

# Generated at 2022-06-24 10:59:56.181497
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert SchemaDefinitions().__getitem__("") == None
    assert SchemaDefinitions().__getitem__("") == None


# Generated at 2022-06-24 10:59:59.818788
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions('a', b = 1)
    s['c'] = (1, 2)
    print(s, s['a'], s['b'], s['c'])
    del s['b']
    print(s)
    try:
        s[None]
    except:
        print('got excetion')
    for k, v in s.items():
        print(k, ':', v)


# Generated at 2022-06-24 11:00:10.447399
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class UnitTestSchemaExample(Schema):
        first_name = String()
    
    # Create a Reference object using the class UnitTestSchemaExample
    reference = Reference(to = UnitTestSchemaExample.__name__)
    
    # Create an instance of UnitTestSchemaExample
    schema = UnitTestSchemaExample(first_name = 'Ryan')
    
    # The instance schema should be serialized without problems
    # with the method serialize of Reference
    serializedData = reference.serialize(schema)
    expectedData = {'first_name': 'Ryan'}
    assert serializedData == expectedData, serializedData
    
    # If a null value is passed as a parameter we should raise a ValidationError
    # with the message May not be null.

# Generated at 2022-06-24 11:00:13.157282
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    d = SchemaDefinitions()
    assert d == {}

from typesystem.fields import Integer, String
from typesystem.schemas import Schema, Reference
from typesystem.schemas import test_SchemaDefinitions
from copy import deepcopy


# Generated at 2022-06-24 11:00:21.841147
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Positive test cases (examples) with satisfying input
    print('\nPositive test cases (examples) with satisfying input:')
    class TestA(Schema):
        pass
    class TestB(TestA):
        a = Field(type=str)
        b = Field(type=str)
    class TestC(TestB):
        pass
    class TestD(TestB):
        a = Field(type=str)
        b = Field(type=str)
    class TestE(TestB):
        a = Field(type=str)
        b = Field(type=str)
    class TestF(TestB):
        a = Field(type=str)
        b = Field(type=str)
    assert TestB.__repr__() == 'TestB()'
    assert TestC.__repr__()

# Generated at 2022-06-24 11:00:23.733671
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # Testing for function init.
    defs = SchemaDefinitions()
    assert defs == {}


# Generated at 2022-06-24 11:00:26.616958
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer, String

    class Foo(Schema):
        score = Integer()
        name = String()

    assert Foo.fields == {
        "name": String(),
        "score": Integer(),
    }



# Generated at 2022-06-24 11:00:30.726488
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class PersonSchema(Schema):
        name = String()
    person = PersonSchema.validate({"name": "Fletcher Heisler"})
    assert person.name == "Fletcher Heisler"


# Generated at 2022-06-24 11:00:41.119798
# Unit test for method validate of class Reference
def test_Reference_validate():
    from collection.abc import Mapping

    class MySchema(object):
        def validate(self, value, strict=False):
            return value

    my_ref = Reference(to=MySchema)
    def g():
        yield 1
    def g2():
        yield 1
        yield 2
    def g3():
        yield 1
        yield 2
        yield 3

    value = 42
    assert my_ref.validate(value) == value

    value = "abc"
    assert my_ref.validate(value) == value

    value = []
    assert my_ref.validate(value) == value

    value = ()
    assert my_ref.validate(value) == value

    value = {}
    assert my_ref.validate(value) == value

    value = set()

# Generated at 2022-06-24 11:00:43.686464
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class A(Schema):
        a=Integer
    assert len(A({'a': 1})) == 1



# Generated at 2022-06-24 11:00:46.410713
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schemaDefinitions = SchemaDefinitions()
    schemaDefinitions['1'] = 'a'
    assert(schemaDefinitions['1'] == 'a')


# Generated at 2022-06-24 11:00:47.784242
# Unit test for constructor of class Reference
def test_Reference():
    expected = Reference(to = "string", allow_null=True)


# Generated at 2022-06-24 11:00:48.749401
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert True


# Generated at 2022-06-24 11:00:52.803599
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        test_field = String(required=True)
    class TestSchema2(Schema):
        test_schema = Reference(TestSchema, required=True)
    schema = TestSchema2.validate({"test_schema": {"test_field": "some_text"}})
    assert schema['test_schema'] == {"test_field": "some_text"}

# Generated at 2022-06-24 11:00:59.384958
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert definitions == {}
    definitions['a'] = '1'
    assert definitions['a'] == '1'
    assert 'a' in definitions
    assert not ('b' in definitions)
    definitions['b'] = '2'
    assert definitions.keys() == {'a', 'b'}
    assert definitions.values() == {'1', '2'}
    del definitions['a']
    assert definitions['b'] == '2'


# Generated at 2022-06-24 11:01:03.939446
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    s = SchemaDefinitions()
    assert list(s) == []
    s = SchemaDefinitions({"a": 1, "b": 2, "c": 3})
    assert list(s) == ["a", "b", "c"]


# Generated at 2022-06-24 11:01:11.420945
# Unit test for method __len__ of class Schema

# Generated at 2022-06-24 11:01:14.278974
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class S(metaclass=SchemaMetaclass):
        ...
    assert S.__class__.__bases__ == (Schema,)
    assert not S.__class__.__dict__


# Generated at 2022-06-24 11:01:25.221141
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        foo = String()
    class B(Schema):
        foo = String()
        bar = Reference("C")

    class C(Schema):
        foo = String()
        bar = Reference("D")

    class D(Schema):
        foo = String()
        bar = Reference("A")

    definitions = SchemaDefinitions()
    assert set_definitions(B.fields["bar"], definitions) == None
    assert set_definitions(C.fields["bar"], definitions) == None
    assert set_definitions(D.fields["bar"], definitions) == None
    assert definitions == {"B": B, "C": C, "D": D, "A": A}

# Generated at 2022-06-24 11:01:33.650854
# Unit test for constructor of class Schema
def test_Schema():
    class Test(Schema):
        field1 = String()
        field2 = String(default="foo")

    s = Test(field1="bar")
    assert s == Test(field1="bar", field2="foo")
    s = Test({"field1": "bar"})
    assert s == Test(field1="bar", field2="foo")
    s = Test(field2="baz", field1="bar")
    assert s == Test(field1="bar", field2="baz")
    s = Test({"field1": "bar", "field2": "baz"})
    assert s == Test(field1="bar", field2="baz")
    s = Test({"field2": "baz", "field1": "bar"})
    assert s == Test(field1="bar", field2="baz")

# Generated at 2022-06-24 11:01:39.585864
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        first_name = Field(string=True)
        last_name = Field(string=True)

    person = Person({"first_name": "Tom", "last_name": "Grisafi"})

    assert person["first_name"] == "Tom"
    assert person["last_name"] == "Grisafi"

    # A Field subclass is callable (a descriptor).
    assert callable(person.first_name)
    assert callable(person.last_name)
    assert person.first_name == person["first_name"]
    assert person.last_name == person["last_name"]



# Generated at 2022-06-24 11:01:44.269676
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
  # local variables
  schema = Schema()
  schema["42"] = "snaketime"
  schema["meow"] = "hiss"
  iterator = schema.keys()
  
  # operation
  #assert iterator.__next__() == "42" # unordered dictionary
  assert iterator.__next__() == "meow"
  #assert iterator.__next__() == "42" # unordered dictionary
  assert iterator.__next__() == "meow"


# Generated at 2022-06-24 11:01:48.676403
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():

    class User(Schema):
        name = String()
        age = Integer()

    user = User(**{"name": "John", "age": 99})
    data = user["name"]
    assert data == "John"

# Generated at 2022-06-24 11:01:49.720506
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Examples and/or test cases go here.
    pass

# Generated at 2022-06-24 11:01:52.677505
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # __delitem__ should delete the right item

    definitions = SchemaDefinitions()
    definitions["test"] = "test"
    assert len(definitions) == 1

    del definitions["test"]
    assert len(definitions) == 0


# Generated at 2022-06-24 11:01:53.795189
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    instance = Schema({})
    assert list(instance) == []


# Generated at 2022-06-24 11:01:59.266682
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Create an instance of SchemaDefinitions
    schema_definitions = SchemaDefinitions()
    # Retrieve the iterable equivalent of the instance of SchemaDefinitions and
    # verify it's type
    result = iter(schema_definitions)
    assert isinstance(result, typing.Iterator)
    # Verify that the iterator returns no values
    assert not list(result)


# Generated at 2022-06-24 11:02:07.314826
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        def __init__(self, **kwargs: typing.Any) -> None:
            for key in self.fields.keys():
                if key in kwargs:
                    setattr(self, key, kwargs.pop(key))
            if kwargs:
                key = list(kwargs.keys())[0]
                class_name = self.__class__.__name__
                message = f"{key!r} is an invalid keyword argument for {class_name}()."
                raise TypeError(message)
    
    foo = Foo(a = 10)


# Generated at 2022-06-24 11:02:16.465465
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    class A(Schema):
        id = Field(str)

    assert len(definitions) == 1
    assert 'A' in definitions.keys()

    class B(Schema):
        id = Field(str)
        a = Field(Reference('A'))

    assert len(definitions) == 2
    assert 'A' in definitions.keys()
    assert 'B' in definitions.keys()

test_SchemaDefinitions___setitem__()

# Generated at 2022-06-24 11:02:29.913765
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    assert len(obj) == 0
    obj["__test1__"] = "test1"
    assert len(obj) == 1
    obj["__test2__"] = "test2"
    assert len(obj) == 2
    obj["__test3__"] = "test3"
    assert len(obj) == 3
    del obj["__test1__"]
    assert len(obj) == 2
    del obj["__test1__"]
    assert len(obj) == 2
    del obj["__test2__"]
    assert len(obj) == 1
    del obj["__test3__"]
    assert len(obj) == 0
    obj["__test1__"] = "test1"
    assert len(obj) == 1
    obj["__test1__"] = "test1"

# Generated at 2022-06-24 11:02:31.511421
# Unit test for constructor of class Schema
def test_Schema():
    assert True
    # TODO: Test Schema constructor


# Generated at 2022-06-24 11:02:38.655397
# Unit test for function set_definitions
def test_set_definitions():
    A = Schema(
        {"x": Field(type="string"), "y": Field(type="string", allow_null=True)}
    )
    B = Schema({"field_a": Reference(to=A), "field_b": Reference(to="A")})
    definitions = SchemaDefinitions()
    set_definitions(field=B, definitions=definitions)
    assert definitions["A"] is A
    assert B.fields["field_a"].definitions is definitions
    assert B.fields["field_b"].definitions is definitions

# Generated at 2022-06-24 11:02:42.765329
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = {"a": int, "b": str, "c": (int, str)}
    class TestSchema(Schema):
        properties = schema
    t = TestSchema({"a": 1, "b": "2"})
    assert len(t) == 2


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 11:02:46.035410
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference(to='abc')
    assert r._target_string == 'abc'

    def abc():
        return True

    r._target = abc
    assert r.target == abc


# Generated at 2022-06-24 11:02:49.001549
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    def_ = SchemaDefinitions()
    def_['key'] = 'value'
    assert def_['key'] == 'value'
    del def_['key']
    try:
        def_['key']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-24 11:02:52.631303
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class A(Schema):
        to_b = Reference("B")
    class B(Schema):
        pass
    set_definitions(A(), definitions)
    assert definitions["A"] == A
    assert A.to_b.definitions == definitions
    assert definitions["B"] == B
    assert A.to_b.target == B

# Generated at 2022-06-24 11:02:59.489693
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = Schema(None)
    b = Schema(None)
    assert (a == b)

    # this is the key part of this test
    # a = Schema("a")
    # b = Schema("b")
    # assert (a != b)
    a = Schema("a")
    b = Schema("b")
    assert (a == b)

test_Schema___eq__()

# Generated at 2022-06-24 11:03:07.237361
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a_property = Field(int)
        a_property2 = Field(float)
        a_property3 = Field(str)
        a_property4 = Field(bool)

    class B(Schema):
        b_property = Field(int)
        b_property2 = Field(int)
        b_property3 = Field(int)
        b_property4 = Field(int)
    assert (A(a_property=3, a_property4=True) == A(a_property4=True, a_property=3)) == True
    assert (A(a_property=3, a_property4=True) == A(a_property4='True', a_property=3)) == False

# Generated at 2022-06-24 11:03:11.541055
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    test_SchemaDefinitions = SchemaDefinitions()
    expected = {}
    actual = test_SchemaDefinitions
    assert expected == actual


# Generated at 2022-06-24 11:03:19.244848
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        bar = Integer()
        baz = String()
    # __init__():
    foo = Foo({'bar': 1, 'baz': 'a'})
    assert foo.bar == 1
    assert foo.baz == 'a'
    # __init__():
    foo = Foo(Foo({'bar': 1, 'baz': 'a'}))
    assert foo.bar == 1
    assert foo.baz == 'a'
    # __init__():
    foo = Foo(bar=1, baz='a')
    assert foo.bar == 1
    assert foo.baz == 'a'
    # make_validator():
    foo = Foo.make_validator()
    foo.validate({'bar': 1, 'baz': 'a'})
    # validate():

# Generated at 2022-06-24 11:03:22.783782
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class MySchema(Schema):
        age = Field(type="integer")


    my_schema = MySchema(age=10)  # type: ignore

    value = my_schema["age"]
    assert value == 10



# Generated at 2022-06-24 11:03:30.038188
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import String

    class User(Schema):
        name = String()

    class Request(Schema):
        user = Reference(to=User)

    request = Request({"user": {"name": "me"}})
    assert request.user.name == "me"
    request2 = Request({"user": None})
    assert request2.user is None
    request3 = Request({"user": {"name": "you"}})
    assert request3.user.name == "you"
    try:
        _ = Request({"user": "you"})
    except Exception as e:
        assert isinstance(e, TypeError)
        assert str(e) == "Invalid argument 'user' for Request(). Object is not of type 'dict'."
        pass

# Generated at 2022-06-24 11:03:37.646401
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class Movie(Schema):
        title = String()
        who = Reference(Person)

    a = Movie({"title": "Joker", "who": {"name": "Joker", "age": 34}})
    assert a.validate(a) == a
    assert a.validate({"title": "Joker", "who": {"name": "Joker", "age": 34}}) == a
    assert a.validate_or_error({"title": "Joker", "who": {"name": "Joker", "age": 34}}) == \
        ("success", "Joker", {"title": "Joker", "who": {"name": "Joker", "age": 34}}, None)

# Generated at 2022-06-24 11:03:44.366555
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # define test data
    input_Schema_object = {}
    input_key = {}
    input_field = {}
    input_value = {}
    expected_output = {}
    # define test function
    def test_function(input_Schema_object, input_key):
        return input_Schema_object.__getitem__(input_key)
    # execute test
    output = test_function(input_Schema_object, input_key)
    assert output == expected_output


# Generated at 2022-06-24 11:03:51.515557
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert isinstance(sd, MutableMapping)
    sd['test1'] = 1
    assert 'test1' in sd.keys()
    assert sd['test1'] == 1
    del(sd['test1'])
    assert 'test1' not in sd.keys()

# Generated at 2022-06-24 11:03:59.216922
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.validators import format_regex

    class Person(Schema):
        name = String()
        email = String(validators=[format_regex(r'\b[^@]+@[^@]+\.[^@]+\b')])
        age = Integer()

    class Company(Schema):
        name = String()
        employees = Array(Reference(Person))

    company = Company(name='Company', employees=[Person(name='John', email='john@company.com', age=24)])
    assert company == Company.validate(company)
    assert company.serialize() == {'name': 'Company', 'employees': [{'name': 'John', 'email': 'john@company.com', 'age': 24}]}

# Generated at 2022-06-24 11:04:07.135699
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    to = type('Schema', (Schema,), {})
    to.fields = {}
    definition = SchemaDefinitions()
    defi = Reference(to, definition)
    cls = type('Schema', (Schema,), {})
    cls.fields = {
        'full_name': defi
    }
    s = cls(full_name=to())
    assert isinstance(s.full_name, to)
    assert dict(s.full_name) == dict(s.full_name.serialize(s.full_name))

# Generated at 2022-06-24 11:04:13.018089
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema):
        name = String()
        age = Integer()

    def filter_schema(fields):
        for item in fields.items():
            if item[0] != '_creation_counter':
                yield item

    assert dict(filter_schema(TestSchema.fields)) == {
        'name': String(), 'age': Integer()
    }


# Generated at 2022-06-24 11:04:20.910007
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Fruit(Schema):
        name = Field(type="string")
        color = Field(type="string")
    class Apple(Fruit):
        color = Field(default="red")
    class Banana(Fruit):
        color = Field(default="yellow")

    assert Fruit(name="Apple") == Fruit(name="Apple")
    assert Apple(name="Apple") == Apple(name="Apple")
    assert Fruit(name="Apple", color="green") == Fruit(name="Apple", color="green")
    assert Fruit(name="Apple", color="green") != Fruit(name="Apple", color="yellow")
    assert Apple() != Banana()
    assert Apple(name="Apple") != Fruit(name="Apple")
    assert Apple(name="Apple") != Fruit(name="Apple", color="yellow")

# Generated at 2022-06-24 11:04:25.686393
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Point(Schema):
        x = Field()
        y = Field()

    point = Point(x=1, y=2)
    assert point.x == 1
    assert point.y == 2
    assert point["x"] == 1
    assert point["y"] == 2



# Generated at 2022-06-24 11:04:27.632168
# Unit test for method validate of class Reference
def test_Reference_validate():
    f = Reference(to="test")
    f.validate(value= {'a':'a'}) == {'a':'a'}

# Generated at 2022-06-24 11:04:30.346294
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    dic = {'a': 1, 'b': 2, 'c': 3}
    obj = SchemaDefinitions(**dic)
    for it in obj:
        assert it in dic

# Generated at 2022-06-24 11:04:40.371709
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .types import Type
    from .enums import BaseEnum
    from typesystem import String, Number
    class FruitEnum(BaseEnum):
        apple = "apple"
        banana = "banana"
        cherry = "cherry"
    class Fruit(Type):
         name = String()
         color = String()
         calories = Number()
         category = FruitEnum()
    a = Fruit(color="red", name="apple", calories=3)
    b = Fruit(color="red", name="apple", calories=3)
    c = Fruit(color="red", name="banana", calories=3)
    d = Fruit(color="green", name="apple", calories=3)
    assert(a == b)
    assert(a != c)
    assert(a != d)


# Generated at 2022-06-24 11:04:45.225220
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import Boolean, Integer, String

    class Example(Schema):
        zero = Integer()
        one = Integer()
        two = Integer()

    example = Example(zero=0, one=1, two=2)
    assert list(iter(example)) == ['zero', 'one', 'two']
    example = Example(one=1, two=2)
    assert list(iter(example)) == ['one', 'two']


# Generated at 2022-06-24 11:04:48.938112
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    #
    class TestSchema(Schema):
        name = String()

    # Nominal test
    schema = TestSchema(name="toto")
    iter_keys = schema.__iter__()
    assert iter_keys == iter(["name"])



# Generated at 2022-06-24 11:04:54.522150
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    from typesystem import Schema

    class Person(Schema):
        first_name = String(max_length=255)
        last_name = String(max_length=255)

    person = Person(first_name="John", last_name="Smith")
    assert [key for key in person] == [
        "first_name",
        "last_name",
    ]


# Generated at 2022-06-24 11:05:00.666119
# Unit test for function set_definitions
def test_set_definitions():
    field = Object(properties={"foo": Integer(required=True), "bar": Integer()})
    definitions = SchemaDefinitions()
    set_definitions(field, definitions)
    assert field.properties["foo"].definitions == definitions
    assert field.properties["bar"].definitions == definitions
    assert field.definitions is None
    assert definitions == SchemaDefinitions()

    field = Array(items=Object(properties={"foo": Integer(), "bar": Integer()}))
    set_definitions(field, definitions)
    assert field.items.properties["foo"].definitions == definitions
    assert field.items.properties["bar"].definitions == definitions
    assert field.items.definitions is None
    assert field.definitions is None
    assert definitions == SchemaDefinitions()

    field = Array(items=[Integer(), Integer()])

# Generated at 2022-06-24 11:05:02.551980
# Unit test for method validate of class Reference
def test_Reference_validate():
    item = Schema(
        [
            Reference("Schema")
        ]
    )
    item.validate(schema)

# Generated at 2022-06-24 11:05:04.007250
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference('Reservation')
    if ref:
        assert True

# Generated at 2022-06-24 11:05:05.987313
# Unit test for method validate of class Reference
def test_Reference_validate():
    test = Reference(to="string")
    assert test.validate("a") == "a"



# Generated at 2022-06-24 11:05:10.632896
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema(Schema):
        a = Field(type="integer")
        b = Field(type="string")
        c = Field(type="boolean")

    obj = MySchema(a=1, b="alpha", c=True)
    assert obj.a == 1
    assert obj.b == "alpha"
    assert obj.c == True


# Generated at 2022-06-24 11:05:14.733161
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        a = Field()
        b = Array(items=Field())
        c = Object(properties={"a": Reference("TestSchema"),})

    definitions = SchemaDefinitions()
    set_definitions(TestSchema, definitions)
    assert "TestSchema" in definitions
    assert (
        TestSchema.fields["c"]
        .properties["a"]
        .target
        == TestSchema.make_validator()
    )



# Generated at 2022-06-24 11:05:25.066959
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """Unit test for method __new__ of class SchemaMetaclass

    """
    import inspect
    import json
    import pdb
    import sys
    import types

    iid = inspect.currentframe().f_lineno # this line's number

    # Debug:
    #   import pdb; pdb.set_trace()
    # Breakpoint:
    #   import pdb; pdb.set_trace();sys.exit(0)
    # Profiling:
    #   import cProfile;cProfile.run('main()', 'prof')
    #   import pstats;p = pstats.Stats('prof')
    #   p.strip_dirs().sor


# Generated at 2022-06-24 11:05:29.898415
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        pass

    ts1 = TestSchema()
    print(ts1)
    ts2 = TestSchema({"aaa":123, "bbb":"abc"})
    print(ts2)
    ts3 = TestSchema(ts2)
    print(ts3)

if __name__ == '__main__':
    test_Schema()

# Generated at 2022-06-24 11:05:38.645772
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from . import Post, User
    data = {'name':'name','age':23,'birthday':'2018-11-11','address':{'street':'abc','city':'abc','country':'abc'}}
    user = User.validate(data)
    serialized = user.__dict__['fields']['id'].serialize(user)
    assert serialized is None
    serialized = user.__dict__['fields']['name'].serialize(user)
    assert serialized == 'name'
    serialized = user.__dict__['fields']['age'].serialize(user)
    assert serialized == 23
    serialized = user.__dict__['fields']['birthday'].serialize(user)
    assert serialized == '2018-11-11'

# Generated at 2022-06-24 11:05:47.775387
# Unit test for method validate of class Reference
def test_Reference_validate():
    class B(Schema):
        y = int
    class A(Schema):
        x = Reference(B)
    assert A().validate({'x':{'y':1}}).target.target_string == 'B'
    assert A().validate({'x':{'y':1}})['x']['y'] == 1
    a = A().validate({'x':{'y':1}})
    a.x.y = 2
    assert a.x.y == 2
    assert A().validate({'x':{'y':1}}).target == B
    assert type(B().validate({'y':1}).y) == int
    assert B().validate({'y':1}).y == 1

# Generated at 2022-06-24 11:05:48.958857
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    SchemaDefinitions.__setitem__


# Generated at 2022-06-24 11:05:54.444763
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_SchemaDefinitions = SchemaDefinitions(**test_dict)
    assert test_SchemaDefinitions['a'] == 1
    assert test_SchemaDefinitions['b'] == 2
    assert test_SchemaDefinitions['c'] == 3


# Generated at 2022-06-24 11:05:58.567183
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    definitions["test"] = "test"
    assert __iter__(definitions) == iter({"test": "test"})

test_SchemaDefinitions___iter__()


# Generated at 2022-06-24 11:06:01.106762
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    print(definitions)


# Generated at 2022-06-24 11:06:02.598452
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    assert False


# Generated at 2022-06-24 11:06:12.238860
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Foo(Schema):
        foo = String()
    class Bar(Schema):
        bar = Integer()
    class Test(Schema):
        ref = Reference(Foo)
    # Test if the Reference object is valid
    if not isinstance(Test.ref, Field):
        raise Exception("Error")
    test = Test(ref = Foo(foo = "foo"))
    if test.ref.foo != "foo":
        raise Exception("Error")
    
    # Test if the value is None and allow_null is True
    ref = Reference(to = Foo, allow_null = True)
    value = ref.validate(None)
    if value is not None:
        raise Exception("Error")
    
    # Test if the value is None and allow_null is False

# Generated at 2022-06-24 11:06:20.267005
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Schema1(Schema):
        name = String()
    class Schema2(Schema):
        position = Integer()
    class Schema3(Schema):
        position = Integer()
        name = String()
    schema1 = Schema1(name='Bob')
    schema2 = Schema2(position=21)
    schema3 = Schema3(position=21, name='Bob')
    print(schema1 == schema2)
    print(schema1 == schema3)
    print(schema1 == schema1)
    print(schema2 == schema3)
    print(schema2 == schema2)
    print(schema3 == schema3)


# Generated at 2022-06-24 11:06:34.113024
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import types, validators
    from typesystem.compat import OrderedDict

    class A(Schema):
        a = types.Integer(required=True)
        b = types.String()

    class B(Schema):
        a = types.Integer()
        b = types.String()

    class C(Schema):
        a = types.Integer()
        b = types.String()
        c = types.String()
        d = types.String()

    class D(C):
        a = types.Integer()
        b = types.String()

    class E(D):
        a = types.Integer()
        b = types.String()

    class F(A):
        a = types.Integer()

    class G(A):
        b = types.String()


# Generated at 2022-06-24 11:06:45.661987
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def_1 = SchemaDefinitions()
    def_2 = SchemaDefinitions({"a" : 1})
    def_3 = SchemaDefinitions(a=1)
    def_4 = SchemaDefinitions({"a" : 1}, a = 2)
    assert len(def_1) == len(def_2) == len(def_3) == len(def_4) == 0
    assert def_2["a"] == def_3["a"] == def_4["a"] == 1
    assert "a" not in def_1
    def_1["a"] = 1
    assert def_1["a"] == def_2["a"] == def_3["a"] == def_4["a"] == 1
    assert "a" in def_1
    def_1["b"] = 2
    assert "b"

# Generated at 2022-06-24 11:06:46.767736
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    pass



# Generated at 2022-06-24 11:06:55.384279
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Create a Schema subclass with no fields.
    class Foo(Schema):
        pass

    # Check that it has no fields.
    assert not getattr(Foo, "fields", {})

    # Create a Schema subclass with one field.
    class Bar(Schema):
        string = String()

    # Check that the field is present.
    assert "string" in Bar.fields

    # Check the type of the field.
    assert isinstance(Bar.fields["string"], String)

    # Instantiate the subclass.
    bar = Bar()

    # Check that the class of the instance matches the subclass.
    assert bar.__class__ is Bar

    # Check that the instance does not have attributes for any fields.
    assert not hasattr(bar, "string")

    # Check that the instance is sparsely populated.

# Generated at 2022-06-24 11:06:57.145023
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    obj = {"Hello": "World"}
    obj1 = Reference("World")
    assert obj1.serialize(obj) == obj

# Generated at 2022-06-24 11:07:04.199020
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    import unittest
    class MyTestSchema(unittest.TestCase):
        class MySchema(Schema):
            foo: int
            bar: str
            
        @classmethod
        def test_create_class_instance(cls):
            MySchema.validate({
                "foo": 123,
                "bar": "xxx",
            })

    MyTestSchema.test_create_class_instance()


# Generated at 2022-06-24 11:07:06.700023
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    pass

# Generated at 2022-06-24 11:07:17.783296
# Unit test for constructor of class Schema
def test_Schema():
    class InnerSchema(Schema):
        #define attributes and their type
        a = Field()
        b = Field()
        c = Field()
        #initialization of attributes
        def __init__(self,a,b,c):
            self.a = a
            self.b = b
            self.c = c

    class OuterSchema(Schema):
        #define attributes and their type
        a = Field()
        b = Field()
        c = Reference(to="InnerSchema")
        #initialization of attributes
        def __init__(self,a,b,c):
            self.a = a
            self.b = b
            self.c = c

    #create objects for InnerSchema
    inner1 = InnerSchema(1,2,3)

# Generated at 2022-06-24 11:07:24.825386
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert issubclass(SchemaMetaclass, type)
    assert hasattr(SchemaMetaclass, "__new__")
    assert callable(SchemaMetaclass.__new__)



# Generated at 2022-06-24 11:07:28.383806
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Target(Schema):
        name = str

    ref = Reference(Target, name="ref")
    target = Target(name="ref")
    assert ref.serialize(target) == {"name": "ref"}

# Generated at 2022-06-24 11:07:31.608494
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = String()
        email = String()

    assert Person.__name__ == 'Person'
    assert Person.fields == {
        'name': String(label='name'),
        'email': String(label='email')
    }


# Generated at 2022-06-24 11:07:43.636735
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        id = Field(serialized_name="id")
        name = Field(serialized_name="name")

    class Post(Schema):
        id = Field(serialized_name="id")
        title = Field(serialized_name="title")
        user = Reference(to=User)

    user = User(id=1, name="John Smith")
    post = Post(id=1, title="My Post", user=user)

    validator = Post.make_validator(strict=True)
    post_data = {
        "id": 1,
        "title": "My Post",
        "user": {"id": 1, "name": "John Smith"},
    }
    post = validator.validate(post_data, strict=True)


# Tests for class Schema

# Generated at 2022-06-24 11:07:44.497741
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len({}) == 0


# Generated at 2022-06-24 11:07:54.908821
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    """
    Test method __iter__ of class SchemaDefinitions
    """
    definitions = SchemaDefinitions()
    definitions = SchemaDefinitions({"a": 1, "b": 2})
    # Assert expected result from method call
    assert sorted(list(definitions.__iter__())) == sorted(["a", "b"])
    definitions = SchemaDefinitions()
    # Assert expected result from method call
    assert sorted(list(definitions.__iter__())) == sorted([])
    definitions = SchemaDefinitions([("a", 1), ("b", 2)])
    # Assert expected result from method call
    assert sorted(list(definitions.__iter__())) == sorted(["a", "b"])
    definitions = SchemaDefinitions(a=1, b=2)
    # Assert expected result from

# Generated at 2022-06-24 11:07:59.812295
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    reference = Reference(object)
    assert reference.serialize(None) == dict()
    assert reference.serialize(dict()) == dict()
    assert reference.serialize(dict(a=1,b=2)) == dict(a=1, b=2)

# Generated at 2022-06-24 11:08:03.058751
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class X(Schema):
        name = Field()

    x1 = X("test")
    assert x1.__repr__() == "X(name='test')"



# Generated at 2022-06-24 11:08:14.473718
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Foo(Schema):
        foo = Reference(to="bar", definitions=definitions)

    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert isinstance(Foo.fields["foo"].target, type)

    class TestArray(Schema):
        foo = Array(Reference(to="bar", definitions=definitions)).bind_parent(foo=dict)

    set_definitions(TestArray.fields["foo"], definitions)

    class TestArrayOfArray(Schema):
        foo = Array(Array(Reference(to="bar", definitions=definitions))).bind_parent(
            foo=dict
        )

    set_definitions(TestArrayOfArray.fields["foo"], definitions)


# Generated at 2022-06-24 11:08:22.937814
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import typesystem
    class FooSchema(typesystem.Schema):
        foo = typesystem.String()
        baz = typesystem.String()
        bar = typesystem.String()
        # def __iter__(self) -> typing.Iterator[str]:
        #     for key in self.fields.keys():
        #         if hasattr(self, key):
        #             yield key
        #     yield from super(FooSchema, self).__iter__()

    fooSchema = FooSchema(foo="hi", baz="there", bar="!")
    fooSchema_iterator = iter(fooSchema)
    assert next(fooSchema_iterator) == "foo"
    assert next(fooSchema_iterator) == "baz"
    assert next(fooSchema_iterator) == "bar"

# Generated at 2022-06-24 11:08:27.554575
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    class A_Schema(Schema):
        a = typesystem.Integer()
        b = typesystem.Integer()
        c = typesystem.Integer()
    assert A_Schema.fields == {'a': A_Schema.a, 'b': A_Schema.b, 'c': A_Schema.c}


# Generated at 2022-06-24 11:08:29.402665
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    def_ins = SchemaDefinitions({"a": 2})
    assert def_ins["a"] == 2


# Generated at 2022-06-24 11:08:33.556837
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    expected = '''
    class Foo(Schema):
        foo = String()
        bar = Array(String)


    foo = Foo(foo="one", bar=[1, "two", 3.0])
    '''

    foo = eval(expected)

    actual = [key for key in foo]
    expected = ['foo', 'bar']
    assert actual == expected

# Generated at 2022-06-24 11:08:36.174465
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Test(Schema):
        pass
    assert Test.__name__ == "Test"
    assert isinstance(Test.fields, dict)
    assert Test.fields == {}



# Generated at 2022-06-24 11:08:39.784067
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    s = Schema(
        fields={"foo": Field(primitive_type=int), "bar": Field(primitive_type=str)},
        foo=123,
        bar="string",
    )
    assert s["foo"] == 123
    assert s["bar"] == "string"
    # Invalid key
    try:
        s["baz"]
    except KeyError:
        return
    raise AssertionError("Invalid key did not raise KeyError")


# Generated at 2022-06-24 11:08:42.598964
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = Field(str, required=True)

    p1 = Person(name="Bob")
    p2 = Person(name="Bob")
    assert p1 == p2

    p2.name = "Sue"
    assert p1 != p2


# Generated at 2022-06-24 11:08:46.383113
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    from typesystem.base import SchemaDefinitions as SD
    assert isinstance(SD(), SD)
    assert isinstance(SD(None), SD)
    try:
        SD(None, None)
    except Exception as e:
        assert(str(e) == "__init__ takes from 1 to 2 arguments (3 given)")



# Generated at 2022-06-24 11:08:49.645198
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    test_object = SchemaDefinitions({"foo":1})
    test_value = "foo"
    test_object.__delitem__(test_value)
    assert not test_value in test_object


# Generated at 2022-06-24 11:08:52.569833
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    p = Person(name="John Smith", age=42)
    assert p.name == "John Smith"
    assert p.age == 42


# Generated at 2022-06-24 11:09:00.814198
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaA(Schema):
        s = Reference("SchemaB")
        a = Reference("SchemaB")
        b = Reference("SchemaA")

    class SchemaB(Schema):
        s = Reference("SchemaA")
        a = Reference("SchemaA")

    definitions = SchemaDefinitions()

    set_definitions(SchemaA, definitions)
    set_definitions(SchemaB, definitions)

    # Check expected results.
    assert SchemaA.fields["s"].definitions == definitions
    assert SchemaA.fields["a"].definitions == definitions
    assert SchemaA.fields["b"].definitions == definitions

    assert SchemaB.fields["s"].definitions == definitions
    assert SchemaB.fields["a"].definitions == definitions

# Generated at 2022-06-24 11:09:03.350890
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    schema = Schema()
    definitions = SchemaDefinitions()
    definitions[schema.__class__.__name__] = schema
    for name in definitions:
        assert name in definitions.keys()


# Generated at 2022-06-24 11:09:10.080507
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchemaMetaclass(Schema):
        pass

    class TestSchemaMetaclassSubclass(TestSchemaMetaclass):
        field1 = Field()
        field2 = Field()

    # isinstance(TestSchemaMetaclassSubclass, Schema) is True 
    assert isinstance(TestSchemaMetaclassSubclass, Schema)
    # TestSchemaMetaclassSubclass.fields is {'field1': <Field>}
    assert TestSchemaMetaclassSubclass.fields == {'field1': Field()}


# Generated at 2022-06-24 11:09:12.391344
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    s = SchemaDefinitions()
    s["foo"] = "bar"
    assert s["foo"] == "bar"


# Generated at 2022-06-24 11:09:23.483284
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer, String

    class Author(Schema):
        name = String()
        id = Integer()

    class Book(Schema):
        author = Reference(to=Author, name="author")
        id = Integer()


# Generated at 2022-06-24 11:09:30.637260
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    class TestSchema1(Schema):
        pass
    class TestSchema2(Schema):
        pass
    assert TestSchema1.__name__ not in definitions
    assert TestSchema2.__name__ not in definitions
    TestSchema2.__init__(TestSchema2, *[], **{'field1': 'value1'})
    assert TestSchema1.__name__ not in definitions
    assert TestSchema2.__name__ not in definitions



# Generated at 2022-06-24 11:09:32.978492
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # Initialize the test object
    obj = SchemaDefinitions({'key1': 'value1', 'key2': 'value2'})
    # Verify the object's existence
    assert obj is not None



# Generated at 2022-06-24 11:09:35.747087
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="number")
    result = TestSchema({"a": "test", "b": 1})
    expected = {'a': 'test', 'b': 1}
    assert result == expected


# Generated at 2022-06-24 11:09:46.575258
# Unit test for function set_definitions
def test_set_definitions():
    test_data = {
        "type": "object",
        "properties": {
            "foo": {
                "type": "object",
                "properties": {
                    "bar": {"type": "string"},
                },
            },
        },
    }

    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()

    Foo.fields["foo"].definitions = definitions
    Bar.fields["bar"].definitions = definitions

    set_definitions(Foo.make_validator(), definitions)

    foo = Foo.validate(test_data)
    assert "\x08Foo" in repr(foo)
    assert "\x08Bar" in repr(foo)

# Generated at 2022-06-24 11:09:52.598200
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    """
    Test for method __delitem__ of class 
    SchemaDefinitions
    """
    print("Test for method __delitem__ of class SchemaDefinitions")
    definitions = SchemaDefinitions()
    definitions['foo'] = 12
    assert definitions['foo'] == 12 
    del definitions['foo']
    try:
        definitions['foo']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 11:09:56.149531
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["test"] = "test"
    assert(len(schema_definitions) == 1)
    del schema_definitions["test"]
    assert(len(schema_definitions) == 0)
