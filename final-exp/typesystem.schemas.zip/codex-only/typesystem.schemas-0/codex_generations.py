

# Generated at 2022-06-24 11:00:00.980152
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String
    from typesystem.types import Choice
    from typesystem.validators import Contains
    from typesystem.validators import MaxLength
    class Pet(Schema):
        name = String(validators=[Contains(["Tom", "Jerry"]), MaxLength(10)])
        type = String(validators=[Choice(["cat", "dog", "bird"])])
    definitions = SchemaDefinitions()
    Pet()
    assert definitions['Pet'] == Pet
    Pet('{"name": "Tom", "type": "cat"}')
    assert definitions['Pet'] == Pet
    Pet(name="Tom")
    assert definitions['Pet'] == Pet
    Pet(name="Tom", type="cat")
    assert definitions['Pet'] == Pet



# Generated at 2022-06-24 11:00:04.449197
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions({
        'key1': 1,
        'key2': 2,
        'key3': 3
    })
    assert iter(definitions) == iter({'key1': 1, 'key2': 2, 'key3': 3})



# Generated at 2022-06-24 11:00:05.517843
# Unit test for constructor of class Reference
def test_Reference():
    assert "Valid"


# Generated at 2022-06-24 11:00:13.115811
# Unit test for function set_definitions
def test_set_definitions():
    class InnerSchema(Schema):
        inner_field = Reference(to='OuterSchema')

    class OuterSchema(Schema):
        outer_field = Reference(to='InnerSchema')

    definitions = SchemaDefinitions()

    assert OuterSchema.fields['outer_field'].definitions is None
    assert InnerSchema.fields['inner_field'].definitions is None

    set_definitions(OuterSchema.fields['outer_field'], definitions=definitions)
    set_definitions(InnerSchema.fields['inner_field'], definitions=definitions)

    assert OuterSchema.fields['outer_field'].definitions is definitions
    assert InnerSchema.fields['inner_field'].definitions is definitions

# Generated at 2022-06-24 11:00:21.204426
# Unit test for method validate of class Reference
def test_Reference_validate():
    class OneProperty(Schema):
        property = String()

    class TwoProperties(Schema):
        property_one = String()
        property_two = String()

    definitions = SchemaDefinitions({"OneProperty": OneProperty, "TwoProperties": TwoProperties})

    reference_to_one_property = Reference("OneProperty", definitions=definitions)
    input_dict_with_one_property_for_reference_to_one_property = {'property': 'prop1'}
    output_dict_after_validation_of_the_input_dict_with_one_property_for_reference_to_one_property = reference_to_one_property.validate(input_dict_with_one_property_for_reference_to_one_property)


# Generated at 2022-06-24 11:00:24.532203
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(Schema, metaclass=SchemaMetaclass):
        test_field = {}

    assert "{}", list(TestSchemaMetaclass___new__.fields.items())



# Generated at 2022-06-24 11:00:31.205506
# Unit test for constructor of class Reference
def test_Reference():
    parameter_to = 'Reference to'
    parameter_definitions = 'Definitions of Reference'
    parameter_allow_null = False
    parameter_description = 'Reference to Object'
    parameter_metadata = {'test': 'test'}
    parameter_required = True
    parameter_title = 'Reference'

    reference = Reference(parameter_to, parameter_definitions, parameter_allow_null,
                          parameter_description, parameter_metadata, parameter_required, parameter_title)

    assert reference.to == parameter_to
    assert reference.definitions == parameter_definitions
    assert reference.allow_null == parameter_allow_null
    assert reference.description == parameter_description
    assert reference.metadata == parameter_metadata
    assert reference.required == parameter_required
    assert reference.title == parameter_title
#



# Generated at 2022-06-24 11:00:37.528569
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import String

    class Meta(SchemaMetaclass):
        pass

    class TestSchema(Schema, metaclass=Meta):
        name = String()

    schema = TestSchema(name="name")
    assert schema["name"] == "name"

    with pytest.raises(KeyError):
        schema["invalid"]



# Generated at 2022-06-24 11:00:42.567068
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem.fields import String, Number, Integer, Boolean, Any

    class A(metaclass=SchemaMetaclass):
        pass

    class B(A):
        pass

    class C(A):
        a = Boolean()
        b = Integer()

    class D(B, C):
        c = String()
        d = Number()

    # class E(D):
    #     z = Any()

    assert d.fields["c"].name == "c"
    assert d.fields["a"].name == "a"


# Generated at 2022-06-24 11:00:50.721165
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    def test_invalid_key():
        with raises(KeyError):
            obj = SchemaDefinitions()
            key = "invalid"
            result = obj.__getitem__(key)

    def test_missing_key():
        with raises(KeyError):
            obj = SchemaDefinitions()
            key = "invalid"
            result = obj.__getitem__(key)

    def test_valid_key():
        obj = SchemaDefinitions()
        key = "key"
        expected = "value"
        obj.__setitem__(key, expected)
        result = obj.__getitem__(key)
        assert result == expected



# Generated at 2022-06-24 11:01:00.080244
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    p = Person(name="Bob", age=12)

    assert p["name"] == "Bob"
    assert p["age"] == 12

    with pytest.raises(KeyError) as exc_info:
        p["sex"]
    assert str(exc_info.value) == "'sex'"



# Generated at 2022-06-24 11:01:02.025526
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    d = SchemaDefinitions({'1': 1, '2': 2})
    assert d['1'] == 1
    assert d['2'] == 2


# Generated at 2022-06-24 11:01:07.672776
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class UserSchema(Schema):
        name = String(required=False)
        age = Integer()
    user = UserSchema(name="Bob", age=20)
    assert user["name"] == "Bob"
    assert user["age"] == 20
    assert user == {"age": 20, "name": "Bob"}
    print("test_Schema___getitem__() passed")


# Generated at 2022-06-24 11:01:10.166751
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    d = SchemaDefinitions()
    try:
        assert d.__len__() == 0
    except:
        return False
    return True


# Generated at 2022-06-24 11:01:14.156675
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
	s = SchemaDefinitions()
	s['a'] = 1
	s['b'] = 2
	assert s['a'] == s['b']
	try:
		s['a'] = 1
		assert False
	except AssertionError:
		pass


# Generated at 2022-06-24 11:01:24.886606
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    """Test method __len__ of class SchemaDefinitions"""
    # Example 1 of __len__
    # Create an instance of SchemaDefinitions
    schema_definitions_instance1 = SchemaDefinitions()
    # Assert len(schema_definitions_instance1) == 0
    assert len(schema_definitions_instance1) == 0
    # Create an instance of SchemaDefinitions
    schema_definitions_instance2 = SchemaDefinitions({'a':1, 'b':2})
    # Assert len(schema_definitions_instance2) == 2
    assert len(schema_definitions_instance2) == 2
    

# Generated at 2022-06-24 11:01:27.238965
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    num = len(obj)
    assert num == obj.__len__()


# Generated at 2022-06-24 11:01:37.601711
# Unit test for method validate of class Reference

# Generated at 2022-06-24 11:01:41.580948
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from pyspark.sql import DataFrame
    from pyspark.sql.types import IntegerType, StructType, StructField
    from typing import List, Dict

    data = DataFrame([[1], [2], [3]], StructType([StructField('a', IntegerType(), True)]))

    def test_list_definition() -> None:
        definitions = SchemaDefinitions()
        # Test list definition
        definitions['test_list_definition'] = List[int]
        assert definitions['test_list_definition'] == List[int]

    def test_dict_definition() -> None:
        defi

# Generated at 2022-06-24 11:01:49.721144
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        test_field = Field(str)

    s = TestSchema(test_field="test")
    assert list(s.__iter__()) == ["test_field"]

    s = TestSchema()
    assert list(s.__iter__()) == []



# Generated at 2022-06-24 11:01:51.411403
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to="foo").serialize(Schema()) == {'bar': 1}


# Generated at 2022-06-24 11:01:52.869792
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert False


# Generated at 2022-06-24 11:02:04.737011
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Create a set of schema definitions
    schema_definitions = SchemaDefinitions()

    # Create a dictionary of items
    items = {'item1': 'item1', 'item2': 'item2', 'item3': 'item3'}

    # Populate the set of schema definitions with the items from 
    # the dictionary
    for key in items:
        schema_definitions[key] = items[key]

    # Create an iterator to iterate of the items in the set of 
    # schema definitions
    iter_obj = iter(schema_definitions)

    # Iterate over the items in the set of schema definitions
    # using the iterator
    key_list = []

# Generated at 2022-06-24 11:02:07.834435
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    class Person(Schema):
        name = Field()
        age = Field()
    definitions = SchemaDefinitions()
    definitions['person'] = Person


    to_test = list(definitions)

    assert to_test == ['person']


# Generated at 2022-06-24 11:02:12.109883
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference(to = "u", definitions = "a")
    assert r.to == "u"
    assert r.definitions == "a"


# Generated at 2022-06-24 11:02:20.750242
# Unit test for method __eq__ of class Schema

# Generated at 2022-06-24 11:02:23.017504
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['1'] = 1
    assert definitions['1'] == 1
    del definitions['1']
    try:
        definitions['1']
    except KeyError:
        pass



# Generated at 2022-06-24 11:02:25.702107
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["a"] = "hello"
    assert definitions["a"] == "hello"


# Generated at 2022-06-24 11:02:32.215371
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        definitions = SchemaDefinitions()
        prop1 = Reference("MyRefSchema")
        prop2 = Reference(MyRefSchema)
        prop3 = Object(
            properties = {
                'prop1': Reference("MyRefSchema"),
                'prop2': Reference(MyRefSchema)
            }
        )
        prop4 = Array(items = [
            Reference("MyRefSchema"),
            Reference(MyRefSchema)
        ])

    class MyRefSchema(Schema):
        definitions = SchemaDefinitions()
        prop1 = Reference("MyRef2Schema")
        prop2 = Reference(MyRef2Schema)

# Generated at 2022-06-24 11:02:38.562718
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    """
    Check whether __delitem__ performs as expected
    """
    x = SchemaDefinitions()
    x["foo"] = "bar"
    x["foo"]
    x.__delitem__("foo")
    try:
        x["foo"]
    except KeyError as e:
        print(f"Function __delitem__ raised KeyError as expected")
    else:
        print(f"Function __delitem__ did not raise KeyError as expected")


# Generated at 2022-06-24 11:02:42.848131
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Set-up

    def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
        self._definitions = dict(*args, **kwargs)  # type: dict

    definitions = dict()
    value = definitions[""]
    # Exercise

    # Verify

    # Cleanup - N/A
    return value


# Generated at 2022-06-24 11:02:52.680450
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # --- variables ----------------------------------------------------------
    field = Field()
    attrs = {
        "fields": {
            "key1": field
        }
    }
    name = "Name1"
    bases = ()
    definitions = SchemaDefinitions()

    # --- test ---------------------------------------------------------------
    SchemaMetaclass.__new__(SchemaMetaclass, name, bases, attrs, definitions)

    # --- check --------------------------------------------------------------

# Generated at 2022-06-24 11:02:53.742492
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    pass



# Generated at 2022-06-24 11:03:01.996118
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Setup data
    class FakeSchema:
        def validate(self, value, *, strict = False):
            return value
    class FakeDefinitions:
        def __getitem__(self, key):
            return FakeSchema()
    fake_definiton = FakeDefinitions()
    fake_reference = Reference("test", definitions=fake_definiton)
    object_to_test = "some random value"


    # Start testing
    try:
        result = fake_reference.validate(object_to_test, strict=False)
    except Exception:
        assert False, "The method threw an Exception"

    assert isinstance(result, str)
    assert result == object_to_test, "The method did not return the correct result"



# Generated at 2022-06-24 11:03:07.944392
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Preparations
    from typesystem.types import String
    from typesystem.fields import Integer

    # Test
    class TestSchema(Schema):
        a = String(required=True)
        b = String()
        c = String()
    assert TestSchema(a="1", b="2").__getitem__("a") == "1"
    assert TestSchema(a="1", b="2").__getitem__("b") == "2"

    with raises(KeyError):
        TestSchema(a="1", b="2").__getitem__("z")


# Generated at 2022-06-24 11:03:16.746730
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")
        fizz = Reference("Fizz")

    class Bar(Schema):
        name = Reference("Name")

    class Baz(Schema):
        name = Reference("Name")

    class Name(Schema):
        first_name = Reference("FirstName")
        last_name = Reference("LastName")

    definitions = SchemaDefinitions(
        {
            "Foo": Foo,
            "Bar": Bar,
            "Baz": Baz,
            "Name": Name,
            "FirstName": Reference("FirstName"),
            "LastName": Reference("LastName"),
        }
    )

    assert Bar.fields["name"].definitions is None
    set_definitions(Foo, definitions)
    assert Bar.fields

# Generated at 2022-06-24 11:03:17.316521
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    pass

# Generated at 2022-06-24 11:03:20.278511
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()

    Person.validate({'name': 'fred'}) == Person.validate({'name': 'fred'})


# Generated at 2022-06-24 11:03:28.364079
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    class Foo(Schema):
        a = Field()
    foo = Foo(a=1)
    bar = Foo(a=2)
    assert foo.a == 1
    assert bar.a == 2
    definitions = SchemaDefinitions()
    definitions[Foo] = foo
    assert definitions[Foo] == foo
    definitions["foo"] = bar
    assert definitions["foo"] == bar
    assert len(definitions) == 2
    with pytest.raises(AssertionError):
        definitions[Foo] = bar



# Generated at 2022-06-24 11:03:29.537438
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass


# Generated at 2022-06-24 11:03:32.290649
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    f=SchemaDefinitions()
    f[0]=0
    f[1]=1
    f[2]=2
    f[3]=3
    f[4]=4
    f[5]=5
    assert len(f)==6


# Generated at 2022-06-24 11:03:36.344126
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    country = Country(name='Spain', capital='Madrid')
    assert country['name'] == 'Spain'
# Test function test_Schema___getitem__
# ran 1 tests in 0.000s
#
# OK

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 11:03:39.501201
# Unit test for method validate of class Reference
def test_Reference_validate():
    try:
        Reference('test').validate(None)
    except Exception as e:
        assert str(e) == "null"
    try:
        Reference('test').validate('test')
    except Exception as e:
        assert str(e) == "test"
    assert Reference('test').validate(None, strict=True) == None


# Generated at 2022-06-24 11:03:46.224983
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    s1 = Person(name = "Sebastian")
    s2 = Chick(name = "Sebastian")
    s3 = Person(name = "Esteban")
    assert (not (s1 == s2))
    assert (not (s1 == s3))
    assert (not (s2 == s3))
    assert (Person(name = "Sebastian") == s1)
    assert (Chick(name = "Sebastian") == s2)
    assert (Person(name = "Esteban") == s3)


# Generated at 2022-06-24 11:03:46.884025
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
   pass

# Generated at 2022-06-24 11:03:48.030647
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    pass

# Generated at 2022-06-24 11:03:53.977885
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    d = SchemaDefinitions()
    l = list(d)
    assert type(l) == list
    assert len(l) == 0
    d.__setitem__('a', 1)
    l = list(d)
    assert len(l) == 1
    assert l[0] == 'a'


# Generated at 2022-06-24 11:03:57.531493
# Unit test for function set_definitions
def test_set_definitions():

    class A(Schema):
        foo = Reference('B')

    class B(Schema):
        pass

    a = A()

    assert isinstance(a.foo, Reference)

    assert hasattr(a.foo, 'definitions')

    assert a.foo.definitions == {'B': B}

# Generated at 2022-06-24 11:04:00.337731
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    obj = SchemaDefinitions()
    try:
        obj.__delitem__('a')
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-24 11:04:06.128682
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String(max_length=10)
        email = String(max_length=20)
        age = Integer(minimum=1, maximum=120)

    p = Person(name='Jack', email='jack@example.com', age=20)

    with pytest.raises(KeyError):
        p['address']

    assert p['name'] == 'Jack'
    assert p['email'] == 'jack@example.com'
    assert p['age'] == 20
    assert sorted(list(p)) == ['age', 'email', 'name']



# Generated at 2022-06-24 11:04:10.314528
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()  # type: SchemaDefinitions
    def pretendToBeALambda():
        pass
    definitions["lambda"] = pretendToBeALambda
    assert definitions == {"lambda": pretendToBeALambda}


# Generated at 2022-06-24 11:04:16.362500
# Unit test for method validate of class Reference
def test_Reference_validate():
    references_definitions = SchemaDefinitions()
    schema_field = Reference("", definitions=references_definitions)
    value = {
        "foo": "bar"
    }
    assert value == schema_field.validate(value)


# Generated at 2022-06-24 11:04:22.877421
# Unit test for constructor of class Reference
def test_Reference():
    class ArticleSchema(Schema):
        title = String(max_length=255)
    
    class ArticlesSchema(Schema):
        articles = Array(Reference(ArticleSchema))

    class Person(Schema):
        name = String(max_length=255)
        age = Integer(minimum=0)
        locations = Array(String(max_length=255))
        friends = Array(Reference(Person))
    
    class PersonSchema(Schema):
        name = String(max_length=255)
        age = Integer(minimum=0)
        locations = Array(String(max_length=255))
        friends = Array(Reference("Person"))
        articles = Reference(ArticlesSchema)

    definitions = SchemaDefinitions({Person.__name__: Person})
    PersonSchema(definitions=definitions)



# Generated at 2022-06-24 11:04:23.498800
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass

# Generated at 2022-06-24 11:04:32.055107
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    # TODO: add unit test for method serialize of class Reference
    
    # sample
    test_dict = {'first_name': 'John', 'last_name': 'Smith'}
    actual = Reference.serialize(Reference, test_dict)
    assert actual == test_dict
    
    # edge cases
    def serialize(self, obj: typing.Any) -> typing.Any:
        if obj is None:
            return None
        return dict(obj)

# Generated at 2022-06-24 11:04:33.912233
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    res = getattr(definitions, "_definitions")
    assert res == dict()


# Generated at 2022-06-24 11:04:43.941600
# Unit test for function set_definitions

# Generated at 2022-06-24 11:04:54.050320
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test to see if the class can return a dictionary
    # Test if the class can return a string
    # Test for specific attributes of a dictionary
    # Test for other datatypes
    print("Starting Test test_Schema___getitem__ ...")
    class Person1(Schema):
        name = String(max_length=100)
        age = Integer()
        bio = String()
        
    Person1.validate = lambda x: x

    person = Person1(name="Mohit", age=22, bio="Grad")
    print("Test 1 ", person["name"])
    print("Test 2 ", person["age"])
    print("Test 3 ", person["bio"])
    print("Test 4 ", person["name"].__repr__())
    print("Test 5 ", person["age"].__repr__())
    print

# Generated at 2022-06-24 11:05:00.451229
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    def method_test_1():
        class FooSchema(Schema):
            bar = Field()
            baz = Field(required=False)

        foo1 = FooSchema(bar=1, baz=2)
        foo2 = FooSchema(bar=1, baz=2)
        assert foo1 == foo2
        assert foo2 == foo1

    def method_test_2():
        class FooSchema(Schema):
            bar = Field()
            baz = Field(required=False)

        foo1 = FooSchema(bar=1)
        foo2 = FooSchema(bar=1)
        assert foo1 == foo2
        assert foo2 == foo1

    def method_test_3():
        class FooSchema(Schema):
            bar = Field()

# Generated at 2022-06-24 11:05:10.106602
# Unit test for method validate of class Reference
def test_Reference_validate():
  #1.a Try to validate None value with allow_null = True
  assert Reference("to", allow_null = True).validate(None) == None
  
  #1.b Try to validate None value with allow_null = False
  try:
    Reference("to", allow_null = False).validate(None)
  except:
    pass
  
  #2.a Try to validate a valid value
  assert Reference("to").validate("a valid value") == \
    Schema.validate("a valid value")

  #2.b Try to validate an invalid value
  try:
    Reference("to").validate(-1)
  except:
    pass

test_Reference_validate()


# Generated at 2022-06-24 11:05:11.779844
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import types
    import typing
    from typesystem.base import ValidationError, ValidationResult
    from typesystem.fields import Array, Field, Object



# Generated at 2022-06-24 11:05:14.133349
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test 0, empty tag
    class PersonSchema(Schema):
        name = String()
        age = Integer()

    person = PersonSchema(name="John", age=42)
    assert len(person) == 2
        



# Generated at 2022-06-24 11:05:18.906276
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import random

    class UserSchema(Schema):
        id = Field(type=int, default=lambda: random.randint(1000, 10000))
        name = Field(max_length=10)
        group = Reference(to="Group")

    class GroupSchema(Schema):
        id = Field(type=int, default=lambda: random.randint(1000, 10000))
        name = Field(max_length=10)

    definitions = SchemaDefinitions(
        {
            "User": UserSchema,
            "Group": GroupSchema
        }
    )
    user = UserSchema(name="Jim Smith", group={'id': 15, 'name': "admins"})
    assert len(user) == 2


# Generated at 2022-06-24 11:05:24.629904
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import String

    class Example(Schema):
        foo = String(required=True)

    assert Example(foo="bar").foo == "bar"
    assert Example({'foo': 'bar'}).foo == "bar"
    assert Example(dict(foo="bar")).foo == "bar"
    assert Example(Example(foo="bar")).foo == "bar"

    assert Example.make_validator().validate(dict(foo="bar")) == dict(foo="bar")
    assert Example.make_validator().validate(Example(foo="bar")) == dict(foo="bar")

    assert Example.validate(dict(foo="bar")).foo == "bar"
    assert Example.validate(Example(foo="bar")).foo == "bar"

    assert list(Example(foo="bar")) == ["foo"]

# Generated at 2022-06-24 11:05:33.998802
# Unit test for constructor of class Schema
def test_Schema():
    '''
    Test Schema constructor
    '''
    import pytest
    from typesystem import types
    from typesystem.field import Callable

    class TestSchema(Schema):
        field1 = types.String(max_length=4)
        field2 = types.Integer()
        field3 = types.Float()
        field4 = types.String(allow_blank=True)

    assert TestSchema({'field1': 'test', 'field2': 10, 'field3': 0.5, 'field4': ''}).field1 == 'test'
    assert TestSchema({'field1': 'test', 'field2': 10, 'field3': 0.5, 'field4': ''}).field2 == 10

# Generated at 2022-06-24 11:05:37.766167
# Unit test for function set_definitions
def test_set_definitions():
    class M(Schema):
        foo = Reference('Foo')
        bar = Reference('Bar')

    class S(Schema):
        pass

    M.make_validator()
    assert not M.fields['foo'].definitions is None
    assert M.fields['foo'].definitions is M.fields['bar'].definitions

    S.make_validator()
    assert S.fields['foo'].definitions is S.fields['bar'].definitions

# Generated at 2022-06-24 11:05:42.694202
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        first = Field(type=str)
        last = Field(type=str)
    class Employee(Schema):
        name = Reference(Person, required=True)
        department = Field(type=str)
    employee = Employee(name=Person(first='John', last='Doe'), department='Admin')
    assert employee.name.serialize(employee.name) == {'first': 'John', 'last': 'Doe'}
    assert employee.serialize(employee.name) is None

# Generated at 2022-06-24 11:05:44.593120
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Setup
    a = SchemaDefinitions()
    a.__setitem__('a', 'b')
    a.__setitem__('a', 'b')

    # Exercise and Verify
    assert a.__len__() == 1


# Generated at 2022-06-24 11:05:46.224748
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    d = SchemaDefinitions()
    assert d is not None


# Generated at 2022-06-24 11:05:49.283239
# Unit test for constructor of class Reference
def test_Reference():
    obj_1 = Reference("to", definitions={"to": Object(properties={})}, allow_null=False)
    assert type(obj_1.to) is str
    assert type(obj_1.definitions) is dict


# Generated at 2022-06-24 11:05:54.540878
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    _definitions = SchemaDefinitions()
    assert _definitions._definitions == {}
    _definitions['name'] = 'ABC'
    assert _definitions._definitions['name'] == 'ABC'
    _definitions['name'] = 'TEST'
    assert _definitions._definitions['name'] == 'ABC'
    
    

# Generated at 2022-06-24 11:06:03.563163
# Unit test for constructor of class Schema
def test_Schema():
    class X(Schema):
        a = Field(int)
        b = Field(int)
        x = Field(int)

    a = 1
    b = 2
    x = 3
    d = {'a': a, 'b': b, 'x': x}
    schema = X(d)

    assert len(schema) == 3
    assert schema == X(a=a, b=b, x=x)
    assert schema != X(a=a, b=b, x=x+1)

    # Check if the fields are in order
    assert schema == X(**d)
    assert X(**d) == X(d)

    # Test if the class can take a non-dict argument as well.
    class Y(X):
        pass

    y = Y(d)


# Generated at 2022-06-24 11:06:07.733734
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .serializers import Car
    
    car1 = Car(
        make="Mazda",
        model="MX-5",
        year=2007,
    )   
    car2 = Car(
        make="Mazda",
        model="MX-5",
        year=2007,
    )   
    car3 = Car(
        make="Toyota",
        model="Rav4",
        year=2006,
    )   
    assert car1 == car2
    assert not (car1 == car3)


# Generated at 2022-06-24 11:06:18.139907
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    import json
    import unittest

    class AddressSchema(Schema):
        street_address = String(format="street-address")

    class FullNameSchema(Schema):
        first_name = String()
        last_name = String()

    class PersonSchema(Schema):
        address = Reference(to=AddressSchema)
        name = Reference(to=FullNameSchema)

    class TestSchemaDefinitions(unittest.TestCase):
        def test___getitem__(self) -> None:
            definitions = SchemaDefinitions()

            # This fixes the order, which we need for assertions below.
            definitions.update({FullNameSchema.__name__: FullNameSchema})
            definitions.update({AddressSchema.__name__: AddressSchema})

# Generated at 2022-06-24 11:06:22.892779
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    instance = SchemaDefinitions()

    assert 'Schema' in instance



# Generated at 2022-06-24 11:06:29.024423
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Test(Schema):
        field = Field()
    assert repr(Test()) == "Test()"
    assert repr(Test(dict(field="testing"))) == "Test(field='testing')"
    assert repr(Test(field="testing")) == "Test(field='testing')"
    assert repr(Test(field="testing", field2="testing2")) == "Test(field='testing')"
    assert repr(Test(field="testing", field2="testing2", field3="testing3")) == "Test(field='testing')"


# Generated at 2022-06-24 11:06:31.220401
# Unit test for method validate of class Reference
def test_Reference_validate():
    r = Reference(to="string")
    r.validate(1)


# Generated at 2022-06-24 11:06:42.296717
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Create instance of class class_b3fad3c2d3cb4b8cbea44315d4e4e4b4
    # Either this class does not extend the abstract base class 'ABCMeta' or the method '__abstractmethods__' cannot be found on the class
    # Either this class does not extend the abstract base class 'MutableMapping' or the method '__abstractmethods__' cannot be found on the class
    # Either this class does not extend the abstract base class 'Mapping' or the method '__abstractmethods__' cannot be found on the class
    test_class_instance = SchemaDefinitions()

    # Call function '__iter__'
    # Call function '__iter__'
    # Call function '__iter__'
    return_value = test_class_instance.__iter__()
   

# Generated at 2022-06-24 11:06:51.854292
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Class1(Schema, definitions=SchemaDefinitions()):
        field_1 = String()
        field_2 = String()

    class Class2(Schema, definitions=SchemaDefinitions()):
        string_ref_1 = Reference(to=Class1)
        field_1 = String()

    class Class3(Schema, definitions=SchemaDefinitions()):
        string_ref_1 = Reference(to=Class1)
        field_2 = String()

    class Class4(Schema, definitions=SchemaDefinitions()):
        string_ref_1 = Reference(to=Class1)
        class_ref_1 = Reference(to=Class3)

    assert isinstance(Class4.fields['string_ref_1'], Reference)
    assert isinstance(Class4.fields['class_ref_1'], Reference)

# Generated at 2022-06-24 11:06:58.422985
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class DefinitionSchema(Schema):
        type = String()

    class FirstSchema(Schema):
        definition = Reference(to="DefinitionSchema")

    class SecondSchema(Schema):
        definition = Reference(to=DefinitionSchema)

    class ThirdSchema(Schema):
        definition = Reference(to="FourthSchema")

    class FourthSchema(Schema):
        definition = Reference(to="ThirdSchema")

    schemas = [
        FirstSchema,
        SecondSchema,
        ThirdSchema,
        FourthSchema
    ]

    for schema in schemas:
        set_definitions(schema.definition, definitions)
        assert schema.definition.definitions is definitions

# Generated at 2022-06-24 11:07:05.221672
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String

    class TestSchema(Schema):
        name = String()

    doc = TestSchema(name="Bob")
    assert len(doc) == 1

    doc = TestSchema(name="Bob", other_field="one")
    assert len(doc) == 1

    doc = TestSchema(name="Bob", other_field="one", other="two")
    assert len(doc) == 1

    doc = TestSchema()
    assert len(doc) == 0



# Generated at 2022-06-24 11:07:10.726483
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Foo(Schema):
        x = int()
        y = int()
    f = Foo(x=1,y=2)
    assert Reference(to=Foo).serialize(f) == {'x': 1, 'y': 2}

# Generated at 2022-06-24 11:07:19.281761
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema1(Schema):
        a = Field()
        b = Field()

    class TestSchema2(TestSchema1):
        b = Field()
        c = Field()

    class TestSchema3(TestSchema2):
        a = Field()
        d = Field()

    test_object1 = TestSchema1(a=1, b=2)
    test_object2 = TestSchema2(b=2, c=1)
    test_object3 = TestSchema3(b=2, c=3, d=3)

    assert test_object1.a == 1
    assert test_object1.b == 2
    assert len(test_object1) == 2
    assert test_object2.a == None
    assert test_object2.b == 2
    assert test_object2

# Generated at 2022-06-24 11:07:21.799099
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    d = SchemaDefinitions()
    assert len(d) == 0  # __len__ -> __len__
    d["NewKey"] = "NewValue"
    assert len(d) == 1  # __len__ -> __len__

# Generated at 2022-06-24 11:07:25.806201
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema, metaclass=SchemaMetaclass, definitions=None):
        fields: typing.Dict[str, Field] = {}
        test = Field(key='test')

    assert TestSchema.fields['test'] == Field(key='test')

# Generated at 2022-06-24 11:07:33.156506
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    _args = ()
    _kwargs = {}
    _expect = {'fields': {}}
    obj = SchemaDefinitions._SchemaMetaclass__new__(SchemaDefinitions, _args, _kwargs)
    try:
        for key in _expect:
            value = _expect[key]
            assert getattr(obj, key) == value, "Attribute {} has value {}, expected {}".format(key, getattr(obj, key), value)
    except Exception as e:
        print('Exception {} raised in test_SchemaDefinitions___iter__()'.format(e))

# Generated at 2022-06-24 11:07:34.574778
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass


# Generated at 2022-06-24 11:07:38.654019
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class A(Schema):
        a=Field(String())
    a=A({'a':'1'})
    a={'a':'1'}
    assert a['a'] == '1'

# Generated at 2022-06-24 11:07:40.513583
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    obj = SchemaDefinitions()
    assert obj._definitions == {}
    obj.__setitem__('key', 'value')
    assert obj._definitions == {'key': 'value'}



# Generated at 2022-06-24 11:07:41.443628
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    SchemaDefinitions()


# Generated at 2022-06-24 11:07:44.454793
# Unit test for function set_definitions
def test_set_definitions():
    Student = Schema.define(name=Field(required=True), age=Field(required=False))
    class School(Schema):
        students = Array(items=Reference(to=Student))
    assert School.fields["students"].items.definitions == {'Student': Student}

# Generated at 2022-06-24 11:07:45.018777
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert True == True

# Generated at 2022-06-24 11:07:46.302093
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert Schema().__len__()==0

# Generated at 2022-06-24 11:07:53.684095
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class BaseSchema(metaclass=SchemaMetaclass):
        first_name = String(max_length=32)
        last_name = String(max_length=32)

    class UserSchema(BaseSchema):
        email = String(max_length=128)

    fields = UserSchema.fields
    assert len(fields) == 3
    for key in ["first_name", "last_name", "email"]:
        assert key in fields
    assert isinstance(fields["email"], String)

# Generated at 2022-06-24 11:07:56.561746
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions([
        ("attr1", 1),
        ("attr2", 2)
    ])
    assert definitions == {"attr1": 1, "attr2": 2}
    del definitions["attr1"]
    assert definitions == {"attr2": 2}



# Generated at 2022-06-24 11:07:59.860338
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    obj = Schema()
    assert type(obj) == Schema
    assert len(obj) == 0


# Generated at 2022-06-24 11:08:02.788688
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Setup
    definitions = SchemaDefinitions()
    expected = 0
    # Exercise
    result = len(definitions)
    # Verify
    assert result == expected


# Generated at 2022-06-24 11:08:05.091167
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    try:
        a = SchemaDefinitions({})
        a.__delitem__('b')
        raise AssertionError('Expected AssertionError not raised')
    except AssertionError as e:
        assert str(e) == "object.__delitem__(self, key)"
    except:
        assert False, 'Expected AssertionError not raised'


# Generated at 2022-06-24 11:08:16.065483
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = StringField()
        age = IntegerField()
        email = StringField(required=False)

    assert Person(name="John", age=20).name == 'John'
    assert Person(name="John", age=20).age == 20
    assert Person(name="John", age=20) == Person(name="John", age=20)
    assert Person(name="John", age=20).to_dict() == {"name": "John", "age": 20}
    # Test is_sparse
    assert Person(name="John", age=20).is_sparse == False
    # Test validate
    Person.validate({"name": "John", "age": 20})

# Generated at 2022-06-24 11:08:20.279238
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert definitions == {}
    definitions = SchemaDefinitions({"test":"test"})
    definitions["test"] = "test"
    assert definitions == {'test': 'test'}
    del definitions["test"]
    assert definitions == {}
    assert len(definitions) == 0 


# Generated at 2022-06-24 11:08:22.189400
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(str).serialize("foo") == dict("foo")

# Generated at 2022-06-24 11:08:25.731059
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    s = SchemaDefinitions({"a": 1, "b": 2})
    assert s['a'] == 1
    assert s['b'] == 2
    try:
        s['c']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-24 11:08:26.707806
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()



# Generated at 2022-06-24 11:08:30.703759
# Unit test for constructor of class Reference
def test_Reference():
    class SomeType(Schema):
        a = String()
        b = String()
    args = dict(a = "a",b = "b")
    some_type = SomeType(args)
    a = Reference(some_type)
    assert a.to == some_type


# Generated at 2022-06-24 11:08:36.916375
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    '''
    """
    Test len() of class Schema
    '''

    # Test Case: len(Schema()) = 0
    schema = Schema()
    len_schema = len(schema)
    assert len_schema == 0, "len(Schema()) != 0"

    # Test Case: len(Schema(**{'a': 1, 'b': 2})) = 2
    schema = Schema(a=1, b=2)
    len_schema = len(schema)
    assert len_schema == 2, "len(Schema(**{'a': 1, 'b': 2})) != 2"

    return "Pass test_Schema___len__()"


# Generated at 2022-06-24 11:08:40.536099
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    value = Schema.validate({"name": "One", "data": 1234})
    assert value == {"name": "One", "data": 1234}

# Generated at 2022-06-24 11:08:43.709511
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class SampleSchema(Schema):
        name = String()

    sample = SampleSchema({"name": "Ronan"})
    sample_equal = SampleSchema({"name": "Ronan"})
    sample_not_equal = SampleSchema({"name": "Oscar"})

    assert sample == sample_equal
    assert sample != sample_not_equal

# Generated at 2022-06-24 11:08:52.082796
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    class TestSchemaMetaclass___new__0(Schema, metaclass=SchemaMetaclass):
        id = typesystem.String()

    # Hashcode of TestSchemaMetaclass___new__0 is
    # "TestSchemaMetaclass___new__0<id=String()>"
    assert TestSchemaMetaclass___new__0.fields.keys() == {"id"}

    # The return values are "TestSchemaMetaclass___new__0" and
    # "TestSchemaMetaclass___new__0<id=String()>"
    return TestSchemaMetaclass___new__0, TestSchemaMetaclass___new__0.fields


# Generated at 2022-06-24 11:09:02.726448
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Create objects for testing
    arg_0 = []
    arg_1 = {}
    arg_2 = []
    arg_3 = {}
    test_object_0 = SchemaDefinitions(arg_0, arg_1)

    # Create expected results
    expected_result_0 = None
    expected_result_1 = None
    expected_result_2 = None
    expected_result_3 = None
    expected_result_4 = None
    expected_result_5 = None
    expected_result_6 = None

    # Call the method to be tested
    result = test_object_0.__getitem__(arg_2, arg_3)

    # Check the results against the expected ones
    assert result == expected_result_0
    assert result == expected_result_1
    assert result == expected_result_2

# Generated at 2022-06-24 11:09:10.072802
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=100)

    person_a = Person(
        name='Jane', age=13
    )
    person_b = Person(
        name='Jane', age=13
    )
    person_c = Person(
        name='Joe', age=13
    )
    person_d = Person(
        name='Joe', age=13, gender='M'
    )
    person_e = Person(
        name='Jane', gender='F'
    )
    assert person_a == person_b
    assert person_b != person_c
    assert person_a != person_e

    try:
        person_a == person_d
    except AssertionError as e:
        print(e)


# Generated at 2022-06-24 11:09:12.787410
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    schema = SchemaDefinitions()
    try:
        assert NotImplementedError == type(schema.__iter__())
    except NotImplementedError:
        pass
    assert NotImplementedError == type(schema.__iter__())



# Generated at 2022-06-24 11:09:18.830796
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    """Test case for method __iter__ of class SchemaDefinitions.

    Test of __iter__ method of class SchemaDefinitions.
    """

    defs = SchemaDefinitions({"a": 1})

    assert (next(iter(defs)) == "a"), "iter first element is wrong"
    assert (next(iter(defs)) == "a"), "iter second element is wrong"


# Generated at 2022-06-24 11:09:29.706418
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # GIVEN
    from typesystem import String, Integer, Array

    class SimpleSchema(Schema):
        x = String
        y = String
        z = Integer

    # WHEN
    mySchema = SimpleSchema(x="hello", y="world")

    # THEN
    assert mySchema["x"] == "hello"
    assert mySchema["y"] == "world"
    assert "z" not in mySchema

    # WHEN
    mySchema.z = 42
    
    # THEN
    assert mySchema["z"] == 42
    assert mySchema.is_sparse() == False

    # WHEN
    class MyOtherSchema(Schema):
        a = Integer
        b = Array(items=SimpleSchema)

    # THEN

# Generated at 2022-06-24 11:09:39.487236
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer()
        dob = DateTime(format="%Y-%m-%dT%H:%M:%S.%fZ")
        register = Boolean()
    
    # Test case
    try:
        mySchema = MySchema(name="Bob", age=17, dob="2019-07-04T16:07:01.206516Z", register=False)
    except Exception as e:
        print(e)
    else:
        print(mySchema["name"])
        print(mySchema["age"])
        print(mySchema["dob"])
        print(mySchema["register"])


# Generated at 2022-06-24 11:09:46.019684
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Integer, String

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    p = Person(name="Iris", age=10)
    assert repr(p) == "Person(name='Iris', age=10)"
    assert p.__repr__() == "Person(name='Iris', age=10)"



# Generated at 2022-06-24 11:09:48.268760
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema):
        field = Array(Integer())
    assert 'fields' in TestSchema.__dict__
    assert {'field': Array(Integer())} == TestSchema.fields


# Generated at 2022-06-24 11:09:58.104797
# Unit test for constructor of class Schema
def test_Schema():
    # Test normal constructor
    class X(Schema):
        a = Field(str)
        b = Field(str)
    x = X(a = "hi", b = "bye", c = "not here")
    assert(str(x) == "X(a='hi', b='bye')")
    assert(len(x) == 2)
    assert(x.a == "hi")
    assert(x.b == "bye")
    assert(hasattr(x, "c") == False)

    # Test 'from_dict' constructor
    x = X({'a': 'hi', 'b': 'bye'})
    assert(str(x) == "X(a='hi', b='bye')")
    assert(len(x) == 2)
    assert(x.a == "hi")