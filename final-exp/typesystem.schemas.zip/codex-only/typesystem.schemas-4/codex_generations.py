

# Generated at 2022-06-24 10:59:53.982531
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    s = SchemaDefinitions()
    s['asdfa'] = 'asdfa'
    del s['asdfa']


# Generated at 2022-06-24 10:59:57.929581
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.definitions import definitions
#    from typesystem.definitions import definitions
    class Foo(Schema):
        bar = Reference("dict")
    
    foo = Foo({"bar": {"prop1": "value1", "prop2": "value2"}})
    print(foo)
    print(foo.bar)


# Generated at 2022-06-24 11:00:08.696170
# Unit test for method validate of class Reference
def test_Reference_validate():
    from .types import Book
    from .fields import Integer, String
    from . import ExampleSchema
    _book = Book(
        "Objects First with Java",
        2017,
        "This is the seventh edition of Objects First with Java...",
        {"David J. Barnes": "barnes@example.com", "Michael Kölling": "koelling@example.com"},
        [
            "Users of this book will find straightforward coverage...",
            "A clear, concise introduction to Java programming...",
            "Carefully structured and illustrated to make learning easy...",
            "The BlueJ integrated development environment is a...",
        ],
    )
    assert isinstance(_book, Book)
    assert isinstance(_book.title, String)
    assert isinstance(_book.year_published, Integer)

# Generated at 2022-06-24 11:00:12.377336
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Example(Schema):
        a_field = Array(String)
        b_field = Array(String)

    class ExampleOther(Example):
        c_field = Array(String)

    assert ExampleOther.fields == {"a_field": Array(String), "b_field": Array(String), "c_field": Array(String)}



# Generated at 2022-06-24 11:00:19.917368
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def1 = dict(type='fruit', color='red')
    def2 = dict(type='veg', color='green')
    defs = SchemaDefinitions(def1, def2)
    assert defs['type'] == 'fruit'
    assert defs['color'] == 'red'
    assert def1 is not defs
    defs['color'] = 'blue'
    assert defs['color'] == 'blue'
    assert def2['color'] == 'green'
    assert len(defs) == 2
    assert 'color' in defs
    for el in defs:
        assert el in ('type', 'color')


# Generated at 2022-06-24 11:00:25.365032
# Unit test for method validate of class Reference
def test_Reference_validate():
    class SubMach(Schema):
      a = String()
      b = String()

    class MyMach(Schema):
      a = String()
      b = Reference(to=SubMach)
    my_dict = {'a': "string", 'b': {'a':"string", 'b':"string"}}
    print(MyMach.validate(my_dict))
    # my_dict.add(KeyError: 'c')


# Generated at 2022-06-24 11:00:32.252745
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import types
    import io
    import sys
    from contextlib import redirect_stdout

    from typesystem.base import String
    from util import assert_output

    class Name(Schema):
        first = String()
        last = String()

    name = Name(first="Wile", last="Coyote")
    assert "first" in name
    assert "last" in name

    name = Name()
    assert "first" not in name
    assert "last" not in name

# Generated at 2022-06-24 11:00:39.883620
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        recurse = Reference("Bar")

    class Bar(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions({"Bar": Bar})
    set_definitions(Foo.fields["recurse"], definitions)
    assert Foo.fields["recurse"].definitions == definitions
    assert Bar.fields["foo"].definitions == definitions
    assert Foo.fields["recurse"].target == Bar
    assert Bar.fields["foo"].target == Foo



# Generated at 2022-06-24 11:00:46.035481
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from .models import Person
    from .serializers import PersonSerializer

    person = Person(first_name="Peter", last_name="Griffin")

    person_serializer = PersonSerializer()

    serialized_person = person_serializer.serialize(person)

    assert serialized_person['first_name'] == 'Peter'
    assert serialized_person['last_name'] == 'Griffin'



# Generated at 2022-06-24 11:00:48.888072
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class PersonSchema(Schema):
        first_name = String()

    person = PersonSchema({'first_name': 'Kamal'})

    assert person['first_name'] == 'Kamal'

# Generated at 2022-06-24 11:00:50.517311
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["test"] = "test_value"
    assert definitions["test"] == "test_value"



# Generated at 2022-06-24 11:01:01.527776
# Unit test for function set_definitions
def test_set_definitions():
    P = Field(name="p")
    Q = Field(name="q")
    R = Field(name="r")
    S = Field(name="s")
    T = Field(name="t")
    U = Field(name="u")
    V = Field(name="v")
    W = Field(name="w")
    X = Field(name="x")
    Y = Field(name="y")
    Z = Field(name="z")

    C = Array(items=Object(properties={"p": P, "q": Q}))
    D = Array(items=Object(properties={"r": R, "s": S}))
    E = Array(items=Object(properties={"t": T, "u": U}))

# Generated at 2022-06-24 11:01:09.973347
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.fields import String
    from typesystem.schema import Schema
    class NameSchema(Schema):
        first_name = String()
        last_name = String()
    class UserSchema(Schema):
        name = Reference('NameSchema')
    user_schema = UserSchema()
    assert user_schema.name.serialize(NameSchema({'first_name':'John', 'last_name':'Doe'})) == {'first_name': 'John', 'last_name': 'Doe'}
    assert user_schema.name.serialize(None) == None
    assert user_schema.name.serialize('John') == 'John'



# Generated at 2022-06-24 11:01:10.591176
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert True

# Generated at 2022-06-24 11:01:15.558198
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer(minimum=1)
        hometown = Reference(to="Town")

    class Town(Schema):
        name = String()
        population = Integer(minimum=1)

    class Post(Schema):
        title = String()
        author = Reference(to="Person")

    class Comment(Schema):
        content = String()
        author = Reference(to=Person)
        post = Reference(to=Post)

    definitions = SchemaDefinitions(
        {"Person": Person, "Town": Town, "Post": Post, "Comment": Comment}
    )

    person = Person(name="John Doe", age=20, hometown="Springfield")
    assert person.is_valid()
    assert isinstance(person.hometown, Town)

# Generated at 2022-06-24 11:01:22.679387
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
  # Creation of object of class SchemaDefinitions with parameters
  SchemaDefinitions
  # Call to method __getitem__ of object "SchemaDefinitions" with parameter "test_definition"
  new_name = SchemaDefinitions.__getitem__('test_definition')
  # Test if the object getted is the same as the object expected
  assert new_name is not 'test_definition', "The returned object is not correct"


# Generated at 2022-06-24 11:01:23.809730
# Unit test for method __setitem__ of class SchemaDefinitions

# Generated at 2022-06-24 11:01:27.462588
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        age = IntField()
        name = StringField()
    schema = MySchema(name = "hello", age = 18)
    assert repr(schema) == "MySchema(name='hello', age=18)"

# Generated at 2022-06-24 11:01:35.226925
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        bar = String(max_length=10)
        baz = Integer()
    class Bar(Schema):
        test = String()
    class Baz(Schema):
        nested = Reference(to="Foo")
        nest_array = Array(items=Reference(to=Foo))
        bar = Reference(to=Bar)
    definitions = SchemaDefinitions()
    set_definitions(Baz.make_validator(), definitions)
    assert isinstance(Baz.nested, Reference)
    assert Baz.nested._target_string == "Foo"
    assert isinstance(Baz.nested.target, Schema)
    assert isinstance(Baz.nest_array.items, Array)
    assert isinstance(Baz.nest_array.items.items, Reference)
   

# Generated at 2022-06-24 11:01:39.732093
# Unit test for constructor of class Reference
def test_Reference():
    print("test_Reference() start")
    to = 'to'
    definitions = 'definitions'
    reference = Reference(to=to, definitions=definitions)
    print(reference)
    print("test_Reference() end")
    
    

# Generated at 2022-06-24 11:01:45.588506
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert [it for it in SchemaDefinitions()] == []
    assert [it for it in SchemaDefinitions({'a':1})] == ['a']
    assert [it for it in SchemaDefinitions(a=1)] == ['a']


# Generated at 2022-06-24 11:01:52.414575
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Parent(Schema):
        parent_required = Field(required=True)
        parent_optional = Field(required=False)

    class Child(Parent):
        child_required = Field(required=True)
        child_optional = Field(required=False)

    child = Child()
    child.child_required = "foo"

    if list(child.keys()) == ["child_required"] and len(child) == 1:
        print("Test passed")
    else:
        print("Test failed")

test_Schema___len__()

# Generated at 2022-06-24 11:02:04.691579
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    
    class MixedTypeSchema(Schema,):
        __doc__ = '\n        >>> val = MixedTypeSchema(int_field=1, float_field=2.5)\\n        >>> val.int_field\\n        1\\n        >>> val.float_field\\n        2.5\\n        '
        __module__ = 'test_schema'
        int_field = Integer(title='Integer field')
        float_field = Float(title='Float field')


# Generated at 2022-06-24 11:02:07.065882
# Unit test for constructor of class Reference
def test_Reference():
    class MyReference(Reference):
        pass
    my_reference = MyReference()
    assert my_reference is not None


# Generated at 2022-06-24 11:02:12.763699
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    d = SchemaDefinitions()
    assert len(d) == 0
    d = SchemaDefinitions({"a": "a value", "b": "another value"})
    assert len(d) == 2


# Generated at 2022-06-24 11:02:14.594170
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    sd = SchemaDefinitions()
    sd['hello'] = 1
    assert sd['hello'] == 1


# Generated at 2022-06-24 11:02:21.841793
# Unit test for constructor of class Reference
def test_Reference():
    from typing import Dict
    from typesystem.fields import String
    from typesystem.object import Object
    from typesystem.schema import SchemaMetaclass, Schema
    from typesystem.string import String

    class Person(Schema, metaclass=SchemaMetaclass):
        name = String(max_length=100)

    class People:
        def __init__(self, *args, **kwargs):
            pass

    class House(Schema, metaclass=SchemaMetaclass):
        residents = Array(Dict(properties={
            "Person": Object(properties={
                "name": String(),
                "age": Reference(to="Person", definitions=People)
            })
        }))

    assert House.validate()



# Generated at 2022-06-24 11:02:27.693501
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    mydict = SchemaDefinitions()
    mydict['key1'] = 'value1'
    mydict['key2'] = 'value2'
    mydict['key3'] = 'value3'
    list1 = [key for key in mydict]
    list1.sort()
    assert list1 == ['key1', 'key2', 'key3']



# Generated at 2022-06-24 11:02:38.609116
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Case 1: value is None and allow_null is True
    # Expected output: None
    reference = Reference(to='', allow_null=True)
    result = reference.validate(value=None)
    assert result == None

    # Case 2: value is None and allow_null is False
    # Expected output: None
    reference = Reference(to='', allow_null=False)
    result = reference.validate(value=None)
    assert result == None

    # Case 3: value is not None and allow_null is False
    # Expected output: Exception
    reference = Reference(to='', allow_null=False)
    try:
        reference.validate(value='a')
    except Exception:
        exception_raised = True
    assert exception_raised == True


# Generated at 2022-06-24 11:02:43.598579
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # __len__()
    # Return the number of definitions in the registry.

    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    
    definitions = SchemaDefinitions()
    definitions["Todo"] = Todo
    assert len(definitions) == 1
    
    definitions = SchemaDefinitions()
    definitions["Todo"] = Todo
    definitions["TodoList"] = TodoList
    assert len(definitions) == 2
    

# Generated at 2022-06-24 11:02:47.130823
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Foo():
        pass
    class Bar(Foo):
        pass
    obj = Bar()
    obj.a = 1
    obj.b = 2
    field = Reference("Bar")
    assert field.serialize(obj) == {'a': 1, 'b': 2}

# Generated at 2022-06-24 11:02:53.046255
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import pytest
    from .impl.fixtures.test_Schema___iter__ import Schema_class, obj_0, obj_1, obj_2, value_0, value_1, value_2
    schema = Schema_class(obj_0)
    assert list(schema) == [value_0, value_1, value_2]
    schema = Schema_class(obj_1)
    assert list(schema) == [value_0, value_1, value_2]
    schema = Schema_class(obj_2)
    assert list(schema) == [value_0, value_1, value_2]

# Generated at 2022-06-24 11:02:58.358591
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String

    class User(Schema):
        name = String(max_length=256)

    user = User(name='Paul')
    assert repr(user) == 'User(name=\'Paul\')'  # type: ignore

    user = User(name='Paul', age=32)
    assert repr(user) == 'User(name=\'Paul\')'  # type: ignore


# Generated at 2022-06-24 11:03:04.089591
# Unit test for constructor of class Schema
def test_Schema():
    # Create a class definition
    class MySchema(Schema):
        foo = Field(type="string")
        bar = Field(type="integer")

        def __init__(self, *args, **kwargs):
            super(MySchema, self).__init__(*args, **kwargs)
        # test schema
        schema = MySchema(foo = "foo", bar = 1)
        result = schema.foo == "foo" and schema.bar == 1
        print(result)

    # Test calls to super
    assert(test_Schema())

if __name__ == "__main__":
    test_Schema()

# Generated at 2022-06-24 11:03:10.253171
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import json
    import operator
    import typesystem
    import typing

    class Person(Schema):
        name = typesystem.String()
        age = typesystem.Integer()

    person = Person(name="Fernando", age=24)

    value = person.serialize()
    print(json.dumps(value, indent=4))

    assert isinstance(value, dict)
    assert len(value) == 2
    assert value.get("name") == "Fernando"
    assert value.get("age") == 24



# Generated at 2022-06-24 11:03:15.395810
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        family_name = String(max_length=30)
        given_name = String(max_length=30)
        age = Integer(min_value=18, max_value=130)
        gender = Enum(["male", "female"])

    person = Person(
        family_name="Doe", given_name="John", age=30, gender="male",
    )

    assert repr(person) == "Person(age=30, family_name='Doe', gender='male', given_name='John')"



# Generated at 2022-06-24 11:03:20.837511
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String

    class MySchema(Schema):
        name = String()

    my_schema = MySchema({'name': 'schema'})
    expected = 1
    actual = len(my_schema)
    assert actual == expected



# Generated at 2022-06-24 11:03:23.801947
# Unit test for function set_definitions
def test_set_definitions():
    class First(Schema):
        first_field = String(max_length=50)

    class Second(Schema):
        second_field = Reference(First)

    assert Second.fields["second_field"].target is First

# Generated at 2022-06-24 11:03:33.529183
# Unit test for constructor of class Schema
def test_Schema():
    class TestType(Schema):
        a = Field()
        b = Field()

    instance = TestType({'a': 3})
    assert instance.a == 3
    assert instance.b is None

    instance = TestType(TestType())
    assert instance.a is None
    assert instance.b is None

    instance = TestType(a=3)
    assert instance.a == 3
    assert instance.b is None

    instance = TestType()
    assert instance.a is None
    assert instance.b is None

    instance = TestType(a=3, b=5)
    assert instance.a == 3
    assert instance.b == 5

    instance = TestType(a=3, c=None)
    assert instance.a == 3
    assert instance.c is None


# Generated at 2022-06-24 11:03:36.715269
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['first'] = 1
    definitions['second'] = 2
    assert len(definitions) == 2
    del definitions['first']
    assert len(definitions) == 1
    assert 'first' not in definitions
    assert 'second' in definitions


# Generated at 2022-06-24 11:03:42.661387
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    """
    Unit test for method __delitem__ of class SchemaDefinitions

    Tests deleting exisiting definition from definition list
    """
    class TestSchema(Schema):
        integer = Integer()

    definitions = SchemaDefinitions()
    definitions["test"] = TestSchema
    assert definitions["test"] == TestSchema
    del definitions["test"]
    assert TestSchema.__name__ not in definitions


# Generated at 2022-06-24 11:03:47.027590
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    """
    Unit test for method `__delitem__` of class SchemaDefinitions
    """
    schema_definitions = SchemaDefinitions()
    key: str = "key"
    value: str = "value"
    schema_definitions["key"] = value
    assert key in schema_definitions
    assert schema_definitions[key] == value
    del schema_definitions[key]
    assert key not in schema_definitions

# Generated at 2022-06-24 11:03:54.271836
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Address(Schema):
        street = Field(type="string")
        city = Field(type="string")
        region = Field(type="string", required=False)

    assert len(Address()) == 2
    assert len(Address(street="A Street", city="London")) == 2
    assert len(Address(street="A Street", city="London", region="UK")) == 3



# Generated at 2022-06-24 11:04:00.108697
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    expected = {
        "email": "test@example.com",
        "age": 1,
    }
    input = {
        "email": "test@example.com",
        "age": 1,
    }
    schema = Reference(to=User)
    result = schema.serialize(input)
    assert expected == result

    expected = None
    input = None
    result = schema.serialize(input)
    assert expected == result



# Generated at 2022-06-24 11:04:03.835845
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def test_getitem_dict():
        assert test_args['test_key'] == 'test_value'
    # Test object creation
    test_args = {"test_key": "test_value"}
    test_object = SchemaDefinitions(test_args)
    # Test getitem
    test_getitem_dict()


# Generated at 2022-06-24 11:04:13.549523
# Unit test for constructor of class Reference
def test_Reference():
    def t(x):
        return x
    reference = Reference(t)
    assert reference.target == t
    assert reference.definitions is None
    reference = Reference("t", definitions={})
    assert reference.to == "t"
    assert reference.definitions == {}
    assert reference.allow_null is False
    assert reference._target_string == "t"
    assert reference.target == "t"
    assert reference.errors == {"null": "May not be null."}
    assert reference.validate is not None
    assert reference.serialize is not None


# Generated at 2022-06-24 11:04:21.448346
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    schema_definitions = SchemaDefinitions()
    assert (
        len(schema_definitions) == 0
    ), """Length of schema_definitions object is not equal to 0"""
    assert (
        not bool(schema_definitions)
    ), """Logical value of schema_definitions object is not equal to False"""
    schema_definitions["key1"] = 1
    assert (
        len(schema_definitions) == 1
    ), """Length of schema_definitions object is not equal to 1"""
    assert (
        schema_definitions["key1"] == 1
    ), """Element value of key 'key1' is not equal to 1"""
    assert (
        next(iter(schema_definitions)) == "key1"
    ), """Element value of key 'key1' is not equal to 1"""
    schema

# Generated at 2022-06-24 11:04:31.552893
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Fruit(Schema):
        name = Field(type=str, required=True)
    class Apple(Fruit):
        color = Field(type=str, required=True)
    
    apple = Apple(name='Golden Delicious', color='red')

    expected = {'color': 'red', 'name': 'Golden Delicious'}

    assert apple == expected
    assert apple != {'color': 'red'}
    assert apple != {'name': 'Golden Delicious'}

    assert Fruit.validate(apple) == apple

    assert Apple.validate({'name': 'Golden Delicious', 'color': 'red'}) == apple

    assert Fruit.validate({'name': 'Golden Delicious', 'color': 'red'}) == {
        'name': 'Golden Delicious', 'color': 'red'}

    # test assert isinstance(obj, Fruit

# Generated at 2022-06-24 11:04:38.737938
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Initialize constant parameters
    definitions = SchemaDefinitions()

    class Location(Schema):
        name = Field(str)
        description = Field(str)

    class Waypoint(Schema):
        name = Field(str)
        location = Reference(Location, definitions)

    # Verify that the method raises an exception when the value passed to it is None

    # Initialize parameter
    value = None
    # Invoke tested method
    try:
        Reference(Location, definitions).validate(value)
    except ValidationError as e:
        # Verify that the exception raised has the correct message and type
        assert e.message == "May not be null."
        assert e.type == "null"
    else:
        raise AssertionError("Expected a ValidationError. Did not get one.")

    # Verify that the method returns the value

# Generated at 2022-06-24 11:04:41.531480
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions["test"] = 0
    assert definitions["test"] == 0
    del definitions["test"]
    assert len(definitions) == 0


# Generated at 2022-06-24 11:04:47.938042
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class SomeSchema(Schema):
        property1 = Field(required=True)
        property2 = Field()

    s = SomeSchema(property1=1)
    assert len(s) == 1

    # Unit test for method __repr__ of class Schema

# Generated at 2022-06-24 11:04:52.260201
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import Integer
    from typesystem.schema import Schema
    class DemoSchema(Schema):
        name = Integer()
        age = Integer()
        weight = Integer()
    demo_schema = DemoSchema(name=12, age=13)
    assert len(demo_schema) == 2


# Generated at 2022-06-24 11:04:53.958962
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from .serializers import String
    class Foo(Schema):
        bar = String()
    print(Foo.fields)

# Generated at 2022-06-24 11:04:56.370446
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class test(Schema):
        a = Field()
        b = Field()
    obj = test({'a': 1, 'b': 2})
    assert len(obj) == 2


# Generated at 2022-06-24 11:05:02.863684
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.types import String, Integer
    class Person(Schema):
        first_name = String()
        age = Integer()
        __strict__ = True
    #class Person(Schema):
    #    first_name = String()
    #    age = Integer()
    #    __strict__ = True
    class PersonReference(Reference):
        to = Person
    person = Person(first_name='Jon', age=23)
    person_reference = PersonReference(person)
    assert person == person_reference.validate(person)


# Generated at 2022-06-24 11:05:05.428335
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test case data
    schema_fields = {'spam': None}
    schema = Schema(schema_fields)
    expected = iter(schema_fields)
    # Perform the test
    actual = schema.__iter__()
    # Validate the test results
    assert expected == actual


# Generated at 2022-06-24 11:05:12.945088
# Unit test for function set_definitions
def test_set_definitions():
    class Base(Schema):
        to_be_overridden = Reference(to="test")
    class Subclass(Base):
        to_be_overridden = Reference(to="test")
    assert Base.fields["to_be_overridden"].target is None
    assert Subclass.fields["to_be_overridden"].target is None
    definitions = SchemaDefinitions()
    definitions["test"] = type("test", (Schema,), {})
    set_definitions(Base.to_be_overridden, definitions)
    assert Base.fields["to_be_overridden"].target is not None
    assert Subclass.fields["to_be_overridden"].target is not None

# Generated at 2022-06-24 11:05:18.683063
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    value = {"a": 1, "b": 2}
    class MySchema(Schema):
        a = Field(type=int)
        b = Field(type=int)
    
    # check if both schemas are equal
    assert MySchema(value) == MySchema(value)

# Generated at 2022-06-24 11:05:26.694582
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema({"a": "b"})) == 1
    assert len(Schema()) == 0
    assert len(Schema(a="b")) == 1
    assert len(Schema({"a": "b"}, c="d")) == 2
    assert len(Schema({"a": "b"}, {"a": "b"}, {"c": "d"})) == 2


# Generated at 2022-06-24 11:05:28.426418
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
    assert "a" in A.fields


# Generated at 2022-06-24 11:05:30.755188
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    """
    test_SchemaDefinitions___getitem__
    """
    d = dict(a=1)
    tmp = SchemaDefinitions(d)
    tmp.__getitem__('a')


# Generated at 2022-06-24 11:05:32.685066
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Using default values for all parameters
    instance = SchemaDefinitions()
    assert len(instance) == 0


# Generated at 2022-06-24 11:05:34.377002
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema()) == "Schema()"


# Generated at 2022-06-24 11:05:35.225493
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    pass



# Generated at 2022-06-24 11:05:36.526848
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    d = SchemaDefinitions()
    assert d['key'] is None
    assert d['key'] is None
    assert d['key'] is None
    assert d['key'] is None


# Generated at 2022-06-24 11:05:37.485609
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass



# Generated at 2022-06-24 11:05:39.584905
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestClass(Schema):
        pass
    test_class = TestClass()
    assert isinstance(test_class, Mapping)
    assert issubclass(TestClass, Mapping)

# Generated at 2022-06-24 11:05:49.816908
# Unit test for constructor of class Schema
def test_Schema():
    class S1(Schema):
        pass
    s1=S1()
    assert isinstance(s1,S1) and isinstance(s1,Schema)
    class S2(Schema):
        a=Array(items=int)
        b=Reference('B')
    s2=S2()
    assert isinstance(s2,S2) and isinstance(s2,Schema)
    def error_fn1(str):
        S1(str)
    def error_fn2(str):
        S2(str)
    pytest.raises(TypeError,error_fn1,'x')
    pytest.raises(TypeError,error_fn2,'x')
    pytest.raises(TypeError,error_fn2,{'a':'y', 'b':'z'})


# Generated at 2022-06-24 11:06:01.162958
# Unit test for method validate of class Reference
def test_Reference_validate():
    '''
    This is the unit test for method validate of class Reference.
    '''
    class SomeClass1(Schema):
        attr1 = String()

    class SomeClass2(Schema):
        attr1 = String()
        attr2 = Reference(to = SomeClass1)

    some_class2_instance1 = SomeClass2(attr1 = "Attribute1", attr2 = SomeClass1(attr1 = "Attribute1"))
    assert some_class2_instance1 is not None
    assert some_class2_instance1.attr1 == "Attribute1"
    assert some_class2_instance1.attr2 is not None
    assert some_class2_instance1.attr2.attr1 == "Attribute1"


# Generated at 2022-06-24 11:06:11.087759
# Unit test for constructor of class Schema
def test_Schema():
    """
    Test for the constructor of class Schema
    """
    class A(Schema):
        x = Array(items=int, min_items=2, max_items=5,)
        y = str

    assert A.validate_or_error([1, 2, 3], strict=True) == ValidationResult(
        value=A([1, 2, 3]), error=None
    )
    assert A.validate_or_error([1, 2], strict=False) == ValidationResult(
        value=A([1, 2]), error=None
    )
    assert A.validate_or_error([1, 2, 3, 4, 5], strict=False) == ValidationResult(
        value=A([1, 2, 3, 4, 5]), error=None
    )
    assert A.validate_or_

# Generated at 2022-06-24 11:06:15.206583
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    obj = SchemaDefinitions()
    obj[1] = 1
    obj[2] = 2
    print(obj)
    try:
        obj[1] = 11
    except Exception as e:
        assert str(e) == r"Definition for '1' has already been set."

# Generated at 2022-06-24 11:06:23.045446
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class A(metaclass=SchemaMetaclass):
        pass
    assert not A.fields
    class A(metaclass=SchemaMetaclass):
        a=1
    assert not A.fields
    class A(metaclass=SchemaMetaclass):
        a=Field()
    assert A.fields['a'].value==None
    assert A().fields['a'].value==None
    class A(metaclass=SchemaMetaclass):
        a=Field()
        b=Array(a)
    assert A.fields['a'].value==None
    assert A.fields['b'].value==[]
    assert A().fields['a'].value==None
    assert A().fields['b'].value==[]
    class A(metaclass=SchemaMetaclass):
        a=Object

# Generated at 2022-06-24 11:06:28.053085
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import doctest
    import typesystem.contrib.django

    globs = {
        "User": typesystem.contrib.django.models.ModelField(User)
    }
    print(doctest.testmod(typesystem.contrib.django, globs=globs))


if __name__ == "__main__":
    import doctest
    import typesystem.contrib.django

    globs = {
        "User": typesystem.contrib.django.models.ModelField(User)
    }
    import sys

    sys.exit(doctest.testmod(typesystem.contrib.django, globs=globs)[0])

# Generated at 2022-06-24 11:06:32.058689
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Source code in lineno 7, col_offset 0
    assert str(
        Schema(
            {
                "foo": 1,
                "bar": "Spam",
            }
        )
    ) == "Schema(foo=1, bar='Spam')"



# Generated at 2022-06-24 11:06:33.852441
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    x = obj.__len__()


# Generated at 2022-06-24 11:06:45.613593
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(Schema):
        a = String()
        b = String()
    assert hasattr(TestSchemaMetaclass___new__, "fields")
    assert TestSchemaMetaclass___new__.fields["a"] == String()
    assert TestSchemaMetaclass___new__.fields["b"] == String()
    assert TestSchemaMetaclass___new__(a="a", b="b") != None
    assert TestSchemaMetaclass___new__(a="a", b="b") == TestSchemaMetaclass___new__(a="a", b="b")
    assert TestSchemaMetaclass___new__(a="a", b="b") != TestSchemaMetaclass___new__(a="a", b="c")
    assert TestSchemaMetaclass___

# Generated at 2022-06-24 11:06:52.663036
# Unit test for constructor of class Reference
def test_Reference():
    # Pass
    Reference(to="a")
    Reference(to=Schema, definitions={"b": Reference})
    reference = Reference(to="a")
    assert reference.to == "a"
    assert reference.definitions is None
    assert reference.allow_null == False
    assert reference.meta == {}
    assert reference.errors == {"null": "May not be null."}
    assert reference.target_string == "a"
    assert reference.target == Reference
    with pytest.raises(ValidationError):
        result = reference.validate(None)
    assert reference.serialize(NullableSchema()) == {}
    # Fail
    with pytest.raises(AssertionError):
        Reference(to="a", definitions={"b": Reference})

# Generated at 2022-06-24 11:06:56.093543
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    """
    Tests serializing a Reference. This is a test stub as it has no
    methods or parameters.
    """
    d = Reference
    s = d.serialize()
    assert s == {}

# Generated at 2022-06-24 11:07:02.375744
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0

    definitions['abc'] = 1
    assert len(definitions) == 1
    definitions['def'] = 2
    assert len(definitions) == 2

    del definitions['abc']
    assert len(definitions) == 1
    del definitions['def']
    assert len(definitions) == 0


# Generated at 2022-06-24 11:07:07.380259
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        foo_array = Array(items=Reference("Bar"))
        foo_array_2 = Array(items=[Reference("Bar")])
        foo_obj = Object(properties=dict(bar=Reference("Bar")))
        foo_obj_2 = Object(properties=dict(bar=[Reference("Bar")]))

    definitions = SchemaDefinitions()
    definitions["Bar"] = Object(properties={})
    set_definitions(Foo, definitions)

    Foo()
    Foo.validate({})

# Generated at 2022-06-24 11:07:10.946970
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from .fields import Integer, String
    from .schema_utils import Schema


    class Person(Schema):
        age = Integer(description="Age of the person.")
        first_name = String(description="First name of the person.")
        last_name = String(description="Last name of the person.")

        class Meta:
            description = "A person."

    person = Person(
        age=42,
        first_name="John",
        last_name="Doe",
    )
    assert len(person) == 3



# Generated at 2022-06-24 11:07:14.146245
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Setup
    definitions = SchemaDefinitions()

    # Exercise
    result = definitions.__iter__()

    # Verify
    assert result == iter(definitions._definitions)


# Generated at 2022-06-24 11:07:22.257859
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typeguard import check_type
    from typesystem.types import String

    class Animal(metaclass=SchemaMetaclass):
        name = String()
        number_of_legs = String()
    class Dog(Animal):
        is_good_boy = String()
    class Cat(Animal):
        is_fluffy = String()
    class CatAndDog(Cat, Dog):
        pass

    assert Cat.fields.keys() == {"name", "number_of_legs", "is_fluffy"}
    assert Dog.fields.keys() == {"name", "number_of_legs", "is_good_boy"}
    assert CatAndDog.fields.keys() == {"name", "number_of_legs", "is_fluffy", "is_good_boy"}

# Generated at 2022-06-24 11:07:25.844309
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import String, Number, Integer

    class MySchema(Schema):
        string = String()
        number = Number()
        id = Integer()

    my_schema = MySchema(string="test", number=1.1, id=1)
    assert list(my_schema.__iter__()) == ['string', 'number', 'id']


# Generated at 2022-06-24 11:07:31.812784
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import String

    class Pet(Schema):
        name = String()

    class Pet2(Schema):
        name = String()

    assert Pet(name="Fido") == Pet(name="Fido")
    assert Pet(name="Fido") != Pet2(name="Fido")
    assert Pet(name="Fido") != Pet(name="Dido")
    assert Pet(name="Fido") != {}



# Generated at 2022-06-24 11:07:35.190837
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    SchemaDefinitions.__delitem__({"test": "test"}, "test")
    assert True
    

# Generated at 2022-06-24 11:07:41.194462
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    print("Testing method __len__ of class SchemaDefinitions")
    my_definitions = SchemaDefinitions()
    try:
        assert len(my_definitions) == 0
        assert len(my_definitions) == 0
    except:
        raise AssertionError("Error somewhere in len(my_definitions), "+
                             "possibly in 'assert len(my_definitions) == 0'")



# Generated at 2022-06-24 11:07:46.467882
# Unit test for constructor of class Reference
def test_Reference():
    # 1. Argument `to` passed, which is a string
    testSchema = Reference("to", definitions={"to": "s"})
    assert testSchema.to == "to"

    # 2. Argument `to` passed, which is an object of class Schema
    testSchema = Reference(Schema, definitions={})
    assert issubclass(testSchema.to, Schema)



# Generated at 2022-06-24 11:07:56.506706
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String

    class AddressSchema(Schema):
        line1 = String(min_length=1, max_length=100)
        line2 = String(min_length=1, max_length=100)
        zipcode = String(min_length=5, max_length=5)
        city = String(min_length=1, max_length=50)
        state = String(min_length=2, max_length=2)

    class PersonSchema(Schema):
        name = String(min_length=1, max_length=100)
        age = Integer(minimum=0, maximum=150)
        address = Reference(to='AddressSchema')

        # Add definitions to the reference.
        definitions = SchemaDefinitions()

    print(PersonSchema.fields['address']._target)

   

# Generated at 2022-06-24 11:08:04.239635
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Tests that the metaclass generates the correct fields
    class B(Schema):
        a = "a"
        b = "b"

    class A(Schema):
        c = Object(properties=B.fields, additional_properties=False)

    a = A()
    a.c = B()
    a.c.a = "a"
    assert a["c"]["a"] == "a"


test_Schema___getitem__()

# Generated at 2022-06-24 11:08:15.484414
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from hypothesis import given
    from hypothesis.strategies import integers, lists, sets, text
    from cachetools import LRUCache
    import hypothesis.strategies as st

    class DummySchema(Schema):
        a = Field(int)
        b = Field(float)
        c = Field(str)

    def make_dummy(a, b, c):
        return DummySchema(a=a, b=b, c=c)

    @given(
        a=integers(),
        b=st.floats(allow_nan=False, allow_infinity=False),
        c=text(),
    )
    def test_dummy_schema_equality(a, b, c):
        d1 = make_dummy(a, b, c)

# Generated at 2022-06-24 11:08:16.248523
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    assert 0

# Generated at 2022-06-24 11:08:23.792622
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    Definition = SchemaDefinitions()
    class A(Schema):
        Definition['a'] = 'a'
        Definition['b'] = 'b'
        Definition['c'] = 'c'
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            if args:
                assert len(args) == 1
                assert not kwargs
                item = args[0]
                if isinstance(item, dict):
                    for key in self.fields.keys():
                        if key in item:
                            setattr(self, key, item[key])
                else:
                    for key in self.fields.keys():
                        if hasattr(item, key):
                            setattr(self, key, getattr(item, key))

# Generated at 2022-06-24 11:08:26.579428
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    d = SchemaDefinitions()
    d['a'] = 1
    d['b'] = 2
    assert (list(d.__iter__())==['a', 'b'])

# Generated at 2022-06-24 11:08:30.550566
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    def validate(schema, expected):
        assert len(schema) == expected
    class PersonSchema(Schema):
        name = Field()
        age = Field()
    schema = PersonSchema(name="Juan")
    validate(schema, 1)


# Generated at 2022-06-24 11:08:32.293207
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    reference = Reference(to="test")
    assert reference.serialize(None) is None
    assert reference.serialize(1) is None



# Generated at 2022-06-24 11:08:36.254690
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Parameters of the constructor.
    # Parameters: name: str, bases: Sequence[type], attrs: dict
    name = "TestSchema"
    bases = ()
    attrs = {}

    # Call the function that we are testing.
    SchemaMetaclass.__new__(SchemaMetaclass, name, bases, attrs)

# Generated at 2022-06-24 11:08:40.929905
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
        schema_definitions = SchemaDefinitions({"a": 0})
        assert len(schema_definitions.items()) == 1
        del schema_definitions["a"]
        assert len(schema_definitions.items()) == 0
        # default case
        schema_definitions = SchemaDefinitions()
        assert len(schema_definitions.items()) == 0
        del schema_definitions["a"]
        assert len(schema_definitions.items()) == 0



# Generated at 2022-06-24 11:08:47.775298
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    class Schema1(Schema):
        name = str
        age = int

    class Schema2(Schema):
        type = int
        age = int

    class Schema3(Schema):
        type = int
        age = int

    assert len(Schema1.fields.items()) == 2, "Expect len(Schema1.fields.items()) == 2"
    assert len(Schema2.fields.items()) == 2, "Expect len(Schema2.fields.items()) == 2"

    assert len(Schema3.fields.items()) == 2, "Expect len(Schema3.fields.items()) == 2"


# Generated at 2022-06-24 11:08:50.827175
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    try:
        definitions = SchemaDefinitions()
        items = definitions.items()
        for x in items:
            if not isinstance(x, tuple):
                raise AssertionError
            if not (2 <= len(x) <= 2):
                raise AssertionError
        actual = [x for x in items]
    except:
        actual = AssertionError
    expected = []
    assert actual == expected


# Generated at 2022-06-24 11:08:53.780327
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Global variables
    S1 = Schema.make_validator()
    R = Reference('S1')
    assert R.validate({}) == {}
    # Error test
    try:
        R.validate(None)
    except ValidationError:
        pass



# Generated at 2022-06-24 11:09:04.045379
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class FooSchema(Schema):
        foo = String(required=False)
        bar = Integer(required=False)
        baz = Boolean(required=False)

    class DummyClass(FooSchema):

        def __init__(self, foo: str = None, bar: int = None, baz: bool = None):
            super().__init__(foo=foo, bar=bar, baz=baz)

    assert repr(DummyClass()) == "DummyClass()"
    assert repr(DummyClass(foo="foo")) == "DummyClass(foo='foo')"
    assert repr(DummyClass(bar=1)) == "DummyClass(bar=1)"
    assert repr(DummyClass(baz=True)) == "DummyClass(baz=True)"

# Generated at 2022-06-24 11:09:12.665400
# Unit test for constructor of class Schema
def test_Schema():
    class Address(Schema):
        street = String()
        city = String()

    address = Address({"street": "805 Royal Street", "city": "New Orleans"})
    assert address["street"] == "805 Royal Street"
    assert address["city"] == "New Orleans"
    assert address.street == "805 Royal Street"
    assert address.city == "New Orleans"
    assert len(address) == 2
    assert list(address) == ["street", "city"]
    assert isinstance(address, Mapping)


    class Person(Schema):
        name = String()
        address = Reference(to=Address)

    person = Person({"name": "Charles", "address": {"street": "805 Royal St."}})
    assert person["address"]["street"] == "805 Royal St."
    assert person.address["street"]

# Generated at 2022-06-24 11:09:14.290991
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    s = SchemaDefinitions(a=1,b=2)
    assert(list(iter(s)) == ['a', 'b'])


# Generated at 2022-06-24 11:09:19.564804
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        name = String(max_length=20)
        age = Integer(minimum=0, maximum=120)
    class TestSchema2(Schema):
        prop1 = TestSchema
        prop2 = TestSchema
    prop1 = TestSchema()
    prop1.name = "I am a super hero"
    prop1.age = 20
    prop2 = TestSchema()
    prop2.name = "I am a super hero too"
    prop2.age = 30
    empty_schema = TestSchema()
    schema = TestSchema2(prop1=prop1, prop2=prop2)
    assert TestSchema2.validate(schema)
    assert TestSchema2.validate_or_error(schema).is_valid
    schema = TestSchema

# Generated at 2022-06-24 11:09:29.756769
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Positive test, Reference is valid and input is not none
    props = {
        "id": Integer(minimum=1, maximum=1000000),
        "dims": Array(items=Integer(minimum=1, maximum=1000, multiple_of=2))
    }
    validate_data = {'id': 1, 'dims': [0, 0]}
    validate_obj = Object(properties=props)
    validate_out = validate_obj.validate(validate_data)
    assert isinstance(validate_out, dict)
    # Negative test, input is null
    with pytest.raises(Exception) as e:
        validate_obj.validate(None)
    assert e.type is ValidationError
    assert isinstance(e.value.as_dict(), dict)

# Generated at 2022-06-24 11:09:39.822814
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class A(Schema):
        a = Integer(default=1, title="a")
        b = Integer(title="b")

    assert A.fields["a"] == Integer(default=1, title="a")
    assert A.fields["b"] == Integer(title="b")
    assert len(A.fields) == 2

    try:
        class A(Schema):
            a = Integer(default=1, title="a")
            a = Integer(title="b")
        assert False, "duplicate fields are not allowed"
    except AssertionError:
        pass

    class B(A):
        c = Integer(title="c")
    assert B.fields["a"] == Integer(default=1, title="a")
    assert B.fields["b"] == Integer(title="b")

# Generated at 2022-06-24 11:09:43.291920
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference.__init__
    reference = Reference("toto", default=["toto"])
    assert reference.target_string == "toto"

# Generated at 2022-06-24 11:09:51.374476
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Scenario 1
    # Tests when value is not None and value is valid
    # Expected: validated return the same value
    class To(Schema):
        pass

    ref = Reference(To)
    obj = To()

    expected = obj
    actual = ref.validate(obj)

    assert actual == expected
    
    
    
    # Scenario 2
    # Tests when value is None, allow_null is True and value is valid
    # Expected: validated return the same value
    ref = Reference(To)
    obj = To()

    expected = obj
    actual = ref.validate(obj)

    assert actual == expected

    # Scenario 3
    # Tests when value is None, allow_null is False and value is valid
    # Expected: The method throws the error 'null'

# Generated at 2022-06-24 11:09:55.772545
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # 1. Assign values
    definitions = SchemaDefinitions()
    definitions["key"] = "value"
    # 2. Execute code under test
    defs = iter(definitions)
    # 3. Assert we get the expected result
    assert list(defs) == list(definitions._definitions)
