

# Generated at 2022-06-24 10:59:55.380052
# Unit test for constructor of class Reference
def test_Reference():
    to = "abc"
    definitions = "abc"
    reference = Reference(to, definitions)
    assert reference.to == to
    assert reference.definitions == definitions
    assert reference.target == "abc"


# Generated at 2022-06-24 11:00:04.777585
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.base import Field
    from typesystem.fields import String

    class Schema1(Schema):
        field1 = Field(required=True)
        field2 = Field(required=False)

    schema1 = Schema1(field1="value1")
    assert list(schema1) == ["field1"]

    class Schema2(Schema):
        field1 = String(required=True)
        field2 = String(required=False)

    schema2 = Schema2(field1="value1")
    assert list(schema2) == ["field1"]


# Generated at 2022-06-24 11:00:06.570328
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference('name',max_length=20)
    r.validate(None)
    r.to

# Generated at 2022-06-24 11:00:13.877217
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A():
        def __init__(self, a: str, b: str, c: int):
            self.a = a
            self.b = b
            self.c = c
        def __eq__(self, other):
            if not isinstance(other, A):
                return False
            return self.a == other.a and self.b == other.b and self.c == other.c
    a1 = A('1', '2', 3)
    a2 = A('4', '5', 6)
    a3 = A('7', '8', 9)
    # a1 and a2 have the same __dict__, so a1 should not be equal to a2
    def alist(a):
        return eval(a.__repr__())
    a1_ser = alist(a1)


# Generated at 2022-06-24 11:00:22.589366
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        a = Field()
        b = Field()
        c = Field()

    class Bar(Schema):
        a = Field()
        b = Field()
        c = Field()

    class A(Schema):
        a = Reference(Foo)

    class B(Schema):
        a = Reference(Foo)

    class C(Schema):
        a = Reference(Foo)
        b = Reference(Bar)

    class D(A, B):
        d = Reference(Bar)

    class E(A, B):
        e = Reference(Bar)

    class F(D, E):
        f = Reference(Bar)

    class G(D, E):
        g = Reference(Bar)


# Generated at 2022-06-24 11:00:26.741024
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.primitives import String
    class FullName(Schema):
        first = String()
        last = String()
    
    class Person(Schema):
        name = FullName()
        age = String()
    
    fn = FullName(first='John', last='Doe')
    p = Person(name=fn, age='20')
    
    assert p.serialize() == {
        'name': {'first': 'John', 'last': 'Doe'},
        'age': '20'
    }

# Generated at 2022-06-24 11:00:31.287602
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typing import Dict, Any

    import typesystem
    from typesystem.types import String

    class Person(typesystem.Schema):
        name = String()

    person = Person({"name": "John"})

    value = person["name"]

    assert value == "John"

# Generated at 2022-06-24 11:00:33.847810
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Request(Schema):
        name = Field(str)

    request = Request({"name": "123"})
    assert request['name'] == "123"



# Generated at 2022-06-24 11:00:41.343853
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Child(Schema):
        age = Integer()
    class Parent(Schema):
        name = String()
        child = Reference(Child)

    parent = Parent({"name": "John", "child":{"age": 14}})
    expected = {"name":"John", "child":{"age":14}}
    assert parent == expected
    parent = Parent({"name": "John", "child":{"age": 14.5}})
    try:
        parent = Parent({"name": "John", "child":{"age": "14"}})
    except Exception as err:
        print("Test case Failed", err)

# Generated at 2022-06-24 11:00:50.259393
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions(a=5)
    assert s.get('a') == 5
    assert s.get('b') == None
    s['b'] = 7
    assert s.get('b') == 7
    #del[s['b']]
    #assert s.get('b') == None
    assert s.__len__() == 2
    assert s.__contains__('a') == True
    assert s.__contains__('c') == False
    assert s.__setitem__('c', 8) == None
    assert s.__len__() == 3
    assert s.__getitem__('c') == 8
    assert s.__getitem__('d') == KeyError

# Generated at 2022-06-24 11:00:54.272383
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    definitions["Test"] = "Test"
    assert len(definitions) == 1


# Generated at 2022-06-24 11:00:57.579922
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["Test"] = "Test"
    assert definitions["Test"] == "Test"


# Generated at 2022-06-24 11:01:07.674942
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # add definitions for all Schema classes
    definitions = SchemaDefinitions()

    # create test classes, which are Schema
    class A(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        a = String()
    class B(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        b = String()
    class C(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        c = String()
    class D(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        d = String()

    assert isinstance(A, type)
    assert isinstance(B, type)
    assert isinstance(C, type)
    assert isinstance(D, type)

    assert issubclass(A, Schema)
   

# Generated at 2022-06-24 11:01:12.090605
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert definitions.__len__() == 0
    definitions['test'] = 2
    assert definitions.__len__() == 1
    definitions['test'] = 3
    assert definitions.__getitem__('test') == 3
    assert len(definitions) == 1
    assert definitions.__getitem__('test') == 3
    assert len(definitions) == 1
    definitions.__delitem__('test')
    assert definitions.__len__() == 0

# Generated at 2022-06-24 11:01:17.498381
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    object_ = SchemaDefinitions()
    key = ""
    try:
        value = object_[key]
    except KeyError:
        pass


# Generated at 2022-06-24 11:01:20.928263
# Unit test for constructor of class Schema
def test_Schema():
    assert len(Schema.__init__.__code__.co_varnames) == 2
    assert len(Schema().fields.keys()) == 0

# Generated at 2022-06-24 11:01:25.998695
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class SomeClass(Schema):
        name = Field(str)
        age = Field(int, required=False)

    instance = SomeClass(name='foo', age=20)
    assert sorted(list(instance)) == ['age', 'name']


# Generated at 2022-06-24 11:01:29.504439
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    sd = SchemaDefinitions()
    sd['A'] = None
    sd['B'] = 1
    sd['D'] = 2
    sd['C'] = 3
    assert list(sd.__iter__()) == ['A', 'B', 'D', 'C']


# Generated at 2022-06-24 11:01:36.550742
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions([]) == {}
    assert SchemaDefinitions([], foo=42) == {"foo": 42}  # type: ignore
    assert SchemaDefinitions(foo=42) == {"foo": 42}
    assert len(SchemaDefinitions({})) == 0
    assert len(SchemaDefinitions([], foo=42)) == 1
    assert len(SchemaDefinitions(foo=42)) == 1

    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions["foo"] = 42



# Generated at 2022-06-24 11:01:40.737770
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Complex(Schema):
        real = Field()
        imaginary = Field()

    assert repr(Complex(real=10, imaginary=22)) == 'Complex(real=10, imaginary=22)'

    assert repr(Complex(real=10)) == 'Complex(real=10) [sparse]'


# Generated at 2022-06-24 11:01:46.703570
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    definitions.Person = None
    assert definitions['Person'] is None

# Generated at 2022-06-24 11:01:47.793498
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    assert False


# Generated at 2022-06-24 11:01:56.063082
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Test(Schema):
        pass

    class Test(Schema):
        a = Field()

    def test():
        class Test(Schema):
            a = Field()
            b = Field(default='')
            c = Field(default='')

        assert Test(a='test').a == 'test'
        assert Test(a='test', b='test').b == 'test'
        assert Test(a='test', b='test').c == ''

        assert Test.make_validator()(a=1, b=1) == {'a': 1, 'b': 1}
        assert Test.make_validator()(a=1, b=1, c=1) == {'a': 1, 'b': 1, 'c': 1}

# Generated at 2022-06-24 11:02:06.116263
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_defs = SchemaDefinitions()

    class TestSchema(Schema, metaclass=SchemaMetaclass, definitions=schema_defs):
        name = Reference("Name")

    class Name(Schema, metaclass=SchemaMetaclass, definitions=schema_defs):
        first = Field()
        last = Field()

    name = Name("Bob", "Dylan")
    s = TestSchema(name=name)
    s_ = TestSchema(name=name)
    s_prime = TestSchema(name="Bob")

    assert s == s_
    assert s != s_prime
    assert s.validate()
    assert s_prime.validate()

# Generated at 2022-06-24 11:02:09.417771
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test that builds a Schema object and calls __iter__ on it
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    person = Person(name="John Doe")
    for item in person:
        assert item in person

# Generated at 2022-06-24 11:02:17.326303
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        x = Field()
        y = Field()

    class B(Schema):
        a = Reference(A)

    class C(Schema):
        b = Reference(B)

    definitions = SchemaDefinitions()
    b = B(a=A(x=1, y=2))
    c = C(b=b)
    set_definitions(c, definitions)
    assert definitions == {
        "A": A,
        "B": B,
        "C": C,
    }
    assert c.b.a.definitions is definitions

# Generated at 2022-06-24 11:02:29.943991
# Unit test for method validate of class Reference
def test_Reference_validate():
    from examples.user import User
    from typesystem.schema import Reference
    from typesystem.fields import String, Integer
    def validate(obj, allow_null=False):
        schema = Reference(User, allow_null=allow_null)
        return schema.validate(obj)
    def test(obj, allow_null=False):
        try:
            validate(obj, allow_null=allow_null)
        except:
            return False
        return True
    # test 1
    user = {
        "name": "John Doe",
        "email": "johndoe@example.com",
        "age": 30,
        "address": {
            "city": "Paris",
            "country": "France",
            "zip_code": "75000"
        }
    }
    assert test(user)
   

# Generated at 2022-06-24 11:02:33.336558
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    w = Reference("test")
    assert w.serialize("test") is None
    class Test(Schema):
        a = "test"
    assert w.serialize({1:4}) == {1:4}

# Generated at 2022-06-24 11:02:37.584362
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["a"] = 1
    if definitions["a"] != 1:
        raise RuntimeError
    if "a" not in definitions.keys():
        raise RuntimeError
    if "a" not in definitions.__dict__["_definitions"]:
        raise RuntimeError


# Generated at 2022-06-24 11:02:43.666549
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class A(Schema):
        a = str
        b=int

    class B(Schema):
        x = Reference(A)
        y = Reference(A)
    
    b = B(x=A(a="foo", b=0), y=A(a="bar", b=1))
    expected_dict_b = {'x': {'a': 'foo', 'b': 0}, 'y': {'a': 'bar', 'b': 1}}
    actual_dict_b = dict(b)
    assert expected_dict_b == actual_dict_b

# Generated at 2022-06-24 11:02:53.371081
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        id = Integer()
        name = String(max_length=140)
        age = Integer()

        class Friends(Schema):
            close_friends = Array(of=Person)
            more_friends = Array(of=Person)

        best_friends = Array(of=Person)
        friends = Friends()
    # SchemaMetaclass.__new__ creates class 'Person' and populates attribute 'fields'
    print("test_SchemaMetaclass():")
    print("class Person(Schema):") 
    print("    id = Integer()")
    print("    name = String(max_length=140)")
    print("    age = Integer()")
    print("    class Friends(Schema):")
    print("        close_friends = Array(of=Person)")

# Generated at 2022-06-24 11:02:55.067094
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    try:
        assert 1 == 2
    except AssertionError as e:
        raise e


# Generated at 2022-06-24 11:02:58.353005
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        name = String()
        country = String()

    assert A.__name__ == 'A'
    assert A.fields == {'name': String, 'country': String}


# Generated at 2022-06-24 11:03:01.796058
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_definitions = SchemaDefinitions()
    assert schema_definitions._definitions == {}
    schema_definitions2 = SchemaDefinitions([("a", "b")], c="d")
    assert schema_definitions2._definitions == {"a": "b", "c": "d"}


# Generated at 2022-06-24 11:03:03.532096
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference.serialize({1, 2, 3}) == {1, 2, 3}
    assert Reference.serialize(()) == ()


# Generated at 2022-06-24 11:03:12.450708
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Test a case where the validation is successful
    class InnerSchema(Schema):
        a = Field()
        b = Field()

    class SampleReference(Schema):
        inner_schema = Reference(InnerSchema)

    value = SampleReference(inner_schema={'a':'val1','b':'val2'})
    assert value.inner_schema.a == 'val1'
    assert value.inner_schema.b == 'val2'

    # Test a case where validation is unsuccessful
    class SampleReference2(Schema):
        inner_schema = Reference(InnerSchema, required=True)

    try:
        value = SampleReference2(inner_schema=None)
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-24 11:03:16.672515
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    p = Person(dict(name="Petr", age=28))

    assert p.name == "Petr"
    assert p.age == 28
    assert p.is_sparse == False
    assert str(p) == "Person(name='Petr', age=28)"


# Generated at 2022-06-24 11:03:26.147912
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Empty(Schema):
        pass
    a = Empty()
    b = len(a)
    assert b == 0
    class Basic(Schema):
        a = Field()
        b = Field()
        c = Field()
    c = Basic()
    d = len(c)
    assert d == 3
    class Advanced(Schema):
        a = Field()
        b = Field()
        c = Field()
    d = Advanced(a=1, b=2, c=3)
    e = len(d)
    assert e == 3
    f = Advanced(a=1, b=2, c=3, d=4)
    g = len(f)
    assert g == 4


# Generated at 2022-06-24 11:03:30.470340
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema = SchemaDefinitions()
    assert len(schema) == 0
    schema['a'] = 1
    assert len(schema) == 1
    schema['a'] = 2
    assert len(schema) == 1
    schema['b'] = 2
    assert len(schema) == 2


# Generated at 2022-06-24 11:03:37.210458
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import Boolean, Integer, String, Array
    from typesystem.schema import Schema

    class Person(Schema):
        id = Integer()
        is_adult = Boolean(default=False)

    class Post(Schema):
        author = Reference(Person)
        headline = String()

    class Timeline(Schema):
        posts = Array(items=Reference(Post))

    post = Post({
        'author': {
            'id': 1,
        },
        'headline': 'New post',
    })
    timeline = Timeline({
        'posts': [
            post,
        ],
    })
    assert timeline.posts[0].author.id == 1

# Generated at 2022-06-24 11:03:44.287943
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # The classes below would not be able to access their own fields
    # and would raise an error in __init__ if this were not fixed.
    class Inherited(Schema):
        a = "a"

    class Interface(Schema):
        b = "b"

    class Implementing(Inherited, Interface):
        c = "c"
        d = "d"

    assert list(Implementing.fields.keys()) == ["a", "b", "c", "d"]
    assert Implementing.__name__ == "Implementing"

# Generated at 2022-06-24 11:03:46.576860
# Unit test for constructor of class Reference
def test_Reference():
  assert Reference is not None


# Generated at 2022-06-24 11:03:52.060750
# Unit test for constructor of class Schema
def test_Schema():
    # initialize an instance of class Schema
    testSchema = Schema(greeting = "Hello", convo = "How are you?")
    assert testSchema == Schema(greeting = "Hello", convo = "How are you?")


# Generated at 2022-06-24 11:03:53.630734
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import pytest

    def test_method():
        pass



# Generated at 2022-06-24 11:03:59.267480
# Unit test for function set_definitions
def test_set_definitions():
    """
    - Input:
        - (obj: dict) field: {'a': Reference('Ref1')}
        - (dict) definitions: {'Ref1': {'b': Integer}}
    - Expected output:
        - Nothing
    """
    class ChildItem(Schema):
        b = Integer()
    class Item(Schema):
        a = Reference('ChildItem')

    definitions = SchemaDefinitions({
        'ChildItem': ChildItem
    })
    set_definitions(Item.fields['a'], definitions)
    assert Item.fields['a'].definitions == definitions


# Generated at 2022-06-24 11:04:04.907324
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import String
    from typesystem.schema import Schema

    class Person(Schema):
        name = String()

    person = Person(name="Joe")
    person_repr = f"Person({person.__dict__})"
    assert repr(person) == person_repr or repr(person) == person_repr[:-1] + ' [sparse])'

# Generated at 2022-06-24 11:04:06.563001
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:04:07.592928
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    return None


# Generated at 2022-06-24 11:04:17.150091
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import json
    import os
    import pathlib
    import string
    import tempfile
    import typesystem.fields
    import typesystem.metadata
    import typesystem.schema
    from typesystem.fields import ContextVar, Field, Object
    from typesystem.metadata import Metadata
    from typesystem.schema import Schema, SchemaDefinitions, SchemaMetaclass
    from typesystem.validators import Validator

    class TestSchema(Schema, metaclass=SchemaMetaclass):

        class Meta:
            title = "Test schema"

        field0 = Field(default=None)
        field1 = Field(default=42)
        field2 = Field(default="foo")
        field3 = Field(default=None)
        field4 = Field(default=False)
        field5 = Field(default=None)

# Generated at 2022-06-24 11:04:23.446838
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
	class TestSchema1(Schema, metaclass=SchemaMetaclass):
	    value = Integer()
	    message = String(required=False)

	assert TestSchema1.fields == {"value": Integer(), "message": String(required=False)}
	assert TestSchema1.__doc__ == None
	assert TestSchema1.__module__ == "__main__"
	assert TestSchema1()["value"] == None
	assert TestSchema1()["message"] == None
	assert TestSchema1(value=3)["value"] == 3
	assert TestSchema1(message="Hello!")["message"] == "Hello!"
	assert TestSchema1(value=5, message="Hello!")["value"] == 5

# Generated at 2022-06-24 11:04:29.082597
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'
    assert definitions['key'] == 'value'


# Generated at 2022-06-24 11:04:36.690326
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    _args = []
    _kwargs = {}
    _return_value = {}
    _return_value['1'], _return_value['2'] = object(), object()
    def _mock_dict(*args, **kwargs):
        assert args == _args
        assert kwargs == _kwargs
        return _return_value
    with unittest.mock.patch('builtins.dict', _mock_dict):
        obj = SchemaDefinitions(*_args, **_kwargs)
        assert obj['1'], _return_value['1']
        assert obj['2'], _return_value['2']
        assert sorted(obj) == ['1', '2']


# Generated at 2022-06-24 11:04:45.612346
# Unit test for method validate of class Reference
def test_Reference_validate():
    testCase_1 = Object(
        properties={
            'param_1': Field(required=True, type='string'),
            'param_2': Field(required=True, type='string'),
            'param_3': Field(required=True, type='string'),
        }
    )
    testCase_2 = Reference(to=testCase_1)
    testCase_2.definitions = {'testCase_1' : testCase_1}
    result = testCase_2.validate({
        'param_1': 'aaaa',
        'param_2': 'bbbb',
        'param_3': 'cccc',
    })
    assert(isinstance(result, Object))
    assert(result.param_1 == 'aaaa')
    assert(result.param_2 == 'bbbb')

# Generated at 2022-06-24 11:04:53.004924
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Spam(metaclass=SchemaMetaclass):
        spam: str

    spam = Spam(spam="a")

    assert spam.fields == {"spam": Field(str)}
    assert spam.spam == "a"
    assert spam == Spam(spam="a")
    assert spam != Spam(spam="b")
    assert spam != Spam(eggs="a")
    assert spam != Spam(spam="a", eggs="b")

    spam = Spam({"spam": "a"})

    assert spam.fields == {"spam": Field(str)}
    assert spam.spam == "a"
    assert spam == Spam(spam="a")
    assert spam != Spam(spam="b")
    assert spam != Spam(eggs="a")

# Generated at 2022-06-24 11:04:55.637696
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Test(Schema):
        field1 = Reference('Test')
    test = Test(field1=Test(field1=1))
    assert test.serialize() == {'field1': {'field1': 1}}

# Generated at 2022-06-24 11:05:03.912284
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Initialization of the class of which we want to test the method
    class TestSchema(Schema):
        a = Field(type="number")
        b = Field(type="number")
    # Initialization of a dictionary to test the method
    test_object = {
        "a": 1,
        "b": 2
    }
    # Initialization of the object we want to test
    test_schema = TestSchema(test_object)
    # Assertion that the outcome of the method is correct
    assert test_schema["a"] == 1

# Generated at 2022-06-24 11:05:08.179302
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sample = SchemaDefinitions()
    # Sample call: sample.__setitem__('a', 'b')
    assert throw(lambda: sample.__setitem__('a', 'b'), AssertionError)
    sample.__setitem__('a', 'b')
    return



# Generated at 2022-06-24 11:05:09.166321
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass




# Generated at 2022-06-24 11:05:12.816445
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema = Schema(1, 2, 3, 4)
    
    assert (schema == Schema(1, 2, 3, 4)) == True, 'Error'
    assert (schema == Schema(1, 2, 3, 5)) == False, 'Error'
    assert (schema == Schema(1, 2, 3)) == False, 'Error'

# Generated at 2022-06-24 11:05:22.782152
# Unit test for method __getitem__ of class SchemaDefinitions

# Generated at 2022-06-24 11:05:33.428207
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()

    person = Person(name="Guido van Rossum")
    assert person.name == "Guido van Rossum"
    assert person.is_sparse
    assert len(person) == 1
    assert person["name"] == "Guido van Rossum"

    # Explicit keyword arguments are validated.
    with pytest.raises(TypeError):
        Person(name=1)

    # All fields are set.
    person = Person(dict(name="Guido van Rossum"))
    assert not person.is_sparse

    # Keyword arguments can be used, even for fields with defaults.
    class PersonWithAge(Person):
        age = Number(default=50)

    person = PersonWithAge(name="Guido van Rossum")
    assert person.age == 50

# Generated at 2022-06-24 11:05:35.724425
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class City(Schema):
        name = String()

    city = City(name="Rennes")
    assert(city["name"] == "Rennes")


# Generated at 2022-06-24 11:05:37.324944
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Test(Schema):
        pass
    assert len(Test()) == 0


# Generated at 2022-06-24 11:05:47.403852
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import operator
    from typesystem.typing import Optional

    # Test empty schema
    class Empty(Schema):
        pass

    assert len(Empty()) == 0

    # Test schema with one field
    class Single(Schema):
        value = Field()

    assert len(Single()) == 0
    assert len(Single(value=123)) == 1

    # Test schema with multiple fields
    class Multiple(Schema):
        value1 = Field()
        value2 = Field()
        value3 = Optional(Field())

    assert len(Multiple()) == 0
    assert len(Multiple(value1=123, value2=456, value3=789)) == 3
    assert len(Multiple(value1=123, value2=456)) == 2
    assert len(Multiple(value1=123)) == 1

    # Test schema with multiple fields

# Generated at 2022-06-24 11:05:50.720620
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = Field(type=str)

    class PersonWithCity(Person):
        city = Reference("City")

    definitions = SchemaDefinitions()
    set_definitions(PersonWithCity.city, definitions)
    assert PersonWithCity.city.definitions == definitions


# Generated at 2022-06-24 11:05:53.281243
# Unit test for constructor of class Schema
def test_Schema():
    assert issubclass(Schema, Mapping)


# Generated at 2022-06-24 11:06:00.769870
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String
    from typesystem.schema import SchemaMetaclass
    import typesystem
    class Namespace(metaclass=SchemaMetaclass):
        name = String()
    assert isinstance(type.__new__, typesystem.SchemaMetaclass)
    assert not hasattr(Namespace, 'type')
    assert hasattr(Namespace, 'name')
    assert isinstance(Namespace.name, String)
    a = Namespace(name='a')
    assert not a.is_sparse


# Generated at 2022-06-24 11:06:06.465755
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = SchemaDefinitions()
    b = SchemaDefinitions(a)
    c = SchemaDefinitions(a, b)
    d = SchemaDefinitions(e=5, f=6)
    e = SchemaDefinitions(a, e=5, f=6)
    f = SchemaDefinitions({'a': 1}, e=5, f=6)
    g = SchemaDefinitions({'a': 1}, {'b': 2}, e=5, f=6)


# Generated at 2022-06-24 11:06:07.468851
# Unit test for constructor of class Schema
def test_Schema():
    assert 0


# Generated at 2022-06-24 11:06:11.959277
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'
    assert definitions['key'] == 'value'
    try:
        definitions['key'] = 'value2'
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-24 11:06:21.091859
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test that Schema.__repr__() returns a string with expected format
    class ToDo(Schema):
        name: str
        description: str = ""
        is_done: bool = False

    # If a value is not provided, the default value should be used
    todo_item = ToDo(name="Wash Car")
    expected = "ToDo(name='Wash Car')"
    assert repr(todo_item) == expected

    # If a value is not provided, the default value should be used
    # even if the default value is None
    class ToDo(Schema):
        name: str
        description: str = None
        is_done: bool = False

    todo_item = ToDo(name="Wash Car")
    expected = "ToDo(name='Wash Car', description=None)"
   

# Generated at 2022-06-24 11:06:31.050559
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    def foo(cls: type, name: str, bases: typing.Sequence[type], attrs: dict,
            definitions: SchemaDefinitions = None) -> type:
        print('cls: ',cls)
        print('name: ',name)
        print('bases: ',bases)
        print('attrs: ',attrs)
        print('definitions: ',definitions)
        return type(name, bases, attrs)

    class Temp(metaclass=foo):
        a = 1

    Temp()
    # cls:  <class '__main__.foo'>
    # name:  Temp
    # bases:  (<class 'object'>,)
    # attrs:  {'__module__': '__main__', '__qualname__': 'Temp', 'a': 1}
    # definitions:

# Generated at 2022-06-24 11:06:33.741973
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
  dd = SchemaDefinitions()
  assert len(dd) == 0
  dd["test"] = 0
  assert len(dd) == 1
  dd["test"] = 0
  assert len(dd) == 1


# Generated at 2022-06-24 11:06:42.721740
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Test to see if the __getitem__ method of the class SchemaDefinitions works as intended
    print("\nUnit test for method __getitem__ of class SchemaDefinitions")
    schema_definitions = SchemaDefinitions(
        {
            'ExampleSchema': Schema,
        }
    )
    try:
        result = schema_definitions.__getitem__('ExampleSchema')
        print("Test passed!\n")
    except AssertionError as e:
        print("Test failed: {}\n".format(str(e)))


# Generated at 2022-06-24 11:06:45.052573
# Unit test for method validate of class Reference
def test_Reference_validate():
    s = Reference("test")
    assert s.validate("test") == ""
    assert s.validate(None) is None

# Generated at 2022-06-24 11:06:54.125241
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Integer
    from typesystem.fields import Float
    from typesystem.typing import Float as FloatType
    import numpy as np

    class TestSchema1(Schema):
        id = Integer()
        weight = Float(default=5.5)

    test_instance_1 = TestSchema1({"id": 5})
    # Check if a sparse object only contains attributes for fields that are not
    # empty.
    assert test_instance_1.__repr__() == "TestSchema1(id=5) [sparse]"
    # Check if the repr method works for non sparse values
    assert TestSchema1({"id": 5, "weight": 5.5}).__repr__() == "TestSchema1(id=5, " \
                                                               "weight=5.5)"


# Generated at 2022-06-24 11:07:04.865587
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    from json import dumps
    
    # test normal operation
    s = SchemaDefinitions({"red": 5, "blue": 10, "yellow": 6, "orange": 7})
    assert len(s) == 4
    assert dumps(s, sort_keys=True) == '{"blue": 10, "orange": 7, "red": 5, "yellow": 6}'
    s["green"] = 8
    assert len(s) == 5
    assert dumps(s, sort_keys=True) == '{"blue": 10, "green": 8, "orange": 7, "red": 5, "yellow": 6}'
    s["golden"] = 9
    assert len(s) == 6

# Generated at 2022-06-24 11:07:09.357892
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    def serialize(self, obj: typing.Any) -> typing.Any:
        if obj is None:
            return None
        return dict(obj)



# Generated at 2022-06-24 11:07:20.523457
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        a = Field(type="string", required=True)
        b = Field(type="string")
        c = Field(type="string", default="default")

    a = A(a="a", b="b")
    assert a.a == "a"
    assert a.b == "b"
    assert a.c == "default"

    a = A({"a": "a", "b": "b"})
    assert a.a == "a"
    assert a.b == "b"
    assert a.c == "default"

    a = A(a="a", c="c")
    assert a.a == "a"
    assert a.b is None
    assert a.c == "c"

    a = A(a="a")

# Generated at 2022-06-24 11:07:27.127181
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Foo(Schema):
        bar = Array(items=Integer)
        # bar = Array(items=[Integer, String])
        # bar = Array(items={"type": "integer", "max_value": 10})
        # bar = Array(items=[Integer, {"type": "string", "min_length": 10}])
        baz = Object(properties={"fizz": {"type": "string"}})
        bizz = {"type": "string", "enum": ["buzz"]}

    class Baz(Schema):
        foo = Reference(Foo)
        fizz = Reference(to="Foo")
        buz = Reference(to=Foo)

    print(Baz.validate_or_error({"foo": {"bar": [1, 2, 3]}}))

# Generated at 2022-06-24 11:07:29.518238
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Pet(Schema):
        name = Field()

    class Person(Schema):
        pet = Reference(Pet)

    person = Person.validate(dict(pet=dict(name="dog")))
    assert person.pet.name == "dog"
    assert person["pet"] == dict(name="dog")

# Generated at 2022-06-24 11:07:31.768578
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Case 1
    definitions = SchemaDefinitions()
    x_1 = definitions.__iter__()
    assert isinstance(x_1, iterator)

# Generated at 2022-06-24 11:07:43.637404
# Unit test for constructor of class Schema
def test_Schema():

    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    # checks all attributes correctly set
    test = TestSchema({'field1': 1, 'field2': 1})
    assert test.field1 == 1 and test.field2 == 1 and test.is_sparse is False

    # checks fields correctly set
    test = TestSchema({'field1': 1})
    assert test.field1 == 1 and test.is_sparse is True

    # checks class error raised
    raised = False
    try:
        TestSchema()
    except TypeError as e:
        assert "__init__() missing 2 required positional arguments: 'field2'" in str(e)
        raised = True
    assert raised

    # checks class error raised
    raised = False

# Generated at 2022-06-24 11:07:47.188841
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # test_SchemaDefinitions___setitem___02
    defs = SchemaDefinitions()
    defs["Foo"] = 1
    defs["Bar"] = 2

    defs["Foo"] = 3

    # TODO uncomment assert and fix it
    # assert False



# Generated at 2022-06-24 11:07:50.430003
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["test"] = None
    assert schema_definitions["test"] == None


# Generated at 2022-06-24 11:07:51.672220
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
  assert True


# Generated at 2022-06-24 11:07:54.545728
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    set_definitions(
        Object(properties={"child": Reference("String")}), definitions
    )
    assert issubclass(Reference, Field)



# Generated at 2022-06-24 11:08:02.375413
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name=String()
        age=Integer()
    p=Person()
    assert len(p)==0
    p=Person(name='choi')
    assert len(p)==1
    p=Person(name='choi', age=33)
    assert len(p)==2
    p=Person(name='choi', age=33, male=True)
    assert len(p)==2


# Generated at 2022-06-24 11:08:09.964881
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    try:
        definitions = SchemaDefinitions()
        definitions["x"] = 0
        assert False, "Expected AssertionError"
    except AssertionError as e:
        assert (
            str(e) == r"Definition for 'x' has already been set."
        ), "Received unexpected exception: %s" % e
    try:
        definitions = SchemaDefinitions()
        definitions[0] = 0
        definitions[0] = 1
        assert False, "Expected AssertionError"
    except AssertionError as e:
        assert (
            str(e) == r"Definition for 0 has already been set."
        ), "Received unexpected exception: %s" % e

# Generated at 2022-06-24 11:08:14.051885
# Unit test for method serialize of class Reference
def test_Reference_serialize():

    class Person(Schema):
        name = String()

    ref = Reference(Person)
    obj = ref.serialize(Person({'name': 'John'}))
    assert obj == {'name': 'John'}

test_Reference_serialize()

# Generated at 2022-06-24 11:08:19.377622
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import String, Integer
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert person['name'] == 'John'
    assert person['age'] == 30

    try:
        person['occupation']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 11:08:23.862104
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        """
        Test schema for Schema class:
        """
        field1 = Field()
        field2 = Field()
        field3 = Field()

    for i in TestSchema:
        print(i)


# Generated at 2022-06-24 11:08:25.551579
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert set_definitions(Mapping, SchemaDefinitions) == None
        

# Generated at 2022-06-24 11:08:28.301872
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    print('Unit test for method __iter__ of class SchemaDefinitions')
    obj1 = SchemaDefinitions()
    assert list(obj1) == [] 


# Generated at 2022-06-24 11:08:29.612213
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass



# Generated at 2022-06-24 11:08:33.849511
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    data = [
        ('asc', ('sort', 'asc')),
        ('desc', ('sort', 'desc')),
        ('def', ('sort', 'def')),
        ('default', ('sort', 'default')),
    ]
    for option, result in data:
        assert Reference('Sort', sort_options=[option]).serialize({'sort': option}) == result

# Generated at 2022-06-24 11:08:36.173821
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert (Reference.validate(1) == 1)
    assert ((Reference.validate(None) == None) == Reference.allow_null)



# Generated at 2022-06-24 11:08:37.374078
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert definitions == {}



# Generated at 2022-06-24 11:08:44.216238
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    import types
    import inspect
    import copy 

    # make a copy of the Schema class to preserve the original
    Schema_ = copy.deepcopy(Schema)  # type: typing.Type[Schema_]
    attrs = {"name": "name"}
    bases = [types.SimpleNamespace(name="namespace")]
    kwargs = {"definitions": {"name": Schema}}
    metaclass = SchemaMetaclass.__new__(SchemaMetaclass, "Schema", bases, attrs, **kwargs)
    new_type = type.__new__(metaclass, "name", (Schema_,), {})
    assert isinstance(new_type, Schema_)
    assert new_type.__qualname__ == "name"

# Generated at 2022-06-24 11:08:53.424236
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Array, Integer, Object, String

    class Pet(Schema):
        name = String(max_length=100)
        age = Integer()

    class Person(Schema):
        name = String(max_length=100)
        pets = Array(items=Object(properties={
            'name': String(max_length=100),
            'kind': String(max_length=100),
        }))
        is_owner = Boolean(required=True)

    data = {
        'name': 'Bruno',
        'pets': [{'name': 'Scratchy', 'kind': 'cat', 'age': 14},
                 {'name': 'Bolt', 'kind': 'dog'},
                 {'name': 'Gwennie', 'kind': 'iguana'}]
    }


# Generated at 2022-06-24 11:08:58.594778
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String, Integer
    from typesystem.object import Object

    class Todo(Schema):
        title = String()
        position = Integer()

    class Todos(Schema):
        todos = Array(Reference("Todo"))

    definitions = SchemaDefinitions({"Todo": Todo})
    Todos.make_validator(strict=True)

# Generated at 2022-06-24 11:09:08.641578
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    """
    class SchemaMetaclass

    Class to construct schema class
    """
    class MetaSchema:
        class Meta:
            definitions = SchemaDefinitions()

        class Schema1(Schema, metaclass=SchemaMetaclass):
            id = Field(str)

        class Schema2(Schema, metaclass=SchemaMetaclass):
            id = Reference(to="Schema1")
            Meta.definitions["Schema2"] = Schema2

    assert hasattr(MetaSchema, "Schema1")
    assert hasattr(MetaSchema, "Schema2")
    assert MetaSchema.Schema2.fields["id"].target_string == "Schema1"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 11:09:11.486903
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__(): 
    from typesystem.fields import String

    class User(Schema):
        name = String()

    definitions = SchemaDefinitions()
    assert definitions["User"] is User


# Generated at 2022-06-24 11:09:13.935076
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class Author(Schema):
        name = String()

    class Book(Schema):
        title = String()
        author = Reference(Author)



# Generated at 2022-06-24 11:09:19.328053
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import Boolean

    class DummySchema(Schema):
        foo = Boolean()

    a = DummySchema(foo=True)
    b = DummySchema(foo=False)
    c = DummySchema(foo=True)
    assert a != b
    assert a == c


# Generated at 2022-06-24 11:09:23.436148
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def f():
        SchemaDefinitions("1", "2")
    try:
        f()
        assert False # It should have thrown an exception
    except Exception as e:
        assert isinstance(e, AssertionError) # It should throw an AssertionError exception


# Generated at 2022-06-24 11:09:28.496916
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String
    from typesystem.schema import Schema

    class MySchema(Schema):
        name = String()

    data = MySchema(None, name="foo")
    assert len(data) == 1

    data = MySchema(None)
    assert len(data) == 0



# Generated at 2022-06-24 11:09:31.482647
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sample_definitions = SchemaDefinitions()
    
    definitions = {'key': 'value'}
    sample_definitions.__setitem__('definitions', definitions)
    assert definitions == sample_definitions['definitions']

# Generated at 2022-06-24 11:09:40.781565
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    item = SchemaDefinitions([('6', ''), ('7', ''), ('2', ''), ('3', '')])
    expected_len_1 = len(item)
    expected_len_2 = 4
    assert expected_len_1 == expected_len_2, 'Expected different values for <len(item)>'
    item = SchemaDefinitions([('2', ''), ('3', ''), ('5', ''), ('9', '')])
    expected_len_1 = len(item)
    expected_len_2 = 4
    assert expected_len_1 == expected_len_2, 'Expected different values for <len(item)>'
    item = SchemaDefinitions([('9', ''), ('8', ''), ('4', ''), ('10', '')])
    expected_len_1 = len(item)

# Generated at 2022-06-24 11:09:46.222219
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Create a SchemaDefinitions object
    obj1 = SchemaDefinitions()
    # Check that __delitem__ works as expected
    obj1[0] = 0
    del obj1[0]
    # Check that __delitem__ raises the correct error for incorrect arguments
    with pytest.raises(KeyError):
        del obj1[0]


# Generated at 2022-06-24 11:09:50.160444
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = 1
        b = 2
        c = 3
    test = TestSchema({'a':1})
    assert len(test) == 1
    test = TestSchema({'a':1, 'b':2, 'c':3})
    assert len(test) == 3


# Generated at 2022-06-24 11:09:59.593603
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema().is_sparse

    # Test that calling the constructor with an invalid keyword argument
    # raises an error.
    from typesystem import Integer
    
    class Person(Schema):
        age = Integer()
    
    def f():
        Person(hair_colour='blue')
    try:
        f()
    except TypeError as e:
        assert 'hair_colour' in str(e)
    else:
        assert False

    # Test that calling the constructor with a positional argument
    # raises an error.
    def f():
        Person(1)
    try:
        f()
    except TypeError as e:
        assert 'Person() takes no positional arguments' in str(e)
    else:
        assert False

    # Test that a class that doesn't inherit from Schema
    # has no fields attribute.
