

# Generated at 2022-06-24 10:59:57.193458
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class A(Schema):
        foo = "a"
        bar = "b"
    assert repr(A({"foo": "Foo", "bar": "Bar"})) == "A(foo='Foo', bar='Bar')"
    assert repr(A(foo="Foo", bar="Bar")) == "A(foo='Foo', bar='Bar')"
    assert repr(A(foo="Foo")) == "A(foo='Foo') [sparse]"

# Generated at 2022-06-24 11:00:00.053980
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions({})
    schema_definitions["a"] = "b"
    assert schema_definitions._definitions == {"a": "b"}



# Generated at 2022-06-24 11:00:03.092487
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    s = Schema({"test_Schema___repr__": "test_Schema___repr__"})
    s.__repr__()

if __name__ == '__main__':
    test_Schema___repr__()

# Generated at 2022-06-24 11:00:12.108620
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def test_getitem():
        schema_definitions = SchemaDefinitions()
        schema_definitions['key1'] = 'value1'
        assert schema_definitions['key1'] == 'value1'

    def test_iter():
        schema_definitions = SchemaDefinitions()
        schema_definitions['key1'] = 'value1'
        schema_definitions['key2'] = 'value2'
        sample_data = {}
        for item in schema_definitions:
            sample_data[item] = schema_definitions[item]
        assert sample_data == {'key1':'value1', 'key2':'value2'}

    def test_len():
        schema_definitions = SchemaDefinitions()
        assert len(schema_definitions) == 0
        schema_definitions['key1']

# Generated at 2022-06-24 11:00:16.575323
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # There is no error if 'key' is not in self._definitions.

    # Create the mocks.
    sd = SchemaDefinitions()
    key = 'abc'
    value = "abc"

    # Perform the test.
    sd[key] = value
    assert sd[key] == value


# Generated at 2022-06-24 11:00:26.425809
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class SubSchema(Schema):
        v1 = String()
        v2 = String()
        v3 = String()

    class MySchema(Schema):
        v1 = String()
        v2 = String()
        v3 = String()
        v4 = String()
        v5 = String()
        SubSchema = SubSchema

    ms1 = MySchema.validate({"v1": "a", "v2": "b", "v3": "c"})
    ms2 = ms1
    ms3 = MySchema.validate({"v1": "a", "v2": "b", "v3": "c"})

    assert ms1 == ms2
    assert ms2 == ms3
    assert ms1 is not ms2
    assert ms2 is not ms3

# Generated at 2022-06-24 11:00:28.094082
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    definitions['MyDefinition'] = 'a'
    assert len(definitions) == 1


# Generated at 2022-06-24 11:00:39.816185
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    try:
        print('Testing: class Foo(Schema, metaclass=SchemaMetaclass)')
        class Bar(Mapping):
            fields: typing.Dict[str, Field] = {}

        class Foo(Bar):
            pass

        print('Expectation: TypeError')
        print('Result:')
        print(Foo)
        print('Passed!')
    except TypeError:
        print('Passed!')

    try:
        print('Testing: class Foo(Schema, metaclass=SchemaMetaclass)')
        class Foo(Schema):
            pass

        print('Expectation: TypeError')
        print('Result:')
        print(hasattr(Foo, 'fields'))
        print('Passed!')
    except TypeError:
        print('Passed!')



# Generated at 2022-06-24 11:00:50.052398
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Given
    from typesystem import Schema
    import types

    class A(Schema):
        name = str
        number = int

    class B(Schema):
        name = str
        age = int
        class1 = A

    A.fields.update(B.fields)
    A.fields.update(((key, value) for key, value in B.fields.items() if key!= 'class1'))
    del A.fields['class1']
    definitions = SchemaDefinitions()
    A.__init__(A, definitions)
    B.__init__(B, definitions)
    definitions["B"] = B

    # When
    actual = definitions["B"]

    # Then
    assert isinstance(actual, types.FunctionType)



# Generated at 2022-06-24 11:01:01.527413
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Transportation(Schema):
        id = Integer()
        carrier = String()
        transport_mode = String(choices=["air", "water", "road"], case_insensitive=True)
        capacity = Integer()
    class Vehicle(Schema):
        name = String()
        color = String(format="color")
        transportation_id = Reference(to=Transportation)
    # Unit test for method validate of class Reference
    # Test validator Reference(ref=Transportation) with valid value
    vehicle = Vehicle.validate(
        {
            "name": "Test vehicle",
            "color": "blue",
            "transportation_id": {
                "id": 1,
                "carrier": "Test carrier",
                "transport_mode": "road",
                "capacity": 20000
            }
        }
    )


# Generated at 2022-06-24 11:01:03.136182
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # TODO
    assert True


# Generated at 2022-06-24 11:01:08.064642
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import String
    from pprint import pprint

    MyClass = Schema.define(
        "MyClass", name=String(max_length=100) 
    )
    user = MyClass({"name": "Foo McBar"})
    assert user["name"] == "Foo McBar"
    pprint(user)


# Generated at 2022-06-24 11:01:12.210719
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    d = SchemaDefinitions()
    assert len(d.keys()) == 0
    d["foo"] = 1
    assert len(d.keys()) == 1
    assert "foo" in d
    assert d["foo"] == 1
    assert ["foo"] == list(dict(d).keys())


# Generated at 2022-06-24 11:01:14.845923
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    pass

# Generated at 2022-06-24 11:01:17.271076
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    _obj = SchemaDefinitions()
    _obj.__delitem__(1)


# Generated at 2022-06-24 11:01:21.440277
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from .test_validators import Person

    result = repr(Person("Gustav","von Aschenbach"))
    assert result == "Person(first_name='Gustav', last_name='von Aschenbach')"

# Generated at 2022-06-24 11:01:25.565272
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    instances = [SchemaDefinitions({"key": "value"})]
    for instance in instances:
        with pytest.raises(NotImplementedError):
            instance.__delitem__("key")


# Generated at 2022-06-24 11:01:28.377823
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Setup
    m = {1: 2}

    # Exercise
    instance = SchemaDefinitions(m)

    # Verify
    expected = 1
    actual = len(instance)
    assert expected == actual

# Generated at 2022-06-24 11:01:33.509866
# Unit test for constructor of class Reference
def test_Reference():
    to = str
    definitions = SchemaDefinitions()
    str_val = Reference(to, definitions)
    assert str_val.to == to
    assert str_val.definitions == definitions
    assert str_val.errors == {"null": "May not be null."}

    class TestSchema(Schema):
        field1 = str
        field2 = str

    to = TestSchema
    str_val = Reference(to)
    assert str_val.to == to
    assert str_val.definitions == None

# Generated at 2022-06-24 11:01:42.952375
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Example 1
    definitions = SchemaDefinitions()
    class SchemaA(Schema, metaclass=SchemaMetaclass):
        field_1 = Reference('SchemaB',definitions)
 
    class SchemaB(Schema, metaclass=SchemaMetaclass):
        field_2 = Reference('SchemaB',definitions)

    schema_a = SchemaA({'field_1':{'field_2':{'field_2':'field2'}}})
    assert schema_a.validate({'field_1':{'field_2':{'field_2':'field2'}}},'', strict=False) == schema_a
    assert schema_a.validate({'field_1':{'field_2':{'field_2':'field2'}}}) == schema_a
    

# Generated at 2022-06-24 11:01:49.014162
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    s = SchemaDefinitions()
    assert len(s) == 0
    s['a'] = 1
    assert len(s) == 1
    del s['a']
    assert len(s) == 0


# Generated at 2022-06-24 11:01:51.814564
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions["foo"] = "bar"
    definitions["hello"] = "world"
    assert len(definitions) == 2


# Generated at 2022-06-24 11:01:56.388010
# Unit test for constructor of class Reference
def test_Reference():
    class Author(Schema):
        name = String()
    class Book(Schema):
        title = String()
        author = Reference("Author")
    assert type(Book.fields['author'].target) == type(Author)

# Generated at 2022-06-24 11:02:00.644575
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from .models import TestSchema1
    obj = TestSchema1(id=1, name="test")
    expected = dict(obj)
    assert Reference("TestSchema1").serialize(obj) == expected

# Generated at 2022-06-24 11:02:10.754308
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class MovieMeta(Schema):
        title = String(min_length=1, max_length=120)
        rating = String(enum=['G', 'PG', 'PG-13', 'R'])

    class Movie(Schema):
        id = String(format='uuid')
        meta = Reference(to=MovieMeta)

    meta = MovieMeta(title='Star Wars: A new Hope', rating='PG')
    movie = Movie(id='2c5ea4c0-4067-11e9-8bad-9b1deb4d3b7d', meta=meta)

    assert movie.meta.title == 'Star Wars: A new Hope'
    assert movie.meta.rating == 'PG'
    assert movie.meta == {'title': 'Star Wars: A new Hope', 'rating': 'PG'}
    assert movie

# Generated at 2022-06-24 11:02:16.333968
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    """
    Test if Reference.serialize() returns a dictionary
    """
    class Test(Schema):
        s = String()
        r = Reference(to="Test")

    assert Test(s="a").r == Test(s="a").r

    test = Test(s="a")
    assert isinstance(test.r, dict)
    assert test.r["s"] == "a"

# Generated at 2022-06-24 11:02:22.124053
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    temp = SchemaDefinitions()
    temp['A'] = 'A'
    temp['B'] = 'B'
    temp__iter = temp.__iter__()
    temp__len = temp.__len__()

    assert temp__iter == ['A', 'B']
    assert temp__len == 2

    del temp['A']
    temp__iter = temp.__iter__()
    temp__len = temp.__len__()

    assert temp__iter == ['B']
    assert temp__len == 1



# Generated at 2022-06-24 11:02:31.054338
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_a = Schema(dict(a=1))
    schema_b = Schema(dict(b=2))

    # Test whether the method 'References.validate' can correctly compare two same schemas
    reference_same = Reference(to=schema_a,definitions=SchemaDefinitions(dict(schema_a=schema_a,schema_b=schema_b)))
    assert reference_same.validate(schema_a,strict=False) == schema_a

    # Test whether the method 'References.validate' can correctly check a schema
    reference_same_check = Reference(to=schema_a,definitions=SchemaDefinitions(dict(schema_a=schema_a,schema_b=schema_b)))

# Generated at 2022-06-24 11:02:41.112116
# Unit test for function set_definitions
def test_set_definitions():
    class OriginalSchema(Schema):
    
        title = Field()
        field_1 = Field()
        field_2 = Field()
        field_3 = Field()
        field_4 = Field()
        field_5 = Field()
        field_6 = Field()
        field_7 = Field()
        field_8 = Field()
        field_9 = Field()
        field_10 = Field()
        field_11 = Field()
        field_12 = Field()
        field_13 = Field()
        field_14 = Field()
        field_15 = Field()
        field_16 = Field()
        field_17 = Field()
        field_18 = Field()
        field_19 = Field()
        field_20 = Field()
        field_21 = Field(default = "default value")

# Generated at 2022-06-24 11:02:44.982212
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    assert "abcd" == Schema({"a":1,"b":2,"c":3,"d":4})["abcd"]


# Generated at 2022-06-24 11:02:48.170535
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    """
    The whole serialize process was not test by previous code.
    """
    class TestRef(Reference):
        def __init__(self):
            super().__init__("TestRef")

    obj = TestRef()
    result = obj.serialize(obj)
    assert result == {}

# Generated at 2022-06-24 11:02:51.274958
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A(Schema):
        a = Field(type=str)
    class B(Schema):
        a = Reference(to=A)
    v = B.validate({'a':{'a':'d'}})
    assert v.a.a == 'd'
    

# Generated at 2022-06-24 11:02:54.941104
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    iter_obj=SchemaDefinitions()
    try:
        list(iter_obj)
    except:
        assert False, "unexpected exception"
    else:
        assert True, "no exception"

# Generated at 2022-06-24 11:03:03.483470
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.object import Object
    from typesystem.schema import Schema
    from typesystem.compat import PY36_PLUS

    class Person(Schema):
        id = Field(type="integer")
        name = Field(type="string")

    class PersonRef(Reference):
        to = Person

    class Department(Schema):
        name = Field(type="string")
        manager = PersonRef()

    class DepartmentRef(Reference):
        to = Department

    class Company(Schema):
        name = Field(type="string")
        departments = Array(items=DepartmentRef())

    @Person.validator
    def person_validator(cls, value):
        if not isinstance(value, Person):
            return cls(value)
        return value


# Generated at 2022-06-24 11:03:07.392157
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    d = SchemaDefinitions()
    assert len(d) == 0

    d["1"] = 1
    d["2"] = 2
    d["3"] = 3
    assert len(d) == 3

    del d["1"]
    assert len(d) == 2

    d["4"] = 4
    assert len(d) == 3


# Generated at 2022-06-24 11:03:12.502315
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    s = SchemaDefinitions({"key1":"value1", "key2":"value2", "key3":"value3"})
    assert len(s) == 3
    s["key4"] = "value4"
    assert len(s) == 4


# Generated at 2022-06-24 11:03:14.847327
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    def test_body(self):
        obj = SchemaDefinitions()
        res = len(obj)
        return res

    def test_stub():
        return 0

    assert test_body(SchemaDefinitions()) == test_stub()


# Generated at 2022-06-24 11:03:26.257506
# Unit test for method __eq__ of class Schema

# Generated at 2022-06-24 11:03:27.785102
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    x = SchemaDefinitions(x = 1)
    x['y'] = 2
    del x['y']


# Generated at 2022-06-24 11:03:34.733718
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    to = 'Example'
    defs = dict()
    kwargs = dict(required=True)
    reference = Reference(to, defs, **kwargs)

    class Example(Schema):
        name = String(max_length=10)
        age = Integer()
        
    defs[to] = Example
    obj = Example('Jim', 21)
    assert reference.serialize(obj) == dict(name='Jim', age=21)
    assert reference.serialize(None) is None

# Generated at 2022-06-24 11:03:36.384457
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Setup
    definitions=SchemaDefinitions()

    # Exercise
    actual = len(definitions)
    # Verify
    assert actual == 0



# Generated at 2022-06-24 11:03:45.810040
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Test the case value is null and allow_null is true
    field = Reference("course")
    assert field.validate(None) is None
    # Test the case value is null and allow_null is false
    field = Reference("course", allow_null=False)
    try:
        field.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "null"
        assert e.message == "May not be null."
    # Test the case value is not null
    class Course(Schema):
        id = Field(type=str)
    field = Reference("course")
    field.definitions = {
        "course": Course.make_validator()
    }
    value = field.validate({
        "id": "0"
    })

# Generated at 2022-06-24 11:03:52.113462
# Unit test for constructor of class Reference
def test_Reference():
    class A(Schema):
        a_field: str = Field()
    class B(Schema):
        a_ref: Reference[A] = Reference[A]()
    a = A(a_field="asdf")
    b = B(a_ref=a)
    assert b.a_ref.a_field == "asdf"

# Generated at 2022-06-24 11:03:57.172817
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class_name = ''.join(random.choice(string.ascii_letters) for _ in range(10))
    obj=Schema({})
    obj._class_name=class_name
    fields={'a':1}
    obj._fields=fields
    assert obj.__repr__()=='{}({!r})'.format(class_name,fields)



# Generated at 2022-06-24 11:04:02.520495
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    c1 = [1, 2, 3]
    c2 = [4, 5, 6]
    c3 = [7, 8, 9]
    schema = Schema(c1 = c1, c2 = c2, c3 = c3)
    li = []
    for i in schema:
        li.append(i)
    assert li == ['c1', 'c2', 'c3']



# Generated at 2022-06-24 11:04:10.557293
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    d = SchemaDefinitions({'a': 1})
    d['b'] = 2
    d['c'] = 3
    print(d.__dict__)
    assert (d.__dict__['_definitions'] == {'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-24 11:04:19.114751
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    def test_1():
        # Test SchemaMetaclass with valid input.
        class MySchema(Schema):
            name = String()
            description = String(allow_null=True)

        class MyOtherSchema(Schema):
            my_schema = Reference(MySchema)
            my_string = String()

        definitions = SchemaDefinitions()
        new_schema: type = SchemaMetaclass.__new__(
            SchemaMetaclass, "MyOtherSchema", (Schema,), {"fields": {}}, definitions
        )
        assert new_schema is not None

    def test_2():
        # Test SchemaMetaclass with invalid value for attribute 'fields'.
        class MySchema(Schema):
            name = String()
            description = String(allow_null=True)

       

# Generated at 2022-06-24 11:04:22.001780
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    class EmptySchema(typesystem.Schema):
        pass
    assert EmptySchema.fields == {}

# Generated at 2022-06-24 11:04:26.612881
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class State(Schema):
        name = String(max_length=100)
        abbreviation = String(max_length=2)

    state = State(name="Oregon", abbreviation="OR")

    assert state.__iter__() == iter(['name', 'abbreviation'])


# Generated at 2022-06-24 11:04:28.854021
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions["key"] = 1
    del definitions["key"]
    with pytest.raises(KeyError):
        definitions["key"]


# Generated at 2022-06-24 11:04:35.945029
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Create object to test
    obj = SchemaDefinitions(a=1, b=2, c=3, d=4)
    obj_it = iter(obj)
    obj_len = len(obj)

    # Create expected result
    expected_result = ['a', 'b', 'c', 'd']
    expected_result_it = iter(expected_result)
    expected_result_len = len(expected_result)

    # Test method for equality
    for x, y in zip(obj_it, expected_result_it):
        assert x == y
    assert obj_len == expected_result_len



# Generated at 2022-06-24 11:04:38.439088
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema = Schema()
    f = Reference(schema, to=schema)
    value = f.validate(schema)
    assert value == schema


# Generated at 2022-06-24 11:04:39.415317
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass


# Generated at 2022-06-24 11:04:40.775824
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    obj = SchemaDefinitions()
    assert False


# Generated at 2022-06-24 11:04:48.061774
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    from unittest import TestCase
    import typesystem
    import typesystem_marshmallow
    import marshmallow
    class address(typesystem.Schema):
        country=typesystem.String()
    class person(typesystem.Schema):
        name=typesystem.String(max_length=10)
        address=typesystem.Reference(address)
    class employer(typesystem.Schema):
        person=typesystem.Reference(person)
        address=typesystem.Reference(address)
    definitions=typesystem_marshmallow.make_definitions()
    print(definitions)
    assert len(definitions)==5
    assert list(definitions.keys())==['address', 'address.1', 'person', 'person.1', 'employer']
    assert isinstance(definitions['address'], address)

# Generated at 2022-06-24 11:04:50.520321
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class ItemSchema(Schema):
        foo = Field()
    schema = ItemSchema(foo="Hi")
    assert [k for k in schema] == ["foo"]

# Generated at 2022-06-24 11:05:02.069268
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():

    definitions = SchemaDefinitions()
    definitions['name'] = 'Foo'
    assert definitions['name'] == 'Foo'
    assert definitions.__len__() == 1
    definitions['age'] = 40
    assert definitions['age'] == 40
    assert definitions.__len__() == 2
    try:
        definitions['name'] = 'Bar'
        assert "Definition for 'name' has already been set." == False
    except AssertionError:
        assert "Definition for 'name' has already been set." == True


# Generated at 2022-06-24 11:05:07.750380
# Unit test for constructor of class Schema
def test_Schema():
    # Create an instance of Schema with name: test_schema
    test_schema1 = Schema(**{"field_1": 100, "field_2": "test"})
    assert test_schema1.field_1 == 100
    assert test_schema1.field_2 == "test"

    class TestSchema(Schema):
        field_1 = Integer()
        field_2 = String()

    test_schema2 = TestSchema({"field_1": 100, "field_2": "test"})
    assert test_schema2.field_1 == 100
    assert test_schema2.field_2 == "test"
    test_schema2 = TestSchema(field_1=100, field_2="test")



# Generated at 2022-06-24 11:05:12.003727
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Sub(Schema):
        prop = Field()

    class FieldSerializeTest(Schema):
        ref = Reference(Sub)

    sub = Sub({"prop": 1})
    field_serialize_test = FieldSerializeTest({"ref": sub})
    ref = field_serialize_test["ref"]
    assert ref == {"prop": 1}


# Generated at 2022-06-24 11:05:14.476609
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    result = len(obj)



# Generated at 2022-06-24 11:05:17.274859
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class PersonSchema(Schema):
        first_name = Field(str)
        last_name = Field(str)
        age = Field(int)

    person = PersonSchema({"first_name": "Fred", "age": 12})
    assert person["first_name"] == "Fred"
    assert person["age"] == 12
    assert "last_name" not in person


# Generated at 2022-06-24 11:05:31.618430
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions({})
    class Item(Schema):
        id: str
        title: str

    class List(Schema):
        items: typing.List[Reference]

    # Test a simple case.
    list_ = List(items=["Item", "Item"])
    for item in list_.items:
        assert item.definitions == definitions

    # Test that sub-objects, lists and tuples are handled correctly.
    class Meta(Schema):
        count: int
        list: List

    meta = Meta(count=1, list={"items": ["Item", "Item"]})
    assert meta.list.items[0].definitions == definitions

    # Test that objects are partially handled correctly.
    class Sub(Schema):
        name: str
        items: typing.List[Reference]


# Generated at 2022-06-24 11:05:37.853270
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = Field(type="string", allow_null=True)
    # exception raised because of value is null
    assert (Reference(to="User").validate(None) == None)
    # exception raised because of value is null and allow_null is False
    assert (Reference(to="User", allow_null=False).validate(None) == None)
    # exception not raised because of value is valid
    assert (Reference(to=User).validate({"name": "John"}))
    # exception raised because of value included invalid field
    try:
        Reference(to="User").validate({"email": "john@example.com"})
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-24 11:05:40.995371
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = Field(type="string", allow_null = False)
        age = Field(type="integer", allow_null = False)
        sex = Field(type="string", enum=["male", "female"], allow_null = False)
    person = Person(name="Tina", age=18, sex="female")
    for key, value in person.items():
        print(f"key: {key}, value: {value}")


# Generated at 2022-06-24 11:05:44.470042
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Create mappings
    class MySchema(Schema):
        name = Field()
        age = Field()
    my_schema_instance = MySchema()
    my_schema_instance.name = 'John Doe'
    my_schema_instance.age = 26
    expected_result = {'name': 'John Doe', 'age': 26}
    result = my_schema_instance
    assert result == expected_result



# Generated at 2022-06-24 11:05:54.381527
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import String, Integer

    class Foo(Schema):
        foo: String
        bar: Integer

    class Baz(Schema):
        foo: Reference(to="Foo")

    def TestReference():
        obj = Baz.validate({"foo": {"foo": "foo", "bar": 1}})
        assert obj.foo == Foo(foo="foo", bar=1)

    # TestReference()

    class Bar(Schema):
        foo: Reference(to=Foo)

    def TestReferenceSchema():
        obj = Bar.validate({"foo": {"foo": "foo", "bar": 1}})
        assert obj.foo == Foo(foo="foo", bar=1)

    TestReferenceSchema()


# Generated at 2022-06-24 11:06:03.485792
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    error_code = '90024'
    error_desc = 'Operation currently unavailable, please wait for maintenance or try again later.'
    errors = {
        'validation': [{
            'code': error_code,
            'description': error_desc
        }]
    }
    schema = SchemaDefinitions()
    schema['Schema'] = Schema
    try :
        assert schema['Schema'] == Schema, f"Invalid value of member of class SchemaDefinitions. Expected 'Schema', but got {schema['Schema']}."
    except AssertionError as e:
        print(f"{e}")

# Generated at 2022-06-24 11:06:10.291163
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    from typesystem.fields import String
    from typesystem.schemas import SchemaDefinitions, Schema, Reference

    definitions = SchemaDefinitions()
    class User(Schema):
        name = String()
    class Post(Schema):
        user = Reference(User)            # after definition: User
        user_name = Reference(User, 'name') # after definition: User

    expected = ['User', 'Post']
    actual = SchemaDefinitions.__iter__(definitions)
    assert actual == expected


# Generated at 2022-06-24 11:06:11.192146
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass # TODO


# Generated at 2022-06-24 11:06:13.045580
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    ret = len(obj)
    assert ret == 0


# Generated at 2022-06-24 11:06:16.601279
# Unit test for constructor of class Reference
def test_Reference():
    validator = Reference(Schema)
    try:
        validator.validate(None)
    except ValidationError:
        print('raise ValidationError as expected')
    else:
        print('didn\'t raise ValidationError as expected')



# Generated at 2022-06-24 11:06:21.660747
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import Integer, String

    class Person(Schema):
        name = String
        age = Integer

    john = Person(name="John", age=35)
    jane = Person(name="Jane", age=35)
    assert john == Person(name="John", age=35)
    assert john != jane
    assert john != jane.serialize()
    assert john != dict(name="John", age=35)
    assert john == dict(name="John", age=35, id=1)

# Generated at 2022-06-24 11:06:25.888196
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    s = SchemaDefinitions()
    s.__delitem__("key")
    pass



# Generated at 2022-06-24 11:06:33.131326
# Unit test for constructor of class Reference
def test_Reference():
    obj = Reference("MyClass")
    assert obj.to == "MyClass"
    assert obj.definitions is None
    assert obj._target_string == "MyClass"
    assert obj._target is None
    assert obj.errors == {"null": "May not be null."}
    assert obj.validation_error == ValidationError
    assert obj.validate == Reference.validate
    assert obj.serialize == Reference.serialize
    assert obj.validate_or_error == Field.validate_or_error


# Generated at 2022-06-24 11:06:35.738107
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert Reference._Reference__validate(None, "null") == "null"

# Generated at 2022-06-24 11:06:42.721856
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class A(Schema):
        x = Reference('B')
    class B(Schema):
        pass
    class C(Schema):
        y = Reference('A')
        z = Reference('B')
    class D(Schema, definitions=definitions):
        m = Reference('C')
        n = Reference('A')
        o = Reference('B')
    class E(Schema):
        p = Reference('D')
    assert isinstance(definitions['D'], type)

# Generated at 2022-06-24 11:06:52.284784
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    try:
        assert not (assrt.endswith("___setitem__")), "Do not call __setitem__ directly"
    except NameError:
        pass
    import typesystem
    import typesystem.base
    import typesystem.fields
    class test(typesystem.base.Schema):
        field = typesystem.fields.String(max_length=8)
    definitions = typesystem.base.SchemaDefinitions()
    definitions['test'] = test
    try:
        assert (definitions['test'] == test), "__setitem__ method of class SchemaDefinitions doesn't return expected value"
    except AssertionError:
        raise AssertionError("__setitem__ method of class SchemaDefinitions doesn't return expected value")

# Generated at 2022-06-24 11:06:54.031186
# Unit test for constructor of class Reference
def test_Reference():
    value = Reference
    expected_result = Reference

    result = Reference
    assert result == expected_result, "Expected: %s Actual: %s" % (expected_result, result)

# Generated at 2022-06-24 11:06:56.437592
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class S1(Schema):
        a = Field()
    s = S1()
    assert len(s) == 0
    assert len(s.fields) == 1


# Generated at 2022-06-24 11:07:04.486895
# Unit test for function set_definitions
def test_set_definitions():
    definition = SchemaDefinitions()
    class TestSchema(Schema):
        def_test = Reference("test", definitions=definition)
        test = Reference("test", definitions=definition)
    class TestClass(Schema):
        pass
    definition["test"] = TestClass
    set_definitions(TestSchema.def_test, definition)
    set_definitions(TestSchema.test, definition)
    assert TestSchema.def_test.definitions == definition
    assert TestSchema.test.definitions == definition



# Generated at 2022-06-24 11:07:07.841637
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    d = SchemaDefinitions()
    assert d['test'] == None


# Generated at 2022-06-24 11:07:19.484699
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(String)
        age = Field(Integer)

    assert isinstance(Person.fields, dict)
    assert 'name' in Person.fields
    assert isinstance(Person.fields['name'], Field)
    assert Person.fields['name'].__class__ is String
    assert 'age' in Person.fields
    assert isinstance(Person.fields['age'], Field)
    assert Person.fields['age'].__class__ is Integer

    assert Person.validate({'name' : 'Joe', 'age' : 45}) == {'name' : 'Joe', 'age' : 45}
    assert Person.validate({'name' : 'Joe', 'age' : '45'}) == {'name' : 'Joe', 'age' : 45}


# Generated at 2022-06-24 11:07:22.388045
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(str)
    p = Person(name="Nick", age=27, height="1.72")
    assert list(p) == ['name', 'age', 'height']



# Generated at 2022-06-24 11:07:27.400381
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import pytest
    class TestSchema(Schema):
        foo = Field(String)
        bar = Field(String)
    schema = TestSchema(foo='bar')
    assert len(schema) == 1
    for k in schema: assert k in ['foo', 'bar']

# Generated at 2022-06-24 11:07:33.304722
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import tensorflow as tf
    import tensorflow_hub as hub
    import types

    class SchemaTest(Schema, metaclass=SchemaMetaclass):
        foo = Field()
        bar = Field()

    assert type(SchemaTest.fields) == dict
    assert type(SchemaTest.foo) == types.MemberDescriptorType
    assert type(SchemaTest.bar) == types.MemberDescriptorType

    # test that SchemaTest.fields is not Schema.fields (which should be empty)
    assert len(SchemaTest.fields) != 0
    assert len(Schema.fields) == 0

    # test SchemaTest.fields
    assert len(SchemaTest.fields.items()) == 2

# Generated at 2022-06-24 11:07:35.515149
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String
    from typesystem.schema import Schema

    class Person(Schema):
        name = String(format="name")

    expected = 1
    result = len(Person(name="Peter"))
    assert expected == result


# Generated at 2022-06-24 11:07:40.263931
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        param1 = String(description='param1', pattern='^0x[0-9A-F]{8}$')
        param2 = Integer(description='param2')

    # test same instance
    s1 = MySchema(param1='0xFFFFFFFF', param2=15)
    assert s1.__eq__(s1) is True
    # test same params
    s2 = MySchema(param1='0xFFFFFFFF', param2=15)
    assert s1.__eq__(s2) is True
    # test diffrent values
    s3 = MySchema(param1='0xFFFFAAAA', param2=20)
    assert s1.__eq__(s3) is False
    # test diffrent instances

# Generated at 2022-06-24 11:07:44.355803
# Unit test for constructor of class Reference
def test_Reference():
    f = Reference(int)
    assert f.to == int
    assert f.definitions == None
    assert f._target_string == None
    assert f._target == int

    g = Reference(str)
    assert g.to == str
    assert g.definitions == None
    assert g._target_string == None
    assert g._target == str


# Generated at 2022-06-24 11:07:46.260420
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """SchemaMetaclass.__new__"""
    from . import Schemas
    assert True, 'Test is not implemented'

# Generated at 2022-06-24 11:07:52.459047
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = String()
        age = Integer()

    class Family(Schema):
        members = Array(items=Reference(Person))

    f = Family(members=[Person(name="John", age=12), Person(name="Alex", age=13)])
    assert f["members"] == [{"name": "John", "age": 12}, {"name": "Alex", "age": 13}]

# Generated at 2022-06-24 11:07:59.207902
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Prepare
    class Schema1(Schema):
        field1 = String(allow_null=True)
        field2 = String()

    class Schema2(Schema):
        field1 = String(allow_null=True)
        field2 = String()

    # Execute & Verify
    assert repr(Schema1()) == "Schema1(field1=None, field2='')"
    assert repr(Schema1(field1="string1")) == "Schema1(field1='string1', field2='')"
    assert repr(Schema1(field2="string2")) == "Schema1(field2='string2') [sparse]"
    assert repr(Schema1(field1="string1", field2="string2")) == "Schema1(field1='string1', field2='string2')"


# Generated at 2022-06-24 11:08:10.532256
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Create a new instance of SchemaDefinitions.
    items = []
    definitions = SchemaDefinitions(items)
    # Check the length of definitions
    assert len(definitions) == 0
    # Create some instances of schema to add to definitions.
    class Dog(Schema):
        name = String
        age = Number
    class Cat(Schema):
        name = String
        age = Number
    # Add the schemas to definitions.
    definitions.update({'Dog': Dog, 'Cat': Cat})
    # Check the length of definitions.
    assert len(definitions) == 2


# Generated at 2022-06-24 11:08:14.472153
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    definitions = SchemaDefinitions({"Person": Person})
    del definitions["Person"]

    assert "Person" not in definitions


# Generated at 2022-06-24 11:08:18.460060
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    assert sd._definitions == {}
    a = Field()
    sd['a'] = a
    assert a.definitions == {'a': a}
    assert sd._definitions == {'a': a}


# Generated at 2022-06-24 11:08:23.489870
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Point(Schema):
        x = Field(type=int)
        y = Field(type=int)
    point1 = Point({"x": 1, "y": 2})
    point2 = Point({"x": 1, "y": 2})
    assert point1 == point2


# Generated at 2022-06-24 11:08:29.239889
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Schema
    from typesystem import fields

    class UserSchema(Schema):
        email = fields.String()
        name = fields.String(required=False)
        age = fields.Integer(required=False)

    user_schema = UserSchema({"email": "cicconi@example.com", "name": "Chris"})
    assert len(user_schema) == 2
    assert list(user_schema._asdict().keys()) == ['email', 'name']


# Generated at 2022-06-24 11:08:31.037343
# Unit test for constructor of class Reference
def test_Reference():
    to_str = 'test_str'
    ref = Reference(to_str)
    assert ref.to == to_str


# Generated at 2022-06-24 11:08:34.507810
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        name = String()
    class OtherSchema(Schema):
        test = Reference(TestSchema)

    test_dict = {'name': 'test'}
    test_obj = TestSchema(test_dict)
    assert OtherSchema.fields['test'].serialize(test_obj) == test_dict

# Generated at 2022-06-24 11:08:39.003187
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Reference(Schema):
        name = String()
        age = Integer()

    class User(Schema):
        reference = Reference()

    user = User({"reference": {"name": "John Doe", "age": 42}})

    assert user == User(reference=Reference(name="John Doe", age=42))
    assert user.serialize() == {"reference": {"name": "John Doe", "age": 42}}

# Generated at 2022-06-24 11:08:44.751583
# Unit test for constructor of class Schema
def test_Schema(): 
    class User(Schema):
        email = String(max_length=100)
        name = String(max_length=50)

    obj = User(email="john@example.com", name="john")
    assert obj["email"] == "john@example.com"
    assert obj["name"] == "john"
    print("Test for constructor of class Schema passed.")


# Generated at 2022-06-24 11:08:47.958738
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String
    class User(Schema):
        id = String()
    assert isinstance(User, type)
    # Note that a type can be used as a default value.
    assert User.fields['id'] == String()


# Generated at 2022-06-24 11:08:49.744490
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['test'] = 0
    del definitions['test']



# Generated at 2022-06-24 11:08:55.705253
# Unit test for function set_definitions
def test_set_definitions():
    class Child(Schema):
        foo = Field()

    class Parent(Schema):
        child = Reference(Child, definitions=SchemaDefinitions())
        children = Array(items=Reference(Child, definitions=SchemaDefinitions()))

    definitions = SchemaDefinitions()
    set_definitions(Parent.child, definitions)
    set_definitions(Parent.children, definitions)
    assert Parent.child.definitions is definitions
    assert Parent.children.items.definitions is definitions
    assert isinstance(Parent.children.items.to, Child)
    assert Parent.children.items.to.foo is Child.foo

# Generated at 2022-06-24 11:08:58.420404
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_definitions = SchemaDefinitions()
    assert isinstance(schema_definitions, SchemaDefinitions)


# Generated at 2022-06-24 11:08:59.345418
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass



# Generated at 2022-06-24 11:09:09.312199
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import String, Integer
    class Person(Schema):
        name = String()
        age = Integer()
    assert Person.fields == {'name':String(), 'age':Integer()}
    p1 = Person.validate({'name':"Tom", 'age':30})
    assert p1.name == "Tom"
    assert p1.age == 30
    assert p1.validate() is None
    assert p1.validate_or_error() == ValidationResult(value=None, error=None)
    assert p1.is_sparse == False
    assert p1 == Person.validate({'name':"Tom", 'age':30})
    assert p1 != Person.validate({'name':"Tom", 'age':29})
    p2 = Person.validate({'name':"Tom"})


# Generated at 2022-06-24 11:09:20.240858
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from unittest import mock

    class TestSchema(Schema):
        a = Array(max_items=1)
        b = Array(max_items=1)
        c = Array(max_items=1)
        d = Array(max_items=1)
        e = Array(max_items=1)
        f = Array(max_items=1)

    with mock.patch.object(TestSchema, "fields", {"test": True}):
        schema = TestSchema()
        schema.a = [1]
        schema.b = [2]
        schema.c = [3]
        schema.d = [4]
        schema.e = [5]
        schema.f = [6]

# Generated at 2022-06-24 11:09:27.769082
# Unit test for constructor of class Reference
def test_Reference():
    definitions = SchemaDefinitions()
    class MySchema(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        a = Reference("SomeSchema")

    assert MySchema.fields["a"].target_string == "SomeSchema"
    assert definitions["MySchema"] == MySchema
    assert hasattr(MySchema.fields["a"], "_target_string")
    assert not hasattr(MySchema.fields["a"], "_target")

if __name__ == "__main__":
    test_Reference()

# Generated at 2022-06-24 11:09:30.689759
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class SomeSchema(Schema):
        a_field = String()
        
    schema = SomeSchema(a_field='Hello World!')
    
    assert schema['a_field'] == 'Hello World!'

# Generated at 2022-06-24 11:09:32.658414
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)

    p = Person(name="John")
    assert p["name"] == "John"


# Generated at 2022-06-24 11:09:38.499689
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String

    class Name(Schema):
        first = String()
        last = String()

    # Test for __init__()
    assert Reference(Name).to == Name
    assert Reference(Name)._target == Name
    assert Reference(Name)._target_string == 'Name'
    assert Reference(Name)._target.__name__ == 'Name'
    assert Reference(Name).definitions is None

# Generated at 2022-06-24 11:09:43.719421
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Arrange
    from unittest.mock import create_autospec
    s = create_autospec(Schema)
    key = "key"
    sd = SchemaDefinitions()
    sd[key] = s
    # Act
    del sd[key]
    # Assert
    assert len(sd) == 0

# Generated at 2022-06-24 11:09:46.455671
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import typesystem
    schema = typesystem.Schema()
    assert isinstance(schema.__iter__(), types.GeneratorType)
    # test that the method returns a generator


# Generated at 2022-06-24 11:09:50.710262
# Unit test for function set_definitions
def test_set_definitions():
    fields = {
        "name": String(),
        "age": Integer(),
        "city": Object(properties = {
            "name": String(),
            "country": Reference('Country'),
            "population": Integer(),
        })
    }
    definitions = SchemaDefinitions({
        "Country": Object(properties = {
            "name": String(),
            "population": Integer(),
        })
    })

    for field in fields.values():
        set_definitions(field, definitions)

    assert fields['city'].properties['country'].target == definitions['Country']

# Generated at 2022-06-24 11:09:57.414819
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Model(metaclass=SchemaMetaclass):
        a = String()
        b = Boolean()
        c = Number()

        class Meta:
            strict = True

    # Test with more items, then without

    obj = Model({
        'a': 1,
        'b': 2,
        'c': 3
    })
    assert len(list(obj.__iter__())) == 3

    obj = Model({
        'a': 1
    })
    assert len(list(obj.__iter__())) == 1
