

# Generated at 2022-06-24 10:59:56.777974
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # arrange
    _SchemaDefinitions = SchemaDefinitions([], [])
    _SchemaDefinitions.__getitem__(key=None)

    # assert
    assert True


# Generated at 2022-06-24 11:00:03.359214
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Setup
    thing = SchemaDefinitions()
    thing['item1'] = 'item1'
    thing['item2'] = 'item2'
    thing['item3'] = 'item3'
    item = 'item2'
    # Exercise
    del thing[item]
    
    # Verify
    assert item not in thing.keys()
    assert len(thing) == 2

    # Cleanup - none necessary


# Generated at 2022-06-24 11:00:04.829379
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert(Reference.validate(1,strict=False)==1)

# Generated at 2022-06-24 11:00:07.714767
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    _empty_definitions = {}
    if (_empty_definitions != {}):
        raise RuntimeError('Assertion failed')


# Generated at 2022-06-24 11:00:09.076565
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    assert len(SchemaDefinitions()) == 0


# Generated at 2022-06-24 11:00:09.980837
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass



# Generated at 2022-06-24 11:00:10.788273
# Unit test for constructor of class Schema
def test_Schema():
    assert repr(Schema()) == 'Schema()'

# Generated at 2022-06-24 11:00:11.582345
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    assert True


# Generated at 2022-06-24 11:00:14.340278
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # """Unit test for method __delitem__."""
    schema_definitions = SchemaDefinitions()
    schema_definitions["name"] = "Eric"
    del schema_definitions["name"]



# Generated at 2022-06-24 11:00:18.150749
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0
    assert len(Schema(None)) == 0
    assert len(Schema({"foo": "bar"})) == 1
    assert len(Schema(foo="bar")) == 1
    assert len(Schema(spam="eggs")) == 1

# Generated at 2022-06-24 11:00:25.939839
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Test(object):
        test_field = "test"
        test_field2 = "test2"
    class TestSchema(Schema):
        test = Reference(to="Test")
        test2 = Reference(to="Test", default=Test())

    test = Test()
    definitions = SchemaDefinitions()
    definitions["Test"] = TestSchema
    test_schema = TestSchema.validate({"test": test})
    serialized_test_schema = test_schema.serialize()
    assert serialized_test_schema == {"test": {"test_field": "test", "test_field2": "test2"}}




# Generated at 2022-06-24 11:00:30.226435
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    instance = SchemaDefinitions()
    try:
        instance.update({"a": "b", "b": "c"})
    except AssertionError:
        pass
    else:
        raise Exception("Did not raise AssertionError on duplicate key")


# Generated at 2022-06-24 11:00:38.259835
# Unit test for function set_definitions
def test_set_definitions():
    schema = Object(
        properties={
            "foo": Array(items=Reference("Bar")),
            "bar": Object(properties={
                "baz": Reference("Baz")
            })
        }
    )
    definitions = SchemaDefinitions()
    set_definitions(schema, definitions)

    assert "Bar" in definitions
    assert "Baz" in definitions

    # Test missing definitions
    with pytest.raises(AssertionError):
        set_definitions(schema, definitions)

# Generated at 2022-06-24 11:00:44.725293
# Unit test for constructor of class Reference
def test_Reference():
    with pytest.raises(AttributeError):
        ref = Reference("Blah")
    ref = Reference("Blah", definitions=SchemaDefinitions())
    assert isinstance(ref, Field)
    ref.to
    assert ref.to == "Blah"
    assert ref.definitions == {}
    with pytest.raises(AssertionError):
        ref = Reference(Schema, definitions=SchemaDefinitions())

# Generated at 2022-06-24 11:00:49.122146
# Unit test for method serialize of class Reference
def test_Reference_serialize(): 
    # Test for lines 143-149
    reference = Reference("test")
    assert reference.serialize(None) == None
    class Test(Schema):
        test = String()
    test = Test(test="test")
    obj = reference.serialize(test)
    assert obj["test"] == "test"


# Generated at 2022-06-24 11:00:57.499727
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    from typesystem import String

    schema_definitions = SchemaDefinitions()
    schema_definitions["String"] = String()

    assert "String" in schema_definitions
    assert len(schema_definitions) == 1
    del schema_definitions["String"]
    assert "String" not in schema_definitions
    assert len(schema_definitions) == 0


# Generated at 2022-06-24 11:01:06.641747
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Integer, String
    class Address(Schema):
        street = String()
        zip = String()
        city = String()
        
    class User(Schema):
        name = String()
        age = Integer()
        address = Reference(Address)
    user = User.validate({'name':'bob','age':'30','address':{'street':'123 Fake St','zip':'39018','city':'Boca Raton'}})
    assert user.name == 'bob'
    assert user.age == 30
    assert user.address.street == '123 Fake St'
    assert user.address.zip == '39018'
    assert user.address.city == 'Boca Raton'

# Generated at 2022-06-24 11:01:08.908936
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to="foobar").serialize(None) is None
    schema_obj = Schema(obj=None)
    assert Reference(to=schema_obj).serialize(None) is None

# Generated at 2022-06-24 11:01:09.932942
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    pass


# Generated at 2022-06-24 11:01:11.202712
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    len(obj)


# Generated at 2022-06-24 11:01:18.453011
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.schema import Schema, SchemaMetaclass

    class Person(metaclass=SchemaMetaclass):
        pass

    class PersonSchema(Schema):
        person = Reference(Person)

    person_schema = PersonSchema()
    assert isinstance(person_schema.person, Reference)
    assert person_schema.person.to is Person
    assert person_schema.person.definitions is None
    assert person_schema.person.errors == {'null': "May not be null."}


# Generated at 2022-06-24 11:01:23.669424
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        alive = Boolean(required=False)

    person = Person(name="Alex", age=30)
    assert tuple(person) == ('name', 'age', 'alive')


# Generated at 2022-06-24 11:01:29.176165
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Nested(Schema):
        foo = Field()
        bar = Field()

    class Data(Schema):
        foo = Field()
        bar = Nested()

    nested = Nested(foo=1, bar=2)
    data = Data(foo=42, bar=nested)
    assert data["foo"] == 42
    assert data["bar"] == {"foo": 1, "bar": 2}

# Generated at 2022-06-24 11:01:33.146046
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions(Animal="a string")
    definitions.__delitem__("Animal")
    assert not definitions.__contains__("Animal")


# Generated at 2022-06-24 11:01:37.249709
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    target = SchemaDefinitions()
    # Set some values to make sure we can delete them later.
    target["foo"] = 42
    target["bar"] = 43
    # Delete one of the set values.
    del target["foo"]
    # Ensure the value was deleted.
    assert "foo" not in target
    # Ensure the other value is still there.
    assert "bar" in target



# Generated at 2022-06-24 11:01:39.152028
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def_schema = SchemaDefinitions()
    def_schema["a"] = "b"
    with pytest.raises(AssertionError):
        def_schema["a"] = "b"
    return



# Generated at 2022-06-24 11:01:46.378491
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        a = Field(String)
        b = Field(Integer)

    s = A()
    assert s.is_sparse == True
    assert s.__eq__(A()) == True
    assert s.__getitem__("a") is None
    assert s.__len__() == 0
    assert s.__repr__() == "A() [sparse]"
    assert s.validate_or_error({"a": "ab", "b": 1}) == ValidationResult(value=A(a="ab", b=1), error=None)
    assert s.validate_or_error({"a": "ab"}) == ValidationResult(value=A(a="ab"), error=None)
    assert s.validate_or_error({"c": "cd"}) == ValidationResult

# Generated at 2022-06-24 11:01:54.784699
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        nickname = Field(type="string")
        given_name = Field(type="string")
        family_name = Field(type="string")

    TestSchema(nickname='john_doe') == TestSchema({'nickname': 'john_doe'})
    TestSchema({'nickname': 'john_doe'}) == TestSchema({'nickname': 'john_doe'})
    TestSchema({'nickname': 'john_doe'}) != TestSchema({'nickname': 'john_doe_alias'})
    TestSchema(nickname='john_doe') != TestSchema({'nickname': 'john_doe_alias'})

# Generated at 2022-06-24 11:02:06.116771
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Create a Schema object
    schema = Schema(
        a=1,
        b="abc",
        c=Schema(c1=1, c2="abc"),
        d=[1,2,3],
        e=[Schema(e1=1, e2="abc"), Schema(e1=2, e2="cde")],
        f=Reference(to="Schema", definitions={
            "Schema": Schema(f1=1, f2="abc")
        }),
        g=Reference(to="Schema", definitions={
            "Schema": Schema(g1=1, g2="abc")
        }),
    )
    # Test
    assert Schema.__getitem__(schema, "a") == 1

# Generated at 2022-06-24 11:02:07.449320
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    d = SchemaDefinitions()
    d['test'] = 'test'

    assert d['test'] == 'test'

# Generated at 2022-06-24 11:02:09.058968
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definition = SchemaDefinitions()
    schema_definition.__len__()
    return 



# Generated at 2022-06-24 11:02:11.769421
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def_ = SchemaDefinitions()
    def_['A'] = 'a'
    assert def_['A'] == 'a'

# Generated at 2022-06-24 11:02:12.991421
# Unit test for constructor of class Reference
def test_Reference():
    assert getattr(Reference, "to") is not None

# Generated at 2022-06-24 11:02:16.070912
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert type(schema_definitions.__len__()) is int
    assert schema_definitions.__len__() == 0



# Generated at 2022-06-24 11:02:19.732823
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Test(Schema):
        x = Field(type="string")
        y = Field(type="string")
        z = Field(type="string")
    keys = [key for key in Test(x="5", y="5")]
    assert keys == ['x', 'y']

# Generated at 2022-06-24 11:02:24.144165
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    assert list(definitions) == []

    definitions["Foo"] = "foo"
    definitions["Bar"] = "bar"
    assert list(definitions) == ["Foo", "Bar"]


# Generated at 2022-06-24 11:02:29.300671
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        first_name = String()
        last_name = String()
    a = Person(first_name="James", last_name="Bond")
    assert isinstance(a, Person)
    assert isinstance(a, Schema)
    assert a["first_name"] == "James"
    assert a["last_name"] == "Bond"


# Generated at 2022-06-24 11:02:30.768570
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    pass



# Generated at 2022-06-24 11:02:40.910138
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        """Schema definition for type `TestSchema`."""

        a = Field(description="Description for field `a`.")
        b = Field(description="Description for field `b`.")
        c = Field(description="Description for field `c`.", default=False)

    schema_instance = TestSchema(a=1, b=2, c=False)
    print(schema_instance)

    def make_validator(schema):
        from typesystem.fields import String

        return String(min_length=5)

    class TestSchema(Schema):
        """Schema definition for type `TestSchema`."""

        a = Field(description="Description for field `a`.")
        b = Field(description="Description for field `b`.")

# Generated at 2022-06-24 11:02:49.923256
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.types import String
    from typesystem.types import Boolean
    from typesystem.types import Integer
    from typesystem.types import Float
    from typesystem.types import Date
    from typesystem.types import DateTime
    from typesystem.types import Time
    from typesystem.types import UUID
    from typesystem.types import Email
    from typesystem.types import URL
    from typesystem.types import Number
    from typesystem.schemas import Reference
    from typesystem.schemas import SchemaDict
    import datetime
    import uuid

    class Schema(Reference):
        pass
        
    assert isinstance(Schema(), Reference)
    print('Test passed!')


# Generated at 2022-06-24 11:02:53.733620
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    testInstance = SchemaDefinitions()
    assert testInstance is not None
    assert testInstance._definitions is not None
    assert testInstance._definitions == {}
    testInstance._definitions['test1'] = 'test2'
    assert testInstance._definitions['test1'] == 'test2'
    del testInstance['test1']
    assert testInstance._definitions['test1'] == 'test2'

# Generated at 2022-06-24 11:02:59.987553
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        a = Array(items=String(), min_items=2, max_items=3)
    class Test(Schema):
        a = String()
        schema = Reference(TestSchema)
        array = Reference(TestSchema)
    assert Test.validate({"a": "a","schema": {"a":["a", "b"]}, "array": {"a":["a", "b"]}}) != None
    assert Test.validate({"a": "a","schema": {"a":["a"]}, "array": {"a":["a"]}}) == None

# Generated at 2022-06-24 11:03:07.842734
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
  from typesystem.base import String, Object, Array, Integer, Any
  from typesystem.fields import Field

  class schemaClass(Schema):
      id = String()

      class Meta:
          strict = True

  class_meta_data = schemaClass.Meta

  assert class_meta_data.strict
  assert len(schemaClass.fields) == 1

  class schemaClass(Schema):
      id = String()
      class Meta:
          strict = True
      class Meta:
          strict = True
      class Meta:
          strict = True

  assert len(schemaClass.fields) == 1
  assert schemaClass.fields.get("id")

  class schemaClass(Schema):
      id = String()
      class Meta:
          strict = True
      class Meta:
          strict = True
      class Meta:
          strict

# Generated at 2022-06-24 11:03:10.538711
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    obj = SchemaDefinitions()
    obj["a"] = 1
    assert len(obj) == 1
    obj["b"] = 2
    assert len(obj) == 2
    del obj["a"]
    assert len(obj) == 1
    del obj["b"]
    assert len(obj) == 0



# Generated at 2022-06-24 11:03:13.272767
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    sd["test"] = 5
    sd["test"] = 5
    sd["test2"] = 6
    sd["test2"] = 6
    assert len(sd._definitions) == 2



# Generated at 2022-06-24 11:03:14.783506
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    test_dict = {"test1": 1}
    s = SchemaDefinitions(test_dict)
    s.__delitem__("test1")
    assert not isinstance(s, dict)


# Generated at 2022-06-24 11:03:16.551570
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.examples import Dog
    definition = Dog(name="Spot", age=2)
    r = Reference('Dog', definition)
    assert(r.to == 'Dog')
    assert(r.definitions == definition)

# Generated at 2022-06-24 11:03:20.985697
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    print('Test __getitem__')
    schema_definitions1 = SchemaDefinitions()
    schema_definitions1['a'] = 1
    assert schema_definitions1['a'] == 1
    print('Success')


# Generated at 2022-06-24 11:03:22.876682
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()

    assert Person.fields["name"] == String()

# Generated at 2022-06-24 11:03:25.926157
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()

    class Worker(Person):
        occupation = String()

    assert Worker.fields.keys() == ('name', 'age', 'address', 'occupation')



# Generated at 2022-06-24 11:03:30.156816
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference("Person").serialize(None) == None
    assert Reference("Person").serialize({"name":"David","age":23}) == {"name":"David","age":23}


# Generated at 2022-06-24 11:03:37.968691
# Unit test for constructor of class Schema
def test_Schema():
    # Test constructor of class Schema with arguments
    import typesystem
    class TestField(Field):
        pass

    class TestSchema(Schema):
        pass
    assert TestSchema.fields == {}
    s = TestSchema()
    assert TestSchema.fields == {}

    class TestSchema(Schema):
        field1 = TestField()
        field2 = TestField()
    assert TestSchema.fields == {
        'field1': TestField(),
        'field2': TestField()
    }
    s = TestSchema()
    assert TestSchema.fields == {
        'field1': TestField(),
        'field2': TestField()
    }
    class TestSchema(Schema):
        field1 = TestField()
        field2 = TestField()

# Generated at 2022-06-24 11:03:42.983565
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    definitions["test"] = "hello"
    assert definitions["test"] == "hello"
    assert definitions.__len__() == 1
    assert definitions.__iter__() == iter(["test"])
    assert len(definitions) == 1


# Generated at 2022-06-24 11:03:48.784730
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        id = Integer()

    class TestSchema2(Schema):
        test = Reference('TestSchema')
        id = Integer()

    test = TestSchema2.validate({'test': {'id': 1}})
    assert isinstance(test.test, TestSchema)
    assert test.test.id == 1



# Generated at 2022-06-24 11:03:52.167912
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    def test_1():
        assert Reference("to").serialize("object") == "object"

    test_1()



# Generated at 2022-06-24 11:03:54.120442
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    obj = SchemaDefinitions()
    ret = obj.__iter__()
    assert True



# Generated at 2022-06-24 11:04:02.255095
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class CDU(Schema):
        name = String()
        genres = Array(String())

    class Album(Schema):
        artirst = Reference(CDU)
        title = String()

    album1 = Album.validate(
        {
            "artist": {"name": "CDU", "genres": ["pop", "rock"]},
            "title": "CDU album",
        }
    )
    album2 = Album.validate(
        {
            "artist": {"name": "CDU", "genres": ["pop", "rock"]},
            "title": "CDU album",
        }
    )
    assert album1 == album2


# Generated at 2022-06-24 11:04:10.167286
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # make sure that deletion of a key-value pair in the dictionary works
    # make sure that the key is in the dictionary
    assert 'key' in dict
    # make sure that there is a key-value pair to delete
    assert dict['key'] == "value"


# Generated at 2022-06-24 11:04:20.693748
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.base import String, Number

    assert type(SchemaMetaclass) is SchemaMetaclass  # type: ignore
    assert issubclass(SchemaMetaclass, ABCMeta)

    class Person(Schema):
        name = String(max_length=100)
        age = Number(minimum=0, maximum=150)

    assert issubclass(Person, Schema)
    assert type(Person.fields) is dict
    assert len(Person.fields.keys()) == 2
    assert Person.fields["name"] is Person.name
    assert Person.fields["age"] is Person.age

    assert type(Person.name) is String
    assert len(Person.name.errors.keys()) == 3
    assert Person.name.errors["max_length"] == "Must have no more than 100 characters."
    assert Person.name

# Generated at 2022-06-24 11:04:26.871353
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    sd = SchemaDefinitions({'a': 1, 'b': 2})
    assert sd['a'] == 1
    assert sd['b'] == 2
    try:
        sd['c']
        assert False
    except KeyError as e:
        assert str(e) == "'c'"
    assert len(sd) == 2
    assert 'a' in sd
    assert 'c' not in sd
    assert not 'abc'.__hash__


# Generated at 2022-06-24 11:04:33.526106
# Unit test for function set_definitions
def test_set_definitions():
    class MySuperSchema(Schema):
        foo = Reference("Foo")

    class MySchema(MySuperSchema):
        bar = Reference("Bar")

    definitions = SchemaDefinitions(
        Foo=Object(properties={"a": Field(str), "b": Field(str)})
    )
    set_definitions(MySchema.fields["foo"], definitions)
    assert MySchema.fields["foo"].definitions is definitions
    set_definitions(MySchema.fields["bar"], definitions)
    assert MySchema.fields["bar"].definitions is definitions

# Generated at 2022-06-24 11:04:39.140191
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    class MySchemaDefinitions(SchemaDefinitions):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self["foo"] = "bar"

    obj = MySchemaDefinitions()
    result = obj["foo"]
    assert result == "bar"


# Generated at 2022-06-24 11:04:42.944616
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # For id:str and name:str
    class Actor(Schema):
        id = str
        name = str
    
    actor = Actor(id="U5678", name="Daniel")
    assert repr(actor) == "Actor(id='U5678', name='Daniel')"


# Generated at 2022-06-24 11:04:52.797831
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # Create a mock type
    class SchemaMetaclass_test(SchemaMetaclass):
        def __new__(
            cls: type,
            name: str,
            bases: typing.Sequence[type],
            attrs: dict,
            definitions: SchemaDefinitions = None,
        ) -> type:
            return cls.__new__(  # type: ignore
                cls, name, bases, attrs
            )
    # Create a mock class
    class MockClass(object):
        __metaclass__ = SchemaMetaclass_test

    # assert that metaclass is set up as MockClass.__metaclass__:
    assert MockClass.__class__ is SchemaMetaclass_test

    pass
test_SchemaMetaclass()

# Generated at 2022-06-24 11:05:01.781484
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String
    from typesystem.meta.schema import SchemaMetaclass
    from typesystem.meta.schema import SchemaDefinitions

    class Meta(SchemaMetaclass): pass

    class Base(metaclass=Meta):
        hello = String()
        world = String()

    class Derived(Base):
        hello = Base.hello.clone()
        world = Base.world.clone()

    assert Derived.fields == {
        'hello': Base.hello,
        'world': Base.world
    }

    definitions = SchemaDefinitions()

    class Derived2(Base, metaclass=Meta, definitions=definitions):
        hello = Base.hello.clone(required=False)
        world = Base.world.clone(required=False)


# Generated at 2022-06-24 11:05:11.599723
# Unit test for constructor of class Reference
def test_Reference():
    class UserSchema(Schema):
        id = Field(type=int)
        name = Field(type=str, required=True)
        email = Field(type=str, required=True)
        password = Field(type=str, required=False)
        # Note: This is a string reference.
        tags = Array(items=Reference("Tag"), required=False)

    class Tag(Schema):
        name = Field(type=str)

    definitions = SchemaDefinitions()
    definitions["User"] = UserSchema
    definitions["Tag"] = Tag

    user = UserSchema(
        id=1, name="John Smith", email="john@example.com", password="foobar"
    )

    assert user == UserSchema(id=1, name="John Smith", email="john@example.com")

# Generated at 2022-06-24 11:05:14.550778
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    t0 = SchemaDefinitions()
    t0["test"] = 1
    assert t0["test"]==1
    try:
        t0["test"] = 2
    except Exception as e:
        assert str(e) == "Definition for 'test' has already been set."

# Generated at 2022-06-24 11:05:24.950519
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import sys
    import os
    import pytest
    import json
    path = os.getcwd() + '/typesystem-master'
    sys.path.append(path)
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String, Integer, Boolean
    from typesystem.schemas import Schema
    from typesystem.schemas import SchemaMetaclass, set_definitions


    class Author(Schema):
        id = Integer()
        name = String()
        is_author = Boolean()

    class Book(Schema):
        name = String()
        author = Reference(Author)  # Reference to another schema

    book = Book.validate({"name": "test", "author": {"id": 10, "name": "test"}})
    # "name": "test" 不

# Generated at 2022-06-24 11:05:31.316682
# Unit test for constructor of class Reference
def test_Reference():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference(Bar)

    class Bar(Schema):
        spam = Field()

    foo = Foo(bar=Bar(spam="abc"))
    assert foo.bar.spam == "abc"

    foo2 = Foo(baz=Bar(spam="abc"))
    assert foo2.baz.spam == "abc"
    return

if __name__ == '__main__':
    test_Reference()

# Generated at 2022-06-24 11:05:33.268802
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    _expected_result = 2
    _result = Schema({'name': 'John'})
    assert _result == _expected_result

# Generated at 2022-06-24 11:05:34.053129
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass


# Generated at 2022-06-24 11:05:39.872252
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
  def_dict = {}
  def_dict['test'] = 'test'
  def_dict['test2'] = {'test':'test'}
  def_dict['test3'] = 1

  # Testing __getitem__
  assert def_dict['test'] == 'test'
  assert def_dict['test2'] == {'test':'test'}
  assert def_dict['test3'] == 1

  # Testing __len__
  assert len(def_dict) == 3

  # Testing __iter__
  for key in def_dict:
    assert key in def_dict

  # Testing __delitem__
  del def_dict['test']
  assert 'test' not in def_dict

  # Testing __setitem__
  def_dict['test4'] = 2

# Generated at 2022-06-24 11:05:42.142996
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    obj = SchemaDefinitions()
    assert not obj._definitions

    class Foo:
        pass

    obj.__setitem__("bar", Foo)
    assert obj._definitions == {"bar": Foo}



# Generated at 2022-06-24 11:05:50.958704
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    keys = ['key_1','key_2','key_3','key_4','key_5','key_6','key_7']
    keys_actual = []
    class Schema_A(Schema):
        key_1 = Field()
        key_2 = Field()
        key_3 = Field()
        key_4 = Field()
        key_5 = Field()
        key_6 = Field()
        key_7 = Field()
    obj_1 = Schema_A(key_1 = 1,key_2 = 1,key_3 = 1,key_4 = 1)
    for item in obj_1:
        keys_actual.append(item)
    assert keys == keys_actual


# Generated at 2022-06-24 11:05:55.898301
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference('test', nullable=True)
    assert r.allow_null == True
    r2 = Reference('test2', nullable=False)
    assert r2.allow_null == False
    assert r.to == 'test'
    assert r2.to == 'test2'

# Generated at 2022-06-24 11:06:01.049666
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.types import String
    class TestSchema(Schema):
        first_name = String()
        last_name = String()
    obj = TestSchema(first_name="Jonas", last_name="Hakansson")
    assert list(obj) == ['first_name', 'last_name']


# Generated at 2022-06-24 11:06:07.352232
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer, String
    from .test_helpers import assert_equal
    from .test_helpers import assert_raises

    class Person(Schema):
        id = Integer(format="int64", minimum=0)
        name = String(max_length=50, pattern=r"^[A-Z][a-z]+$")
        age = Integer(minimum=0)

    person = Person(id=1, name="Foo")

    assert_equal(len(person), 2)

    person = Person(id=1, name="Foo", age=10)

    assert_equal(len(person), 3)



# Generated at 2022-06-24 11:06:17.921612
# Unit test for constructor of class Schema
def test_Schema():
    # class with one field, "value", and no validator
    class Simple(Schema):
        value = Field()

    # class with no validator and default
    class WithDefault(Schema):
        name = Field(default="Test")

    # class with no validator and default from function
    def fx(x):
        return x + x

    class WithDefaultFromFunc(Schema):
        name = Field(default=fx, validators=[fx])

    # class with validator
    def f(x):
        return x + x

    class Complex(Schema):
        n = Field(validators=[f])

    # test Simple
    s = Simple(value=1)
    assert s.value == 1

    # test WithDefault
    s = WithDefault()
    assert s.name == "Test"

# Generated at 2022-06-24 11:06:23.765273
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    nested = Reference('Nested')
    set_definitions(nested, definitions)
    assert definitions['Nested'] == Reference

# Generated at 2022-06-24 11:06:32.875623
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    if __name__ == '__main__':
        print('test_SchemaDefinitions___getitem__')

    # Simple test
    sd1 = SchemaDefinitions({'a': 1})
    assert sd1['a'] == 1

    # Test with chain of inheritance
    sd2 = SchemaDefinitions({'a': 2})
    sd3 = SchemaDefinitions({'a': 3}, sd2)
    assert sd3['a'] == 3

    # Test with dictionary addition
    sd4 = SchemaDefinitions({'a': 4})
    sd4.update({'b': 5})
    assert sd4['b'] == 5


# Generated at 2022-06-24 11:06:44.766422
# Unit test for method validate of class Reference
def test_Reference_validate():
    class ItemSchema(Schema):
        serial = Field(str)
        location = Field(str)

    class InventorySchema(Schema):
        items = Array(
            items=Reference(to=ItemSchema),
            title="Inventory Items",
            description="All items in the inventory.",
        )

    reference_field = InventorySchema.fields['items'].items

    assert reference_field.validate({
        'serial': '123',
        'location': 'Slack'
    })
    assert reference_field.validate([{
        'serial': '123',
        'location': 'Slack'
    }])

    assert (
        reference_field.validate_or_error(None).error.messages()[0].text
        == 'May not be null.'
    )


# Generated at 2022-06-24 11:06:53.888807
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    """
    생성자 테스트
    """
    class TestSchemaMetaclass(metaclass=SchemaMetaclass):
        """
        SchemaMetaclass 상속 테스트
        """
        fields = {
            "test_field1": Field(int),
            "test_field2": Field(str),
        }

    TestSchemaMetaclass()  # 생성자 호출

# -----------------
# 문제 : Unit test for validate_or_error method of class Schema
#     class TestSchema(Schema):
#         """
#         Schema 상속 테스트
#

# Generated at 2022-06-24 11:07:04.754876
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typing import Dict
    from typesystem import Integer
    from typesystem_schema import Schema

    class Pet(Schema):
        id = Integer()
        name = Integer()
    
    class Owner(Schema):
        id = Integer()
        name = Integer()
        pets = Reference(to=Pet)

    # Case 1: One Pet
    owner = Owner(id=1, name='benjamin', pets=[Pet(id=2, name='dog')])
    result = Reference.serialize(owner.pets, owner.pets)
    solution = {'id': 2, 'name': 'dog'}
    assert isinstance(result, Dict)
    assert result == solution

    # Case 2: Multiple Pets

# Generated at 2022-06-24 11:07:11.444866
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Book(Schema):
        title = Field(str)
        author = Field(str)
    obj = Book(title="Final Fantasy XII", author="Motomu Toriyama")
    res = obj["title"]
    assert isinstance(res, str)

# Generated at 2022-06-24 11:07:14.185311
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Test if the number of elements in a SchemaDefinitions instance after initialization is 0
    definitions = SchemaDefinitions()
    assert len(definitions) == 0



# Generated at 2022-06-24 11:07:22.283424
# Unit test for constructor of class Schema
def test_Schema():
    assert getattr(Schema, "fields") == {}
    assert isinstance(Schema(), Mapping)
    assert isinstance(Schema(), MutableMapping)
    assert isinstance(Schema(), Schema)
    assert Schema().fields == {}

    class TestSchema(Schema):
        def __init__(self, a, b=2, c=3, d=4) -> None:
            assert a == 1
            assert b == 2
            assert c == 3
            assert d == 4

    TestSchema(1)
    TestSchema(1, 2)
    TestSchema(1, 2, 3)
    TestSchema(1, 2, 3, 4)


# Generated at 2022-06-24 11:07:28.753136
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def test_body():
        a = SchemaDefinitions()
        b = SchemaDefinitions()
        c = SchemaDefinitions()
        ass_lst = [a, b, c]

        # verify __init__, len, __eq__
        assert len(ass_lst) == len(set(ass_lst))
        # verify __getitem__
        assert "key" in a
        assert "key" not in b
        assert "key" not in c
        assert "key" not in a._definitions
        # verify __setitem__, __delitem__
        a["key"] = "value"
        b._definitions.clear()
        assert "key" in a
        assert "key" not in b
        assert "key" not in c
        assert "key" in a._definitions
        b._

# Generated at 2022-06-24 11:07:34.003585
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        first_name = Field(str)
        last_name = Field(str)
    
    class Singer(Schema):
        name = Reference(Person)
        style = Field(str)

    singer1 = Singer(name=Person(first_name="Tina",last_name="Turner"), style="rock")
    assert singer1.name.serialize(singer1.name) == {"first_name": "Tina", "last_name": "Turner"}


test_Reference_serialize()

# Generated at 2022-06-24 11:07:36.028814
# Unit test for constructor of class Schema
def test_Schema():
    test = Schema(name=3)
    print(test)



# Generated at 2022-06-24 11:07:45.096152
# Unit test for function set_definitions
def test_set_definitions():
    field = Reference('Foo')
    definitions = SchemaDefinitions()
    
    assert field.definitions == None
    
    set_definitions(field, definitions)
    
    assert field.definitions == definitions
    
    # Test handling of an uninitialized array field
    field = Array(items=Reference('Foo'))
    assert field.items.definitions == None
    
    set_definitions(field, definitions)
    
    assert field.items.definitions == definitions

    # Test handling of an initialized array field
    field = Array(items=[Reference('Foo'), Reference('Bar')])
    assert field.items[0].definitions == None
    assert field.items[1].definitions == None
    
    set_definitions(field, definitions)
    
    assert field.items[0].definitions == definitions


# Generated at 2022-06-24 11:07:51.576447
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    import typing
    from typesystem.base import String

    class Base(Schema):
        name = String()
        description = String(allow_null=True)
    
    class Error(Schema):
        name = String(min_length=1, max_length=10)
        errors = {'name': {'min_length': 'Must be at least one character.',
                           'max_length': 'Must be at most 10 characters.'}}

# Generated at 2022-06-24 11:07:54.462482
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    a = SchemaDefinitions()
    b = SchemaDefinitions()
    c = SchemaDefinitions()
    a[b] = c
    assert a[b] == c


# Generated at 2022-06-24 11:07:59.261235
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        a = Field()
        b = Field()

    obj = A(a=1, b=2)
    assert(obj['a'] == 1)
    assert(obj['b'] == 2)


# Generated at 2022-06-24 11:08:07.777932
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(required=True)
        age = Integer(default=0)

    # Test initializing a schema object with values as kwargs, and us in object style
    person_kwargs = Person(name="Raymond")
    assert person_kwargs.name == "Raymond"
    assert person_kwargs.age == 0

    person_kwargs = Person(name="Raymond", age=25)
    assert person_kwargs.name == "Raymond"
    assert person_kwargs.age == 25

    with pytest.raises(TypeError, match="age is an invalid keyword argument for Person()."):
        Person(name="Raymond", age="25")

    person_obj = Person({"name": "Raymond"})
    assert person_obj.name == "Raymond"
   

# Generated at 2022-06-24 11:08:12.614628
# Unit test for function set_definitions
def test_set_definitions():
    # Arrange
    class Test1(Object, properties={
        'test': Integer
    }):
        pass
    class Test2(Object, properties={
        'test': Test1
    }):
        pass
    class Test3(Object, properties={
        'test': Test2
    }):
        pass

    # Act
    set_definitions(Test3, SchemaDefinitions(Test1=Test1, Test2=Test2, Test3=Test3))

    # Assert
    assert Test3._properties["test"]._properties["test"]._properties["test"]._definitions == SchemaDefinitions(Test1=Test1, Test2=Test2, Test3=Test3)



# Generated at 2022-06-24 11:08:18.130286
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from collections import OrderedDict
    from typesystem import String, Number
    class Person(Schema):
        name = String(required=True)
        age = Number(required=True)
    person = Person.validate(OrderedDict([('name', 'foo'), ('age', 20)]))

    assert list(person) == ['name', 'age']


# Generated at 2022-06-24 11:08:23.499835
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import String
    from typesystem import ValidationError
    class Person(Schema):
        name = String()
    p1 = Person(name='Jack')
    p2 = Person(name='Jack')
    assert p1 == p2
    p2 = Person(name='John')
    assert p1 != p2
    class Faker(Schema):
        a = String()
    with pytest.raises(TypeError):
        f1 = Faker(a='Jack')
        f2 = Faker(a='Jack')
        assert f1 == f2


# Generated at 2022-06-24 11:08:32.253679
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class A(Schema):
        foo = Field()
        bar = Field()

    a = A()
    assert repr(A) == 'A'
    assert repr(a) == 'A(foo=None, bar=None)'

    a = A(foo=1, bar=2)
    assert repr(a) == 'A(foo=1, bar=2)'

    a = A(foo=1)
    assert repr(a) == 'A(foo=1) [sparse]'

    a = A(bar=3)
    assert repr(a) == 'A(bar=3) [sparse]'

    a = A(1)
    assert repr(a) == 'A(foo=1, bar=None)'

    a = A({"foo": 1, "bar": 2})

# Generated at 2022-06-24 11:08:37.547337
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field()
        b = Field()

    foo = Foo({"a": 1, "b": 2})
    foo2 = Foo({"a": 1})
    foo3 = Foo({"b": 2})

    assert foo == foo
    assert foo == Foo({"a": 1, "b": 2})
    assert foo != foo2
    assert foo != foo3
    assert foo != {"a": 1, "b": 2}

# Generated at 2022-06-24 11:08:43.670236
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem.base import String
    assert issubclass(SchemaMetaclass, ABCMeta)

    class Foo(metaclass=SchemaMetaclass):
        a = String()
        b = String()
        c = String()

    assert Foo.fields == {'a': String(), 'b': String(), 'c': String()}



# Generated at 2022-06-24 11:08:52.980527
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():

    # Test with a single element added
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'
    assert len(definitions) == 1
    assert definitions['key'] == 'value'

    # Test with two elements added
    definitions = SchemaDefinitions()
    definitions['key1'] = 'value1'
    definitions['key2'] = 'value2'
    assert len(definitions) == 2
    assert definitions['key1'] == 'value1'
    assert definitions['key2'] == 'value2'

    # Test with three elements added
    definitions = SchemaDefinitions()
    definitions['key1'] = 'value1'
    definitions['key2'] = 'value2'
    definitions['key3'] = 'value3'
    assert len(definitions) == 3

# Generated at 2022-06-24 11:08:53.893879
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    pass

# Generated at 2022-06-24 11:08:57.897858
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definition = SchemaDefinitions()
    definition[2] = 123
    # print(definition)
    assert 123 == definition[2]
    try:
        definition[1]
    except KeyError:
        assert True
        return
    assert False


# Generated at 2022-06-24 11:09:05.090812
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class A(Schema):
        a = Integer()
        b = Float()

    a = A(a=4, b=2)
    assert repr(a) == "A(a=4, b=2)"

    a = A(a=4)
    assert repr(a) == "A(a=4) [sparse]"

    a = A(a=1, b=2)
    assert repr(a) == "A(a=1, b=2)"
    assert repr(a) == "A(a=1, b=2)"



# Generated at 2022-06-24 11:09:07.780304
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["test"] = 1
    assert schema_definitions == {"test": 1}



# Generated at 2022-06-24 11:09:11.652808
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    field = Field(label="Property 1")
    class TestSchema1(Schema):
        field = field
    # Check the name of the Schema class has been set correctly
    assert TestSchema1.__name__ == "TestSchema1"
    # Check fields have been set correctly
    assert TestSchema1.fields['field'] == field


# Generated at 2022-06-24 11:09:12.776915
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert sd._definitions == {}


# Generated at 2022-06-24 11:09:14.783416
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    d = SchemaDefinitions()
    d["key"] = "value"
    assert d["key"] == "value"


# Generated at 2022-06-24 11:09:20.532715
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Initialize the class (Go through the __init__ method)
    obj = SchemaDefinitions()

    # Call the method with a defined argument
    obj['test'] = 1
    assert obj['test'] == 1
    obj.__delitem__('test')
    with pytest.raises(KeyError):
        obj['test']


# Generated at 2022-06-24 11:09:25.440432
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type="string", nullable=False)
        age = Field(type="integer", minimum=0)

    p = Person(name="Alice", age=30)
    print(p)
    p = Person(name="Bob")
    print(p)
    p = Person()
    print(p)


# Generated at 2022-06-24 11:09:27.073361
# Unit test for constructor of class Schema
def test_Schema():
    a = Schema()
    if (a.fields != {}):
        print("a.fields is wrong")
    a.__init__(a)
    a.__init__()



# Generated at 2022-06-24 11:09:31.443152
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ComplexObject(Schema):
        a = Field()
        b = Field(pretty_name="bee")

    assert ComplexObject(a=1, b=2) == ComplexObject(a=1, b=2)
    assert ComplexObject(a=1, b=2) == {"a": 1, "bee": 2}



# Generated at 2022-06-24 11:09:34.252611
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class SimpleSchema(Schema):
        field1 = True
        field2 = False
        field3 = True

    simple_schema = SimpleSchema(field1="test_field1", field2="test_field2")
    assert len(simple_schema) == 2

# Generated at 2022-06-24 11:09:38.624252
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Book(Schema):
        id = Integer()
        title = String()

    b = Book(id=1234, title="Python")
    assert repr(b) == "Book(id=1234, title='Python')"


# Generated at 2022-06-24 11:09:48.348332
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        no = Field(type="integer")
    class B(Schema):
        no = Field(type="integer")
    class C(Schema):
        no = Field(type="integer")
        name = Field(type="string")
    a1 = A(no=1)
    a2 = A(no=1)
    b1 = B(no=1)
    c1 = C(no=1)
    c2 = C(no=1, name="John")
    c3 = C(no=1, name="John")
    assert a1 == a1
    assert a1 == a2
    assert a1 == b1
    assert a1 != c1
    assert c1 != c2
    assert c2 == c3


# Generated at 2022-06-24 11:09:55.773388
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")
    testSchema = TestSchema(field1="value1")
    assert str(testSchema) == "TestSchema(field1='value1')"
    assert str(TestSchema()) == "TestSchema() [sparse]"
    assert str(TestSchema(field1="a",field2="b")) == "TestSchema(field1='a', field2='b')"
