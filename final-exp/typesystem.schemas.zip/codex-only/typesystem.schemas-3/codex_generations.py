

# Generated at 2022-06-24 10:59:59.037113
# Unit test for method validate of class Reference
def test_Reference_validate():
    class UserSchema(Schema):
        user_id = Field(type=int)
    UserSchema_object = UserSchema(**{"user_id": 1})
    value = UserSchema_object
    strict = False
    result = UserSchema_object.validate(value, strict=strict)
    assert result == UserSchema_object
    assert result.user_id == UserSchema_object.user_id
    assert result.user_id == 1
    assert isinstance(result, UserSchema)

# Generated at 2022-06-24 11:00:04.577091
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Check when there is an item with the given key
    s = SchemaDefinitions({'a': 1})
    assert s['a'] == 1

    # Check when there is no item with the given key
    s = SchemaDefinitions({})
    try:
        s['a']
    except:
        pass


# Generated at 2022-06-24 11:00:08.482983
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    s = TestSchema({"a": 1, "b": 2})
    assert len(s) == 2
    s = TestSchema({"a": 1})
    assert len(s) == 1


# Generated at 2022-06-24 11:00:12.824065
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    try:
        schema_definitions = SchemaDefinitions(["a", "b"])
    except:
        assert False
    try:
        schema_definitions = SchemaDefinitions(String(name="hello"))
    except:
        assert False
    try:
        schema_definitions = SchemaDefinitions(name="hello")
    except:
        assert False

# Generated at 2022-06-24 11:00:21.576027
# Unit test for method validate of class Reference
def test_Reference_validate():
    # test 1
    print("\ntest 1")
    class A(Schema):
        m = Reference(to='B')

    class B(Schema):
        n = Field()

    a = A(m={'n': 10})
    print(a)
    # test 2
    print("test 2")
    class C(Schema):
        n = Field(optional=True)

    class D(Schema):
        m = Reference(to='C')

    d = D(m={'n': 10})
    print(d)
    try:
        d = D(m={'n': None})
        print(d)
    except ValidationError:
        print(" Wrong: validate successfully when n is null, but it is not allowed")
    # test 3
    print("test 3")

# Generated at 2022-06-24 11:00:26.505158
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Subclass(Schema):
        field = Field()

    class X(Schema):
        field = Field()
        reference = Reference(to="Subclass")

    definitions = SchemaDefinitions()
    X.__new__(
        SchemaMetaclass, "X", (Schema,), {}, definitions=definitions
    )  # type: ignore
    assert definitions["Subclass"] == Subclass



# Generated at 2022-06-24 11:00:32.542472
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = Field()
        age = Field(
            type="integer",
        )

    class Book(Schema):
        title = Field()
        author = Reference(Person)
    book = Book({'title': '1984', 'author': {'name': 'George Orwell', 'age': 46}})
    assert book['author'] == {'name': 'George Orwell', 'age': 46}

# Generated at 2022-06-24 11:00:35.597577
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions({"A": "person"})
    del definitions["A"]
    assert not definitions._definitions


# Generated at 2022-06-24 11:00:37.428823
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_definitions = SchemaDefinitions()
    assert schema_definitions == {}

# Generated at 2022-06-24 11:00:41.232891
# Unit test for function set_definitions
def test_set_definitions():
    class Address(Schema):
        street = String()

    class Customer(Schema):
        id = String()
        addresses = Array(Reference(Address))

    definitions = SchemaDefinitions()

    set_definitions(Customer.fields['addresses'], definitions)
    assert Customer.fields['addresses'].items[0].definitions == definitions



# Generated at 2022-06-24 11:00:44.969258
# Unit test for method validate of class Reference
def test_Reference_validate():
    definitions = SchemaDefinitions({"Person": Person})
    employee = Employee(id=100, first_name="Thomas", last_name="Ochman", role="CTO")
    assert employee.validate(employee, strict=True) == employee



# Generated at 2022-06-24 11:00:53.268748
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class User(Schema):
        pass

    assert isinstance(User.fields, dict)

    user = User()
    assert not user.fields

    class User(Schema):
        id = String()
        first_name = String()
        last_name = String()

    assert isinstance(User.fields, dict)
    assert User.fields["id"].coerce_value("123") == "123"
    assert User.fields["first_name"].coerce_value("John") == "John"
    assert User.fields["last_name"].coerce_value("Doe") == "Doe"

    user1 = User(id="123", first_name="John", last_name="Doe")
    assert isinstance(user1, User)
    assert user1.id == "123"
    assert user

# Generated at 2022-06-24 11:00:59.214338
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class TestSchema(Schema):
        foo = Reference("BarSchema")

    class BarSchema(Schema):
        bar = Reference("AnotherSchema")

    class AnotherSchema(Schema):
        pass

    set_definitions(TestSchema.foo, definitions)
    assert TestSchema.foo.definitions == definitions
    assert BarSchema.bar.definitions == definitions

# Generated at 2022-06-24 11:01:01.814017
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Book(Schema):
        title: str
        author: str

    book = Book(title="PyTest", author="Me")
    assert book["title"] == "PyTest"
    assert book["author"] == "Me"

# Generated at 2022-06-24 11:01:07.672784
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from .test_fields import Car
    car = Car(
        "Ford",
        "Focus",
        1999,
    )
    assert repr(car) == "Car(brand='Ford', model='Focus', year=1999)"
    car2 = Car(
        "Ford",
        "Focus",
    )
    assert repr(car2) == "Car(brand='Ford', model='Focus') [sparse]"

# Generated at 2022-06-24 11:01:11.665811
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Prime(Schema):
        num = Field(int, nullable=True)
        is_prime = Field(bool, nullable=True)
    p = Prime(num=5, is_prime=True)
    assert len(p) == 2
    for key, value in p.items():
        assert key in ["num", "is_prime"]
        assert value in [5, True]
test_Schema___getitem__()


# Generated at 2022-06-24 11:01:13.849943
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        test_field = String(description="Test field.")

    assert TestSchema.fields["test_field"] == String(description="Test field.")
    assert TestSchema(test_field="test").test_field == "test"



# Generated at 2022-06-24 11:01:26.142071
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchemaDefinitions(object):
        definitions = SchemaDefinitions()

        class Meta(Schema):
            definitions = TestSchemaDefinitions.definitions

        class Message:
            pass

        class Collection:
            pass

        class Meta(Schema):
            definitions = TestSchemaDefinitions.definitions

            key = String(required=True)
            # Array of references
            collection = Array(Reference(Collection), required=True)
            # Reference
            message = Reference(Message, required=True)

            # Array of references
            messages = Array(Reference(Message), required=True)
            # Array of objects

# Generated at 2022-06-24 11:01:30.963676
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    class A(Schema):
        x = {'type': 'integer'}
    schema_definitions = SchemaDefinitions()
    schema_definitions['A'] = A
    assert schema_definitions.__delitem__('A') == None
    assert schema_definitions['A'] == None


# Generated at 2022-06-24 11:01:38.777571
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert("test_SchemaDefinitions___getitem__")
    
    # Mock object for testing
    class Mock():
        pass

    mock = Mock()
    mock.fields = {}
    mock.field_name = "test_field_name"

    target = SchemaDefinitions()
    target[mock.field_name] = mock

    # Test cases
    def case_1():
        target[mock.field_name] = mock
        assert(target[mock.field_name] == mock)

    def case_2():
        target["test_field_name"] = mock
        assert(target["test_field_name"] == mock)

    # Execute test cases
    case_1()
    case_2()
    

# Generated at 2022-06-24 11:01:46.105582
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from typesystem.base import (
        Field,
        Message,
        MessageType,
        ValidationError,
        ValidationResult,
    )

    class TestSchemaDefinitions___setitem__Schema(object):
        @classmethod
        def make_validator(
            cls: typing.Type[TestSchemaDefinitions___setitem__Schema],
            *,
            strict: bool = False,
        ) -> Field:
            return Field()

        @classmethod
        def validate(
            cls: typing.Type[TestSchemaDefinitions___setitem__Schema],
            value: typing.Any,
            *,
            strict: bool = False,
        ) -> TestSchemaDefinitions___setitem__Schema:
            validator = cls.make_validator(strict=strict)
            value

# Generated at 2022-06-24 11:01:55.413713
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    class Family(Schema):
        members = Array(items=Object(properties={
            "name": String(max_length=100),
            "age": Integer(minimum=0, maximum=150)}))

    class_Person = Reference(to='Person')
    print("Exercise: class Person, field name: ")
    print(class_Person.validate('Lizzy'))
    print("Exercise: class Person, field age ")
    print(class_Person.validate(10))
    print("Exercise: class Person, field age ")
    print(class_Person.validate("Lizzy"))

    class_Family = Reference(to='Family')

# Generated at 2022-06-24 11:02:06.565556
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Test code
    class SchemaDefinitions_Test(SchemaDefinitions):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self.args = args
            self.kwargs = kwargs
            super().__init__(*args, **kwargs)

    schema_definitions = SchemaDefinitions_Test(1, 2, a=3, b=4)  # type: dict
    # Test of the start state
    assert isinstance(schema_definitions, SchemaDefinitions)
    assert len(schema_definitions) == 4
    assert schema_definitions.args == (1, 2)
    assert schema_definitions.kwargs == {"a": 3, "b": 4}
    # Test of method __delitem__
    del schema_definitions

# Generated at 2022-06-24 11:02:15.221819
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer, String, ValidationError
    from typesystem import tools
    import types

    class Foo(Schema):
        a = Integer()
        b = String()

    assert isinstance(Foo, type)
    assert Foo.fields == {"a": Integer(), "b": String()}

    class SubFoo(Foo):
        c = Integer()

    assert isinstance(SubFoo, type)
    assert SubFoo.fields == {"a": Integer(), "b": String(), "c": Integer()}

    try:
        class BadSubFoo(Foo):
            a = Integer()
    except AssertionError:
        pass
    else:
        assert False, "Duplicate field definitions"


# Generated at 2022-06-24 11:02:19.164684
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert len(sd) == 0
    assert sd[1] == None
    assert sd[1] == None
    assert len(sd) == 0


# Generated at 2022-06-24 11:02:24.294864
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Schema1(Schema):
        test = String(max_length=10)
    class Schema2(Schema):
        test = Reference(Schema1)
    obj = Schema2({'test':{'test':'test'}})
    assert obj.serialize() == {'test': {'test': 'test'}}
    assert obj['test'] == {'test':'test'}
    assert obj['test'] == obj.serialize()['test']
    assert obj.test == obj['test']

# # Unit test for method validate of class Reference

# Generated at 2022-06-24 11:02:27.419227
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Set up
    obj = SchemaDefinitions()

    # Exercise
    actual = len(obj)

    # Verify
    assert actual == 0


# Generated at 2022-06-24 11:02:38.329798
# Unit test for constructor of class Reference
def test_Reference():
    # type: () -> None
    """
    Make sure that the constructor of Reference is correct
    """
    from typesystem.fields import String

    class Pet(Schema):
        name = String()
        species = String()

    class Person(Schema):
        name = String()
        favorite_pet = Reference(Pet)

    assert isinstance(Person().favorite_pet, Reference) and (
        Pet.__name__ == Person().favorite_pet.target.__name__
    )
    assert isinstance(Person().favorite_pet, Reference) and (
        Pet.__name__ == Person().favorite_pet.to
    )

    class Pet2(Schema):
        name = String()
        species = String()

    class Person2(Schema):
        name = String()
        favorite_pet = Reference("Pet2")

    definitions

# Generated at 2022-06-24 11:02:45.322559
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    # Set up test for serializing a dictionary
    test_dict = {
        "name": "Fred",
        "age": 21,
        "foods": ["pizza", "pasta", "pierogi"]
    }
    Reference.validate(test_dict)
    test_dict_serialized = Reference.serialize(test_dict)
    expected_dict_serialized = {
        "name": "Fred",
        "age": 21,
        "foods": ["pizza", "pasta", "pierogi"]
    }
    assert test_dict_serialized == expected_dict_serialized
    print("test_Reference_serialize passed")

test_Reference_serialize()

# Generated at 2022-06-24 11:02:48.540556
# Unit test for constructor of class Schema
def test_Schema():
    class Simple(Schema):
        name = StringField()
        age = IntegerField()
    simple = Simple({'name':'Tom', 'age':20})
    assert simple.name == 'Tom'
    assert simple.age == 20

if __name__ == "__main__":
    test_Schema()

# Generated at 2022-06-24 11:02:52.735592
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # No exception should be raised
    Schema({"a": 1, "b": 2})
    # KeyError is expected
    try:
        Schema({"a": 1, "b": 2, "c": 3})
    except KeyError:
        pass
    # KeyError is expected
    try:
        Schema({"a": 1, "b": 2, "c": 3})["c"]
    except KeyError:
        pass


# Generated at 2022-06-24 11:03:01.571215
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from copy import copy 
    from typesystem import Schema

    class Book(Schema):
        title = Field(str)
        author = Field(str)
        year = Field(int, nullable=True)
        numPages = Field(int, nullable=True)
        comments = Field(str, nullable=True)

    book1 = Book(title="Moby Dick", author="Herman Melville", year=1851)
    book2 = Book(title="Moby Dick", author="Herman Melville", year=1851)
    book3 = Book(title="Moby Dick", author="Herman Melville", year=1851, numPages=400)
    book4 = Book(title="Moby Dick", author="Herman Melville", year=1852)

    assert book1 == book2
    assert book1 != book3

# Generated at 2022-06-24 11:03:06.985575
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        field1 = Reference('testSchema')
        field2 = Reference('testSchema', allow_null=True)

    data = dict(field1='test', field2='test')

    definitions = SchemaDefinitions()
    definitions['testSchema'] = TestSchema
    TestSchema.validate(data, strict=True)
    assert data == dict(field1={'field1': 'test', 'field2': None}, field2={'field1': 'test', 'field2': None})


# Generated at 2022-06-24 11:03:14.406966
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.types import String

    class Foo(Schema):
        bar = Reference(String)
        definitions = SchemaDefinitions(String=String)
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super(Foo, self).__init__(*args, **kwargs)
        @classmethod
        def validate(cls: typing.Type["Schema"], value: typing.Any, *, strict: bool = False) -> "Schema":
            validator = cls.make_validator(strict=strict)
            value = validator.validate(value, strict=strict)
            return cls(value)

# Generated at 2022-06-24 11:03:23.513199
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    
    # Setting up
    definitions = {}
    cls = SchemaMetaclass
    
    name = 'Vendor'
    bases = (Schema,)
    attrs = {
        'fields': {},
        'name': None,
        'description': None,
        'homepage_url': None,
        'logo_url': None
    }
    
    output = cls.__new__(cls, name, bases, attrs, definitions)
    expected_output = typesystem.Schema
    assert output == expected_output



# Generated at 2022-06-24 11:03:25.472869
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert hasattr(SchemaDefinitions, "__iter__")


# Generated at 2022-06-24 11:03:30.458586
# Unit test for function set_definitions
def test_set_definitions():
    schema = Schema()
    schema.fields = {"name": Reference(to="Person")}
    definitions = SchemaDefinitions()
    definitions["Person"] = Field()
    set_definitions(schema.fields["name"], definitions)

# Generated at 2022-06-24 11:03:38.498940
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    """
    This test case tests method __getitem__ of class Schema
    """
    from typesystem import Integer, Object, String
    from typesystem.schema import Schema

    class MySchema(Schema):
        class Meta:
            additional_properties = False

        id = Integer()
        name = String()

    my_schema = MySchema(id=5, name="hong")
    assert my_schema["id"] == 5
    assert my_schema["name"] == "hong"
    try:
        my_schema["address"]
    except KeyError as e:
        print("KeyError because of not having address")
        print("==========================")



# Generated at 2022-06-24 11:03:42.844460
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        pass

    class TestReference(Schema):
        ref = Reference(TestSchema)

    ref = TestReference.validate({'ref': {}})
    obj = ref.serialize()
    assert obj['ref'] == {}

# Generated at 2022-06-24 11:03:44.705572
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    a = Schema({"a": "a"})
    assert a.__iter__() == {"a"}


# Generated at 2022-06-24 11:03:57.093024
# Unit test for constructor of class Schema
def test_Schema():
    class StrictSchema(Schema):
        field1 = Field(required=True)
        field2 = Field(required=True)
        field3 = Field(required=False)
        field4 = Field(required=True)
        field5 = Field(required=True)

    assert StrictSchema(field1="1", field2="2", field4="4", field5="5") == StrictSchema(field1="1", field2="2", field4="4", field5="5")
    assert StrictSchema(field1="1", field2="2", field3="3", field4="4", field5="5") == StrictSchema(field1="1", field2="2", field3="3", field4="4", field5="5")

# Generated at 2022-06-24 11:03:58.332033
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    pass


# Generated at 2022-06-24 11:04:00.384678
# Unit test for constructor of class Reference
def test_Reference():
  assert Reference(to="test").validate({"test" : "test"}) == {"test" : "test"}

# Generated at 2022-06-24 11:04:02.817073
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['test'] = {'this': 'That'}
    assert list(iter(schema_definitions)) == ['test'] 


# Generated at 2022-06-24 11:04:06.905827
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        field0 = Field(primitive_type=str)
        field1 = Field(primitive_type=str)
    my_schema = MySchema(field0="a")
    assert list(my_schema) == ['field0']
    

# Generated at 2022-06-24 11:04:11.266341
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()

    person1 = Person(name='John')
    person2 = Person(name='John')

    assert(person1 == person2)
    assert(person1.__eq__(person1))
    assert(not person1.__eq__(person2))

# Generated at 2022-06-24 11:04:17.036488
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    """Unit test for method __iter__ of class Schema"""

    # initialize the Schema instance
    value_schema = Schema(id=1, name="foo")

    # assert the result, because the __iter__ method should return the key of the value
    assert list(value_schema) == ["id", "name"]


# Generated at 2022-06-24 11:04:19.690074
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    try:
        s = SchemaDefinitions()
        s[3] = 45
        assert len(s._definitions) == 1
        del s[3]
        assert len(s._definitions) == 0
    except Exception as e:
        raise e


# Generated at 2022-06-24 11:04:25.812888
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Variables for test
    class TestSchema(Schema):
        fields = {
            "id": Integer(required=True),
            "title": String(max_length=255, required=True),
            "content": String(),
        }

    # Run test
    assert repr(TestSchema(id=1, title="Title")) == "TestSchema(id=1, title='Title')"

# Generated at 2022-06-24 11:04:28.436344
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    fields = [
        Field(name="field_1"),
        Field(name="field_2"),
        Field(name="field_3"),
    ]
    print(fields)


test_SchemaMetaclass()

# Generated at 2022-06-24 11:04:34.423053
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    ref_field = Reference("reference")
    array_field = Array(items=ref_field)
    object_field = Object(properties={"key": ref_field})

    assert ref_field.definitions is None
    assert array_field.items.definitions is None
    assert object_field.properties["key"].definitions is None

    set_definitions(ref_field, definitions)
    set_definitions(array_field, definitions)
    set_definitions(object_field, definitions)

    assert definitions == ref_field.definitions
    assert definitions == array_field.items.definitions
    assert definitions == object_field.properties["key"].definitions

    assert ref_field.target is None
    assert array_field.items.target is None

# Generated at 2022-06-24 11:04:37.249366
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import Integer

    class Person(Schema):
        age: Integer
    assert repr(Person(age=42)) == "Person(age=42)"


# Generated at 2022-06-24 11:04:40.505459
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Set up
    sut = SchemaDefinitions()
    key = "Test"
    value = "Test"
    sut[key] = value
    # Testing
    with raises(KeyError):
        del sut[key]


# Generated at 2022-06-24 11:04:46.647593
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    require_string = lambda s: s
    require_iter = lambda i: i
    require_int = lambda i: i
    class TestA(Schema):
        str_field = require_string
        int_field = require_int
        class TestB(Schema):
            str_field = require_string
    assert TestA.fields == {'str_field': TestA.__dict__['str_field'], 'int_field': TestA.__dict__['int_field']}
    assert TestA.TestB.fields == {'str_field': TestA.TestB.__dict__['str_field']}

# Generated at 2022-06-24 11:04:50.471089
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)

    assert Person.fields == {"name": String(required=True), "age": Integer(required=True)}
    assert Person.__name__ == "Person"


# Generated at 2022-06-24 11:04:58.274716
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Student(Schema):
        name = String()
        age = Integer(description="Student's age in years")

        class Options:
            definition_name = "Student"

    class Classroom(Schema):
        name = String()
        teacher = String()
        students = Array(items=Reference(to=Student))

    assert Student.fields == {'name': String(name='name', description=''), 'age': Integer(name='age', description="Student's age in years")}
    assert Student.__doc__ == ''
    assert issubclass(Student, Schema)

# Generated at 2022-06-24 11:05:03.812163
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert Schema.__repr__ is not None
    my_class = Schema()
    assert my_class.__repr__ == 'Schema({})'


# Generated at 2022-06-24 11:05:09.678344
# Unit test for function set_definitions
def test_set_definitions():
    class NestedSchema(Schema):
        foo = Reference("FooSchema")
        bar = Reference("BarSchema")

    class ArraySchema(Schema):
        arr = Array(Reference("FooSchema"), min_items=1)
        nes = NestedSchema()

    definitions = SchemaDefinitions({"FooSchema": Field()})
    foo = Reference("FooSchema")
    assert foo.definitions is None
    set_definitions(foo, definitions)
    assert foo.definitions is definitions
    bar = Reference("BarSchema")
    assert bar.definitions is None
    set_definitions(bar, definitions)
    assert bar.definitions is definitions
    assert isinstance(ArraySchema.fields["arr"], Array)

# Generated at 2022-06-24 11:05:10.585626
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len({'a': 1, 'b': 2}) == 2


# Generated at 2022-06-24 11:05:19.984333
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Joe Bloggs", age=23)
    # Test Schema()
    assert person.name == "Joe Bloggs"
    assert person.age == 23
    assert person["name"] == "Joe Bloggs"
    assert person["age"] == 23
    assert person == Person(name="Joe Bloggs", age=23)
    assert person == Person({"name": "Joe Bloggs", "age": 23})
    assert person == Person( Person(name="Joe Bloggs", age=23))

    person = Person({"name": "Joe Bloggs", "age": 23})
    # Test Schema(dict)
    assert person.name == "Joe Bloggs"
    assert person.age == 23

# Generated at 2022-06-24 11:05:26.029038
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # test for normal case
    class SchemaTest(Schema):
        test = Field()
    schema = SchemaTest(test="test")
    assert schema["test"] == "test"

    # test for exception case
    try:
        schema["not_exist"]
    except KeyError:
        pass

# Generated at 2022-06-24 11:05:28.598170
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref = Reference(to='a', definitions={'a': 1}, allow_null=True)
    assert ref.validate(1) == 1
    assert ref.validate(None) == None

# Generated at 2022-06-24 11:05:30.062389
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
  definitions = SchemaDefinitions()
  definitions['A'] = 'a'
  assert definitions['A'] == 'a'

# Generated at 2022-06-24 11:05:34.285198
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    field = Field(name="foo")
    array = Array(items=field)
    object = Object(properties={"foo": array}, additional_properties=False)
    set_definitions(object, definitions)
    assert isinstance(array.items, Field)
    assert array.items.name == "foo"
    assert array.items.definitions == definitions

# Generated at 2022-06-24 11:05:42.352227
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class KLSchema(Schema):
        name = String(length=20)
        age = Integer(minimum=0, maximum=120)
        city = String(length=20)
        occupation = String(length=20)
        job = String(length=20)

    s = KLSchema({'name':'John', 'age':33, 'city':'Boston', 'occupation':'Developer'},job='Software Engineer')
    assert s['name']=='John'
    assert s['age'] == 33
    assert s['city'] == 'Boston'
    assert s['occupation'] == 'Developer'
    assert s['job'] == 'Software Engineer'
    try:
        s['country']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 11:05:49.608996
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import Field
    from typesystem.object import Object, Schema

    class TestSchema(Schema):
        my_field = Field()

    schema = TestSchema(my_field="DONE")
    assert schema["my_field"] == "DONE"
    exception_caught = False
    try:
        schema["unknown_field"]
    except KeyError as error:
        exception_caught = True
        assert error.args == ("unknown_field", )
    assert exception_caught


# Generated at 2022-06-24 11:06:00.931010
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Integer, Object, String
    from typing import Any

    class ExampleSchema(Schema):
        name = String()
        age = Integer()

    # Test __init__ with dictionary keyword arguments
    s = ExampleSchema(name="Bob", age=42)
    assert s.name == "Bob"
    assert s.age == 42
    assert s["name"] == "Bob"
    assert s["age"] == 42

    # Test __init__ with dictionary positional argument
    d = {"name": "Bob", "age": 42}
    s = ExampleSchema(d)
    assert s.name == "Bob"
    assert s.age == 42
    assert s["name"] == "Bob"
    assert s["age"] == 42

    # Test __init__ with object positional argument
    o = ExampleSchema(d)


# Generated at 2022-06-24 11:06:04.670760
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    class Book(Schema):
        title = Field(str)
        pages = Field(int)
    definitions = SchemaDefinitions()
    definitions["Book"] = Book
    book = definitions["Book"]
    assert book is Book

# Generated at 2022-06-24 11:06:08.739945
# Unit test for function set_definitions
def test_set_definitions():
    class B(Schema):
        pass
    class A(Schema):
        b = Reference('B')
    d = SchemaDefinitions()
    set_definitions(A.fields['b'], d)
    assert A.fields['b'].target is B
test_set_definitions()

# Generated at 2022-06-24 11:06:13.403794
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person({"name": "John", "age": 40})
    assert person["name"] == "John"
    assert person["age"] == 40
    person = Person({"name": "John"})
    assert person["name"] == "John"



# Generated at 2022-06-24 11:06:14.382423
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert True


# Generated at 2022-06-24 11:06:16.060458
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    obj = SchemaDefinitions()
    obj['test'] = 'test'
    del obj['test']


# Generated at 2022-06-24 11:06:22.173047
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Passing
    class TestSchema(Schema):
        a = Field()
        b = Field()
    t = TestSchema(a=2, b=3)
    assert len(t) == 2
    assert t.is_sparse == False
    t = TestSchema(a=2)
    assert len(t) == 1
    assert t.is_sparse == True
    t = TestSchema()
    assert len(t) == 0
    assert t.is_sparse == True
    # Exception
    try:
        assert t["a"]
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 11:06:27.016392
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    s = Student(name='John', email='john@example.com')
    assert s['name'] == 'John'
    assert s['email'] == 'john@example.com'
    assert s['age'] == 30
    assert s['past_schools'] == [
        {'school': 'UCLA', 'major': 'Math'},
        {'school': 'UCSD', 'major': 'CS'},
    ]


# Generated at 2022-06-24 11:06:30.487025
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions[0] = 0
    assert len(definitions) == 1
    del definitions[0]
    assert len(definitions) == 0


# Generated at 2022-06-24 11:06:34.270497
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Integer, String

    class Pet(Schema):
        id = Integer()
        name = String()

    actual = Pet({'id': 1, 'name': 'Fluffy'})
    assert {'id': 1, 'name': 'Fluffy'} == actual
    assert {'id': 1, 'name': 'Fluffy'} == actual['id']


# Generated at 2022-06-24 11:06:38.799490
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class MySchemaMetaclass(SchemaMetaclass):
        pass

    class MySchema(metaclass=MySchemaMetaclass):
        def __init__(self, my_id: str, my_property: str) -> None:
            self.my_id = my_id
            self.my_property = my_property

    assert MySchema.fields == {"my_id": str, "my_property": str}

# Generated at 2022-06-24 11:06:47.765344
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class A(Schema):
        a = Field(type=int)
        b = Field(type=int)

    class B(A):
        c = Field(type=int)
        d = Field(type=int)

    assert repr(A()) == "A() [sparse]"
    assert repr(A(a=10)) == "A(a=10)"
    assert repr(A(a=10, b=20)) == "A(a=10, b=20)"
    assert repr(B()) == "B() [sparse]"
    assert repr(B(a=10, b=20, c=30)) == "B(a=10, b=20, c=30)"


# Generated at 2022-06-24 11:06:48.806526
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
	pass


# Generated at 2022-06-24 11:06:52.114592
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem.fields import String
    from typesystem import Schema

    class Foo(Schema):
        bar = String()

    foo = Foo.validate({"bar": "baz"})
    assert foo.bar == "baz"


# Generated at 2022-06-24 11:06:54.886912
# Unit test for constructor of class Schema
def test_Schema():
    class SomeSchema(Schema):
        field=int
    assert SomeSchema({"field":1}).field==1

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:06:57.221909
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    obj = SchemaDefinitions()
    key = None
    __tracebackhide__ = True
    with pytest.raises(KeyError, match=r".*"):
        del obj[key]


# Generated at 2022-06-24 11:07:01.762639
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    from typing import Any
    from unittest import TestCase

    test_cases: list[Any] = []
    for test_case in test_cases:
        print(test_case)



# Generated at 2022-06-24 11:07:05.568260
# Unit test for constructor of class Reference
def test_Reference():
    import typesystem
    c = typesystem.Reference("some_name", definitions={}, required=True)
    assert c.target_string == "some_name"
    assert c.to == "some_name"
    assert isinstance(c.errors["null"], str)
    assert c.errors["null"] == "May not be null."

# Generated at 2022-06-24 11:07:14.064929
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Definition1(Schema):
        field_1 = String()
        
    class Definition2(Schema):
        field_2 = String()

    class Definition3(Schema):
        field_3 = String()

    field = Reference(Definition1)
    assert field.validate(Definition1(field_1='string')) == Definition1(field_1='string')
    assert field.validate(Definition3(field_3='string')) == None


# Generated at 2022-06-24 11:07:22.184663
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from re import compile
    from typesystem import Schema
    from typesystem import fields
    class TestSchema(Schema):
        f1 = fields.Boolean()
        f2 = fields.Boolean()
        f3 = fields.Boolean()
        def __init__(self, f1, f2, f3):
            self.f1 = f1
            self.f2 = f2
            self.f3 = f3
        def __eq__(self, other):
            return (isinstance(other, TestSchema) and (self.f1 == other.f1) and (self.f2 == other.f2) and (self.f3 == other.f3))
        def __len__(self):
            return 3

# Generated at 2022-06-24 11:07:25.996798
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Array[int]()


    a1 = A([1,2,3])
    a2 = A([1,2,3])
    a3 = A([1,2])

    assert a1 == a2
    assert a1 != a3

# Generated at 2022-06-24 11:07:30.293134
# Unit test for constructor of class Schema
def test_Schema():
    class FooSchema(Schema):
        foo = Field(primitive_type=int, description="The foo.")
        bar = Field(primitive_type=str, description="The bar.")
    defs = SchemaDefinitions({})
    s = FooSchema(foo=2, bar='baz', definitions=defs)
    assert s.foo == 2 and s.bar == 'baz' and s.is_sparse == False
    s = FooSchema(foo=2, definitions=defs)
    assert s.foo == 2 and s.bar == None and s.is_sparse == True



# Generated at 2022-06-24 11:07:33.454805
# Unit test for function set_definitions
def test_set_definitions():
    class TestReference(Reference):
        pass

    class TestSchema(Schema):
        class Meta:
            definitions = "foobar"

        field = TestReference("TestReference")

    TestReference.Meta.definitions = TestSchema.Meta.definitions

    assert TestReference.definitions == "foobar"

# Generated at 2022-06-24 11:07:36.774103
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class MySchema(Schema):
        field = Field()
    schema = MySchema({"field": 3})
    assert schema["field"] == 3


# Generated at 2022-06-24 11:07:37.706777
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # 2 arguments
    # assert False # TODO implement your test here
    pass


# Generated at 2022-06-24 11:07:38.622669
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    pass #TODO: write tests for this class


# Generated at 2022-06-24 11:07:40.712422
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from tests.features.types.models import Car

    car_1 = Car(model="Toyota Yaris", doors=5)
    car_2 = Car(model="Toyota Yaris", doors=5)
    assert car_1 == car_2

# Generated at 2022-06-24 11:07:44.421852
# Unit test for method validate of class Reference
def test_Reference_validate():
    print("Running test Reference_validate")
    data = {'name': 'Joshua'}
    to = Schema(data) # Using {}
    ref = Reference(to, name='name')
    res = ref.validate(data)
    print(res)
    

# Generated at 2022-06-24 11:07:45.954717
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # __getitem__ exists
    assert hasattr(SchemaDefinitions, '__getitem__')


# Generated at 2022-06-24 11:07:56.131797
# Unit test for function set_definitions
def test_set_definitions():
    class Item(Schema):
        a = Reference('string')
        b = Reference('int')
    
    class Item2(Schema):
        c = Reference('float')
        d = Reference('bool')

    class ItemArray(Schema):
        e = Reference('string')
        f = Reference('int')
        g = Reference('float')
        h = Reference('bool')

    class ItemArray2(Schema):
        i = Reference('string')
        j = Reference('bool')

    class ItemObject(Schema):
        k = Reference('string')
        l = Reference('bool')

    class ItemObject2(Schema):
        m = Reference('string')
        n = Reference('int')
        o = Reference('float')
        p = Reference('bool')

    class ItemObject3(Schema):
        q = Reference

# Generated at 2022-06-24 11:08:06.860550
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class S(Schema):
        pass

    class P(Schema):
        pass

    class Q(Schema):
        pass

    class R(Schema):
        pass

    class X(Schema):
        a = String()
        b = R()
        c = String(required=False)
        f = String(default="abc")

    class Y(X):
        d = String()
        e = String(required=False)

    class Z(Y):
        h = P()
        i = String(default="def")
        j = String(required=False)

    # Scenario: Schema class that has no fields
    # Given I have a schema class S
    # Then repr(S()) must be "S()"
    assert repr(S()) == "S()"
    # Scenario: Schema class that has

# Generated at 2022-06-24 11:08:17.920310
# Unit test for constructor of class Reference
def test_Reference():
    doc = {
        '$schema': 'http://json-schema.org/draft-07/schema#',
        '$id': 'https://example.com/arrays.schema.json',
        'description': 'Test whether a value is a string, and if it is, whether it '
                       'is a valid date-time.',
        'type': 'string',
        'format': 'date-time',
    }

    from typesystem import datetime, date_time
    from typesystem.definitions import Definitions
    from typesystem.tests.schema import DateTime

    def test_datetime(datetime_str):
        return datetime_str.strftime('%Y-%m-%d %H:%M:%S')

    definitions = Definitions()
    definitions['DateTime'] = DateTime
    format

# Generated at 2022-06-24 11:08:19.416150
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        bar = String("Bar")


test_SchemaMetaclass()

# Generated at 2022-06-24 11:08:23.858686
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = "foo"
        field2 = "bar"

    s = TestSchema()
    result = list(s.__iter__())
    assert result == ['field1', 'field2']



# Generated at 2022-06-24 11:08:25.256574
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Test when _definitions is empty
    schema_definitions = SchemaDefinitions()
    assert next(schema_definitions.__iter__()) == (None,)


# Generated at 2022-06-24 11:08:34.238369
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class TestSchema(Schema):
        instance_field = Field()
        instance_field_with_default = Field(required=False, default=42)

    instance = TestSchema(instance_field='foo')
    assert repr(instance) == "TestSchema(instance_field='foo')"

    instance = TestSchema(instance_field='foo', instance_field_with_default=42)
    assert repr(instance) == "TestSchema(instance_field='foo', instance_field_with_default=42)"

    instance = TestSchema(instance_field='foo', instance_field_with_default=42)
    instance.instance_field_with_default = None
    assert repr(instance) == "TestSchema(instance_field='foo', instance_field_with_default=None)"


# Generated at 2022-06-24 11:08:38.636523
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert True



# Generated at 2022-06-24 11:08:50.035120
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Test reference with schema target
    class Pet(Schema):
        name = String()
        age = Number()

    pet_define = {'name': 'john'}
    pet_instance = Pet.validate(pet_define)
    reference = Reference(to=Pet)
    # Check if the reference field is a schema
    assert isinstance(reference.target, Schema)
    # Check validation of reference field
    assert reference.validate(pet_instance) == pet_instance
    # Check exception in case of invalid field
    try:
        reference.validate(None)
    except Exception as e:
        assert isinstance(e, ValidationError)

    # Test reference with string target
    pet_define = {'name': 'john'}
    pet_instance = Pet.validate(pet_define)

# Generated at 2022-06-24 11:08:54.050950
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(format='title')
        age = Integer()

    with pytest.raises(TypeError) as exc_info:
        Person(name='Joe', age=42, invalid=True)

    Person(name='Joe', age=42)
    Person(Person({'name': 'Joe', 'age': 42}))


# Generated at 2022-06-24 11:08:55.427841
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass # noqa: F841

# Generated at 2022-06-24 11:09:01.006541
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    class Post(Schema):
        title = String(max_length=100)
        author = Reference(Person)

    post = Post({"title": "foo", "author": {"name": "Corey", "age": 99}})
    assert isinstance(post.author, Person)
    assert post.author.name == "Corey"

# Generated at 2022-06-24 11:09:07.002411
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaA(Schema):
        field = Field()

    class SchemaB(Schema):
        field = Reference(to="SchemaA")

    definitions = SchemaDefinitions()
    set_definitions(SchemaB.fields["field"], definitions)
    assert definitions["SchemaA"] is SchemaA

    assert isinstance(SchemaB.fields["field"].target, Schema)


# Generated at 2022-06-24 11:09:07.667268
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert True

# Generated at 2022-06-24 11:09:14.750488
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from abc import ABCMeta
    from copy import copy
    import json
    import typesystem
    # Test Schema.__repr__: keyword arguments and arguments position
    class TestSchema0(typesystem.Schema, metaclass=ABCMeta):
        field_0 = typesystem.fields.String()
    class TestSchema1(typesystem.Schema, metaclass=ABCMeta):
        field_0 = typesystem.fields.String()
        field_1 = typesystem.fields.String()
    class TestSchema2(typesystem.Schema, metaclass=ABCMeta):
        field_0 = typesystem.fields.String()
        field_1 = typesystem.fields.String()
        field_2 = typesystem.fields.String()

# Generated at 2022-06-24 11:09:20.485802
# Unit test for function set_definitions
def test_set_definitions():
    class Child(Schema):
        pass

    class Parent(Schema):
        child = Reference(Child)

    definitions = SchemaDefinitions()

    assert definitions["Child"] == Child
    assert definitions["Parent"] == Parent
    assert Parent.fields["child"].definitions == definitions
    assert Parent.fields["child"]._target == Child

# Generated at 2022-06-24 11:09:25.046754
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class P(Schema):
        a = Field()
        b = Reference('Q')

    class Q(Schema):
        c = Field()

    set_definitions(P, definitions)
    assert Q.__name__ in definitions
    assert P.fields["b"].definitions == definitions

# Generated at 2022-06-24 11:09:30.388084
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import String
    class SchemaClass(Schema, metaclass=SchemaMetaclass):
        name = String(min_length=5)
        age = String(min_length=1)
    assert SchemaClass.fields == {'name': String(min_length=5), 'age': String(min_length=1)}


# Generated at 2022-06-24 11:09:39.932300
# Unit test for constructor of class Schema
def test_Schema():
    # Simple validator
    class SimpleSchema(Schema):
        name = Field(max_length=10)

    simple_schema = SimpleSchema(name='stefan')
    assert type(simple_schema) == SimpleSchema
    assert simple_schema['name'] == 'stefan'

    # Validator with an array and nested validator
    class ArraySchema(Schema):
        names = Array(of=Field(max_length=10))
    class NestedSchema(Schema):
        name = Field(max_length=10)
        age = Field(min_value=0, max_value=100)

    array_schema = ArraySchema(names=['stefan', 'sandra'])
    assert array_schema['names'] == ['stefan', 'sandra']
    nested

# Generated at 2022-06-24 11:09:47.750063
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.json_schema import Schema, Integer
    class A(Schema):
        a = Integer()

    class B(Schema):
        b = Reference(A)

    b = B.validate({'b': {'a': 1}})
    assert A.make_validator().serialize(b['b']) == {'a': 1}
    assert B.make_validator().serialize(b) == {'b': {'a': 1}}
    assert A.make_validator().serialize(b['b']) == {'a': 1}

# Generated at 2022-06-24 11:09:53.200028
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()

    # Test error message when attempting to set definition for existing name
    definitions["name1"] = "value1"
    with pytest.raises(AssertionError) as excinfo:
        definitions["name1"] = "value2"
    assert str(excinfo.value) == "Definition for 'name1' has already been set."

