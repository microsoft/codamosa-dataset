

# Generated at 2022-06-24 11:00:00.001756
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Name(Schema):
        first = Field(str)
        last = Field(str)
    name = Name(first="James", last="Bond")
    expected_repr = "Name(first='James', last='Bond')"
    assert repr(name) == expected_repr

# Generated at 2022-06-24 11:00:03.998969
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    __rv: dict
    schema_definitions: SchemaDefinitions = SchemaDefinitions()
    __rv = list(schema_definitions)
    return __rv


# Generated at 2022-06-24 11:00:06.967819
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Given
    definitions = SchemaDefinitions()
    # When
    result = definitions.__iter__()
    # Then
    assert isinstance(result, typing.Iterator) == True


# Generated at 2022-06-24 11:00:13.349929
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions=SchemaDefinitions()
    a=Field(label='a')
    definitions['a']=a
    definitions['b']=a
    definitions['c']=a
    definitions['d']=a
    assert len(definitions) == 4

    del definitions['d']
    assert len(definitions) == 3
    assert 'd' not in definitions

    try:
        del definitions['d']
    except AssertionError as e:
        assert type(e) == AssertionError

    try:
        definitions['a'] = a
    except AssertionError as e:
        assert type(e) == AssertionError


# Generated at 2022-06-24 11:00:20.131038
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref = Reference(int, min_length=2, max_length=5)
    assert ref.validate(2) == 2
    assert ref.validate(5) == 5
    assert ref.validate(7) == 7
    assert ref.validate(10) == 10
    assert ref.validate(4.5) == 5
    assert ref.validate(4.4) == 4
    assert ref.validate(4) == 4

    assert ref.validate(100) == 100
    assert ref.validate(100) == 100


# Generated at 2022-06-24 11:00:27.959751
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Foo(Schema):
        a = String()
        b = String()
        c = String()

    foo = Foo({'a': 'foo'})
    # test basic case
    assert repr(foo) == "Foo(a='foo') [sparse]"
    # test not sparse
    foo = Foo({'a': 'foo', 'b': 'bar'})
    assert repr(foo) == "Foo(a='foo', b='bar')"
    # test all fields defined
    foo = Foo({'a': 'foo', 'b': 'bar', 'c': 'baz'})
    assert repr(foo) == "Foo(a='foo', b='bar', c='baz')"


# Generated at 2022-06-24 11:00:31.418739
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class myClass(Schema):
        x = Field(int)
        y = Field(int)

    obj = myClass(x=1, y=2)
    assert len(obj) == 2


# Generated at 2022-06-24 11:00:38.931887
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        # 1st level:
        string = "str"
        number = 1.1

        # 2nd level:
        array = [[]]
        object = {"key": "value"}
        reference = Reference("ReferenceSchema")

    assert TestSchema.fields["reference"].definitions is None
    definitions = SchemaDefinitions()
    set_definitions(TestSchema, definitions)
    assert TestSchema.fields["reference"].definitions == definitions

# Generated at 2022-06-24 11:00:42.905325
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    d = SchemaDefinitions()
    d['a'] = 0
    assert d['a'] == 0
    del d['a']
    try:
        assert d['a']
        assert False
    except:
        assert True


# Generated at 2022-06-24 11:00:52.044508
# Unit test for method validate of class Reference
def test_Reference_validate():

    class LogLevels(Schema):
        info = Boolean()
        error = Boolean()
        warning = Boolean()
        debug = Boolean()

    class ReferenceLog(Schema):
        reference_log = LogLevels()
        ref = Reference(LogLevels)

    def validate(dict):
        try:
            return ReferenceLog.validate(dict)
        except ValidationError:
            return None

    valid_parameters = {
        'reference_log': {'info': False, 'error': True, 'warning': False, 'debug': True},
        'ref': {'info': False, 'error': False, 'warning': False, 'debug': True}
    }

    assert validate(valid_parameters) is not None


# Generated at 2022-06-24 11:00:55.390204
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    c1 = ChildSchema(name='c1',age=2)
    c2 = ChildSchema(name='c1',age=2)
    c3 = ChildSchema(name='c1',age=1)
    assert c1 == c2
    assert c1 != c3


# Generated at 2022-06-24 11:00:56.741711
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert False, "Test not implemented."


# Generated at 2022-06-24 11:01:01.017568
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # constructor test1
    d1 = SchemaDefinitions()
    assert d1._definitions == {}

    # constructor test2
    d2 = SchemaDefinitions({1: 2, 3: 4}, b=2, c=4)
    assert d2._definitions == {1: 2, 3: 4, 'b': 2, 'c': 4}


# Generated at 2022-06-24 11:01:08.075433
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    """
    Test whether serialize method could transfer an object to a dict
    """
    from typesystem.base import get_type_info
    from typesystem.types import String, DateTime
    class ClassA(Schema):
        class Meta:
            strict = False
        name = String()
        datetime = DateTime()
    classA = ClassA(name = '1', datetime = '2020-10-11T15:57:26Z')
    type_info = get_type_info(ClassA)
    ref = Reference(to = "ClassA", definitions = type_info)
    serialized_classA = ref.serialize(classA)
    right_classA = {'name': '1', 'datetime': '2020-10-11T15:57:26Z'}
    assert serialized_classA == right

# Generated at 2022-06-24 11:01:18.253287
# Unit test for constructor of class Schema
def test_Schema():
    # Test Schema class.
    class TestSchema(Schema):
        a = Field(required=True)
        b = Field(default=42)

    # Test that required values are required.
    with pytest.raises(TypeError):
        TestSchema()

    # Test that default values are respected.
    obj = TestSchema(a=1)
    assert obj == TestSchema(a=1, b=42)
    assert obj != TestSchema(a=1, b=24)

    # Test that default values are *not* respected when a value is provided.
    assert obj == TestSchema(a=1, b=24)
    assert obj != TestSchema(a=1, b=42)

    # Test that we can pass keyword arguments.
    obj = TestSchema(a=1)

# Generated at 2022-06-24 11:01:25.706209
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Animal(Schema):
        name = String(required=True)
        age = Integer()

    class Cat(Animal):
        color = String()
        is_cute = Boolean(required=True)

    assert Cat.fields["name"] == String(required=True)
    assert Cat.fields["age"] == Integer()
    assert Cat.fields["color"] == String()
    assert Cat.fields["is_cute"] == Boolean(required=True)

    assert len(Cat.fields) == 4


# Generated at 2022-06-24 11:01:26.337039
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass

# Generated at 2022-06-24 11:01:27.998395
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    result2 = Schema()

    assert result2.__repr__() == "Schema()"


# Generated at 2022-06-24 11:01:35.583526
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        required = Array(items=String())
        optional = Array(items=String(), allow_null=True, default=None)

    class Bar(Foo):
        field = String(required=True)
        
    foo = Foo(field=String())
    bar = Bar(field=String())
    assert len(foo.fields) == 1
    assert len(bar.fields) == 2
    assert len(bar.fields['field'].validators) == 1
    assert bar.fields['field'].validators[0] == String()
    assert len(bar.fields['required'].validators) == 1
    assert bar.fields['required'].validators[0] == String()
    assert len(bar.fields['optional'].validators) == 1

# Generated at 2022-06-24 11:01:39.454042
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    class A(Schema):
        field = Field()

    class B(Schema):
        field = Field()

    class C(Schema):
        field = Field()

    definitions = SchemaDefinitions()
    definitions["a"] = A
    definitions["b"] = B
    definitions["c"] = C
    assert list(iter(definitions)) == ["a", "b", "c"]


# Generated at 2022-06-24 11:01:42.727918
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    from typesystem.fields import String

    d = SchemaDefinitions({"Person": Object(properties={"name": String()})})
    assert len(d) == 1
    assert d["Person"]
    del d["Person"]
    assert len(d) == 0
    assert "Person" not in d


# Generated at 2022-06-24 11:01:46.823415
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert (len(definitions) == 0)



# Generated at 2022-06-24 11:01:55.622066
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema.__name__ == "Schema"
    assert Schema.__bases__ == (
        Mapping,
    )
    assert hasattr(Schema, "fields")
    assert hasattr(Schema, "__init__")
    assert hasattr(Schema, "make_validator")
    assert hasattr(Schema, "validate")
    assert hasattr(Schema, "validate_or_error")
    assert hasattr(Schema, "is_sparse")
    assert hasattr(Schema, "__eq__")
    assert hasattr(Schema, "__getitem__")
    assert hasattr(Schema, "__iter__")
    assert hasattr(Schema, "__len__")
    assert hasattr(Schema, "__repr__")


# Generated at 2022-06-24 11:02:01.591703
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person({"name": "Arthur", "age": 42})

    assert person != None
    assert person.name == 'Arthur'
    assert person.age == 42



# Generated at 2022-06-24 11:02:11.222321
# Unit test for method validate of class Reference
def test_Reference_validate():
    from pprint import pprint
# Test 1 of Reference.validate
#     Test if everything works correctly

# Generated at 2022-06-24 11:02:14.810778
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Foo(Schema):
        bar = Field(description="baz")

    foo = Foo(bar="qux")
    assert foo["bar"] == "qux"

test_Schema___getitem__()

# Generated at 2022-06-24 11:02:20.691360
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Test fields
    a = Field()
    b = Field()
    class TestSchemaClass(SchemaMetaclass):
        fields = {
            "a" : a,
            "b" : b,
        }
    a.default = 1
    b.default = 2
    test_schema = TestSchemaClass()
    compare_test_schema = TestSchemaClass(test_schema)

    # Test cases
    assert test_schema == compare_test_schema
    assert test_schema is not compare_test_schema



# Generated at 2022-06-24 11:02:24.811064
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Subschema(Schema):
        name = Field(type_=str)

    class Schema(Schema):
        sub = Reference(to=Subschema)

    schema = Schema({'sub': {'name': 'test'}})
    # expected = {'sub': {'name': 'test'}}
    expected = {'sub': {'name': 'test'}}
    assert schema.serialize(schema) == expected


# Generated at 2022-06-24 11:02:32.034701
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # Test __init__, args and kwargs both empty
    schema_definitions = SchemaDefinitions()
    assert schema_definitions == {}

    # Test __init__, args empty, kwargs not empty
    schema_definitions = SchemaDefinitions(key1 = 'value1')
    assert schema_definitions == {'key1': 'value1'}

    # Test __init__, args not empty, kwargs empty
    schema_definitions = SchemaDefinitions({'key1': 'value1'})
    assert schema_definitions == {'key1': 'value1'}

    # Test __getitem__, key not in schema_definitions
    # should raise exception
    try:
        schema_definitions['key2']
    except KeyError:
        pass

# Generated at 2022-06-24 11:02:41.769016
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        age=Integer()
        date_joined=Date()
        fruit=Enum(['apple','orange','banana'])

    fruit_validator = Reference('TestSchema')
    try:
        fruit = fruit_validator.validate('apple')
        assert fruit == 'apple'
    except ValidationError as error:
        assert error.text == 'apple is not a valid member of the list.'

    fruit_validator.allow_null=True
    fruit = fruit_validator.validate(None)
    assert fruit == None

    fruit_validator.definitions = SchemaDefinitions()
    fruit_validator.definitions['TestSchema'] = TestSchema

    age_validator = TestSchema.fields['age']

# Generated at 2022-06-24 11:02:42.828986
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
  pass

# Generated at 2022-06-24 11:02:52.209528
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class TestSchema(Schema):
        field = Reference("TestSchema")
        field2 = Reference(TestSchema)
        field3 = Array(Reference("TestSchema"))
        field4 = Array(Reference(TestSchema))
        field5 = Object({
            "field6": Reference("TestSchema"),
            "field7": Reference(TestSchema),
        })
    set_definitions(TestSchema, definitions)
    assert TestSchema.validate(
        {
            "field": None,
            "field2": None,
            "field3": [None],
            "field4": [None],
            "field5": {
                "field6": None,
                "field7": None,
            },
        }
    )

# Generated at 2022-06-24 11:02:58.903764
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    s = Schema()
    # check the return value is iterable.
    assert hasattr(s, '__iter__')
    # check the return value is not regular sequence type.
    assert isinstance(s, Mapping)
    # check the return value is not regular sequence type.
    assert not isinstance(s, typing.Sequence)



# Generated at 2022-06-24 11:03:02.800936
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    v = {"a": 1}
    #if __name__ == "__main__":
    #    import doctest
    #    doctest.testmod()
    #    print("*******")
    assert (Reference("").serialize(v) == {"a": 1})

try:
    from typing import Literal
except ImportError:

    def Literal(*values: typing.Any) -> typing.Any:
        return values

# Generated at 2022-06-24 11:03:06.393150
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['key1'] = 'value1'
    schema_definitions['key2'] = 'value2'

    result = [i for i in schema_definitions]
    expected = ['key1', 'key2']

    assert(expected == result)



# Generated at 2022-06-24 11:03:09.555256
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        test = String(description='description')
    obj1 = TestSchema({'test': "value"})
    obj2 = TestSchema({'test': "value"})
    assert obj1 == obj2


# Generated at 2022-06-24 11:03:13.508520
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Create a new Schema object.
    schema = Schema()
    # Access the length of this object's `fields` attribute.
    # This method returns 0, as the `fields` attribute is an empty dictionary.
    result = len(schema)
    expected = 0
    assert result == expected


# Generated at 2022-06-24 11:03:20.422753
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    d = SchemaDefinitions({1: 'a', 2: 'b', 3: 'c'})
    assert d[1] == 'a'
    assert d[2] == 'b'
    assert d[3] == 'c'
    assert d.__len__() == 3
    assert len(d) == 3
    assert sorted(d.__iter__()) == [1, 2, 3]
    assert sorted(iter(d)) == [1, 2, 3]
    d[1] = 'abc'
    assert d[1] == 'abc'
    d[4] = 'd'
    assert d[4] == 'd'
    del d[4]
    assert len(d) == 3
    try:
        d[4]
        assert False
    except KeyError as error:
        assert error.args

# Generated at 2022-06-24 11:03:21.033396
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    pass


# Generated at 2022-06-24 11:03:25.782220
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # GIVEN
    definition = SchemaDefinitions({"a": 1, "b": 2, "c": 3})
    # THEN
    assert list(definition) == ["a", "b", "c"]


# Generated at 2022-06-24 11:03:34.986449
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class FooSchema(Schema):
        foo = Field(type_=str)
        bar = Field(type_=int)

    foo1 = FooSchema(foo='Hello', bar=1)
    foo2 = FooSchema(foo='Hello', bar=1)
    foo3 = FooSchema(foo='World', bar=3)
    print(f'foo1==foo2? {foo1==foo2}')
    print(f'foo1==foo3? {foo1==foo3}')

    # print(f'foo1.is_sparse? {foo1.is_sparse}')
    # print(f'foo3.is_sparse? {foo3.is_sparse}')

    print(f'foo1["foo"]? {foo1["foo"]}')

# Generated at 2022-06-24 11:03:37.699757
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Integer, String
    
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='Brian', age=23)
    assert list(p.__iter__()) == ['name', 'age']


# Generated at 2022-06-24 11:03:39.900875
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Integer
    class Person(Schema):
        age = Integer()
    p = Person(age = 20)
    # Test for RETURNS
    assert p.__getitem__('age') == 20, 'Return value is wrong'
    

# Generated at 2022-06-24 11:03:41.248790
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
	pass


# Generated at 2022-06-24 11:03:49.137002
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test that the _getitem__ method works as expected
    schema_definitions = SchemaDefinitions()
    class Schema1(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions):
        # Class created to test getitem method
        name = Field(description="The name of the person")
        age = Field(description="The age of the person")
    # create an instance of the class
    instance1 = Schema1(name="John", age=21)
    # check that the method retrieves the correct value
    assert instance1.__getitem__("name") == "John"
    # check that error is raised for invalid key
    with pytest.raises(KeyError):
        instance1.__getitem__("gender")


# Generated at 2022-06-24 11:03:53.316939
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Null
    s = SchemaDefinitions()
    try:
        s.__getitem__(1)
    except:
        pass
    else:
        assert False
    


# Generated at 2022-06-24 11:03:57.163123
# Unit test for function set_definitions
def test_set_definitions():
    for field in [Reference, List, Dict]:
        a = field()
        assert not hasattr(a, "definitions")
        set_definitions(a, {"foo": "bar"})
        assert hasattr(a, "definitions")
        assert a.definitions["foo"] == "bar"

# Generated at 2022-06-24 11:03:58.429537
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()

# Generated at 2022-06-24 11:04:02.724570
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    ref = Reference(to = '', definitions = None, required = True)
    # Uncomment these lines below and the unit test will fail
    #validator = ref.make_validator()
    #validator.validate(None)
    assert type(ref.serialize(None)) == dict



# Generated at 2022-06-24 11:04:15.849688
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import Boolean, Integer, String

    class Schema1(Schema):
        a = Integer()
        b = Integer()
        c = Integer()
        e = Integer()
    class Schema2(Schema):
        d = Integer()
        e = Integer()
        f = Integer()

    class Schema3(Schema):
        g = Integer()
        h = Integer()
        i = Integer()

    class Schema4(Schema2):
        g = Integer()
        h = Integer()
        i = Integer()

    assert Schema1.fields.keys() == {'a', 'b', 'c', 'e'}
    assert Schema2.fields.keys() == {'d', 'e', 'f'}

# Generated at 2022-06-24 11:04:16.594897
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    assert True


# Generated at 2022-06-24 11:04:18.911202
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import typesystem
    schema_definitions_instance = SchemaDefinitions()
    assert isinstance(schema_definitions_instance.__iter__(), types.GeneratorType)


# Generated at 2022-06-24 11:04:22.327490
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    print("== Unit test for method __getitem__ of class Schema ==")

    class FakeSchema(Schema):
        field = Field()

    schema = FakeSchema({'field': 'value'})

    assert schema['field'] == 'value'

    try:
        print(schema['undefined_field'])
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-24 11:04:28.854623
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Integer

    class TestSchema(Schema):
        id = Integer()

    schema = TestSchema(id=1)
    assert schema == TestSchema(id=1)

    s = ','.join([str(i) for i in schema])
    assert s == "id"

    assert (
        repr(schema)
        == "TestSchema(id=1)"
    ), '__repr__ should return "TestSchema(id=1)"'



# Generated at 2022-06-24 11:04:30.835253
# Unit test for function set_definitions
def test_set_definitions():
    class Summary(Schema):
        title = Field()
    set_definitions(Summary, SchemaDefinitions())


# Generated at 2022-06-24 11:04:33.410436
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions() # type: SchemaDefinitions
    definitions["a"] = 1
    definitions["b"] = 2
    assert len(definitions) == 2


# Generated at 2022-06-24 11:04:40.277086
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = "a"

    assert A.fields == {"a": "a"}
    assert A.make_validator() == Object(properties={"a": "a"}, required=["a"])

    class B(Schema):
        b = "b"

    assert B.fields == {"b": "b"}
    assert B.make_validator() == Object(properties={"b": "b"}, required=["b"])



# Generated at 2022-06-24 11:04:47.800882
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    s = SchemaDefinitions()
    def add_items(s: SchemaDefinitions, number_of_items:int):
        for i in range(0, number_of_items):
            s[i] = i
        
    add_items(s, 3)
    i = iter(s)
    assert next(i) == 0
    assert next(i) == 1
    assert next(i) == 2
    with pytest.raises(StopIteration):
        next(i)
    def add_items(s: SchemaDefinitions, number_of_items:int):
        for i in range(0, number_of_items):
            s[i] = i
    add_items(s, 3)
    i = iter(s)
    assert next(i) == 0

# Generated at 2022-06-24 11:04:56.579979
# Unit test for function set_definitions
def test_set_definitions():
    def assert_definitions(field: Field, definitions: SchemaDefinitions) -> None:
        """Recursively assert the definitions on all fields in a tree."""
        assert field.definitions == definitions
        if isinstance(field, Array):
            if field.items is not None:
                if isinstance(field.items, (tuple, list)):
                    for child in field.items:
                        assert_definitions(child, definitions)
                else:
                    assert_definitions(field.items, definitions)
        elif isinstance(field, Object):
            for child in field.properties.values():
                assert_definitions(child, definitions)

    definitions = SchemaDefinitions()
    reference_field = Reference("Foo")
    set_definitions(reference_field, definitions)
    assert reference_field.definitions == definitions



# Generated at 2022-06-24 11:05:01.540671
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    item1 = None
    item2 = None
    obj2 = SchemaDefinitions(item2)
    assert len(obj2) == 0
    item1 = (1, 2, 3)
    obj2 = SchemaDefinitions(item1)
    assert len(obj2) == 3


# Generated at 2022-06-24 11:05:02.733531
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert False, "Not implemented"


# Generated at 2022-06-24 11:05:08.179535
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert (Schema() == Schema()) is True
    assert (Schema(x=1) == Schema(x=1)) is True
    assert (Schema(x=1) == Schema(x=2)) is False
    assert (Schema(x=1) == Schema(y=1)) is False
    assert (Schema(x=1) == Schema()) is False


# Generated at 2022-06-24 11:05:14.619284
# Unit test for function set_definitions
def test_set_definitions():
    field = Reference("Test")
    definitions = SchemaDefinitions()
    definitions["Test"] = {"1": "one"}
    set_definitions(field, definitions)
    assert field.target_string == "Test"
    assert field._target == {"1": "one"}
    assert field.definitions == definitions
    field2 = Array(Reference("Test"))
    set_definitions(field2, definitions)
    assert field2.items.target_string == "Test"
    assert field2.items._target == {"1": "one"}
    assert field2.items.definitions == definitions
    field3 = Object({"a": Reference("Test"), "b": Reference("Test")})
    set_definitions(field3, definitions)
    assert field3.properties["a"].target_string == "Test"
    assert field3.properties

# Generated at 2022-06-24 11:05:23.481730
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import Integer, String
    from typesystem import Schema
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    class MySchema(Schema):
    
        id = Integer()
    
        name = String()
    
        email = String(format='email', default=None)
    
        height = Integer(minimum=240, default=None)
    
        weight = Integer(minimum=30, default=None)
    
        age = Integer(minimum=5, default=None)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-24 11:05:27.339085
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    
    p = Person(name="John", age=20)
    assert len(p) == 2


# Generated at 2022-06-24 11:05:32.342476
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    print("test_SchemaDefinitions___iter__()")
    definitions = SchemaDefinitions()
    definitions["A"] = ""
    definitions["B"] = ""
    definitions["C"] = ""
    definitions["D"] = ""
    definitions["E"] = ""
    definitions["F"] = ""
    definitions["G"] = ""
    assert list(definitions) == ["A", "B", "C", "D", "E", "F", "G"]


# Generated at 2022-06-24 11:05:35.225857
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(name='Test')
    print(schema)  # Should print 'Schema(name=Test)'

test_Schema()

 

# Generated at 2022-06-24 11:05:43.064359
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(str).serialize('a') == 'a'
    assert Reference(str, allow_null=True).serialize(None) is None
    assert Reference(str, allow_null=True).serialize('a') == 'a'
    assert Reference(str, allow_null=True).serialize(4) == '4'
    assert Reference(int).serialize(4) == 4
    assert Reference(int).serialize('a') == 0
    assert Reference(int).serialize([1]) == 1
    assert Reference(int).serialize(None) is None
    assert Reference(int, allow_null=True).serialize(None) is None
    assert Reference(int, default=4).serialize(None) == 4
    assert Reference(int, allow_null=True, default=4).serialize(None) == 4
   

# Generated at 2022-06-24 11:05:47.608905
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Integer()
        field2 = String()
    schema = TestSchema()
    assert len(schema) == 0
    schema = TestSchema(field1=15, field2="16")
    assert len(schema) == 2


# Generated at 2022-06-24 11:05:49.439489
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        id = Field()

    parameters = dict(id=1)
    person = Person(parameters)


# Generated at 2022-06-24 11:05:55.089888
# Unit test for method __getitem__ of class SchemaDefinitions

# Generated at 2022-06-24 11:05:59.932464
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A(Schema):
        name = String(required=True)

    class B(Schema):
        a = Reference(A)

    b = B.validate({"a": {"name": "Pablo"}})
    assert b.a.name == "Pablo"



# Generated at 2022-06-24 11:06:07.430825
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class User(Schema):
        username = Field(str)
        password = Field(str)
        birthday = Field(DateTime)

    user = User(username='foo', password='bar', birthday=datetime(2000, 1, 1))

    assert user['username'] == 'foo'
    assert user['password'] == 'bar'
    assert user['birthday'] == '2000-01-01T00:00:00+00:00'

    try:
        x = user['homepage']
    except KeyError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 11:06:10.951676
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String(max_length=100)

    person = Person(name='Mary')
    assert len(person) == 1


# Generated at 2022-06-24 11:06:15.746152
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert True
    # TODO: fixme
    return
    object_mapping = {'toto': 'titi'}
    object_expected_result = object_mapping['toto']  # type: ignore
    object_actual_result = SchemaDefinitions(object_mapping)['toto']
    assert object_expected_result == object_actual_result



# Generated at 2022-06-24 11:06:19.073514
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    sd[1] = 5
    sd[1] = 5

    try:
        sd[1] = 6
    except AssertionError as e:
        assert str(e) == "Definition for 1 has already been set."

# Generated at 2022-06-24 11:06:20.974470
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String
    class A(Schema):
        a = String()
    A.__new__(A)


# Generated at 2022-06-24 11:06:25.177236
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def _test():
        definitions = SchemaDefinitions()

        definitions["key"] = "value"
        assert definitions["key"] == "value"

        definitions["key"] = "value"

    _test()



# Generated at 2022-06-24 11:06:31.790064
# Unit test for constructor of class Reference
def test_Reference():
    """
    Test constructor of Reference.
    """
    from typesystem.types import String

    class MySchema(Schema):
        """
        Schema for MySchema
        """
        foo = String()
    
    reference = Reference(definition=MySchema)
    assert str(reference) == 'Reference(to=MySchema)'
    assert reference.target_string == 'MySchema'
    assert reference.target == MySchema

# Generated at 2022-06-24 11:06:41.225765
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class PersonSchema(Schema):
        first_name = String()
        last_name = String()

    person = PersonSchema({"first_name": "Mark", "last_name": "Mueller"})
    assert person == PersonSchema(first_name="Mark", last_name="Mueller")
    assert person == PersonSchema(PersonSchema(first_name="Mark", last_name="Mueller"))
    assert isinstance(person, PersonSchema)
    assert person.first_name == "Mark"
    assert person.last_name == "Mueller"
    assert len(person) == 2


# Generated at 2022-06-24 11:06:47.022296
# Unit test for function set_definitions
def test_set_definitions():
    d = SchemaDefinitions()
    class A(Schema):
        f = Reference("B")
    class B(Schema):
        f = Field()
    set_definitions(A, d)
    assert d["A"] == A
    assert d["B"] == B
    assert A.fields["f"].target is B
    assert A.fields["f"].target_string == "B"
    assert B.fields["f"].target_string == "f"

# Generated at 2022-06-24 11:06:52.792127
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    ms = MySchema(a=10, b=20, c=30)
    assert len(ms) == 3
    assert list(ms) == ['a', 'b', 'c']
    assert list(ms['a']) == [10]
    assert list(ms['b']) == [20]
    assert list(ms['c']) == [30]


# Generated at 2022-06-24 11:06:55.053495
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference(to="abc", definitions=None) is not None


# Generated at 2022-06-24 11:06:56.788374
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    print(Schema.__iter__)

if __name__ == '__main__':
    test_Schema___iter__()

# Generated at 2022-06-24 11:07:06.846789
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # corner case
    S = SchemaMetaclass.__new__(type, 'S', (), {})
    assert type(S) is type
    assert not hasattr(S, 'fields')

    # simple case
    class Test(object):
        fields = {'value': 'value'}

    class T(metaclass=SchemaMetaclass):
        fields = {'value': 'value'}
    assert Test.fields == T.fields

    # more complex case with bases
    class Test(object):
        fields = {'value': 'value'}
    class T(metaclass=SchemaMetaclass):
        fields = {'value': 'value'}
    class Test2(Test):
        fields = {'value2': 'value2'}

# Generated at 2022-06-24 11:07:08.322920
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    s = SchemaDefinitions()
    assert not "__getitem__" in dir(s)



# Generated at 2022-06-24 11:07:17.419719
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert hasattr(Schema, 'fields')
    assert hasattr(Schema, '__init__')
    assert hasattr(Schema, 'make_validator')
    assert hasattr(Schema, 'validate')
    assert hasattr(Schema, 'validate_or_error')
    assert hasattr(Schema, 'is_sparse')
    assert hasattr(Schema, '__eq__')
    assert hasattr(Schema, '__getitem__')
    assert hasattr(Schema, '__iter__')
    assert hasattr(Schema, '__len__')
    assert hasattr(Schema, '__repr__')


# Generated at 2022-06-24 11:07:25.760513
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test with a simple schema
    class SimpleSchema(Schema):
        a = Field(type=str)
        b = Field(type=str, default="hello")
        c = Field(type=str, default="world")
        d = Field(type=str, default="python")

    instance = SimpleSchema({"a": "I"})
    # Test that the instance has 2 fields
    assert len(instance) == 2

    # Test with a complex schema
    class ComplexSchema(Schema):
        a = Field(type=str)
        b = Field(type=str)
        c = Field(type=str)
        d = Field(type=str)
        _json_class = Field(type=str)
        _json_schema = Field(type=str)


# Generated at 2022-06-24 11:07:30.450052
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    d = SchemaDefinitions()
    d["a"]=1
    d["b"]=2
    # the expected item is already in dictionary
    try:
        d["c"]=3
        d["c"]=4
    except:
        pass
    else:
        raise Exception("fail")


# Generated at 2022-06-24 11:07:34.315446
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import Integer
    from typesystem.schema import Schema

    class Animal(Schema):
        id = Integer() # type: ignore

    assert Animal({"id": 1}) != Animal({"id": 2})
    assert Animal({"id": 1}) == Animal({"id": 1})

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 11:07:44.390061
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Schema1(Schema):
        field = Reference("foo")

    class Schema2(Schema):
        field1: Reference("bar")
        field2 = Reference("foo")

    class Schema3(Schema):
        field1 = Reference("foo")
        field2 = Reference("bar")

    class Schema4(Schema):
        field = Reference("foo")

    def assert_reference_has_definitions(reference, types):
        assert reference.definitions is types

    assert_reference_has_definitions(Schema1.fields["field"], None)
    assert_reference_has_definitions(Schema2.fields["field1"], None)
    assert_reference_has_definitions(Schema2.fields["field2"], None)
    assert_reference_has_def

# Generated at 2022-06-24 11:07:53.045725
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    from typesystem.types import String

    class Node(Schema):
        name = String()

    assert len(Node.fields) == 1
    assert isinstance(Node.fields["name"], String)
    assert not Node.fields["name"].required

    class Employee(Node):
        office = String()
        cell = String(required=True)

    assert len(Employee.fields) == 3
    assert isinstance(Employee.fields["office"], String)
    assert not Employee.fields["office"].required
    assert isinstance(Employee.fields["cell"], String)
    assert Employee.fields["cell"].required

# Generated at 2022-06-24 11:07:55.582306
# Unit test for constructor of class Schema
def test_Schema():
    class ResourceSchema(Schema):
        name = String(max_length=100)

    resource = ResourceSchema(dict(name="A Resource"))
    assert resource.name == "A Resource"


# Generated at 2022-06-24 11:08:06.529986
# Unit test for function set_definitions
def test_set_definitions():
    obj = {
        "title": "My Title",
        "author": "My Author",
        "keywords": ["k1", "k2"],
        "categories": ["c1", "c2"],
        "metadata": {"key1": "m1", "key2": "m2"},
    }

    class Categories(Schema):
        category = String()

    class Metadata(Schema):
        key = String()
        value = String()

    class Post(Schema):
        title = String()
        author = String()
        keywords = Array(String())
        categories = Array(Reference("Categories"))
        metadata = Array(Reference("Metadata"))

    class PostExecutor(object):
        def __init__(self, definitions: SchemaDefinitions) -> None:
            set_definitions(Post, definitions)



# Generated at 2022-06-24 11:08:10.806480
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String(max_length=20)
        age = Integer()

    d1 = Person(name='jean', age=25)
    d2 = Person(name='jean', age=25)

    print(d1 == d2)  # True



# Generated at 2022-06-24 11:08:16.372882
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema(**{"a": 1, "b": 2, "c": 3})) == "Schema(a=1, b=2, c=3)"
    assert repr(Schema(**{"a": 1, "b": 2, "c": 3})) != "Schema(a=1, b=2, c=3, d=4)"

# Generated at 2022-06-24 11:08:19.324175
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schemaDefinitions = SchemaDefinitions()
    assert len(schemaDefinitions) == 0


# Generated at 2022-06-24 11:08:29.278200
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import json
    import typesystem

    def check_set_definition(definitions: SchemaDefinitions, field: Field, to: str):
        if isinstance(field, Reference) and field.definitions is None:
            assert field.definitions is None
            field.definitions = definitions
            assert field.definitions == definitions
            assert field.to == to

    definitions = SchemaDefinitions({"name": "Staff"})
    new_type = SchemaMetaclass(
        "name",
        (),
        {"name": typesystem.String()},
        definitions=definitions,
    )
    assert isinstance(new_type, type)
    assert new_type.__name__ == "name"
    assert new_type.fields == {"name": typesystem.String()}


# Generated at 2022-06-24 11:08:33.434001
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Bob", age=99)

    # This is a simple test for making sure the `__init__` method is added to
    # the Schema class.
    print(person)

if __name__ == "__main__":
    test_Schema()

# Generated at 2022-06-24 11:08:39.238829
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.types import String
    r = Reference("abc", to="abc")
    assert r.definitions is None
    assert r.target_string == "abc"
    assert r.to == "abc"
    assert r._target_string == "abc"
    assert r.target is None
    r = Reference("abc", to=String)
    assert r.definitions is None
    assert r.target_string is None
    assert r.to == String
    assert r._target_string is None
    assert r.target == String


# Generated at 2022-06-24 11:08:50.312014
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    assert len(s) == 0
    assert s.get('test') == None
    assert s.__contains__('test') == False
    assert s.__delitem__('test') == None
    assert s.__eq__({'test':'test'}) == False
    assert s.__getitem__('test') == None
    assert s.__iter__() == None
    assert s.__len__() == 0
    assert s.__ne__({'test':'test'}) == True
    assert s.__repr__() == "SchemaDefinitions({})"
    assert s.__setitem__('test', 'test') == None
    assert s.__str__() == "SchemaDefinitions({})"
    assert s.clear() == None

# Generated at 2022-06-24 11:08:53.774378
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    if hasattr(Schema, '__abstractmethods__'):
        del Schema.__abstractmethods__
    from typesystem import Integer

    class Person(Schema):
        id = Integer()
        name = Integer()

    assert len(Person(1, 2)) == 1



# Generated at 2022-06-24 11:09:02.192785
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import json
    import jsonschema

    class Account(Schema):
        balance = Field(type=int)
        name = Field(type=str, required=False)

    accounts = [Account({"balance": 1}), Account({"balance": 2, "name": "foo"})]

    for account in accounts:
        print(account)

    print(Account({"balance": 1, "name": "foo"}))

    assert (
        str(Account({}))
        == "Account(balance=None) [sparse]"
    )
    assert (
        str(Account({}))
        == "Account(balance=None) [sparse]"
    )
    assert (
        str(Account({"balance": 1}))
        == "Account(balance=1)"
    )

# Generated at 2022-06-24 11:09:03.923419
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions(test="test")
    assert definitions["test"] == "test"


# Generated at 2022-06-24 11:09:06.388484
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test that __getitem__() returns the correct value
    test_instance = Schema()
    assert test_instance[1] == 1

# Generated at 2022-06-24 11:09:12.223959
# Unit test for constructor of class Reference
def test_Reference():
    schema = Schema.validate(
        {
            "name": "Jane Smith",
            "age": 30,
            "postal_address": {
                "street_address": "123 Main Street",
                "country": "Canada",
                "postal_code": "H0H 0H0",
            },
            "phone_number": [
                {"number": "555 555-5555", "type": "work"},
                {"number": "444-444-4444", "type": "home"},
            ],
        }
    )
    schema.name


# Generated at 2022-06-24 11:09:15.275992
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['X'] = 1
    definitions['Y'] = 2
    assert definitions.__getitem__('X') == 1
    assert definitions.__getitem__('Y') == 2


# Generated at 2022-06-24 11:09:26.685116
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    a = typing.Any()
    b = typing.Any()
    c = typing.Any()
    test_cases__getitem__ = [
        (
            "Mapping.__getitem__",
            {
                a: b,
                c: typing.Any(),
            },
            "abc"[2],
            b,
        ),
        # [
        #     "Mapping.__getitem__",
        #     "dict",
        #     "a",
        #     b,
        # ]
    ]
    for test_case in test_cases__getitem__:
        test_label, x, k, expected = test_case
        #print(f"{test_label}: {x}, {k}")
        actual = x[k]
        assert actual == expected

# Generated at 2022-06-24 11:09:28.180506
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass


# Generated at 2022-06-24 11:09:33.263175
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        x = Field(String)
        y = Field(String)

    field_names = list(TestSchema({}))
    assert len(field_names) == 0

    field_names = list(TestSchema({"x": "str"}))
    assert len(field_names) == 1

    field_names = list(TestSchema({"x": "str", "y": "str"}))
    assert len(field_names) == 2

# Generated at 2022-06-24 11:09:41.650824
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Diagnostic(Schema):
        phase = String()
        message = String()

    assert set(Diagnostic.fields.keys()) == {"phase", "message"}
    diagnostic = Diagnostic(phase="syntax", message="Could not parse")
    assert diagnostic.phase == "syntax" and diagnostic.message == "Could not parse"
    assert len(diagnostic) == 2
    assert diagnostic["phase"] == "syntax" and diagnostic["message"] == "Could not parse"
    assert set(list(diagnostic)) == {"phase", "message"}
    assert diagnostic.is_sparse == False
    assert repr(diagnostic) == "Diagnostic(phase='syntax', message='Could not parse')"



# Generated at 2022-06-24 11:09:47.085768
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    instance = SchemaDefinitions()
    value = instance.__iter__()
    assert isinstance(value, typing.Iterator)


# Generated at 2022-06-24 11:09:48.943724
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Module-level docstrings are not valid arguments to the test function
    # docstring
    # TODO: write the unit test

    pass

# Generated at 2022-06-24 11:09:55.298344
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema()) == "Schema()"
    assert repr(Schema(foo=3)) == "Schema(foo=3)"
    assert repr(Schema(foo=3, bar=4.0)) == "Schema(bar=4.0, foo=3)"
    assert repr(Schema(foo=3, bar=4.0)) == "Schema(bar=4.0, foo=3)"
    return

