

# Generated at 2022-06-24 10:59:56.260778
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    definitions["child"] = ChildDefinition = Schema(String(), definitions=definitions)
    definitions["parent"] = ParentDefinition = Schema(Reference("child"), definitions=definitions)
    assert definitions["child"] == ChildDefinition
    assert definitions["parent"] == ParentDefinition
    assert ChildDefinition.fields.items() == {'value':String()}.items()
    assert ParentDefinition.fields.items() == {'to': Reference("child")}.items()
    assert ChildDefinition.fields['value'] == String()
    assert ParentDefinition.fields['to'].target_string == 'child'

# Generated at 2022-06-24 11:00:07.136548
# Unit test for constructor of class Reference
def test_Reference():
    # Type error assertion
    try:
        References
    except NameError:
        flag = True
    assert flag
    # Type error assertion
    try:
        References
    except UnboundLocalError:
        flag = True
    assert flag
    # Type error assertion
    try:
        References = Reference()
    except AssertionError:
        flag = True
    assert flag
    # Type error assertion
    try:
        References = Reference("string")
    except AssertionError:
        flag = True
    assert flag
    # Type error assertion
    try:
        References = Reference(Schema)
    except AssertionError:
        flag = True
    assert flag
    # Type error assertion
    try:
        References = Reference(to="string")
    except AssertionError:
        flag = True
    assert flag


# Generated at 2022-06-24 11:00:12.503585
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class DummySchema1(Schema):
        field_0 = Field()
        field_1 = Field()
        field_2 = Field()
    dummy_schema_1 = DummySchema1({'field_0': 0, 'field_1': 1, 'field_2': 2})
    try:
        assert len(dummy_schema_1) == 3
    except AssertionError:
        raise AssertionError('AssertionError raised in test_Schema___len__')


# Generated at 2022-06-24 11:00:17.318136
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    class A(Schema, name="A"):
        a = Field()
    class B(Schema, name="B"):
        b = Field()
    definitions = SchemaDefinitions()
    definitions["A"] = A
    definitions["B"] = B
    assert set(definitions) == {"A", "B"}



# Generated at 2022-06-24 11:00:23.094565
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    args = ()
    kwargs = {}
    try:
        obj = SchemaDefinitions(*args, **kwargs)
    except Exception as e:
        print(f"Failed to instantiate SchemaDefinitions: {e}")
        return False
    try:
        len(obj)
    except Exception as e:
        print(f"call to __len__ failed: {e}")
        return False
    return True



# Generated at 2022-06-24 11:00:27.339910
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schemaDefinitions = SchemaDefinitions()
    assert len(schemaDefinitions) == 0
    schemaDefinitions['key'] = 'value'
    assert len(schemaDefinitions) == 1
    assert schemaDefinitions['key'] == 'value'
    del schemaDefinitions['key']
    assert len(schemaDefinitions) == 0


# Generated at 2022-06-24 11:00:32.831558
# Unit test for function set_definitions
def test_set_definitions():
    """
    Test set_definitions which sets the reference definition from the given definition
    """
    class User(Schema):
        name = String()
        age = Integer()

    definitions = SchemaDefinitions()
    user_def = Reference("User", definitions=definitions)
    set_definitions(user_def, definitions)
    assert definitions['User'] == User

# Generated at 2022-06-24 11:00:40.019918
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class A(Schema, metaclass=SchemaMetaclass):
        a = Field(type_name="string")
        b = Field(type_name="string")
        c = Field(type_name="number")
    assert (A.fields["a"] == Field(type_name="string"))
    assert (A.fields["b"] == Field(type_name="string"))
    assert (A.fields["c"] == Field(type_name="number"))


# Generated at 2022-06-24 11:00:45.414304
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    import typesystem

    def test_1():
        definitions = typesystem.SchemaDefinitions()
        assert len(definitions) == 0
        definitions["a"] = "abcd"
        assert len(definitions) == 1
        del definitions["a"]
        assert len(definitions) == 0

    test_1()


# Generated at 2022-06-24 11:00:46.295138
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    assert(False)


# Generated at 2022-06-24 11:00:46.920896
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions() == {}


# Generated at 2022-06-24 11:00:50.044343
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Create a instance of class SchemaDefinitions
    obj1 = SchemaDefinitions()
    assert isinstance(obj1, SchemaDefinitions)
    assert obj1.__class__.__name__ == 'SchemaDefinitions'
    
    # Check the class of the output of the __iter__ method
    assert isinstance(obj1.__iter__(), typing.Iterator)

# Generated at 2022-06-24 11:00:58.064491
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema1(Schema):
        a = 1
        b = 2
        c = 3

    s = TestSchema1()

    assert [key for key in s] == []

    s.a = 1
    s.b = 2
    s.c = 3

    assert [key for key in s] == ["a", "b", "c"]



# Generated at 2022-06-24 11:01:00.793203
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    assert len(s) == 0
    assert type(s) is SchemaDefinitions
    assert not hasattr(s, "key")
    assert not hasattr(s, "value")


# Generated at 2022-06-24 11:01:05.441498
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    #  Test the method with a field with no definitions set
    field = Reference("test")

    #  Test the method with a valid field and definition
    definitions = SchemaDefinitions()
    set_definitions(field, definitions)

    #  Test the method with a field with definitions already set
    field = Reference("test")
    set_definitions(field, definitions)

    try:
        set_definitions(field, definitions)
        assert False, "Expected exception."
    except AssertionError as e:
        pass


# Generated at 2022-06-24 11:01:10.178370
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    serialize_called = 0
    class _Reference(Reference):

        def serialize(self, obj: typing.Any) -> typing.Any:
            nonlocal serialize_called
            serialize_called += 1
            return super().serialize(obj)
    
    r = _Reference("schema_name")
    r.serialize(None)
    if serialize_called != 1:
        raise AssertionError()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 11:01:13.729134
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions(Foo=Foo)

    foo = Foo.fields["foo"]
    assert foo.definitions == None
    set_definitions(foo, definitions)
    assert foo.definitions == definitions
    assert foo.target == Foo

# Generated at 2022-06-24 11:01:26.141746
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    import unittest
    import typesystem
    from unittest import mock
    class Mock(unittest.TestCase):
        def __init__(self):
            self.schema_definitions = typesystem.SchemaDefinitions()
        def test_delitem_1(self):
            '''SchemaDefinitions.__delitem__ should delete the element with the given key'''
            key = "schema1"
            value = "value"
            self.schema_definitions[key] = value
            self.schema_definitions[key] = value
            self.schema_definitions[key] = value
            del self.schema_definitions[key]
            mock_method = mock.Mock()
            mock_method(self.schema_definitions)
            mock_method.assert_called_once

# Generated at 2022-06-24 11:01:28.948707
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Set up test data
    item = dict()

    # Invoke method
    result = SchemaDefinitions(item)

    # Check result
    assert isinstance(result, dict)



# Generated at 2022-06-24 11:01:34.085941
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["key_1"] = 1
    assert schema_definitions["key_1"] == 1

    with pytest.raises(AssertionError):
        schema_definitions["key_1"] = 2

# Generated at 2022-06-24 11:01:35.759912
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert Schema.__bases__ is (Mapping, )
    assert isinstance(Schema.fields, dict)


# Generated at 2022-06-24 11:01:46.114094
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class A(Schema):
        a = String(max_length=10)
        b = Integer()

    assert A.fields == {"a": String(max_length=10), "b": Integer()}
    assert A(b=2, a="1234").b == 2
    assert A(b=2, a="1234") == A(dict(b=2, a="1234"))
    assert A(b=2, a="1234").serialize() == {"a": "1234", "b": 2}
    assert A(b=2, a="1234").validate() == A(b=2, a="1234")

# Generated at 2022-06-24 11:01:50.393563
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field: typing.Any = None
    schema1 = TestSchema(field=1)
    schema2 = TestSchema(field=1)
    assert schema1 == schema2


# Generated at 2022-06-24 11:01:57.970776
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference(to='Foo')
    assert reference.to == 'Foo'
    assert reference.definitions is None
    assert reference.target_string == 'Foo'
    reference._target_string = 'Bar'
    assert reference.target_string == 'Bar'
    reference._target = 123
    assert reference.target == 123


# Generated at 2022-06-24 11:02:00.216637
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = int



# Generated at 2022-06-24 11:02:06.913234
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    del definitions[str()]
    assert isinstance(definitions, typing.Mapping)
    del definitions[str()]
    def test():
        definitions.__setitem__(str(), object())
    test()
    def test():
        definitions.__setitem__(str(), object())
    test()
    definitions.__setitem__(str(), object())
    assert len(definitions) == 1
    assert isinstance(definitions, typing.Iterable)
    assert len(definitions) == 1


# Generated at 2022-06-24 11:02:12.367872
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Create an instance of class Schema
    schema_instance = Schema()

    # Test method __getitem__ of class Schema
    schema_instance.__getitem__()


# Generated at 2022-06-24 11:02:17.637933
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    
    __tracebackhide__ = True

    import types

    class Planet(Schema):
        name = Field()

    planet = Planet(name="Earth")
    assert planet["name"] == "Earth"

    try:
        planet["missing"]
    except KeyError:
        __tracebackhide__ = False
    assert raise_or_pass(KeyError, exc_message='missing')



# Generated at 2022-06-24 11:02:22.609541
# Unit test for constructor of class Schema
def test_Schema():
    class AddressSchema(Schema):
        street_address = String()
        city = String()
        state = String()
        zip_code = String()

    address = AddressSchema(street_address="220 Broadway NYC", city="New York City", state="NY", zip_code="10038")
    assert address.street_address == "220 Broadway NYC"
    assert address.city == "New York City"
    assert address.state == "NY"
    assert address.zip_code == "10038"
    

# Generated at 2022-06-24 11:02:26.446181
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=50)
        age = Integer(required=False)
    person = Person(name="John", age=None)

# Generated at 2022-06-24 11:02:31.566822
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Simple(Schema):
        test = bool

    class Complex(Schema):
        test1 = int
        test2 = bool

    simple = Simple(test=True)
    assert repr(simple) == "Simple(test=True)"

    complex = Complex(test1=1)
    assert repr(complex) == "Complex(test1=1) [sparse]"

# Generated at 2022-06-24 11:02:37.245473
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        id = Integer()
        name = String()

    class Profile(Schema):
        owner = Reference(to=User)

    data = {'owner': {'id': 42, 'name': 'John'}}
    result = Profile.validate(data)
    print("result: ", result)
    assert result.owner == User(id=42, name='John')



# Generated at 2022-06-24 11:02:41.351632
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(str).serialize("Hello") == "Hello"
    assert Reference(int).serialize(1) == 1
    assert Reference(int).serialize(1.0) == 1
    assert Reference(float).serialize(1.0) == 1.0
    assert Reference(Schema).serialize(Schema()) == dict(obj)

# Generated at 2022-06-24 11:02:43.038926
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    a = SchemaDefinitions({0: "1"})
    assert("1" == a.__getitem__(0))


# Generated at 2022-06-24 11:02:44.045127
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert(len(sd) == 0)

# Generated at 2022-06-24 11:02:47.532218
# Unit test for constructor of class Schema
def test_Schema():
    class Test(Schema):
        id = Field(required=True)
        type = Field(required=True)
    test = {
        'id': 1,
        'type': 'test'
    }
    ts = Test(test)
    assert isinstance(ts, Test)
    assert ts.id == 1
    assert ts.type == 'test'

# Generated at 2022-06-24 11:02:54.536298
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        b = Reference("C")
    
    class C(Schema):
        d = String()
    
    class E(Schema):
        f = Array(String())
    
    class B(Schema):
        c = Array(Array(Reference("A")))
        d = Object(
            properties={"a": Reference("A"), "c": Reference("C")}
        )
    
    class D(Schema):
        a = Reference("A")
        b = Reference("B")
        e = Reference("E")
    
    schema_defs = SchemaDefinitions()
    set_definitions(D.fields["a"], schema_defs)
    assert D.fields["a"].to == "A"
    set_definitions(D.fields["b"], schema_defs)

# Generated at 2022-06-24 11:02:56.340266
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    obj = SchemaDefinitions()
    raise NotImplementedError()


# Generated at 2022-06-24 11:03:00.344617
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Given a Schema class with Fields
    class Person(Schema):
        name = String()
    assert Person.fields == {'name': String()}
    # Then the Schema should have the same fields
    assert Person.name == String()

SchemaMetaclass.__new__(SchemaMetaclass, 'Person', (Schema,), {'name': String()})


# Generated at 2022-06-24 11:03:05.615747
# Unit test for constructor of class Schema
def test_Schema():
    # Test for constructor with no arguments.
    class Person(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string")
        age = Field(type="integer")
    p = Person()

    # Test for constructor with one argument.
    p1 = Person({"first_name": "Asjad", "age": 24})

    # Test for constructor with two arguments.
    p2 = Person(first_name="Asjad", last_name="Naqvi", age=24)


# Generated at 2022-06-24 11:03:07.819546
# Unit test for constructor of class Reference
def test_Reference():
    # initialization
    ref_instance = Reference(to=1)

    assert(ref_instance.to == 1)


# Unit tests for method validate of class Reference

# Generated at 2022-06-24 11:03:09.294006
# Unit test for method validate of class Reference
def test_Reference_validate():
	assert Reference('notschema').validate(()).__repr__() == "()"

#Unit test for method serialize of class Reference

# Generated at 2022-06-24 11:03:16.793303
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from json import loads
    from yaml import load
    schema = Schema(loads(
        '''
        {
          "name": "Schema",
          "type": "object",
          "properties": {
            "name": {
              "type": "string",
              "minLength": 1
            },
            "age": {
              "type": "integer",
              "minimum": 1
            },
            "married": {
              "type": "boolean"
            }
          }
        }
        '''
    ))
    _input = dict(
        name='Schema',
        age=20,
        married=True,
    )
    value, error = schema.validate_or_error(_input)
    assert error is None
    assert len(value) == 3

# Generated at 2022-06-24 11:03:17.611430
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    pass


# Generated at 2022-06-24 11:03:18.910840
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-24 11:03:27.658575
# Unit test for constructor of class Schema
def test_Schema():
    import typesystem
    from typesystem import fields

    class User(typesystem.Schema):
        id = fields.String()
        email = fields.Email()
        name = fields.String()
        age = fields.Integer()

    user = User(id="123", name="John")
    assert user.id == "123"
    assert user.name == "John"
    assert user.email is None
    assert user.age is None

    user = User({"id": "123", "name": "John"})
    assert user.id == "123"
    assert user.name == "John"
    assert user.email is None
    assert user.age is None

    class User(typesystem.Schema):
        id = fields.String()
        email = fields.Email()
        name = fields.String()
        age = fields

# Generated at 2022-06-24 11:03:28.399021
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass

# Generated at 2022-06-24 11:03:34.337741
# Unit test for method validate of class Reference
def test_Reference_validate():
    class ObjetTest:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    obj_test = ObjetTest(1, 2, 3)

    reference = Reference(to="test")
    reference.target = ObjetTest
    result = reference.validate(obj_test)
    assert isinstance(result, ObjetTest)
    assert result.a == 1
    assert result.b == 2
    assert result.c == 3

#Sprint 3

# Generated at 2022-06-24 11:03:35.498625
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    assert False, "Unimplemented"



# Generated at 2022-06-24 11:03:38.595274
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.types import Integer
    from typesystem import validate
    class A(Schema):
        a=Integer(title='A')
    referencia=Reference(to=A)
    result=referencia.validate({'a':1})
    result2=A(a=1)
    assert result == result2


# Generated at 2022-06-24 11:03:41.473214
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()

    field = Field(required=True)
    definitions["Test"] = field

    assert definitions["Test"] == field

# Generated at 2022-06-24 11:03:46.769130
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import Schema, fields

    class Person(Schema):
        name = fields.String()
        age = fields.Integer(min_value=0, max_value=150)

    class Library(Schema):
        title = fields.String()
        author = Reference(Person)

    library = Library(title="The trial", author=Person(name="Franz Kafka", age="40"))
    print(library.author)


if __name__ == "__main__":
    test_Reference_validate()

# Generated at 2022-06-24 11:03:57.884770
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field1 = Field(format = "test")

    field = Reference(to = TestSchema)

    assert field.validate(None, strict = False) is None
    assert field.validate(None, strict = True) is None
    assert field.validate(TestSchema(field1 = 1), strict = False).field1 == 1
    assert field.validate(TestSchema(field1 = 1), strict = True).field1 == 1
    assert field.validate({"field1": 1}, strict = False) == {"field1": 1}
    assert field.validate({"field1": 1}, strict = True) == {"field1": 1}

    field = Reference(to = TestSchema, allow_null = False)

    assert field.validate(None, strict = False) is None

# Generated at 2022-06-24 11:03:58.776028
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass

# Generated at 2022-06-24 11:04:04.015834
# Unit test for method validate of class Reference
def test_Reference_validate():

    from typesystem import String

    class User(Schema):
        username = String()
        avatar_url = String()

    class Comment(Schema):
        text = String()
        author = Reference(User)

    comment = Comment.validate({"text": "Hello world!", "author": {"username": "Nicholas"}}, strict=True)
    assert comment.author.username == "Nicholas"
    assert comment.author.avatar_url is None


# Generated at 2022-06-24 11:04:13.134300
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import pytest
    from typesystem import Schema, fields
    from typesystem import structures
    from typesystem import typedefs

    import pytest

    # Sections below represent test cases
    # each test case is initiated by the keyword `case`

    # section: case-1.1
    # Case 1.1: Positive
    # Given:   valid object of type Schema
    # When: compare them
    # Then: return true

# Generated at 2022-06-24 11:04:21.223236
# Unit test for function set_definitions
def test_set_definitions():
    # Create a dummy object that looks like a Field object
    class Dummy(Field):
        pass

    # Create a dummy field
    ref = Reference("Person", definitions = {})

    # Test with a basic field
    dummy = Dummy()
    set_definitions(dummy, None)
    # This generally shouldn't be called, so the field shouldn't be changed
    assert dummy._creation_counter == 0

    # Test with an array field
    array1 = Array()
    assert array1.items is None
    set_definitions(array1, None)
    assert array1.items is None

    array2 = Array(items = dummy)
    assert array2.items is not None
    set_definitions(array2, None)
    assert array2.items is not None


# Generated at 2022-06-24 11:04:27.297504
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Address(Schema):
        street = Field(str)

    class Person(Schema):
        name = Field(str)
        address = Reference(Address)

    jon = Person(name="Jon Snow", address=Address(street="Winterfell"))
    assert jon.address.street == "Winterfell"
    assert jon.serialize() == {"name": "Jon Snow", "address": {"street": "Winterfell"}}




# Generated at 2022-06-24 11:04:29.537667
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    sd = SchemaDefinitions()
    assert sd.__getitem__('a') == dict()
    assert sd.__getitem__('test') == dict()


# Generated at 2022-06-24 11:04:31.804070
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert issubclass(Schema, Mapping)
    assert issubclass(Schema, metaclass=SchemaMetaclass)



# Generated at 2022-06-24 11:04:35.534025
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    test = []
    def test_inner():
        class One(Schema):
            foo = String()
            bar = String()

        if (sorted(list(SchemaDefinitions({'One': One}))) == ['One']):
            test.append(True)
        else:
            test.append(False)



# Generated at 2022-06-24 11:04:38.387194
# Unit test for method validate of class Reference
def test_Reference_validate():
    class NumberSchema(Schema):
        integer = Integer()
    schema = Reference(NumberSchema)
    value = schema.validate({"integer": 1})
    assert value.integer == 1

# Generated at 2022-06-24 11:04:42.266530
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    obj = SchemaDefinitions()
    obj["key"] = "value"
    with pytest.raises(AssertionError) as e_info:
        obj["key"] = "value2"
    assert str(e_info.value) == r"Definition for 'key' has already been set."


# Generated at 2022-06-24 11:04:49.514529
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    assert len(TestSchema(a="aa")) is 1
    assert len(TestSchema(a="aa", b="bb")) is 2
    assert len(TestSchema(a="aa", b="bb", c="cc")) is 3


# Generated at 2022-06-24 11:04:57.755004
# Unit test for method __len__ of class SchemaDefinitions

# Generated at 2022-06-24 11:05:03.809064
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['a'] = 'A'
    definitions['b'] = 'B'
    assert 'a' in definitions
    assert 'b' in definitions
    del definitions['a']
    assert 'a' not in definitions
    assert 'b' in definitions
    del definitions['b']
    assert 'a' not in definitions
    assert 'b' not in definitions



# Generated at 2022-06-24 11:05:12.910965
# Unit test for constructor of class Schema
def test_Schema():
    import pytest
    from typesystem.fields import Boolean, Integer, String

    # Test title
    with pytest.raises(TypeError, match='is an invalid keyword argument for MySchema\\(\\).'):
        MySchema(foo='bar')

    with pytest.raises(TypeError, match='must be initialized with a dictionary.'):
        MySchema([])

    # Test: Allow initialization from dictionary
    schema = MySchema({'a': 1, 'b': 'a'})
    assert schema.a == 1
    assert schema.b == 'a'
    assert schema == MySchema(a=1, b='a')

    # Test: Allow initialization from another schema instance
    schema = MySchema(MySchema(a=1, b='a'))
    assert schema.a == 1

# Generated at 2022-06-24 11:05:22.808601
# Unit test for constructor of class Reference
def test_Reference():
    class NetApp:
        field_1 = String()
        field_2 = String()
    class NetApp_Ref(NetApp, metaclass=SchemaMetaclass):
        pass
    class MySchema(Schema):
        name = String()
        reference = Reference(to=NetApp_Ref)

    expected_NetApp_Ref = NetApp_Ref(field_1=None, field_2=None)
    expected_MySchema = MySchema(name=None, reference=expected_NetApp_Ref)

    # Test Reference.validate()
    actual_MySchema = MySchema(name=None, reference={})
    expected_MySchema = MySchema(name=None, reference=expected_NetApp_Ref)
    assert actual_MySchema == expected_MySchema

    # Test Reference.valid

# Generated at 2022-06-24 11:05:33.428933
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class A(Schema):
        key1 = String()
        key2 = String()

    a = A()
    assert(a.key1 == None)
    assert(a.key2 == None)
    a = A({"key1" : "val1"})
    assert(a.key1 == "val1")
    assert(a.key2 == None)
    a = A(A({"key1" : "val1"}))
    assert(a.key1 == "val1")
    assert(a.key2 == None)
    a = A(key1 = "val1")
    assert(a.key1 == "val1")
    assert(a.key2 == None)
    a = A(key2 = "val2")
    assert(a.key1 == None)

# Generated at 2022-06-24 11:05:36.769403
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class FooSchema(Schema):
        foo = Field(type="string")
        bar = Field(type="string")
        baz = Field(type="string")

    foo = FooSchema(foo="foo", bar="bar")
    return foo.__iter__()


# Generated at 2022-06-24 11:05:39.974410
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema1(Schema):
        field1 = String()

    schema = TestSchema1()
    assert len(schema) == 0

    schema = TestSchema1({"field1": "hello"})
    assert len(schema) == 1


# Generated at 2022-06-24 11:05:41.123998
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference('to', definitions={'to': 0})
    print(ref._target)

# Generated at 2022-06-24 11:05:49.096423
# Unit test for constructor of class Reference
def test_Reference():
    # given
    x = Reference("Test") # type: ignore
    assert x.to == "Test"
    assert x.definitions is None
    assert not x.allow_null
    assert not x.required
    assert x.default == None
    assert x.description is None
    assert x.example is None
    assert x.error_messages == {'null': 'May not be null.'}
    assert x._creation_counter == 0
    assert x.validator is None
    assert x._target_string == "Test"
    assert x.target == None


# Generated at 2022-06-24 11:05:50.439120
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def1 = SchemaDefinitions()
    assert(isinstance(def1, MutableMapping))

# Generated at 2022-06-24 11:05:54.890064
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name1 = Field(type=str)
        name2 = Field(type=str)

    assert len(Person({'name1': 'test', 'name2': 'test2'})) == 2



# Generated at 2022-06-24 11:06:02.178601
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import Integer, String
    
    class Schema1(Schema):
        test_field = String(max_length=100)

    class Schema2(Schema):
        test_field = Reference(to=Schema1)

    test_obj = Schema2(test_field=Schema1(test_field='test input'))
    result = test_obj.test_field
    expected = Schema1(test_field='test input')
    assert result == expected
    assert test_obj.test_field.test_field == 'test input'

# Generated at 2022-06-24 11:06:08.668003
# Unit test for constructor of class Reference
def test_Reference():
    # Passes the null argument
    assert (Reference(null=True) == Reference(null=True))
    # Passes the additional_properties
    assert (Reference(to="overridden", additional_properties=False) == Reference(to="overridden", additional_properties=False))
    # Passes the description
    assert (Reference(to="overridden", description="test description") == Reference(to="overridden", description="test description"))
    # Passes the to
    assert (Reference(to="overridden") == Reference(to="overridden"))
    # Passes the validators
    assert (Reference(to="overridden", validators=[None]) == Reference(to="overridden", validators=[None]))
    # Passes the validators_kwargs

# Generated at 2022-06-24 11:06:14.524771
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A(Schema):
        a = Field()

    class B(Schema):
        b = Reference(to=A, allow_null=False)

    class C(Schema):
        c = Reference(to=B)

    a = A(a="test")
    b = B(b=a)
    c = C(c=b)

    try:
        C.validate(c)
    except Exception:
        raise AssertionError("Validate did not succeed!")

# Generated at 2022-06-24 11:06:17.305066
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions['k1'] = 1
    definitions['k2'] = 2
    assert len(definitions) == 2
    del definitions['k2']
    assert len(definitions) == 1



# Generated at 2022-06-24 11:06:25.856739
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions()
    extended_iterator = enumerate(schema_definitions)
    extended_dict = dict(schema_definitions)
    assert isinstance(extended_iterator, enumerate)
    assert isinstance(extended_dict, dict)
    items = {"a" : 0}
    schema_definitions["a"] = 0
    assert schema_definitions["a"] == 0
    assert items["a"] == 0
    assert schema_definitions._definitions["a"] == 0


# Generated at 2022-06-24 11:06:34.530409
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    dict1 = {"a": "a"}
    dict2 = {"b": {"b": "b", "c": "c"}}
    test_defintions = SchemaDefinitions(dict1)
    assert(test_defintions["a"] == dict1["a"])
    test_defintions["b"] = dict2["b"]
    assert(test_defintions["b"] == dict2["b"])
    del test_defintions["b"]
    assert(test_defintions == dict1)
    test_defintions.clear()
    assert(test_defintions == {})
    assert(len(test_defintions) == 0)


# Generated at 2022-06-24 11:06:39.919752
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field_1 = Field()
        field_2 = Field()
        field_3 = Field()
    schema = TestSchema(field_2=2, field_3=3)
    result = list(schema)
    assert result == ['field_2', 'field_3']

# Generated at 2022-06-24 11:06:44.821461
# Unit test for constructor of class Schema
def test_Schema():
    class ValueSchema(Schema):
        name = Field(str)
        age = Field(int)

    schema = ValueSchema(name="Sam", age="21")
    assert isinstance(schema, Schema)
    assert isinstance(schema, ValueSchema)
    assert schema.name == "Sam"
    assert schema.age == 21


# Generated at 2022-06-24 11:06:49.586415
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # define variables
    class_name = 'SchemaDefinitions'
    definitions = {}
    key = '{{id}}'
    value = {}
    # set-up
    SchemaDefinitions_object = SchemaDefinitions(definitions)
    # assert
    assert (SchemaDefinitions_object.__getitem__(key) == value)


# Generated at 2022-06-24 11:06:52.832235
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0
    assert len(Schema({"x": "foo", "y": "bar", "z": "baz"})) == 3
    assert len(Schema(x="foo", y="bar", z="baz")) == 3


# Generated at 2022-06-24 11:07:01.236162
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from typesystem.fields import String

    definitions = SchemaDefinitions()
    class Foo(Schema):
        foo = String()

    class Bar(Schema):
        bar = String()
        foo = Reference("Foo", definitions=definitions)

    # This is the test
    f = Foo()
    b = Bar(bar="baz")
    assert b.foo is None
    definitions["Foo"] = f
    assert b.foo is f

Schema.__module__ = __name__

# Generated at 2022-06-24 11:07:03.948409
# Unit test for constructor of class Reference
def test_Reference():
    x = Reference('x')
    # assert x.validate(None) == dict(None)
    assert x.to == 'x'
    print('Test passed!')

test_Reference()

# Generated at 2022-06-24 11:07:16.715900
# Unit test for function set_definitions
def test_set_definitions():

    class MySchema(Schema):
        a = Reference("a")
        b = Reference("b")

    definitions = SchemaDefinitions()
    set_definitions(MySchema.make_validator(), definitions)
    assert isinstance(MySchema.a, Reference)
    assert MySchema.a.definitions == definitions
    assert MySchema.b.definitions == definitions

    class MySchema2(MySchema):
        c = Reference("c")

    set_definitions(MySchema2.make_validator(), definitions)
    assert isinstance(MySchema2.a, Reference)
    assert MySchema2.a.definitions == definitions
    assert MySchema2.b.definitions == definitions
    assert MySchema2.c.definitions == definitions

# Generated at 2022-06-24 11:07:17.888903
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions()
    assert obj is not None


# Generated at 2022-06-24 11:07:31.849227
# Unit test for constructor of class Schema
def test_Schema():
    import pytest
    a = object()
    b = object()
    c = object()
    class foo(Schema):
        field1 = Array()
        field2 = Array(items=Object())
        field3 = Array(items=[Object(), Object()])
        field4 = Array(items=Array())
        field5 = Array(items=[Object(), Array()])
        field7 = Array(items=Array())
        field8 = Array(items=[Array(), Array()])
        field9 = Object(properties={"field9": String()})
        field10 = Object(properties={"field10": String()})
        field11 = Object(properties={"field11": [String(), String()]})
        field12 = Object(properties={"field12": [String(), String()]})
        field13 = Reference("foo")


# Generated at 2022-06-24 11:07:35.240236
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    param = None
    ret = Schema.__len__(param)
    assert ret is None


# Generated at 2022-06-24 11:07:43.556482
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    class TestSchema(Schema):
        field1 = String()
    TestSchema.__setitem__('TestSchema', TestSchema)
    TestSchema_1 = TestSchema.make_validator()
    assert TestSchema_1.properties == {'field1': String()}
    assert TestSchema_1.required == ['field1']
    assert TestSchema_1.additional_properties == None
    assert TestSchema_1.allow_null == False
    assert TestSchema_1.definitions == {'TestSchema': TestSchema}


# Generated at 2022-06-24 11:07:46.769861
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    sd = SchemaDefinitions()
    sd['B'] = 2
    sd['A'] = 2
    sd['A'] = 2    
    sd.__delitem__('A')
    assert sd._definitions == {'B' : 2 }
    return True


# Generated at 2022-06-24 11:07:50.021707
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['key'] = 'value'
    del schema_definitions['key']


# Generated at 2022-06-24 11:07:58.137263
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    """
    Schema.__eq__:
        x = Schema(id=1, name="John Doe", age=30)
        y = Schema(name="Jane Doe", age=30)
        y.id = 1
        assert x == y
    """
    class Person(Schema):
        id: int
        name: str
        age: int

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:# pass
            super().__init__(*args, **kwargs)

        def __eq__(self, other: typing.Any) -> bool:
            if not isinstance(other, self.__class__):
                return False
            for key in self.fields.keys():
                if getattr(self, key) != getattr(other, key):
                    return False


# Generated at 2022-06-24 11:08:03.410042
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Foo(Schema):
        pass
    class CaseSchema(Schema):
        foo = Reference(to='Foo')
        definitions = SchemaDefinitions(
            Foo=Foo,
        )
    schema = CaseSchema.validate({'foo': {}})
    assert isinstance(schema.foo, Foo)


# Generated at 2022-06-24 11:08:06.995018
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a = Object(properties={"a": Object(properties={"a": Integer()})})
    assert list(iter(A())) == ["a"]


# Generated at 2022-06-24 11:08:13.869680
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    d = SchemaDefinitions(one=1, two=2)
    assert 1 == d["one"]
    assert 2 == d["two"]
    assert len(d) == 2
    d["three"] = 3
    assert 3 == d["three"]
    assert len(d) == 3
    del d["two"]
    assert len(d) == 2
    d[1] = "something"
    assert "something" == d[1]


# Generated at 2022-06-24 11:08:22.527551
# Unit test for function set_definitions
def test_set_definitions():
    class QuerySchema(Schema):
        name = Field(required=True)
        id = Reference("Person")
        age = Field(required=True, type=int)

    class PersonSchema(Schema):
        id = Field(required=True, type=str)
        name = Field(required=True, type=str)
        age = Field(required=True, type=int)

    class Query(QuerySchema):
        pass

    class Person(PersonSchema):
        pass

    definitions = SchemaDefinitions()

    set_definitions(QuerySchema.fields["id"], definitions)

    assert isinstance(QuerySchema.fields["id"].definitions, SchemaDefinitions)
    assert QuerySchema.fields["id"].definitions == definitions

# Generated at 2022-06-24 11:08:24.592549
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    definitions['test'] = 'testValue'

    assert set(iter(definitions)) == {'test'}


# Generated at 2022-06-24 11:08:33.145908
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        name = String()

    assert A.fields == {'name': String()}
    assert A(name='Brian').name == 'Brian'
    assert A.validate({'name':'Brian'}).name == 'Brian'
    assert A.validate({'name':'Brian'}) == A(name='Brian')
    assert A.validate({'name':'Brian'}) != A(name='brian')
    assert A.validate({'name':'Brian'}).is_sparse == False
    assert A.validate_or_error({'name':'Brian'}).value.name == 'Brian'
    assert A.validate_or_error({'name':'Brian'}).error == None

# Generated at 2022-06-24 11:08:34.705181
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def test_new():
        return SchemaDefinitions()
    assert test_new() is not None


# Generated at 2022-06-24 11:08:42.133399
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    someInstance = SchemaDefinitions()
    someInstance['key'] = 'value'
    try:
        someInstance['key']
    except Exception as e:
        print(e)
    else:
        assert True


# Generated at 2022-06-24 11:08:52.419694
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String, Integer

    class User(Schema):
        username = String()
        email = String(format="email")

    user = User(
        {
            "username": "joe_schmoe",
            "email": "joe.schmoe@example.com",
        }
    )
    assert isinstance(user, User)
    assert user.username == "joe_schmoe"
    assert user.email == "joe.schmoe@example.com"
    assert sorted(iter(user))
    assert user.is_sparse == False

    class User(Schema):
        username = String()
        email = String(format="email")

    # The following value will not be accepted because the username
    # key is not valid.
    # A KeyError is raised.
   

# Generated at 2022-06-24 11:08:54.180683
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    print("Testing: constructor of class SchemaMetaclass.\n")

# Generated at 2022-06-24 11:08:58.510892
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    to = Reference("Address")
    array = Array(of=to)
    obj = Object(properties={"array": array})
    defs = {"Address": Schema}
    set_definitions(obj, definitions)
    assert obj.properties["array"].items.definitions == definitions

# Generated at 2022-06-24 11:09:04.580094
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import String
    from typesystem.compat import Mapping

    class Person(Schema):
        name = String()

    class PubSchema(Schema):
        address = String()
        author = Reference(Person)

    peter = Person(name="Peter")
    address = "Nørrebrogade"
    pub = PubSchema(author=peter, address=address)
    pub.validate(pub) # reference to class Person is correct

# Generated at 2022-06-24 11:09:07.411790
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    SchemaDefinitions_ = SchemaDefinitions()
    SchemaDefinitions_['test'] = {}
    assert SchemaDefinitions_.__getitem__("test") == {}


# Generated at 2022-06-24 11:09:14.582674
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Test(Schema):
        a = Field()
        b = Field()
    a = Test(a=1, b=2)
    b = Test(a=1, b=2)
    assert a == b, "Expected a and b to be equal according to Schema's __eq__."
    a = Test(a=1,)
    b = Test(a=1, b=2)
    assert a != b, "Expected a and b to be unequal according to Schema's __eq__."
    c = Test(a=1, b=2)
    d = Test(a=1, b="2")
    assert c != d, "Expected c and d to be unequal according to Schema's __eq__."
    e = Test(a=1,)
    f = Test(a=1, b="2")


# Generated at 2022-06-24 11:09:18.527175
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        name = Field()

    assert len(TestSchema({'name': 'test'})) == 1
    assert len(TestSchema()) == 0


# Generated at 2022-06-24 11:09:19.788977
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass # TODO


# Generated at 2022-06-24 11:09:24.050356
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	from unittest import TestCase
	from typesystem import Schema, fields
	class MySchema(Schema):
		field = fields.Int()
	s = MySchema(field=1)
	assert len(s) == 1
	assert len(s.fields) == 1


# Generated at 2022-06-24 11:09:28.717011
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    a = SchemaDefinitions()
    assert len(a) == 0
    a["key"] = 1
    assert len(a) == 1
    assert a["key"] == 1
    a["key"] = 2
    assert a["key"] == 2
    assert len(a) == 1



# Generated at 2022-06-24 11:09:36.124408
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.mappings import Dict

    class Address(Schema):
        city = Field()
        country = Field()
        lines = Array(Field())
        postal_code = Field()
        region = Field()

    class Person(Schema):
        name = Field()
        addresses = Dict(Reference(to=Address))

    person = Person(
        {
            "name": "John Smith",
            "addresses": {
                "home": {
                    "lines": ["123 Main Street"],
                    "city": "Ottawa",
                    "region": "ON",
                    "postal_code": "K1K1K1",
                    "country": "Canada",
                }
            },
        }
    )

    # assert person.addresses['home'] == Address(
    #     lines=["123 Main Street"],


# Generated at 2022-06-24 11:09:44.570476
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class MySchema(Schema):
        name = Field(str)
        age = Field(int)
    my_schema = MySchema(name="Jack", age=20)
    assert my_schema["name"] == "Jack"
    try:
        assert my_schema["test"] == "test"
        return False
    except KeyError as e:
        return True
    return False


# Generated at 2022-06-24 11:09:54.592535
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema({"a": 1, "b": 2})
    assert s.a == 1
    assert s.b == 2
    # Test that the constructor returns the right type.
    assert type(s) == Schema

    # Test that the constructor also works with keyword arguments.
    s = Schema(a=1, b=2)
    assert s.a == 1
    assert s.b == 2
    assert type(s) == Schema

    # Test that the constructor also works with positional arguments.
    s = Schema({"a": 1, "b": 2})
    assert type(s) == Schema

    # Test that the constructor also works with a mixture of keyword arguments and
    # positional arguments.
    s = Schema({"a": 1}, b=2)
    assert s.a == 1