

# Generated at 2022-06-24 10:59:59.076591
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    # Create a Schema
    class PersonSchema(Schema):
        age = Field(int, default=None)
        name = Field(str, default=None)

    # Create a Reference
    person = Reference(PersonSchema)

    # Create an object of type Person
    person_obj = PersonSchema(age=19, name="John Doe")
    person_dict = dict(person_obj)

    # Check result of method serialize
    assert person.serialize(person_obj) == person_dict

# Generated at 2022-06-24 11:00:01.873624
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    result = Schema.__repr__()
    assert result is not None


# Generated at 2022-06-24 11:00:10.007573
# Unit test for constructor of class Reference
def test_Reference():
    class TestSchema(Schema):
        test: str

    class InnerSchema(Schema):
        inner_test: str

    class TestReference(Schema):
        inner: Reference[InnerSchema] = Reference[InnerSchema](to=InnerSchema)

    test_schema = TestSchema(test="hello world")
    inner_schema = InnerSchema(inner_test="inner hello world")
    test_reference = TestReference(inner=inner_schema)

    assert test_schema.test == "hello world"
    assert inner_schema.inner_test == "inner hello world"
    assert test_reference.inner == inner_schema

# Generated at 2022-06-24 11:00:13.777264
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    schema.fields = {'key': Field(validators=[])}
    schema.key = {
        'namespace': 'string',
        'name': 'string',
    }

    print(list(schema.__iter__()))
    assert schema.__iter__() == ['key']


# Generated at 2022-06-24 11:00:16.827388
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Person(name="Test", age=12, alive=True)) == "Person(name='Test', age=12, alive=True)"


# Generated at 2022-06-24 11:00:20.196599
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    s = SchemaDefinitions({'a':1})
    assert type(s.__iter__()) == types.GeneratorType
    assert next(s.__iter__()) == 'a'



# Generated at 2022-06-24 11:00:22.588058
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    s = SchemaDefinitions(a=1, b=2)

    assert len(s) == 2
    assert s == {'a': 1, 'b': 2}



# Generated at 2022-06-24 11:00:24.781932
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to=str).serialize({})=={}
    assert Reference(to=str).serialize(None)==None



# Generated at 2022-06-24 11:00:28.317889
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import datetime

    class Order(Schema):
        id = Field(type=int)
        date = Field(type=datetime.date)

    order = Order(id=15, date=datetime.date(2016, 6, 16))
    assert order["id"] == 15
    assert order["date"] == "2016-06-16"

# Generated at 2022-06-24 11:00:39.987936
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # test_Schema___len__#1
    #   Validate that when a schema is created with all attributes,
    # its length is the number of fields.
    class MySchema(Schema):
        foo = String()
        bar = String()
    assert len(MySchema(foo="foo", bar="bar")) == 2

    # test_Schema___len__#2
    #   Validate that when a schema is sparsely populated, its length
    # is the count of its populated fields.
    assert len(MySchema(bar="bar")) == 1

    # test_Schema___len__#3
    #   Validate that when a schema is not sparsely populated, its length
    # is the count of its fields.
    assert len(MySchema(foo="foo")) == 2


# Generated at 2022-06-24 11:00:42.903007
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    d = SchemaDefinitions()
    assert 0 == len(d)
    d['aa']=1
    assert 1 == len(d)

# Generated at 2022-06-24 11:00:50.682927
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    def get_SchemaDefinitions():
        sd = SchemaDefinitions()
        sd.__setitem__('one',1)
        sd.__setitem__('two',2)
        sd.__setitem__('three',3)
        return sd
    sd = get_SchemaDefinitions()
    sd.__delitem__('one')
    assert len(sd) == 2
    del sd['three']
    assert len(sd) == 1
    #if an exception is thrown, then the test fails
    #we expect an exception to be thrown for the following call
    sd.__delitem__('not existing')



# Generated at 2022-06-24 11:01:01.557985
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference.__init__  # check if the method __init__ is defined
    assert type(Reference.__init__) == types.MethodType # check if the type of the object is a method
    assert len(inspect.getfullargspec(Reference.__init__).args) == 3 # check the number of arguments
    # Check the number of annotations
    assert len(inspect.getfullargspec(Reference.__init__).annotations) == 3 
    assert inspect.getfullargspec(Reference.__init__).annotations['self'] == Reference  # check if the annotation of variable self is correct
    assert inspect.getfullargspec(Reference.__init__).annotations['to'] == typing.Union[str, typing.Type[Schema]] # check if the annotation of variable to is correct

# Generated at 2022-06-24 11:01:06.046114
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class ExampleSchema(Schema):
        name = types.String()

    my_schema = ExampleSchema.validate({"name": "David"})
    assert my_schema["name"] == "David"



# Generated at 2022-06-24 11:01:10.712781
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    obj = SchemaDefinitions("en_US", "en_GB", "ch_ZH")
    result = obj.__iter__()
    assert result == ["en_US", "en_GB", "ch_ZH"]


# Generated at 2022-06-24 11:01:13.550353
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    ceb7e1eac454a8a2420c6be2de4c4f4d = SchemaDefinitions()
    ceb7e1eac454a8a2420c6be2de4c4f4d['key'] = 'value'
    assert ceb7e1eac454a8a2420c6be2de4c4f4d['key'] == 'value'

# Generated at 2022-06-24 11:01:17.602302
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    _fields = {}
    assert SchemaMetaclass.__new__(SchemaMetaclass, "name", "bases", "attrs", "definitions") == Schema

# Generated at 2022-06-24 11:01:23.943303
# Unit test for function set_definitions
def test_set_definitions():
    A = Field()
    B = Field(B=A)

    class C(Schema):
        a = A
        b = B

    defs = SchemaDefinitions()
    set_definitions(C, defs)

    assert defs["C"] == C
    assert C.a.definitions == defs
    assert C.b.B.definitions == defs

# Generated at 2022-06-24 11:01:26.141204
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    assert [i for i in definitions] == []


# Generated at 2022-06-24 11:01:27.848906
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSerialize(Schema):
        name = Field()

    t = TestSerialize(name="toto")
    assert t.name == "toto"
    assert t["name"] == "toto"



# Generated at 2022-06-24 11:01:38.716560
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    print("\nTest method __iter__ of class SchemaDefinitions\n")
    fields = {
        "name": String(min_length=1),
        "age": Integer(minimum=1, maximum=99),
        "income": Float(minimum=0.0),
        "is_active": Boolean(),
    }
    name = 'IncomePerson'
    definitions = SchemaDefinitions()
    IncomePerson = SchemaMetaclass.__new__(SchemaMetaclass, name, (), fields, definitions)
    print("\n")
    print("After declare IncomePerson, the definitions are:")
    print("Declare iterator by iter()")
    print("* the iterator of the definitions are:")
    it = iter(definitions)
    print("* the first item of iterator is:")
    print(next(it))


# Generated at 2022-06-24 11:01:40.853789
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_dic = SchemaDefinitions()
    schema_dic["Test"] = 'abc'
    assert schema_dic["Test"] == 'abc'


# Generated at 2022-06-24 11:01:50.083244
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert isinstance(SchemaMetaclass, type)
    assert isinstance(SchemaMetaclass('test_SchemaMetaclass', 'test_SchemaMetaclass1', 'test_SchemaMetaclass2', 'test_SchemaMetaclass3', 'test_SchemaMetaclass4'), type)


# Generated at 2022-06-24 11:01:54.779216
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Simple(Schema):
        field = Field()

    assert repr(Simple()) == "Simple()"

    assert repr(Simple({"field": None})) == "Simple(field=None)"

    assert repr(Simple(Simple({"field": None}))) == "Simple(field=None)"


# Generated at 2022-06-24 11:02:01.181840
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import pytest
    _definitions = SchemaDefinitions()
    _definitions["key1"] = "value1"
    _definitions["key2"] = "value2"
    val = _definitions.__iter__()
    sol = ["key1", "key2"]
    assert all([e == s for e, s in zip(list(val), sol)])


# Generated at 2022-06-24 11:02:06.942113
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sut = SchemaDefinitions()
    assert (
        isinstance(sut, MutableMapping)
        and sut.__class__.__name__ == "SchemaDefinitions"
    )

    # test
    sut["key"] = "value"
    assert len(sut) == 1
    assert sut["key"] == "value"


# Generated at 2022-06-24 11:02:11.864980
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    serialize_res=Reference.serialize({"a":1})
    assert serialize_res == {"a":1}
    assert type(serialize_res) == dict


# Generated at 2022-06-24 11:02:20.145551
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.objects import BaseType, ValidationError
    from typesystem.primitives import Any, Integer, String

    class UserSchema(Schema):
        id = Integer(description="The user's unique ID.")
        name = String(description="The user's name")
        role = Integer(description="The user's role.")

    user = {"id": 1, "name": "Foo Bar"}
    user = UserSchema(user)
    assert user["id"] == 1
    assert user["name"] == "Foo Bar"
    assert user["role"] == None
    assert isinstance(user["role"], None)
    assert isinstance(user.id, int)
    assert isinstance(user.name, str)


# Generated at 2022-06-24 11:02:21.725223
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    def_1 = SchemaDefinitions()
    assert len(def_1) == 0


# Generated at 2022-06-24 11:02:26.963567
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Arrange
    fields = {"foo": 123, "bar": 456}
    schema = Schema(fields)

    # Act
    foo = schema["foo"]
    bar = schema["bar"]

    # Assert
    assert foo == 123
    assert bar == 456


# Generated at 2022-06-24 11:02:28.968422
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        pass
    instance = TestSchema()
    assert len(instance) == 0


# Generated at 2022-06-24 11:02:39.767014
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class OtherSchema(Schema):
        """This is the docstring for OtherSchema."""
        pass
    class AnotherSchema(Schema):
        """This is the docstring for AnotherSchema."""
        pass    
    class TestSchema(Schema):
        """This is the docstring for TestSchema."""
        one = OtherSchema.make_validator()
        two = another_schema = Reference("AnotherSchema", definitions={
            "AnotherSchema": AnotherSchema
        })
        three = Array(String())
        four = Integer(minimum=0)
    assert TestSchema.__doc__ == "This is the docstring for TestSchema."
    assert OtherSchema.__doc__ == "This is the docstring for OtherSchema."

# Generated at 2022-06-24 11:02:50.884127
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions['key1'] = 1
    assert len(definitions) == 1
    try:
        definitions['key1'] = 2
    except Exception as e:
        assert isinstance(e, AssertionError)
        assert str(e) == "Definition for 'key1' has already been set."
    else:
        raise AssertionError("Exception not raised")
    #
    tmp = definitions['key1']
    assert tmp == 1
    definitions['key2'] = 2
    assert len(definitions) == 2
    definitions['key3'] = 3
    assert len(definitions) == 3
    del definitions['key2']
    assert len(definitions) == 2
    tmp = []

# Generated at 2022-06-24 11:02:59.129555
# Unit test for function set_definitions
def test_set_definitions():
    class Test(Schema):
        foo = String()
        bar = Array(String())
        baz = Array(Array(String()))

    definitions = SchemaDefinitions()
    class_name = "Test"
    definitions[class_name] = Test

    for field in Test.fields.values():
        set_definitions(field, definitions)

test_set_definitions()

# Generated at 2022-06-24 11:02:59.572765
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    pass

# Generated at 2022-06-24 11:03:03.068393
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name=String(min_length=3)
        description=String()
    test_schema = TestSchema(name="Product", description="This is a product")
    assert test_schema.name=="Product"
    assert test_schema.description=="This is a product"


# Generated at 2022-06-24 11:03:04.805989
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    obj = SchemaDefinitions({'a': 1, 'b': 2})
    assert obj.__getitem__('a') == 1



# Generated at 2022-06-24 11:03:12.946105
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import json
    from typesystem.fields import Array, Number, Object, String

    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Number()
        children = Array(
            Object(
                properties={
                    "first_name": String(),
                    "last_name": String(),
                    "age": Number(),
                }
            )
        )

    # When called on a schema, it returns a list of property names
    expected = ["first_name", "last_name", "age", "children"]
    person = Person(first_name="John", last_name="Doe", age=42, children=[])
    assert list(person) == expected

    # When called on a schema instance, the returned list only includes those
    # properties which have been given a value in the constructor
    person

# Generated at 2022-06-24 11:03:15.718574
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    _dict = dict()
    test_obj = SchemaDefinitions(_dict)
    expected = ((_dict,), {}, None)
    actual = test_obj.__iter__()
    assert actual == expected


# Generated at 2022-06-24 11:03:26.420581
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    #import types

    class SchemaMetaclass(type):
        def __new__(cls, name, bases, attrs):
            print("Creating %s" % name)
            print("attrs type is %s" % type(attrs))
            fields = {}
            for key, value in attrs.items():
                if isinstance(value, Field):
                    fields[key] = value
                    attrs.pop(key)
            attrs['fields'] = fields
            new_type = type.__new__(cls, name, bases, attrs)
            return new_type

    class MetaClass(metaclass=SchemaMetaclass):
        field = String()

    class MetaClass2(MetaClass):
        field2 = String()

    print(MetaClass.fields)
    print(MetaClass2.fields)

# Generated at 2022-06-24 11:03:34.421970
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String
    from typesystem.types import DateTime

    class Example(Schema):
        date = DateTime(format='iso', strict=True)
        def __repr__(self):
            return 'ExampleSchema'

    example = Example(date='2017-01-01T12:00:00Z')

    assert repr(example) == 'ExampleSchema(date=datetime.datetime(2017, 1, 1, 12, 0, 0, tzinfo=tzutc()))'


# Generated at 2022-06-24 11:03:40.259239
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class User(Schema):
        id = Field(type="integer")
        first_name = Field(type="string")
        last_name = Field(type="string", default="Doe")
        tagline = Field(type="string")
        email = Field(type="string")

    assert len(User.fields) == 5
    assert len(User("invalid").fields) == 5
    assert User("invalid").id is None
    assert User("invalid").first_name is None
    assert User("invalid").last_name == "Doe"
    assert User("invalid").tagline is None
    assert User("invalid").email is None
    assert User("invalid").is_sparse is True
    user = User(id=123, first_name="John", email="john@doe.com")

# Generated at 2022-06-24 11:03:43.338745
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Doc(Schema):
        first_name = String()

    document = Doc(first_name="Foo")
    assert repr(document) == "Doc(first_name='Foo')"


# Generated at 2022-06-24 11:03:48.926205
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import typesystem
    schema = typesystem.Schema({'title': 'Hello', 'year': 2019})
    assert len(schema) == 2
test_Schema___len__.test = True



# Generated at 2022-06-24 11:03:54.457611
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='john', age=32)
    assert p == Person(name='john', age=32)
    assert list(p) == ['name', 'age']
    assert len(p) == 2


# Generated at 2022-06-24 11:03:56.606557
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    def _schema_definitions___delitem__(obj, key):
        obj.__delitem__(key)
        # Check schema definitions

# Generated at 2022-06-24 11:04:01.904602
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.types import String

    class PersonSchema(Schema):
        name = String()
        email = String()

    # Full schema.
    person = PersonSchema(name='Jordan', email='jordan@example.com')
    len(person) == 2

    # Sparse schema.
    person = PersonSchema(name='Jordan')
    len(person) == 1



# Generated at 2022-06-24 11:04:15.504607
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # Internal testing only
    class MyClass(Schema):
        propA = Field(required=True)
        propB = Field()
    class MyClassSubclass(MyClass):
        propC = Field()
        propB = Field()
    class MyClassSubclass2(MyClass):
        propB = Field()
    assert isinstance(MyClass.fields.get('propA'), Field)
    assert isinstance(MyClass.fields.get('propB'), Field)
    assert isinstance(MyClassSubclass.fields.get('propC'), Field)
    assert MyClassSubclass.fields.get('propB') != MyClass.fields.get('propB')
    assert MyClassSubclass.fields.get('propB') != MyClassSubclass2.fields.get('propB')

# Generated at 2022-06-24 11:04:16.687710
# Unit test for function set_definitions
def test_set_definitions():
    assert True

# Generated at 2022-06-24 11:04:22.162242
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str, default="")
        age = Field(int, default=0)

    person = Person(name="Rafael", age=24)
    assert person.name == "Rafael"
    assert person.age == 24
    assert person == Person(name="Rafael", age=24)
    assert person != Person(name="Rafael", age=25)
    assert person != Person(name="Rafael", age=24, foo="foo")
    assert repr(person) == "Person(name='Rafael', age=24)"


# Generated at 2022-06-24 11:04:30.180283
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():

    sd = SchemaDefinitions()

    assert len(sd) == 0

    sd[1] = 2

    assert len(sd) == 1
    assert sd[1] == 2
    
    sd[1] = 3

    assert len(sd) == 1
    assert sd[1] == 3

    sd[2] = 3

    assert len(sd) == 2
    assert sd[2] == 3

    del sd[2]

    assert len(sd) == 1

    try:
        sd[1] = 4
        assert False
    except AssertionError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-24 11:04:32.702004
# Unit test for constructor of class Reference
def test_Reference():
    a = Reference(
        to = 'a',
        definitions = {'a':'a'}
    )
    print(a)

if __name__ == '__main__':
    test_Reference()

# Generated at 2022-06-24 11:04:36.056072
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    s = SchemaDefinitions(
        {
            "definition_key": "definition_value"
        }
    )
    print("Given SchemaDefinitions:", s)
    print("__getitem__('definition_key'):", s.__getitem__("definition_key"))


# Generated at 2022-06-24 11:04:37.060453
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-24 11:04:45.853110
# Unit test for constructor of class Schema
def test_Schema():
    class X(Schema):
        foo = Field(default=42)

    assert isinstance(X(), dict)
    assert X().foo == 42
    assert X(None).foo == 42
    assert X({}).foo == 42
    assert X({"foo": 5}).foo == 5
    assert X(foo=5).foo == 5

    class Y(X):
        bar = Field(default=8)

    assert Y().foo == 42
    assert Y().bar == 8
    assert Y({"foo": 5}).foo == 5
    assert Y({"foo": 5}).bar == 8
    assert Y({"bar": 7}).foo == 42
    assert Y({"bar": 7}).bar == 7


# Generated at 2022-06-24 11:04:49.451571
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field = Field()
        field_with_default = Field(default="foo")

    assert len(TestSchema())==1
    assert len(TestSchema(field="bar"))==2
    assert len(TestSchema(field="bar", field_with_default="foo"))==2



# Generated at 2022-06-24 11:04:52.347220
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['definition_key'] = 'definition_value'
    assert schema_definitions['definition_key'] == 'definition_value'


# Generated at 2022-06-24 11:04:54.050383
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema = SchemaDefinitions()
    schema["key"] = 1
    assert schema["key"] == 1


# Generated at 2022-06-24 11:05:00.452202
# Unit test for method validate of class Reference
def test_Reference_validate():
    class CarSchema(Schema):
        mark = String()
        model = String()
        year = Integer()

    class PersonSchema(Schema):
        name = String()
        age = Integer()
        car = Reference(CarSchema)
    
    person = PersonSchema.validate({"name":"John", "age":40, "car":{"mark":"Audi", "model":"A3", "year":2015}}) 
    print("person: " + str(person))
    assert person.car.mark == "Audi"
    assert person.car.year == 2015
    
    # bad input 

# Generated at 2022-06-24 11:05:04.363922
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Empty(Schema):
        pass

    class One(Schema):
        one = Field()

    class Two(Schema):
        one = Field()
        two = Field()

    assert len(Empty()) == 0
    assert len(One(one=1)) == 1
    assert len(Two(one=1, two=2)) == 2
    assert len(Two(one=1)) == 1

# Generated at 2022-06-24 11:05:08.783875
# Unit test for constructor of class Reference
def test_Reference():
    reference_test = Reference('test',test='test')
    assert reference_test.to == 'test'
    assert reference_test.definitions == {'test': 'test'}
    assert reference_test.errors == {'null': 'May not be null.'}
    assert reference_test.description is None

# Generated at 2022-06-24 11:05:10.557955
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions({})
    definitions["key"] = "value"
    assert definitions == {"key": "value"}
    # Unit test for method __getitem__ of class SchemaDefinitions

# Generated at 2022-06-24 11:05:14.464813
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference('Bar')
    class Bar(Schema):
        bar = Reference('Baz')
    class Baz(Schema):
        baz = Reference('Bar')
    definitions = { 'Bar': Bar, 'Baz': Baz }
    set_definitions(Foo.fields['foo'], definitions)
    assert Foo.fields['foo'].target == Bar


# Generated at 2022-06-24 11:05:23.402996
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        field1 = Reference("B")
        field2 = Array(Reference("C"))
        field3 = Array(Reference("C"), min_items=1, max_items=1)
        field4 = Object({"field5": Reference("D")})

    class B(Schema):
        pass

    class C(Schema):
        pass

    class D(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions == {
        "A": A,
        "B": B,
        "C": C,
        "D": D,
    }
    assert A.fields["field1"].definitions == definitions
    assert A.fields["field2"].items[0].definitions == definitions

# Generated at 2022-06-24 11:05:28.040100
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        pass
    # should return None
    assert Person({}).__getitem__('a')==None
    # should return not None
    assert Person({'a':'b'}).__getitem__('a')!=None


# Generated at 2022-06-24 11:05:32.453412
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj1 = SchemaDefinitions()
    obj2 = SchemaDefinitions()
    assert obj1 == obj2
    assert obj1 is not obj2
    assert obj1 == {}
    assert obj2 == {}
    assert obj1._definitions == {}
    assert obj2._definitions == {}
    assert obj1._definitions is not obj2._definitions
    assert obj1 is not obj2
    return True



# Generated at 2022-06-24 11:05:38.415368
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    object_field = Object(properties={}, required=[], additional_properties=True)
    object_field._creation_counter = 0
    string_field = Field()
    string_field._creation_counter = 1
    schema_definitions = SchemaDefinitions()
    cls = SchemaMetaclass.__new__(
        SchemaMetaclass,
        "TestSchema",
        (Schema,),
        {"fields": {"object_field": object_field, "string_field": string_field}},
        definitions=schema_definitions,
    )
    assert cls.fields == {"string_field": string_field, "object_field": object_field}
    assert schema_definitions["TestSchema"] == cls


# Generated at 2022-06-24 11:05:42.626826
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.fields import String

    class TestSchema(Schema):
        field1 = String(pattern="^[a-z]")

    value = TestSchema.validate({'field1': 'abc'})
    ref = Reference(TestSchema, Nullable(required=True))

    assert ref.serialize(value) == {'field1': 'abc'}
    assert ref.serialize(None) == None

# Generated at 2022-06-24 11:05:53.149189
# Unit test for method validate of class Reference
def test_Reference_validate():
    from .enums import Coin, CoinReference
    from .fields import String
    from .schema import Schema
    from .utils import any_field

    class SomeSchema(Schema):
        coins = Array(items=any_field(CoinReference))

    # This will fail because of the references not being defined
    message = "String reference missing 'definitions'."
    print(Reference(to=String).validate(1))
    try:
        Reference(to=String).validate(1)
    except AssertionError as e:
        assert str(e) == message
    print()

    # It will work if I provide the definitions
    print(Reference(to=String).validate(1, definitions={'String': any_field(String)}))

# Generated at 2022-06-24 11:05:59.662893
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    check = False
    try:
        class test_schema_1(metaclass=SchemaMetaclass):
            def __init__(self):
                super().__init__()
                self.x = "test"
    except AssertionError as e:
        check = 'Definition for "test_schema_1" has already been set.' in e.args[0]
    assert check == True
test_SchemaMetaclass()

# Generated at 2022-06-24 11:06:06.872632
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    class Home(Schema):
        street = String(max_length=80)
        city = String(max_length=50)
        state = String(max_length=2)
        zip = String(max_length=5)

    class Address(Schema):
        home = Reference(Home)

    class Person(Schema):
        name = String(max_length=30)
        age = Integer(minimum=0, maximum=150)
        address = Reference(Address)

    defns = SchemaDefinitions() # do not raise an exception


# Generated at 2022-06-24 11:06:12.044857
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    field = Field(name='key')
    attrs = {'key': field}
    definitions = SchemaDefinitions()
    cls: SchemaMetaclass = SchemaMetaclass('name', [], attrs, definitions)
    assert cls.fields == {'key': field}
    assert cls == definitions['name']

# Generated at 2022-06-24 11:06:21.124279
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # TEST CASE 1
    definitions = dict()
    definitions["foo"] = "bar"
    definitions["other"] = "value"

    # TEST CASE 2
    definitions = dict()
    definitions["foo"] = "bar"
    definitions["other"] = "value"
    # TEST CASE 3
    definitions = dict()
    definitions["foo"] = "bar"
    definitions["other"] = "value"
    # TEST CASE 4
    definitions = dict()
    definitions["foo"] = "bar"
    definitions["other"] = "value"

    # TEST CASE 5
    definitions = dict()
    definitions["foo"] = "bar"
    definitions["other"] = "value"
    # TEST CASE 6
    definitions = dict()
    definitions["foo"] = "bar"
    definitions["other"] = "value"

    # TEST CASE 1
   

# Generated at 2022-06-24 11:06:29.113862
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from io import StringIO

# Test of __getitem__ for class Schema, where self.fields is an empty dict
    schema = Schema()
    assert schema['testkey'] == KeyError('testkey'), '__getitem__ method of class Schema returned incorrect value when self.fields is an empty dict'

# Test of __getitem__ for class Schema, where self.fields is valid
    class TestSchema(Schema):
        field = Field()
    schema = TestSchema()
    schema.field = 'testfield'
    assert schema['field'] == 'testfield', '__getitem__ method of class Schema returned incorrect value when self.fields is valid'


# Generated at 2022-06-24 11:06:35.837079
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Create an instance of class SchemaDefinitions with no arguments
    var = SchemaDefinitions()
    # Create an instance of class SchemaDefinitions with no arguments
    assert len(var) == 0
    # Create an instance of class SchemaDefinitions with argument types mapped
    var = SchemaDefinitions({"a": 1})
    # Create an instance of class SchemaDefinitions with argument types mapped
    assert len(var) == 1
    # Create an instance of class SchemaDefinitions with argument types mapped
    var = SchemaDefinitions({"a": 1, "b": 2})
    # Create an instance of class SchemaDefinitions with argument types mapped
    assert len(var) == 2


# Generated at 2022-06-24 11:06:37.347847
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    assert hasattr(Schema, '__getitem__')



# Generated at 2022-06-24 11:06:39.577638
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__(): # real signature unknown; restored from __doc__
    """
    __iter__()
    """
    pass


# Generated at 2022-06-24 11:06:41.725179
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    assert len(definitions)==0
    assert definitions[0] == None


# Generated at 2022-06-24 11:06:51.297086
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = 'a'
    b = 'b'
    c = 'c'
    d = 'd'
    a1 = '1'
    b1 = {'b1':1}
    c1 = '#'
    d1 = '_'
    d2 = '$'
    adict = {a:a1, b:b1, c:c1, d:d2}
    adef = SchemaDefinitions()
    adef[a] = a1
    adef[b] = b1
    adef[c] = c1
    adef[d] = d1
    assert adict == adef
    for k in adict.keys():
        assert adict[k] == adef[k]
    assert len(adict) == len(adef)

# Generated at 2022-06-24 11:06:52.199391
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass


# Generated at 2022-06-24 11:06:57.963997
# Unit test for method validate of class Reference
def test_Reference_validate():
    class FooSchema(Schema):
        foo = Array(Field(String))
        bar = Array(Field(Number))
    foo1 = FooSchema({
        "foo": ["1", "2"],
        "bar": [1, 2]
    })
    foo2 = FooSchema({
        "foo": ["1", "2"],
        "bar": [1, 2.5]
    })
    assert foo1.foo == ["1", "2"]
    assert foo1.bar == [1, 2]
    assert foo2.foo == ["1", "2"]
    assert foo2.bar == [1, 2.5]



# Generated at 2022-06-24 11:07:03.617688
# Unit test for method validate of class Reference
def test_Reference_validate():
    # GIVEN
    reference = Field(name='age')
    target = Object(properties={'age': reference})
    reference = Reference(to=target, definitions={'target': target})

    # WHEN
    result = reference.validate(value={'age':12})

    # THEN
    assert result == {'age':12}



# Generated at 2022-06-24 11:07:08.721132
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Human(Schema):
        name = str
        age = int

    h = Human(name='Peter', age=23)

    assert Reference(to='Human').serialize(h) == {'name': 'Peter', 'age': 23}

# Generated at 2022-06-24 11:07:12.650388
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer
    from .types import SimpleSchema

    assert len(SimpleSchema()) == 0
    assert len(SimpleSchema(integer=Integer())) == 1


# Generated at 2022-06-24 11:07:19.692584
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['test1'] = 1
    assert definitions['test1'] == 1
    definitions['test2'] = 2
    assert definitions['test2'] == 2
    del definitions['test2']
    try:
        _ = definitions['test2']
        raise ValueError("delitem failed")
    except KeyError:
        pass
    assert len(definitions) == 1
    del definitions['test1']
    assert len(definitions) == 0
    try:
        _ = definitions['test1']
        raise ValueError("delitem failed")
    except KeyError:
        pass



# Generated at 2022-06-24 11:07:25.882642
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class SchemaA(Schema):
        field = Field()
    #   x = Field()
    #   y = Array(Field())

    s = SchemaA(field=1)
    assert s == SchemaA(field=1)
    assert s != SchemaA(field=2)


# Generated at 2022-06-24 11:07:27.181207
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = SchemaDefinitions()
    assert a == {}
    a['a'] = 1
    assert a == {'a': 1}

# Generated at 2022-06-24 11:07:31.209324
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import re
    import random
    import math
    import json
    import array
    import reprlib
    from collections import Counter
    import dataclasses
    import timeit
    from pathlib import Path
    from itertools import filterfalse

    with open(Path.joinpath(Path.cwd(),"test_data/test_Schema___len__.json")) as f:
        j = json.load(f)
        for case in j:
            test_Schema___len___0(case.get("fields"), case.get("value"))
    return 


# Generated at 2022-06-24 11:07:36.993366
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class City(Schema):
        name = Field(String)
        population = Field(Integer)

    # Testing with parameters (name, population)
    assert repr(City(name="Delhi", population=1000000)) == "City(name='Delhi', population=1000000)"
    # Testing with parameter (population, name)
    assert repr(City(population=1000000, name="Delhi")) == "City(population=1000000, name='Delhi')"
    # Testing with parameter using dictionary
    assert repr(City({"name": "Delhi", "population": 1000000})) == "City(name='Delhi', population=1000000)"
    # Testing without parameters
    assert repr(City()) == "City()"

# Unit testing for method __str__ of class Schema

# Generated at 2022-06-24 11:07:41.780720
# Unit test for constructor of class Reference
def test_Reference():
    # No error should be raised on correct arguments
    try:
        ref = Reference(ReferencedModel, definitions=None, description="Referenced Model.")
    except Exception:
        assert False
    # Error should be raised on incorrect arguments
    try:
        ref = Reference(ReferencedModel, definitions=None)
        assert False
    except:
        assert True

# Generated at 2022-06-24 11:07:46.576390
# Unit test for method validate of class Reference
def test_Reference_validate():
    #from typesystem.schema import Schema, Reference

    class ValidatedSchema(Schema):
        a = Field()
        b = Reference(to='ObjectB')

    class ObjectB(Schema):
        c = Field()
        d = Field()

    class TestClass(Schema):
        to = Reference(to='ObjectB')
        
    definitions = SchemaDefinitions({'ObjectB': ObjectB})
    TestClass.validate(value={'to': {'c': 'valc'}}, definitions=definitions)
    assert True
        


# Generated at 2022-06-24 11:07:53.635427
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert True
    def init_schema_with_fields():
        class Foo(Schema):
            bar = String()
            baz = Integer()
        return Foo
    s= init_schema_with_fields()
    assert type(s) is type
    assert type(s.fields) is dict
    assert len(s.fields) is 2
    assert type(s.fields['bar']) is String
    assert type(s.fields['baz']) is Integer


# Generated at 2022-06-24 11:07:56.737341
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import Integer

    class User(Schema):
        age = Integer()

    definitions = SchemaDefinitions()
    field = Reference(to="User", definitions=definitions)
    user = User(age=42)
    result = field.validate(user)
    assert result == 42


# Generated at 2022-06-24 11:08:02.003606
# Unit test for method validate of class Reference
def test_Reference_validate():
     from typesystem.fields import String

     class User(Schema):
        email = String(format="email")

     ref = Reference(to=User)
     print(ref.validate({"email": "foo"}))
     print(ref.validate(None))


# Generated at 2022-06-24 11:08:07.616382
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        first_name = String(max_length=100, required=True)
        last_name = String(max_length=100, required=True)
        age = Integer()
        address = String()

    my_schema = MySchema(first_name='First name', last_name='Last name')
    assert type(my_schema) == MySchema
    assert repr(my_schema) == "MySchema(first_name='First name', last_name='Last name') [sparse]"


test_Schema___repr__()

# Generated at 2022-06-24 11:08:09.137730
# Unit test for method validate of class Reference
def test_Reference_validate():
    '''
        Not yet implemented
    '''
    pass


# Generated at 2022-06-24 11:08:11.412083
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['test'] = 'test'
    assert definitions['test'] == 'test'


# Generated at 2022-06-24 11:08:15.048458
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        name = String(required=True)
        age = Integer()

    schema = TestSchema(name="liwei", age=19)


# Generated at 2022-06-24 11:08:23.243141
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    def_dict = SchemaDefinitions({"c": 3, "b": 2, "a": 1})

    assert len(def_dict) == 3
    assert "a" in def_dict
    assert "b" in def_dict
    assert "c" in def_dict

    del def_dict["a"]
    assert len(def_dict) == 2
    assert "a" not in def_dict
    assert "b" in def_dict
    assert "c" in def_dict

    del def_dict["c"]
    assert len(def_dict) == 1
    assert "a" not in def_dict
    assert "b" in def_dict
    assert "c" not in def_dict

    del def_dict["b"]
    assert len(def_dict) == 0
    assert "a" not in def_

# Generated at 2022-06-24 11:08:32.022653
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    mock_item = "MOCK_ITEM"
    mock__definitions = {mock_item: mock_item}
    schema_definitions = SchemaDefinitions(mock__definitions)

    mock__definitions_keys = mock__definitions.keys()
    mock__definitions_keys_return_value, _ = iter(mock__definitions_keys)
    mock__definitions_keys_return_value_str = str(mock__definitions_keys_return_value)
    with unittest.mock.patch.object(mock__definitions, "keys", return_value=mock__definitions_keys_return_value_str) as mock_keys:
        m = unittest.mock.mock_open()

# Generated at 2022-06-24 11:08:39.719178
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    print('\nTesting Schema.__eq__()')
    from typesystem import Integer, String
    from typesystem.compat import classproperty

    class Hotel(Schema):
        price = Integer()
        name = String()
        address = String()

        @classproperty
        def price_filter(cls):
            return Integer(minimum=0, maximum=1000)

    h1 = Hotel(price=100, name='hotel-1',address='address-1')
    h2 = Hotel(price=100, name='hotel-1',address='address-1')
    h3 = Hotel(price=100, name='hotel-1')
    assert h1 == h2
    assert h1 != h3
    print('Test pass')


# Generated at 2022-06-24 11:08:50.589709
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import String
    from typesystem.main import SchemaDefinitions
    from typesystem.schema import Schema

    assert issubclass(Reference, Field)
    definitions = SchemaDefinitions()
    # reference object of type String
    reference = Reference(to='String', definitions=definitions)
    # call validate
    value_1 = 'string'
    assert reference.validate(value_1) == value_1
    # call validate with value = None
    value_2 = None
    assert reference.validate(value_2) == value_2

    definitions['String'] = String
    # reference object of type Reference
    reference = Reference(to='String', definitions=definitions)
    # call validate
    value_3 = {'required': True}

# Generated at 2022-06-24 11:08:58.775085
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        name = Reference("Name")
        names = Array(Reference("Name"))

    definitions = SchemaDefinitions()

    assert TestSchema.fields["name"].definitions is None
    assert TestSchema.fields["names"].items.definitions is None

    set_definitions(TestSchema.fields["name"], definitions)
    set_definitions(TestSchema.fields["names"], definitions)

    assert TestSchema.fields["name"].definitions is definitions
    assert TestSchema.fields["names"].items.definitions is definitions

# Generated at 2022-06-24 11:09:02.724298
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        name = Field(type="string")
        age = Field(type="number")

    s = MySchema(name="John", age=30)
    assert list(s) == ['name', 'age']


# Generated at 2022-06-24 11:09:07.795596
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = String()
        email = String()

    class Group(Schema):
        name = String()
        members = Array(Reference(User))

    class Category(Schema):
        name = String()
        group = Reference(Group)

    user = User(name='Nicolas', email='nicolas@example.com')
    group = Group(name='Developers', members=[user])
    category = Category(name='Nomenclature', group=group)

    assert category.validate(category) is None



# Generated at 2022-06-24 11:09:10.232912
# Unit test for constructor of class Reference
def test_Reference():
    instance = Reference("foo")
    assert instance.to == "foo"
    assert instance.definitions == None
    assert instance._target_string == "foo"
    assert instance._target == None


# Generated at 2022-06-24 11:09:20.187236
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import typesystem
    import typesystem_jsl

    class example_schema(typesystem.Schema):
        name = typesystem.String(max_length=10)
        age = typesystem.Integer()
        height_m = typesystem.Number()

        country = typesystem.String(max_length=10)

    obj = example_schema.validate(
        {"name": "John Doe", "age": 42, "height_m": 1.83, "country": "France"}
    )
    assert obj["name"] == "John Doe"
    assert obj["age"] == 42
    assert obj["height_m"] == 1.83
    assert obj["country"] == "France"


# Generated at 2022-06-24 11:09:24.049105
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    def do_test(obj, expected):
        actual = obj.__repr__()
        assert actual == expected
    # Test with default arguments
    obj = Schema()
    expected = "Schema()"
    do_test(obj, expected)



# Generated at 2022-06-24 11:09:26.126378
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	class TestSchema(Schema):
		a = Field()
		b = Field()
		c = Field()
		d = Field()
		e = Field()
	assert len(TestSchema({"a": 1, "b": 2, "c": 3})) == 3


# Generated at 2022-06-24 11:09:34.852703
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import String, Integer, DateTime

    class Person(Schema):
        name = String(max_length=20)
        age = Integer(minimum=1, maximum=120)

    class PersonReference(Schema):
        person = Reference(to="Person")

    class PersonContainer(Schema):
        person = Reference(to=Person)

    person = Person(name="Bob", age=20)
    ref1 = PersonReference(person=person)
    ref2 = PersonContainer(person=person)

    # Passing a person object
    assert ref1.person == person
    assert ref2.person == person

    # Passing a dictionary
    assert ref1.person == Person({"name": "John", "age": 40})
    assert ref2.person == Person({"name": "John", "age": 40})

    # Passing keyword

# Generated at 2022-06-24 11:09:43.123447
# Unit test for method serialize of class Reference
def test_Reference_serialize():
  class Book(Schema): name = String()
  class Library(Schema): books = Array(Reference(Book))
  books = [{'name': 'Alice in Wonderland'}, {'name': 'The Hobbit'}]
  lib = Library(books=books)
  serialized = lib.serialize()
  assert serialized == {'books': [{'name': 'Alice in Wonderland'}, {'name': 'The Hobbit'}]}
  print('[TEST] Reference.serialize: PASSED')



# Generated at 2022-06-24 11:09:48.147095
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    kwargs = {"k": 1, "b": 2}
    s.update(kwargs)
    assert len(s) == 2
    assert s["k"] == 1
    assert s["b"] == 2
    assert s.pop("b") == 2
    assert len(s) == 1
    assert s["k"] == 1
    del s["k"]
    assert len(s) == 0



# Generated at 2022-06-24 11:09:53.297152
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    try:
        __result = SchemaDefinitions.__iter__(SchemaDefinitions())
    except Exception as __excep:
        __excep = str(__excep)
        assert False, __excep
    __result = str(__result)
    assert __result == "dict_keyiterator({})", __result


# Generated at 2022-06-24 11:09:55.428252
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        foo = Field(type=int)

    assert Foo.fields == {"foo": Field(type=int)}

