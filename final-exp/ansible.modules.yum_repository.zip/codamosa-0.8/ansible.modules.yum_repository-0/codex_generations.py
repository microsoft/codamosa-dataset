

# Generated at 2022-06-11 08:18:31.287519
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Create module
    module = AnsibleModule({
        "name": "epel",
        "file": "external_repos",
        "state": "absent",
        "reposdir": "/test/repos"
    })

    # Create class
    yum_repo = YumRepo(module)

    # We do not want to use the open function
    # pylint: disable=W0212
    # Dummy data

# Generated at 2022-06-11 08:18:37.782622
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    yum_repo_file = os.path.join(
        os.path.dirname(__file__), 'fixtures', 'test_YumRepo_remove')

    yum_repo = YumRepo(AnsibleModule({'reposdir': '/dev/null'}))
    yum_repo.repofile.read(yum_repo_file)
    yum_repo.remove()
    assert (yum_repo.repofile.sections() == [])



# Generated at 2022-06-11 08:18:39.414840
# Unit test for function main
def test_main():
    module = ansible_module_yumrepo()
    assert main() == module.exit_json()


# Generated at 2022-06-11 08:18:45.116068
# Unit test for function main

# Generated at 2022-06-11 08:18:47.971344
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={})
    yum = YumRepo(module)
    yum.remove()
    expected = ""
    assert yum.dump() == expected


# Generated at 2022-06-11 08:18:59.384453
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():

    # Mock the module
    module = mock.Mock()

    # Create a fake instance of the AnsibleModule
    am = mock.Mock()
    am.params = {'repoid': 'test_id'}
    module.return_value = am

    # Create a fake instance of YumRepo
    y = YumRepo(module)

    # Fake instance of RawConfigParser
    raw = mock.Mock()

    raw.has_section.return_value = True
    raw.remove_section.return_value = None

    y.repofile = raw

    y.remove()

    raw.has_section.assert_called_with('test_id')
    raw.remove_section.assert_called_with('test_id')


# Generated at 2022-06-11 08:19:11.250960
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    ym_repo = YumRepo(AnsibleModule({}))
    ym_repo.repofile = configparser.RawConfigParser()
    ym_repo.repofile.add_section('[section]')
    ym_repo.repofile.set('[section]', 'abc', 'abc')
    ym_repo.repofile.set('[section]', 'xyz', 'xyz')
    ym_repo.repofile.add_section('[section2]')
    ym_repo.repofile.set('[section2]', 'xyz', 'xyz')
    ym_repo.repofile.set('[section2]', 'abc', 'abc')
    res = ym_repo.dump()

# Generated at 2022-06-11 08:19:22.291714
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    import os

    # Create the instance
    repo = YumRepo(None)

    # Set dest
    repo.params['dest'] = "/tmp/%s.repo" % repo.params['file']

    # Remove the file if already exists
    try:
        os.remove(repo.params['dest'])
    except OSError:
        pass

    # Set the options
    repo.repofile.add_section('section1')
    repo.repofile.set('section1', 'baseurl', 'http://baseurl.com')
    repo.repofile.add_section('section2')

    # Save the file
    repo.save()

    # Check if file exists
    assert os.path.isfile(repo.params['dest'])

    # Read file
    repofile = configparser

# Generated at 2022-06-11 08:19:24.423212
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    r = YumRepo(None)
    assert r.dump() == r.repofile.__str__()


# Generated at 2022-06-11 08:19:27.026560
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec=dict(action=dict(default='dump')))
    repo = YumRepo(module)
    repo.save()



# Generated at 2022-06-11 08:20:04.982713
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    """
    Test YumRepo.remove method.
    """

    module = AnsibleModule(
        argument_spec=dict(
            file="testing",
            repoid="testing",
            reposdir="/tmp/yumrepos",
        ),
    )

    sample_repo_data = """[epel]
name=Extra Packages for Enterprise Linux 7 - $basearch
baseurl=https://download.fedoraproject.org/pub/epel/7/$basearch
enabled=0
gpgcheck=0
"""


# Generated at 2022-06-11 08:20:10.667957
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    '''Unit test for method dump of class YumRepo'''
    # Create the module object
    module = AnsibleModule(argument_spec={
        'file': {'required': True},
        'state': {'default': 'present'},
        'name': {'required': True},
        'baseurl': {'required': True},
        'reposdir': {'default': '/etc/yum.repos.d'},
        'yum_repository_facts': {'default': False, 'type': 'bool'},
    })

    # Create repofile content
    repofile = configparser.RawConfigParser()
    repofile.add_section('testrepo2')
    repofile.set('testrepo2', 'baseurl', 'http://repo.test')
    repofile

# Generated at 2022-06-11 08:20:21.161238
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    import os
    import tempfile
    import shutil

    class MockModule(object):
        params = dict()

    module = MockModule()

    module.params = {
        'baseurl': 'http://example.com/foo/bar',
        'descr': 'Foo repository',
        'dest': None,
        'enabled': True,
        'file': 'foo',
        'gpgcheck': False,
        'name': 'foo',
        'proxy': None,
        'reposdir': None,
        'repoid': 'foo',
        'state': 'present'}

    repos_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 08:20:28.576602
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Initialize a fake module for testing
    module = AnsibleModule(
        argument_spec={
            'name': {'required': False, 'default': 'epel'},
            'file': {'required': False, 'default': 'epel'},
            'reposdir': {'required': False, 'default': '/etc/yum.repos.d'}})

    # Instantiate YumRepo class
    yum_repo = YumRepo(module)

    # yum_repo should now have a module variable set
    assert yum_repo.module is not None



# Generated at 2022-06-11 08:20:38.792742
# Unit test for method dump of class YumRepo

# Generated at 2022-06-11 08:20:46.945817
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    from ansible.module_utils import basic
    from ansible.module_utils import files
    from ansible.module_utils._text import to_bytes

    testcase = """
[epel]
name=EPEL YUM repo
baseurl=https://download.fedoraproject.org/pub/epel/$releasever/$basearch/
"""

    # Create a temp file
    (fd, dest) = files.mkstemp_hidden(suffix='.repo')
    f = os.fdopen(fd, 'w')
    f.write(to_bytes(testcase))
    f.close()

    # Set the args
    args = dict(
        name='epel',
        file='epel',
        state='absent',
        reposdir='/tmp/',
        dest=dest)

    #

# Generated at 2022-06-11 08:20:58.362270
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        'name': {'required': True},
        'baseurl': {'type': 'str'},
        'mirrorlist': {'type': 'str'},
        'reposdir': {'default': '/etc/yum.repos.d'},
        'file': {'default': 'mock.repo'},
        'state': {'default': 'absent', 'choices': ['present', 'absent']}
    })
    repo = YumRepo(module)
    # Add a section
    repo.repofile.add_section('mock')
    repo.repofile.set('mock', 'baseurl', 'http://mock')

# Generated at 2022-06-11 08:21:07.645814
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    with open('/etc/yum.repos.d/rhel-tmp.repo', "r") as fh:
        repofile = fh.read()
    with open('/etc/yum.repos.d/rhel-tmp.repo', "w") as fh:
        fh.write("")
    module = AnsibleModule({
        'baseurl': None,
        'dest': '/etc/yum.repos.d/rhel-tmp.repo',
        'file': 'rhel-tmp',
        'reposdir': '/etc/yum.repos.d'})
    yum_repo = YumRepo(module)
    yum_repo.save()

# Generated at 2022-06-11 08:21:17.903512
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    import tempfile

    module = AnsibleModule(
        argument_spec = dict(
            repoid = dict(default="foo", type='str'),
            file = dict(default="foo", type='str'),
            name = dict(default="foo", type='str'),
            baseurl = dict(default="http://foo.com", type='str'),
            enabled = dict(default=True, type='bool'),
            gpgcheck = dict(default=True, type='bool'),
            proxy = dict(default="http://foo.com", type='str'),
            reposdir = dict(default=tempfile.gettempdir(), type='str'),
        ),
        supports_check_mode=True,
        no_log=True
    )

    yumrepo = YumRepo(module)
    yumrepo.add()
   

# Generated at 2022-06-11 08:21:25.180470
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({'file': 'external_repos',
                            'reposdir': 'test_dir',
                            'name': 'epel'})
    repofile = configparser.RawConfigParser()
    repofile.add_section('epel')
    repofile.set('epel', 'baseurl', 'http://download.fedoraproject.org/pub/epel/7/$basearch')
    repofile.set('epel', 'enabled', '1')
    repofile.add_section('rpmforge')
    repofile.set('rpmforge', 'baseurl', 'http://apt.sw.be/redhat/el7/en/$basearch/rpmforge')
    repofile.set('rpmforge', 'enabled', '0')
    yumrepo = YumRep

# Generated at 2022-06-11 08:22:33.493736
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    import os
    import sys
    import tempfile
    dummy_values = {
        'reposdir': tempfile.mkdtemp(),
        'file': 'test-repo',
        # Test remove from file with multiple repos
        'src': os.path.join(os.path.dirname(__file__), 'repo-4-sections.repo'),
        'section': 'epel',
        'state': 'absent'
    }

# Generated at 2022-06-11 08:22:42.940046
# Unit test for method save of class YumRepo
def test_YumRepo_save():
   from ansible.module_utils.six.moves import StringIO
   from ansible.module_utils.basic import AnsibleModule
   # Create the class test object
   dummy_url = 'http://dummy.url/'
   dummy_mirrorlist_url = 'http://dummy.mirrorlist.url/'
   dummy_metalink_url = 'http://dummy.metalink.url/'

# Generated at 2022-06-11 08:22:47.116177
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    from ansible.module_utils.ansible_modlib import AnsibleModuleMock

    # Prepare the arguments
    params = {'file': 'epel', 'name': 'epel', 'reposdir': '/etc/yum.repos.d'}

    # Create a fake module
    module = AnsibleModuleMock(params)

    # Create a fake repo file
    existing = "[epel]\n" \
               "name = epel\n" \
               "baseurl = http://epel.org\n" \
               "\n" \
               "[foobar]\n" \
               "name = foobar\n" \
               "baseurl = http://foobar.org\n" \
               "\n"
    tmp_path = '/tmp/test_YumRepo_remove'

# Generated at 2022-06-11 08:22:54.946937
# Unit test for function main
def test_main():
    '''test main'''

# Generated at 2022-06-11 08:22:57.523256
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:23:07.124305
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    test_module = AnsibleModule(argument_spec={})
    test_yumrepo = YumRepo(test_module)

    test_yumrepo.repofile.add_section("test1")
    test_yumrepo.repofile.set("test1", "option1", "value1")
    test_yumrepo.repofile.set("test1", "option2", "value2")

    test_yumrepo.repofile.add_section("test2")
    test_yumrepo.repofile.set("test2", "option1", "value1")
    test_yumrepo.repofile.set("test2", "option2", "value2")

    output = test_yumrepo.dump()


# Generated at 2022-06-11 08:23:16.978590
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    param = {'basearch': 'x86_64',
             'baseurl': 'http://www.example.com',
             'failovermethod': 'priority',
             'file': 'example.repo',
             'gpgcheck': True,
             'gpgkey': 'http://www.example.com',
             'name': 'example-repo',
             'reposdir': '/etc/yum.repos.d',
             'repoid': 'example-repo'}
    c = YumRepo(None, param)

    # Build a configparser object
    config = configparser.RawConfigParser()
    config.add_section('example-repo')
    config.set('example-repo', 'gpgkey', 'http://www.example.com')

# Generated at 2022-06-11 08:23:26.050458
# Unit test for function main

# Generated at 2022-06-11 08:23:27.036380
# Unit test for constructor of class YumRepo
def test_YumRepo():
    YumRepo()


# Generated at 2022-06-11 08:23:34.637725
# Unit test for function main
def test_main():
    # create the mock object for module
    module_mock = Mock(params={'reposdir':'/etc/yum.repos.d','dest': '/etc/yum.repos.d/test_repo.repo', 'name': 'test_repo', 'description': 'Test repo', 'baseurl':'http://example.com/rhel/$releasever/x86_64/os/', 'enabled':False, 'gpgcheck': True, 'gpgkey':'file:///etc/pki/test_repo/gpgkey', 'state':'present', 'file':'test_repo'})
    # create the mock object for module.fail_json
    module_mock.fail_json = Mock()
    # create the mock object for module.set_fs_attributes_if_different
    module_m

# Generated at 2022-06-11 08:24:41.777567
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(
        argument_spec=dict(
            params=dict(type='dict')
        )
    )
    module.params = {
        'params': {
            'reposdir': '/tmp/yum-test-repos',
            'file': 'unit-test'
        }
    }
    y = YumRepo(module)
    # Create the directory for testing
    os.makedirs(module.params['params']['reposdir'])
    y.add()
    y.save()
    assert(os.path.exists(os.path.join(module.params['params']['reposdir'], 'unit-test.repo')))



# Generated at 2022-06-11 08:24:50.209497
# Unit test for constructor of class YumRepo
def test_YumRepo():
    yumrepo = YumRepo(AnsibleModule(
        argument_spec={
            'baseurl': {'type': 'str'},
            'repoid': {'type': 'str'},
            'reposdir': {'type': 'str'},
            'file': {'type': 'str'},
        }
    ))

    if not isinstance(yumrepo.repofile, configparser.RawConfigParser):
        raise AssertionError("YumRepo object doesn't have member 'repofile' "
                             "which should be instance of RawConfigParser.")


# Generated at 2022-06-11 08:24:50.753124
# Unit test for constructor of class YumRepo
def test_YumRepo():
    YumRepo(None)



# Generated at 2022-06-11 08:24:52.213168
# Unit test for constructor of class YumRepo
def test_YumRepo():
    assert(YumRepo('test') is not None)



# Generated at 2022-06-11 08:24:59.893096
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        "file": {"default": "test.repo", "type": "str"},
        "repoid": {"default": "test", "type": "str"},
        "reposdir": {"default": "/tmp", "type": "str"},
        "baseurl": {"default": "http://domain.tld/path/to/repo/$releasever/$basearch/", "type": "str"},
        "metalink": {"default": "None", "type": "str"},
        "mirrorlist": {"default": "None", "type": "str"}
    })
    repo = YumRepo(module)

    repo.add()
    repo.remove()
    dump = repo.dump()


# Generated at 2022-06-11 08:25:10.612926
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    import tempfile
    import os
    import shutil

    # Create temporary directory
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, "test.repo")
    # empty repofile
    repofile = configparser.RawConfigParser()
    # instance of class
    yumrepo = YumRepo(None)
    # set a filename
    yumrepo.params = {'dest':filename}
    # set a repofile
    yumrepo.repofile = repofile
    # run the method
    yumrepo.save()
    # assert that the file was created
    assert os.path.exists(filename)
    # delete all
    shutil.rmtree(tempdir)

# Generated at 2022-06-11 08:25:18.680855
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Test with empty config object
    repo = YumRepo(None)

    assert repo.dump() == ""

    # Test with a repository in the config
    section = "test"
    repofile = configparser.RawConfigParser()
    repofile.add_section(section)
    repofile.set(section, 'enabled', 1)
    repofile.set(section, 'name', 'test')
    repofile.set(section, 'baseurl', 'http://localhost/')
    repofile.set(section, 'gpgcheck', 0)

    repo.repofile = repofile

# Generated at 2022-06-11 08:25:26.788186
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    # Init module and class
    module = AnsibleModule({})
    class_ = YumRepo(module)

    # Prepare data to be saved
    class_.repofile.add_section('foo')
    class_.repofile.set('foo', 'baseurl', 'https://example.com')
    class_.repofile.add_section('bar')
    class_.repofile.set('bar', 'baseurl', 'https://example.com')

    # Set the destination file
    class_.params['dest'] = '/tmp/foo.repo'

    # Write the data and complete the test
    class_.save()
    class_.module.exit_json(changed=True)



# Generated at 2022-06-11 08:25:37.880505
# Unit test for method add of class YumRepo

# Generated at 2022-06-11 08:25:45.755059
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    params = {'repoid': 'example',
              'reposdir': '/tmp',
              'file': 'test',
              'baseurl': 'http://example.com',
              'gpgcheck': True,
              'gpgkey':  'http://example.com/gpgkey',
              'enabled': False}

    module = ansible_module_mock({'params': params})
    yum_repo = YumRepo(module)
    yum_repo.add()

    expected = "[example]\nbaseurl = http://example.com\n"\
               "enabled = 0\n"\
               "gpgcheck = 1\n"\
               "gpgkey = http://example.com/gpgkey\n"

    assert yum_repo.dump() == expected

# Unit tests

# Generated at 2022-06-11 08:27:52.748050
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(
        argument_spec=dict(
            file='epel',
            repoid='epel',
            gpgcheck='no',
            baseurl='https://download.fedoraproject.org/pub/epel/6/x86_64/',
            reposdir='/tmp/repos/',
            state='present',
        )
    )

    obj = YumRepo(module)
    obj.add()

    str_file = obj.dump()
    assert "[epel]\nbaseurl = https://download.fedoraproject.org/pub/epel/6/x86_64/\ngpgcheck = 0\n\n" == str_file

    obj.save()
    string_file = open("/tmp/repos/epel.repo").read()

# Generated at 2022-06-11 08:27:58.075239
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Testing if YumRepo raises an exception if the reposdir is invalid
    module = AnsibleModule({
        'reposdir': '/invalid/dir'
    })
    try:
        YumRepo(module)
        assert False
    except SystemExit:
        assert True

    # Testing if YumRepo raises an exception if baseurl/metalink/mirrorlist are
    # not defined
    module = AnsibleModule({
        'reposdir': '/etc/yum.repos.d',
    })
    try:
        YumRepo(module)
        assert False
    except SystemExit:
        assert True

