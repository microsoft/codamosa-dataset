

# Generated at 2022-06-11 08:18:32.883150
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception
    from io import StringIO
    import os

    # Workaround: AnsibleModule with params is not supported in test_utils.
    # https://github.com/ansible/ansible-modules-core/issues/4476

# Generated at 2022-06-11 08:18:41.919695
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({})
    test_object = YumRepo(module)
    test_object.repofile = configparser.RawConfigParser()

    # Add sections and options
    test_object.repofile.add_section('test')
    test_object.repofile.set('test', 'a', 'b')
    test_object.repofile.set('test', 'c', 'd')
    test_object.repofile.set('test', 'e', 'f')
    test_object.repofile.add_section('test1')
    test_object.repofile.set('test1', 'g', 'h')
    test_object.repofile.set('test1', 'i', 'j')

    # Dump the repo file
    dumped_data = test_object.dump

# Generated at 2022-06-11 08:18:42.629793
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    pass



# Generated at 2022-06-11 08:18:53.936227
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 08:19:03.145114
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    repofile = configparser.RawConfigParser()
    repofile.read('/home/vagrant/repo.ini')
    a = YumRepo('epel')
    a.repofile = repofile
    a.section = 'epel'
    a.params['baseurl'] = 'http://mirrors.aliyun.com/epel/7/x86_64'
    a.params['dest'] = '/etc/yum.repos.d/repo.ini'
    a.params['name'] = 'epel'
    a.params['mirrorlist'] = None
    a.params['reposdir'] = '/etc/yum.repos.d'
    a.params['state'] = 'present'
    a.params['gpgcheck'] = False

# Generated at 2022-06-11 08:19:11.841063
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Create a fake module
    module = AnsibleModule({})

    # Create a section which will be removed
    section = "my_repo"

    # Create a configparser object
    repofile = configparser.RawConfigParser()
    repofile.add_section(section)

    # Create the instance
    repo = YumRepo(module)

    # Assign the values to the class members
    repo.section = section
    repo.repofile = repofile

    # Call the remove method
    repo.remove()

    # Check if the section was removed
    assert not repo.repofile.has_section(section)



# Generated at 2022-06-11 08:19:18.371522
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    import os
    import shutil
    import tempfile
    import textwrap

    module = AnsibleModule(
        argument_spec = dict(
            # Fake parameters
            status=dict(default="OK"),
            baseurl=dict(default="http://example.com"),
            exclude=dict(default=None),
            includepkgs=dict(default=None, type='list'),
            # Required parameters
            file=dict(default="a", required=True),
            repoid=dict(default="b", required=True),
            state=dict(default="present", choices=["present", "absent"]),
            reposdir=dict(default=os.path.join(tempfile.gettempdir(), "repos"))
        )
    )

    test_repoid = module.params['repoid']


# Generated at 2022-06-11 08:19:26.039673
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Create the Ansible module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            baseurl=dict(),
            file=dict(default='CentOS-Base'),
            metadata_expire=dict(default=21600),
            reposdir=dict(default='/etc/yum.repos.d'),
            state=dict(default='present', choices=['absent', 'present']),
        )
    )

    yumrepo = YumRepo(module)
    module.exit_json(changed=False)


# Generated at 2022-06-11 08:19:37.852446
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import list_to_dict

    # Read main function
    main_content = main.__code__.co_consts[0]
    # pylint: disable=eval-used
    main_function = eval(to_bytes(main_content))

    # Set module args

# Generated at 2022-06-11 08:19:42.096105
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule({'name': 'test'})
    repo = YumRepo(module)

    assert repo.params['repoid'] == 'test'
    assert repo.params['dest'] == '/etc/yum.repos.d/test.repo'
    assert repo.repofile.sections() == []


# Generated at 2022-06-11 08:20:06.235232
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    import tempfile
    import shutil

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(default="test", required=True),
            file=dict(default="testrepo", required=True),
            reposdir=dict(default=tempfile.mkdtemp()),
        ),
        supports_check_mode=True,
    )

    repo = YumRepo(module)
    repo.add()

    # Create a backup of the repo file
    # Due to the lack of `set_fs_attributes` in AnsibleModule it's not possible
    # to use an existing file.
    backup_file = "%s.ansible-bak" % repo.params['dest']
    shutil.copyfile(repo.params['dest'], backup_file)

    repo.save()

   

# Generated at 2022-06-11 08:20:11.261464
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={})
    repo = YumRepo(module)

    # Add test section
    repo.repofile.add_section('test')
    assert repo.repofile.has_section('test')

    # Remove test section
    repo.remove()
    assert not repo.repofile.has_section('test')

# Generated at 2022-06-11 08:20:22.048843
# Unit test for function main
def test_main():
    # Save the original sys.argv
    orig_argv = sys.argv[:]

    # Change sys.argv
    sys.argv = ['ansible-test', 'yum_repository']
    sys.argv[1] = '-m'
    sys.argv[2] = os.path.join(os.path.dirname(__file__), '..', 'library', 'yum_repository.py')
    sys.argv[3] = '-a'
    sys.argv[4] = 'name=epel'
    sys.argv[5] = '-a'
    sys.argv[6] = 'file=epel'
    sys.argv[7] = '-a'

# Generated at 2022-06-11 08:20:28.745074
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    yumrepo_test = YumRepo(None)

    yumrepo_test.repofile.add_section('test_section')
    yumrepo_test.repofile.set('test_section', 'arg1', 'value1')
    yumrepo_test.repofile.set('test_section', 'arg2', 'value2')

    yumrepo_test.repofile.add_section('test_section2')
    yumrepo_test.repofile.set('test_section2', 'arg1', 'value1')
    yumrepo_test.repofile.set('test_section2', 'arg2', 'value2')

    output = yumrepo_test.dump()


# Generated at 2022-06-11 08:20:38.978313
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(
        argument_spec = dict(
            file = dict(required = False, default = 'test'),
            repoid = dict(required = True),
            reposdir = dict(required = False, default = '/tmp'),
            description = dict(required = False, default = 'Test repository'),
            baseurl = dict(required = False, default = 'http://test'),
            mirrorlist = dict(required = False, default = 'http://test'),
            gpgcheck = dict(required = False, default = 'no'),
            gpgkey = dict(required = False, default = 'http://test2'),
            state = dict(required = False, default = 'present')),
    )
    # Put a repo into a repo file
    repo = YumRepo(module)
    repo.add()
    repo.save()

# Generated at 2022-06-11 08:20:46.253613
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if PY3:
        to_str = str
    else:
        to_str = unicode


# Generated at 2022-06-11 08:20:57.768997
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    """
    Tests the save method of class YumRepo
    """

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            'name': dict(required=True),
            'reposdir': dict(default='/etc/yum.repos.d'),
            'file': dict(default='ansible_test_repo')
        })

    # Initialize repofile
    repofile = configparser.RawConfigParser()

    # Create a section
    repofile.add_section('test_section')

    # Add a key/value
    repofile.set('test_section', 'test_key', 'test_value')

    # Create repo object
    repo = Yum

# Generated at 2022-06-11 08:21:05.368959
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    '''
    Unit test for method remove of class YumRepo.
    '''
    # Create class object
    repo = YumRepo(AnsibleModule({
        'baseurl': None,
        'file': 'external_repos',
        'reposdir': 'tests/repos',
        'repoid': 'epel',
        'state': 'absent'
    }))
    repo.add()

    assert repo.repofile.sections() == ['epel']

    repo.remove()

    assert repo.repofile.sections() == []



# Generated at 2022-06-11 08:21:14.984076
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    # Create a fake module object
    module = type('', (), {})()

    # Create a fake params
    params = {
        'reposdir': '/tmp/repos',
        'file': 'test',
        'dest': '',
    }

    # Create an object with fake module and params
    repo = YumRepo(module, params)

    # Write the repo file
    repo.add()
    repo.save()

    # Open the file and test the content
    filename = os.path.join(params['reposdir'], "%s.repo" % params['file'])
    assert os.path.isfile(filename)

    with open(filename, 'r') as fd:
        assert fd.read() == "[test]\n"

    # Test if the file will be removed
    repo = Y

# Generated at 2022-06-11 08:21:22.371554
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(
        argument_spec={
            'repoid':
                dict(default='epel', type='str'),
            'file':
                dict(default='external_repos', type='str'),
            'reposdir':
                dict(default='/etc/yum.repos.d', type='str'),
        }
    )
    repo = YumRepo(module)

    repo.add()

    assert(repo.repofile.has_section('epel'))
    assert(repo.repofile.get('epel', 'file') == 'external_repos')

# Generated at 2022-06-11 08:21:59.893907
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({})
    repofile = configparser.RawConfigParser()
    repofile.add_section("test_section")
    repofile.set("test_section", "test_key", "test_value")

    yumrepo = YumRepo(module)
    yumrepo.repofile = repofile

    result = yumrepo.dump()
    assert result == "[test_section]\ntest_key = test_value\n"



# Generated at 2022-06-11 08:22:07.897388
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule({
        'file': {
            'type': 'str',
            'required': False,
            'default': 'ansible',
        },
        'name': {
            'type': 'str',
            'required': True,
        },
        'reposdir': {
            'type': 'path',
            'required': False,
            'default': '/etc/yum.repos.d',
        },
        'baseurl': {
            'type': 'str',
            'required': False,
            'default': None,
        },
    })

    y_r = YumRepo(module)

    y_r.add()

    y_r.save()


# Generated at 2022-06-11 08:22:11.914812
# Unit test for constructor of class YumRepo
def test_YumRepo():
    yum_repo_obj = YumRepo(None)
    assert yum_repo_obj.module == None
    assert yum_repo_obj.params == None
    assert yum_repo_obj.section == None
    assert isinstance(yum_repo_obj.repofile, configparser.RawConfigParser)


# Generated at 2022-06-11 08:22:20.225818
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = MockAnsibleModule()
    module.params['reposdir'] = "/tmp"
    module.params['file'] = "external_repos"
    module.params['repoid'] = "epel"
    repofile = configparser.RawConfigParser()
    repofile.add_section("epel")
    repofile.set("epel", "baseurl", "https://download.fedoraproject.org/pub/epel/7/$basearch/")
    repofile.set("epel", "enabled", "1")
    repofile.set("epel", "gpgcheck", "0")
    repofile.add_section("rpmforge")

# Generated at 2022-06-11 08:22:30.999910
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            file=dict(aliases=['repo_file']),
            # Override dest to avoid problems with directory access
            dest=dict()))

    yumrepo = YumRepo(module)
    yumrepo.repofile.add_section("test")
    yumrepo.repofile.set("test", "key", "value")
    yumrepo.repofile.add_section("test2")
    yumrepo.repofile.set("test2", "key2", "value2")
    yumrepo.repofile.set("test2", "key3", "value3")

# Generated at 2022-06-11 08:22:40.769522
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({})
    repo = YumRepo(module)

    repofile = configparser.RawConfigParser()
    repofile.add_section('example')
    repofile.set('example', 'enabled', 1)
    repofile.set('example', 'baseurl', 'http://example.com')
    repofile.add_section('example2')
    repofile.set('example2', 'enabled', 1)
    repofile.set('example2', 'baseurl', 'http://example2.com')

    repo.repofile = repofile

    output = repo.dump()

    assert '[example]\n\n' in output
    assert '[example2]\n\n' in output
    assert 'enabled = 1' in output

# Generated at 2022-06-11 08:22:48.219804
# Unit test for function main

# Generated at 2022-06-11 08:22:54.917059
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule({
        'baseurl': 'http://example.com/repo',
        'description': 'Test repo',
        'enabled': True,
        'name': 'testrepo'
    })

    yum_repo = YumRepo(module)

    yum_repo.add()

    assert(yum_repo.repofile.has_section('testrepo'))
    assert(yum_repo.repofile.get('testrepo', 'baseurl') == 'http://example.com/repo')
    assert(yum_repo.repofile.get('testrepo', 'enabled') == '1')


# Generated at 2022-06-11 08:23:06.074346
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    '''
    Test creating and writing a file
    '''
    import os
    import shutil
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            'file': {
                'default': 'zypp',
                'type': 'str'
            },
            'reposdir': {
                'default': '/tmp',
                'type': 'str'
            },
        })

    # Create testing object
    yum_repo = YumRepo(module)

    # Check if the repo directory exists
    repos_dir = yum_repo.params['reposdir']

# Generated at 2022-06-11 08:23:10.549235
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule({'name': 'epel'})
    yum_repo = YumRepo(module)
    # Remove section if exists
    if yum_repo.repofile.has_section('epel'):
        yum_repo.repofile.remove_section('epel')


# Generated at 2022-06-11 08:24:24.436448
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={})

    repo = YumRepo(module)

    # Check if repo was initialized
    assert isinstance(repo, YumRepo)

    # Add section
    repo.add()

    # Check if the section is present
    assert repo.section in repo.repofile.sections()

    # Check if the section has the same options

# Generated at 2022-06-11 08:24:32.945789
# Unit test for constructor of class YumRepo
def test_YumRepo():
    from ansible.module_utils.basic import AnsibleModule

    # Create a fake AnsibleModule instance for testing
    test_module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            reposdir = dict(default='/etc/yum.repos.d'),
            file = dict(default='testrepo.repo')
        )
    )

    # Test if module fails with reposdir set to a no existing directory
    repos_dir = os.path.join('/tmp', 'nonexisting_dir')
    try:
        YumRepo(test_module)
    except Exception as e:
        test_module.fail_json(
            msg="Test failed; missing reposdir directory %s." % repos_dir,
            details=to_native(e))

# Generated at 2022-06-11 08:24:38.413951
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Fake AnsibleModule
    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = None
    # Fake AnsibleModule object
    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params
    # Fake configparser object
    class FakeConfigParser(object):
        def __init__(self):
            self.sections = []
            self.items = []
        def has_section(self, section):
            return True
        def remove_section(self, section):
            return True
        def add_section(self, section):
            return True
        def get(self, section, key):
            return True
        def sections(self):
            return [1, 2, 3]

    # Value for

# Generated at 2022-06-11 08:24:39.579985
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    pass


# Generated at 2022-06-11 08:24:50.647733
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['present', 'absent'], type='str'),
            repoid=dict(default='epel', required=True, type='str'),
            baseurl=dict(default='http://example.com/', type='str'),
            file=dict(default='__test_yumrepo_dump', type='str'),
            reposdir=dict(default='/tmp', type='str'),
        )
    )
    repo = YumRepo(module)

    assert repo.dump() == ''

    repo.params['state'] = 'present'
    repo.add()
    expected = "[epel]\nbaseurl = http://example.com/\n\n"
    assert repo.dump() == expected


# Generated at 2022-06-11 08:24:59.122121
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Create module
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str'),
        state=dict(required=True, choices=['absent', 'present'], type='str'),
        repoid=dict(aliases=['name'], type='str'),
        file=dict(type='str'),
        reposdir=dict(type='str'),
    ), supports_check_mode=True, required_if=[['state', 'absent', ['repoid']]])

    # The section is always the repoid
    module.params['repoid'] = module.params['name']

    # Set dest; also used to set dest parameter for the FS attributes

# Generated at 2022-06-11 08:25:10.077809
# Unit test for constructor of class YumRepo
def test_YumRepo():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    params = dict(
        repoid='epel',
        file='epel',
        reposdir='/tmp',
    )

    # Create a fake AnsibleModule object
    module = AnsibleModule(argument_spec=dict())
    module.params = params

    # Create a fake StringIO object
    repo_content = StringIO()
    repo_content.write("[epel]\nname=epel\nbaseurl=https://download.fedoraproject.org/pub/epel/7/$basearch/")

    # Mock the open() method and set the StringIO object as file descriptor
    mock_open = mock.mock_open(read_data=repo_content.getvalue())


# Generated at 2022-06-11 08:25:18.333470
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    """Check remove method of YumRepo class."""
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    class AnsibleFailJson(Exception):
        pass

    class TestAnsibleModule(basic.AnsibleModule):
        def fail_json(self, *args, **kwargs):
            raise AnsibleFailJson(kwargs['msg'])

    class TestYumRepo(object):
        def __init__(self, module):
            self.module = module
            self.params = self.module.params
            self.section = self.params['repoid']
            self.repofile = configparser.RawConfigParser()


# Generated at 2022-06-11 08:25:27.861814
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule({
        'name': 'epel',
        'description': 'EPEL YUM repo',
        'baseurl': 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/',
        'reposdir': '/tmp/yum-repos-test',
        'dest': '/tmp/epel.repo',
    },
    argument_spec={},
    supports_check_mode=True)

    # Create the repo file directory if not exists
    if not os.path.isdir(module.params['reposdir']):
        os.mkdir(module.params['reposdir'])

    yum_repo = YumRepo(module)

    # Check if dest is set correctly

# Generated at 2022-06-11 08:25:39.108592
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Create a FakeModule to work with
    attrs_to_return = {
        'params': {
            'name': 'testrepo',
            'description': 'testdescription',
            'baseurl': 'testbaseurl',
            'repoid': 'testrepoid'
        }
    }
    fake_module = FakeModule(attrs_to_return)

    # Create a FakeConfigParser to work with
    config_parser = FakeConfigParser()
    config_parser.sections = []
    config_parser.repofile = FakeRepoFile()

    # Create the YumRepo object
    yum_repo = YumRepo(fake_module)
    yum_repo.repofile = config_parser
    yum_repo.repofile.add_section = add_section_fake
    y

# Generated at 2022-06-11 08:27:50.459171
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    my_repo = YumRepo(None)
    my_repo.params = {}
    my_repo.params['dest'] = '.'

    # Create a empty file
    open(my_repo.params['dest'], 'w').close()

    my_repo.repofile.add_section('test1')
    my_repo.repofile.add_section('test2')

    # Unit test save
    my_repo.save()

    # Check if file exists
    if not os.path.isfile(my_repo.params['dest']):
        raise Exception("File not created.")

    # Remove file
    os.remove(my_repo.params['dest'])


# Generated at 2022-06-11 08:27:57.810046
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    """
    This function is called from unit.module_utils.basic.AnsibleModuleTestCase
    """
    module = None