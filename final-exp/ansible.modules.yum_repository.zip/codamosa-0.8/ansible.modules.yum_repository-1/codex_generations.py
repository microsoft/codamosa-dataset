

# Generated at 2022-06-11 08:18:31.189945
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import ModuleTestCase
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args

# Generated at 2022-06-11 08:18:40.679853
# Unit test for constructor of class YumRepo
def test_YumRepo():
    import os
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import configparser

    # Create temporary directory for tests
    repos_dir = "/tmp/ansible_repos_test"
    if not os.path.isdir(repos_dir):
        os.mkdir(repos_dir)

    files_to_remove = []
    repos_file = os.path.join(repos_dir, "repo1.repo")
    files_to_remove.append(repos_file)

    # Create the module object

# Generated at 2022-06-11 08:18:47.171977
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Create a new instance of YumRepo and mock the module
    ym = YumRepo(AnsibleModule({}))
    ym.section = 'section'

    # Add a section to the repo file
    ym.repofile.add_section('section')

    # Remove the section
    ym.remove()

    # Check if the section was removed
    assert not ym.repofile.has_section('section')


# Generated at 2022-06-11 08:18:56.920390
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    # Create an instance of class YumRepo
    repo = YumRepo(module=None)

    # Set repofile to a RawConfigParser
    repo.repofile = configparser.RawConfigParser()

    # Create a temp file in the local directory
    repo.params['dest'] = "./test.repo"

    # Add a new section and option
    repo.repofile.add_section("test")
    repo.repofile.set("test", "test", "test")

    # Save file
    if repo.save() is None and os.path.isfile("./test.repo"):
        os.remove("./test.repo")

# Generated at 2022-06-11 08:19:08.861125
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from StringIO import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3, b

    # Data to be composed into a repo file

# Generated at 2022-06-11 08:19:20.031831
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Prepare the parameters
    params = {
        'baseurl': 'http://example.com',
        'file': 'example',
        'reposdir': '/etc/yum.repos.d',
        'repoid': 'example',
    }

    # Create an empty module
    module = AnsibleModule(params=params)

    # Instantiate the class
    repo = YumRepo(module)

    # Add the repo
    repo.add()

    # Test the string representation of repofile
    result = str(repo.repofile)
    assert result == '[example]\nfile = example\nreposdir = /etc/yum.repos.d\nrepoid = example\n'



# Generated at 2022-06-11 08:19:27.160078
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(
        argument_spec={
            'baseurl': {'type': 'str'},
            'file': {'type': 'str'},
            'reposdir': {'type': 'str'},
        },
    )
    yum_repo = YumRepo(module)
    yum_repo.add()
    yum_output = yum_repo.dump()
    assert yum_output == "[epel]\nbaseurl = http://example.com/epel7\n\n"


# Generated at 2022-06-11 08:19:38.770886
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    data = [
        # [name, state, section_exists_before_exec, section_exists_after_exec]
        ['example', 'absent', True, False],
        ['example2', 'absent', False, False],
        ]

    for name, state, section_exists_before_exec, section_exists_after_exec in data:
        module = AnsibleModule({
            'file': 'test.repo',
            'repoid' : name,
            'state': state,
            'reposdir': '/tmp/'
        })
        yum_repo = YumRepo(module)

        # Create a dummy config file
        yum_repo.repofile.add_section('example')
        yum_repo.repofile.add_section('example2')
        y

# Generated at 2022-06-11 08:19:44.237528
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    data = '''
[epel]
bandwidth = 100
foo = bar
protect = 1

[epel-source]
foo = bar
'''
    repofile = configparser.RawConfigParser()
    repofile.read_string(data)

    yumrepo = YumRepo(None)
    yumrepo.repofile = repofile
    dump_repo = yumrepo.dump()

    assert dump_repo == data


# Generated at 2022-06-11 08:19:49.987268
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = mock.MagicMock()
    repofile = configparser.RawConfigParser()
    repofile.add_section("test_1")
    repofile.set("test_1", "foo", "bar")

    result = YumRepo(module).dump()
    assert result == "[test_1]\nfoo = bar\n\n"



# Generated at 2022-06-11 08:20:10.796579
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({
        'params': {'reposdir': '/etc/yum.repos.d'},
        'state': 'present',
        'baseurl': 'http://apt.sw.be/redhat/el7/en/$basearch/rpmforge',
        'file': 'dummy',
        'repoid': 'dummy'})
    repo = YumRepo(module)

    # Add section
    repo.repofile.add_section(repo.section)

    # Set some options
    repo.repofile.set(repo.section, 'baseurl', 'http://apt.sw.be/redhat/el7/en/$basearch/rpmforge')
    repo.repofile.set(repo.section, 'name', 'dummy')

    print(repo.dump())

# Generated at 2022-06-11 08:20:21.334983
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule({
        'repoid': 'repoid',
        'name': 'name',
        'baseurl': 'baseurl',
        'reposdir': '/myrepodir',
        'file': 'myrepo.repo'
    })

    repo = YumRepo(module)

    repo.add()

    try:
        repo.repofile.get('repoid', 'repoid')
        repo.repofile.get('repoid', 'name')
        repo.repofile.get('repoid', 'baseurl')
    except configparser.NoSectionError:
        assert False
    except configparser.NoOptionError:
        assert False
    else:
        assert True
    finally:
        # Clean up
        os.remove(repo.params['dest'])

# Unit test

# Generated at 2022-06-11 08:20:31.127473
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create the config parser object
    conf = configparser.RawConfigParser()

    # Create sections
    conf.add_section('epel')
    conf.set('epel', 'baseurl', 'https://download.fedoraproject.org/pub/epel/7/$basearch')

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    # Create YumRepo object
    repo = YumRepo(module)

    # Populate repo file
    repo.repofile = conf

   

# Generated at 2022-06-11 08:20:38.979864
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    # Given
    module_args = dict(
        name='epel',
        baseurl='https://download.fedoraproject.org/pub/epel/$releasever/$basearch/')

    module = AnsibleModule(argument_spec=module_args)
    yum_repo = YumRepo(module)

    # When
    yum_repo.add()
    yum_repo.save()

    # Then
    assert os.path.isfile(module_args['dest']) is True

    # Cleanup
    os.remove(module_args['dest'])



# Generated at 2022-06-11 08:20:46.253385
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Initialize module
    module = AnsibleModule(argument_spec={
        'file': {'type': 'str', 'required': False, 'default': 'test'},
        'reposdir': {'type': 'path', 'required': False, 'default': tempfile.gettempdir()},
        'section': {'type': 'str', 'required': False, 'default': 'test'},
        'write': {'type': 'str', 'required': False, 'default': True}
    })

    # Create temporary file
    fd, path = tempfile.mkstemp()

    # Set params
    module.params['reposdir'] = tempfile.gettempdir()
    module.params['dest'] = path

    # Create Yum

# Generated at 2022-06-11 08:20:57.768783
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        'repoid': {
            'type': 'str',
            'default': 'repoid'
        },
        'baseurl': {
            'type': 'str'
        },
        'file': {
            'type': 'str',
            'default': 'repofile.repo'
        },
        'reposdir': {
            'type': 'str',
            'default': '/tmp'
        }
    })

    # Set up for the test
    repos_dir = module.params['reposdir']
    repofile = module.params['file']
    test_repo = YumRepo(module)

    # Test input

# Generated at 2022-06-11 08:21:06.495819
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={'dest': {'type': 'str'}})
    yum_repo = YumRepo(module)
    yum_repo.repofile.add_section('test_section')
    yum_repo.repofile.set('test_section', 'test_key', 'test_value')

    yum_repo.save()
import os

try:
    import ConfigParser as configparser
except ImportError:
    import configparser

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.six.moves import configparser
from ansible.module_utils._text import to_native



# Generated at 2022-06-11 08:21:08.713845
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule({'reposdir': '/etc/yum.repos.d'})
    p = YumRepo(module)
    assert p.module == module



# Generated at 2022-06-11 08:21:19.083978
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Create a dummy module
    module = AnsibleModule(argument_spec={})

    # Create an instance of YumRepo class
    repo = YumRepo(module)

    # Test attributes of the instance
    assert repo.module is module
    assert repo.params == {}
    assert repo.section is None

# Generated at 2022-06-11 08:21:25.792470
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():

    import tempfile
    import os

    # Create temporary repo file
    fn = tempfile.NamedTemporaryFile(mode='w+t', delete=False)
    fn.writelines(
        "[main]\nrepo-foo=bar\n\n[epel]\nbaseurl = http://download.fedoraproject.org/pub/epel/6/$basearch\n")
    fn.close()

    # Create a module for this test only
    module = AnsibleModule(
        argument_spec=dict(
            repoid='epel',
            reposdir=os.path.dirname(fn.name),
            file='repo-file'
        )
    )

    # Create YumRepo object
    repo = YumRepo(module)
    # Remove" epel "section
    repo

# Generated at 2022-06-11 08:22:04.428702
# Unit test for function main
def test_main():
    '''Test function main'''
    main_test = dict(
        name='test',
        description='test repo',
        baseurl='http://localhost',
        state='present')
    with pytest.raises(AnsibleModuleFail) as e_module_fail:
        setattr(AnsibleModule, 'fail_json', lambda *args, **kwargs: None)
        YumRepo.module = AnsibleModule(main_test)
        YumRepo.params = YumRepo.module.params
        YumRepo.repofile = configparser.RawConfigParser()
        YumRepo.repofile.read('examples/repo_fail.txt')
        YumRepo.section = YumRepo.params['repoid']

# Generated at 2022-06-11 08:22:06.609568
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    instance = YumRepo(module)
    module.exit_json(changed=False)


# Generated at 2022-06-11 08:22:10.628653
# Unit test for constructor of class YumRepo
def test_YumRepo():
    yum_repo = YumRepo()
    assert yum_repo.module is None
    assert yum_repo.params is None
    assert yum_repo.section is None
    assert isinstance(yum_repo.repofile, configparser.RawConfigParser)
    assert yum_repo.repofile.sections() == []



# Generated at 2022-06-11 08:22:18.274755
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Create module argument specifications
    argument_spec = dict(
        name=dict(type='str', required=True),
        file=dict(type='str', default='ansible-repos'),
        reposdir=dict(type='str', default='/etc/yum.repos.d'))

    # Create a dummy AnsibleModule
    module = AnsibleModule(argument_spec=argument_spec)

    # Create a dummy ConfigParser
    repofile = configparser.RawConfigParser()

    # Add section
    repofile.add_section('section')

    # Set options
    repofile.set('section', 'option1', 'value1')
    repofile.set('section', 'option2', 'value2')

    module.params['name'] = 'section'

# Generated at 2022-06-11 08:22:27.515066
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule({
        'file': 'test_file',
        'reposdir': 'test_reposdir',
        'repoid': 'test',
        'baseurl': 'http://foo.example.com',
    })
    yum_repo = YumRepo(module)
    yum_repo.add()

    assert yum_repo.repofile.has_section('test')
    assert yum_repo.repofile.get('test', 'baseurl') == 'http://foo.example.com'
    assert yum_repo.repofile.get('test', 'gpgcheck') == '0'


# Generated at 2022-06-11 08:22:33.227487
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = MockAnsibleModule()
    module.params = {'repoid':'test'}
    repo = YumRepo(module)

    try:
        repo.repofile.add_section('test')
    except configparser.DuplicateSectionError:
        # If the section already exists, do nothing
        pass
    repo.remove()

    assert not repo.repofile.has_section('test')


# Generated at 2022-06-11 08:22:33.929849
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    pass

# Generated at 2022-06-11 08:22:43.290951
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    import tempfile
    test_object = YumRepo(module)
    # Set the temp directory
    fd, temp_path = tempfile.mkstemp()


# Generated at 2022-06-11 08:22:52.439338
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import configparser

    # Initialize the class
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)

    # Create a temporary repo file
    with tempfile.NamedTemporaryFile(delete=False) as fd:
        print('''
[epel]
name = EPEL
baseurl = https://download.fedoraproject.org/pub/epel/$releasever/$basearch/
gpgcheck = no
        ''', file=fd)

    # Read the repo file
    yum_repo.repofile.read(fd.name)

    # Compare with expected string

# Generated at 2022-06-11 08:22:58.573924
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = MockModule()
    repo = YumRepo(module)
    repo.add()

    repo_file = repo.dump()
    assert repo_file == '[epel]\nbaseurl = https://download.fedoraproject.org/pub/epel/$releasever/$basearch/\ngpgcheck = yes\nname = epel\n'


# Generated at 2022-06-11 08:23:59.561472
# Unit test for constructor of class YumRepo
def test_YumRepo():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    yum_repo = YumRepo(module)

    assert yum_repo.module.fail_json == module.fail_json


# Generated at 2022-06-11 08:24:09.234348
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    import StringIO

    # module arguments
    args = dict(
        baseurl="http://someurl",
        name="test",
        reposdir="/tmp",
        file="test.repo"
    )

    # Set module and its parameters
    module = AnsibleModule(argument_spec={'baseurl': dict(required=True),
                                          'name': dict(required=True),
                                          'reposdir': dict(required=True),
                                          'file': dict(required=True),
                                          },
                           supports_check_mode=True)

    setattr(module, 'params', args)

    # Fake the file
    setattr(module, 'tmpfile', None)

    # Class initialization
    yum = YumRepo(module)

    # Add test repo
    yum.add()

# Generated at 2022-06-11 08:24:18.932437
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Initializing repo dictionary
    repo_dict = dict(
        state='present',
        repoid='epel',
        description='Description',
        baseurl='https://example.com/epel/7/x86_64',
        reposdir='/etc/yum.repos.d',
        file='epel.repo',
        gpgcheck=True)

    # Initializing module and Yumrepo class
    module = AnsibleModule(argument_spec=dict())
    yumrepo = YumRepo(module)

    # Initializing the repo file
    yumrepo.repofile = configparser.RawConfigParser()

    # Adding the section
    yumrepo.repofile.add_section(repo_dict['repoid'])

    # Setting parameters

# Generated at 2022-06-11 08:24:29.098599
# Unit test for method save of class YumRepo
def test_YumRepo_save():

    module = AnsibleModule(argument_spec = {
        'state': {
            'default': 'present',
            'choices': ['absent', 'present']
        },
        'name': {'required': True},
        'baseurl': {'default': None},
        'enabled': {'default': True},
        'gpgcheck': {'default': False},
        'file': {'default': None},
        'reposdir': {'default': '/etc/yum.repos.d'},
        'dest': {
            'type': 'path',
            'default': '/etc/yum.repos.d'
        }
    },
    supports_check_mode=True)

    yumrepo = YumRepo(module)
    yumrepo.save()


# Generated at 2022-06-11 08:24:35.863542
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
    )

    module.params = {
        'name': 'epel',
        'file': 'external_repos',
        'reposdir': '/tmp',
        'dest': '/tmp/external_repos.repo',
        'baseurl': 'http://download.fedoraproject.org/pub/epel/6/x86_64',
        'enabled': True,
        'state': 'present',
    }

    repo = YumRepo(module)

    assert repo.repofile.sections() == ['epel']

# Generated at 2022-06-11 08:24:44.400134
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(
        argument_spec=dict(
            repo=dict(required=True),
            reposdir=dict(default='/etc/yum.repos.d'),
        ),
        supports_check_mode=True,
    )
    repo = YumRepo(module)
    assert repo.params['dest'] == '/etc/yum.repos.d/external_repos.repo'
    assert repo.params['repo'] == 'external_repos'
    assert repo.params['reposdir'] == '/etc/yum.repos.d'
    assert repo.section == 'rpmforge'


# Generated at 2022-06-11 08:24:51.564023
# Unit test for constructor of class YumRepo
def test_YumRepo():
    class inject(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    module = inject(
        repoid="epel",
        reposdir="/opt/yum/repos"
    )

    repo = YumRepo(module)

    assert repo.module == module
    assert repo.params == {
        'repoid': 'epel',
        'reposdir': '/opt/yum/repos'
    }
    assert repo.section == 'epel'


# Generated at 2022-06-11 08:24:57.444868
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Create a dummy module for testing
    module = AnsibleModule(argument_spec={
        "repoid": {"type": "str", "required": True},
        "reposdir": {"type": "str", "default": "/etc/yum.repos.d"},
        "file": {"type": "str", "default": "ansible-test"},
    })

    yum_repo = YumRepo(module)
    module.exit_json(changed=False)


# Generated at 2022-06-11 08:25:08.103608
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            file="test",
        )
    )

    # First test if correct output is created
    test_class = YumRepo(module)
    test_class.repofile.add_section("test_section")
    test_class.repofile.set("test_section", "test_key", "test_value")

    output = test_class.dump()
    assert output == "[test_section]\ntest_key = test_value\n\n"

    # Second test if the output is still correct after changing the value of
    # test_value
    test_class.repofile.set("test_section", "test_key", "test_value_changed")

    output = test_class

# Generated at 2022-06-11 08:25:09.122381
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    assert YumRepo.dump()


# Generated at 2022-06-11 08:27:12.183078
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Create object
    YumRepo_instance = YumRepo(AnsibleModule({}))
    # Get the YumRepo_instance.repofile variable
    repofile = getattr(YumRepo_instance, "repofile")
    # Add section
    repofile.add_section(YumRepo_instance.section)
    # Set options
    for key, value in sorted(YumRepo_instance.params.items()):
        if key in YumRepo_instance.list_params and isinstance(value, list):
            # Join items into one string for specific parameters
            value = ' '.join(value)
        elif isinstance(value, bool):
            # Convert boolean value to integer
            value = int(value)

        # Set the value only if it was defined (default is None)

# Generated at 2022-06-11 08:27:17.971870
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule({
        'dest': '/tmp/my_file',
        'file': 'my_file',
        'state': 'present',
        'reposdir': '/tmp'
    })

    mock = YumRepo(module)
    mock.save()

    assert os.path.isfile('/tmp/my_file.repo') is True, "save method of YumRepo class failed unit test."



# Generated at 2022-06-11 08:27:24.466706
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Prepare the test parameters
    params = {
        'baseurl': 'http://example.com/',
        'gpgcheck': False,
        'reposdir': '/root/',
        'file': 'test',
        'repoid': 'test',
        'bandwidth': 50,
        'deltarpm_metadata_percentage': 50,
        'metalink': 'http://example.com/metalink.xml',
        'mirrorlist': 'http://example.com/list'
    }

    # Set the module_args

# Generated at 2022-06-11 08:27:30.609075
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={})
    yum = YumRepo(module)
    assert yum.section == None
    yum.params = {'repoid': 'test-repo'}
    yum.add()
    assert yum.repofile.sections()[0] == yum.section
    assert yum.repofile.sections()[-1] == yum.section
    yum.params = {'repoid': 'another-repo'}
    yum.add()
    assert yum.repofile.sections()[0] != yum.section
    assert yum.repofile.sections()[-1] == yum.section


# Generated at 2022-06-11 08:27:34.624150
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    with pytest.raises(AnsibleFailJson) as excinfo:
        y = YumRepo(None)
        y.params = {
            'repoid': 'foo',
            'reposdir': '/bar/baz',
            'file': 'qux',
            'baseurl': None,
            'mirrorlist': None,
            'metalink': None,
        }

        y.add()

    assert excinfo.value.args == ("Parameter 'baseurl', 'metalink' or 'mirrorlist' is required for adding a new repo.",)



# Generated at 2022-06-11 08:27:43.766621
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule({
        'file': 'ansible-test-repo',
        'repoid': 'test-repo',
        'name': 'Ansible Test Repo',
        'baseurl': 'http://127.0.0.1/',
        'enabled': False,
        'reposdir': '/root/'
    })

    yum_repo = YumRepo(module)
    yum_repo.add()

    assert module.params['repoid'] in yum_repo.repofile.sections()
    assert yum_repo.repofile.getboolean(module.params['repoid'], 'enabled') is False
    assert yum_repo.repofile.get(module.params['repoid'], 'baseurl') == module.params['baseurl']



# Generated at 2022-06-11 08:27:53.019261
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    """
    Tests YumRepo.add
    """
    m = AnsibleModule({
        'name': 'epel',
        'description': 'EPEL YUM repo',
        'baseurl': 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/',
        'file': 'external_repos',
        'gpgcheck': False,
        'reposdir': '/etc/yum.repos.d',
        'state': 'present'
    })
    y = YumRepo(m)
    y.add()
    output = y.dump()

    assert output == '[epel]\nbaseurl = https://download.fedoraproject.org/pub/epel/$releasever/$basearch/\ngpgcheck = 0\n'

# Unit test

# Generated at 2022-06-11 08:28:01.148151
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.file import Filesystem

    dummy_repo_file = """\
[dummy-repo]
name=dummy-repo
baseurl=http://example.org/repo
enabled=1
gpgcheck=1
gpgkey=http://example.org/gpg/key
"""
    dummy_repo_file_renamed = """\
[dummy-repo-renamed]
name=dummy-repo
baseurl=http://example.org/repo
enabled=1
gpgcheck=1
gpgkey=http://example.org/gpg/key
"""