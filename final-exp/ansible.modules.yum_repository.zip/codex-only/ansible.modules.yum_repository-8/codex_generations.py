

# Generated at 2022-06-23 04:40:08.372527
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    import tempfile

    MOCK_REPODIR = tempfile.mkdtemp()
    MOCK_PARAMS = {
        'name': 'epel',
        'reposdir': MOCK_REPODIR,
        'baseurl': 'https://download.fedoraproject.org/pub/epel/7/$basearch',
        'gpgcheck': False,
    }

    MOCK_REPOFILE = os.path.join(MOCK_REPODIR, 'epel.repo')

    module = AnsibleModule({
        'repo': MOCK_PARAMS,
        'state': 'present'
    })

    yum_repo = YumRepo(module)
    yum_repo.add()

    repofile = configparser.RawConfigParser()

# Generated at 2022-06-23 04:40:18.702567
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)
    yum_repo.repofile.add_section('foo')
    yum_repo.repofile.set('foo', 'bar', 'baz')
    yum_repo.repofile.set('foo', 'baz', 'foo')
    yum_repo.repofile.add_section('bar')
    yum_repo.repofile.set('bar', 'foo', 'bar')
    yum_repo.repofile.set('bar', 'baz', 'foo')


# Generated at 2022-06-23 04:40:29.905550
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Test data
    repo_file = """
[epel]
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-6
enabled=1

[rpmforge]
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-rpmforge-dag
enabled=0
"""

    # Init the module
    module = AnsibleModule(argument_spec=dict(
        file='external_repos',
        reposdir='/tmp/test_yum_repository',
    ))
    # Create the test directory
    os.makedirs(module.params['reposdir'])

    # Create the test repo file

# Generated at 2022-06-23 04:40:36.593529
# Unit test for constructor of class YumRepo
def test_YumRepo():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            baseurl=dict(),
            mirrorlist=dict(),
            file=dict(type='str', default='ansible.repo'),
            reposdir=dict(type='str', default='/tmp'),
            repoid=dict(type='str', default='myrepo')),
        params={})

    repo = YumRepo(module)
    module.params['baseurl'] = "http://example.com/repos/"
    repo.add()
    repo.save()

    assert os.path.isfile(os.path.join(module.params['reposdir'], "%s.repo" % module.params['file']))


# Generated at 2022-06-23 04:40:44.927402
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = MagicMock()
    module.params.update({
        'repoid': 'epel',
        'baseurl': 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/',
    })

    yumrepo = YumRepo(module)

    yumrepo.add()
    assert '[epel]\n' \
           'baseurl = https://download.fedoraproject.org/pub/epel/$releasever/$basearch/\n' \
           'name = epel\n' in yumrepo.dump()


# Generated at 2022-06-23 04:40:46.201052
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:40:53.387867
# Unit test for function main

# Generated at 2022-06-23 04:41:03.605709
# Unit test for function main

# Generated at 2022-06-23 04:41:09.491135
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        "file": {"type": "str", "required": False, "default": ""},
        "reposdir": {"type": "path", "required": False, "default": "/etc/yum.repos.d"},
        "name": {"type": "str", "required": True, "default": ""},
        "state": {"type": "str", "required": False, "default": "present"}
    }, )

    module.params['dest'] = os.path.join(
        module.params['reposdir'], "%s.repo" % module.params['file'])

    # Read the repo file if it exists
    repofile = configparser.RawConfigParser()

# Generated at 2022-06-23 04:41:21.660773
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule({
        'reposdir': '/tmp/ansible',
        'file': 'test_YumRepo_save',
        'repo_gpgcheck': False,
        'name': 'fake_repo_1',
        'baseurl': 'https://fake-repo.com/repos/1',
        'gpgcheck': False,
        'gpgkey': 'http://fake-repo.com/repos/1/gpg',
        'state': 'present'})

# Generated at 2022-06-23 04:41:33.387396
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    """Unit test for method save
    """

    # Prepare parameters for test
    file_content = "[epel]\n"
    file_content += "name = Extra Packages for Enterprise Linux 7 - $basearch\n"
    file_content += "mirrorlist = https://mirrors.fedoraproject.org/metalink?repo=epel-7&arch=$basearch\n"
    file_content += "enabled = 0\n"

    # Execute method save and check the output

# Generated at 2022-06-23 04:41:44.506475
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Set up
    test_module = AnsibleModule(argument_spec={})
    # We have to set the default for dest
    yum_repo = YumRepo(test_module)
    yum_repo.params['dest'] = 'test/yum.repos.d/test.repo'
    yum_repo.repofile.read(yum_repo.params['dest'])

    # Test
    repo_string = yum_repo.dump()

    # Verify
    assert isinstance(repo_string, str)
    assert repo_string == "[epel]\nbaseurl = https://download.fedoraproject.org/pub/epel/7/$basearch\nenabled = 1\n\n"

# Generated at 2022-06-23 04:41:56.564943
# Unit test for method add of class YumRepo

# Generated at 2022-06-23 04:42:04.348645
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Create a basic module instance
    module = AnsibleModule(
        argument_spec={
            'name': {'required': True},
        }
    )

    # Create a yumrepo instance
    yumrepo = YumRepo(module)

    # Check if yumrepo instance is correctly initialized
    module.exit_json(
        changed=False,
        yumrepo=yumrepo
    )



# Generated at 2022-06-23 04:42:15.946929
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(
        argument_spec=dict(
            # Hardcoded for testing purposes
            repoid='epel',
            reposdir='/etc/yum.repos.d',
            file='epel'
        )
    )
    yr = YumRepo(module)
    assert os.path.isfile(yr.params['dest'])
    assert yr.repofile.sections() == [yr.section]
    assert yr.dump() == '[epel]\nname = epel\ngpgcheck = 0\nenabled = 1\n'


# Generated at 2022-06-23 04:42:28.569955
# Unit test for function main

# Generated at 2022-06-23 04:42:39.364345
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os import yum_repository

    # If the module is not mocked, the following import will fail
    from ansible.modules.packaging.os.yum_repository import YumRepo

    import sys

    # Mock AnsibleModule
    class AnsibleModuleMock():
        def __init__(self):
            self.params = {'name': 'test_name'}
            self.check_mode = False

        # Mocking fail_json()
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        # Mocking exit_json()
        def exit_json(self, **kwargs):
            sys.exit(0)

    # Mocking AnsibleModule()
    module = AnsibleModuleMock()

# Generated at 2022-06-23 04:42:49.677812
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({})
    params = {
        'repoid': 'epel',
        'file': 'external_repos'
    }
    repofile = configparser.RawConfigParser()
    section = 'epel'
    repofile.add_section(section)
    repofile.set(section, 'name', 'epel')
    repofile.set(section, 'enabled', 1)
    repofile.set(section, 'baseurl', 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/')
    repofile.set(section, 'cost', '100')
    repofile.set(section, 'gpgcheck', 0)

    repo = YumRepo(module)
    repo.repofile = repofile
    repo

# Generated at 2022-06-23 04:42:51.468620
# Unit test for constructor of class YumRepo
def test_YumRepo():
    y = YumRepo()
    print(y.allowed_params)
    print(y.list_params)

# Main function

# Generated at 2022-06-23 04:42:57.886751
# Unit test for function main

# Generated at 2022-06-23 04:43:09.883445
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    '''
    Unit test for method save of class YumRepo
    '''
    # pylint: disable=line-too-long
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    repo = YumRepo(module)
    repo.repofile.add_section("test")
    repo.repofile.set("test", "enabled", 1)
    repo.repofile.set("test", "gpgcheck", 0)
    repo.repofile.set("test", "name", "test")
    repo.repofile.set("test", "baseurl", "http://test.com")
    repo.repofile.set("test", "gpgkey", "http://test.com/key")

# Generated at 2022-06-23 04:43:20.007138
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule({'reposdir': '/tmp'})
    yumrepo = YumRepo(module)
    assert yumrepo.module is module

# Generated at 2022-06-23 04:43:32.501002
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Create mock module for class YumRepo
    module = MockModule()
    module.params = {
        'baseurl': 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/',
        'dest': '/etc/yum.repos.d/external_repos.repo',
        'enabled': True,
        'failovermethod': 'priority',
        'file': 'external_repos',
        'gpgcheck': False,
        'name': 'epel',
        'reposdir': '/etc/yum.repos.d',
        'repoid': 'epel',
        'state': 'present'}

    yum_repo = YumRepo(module)
    yum_repo.add()

    repo_string = yum_repo

# Generated at 2022-06-23 04:43:38.013874
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    repofile = configparser.RawConfigParser()
    repofile.read('/tmp/epel.repo')
    assert repofile.has_section('epel')
    assert repofile.get('epel', 'name') == 'Extra Packages for Enterprise Linux 7 - $basearch'



# Generated at 2022-06-23 04:43:38.851503
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    pass



# Generated at 2022-06-23 04:43:50.269662
# Unit test for method add of class YumRepo

# Generated at 2022-06-23 04:44:02.093081
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(AnsibleModule):
        def __init__(self, argument_spec):
            super(MockAnsibleModule, self).__init__(argument_spec=argument_spec)
            self.params = dict()
            self.params['reposdir'] = '/dev/null'
            self.params['repoid'] = 'repotest'
            self.params['file'] = 'repotest'
            self.params['dest'] = 'repotest.repo'

        def fail_json(self, **args):
            raise Exception('An error happened')


# Generated at 2022-06-23 04:44:09.754214
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    import tempfile
    import random
    import string

    random_name = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
    # Create a temp directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temp file
    tmp_file = os.path.join(tmp_dir, "%s.repo" % random_name)
    # Create instance of YumRepo
    y = YumRepo(None)
    # Set params required for init
    y.params = { 'file': random_name, 'state': 'absent', 'reposdir': tmp_dir }
    # Set section
    y.section = random_name
    # Add a fake repo
    y.repofile.add_section(y.section)



# Generated at 2022-06-23 04:44:17.679867
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({
        'file': 'test.repo'
    })
    repo = YumRepo(module)
    repo.repofile._sections["test"] = {
        "enabled": 1,
        "name": "Test name",
    }
    repo_string = repo.dump()

    assert repo_string == "[test]\nenabled = 1\nname = Test name\n\n"



# Generated at 2022-06-23 04:44:27.858266
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(
        argument_spec=dict(
            repoid="epel",
            file="test_repo",
            reposdir="/tmp"),
        check_invalid_arguments=False)
    yum_repo = YumRepo(module)
    # Remove the existing repo
    yum_repo.remove()
    # Add a new repo
    yum_repo.add()
    # Remove the repo
    yum_repo.remove()
    # Dump the repo file to string
    output = yum_repo.dump()
    # Check if the repo is really removed
    assert "[epel]\n" not in output
    # Check if the repo file is empty
    assert output == ""

# Generated at 2022-06-23 04:44:37.644261
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={'reposdir': {'type':'path'}, 'file': {'type':'str', 'default':'test'}})
    fake_repo = YumRepo(module)
    fake_repo.repofile.add_section('test')
    fake_repo.repofile.set('test', 'a', '1')
    fake_repo.repofile.set('test', 'b', '2')

    fake_repo.save()
    with open(fake_repo.params['dest'], 'r') as file:
        file_string = file.read()

# Generated at 2022-06-23 04:44:47.975866
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    import tempfile
    import os
    import shutil
    import textwrap
    from ansible_collections.ansible.community.plugins.module_utils.ansible_module_utils._text import to_native

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a repo file
    repofile = os.path.join(tmpdir, 'test.repo')
    with open(repofile, 'w') as fd:
        fd.write(textwrap.dedent("""\
            [test]
            name=test
            baseurl=http://test.com
            enabled=yes
            """))


# Generated at 2022-06-23 04:44:59.360713
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    class Module(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    repoid = 'epel'

# Generated at 2022-06-23 04:45:12.378046
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    repo = YumRepo(AnsibleModule(argument_spec=dict(reposdir=dict(default='/etc/yum.repos.d'))))
    repo.params['dest'] = '/tmp/test.repo_save'
    repo.params['file'] = 'test'
    repo.params['name'] = 'test'

    repo.add()
    repo.save()

    assert os.path.isfile(repo.params['dest'])

    # Clean up
    os.remove(repo.params['dest'])


# Generated at 2022-06-23 04:45:21.260376
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    import unittest
    import os
    import tempfile
    import shutil

    class YumRepoTest(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.repofile = os.path.join(self.tempdir, 'test.repo')
            shutil.copyfile('./test/test.repo', self.repofile)

# Generated at 2022-06-23 04:45:32.751527
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    params = {
        'repoid': 'test',
        'reposdir': '/tmp',
        'file': 'test.repo'}
    testobj = YumRepo(params)
    testobj.repofile.add_section('test')
    testobj.repofile.add_section('test2')
    testobj.repofile.add_section('test3')

    # Remove a non-existing repo
    testobj.remove()
    assert len(testobj.repofile.sections()) == 3

    # Remove test2 repo
    testobj.section = 'test2'
    testobj.remove()
    assert len(testobj.repofile.sections()) == 2

    # Remove test repo
    testobj.section = 'test'
    testobj.remove()

# Generated at 2022-06-23 04:45:41.629551
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    repofile = configparser.RawConfigParser()
    # Section 1
    repofile.add_section("epel")
    repofile.set("epel", "name", "epel")
    repofile.set("epel", "async", 1)
    repofile.set("epel", "bandwidth", "10 M")
    repofile.set("epel", "baseurl", "https://download.fedoraproject.org/pub/epel/$releasever/$basearch/")
    repofile.set("epel", "cost", 1000)
    repofile.set("epel", "deltarpm", "yes")
    repofile.set("epel", "deltarpm_metadata_percentage", 0)

# Generated at 2022-06-23 04:45:54.752708
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Create a tempfile
    fd, path = tempfile.mkstemp(text=True)

    # Create a string for the tempfile

# Generated at 2022-06-23 04:46:04.149811
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule({
        'reposdir': 'repos',
        'file': 'test',
        'state': 'present',
        'repoid': 'test_1',
        'baseurl': 'test',
        'state': 'present'
    })

    yum_repo = YumRepo(module)
    yum_repo.add()
    yum_repo.save()

    # Test save again
    yum_repo.save()

    # Test save with empty repo file
    os.remove(os.path.join(module.params['reposdir'], "%s.repo" % module.params['file']))
    yum_repo.save()



# Generated at 2022-06-23 04:46:16.351019
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule(
        argument_spec=dict(
            file=dict(default=None, required=True),
            name=dict(default=None, required=True),
            reposdir=dict(default='/etc/yum.repos.d'),
        )
    )

    with open('testdata/repo.repo') as fd:
        repofile = fd.read()

    module.params = YumRepo(module).params

    # Create an instance of YumRepo
    yumrepo = YumRepo(module)
    # Read the file
    yumrepo.repofile.read(module.params['dest'])

    # Test the repofile output
    assert repofile == yumrepo.dump()


# Generated at 2022-06-23 04:46:27.548565
# Unit test for function main
def test_main():
    # Name of function to be tested (without module name)
    function_name = 'main'

    # Create the test environment.
    tmpdir, module_path = create_test_environment(function_name)

    # Name of the repo file
    repo_file = 'dummy.repo'

    # Path to the repo file
    repo_file_path = os.path.join(tmpdir, repo_file)

    # Create the repo file
    with open(repo_file_path, 'w') as f:
        f.write("""[dummy-repo]""")

    # Params used to call the main function
    # The name of the repo file is set to the name of the repo

# Generated at 2022-06-23 04:46:40.186674
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    """
    This unittest test a minimal call to the remove method of the class YumRepo.
    The tested behavior is to remove a given section in the repofile.
    """
    # This object is supposed to be mocked as basic AnsibleModule class
    module = object
    # Parse test repository file
    repofile = object
    repofile.read = lambda x: configparser.RawConfigParser().read('./test/resources/test_YumRepo_remove.repo')
    # Instantiate the class to test (YumRepo)
    yum_repo = YumRepo(module)
    # Add the repofile to the class
    yum_repo.repofile = repofile
    # Set the section name to remove

# Generated at 2022-06-23 04:46:44.723194
# Unit test for function main
def test_main():
  module = AnsibleModule(argument_spec=dict(
    name = dict(required=True),
    description = dict(),
    baseurl = dict(type='list', elements='str'),
    gpgkey = dict(type='list', elements='str', no_log=True),
    gpgcheck = dict(type='bool'),
    enabled = dict(type='bool'),
    state = dict(choices=['present', 'absent'], default='present'),
    params = dict(),
  ))

  # Set return value
  y = YumRepo(module)
  y.add()
  y.save()

# Generated at 2022-06-23 04:46:51.313762
# Unit test for function main

# Generated at 2022-06-23 04:46:59.700383
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    import os
    # Mock module input parameters
    params = {'name': 'epel', 'state': 'absent', 'dest': '/tmp/test.repo'}

    # Create a dummy class object
    repofile = configparser.RawConfigParser()

    # Write a dummy repo file
    with open(params['dest'], 'w') as fd:
        fd.write("""[epel]
name = EPEL YUM repo
baseurl = https://download.fedoraproject.org/pub/epel/6/$basearch/""")
    repofile.read(params['dest'])

    # Create a dummy class object
    test_obj = YumRepo(params)
    test_obj.repofile = repofile

    # Test remove method
    test_obj.remove()

    #

# Generated at 2022-06-23 04:47:12.595296
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    import os, shutil

    module = AnsibleModule(argument_spec=dict(
        dest=dict(required=True),
        reposdir=dict(default=None),
    ))

    my_repo = YumRepo(module)
    my_repo.add()
    my_repo.save()
    yum_repo_string = my_repo.dump()

    tmp_fd, tmp_path = tempfile.mkstemp()

    with os.fdopen(tmp_fd, 'w') as fd:
        fd.write(yum_repo_string)

    # Create a symlink and remove the symlink
    os.symlink(tmp_path, my_repo.params['dest'])
    os.remove(my_repo.params['dest'])

   

# Generated at 2022-06-23 04:47:22.272672
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({})
    yum_repo = YumRepo(module)

    yum_repo.repofile.add_section('rhel-server')
    yum_repo.repofile.set(
        'rhel-server', 'name', 'Red Hat Enterprise Linux $releasever - $basearch')
    yum_repo.repofile.set(
        'rhel-server', 'baseurl', 'http://mirrors.kernel.org/fedora-epel/6/$basearch')
    yum_repo.repofile.set('rhel-server', 'enabled', 0)
    yum_repo.repofile.set('rhel-server', 'gpgcheck', 1)

# Generated at 2022-06-23 04:47:35.018266
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import StringIO
    import tempfile


# Generated at 2022-06-23 04:47:46.489850
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    class AnsibleModuleDummy(object):
        class FailJSON(Exception):
            pass

        def fail_json(self, msg, **kwargs):
            raise self.__class__.FailJSON(msg)

        def __init__(self, **kwargs):
            pass

    r = YumRepo(AnsibleModuleDummy(params=dict(reposdir='/')))

    r.params['repoid'] = 'epel'
    r.params['baseurl'] = 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/'
    r.params['gpgcheck'] = False
    r.add()


# Generated at 2022-06-23 04:47:54.904611
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3

    basedir = os.path.dirname(__file__)
    args = dict(
        file="epel",
        name="EPEL YUM repo",
        baseurl="https://download.fedoraproject.org/pub/epel/$releasever/$basearch/",
        gpgcheck=False,
        reposdir=os.path.join(basedir, "yum_repository_test_dir"),
    )


# Generated at 2022-06-23 04:48:06.901556
# Unit test for function main
def test_main():
    # This is a unit test for yum_repository module
    # It is used to demonstrate that yum_repository module does not
    # introduce any regression from bugfix or new feature
    # This unit test can be used as a template for other modules
    # It uses the fixture from test/unit/yum_repository.py

    # Load the yum_repository module
    module_name = 'yum_repository'
    module_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '../../library')
    module_utils_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '../../module_utils')

# Generated at 2022-06-23 04:48:18.806718
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    class TestModule(object):
        params = {
            'dest': '/tmp/repos.repo'
        }

        fail_json = lambda self, *args: None

# Generated at 2022-06-23 04:48:28.697287
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import StringIO

    try:
        del os.environ['ANSIBLE_INVENTORY']
    except KeyError:
        pass


# Generated at 2022-06-23 04:48:38.292290
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    repo = YumRepo(module)

    repo.repofile.add_section('repo-section')
    repo.repofile.set('repo-section', 'key1', 'value1')
    repo.repofile.set('repo-section', 'key2', 'value2')

    expected_lines = [
        "[repo-section]",
        "key1 = value1",
        "key2 = value2"]

    lines = repo.dump().split('\n')

    for index, line in enumerate(expected_lines):
        assert line in lines[index]



# Generated at 2022-06-23 04:48:48.187739
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(
        argument_spec=dict(
            descr=dict(default='Red Hat $releasever - $basearch - Base', type='str'),
            name=dict(default='redhat', type='str'),
            baseurl=dict(default='http://somehost.example.com/repo/$releasever/$basearch/', type='str'),
            dest=dict(default='/etc/yum.repos.d/redhat.repo', type='str'),
            gpgcheck=dict(default='no', type='bool'),
            gpgkey=dict(default='file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release', type='str'),
        ),
        supports_check_mode=False
    )

    repo = YumRepo(module)


# Generated at 2022-06-23 04:48:58.912296
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    # Initialize module
    module = AnsibleModule(
        argument_spec={
            'dest': dict(
                required=True,
                type='path'
            ),
            'reposdir': dict(
                required=True,
                type='path'
            ),
            'file': dict(
                required=True,
                type='str'
            )
        },
        supports_check_mode=True
    )

    # Initialize repository
    repo = YumRepo(module)

    # Check if repo file exists and remove it
    dest = repo.params['dest']
    if os.path.isfile(dest):
        os.remove(dest)

    # Add a repository
    repo.repofile.add_section('main')

# Generated at 2022-06-23 04:49:11.451555
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestYumRepo(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec={},
                supports_check_mode=True)

# Generated at 2022-06-23 04:49:21.168382
# Unit test for constructor of class YumRepo
def test_YumRepo():
    from ansible.module_utils.basic import AnsibleModule

    # Module init
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            state=dict(
                type='str',
                default='present',
                choices=['present', 'absent']),
            reposdir=dict(type='str', default='/etc/yum.repos.d'),
            file=dict(type='str', default='ansible-yum-repository'),
            baseurl=dict(type='str'),
            dest=dict(type='str'),
            enabled=dict(type='bool', default='no'),
            enablegroups=dict(type='bool', default='no'),
        )
    )

    # Check that the reposdir exists

# Generated at 2022-06-23 04:49:31.576518
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Initialize module and class
    module = AnsibleModule({})
    yumrepo = YumRepo(module)
    yumrepo.params = {'file': 'repo-file.repo', 'reposdir': '/tmp/repo.d'}

    # Add repo to the repo file
    yumrepo.params['name'] = 'epel'
    yumrepo.params['baseurl'] = 'https://download.fedoraproject.org/pub/epel/'
    yumrepo.add()
    # Compare repofile with a given data
    data = """[epel]
baseurl = https://download.fedoraproject.org/pub/epel/
gpgcheck = 0
enabled = 1
name = epel

"""

# Generated at 2022-06-23 04:49:36.030223
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Test for None
    assert(YumRepo(None).module == None)

    # Test for empty
    assert(YumRepo({}).module == {})

    # Test for non empty
    assert(YumRepo({"name": "test"}).module == {"name": "test"})


# Generated at 2022-06-23 04:49:48.475007
# Unit test for constructor of class YumRepo
def test_YumRepo():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock, call

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *a, **kw):
            raise Exception

    class TestModuleUtilsBasic(object):
        class AnsibleModule(object):
            def __init__(self, *a, **kw):
                pass

    params = {'repoid': 'testrepo',
              'reposdir': '/path/to/repo/dir'}


# Generated at 2022-06-23 04:50:00.228810
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequential

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    yumrepo = YumRepo(module)

    # Test with a section
    yumrepo.repofile.add_section('section')
    assert yumrepo.dump() == "[section]\n\n"

    # Test with multiple sections
    yumrepo.repofile.add_section('section2')
    assert "[section]\n\n[section2]\n\n" in yumrepo.dump()

    # Test with a parameter in section

# Generated at 2022-06-23 04:50:06.752791
# Unit test for constructor of class YumRepo
def test_YumRepo():
    ret = dict()
    reposdir = '/tmp/reposdir'

    # Passing all parameters
    module = AnsibleModule({
        'name': 'test',
        'file': 'test',
        'baseurl': 'http://example.com',
        'reposdir': reposdir,
        'state': 'absent',
    })
    target = YumRepo(module)
    ret['target'] = target
    ret['params'] = target.params

    return ret
