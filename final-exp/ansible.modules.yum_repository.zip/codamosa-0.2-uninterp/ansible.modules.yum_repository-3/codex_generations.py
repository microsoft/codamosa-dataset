

# Generated at 2022-06-17 05:39:11.016447
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        'repoid': {'type': 'str', 'required': True},
        'reposdir': {'type': 'str', 'default': '/etc/yum.repos.d'},
        'file': {'type': 'str', 'default': 'ansible_test'},
        'state': {'type': 'str', 'default': 'present'},
    })

    repo = YumRepo(module)
    repo.remove()
    assert repo.dump() == ""


# Generated at 2022-06-17 05:39:23.907628
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            description=dict(type='str'),
            baseurl=dict(type='str'),
            mirrorlist=dict(type='str'),
            metalink=dict(type='str'),
            enabled=dict(type='bool', default=True),
            gpgcheck=dict(type='bool', default=True),
            gpgkey=dict(type='str'),
            reposdir=dict(type='path', default='/etc/yum.repos.d'),
            file=dict(type='str', default='ansible-yum-repository'),
        ),
        supports_check_mode=True,
    )

    yum_repo = YumRepo(module)
    assert yum_re

# Generated at 2022-06-17 05:39:30.315398
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import NoSectionError
    from ansible.module_utils.six.moves.configparser import NoOptionError
    from ansible.module_utils.six.moves.configparser import RawConfigParser
    from ansible.module_utils.six.moves.configparser import SafeConfigParser
    from ansible.module_utils.six.moves.configparser import Error
    from ansible.module_utils.six.moves.configparser import DEFAULTS

# Generated at 2022-06-17 05:39:42.622110
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(argument_spec={})
    repo = YumRepo(module)
    assert repo.module == module
    assert repo.params == {}
    assert repo.section is None
    assert isinstance(repo.repofile, configparser.RawConfigParser)

# Generated at 2022-06-17 05:39:48.271992
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({})
    repo = YumRepo(module)

    repo.repofile.add_section('epel')
    repo.repofile.set('epel', 'name', 'EPEL')
    repo.repofile.set('epel', 'baseurl', 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/')

    repo.repofile.add_section('rpmforge')
    repo.repofile.set('rpmforge', 'name', 'RPMforge')
    repo.repofile.set('rpmforge', 'baseurl', 'http://apt.sw.be/redhat/el7/en/$basearch/rpmforge')


# Generated at 2022-06-17 05:39:59.194789
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Create a fake module
    module = AnsibleModule(
        argument_spec={
            'repoid': {'type': 'str', 'required': True},
            'reposdir': {'type': 'str', 'default': '/etc/yum.repos.d'},
            'file': {'type': 'str', 'default': 'ansible-test'},
            'state': {'type': 'str', 'default': 'present'}
        },
        supports_check_mode=True
    )

    # Create a fake repo file
    repofile = configparser.RawConfigParser()
    repofile.add_section('epel')
    repofile.set('epel', 'name', 'EPEL YUM repo')

# Generated at 2022-06-17 05:40:04.692772
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule({
        'name': 'epel',
        'state': 'absent',
        'reposdir': 'tests/repos',
        'file': 'test.repo'
    })

    yum_repo = YumRepo(module)
    yum_repo.remove()
    yum_repo.save()

    assert os.path.isfile('tests/repos/test.repo') is False


# Generated at 2022-06-17 05:40:13.578916
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)
    yum_repo.repofile.add_section('test')
    yum_repo.repofile.set('test', 'key', 'value')
    yum_repo.params['dest'] = '/tmp/test.repo'
    yum_repo.save()
    assert os.path.isfile(yum_repo.params['dest'])
    os.remove(yum_repo.params['dest'])


# Generated at 2022-06-17 05:40:21.204826
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'baseurl': {'type': 'str'},
        'file': {'type': 'str', 'default': 'ansible-test'},
        'name': {'type': 'str', 'required': True},
        'reposdir': {'type': 'str', 'default': '/tmp'},
    })

    # Create a new YumRepo object
    repo = YumRepo(module)

    # Add a new repo
    repo.add()

    # Save the repo file
    repo.save()

    # Remove the repo file
    os.remove(repo.params['dest'])


# Generated at 2022-06-17 05:40:32.354586
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Create a module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            baseurl=dict(type='str'),
            file=dict(type='str', default='ansible-yum-repo'),
            reposdir=dict(type='str', default='/etc/yum.repos.d'),
            state=dict(type='str', default='present', choices=['absent', 'present']),
        ),
        supports_check_mode=True,
    )

    # Create a YumRepo object
    repo = YumRepo(module)

    # Add a repo
    repo.add()

    # Dump the repo file
    repo_string = repo.dump()

    # Check the result

# Generated at 2022-06-17 05:41:01.442776
# Unit test for function main

# Generated at 2022-06-17 05:41:10.742058
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Create a module
    module = AnsibleModule(
        argument_spec=dict(
            repoid=dict(type='str', required=True),
            description=dict(type='str'),
            file=dict(type='str', default='ansible-yum-repository'),
            baseurl=dict(type='str'),
            metalink=dict(type='str'),
            mirrorlist=dict(type='str'),
            reposdir=dict(type='str', default='/etc/yum.repos.d'),
        ),
        supports_check_mode=True,
    )

    # Create a YumRepo object
    yumrepo = YumRepo(module)

    # Add a repo
    yumrepo.add()

    # Save the repo file
    yumrepo.save()

   

# Generated at 2022-06-17 05:41:17.156080
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)

    assert yum_repo.module == module
    assert yum_repo.params == module.params
    assert yum_repo.section is None
    assert isinstance(yum_repo.repofile, configparser.RawConfigParser)



# Generated at 2022-06-17 05:41:21.495545
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            baseurl=dict(required=True),
            reposdir=dict(default='/etc/yum.repos.d'),
            file=dict(default='ansible-test-repo'),
            state=dict(default='present', choices=['absent', 'present']),
        ),
        supports_check_mode=True,
    )

    # Create an instance of YumRepo
    repo = YumRepo(module)

    # Add the repo
    repo.add()

    # Save the repo file
    repo.save()

    # Dump the repo file
    repo_string = repo.dump()

    # Check if the repo file is correct

# Generated at 2022-06-17 05:41:30.172792
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'repoid': {'required': True},
        'file': {'default': 'ansible-test'},
        'reposdir': {'default': '/tmp'},
        'baseurl': {'default': 'http://example.com/'},
        'name': {'default': 'Test repository'},
        'enabled': {'default': True},
        'gpgcheck': {'default': True},
        'gpgkey': {'default': 'http://example.com/gpgkey'},
        'exclude': {'default': ['kernel', 'kernel-devel']},
        'includepkgs': {'default': ['kernel-devel']},
        'state': {'default': 'present'},
    })

    # Create a new YumRep

# Generated at 2022-06-17 05:41:45.685539
# Unit test for function main

# Generated at 2022-06-17 05:41:53.292969
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)
    yum_repo.repofile.add_section('test')
    yum_repo.repofile.set('test', 'test', 'test')
    yum_repo.params['dest'] = '/tmp/test.repo'
    yum_repo.save()
    assert os.path.isfile('/tmp/test.repo')
    os.remove('/tmp/test.repo')


# Generated at 2022-06-17 05:42:07.157687
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        'file': {'type': 'str', 'default': 'test'},
        'repoid': {'type': 'str', 'default': 'test'},
        'reposdir': {'type': 'str', 'default': '/tmp'},
    })

    # Create a repo file
    repo_file = configparser.RawConfigParser()
    repo_file.add_section('test')
    repo_file.set('test', 'baseurl', 'http://example.com')
    with open('/tmp/test.repo', 'w') as fd:
        repo_file.write(fd)

    # Create a YumRepo object
    yum_repo = YumRepo(module)

    # Remove the section
    yum_repo.remove()



# Generated at 2022-06-17 05:42:11.941925
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(
        argument_spec=dict(
            repoid=dict(required=True),
            file=dict(default='ansible-yum-repository'),
            reposdir=dict(default='/etc/yum.repos.d'),
        )
    )

    repo = YumRepo(module)

    assert repo.module == module
    assert repo.params == module.params
    assert repo.section == module.params['repoid']
    assert repo.repofile == configparser.RawConfigParser()



# Generated at 2022-06-17 05:42:25.434796
# Unit test for method add of class YumRepo

# Generated at 2022-06-17 05:43:07.371695
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule({
        'name': 'epel',
        'file': 'external_repos',
        'reposdir': '/tmp',
        'baseurl': 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/',
        'gpgcheck': False,
    })

    yum_repo = YumRepo(module)
    yum_repo.add()
    yum_repo.save()

    assert os.path.isfile('/tmp/external_repos.repo')

    # Cleanup
    os.remove('/tmp/external_repos.repo')


# Generated at 2022-06-17 05:43:20.689600
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'name': {'required': True},
        'baseurl': {'required': True},
        'reposdir': {'default': '/etc/yum.repos.d'},
        'file': {'default': 'ansible-test'},
        'gpgcheck': {'default': True},
        'gpgkey': {'default': 'https://dl.fedoraproject.org/pub/epel/RPM-GPG-KEY-EPEL-7'},
        'enabled': {'default': True},
        'exclude': {'default': ['kernel*', '*debug*']},
        'includepkgs': {'default': ['kernel*', '*debug*']},
        'state': {'default': 'present'},
    })

# Generated at 2022-06-17 05:43:34.186872
# Unit test for function main

# Generated at 2022-06-17 05:43:45.236444
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'baseurl': {'type': 'str'},
        'file': {'type': 'str'},
        'name': {'type': 'str'},
        'reposdir': {'type': 'str'},
        'state': {'type': 'str'},
    })
    module.params['repoid'] = 'epel'
    module.params['baseurl'] = 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/'
    module.params['file'] = 'epel'
    module.params['name'] = 'epel'
    module.params['reposdir'] = '/etc/yum.repos.d'
    module.params['state'] = 'present'

# Generated at 2022-06-17 05:43:57.257220
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'name': {'required': True},
        'file': {'default': 'ansible-test'},
        'reposdir': {'default': '/tmp'},
    })

    # Create a YumRepo object
    yum_repo = YumRepo(module)

    # Add a repo
    yum_repo.add()

    # Save the repo file
    yum_repo.save()

    # Read the repo file
    repofile = configparser.RawConfigParser()
    repofile.read(os.path.join(yum_repo.params['reposdir'], "%s.repo" % yum_repo.params['file']))

    # Check if the repo was added

# Generated at 2022-06-17 05:44:06.214182
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)
    yum_repo.repofile.add_section('test')
    yum_repo.repofile.set('test', 'test_key', 'test_value')
    assert yum_repo.dump() == "[test]\ntest_key = test_value\n\n"



# Generated at 2022-06-17 05:44:17.070780
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'baseurl': {'type': 'str'},
        'file': {'type': 'str', 'default': 'test'},
        'repoid': {'type': 'str', 'default': 'test'},
        'reposdir': {'type': 'str', 'default': '/tmp'},
        'state': {'type': 'str', 'default': 'present'}
    })

    yum_repo = YumRepo(module)

    # Add a new repo
    yum_repo.add()

    # Check if the repo was added
    assert yum_repo.repofile.has_section(yum_repo.section)

    # Check if the repo has the baseurl
    assert yum_repo.repofile.has_

# Generated at 2022-06-17 05:44:31.413880
# Unit test for method dump of class YumRepo

# Generated at 2022-06-17 05:44:40.691858
# Unit test for function main

# Generated at 2022-06-17 05:44:50.398299
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)
    yum_repo.repofile.add_section('test')
    yum_repo.repofile.set('test', 'test', 'test')
    yum_repo.params['dest'] = '/tmp/test.repo'
    yum_repo.save()
    assert os.path.isfile(yum_repo.params['dest'])
    os.remove(yum_repo.params['dest'])


# Generated at 2022-06-17 05:46:04.842982
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(
        argument_spec=dict(
            baseurl=dict(type='str'),
            dest=dict(type='str'),
            file=dict(type='str'),
            repoid=dict(type='str'),
            reposdir=dict(type='str'),
        ),
        supports_check_mode=True
    )

    # Create a new YumRepo object
    repo = YumRepo(module)

    # Add a new section
    repo.add()

    # Save the repo file
    repo.save()

    # Remove the section
    repo.remove()

    # Save the repo file
    repo.save()



# Generated at 2022-06-17 05:46:14.598752
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Create a module
    module = AnsibleModule(argument_spec={
        'baseurl': {'type': 'str'},
        'file': {'type': 'str'},
        'reposdir': {'type': 'str'},
        'repoid': {'type': 'str'},
    })

    # Create a YumRepo object
    repo = YumRepo(module)

    # Add a repo
    repo.add()

    # Check the result
    assert repo.repofile.has_section('epel')
    assert repo.repofile.get('epel', 'baseurl') == 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/'


# Generated at 2022-06-17 05:46:25.231833
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({})
    repo = YumRepo(module)

    # Add a section
    repo.repofile.add_section('test')
    repo.repofile.set('test', 'key1', 'value1')
    repo.repofile.set('test', 'key2', 'value2')

    # Add another section
    repo.repofile.add_section('test2')
    repo.repofile.set('test2', 'key1', 'value1')
    repo.repofile.set('test2', 'key2', 'value2')

    # Dump the repo file
    repo_string = repo.dump()

    # Check the result

# Generated at 2022-06-17 05:46:31.056703
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Create a module
    module = AnsibleModule(
        argument_spec={
            'repoid': {'required': True, 'type': 'str'},
            'reposdir': {'default': '/etc/yum.repos.d', 'type': 'path'},
            'file': {'default': 'ansible-test', 'type': 'str'}
        },
        supports_check_mode=True
    )

    # Create a repo object
    repo = YumRepo(module)

    # Create a repo file
    repo.repofile.add_section('test')
    repo.repofile.set('test', 'baseurl', 'http://example.com')

    # Remove the repo
    repo.remove()

    # Check if the repo was removed
    assert not repo.repofile.has_

# Generated at 2022-06-17 05:46:36.203101
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)
    assert yum_repo.module == module
    assert yum_repo.params == module.params
    assert yum_repo.section == module.params['repoid']



# Generated at 2022-06-17 05:46:42.161142
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)
    yum_repo.repofile.add_section('test')
    yum_repo.repofile.set('test', 'test', 'test')
    yum_repo.params['dest'] = '/tmp/test.repo'
    yum_repo.save()
    assert os.path.isfile('/tmp/test.repo')
    os.remove('/tmp/test.repo')


# Generated at 2022-06-17 05:46:47.193055
# Unit test for function main

# Generated at 2022-06-17 05:46:56.958179
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        'file': {'type': 'str', 'default': 'test'},
        'reposdir': {'type': 'str', 'default': '/tmp'},
        'repoid': {'type': 'str', 'default': 'test'},
    })

    yum_repo = YumRepo(module)
    yum_repo.remove()
    assert not yum_repo.repofile.has_section('test')


# Generated at 2022-06-17 05:47:01.787369
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={
        'file': {'type': 'str', 'default': 'test'},
        'reposdir': {'type': 'str', 'default': '/tmp'},
        'dest': {'type': 'str', 'default': '/tmp/test.repo'},
        'repoid': {'type': 'str', 'default': 'test'},
        'baseurl': {'type': 'str', 'default': 'http://example.com'},
        'state': {'type': 'str', 'default': 'present'},
    })
    yum_repo = YumRepo(module)
    yum_repo.add()
    yum_repo.save()
    assert os.path.isfile(yum_repo.params['dest'])
   

# Generated at 2022-06-17 05:47:16.629804
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'baseurl': {'type': 'str'},
        'dest': {'type': 'str'},
        'file': {'type': 'str'},
        'repoid': {'type': 'str'},
        'reposdir': {'type': 'str'},
    })

    # Create a YumRepo object
    yum_repo = YumRepo(module)

    # Create a repo file
    yum_repo.add()

    # Save the repo file
    yum_repo.save()

    # Check if the repo file was created
    assert os.path.isfile(yum_repo.params['dest'])

    # Remove the repo file
    os.remove(yum_repo.params['dest'])

