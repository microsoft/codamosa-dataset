

# Generated at 2022-06-25 03:37:54.086845
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    repo = YumRepo()
    repo.save()


# Generated at 2022-06-25 03:37:55.955713
# Unit test for constructor of class YumRepo
def test_YumRepo():
    test_YumRepo = main()
    print("The module is", test_YumRepo)


# Generated at 2022-06-25 03:37:58.248361
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    test_YumRepo = YumRepo(main())
    test_YumRepo.save()


# Generated at 2022-06-25 03:37:59.794593
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    var_0 = YumRepo(AnsibleModule)
    var_0.dump()


# Generated at 2022-06-25 03:38:09.566600
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_1 = AnsibleModule()
    var_2 = {'baseurl': None, 'name': 'test1', 'state': 'present', 'repoid': 'test1', 'reposdir': '/etc/yum.repos.d', 'file': 'test1.repo'}
    var_3 = YumRepo(var_1)
    var_3.params = var_2
    var_3.section = 'test2'
    var_3.repofile = configparser.RawConfigParser()
    var_3.repofile.add_section('test1')
    var_3.repofile.set('test1', 'not_allowed', 'abc')
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        var_3.save()

# Unit test

# Generated at 2022-06-25 03:38:12.665843
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Create an instance of class YumRepo
    var_YumRepo = YumRepo(module)
    # Call method dump of var_YumRepo
    res_YumRepo_dump = var_YumRepo.dump()


# Generated at 2022-06-25 03:38:22.828374
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    # test_0
    class StubModule0(object):
        def fail_json(self, *args, **kwargs):
            return {'failed': True}
        def exit_json(self, **kwargs):
            return {}

    module0 = StubModule0()
    module0.params = {'file': 'default',
    'warn': False,
    'state': 'present',
    'basearch': 'amd64',
    'changed': False,
    'reposdir': '/etc/yum.repos.d',
    'diff_mode': False,
    'check_mode': False}
    module0.params['dest'] = None
    class StubClass0():
        pass
    var0 = StubClass0()
    var0.sections = lambda: ['some section']
    module0.params['dest']

# Generated at 2022-06-25 03:38:33.588146
# Unit test for method add of class YumRepo

# Generated at 2022-06-25 03:38:36.430648
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    enabled=None

# Generated at 2022-06-25 03:38:43.656710
# Unit test for method add of class YumRepo

# Generated at 2022-06-25 03:39:02.670848
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_0 = YumRepo(AnsibleModule)
    var_0.add()


# Generated at 2022-06-25 03:39:03.897271
# Unit test for constructor of class YumRepo
def test_YumRepo():
    test_case_0()

test_YumRepo()

# Generated at 2022-06-25 03:39:06.267005
# Unit test for constructor of class YumRepo
def test_YumRepo():
    var_0 = YumRepo()


if __name__ == '__main__':
    yum_repo = YumRepo()
    yum_repo.repo_pack()

# Generated at 2022-06-25 03:39:13.039118
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    print()
    print("Test case test_YumRepo_add is running...")
    # Initialize the object
    yum_repo = YumRepo(AnsibleModule())
    # Call the desired function
    yum_repo.add()
    # Run test case
    assert (yum_repo.section == "epel")


# Generated at 2022-06-25 03:39:14.898886
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_0 = YumRepo(module)
    var_0.save()


# Generated at 2022-06-25 03:39:17.256187
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    assert 'foo' == True


# Generated at 2022-06-25 03:39:27.620659
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Initialize module parameters
    params = {
        'async': False,
        'baseurl': 'http://example.com',
        'dest': '/etc/yum.repos.d/epel.repo',
        'enabled': True,
        'file': 'epel',
        'gpgcheck': True,
        'gpgkey': 'file:///etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7',
        'name': 'epel',
        'reposdir': '/etc/yum.repos.d',
        'repoid': 'epel',
        'sslverify': False,
    }
    # Get an instance of class YumRepo
    yum_repo = YumRepo(params)
    # Get parameters from getattr()


# Generated at 2022-06-25 03:39:28.242012
# Unit test for constructor of class YumRepo
def test_YumRepo():
    instance = YumRepo()


# Generated at 2022-06-25 03:39:29.385949
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    y = YumRepo()
    y.remove()


# Generated at 2022-06-25 03:39:30.027875
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 03:39:52.211425
# Unit test for function main
def test_main():
    var_0 = dict()
    var_0["async"] = True
    # var_0["bandwidth"] =
    var_0["baseurl"] = "http://example.com"
    # var_0["cost"] =
    # var_0["deltarpm_metadata_percentage"] =
    # var_0["deltarpm_percentage"] =
    var_0["description"] = "Example Repo"
    var_0["dest"] = "/etc/yum.repos.d/example.repo"
    var_0["enabled"] = False
    var_0["enablegroups"] = True
    var_0["exclude"] = ["example_exclude_1", "example_exclude_2"]
    var_0["failovermethod"] = "roundrobin"

# Generated at 2022-06-25 03:39:53.667116
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    main()


# Generated at 2022-06-25 03:40:05.062245
# Unit test for constructor of class YumRepo
def test_YumRepo():
    data = {}
    data['module'] = None
    data['params'] = {}
    # Repoid
    data['params']['repoid'] = "epel"
    # Repo file name
    data['params']['file'] = "epel"
    data['params']['dest'] = "/etc/yum.repos.d/epel.repo"
    # Repos dir
    data['params']['reposdir'] = "/etc/yum.repos.d"
    req_params = (data['params']['baseurl'], data['params']['metalink'], data['params']['mirrorlist'])
    YumRepo(data)


# Generated at 2022-06-25 03:40:12.763062
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    assert (test_case_0() == '''\
[Repo_0]
gpgcheck = False
http_caching = all
keepalive = True
keepcache = True
metadata_expire = 30
proxy = None
sslverify = True

[Repo_1]
gpgcheck = False
http_caching = all
keepalive = True
keepcache = True
metadata_expire = 30
proxy = None
sslverify = True
''')


# Generated at 2022-06-25 03:40:19.162978
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    param_0 = None
    var_0 = YumRepo(param_0)
    var_0.add()
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 03:40:25.614265
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    import os
    ans = os.environ.get("ansible_service_plugins")
    if ans is None:
       ans = "/etc/ansible/plugins/modules/service/"
    else:
       ans = ans+"/service/"
    if not os.path.exists(ans):
       print("Path not found: %s"%ans)
    print("Path: %s"%ans)
    os.environ["ANSIBLE_MODULE_UTILS"]=ans+"/../utils"
    test_case_0()

# Generated at 2022-06-25 03:40:30.735422
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_1 = YumRepo(module)
    var_1.add()


# Generated at 2022-06-25 03:40:41.457145
# Unit test for constructor of class YumRepo
def test_YumRepo():
    class Module(object):
        def __init__(self):
            self.params = dict()
        def fail_json(self, **kwargs):
            raise ValueError
    class Params(object):
        repoid = 'epel'
        file = 'external_repos'
        reposdir = '../external_repos'
        dest = '../external_repos'
    module = Module()
    params = Params()
    module.params = params
    try:
        yum_repo = YumRepo(module)
    except Exception as e:
        print("Exception: {}".format(e))
    assert yum_repo.params['dest'] == '../external_repos/external_repos.repo'


# Generated at 2022-06-25 03:40:44.031639
# Unit test for constructor of class YumRepo
def test_YumRepo():
    var_yum_repo = YumRepo(AnsibleModule)



# Generated at 2022-06-25 03:40:45.473925
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_0 = YumRepo("string")
    var_0.save()


# Generated at 2022-06-25 03:41:24.964020
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_0 = main()
    var_0.add()


# Generated at 2022-06-25 03:41:31.349389
# Unit test for method dump of class YumRepo

# Generated at 2022-06-25 03:41:35.185555
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Setup
    var_0 = main()
    # Exercise
    var_1 = var_0.remove()
    assert var_1 == None
    # Cleanup
    if __name__ == '__main__': test_case_0()


# Generated at 2022-06-25 03:41:42.459061
# Unit test for constructor of class YumRepo

# Generated at 2022-06-25 03:41:53.927497
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    import tempfile
    import shutil
    import os
    import sys

    # prepare the code and call the put method

# Generated at 2022-06-25 03:42:03.690782
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_1 = {}
    var_1['async'] = None
    var_1['baseurl'] = None
    var_1['bandwidth'] = None
    var_1['cost'] = None
    var_1['deltarpm_metadata_percentage'] = None
    var_1['deltarpm_percentage'] = None
    var_1['dest'] = 'test_repo_file.repo'
    var_1['enablegroups'] = None
    var_1['enabled'] = None
    var_1['exclude'] = None
    var_1['failovermethod'] = None
    var_1['file'] = 'test'
    var_1['gpgcakey'] = None
    var_1['gpgcheck'] = None
    var_1['gpgkey'] = None
    var

# Generated at 2022-06-25 03:42:07.396732
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    arg_0 = None
    var_0 = YumRepo(arg_0)


# Generated at 2022-06-25 03:42:16.525241
# Unit test for constructor of class YumRepo
def test_YumRepo():
    mock_module = Mock()
    test_obj = YumRepo(mock_module)

if __name__ == '__main__':
    state = "present"
    repoid = "epel"
    reposdir = "/etc/yum.repos.d"
    changes = {}
    test_obj = YumRepo(mock_module)
    test_obj.add()
    test_obj.save()
    test_obj.remove()
    test_obj.dump()
    test_obj.add()
    test_obj.save()
    test_obj.remove()
    test_obj.dump()



# Generated at 2022-06-25 03:42:20.893008
# Unit test for method remove of class YumRepo

# Generated at 2022-06-25 03:42:23.371521
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
  yum_repo = YumRepo()
  var_0 = yum_repo.dump()
  if var_0:
    var_0 = 1
  else:
    var_0 = 0
  return var_0


# Generated at 2022-06-25 03:43:41.846069
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    new_repofile = configparser.RawConfigParser()
    new_repofile.read('/tmp/test_YumRepo_save.repo')
    repofile = configparser.RawConfigParser()
    repofile.add_section('epel')
    repofile.set('epel', 'baseurl', 'http://test.url.com/')
    repofile.set('epel', 'priority', '2')
    repofile.set('epel', 'gpgcheck', '1')

    try:
        with open('/tmp/test_YumRepo_save.repo', 'w') as fd:
            repofile.write(fd)
    except IOError as e:
        print("Problems handling file /tmp/test_YumRepo_save.repo.")


# Generated at 2022-06-25 03:43:43.977752
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_YumRepo= YumRepo(test_case_0)
    var_YumRepo.add()


# Generated at 2022-06-25 03:43:49.407610
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(argument_spec={'test': dict(default='test', type='list')})
    var_0 = YumRepo(module)
    assert type(var_0) == YumRepo


# Generated at 2022-06-25 03:43:57.046374
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Mock the module
    module_mock = mockModule()

    # Test calling of constructor without module
    test_object = YumRepo(None)
    assert test_object is not None, "Constructor of class YumRepo should not return None."

    # Test calling of constructor with a module
    test_object = YumRepo(module_mock)
    assert test_object is not None, "Constructor of class YumRepo should not return None."



# Generated at 2022-06-25 03:44:01.697717
# Unit test for function main
def test_main():
    # Prepare parameters
    params = dict(  name='epel-6',
                    description='Extra Packages for Enterprise Linux 6 - $basearch',
                    baseurl='https://download.fedoraproject.org/pub/epel/6/$basearch',
                    enabled=1,
                    gpgcheck=1,
                    gpgkey='file:///etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-6',
                    repo_gpgcheck=1,
                    state='present')

    # Generate result
    result = main(params)

    # Print result
    print(result)

# Command line execution
if __name__ == '__main__':
    # Execute main function
    main()

# Generated at 2022-06-25 03:44:02.853777
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_1 = YumRepo()
    test_0 = YumRepo.remove(var_1)


# Generated at 2022-06-25 03:44:14.047226
# Unit test for constructor of class YumRepo

# Generated at 2022-06-25 03:44:15.355227
# Unit test for function main
def test_main():
    with mock.patch.object(sys, 'argv', ['main']):
        test_case_0()


# Generated at 2022-06-25 03:44:18.709638
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_0 = YumRepo()
    var_0.save()


# Generated at 2022-06-25 03:44:19.557732
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    var_1 = main()


# Generated at 2022-06-25 03:47:03.468891
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module_args = dict(
      baseurl='https://download.fedoraproject.org/pub/epel/$releasever/$basearch/',
      dest='/etc/yum.repos.d/epel.repo',
      file='epel',
      gpgcheck='no',
      name='epel',
      reposdir='/etc/yum.repos.d',
      state='present')
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    yum_repo = YumRepo(module)
    yum_repo.add()
    dump_result = yum_repo.dump()

# Generated at 2022-06-25 03:47:05.472585
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_0 = main()
    assert True == var_0


# Generated at 2022-06-25 03:47:10.384509
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    var_1 = test_case_0()
    try:
        var_1.dump()
    except:
        raise Exception("dump() exception.")


# Generated at 2022-06-25 03:47:22.134014
# Unit test for method save of class YumRepo
def test_YumRepo_save():

    with open('/tmp/yum_repository.repo', 'w') as fd:
        fd.write('[test]\n')
        fd.write('async = 1\n')
        fd.write('baseurl = test\n')
        fd.write('enabled = 1\n')
        fd.write('exclude = test\n')
        fd.write('gpgcakey = test\n')
        fd.write('gpgcheck = 1\n')
        fd.write('gpgkey = test\n')
        fd.write('http_caching = all\n')
        fd.write('include = test\n')
        fd.write('includepkgs = test\n')
        fd.write('keepalive = 1\n')

# Generated at 2022-06-25 03:47:24.820107
# Unit test for constructor of class YumRepo
def test_YumRepo():
    assert test_case_0() == '_ansible_module_yum_repository.params'

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-25 03:47:34.634906
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    params = dict(
        baseurl = "https://download.fedoraproject.org/pub/epel/$releasever/$basearch/"
    )
