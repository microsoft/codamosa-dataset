

# Generated at 2022-06-25 03:37:51.679352
# Unit test for constructor of class YumRepo
def test_YumRepo():
    test_case_0()

# --- main ---

# Generated at 2022-06-25 03:37:54.641087
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    yum_repo_0 = YumRepo(None)
    yum_repo_0.save()


# Generated at 2022-06-25 03:37:59.042308
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    yum_repo_1 = YumRepo(yum_repo_0)
    str_1 = yum_repo_1.dump()
    str_2 = '[epel]\nbaseurl = https://download.fedoraproject.org/pub/epel/$releasever/$basearch/\n\n'
    assert str_1 == str_2


# Generated at 2022-06-25 03:38:02.531490
# Unit test for method dump of class YumRepo

# Generated at 2022-06-25 03:38:04.504851
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)
    result_0 = yum_repo_0.add()
    assert result_0 is None


# Generated at 2022-06-25 03:38:07.301101
# Unit test for constructor of class YumRepo
def test_YumRepo():
    str_0 = 'P677y'
    try:
       yum_repo_0 = YumRepo(str_0)
    except Exception as e:
        print('Caught exception:', e)
    print('Test of constructor passed!')


# Generated at 2022-06-25 03:38:08.878420
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    str_0 = 2
    yum_repo_0 = YumRepo(str_0)

if __name__ == '__main__':
    # Unit tests
    test_case_0()
    test_YumRepo_save()

# Generated at 2022-06-25 03:38:10.430389
# Unit test for constructor of class YumRepo
def test_YumRepo():
    try:
        # test case 0
        test_case_0()
        print('test case 0 passed')
    except:
        print('test case 0 failed')

test_YumRepo()

# Generated at 2022-06-25 03:38:12.205596
# Unit test for function main
def test_main():
    pass

# Entry point for the module

# Generated at 2022-06-25 03:38:22.520040
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    yum_repo_0 = YumRepo(None)
    yum_repo_0.repofile = [55]
    yum_repo_0.repofile = [None]
    yum_repo_0.repofile = [None]
    yum_repo_0.repofile = [54]
    yum_repo_0.repofile = [None]
    yum_repo_0.repofile = [None]
    yum_repo_0.params = [11]
    yum_repo_0.params = [None]
    yum_repo_0.params = [None]
    yum_repo_0.params = [None]
    yum_repo_0.params = [None]
    yum_re

# Generated at 2022-06-25 03:38:42.467707
# Unit test for function main
def test_main():
    # Test for the case: no optional arguments
    module_around_the_world = AnsibleModule({
        'cost': 5,
        'file': 'str_0',
        'file_0': 'str_0',
        'keepcache': '0',
        'name': 'str_0',
        'priority': 4,
        'reposdir': 'str_0',
    }, False)
    main()
    module_around_the_world.exit_json(changed=True)

    # Test for the case: only optional arguments

# Generated at 2022-06-25 03:38:44.305623
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)
    yum_repo_0.add()


# Generated at 2022-06-25 03:38:50.241499
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    str_1 = 'P9gY6'
    yum_repo_1 = YumRepo(str_1)
    test_case_0()
    test_case_1()
    test_case_2()

# Tests for class YumRepo

# Generated at 2022-06-25 03:38:51.458122
# Unit test for constructor of class YumRepo
def test_YumRepo():
    test_case_0()


# Generated at 2022-06-25 03:38:54.607151
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():

    str_0 = 'T1l'
    test_case_0(str_0)



# Generated at 2022-06-25 03:38:59.825910
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)
    yum_repo_0.remove()


# Generated at 2022-06-25 03:39:07.543611
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():

    # Setup
    str_0 = 'Fy7'
    yum_repo_0 = YumRepo(str_0)
    str_1 = 'L'
    yum_repo_0.repofile = str_1
    str_2 = 'zp'
    yum_repo_0.allowed_params = str_2
    str_3 = 'Sai1'
    yum_repo_0.list_params = str_3

    # Exercise
    retval_0 = yum_repo_0.dump()
    str_4 = 'gFq'
    str_5 = 'hZ'
    str_6 = 'DU6'
    str_7 = 'd1l'
    str_8 = 'Z5r'
    str_9 = 'e'


# Generated at 2022-06-25 03:39:09.341708
# Unit test for constructor of class YumRepo
def test_YumRepo():
    assert issubclass(YumRepo, object)
    test_case_0()



# Generated at 2022-06-25 03:39:12.744651
# Unit test for constructor of class YumRepo
def test_YumRepo():
    test_case_0()


# Generated at 2022-06-25 03:39:20.901243
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)
    str_dump_0 = yum_repo_0.dump()
    str_dump_1 = yum_repo_0.dump()
    str_dump_2 = '{~#!]o5@5'
    str_dump_7 = 'Jw0!1c!p@'
    str_dump_3 = str_dump_2.index('o')
    str_dump_4 = '#' in str_dump_0
    str_dump_5 = 'EPEL YUM repo'
    str_dump_6 = str_dump_5.index('Y')
    str_dump_8 = 'rhel'

# Generated at 2022-06-25 03:39:59.252199
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    base_path = './YumRepo/tmp'

    # Create os.path.join(base_path, 'module.params')
    fd = os.open(path.join(base_path, 'module.params'), os.O_RDWR|os.O_CREAT)
    os.close(fd)

    # Create YumRepo
    params_0 = {"state": "present", "name": "ansible"}
    yum_repo_0 = YumRepo(params_0)

    # Unit test for dump
    yum_repo_0.dump()

    # Remove os.path.join(base_path, 'module.params')
    os.remove(os.path.join(base_path, 'module.params'))


# Generated at 2022-06-25 03:40:06.972583
# Unit test for constructor of class YumRepo
def test_YumRepo():
    str_a = 'NAlsN'
    yum_repo_a = YumRepo(str_a)
    str_b = 'c3qmP'
    str_c = 'B8J1Q'
    dict_d = {'file': str_b, 'reposdir': str_c}
    yum_repo_a.module.params = dict_d
    str_e = 'xuJET'
    dict_d = {'section': str_e, 'dest': str_c + os.path.sep + str_b + '.repo'}
    assert(yum_repo_a.params == dict_d)


# Generated at 2022-06-25 03:40:09.758147
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    yum_repo = YumRepo(test_case_0)
    yum_repo.save()


# Generated at 2022-06-25 03:40:17.012401
# Unit test for function main
def test_main():
    # Create a test module
    data = {
        'name': 'foo',
        'state': 'present',
        'baseurl': 'http://foo.bar/',
        'dest': '/etc/yum.repos.d/foo.repo',
        'description': 'foo-repo',
        'file': 'foo',
        'repoid': 'foo',
    }

# Generated at 2022-06-25 03:40:20.783102
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 03:40:26.834898
# Unit test for constructor of class YumRepo
def test_YumRepo():
    yum_repo_0 = YumRepo(None)
    yum_repo_1 = YumRepo(0)
    yum_repo_2 = YumRepo(1)
    yum_repo_3 = YumRepo('module')
    yum_repo_4 = YumRepo(True)
    yum_repo_5 = YumRepo(False)


# Generated at 2022-06-25 03:40:33.473907
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    str_1 = 'tSZkn'
    str_2 = 'Dsm'
    yum_repo_1 = YumRepo(str_1)
    yum_repo_1.section = str_2
    yum_repo_1.remove()


# Generated at 2022-06-25 03:40:41.123421
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    str_0 = 'T3oc3'
    print('\n##### Testing add() method of class YumRepo #####')
    print('\n### Case 0 ###')
    str_1 = 'hvM6U'
    try:
        test_case_0()
        print('\nCase 0: PASSED')
    except AssertionError as e:
        print('Case 0: FAILED')
        print('\nReason: ')
        print(e)
        print('\n')


# Generated at 2022-06-25 03:40:43.996960
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    yum_repo_0 = YumRepo(None)


# Generated at 2022-06-25 03:40:51.856568
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    str_0 = 'P677y'
    str_1 = 'VH,u'
    str_2 = '!;eQ'
    str_3 = '9X@x'
    str_4 = 'y[U'
    str_5 = '?-J=`b'
    yum_repo_0 = YumRepo(str_0)
    str_6 = 'zP*.a'
    str_7 = '*{Q#'
    str_8 = ':g('
    str_9 = 'Zo}'
    str_10 = 'Xs"s'
    str_11 = ';P'
    str_12 = '=m'
    str_13 = 'Q}|y'
    str_14 = ',)+'
    str_15 = '&_'

# Generated at 2022-06-25 03:41:56.564414
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)
    yum_repo_0.remove()
    
test_YumRepo_remove()
test_case_0()


# Generated at 2022-06-25 03:41:59.448008
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)


# Generated at 2022-06-25 03:42:01.823859
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    str_1 = 'X9h6M'
    yum_repo_1 = YumRepo(str_1)
    yum_repo_1.dump()

# Generated at 2022-06-25 03:42:06.358639
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    str_0 = '{@I:H U'
    test_YumRepo_0 = YumRepo(str_0)
    str_1 = 'EZ=S0'
    dict_0 = {str_1: '9$ype'}
    test_YumRepo_0.add(dict_0)


# Generated at 2022-06-25 03:42:09.311339
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    test_case_0()


# Generated at 2022-06-25 03:42:10.777462
# Unit test for constructor of class YumRepo
def test_YumRepo():
    yum_repo = test_case_0()


# Generated at 2022-06-25 03:42:15.494875
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    str_0 = 'NX}x'
    yum_repo_0 = YumRepo(str_0)
    str_0 = '.p'
    yum_repo_0.remove(str_0)

if __name__ == '__main__':
    test_case_0()
    test_YumRepo_remove()

# Generated at 2022-06-25 03:42:24.641047
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule({'name': 'epel'})
    module.check_mode = False

    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)
    yum_repo_0.params['name'] = 'epel'
    yum_repo_0.params['reposdir'] = '/etc/yum.repos.d'
    yum_repo_0.params['file'] = 'epel'
    yum_repo_0.params['baseurl'] = 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/'
    yum_repo_0.params['enabled'] = 1
    str_1 = 'VuLmw'

# Generated at 2022-06-25 03:42:31.998543
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    str_0 = 'J370'
    yum_repo_0 = YumRepo(str_0)

    # Save the repo file
    yum_repo_0.save()

    str_1 = 'C814'
    yum_repo_1 = YumRepo(str_1)

    # Save the repo file
    yum_repo_1.save()


# Generated at 2022-06-25 03:42:35.889270
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    str_0 = 'P677y'
    yum_repo_0 = YumRepo(str_0)



# Generated at 2022-06-25 03:44:39.991233
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # yum_repo_0 = YumRepo()
    assert yum_repo_0 is None


# Generated at 2022-06-25 03:44:44.422964
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    print ('\n**** Executing unit test for method add of class YumRepo ...')
    try:
        mod_ = AnsibleModule({})
        yumRepo_ = YumRepo(mod_)
        yumRepo_.add()
    except Exception as ex:
        print('\n**** Unit test for method add of class YumRepo failed.\n')
        print(traceback.format_exc())
    else:
        print('\n**** Unit test for method add of class YumRepo success.\n')


# Generated at 2022-06-25 03:44:45.023315
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    test_case_0()


# Generated at 2022-06-25 03:44:47.395621
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    test_0 = False
    if test_0:
        # import class for testing
        yum_repo_0 = YumRepo(False)
        yum_repo_0.save()


# Generated at 2022-06-25 03:44:50.236300
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    assert 'P677y' not in c_3


# Generated at 2022-06-25 03:44:51.728139
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    test_case_0()


# Generated at 2022-06-25 03:44:57.135939
# Unit test for constructor of class YumRepo
def test_YumRepo():
    YumRepo.__init__(AnsibleModule, 'module')
    if not hasattr(YumRepo, 'module') or not hasattr(YumRepo, 'params') or not hasattr(YumRepo, 'section') or not hasattr(YumRepo, 'repofile'):
        raise Exception('The function YumRepo.__init__() has not set one of the attributes.')


# Generated at 2022-06-25 03:45:00.471178
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    try:
        assert test_case_0() == 'P677y'
    except AssertionError as e:
        print('Expected:', 'P677y', sep=' ', end='\n', flush=True)
        print('Actual  :', test_case_0(), sep=' ', end='\n', flush=True)
        print('AssertionError:', e, sep=' ', end='\n', flush=True)


# Generated at 2022-06-25 03:45:06.358549
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    yum_repo_0 = YumRepo(str_0)
    str_0 = 'P677y'
    yum_repo_0.remove()


# Generated at 2022-06-25 03:45:14.102832
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    yum_repo_0 = YumRepo(AnsibleModule(arg_spec={}))
    # We need to mock the methods inside the class to be able to test them
    yum_repo_0.repofile = configparser.RawConfigParser()
    yum_repo_0.params = {'baseurl': None}
    yum_repo_0.add()
    yum_repo_0.save()
