

# Generated at 2022-06-25 03:37:51.982261
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():

    # Arrange
    main()

    # Act
    yum_object.dump()


# Generated at 2022-06-25 03:37:56.045973
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Test YumRepo(AnsibleModule)
    myModule = AnsibleModule(
        argument_spec={},
        required_one_of=[['name']],
        supports_check_mode=True,
    )

    myRepo = YumRepo(myModule)


# Generated at 2022-06-25 03:37:57.596295
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_1 = YumRepo()
    var_1.remove()


# Generated at 2022-06-25 03:38:00.043916
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # instantiate class
    new_obj = YumRepo(module)

    # Call add() method on new_obj
    new_obj.add()


# Generated at 2022-06-25 03:38:04.652416
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 03:38:05.425128
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_2 = main()


# Generated at 2022-06-25 03:38:15.812603
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_1 = None
    var_YumRepo_1 = YumRepo(var_1)
    var_2 = None
    var_YumRepo_1.module(var_2)
    var_3 = None
    var_YumRepo_1.params(var_3)
    var_4 = None
    var_YumRepo_1.section(var_4)
    var_5 = None
    var_5 = configparser.RawConfigParser()
    var_YumRepo_1.repofile(var_5)
    var_6 = None
    var_6 = [None, None, None]
    var_YumRepo_1.allowed_params(var_6)
    var_7 = None

# Generated at 2022-06-25 03:38:18.881746
# Unit test for constructor of class YumRepo
def test_YumRepo():
    yum_repo = YumRepo(module)
    print(yum_repo.module)
    print(yum_repo.params)
    print(yum_repo.section)
    print(yum_repo.allowed_params)
    print(yum_repo.list_params)


# Generated at 2022-06-25 03:38:19.875622
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    repo = YumRepo()
    print(repo.save())


# Generated at 2022-06-25 03:38:26.110414
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    args = dict(
        baseurl=dict(type='str', required=True),
        dest=dict(type='path', required=True),
        exclude=dict(type='list', required=False),
        file=dict(type='str', required=True),
        includepkgs=dict(type='list', required=False),
        metalink=dict(type='str', required=False),
        mirrorlist=dict(type='str', required=True),
        module_hotfixes=dict(type='bool', required=False),
        name=dict(type='str', required=False),
        reposdir=dict(type='str', required=False),
        section=dict(type='str', required=False),
    )


# Generated at 2022-06-25 03:38:47.124859
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_1 = YumRepo("var_1")
    var_1.params = {"dest)": "/etc/yum.repos.d/var_2.repo"}
    var_1.repofile = configparser.RawConfigParser()
    var_1.repofile.add_section("var_3")
    var_1.repofile.set("var_3", "var_4", "var_5")
    var_1.repofile.write = MagicMock(return_value=var_1.repofile.write)
    var_1.repofile.read = MagicMock(return_value=var_1.repofile.read)
    var_1.repofile.remove_section = MagicMock(return_value=None)

# Generated at 2022-06-25 03:38:49.432847
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    YumRepo.add()


# Generated at 2022-06-25 03:38:50.526577
# Unit test for function main
def test_main():
    print ("Starting test_main")
    result = main()
    print ("End of test_main")


# Generated at 2022-06-25 03:38:52.078572
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_0 = main()
    var_0.add()


# Generated at 2022-06-25 03:39:04.035825
# Unit test for method add of class YumRepo

# Generated at 2022-06-25 03:39:05.811582
# Unit test for constructor of class YumRepo
def test_YumRepo():
    print("test_YumRepo\n")
    var_0 = YumRepo()
    var_0.test_function()


# Generated at 2022-06-25 03:39:08.620332
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    var_0 = YumRepo(None)
    assert isinstance(var_0.dump(), str)


# Generated at 2022-06-25 03:39:18.683736
# Unit test for constructor of class YumRepo
def test_YumRepo():
    print("\nTesting class YumRepo")
    module = AnsibleModule({
        "reposdir": "/etc/yum.repos.d",
        "file": "test_case_0",
        "name": "test_case_0",
    })
    obj = YumRepo(module=module)

    # Testing allowed_params
    print("Testing allowed_params")

# Generated at 2022-06-25 03:39:22.494159
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_0 = YumRepo(0)
    var_0.section = "section_name"
    var_0.repofile = configparser.RawConfigParser()
    var_0.add()


# Generated at 2022-06-25 03:39:35.882912
# Unit test for function main
def test_main():
    var_5 = {"state": "present",
             "file": "epel",
             "description": "EPEL YUM repo",
             "name": "EPEL YUM repo",
             "baseurl": "https://download.fedoraproject.org/pub/epel/$releasever/$basearch/",
             "repoid": "epel"}
    var_3 = configparser.RawConfigParser()
    var_3.read("/etc/yum.repos.d/epel.repo")
    var_3.add_section("epel")
    var_3.set("epel", "enabled", "False")
    var_3.set("epel", "baseurl", "https://download.fedoraproject.org/pub/epel/$releasever/$basearch/")

# Generated at 2022-06-25 03:40:08.960121
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_1 = YumRepo("a")
    var_1.remove()


# Generated at 2022-06-25 03:40:10.812131
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_1 = YumRepo()


# Generated at 2022-06-25 03:40:13.301615
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    yumrepo = YumRepo(None)
    yumrepo.save()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:40:14.566340
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 03:40:15.734754
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_0 = YumRepo()
    var_1 = var_0.remove()



# Generated at 2022-06-25 03:40:23.232425
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    var_0 = YumRepo_dump()

# Generated at 2022-06-25 03:40:34.004300
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_1 = YumRepo()
    var_2 = {'repoid': ['epel'], 'reposdir': ['/etc/yum.repos.d'], 
        'file': ['epel'], 'baseurl': ['https://download.fedoraproject.org/pub/epel/$releasever/$basearch/'], 
        'name': ['EPEL YUM repo'], 'state': ['present'], 
        'dest': ['/etc/yum.repos.d/epel.repo']}
    for k,v in var_2.items():
       var_1.module.params[k] = v
    var_3 = configparser.RawConfigParser()
    var_3.read('/etc/yum.repos.d/epel.repo')
    var

# Generated at 2022-06-25 03:40:44.399630
# Unit test for method remove of class YumRepo

# Generated at 2022-06-25 03:40:45.833169
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_0 = YumRepo(module)
    # TODO: Please implement unit test cases here



# Generated at 2022-06-25 03:40:49.040457
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    y = YumRepo(module)
    if y.params['baseurl'] is not None or y.params['mirrorlist'] is not None or y.params['metalink'] is not None:
        y.add()
        y.save()


# Generated at 2022-06-25 03:41:54.014533
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_0 = YumRepo()
    var_0.params = {"fromAction": "fromAction"}

    # Assertion error when case with "async" = True
    try:
        var_0.params["async"] = True
        var_0.add()

    # Assertion error when case with "async" = False
    except AssertionError:
        var_1 = False
    else:
        var_1 = True
    finally:
        assert var_1

    # Assertion error when case with "async" = None
    try:
        var_0.params["async"] = None
        var_0.add()

    # Assertion error when case with "async" = True
    except AssertionError:
        var_1 = False
    else:
        var_

# Generated at 2022-06-25 03:42:02.652486
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # module is a mock of the AnsibleModule
    module = Mock(params={
        'baseurl': None, 'dest': 'repos.d/test.repo',
        'gpgcheck': None, 'name': 'test', 'reposdir': 'repos.d',
        'state': None})
    yum_repo = YumRepo(module)

    # we test if module was properly initialized
    assert (yum_repo.module == module)
    assert (yum_repo.params == module.params)
    assert (yum_repo.section == 'test')
    assert (yum_repo.repofile == None)



# Generated at 2022-06-25 03:42:13.272829
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    args = dict(
        file='main',
        params=dict(
            state='absent',
            repoid='epel',
            description='EPEL YUM repo',
            baseurl='https://download.fedoraproject.org/pub/epel/$releasever/$basearch/',
            gpgcheck='no',
            gpgkey='file:///etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7',
            reposdir='/etc/yum.repos.d',
            diff_mode='no'
        )
    )
    module = AnsibleModule(**args)
    yum_repository = YumRepo(module)
    yum_repository.add()
    yum_repository.remove()
    yum_repository

# Generated at 2022-06-25 03:42:19.242056
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    data = {
        'name': 'epel',
        'repoid': 'epel',
        'reposdir': '/etc/yum.repos.d',
        'state': 'absent',
    }

    module = AnsibleModule(argument_spec=data.copy())
    repo = YumRepo(module)

    repo.remove()


# Generated at 2022-06-25 03:42:20.827950
# Unit test for constructor of class YumRepo
def test_YumRepo():
    var_0 = YumRepo()


# Generated at 2022-06-25 03:42:31.243879
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    yum_repo = YumRepo(AnsibleModule(argument_spec={}))
    yum_repo.repofile.add_section('epel')
    yum_repo.repofile.set('epel', 'name', 'EPEL YUM repo')
    yum_repo.repofile.set('epel', 'baseurl', 'https://download.fedoraproject.org/pub/epel/7/$basearch/')
    yum_repo.repofile.set('epel', 'gpgcheck', False)
    yum_repo.repofile.set('epel', 'enabled', True)

# Generated at 2022-06-25 03:42:32.617800
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    print('\n*** Test YumRepo.save ***')
    var_0 = main()


# Generated at 2022-06-25 03:42:38.162409
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    test_case_0()

if __name__ == "__main__":
    test_YumRepo_save()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.action import *

# Generated at 2022-06-25 03:42:40.034570
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_2 = YumRepo()
    var_2.remove()


# Generated at 2022-06-25 03:42:49.217283
# Unit test for constructor of class YumRepo

# Generated at 2022-06-25 03:44:45.751017
# Unit test for constructor of class YumRepo
def test_YumRepo():
    main()



# Generated at 2022-06-25 03:44:53.106352
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_1 = module()
    var_2 = dict()
    var_2['state'] = 'present'
    var_2['name'] = 'epel'
    var_2['repoid'] = 'epel'
    var_2['baseurl'] = 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/'
    var_1.params['repoid'] = var_2['repoid']
    var_1.params['baseurl'] = var_2['baseurl']
    var_1.params['name'] = var_2['name']
    var_1.params['state'] = var_2['state']
    var_3 = YumRepo(var_1)
    var_3.repofile.add_section('epel')

# Generated at 2022-06-25 03:44:54.415744
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 03:44:57.732070
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_YumRepo_save = YumRepo(module)
    # Execute the method under test
    result_YumRepo_save = var_YumRepo_save.save()
    assert result_YumRepo_save is None
    return


# Generated at 2022-06-25 03:45:02.953867
# Unit test for constructor of class YumRepo

# Generated at 2022-06-25 03:45:12.145172
# Unit test for method save of class YumRepo

# Generated at 2022-06-25 03:45:21.108451
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    var_0 = YumRepo()

# Generated at 2022-06-25 03:45:23.828907
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_1 = YumRepo(object)
    var_2 = var_1.remove()


# Generated at 2022-06-25 03:45:24.791695
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_0 = YumRepo()
    var_0.add()


# Generated at 2022-06-25 03:45:28.908277
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    try:
        mod_obj = YumRepo()
        mod_obj.save()
    except Exception as e:
        return False

    return True
