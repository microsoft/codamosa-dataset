

# Generated at 2022-06-25 03:37:52.653415
# Unit test for function main
def test_main():
    args = {}

    yum_repository = YumRepo(args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:38:01.111254
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Construction of repos_dir
    repos_dir = '/etc/my_repos'
    # Construction of filename
    filename = 'my_repository'
    # Construction of destination
    destination = os.path.join(repos_dir, "%s.repo" % filename)
    # Construction of repoid
    repoid = 'my_repoid'
    # Construction of params
    params = {'reposdir': repos_dir, 'file': filename, 'dest': destination, 'repoid': repoid}
    # Construction of module
    module = AnsibleModule({
        "reposdir": repos_dir,
        "file": filename,
        "repoid": repoid
    })
    # Construction of obj
    obj = YumRepo(module)

# Generated at 2022-06-25 03:38:04.751694
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    import string

    # Create a mock module
    module = AnsibleModule(
        argument_spec={})
    module.check_mode = True

    # Create an instance and run dump method
    yum_repo = YumRepo(module)
    string_dump = yum_repo.dump()

    # Make sure it's a string
    assert isinstance(string_dump, string)


# Generated at 2022-06-25 03:38:09.186886
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Define arguments
    module_args = {
        "name": "epel",
        "state": "absent",
        "reposdir": "/etc/yum.repos.d"
    }

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True)

    # Initialize the class
    yum = YumRepo(module)

    # Call the function
    yum.remove()


# Generated at 2022-06-25 03:38:10.754999
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule({}, supports_check_mode=True)
    yumrepo = YumRepo(module)
    yumrepo.add()
    pass


# Generated at 2022-06-25 03:38:12.418322
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_1 = YumRepo()
    var_1.save()


# Generated at 2022-06-25 03:38:16.749839
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    global var_0
    var_0.add()


# Generated at 2022-06-25 03:38:23.460041
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    var_0_0 = os.path.join(os.curdir, 'repos/yum/etc/yum.repos.d/edge.repo')
    var_0_1 = main(module_args={'dest': var_0_0, 'view': '', 'create': True, 'force': True})
    var_0_2 = var_0_1['repo_file_content']
    var_0_3 = '[edge]\n'
    var_0_4 = var_0_2 == var_0_3
    var_0_5 = os.path.join(os.curdir, 'repos/yum/etc/yum.repos.d/edge.repo.bak')

# Generated at 2022-06-25 03:38:26.130623
# Unit test for constructor of class YumRepo
def test_YumRepo():
    var_1 = YumRepo()


# Generated at 2022-06-25 03:38:30.077668
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    global var_0
    tmp_1 = YumRepo(var_0)
    return tmp_1.remove()


# Generated at 2022-06-25 03:38:48.470324
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            raise

if __name__ == '__main__':
    from run import run_test
    run_test(['test_epel'])

# Generated at 2022-06-25 03:38:55.703001
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_0 = YumRepo()
    var_0.repofile = configparser.RawConfigParser()
    var_0.repofile.read('student_courses.repo')
    var_0.repofile.remove_section('UNSW')
    var_0.repofile.remove_section('USYD')
    var_0.repofile.remove_section('ANU')
    repofile_content =  var_0.repofile.sections()
    print("[Result]")
    print(repofile_content)
    print("[Expected Result]")
    print("['UTS']")
    return repofile_content == "['UTS']"


# Generated at 2022-06-25 03:38:59.083437
# Unit test for constructor of class YumRepo
def test_YumRepo():
    y = YumRepo(module)


# Generated at 2022-06-25 03:39:00.192662
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var = YumRepo(module)
    var.remove()


# Generated at 2022-06-25 03:39:01.106530
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:39:07.451465
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'baseurl': {'default': None, 'type': 'str'},
        'dest': {'default': '', 'type': 'path'},
        'file': {'default': '', 'type': 'str'},
        'metalink': {'default': None, 'type': 'str'},
        'mirrorlist': {'default': None, 'type': 'str'},
        'repoid': {'required': True, 'type': 'str'},
        'reposdir': {'default': '/etc/yum.repos.d', 'type': 'path'},
      })
    target = YumRepo(module)
    target.add()


# Generated at 2022-06-25 03:39:09.341590
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    h0 = YumRepo(1)
    h0.remove()


# Generated at 2022-06-25 03:39:16.634375
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    yum_repo = YumRepo(AnsibleModule(argument_spec=dict()))
    yum_repo.repofile.add_section('test_                                                                                                                                                                                                                     ')
    yum_repo.repofile.set('test_                                                                                                                                                                                                                     ', 'async', '0')
    assert yum_repo.dump() == '[test_                                                                                                                                                                                                                      ]\nasync = 0'


# Generated at 2022-06-25 03:39:17.473957
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    main()
    var_0 = main()


# Generated at 2022-06-25 03:39:19.087211
# Unit test for constructor of class YumRepo
def test_YumRepo():
    repo = YumRepo('')
    assert repo is not None


# Generated at 2022-06-25 03:39:57.091684
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_1 = None

    def test_1():
        arg_0 = None
        remove_file(arg_0)
        yield None

    var_1 = test_1()

    # import module snippets. This is required
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-25 03:40:06.742212
# Unit test for method add of class YumRepo

# Generated at 2022-06-25 03:40:15.122719
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.file import _load_params
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils import _load_params
    from ansible.module_utils.action_plugins.files import set_defaults

# Generated at 2022-06-25 03:40:20.738477
# Unit test for constructor of class YumRepo
def test_YumRepo():
    path = os.path.realpath(os.path.join(__file__, "..", "..", ".."))
    module_path = os.path.join(path, "lib", "ansible", "modules", "system")

# Generated at 2022-06-25 03:40:31.076318
# Unit test for method save of class YumRepo

# Generated at 2022-06-25 03:40:33.205716
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    test1 = YumRepo()
    var_0 = test1.remove(self)



# Generated at 2022-06-25 03:40:44.060537
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import configparser
    var_A = AnsibleModule()
    # Fake values for the params
    var_A.params = {'repoid': 'epel', 'reposdir': '/etc/yum.repos.d', 'name': 'epel'}
    var_B = configparser.RawConfigParser()
    var_C = YumRepo(var_A)
    var_C.repofile = var_B
    var_B.add_section('epel')
    var_B.set('epel', 'name', 'epel')
    # Calling the method
    var_C.remove()
    # Testing the value of attribute repofile
    assert var_C.repofile == var

# Generated at 2022-06-25 03:40:45.513079
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_1 = YumRepo()
    var_1.add()


# Generated at 2022-06-25 03:40:47.528347
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_0 = YumRepo(AnsibleModule)

    # Call method remove of class YumRepo
    var_0.remove()



# Generated at 2022-06-25 03:40:53.060762
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # Initialize
    yum_repo = YumRepo.__new__(YumRepo)
    yum_repo.section = "section"
    yum_repo.repofile = configparser.RawConfigParser()

    # Add section to be removed
    yum_repo.repofile.add_section(yum_repo.section)

    # Call the method
    yum_repo.remove()

    # Should not have the section anymore
    assert yum_repo.repofile.has_section(yum_repo.section) == False


# Generated at 2022-06-25 03:41:28.118429
# Unit test for method save of class YumRepo

# Generated at 2022-06-25 03:41:37.563699
# Unit test for method dump of class YumRepo

# Generated at 2022-06-25 03:41:45.011337
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    print("\n\n\nUNIT TEST (test_YumRepo_remove)")
    module_bak = AnsibleModule(
        argument_spec=dict(
            baseurl=dict(type='str'),
            metalink=dict(type='str'),
            mirrorlist=dict(type='str'),
            repoid=dict(required=True, type='str'),
            repo_name=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )

    # Get YumRepo class
    test_class_obj = YumRepo(module=module_bak)

    # Test section
    section = 'epel'
    test_class_obj.repofile.add_section(section)

# Generated at 2022-06-25 03:41:47.998069
# Unit test for constructor of class YumRepo
def test_YumRepo():
    var_0 = main()
    # Assert on type
    assert (isinstance(var_0['yum_repo'], YumRepo))


# Generated at 2022-06-25 03:41:52.074790
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_0 = YumRepo()
    var_1 = YumRepo()
    var_2 = YumRepo()
    var_0.module = var_1
    var_2.module = var_0
    var_1.remove()
    var_2.remove()
    var_0.remove()


# Generated at 2022-06-25 03:42:03.219883
# Unit test for constructor of class YumRepo
def test_YumRepo():
    with open("yum_test_file.repo", "w") as test_file:
        test_file.write("[test_section_0]\n")
        test_file.write("test_parameter_0 = test_value_0\n")
        test_file.write("test_parameter_1 = test_value_1\n")
        test_file.write("\n")
        test_file.write("[test_section_1]\n")
        test_file.write("test_parameter_2 = test_value_2\n")
        test_file.write("test_parameter_3 = test_value_3\n")

    # Mock module

# Generated at 2022-06-25 03:42:06.602105
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_1 = YumRepo()


# Generated at 2022-06-25 03:42:10.083605
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_YumRepo = YumRepo(None)
    var_YumRepo.remove()


# Generated at 2022-06-25 03:42:19.146597
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Test a section with a list 'includepkgs' in the repo file
    repo = YumRepo(module)
    repo.add()
    repo.module.params['includepkgs'] = ['pkg1', 'pkg2', 'pkg3']
    res = repo.dump()

    # We expect the following output
    res_expected = "[test]\n"
    res_expected += "async = 0\n"
    res_expected += "includepkgs = pkg1 pkg2 pkg3\n\n"

    assert res == res_expected


# Generated at 2022-06-25 03:42:20.979386
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    var_1 = YumRepo()
    var_2 = None
    var_1.remove(var_2)


# Generated at 2022-06-25 03:43:23.931912
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_0 = YumRepo()
    var_0.save()


# Generated at 2022-06-25 03:43:24.842484
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    var_0 = main()


# Generated at 2022-06-25 03:43:32.007129
# Unit test for method dump of class YumRepo

# Generated at 2022-06-25 03:43:36.186062
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    var_1 = ansible.module_utils.basic.AnsibleModule()
    var_2 = YumRepo(var_1)
    var_2.add()


# Generated at 2022-06-25 03:43:42.970683
# Unit test for method add of class YumRepo

# Generated at 2022-06-25 03:43:53.284879
# Unit test for function main
def test_main():
    try:
        var_0 = "The `repo` parameter in `yum_repository` was renamed to `name`"
        var_0 = "to comply with Ansible's parameter naming standards."
        var_0 = "The `params` parameter was removed in Ansible 2.5 due to circumventing Ansible's parameter handling"
        var_1 = main()
        assert var_0 == var_1
    except Exception as e:
        assert e.__class__.__name__ == "AttributeError"
        assert e.__str__() == "AttributeError(\"'str' object has no attribute 'session'\",)"
    except Exception as e:
        assert e.__class__.__name__ == "NameError"
        assert e.__str__() == "name 'main' is not defined"

# Generated at 2022-06-25 03:44:02.805924
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    obj = YumRepo(None)
    obj.module.params = {
            'dest': '/etc/file'}
    # Inject function results
    with mock.patch.object(YumRepo, 'dump') as mocked_dump:
        mocked_dump.return_value = """
[test_section]
key1 = value1
key2 = value2

[another_section]
key3 = value3
key4 = value4
"""
        obj.save()
        fd = open('/etc/file', 'r')
        assert fd.read().strip() == """
[test_section]
key1 = value1
key2 = value2

[another_section]
key3 = value3
key4 = value4
"""
        fd.close()
        os.remove('/etc/file')

# Generated at 2022-06-25 03:44:09.575005
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    print("test case start")
    var_0 = YumRepo(main())
    var_0.dump()
    print("test case end")

if __name__ == '__main__':
    test_case_0()
    test_YumRepo_dump()


# Generated at 2022-06-25 03:44:19.183270
# Unit test for constructor of class YumRepo

# Generated at 2022-06-25 03:44:22.571252
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    a = YumRepo()
    assert a.add() == None


# Generated at 2022-06-25 03:46:43.850813
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    yumRepo = YumRepo(module)
    yumRepo.remove()


# Generated at 2022-06-25 03:46:46.236203
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    class_0 = YumRepo(None)
    var_0 = class_0.dump()


# Generated at 2022-06-25 03:46:52.807371
# Unit test for constructor of class YumRepo
def test_YumRepo():
    params = {
        'repoid': 'epel',
        'description': 'EPEL YUM repo',
        'reposdir': '/tmp/repos/',
        'file': 'epel.repo',
        'baseurl': 'https://download.fedoraproject.org/pub/epel/$releasever/$basearch/'
    }
    module = AnsibleModule(argument_spec=params)
    res = YumRepo(module)
    assert isinstance(res, YumRepo)


# Generated at 2022-06-25 03:46:55.563796
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    try:
        repofile = configparser.RawConfigParser()
        repofile.add_section('section')

        obj_0 = YumRepo('module')
        obj_0.repofile = repofile
        obj_0.section = 'section'
        obj_0.remove()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 03:47:00.454168
# Unit test for function main
def test_main():
    try:
        # Test case 0
        test_case_0()
    except Exception:
        # Print the error message
        print(traceback.format_exc())


if __name__ == "__main__":
    # Call main function
    test_main()

# Generated at 2022-06-25 03:47:01.256219
# Unit test for constructor of class YumRepo
def test_YumRepo():
    test_case_0()
    return


# Generated at 2022-06-25 03:47:09.768502
# Unit test for method add of class YumRepo

# Generated at 2022-06-25 03:47:17.888123
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in user code:")
        print('-' * 60)
        traceback.print_exc(file=sys.stdout)
        print('-' * 60)
        raise(e)
    else:
        pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:47:18.904945
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    yumRepo = YumRepo(None)
    yumRepo.add()


# Generated at 2022-06-25 03:47:22.518525
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    obj = YumRepo(AnsibleModule())
    string = obj.dump()
