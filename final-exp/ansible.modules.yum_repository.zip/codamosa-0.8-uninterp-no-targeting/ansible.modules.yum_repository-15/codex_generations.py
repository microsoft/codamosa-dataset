

# Generated at 2022-06-20 22:56:14.573010
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    m = AnsibleModule(argument_spec={
        'repoid': {'required': True},
        'file' : {'required': True},
        'reposdir' : {'required': True}
        })
    m.params['dest'] = 'tests/test_repo_remove.repo'
    yum_repo = YumRepo(m)
    yum_repo.remove()
    yum_repo.save()
    with open('tests/test_repo_remove.repo', 'r') as myfile:
        data=myfile.read()
    assert data == ""


# Generated at 2022-06-20 22:56:23.225789
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    mock_repofile = configparser.RawConfigParser()
    mock_repofile.add_section('epel')
    mock_repofile.add_section('third-party')
    mock_repofile.add_section('rhel')
    mock_repofile.set('epel', 'name', 'Epel YUM repo')
    mock_repofile.set('epel', 'baseurl', 'http://download.fedoraproject.org/pub/epel/7/$basearch')
    mock_repofile.set('epel', 'enabled', 1)
    mock_repofile.set('epel', 'gpgcheck', 0)

# Generated at 2022-06-20 22:56:35.747425
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    # Create a temporary file with a repo
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as fd:
        fd.write("""[section 1]
option1 = value1
option2 = value2

[section 2]
option1 = value1
option2 = value2

""")

    # Create repo object
    module = AnsibleModule({})
    repo = YumRepo(module)
    repo.params['dest'] = fd.name
    repo.repofile.read(fd.name)

    # Returned value is a text
    assert isinstance(repo.dump(), str)

    # Returned value is the content of

# Generated at 2022-06-20 22:56:43.317758
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(argument_spec={
        'repoid': {'required': True},
        'reposdir': {'required': True}
    })
    testobj = YumRepo(module=module)
    testobj.repofile.add_section('test_remove')
    assert testobj.repofile.has_section('test_remove')
    testobj.remove()
    assert not testobj.repofile.has_section('test_remove')

# Generated at 2022-06-20 22:56:53.043562
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from ansible.module_utils import basic

    # Parameters
    params = {
        'repoid': 'foo',
        'reposdir': '/etc/yum.repos.d'}

    # Create object, add repo and save
    module = basic.AnsibleModule({}, {})
    yumrepo = YumRepo(module)
    yumrepo.add()
    yumrepo.save()

    # Check the output
    repo_file = '''
[foo]
baseurl = 
gpgkey = 
'''
    assert repo_file == yumrepo.dump()


# Generated at 2022-06-20 22:57:03.248029
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # Create the YumRepo object
    repo = YumRepo(None)

    # Prepare the test parameters

# Generated at 2022-06-20 22:57:14.898650
# Unit test for function main

# Generated at 2022-06-20 22:57:25.606045
# Unit test for method add of class YumRepo

# Generated at 2022-06-20 22:57:33.401264
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    import os
    import getpass
    import tempfile
    import shutil

    # Create temporary directory
    reposdir = tempfile.mkdtemp()

    module = AnsibleModule(
        argument_spec=dict(
            baseurl=dict(type='str', required=True),
            name=dict(type='str', required=True),
            reposdir=dict(type='str', default=reposdir),
            state=dict(type='str', default='present', choices=['absent', 'present']),
        )
    )
    module.params['dest'] = os.path.join(reposdir, getpass.getuser())

    # New repo file
    yum_repo = YumRepo(module)
    yum_repo.add()
    yum_repo.save()

    #

# Generated at 2022-06-20 22:57:39.502170
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(
        argument_spec=dict(
            repoid="epel",
            file="epel",
            reposdir="/etc/yum.repos.d"),
        check_invalid_arguments=False)

    # Initialize the object
    y = YumRepo(module)

    # Add a section
    y.repofile.add_section("epel")

    y.remove()

    assert(y.repofile.sections() == [])


# Generated at 2022-06-20 22:58:22.370108
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Class global variables
    module = AnsibleModule(argument_spec=dict(
        repoid=dict(
            type='str', required=True),
        description=dict(
            type='str', required=True),
        baseurl=dict(
            type='str'),
        metalink=dict(
            type='str'),
        mirrorlist=dict(
            type='str'),
        file=dict(
            type='str', default='CentOS-Base.repo'),
        reposdir=dict(
            type='path', default='/etc/yum.repos.d'),
    ))
    params = module.params
    yum_repo = YumRepo(module)

    # Create a new repo
    yum_repo.add()

    # Save the repo to a file

# Generated at 2022-06-20 22:58:27.557266
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    """Remove repo section"""
    conf = configparser.RawConfigParser()
    conf.add_section('test_remove')
    conf.set('test_remove', 'some_param', 'test')

    repo = YumRepo(object())
    repo.repofile = conf
    repo.section = 'test_remove'

    repo.remove()

    assert not conf.has_section('test_remove')


# Generated at 2022-06-20 22:58:38.232866
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    # This is the module argument specification.
    argument_spec = dict(
        file=dict(type='str', required=True, default='test_repo'),
        name=dict(type='str', required=True, aliases=['repoid']),
        description=dict(type='str'),
        baseurl=dict(type='str'),
        mirrorlist=dict(type='str'),
        gpgcheck=dict(type='bool'),
        enabled=dict(type='bool'),
        enablegroups=dict(type='bool'),
        gpgkey=dict(type='list'),
        exclude=dict(type='list'),
        reposdir=dict(type='str', default='/etc/yum.repos.d'),
        state=dict(choices=['present', 'absent'], type='str', default='present')
    )

# Generated at 2022-06-20 22:58:50.111994
# Unit test for constructor of class YumRepo

# Generated at 2022-06-20 22:58:59.793583
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)

    yum_repo.repofile.add_section("section_1")
    yum_repo.repofile.set("section_1", "test_key_1", "test_value_1")
    yum_repo.repofile.set("section_1", "test_key_2", "test_value_2")
    yum_repo.repofile.add_section("section_2")
    yum_repo.repofile.set("section_2", "test_key_3", "test_value_3")
    yum_repo.repofile.set("section_2", "test_key_4", "test_value_4")
    #


# Generated at 2022-06-20 22:59:00.520662
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    pass


# Generated at 2022-06-20 22:59:11.423964
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    module = AnsibleModule(argument_spec={
        'baseurl': {'required': False, 'type': 'str'},
        'dest': {'required': True, 'type': 'str'},
        'file': {'required': True, 'type': 'str'},
        'reposdir': {'required': True, 'type': 'str'},
        'repoid': {'required': True, 'type': 'str'},
    })
    option = YumRepo(module)

    # Test baseurl
    option.params['baseurl'] = 'http://repo.com/centos/$releasever/test/x86_64/'
    option.add()

# Generated at 2022-06-20 22:59:23.247658
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def get_module_mock(params):
        m = basic.AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type='str'),
                file=dict(required=False, type='str', default='ansible'),
                state=dict(required=False, type='str', default='present'),
                reposdir=dict(required=False, type='str', default='/etc/yum.repos.d'),
                dest=dict(required=False, type='str'),
                baseurl=dict(required=False, type='str'),
                mirrorlist=dict(required=False, type='str'),
            ),
            supports_check_mode=True
        )

# Generated at 2022-06-20 22:59:30.687771
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(argument_spec={
        'baseurl': {'type': 'str'},
        'enabled': {'type': 'bool', 'default': True},
        'file': {'type': 'str', 'default': 'default.repo'},
        'name': {'type': 'str', 'default': 'default'}
    })
    yumrepo = YumRepo(module)
    module.exit_json(changed=False)


# Generated at 2022-06-20 22:59:40.018659
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Create a new instance
    yum = YumRepo(AnsibleModule(argument_spec={}))

    # Create a config parser object to compare with the result
    new = configparser.RawConfigParser()

    # Add sections and parameters to compare
    new.add_section('nfs-server')
    new.set('nfs-server', 'enabled', True)
    new.set('nfs-server', 'description', "NFS Server")

    new.add_section('nfs-client')
    new.set('nfs-client', 'enabled', False)
    new.set('nfs-client', 'description', "NFS Client")

    # Set the new configparser object to the config attribute
    yum.repofile = new

    # Dump the configparser object
    result = yum.dump()

   

# Generated at 2022-06-20 23:00:18.587837
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    yumrepo = YumRepo(module)
    params = {
        'baseurl': 'http://repos.example.com/repo/$releasever/$basearch',
        'dest': '/tmp/repo.repo',
        'enabled': 1,
        'gpgcheck': 0,
        'metadata_expire': '7d',
        'metalink': None,
        'mirrorlist': None,
        'name': 'epel',
        'file': 'epel'
    }

    yumrepo.params = params

    yumrepo.add()
    yumrepo.save()

    # Remove the file
    os

# Generated at 2022-06-20 23:00:30.047672
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    module = AnsibleModule(
        argument_spec=dict(
            repoid=dict(required=True, type='str'),
            baseurl=dict(required=False, type='str'),
            enabled=dict(required=False, type='bool'),
            file=dict(required=False, type='str', default='ansible-test'),
            gpgcheck=dict(required=False, type='bool'),
            gpgkey=dict(required=False, type='str'),
            metalink=dict(required=False, type='str'),
            mirrorlist=dict(required=False, type='str'),
            reposdir=dict(required=False, type='path', default='/tmp'),
            state=dict(required=False, type='str', choices=['present', 'absent'], default='present'),
        )
    )

   

# Generated at 2022-06-20 23:00:40.593573
# Unit test for constructor of class YumRepo
def test_YumRepo():
    class Module(object):
        def __init__(self):
            self.params = {
                'repoid': 'test',
                'file': 'test_repo',
                'reposdir': '../test_repos',
            }

    yum_repo = YumRepo(Module())

    assert yum_repo.section == "test"
    assert yum_repo.params['dest'] == '../test_repos/test_repo.repo'

    # Add a new repo
    yum_repo.add()

    # Save the repo file
    yum_repo.save()

    # Remove the repo
    yum_repo.remove()

    # Save again
    yum_repo.save()



# Generated at 2022-06-20 23:00:41.333241
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    pass

# Generated at 2022-06-20 23:00:49.459311
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(
        argument_spec=dict(
            file=dict(default='unit_test'),
            repoid=dict(required=True),
        ),
    )

    plugin = YumRepo(module)
    assert plugin.module == module
    assert plugin.params == module.params
    assert plugin.section == module.params['repoid']
    assert plugin.repofile == configparser.RawConfigParser()

    # Remove the unit test file
    os.remove(plugin.params['dest'])



# Generated at 2022-06-20 23:01:01.329495
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import configparser
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.plugins.modules.files import yum_repository as yum_repository


# Generated at 2022-06-20 23:01:11.622512
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    import sys
    import pytest

    test_module = AnsibleModule(
        argument_spec={
            "state": {
                "type": "str",
                "required": True},
            "repoid": {
                "type": "str",
                "required": True},
            "reposdir": {
                "type": "str",
                "required": True},
            "file": {
                "type": "str"}})
    sys.modules['ansible.module_utils.basic'] = test_module
    import ansible.module_utils.basic
    test_YumRepo = YumRepo(test_module)
    test_repofile = configparser.RawConfigParser()

# Generated at 2022-06-20 23:01:22.384990
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Create a module object
    module = AnsibleModule(
        argument_spec=dict(
            file='epel',
            reposdir='/etc/yum.repos.d'
        )
    )

    # Create a YumRepo object
    yumrepo = YumRepo(module)

    # Add the section
    yumrepo.repofile.add_section('[section1]')

    # Add the options to the section
    yumrepo.repofile.set('[section1]', 'option1', 'value1')
    yumrepo.repofile.set('[section1]', 'option2', 'value2')

    # Add the second section
    yumrepo.repofile.add_section('[section2]')

    # Add the options to the second

# Generated at 2022-06-20 23:01:33.240281
# Unit test for constructor of class YumRepo
def test_YumRepo():
    # Shortcut for the params
    params = {}
    # Section is always the repoid
    params['repoid'] = "epel"
    # Set repo file
    params['file'] = "epel"
    # Set dest
    params['dest'] = "/tmp/epel.repo"

    # Create a new repo file
    repofile = configparser.RawConfigParser()

    # Add section
    repofile.add_section(params['repoid'])

    # Set options
    params['baseurl'] = "http://download.fedoraproject.org/pub/epel/6/$basearch"
    params['failovermethod'] = "priority"
    params['enabled'] = True
    params['gpgcheck'] = True

# Generated at 2022-06-20 23:01:44.300105
# Unit test for function main

# Generated at 2022-06-20 23:02:57.403247
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    # Define a YumRepo instance
    yumrepo = YumRepo(None)

    # Add a section
    yumrepo.section = 'section_1'
    yumrepo.repofile.add_section(yumrepo.section)

    # First line - section title
    assert yumrepo.dump().splitlines()[0] == '[%s]' % yumrepo.section

    # Set and populate some options
    options = {
        'option1': 'value1',
        'option2': 'value2',
        'option3': 'value3'
    }
    for key, value in options.items():
        yumrepo.repofile.set(yumrepo.section, key, value)

    # Check the output options
    assert yumrepo.dump

# Generated at 2022-06-20 23:03:05.368002
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    module = AnsibleModule(
        argument_spec={
            'state': {'default': 'present', 'choices': ['present', 'absent']},
            'baseurl': {'type': 'str'},
            'name': {'required': True, 'type': 'str'},
        }
    )
    yumrepo = YumRepo(module)
    yumrepo.repofile.add_section("section")
    yumrepo.repofile.set("section", "key", "value")
    assert yumrepo.dump() == "[section]\n" \
                             "key = value\n" \
                             "\n"


# Generated at 2022-06-20 23:03:16.336520
# Unit test for constructor of class YumRepo

# Generated at 2022-06-20 23:03:27.811940
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    module = AnsibleModule(argument_spec={})
    yum_repo = YumRepo(module)

    # Mock repofile to be config parser object
    class configparser:
        class RawConfigParser:
            def __init__(self):
                self.sections = ['first_sec', 'second_sec']
                self.options = ['opt1', 'opt2', 'opt3']
                self.option_list = [['opt1', 'value1'], ['opt2', 'value2'], ['opt3', 'value3']]
                self.option_dict = {'opt1': 'value1', 'opt2': 'value2', 'opt3': 'value3'}

            def sections(self):
                return self.sections

            def options(self, section):
                return self.options


# Generated at 2022-06-20 23:03:37.112342
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    """
    Test if the remove method of the YumRepo class does work
    """

    # Return values of removed repo
    return_values = [
        {
            'state': 'absent',
            'repo': 'testrepo',
            'warnings': [],
        }
    ]

    # Init ansible module
    module = AnsibleModule(
        argument_spec={
            'state': {
                'choices': ['absent', 'present'],
                'default': 'present',
            },
            'repoid': {
                'required': True,
            },
            'reposdir': {
                'default': '/etc/yum.repos.d',
            },
        },
    )

    # Create a YumRepo class object

# Generated at 2022-06-20 23:03:47.796355
# Unit test for method add of class YumRepo
def test_YumRepo_add():
    params = {
        'baseurl': 'http://www.example.com',
        'enabled': False,
        'exclude': ['foo', 'bar'],
        'includepkgs': ['foo', 'bar'],
        'name': 'example',
        'password': 'mypassword',
        'username': 'myusername'
    }

    repofile = configparser.RawConfigParser()

    repofile.add_section('example')

    # Set options
    for key, value in sorted(params.items()):
        if key in ['exclude', 'includepkgs'] and isinstance(value, list):
            # Join items into one string for specific parameters
            value = ' '.join(value)

        repofile.set('example', key, value)


# Generated at 2022-06-20 23:03:51.809513
# Unit test for constructor of class YumRepo
def test_YumRepo():
    module = AnsibleModule(argument_spec={})
    repo = YumRepo(module)

    assert repo.module == module
    assert repo.params == module.params
    assert repo.section == module.params['repoid']
    assert repo.repofile.sections() == []



# Generated at 2022-06-20 23:04:03.087071
# Unit test for method save of class YumRepo
def test_YumRepo_save():
    class MockModule(object):
        params = {
            'repoid': 'epel',
            'dest': os.path.join(
                '/tmp',
                "%s.repo" % 'epel')
        }

        def fail_json(self, msg, details=None):
            raise Exception(msg)

    # Make test repo dir
    if not os.path.isdir('/tmp/yum.repos.d'):
        os.makedirs('/tmp/yum.repos.d')

    # Add section to repofile
    repofile = configparser.RawConfigParser()
    repofile.add_section('epel')

# Generated at 2022-06-20 23:04:13.731953
# Unit test for method dump of class YumRepo
def test_YumRepo_dump():
    import os.path
    import sys
    import StringIO

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Build a simple repo file to pass to the class
    repofile = configparser.RawConfigParser()
    repofile.add_section('repo1')
    repofile.set('repo1', 'a', 'b')
    repofile.add_section('repo2')
    repofile.set('repo2', 'c', 'd')
    repofile.set('repo2', 'e', 'f')

    # Build the class for executing the dump method

# Generated at 2022-06-20 23:04:19.956776
# Unit test for method remove of class YumRepo
def test_YumRepo_remove():
    # mock a module
    module = AnsibleModule(argument_spec = dict())
    module.params = {
        "repoid": "epel",
        "dest": "/tmp/test_repofile"
    }

    # Create an empty repofile
    f = open(module.params["dest"], "w+")
    f.close()

    # test if fail without section
    repofile = configparser.RawConfigParser()
    repofile.read(module.params["dest"])
    repofile.add_section("test")
    repofile.set("test", "value", "test")

    yum_repo = YumRepo(module)
    yum_repo.section = "test"
    yum_repo.repofile = repofile