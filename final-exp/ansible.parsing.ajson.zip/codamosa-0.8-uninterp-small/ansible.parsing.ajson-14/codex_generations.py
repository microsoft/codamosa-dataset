

# Generated at 2022-06-25 03:37:38.601137
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO: implement assertions
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:37:44.284977
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:37:52.566578
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class Test_AnsibleJSONDecoder(object):
        _vaults = {}

        def __init__(self, *args, **kwargs):
            kwargs['object_hook'] = self.object_hook
            super(AnsibleJSONDecoder, self).__init__(*args, **kwargs)

        @classmethod
        def set_secrets(cls, secrets):
            cls._vaults['default'] = VaultLib(secrets=secrets)

        def object_hook(self, pairs):
            for key in pairs:
                value = pairs[key]

                if key == '__ansible_vault':
                    value = AnsibleVaultEncryptedUnicode(value)
                    if self._vaults:
                        value.vault = self._vaults['default']
                    return value

# Generated at 2022-06-25 03:37:55.894410
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = None
    expected_result = None
    actual_result = None
    assert actual_result == expected_result


# Generated at 2022-06-25 03:37:57.352124
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:37:59.083963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Testing str type
    # Testing dict type
    # Testing AnsibleVaultEncryptedUnicode type
    # Testing AnsibleUnsafeText type



# Generated at 2022-06-25 03:37:59.831950
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:05.465442
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(['test_secret'])

# Generated at 2022-06-25 03:38:15.812405
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets("password")

# Generated at 2022-06-25 03:38:17.793361
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({}) is None


# Generated at 2022-06-25 03:38:26.256643
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_object_hook_0 = ansible_j_s_o_n_decoder_0.object_hook('__ansible_vault')
    ansible_json_decoder_object_hook_1 = ansible_j_s_o_n_decoder_0.object_hook('__ansible_unsafe')


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:38:29.718297
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    msg = 'No object hook used'
    assert hasattr(ansible_j_s_o_n_decoder_0, 'object_hook')

test_case_0()
test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:38:35.525698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["default"])
# How to test AnsibleVaultEncryptedUnicode?

# Generated at 2022-06-25 03:38:40.748806
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:38:48.675028
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['foo'])

    assert {'test': 'truth'} == decoder.decode('{"test": "truth"}')
    assert {'test': 'truth'} == decoder.decode(
        '{"test": "truth", "__ansible_vault": "foo"}'
    )
    assert {'test': 'truth'} == decoder.decode(
        '{"test": "truth", "__ansible_unsafe": "foo"}'
    )

# Generated at 2022-06-25 03:38:55.285272
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets='')
    # Converts pairs to an object
    ansible_j_s_o_n_decoder_0.object_hook(pairs={})
    # Test error raises
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # converting pairs to a object
    assert ansible_j_s_o_n_encoder_0.default(o={}) == {}



# Generated at 2022-06-25 03:38:58.330474
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True


# Generated at 2022-06-25 03:39:08.702982
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    input_0 = {'ansible_facts': {'ansible_local': {'test': {'ansible_local_var': 'test'}}, 'ansible_system': {'distribution': 'Ubuntu', 'distribution_release': '18.04', 'distribution_version': '18.04', 'kernel': 'Linux'}, 'ansible_system_capabilities': ['net_admin: true', 'net_raw: false', 'sys_chroot: true'], 'ansible_system_capabilities_enforced': True, 'ansible_system_capabilities_supported': True}}

# Generated at 2022-06-25 03:39:17.886596
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder()

    # Testing with invalid type for 'pairs' (STR)
    # pairs:
    #     - name: test
    #     - value: test
    with pytest.raises(TypeError) as excinfo:
        obj.object_hook("STR")
    assert str(excinfo.value) == "object_hook() takes exactly 1 argument (2 given)"

    # Testing with valid type for 'pairs' (dict)
    # pairs:
    #     - name: test
    #     - value: test
    assert obj.object_hook({'name': 'test', 'value': 'test', }) == {'name': 'test', 'value': 'test', }


# Generated at 2022-06-25 03:39:27.944173
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib()
    ansible_unsafe_0 = wrap_var({'__ansible_vault': 'sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf....'})
    ansible_unsafe_1 = wrap_var({'__ansible_unsafe': 'my-unsafe-password'})
    assert ansible_j_s_o_n_decoder_0.object_hook(ansible_unsafe_0) != ansible_unsafe_0
    assert ansible_j_s_o_n_dec

# Generated at 2022-06-25 03:39:34.235481
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_1 = dict()

    # Call method
    ansible_j_s_o_n_decoder_0.object_hook(pairs_1)


# Generated at 2022-06-25 03:39:38.473575
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = [
        [{
            "__ansible_vault": "abc",
            "__ansible_unsafe": "abc"
        },
        ['__ansible_vault', '__ansible_unsafe']]
    ]

    for element in test_data:
        input, output = element
        ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
        ansible_j_s_o

# Generated at 2022-06-25 03:39:48.069711
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_obj = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:39:59.278167
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;janejanejanejane\n63303161366163313463653532616263626362353965653035363466363538663337323600000\n')
    ansible_j_s_o_n_decoder_0.set_secrets('janejanejanejane')

# Generated at 2022-06-25 03:40:04.567037
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    assert ansible_json_encoder_0.default('some_str') == '"some_str"'
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'some_str'}) == "some_str"

# Generated at 2022-06-25 03:40:14.723958
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # encryption
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.object_hook(pairs={'key': ansible_vault_encrypted_unicode_0})
    ansible_json_decoder_0.object_hook(pairs={'key': 'value'})
    # unsafe
    ansible_json_decoder_0.object_hook(pairs={'__ansible_unsafe': 'eval'})

# Generated at 2022-06-25 03:40:16.798004
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs = {}
    result = ansible_j_s_o_n_decoder_1.object_hook(pairs)


# Generated at 2022-06-25 03:40:28.232680
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test with default args
    result = ansible_j_s_o_n_decoder_0.object_hook([])
    assert result == [], "Test of 'object_hook' method of class AnsibleJSONDecoder failed"
    # Test with args
    result = ansible_j_s_o_n_decoder_0.object_hook(['__ansible_vault'])
    assert isinstance(result, AnsibleVaultEncryptedUnicode), "Test of 'object_hook' method of class AnsibleJSONDecoder failed"



# Generated at 2022-06-25 03:40:32.225371
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
#
#   Decode json data
#
    with open('json_data.json') as json_data:
        ansible_json_decoder_0.decode(json_data)



# Generated at 2022-06-25 03:40:42.158462
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    vault_lib_0 = VaultLib()
    vault_encrypted_unicode_0.vault = vault_lib_0

    # Test with valid parameters
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'test'})

    # Test with missing parameter
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'evil'}) == {'__ansible_unsafe': 'evil'}


# Generated at 2022-06-25 03:40:55.538580
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:00.434764
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:04.746927
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs = {'key': 'value'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {'key': 'value'}


# Generated at 2022-06-25 03:41:12.610810
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    decoded = decoder.object_hook({'__ansible_vault': 'foo', 'bar': 'baz'})
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded == 'foo'
    assert decoded.vault is None

    decoder.set_secrets(['foo'])
    decoded = decoder.object_hook({'__ansible_vault': 'bar'})
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded == 'bar'
    assert decoded.vault is not None
    assert decoded.vault.secrets == ['foo']


# Generated at 2022-06-25 03:41:14.071568
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:41:20.575616
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    # This can be changed to anything you want.
    ansible_json_decoder_1.set_secrets(None)
    dict_2 = {}

# Generated at 2022-06-25 03:41:26.924553
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("Hi",  "")
    assert ansible_j_s_o_n_decoder_0.object_hook("Hi") == "Hi"
    assert ansible_j_s_o_n_decoder_0.object_hook("Hi") != ansible_vault_encrypted_unicode_0 


# Generated at 2022-06-25 03:41:37.350920
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

    # Test case section 0
    vault_str = "$ANSIBLE_VAULT;1.1;AES256\n613162356161303331303133393536353737666636306131643734396337343666303737626265323\n366346433343934613962343265323434303965643533353965356632323765336532623963393135\n32656533393035643839386436323230393366376366386638343863396166343163316236333034\n3132313165363635306134623238633162643236\n"

# Generated at 2022-06-25 03:41:41.002950
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Simple test with minimum parameters
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(pairs={'__ansible_vault': '12345'})


# Generated at 2022-06-25 03:41:44.709866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test with vault
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('12345')

    some_vault_0 = VaultLib()
    ansible_j_s_o_n_decoder_0.set_secrets('test')
    # Test with secrets
    # Test with unsafe
    pass

# Generated at 2022-06-25 03:41:54.532395
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    key = 'test_key'
    value = 'test_value'

    pairs = { key : value }
    decoded_value = ansible_j_s_o_n_decoder_0.object_hook(pairs)

    assert decoded_value == pairs

# Generated at 2022-06-25 03:41:58.120898
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("a")
    assert ansible_vault_encrypted_unicode_0.vault == None


# Generated at 2022-06-25 03:42:00.691313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

    # Test cases for AnsibleJSONDecoder.object_hook()


# Generated at 2022-06-25 03:42:03.057095
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_obj = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_obj.object_hook(pairs={})


# Generated at 2022-06-25 03:42:10.835053
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(secrets=secrets)
    ansible_vault_encoded_string_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encoded_string_1)
    ansible_vault_encoded_string_1 = ansible_j_s_o_n_decoder_1.object_hook()


# Generated at 2022-06-25 03:42:14.116611
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    assert ansible_json_decoder_0.object_hook({'key': 'value'}) == {"key": "value"}


# Generated at 2022-06-25 03:42:24.428152
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Test with an unprotected vault password string
    ansible_j_s_o_n_encoder_0.secrets = ['vault_password']

    vault_password = 'example_password'

    vault_value = dict()
    vault_value['__ansible_vault'] = ansible_j_s_o_n_encoder_0.encode('test')
    vault_value['__ansible_vault_password'] = ansible_j_s_o_n_encoder_0.encode(vault_password)

    assert ansible_j_s_o_n_decoder_0.decode

# Generated at 2022-06-25 03:42:29.223079
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({"foo": "bar"}) == {"foo": "bar"}
    assert ansible_j_s_o_n_decoder_0.object_hook({"__ansible_unsafe": "bar"}) == {"__ansible_unsafe": "bar"}



# Generated at 2022-06-25 03:42:33.550380
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_obj_0 = AnsibleJSONDecoder()
    with pytest.raises(KeyError):
        ansible_j_s_o_n_decoder_obj_0.object_hook({'foo': 'bar', 'baz': 'qux'})


# Generated at 2022-06-25 03:42:41.355672
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_decoder_0 = dict()
    ansible_vault_decoder_0['__ansible_vault'] = 'vault_ansible'
    ansible_json_decoder_0._vaults = {'default': 'default'}
    ansible_vault_decoder_0 = ansible_json_decoder_0.object_hook(ansible_vault_decoder_0)


# Generated at 2022-06-25 03:42:54.349735
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_1 is not None

    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_2 is not None

    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_3 is not None


# Generated at 2022-06-25 03:43:01.309127
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    result = ansible_j_s_o_n_encoder_0.encode(wrap_var('foo'))
    ansible_j_s_o_n_decoder_0.object_hook(json.loads(result))

# Generated at 2022-06-25 03:43:09.621427
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:43:20.780455
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'test'})
    wrap_var_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test'})
    assert wrap_var_0.data == 'test'


# Generated at 2022-06-25 03:43:28.687770
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["ansible"])

# Generated at 2022-06-25 03:43:40.779370
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    def test_dict_extraction(self, astring):
        if isinstance(astring, AnsibleVaultEncryptedUnicode):
            return astring.vault.decrypt(astring)
        try:
            return json.loads(astring)
        except AttributeError:
            return astring
        except ValueError:
            return json.loads(str(astring))
    # Test of AnsibleJSONDecoder.object_hook
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': "test"})
    ansible_j_s_o_

# Generated at 2022-06-25 03:43:45.388627
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder_obj = AnsibleJSONDecoder()
    json_pairs = {"__ansible_vault": "vault value", "__ansible_unsafe": "unsafe value"}
    assert decoder_obj.object_hook(json_pairs) == {
        "__ansible_vault": AnsibleVaultEncryptedUnicode("vault value"),
        "__ansible_unsafe": wrap_var("unsafe value"),
    }

# Generated at 2022-06-25 03:43:53.543981
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_e_d_u_n_i_c_o_d_e_0 = AnsibleVaultEncryptedUnicode('value')
    dict_0 = ansible_j_s_o_n_decoder_0.object_hook({'key': 'value'})
    assert dict_0['key'] == 'value'
    dict_1 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'value'})
    assert dict_1['__ansible_vault'] == ansible_v_a_u_l_t_e_d_u_n_i_c_o_d_e

# Generated at 2022-06-25 03:43:58.091746
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['1'])
    assert AnsibleVaultEncryptedUnicode({'__ansible_vault': '1'})

# Generated at 2022-06-25 03:44:03.045061
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"__ansible_vault": {}}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)
    ansible_j_s_o_n_decoder_0._vaults = {"default": '1234'}
    ansible_j_s_o_n_decoder_0.object_hook(obj)

# Generated at 2022-06-25 03:44:27.915940
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_3.set_secrets('hello')
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_5 = AnsibleVaultEncryptedUnicode(ansible_j_s_o_n_decoder_3._vaults['default'].encrypt('hello'))
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder()

# Generated at 2022-06-25 03:44:32.788313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook('pairs')

# Generated at 2022-06-25 03:44:44.060355
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs_0 = {}

    pairs_0['__ansible_vault'] = AnsibleVaultEncryptedUnicode('bar')

    # Test of input ansible_j_s_o_n_decoder_0 and pairs_0 -> method call return value.
    ansible_j_s_o_n_decoder_0.set_secrets(['foo'])
    
    return_value_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert return_value_0 == pairs_0
    ## END OF TESTS ##


# Generated at 2022-06-25 03:44:46.913722
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_case_0()

if __name__ == "__main__":
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:44:54.821773
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {}
    pairs = {'__ansible_unsafe': {'__ansible_vault': 'test_value_3', '__ansible_unsafe': 'test_value_4'}}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert result == {'__ansible_unsafe': wrap_var({'__ansible_vault': AnsibleVaultEncryptedUnicode('test_value_3'), '__ansible_unsafe': wrap_var('test_value_4')})}

# Generated at 2022-06-25 03:45:01.708588
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_object_hook_2 = ansible_j_s_o_n_decoder_object_hook_0.object_hook({'key': 'value'})

# Generated at 2022-06-25 03:45:11.962233
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:45:17.280143
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:45:28.246294
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    AnsibleJSONDecoder.set_secrets(["foo"])

    foo = dict(__ansible_unsafe='foo', __ansible_vault='bar', no_key=1)
    res = ansible_j_s_o_n_decoder_0.decode(ansible_j_s_o_n_encoder_0.encode(foo))
    assert res['__ansible_unsafe'].data == 'foo'
    assert res['__ansible_vault'].data == 'bar'
    assert res['no_key'] == 1
    assert len(res) == 3

    AnsibleJSON

# Generated at 2022-06-25 03:45:38.096141
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test AnsibleVaultEncryptedUnicode
    data = '{"__ansible_vault": "AQAASY8lJmD67mwCD1okZmY+YG/4IE4eRWz/P/R5H4WhnS5S5N5Cw2QAf+3IugHaxsw=="}'
    j_s_o_n_decoder_0 = json.JSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['hunter2'])
    result = ansible_j_s_o_n_decoder_0.decode(data)


# Generated at 2022-06-25 03:46:30.887101
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_object_hook_0.set_secrets(secrets=None)
    ansible_json_pairs_0 = {'__ansible_vault': 'ansible_vault_0'}
    ansible_json_pairs_1 = {'__ansible_unsafe': 'ansible_unsafe_0'}
    assert isinstance(ansible_j_s_o_n_decoder_object_hook_0.object_hook(pairs=ansible_json_pairs_0), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 03:46:35.846706
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(sort_keys=True)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(indent=4)
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder(indent=4, sort_keys=True, separators=(', ', ': '))


# Generated at 2022-06-25 03:46:41.502482
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # AnsibleJSONDecoder._vaults['default'] is None.
    # This implies AnsibleVaultEncryptedUnicode.vault is None.
    expected_result_1 = {'__ansible_vault': 'encrypted_string'}
    object_hook_result_1 = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'encrypted_string'})
    assert expected_result_1 == object_hook_result_1


# Generated at 2022-06-25 03:46:45.296479
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    fake_pairs = dict()
    fake_pairs['key'] = 'value'
    expected_result = dict()
    expected_result['key'] = 'value'

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    result = ansible_j_s_o_n_decoder_0.object_hook(fake_pairs)

    assert result == expected_result


# Generated at 2022-06-25 03:46:52.507565
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Pairs data is optional
    ansible_j_s_o_n_decoder_0.object_hook(vault_value='`8TtT-BbY#\nq~,7V.')
    # Pairs data is optional
    ansible_j_s_o_n_decoder_0.object_hook(unsafe_value='z#Ql^|qwm!+')


# Generated at 2022-06-25 03:46:54.836193
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    expected = {'some': 'value'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    actual = ansible_j_s_o_n_decoder_0.object_hook({'some': 'value'})
    assert actual == expected


# Generated at 2022-06-25 03:47:05.050362
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    object_hook_value_0 = dict(__ansible_vault='MyVault', __ansible_unsafe='MyUnsafe')
    object_hook_value_1 = ansible_j_s_o_n_decoder_0.object_hook(object_hook_value_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('MyVault')
    assert 'default' in AnsibleJSONDecoder._vaults
    assert object_hook_value_1['__ansible_vault'] == ansible_vault_encrypted_unicode_0
    assert object_hook_value_1['__ansible_unsafe'] == 'MyUnsafe'

# Unit test

# Generated at 2022-06-25 03:47:14.108758
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test for object_hook, method of class AnsibleJSONDecoder
    # Test for object_hook, method of class AnsibleJSONDecoder

    # assertEquals is not used since the objects don't have the same __dict__,
    # even though they are the same object
    assert ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault":"123"}) == AnsibleVaultEncryptedUnicode("123")


# Generated at 2022-06-25 03:47:19.243561
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder(encoding=None, object_hook=None, parse_float=None, parse_int=None, parse_constant=None, strict=False, object_pairs_hook=None)

    ansible_j_s_o_n_decoder_2.set_secrets("Passphrase")

    ansible_j_s_o_n_decoder_2.object_hook("Test")

# Generated at 2022-06-25 03:47:21.989384
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test for valid return value
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({}).__class__.__name__ == 'dict'
