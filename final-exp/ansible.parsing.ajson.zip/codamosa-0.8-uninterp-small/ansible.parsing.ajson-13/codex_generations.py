

# Generated at 2022-06-25 03:37:42.299536
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    buffer = b'{"__ansible_vault": "U2FsdGVkX18/NdlBlSSw="}'

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['password'])
    ansible_j_s_o_n_decoder_0.object_hook(buffer)


# Generated at 2022-06-25 03:37:49.053981
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_object_hook_2 = {}
    ansible_j_s_o_n_decoder_object_hook_1 = ansible_j_s_o_n_decoder_object_hook_0.object_hook(ansible_j_s_o_n_decoder_object_hook_2)


# Generated at 2022-06-25 03:37:54.945539
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0


# Generated at 2022-06-25 03:37:59.342681
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'ZmxhZ3tSb3dzaEZsYWd9'

    decoder = AnsibleJSONDecoder()
    text = decoder.decode('{"__ansible_vault": "%s"}' % secret)
    assert isinstance(text, dict)
    assert isinstance(text['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert text['__ansible_vault'].vault is None or text['__ansible_vault'].vault.secrets == [secret]

    decoder.set_secrets(['12345'])

    text = decoder.decode('{"__ansible_vault": "%s"}' % secret)
    assert isinstance(text, dict)

# Generated at 2022-06-25 03:38:05.014150
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
  pairs_0 = {}
  try:
      keys_0 = ['__ansible_vault', '__ansible_unsafe']
  except NameError as err:
      pass
  pairs_0["__ansible_vault"] = 'ya29.bQBzdeKh0V7QQw1fPgx7SCuLZ-kV0b0JWd9V7F_yek5o5P5FUwSRgxRJTsQ6kYF6A3q6GJ9Vg-LHmDr5LpUfuunwcpxR_fZ1PhUe7fnq3D6EJG6ybB06ckN-G2fDw'
  pairs_0

# Generated at 2022-06-25 03:38:11.834926
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = AnsibleJSONDecoder()

    ansible_json_encoder_1 = AnsibleJSONEncoder()
    v_1 = AnsibleVaultEncryptedUnicode('3:c2')
    v_1.set_vault_id('id_1')
    v_1.set_vault_version(1)
    v_1.set_vault_secret('secret_1')
    v_1.load_secret()
    output_1 = json.loads(ansible_json_encoder_1.encode({'__ansible_vault':v_1}), object_hook=ansible_json_decoder_1.object_hook)

    assert 'secret' in output_1['__ansible_vault']

# Generated at 2022-06-25 03:38:18.180248
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook(" pairs ") == ' pairs ' 
    
    

# Generated at 2022-06-25 03:38:25.823024
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    line = '{ "__ansible_vault": "Not encrypted", "__ansible_unsafe": "unsafe" }'
    pairs = json.loads(line)
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert result['__ansible_vault'] == 'Not encrypted'
    assert result['__ansible_unsafe'] == 'unsafe'



# Generated at 2022-06-25 03:38:34.069838
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
        AJSOD_object_hook_fut_var = False
        ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
        ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib()
        AJSOD_object_hook_fut_var = ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": "my_secret_data"})
        assert isinstance(AJSOD_object_hook_fut_var, AnsibleVaultEncryptedUnicode), "Failed to return AnsibleVaultEncryptedUnicode"


# Generated at 2022-06-25 03:38:40.398540
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['mysecrets'])
    pairs = {'__ansible_vault': 'mysecrets'}
    expected = 'AnsibleVaultEncryptedUnicode(u\'mysecrets\', vault=<ansible.parsing.vault.VaultLib object at 0x7fb2b8f38210>)'
    assert str(ansible_j_s_o_n_decoder_0.object_hook(pairs)) == expected
    pairs = {'__ansible_unsafe': 'mysecrets'}
    expected = 'unsafe_proxy.SafeText(u\'mysecrets\')'

# Generated at 2022-06-25 03:38:48.081698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    
    pairs = {'key1':'value1', 'key2':'value2'}
    
    pairs_0 = pairs.copy()
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

    pairs_1 = pairs.copy()
    ansible_j_s_o_n_decoder_0.object_hook(pairs_1)

    pairs_2 = pairs.copy()
    ansible_j_s_o_n_decoder_0.object_hook(pairs_2)

    pairs_3 = pairs.copy()
    ansible_j_s_o_n_decoder_0.object_hook(pairs_3)

   

# Generated at 2022-06-25 03:38:52.239125
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(None)
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook(None), dict)

# Generated at 2022-06-25 03:39:00.158801
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = dict()
    test_case_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert test_case_0 == pairs


# Generated at 2022-06-25 03:39:01.270020
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:39:02.316264
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True


# Generated at 2022-06-25 03:39:07.028697
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets=None)
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs=None)
    if result is not None:
        print("")
    else:
        print("")


# Generated at 2022-06-25 03:39:15.992844
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': "AgDlUkN0AHYCSy1Nc20ML0FKVXUoaiNUOmJzQC1h"}
    test_dict = {'__ansible_vault': "AgDlUkN0AHYCSy1Nc20ML0FKVXUoaiNUOmJzQC1h"}
    assert test_dict == ansible_j_s_o_n_decoder_1.object_hook(pairs)


# Generated at 2022-06-25 03:39:21.002149
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_json_encoder_0 = AnsibleJSONEncoder().encode
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('This is some secret text', vault=None)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0, vault=None)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_1.vault
    ansible_vault_encrypted_unicode_1.vault = ansible_j_s_o_n_decoder_0._vaults
    ansible_j_s_o

# Generated at 2022-06-25 03:39:25.566423
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(None)
    result = ansible_j_s_o_n_decoder_1.object_hook(None)
    assert result == {}


# Generated at 2022-06-25 03:39:28.716398
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    str_obj_hook_2 = {}
    ansible_j_s_o_n_decoder_1.object_hook(str_obj_hook_2)

# Generated at 2022-06-25 03:39:39.951259
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    pairs_1 = {}

    AnsibleJSONDecoder.set_secrets(["test"])
    # Test with good input
    key_1 = '__ansible_vault'
    value_1 = 'AQD/JW8MvzD1Z3Lq5L5wcF8nsvbOdFgB0V52OQ=='
    pairs_1[key_1] = value_1
    pairs_2 = pairs_1.copy()

# Generated at 2022-06-25 03:39:49.619152
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['test'])

# Generated at 2022-06-25 03:39:57.594448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(None)
    ansible_json_decoder_0.object_hook("{'__ansible_vault': 'ansible_vault_encrypted_0'}")
    ansible_json_decoder_0.object_hook("__ansible_unsafe").__str__()

if __name__ == "__main__":
	test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:40:04.099698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    ansible_json_decoder_1.set_secrets(None)
    ansible_json_decoder_1.set_secrets([])
    pairs = {
        "__ansible_vault": "my_secret",
        "__ansible_unsafe": "my_other_secret"
    }
    ansible_json_decoder_1.object_hook(pairs)

# Generated at 2022-06-25 03:40:11.266216
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(object_hook_0_data)


# Generated at 2022-06-25 03:40:19.639943
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['secret'])
    test_obj = {'__ansible_vault': 'c29tZVZhdWx0IGVuY3J5cHRlZA=='}
    ansible_j_s_o_n_decoder_0.object_hook(test_obj)


# Generated at 2022-06-25 03:40:27.464497
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    string_0 = ansible_j_s_o_n_encoder_0.encode({'__ansible_vault': 'QQ=='})
    assert ansible_j_s_o_n_decoder_0.decode(string_0) == {'__ansible_vault': 'QQ=='}

# Generated at 2022-06-25 03:40:29.249901
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook(['TestString']) == ['TestString']



# Generated at 2022-06-25 03:40:37.596540
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets=dict())
    # Input data:
    json_data_0 = '{}'

    # Unit test execution:
    result = ansible_j_s_o_n_decoder_0.object_hook(json_data_0)

    # Unit test assertions:
    assert result == {}, 'Unit test for AnsibleJSONDecoder object_hook() method.'


# Generated at 2022-06-25 03:40:41.210146
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test case with no arguments.
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test case with positional arguments.
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:40:47.155479
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    dict_0 = dict()
    dict_0['__ansible_vault'] = 'foobar'
    dict_0['__ansible_unsafe'] = 'foobar'
    result = ansible_json_decoder_0.object_hook(dict_0)
    assert isinstance(result, dict)


# Generated at 2022-06-25 03:40:55.678698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # The value AnsibleVaultEncryptedUnicode can only be used for testing
    # of the class AnsibleJSONDecoder
    a_v_e_u_0 = AnsibleVaultEncryptedUnicode()
    # The value VaultLib can only be used for testing
    # of the class AnsibleJSONDecoder
    v_l_0 = VaultLib()
    ansible_j_s_o_n_decoder_0._vaults['default'] = v_l_0
    # The value AnsibleJSONDecoder._vaults['default'] can only be used for testing
    # of the class AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_0._vaults['default'] = v_

# Generated at 2022-06-25 03:41:02.817267
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # AnsibleJSONDecoder - object_hook
    # AnsibleJSONDecoder.object_hook(self, pairs)
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_u_n_i_c_o_d_e_0 = ansible_j_s_o_n_decoder_0.object_hook("__ansible_vault")
    ansible_u_n_s_a_f_e_p_r_o_x_y_0 = ansible_j_s_o_n_decoder_0.object_hook("__ansible_unsafe")

# Generated at 2022-06-25 03:41:12.383219
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0_0.object_hook({}) is None
    # A mock function that returns the first argument gets passed to the object_hook method
    ansible_j_s_o_n_decoder_0_1 = AnsibleJSONDecoder(object_hook=lambda x: x)
    assert ansible_j_s_o_n_decoder_0_1.object_hook({}) == {}
    # A mock function that raises an exception gets passed to the object_hook method
    # Per docs here https://docs.python.org/3/library/json.html#json.JSONDecoder.object_hook
    # if object_hook returns None, that's what ends up

# Generated at 2022-06-25 03:41:13.563560
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 03:41:17.615705
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:41:27.978311
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # test __ansible_vault
    # assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'string'}) == AnsibleVaultEncryptedUnicode('string')
    # assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'string', '__ansible_vault': 'string'}) == AnsibleVaultEncryptedUnicode('string', 'string')
    # test __ansible_unsafe
    # assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'string'}) == wrap_var('string')


# Generated at 2022-06-25 03:41:34.807492
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    if False:
        # we will never get this far, but the script(s) that generate the docs don't know that
        # and will emit a warning, so we use this instead
        pairs = None
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert type(result) == dict


# Generated at 2022-06-25 03:41:44.376953
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO
    # ansible_j_s_o_n_decoder_0._vaults = {} - ValueError: unknown format code 'b' for object of type 'str'
    # ansible_j_s_o_n_decoder_0.object_hook("default") - str is not JSON serializable


# Generated at 2022-06-25 03:41:51.332939
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': "data", '__ansible_unsafe': ["data", "data", "data"]}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs = pairs)
    assert type(result) == dict

# Generated at 2022-06-25 03:41:57.879184
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook() is None


# Generated at 2022-06-25 03:41:59.211609
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert False, "Test case or function not implemented."



# Generated at 2022-06-25 03:42:06.811377
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Case 0
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;0000000000000001\n626f6f6b2d7365637265722d76616c7565\n'})

# Generated at 2022-06-25 03:42:08.969543
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True

# Generated at 2022-06-25 03:42:17.844571
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs_0 = dict()
    pairs_0['__ansible_vault'] = 'foo'
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

    pairs_1 = dict()
    pairs_1['__ansible_vault'] = object()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(pairs_1)

    pairs_2 = dict()
    pairs_2['__ansible_unsafe'] = 'foo'
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:42:27.336452
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    variable_manager_3 = VariableManager()
    play_context_4 = PlayContext()
    task_5 = Task()
    ansible_j_s_o_n_decoder_0.object_hook(variable_manager_3)
    ansible_j_s_o_n_decoder_2.object_hook(play_context_4)
    ansible_j_s_o_n_decoder_0.object_hook(task_5)
#

# Generated at 2022-06-25 03:42:35.354523
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    ansible_json_decoder_2 = AnsibleJSONDecoder()
    ansible_json_decoder_3 = AnsibleJSONDecoder()
    ansible_json_decoder_3.set_secrets([''])
    ansible_json_decoder_4 = AnsibleJSONDecoder()
    ansible_json_decoder_4.set_secrets([''])


# Generated at 2022-06-25 03:42:46.264000
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:42:56.232909
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets('secret')
    answer = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'})

    assert isinstance(answer, AnsibleVaultEncryptedUnicode)
    assert answer == "$ANSIBLE_VAULT;1.1;AES256"



# Generated at 2022-06-25 03:43:03.250789
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:43:18.397837
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': ''}
    with pytest.raises(TypeError):
        ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:43:23.090213
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for object_hook produced by case_0
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_input = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n6332666163396137613461333563353466653062356338326535316266376363396430666262650\na\na'}
    test_output = ansible_j_s_o_n_decoder_0.object_hook(test_input)
    assert isinstance(test_output,AnsibleVaultEncryptedUnicode)
    assert test_output.vault


# Generated at 2022-06-25 03:43:27.238870
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_obj1 = AnsibleJSONDecoder()
    test_var_val = [{"key1": "val1", "key2": "val2", "key3": "val3"}]
    assert ansible_j_s_o_n_decoder_obj1.object_hook(test_var_val) is None
#

# Generated at 2022-06-25 03:43:35.901257
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # setup test data
    pairs = {'__ansible_vault': 'value'}
    # noinspection PyTypeChecker
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:43:42.760376
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    vault_lib_1 = VaultLib()
    ansible_v_a_u_l_t_encrypted_unicode_1.vault = vault_lib_1
    ansible_j_s_o_n_decoder_1._vaults['default'] = vault_lib_1
    actual = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'XXX'})
    assert actual == ansible_v_a_u_l_t_encrypted_unicode_1
    ansible_j_s_o_n_dec

# Generated at 2022-06-25 03:43:50.169424
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('Too long to be a password')
    ansible_v_a_u_l_t_encrypted_unicode_0.vault = VaultLib(secrets=['password'])

    # Test case where the key is __ansible_vault

# Generated at 2022-06-25 03:43:58.544499
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["my_secret"])
    ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": "AQIDBAUGBwgJCgsMDQ4PEA==", "__ansible_unsafe": "bad\u0020guy"})
    ansible_j_s_o_n_decoder_0.object_hook({"__ansible_unsafe": "good\u0020guy"})



# Generated at 2022-06-25 03:44:01.139349
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:44:02.512932
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass


# Generated at 2022-06-25 03:44:10.898327
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

    # Test with no optional arguments

    actual = ansible_j_s_o_n_decoder.object_hook({'1': '2', '__ansible_vault': '3', '__ansible_unsafe': '4'})
    expected = {'1': '2', '__ansible_vault': '3', '__ansible_unsafe': '4'}
    assert actual == expected


# Generated at 2022-06-25 03:44:19.428727
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs=[])


# Generated at 2022-06-25 03:44:29.712220
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_object_hook_0 = AnsibleJSONDecoder()
# No input
    result = ansible_json_decoder_object_hook_0.object_hook({'key': 'value'})
    assert isinstance(result, dict)
    assert not '__ansible_vault' in result.keys()
    assert 'key' in result.keys()

# Test with a vault object
    result = ansible_json_decoder_object_hook_0.object_hook({'__ansible_vault': 'foo'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is None

# Test with a vault object and a given vault
    ansible_json_decoder_object_hook_0.vault = VaultLib()

# Generated at 2022-06-25 03:44:34.054534
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs = {'ansible_vault': 'ansible_vault', 'ansible_unsafe': 'ansible_unsafe'}

    assert ansible_j_s_o_n_decoder_1.object_hook(pairs) == pairs

# Generated at 2022-06-25 03:44:40.191754
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == pairs


# Generated at 2022-06-25 03:44:42.765139
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    #assert ansible_j_s_o_n_decoder_1.object_hook() == NotImplementedError


# Generated at 2022-06-25 03:44:54.136323
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0_object_hook_pairs_0 = {'__ansible_unsafe': 'unsafe value'}
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1_result = ansible_j_s_o_n_decoder_1.object_hook(ansible_j_s_o_n_decoder_0_object_hook_pairs_0)
    ansible_j_s_o_n_decoder_0_object_hook_pairs_1 = {'__ansible_vault': 'vault value'}
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ans

# Generated at 2022-06-25 03:45:01.319034
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib()
    ansible_j_s_o_n_decoder_0.object_hook({})



# Generated at 2022-06-25 03:45:11.925413
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets='super_secret_password')
    vault_string = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test\n636534633232626539393762333766353965666530366635363866373839616662386162313664\n61626464363032386131623436313265396466396162316639\n'})

# Generated at 2022-06-25 03:45:17.248192
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0 is not None


# Generated at 2022-06-25 03:45:24.286444
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Check the object_hook of AnsibleJSONDecoder
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    test_AnsibleJSONDecoder_obj = ansible_json_decoder_0.object_hook({'__ansible_vault': 'test_vault_secret', '__ansible_unsafe': 'test_value'})


# Generated at 2022-06-25 03:45:39.241890
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({"key": "value"}) == {"key": "value"}


# Generated at 2022-06-25 03:45:49.628864
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test with invalid arguments
    # No arguments
    try:
        ansible_j_s_o_n_decoder_0.object_hook()
        assert(False)
    except TypeError as e:
        assert(str(e) == "object_hook() takes exactly 2 arguments (1 given)")
    # One argument
    try:
        ansible_j_s_o_n_decoder_0.object_hook('pairs')
        assert(False)
    except TypeError as e:
        assert(str(e) == "object_hook() takes exactly 2 arguments (1 given)")
    # Three arguments

# Generated at 2022-06-25 03:45:54.112327
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test for object_hook
    # test_case_0
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:45:59.751768
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    try:
        return_value_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    except NameError as e:
        if "global name '__ansible_vault' is not defined" in str(e):
            return 1
        else:
            raise


# Generated at 2022-06-25 03:46:07.111102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(strict=True)
    ansible_j_s_o_n_decoder_0.set_secrets(["password"])

# Generated at 2022-06-25 03:46:08.531536
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()



# Generated at 2022-06-25 03:46:10.410375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook() == None

# Generated at 2022-06-25 03:46:19.803863
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test with input parameter #0 (pairs={})
    ansible_j_s_o_n_decoder_0_pairs_0 = {}
    ansible_j_s_o_n_decoder_0_return_value_0 = ansible_j_s_o_n_decoder_0.object_hook(ansible_j_s_o_n_decoder_0_pairs_0)

    # Test with input parameter #1 (pairs={'key_0': 'value_0'})
    ansible_j_s_o_n_decoder_0_pairs_1 = {'key_0': 'value_0'}
    ansible_j_s_o_n_dec

# Generated at 2022-06-25 03:46:25.463276
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_u_n_i_c_o_d_e_0 = AnsibleVaultEncryptedUnicode("")
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': ansible_v_a_u_l_t_encrypted_u_n_i_c_o_d_e_0}) is ansible_v_a_u_l_t_encrypted_u_n_i_c_o_d_e_0

# Generated at 2022-06-25 03:46:33.251335
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncodedUnicode()


# Generated at 2022-06-25 03:47:04.288244
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:47:14.979784
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    secret = b'$ANSIBLE_VAULT;1.1;AES256;abcdefghijklmnopqrstuvwxyz123456\n3434324324234324324234234234324323423423423342344\n'

    AnsibleJSONDecoder.set_secrets(b'ansible')
    test_input = b'{"__ansible_vault": "3434324324234324324234234234324323423423423342344"}'
    test_output = ansible_j_s_o_n_decoder_0.decode(test_input)



# Generated at 2022-06-25 03:47:21.221655
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Assign values to variables for testing

    # Call method
    method_return_value = ansible_j_s_o_n_decoder_0.object_hook()



# Generated at 2022-06-25 03:47:25.945252
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # FIXME: This should be a test of
    #        ansible.module_utils.common.json.AnsibleJSONDecoder
    #        but that uses AnsibleJSONDecoder instead of object_hook
    #        which is confusing (to me).

    # ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # if not isinstance(ansible_j_s_o_n_decoder_0, AnsibleJSONDecoder):
    #     fail('Failed to create instance of AnsibleJSONDecoder')

    # FIXME: Test code goes here.
    raise NotImplementedError()



# Generated at 2022-06-25 03:47:29.377779
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:47:37.950690
# Unit test for method object_hook of class AnsibleJSONDecoder