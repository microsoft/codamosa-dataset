

# Generated at 2022-06-25 03:37:40.237639
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:37:49.355088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create AnsibleJSONEncoder object with default constructor call
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()

    # Create AnsibleJSONDecoder object with default constructor call
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

    # Extract string from AnsibleVaultEncryptedUnicode object with
    # vault_id and vault_password as parameters
    vaulted_string = ansible_j_s_o_n_encoder.encode(
        AnsibleVaultEncryptedUnicode(
            '{"password": "%s"}' % 'password', vault_identity='default')).strip('"')

    # Extract string from AnsibleVaultEncryptedUnicode object with
    # vault_id and vault_password as parameters
    vaulted_string_enc

# Generated at 2022-06-25 03:38:01.282957
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # TestCase 1
    # Vault decrypt data and safe string

# Generated at 2022-06-25 03:38:07.030110
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {'__ansible_vault': 'foo'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(data)


# Generated at 2022-06-25 03:38:08.780280
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.object_hook(dict())


# Generated at 2022-06-25 03:38:19.399744
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Dump dict '__ansible_unsafe'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.set_defaults()
    dict_0 = {'__ansible_unsafe': 'foo'}
    json_str_0 = ansible_j_s_o_n_encoder_0.encode(dict_0)
    json_dict_0 = json.loads(json_str_0, object_hook=ansible_j_s_o_n_decoder_0.object_hook)
    assert json_dict_0['__ansible_unsafe'] == 'foo'


#

# Generated at 2022-06-25 03:38:21.792238
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert isinstance(ansible_j_s_o_n_decoder_1.object_hook({}), dict)


# Generated at 2022-06-25 03:38:26.841628
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    dict_0 = dict()
    dict_1 = dict()
    dict_0['__ansible_vault'] = 'some_string'
    dict_1['__ansible_vault'] = 'some_string'

    dict_0 = ansible_j_s_o_n_decoder_0.object_hook(dict_0)
    dict_1 = ansible_j_s_o_n_decoder_0.object_hook(dict_1)

    assert dict_0 == dict_1


# Generated at 2022-06-25 03:38:31.758136
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(ansible_j_s_o_n_decoder_0)

# Generated at 2022-06-25 03:38:37.804272
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:38:40.051637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True


# Generated at 2022-06-25 03:38:48.407503
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    fake_pairs_0 = "TODO"

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {}
    # Exercise
    fake_pairs_1 = "TODO"
    ansible_j_s_o_n_decoder_0.object_hook(fake_pairs_1)
    # Verify


# Generated at 2022-06-25 03:38:50.036901
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:54.403070
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:39:03.060943
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:39:07.530966
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test that normal dicts are returned unaltered.
    dict_input = {'foo': 'bar'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    if not ansible_j_s_o_n_decoder_0.object_hook(dict_input) == dict_input:
        raise AssertionError('dict not returned unaltered by AnsibleJSONDecoder.object_hook')


# Generated at 2022-06-25 03:39:17.921335
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pre_object_hook_input_path = 'fake_pre_object_hook_input_path'
    pre_object_hook_input_vault = None
    pre_object_hook_input_unsafe = None
    pre_object_hook_args = (pre_object_hook_input_path, pre_object_hook_input_vault, pre_object_hook_input_unsafe)
    pre_object_hook_def = (None, 'fake_pre_object_hook_def_path', None)
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1._vaults['default'] = 'fake_secret'

# Generated at 2022-06-25 03:39:23.878256
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "test_value"}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {"__ansible_vault": AnsibleVaultEncryptedUnicode("test_value")}

# Generated at 2022-06-25 03:39:32.171267
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {}

# Generated at 2022-06-25 03:39:35.198781
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:39:49.255225
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # In this test we create a structure that contains both a __safe__ and a __unsafe__ element.
    # we expect a wrapped unsafe element to be returned when calling _object_hook()
    test_result = ansible_j_s_o_n_decoder_0._object_hook({'__ansible_unsafe': 'default_value'})
    assert isinstance(test_result, dict)
    # the dict will only contain one key (__ansible_unsafe)
    assert len(test_result.keys()) == 1
    # and the returned object has to be of AnsibleUnsafeText type

# Generated at 2022-06-25 03:39:54.226476
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(ansible_vault=None)

# Generated at 2022-06-25 03:40:01.161774
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Mock object_hook
    test_object_hook = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook = test_object_hook


# Generated at 2022-06-25 03:40:07.873591
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Load the expected output of the command
    try:
        with open('tests/fixtures/output/test_AnsibleJSONDecoder_object_hook.json', 'r') as f:
            test_data = json.load(f)
    except Exception as e:
        print('Exception: ' + str(e))
        assert False

    # Load the input of the command
    try:
        with open('tests/fixtures/input/test_AnsibleJSONDecoder_object_hook.json', 'r') as f:
            input_data = json.load(f)
    except Exception as e:
        print('Exception: ' + str(e))
        assert False

    # Load the variable(s)

# Generated at 2022-06-25 03:40:14.564509
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0.set_secrets(str(ansible_json_encoder_0))
    assert ansible_j_s_o_n_decoder_0.object_hook(str(ansible_json_encoder_0)) is None


# Generated at 2022-06-25 03:40:18.256629
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    with open('/home/dynatrace/workspaces/ansible/ansible/test/units/lib/ansible/module_utils/common/json/ansible_json.json', 'r') as ans_json_1:
        ansible_j_s_o_n_decoder_1.decode(ans_json_1.read())


# Generated at 2022-06-25 03:40:21.732122
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # input arguments for function
    pairs = {'key': 'value'}

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs)


# Generated at 2022-06-25 03:40:26.515670
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_0.object_hook("dummy")


# Generated at 2022-06-25 03:40:34.471252
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:40:44.628573
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:40:52.232218
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}

    # Call method object_hook with pair_0
    AnsibleJSONDecoder_object_hook(ansible_j_s_o_n_decoder_0, pairs_0)


# Generated at 2022-06-25 03:40:54.292542
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    assert ansible_j_s_o_n_decoder_0.object_hook([]) == []


# Generated at 2022-06-25 03:41:02.053257
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_dict = {'__ansible_vault': 'ansible_vault'}
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(test_dict)
    assert(ansible_vault_encrypted_unicode_0['__ansible_vault'] == 'ansible_vault')


# Generated at 2022-06-25 03:41:03.381523
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)


# Generated at 2022-06-25 03:41:11.962084
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder(object_hook=ansible_j_s_o_n_decoder_0.object_hook)
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2.object_hook('__ansible_vault')
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_3.object_hook('__ansible_unsafe')


# Generated at 2022-06-25 03:41:18.993486
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    secrets = ['hello']
    AnsibleJSONDecoder.set_secrets(secrets)
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    pairs['__ansible_vault'] = 'hello'
    pairs['__ansible_unsafe'] = 'hello'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(pairs['__ansible_vault'])
    ansible_vault_encrypted_unicode_0.vault = ansible_j_s_o_n_decoder_0._vaults['default']
    expected_0 = {}
    expected_0['__ansible_vault'] = ansible_vault_encrypted_unicode_0

# Generated at 2022-06-25 03:41:30.732705
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj_hook_obj = AnsibleJSONDecoder()
    obj_hook_obj.set_secrets([])
    # Test __ansible_vault
    obj_hook_str_pairs = {'__ansible_vault': 'abc'}
    obj_hook_ret = obj_hook_obj.object_hook(obj_hook_str_pairs)
    obj_hook_exp = {'__ansible_vault': 'abc'}
    test_assert(obj_hook_ret == obj_hook_exp)
    # Test __ansible_unsafe
    obj_hook_str_pairs = {'__ansible_unsafe': 'abc'}
    obj_hook_ret = obj_hook_obj.object_hook(obj_hook_str_pairs)

# Generated at 2022-06-25 03:41:40.439903
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    with open('tests/test_utils/playbook/ansible_j_s_o_n_encoder.json', 'r') as my_file:
        test_json = my_file.read()
    ansible_j_s_o_n_decoder_0.set_secrets(['secretpassword'])
    decoded_json = ansible_j_s_o_n_decoder_0.decode('{"__ansible_vault": "AQD/HtI2Rt1bIXfvXXoie0wfSF5OZHkI5d2Q5O1xB4Ly4yelYNAF4PHitB"}')

# Generated at 2022-06-25 03:41:43.578200
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # No input data to test with, test skipped


# Generated at 2022-06-25 03:41:48.369732
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:41:59.383441
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {"b" : 1}
    ansible_json_decoder_object_hook_1 = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert (ansible_json_decoder_object_hook_1 == {'b': 1})


# Generated at 2022-06-25 03:42:05.232262
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    assert ansible_j_s_o_n_decoder_0.object_hook({}) == {}


# Generated at 2022-06-25 03:42:07.162495
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) is not None


# Generated at 2022-06-25 03:42:14.681869
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["not-a-real-secret"])

    c_n_d_0 = '__ansible_vault'
    c_n_d_1 = '$ANSIBLE_VAULT;1.1;AES256;fakedomain.com;'
    c_n_d_2 = '6152366265393564373732656466383638343563376365363537663538373934376466353133363164'

# Generated at 2022-06-25 03:42:22.166734
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    key_0 = '__ansible_vault'
    value_0 = 'ansible'
    pairs_0 = {key_0: value_0}
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert isinstance(result_0, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 03:42:29.721600
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook("x") == "x"


# Generated at 2022-06-25 03:42:36.035929
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:42:44.825820
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({
        '__ansible_unsafe': '{{lookup("env", "ANSIBLE_TESTVAR_IN_ENV")}}',
        '__ansible_vault': 'test'
    }) == {
        '__ansible_unsafe': '{{lookup("env", "ANSIBLE_TESTVAR_IN_ENV")}}',
        '__ansible_vault': 'test'
    }


# Generated at 2022-06-25 03:42:45.653374
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True

# Generated at 2022-06-25 03:42:47.554612
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_json_decoder = AnsibleJSONDecoder()

    ansible_json_decoder.object_hook('some pairs')



# Generated at 2022-06-25 03:43:06.837102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    print('')
    # *** AnsibleVaultEncryptedUnicode
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    keys_0 = {'a': 'b', 'c': 'd'}
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(keys_0)
    assert result_0 == keys_0

    # *** AnsibleVaultEncryptedUnicode
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs_0 = {'__ansible_vault': 'b'}
    result_1 =ansible_j_s_o_n_decoder_1.object_hook(pairs_0)

# Generated at 2022-06-25 03:43:09.910895
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Set up valid input...
    pairs = dict()

    # ...and run the method.
    ansible_j_s_o_n_decoder_1.object_hook(pairs)


# Generated at 2022-06-25 03:43:22.709735
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['abc123'])

# Generated at 2022-06-25 03:43:28.584423
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setting vault secret
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['test_secrets'])
    # Preparing pairs
    pairs = {'__ansible_vault': 'test_value'}
    # Invoking object_hook
    value = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert value == AnsibleVaultEncryptedUnicode('test_value')

# Generated at 2022-06-25 03:43:33.273396
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:43:37.604264
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook == ansible_j_s_o_n_decoder_0.object_hook


# Generated at 2022-06-25 03:43:43.902810
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = dict()
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook(pairs), object)


# Generated at 2022-06-25 03:43:49.372873
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Default test case
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(None)



# Generated at 2022-06-25 03:43:58.252249
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.vault = ansible_j_s_o_n_decoder_1._vaults['default']

# Generated at 2022-06-25 03:44:09.363031
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(secrets=None)
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2.set_secrets(secrets=[{}, [], '', '', ()])
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_3.set_secrets(secrets=['', [], '', '', '', (1, 2), {2}, {2: ''}, [{}], '', (1, 2, 3)])


# Generated at 2022-06-25 03:44:37.295584
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    vault_lib_0 = VaultLib()
    ansible_j_s_o_n_decoder_0.set_secrets(vault_lib_0)
    ansible_json_decoder_0 = AnsibleJSONDecoder(ansible_j_s_o_n_decoder_0)
    ansible_json_encoder_0 = AnsibleJSONEncoder(ansible_j_s_o_n_encoder_0)
    ansible_json_encoder_0.encode()
    ansible_json_encoder_0.iterencode()

# Generated at 2022-06-25 03:44:42.479163
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    arg_0 = dict()
    arg_0['__ansible_vault'] = '1234'

    res_0 = ansible_j_s_o_n_decoder_0.object_hook(arg_0)
    assert res_0['__ansible_vault'].enc_data == '1234'


# Generated at 2022-06-25 03:44:53.377410
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_object_hook_0_pairs = {'__ansible_vault':'test_object_hook_0___ansible_vault'}
    test_object_hook_0_pairs['__ansible_unsafe'] = 'test_object_hook_0___ansible_unsafe'
    test_AnsibleJSONDecoder_object_hook_0_pairs = ansible_j_s_o_n_decoder_0.object_hook(test_object_hook_0_pairs)
# Test for AnsibleJSONEncoder

# Generated at 2022-06-25 03:45:00.646823
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_json_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_1.set_secrets('secret_one')

# Generated at 2022-06-25 03:45:11.861466
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:45:21.084639
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(['secret'])

    # Test __ansible_vault
    input = {'__ansible_vault': 'vault'}
    output = ansible_j_s_o_n_decoder_1.object_hook(input)
    assert(output.data == input['__ansible_vault'])
    assert(output._AnsibleVault__vault == ansible_j_s_o_n_decoder_1._vaults['default'])

    # Test __ansible_unsafe
    input = {'__ansible_unsafe': 'unsafe'}
    output = ansible_j_s_o

# Generated at 2022-06-25 03:45:21.996027
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_case_0()

# Generated at 2022-06-25 03:45:30.214990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["password"])

# Generated at 2022-06-25 03:45:34.247237
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs='')

# Generated at 2022-06-25 03:45:34.987116
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert (False)

# Generated at 2022-06-25 03:46:23.357216
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    unparsed_obj = {'__ansible_vault': "Some string"}
    parsed_obj = decoder.object_hook(unparsed_obj)
    assert isinstance(parsed_obj, AnsibleVaultEncryptedUnicode)
    assert parsed_obj.vault == decoder._vaults['default']
    assert parsed_obj.raw_data == "Some string"



# Generated at 2022-06-25 03:46:28.370637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'key': 'value'}
    pairs = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert pairs == {'key': 'value'}


# Generated at 2022-06-25 03:46:36.882272
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('zwL+GJjKxCiobr9r9kQABAKj3q1iFzLO')
    ansible_vault_encrypted_unicode_0._vault = VaultLib('zwL+GJjKxCiobr9r9kQABAKj3q1iFzLO')
    dict_0 = {'__ansible_vault': 'zwL+GJjKxCiobr9r9kQABAKj3q1iFzLO'}


# Generated at 2022-06-25 03:46:43.354291
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Encrypt the secret with vaule "12345678" with the password "password".
    secret = '$ANSIBLE_VAULT;1.1;AES256\n313537333038333061623033316336626165626161343134613331333135653636653836313636626634\n653634316562366164326132323634373834393965373662336264613937386662343437353361343432\n626533396661323165353634366633353439'
    AnsibleJSONDecoder.set_secrets(['password'])

    # Step 1: Check __anssible_vault
    # Set

# Generated at 2022-06-25 03:46:52.876347
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': '', '__ansible_unsafe': ''}
    expected_pairs = {'__ansible_vault': '', '__ansible_unsafe': ''}
    actual_pairs = ansible_j_s_o_n_decoder_0.object_hook(pairs)

    assert actual_pairs == expected_pairs, "%s != %s" % (actual_pairs, expected_pairs)


# Generated at 2022-06-25 03:46:57.877703
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test object_hook on AnsibleJSONDecoder
    ansible_json_decoder_object_hook_1_pairs = {'__ansible_vault': {'vault_password': 'secret'}}
    ansible_json_decoder_object_hook_1 = TestClass12(ansible_json_decoder_object_hook_1_pairs)
    ansible_json_decoder_object_hook_1.set_secrets(['secret'])
    ansible_json_decoder_object_hook_1_result = ansible_json_decoder_object_hook_1.object_hook(ansible_json_decoder_object_hook_1_pairs)

# Generated at 2022-06-25 03:47:03.984917
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    #
    # Imported for backwards compat
    #
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_decoder_0.vault = ansible_v_a_u_l_t_encrypted_unicode_0
    key = '__ansible_vault'
    value = 'ANSIBLE_VAULT;1.1;AES256;ansibleadmin\n'
    pairs = {key: value}
    ansible_j_s_o_n_decoder_0.object_

# Generated at 2022-06-25 03:47:09.322738
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['test_secrets'])
    result = ansible_j_s_o_n_decoder_0.object_hook(dict(__ansible_vault='test_value'))
    assert result.vault == ansible_j_s_o_n_decoder_0._vaults['default']


# Generated at 2022-06-25 03:47:14.353702
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj_0 = AnsibleJSONDecoder()
    obj_0.set_secrets('WILL BE IGNORED')
    pairs = '__ansible_vault'
    obj_0_object_hook = obj_0.object_hook(pairs)
    assert obj_0_object_hook is not None
    assert isinstance(obj_0_object_hook, AnsibleVaultEncryptedUnicode)

test_case_0()
test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:47:19.518524
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_json_decoder_object_hook_0.object_hook({'foo': 'bar'})
