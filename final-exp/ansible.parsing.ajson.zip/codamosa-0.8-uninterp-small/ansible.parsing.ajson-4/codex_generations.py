

# Generated at 2022-06-25 03:37:40.305911
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    tuple_0 = ()
    ansible_j_s_o_n_decoder_0.object_hook(tuple_0)

# Generated at 2022-06-25 03:37:42.425090
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for method object_hook of class AnsibleJSONDecoder
    # Calling method object_hook of class AnsibleJSONDecoder
    test_case_0()


# Generated at 2022-06-25 03:37:48.347797
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    dict_0 = dict()
    dict_0['__ansible_unsafe'] = '42.42'
    key_0 = ansible_j_s_o_n_decoder_0.object_hook(dict_0)._key
    assert key_0 == '42.42'


# Generated at 2022-06-25 03:37:56.337983
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Testing for empty dictionary
    pairs = {}

    AnsibleJSONDecoder.set_secrets(None)
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = pairs
    assert pairs == ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

    # Testing for a dictionary with standard key-value pairs
    AnsibleJSONDecoder.set_secrets(None)
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs = {'standard_key': 'standard_value'}
    pairs_1 = pairs
    assert pairs == ansible_j_s_o_n_decoder_1.object_hook(pairs_1)

    # Testing for a dictionary

# Generated at 2022-06-25 03:37:59.581360
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    tuple_0 = ()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO: Create testcase for method object_hook of class AnsibleJSONDecoder
    return ansible_j_s_o_n_decoder_0


# Generated at 2022-06-25 03:38:09.366652
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    tuple_0 = ()
    dict_0 = dict(__ansible_vault='V2h5IHNvdWxkIGFuIGluc3RhbmNlIG9mIGpzb24uSlNPTkRlY29kZXIgb2J0YWluIGEgY29tcG9uZW50IG9mIHR5cGUgamlwcGxlLiQ=')
    dict_0 = dict(__ansible_unsafe='V2h5IHNvdWxkIGFuIGluc3RhbmNlIG9mIGpzb24uSlNPTkRlY29kZXIgb2J0YWluIGEgY29tcG9uZW50IG9mIHR5cGUgamlwcGxlLiQ=')
    ansible_j_

# Generated at 2022-06-25 03:38:15.295084
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    tuple_0 = ()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.set_secrets("password")
    ansible_j_s_o_n_decoder_0.object_hook(tuple_0)

# Generated at 2022-06-25 03:38:19.423722
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    string_0 = {"__ansible_unsafe": False}
    assert ansible_j_s_o_n_decoder_0.object_hook(string_0)


# Generated at 2022-06-25 03:38:27.338426
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Ensure that this method handles string values without crashing.
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0='RgRmZTVlMDQ2M2ZmZDk3MjJkMzM0NjFhZmRiYjY5YWI2MGU2YjU5MzU5MThmZDRkMzE5YjJmZGNkMzYwYjMwYw==')

# Generated at 2022-06-25 03:38:34.401226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Initialize a variable with value
    input_0 = {'__ansible_vault': '7384u22hdv87'}
    # Uncomment the next line to instantiate a class instance
    # ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Uncomment the next line to instantiate a class instance
    # ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Call the method under test
    AnsibleJSONDecoder._vaults = {}
    AnsibleJSONDecoder.set_secrets('password')
    assert AnsibleJSONDecoder.object_hook(ansible_j_s_o_n_decoder_0, input_0) == {'__ansible_vault': '7384u22hdv87'}

# Generated at 2022-06-25 03:38:41.122906
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('vault_secret')
    ansible_v_a_u_l_t_encrypted_unicode_0_as_safe = wrap_var(ansible_v_a_u_l_t_encrypted_unicode_0)
    ansible_j_s_o_n_decoder_0.set_secrets({})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'vault_secret'})

# Generated at 2022-06-25 03:38:45.542914
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:38:51.996161
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_obj = AnsibleJSONDecoder()
    if hasattr(ansible_j_s_o_n_decoder_obj, "object_hook"):
        ansible_j_s_o_n_decoder_obj.object_hook("")


# Generated at 2022-06-25 03:38:57.006852
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:39:08.704669
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """test class method AnsibleJSONDecoder.object_hook()
    """

# Generated at 2022-06-25 03:39:12.294741
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets('12345')


# Generated at 2022-06-25 03:39:19.022888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with an empty dictionary as input
    ansible_j_s_o_n_decoder_object_hook_1 = AnsibleJSONDecoder.object_hook(dict())

    expected = dict()
    assert ansible_j_s_o_n_decoder_object_hook_1 == expected

    # Test with '__ansible_vault' key in the dictionary

# Generated at 2022-06-25 03:39:27.213454
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Case of object hook is AnsibleVaultEncryptedUnicode
    def test_case_11():
        ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'test_value_12'})
    # Case of object hook is AnsibleUnsafeText
    def test_case_21():
        ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test_value_22'})


# Generated at 2022-06-25 03:39:29.563713
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:39:37.832784
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('test_vault_secrets')
    with open('test/unittests/data/role_defaults/test_object_hook.json') as f:
        json_input = f.read()
    ansible_j_s_o_n_decoder_0.decode(json_input)
    # ansible_j_s_o_n_decoder_0.object_hook(json.load(open('test/unittests/data/role_defaults/test_object_hook.json')))


# Generated at 2022-06-25 03:39:48.069031
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["password1", "password2"])

    # Encrypted text without vault prefix
    data = '{"__ansible_vault": "test_value"}'
    result = ansible_j_s_o_n_decoder_1.decode(data)
    assert result['__ansible_vault'].vault == ansible_j_s_o_n_decoder_0._vaults['default']

    # Encrypted text with vault prefix

# Generated at 2022-06-25 03:39:54.121920
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_obj = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_obj.object_hook()


# Generated at 2022-06-25 03:40:05.968935
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Unit test for method object_hook of class AnsibleJSONDecoder
    """
    # Run test with value = {'__ansible_vault': 'yH2J0G+vK8b6W/B6ZqJf/w=='}
    pairs = {'__ansible_vault': 'yH2J0G+vK8b6W/B6ZqJf/w=='}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert ansible_j_s_o_n_decoder_1 is not None
    # Run test with value = {'

# Generated at 2022-06-25 03:40:12.189064
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # From generated test
    secret_0 = 'testString'
    ansible_j_s_o_n_decoder_0.set_secrets(secrets=secret_0)
    data_0 = 'testString'
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(data_0)
    # compare result_0 with expected result


# Generated at 2022-06-25 03:40:19.959732
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder.AnsibleJSONDecoder()
    pairs = dict()
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert isinstance(result, dict)



# Generated at 2022-06-25 03:40:27.877096
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["hunter2"])
    ansible_j_s_o_n_decoder_0.object_hook("U2FuZGJveC1wZW0=")
    ansible_j_s_o_n_decoder_0.object_hook("U2FuZGJveC1wZW0=")


# Generated at 2022-06-25 03:40:32.278164
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'abc'}) == AnsibleVaultEncryptedUnicode('abc')


# Generated at 2022-06-25 03:40:42.738489
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:40:45.096266
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert True
    # We don't have a test for this
    pass

# Generated at 2022-06-25 03:40:55.586199
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:01.857737
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0_dictionary_0 = {'__ansible_vault': 'abcdefg'}
    ansible_json_decoder_0_object_0 = ansible_json_decoder_0.object_hook(ansible_json_decoder_0_dictionary_0)


# Generated at 2022-06-25 03:41:12.481504
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json


# Generated at 2022-06-25 03:41:15.149851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs = ['my_pair'])


# Generated at 2022-06-25 03:41:20.453237
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(dict())


# Generated at 2022-06-25 03:41:28.695633
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create an instance of the AnsibleJSONDecoder class
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Case 1: Test with a dictionary of key-value pairs
    pairs = {'f': 'g'}
    pairs_expected = pairs
    pairs_actual = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert pairs_expected == pairs_actual

    # Case 2: Test with an empty dictionary
    pairs = {}
    pairs_expected = {}
    pairs_actual = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert pairs_expected == pairs_actual

    # Case 3: Test with a key-value pair in the dictionary, where the key is '__ansible_v

# Generated at 2022-06-25 03:41:37.646163
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansibleuser\n36396235316536643433366433343535326463313235633264653039383666336566626432373\n3561333565623033396437393465353236333563366562333036313932623734323663363734\n63366336393333333964373538363838343866323563666362616466\n'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)

# Generated at 2022-06-25 03:41:39.175473
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True is not False



# Generated at 2022-06-25 03:41:50.106986
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # assert callable(AnsibleJSONDecoder.object_hook)
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # ansible_j_s_o_n_decoder_0.set_secrets(secrets=secrets)
    ansible_j_s_o_n_decoder_0.object_hook(pairs={'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe'})

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(vault_id='default', value='value')
    # ansible_vault_encrypted_unicode_0.vault

# Generated at 2022-06-25 03:41:56.210496
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test with default arguments
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:42:01.004648
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    dict = dict(a=1, b=2)
    dict['__ansible_vault'] = 'vault_password'
    dict['__ansible_unsafe'] = '{"a":1, "b":2}'

    assert AnsibleJSONDecoder.object_hook(dict) == dict

# Generated at 2022-06-25 03:42:13.281978
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:42:16.442116
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook('TEST') == 'TEST'

# Generated at 2022-06-25 03:42:18.404574
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    params = {}
    result = ansible_j_s_o_n_decoder_1.object_hook(params)

# Generated at 2022-06-25 03:42:27.527701
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    def test_object_hook(pairs):
        for key in pairs:
            value = pairs[key]
            if key == '__ansible_vault':
                value = AnsibleVaultEncryptedUnicode(value)
                if ansible_j_s_o_n_decoder_0._vaults:
                    value.vault = ansible_j_s_o_n_decoder_0._vaults['default']
                return value
            elif key == '__ansible_unsafe':
                return wrap_var(value)

        return pairs

    sample = {
        'a': 5,
        'b': 7,
        'c': '__ansible_vault'
    }


# Generated at 2022-06-25 03:42:34.597732
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    my_dict = {'a': 'A', 'b': AnsibleVaultEncryptedUnicode('Encrypted String')}  # Unused
    ansible_j_s_o_n_decoder_0.set_secrets(['my_secret'])
    decoded = ansible_j_s_o_n_decoder_0.decode(json.dumps(my_dict))
    assert decoded == {'__ansible_unsafe': False, 'a': 'A', 'b': 'Encrypted String'}

# Generated at 2022-06-25 03:42:45.722874
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)


# Generated at 2022-06-25 03:42:47.633255
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pass


# Generated at 2022-06-25 03:42:54.018417
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:42:57.035541
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # set up test data
    pairs = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder.object_hook(pairs)


# Generated at 2022-06-25 03:43:00.735988
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json = """{
        "__ansible_unsafe": {
            "__ansible_unsafe_bytes": "hi"
        }
    }"""

    result = AnsibleJSONDecoder().decode(test_json)
    assert result == {'__ansible_unsafe': {'__ansible_unsafe_bytes': b'hi'}}


# Generated at 2022-06-25 03:43:12.195502
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['test_secrets'])
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'test_value'}) == AnsibleVaultEncryptedUnicode('test_value')
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test_value'}) == wrap_var('test_value')

# Generated at 2022-06-25 03:43:18.896314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:43:24.581906
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_dict = {'__ansible_vault': 'TESTING'}
    ansible_j_s_o_n_decoder_0.set_secrets(['123'])
    result = ansible_j_s_o_n_decoder_0.object_hook(json_dict)
    assert isinstance(result, dict)
    assert len(result) == 1
    assert '__ansible_vault' in result
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 03:43:26.310053
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_case_0()



# Generated at 2022-06-25 03:43:28.487398
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    

# Generated at 2022-06-25 03:43:33.724871
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    assert ansible_json_decoder_0.object_hook({}) == {}

# Generated at 2022-06-25 03:43:37.348997
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook()


# Generated at 2022-06-25 03:43:46.018183
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Set secrets for class AnsibleJSONDecoder
    secrets = ['foo']
    AnsibleJSONDecoder.set_secrets(secrets)
    # Set attribute of object
    value = 'bar'
    pairs = {"__ansible_unsafe": value}
    # Call method
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    # Assert result
    try:
        assert result
        assert result['__ansible_unsafe'] == wrap_var('bar')
    except AssertionError as e:
        raise AssertionError()
    # Set attribute of object
    value = 'bar'
    pairs = {"__ansible_vault": value}
   

# Generated at 2022-06-25 03:43:47.192345
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_4 = AnsibleJSONDecoder()
	



# Generated at 2022-06-25 03:43:51.704773
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_secrets = ['ansible']
    ansible_j_s_o_n_decoder_0.set_secrets(test_secrets)
    encrypted_string_0 = ansible_j_s_o_n_encoder_0.encode({'__ansible_vault': 'hello world'})
    ansible_j_s_o_n_decoder_0.decode(encrypted_string_0)


# Generated at 2022-06-25 03:44:00.992044
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    keys = ['a', 'b', 'c']
    args = {key: key for key in keys}
    parsed = AnsibleJSONDecoder().object_hook(args)
    assert parsed == args
    assert AnsibleJSONDecoder._vaults == {}


# Generated at 2022-06-25 03:44:11.246475
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:44:13.585444
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:44:20.801344
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('foo')

    pairs = {
        '__ansible_unsafe': "password: \"{{ lookup('env', 'ANSIBLE_VAULT_PASSWORD_FILE') }}\"",
        '__ansible_vault': "vaulted string",
    }
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)

    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(result['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-25 03:44:29.807358
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # This just tests the object hook to make sure it does something. It's
    # somewhat difficult to test the actual vault behavior because we'd need
    # to setup a vault and insert a secret.
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # AssertionError:
    # {"__ansible_vault": "asdf"} == AnsibleVaultEncryptedUnicode('asdf')
    assert ansible_j_s_o_n_decoder_0.object_hook(
        {'__ansible_vault': 'asdf'}
    ) == AnsibleVaultEncryptedUnicode('asdf')

    # AssertionError:
    # {"__ansible_vault": "asdf", "__ansible_unsafe": "jkl;"} == {

# Generated at 2022-06-25 03:44:33.109287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# To run a specific test, put a number in the unittest.skip decorator

# Generated at 2022-06-25 03:44:41.509073
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 =  {'__ansible_vault' : 'some_random_value', '__ansible_unsafe' : 'some_value'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)



# Generated at 2022-06-25 03:44:47.370379
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["the_password"])



# Generated at 2022-06-25 03:44:52.354649
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:44:58.128414
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_dict = dict({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;inexistent0000000000', 'vault': {}})
    result = ansible_j_s_o_n_decoder_0.object_hook(test_dict)
    assert type(result['__ansible_vault']) == AnsibleVaultEncryptedUnicode


# Generated at 2022-06-25 03:45:13.384101
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with default params
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder.object_hook({})


# Generated at 2022-06-25 03:45:15.217919
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()

# Generated at 2022-06-25 03:45:22.033415
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': _object_hook()}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:45:30.239132
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test with invalid value for args['pairs']
    # TypeError: Unsupported type for value: <class 'NoneType'>
    # test_AnsibleJSONDecoder_object_hook: test_case_0
    # assert None <class 'NoneType'>
    with pytest.raises(TypeError):
        ansible_j_s_o_n_decoder_0.object_hook({'a': None})

    # Test with invalid value for args['pairs']
    # TypeError: Unsupported type for value: <class 'bool'>
    # test_AnsibleJSONDecoder_object_hook: test_case_1
    # assert True <class 'bool'>

# Generated at 2022-06-25 03:45:34.515848
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    with pytest.raises(KeyError):
        ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
        ansible_j_s_o_n_decoder_1.object_hook()


# Generated at 2022-06-25 03:45:45.672851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    # Create a new AnsibleVaultEncryptedUnicode object
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('not_encrypted_data')
    # Overwrite AnsibleVaultEncryptedUnicode value to 'encrypted_data'
    ansible_vault_encrypted_unicode_1.value = 'encrypted_data'

    # Create pairs containing key-value pair, where key is '__ansible_vault' and
    # value is 'ansible_vault_encrypted_unicode_1'
    pairs = { '__ansible_vault': ansible_vault_encrypted_unicode_1 }
    # Call AnsibleJSONDecoder method object_hook with parameters pairs
   

# Generated at 2022-06-25 03:45:51.721486
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_string = '{"__ansible_vault": "vault_value"}'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('vault_value')

    assert ansible_vault_encrypted_unicode_0 == ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'vault_value'})


# Generated at 2022-06-25 03:45:56.514002
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {"__ansible_unsafe": "foo"}
    expected = wrap_var("foo")
    actual = ansible_json_decoder_0.object_hook(pairs_0)
    assert actual == expected


# Generated at 2022-06-25 03:46:03.915244
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs={'__ansible_vault': 'AQAAAAAAAAD/A5P5m+qlB/vHlxqW8/y97mj0K/a0GXR'})


# Generated at 2022-06-25 03:46:12.579117
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:46:51.670332
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs=None)

# Generated at 2022-06-25 03:47:00.023065
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test for object_hook
    """
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    yaml_ansible_vault_map_0 = {}
    # test case
    value = ansible_j_s_o_n_decoder_0.object_hook(yaml_ansible_vault_map_0)
    assert value == {}


# Generated at 2022-06-25 03:47:09.467501
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    str_1 = '{}'
    assert ansible_json_decoder_1.object_hook(json.loads(str_1)) == json.loads(str_1)


# Generated at 2022-06-25 03:47:15.848601
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {'default': VaultLib(secrets=['password'])}

# Generated at 2022-06-25 03:47:23.508242
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_1 =  AnsibleVaultEncryptedUnicode(13)
    ansible_vault_encrypted_unicode_1.vault = {'default': VaultLib(secrets=[])}
    pairs_2 = {'__ansible_vault': 13}
    ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs_2)


    assert True


# Generated at 2022-06-25 03:47:29.356935
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encrypted = '$ANSIBLE_VAULT;1.1;AES256\n353633326265323532653161353933376431623461326365306466303864333662303634656437\n' \
                '3865616633353437666536376636303465316137363937303336633033356435363336333232\n' \
                '6663363038666364366331333935663234366535376436393964386565643336306439313064\n' \
                '6466383837363435363739393533363564353334\n'
    decrypted = 'p@ssw0rd'


# Generated at 2022-06-25 03:47:37.938913
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["1"])
    res = ansible_j_s_o_n_decoder_0.object_hook({u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;encrypt\ntest\nencrypt'})
    assert res.vault.secrets == ['1']
    assert res.vault.secrets == ["1"]
    assert res.vault.secrets == ['1']