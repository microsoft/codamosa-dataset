

# Generated at 2022-06-25 03:37:41.528785
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Input for the test
    list_0 = []
    dict_0 = {
        "__ansible_unsafe": "value1",
        "__ansible_vault": "value2"
    }
    ansible_vault_encrypted_unicode_0 = {}
    # Expected output
    dict_1 = {
        "__ansible_unsafe": "value1",
        "__ansible_vault": ansible_vault_encrypted_unicode_0
    }

    # Call the tested method
    actual_result = AnsibleJSONDecoder.object_hook(dict_0)

    # Check if the result is the expected one
    assert actual_result == dict_1, "Actual and expected objects differ."



# Generated at 2022-06-25 03:37:51.046271
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    pairs_0 = {}
    key_0 = '__ansible_vault'
    value_0 = '__ansible_vault'
    pairs_0[key_0] = value_0
    key_1 = '__ansible_unsafe'
    value_1 = '__ansible_unsafe'
    pairs_0[key_1] = value_1
    return_value_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

# Generated at 2022-06-25 03:37:58.734358
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_v_e_u_0 = AnsibleVaultEncryptedUnicode(*list_0, **dict_0)
    ansible_unsafe_var_0 = wrap_var(*list_0, **dict_0)
    dict_1 = {'__ansible_vault': ansible_v_e_u_0,
              '__ansible_unsafe': ansible_unsafe_var_0}
    assert(ansible_j_s_o_n_decoder_0.object_hook(dict_1) == dict_1)

# Generated at 2022-06-25 03:38:03.304731
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Initializing arguments
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test\r\ntest\r\ntest\r\n', '__ansible_unsafe': 'test'}

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('test')
    ansible_j_s_o_n_decoder_0.object_hook(pairs)



# Generated at 2022-06-25 03:38:04.955389
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # public void object_hook(java.util.Map pairs) throws org.yaml.snakeyaml.error.YAMLException
    assert True == False


# Generated at 2022-06-25 03:38:08.553625
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    pairs_0 = {}
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook(pairs_0), dict)


# Generated at 2022-06-25 03:38:12.782971
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    try:
        list_0 = []
        dict_0 = {}
        ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
        obj = ansible_j_s_o_n_decoder_0.object_hook(*list_0)
        # obj should be a dict if value is valid
        assert isinstance(obj, dict)
    except Exception:
        # obj should be a dict if ansible_vault is used
        assert isinstance(obj, dict)


# Generated at 2022-06-25 03:38:15.892235
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # list_0 will hold the first parameter.
    list_0 = []
    list_0.append(1)
    # dict_0 will hold the second parameter.
    dict_0 = {}
    dict_0['a'] = 1
    dict_0['b'] = 2

    # ansible_j_s_o_n_decoder_0 will hold the object.
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_decoder_0.object_hook(dict_0)


# Generated at 2022-06-25 03:38:26.937751
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    str_0 = '/'
    str_1 = '!'
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    setattr(ansible_j_s_o_n_decoder_0, '_vaults', dict_0)
    dict_1 = {}
    dict_1['__ansible_vault'] = str_0
    dict_1['__ansible_unsafe'] = str_1
    dict_1['__ansible_vault'] = str_0
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(dict_1)

# Generated at 2022-06-25 03:38:35.226937
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

    parm_pairs = {u'foo': 123, u'bar': 456, u'baz': 789}
    value = ansible_j_s_o_n_decoder_0.object_hook(parm_pairs)
    # the return value should be the same as the input paramter.
    assert parm_pairs == value
    # No value in parm_pairs has key starting with '__ansible_'
    assert parm_pairs['foo'] == value['foo']
    assert parm_pairs['bar'] == value['bar']
    assert parm_pairs['baz'] == value

# Generated at 2022-06-25 03:38:40.682493
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    pairs = {}
    key = '__ansible_vault'
    value = 'test_value'
    pairs[key] = value
    ansible_j_s_o_n_decoder_0._vaults['default'] = 'test_value'
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == AnsibleVaultEncryptedUnicode(value)


# Generated at 2022-06-25 03:38:50.432435
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    str_0 = ''

    # Call method object_hook with arguments (ansible_vault_encrypted_unicode_0)
    ansible_v_a_u_l_t_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(ansible_vault_encrypted_unicode_0)

# Generated at 2022-06-25 03:38:57.866636
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    str_0 = str()
    str_1 = str()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0, str_1)
    str_2 = str()
    wrap_var_0 = wrap_var(str_2)
    str_3 = str()
    str_4 = str()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_3, str_4)
    list_1 = [ansible_vault_encrypted_unicode_1]
    dict_1 = {}
    pair_

# Generated at 2022-06-25 03:39:05.455188
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    pairs = {"__ansible_vault": AnsibleVaultEncryptedUnicode("Accept: */*")}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {"__ansible_vault": AnsibleVaultEncryptedUnicode("Accept: */*")}
    pairs = {"__ansible_vault": ansible_vault_encrypted_unicode_0}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {"__ansible_vault": ansible_vault_encrypted_unicode_0}


# Generated at 2022-06-25 03:39:18.295635
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    dict_1 = {}
    int_0 = 0
    str_0 = 'g'
    int_1 = 0
    int_2 = 0
    int_3 = 0
    str_1 = 'm'
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    int_9 = 0
    int_10 = 0
    int_11 = 0
    int_12 = 0
    int_13 = 0
    int_14 = 0
    str_2 = 'x'
    int_15 = 0

# Generated at 2022-06-25 03:39:27.944203
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # If a json key is __ansible_vault, create a new AnsibleVaultEncryptedUnicode object and store it in value
    key = '__ansible_vault'
    value = 'value'
    result = AnsibleVaultEncryptedUnicode(value)

    # If a json key is __ansible_unsafe, create a new AnsibleUnsafeText object and store it in value
    key = '__ansible_unsafe'
    value = 'value'
    result = wrap_var(value)

    # Else, return pairs
    key = 'key'
    value = 'value'
    result = (key, value)

    # Check result
    if result == (key, value):
        assert True
    else:
        assert False


# Generated at 2022-06-25 03:39:31.058571
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert False, 'Test stub'


# Generated at 2022-06-25 03:39:40.328713
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_decoder_0._vaults = dict_0
    dict_1 = dict()
    dict_1['__ansible_vault'] = ''
    dict_1['__ansible_unsafe'] = ''
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(dict_1)
    assert isinstance(ansible_vault_encrypted_unicode_0, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 03:39:49.767284
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('The quick brown fox jumps over the lazy dog')
    vault_lib_0 = VaultLib(secrets=list_0)
    ansible_vault_encrypted_unicode_0.vault = vault_lib_0
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(*list_0, **dict_0)

# Generated at 2022-06-25 03:39:59.383675
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # test case 0

    str_0 = '__ansible_vault'
    str_1 = 'hogehoge'
    dict_0 = {str_0: str_1}
    # enable debug
    ansible_j_s_o_n_decoder_0.debug = True

    # test case 1

    str_0 = '__ansible_unsafe'
    str_1 = 'hogehoge'
    dict_0 = {str_0: str_1}
    # enable debug
    ansible_j_s_o_n_decoder_0.debug = True

    # test case 2

    str_0 = 'hogehoge'

# Generated at 2022-06-25 03:40:06.183684
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

    pairs = {"__ansible_unsafe": "{{ foo }}"}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert(result == pairs)


# Generated at 2022-06-25 03:40:15.102193
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    list_1 = []
    dict_1 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(*list_1, **dict_1)
    vault_lib_0 = VaultLib('ansible-secret')
    ansible_vault_encrypted_unicode_0.vault = vault_lib_0
    pairs_0 = {'__ansible_vault': ansible_vault_encrypted_unicode_0}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

# Generated at 2022-06-25 03:40:26.280910
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # key is of type 'str'
    key = 'str'
    # value is of type 'str'
    value = 'str'
    pairs = {key: value}
    # pairs is of type 'dict'
    assert isinstance(pairs, dict)
    # data is of type 'dict'
    data = pairs
    # ansible_j_s_o_n_decoder_0 is of type 'AnsibleJSONDecoder'
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # AnsibleJSONDecoder.object_hook runs successfully
    ansible_j_s_o_n_decoder_0.object_hook(data)



# Generated at 2022-06-25 03:40:36.843968
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\n66303839663533363239653330653834393461626430356562333562393834353133633636663330\n37373464366265333861333331353431353038373835323066633537336639623538373735326665\n64336335613138396564346661303538313033626636643566376433633862626139663330366331\n3433643038346436353335363635623532366338313766\n')
    list_0 = []

# Generated at 2022-06-25 03:40:41.961558
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_decoder_0.object_hook(None)


# Generated at 2022-06-25 03:40:45.782551
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert ansible_j_s_o_n_decoder_0.object_hook(ansible_vault_encrypted_unicode_0) == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 03:40:53.282479
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    try:
        list_0 = []
        dict_0 = {}
        ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
        ansible_j_s_o_n_decoder_0.object_hook(pairs='pairs')
    except Exception as exception_0:
        print(str(exception_0))

test_AnsibleJSONDecoder_object_hook()


# Generated at 2022-06-25 03:40:56.353130
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dict_0 = dict()
    dict_0["a"] = 1
    dict_0["b"] = "string"
    dict_0["c"] = 1.234
    ansible_j_s_o_n_decoder_obj = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_obj.object_hook(dict_0) == dict_0


# Generated at 2022-06-25 03:41:04.990304
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(*list_0, **dict_0)
    # Secret-only values, part I
    ansible_j_s_o_n_decoder_0.set_secrets(['secret_0', 'secret_1'])
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_encoder_0.encode(
        dict_0, vault_password='secret_1'
    )

# Generated at 2022-06-25 03:41:08.229160
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_unsafe': 'abc'}
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder.object_hook(pairs)


# Generated at 2022-06-25 03:41:16.208434
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    pairs_0 = {}
    assert pairs_0 == ansible_j_s_o_n_decoder_0.object_hook(pairs_0)


# Generated at 2022-06-25 03:41:26.412651
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    dict_1 = {}
    dict_1['__ansible_vault'] = 'password'
    dict_1['__ansible_unsafe'] = 'password'
    assert ansible_j_s_o_n_decoder_0.object_hook(dict_1) == {'__ansible_vault': 'password', '__ansible_unsafe': 'password'}


# Generated at 2022-06-25 03:41:33.065393
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    list_0 = []
    dict_0 = {}
    set_secrets_0 = ansible_j_s_o_n_decoder_0.set_secrets(*list_0, **dict_0)
    object_hook_0 = ansible_j_s_o_n_decoder_0.object_hook(value='__ansible_vault')

# Generated at 2022-06-25 03:41:41.427395
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

# Generated at 2022-06-25 03:41:44.856761
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_1 = []
    dict_1 = {'object_hook': 'object_hook'}
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder(*list_1, **dict_1)
    pairs_1 = 'pairs'
    ansible_j_s_o_n_decoder_1.object_hook(pairs_1)


# Generated at 2022-06-25 03:41:52.661489
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    dict_0 = {}
    dict_0['__ansible_vault'] = 'some string'
    dict_0['__ansible_unsafe'] = 'some string'
    return_value_0 = ansible_j_s_o_n_decoder_0.object_hook(dict_0)
    assert return_value_0 == dict_0


# Generated at 2022-06-25 03:42:03.536674
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    for argument_0 in [{}, {"ansible_vault": "ansible_vault"}]:
        # Defining a Callable
        def callable_0(argument_1):
            return AnsibleJSONDecoder._vaults.get(argument_1)

        # Defining a Callable
        def callable_1(argument_1):
            return AnsibleVaultEncryptedUnicode(argument_1)


        # Call to set_secrets of AnsibleJSONDecoder class
        AnsibleJSONDecoder.set_secrets('secret')
        list_0 = [argument_0]
        dict_0 = {}
        ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

        # Call to object_hook of AnsibleJSONDecoder object
       

# Generated at 2022-06-25 03:42:13.847266
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)


# Generated at 2022-06-25 03:42:24.226916
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create an instance of AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Create a list of input data

# Generated at 2022-06-25 03:42:27.541829
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_object = { 'a' : 'foo', 'b' : 'bar'}
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.object_hook(json_object)

# Generated at 2022-06-25 03:42:39.127967
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'key1': 'value1', 'key2': 'value2'}
    json_decoder = AnsibleJSONDecoder()
    json_decoder.object_hook(pairs)


# Generated at 2022-06-25 03:42:48.485861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

# Generated at 2022-06-25 03:43:00.171407
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    obj_AnsibleJSONDecoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

    list_0 = []
    dict_0 = {}
    obj_AnsibleJSONEncoder_0 = AnsibleJSONEncoder(*list_0, **dict_0)

    ansible_vault_encrypted_unicode_0 = obj_AnsibleJSONEncoder_0.default(
        AnsibleVaultEncryptedUnicode())

    # ansible_vault_encrypted_unicode_0 == '{"__ansible_vault": "__VAULT__"}',
    # raises AssertionError
    try:
        pass
    except AssertionError:
        pass

    # ansible_vault_encrypted_unicode_0 != ansible

# Generated at 2022-06-25 03:43:08.886690
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

    dict_1 = dict()
    dict_2 = dict()

# Generated at 2022-06-25 03:43:11.931100
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO Write tests
    pass


# Generated at 2022-06-25 03:43:18.458266
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_0 = dict()
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_decoder_0.object_hook(json_0)


# Generated at 2022-06-25 03:43:21.816831
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test case data
    key = '__ansible_vault'
    value = '11111____1111'
    pairs = { key: value }
    expected = AnsibleVaultEncryptedUnicode(value)

    # Unit test execution
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    actual = ansible_j_s_o_n_decoder_0.object_hook(pairs)

    # Unit test assertion
    assert expected == actual


# Generated at 2022-06-25 03:43:30.190000
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = ['list_0']
    dict_0 = {'some_key': 'some_value'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

    # Dictionary of test cases
    test_cases = [
        {
            'name': 'test_key_0',
            'pairs': {'__ansible_vault': 'some_value'},
            'vault': VaultLib()
        },
        {
            'name': 'test_key_1',
            'pairs': {'__ansible_unsafe': 'some_value'},
            'vault': None
        },
    ]

    # Run tests
    for test_case in test_cases:
        test_case_name = test_case

# Generated at 2022-06-25 03:43:40.842790
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_obj_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_vault_encrypted_string_obj_0 = AnsibleVaultEncryptedUnicode("ansible_vault_encrypted_string")
    encrypted_string_0 = ansible_vault_encrypted_string_obj_0._decrypt("ansible_vault_decrypt")
    ansible_vault_encrypted_string_obj_0.vault = "vault"
    ansible_j_s_o_n_decoder_obj_0._decoder_object_hook_0("vault", {"__ansible_vault":"ansible_vault_encrypted_string"})
    ansible_j_

# Generated at 2022-06-25 03:43:48.218428
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = [ ]
    dict_0 = { }
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

    # Test cases

    # AnsibleVaultEncryptedUnicode
    # AnsibleVaultEncryptedUnicode
    # AnsibleUnsafeText
    # AnsibleUnsafeText
    # AnsibleUnsafeText
    # AnsibleUnsafeText
    # AnsibleUnsafeText

    # AnsibleVaultEncryptedUnicode
    # AnsibleVaultEncryptedUnicode
    # AnsibleUnsafeText
    # AnsibleUnsafeText
    # AnsibleUnsafeText
    # AnsibleUnsafeText
    # AnsibleUnsafeText



# Generated at 2022-06-25 03:44:09.647512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {
        'hello': 'world',
        '__ansible_vault': 'This is a secret'
    }

    result = AnsibleJSONDecoder.object_hook(pairs=pairs)



# Generated at 2022-06-25 03:44:13.929313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    key_0 = '__ansible_unsafe'
    value_0 = '__ansible_unsafe'
    value_1 = '__ansible_unsafe'
    pairs_0 = {}
    pairs_0[key_0] = value_0
    pairs_1 = {}
    pairs_1[key_0] = value_1
    assert pairs_0[key_0] == pairs_1[key_0]
    assert type(pairs_0) is type(pairs_1)

# Generated at 2022-06-25 03:44:19.563375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Input parameters
    object_hook_pairs = 'dict_0'

    # Output parameters

    # Pass input parameters to the method
    object_hook_pairs = {}
    # AnsibleJSONDecoder._vaults = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(object_hook_pairs)



# Generated at 2022-06-25 03:44:29.737083
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('wDhLJyDp0Vu9I+p5pVu5Z5S5SJ+c2VL0')
    ansible_vault_encrypted_unicode_0.vault = VaultLib()
    list_1 = []
    dict_1 = {}
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder(*list_1, **dict_1)

# Generated at 2022-06-25 03:44:35.290311
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible_json_decoder_0_0 is a AnsibleJSONDecoder
    ansible_json_decoder_0_0 = AnsibleJSONDecoder()
    # pairs_0 is a dict
    pairs_0 = {}
    # call the object_hook method of class AnsibleJSONDecoder with arguments pairs_0
    object_hook_0 = ansible_json_decoder_0_0.object_hook(pairs_0)
    assert object_hook_0 == pairs_0


# Generated at 2022-06-25 03:44:40.374456
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_decoder_0._vaults.update({
        'default': VaultLib(*list_0, **dict_0),
    })
    str_0 = '<<inherit>>'
    str_1 = '__ansible_vault'
    str_2 = '__ansible_unsafe'
    int_0 = 0

# Generated at 2022-06-25 03:44:46.364191
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)

# Generated at 2022-06-25 03:44:51.985824
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(list_0, dict_0)
    assert ansible_j_s_o_n_decoder_0.object_hook() is None


# Generated at 2022-06-25 03:44:56.412251
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    object_hook_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert object_hook_0 == {}                                                  # test


# Generated at 2022-06-25 03:44:59.039790
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder()

    obj.object_hook("fake_text")



# Generated at 2022-06-25 03:45:35.409964
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    args = {}
    args['pairs'] = "{}"
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(**args)
    result = ansible_j_s_o_n_decoder_0.object_hook(args['pairs'])
    assert result == {}



# Generated at 2022-06-25 03:45:40.805008
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    # FIXME: changeme
    dict_0 = {"__ansible_vault": "changeme"}
    ansible_j_s_o_n_decoder_0.set_secrets(["changeme", "changeme"])
    result = ansible_j_s_o_n_decoder_0.object_hook(dict_0)
    if not isinstance(result, AnsibleVaultEncryptedUnicode):
        raise Exception("ansible_j_s_o_n_decoder_0.object_hook returned an unexpected result")


# Generated at 2022-06-25 03:45:42.608165
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert callable(AnsibleJSONDecoder.object_hook)


# Generated at 2022-06-25 03:45:50.539384
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test case 0
    list_0 = [None]
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_decoder_0._vaults['default'] = None
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('"data"')

    pairs = {'__ansible_vault': '"data"'}

    # Test case 0
    ansible_j_s_o_n_decoder_0.object_hook(pairs)



# Generated at 2022-06-25 03:45:53.568902
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'a': 1, 'b': 2}
    result = AnsibleJSONDecoder.object_hook(pairs)
    assert result == pairs

# Generated at 2022-06-25 03:45:59.667354
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test vault
    vault_secret_0 = 'test_vault_secret'
    vault_pass_0 = 'test_vault_pass'
    vault_format_0 = 'test_vault_format'
    vault_raw_0 = 'test_vault_raw'

    vault_0 = AnsibleVaultEncryptedUnicode(vault_secret_0, vault_pass_0, vault_format_0, vault_raw_0)
    vault_pair_0 = {}
    vault_pair_0['__ansible_vault'] = vault_secret_0

    AnsibleJSONDecoder.set_secrets(vault_pass_0)

    # Test unsafe
    unsafe_var_0 = 'test_unsafe_var'

# Generated at 2022-06-25 03:46:03.479812
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert(callable(AnsibleJSONDecoder.object_hook))
    assert(isinstance(AnsibleJSONDecoder.object_hook(AnsibleJSONDecoder(), {}, {}), dict))

# Generated at 2022-06-25 03:46:09.529040
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_j_s_o_n_decoder_0.object_hook(dict_0)


# Generated at 2022-06-25 03:46:12.282037
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    pass


# Generated at 2022-06-25 03:46:20.371525
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    str_0 = ansible_vault_encrypted_unicode_0.translate()
    dict_1 = dict()
    dict_1['__ansible_vault'] = str_0
    ansible_vault_encrypted_unicode_1 = ansible_j_s_o_n_decoder_0.object_hook(dict_1)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_1.vault
    str_1 = ans

# Generated at 2022-06-25 03:47:37.829393
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0, **dict_0)
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs=None)
    assert ansible_vault_encrypted_unicode_0 == None
