

# Generated at 2022-06-25 03:37:41.984954
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0)
    pairs_0 = {'__ansible_vault': 'secret'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    

# Generated at 2022-06-25 03:37:51.526517
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:37:56.718901
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"test": "1"}
    dec = AnsibleJSONDecoder()
    assert dec.object_hook(obj) == obj

    dec = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets("foo")
    enc = AnsibleJSONEncoder()
    obj = {'__ansible_vault': enc.encode("bar")}
    res = dec.object_hook(obj)

# Generated at 2022-06-25 03:38:03.978479
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0)

    ansible_j_s_o_n_decoder_0.set_secrets(list_0)

    dict_0 = dict()
    dict_0['__ansible_vault'] = '123'
    ret = ansible_j_s_o_n_decoder_0.object_hook(dict_0)
    assert ret
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)

    dict_0 = dict()
    dict_0['__ansible_unsafe'] = '${unsafe_var}'
    ret = ansible_j_s_o_n_decoder_0.object_hook(dict_0)
    assert ret


# Generated at 2022-06-25 03:38:07.766553
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    dict_0 = dict()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0)
    # Returns <class 'ansible.parsing.vault.AnsibleVaultEncryptedUnicode'>
    value_0 = ansible_j_s_o_n_decoder_0.object_hook(dict_0)

# Generated at 2022-06-25 03:38:18.430800
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(*list_0)
    set_secrets(ansible_j_s_o_n_decoder_0, list_0)

# Generated at 2022-06-25 03:38:27.297880
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dict_0 = {}
    dict_0['__ansible_vault'] = str('$ANSIBLE_VAULT;1.1;AES256')
    obj_0 = AnsibleJSONDecoder.object_hook(dict_0)
    assert dict_0['__ansible_vault'] == '$ANSIBLE_VAULT;1.1;AES256'

if __name__ == '__main__':
    import os

    coverage = os.getenv('COVERAGE', False)
    if coverage:
        import coverage
        coverage.process_startup()
        COVERAGE_PROCESS_START = os.getenv('COVERAGE_PROCESS_START')
        if COVERAGE_PROCESS_START:
            coverage.process_startup()
        else:
            coverage.process_startup

# Generated at 2022-06-25 03:38:30.447792
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_obj = AnsibleJSONDecoder()
    pairs = {}
    result = test_obj.object_hook(pairs)
    assert result is not None


# Generated at 2022-06-25 03:38:35.969819
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    list_0 = []
    ansible_json_decoder_0 = AnsibleJSONDecoder(*list_0)
    ansible_json_decoder_0.set_secrets('secrets')

    # Create input for method object_hook of class AnsibleJSONDecoder
    pairs_0 = {'__ansible_vault': 'abc', '__ansible_unsafe': 'abc'}
    # Call method object_hook of class AnsibleJSONDecoder
    test_0 = ansible_json_decoder_0.object_hook(pairs_0)
    assert test_0['__ansible_vault'].vault == ansible_json_decoder_0._vaults['default']



# Generated at 2022-06-25 03:38:45.030608
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:38:48.212663
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'awesome'}) == wrap_var('awesome')

# Generated at 2022-06-25 03:38:50.309287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j = json.dumps([], cls=AnsibleJSONEncoder)
    assert AnsibleJSONDecoder.object_hook(j) == {}

# Generated at 2022-06-25 03:38:57.754536
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # We can't really test the object_hook method as it's called by the constructor
    # instead of it, we'll test decode()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    a = {'a': 1}
    encoded = ansible_j_s_o_n_encoder_0.encode(a)
    decoded = ansible_j_s_o_n_decoder_0.decode(encoded)
    assert decoded == a, "Failed to decode a dictionary"
    b = u'test'
    encoded = ansible_j_s_o_n_encoder_0.encode(b)
    decoded = ansible_j

# Generated at 2022-06-25 03:39:03.241232
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # nothing to test here


# Generated at 2022-06-25 03:39:04.669766
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:39:06.062813
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:39:12.717742
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets("raw")
    pairs = {"test": "encrypted"}
    ansible_vault_encrypted_unicode_0 = AnsibleJSONDecoder.object_hook(pairs)

# Generated at 2022-06-25 03:39:20.846608
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
  assert ansible_j_s_o_n_decoder_0.object_hook({}) == {}
  assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault' : '123321'}) == AnsibleVaultEncryptedUnicode('123321')
  assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe' : '123321'}) == '123321'

# Generated at 2022-06-25 03:39:24.686076
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_t_c_0 = AnsibleJSONDecoder()
    ansible_json_decoder_t_c_0.object_hook({'__ansible_vault': 'bndkbndddjdnkfndkfnkdmf'})

# Generated at 2022-06-25 03:39:32.724662
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()

    ansible_json_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-25 03:39:43.768240
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    with open('tests/fixtures/test_case_0.json', 'r') as json_file:
        test_verses = json_file.read()
    answer = ansible_j_s_o_n_decoder_0.decode(test_verses)
    true_answer = json.loads(test_verses)
    assert answer == true_answer
    test_verses = ansible_j_s_o_n_encoder_0.encode(answer)
    answer = ansible_j_s_o_n_decoder_0.decode(test_verses)
    assert answer == true

# Generated at 2022-06-25 03:39:51.397163
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # FIXME: use vault here instead of stubbing result

    pairs_0 = {'key': 'value'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # AnsibleVaultEncryptedUnicode
    pairs_0['__ansible_vault'] = "c2VjcmV0Cg=="
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0) == dict(key="value", __ansible_vault="c2VjcmV0Cg==")



# Generated at 2022-06-25 03:39:53.899918
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert True


# Generated at 2022-06-25 03:39:59.233135
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"__ansible_unsafe": "asdf"}
    ret = AnsibleJSONDecoder.object_hook(obj)
    assert ret == obj


# Generated at 2022-06-25 03:40:08.368363
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # AnsibleJSONDecoder.object_hook(pairs)
    # test if AnsibleJSONDecoder.parse(...) properly calls AnsibleJSONDecoder.object_hook(...)
    ansible_j_s_o_n_decoder_1.set_secrets('my_pass')

# Generated at 2022-06-25 03:40:16.753684
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Setup mocks
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    # Setup format strings
    str_1 = '{}'
    str_2 = '{ }'
    str_3 = '{ "__ansible_vault": "test_value_3" }'

    # Perform test
    assert json.loads(str_1, cls=ansible_j_s_o_n_decoder_0) == {}
    assert json.loads(str_2, cls=ansible_j_s_o_n_decoder_0) == {}

# Generated at 2022-06-25 03:40:20.359364
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-25 03:40:21.276965
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    test_case_0()

# Generated at 2022-06-25 03:40:26.407094
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    # Call method object_hook of class AnsibleJSONDecoder
    result = ansible_j_s_o_n_decoder_1.object_hook()

    # Check if method object_hook of class AnsibleJSONDecoder has been called correctly
    assert result == None


# Generated at 2022-06-25 03:40:30.367435
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # If a key is __ansible_vault
    actual_result = key == '__ansible_vault'
    assert actual_result
    # If a key is __ansible_unsafe
    actual_result = key == '__ansible_unsafe'
    assert actual_result

# Generated at 2022-06-25 03:40:35.968520
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {}

# Generated at 2022-06-25 03:40:41.643013
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {"key": "value"}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == pairs


# Generated at 2022-06-25 03:40:46.198742
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder() # instantiate class
    a_d_o_h_0 = dict() # a_d_o_h_0 is an instance of dict
    a_d_o_h_1 = ansible_j_s_o_n_decoder_0.object_hook(a_d_o_h_0)
    assert a_d_o_h_1 == dict()


# Generated at 2022-06-25 03:40:55.625918
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:00.142676
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs_1= { 'key' : 'value' }
    result_1 = ansible_j_s_o_n_decoder_1.object_hook(pairs_1)
    assert result_1 == pairs_1


# Generated at 2022-06-25 03:41:09.664548
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test Cases for method object_hook of class AnsibleJSONDecoder
    test_cases = [
        # (0, "b'__ansible_unsafe' : '123'", {"__ansible_unsafe" : 123},'dict'),
        (1, "{'__ansible_unsafe' : '123'}", {"__ansible_unsafe" : 123}, 'dict'),
        (2, "", {}, 'dict'),
    ]

    for count, test_case in enumerate(test_cases, start=1):
        yield check_object_hook, ansible_j_s_o_n_decoder_0, test_case, count



# Generated at 2022-06-25 03:41:18.317895
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:22.388815
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder._vaults['default'] = True
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = dict()
    pairs_0.setdefault('__ansible_vault', '7a63d6c69f56db8ebc264f4970a1ee77')
    pairs_0.setdefault('__ansible_unsafe', 'bWVzc2FnZQ==')
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)


# Generated at 2022-06-25 03:41:28.196087
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.decode('{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible\n39326336386638303936623533623166633837346633376566386537663638633465313262333566\n30343965656332396262373861366439333630663630316164313365623236313736623964336630\n6338646566356465343133633339353330623636643336653935393666\n"}')

# Testing for class AnsibleJSONEncoder


# Generated at 2022-06-25 03:41:32.005199
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    import copy
    pairs = copy.deepcopy(dict())
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) is not None


# Generated at 2022-06-25 03:41:39.614895
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert result


# Generated at 2022-06-25 03:41:43.442025
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    try:
        with open('jsonfile', 'r') as handle:
            ansible_json_decoder_0 = AnsibleJSONDecoder()
            ansible_json_decoder_0.set_secrets(['secret1'])
            ansible_json_decoder_0.object_hook(json.load(handle))
        assert True
    except AssertionError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 03:41:53.974566
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:58.788761
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    if not isinstance(ansible_j_s_o_n_decoder_0.object_hook({'e': 3}), dict):
        raise AssertionError()


# Generated at 2022-06-25 03:42:09.900007
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '{"a": 1, "__ansible_vault": "VjBYMTIzNDU2NzgK", "b": 2, "__ansible_unsafe": "VjBYMTIzNDU2NzgK" }'
    #Test 1: check __ansible_vault and __ansible_unsafe with data
    AnsibleJSONDecoder.set_secrets(['abcdefgh'])

# Generated at 2022-06-25 03:42:14.489761
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = { "__ansible_vault": "dummy value", "__ansible_unsafe": "dummy value"}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:42:25.415139
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # *** No value provided for parameter 'pairs'
    ansible_j_s_o_n_decoder_0.object_hook()
    # *** No value provided for parameter 'pairs'
    ansible_j_s_o_n_decoder_0.object_hook()
    # *** No value provided for parameter 'pairs'
    ansible_j_s_o_n_decoder_0.object_hook()
    # *** No value provided for parameter 'pairs'
    ansible_j_s_o_n_decoder_0.object_hook()
    # *** No value provided for parameter 'pairs'
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:42:29.918750
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets("ham")

    ansible_j_s_o_n_decoder_0._vaults = {'default': VaultLib(secrets=None)}

    # Check if the method works
    ansible_j_s_o_n_decoder_0.object_hook({"key" : "value"})



# Generated at 2022-06-25 03:42:34.125429
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_e_u_0 = AnsibleVaultEncryptedUnicode('value')
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'value'}) == ansible_v_e_u_0


# Generated at 2022-06-25 03:42:44.986936
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Arrange
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder__vaults_0 = {}
    ansible_j_s_o_n_decoder_0._vaults = ansible_j_s_o_n_decoder__vaults_0

    # Act
    ansible_j_s_o_n_decoder_0.object_hook({u'__ansible_unsafe': u"aHR0cDovL2NhY2VyLmNvbQ=="})

    # Assert
    assert (ansible_j_s_o_n_decoder_0._vaults == ansible_j_s_o_n_decoder__vaults_0)

    #

# Generated at 2022-06-25 03:42:52.135279
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:43:03.533660
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_5 = u'\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015\u0015'


# Generated at 2022-06-25 03:43:11.228445
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:43:22.762740
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_in = {'__ansible_vault': 'lalallalalalal'}
    object_hook_out = ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs_in)
    assert isinstance(object_hook_out, AnsibleVaultEncryptedUnicode)
    assert ansible_j_s_o_n_decoder_0._vaults['default'].secrets == ['default']
    assert object_hook_out == 'lalallalalalal'

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:43:33.318743
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:43:37.925333
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    try:    
        ret = ansible_j_s_o_n_decoder_0.object_hook(pairs)
        assert ret == {}
    except Exception:
        assert False


# Generated at 2022-06-25 03:43:47.319153
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_1.object_hook("") == ""
    ansible_j_s_o_n_decoder_1.set_secrets("")
    assert ansible_j_s_o_n_decoder_1.object_hook("") == ""
    ansible_j_s_o_n_decoder_1.set_secrets("")
    assert ansible_j_s_o_n_decoder_1.object_hook("") == ""
    ansible_j_s_o_n_decoder_1.set_secrets("")
    assert ansible_j_s_o_n_decoder_1.object_hook("") == ""

# Generated at 2022-06-25 03:43:51.015553
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test for set_secrets method
    ansible_j_s_o_n_decoder_0.set_secrets([])

    # Test for object_hook method
    ansible_j_s_o_n_decoder_0.object_hook({})

# Generated at 2022-06-25 03:43:59.500002
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    test_inputs = [
        '{"__ansible_vault": "vault_contents"}',
        '{"__ansible_vault": "vault_contents", "key": "value"}',
        '{"key": "value", "__ansible_vault": "vault_contents"}',
        '{"key": "value", "__ansible_vault": "vault_contents", "key2": "value2"}'
    ]

    for input in test_inputs:
        expected = json.loads(input)

        decoded = ansible_j_s_o_n_decoder_0.object_hook(json.loads(input))


# Generated at 2022-06-25 03:44:06.990783
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Initializing objects needed to perform test
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'something'}
    assert ansible_j_s_o_n_decoder_1.object_hook(pairs) == AnsibleVaultEncryptedUnicode('something')


# Generated at 2022-06-25 03:44:21.719174
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_v_a_u_l_t_lib_1 = VaultLib()
    ansible_j_s_o_n_decoder_1._vaults['default'] = ansible_v_a_u_l_t_encrypted_unicode_1.vault = ansible_v_a_u_l_t_lib_1
    pairs = {'__ansible_vault': 'bar'}
    expected_value = AnsibleVaultEncryptedUnicode(pairs['__ansible_vault'])
    expected_value.vault = ansible_v_a

# Generated at 2022-06-25 03:44:26.432366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0._vaults == {}
    ansible_j_s_o_n_decoder_0.set_secrets(u'9mEkaZRMSi7VlmAyrpAet7VzmqxniuV7')
    assert ansible_j_s_o_n_decoder_0._vaults == {"default": VaultLib(secrets=u'9mEkaZRMSi7VlmAyrpAet7VzmqxniuV7')}


# Generated at 2022-06-25 03:44:35.130260
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_s_s_h_p_a_s_s_w_o_r_d_d_e_c_1 = 'v1!v2'
    ansible_j_s_o_n_decoder_1.set_secrets(ansible_s_s_h_p_a_s_s_w_o_r_d_d_e_c_1)

# Generated at 2022-06-25 03:44:37.648390
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = dict( __ansible_vault = 'e30=' , __ansible_unsafe = 'e30=')
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert type(result) is dict


# Generated at 2022-06-25 03:44:44.761837
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create a dummy object
    dummy_object = {}
    # Add a key named '__ansible_vault' and assign a dummy data
    dummy_object['__ansible_vault'] = 'dummy_ansible_vault'
    # Create an instance of class AnsibleJSONDecoder
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets('dummy_secrets')
    # Execute the function AnsibleJSONDecoder.object_hook with parameter dummy_object.
    # The function returns a AnsibleVaultEncryptedUnicode object.
    ansible_vault_obj = ansible_json_decoder_0.object_hook(dummy_object)
    # Check the type of the object returned by the function AnsibleJSONDecoder.

# Generated at 2022-06-25 03:44:49.578469
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook() # TODO check results


# Generated at 2022-06-25 03:44:54.776103
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('ansible')

    ansible_j_s_o_n_decoder_0.object_hook({'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1'})

# Generated at 2022-06-25 03:45:05.010848
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # The object_hook method is called once for each key-value pair,
    # with the key and value as positional arguments,
    # and the dictionary as keyword argument,
    # and the return value of object_hook
    # is used as the real value instead.
    #
    # The first argument passed to the object_hook function is the members
    # of a JSON object or the value of a JSON array.
    #
    # This hook can be used to modify the value of a member while the object
    # is being constructed.
    #
    # The hook can be used to validate the value of a member or to raise
    # an exception,
    # or to make a member optional
    # (by returning None).

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Check that there is no

# Generated at 2022-06-25 03:45:16.170923
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:45:19.387512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-25 03:45:40.825144
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["abcd"])

# Generated at 2022-06-25 03:45:44.289519
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(pairs={})
    assert True == True

# Generated at 2022-06-25 03:45:51.424525
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    input_object_hook_value_0 = {
        'a': 'b',
        '__ansible_vault': 'c',
        'd': 'e'
    }
    assert ansible_j_s_o_n_decoder_0.object_hook(input_object_hook_value_0) == {
        'a': 'b',
        '__ansible_vault': 'c',
        'd': 'e'
    }


# Generated at 2022-06-25 03:45:54.046356
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:45:58.773125
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # ansible_j_s_o_n_decoder_0.set_secrets()
    # ansible_j_s_o_n_decoder_0.object_hook()

    pass


# Generated at 2022-06-25 03:46:03.710309
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()



# Generated at 2022-06-25 03:46:08.087154
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    o = AnsibleJSONDecoder.object_hook(None, None)
    assert o is None



# Generated at 2022-06-25 03:46:09.266650
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:46:09.999221
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # It isn't possible to test this normally.
    pass

# Generated at 2022-06-25 03:46:13.921638
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:46:57.315551
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

    pairs = {
        '__ansible_unsafe': '__ansible_vault',

    }

    ansible_j_s_o_n_decoder.object_hook(pairs)



# Generated at 2022-06-25 03:47:05.952669
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder.set_secrets(['123456'])
    test_json = json.dumps({'name': 'value', '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n36653433663639393431623262346331623639373161343833646532616332616434363963376136\n39393338373766306137316234623230343362363733356230623438353438666530396635396139\n61376635653639'}, cls=AnsibleJSONEncoder)

# Generated at 2022-06-25 03:47:15.376140
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    # Test if type of return value of method object_hook is dict
    assert isinstance(ansible_j_s_o_n_decoder_1.object_hook({}), dict)

    # Test if return value of method object_hook is dict
    assert isinstance({}, dict)

    # Test if return value of method object_hook is dict
    assert isinstance(ansible_j_s_o_n_decoder_1.object_hook({"__ansible_unsafe": ("my_password",)}), dict)

    # Test if return value of method object_hook is dict

# Generated at 2022-06-25 03:47:25.155552
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode()

    # Case 0
    ret = ansible_j_s_o_n_decoder.object_hook({})
    assert ret == {}

    # Case 1
    ret = ansible_j_s_o_n_decoder.object_hook({'__ansible_vault': ansible_vault_encrypted_unicode})
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)

    # Case 2
    ret = ansible_j_s_o_n_decoder.object_hook({'__ansible_unsafe': 'unsafe_value'})
    assert isinstance(ret, dict)

# Generated at 2022-06-25 03:47:33.540389
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    answer_1 = ansible_j_s_o_n_encoder_0.encode(AnsibleVaultEncryptedUnicode('ABCDEFGH'))

    # Call the method with a valid argument
    assert type(ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': answer_1})) is AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 03:47:35.592881
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder.object_hook == ansible_json_decoder.object_hook