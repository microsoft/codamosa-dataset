

# Generated at 2022-06-25 03:37:42.664086
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    dict_0 = dict()
    dict_0['__ansible_vault'] = 'test_value_1'
    dict_0['__ansible_unsafe'] = 'test_value_2'
    dict_0['test_key_3'] = 'test_value_3'
    dict_0['test_key_4'] = 'test_value_4'

    ansible_json_decoder_0.object_hook(dict_0)


# Generated at 2022-06-25 03:37:52.041570
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['secret', ])
    # Test case with '__ansible_vault' in key and string in value
    vault_string_0 = ansible_j_s_o_n_decoder_0.object_hook({
        '__ansible_vault': 'vault',
        '__ansible_unsafe': 'unsafe',
    })
    assert isinstance(vault_string_0['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert vault_string_0['__ansible_vault'].vault.secrets == ['secret', ]

# Generated at 2022-06-25 03:37:59.790864
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:38:00.521363
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:04.325453
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-25 03:38:12.245919
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    assert ansible_j_s_o_n_decoder_1.object_hook({'__ansible_unsafe': 'BUILTIN_REGEX(abc)'}) == AnsibleVaultEncryptedUnicode('BUILTIN_REGEX(abc)')


# Generated at 2022-06-25 03:38:14.873245
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs={'key': 'value'})

# Generated at 2022-06-25 03:38:22.986537
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["vault_s3cr3t"])

# Generated at 2022-06-25 03:38:25.224430
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.__init__()
    # Provided by inventory
    test_case_0()


# Generated at 2022-06-25 03:38:31.628338
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Read input from stdin
    pairs = json.load(sys.stdin)

    # Module AnsibleJSONDecoder():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:38:35.628654
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    assert(ansible_j_s_o_n_decoder_0.object_hook(pairs_0) == {})


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:38:38.980609
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    key_0 = '__ansible_vault'
    value_0 = AnsibleVaultEncryptedUnicode(value='value')
    pairs_0[key_0] = value_0


# Generated at 2022-06-25 03:38:42.100993
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    with open('ansible_json_decoder_test.json') as f:
        ansible_j_s_o_n_decoder_0.decode(f.read())



# Generated at 2022-06-25 03:38:47.444377
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = { 
        "__ansible_vault": "test",
    }
    ansible_j_s_o_n_decoder_0.set_secrets(['test'])
    results_expected = AnsibleVaultEncryptedUnicode(pairs["__ansible_vault"])
    results_actual = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert AnsibleJSONEncoder.default(None, results_expected) == AnsibleJSONEncoder.default(None, results_actual)



# Generated at 2022-06-25 03:38:50.404924
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    value = decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': {'x': 'y'}})
    assert value == dict(__ansible_vault='foo', __ansible_unsafe=wrap_var({'x': 'y'}))



# Generated at 2022-06-25 03:39:01.151694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_enc_u_n_i_c_o_d_e_0 = AnsibleVaultEncryptedUnicode('sample')
    ansible_j_s_o_n_decoder_0._vaults = {}
    ansible_j_s_o_n_decoder_0._vaults['default'] = 'sample'
    ansible_v_a_u_l_t_enc_u_n_i_c_o_d_e_0.vault = 'sample'


# Generated at 2022-06-25 03:39:07.679009
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Init key-value pair
    pairs = {}
    # Init key
    key = ""
    # Init value
    value = ""
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    # If statement
    if key == '__ansible_vault':
        # Compare whether the value equals to value
        assert value == value
        # If statement
        if ansible_j_s_o_n_decoder._vaults:
            # Compare whether the value equals to value
            assert value == value
        # Return value
        return value
    # IF statement
    if key == '__ansible_unsafe':
        # Return value
        return wrap_var(value)
    # Return value
    return pairs


# Generated at 2022-06-25 03:39:15.850275
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    t_a_j_d_o_h_0 = AnsibleJSONDecoder()
    t_a_j_d_o_h_p_0 = {'__ansible_vault': 'test___ansible_vault'}
    t_a_j_d_o_h_r_0 = t_a_j_d_o_h_0.object_hook(t_a_j_d_o_h_p_0)
    assert t_a_j_d_o_h_r_0.__class__ == AnsibleVaultEncryptedUnicode


# Generated at 2022-06-25 03:39:18.205272
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.object_hook(str())


# Generated at 2022-06-25 03:39:26.549399
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'vault'})
    ansible_j_s_o_n_decoder_0.set_secrets(secrets=['secret'])
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'vault'})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'unsafe'})

# Generated at 2022-06-25 03:39:38.508237
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test various combinations of possible inputs
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(['vault_password'])

    # Simple case where no values are encrypted or unsafe
    test1_pairs = {'name': 'Ansible', 'version': '2.9.1'}
    test1_expected = {'name': 'Ansible', 'version': '2.9.1'}
    test1_actual = ansible_json_decoder_0.object_hook(test1_pairs)
    assert test1_expected == test1_actual

    # Simple case where values are encrypted

# Generated at 2022-06-25 03:39:43.484889
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({'ansible':'True'})

# Generated at 2022-06-25 03:39:47.687287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()

# Method set_secrets of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:39:56.224157
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test case_0
    ansible_j_s_o_n_decoder_0.set_secrets(['default_password'])
    assert ansible_j_s_o_n_decoder_0.decode('{"__ansible_vault": "vault_input"}') == {u'__ansible_vault': u'vault_input'}

# Generated at 2022-06-25 03:40:06.210121
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    import json
    secret = 'test'
    ansible_j_s_o_n_decoder_0.set_secrets([secret])

# Generated at 2022-06-25 03:40:15.098964
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0.set_secrets('VaultPassword')

# Generated at 2022-06-25 03:40:19.560987
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({'key1': 'value1', 'key2': 'value2'})

# Generated at 2022-06-25 03:40:27.392169
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_1.set_secrets('foooo')
    ansible_j_s_o_n_decoder_0.object_hook(
        {'__ansible_vault': 'bar', '__ansible_unsafe': 'baz'}
    )



# Generated at 2022-06-25 03:40:30.193903
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_dumps_1 = dict()


# Generated at 2022-06-25 03:40:38.514525
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    data = AnsibleJSONEncoder(sort_keys=True, indent=4, ensure_ascii=False, cls=AnsibleJSONEncoder).encode({'__ansible_unsafe': 'value'})
    expected = '{{ hello }}'
    result = ansible_j_s_o_n_decoder_0.decode(data)
    assert result == expected, 'Expected: {0}, got: {1}'.format(expected, result)

# Generated at 2022-06-25 03:40:44.794436
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": "test"}) == {"__ansible_vault": "test"}

# Generated at 2022-06-25 03:40:52.088117
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert type(ansible_j_s_o_n_decoder_0.object_hook(pairs={'__ansible_vault': '<secret>'})) is AnsibleVaultEncryptedUnicode


# Generated at 2022-06-25 03:41:01.433571
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Unit test for method object_hook of class AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_0 = '''
    {"foo": "bar", "baz": null}
    '''
    pairs_0 = json.loads(json_0)
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)


# Generated at 2022-06-25 03:41:09.959390
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('ansible-secret')
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.set_secrets('ansible-secret', True)
    test_value = {'__ansible_vault': ansible_j_s_o_n_encoder_0.encode(['value'])}
    ansible_j_s_o_n_decoder_0.object_hook(test_value)


# Generated at 2022-06-25 03:41:14.580584
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_1.object_hook({"__ansible_unsafe": "something", "__ansible_vault": "something"})


# Generated at 2022-06-25 03:41:24.266912
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_decoder_0.object_hook
    ansible_j_s_o_n_decoder_0.object_hook(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 03:41:28.305817
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # No input so should return empty dict
    assert ansible_j_s_o_n_decoder_0.object_hook({}) == {}
    # No input so should return empty dict
    assert ansible_j_s_o_n_decoder_0.object_hook(None) == {}

# Generated at 2022-06-25 03:41:30.550777
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder(object_hook=object_hook)


# Generated at 2022-06-25 03:41:34.477384
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = json.loads('{"test": "test"}')
    # Test for existence of keys
    assert 'test' in obj
    # Test for equality
    assert "test" == obj['test']


# Generated at 2022-06-25 03:41:44.058439
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2.set_secrets(["foo"])
    pairs = {'__ansible_vault': 'foo'}
    ansible_j_s_o_n_decoder_2.object_hook(pairs)


# Generated at 2022-06-25 03:41:54.673659
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    try:
        value = "test_value"
        pairs = {'test': test_value}
        ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
        ansible_j_s_o_n_decoder_1.object_hook(pairs)
    except Exception as e:
        assert False, "Raised exception: " + str(e)


# Generated at 2022-06-25 03:42:04.079228
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    A_v_e_0 = AnsibleVaultEncryptedUnicode('foo')

    # Test with non-AnsibleVaultEncryptedUnicode object
    wrapped = ansible_j_s_o_n_decoder_0.object_hook(A_v_e_0)
    assert wrapped is A_v_e_0

    # Test with AnsibleVaultEncryptedUnicode object
    wrapped = ansible_j_s_o_n_decoder_0.object_hook({
        '__ansible_vault': 'foo',
    })
    assert isinstance(wrapped, AnsibleVaultEncryptedUnicode)
    assert wrapped.data == 'foo'

    # Test with AnsibleV

# Generated at 2022-06-25 03:42:10.477073
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    pairs['__ansible_vault'] = 'AnsibleVaultEncryptedUnicode'
    pairs['__ansible_unsafe'] = 'wrap_var'
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:42:21.406589
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('/etc/ansible/secrets.yml')
    assert ansible_j_s_o_n_decoder_0._vaults['default'].secrets == '/etc/ansible/secrets.yml'
    data = '{"__ansible_vault": "vaultencodedstring", "__ansible_unsafe": "{\"required\": true, \"type\": \"boolean\"}" }'
    json_decoded = json.loads(data, cls=ansible_j_s_o_n_decoder_0)
    assert json_decoded['__ansible_vault'] == 'vaultencodedstring'
   

# Generated at 2022-06-25 03:42:34.710788
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = object
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_vault_2 = AnsibleVaultEncryptedUnicode('some_vault')
    ansible_j_s_o_n_decoder_1.set_secrets('some_secrets')
    pairs_3 = {}
    pairs_3['__ansible_vault'] = 'some_vault'
    ansible_vault_4 =  pairs_3['__ansible_vault']

    try:
        assert ansible_vault_2 == ansible_vault_4
    except AssertionError:
        print("assertion error:")
        print(ansible_vault_2)

# Generated at 2022-06-25 03:42:37.651430
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    assert ansible_json_decoder_0


# Generated at 2022-06-25 03:42:40.182329
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:42:49.282289
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:42:54.321743
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(object_hook="object_hook")
    assert ansible_j_s_o_n_decoder_0 is not None


# Generated at 2022-06-25 03:43:03.821481
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": "ansible"}) == AnsibleVaultEncryptedUnicode("ansible")

# Generated at 2022-06-25 03:43:23.258687
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:43:33.776577
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder.set_secrets(['s3cr3t'])

# Generated at 2022-06-25 03:43:42.159866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Multiple asserts to assure test fails at first failure
    assert ansible_j_s_o_n_decoder_0.object_hook(ansible_j_s_o_n_encoder_0.default(wrap_var(
        b'\x00\x00\x00\x01\x03\x00\x00\x00\x00'))) == wrap_var(b'\x00\x00\x00\x01\x03\x00\x00\x00\x00')

# Generated at 2022-06-25 03:43:47.789701
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets("")
    # This test case has no input
    # Expecting: 'AnsibleVaultEncryptedUnicode', return_value
    return_value = {}
    # No output

    # Call the Ansible module ...
    ansible_j_s_o_n_decoder_0.object_hook(return_value)


# Generated at 2022-06-25 03:43:54.711441
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:43:57.323912
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO: Create test case
    ansible_j_s_o_n_decoder_decoder_1 = AnsibleJSONDecoder(encoding='utf-8', object_hook=None)
    assert callable(ansible_j_s_o_n_decoder_decoder_1.object_hook) is True


# Generated at 2022-06-25 03:44:07.486324
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # data = {'__ansible_vault': 'test', '__ansible_unsafe': 'test'}
    # ansible_j_s_o_n_decoder_0.object_hook(data)
    with pytest.raises(Exception) as excinfo:
        ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'})
    assert excinfo.value.args[0] == 'The secret string must be provided to decrypt the data.'


# Generated at 2022-06-25 03:44:18.389312
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    AnsibleJSONDecoder.set_secrets('secret')

    pairs = []
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == []

    pairs = {}
    assert ansible_j_s_o_n_decoder_1.object_hook(pairs) == {}


# Generated at 2022-06-25 03:44:23.977712
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    a_v_e_u_0 = AnsibleVaultEncryptedUnicode(u'AQDcG6wYW6AEKrMd+J9Qhq3vsqbW8kes+6xzSp1s+0Dw')
    u_v_s_0 = {'__ansible_vault': a_v_e_u_0}

# Generated at 2022-06-25 03:44:34.958489
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_object_hook = AnsibleJSONDecoder()

    ansible_json_decoder_object_hook.set_secrets("secret")
    # AnsibleJSONDecoder.set_secrets("secret")


# Generated at 2022-06-25 03:44:54.634322
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder()
    s = {'__ansible_vault': 'test_value'}
    assert obj.object_hook(s) == {'__ansible_vault': AnsibleVaultEncryptedUnicode('test_value')}


# Generated at 2022-06-25 03:45:02.428855
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(['foo'])
    ansible_json_decoder_0.decode('{"__ansible_vault": "AQMDAwMDAwMDAwMDCxuQ7Vnf+gZUznVf3qLq3g=="}')


# Generated at 2022-06-25 03:45:08.046099
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_set_secrets_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_set_secrets_0.set_secrets("]^vYmwI(@ID6A8%$#")



# Generated at 2022-06-25 03:45:10.786051
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder.object_hook('AnsibleVaultEncryptedUnicode') is not None


# Generated at 2022-06-25 03:45:18.100984
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")

    assert ansible_j_s_o_n_decoder_0.object_hook({
        '__ansible_vault': ansible_vault_encrypted_unicode_0})["__ansible_vault"] == (
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")


# Generated at 2022-06-25 03:45:30.433436
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    secret = "string"
    ansible_j_s_o_n_decoder_1.set_secrets(secret)
    vault = ansible_j_s_o_n_decoder_1._vaults['default']
    text = "test"
    encrypted_text = vault.encrypt(text)
    pairs = {'__ansible_vault': encrypted_text}
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_1.object_hook(pairs)
    assert ansible_vault_encrypted_unicode_0.vault == vault
    assert ansible_vault_encrypted_unicode_0.text == encrypted_text


#

# Generated at 2022-06-25 03:45:37.867412
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_u_n_i_c_o_d_e = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'string'})


# Generated at 2022-06-25 03:45:41.822769
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs = {'key': 'value'})

# Generated at 2022-06-25 03:45:50.325082
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["5a0d69d5-5e0f-46cb-8a02-d2ed15beaee1", ])
    pairs = {}

    # Testing with pairs
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert result

    # Testing with pairs.
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert result


# Generated at 2022-06-25 03:45:59.828263
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # AnsibleJSONDecoder.object_hook() test case 1
    if True:
        ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo', 'bar': 'baz'}) == \
            {'__ansible_vault': 'foo', 'bar': 'baz'}

    # AnsibleJSONDecoder.object_hook() test case 2

# Generated at 2022-06-25 03:46:38.226289
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)



# Generated at 2022-06-25 03:46:45.084416
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert type(ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test_value'})) == dict


# Generated at 2022-06-25 03:46:54.033017
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    vault_data = {}
    vault_encoded = ansible_j_s_o_n_encoder_0.encode({'__ansible_vault':vault_data}).strip()
    try:
        vault_decoded = ansible_j_s_o_n_decoder_0.decode(vault_encoded)
        assert vault_encoded == ansible_j_s_o_n_encoder_0.encode(vault_decoded).strip()
    except Exception:
        raise Exception('Exception')


# Generated at 2022-06-25 03:47:00.328121
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # below test will fail as '__ansible_vault' is not in pairs,
    # and assert statement is also failed
    ansible_json_decoder = AnsibleJSONDecoder()
    pairs = {}
    res = ansible_json_decoder.object_hook(pairs)
    assert(res == pairs)

# Generated at 2022-06-25 03:47:05.352282
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook({}), dict)


# Generated at 2022-06-25 03:47:15.338120
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(['12345'])


# Generated at 2022-06-25 03:47:21.127539
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:47:22.969195
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook() == None


# Generated at 2022-06-25 03:47:28.776920
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets([ ])
    ansible_j_s_o_n_decoder_0.object_hook('{"__ansible_unsafe":"asdf"}')


# Generated at 2022-06-25 03:47:35.078471
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets=None)
    object_0 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test\n6336313031656535506631656631333366346637636661633834353931633963643934343331630a323536656631316361333465356536343966346662373332613638373639303466303165650a303866643338353830356238653832356634363338356561'}
    result_0 = ansible_j_s_o_n_decoder_