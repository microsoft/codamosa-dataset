

# Generated at 2022-06-25 03:37:43.657861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:37:52.126894
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(['test_secret'])

# Generated at 2022-06-25 03:37:59.819174
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pair = {"__ansible_vault": '$ANSIBLE_VAULT;1.1;AES256\r\n66666....\r\n'}
    deco = ansible_j_s_o_n_decoder_0.object_hook(pair)
    assert isinstance(deco, AnsibleVaultEncryptedUnicode)
    assert deco.startswith('$ANSIBLE_VAULT;1.1;AES256\r\n66666....\r\n')

# Generated at 2022-06-25 03:38:09.261099
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_json_decoder_object_hook_pairs = {"__ansible_vault": "$ANSIBLE_VAULT;1.2;AES256;ansible", "__ansible_unsafe": "ansible"}
    if True: # Just to avoid 'Reformat' error of PyCharm
        ansible_json_decoder_object_hook_pairs = {"__ansible_vault": "$ANSIBLE_VAULT;1.2;AES256;ansible", "__ansible_unsafe": "ansible"}
    ansible_json_decoder_object_hook_0.object_hook(ansible_json_decoder_object_hook_pairs)

# Generated at 2022-06-25 03:38:12.277178
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({'test': 'test'})


test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:38:13.737715
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()



# Generated at 2022-06-25 03:38:20.318316
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    with pytest.raises(NotImplementedError) as excinfo:
        ansible_j_s_o_n_decoder_0.object_hook()
    assert 'subclasses of AnsibleJSONDecoder must override object_hook()' in str(excinfo.value)

# Unit tests for class AnsibleJSONEncoder


# Generated at 2022-06-25 03:38:22.632367
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs=None)


# Generated at 2022-06-25 03:38:29.001305
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:35.559907
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0
    if isinstance(ansible_j_s_o_n_decoder_0, object):
        ansible_j_s_o_n_decoder_0.object_hook()

# Generated at 2022-06-25 03:38:38.510294
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Case 0
    test_case_0()



# Generated at 2022-06-25 03:38:45.559559
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # exp_pairs_0 is a dict
    exp_pairs_0 = dict()
    exp_pairs_0['__ansible_vault'] = 'test string'
    exp_pairs_0['__ansible_unsafe'] = 'test string'

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # call AnsibleJSONDecoder.object_hook()
    ansible_j_s_o_n_decoder_0.object_hook(exp_pairs_0)

    # exp_pairs_1 is a dict
    exp_pairs_1 = dict()
    exp_pairs_1['__ansible_vault'] = 'test string'

    # call AnsibleJSONDecoder

# Generated at 2022-06-25 03:38:51.997273
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    result = ansible_j_s_o_n_decoder_0.object_hook(pairs={'foo': 'bar'})
    assert result == {'foo': 'bar'}


# Generated at 2022-06-25 03:39:05.307921
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import wrap_var

    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_j_s_o_n_encoder_1.encode('encrypted value'))
    ansible_vault_encrypted_unicode_2.vault = VaultLib()

    dict_3 = {'__ansible_vault': ansible_vault_encrypted_unicode_2}

    ansible_json_decoder_4 = AnsibleJSONDecoder()

    assert(ansible_json_decoder_4.object_hook(dict_3)['__ansible_vault'] == ansible_vault_encrypted_unicode_2)



# Generated at 2022-06-25 03:39:12.255777
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {"__ansible_vault": "test"}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:39:14.283513
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_decoder_1.object_hook



# Generated at 2022-06-25 03:39:17.567627
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Assertions
    # object_hook(dict dict)
    pass

# Generated at 2022-06-25 03:39:22.562866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    vault_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES;aes128;PAYLOAD'}
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES;aes128;PAYLOAD'}

    ansible_j_s_o_n_decoder_0.set_secrets('PASSWORD')
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook(pairs)['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 03:39:28.493215
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs = {}
    # Exercise
    value = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    # Verify
    assert value == {}


# Generated at 2022-06-25 03:39:35.300706
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from json import decoder

    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0._vaults = {}
    ansible_json_decoder_0._vaults['default'] = VaultLib()

    ansible_json_decoder_0.object_hook({'__ansible_vault': 'test_password'})


# Generated at 2022-06-25 03:39:49.002162
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs_0 = dict()
    pairs_0['key'] = 'value'
    pairs_0['__ansible_vault'] = 'value'
    pairs_0['__ansible_unsafe'] = 'value'

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    expected_result_0 = dict()
    expected_result_0['key'] = 'value'
    expected_result_0['__ansible_vault'] = 'value'
    expected_result_0['__ansible_unsafe'] = 'value'
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-25 03:39:54.253933
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs={})


# Generated at 2022-06-25 03:39:58.858279
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_dict_0 = {'__ansible_vault': '__ansible_vault'}
    result_obj_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_dict_0)
    assert isinstance(result_obj_0, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-25 03:40:00.906180
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:40:05.978066
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create a valid JSON object
    pairs = {}
    pairs["__ansible_vault"] = "abcdefghij0123456789"
    pairs["__ansible_unsafe"] = "abcdefghij0123456789"
    # Test if the method returns the correct object
    assert AnsibleJSONDecoder.object_hook(AnsibleJSONDecoder(), pairs) == pairs


# Generated at 2022-06-25 03:40:12.491125
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()

    pairs = {}
    key = '__ansible_vault'
    value = 'asd'
    pairs[key] = value

    ansible_j_s_o_n_decoder_object_hook_0 = ansible_json_decoder_0.object_hook(pairs)

    assert ansible_j_s_o_n_decoder_object_hook_0 == {'__ansible_vault': 'asd'}


# Generated at 2022-06-25 03:40:21.474323
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj_pairs_0 = {}
    obj_pairs_0['__ansible_vault'] = None
    obj_pairs_0['__ansible_unsafe'] = None
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook(obj_pairs_0), dict)


# Generated at 2022-06-25 03:40:28.618849
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(['foo'])
    result = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'bar'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == ansible_j_s_o_n_decoder_1._vaults['default']

# Generated at 2022-06-25 03:40:39.881391
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:40:50.934225
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_d_e_c_o_d_e_r__o_b_j_e_c_t_h_o_o_k_0_secrets = ['vault_password']
    AnsibleJSONDecoder.str = ansible_j_s_o_n_d_e_c_o_d_e_r__o_b_j_e_c_t_h_o_o_k_0_secrets

# Generated at 2022-06-25 03:41:01.403982
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:41:04.195671
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()

    ansible_json_decoder_0.object_hook(pairs=dict())



# Generated at 2022-06-25 03:41:07.343979
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(pairs)


# Generated at 2022-06-25 03:41:12.464959
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0_object_hook_obj = AnsibleJSONDecoder()
    ansible_json_decoder_0_object_hook_got = ansible_json_decoder_0_object_hook_obj.object_hook()
    ansible_json_decoder_0_object_hook_exp = None
    assert ansible_json_decoder_0_object_hook_got == ansible_json_decoder_0_object_hook_exp


# Generated at 2022-06-25 03:41:19.512724
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_3.set_secrets(["secret"])

# Generated at 2022-06-25 03:41:30.732689
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # this is not quite right as the decoder is not initialized with
    # a vault, which is required in order to decrypt the value

# Generated at 2022-06-25 03:41:37.259508
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Case 0
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Case 1
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Case 2
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    # Case 3
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:41:48.138395
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_e_d_u_n_i_c_o_d_e_0 = AnsibleVaultEncryptedUnicode('YXNpYmVsOiBhc2liZWw=')
    ansible_j_s_o_n_decoder_0.object_hook({})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault':'YXNpYmVsOiBhc2liZWw='})

# Generated at 2022-06-25 03:41:57.051372
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_obj = AnsibleJSONDecoder()
    input_arg_0 = {'arg0': 'value0', 'arg1': 'value1'}
    output_ret_0 = ansible_j_s_o_n_decoder_obj.object_hook(input_arg_0)
    assert 'arg0' in output_ret_0
    assert 'arg1' in output_ret_0
    assert output_ret_0['arg0'] == 'value0'
    assert output_ret_0['arg1'] == 'value1'


# Generated at 2022-06-25 03:42:06.043637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_0.vault
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_0.vault
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_0.vault

# Generated at 2022-06-25 03:42:16.760630
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(__ansible_vault='ansible_vault')
    ansible_j_s_o_n_decoder_0._vaults['default'] = ansible_vault_encrypted_unicode_0
    pairs = {'__ansible_vault':'ansible_vault'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 03:42:26.455944
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Assert AnsibleJSONDecoder.object_hook() return true or false
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    # Return value: ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_1 = ansible_json_decoder_1.object_hook({"__ansible_vault": "$ANSIBLE_VAULT;1.2;AES256;CredTestVaultEncryption\nxxxxx"})
    print(ansible_vault_encrypted_unicode_1)
    print(type(ansible_vault_encrypted_unicode_1))
    ansible_vault_encrypted_unicode_1.vault.decrypt()
    print(ansible_vault_encrypted_unicode_1.vault.decrypt())

# Generated at 2022-06-25 03:42:35.200496
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

    import crypt
    import os
    import platform
    import pwd
    import random
    import re
    import string
    import sys

    import ansible.module_utils.json_utils

    try:
        import bcrypt

        HAS_B_C_RYPT = True
    except ImportError:
        HAS_B_C_RYPT = False

    from ansible.module_utils.six import text_type


    class VaultLibCrypt(object):

        version = 1

        def __init__(self, password=None, salt=None, new=0, identify_only=False):
            self.identify_only = identify_only

            if self.identify_only:
                return

            if not password:
                password = os

# Generated at 2022-06-25 03:42:39.604829
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # noinspection PyUnusedLocal
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:42:48.854877
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(['password'])
    keys = ['__ansible_vault', '__ansible_unsafe']

    string = '{"__ansible_vault": "vault_id:42:$ANSIBLE_VAULT;1.1;AES256\n63353935646135373233636238636537333638643662386163383361386139613261386138313\n5663616130366539656634363530353337376232653538343864\n", "__ansible_unsafe": "unsafe_value"}'
    result = ansible_j_s_o

# Generated at 2022-06-25 03:42:53.648448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Call object_hook()
    object_hook_0 = ansible_j_s_o_n_decoder_0.object_hook()
    assert object_hook_0 is None

    # Call object_hook()

# Generated at 2022-06-25 03:43:01.711931
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_object = None
    j_s_o_n_decoder_0_object = dict()
    j_s_o_n_decoder_0_object['j_s_o_n_decoder_0_key'] = 'j_s_o_n_decoder_0_val'
    j_s_o_n_decoder_0_object['__ansible_unsafe'] = '__ansible_unsafe'
    j_s_o_n_decoder_0_object[u'__ansible_vault'] = u'MY_VAULT'

# Generated at 2022-06-25 03:43:09.531283
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_proxy_0 = wrap_var(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_1 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': ansible_unsafe_proxy_0})

# Generated at 2022-06-25 03:43:14.128167
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_case_0()


# Generated at 2022-06-25 03:43:22.539379
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0_pairs_0 = {}
    ansible_j_s_o_n_decoder_0_pairs_0['__ansible_vault'] = [
        {'key': 'value0'},
        {'key': 'value1'}
    ]
    ansible_j_s_o_n_decoder_0_pairs_0['__ansible_unsafe'] = [
        {'key': 'value0'},
        {'key': 'value1'}
    ]
    ansible_j_s_o_n_decoder_0_pairs_1 = {}

# Generated at 2022-06-25 03:43:28.124589
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {"__ansible_unsafe":"value"}
    instance = AnsibleJSONDecoder()
    assert isinstance(instance.object_hook(pairs), dict)


# Generated at 2022-06-25 03:43:34.598217
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "VzExNzY2MjQ2MTM2MTE3NjY0MzEyMw==", "__ansible_unsafe": true}'
    expected = {'__ansible_vault': 'VzExNzY2MjQ2MTM2MTE3NjY0MzEyMw==', '__ansible_unsafe': True}
    actual = json.loads(s, object_hook=AnsibleJSONDecoder.object_hook)

    assert expected == actual

# Generated at 2022-06-25 03:43:40.609472
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_1.object_hook('pairs') == 'pairs'
    assert ansible_j_s_o_n_decoder_1.object_hook('key') == 'key'
    assert ansible_j_s_o_n_decoder_1.object_hook('value') == 'value'
    assert ansible_j_s_o_n_decoder_1.object_hook('pairs') == 'pairs'


# Generated at 2022-06-25 03:43:45.175411
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Call AnsibleJSONDecoder.object_hook()
    result = ansible_j_s_o_n_decoder_0.object_hook('foo', {'__ansible_vault':'bar', '__ansible_unsafe':'baz'})
    assert result



# Generated at 2022-06-25 03:43:51.112527
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    obj = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test'}
    value = ansible_j_s_o_n_decoder_0.object_hook(obj)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-25 03:43:53.211800
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(["__ansible_vault"])
    ansible_j_s_o_n_decoder_0.object_hook(["__ansible_unsafe"])


# Generated at 2022-06-25 03:43:58.761493
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs = {}
    pairs['__ansible_vault'] = "clear_text"
    pairs['__ansible_unsafe'] = wrap_var( 'clear_text' )

    result = ansible_j_s_o_n_decoder_0.object_hook( pairs )


# Generated at 2022-06-25 03:44:02.770859
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(['secret0'])
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'v0'})
    ansible_vault_encrypted_unicode_1 = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'v1'}).as_plaintext()
    # try catch block around vault_decode
    #assert ansible_vault_encrypted_unicode_1 == 'v1'
    #assert ansible_vault_encrypted_unicode

# Generated at 2022-06-25 03:44:13.902996
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    class_json_0 = dict()
    class_json_0.keys = lambda: [u'__ansible_vault']

# Generated at 2022-06-25 03:44:17.917348
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook({'key': "value"})
    assert ansible_vault_encrypted_unicode_0 == {'key': "value"}

# Generated at 2022-06-25 03:44:35.231766
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:44:39.361698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0._vaults = {}
    ansible_json_decoder_0._vaults['default'] = VaultLib(secrets=[])
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;9.9;'}
    assert ansible_json_decoder_0.object_hook(pairs) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;9.9;')
    assert ansible_json_decoder_0._vaults['default'].secrets == []


# Generated at 2022-06-25 03:44:42.447059
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with args
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    test_var_1 = {}
    result = ansible_j_s_o_n_decoder_1.object_hook(test_var_1)
    assert result == {}



# Generated at 2022-06-25 03:44:50.158302
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_dict_0 = {"__ansible_unsafe": "Test string"}
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(test_dict_0)


# Generated at 2022-06-25 03:44:54.030335
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    #set_secrets(secrets)
    #secret_data
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:45:04.937955
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    assert not hasattr(ansible_j_s_o_n_decoder_0, '_vaults')
    ansible_j_s_o_n_decoder_0.object_hook(dict(__ansible_unsafe=b'\x00\x01\x02'))
    assert not hasattr(ansible_j_s_o_n_decoder_0, '_vaults')

# Generated at 2022-06-25 03:45:15.942256
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = {'vault_password': 'secret_password'}

# Generated at 2022-06-25 03:45:23.074016
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:45:26.263228
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook() is None


# Generated at 2022-06-25 03:45:31.997822
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    Test AnsibleJSONDecoder object_hook
    '''
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(["123"])

# Generated at 2022-06-25 03:45:54.851762
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    str_0 = 'a'
    str_1 = 'c'
    str_4 = 'd'
    str_5 = 'b'
    str_6 = 'f'
    str_7 = 'e'
    str_8 = 'b'
    str_2 = '{'
    str_3 = '}'
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets([(str_0, str_1)])
    str_9 = 'g'
    str_10 = 'h'
    str_11 = 'a'
    str_12 =  '{__ansible_vault: ' + str_2 + str_9 + str_10 + str_3 + str

# Generated at 2022-06-25 03:46:00.464238
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # For each test case of the method object_hook of class AnsibleJSONDecoder
#    def test_case_0(self):
    pass
#    def test_case_1(self):
    pass
#    def test_case_2(self):
    pass
#    def test_case_3(self):
    pass
#    def test_case_4(self):
    pass
#    def test_case_5(self):
    pass
#    def test_case_6(self):
    pass
#    def test_case_7(self):
    pass
#    def test_case_8(self):
    pass
#    def test_case_9(self):
    pass


# Generated at 2022-06-25 03:46:03.001654
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook({}) == {}


# Generated at 2022-06-25 03:46:12.525509
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:46:16.726520
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    test for method object_hook of class AnsibleJSONDecoder
    """
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert not ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:46:18.961504
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:46:23.896575
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    assert(ansible_j_s_o_n_decoder.object_hook()) != None


# Generated at 2022-06-25 03:46:30.681583
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # initializing the dict
    dict_0 = {}
    # initializing the variable
    str_1 = 'foo'
    # initializing the variable
    str_2 = 'foo'
    # initializing the variable
    str_3 = 'foo'
    dict_0[str_1] = str_2
    ansible_j_s_o_n_decoder_0.set_secrets(str_3)
    # invoking object_hook method
    result = ansible_j_s_o_n_decoder_0.object_hook(dict_0)
    assert result == dict_0



# Generated at 2022-06-25 03:46:37.228300
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Instantiate object
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Populate values

# Generated at 2022-06-25 03:46:40.161275
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_obj = AnsibleJSONDecoder()
    value = ansible_j_s_o_n_decoder_obj.object_hook()


# Generated at 2022-06-25 03:47:17.604449
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # object_hook(pairs)
    data = dict(__ansible_unsafe=dict(value=3))
    # object_hook wraps the dict in a proxy object
    pairs = json.loads(json.dumps(data), object_hook=ansible_j_s_o_n_decoder_0.object_hook)
    assert pairs == dict(__ansible_unsafe=dict(value=3))
    assert pairs['__ansible_unsafe']['value'] == 3
    # Test with multiple values (one wrapped, one not)
    data = dict(__ansible_unsafe=dict(value=3), __ansible_vault=dict(value=4))
    # object_hook wraps the dict in a

# Generated at 2022-06-25 03:47:25.280322
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:47:31.743109
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    payload_2 = '''{"a": null, "b": null}'''
    ansible_j_s_o_n_decoder_1.decode(payload_2)


# Generated at 2022-06-25 03:47:38.042519
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    class Vault(object):

        def __init__(self, password):
            self.password = password

        def load(self, data):
            return b'vault_load(' + self.password.encode('utf-8') + b')'.join([data.encode('utf-8')])

        def dump(self, data):
            return b'vault_dump(' + self.password.encode('utf-8') + b')'.join([data.encode('utf-8')])

        def load_bytes(self, data):
            return b'vault_load_bytes(' + self.password.encode('utf-8') + b')'.join([data])

        def dump_bytes(self, data):
            return