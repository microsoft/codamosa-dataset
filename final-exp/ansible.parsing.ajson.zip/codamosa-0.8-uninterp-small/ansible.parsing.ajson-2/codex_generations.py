

# Generated at 2022-06-25 03:37:41.119426
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook("")


# Generated at 2022-06-25 03:37:45.886887
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs_0_0 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}

    ansible_j_s_o_n_decoder_0.object_hook(pairs_0_0)


# Generated at 2022-06-25 03:37:53.777304
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook("") == "", "Failed to handle value = None"
    assert ansible_j_s_o_n_decoder_0.object_hook("") == "", "Failed to handle value = ''"
    # assert ansible_j_s_o_n_decoder_0.object_hook("") == "", "Failed to handle value = 'abc'"
    # assert ansible_j_s_o_n_decoder_0.object_hook("") == "", "Failed to handle value = [1, 2, 3, 4, 5]"
    # assert ansible_j_s_o_n_decoder_0.

# Generated at 2022-06-25 03:38:02.092673
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with a simple value
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Test with another simple value
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    # Test with a complex value
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    # Test with another complex value
    ansible_j_s_o_n_decoder_4 = AnsibleJSONDecoder()
    # Test with a simple value
    ansible_j_s_o_n_decoder_5 = AnsibleJSONDecoder()
    # Test with a complex value
    ansible_j_s_o_n_decoder_6 = AnsibleJSONDecoder()
    # Test with a simple value

# Generated at 2022-06-25 03:38:12.721347
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    _ansible_vault = "test"
    _ansible_unsafe = "test"
    _ansible_vault_0 = "test"
    _ansible_unsafe_0 = "test"
    attributes = dict()
    attributes['__ansible_vault'] = _ansible_vault
    attributes['__ansible_unsafe'] = _ansible_unsafe
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(attributes=attributes)
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('test')

# Generated at 2022-06-25 03:38:15.234931
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:19.423710
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = ansible_j_s_o_n_decoder_0.object_hook(pairs={'keyword1': 'value1'})
    assert ansible_json_decoder_1 == {'keyword1': 'value1'}


# Generated at 2022-06-25 03:38:27.338764
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1._vaults = {'default': "VaultLib(secrets=[])"}

# Generated at 2022-06-25 03:38:35.258419
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0.set_secrets('default')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('foo')
    bytes_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo'})
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('foo')
    bytes_1 = ansible_vault_encrypted_unicode_1.encode()

# Generated at 2022-06-25 03:38:44.967711
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    vault_lib_0 = VaultLib()
    vault_lib_0.set_secrets('test_value_1')
    ansible_j_s_o_n_decoder_0.set_secrets(vault_lib_0)
    ansible_vault_encrypted_unicode_0.vault = vault_lib_0
    assert ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": ansible_vault_encrypted_unicode_0}) == ansible_vault_encrypted_unicode_0



# Generated at 2022-06-25 03:38:48.376706
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    o = AnsibleJSONDecoder()
    o.object_hook({})


# Generated at 2022-06-25 03:38:56.558829
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Hacky way of setting the tests
    ansible_j_s_o_n_decoder_0.set_secrets('m4KV7WmDYa1e7x1Kj2S0oCZ')

    # Testing method object_hook
    assert hasattr(ansible_j_s_o_n_decoder_0.object_hook, '__call__')

    # Call the method object_hook

# Generated at 2022-06-25 03:39:08.672887
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    # Test using sample private key
    ansible_json_decoder_0.set_secrets(['ansible', 'ansible'])

# Generated at 2022-06-25 03:39:18.717874
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # encrypt string for testing
    #
    # mock the Vault class so that it returns the vault, and we can decrypt it
    ansible_vault_2 = VaultLib(password='secret')

# Generated at 2022-06-25 03:39:28.565289
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib()

# Generated at 2022-06-25 03:39:38.507412
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder() # Unused Variable
    ansible_j_s_o_n_decoder_pairs = { '__ansible_vault': 'gAAAAABbN_CdS1hDtSW74nEWPuV7RWX4bDT-gs7W4UTxl2B0zDdwjKGy8T1Bh26rmfI9XKsfaZp8Wkx0GvjKF47YwYz8U6JiUOgq3KDGqqZQ' }
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_vault_0)
    ansible_vault_encrypted_unicode_0.vault

# Generated at 2022-06-25 03:39:48.070049
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # 1st parameter: AnsibleJSONDecoder.object_hook
    # 2nd parameter:
    # 3rd parameter:
    # assert object_hook(self, data)
    ansible_j_s_o_n_decoder_1.object_hook({"__ansible_vault": "__ansible_vault", "__ansible_unsafe": "__ansible_unsafe"})
    AnsibleJSONDecoder.set_secrets("")
    # assert object_hook(self, data)

# Generated at 2022-06-25 03:39:48.697490
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True == True


# Generated at 2022-06-25 03:39:59.115526
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'a': 'b'}
    pairs['__ansible_vault'] = 'QQ=='
    pairs['__ansible_unsafe'] = 'QQ=='
    ansible_j_s_o_n_decoder_0.set_secrets('ASD')
    result_a = ansible_j_s_o_n_decoder_0.object_hook(pairs)

    assert result_a['__ansible_vault'].vault == ansible_j_s_o_n_decoder_0._vaults['default']
    assert result_a['__ansible_unsafe'] == 'QQ=='

# Generated at 2022-06-25 03:40:02.824054
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test case 0
    ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": "foo"})



# Generated at 2022-06-25 03:40:10.450777
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Instance for class AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:40:12.768756
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()



# Generated at 2022-06-25 03:40:20.826586
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    arguments = {
        'key': '__ansible_vault',
        'value' : '***value***'
    }
    assert ansible_j_s_o_n_decoder_0.object_hook(arguments) == '***value***'

# Generated at 2022-06-25 03:40:31.117281
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('VaultString')
    ansible_j_s_o_n_encoder_0._current_indent_level = 6
    # When the key '__ansible_vault' is in pairs, return AnsibleVaultEncryptedUnicode
    assert type(ansible_j_s_o_n_encoder_0.pairs(None)) == dict

# Generated at 2022-06-25 03:40:42.086920
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    secret = 'ansible'
    AnsibleJSONDecoder.set_secrets(secret)

# Generated at 2022-06-25 03:40:45.503468
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets([b'12345'])
    pairs = {'__ansible_unsafe': 'a password'}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert result == pairs

# Generated at 2022-06-25 03:40:55.606297
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['password'])
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_0.vault = ansible_j_s_o_n_decoder_0._vaults['default']
    ansible_j_s_o_n_encoder_0.encode(ansible_vault_encrypted_unicode_0)

# Generated at 2022-06-25 03:41:03.278803
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:08.265245
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault0 = 'secrets'
    x0 = {'vault': vault0}
    x1 = {'vault': vault0}
    x2 = {'vault': vault0}

    # Test a call to object_hook without vaults (should return the empty string)
    ansible_j_s_o_n_decoder_0_0 = AnsibleJSONDecoder()
    result0 = ansible_j_s_o_n_decoder_0_0.object_hook(x0)
    assert result0 == x0
    result1 = ansible_j_s_o_n_decoder_0_0.object_hook(x1)
    assert result1 == x1
    result2 = ansible_j_s_o_n_decoder_0_0.object_hook(x2)

# Generated at 2022-06-25 03:41:16.185368
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('test_string')
    string_0 = '{"__ansible_vault": "test_string"}'
    result = ansible_j_s_o_n_decoder_0.object_hook(json.loads(string_0))
    assert result == {'__ansible_vault': AnsibleVaultEncryptedUnicode('test_string')}


# Generated at 2022-06-25 03:41:19.018614
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True


# Generated at 2022-06-25 03:41:27.489298
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    b_0 = '{"__ansible_unsafe": "{{ssn}}"}'
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(b_0)


# Generated at 2022-06-25 03:41:32.360442
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_unsafe': 'abc', '__ansible_vault': 'abc'}
    # not safe to return the original dictionary
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) is not pairs

# Generated at 2022-06-25 03:41:37.752785
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test with AnsibleVaultEncryptedUnicode
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.object_hook({'__ansible_vault': 'test'})

    # Test with AnsibleUnsafeText
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.object_hook({'__ansible_unsafe': 'test'})

# Generated at 2022-06-25 03:41:43.225279
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {"__ansible_vault": "test_value_1"}

    # Expected
    expected_0 = {"__ansible_vault": "test_value_1"}

    # Actual
    actual_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

    # Assert
    assert actual_0 == expected_0


# Generated at 2022-06-25 03:41:48.122580
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs={})



# Generated at 2022-06-25 03:41:56.316436
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs=dict(__ansible_vault=None))
    ansible_u_n_s_a_f_e_proxy_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs=dict(__ansible_unsafe=None))


# Generated at 2022-06-25 03:42:05.597221
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:42:15.783830
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    pairs_0 = {
        '__ansible_unsafe': "{{ 'ansible' }}",
        '__ansible_vault': ansible_json_encoder_0.encode(AnsibleVaultEncryptedUnicode('test')),
    }
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

# Generated at 2022-06-25 03:42:26.372723
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['PASSWORD'])

    # Case 0
    kwargs = {
        'object_hook': ansible_j_s_o_n_decoder_0.object_hook,
    }
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder(**kwargs)
    # Case 1
    kwargs = {
        'object_hook': ansible_j_s_o_n_decoder_0.object_hook,
    }
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder(**kwargs)
    # Case 2
   

# Generated at 2022-06-25 03:42:33.900005
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n', '__ansible_unsafe': 'foo'}

    # Test execution:
    assert AnsibleJSONDecoder.object_hook(pairs) == {'__ansible_vault': 'bar', '__ansible_unsafe': 'foo'}


# Generated at 2022-06-25 03:42:40.327246
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    pairs = {"__ansible_vault": ansible_json_encoder_0.encode("Vault string")}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)

# Generated at 2022-06-25 03:42:49.377539
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test whether we can use the method object_hook of class AnsibleJSONDecoder
    # without initializing it
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:42:52.821943
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    print('Testing method object_hook of AnsibleJSONDecoder')
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    v_0 = ansible_j_s_o_n_decoder_1.object_hook(u'__ansible_unsafe')
    assert v_0 == u'__ansible_unsafe'



# Generated at 2022-06-25 03:43:01.167672
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Initializing object with value
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_decoder_0._vaults['default'] = ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_decoder_0._vaults['default'] = ansible_vault_encrypted_unicode_2
    ansible_j_s_o_n_decoder_0.set_secrets(None)

# Generated at 2022-06-25 03:43:08.516872
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_0_0 = AnsibleVaultEncryptedUnicode(' __ansible_unsafe:\'abcdef\'  ')
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': ansible_json_encoder_0, '__ansible_unsafe': ansible_vault_encrypted_unicode_0_0})


# Generated at 2022-06-25 03:43:17.296954
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook = AnsibleJSONDecoder()
    object_hook = ansible_j_s_o_n_decoder_object_hook.object_hook()
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder()
    object_hook_0 = ansible_j_s_o_n_decoder_object_hook_0.object_hook(object_hook)


# Generated at 2022-06-25 03:43:20.877437
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook('') == ''


# Generated at 2022-06-25 03:43:22.445651
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder().object_hook()


# Generated at 2022-06-25 03:43:25.520125
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    # Assert.
    try:
        assert ansible_json_decoder_0.object_hook()
    except AssertionError:
        assert False


# Generated at 2022-06-25 03:43:35.631366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs=dict())


# Generated at 2022-06-25 03:43:42.607336
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:43:45.503801
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook('pairs')

# Generated at 2022-06-25 03:43:53.544193
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256', '__ansible_unsafe': 'hello'}
    value = '$ANSIBLE_VAULT;1.1;AES256'
    assert value == pairs['__ansible_vault']
    assert 'hello' == pairs['__ansible_unsafe']
    # this is the class that gets returned for __ansible_vault
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs)['__ansible_vault']
    assert '$ANSIBLE_VAULT;1.1;AES256' == ansible

# Generated at 2022-06-25 03:43:57.132917
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder_1.object_hook({}), dict)



# Generated at 2022-06-25 03:44:08.289020
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    res_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs_0)
    assert res_0 == {}
    pairs_1 = {'test': 'int', 'test2': 'test'}
    res_1 = ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs_1)
    assert res_1 == {'test': 'int', 'test2': 'test'}
    pairs_2 = {'__ansible_vault': 'test'}

# Generated at 2022-06-25 03:44:12.012514
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO: why does it fail?
    #ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe':'TEST'})

# Generated at 2022-06-25 03:44:21.057598
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_encryted_unicode_0 = "dummy Ansible encryted unicode"
    ansible_unsafe_0 = "dummy Ansible unsafe"
    pairs_0 = {'__ansible_vault': ansible_encryted_unicode_0, '__ansible_unsafe': ansible_unsafe_0}

    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0) is not None
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0)['__ansible_unsafe'] is not None
    assert ansible_j_s_o_n_decoder_0.object_

# Generated at 2022-06-25 03:44:24.807298
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoded_json = '{"__ansible_vault" : "BwAAAAABeQF0AAAABXNlcmlhbGl6YXRpb24tYWxsb3dlZAAAAAACG" }'
    result = AnsibleJSONDecoder.object_hook(encoded_json)
    assert result == {'__ansible_vault': 'BwAAAAABeQF0AAAABXNlcmlhbGl6YXRpb24tYWxsb3dlZAAAAAACG'}

# Generated at 2022-06-25 03:44:31.737677
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {}
    a_map = {}
    a_map['__ansible_vault'] = 'a_string'
    result = ansible_j_s_o_n_decoder_0.object_hook(a_map)
    assert result['__ansible_vault'] is not None


# Generated at 2022-06-25 03:44:50.409503
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(['first_secret', 'second_secret'])

# Generated at 2022-06-25 03:44:57.797620
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {'default': 'test_default'}
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    test_obj = {
        '__ansible_vault': 'value',
    }
    obj = decoder.object_hook(test_obj)
    assert obj['__ansible_vault'].vault.secrets == secrets
    assert obj['__ansible_vault'].vault.secrets['default'] == secrets['default']
    assert obj['__ansible_vault'].vault.secrets['default'] == 'test_default'

# Generated at 2022-06-25 03:45:00.862005
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "my_vault_secret", "__ansible_unsafe": "my_unsafe_stuff"}'

    data = AnsibleJSONDecoder().decode(s)
    assert data['__ansible_vault'].vault.secrets == ['my_vault_secret']
    assert not isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert data['__ansible_unsafe'] == 'my_unsafe_stuff'
    assert not isinstance(data['__ansible_unsafe'], wrap_var)



# Generated at 2022-06-25 03:45:11.922980
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1._vaults['default'] = VaultLib(secrets='test_value_2')
    ansible_j_s_o_n_decoder_1._vaults['default'].secrets = 'test_value_3'
    ansible_j_s_o_n_decoder_1._vaults['default'].password = 'test_value_4'
    ansible_j_s_o_n_decoder_1._vaults['default'].keys = 'test_value_5'
    ansible_j_s_o_n_decoder_1._vaults['default']._fernet = 'test_value_6'
    ansible

# Generated at 2022-06-25 03:45:17.746382
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {"key": "value"}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == pairs


# Generated at 2022-06-25 03:45:29.227355
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:45:33.890707
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansiblejjsondo_0 = AnsibleJSONDecoder()
    assert True == ansiblejjsondo_0.object_hook(True)


# Generated at 2022-06-25 03:45:38.378329
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder.object_hook(ansible_json_decoder_0, {"__ansible_vault": "foo"})
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder.object_hook(ansible_json_decoder_0, {"__ansible_unsafe": "bar"})


# Generated at 2022-06-25 03:45:43.180233
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook({}), dict), 'Expected the return type of method object_hook to be dict'


# Generated at 2022-06-25 03:45:50.727614
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    assert ansible_j_s_o_n_decoder_0.object_hook(pairs='vault') == ansible_j_s_o_n_decoder_0._vaults['default']


# Generated at 2022-06-25 03:46:11.216742
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO: Test fails. Ensure contents of pairs are correct
    # ansible_j_s_o_n_decoder_0.object_hook(pairs={"__ansible_vault": "test_value_1"})


# Generated at 2022-06-25 03:46:16.149249
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'a': 'b'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {'a': 'b'}


# Generated at 2022-06-25 03:46:22.542794
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    a_j_d_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:46:29.771133
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    # Inputs
    key = '__ansible_vault'
    value = ansible_vault_encrypted_unicode_0
    # Output
    output = ansible_vault_encrypted_unicode_0
    assert output == ansible_j_s_o_n_decoder_0.object_hook({key: value})


# Generated at 2022-06-25 03:46:33.924375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    pairs['value'] = ['mixed', {'value': [1, 'a']}]

    # Test with no exception
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == pairs


# Generated at 2022-06-25 03:46:43.133384
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Init AnsibleJSONDecoder object
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    class AnsibleVaultEncryptedUnicode(object):
        pass

    # AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    # Init dict object
    dict_0 = {
        '__ansible_vault': ansible_vault_encrypted_unicode_0
    }

    # Call AnsibleJSONDecoder method object_hook with args
    ansible_j_s_o_n_decoder_object_hook_ret_0 = ansible_j_s_o_n_decoder_1.object_hook(dict_0)

    assert ansible_j_s_

# Generated at 2022-06-25 03:46:54.062460
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('ansible_vault_encrypted_unicode_1')
    vault_lib_1 = VaultLib()
    ansible_v_a_u_l_t_encrypted_unicode_1.vault = vault_lib_1
    res = AnsibleJSONEncoder().encode({'__ansible_vault': ansible_v_a_u_l_t_encrypted_unicode_1})
    json_data = json.loads(res)

# Generated at 2022-06-25 03:47:03.827428
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    #case 0 - empty object
    data = {}
    result = ansible_j_s_o_n_decoder_0.object_hook(data)
    assert result == {}


    #case 1 - object with no ansible variables
    data = {'key': 'value'}
    result = ansible_j_s_o_n_decoder_0.object_hook(data)
    assert result == data


    #case 2 - object with one __ansible_unsafe variable
    data = {'__ansible_unsafe': 'value'}
    result = ansible_j_s_o_n_dec

# Generated at 2022-06-25 03:47:06.164364
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:47:11.606858
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(__ansible_vault='')
    assert True
