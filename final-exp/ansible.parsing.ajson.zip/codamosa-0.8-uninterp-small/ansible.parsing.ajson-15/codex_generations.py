

# Generated at 2022-06-25 03:37:36.005772
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook('')


# Generated at 2022-06-25 03:37:39.432043
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder()
    obj._vaults = {'default': VaultLib(secrets='')}
    pairs = {'__ansible_vault': 'test'}
    expected = AnsibleVaultEncryptedUnicode('test')
    assert obj.object_hook(pairs) == expected


# Generated at 2022-06-25 03:37:40.293288
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    assert True



# Generated at 2022-06-25 03:37:49.378155
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:37:53.098291
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True

# Generated at 2022-06-25 03:37:55.377444
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible_j_s_o_n_decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    pass



# Generated at 2022-06-25 03:37:59.300848
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {
            "__ansible_vault": "12345678901234567890123456789012",
            "__ansible_unsafe": "12345678901234567890123456789012",
            "__ansible_unsafe_variable": "12345678901234567890123456789012",
            "__ansible_vault_identity": "12345678901234567890123456789012",
        }
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(obj)

# Generated at 2022-06-25 03:38:07.623588
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test case 0 is a simple test with no vault objects in the JSON.
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_0_data = b'{"myvar": "ansible"}'
    test_0_exp = {
        'myvar': 'ansible'
    }
    assert ansible_j_s_o_n_decoder_0.decode(test_0_data) == test_0_exp


# Generated at 2022-06-25 03:38:11.001366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  s = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256"}'
  try:
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(s)
  except:
    pass


# Generated at 2022-06-25 03:38:20.172803
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('1111')
    pairs_dict_0 = {}
    pairs_0 = pairs_dict_0


# Generated at 2022-06-25 03:38:27.717965
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    var_0 = AnsibleJSONDecoder()
    var_1 = {u'col1': u'foo', u'col2': u'bar'}
    var_2 = {u'__ansible_vault': u'this_is_my_fake_vault_password_dog'}
    var_3 = {u'col1': u'foo', u'col2': u'bar', u'__ansible_unsafe': {u'__unsafe_proxy__': u'[]'}}
    var_4 = var_0.object_hook(var_1)
    var_5 = var_0.object_hook(var_2)
    var_6 = var_0.object_hook(var_3)
    assert var_0._vaults['default'] == None
    assert var_4 == var_1


# Generated at 2022-06-25 03:38:33.297785
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0_o_b_j_e_c_t_h_o_o_k_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_o_b_j_e_c_t_h_o_o_k_0.set_secrets(['password'])
    ansible_j_s_o_n_decoder_0_o_b_j_e_c_t_h_o_o_k_0.object_hook(1)


# Generated at 2022-06-25 03:38:39.049676
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(secrets_0)
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.set_secrets(secrets_1)
    result = ansible_j_s_o_n_decoder_1.object_hook({'a': {'__ansible_vault': ansible_json_encoder_0.encode('b')}})

# Generated at 2022-06-25 03:38:46.056649
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # (test case 0)
    # file: test/integration/targets/test_case_0.json
    # line: 10


# Generated at 2022-06-25 03:38:51.708319
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs = {'__ansible_vault': "vault_string" }
    ansible_j_s_o_n_decoder_0.object_hook(pairs)

# Generated at 2022-06-25 03:38:56.592101
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook() == undefined


# Generated at 2022-06-25 03:38:59.160758
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 03:39:05.733518
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:39:16.494166
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded_0 = json.loads('{ "__ansible_unsafe" : "yo" }', cls=AnsibleJSONDecoder)
    #assert(decoded_0 == AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'yo'}) == {'__ansible_unsafe': 'yo'})
    #assert(decoded_0 == AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'yo'}) == {'__ansible_unsafe': 'yo'})
    #assert(decoded_0 == AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'yo'}) == {'__ansible_unsafe': 'yo'})
    #assert(decoded_0 == AnsibleJSONDecoder.object_hook({'__ansible_uns

# Generated at 2022-06-25 03:39:22.690048
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n63353039353862643166653561316563633463633135616262366431333765333734306433383436\n61316439343666363365613561343137303331303433323166333736303739393436353362666265\n64313633633163663637303534336663653730616535336235323538383538646136313335333566\n6265366531393036363836623531643033636439343134353461\n', '__ansible_unsafe': '12345'}

# Generated at 2022-06-25 03:39:31.608588
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    dict_3 = dict()
    dict_3['char'] = [1, 2, 3]
    dict_3['ansible_vault'] = ansible_vault_encrypted_unicode_2
    dict_3['safe'] = 'safe'
    dict_3['unsafe'] = 'unsafe'
    str_4 = ansible_j_s_o_n_encoder_1.encode(dict_3)
    dict_5 = ansible_j_s_o_n_decoder_0.dec

# Generated at 2022-06-25 03:39:35.037828
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook(None) is None



# Generated at 2022-06-25 03:39:36.894906
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
# End unit test for method object_hook of class AnsibleJSONDecoder


# Generated at 2022-06-25 03:39:49.282615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_4 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_lib_0 = VaultLib()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('Vault text!')
    ansible_vault_encrypted_unic

# Generated at 2022-06-25 03:39:59.143147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['a'])
    text_0 = """ansible-vault encrypt_string 'foo' --vault-id 'default'"""
    encrypted_text_0 = ansible_j_s_o_n_decoder_0._vaults['default'].encrypt(text_0)
    decrypted_text_0 = ansible_j_s_o_n_decoder_0._vaults['default'].decrypt(encrypted_text_0)
    assert json.loads(encrypted_text_0, cls=AnsibleJSONDecoder) == decrypted_text_0



# Generated at 2022-06-25 03:40:05.471371
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # return value is AnsibleVaultEncryptedUnicode. We are
    # just checking fot it's existence.
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;some_value'})
    assert ansible_vault_encrypted_unicode_0 is not None

# Generated at 2022-06-25 03:40:11.120465
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs = {}
    ret_value = ansible_j_s_o_n_decoder_1.object_hook(pairs)


# Generated at 2022-06-25 03:40:14.867071
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_decoder = AnsibleJSONDecoder()
    ansible_decoder_test_pairs = {'a': {'b': 'c', 'd': 'e'}}
    ansible_result = ansible_decoder.object_hook(ansible_decoder_test_pairs)
    assert type(ansible_result) is dict

# Generated at 2022-06-25 03:40:27.179891
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test object_hook method from AnsibleJSONDecoder class
    """
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    assert not ansible_json_decoder_1._vaults
    test_string = 'test'
    assert ansible_json_decoder_1.object_hook(test_string) == test_string

    ansible_json_decoder_1.set_secrets(secrets=['test_secret'])
    assert ansible_json_decoder_1._vaults.get('default')
    try:
        ansible_json_decoder_1.object_hook(dict(__ansible_vault=test_string))
    except:
        assert False

    ansible_json_decoder_1.set_secrets(secrets=[])

# Generated at 2022-06-25 03:40:38.557079
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    secret = 'foo'
    value = 'AQAAdGVzdCFzZWNyZXQ=\n'
    vault_realm = 'default'
    vault_section = {}

# Generated at 2022-06-25 03:40:40.946829
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-25 03:40:50.983607
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert(ansible_j_s_o_n_decoder_1.object_hook({'ansible_facts': {'discovered_interpreter_python': '/usr/bin/python'}}) == {'ansible_facts': {'discovered_interpreter_python': '/usr/bin/python'}})

# Generated at 2022-06-25 03:41:01.343084
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONEncoder().encode(dict(__ansible_unsafe='$foo'))
    obj = json.loads(obj, cls=AnsibleJSONDecoder)
    assert obj['__ansible_unsafe'] == wrap_var('$foo')
    assert not isinstance(obj['__ansible_unsafe'], dict)

    obj = AnsibleJSONEncoder().encode(dict(__ansible_vault=dict(foo='bar')))
    obj = json.loads(obj, cls=AnsibleJSONDecoder)
    assert isinstance(obj['__ansible_vault'], dict)
    assert obj['__ansible_vault']['foo'] == 'bar'

# Generated at 2022-06-25 03:41:05.039937
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    data = 'testing'
    with pytest.raises(TypeError):
        ansible_j_s_o_n_decoder_0.object_hook(data)

# Generated at 2022-06-25 03:41:06.949814
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_obj = AnsibleJSONDecoder()
    assert test_obj.object_hook


# Generated at 2022-06-25 03:41:08.955046
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({}) is None

# Generated at 2022-06-25 03:41:12.466226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:41:19.513555
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'&*((&@!?@!$#', b'12345678901234567890']
    AnsibleJSONDecoder.set_secrets(secrets)
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:41:28.205384
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs={"__ansible_vault":"secret","__ansible_unsafe":"secret"}
    ansible_j_s_o_n_decoder_0_object = ansible_j_s_o_n_decoder_0.object_hook(pairs)




# Generated at 2022-06-25 03:41:31.682336
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {
    }
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert {} == result

# Generated at 2022-06-25 03:41:41.741599
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Used to test object_hook method
    ansible_vault_encrypted_unicode_0 = 'AnsibleVaultEncryptedUnicode'
    # Used to test object_hook method
    ansible_vault_encrypted_unicode_1 = '{__ansible_vault: AnsibleVaultEncryptedUnicode}'

# Generated at 2022-06-25 03:41:46.806311
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "Zm9vYmFy"}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == AnsibleVaultEncryptedUnicode("Zm9vYmFy")


# Generated at 2022-06-25 03:41:52.113702
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    s = '{"__ansible_unsafe": "{{ foo }}"}'
    obj = json.loads(s, ansible_j_s_o_n_decoder_0)
    assert len(obj) == 1
    assert '__ansible_unsafe' in obj

# Generated at 2022-06-25 03:41:58.077168
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": "4"}) == AnsibleVaultEncryptedUnicode(wrapped_var="4")

# Generated at 2022-06-25 03:42:01.004142
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-25 03:42:09.802814
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_str = """{"__ansible_vault":"x\nx"}"""
    ansible_j_s_o_n_decoder_0.set_secrets(['password'])
    result = ansible_j_s_o_n_decoder_0.decode(json_str)
    assert result['__ansible_vault'].vault is not None
    assert result['__ansible_vault'].vault.secrets == ['password']

# Generated at 2022-06-25 03:42:17.775070
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j_s_o_n_dict_0 = {u'a': u'foobar', u'b': 10}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert ansible_j_s_o_n_decoder_0.object_hook(j_s_o_n_dict_0) == {u'a': u'foobar', u'b': 10}


# Generated at 2022-06-25 03:42:27.298412
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:42:34.023076
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test with a vault secret
    ansible_j_s_o_n_decoder_0.set_secrets(secrets='test/ansible_vault')
    ass_val_0 = json.loads(
        '{"__ansible_vault": "test"}', cls=AnsibleJSONDecoder
    )
    if ass_val_0 == "test":
        raise AssertionError("Decoder did not decrypt vault encrypted text")


# Generated at 2022-06-25 03:42:35.890315
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    assert True

# Generated at 2022-06-25 03:42:47.436144
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_json_decoder_0 = AnsibleJSONDecoder()
    assert ansible_json_decoder_0 != None
    ansible_json_decoder_0.set_secrets(secrets='a')
    ansible_json_decoder_0.object_hook(pairs='b')


# Generated at 2022-06-25 03:42:51.389724
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    pairs = {}
    ansible_j_s_o_n_decoder_1.object_hook(pairs)
    ansible_j_s_o_n_decoder_2.object_hook(pairs)


# Generated at 2022-06-25 03:42:58.942896
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    :case: 0
    :description:
    """
    ansible_json_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_json_decoder_object_hook_0.object_hook({})


# Generated at 2022-06-25 03:43:04.471440
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    #assert type(ansible_j_s_o_n_decoder_0) == dict
    print("Unit test working fine")


# Generated at 2022-06-25 03:43:12.141658
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Unit test for method object_hook of class AnsibleJSONDecoder
    # Test for passing in a dictionary of k/v pairs, and getting back the same dictionary
    param0 = dict()
    param1 = dict()

# Generated at 2022-06-25 03:43:14.210762
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_case_0()

# Generated at 2022-06-25 03:43:23.259993
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.set_secrets(["foobar"])

# Generated at 2022-06-25 03:43:24.659665
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj_0 = AnsibleJSONDecoder()
    assert obj_0 is not None


# Generated at 2022-06-25 03:43:31.903258
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('AnsibleVaultEncryptedUnicode')
    AnsibleJSONDecoder.set_secrets('==')
    pairs_0 = {'__ansible_vault': 'AnsibleVaultEncryptedUnicode'}



# Generated at 2022-06-25 03:43:41.152738
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets('77bcd62f08cf7fcb86c80b656d238e217e1d9667e53e5fdba0a18aa48d03feba')

# Generated at 2022-06-25 03:43:58.251197
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'abc'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:44:03.073260
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:44:08.422014
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:44:11.110183
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO: Implement the test for AnsibleJSONDecoder.object_hook()
    assert False


# Generated at 2022-06-25 03:44:18.583670
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # NOTE: The following aobjec_hooks_0 is an auto-generated list
    #       of parameters for the AnsibleJSONDecoder.object_hook() method,
    #       generated by the test_case_0() function above
    aobjec_hooks_0 = []
    for aobjec_hook in aobjec_hooks_0:
        ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

        result = ansible_j_s_o_n_decoder_0.object_hook(aobjec_hook)
        # NOTE: Add verification of the result here



# Generated at 2022-06-25 03:44:29.111893
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder
    ansible_json_decoder_0._vaults['default'] = VaultLib(secrets=['test_secret'])

# Generated at 2022-06-25 03:44:31.998204
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    test_pairs_0 = {}
    assert ansible_json_decoder_0.object_hook(test_pairs_0) == test_pairs_0


# Generated at 2022-06-25 03:44:44.059134
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'AQC+V7AIt4sdkvj4h4RAxswosb7X9qjBeY6pWU6c+ef6ISFzBxyjKph8Rgx+G9lHX9FvN5W5V8upuwN75hV7kMr4xxW4LG0/0'})
    ansible_j_s_o_n_decoder_1.object_hook({'__ansible_unsafe': 'some_str'})
    assert True

# Generated at 2022-06-25 03:44:54.221847
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_0.vault = VaultLib()
    ansible_vault_encrypted_unicode_1 = ansible_j_s_o_n_decoder_1.object_hook({"__ansible_vault": 'foo'})
    assert ansible_vault_encrypted_unicode_1.vault == VaultLib()
    assert ansible_vault_encrypted_unicode_1.vdata == 'foo'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_

# Generated at 2022-06-25 03:45:04.987776
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # 
    # This is the simplest test case which adds the object_hook method to the
    # class. 
    # 

    # set_secrets is a class method.

# Generated at 2022-06-25 03:45:39.977912
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jso = {
        "__ansible_vault": "$ANSIBLE_VAULT;1.2;AES256;ansible\n6534356434343233313939353062613831623534366434363935343633323639346266633038372d3d\n0a",
        "age": "10"
    }

    result = AnsibleJSONDecoder.object_hook(jso)

    assert result[0] == AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.2;AES256;ansible\n6534356434343233313939353062613831623534366434363935343633323639346266633038372d3d\n0a")
    assert result[1] == "10"

#

# Generated at 2022-06-25 03:45:45.568565
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Fixture setup
    ansible_json_decoder = AnsibleJSONDecoder()
    # Exercise
    # Verify
    assert ansible_json_decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert ansible_json_decoder.object_hook({'bar': 'baz'}) == {'bar': 'baz'}

# Generated at 2022-06-25 03:45:50.132969
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_3.object_hook({"ansible": 1}) == {"ansible": 1}

# Generated at 2022-06-25 03:45:54.432154
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = dict()
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert result == pairs_0


# Generated at 2022-06-25 03:45:58.596192
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0) is None


# Generated at 2022-06-25 03:46:04.185341
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault':'ansible_vault_ed_u_n_i_c_o_d_e'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:46:08.669271
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Need to add also a test of a vaulted string



# Generated at 2022-06-25 03:46:12.241626
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    str_0 = 'bar'
    str_0 = AnsibleVaultEncryptedUnicode(str_0)
    dict_0 = {'foo': str_0}
    int_0 = AnsibleJSONDecoder.object_hook(ansible_j_s_o_n_decoder_0, dict_0)
    assert u'__ansible_vault' in dict_0



# Generated at 2022-06-25 03:46:15.275146
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ret_0 = ansible_j_s_o_n_decoder_0.object_hook([])

# Generated at 2022-06-25 03:46:20.026877
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_method = ansible_j_s_o_n_decoder_0.object_hook
    ansible_j_s_o_n_decoder_0.set_secrets(None)
    pairs = {'__ansible_vault': 'VjAxLTItc3VyZS50eHQ='}
    result = test_method(pairs)
    assert result is not None


# Generated at 2022-06-25 03:47:30.800771
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
