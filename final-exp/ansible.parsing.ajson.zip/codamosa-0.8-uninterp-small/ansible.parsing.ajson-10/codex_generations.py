

# Generated at 2022-06-25 03:37:36.399483
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_json_decoder_object_hook_0.object_hook({})


# Generated at 2022-06-25 03:37:41.316882
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:37:44.711418
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = ansible_j_s_o_n_decoder.object_hook()


# Generated at 2022-06-25 03:37:52.988480
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    input_0 = {
        "baz": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        "foo": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        "bar": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    }

# Generated at 2022-06-25 03:38:01.412457
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Testing the attribute vaults of AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_0.vaults = None
    ansible_j_s_o_n_decoder_0.set_secrets(None)
    # Testing the attribute vaults of AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Testing the attribute vaults of AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    # Testing the method object_hook of AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:38:03.387413
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:38:08.415355
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
# Test with dict inputs
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('secret')

# Test with dict inputs
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('')

# Generated at 2022-06-25 03:38:14.330824
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {u'foo': u'bar', u'baz': u'qux'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)


# Generated at 2022-06-25 03:38:18.554414
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Print start message
    print("Testing class AnsibleJSONDecoder: method object_hook")



# Generated at 2022-06-25 03:38:25.222432
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = """'__ansible_unsafe': '{ansible_ssh_pass}'"""
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(['test_secrets'])
    ansible_j_s_o_n_string_0 = json.loads(json_data, cls=ansible_json_decoder_0)

# Generated at 2022-06-25 03:38:29.638091
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_1.object_hook() == {}


# Generated at 2022-06-25 03:38:33.653714
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:35.360154
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:44.968024
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['test_secret'])

    data = {'__ansible_vault': '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          38343361663464313837306335363338636132643063303432653537656235636537316535663765\n          '}
    decoded_data = ansible_j_s_o_n_decoder_0.decode(json.dumps(data))


# Generated at 2022-06-25 03:38:54.079355
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Setup:
    pairs = {"__ansible_vault": "ansible-vault encrypted string"}

    # Exercise:
    ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs)
    
    # Assert:
    assert pairs['__ansible_vault'] == "ansible-vault encrypted string"
    assert isinstance(pairs['__ansible_vault'], str)


# Generated at 2022-06-25 03:39:05.374694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test object_hook method.
    """
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    keys = ['__ansible_vault', '__ansible_unsafe']

# Generated at 2022-06-25 03:39:18.277373
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    password = 'password'
    plaintext = "abcd"

# Generated at 2022-06-25 03:39:22.505443
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_1 = {}
    pairs_1 = ansible_j_s_o_n_decoder_0.object_hook(pairs_1)


# Generated at 2022-06-25 03:39:27.088808
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({}) # Should be safe
    ansible_j_s_o_n_decoder_0.object_hook(__ansible_unsafe="unsafe") # Should be unsafe


# Generated at 2022-06-25 03:39:34.182904
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_object_hook_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n356434303337366637646436623763653332643836646338643332326664373566643531663064\n396534386537333536343965613239376262616666633137643661306636356232643939393633\n'})

# Generated at 2022-06-25 03:39:38.506754
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_decoder_0.object_hook({'key': ansible_vault_encrypted_unicode_0})


# Generated at 2022-06-25 03:39:48.070115
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    key_0 = '__ansible_unsafe'
    value_0 = '__ansible_vault'
    pairs_0[key_0] = value_0

    # Test with invalid arguments.
    try:
        result_0 = ansible_j_s_o_n_decoder_0.object_hook()
    except TypeError:
        pass
    else:
        print('invalid test: object_hook() did not raise TypeError')

    # Test using Python dictionary objects.
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    if isinstance(result_0, dict):
        pass

# Generated at 2022-06-25 03:39:50.985401
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    #
    # Environment test setup
    #

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


    #
    # Test parameters
    #

    # Enable this test case!
    if True:
        ansible_j_s_o_n_decoder_0.object_hook(pairs={'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'})

# Generated at 2022-06-25 03:39:54.682123
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    pairs = ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:40:02.865370
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = \
        ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '', '__ansible_unsafe': ''})
    assert isinstance(ansible_vault_encrypted_unicode_0, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 03:40:11.873046
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_object_hook = ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:40:19.689333
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook() == "AnsibleJSONDecoder.object_hook() called: pairs: "

# Generated at 2022-06-25 03:40:25.508628
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Testing a direct call
    pairs = {}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert result is not None


# Generated at 2022-06-25 03:40:30.355714
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True


# Generated at 2022-06-25 03:40:37.637660
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook('__ansible_vault=vU6DjUZrIkH2sWG')
    ansible_j_s_o_n_decoder_0.object_hook('__ansible_unsafe=vU6DjUZrIkH2sWG')

# Generated at 2022-06-25 03:40:44.651615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)


# Generated at 2022-06-25 03:40:51.787721
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {"__ansible_unsafe": "str"}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0) == pairs_0



# Generated at 2022-06-25 03:41:01.404661
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-25 03:41:05.077305
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO: Create test case
    print('Testing object_hook')
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:41:11.932639
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs_1 = dict()
    pairs_1['key_1'] = 'value_1'
    pairs_1['key_2'] = 'value_2'
    pairs_1['key_3'] = 'value_3'
    pairs_1['key_4'] = 'value_4'
    pairs_1['key_5'] = 'value_5'
    pairs_1['key_6'] = 'value_6'
    assert ansible_j_s_o_n_decoder_1.object_hook(pairs_1) ==  pairs_1



# Generated at 2022-06-25 03:41:19.005313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_3 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_4 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_5 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_6 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_7 = AnsibleJSONDecoder()
    ansible_j_s

# Generated at 2022-06-25 03:41:28.653112
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_class_0 = {'__ansible_vault': '123'}
    test_pairs_0 = ansible_j_s_o_n_decoder_0.object_hook(test_class_0)
    assert(test_pairs_0['__ansible_vault'].vault.secrets == [])


# Generated at 2022-06-25 03:41:35.854998
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    test_input = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo\r\nbar\r\n'}
    assert ansible_j_s_o_n_decoder_1.object_hook(test_input) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo\r\nbar\r\n'}


# Generated at 2022-06-25 03:41:43.499145
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder()
    assert isinstance(obj.object_hook('__ansible_vault'), AnsibleVaultEncryptedUnicode)
    assert isinstance(obj.object_hook('__ansible_unsafe'), wrap_var)
    assert isinstance(obj.object_hook('a'), None)


# Generated at 2022-06-25 03:41:52.350715
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = ""
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder.object_hook({
        "__ansible_vault": ansible_vault_encrypted_unicode_0,
        "__ansible_unsafe": "unsafe"
    })
    assert ansible_vault_encrypted_unicode_0 is not None

# Generated at 2022-06-25 03:41:57.878904
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO Figure out how to test this
    pass
# End of test case


# Generated at 2022-06-25 03:42:01.744329
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO: modify this test to test the method object_hook of class AnsibleJSONDecoder
    assert ansible_j_s_o_n_decoder_0 is not None


# Generated at 2022-06-25 03:42:08.983980
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    input = u'{"__vault": "vault value", "__ansible_vault": "__ansible_vault__", "__ansible_memo": "__ansible_memo__", "__ansible_unsafe": "__ansible_unsafe__"}'
    expected = {'__vault': 'vault value', '__ansible_vault': '__ansible_vault__', '__ansible_memo': '__ansible_memo__', '__ansible_unsafe': '__ansible_unsafe__'}

    assert expected == json.loads(input)


# Generated at 2022-06-25 03:42:16.898640
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['ansible'])
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    del(ansible_vault_encrypted_unicode_0.vault)
    ansible_j_s_o_n_decoder_0.object_hook({'_ansible_vault': 'test'})

# Generated at 2022-06-25 03:42:17.916380
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert False


# Generated at 2022-06-25 03:42:20.904738
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert decoder.object_hook({'__ansible_vault': 'abc'}) == AnsibleVaultEncryptedUnicode('abc')



# Generated at 2022-06-25 03:42:22.835830
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults



# Generated at 2022-06-25 03:42:31.628695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # AnsibleVaultEncryptedUnicode
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '****'})['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # WrapVariable
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test'})['__ansible_unsafe']._legacy_unsafe

    ansible_j_s_o_n_decoder_0.set_secrets(['test'])

# Generated at 2022-06-25 03:42:35.765484
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(list(list(list(list()))))
    test_0 = {'__ansible_unsafe': 'test string'}
    ansible_j_s_o_n_decoder_0.object_hook(test_0)
    test_1 = {'__ansible_vault': 'test string'}
    ansible_j_s_o_n_decoder_0.object_hook(test_1)

# Generated at 2022-06-25 03:42:40.567332
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'secret'}) == wrap_var('secret')

# Generated at 2022-06-25 03:42:49.108591
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets("")
    with open("tests/mock_data/parse_yaml.json", "r") as f:
        json_data = json.load(f, cls=AnsibleJSONDecoder)
    assert "FRUIT" in json_data

# Generated at 2022-06-25 03:43:00.170580
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # There is a bug in the py3_env.  Rather than fix it via a complex workaround, just do this test in python2.
    try:
        from __pypy__ import pyversion
        if pyversion >= '3.5':
            return
    except ImportError:
        pass

    ansible_json_decoder_0 = AnsibleJSONDecoder()

    # It is a tuple, containing three elements.
    test_case_0 = (({'__ansible_vault': 'N/A'},
                     {'__ansible_unsafe': 'N/A'}),
                    {'__ansible_default_vault_id': 'N/A'},
                    {'__ansible_vault': 'N/A', '__ansible_unsafe': 'N/A'})
    ansible_json_

# Generated at 2022-06-25 03:43:04.548755
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    # Call method object_hook  with args
    ansible_j_s_o_n_decoder_1.object_hook()

# Generated at 2022-06-25 03:43:10.815690
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_json_0 = '{"__ansible_vault": "vault"}'
    test_value_0 = json.loads(test_json_0, object_hook=ansible_j_s_o_n_decoder_0.object_hook)
    # AssertionError: assert '<ansible.parsing.vault.AnsibleVaultEncryptedUnicode object at 0x7f0ad0f75190>' == 'vault'


# Generated at 2022-06-25 03:43:17.587861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs_1 = {}
    ansible_j_s_o_n_decoder_1.object_hook( pairs_1 )


# Generated at 2022-06-25 03:43:20.593694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder.object_hook(
        {
            '__ansible_vault': 'foo',
        }
    ) == AnsibleVaultEncryptedUnicode('foo')



# Generated at 2022-06-25 03:43:23.763156
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    result_0 = ansible_j_s_o_n_decoder_1.object_hook({})
    assert result_0 == {}


# Generated at 2022-06-25 03:43:28.124423
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_data = '{"__ansible_vault": "AES256"}'
    ansible_json_data = ansible_j_s_o_n_decoder_0.decode(json_data)
    assert(ansible_json_data == {u'__ansible_vault': u'AES256'})


# Generated at 2022-06-25 03:43:33.925714
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Creating objects for test
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=None)
    pairs = {'__ansible_unsafe': 'unsafe data', '__ansible_vault': 'vault data'}
    ansible_json_decoder.set_secrets('Hello World')

    # Testing the method
    res = ansible_json_decoder.object_hook(pairs)
    assert type(res) is dict

# Generated at 2022-06-25 03:43:42.239545
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets({'default': '12345678901234567890123456789012'})

# Generated at 2022-06-25 03:43:49.545396
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Assumes AnsibleJSONDecoder.set_secrets(secrets) was already called
    ansible_j_s_o_n_decoder_0.object_hook({
        "foo": "bar",
        "baz": "qux",
        "__ansible_vault": "my_secret"
    })


# Generated at 2022-06-25 03:43:56.546761
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test case 0
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

# Generated at 2022-06-25 03:43:58.127776
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': '{{ foo }}'})


# Generated at 2022-06-25 03:44:00.415875
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  ansible_json_decoder_0 = AnsibleJSONDecoder()
  assert ansible_json_decoder_0 is not None
  ansible_json_decoder_0.object_hook({'key1':'value1'})


# Generated at 2022-06-25 03:44:08.212678
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    pairs_1 = {u'key_1': u'value_1', u'key_2': u'value_2', u'key_4': u'value_4'}
    ansible_j_s_o_n_decoder_1.object_hook(pairs_1)

# Generated at 2022-06-25 03:44:17.511077
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('54e88f8d')
    ansible_j_s_o_n_decoder_0._vaults['default'] = ansible_v_a_u_l_t_encrypted_unicode_0.vault
    pairs_0 = {'__ansible_vault': '54e88f8d'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0)


# Generated at 2022-06-25 03:44:21.463229
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1_s = {'a': 1, 'b': 2, 'c': 3}
    ansible_j_s_o_n_decoder_0 = ansible_j_s_o_n_decoder_1.object_hook(ansible_j_s_o_n_decoder_1_s)


# Generated at 2022-06-25 03:44:25.011677
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test for case 0
    ansible_j_s_o_n_decoder_0.object_hook()

# Generated at 2022-06-25 03:44:35.074442
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:44:39.386441
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = 'Default'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('AnsibleVaultEncryptedUnicode_1')
    pairs = {'AnsibleVaultEncryptedUnicode_0': ansible_vault_encrypted_unicode_1, 'debug_1': 'debug_2'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == pairs


# Generated at 2022-06-25 03:44:52.067528
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True == False

    # Set up test inputs

    # Run the method
    method_return = AnsibleJSONDecoder.object_hook(pair)

    # Check the expected result
    assert method_return == expected_result

# Generated at 2022-06-25 03:44:54.300425
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder(object_hook='')


# Generated at 2022-06-25 03:45:02.149348
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'foo', 'key2': 'bar'}
    output = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert output == {'__ansible_vault': 'foo', 'key2': 'bar'}

# Generated at 2022-06-25 03:45:09.199844
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_object_hook_1 = AnsibleJSONDecoder.object_hook(ansible_j_s_o_n_decoder_object_hook_0, {})
    return ansible_j_s_o_n_decoder_object_hook_1


# Generated at 2022-06-25 03:45:10.646369
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert True

# Generated at 2022-06-25 03:45:14.912853
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(['hunter1'])
    ansible_j_s_o_n_decoder_1.object_hook(dict)
    ansible_j_s_o_n_decoder_1.vaults

# Generated at 2022-06-25 03:45:16.809567
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    assert ansible_j_s_o_n_decoder_0.object_hook({}) == {}


# Generated at 2022-06-25 03:45:30.415978
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {
    }
    pairs0 = dict(__ansible_vault='test', __ansible_unsafe='dict')
    pairs1 = dict(__ansible_vault=1, __ansible_unsafe=2)
    pairs2 = dict(__ansible_vault=1.1, __ansible_unsafe=2.1)
    pairs3 = dict(__ansible_vault=True, __ansible_unsafe=False)
    pairs4 = dict(__ansible_vault=False, __ansible_unsafe=True)
    pairs5 = dict(__ansible_vault=None, __ansible_unsafe=None)

# Generated at 2022-06-25 03:45:40.302053
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_obj_0 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder().object_hook)
    ansible_json_decoder_obj_1 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder().object_hook)
    ansible_json_decoder_obj_1.set_secrets("some_secrets")
    ansible_json_decoder_obj_2 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder().object_hook)
    ansible_json_decoder_obj_2.set_secrets("some_secrets")
    ansible_json_decoder_obj_3 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder().object_hook)
    ansible_json_decoder_obj_

# Generated at 2022-06-25 03:45:45.212660
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    string = '{"__ansible_vault": "EncryptedYWJjZGVmZw==\n"}'
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    assert string == ansible_j_s_o_n_decoder_1.object_hook(string)


# Generated at 2022-06-25 03:46:07.750054
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(b'foo')
    result_0 = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n61646d696e646f78206c6f6f6b65206865796c6465206c6f6f6b65206865796c6465206c6f6f\n6b65206865796c646520\n'})

# Generated at 2022-06-25 03:46:12.754836
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test with key == '__ansible_vault'
    # Test with key == '__ansible_unsafe'
    # Test with keys != '__ansible_vault' and != '__ansible_unsafe'

# Generated at 2022-06-25 03:46:20.684644
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_encoder_0.vaults['default'] = VaultLib()

# Generated at 2022-06-25 03:46:26.149867
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    expected_result_1 = {'y': 5, 'x': 2}
    actual_result_1 = ansible_j_s_o_n_decoder_1.object_hook({'y': 5.0, 'x': 2.0})
    assert actual_result_1 == expected_result_1

# Generated at 2022-06-25 03:46:35.139012
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    payload = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
        '__ansible_unsafe': '$VAR',
    }
    expected_result = {
        '__ansible_vault': b'$ANSIBLE_VAULT;1.1;AES256',
        '__ansible_unsafe': b'$VAR',
    }

    result = ansible_j_s_o_n_decoder_0.object_hook(payload)
    assert result == expected_result


# Generated at 2022-06-25 03:46:43.227327
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    encoder = AnsibleJSONEncoder()

    # object hook should work like a dict
    test_dict = dict(foo=42, bar=True)
    json_str = encoder.encode(test_dict)
    decoded_dict = decoder.decode(json_str)
    assert decoded_dict == dict(foo=42, bar=True)

    # the __ansible_vault key should use AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 03:46:54.064456
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1._vaults['default'] = VaultLib(secrets=[VaultLib._deprecated_string_to_bytes('test')])

    # Test with a non-secret JSON object
    # Assert the result has the correct type
    assert isinstance(ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)
    # Assert that the result is equal to the expected value

# Generated at 2022-06-25 03:46:59.412147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()
    assert True


# Generated at 2022-06-25 03:47:09.455637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test with vault variable
    ansible_j_s_o_n_decoder_0.set_secrets(['test_password'])
    vault = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n...\n', '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256\n...\n'}
    vault_out = ansible_j_s_o_n_decoder_0.object_hook(vault)

    assert isinstance(vault_out['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 03:47:15.860074
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()