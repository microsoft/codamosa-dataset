

# Generated at 2022-06-25 03:37:41.418042
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_o_h_0 = ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:37:49.680598
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    object_hook_args_1 = {'__ansible_vault': 'test_value'}
    with pytest.raises(Exception):
        ansible_j_s_o_n_decoder_0.object_hook(object_hook_args_1)
    object_hook_args_2 = {'test_key': 'test_value'}
    return_value_3 = ansible_j_s_o_n_decoder_0.object_hook(object_hook_args_2)
    assert return_value_3 == {'test_key': 'test_value'}


# Generated at 2022-06-25 03:37:54.314750
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()



# Generated at 2022-06-25 03:38:02.141892
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    pairs['__ansible_vault'] = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n61323267653039333732386232306266626135313531393165323335373732356337653832623164320a633663336166623262666139353336623132333730376263393563356464636533643932330a3465376439353961623737343665333064376662626163396665373362643038656564353163\n'}

    # call method
    result = ansible_j_s_o_n_decoder_

# Generated at 2022-06-25 03:38:09.186640
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:38:14.365716
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = dict()
    ansible_j_s_o_n_decoder_0.object_hook(pairs)



# Generated at 2022-06-25 03:38:19.097395
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {"__ansible_unsafe": "string"}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:38:23.926266
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.vault = None
    object_hook_tuple_0 = {'__ansible_vault': 'ansible_vault_encrypted_unicode_0'}
    ansible_j_s_o_n_decoder_0.object_hook(object_hook_tuple_0)


# Generated at 2022-06-25 03:38:34.805851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Pass in non-basestring key and value and expect no changes in the returned value
    pairs = {'key': 'value'}
    returned_value = ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs)
    assert pairs == returned_value

    # Pass in __ansible_vault and value to trigger AnsibleVaultEncryptedUnicode()
    pairs = {'__ansible_vault': 'value'}
    returned_value = ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs)
    assert isinstance(returned_value, AnsibleVaultEncryptedUnicode)

    # Pass in __ansible

# Generated at 2022-06-25 03:38:43.089283
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_test_data = '{"test_0": "test_0", "test_1": "test_1"}'
    json_test_object = json.loads(json_test_data, object_hook=AnsibleJSONDecoder.object_hook)
    assert json_test_object["test_0"] == "test_0", "AnsibleJSONDecoder.object_hook() method failed."
    assert json_test_object["test_1"] == "test_1", "AnsibleJSONDecoder.object_hook() method failed."


# Generated at 2022-06-25 03:38:47.286672
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder.set_secrets(["SOMESECRET"])
    object_hook_pairs_0 = ansible_j_s_o_n_decoder_0.object_hook({})
    assert ansible_j_s_o_n_decoder_0


# Generated at 2022-06-25 03:38:50.439818
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    in_json = '{"__ansible_vault": "sample_value"}'
    in_secrets = "['secret_value']"
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(in_secrets)
    actual = ansible_j_s_o_n_decoder_0.decode(in_json)
    expected = {u'__ansible_vault': AnsibleVaultEncryptedUnicode('sample_value')}
    assert actual == expected

# Generated at 2022-06-25 03:38:54.114497
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    e_0 = AnsibleJSONDecoder()
    e_0.set_secrets(['foo'])
    res_0 = e_0.object_hook({'__ansible_vault': 'bla'})
    assert res_0.vault.secrets == ['foo']


# Generated at 2022-06-25 03:39:04.573050
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:39:08.702211
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_object = ansible_j_s_o_n_decoder_0.object_hook(pairs=[['__ansible_unsafe', '{}']])
    assert ansible_j_s_o_n_decoder_0_object == {'__ansible_unsafe': {}}

# Generated at 2022-06-25 03:39:14.248799
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    with pytest.raises():
        # Case 1
        ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
        pairs_0 = 'Sd'
        ansible_j_s_o_n_decoder_0.object_hook(pairs_0)


# Generated at 2022-06-25 03:39:21.322314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('foo')
    pairs = dict()
    y = ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:39:26.882011
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {
        '__ansible_unsafe': '{"__ansible_vault": "This is a vault value"}',
    }
    ret = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert isinstance(ret['__ansible_unsafe'], dict)


# Generated at 2022-06-25 03:39:29.564313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder._object_hook
    pass


# Generated at 2022-06-25 03:39:39.006150
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Test object_hook method of class AnsibleJSONDecoder"""
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Tests on ansible_vault
    # Test for simple ansible_vault string representation
    assert isinstance(json.loads('{"__ansible_vault": "MySecretValue"}', cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)

    # Test for nested ansible_vault string representation
    assert isinstance(json.loads('{"a":{"b":{"__ansible_vault": "MySecretValue"}}}', cls=AnsibleJSONDecoder)['a']['b'], AnsibleVaultEncryptedUnicode)

    # Tests on __ansible_unsafe
    # Test for simple unsafe object

# Generated at 2022-06-25 03:39:44.773977
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_decoder_0.object_hook("pairs")


# Generated at 2022-06-25 03:39:49.564635
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    body = """
    {
        "__ansible_vault": "abcde"
    }
    """
    assert ansible_j_s_o_n_decoder_0.object_hook(json.loads(body)) == {'__ansible_vault': 'abcde'}

# Generated at 2022-06-25 03:39:52.160328
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True


# Generated at 2022-06-25 03:39:59.772328
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_0 = AnsibleVaultEncryptedUnicode('__ansible_vault')
    if ansible_v_a_u_l_t_0:
        ansible_j_s_o_n_decoder_0._vaults['default'] = ansible_v_a_u_l_t_0.vault
        ansible_j_s_o_n_decoder_0._vaults['default'].secrets = ansible_j_s_o_n_decoder_0._vaults.get('default', {}).get('secrets', [])

# Generated at 2022-06-25 03:40:06.491852
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'foo')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(u'foo')
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_1.vault


# Generated at 2022-06-25 03:40:11.182837
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs=42)


# Generated at 2022-06-25 03:40:17.298813
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook(()) == []
    assert ansible_j_s_o_n_decoder_0.object_hook({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert test_AnsibleJSONDecoder_method_3(ansible_j_s_o_n_decoder_0)


# Generated at 2022-06-25 03:40:23.763561
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'dummy'}
    assert ansible_j_s_o_n_decoder_2.object_hook(pairs)


# Generated at 2022-06-25 03:40:34.575710
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_jsonencoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0._vaults = {}
    ansible_j_s_o_n_decoder_0.object_hook("test_value")
    ansible_j_s_o_n_decoder_0._vaults = ansible_j_s_o_n_decoder_0._vaults
    ansible_jsonencoder_0.encoder = ""
    ansible_jsonencoder_0.iterencode = ""
    ansible_j_s_o_n_decoder_0.object_hook("test_value")
    ansible_j_s_o_n_decoder

# Generated at 2022-06-25 03:40:37.680102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json = json.loads('{"__ansible_unsafe": "test"}')
    assert ansible_json == {Wrapper(u'test'): None}


# Generated at 2022-06-25 03:40:44.852851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {
        'default': "VaultLib('$ANSIBLE_VAULT;1.1;AES256', '\\nansible\\n')",
    }
    data = {'__ansible_vault': 'encrypted_string'}

    assert ansible_j_s_o_n_decoder_0.object_hook(data) == AnsibleVaultEncryptedUnicode('encrypted_string')



# Generated at 2022-06-25 03:40:52.377412
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    dict = dict()
    dict['__ansible_vault'] = 'sample'
    dict['__ansible_unsafe'] = 'sample'
    assert ansible_j_s_o_n_decoder.object_hook(dict) is not None


# Generated at 2022-06-25 03:40:56.896619
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets({'keys': {'key_0': {'cipher': 'aes256', 'vault_id': 'default'}}})
    vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('vault_encrypted_unicode_0')
    ansible_j_s_o_n_decoder_0.object_hook(vault_encrypted_unicode_0)


# Generated at 2022-06-25 03:41:03.318545
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = AnsibleJSONDecoder()
    # Replace the VaultLib with a mock object
    s._vaults['default'] = mock.Mock()
    vaulted_string = {
        "foo": "bar",
        "baz": {"__ansible_vault": "foobar"}}
    result = s.object_hook(vaulted_string)
    assert result['baz'].vault == s._vaults['default']
    assert type(result['baz']) is AnsibleVaultEncryptedUnicode
    assert result['baz'] == 'foobar'

# Generated at 2022-06-25 03:41:07.909542
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    field_0 = '__ansible_vault'
    field_1 = '__ansible_unsafe'
    value_0 = '7b226c6f67223a2022696e737465'
    value_1 = {
        '__ansible_unsafe': True,
        field_0: value_0,
        }

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({field_1: value_1}) == {field_1: value_1}
    assert ansible_j_s_o_n_decoder_0.object_hook({field_0: value_0}) == {field_0: value_0}

# Generated at 2022-06-25 03:41:10.115762
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()

    input = {}
    output = ansible_json_decoder_0.object_hook(input)
    assert(output == input)


# Generated at 2022-06-25 03:41:12.845732
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert True

# Generated at 2022-06-25 03:41:19.871826
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Call object_hook without arguments
    # Because we are calling the method directly we need to pass in the self
    # object to make it work as expected
    result = ansible_j_s_o_n_decoder_1.object_hook(ansible_j_s_o_n_decoder_1)
    # Check the result
    assert result == ansible_j_s_o_n_decoder_1
    # Call object_hook with arguments
    # Because we are calling the method directly we need to pass in the self
    # object to make it work as expected

# Generated at 2022-06-25 03:41:28.204544
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = b'{"__ansible_vault": "vault_value"}'
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    output = ansible_j_s_o_n_decoder_0.decode(data)
    assert output == {'__ansible_vault': 'vault_value'}


# Generated at 2022-06-25 03:41:33.327753
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    p1 = {'__ansible_vault': 'meh'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    p2 = ansible_j_s_o_n_decoder_0.object_hook(p1)
    assert p2 is not None
    assert p2[0] == '__ansible_vault'
    assert p2[1] == 'meh'


# Generated at 2022-06-25 03:41:48.104884
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets('hello')

# Generated at 2022-06-25 03:41:50.757220
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Invalid inputs to method object_hook


# Generated at 2022-06-25 03:42:02.948259
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['secret'])
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_lib_0 = VaultLib(secrets=['secret'])
    ansible_vault_encrypted_unicode_0 = ansible_vault_lib_0.encrypt('abc')
    unsafe_0 = wrap_var({'a': 'b'})

# Generated at 2022-06-25 03:42:13.343165
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert(ansible_j_s_o_n_decoder_0._vaults == {})

    ansible_j_s_o_n_decoder_0.set_secrets('test_pass')
    assert(len(ansible_j_s_o_n_decoder_0._vaults) == 1)

    assert(ansible_j_s_o_n_decoder_0._vaults['default'].secrets == 'test_pass')

    assert(ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo'}).data == 'foo')

# Generated at 2022-06-25 03:42:23.962425
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0_0 = AnsibleJSONDecoder()

    # Note: For this to work in python2.7, the vault_password_file and
    # enable_exclude_vars_from_vault options must be set in ansible.cfg
    secret = "example_password"
    AnsibleJSONDecoder.set_secrets(secret)

    example_dict = {'a': 1, 'b': 2}
    json_dict = json.dumps(example_dict, cls=AnsibleJSONEncoder)
    # Note: This would be a VaultLib instance if the vault_password_file and
    # enable_exclude_vars_from_vault options were set in ansible.cfg.  Because
    # the options were not set in ansible.cfg and unit tests

# Generated at 2022-06-25 03:42:32.376111
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_secrets = ['random']
    AnsibleJSONDecoder.set_secrets(vault_secrets)

    p_o_k_e_m_o_n_0 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n32343232343232323432\n', '__ansible_unsafe': False}
    p_o_k_e_m_o_n_1 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n32343232343232323432\n', '__ansible_unsafe': True}

    # Object hook test case 1
    a_n_s_i_b_l_e_j_s_o_n_decoder = AnsibleJSONDec

# Generated at 2022-06-25 03:42:44.582121
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    pairs = {}

    key = None
    value = u'AAECBEZhbGxvdy1teS1hY2Nlc3MIe1//H4RS4o7BUJ/Fsz9X/VuDx8+vn6hbNlGANreT6UIUM/aA/d+0u6A==\n'
    pairs[key] = value

    key = '__ansible_vault'

# Generated at 2022-06-25 03:42:52.105103
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    d = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n313031323132313231323132313231323132313231323132313231323132313231323132313231313231323132313433\n353332643465343133366562613833653737666631303966373636613032336536616266333730626432306263363739\n353132313231323132313231323132313231323132313231323132313231323132313231323131323132313231323433\n'
    }


# Generated at 2022-06-25 03:43:03.581888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:43:11.277658
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test with a non-empty dictionary

# Generated at 2022-06-25 03:43:21.180178
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True == True


# Generated at 2022-06-25 03:43:24.072747
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test for method object_hook
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:43:31.866285
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({"__ansible_unsafe": ansible_vault_encrypted_unicode_0}) == wrap_var(ansible_vault_encrypted_unicode_0)

# Generated at 2022-06-25 03:43:33.484092
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
	
	# Test 1, str with ansible_vault
	pass


# Generated at 2022-06-25 03:43:41.992210
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib()

    data = '__ansible_unsafe=foo'
    result = ansible_j_s_o_n_decoder_0.object_hook(json.loads(data))
    assert result == {'__ansible_unsafe': 'foo'}

    data = '__ansible_vault=foo'
    result = ansible_j_s_o_n_decoder_0.object_hook(json.loads(data))
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is ansible_j_s_o_n_decoder_0._v

# Generated at 2022-06-25 03:43:45.347243
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(None)
    assert ansible_json_decoder_0.object_hook("{}") == {}


# Generated at 2022-06-25 03:43:47.764254
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    object_hook = ansible_j_s_o_n_decoder_1.object_hook
    assert object_hook is not None


# Generated at 2022-06-25 03:44:00.588200
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    input_0 = {'__ansible_unsafe' : {'__ansible_vault' : '$ANSIBLE_VAULT;1.1;AES256', '__ansible_unsafe' : {'__ansible_vault' : '$ANSIBLE_VAULT;1.1;AES256'}, '__ansible_vault' : '$ANSIBLE_VAULT;1.1;AES256'}, '__ansible_vault' : '$ANSIBLE_VAULT;1.1;AES256'}

# Generated at 2022-06-25 03:44:07.763786
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = AnsibleJSONDecoder()
    ansible_json_decoder_object_hook_1 = ansible_json_decoder_1.object_hook({})
    assert ansible_json_decoder_object_hook_1 == {}


# Generated at 2022-06-25 03:44:11.157199
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook({'foo': 'bar'})


# Generated at 2022-06-25 03:44:29.100768
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()



# Generated at 2022-06-25 03:44:33.288965
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'foo': 'bar'}
    pairs_copy = pairs.copy()
    ret = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert ret == pairs_copy


# Generated at 2022-06-25 03:44:44.147311
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_0 = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256\\n313233666461306535386637343066363533663562613536323337626533323231643964353238\\n383061323663313931333532353239353937396335636665386461616639633565363331626561\\ntRxXBH9s7sF+vIuotjoFwZJbzW+kYUCvDIzHfUdCL6UQWsk+8JvbGk/oiv4O4ZrtN4B4GcK\\n","__ansible_unsafe": true}'
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible

# Generated at 2022-06-25 03:44:48.587416
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._AnsibleJSONDecoder__vaults['default'] = VaultLib()
    ansible_j_s_o_n_decoder_0.object_hook({})
    ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:44:58.308880
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Test method object_hook of class AnsibleJSONDecoder"""
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # From file vault/test/fixtures/encrypt_and_decrypt.json

# Generated at 2022-06-25 03:45:02.117682
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # The following will cause object_hook method to throw an error exception since it needs to be passed input from json.loads
    #ansible_j_s_o_n_decoder_0.object_hook(None)

# Generated at 2022-06-25 03:45:11.975548
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '''
    {
        "__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n      64396338396265376665626532353161366138613137333932616262643139393963343965636334\n      31613236376630366530653162383837653532613538613534653966626435363831636331643136\n      343833336433306264643435306438\n      "
    }
    '''

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(['secret'])
    assert ansible_j

# Generated at 2022-06-25 03:45:18.705753
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder.object_hook('foo')
    ansible_j_s_o_n_decoder_1 = ansible_j_s_o_n_decoder_0.object_hook({'bar':'foobar'})
    assert(ansible_j_s_o_n_decoder_1)


# Generated at 2022-06-25 03:45:29.259051
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(object_hook=1)
    str_0 = "{'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\n[snip]\n'}"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    if isinstance(ansible_vault_encrypted_unicode_0, basestring):
        unichr_0 = ansible_vault_encrypted_unicode_0
        str_1 = str(unichr_0)
    else:
        str_1 = ansible_vault_encrypted_unicode_0

# Generated at 2022-06-25 03:45:33.636194
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import to_text
    assert to_text(test_case_0) == 'test_case_0()'

# Generated at 2022-06-25 03:46:10.577053
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    pairs = {
        'a': {
            'b': 'hello-world'
        }
    }
    # Test
    for key in pairs:
        value = pairs[key]

        if key == 'a':
            assert(value == { 'b': 'hello-world' })


# Generated at 2022-06-25 03:46:19.832021
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_str_0 = '{"__ansible_vault": "test"}'
    ansible_json_str_1 = '{"__ansible_unsafe": "test"}'
    ansible_json_str_2 = '{"test": "test"}'
    ansible_json_str_3 = '{"__ansible_vault": "test", "__ansible_unsafe": "test", "test": "test"}'

    ansible_json_secrets_0 = ['test', 'passw0rd']
    ansible_json_secrets_1 = ['test']

    # case 0
    ansible_j_s_o_n_decoder_0_object_hook_pairs_0 = ansible_json_str_0
    ansible_j_s_o_n_decoder_

# Generated at 2022-06-25 03:46:21.962756
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs=None)


# Generated at 2022-06-25 03:46:30.024808
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets([])
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test_string'})
    ansible_j_s_o_n_decoder_0.set_secrets([])
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'test_string'})

# Generated at 2022-06-25 03:46:31.862156
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = AnsibleJSONDecoder()
    assert result.object_hook == 'object_hook'


# Generated at 2022-06-25 03:46:35.421921
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    AnsibleJSONDecoder.set_secrets('mysecrets')
    res_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert res_0 == pairs_0


# Generated at 2022-06-25 03:46:43.229975
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:46:49.190565
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    params = {}
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(params)

# Generated at 2022-06-25 03:47:00.361612
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0_obj = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_pairs = {}
    ansible_j_s_o_n_decoder_0_obj.object_hook(ansible_j_s_o_n_decoder_0_pairs);


# Generated at 2022-06-25 03:47:01.538778
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # case0
    test_case_0()