

# Generated at 2022-06-25 03:37:38.659532
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0 is not None


# Generated at 2022-06-25 03:37:45.423598
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test of method object_hook of AnsibleJSONDecoder
    secrets = ['test']
    encrypted_data = u'$ANSIBLE_VAULT;1.1;AES256\nmUyzOyIY+CbY3qmgb71pOgZ+/0g/1e8xPO/r0cEoN+BJ6Ng8d1WArHvG1D\nrgKX6U2x6dRk6JYw6TfcKj3Wq3+SLpMzLZKXJpCz+8xvEg==\n'
    test_data = {
        u'some_var': encrypted_data,
    }
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-25 03:37:49.532410
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:01.282710
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:38:12.688982
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['1234'])
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n....', '__ansible_unsafe': 'test'}
    actual_result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    expected_result = {'__ansible_vault': AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n....'),
                       '__ansible_unsafe': 'test'}
    assert actual_result == expected_result


# Generated at 2022-06-25 03:38:21.903781
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_case = {'__ansible_vault': 'something encrypted', '__ansible_unsafe': 'something unsafe'}
    ansible_json_encoder = AnsibleJSONEncoder()
    test_case_json = ansible_json_encoder.encode(test_case)
    decoded = ansible_j_s_o_n_decoder_0.decode(test_case_json)
    assert decoded['__ansible_vault'] == 'something encrypted'
    assert decoded['__ansible_unsafe'] == 'something unsafe'


# Generated at 2022-06-25 03:38:27.166262
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    f_json_data_0 = """{
    "__ansible_unsafe": "SSBsb3ZlIEFuc2libGUh"
}"""
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    f_result_0 = ansible_j_s_o_n_decoder_0.decode(f_json_data_0)
    assert f_result_0 == {'__ansible_unsafe': 'SSBsb3ZlIEFuc2libGUh'}


# Generated at 2022-06-25 03:38:29.685972
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj_0 = AnsibleJSONDecoder()
    secret_0 = ['bar']
    AnsibleJSONDecoder.set_secrets(secret_0)
    obj_0.object_hook(pairs='foo')

# Generated at 2022-06-25 03:38:39.465686
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j_s_o_n_data = {
        "__ansible_vault": '$ANSIBLE_VAULT;1.1;AES256;foo;bar;blahblah\r\nblahblahblahblahblahblahblah==',
        '__ansible_unsafe': 'unsafe'
    }
    j_s_o_n_data2 = "{'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo;bar;blahblah\\r\\nblahblahblahblahblahblahblah==', '__ansible_unsafe': 'unsafe'}"

    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0._vaults['default'] = Vault

# Generated at 2022-06-25 03:38:44.470325
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_object_hook_pairs_0 = {} # FIXME: Create an instance of dict
    ansible_j_s_o_n_decoder_0_object_hook_pairs_1 = {} # FIXME: Create an instance of dict
    ansible_j_s_o_n_decoder_0_object_hook_pairs_2 = {} # FIXME: Create an instance of dict
    ansible_j_s_o_n_decoder_0_object_hook_pairs_3 = {} # FIXME: Create an instance of dict
    ansible_j_s_o_n_decoder_0_object_hook_pairs_4 = {}

# Generated at 2022-06-25 03:38:56.265702
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # default args
    ansible_j_s_o_n_decoder_object_hook_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_object_hook_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_object_hook_1.set_secrets('password')

# Generated at 2022-06-25 03:39:00.069497
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:39:02.671126
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
# Creation of object of class AnsibleJSONEncoder

# Generated at 2022-06-25 03:39:05.566167
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test for a bad module name
    ansible_j_s_o_n_decoder_0.object_hook(pairs={'__ansible_vault': '--'})

# Generated at 2022-06-25 03:39:15.990866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_object = AnsibleJSONDecoder()

    e_v_a_u_l_t = {"A": "B"}
    test_object._vaults['default'] = e_v_a_u_l_t

    test_input = {'__ansible_vault': 'asdf1234','__ansible_unsafe': '1234'}
    assert test_object.object_hook(test_input) == {'__ansible_vault': 'asdf1234','__ansible_unsafe': 1234}

# Generated at 2022-06-25 03:39:18.841862
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook({
        'foo': 'bar'
    }) == {'foo': 'bar'}


# Generated at 2022-06-25 03:39:28.641139
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['test'])
    pairs = {'__ansible_vault': '9A46C9A19104B0AF66F2FFF2C24D78F0'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)
    pairs = {'__ansible_unsafe': '9A46C9A19104B0AF66F2FFF2C24D78F0'}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)

# Generated at 2022-06-25 03:39:32.508487
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # For sanity check.
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # For failure check.
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    if True:
        assert True
    else:
        raise AssertionError('True is not false.')



# Generated at 2022-06-25 03:39:33.221229
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass


# Generated at 2022-06-25 03:39:43.422458
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_JSON_decoder_1 = json.JSONDecoder()

    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'value'}), AnsibleVaultEncryptedUnicode)
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'value'}) == {'__ansible_unsafe': 'value'}

# Generated at 2022-06-25 03:39:52.496780
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    if False:
        # ansible_j_s_o_n_decoder_0._vaults, ansible_j_s_o_n_encoder_0._vaults
        pass
    # FIXME: AnsibleVaultEncryptedUnicode() not exists in this unit test env.
    ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": AnsibleVaultEncryptedUnicode("my_secret", "AES256")})
    # FIXME: AnsibleVaultEncryptedUnicode() not exists in this unit test env.
    ansible_j

# Generated at 2022-06-25 03:39:55.585579
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_1.set_secrets(['secret'])

    # TODO: Write this test

# Generated at 2022-06-25 03:40:06.108770
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:40:12.640403
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Mock object_hook method
    def mock_object_hook(pairs):
        value = pairs.values()[0]

        if isinstance(value, dict):
            return value

        return value.upper()

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(object_hook=mock_object_hook)

    assert ansible_j_s_o_n_decoder_0.object_hook({'value':'value'}) == {'value':'VALUE'}


# Generated at 2022-06-25 03:40:19.454067
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
  ansible_j_s_o_n_decoder_0.object_hook({"dict_key_0": "dict_value_0"})

# Generated at 2022-06-25 03:40:26.751631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('$ANSIBLE_VAULT;1.1;AES256')
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'})



# Generated at 2022-06-25 03:40:36.846673
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256\n3337663032303436373336356534356361613561333961303265306439333635633861656466386130\n3064396131356433353064656663643635383431363930323531323233306639623733666539373335\n6536623361653436325a\n"})

# Generated at 2022-06-25 03:40:45.424084
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets('foo')
    obj_2 = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;default\n313936366637353733353438636563346637613461376136356639626434666434353937636336\n3962326262396361646333613135333934373038653839353334613337636162333961626237326\n3961616361643838633936\n', u'__ansible_unsafe': {u'value': u'foo', u'safe': 'False'}}

# Generated at 2022-06-25 03:40:55.587544
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    AnsibleJSONDecoder object_hook
    """
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test with required args.
    test_data = {"__ansible_unsafe": "{{goodsecrets}}"}
    unfiltered_data = ansible_j_s_o_n_decoder_0.object_hook(test_data)
    expected_data = {'__ansible_unsafe': u'{{goodsecrets}}'}

    # Test with optional args.
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

# Generated at 2022-06-25 03:41:00.142683
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    # Call method object_hook of class AnsibleJSONDecoder with one arguments
    result = ansible_json_decoder_0.object_hook({'__ansible_vault':'foo','__ansible_unsafe':'bar'})


# Generated at 2022-06-25 03:41:05.149136
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # TypeError: self._vaults is not subscriptable
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'secret'})


# Generated at 2022-06-25 03:41:12.940500
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    p_a_i_r_s_0 = {}
    a_v_e_0 = '__ansible_unsafe'
    ansible_j_s_o_n_decoder_0._vaults = {'default': 'default'}
    s_e_c_r_e_t_s_0 = {a_v_e_0: '__ansible_unsafe', 'default': 'default'}
    v_a_u_l_t_l_i_b_0 = VaultLib(secrets=s_e_c_r_e_t_s_0)
    ansible_v_a_u_l_t_e_n_c_r_y_p_t_e

# Generated at 2022-06-25 03:41:18.272471
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    test_var_0 = {'__ansible_vault': 'thevalue'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['thepassword'])
    result = ansible_j_s_o_n_decoder_0.object_hook(test_var_0)
    assert result.vault == ansible_j_s_o_n_decoder_0._vaults['default']


# Generated at 2022-06-25 03:41:28.129871
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Default return type of the method object_hook is AnsibleVaultEncryptedUnicode
    # Type of the parameter pairs is dict
    # Type of key is str
    # Type of value is str
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs={'__ansible_vault': 'hackme'})
    # Type of ansible_vault_encrypted_unicode_0 is AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 03:41:37.535766
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # example from:
    # https://ansible-review.googlesource.com/admin/repos/ansible/ansible/+/57c4b4f4bfc250ed2d9d9c452bc7f8a46370e3b3/lib/ansible/parsing/vault/init.py#53
    # in ansible 2.6.x
    ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib(secrets=['hello'])

# Generated at 2022-06-25 03:41:41.460630
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(None)
    assert(hasattr(ansible_j_s_o_n_decoder_0.object_hook(None), 'vault'))

# Generated at 2022-06-25 03:41:51.100920
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_v_a_l_u_e = 'ansible_value'
    ansible_v_a_l_u_e_1 = 'ansible_value_1'
    ansible_j_s_o_n_decoder_0._vaults = {'default': ansible_v_a_l_u_e_1}
    ansible_v_a_u_l_t_2 = {}
    ansible_v_a_u_l_t_2['__ansible_vault'] = ansible_v_a_l_u_e
    ansible_j_s_o_

# Generated at 2022-06-25 03:42:02.983136
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs={}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {}
    pairs={'key':'code'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {'key':'code'}
    pairs={'key':'code', 'abc':'abc'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == {'key':'code', 'abc':'abc'}

# Generated at 2022-06-25 03:42:13.375759
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    secrets = ('password')
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-25 03:42:23.853557
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1._vaults = {}
    input_1 = {'__ansible_vault': 'dummy_variable'}

    # Test cases for AnsibleJSONDecoder._vaults == {}
    with pytest.raises(AttributeError) as excinfo:
        ansible_j_s_o_n_decoder_1.object_hook(input_1)
        pytest.fail('AnsibleJSONDecoder.object_hook() should raise AttributeError when AnsibleJSONDecoder._vaults == {}')

    # Test cases for AnsibleJSONDecoder._vaults != {}
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder

# Generated at 2022-06-25 03:42:34.570514
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    input_0 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n65373638376265323432373531383963323965393431396166353438663733663164393832653736\n36373232363239366234383437643333663035376261323733633135613662346363316262326265\n6539\'\n', '__ansible_unsafe': 'string_0', 'string_0': 'string_0'}
    result = ansible_j_s_o_n_decoder_0.object_hook(input_0)
    assert result


# Generated at 2022-06-25 03:42:39.940178
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Test exception handling
    try:
        ansible_j_s_o_n_decoder_1.object_hook()
    except Exception as exc:
        print('An exception occurred: %s' % str(exc))

# Generated at 2022-06-25 03:42:48.818900
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets([])
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n3231333434353039373337423235353038343335363934303334353234393239323133333238343239\n3966323236373465363737356533653230323333306336343530333938343532383566643737666536\n6438363539373539366534'})


# Generated at 2022-06-25 03:42:54.968118
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test AnsibleJSONEncoder object_hook method
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    str = 'foo'
    ansible_j_s_o_n_decoder_1.object_hook(str)

# Generated at 2022-06-25 03:43:00.400865
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'a': 'b'}
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert result is None

# Generated at 2022-06-25 03:43:05.111631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_json_decoder_0._vaults = {'default': ansible_vault_encrypted_unicode_0}


# Generated at 2022-06-25 03:43:12.214322
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:43:16.349642
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    v0 = {'a': 'b', 'c': 'd'}
    d0 = AnsibleJSONDecoder()
    assert d0.object_hook(v0) == v0


# Generated at 2022-06-25 03:43:26.068098
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    pairs_0['__ansible_unsafe'] = 'VXNlIGluc2VjdXJlIHVybCBmb3IgdGhpcyBzb2NrZXQgaWYgbm90IHVzaW5nIFNTTC4='
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0=pairs_0)
    assert type(result_0) == AnsibleJSONEncoder.AnsibleUnsafeText

# Generated at 2022-06-25 03:43:32.698249
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:43:39.787848
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test cases
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'test_val_0'})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'test_val_1'})

# Generated at 2022-06-25 03:43:47.413281
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('secret')
    ansible_v_a_u_l_t_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('secret')

    # Equivalence classes of matching inputs to object_hook
    assert ansible_j_s_o_n_decoder_0.object_hook(dict(__ansible_vault='secret')) == ansible_v_a_u_l_t_encrypted_unicode_0, '__ansible_vault'

# Generated at 2022-06-25 03:43:57.267876
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs_0 = dict(a=1, b=2)
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets('')

    ansible_j_s_o_n_decoder_1.object_hook(pairs_0)

# Generated at 2022-06-25 03:43:59.692254
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({'key1': 'value1', 'key2': 'value2'})


# Generated at 2022-06-25 03:44:10.462195
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_vault_0 = {'some_secret': 'value0'}
    ansible_j_s_o_n_decoder_0.set_secrets(ansible_json_decoder_vault_0)


# Generated at 2022-06-25 03:44:12.510982
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    ansible_j_s_o_n_decoder_0.object_hook(pairs)

# Generated at 2022-06-25 03:44:15.744949
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:44:22.106193
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    if ansible_j_s_o_n_encoder_0._vaults:
        ansible_j_s_o_n_decoder_0._vaults['default'] = ansible_j_s_o_n_encoder_0._vaults['default']

# Generated at 2022-06-25 03:44:29.975563
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode__0 = AnsibleVaultEncryptedUnicode('test_value__6')
    ansible_j_s_o_n_decoder_0._vaults['default'] = ansible_v_a_u_l_t_encrypted_unicode__0
    pairs__1 = {'__ansible_vault': 'test_value__6'}
    ansible_j_s_o_n_d_e_c_o_d_e_r__2 = ansible_j_s_o_n_decoder_0.object_hook(pairs__1)
    ansible_v_a_u_l_t_encrypted_unic

# Generated at 2022-06-25 03:44:32.986262
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook() == None

# Generated at 2022-06-25 03:44:43.953505
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['default', 'secretvault'])
    ansible_j_s_o_n_decoder_0.object_hook({'a': 'b'})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'c'})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'd'})


# Generated at 2022-06-25 03:44:48.705048
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    assert not ansible_j_s_o_n_decoder_0.object_hook({'foo': 'bar'})


# Generated at 2022-06-25 03:44:55.012599
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['test_ansible_vaults'] = VaultLib(secrets=['test_ansible_vault_secrets'])
    ansible_j_s_o_n_decoder_0.object_hook(pairs=['test_pairs'])


# Generated at 2022-06-25 03:45:05.031711
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:45:13.254390
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {'__ansible_vault': 'ansible-vault encrypted string'}
    expected_result = AnsibleVaultEncryptedUnicode('ansible-vault encrypted string')
    actual_result = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert actual_result == expected_result


# Generated at 2022-06-25 03:45:18.998637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    yaml_0 = """foo"""
    try:
        ansible_j_s_o_n_decoder_0.object_hook(yaml_0)
    except TypeError as e:
        print(e)
        assert True

test_case_0()
test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:45:29.287109
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib(secrets=['secret_1'])

    # For now, this is just a check for the basic functionality of AnsibleJSONEncoder
    # and AnsibleJSONDecoder. This is a placeholder for more extensive checks
    # in a future PR.

# Generated at 2022-06-25 03:45:36.648755
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert not hasattr(ansible_j_s_o_n_decoder_0, "__ansible_vault")
    assert ansible_j_s_o_n_decoder_0.__ansible_vault == 'default'
    assert not hasattr(ansible_j_s_o_n_decoder_0, "__ansible_unsafe")

# Generated at 2022-06-25 03:45:39.838902
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:45:50.004930
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = VaultLib()

    # Test cases for object_hook method of class AnsibleJSONDecoder
    # Test for object hooking with variable value as a dictionary.
    input_0 = {'__ansible_vault': 'v0'}
    expected_output_0 = AnsibleVaultEncryptedUnicode('v0')
    actual_output_0 = ansible_j_s_o_n_decoder_0.object_hook(input_0)
    assert expected_output_0 == actual_output_0

    # Test for object hooking with variable value as a list.

# Generated at 2022-06-25 03:46:06.821558
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:46:10.084393
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_AnsibleJSONDecoder_object_hook.ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_case_0()
    test_AnsibleJSONDecoder_object_hook.ansible_j_s_o_n_decoder_0.object_hook(dict())


# Generated at 2022-06-25 03:46:15.112544
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # No exception thrown for object_hook
    ansible_j_s_o_n_decoder_0.object_hook(pairs={})


# Generated at 2022-06-25 03:46:22.008499
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("test")
    vault_lib_0 = VaultLib(secrets=["test"])
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    #assert ansible_json_decoder_0.object_hook() == vault_encrypted_unicode_0
    assert ansible_json_decoder_0.object_hook({'__ansible_vault': 'test'}) == vault_encrypted_unicode_0
    if vault_encrypted_unicode_0.vault != vault_lib_0:
        raise RuntimeError("AnsibleJSONDecoder.object_hook of class AnsibleJSONDecoder: assert vault_encrypted_unicode_0.vault == vault_lib_0 failed")



# Generated at 2022-06-25 03:46:28.088388
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {'a': 'b'}
    pairs = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert pairs == {'a': 'b'}


# Generated at 2022-06-25 03:46:33.276891
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['default'])
    test_AnsibleJSONDecoder_object_hook_0()


# Generated at 2022-06-25 03:46:39.296433
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj_dict = dict()

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Testing with incorrect type (pairs)
    with pytest.raises(TypeError):
        ansible_j_s_o_n_decoder_0.object_hook(obj_dict)



# Generated at 2022-06-25 03:46:47.107800
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo'})
    ansible_j_s_o_n_decoder_0.set_secrets({'default': 'foo'})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo'})
    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'foo'})

# Generated at 2022-06-25 03:46:54.512459
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Test the method and verify the results
    result = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'value_0'})
    assert result == wrap_var(AnsibleVaultEncryptedUnicode('value_0'))
    # Test the method and verify the results
    result = ansible_j_s_o_n_decoder_1.object_hook({'__ansible_unsafe': 'value_1'})
    assert result == wrap_var(wrap_var('value_1'))


# Generated at 2022-06-25 03:46:59.767702
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets('password')

# Generated at 2022-06-25 03:47:25.231302
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    src = [{'__ansible_vault': ansible_j_s_o_n_encoder_0.encode({'value': 'secret'})},
           {'__ansible_unsafe': ansible_j_s_o_n_encoder_0.encode({'value': 'not secret'})}]
    encoded_src = ansible_j_s_o_n_encoder_0.encode(src)
    decoded_src = ansible_j_s_o_n_decoder_0.decode(encoded_src)

    ansible_j_s_o_n_

# Generated at 2022-06-25 03:47:31.522940
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {}
    ansible_j_s_o_n_decoder_0.object_hook()

