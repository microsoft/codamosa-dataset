

# Generated at 2022-06-25 03:37:47.442948
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(None)


# Generated at 2022-06-25 03:37:50.957832
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()

    # Execution
    ansible_j_s_o_n_decoder.object_hook()

    # Verification
    assert True



# Generated at 2022-06-25 03:37:54.464128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    # checks if member default_ansible_vault exists in ansible_json_decoder
    if hasattr(ansible_j_s_o_n_decoder, 'default_ansible_vault'):
        ansible_j_s_o_n_decoder.default_ansible_vault = 'value'


# Generated at 2022-06-25 03:37:56.376634
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    value = None
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:37:58.745530
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook([{}])


# Generated at 2022-06-25 03:38:02.212745
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    assert decoder.decode('{"__ansible_vault": "TmFtZTogVmF1bHQ=", "key": "value"}') == \
        AnsibleVaultEncryptedUnicode('TmFtZTogVmF1bHQ=', vault=None)

# Generated at 2022-06-25 03:38:05.919410
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_json_decoder_1_object_hook = AnsibleJSONDecoder._object_hook

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_json_decoder_1_object_hook = ansible_json_decoder_1._object_hook
    ansible_json_decoder_1_object_hook({})


# Generated at 2022-06-25 03:38:14.578168
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs_0 = {'__ansible_unsafe': 'asdf'}
    pairs_1 = {'__ansible_vault': 'fdsa'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Call method object_hook of class AnsibleJSONDecoder with args pairs_0
    ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

    # Call method object_hook of class AnsibleJSONDecoder with args pairs_1
    ansible_j_s_o_n_decoder_0.object_hook(pairs_1)

# Generated at 2022-06-25 03:38:20.870209
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
#     ansible_j_s_o_n_decoder_0.object_hook(pairs: {str: object})
# assert call_0.output == expected_output_0, 'AnsibleJSONDecoder.object_hook(pairs=\'{str: object}\'): expected output = \'expected_output_0\', actual output = \'' + str(call_0.output) + '\''

# Generated at 2022-06-25 03:38:27.532154
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    with open(b'../../test/unit/parsing/vault/test_vault_data.txt', 'rb') as f:
        ansible_json_decoder.set_secrets(f.read())

# Generated at 2022-06-25 03:38:29.637953
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = None
    assert result == 'Not yet implemented'



# Generated at 2022-06-25 03:38:37.939001
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_unsafe_0 = wrap_var("ansible_unsafe_0")
    ansible_vault_1 = AnsibleVaultEncryptedUnicode("ansible_vault_1")
    return_value_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': ansible_unsafe_0, '__ansible_vault': ansible_vault_1})


# Generated at 2022-06-25 03:38:43.927692
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
# TODO fix this test
#    ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256\n353466323332363134353665366537616264326231633661316138313233343331363035666536\n363236386230653164376238393536323332646434616631323038653533386666653561303733\n643565616365373736643866346430386233313231303762366263363533373430383630313534\n3232623030623133313663316

# Generated at 2022-06-25 03:38:49.364940
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import copy
    # ---- Begin of test_AnsibleJSONDecoder_object_hook code ----
    # Canned test case for AnsibleJSONDecoder.object_hook method.
    #
    # Create the input JSON string with ansible_fact objects.
    # {
    #   "test": {
    #     "ansible_facts": {
    #       "_ansible_no_log": false,
    #       "some_ansible_fact": {
    #         "__ansible_unsafe": true,
    #         "__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          61303231346466653064663634626361356131396665363332393164383132666634663364653732\n

# Generated at 2022-06-25 03:38:57.093618
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_0 = AnsibleVaultEncryptedUnicode("__ansible_vault", "password")
    ansible_unsafe_0 = wrap_var("__ansible_unsafe", "password")
    assert ansible_j_s_o_n_decoder_0 is not None
    assert ansible_vault_0 is not None
    assert ansible_unsafe_0 is not None
    pairs = {"__ansible_vault":ansible_vault_0, "__ansible_unsafe":ansible_unsafe_0}
    assert pairs is not None
    assert pairs["__ansible_vault"] is not None
    assert pairs["__ansible_unsafe"] is not None
   

# Generated at 2022-06-25 03:39:07.262644
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_0 = {"__ansible_unsafe": "false"}
    ansible_j_s_o_n_decoder_0.object_hook(json_0)
    # Should print a string
    print(json_0)
    json_1 = {"__ansible_vault": "false"}
    ansible_j_s_o_n_decoder_0.object_hook(json_1)
    # Should print a string
    print(json_1)


# Generated at 2022-06-25 03:39:10.954146
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
# end unit test for method object_hook of class AnsibleJSONDecoder


# Generated at 2022-06-25 03:39:19.817565
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {}
    pairs_0 = {}
    for key in pairs_0:
        value = pairs_0[key]
        if key == '__ansible_vault':
            value = AnsibleVaultEncryptedUnicode(value)
            if ansible_j_s_o_n_decoder_0._vaults:
                value.vault = ansible_j_s_o_n_decoder_0._vaults['default']
            return value
        elif key == '__ansible_unsafe':
            return wrap_var(value)

    # Exercise
    result = ansible_j_s_o_n

# Generated at 2022-06-25 03:39:29.010379
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    vault_key_0 = 'vault_key'
    plain_text_0 = 'plain text'
    vault_lib_0 = VaultLib()
    AnsibleJSONDecoder.set_secrets(vault_key_0)
    vaulted_p_w_0 = vault_lib_0.encrypt(plain_text_0)
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': plain_text_0})
    assert ansible_vault_encrypted_unicode_0 == AnsibleVault

# Generated at 2022-06-25 03:39:33.349267
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test the method object_hook of class AnsibleJSONDecoder
    """
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:39:37.767481
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Case 0
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    pairs['__ansible_vault'] = '123'
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == AnsibleVaultEncryptedUnicode('123')



# Generated at 2022-06-25 03:39:49.311339
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Variable input_1 of type list

# Generated at 2022-06-25 03:39:59.144350
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible_j_s_o_n_decoder[0] -> AnsibleJSONDecoder
    ansible_j_s_o_n_decoder[0]._vaults['default'] = ansible_vault_lib[0]
    ansible_j_s_o_n_decoder[0].object_hook({'__ansible_vault': 'VgBfDxA3CxANB3AHBwAIBGAGDwAOCg8A'})
    ansible_j_s_o_n_decoder[0].object_hook({'__ansible_unsafe': 'PHAgY2xhc3M9InRleHQiPnBsYXNlIGhlcmU8L3A+'})


# Generated at 2022-06-25 03:40:04.140641
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    try:
        pairs_0 = {}
        ansible_j_s_o_n_decoder_0.object_hook(pairs=pairs_0)
    except TypeError as e1:
        assert e1
    else:
        raise AssertionError('Raised no TypeError')


# Generated at 2022-06-25 03:40:14.967082
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.encoding = 'utf-8'
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.encoding = 'utf-8'
    secret = 'somesecret'
    ansible_json_decoder_0.set_secrets([secret])
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_0.vault = VaultLib(secrets=[secret])
    ansible_vault_encrypted_unicode_0.vault.decrypt()

# Generated at 2022-06-25 03:40:27.179452
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:40:38.556581
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Set secret to test AnsibleVaultEncryptedUnicode
    ansible_j_s_o_n_decoder_0.set_secrets(b"my secret")
    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 03:40:45.576390
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:40:53.552056
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_json_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_1.set_secrets(ansible_json_encoder_1.secrets)

    try:
        ansible_j_s_o_n_decoder_1.object_hook()
    except:
        pass               # Expected exception


# Generated at 2022-06-25 03:40:56.834623
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets("bar")
    pairs = {}
    output = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert output == {}
    #assert output == 'AnsibleVaultEncryptedUnicode'



# Generated at 2022-06-25 03:41:09.430773
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Init AnsibleJSONDecoder
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    fake_secret = ['notsosecurepassword']
    vault_string = ansible_j_s_o_n_encoder_0.encode({'__ansible_vault': fake_secret})

    ansible_j_s_o_n_decoder_0.set_secrets(fake_secret)
    secret = ansible_j_s_o_n_decoder_0.decode(vault_string)

    assert type(secret['__ansible_vault']) == AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 03:41:13.874082
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook(pairs={'a':1, 'b':2})

# Generated at 2022-06-25 03:41:20.404491
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.object_hook({'a':'b'})

# Generated at 2022-06-25 03:41:27.053542
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    with pytest.raises(TypeError):
        instance = AnsibleJSONDecoder()
        ansible_j_s_o_n_decoder_obj = ansible_j_s_o_n_decoder.object_hook()

# Generated at 2022-06-25 03:41:37.383714
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    o_b_j_e_c_t_p_a_i_r_s_0 = dict()
    o_b_j_e_c_t_p_a_i_r_s_0['__ansible_vault'] = None
    o_b_j_e_c_t_p_a_i_r_s_0['__ansible_unsafe'] = None
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    p_a_i_r_s_0 = None
    e_x_p_e_c_t_e_d_0 = None
    a_c_t_u_a_l_0 = ansible

# Generated at 2022-06-25 03:41:44.839245
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    json_0 = '''{
    "__ansible_vault": "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGH"
}'''
    vault_secret_0 = "foobar"
    ansible_j_s_o_n_decoder_0.set_secrets(vault_secret_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(json_0)

# Generated at 2022-06-25 03:41:50.763633
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    secrets = None
    pairs = None
    ansible_j_s_o_n_decoder_1.set_secrets(secrets)
    ansible_j_s_o_n_decoder_1.object_hook(pairs)

# Generated at 2022-06-25 03:42:02.947226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    a = {}
    assert a == AnsibleJSONDecoder().object_hook(a)


# Generated at 2022-06-25 03:42:11.015509
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {'__ansible_vault': 'test_value_1', '__ansible_unsafe': 'test_value_2'}
    pairs_1 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert pairs_1['__ansible_vault'] == 'test_value_1'
    assert pairs_1['__ansible_unsafe'] == 'test_value_2'


# Generated at 2022-06-25 03:42:22.480061
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0_str_0 = '__ansible_vault'
    pairs_0_str_1 = 'AQAAMO4sL4F/zHMHmDz0Fm73mDv/8AA=='
    pairs_0_tuple = (pairs_0_str_0, pairs_0_str_1)
    pairs_0 = dict((pairs_0_tuple,))
    res_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

# Generated at 2022-06-25 03:42:35.213561
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    # Create an object of which contains class variables, to test the object_hook method of AnsibleJSONDecoder
    y_a_m_l_vault_0 = VaultLib()
    # Create an object to be used to test the AnsibleJSONDecoder.object_hook method
    s_t_r_1 = '{ "__ansible_vault": "1" }'
    # Call the AnsibleJSONDecoder.object_hook method to decode the text
    ansible_j_s_o_n_decoder_decode_0 = AnsibleJSONDecoder.object_hook(s_t_r_1, vault=y_a_m_l_vault_0)

    # Create an object to be used to test the AnsibleJSONDecoder.object_hook method

# Generated at 2022-06-25 03:42:44.459408
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    with open('tests/unit/parsing/parsing_utils/fixtures/test_AnsibleJSONDecoder_object_hook.json') as f:
        ansible_j_s_o_n_decoder_0.set_secrets([f.read()])

    with open('tests/unit/parsing/parsing_utils/fixtures/test_AnsibleJSONDecoder_object_hook.json') as f:
        assert ansible_j_s_o_n_decoder_0.object_hook(json.load(f))

# Generated at 2022-06-25 03:42:49.912285
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    pairs = dict()
    pairs['__ansible_vault'] = ansible_vault_encrypted_unicode_0
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert type(result) == dict


# Generated at 2022-06-25 03:42:52.013314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-25 03:42:57.315679
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = dict()
    value = dict()
    value.update({"secret": "donttellanyone"})
    pairs.update({"__ansible_vault": value})
    ansible_json_decoder.object_hook(pairs)

# Generated at 2022-06-25 03:42:59.044408
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:43:07.113406
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets=[b'Test_Vault_Secret_0'])
    pairs_0 = dict()
    pairs_0['__ansible_vault'] = 'Some_value'
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)
    assert result_0.vault.secrets == [b'Test_Vault_Secret_0']



# Generated at 2022-06-25 03:43:13.179500
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_pass = False
    # Encrypting the string "hello world" with the password "test" in a vault file
    secrets = ['test']
    ansible_j_s_o_n_decoder_0.set_secrets(secrets)
    # Ensure the object_hook method returns a AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-25 03:43:20.264874
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Assign values to variables for testing method
    pairs = {'__ansible_vault': 'value'}

    assertion = ansible_j_s_o_n_decoder_1.object_hook(pairs)

    assert assertion != None


# Generated at 2022-06-25 03:43:28.328844
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_0.set_secrets(['password'])
    ansible_j_s_o_n_decoder_0.set_secrets(['password'])

    ansible_json_decoder_0._raw_decode = AnsibleJSONDecoder._raw_decode

# Generated at 2022-06-25 03:43:43.170105
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    output_0 = dict()

# Generated at 2022-06-25 03:43:51.470829
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Example:
    # pairs = {'__ansible_vault': '....'}
    #ansible_j_s_o_n_decoder_0.object_hook(pairs)
    # pairs = {'__ansible_unsafe': {'user': 'test'}}
    #ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:43:56.220056
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs={'__ansible_vault': {'temp': '0'}, '__ansible_unsafe': {'temp': '0'}})


# Generated at 2022-06-25 03:43:58.822682
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['test_pass'])
    str_0 = '{"__ansible_vault": ""}'
    # AnsibleJSONDecoder.object_hook(pairs)
    ansible_j_s_o_n_decoder_0.object_hook(json.loads(str_0))


# Generated at 2022-06-25 03:44:00.889444
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    
    ansible_j_s_o_n_decoder_0.object_hook({})


# Generated at 2022-06-25 03:44:11.214278
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:44:13.355005
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

#  Unit test for method set_secrets of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:44:15.810305
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:44:23.614464
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # encoding: utf-8
    # immutable_pairs = {"__ansible_vault": "This is a vault test string", "__ansible_unsafe": "This is an unsafe string"}
    # ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # result = ansible_j_s_o_n_decoder_0.object_hook(immutable_pairs)
    # assert type(result["__ansible_unsafe"]) == type(wrap_var(""))
    # assert type(result["__ansible_vault"]) == type(AnsibleVaultEncryptedUnicode(""))
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1

# Generated at 2022-06-25 03:44:28.963266
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook()


# Generated at 2022-06-25 03:44:52.697402
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0 == ansible_j_s_o_n_decoder_0.object_hook


# Generated at 2022-06-25 03:44:57.066246
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['vault'])
    assert AnsibleVaultEncryptedUnicode('vault').vault.secrets == ['vault']


# Generated at 2022-06-25 03:45:01.354866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0) is not None


# Generated at 2022-06-25 03:45:11.922375
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:45:18.225548
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0.object_hook({"__ansible_unsafe": ansible_json_encoder_0})

# Generated at 2022-06-25 03:45:24.710355
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook({'ansible_vault': 'something'}), dict)

# Generated at 2022-06-25 03:45:28.939657
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup and unpack parameter
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['default'])  # Type: list

    # Execute the code to be tested
    pairs = {
        '__ansible_vault': 'Foo',
        '__ansible_unsafe': 'Bar'
    }
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)

    # Verify the result
    assert type(result['__ansible_vault']) is AnsibleVaultEncryptedUnicode
    assert type(result['__ansible_unsafe']) is str



# Generated at 2022-06-25 03:45:38.845150
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
  ansible_j_s_o_n_decoder_0_obj_hook_arg_0 = { '__ansible_vault': 'foo', '__ansible_unsafe': 'bar' }
  ansible_j_s_o_n_decoder_0_obj_hook_arg_1 = {}
  ansible_j_s_o_n_decoder_0_obj_hook_ret_0 = { '__ansible_vault': unicode('foo'), '__ansible_unsafe': 'bar' }

# Generated at 2022-06-25 03:45:49.334828
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j_s_o_n_s_e_c_r_e_t = '$ANSIBLE_TEST_VAULT_PASSWORD'

    AnsibleJSONDecoder.set_secrets(j_s_o_n_s_e_c_r_e_t)

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:45:54.968528
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    #pairs = {'__ansible_unsafe': '{{ some_secret_string }}'}
    pairs = {'__ansible_vault': 'some_encrypted_string'}
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder.object_hook(pairs)


# Generated at 2022-06-25 03:46:43.076270
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {
        '__ansible_unsafe': 'hello',
        '__ansible_vault': 'world'
    }

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.set_secrets('pass')

    ansible_j_s_o_n_decoder_0._vaults['default'].decrypt('world')
    ansible_j_s_o_n_decoder_0.object_hook(obj)

    if obj != {'__ansible_unsafe': wrap_var('hello')}:
        raise AssertionError('AnsibleJSONDecoder.object_hook did not return the expected result')


# Generated at 2022-06-25 03:46:51.577372
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['secret0'])
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("0")
    ansible_vault_encrypted_unicode_0.vault = ansible_j_s_o_n_decoder_0._vaults['default']
    ansible_j_s_o_n_decoder_0._vaults['default']._secrets.append("secret0")
    pairs_0 = {"__ansible_vault": "0"}
    ret = ansible_j_s_o_n_decoder_0.object_hook(pairs_0)

# Generated at 2022-06-25 03:47:00.150322
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': True, '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}) == wrap_var(True)


# Generated at 2022-06-25 03:47:07.807038
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # params
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256', '__ansible_unsafe': '$REDACT'}
    # expected
    expected = "AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256', vault=VaultLib(secrets=None))"
    assert str(ansible_j_s_o_n_decoder_0.object_hook(pairs)) == expected


# Generated at 2022-06-25 03:47:14.794462
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    str_0 = '{"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3535373933633631653337342d393435332d33303366342d39663837342d633362626239646336316234\n          313761\n          "}'
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(json.loads(json.loads(str_0)))

# Generated at 2022-06-25 03:47:22.199071
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    data_0 = {"A": "B"}
    result_0 = ansible_j_s_o_n_decoder_0.object_hook(data=data_0)
    assert data_0 == result_0

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-25 03:47:27.058124
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets='foo')
    ansible_unsafe_pairs = 'foo'
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs=ansible_unsafe_pairs) == wrap_var(var='foo')


# Generated at 2022-06-25 03:47:32.470553
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0_object_hook_0_0 = ansible_j_s_o_n_decoder_0.object_hook()
    assert ansible_j_s_o_n_decoder_0_object_hook_0_0 is None


# Generated at 2022-06-25 03:47:35.181338
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = dict()
    result = ansible_j_s_o_n_decoder_0.object_hook(pairs)


# Generated at 2022-06-25 03:47:43.526012
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # Test the '__ansible_vault' key
    ansible_j_s_o_n_decoder_0.set_secrets(['1'])
    vault_key = ansible_j_s_o_n_encoder_0.encode(['ansible_vault_encrypted_content_0'])
    vault_value = ansible_j_s_o_n_encoder_0.encode('hello')