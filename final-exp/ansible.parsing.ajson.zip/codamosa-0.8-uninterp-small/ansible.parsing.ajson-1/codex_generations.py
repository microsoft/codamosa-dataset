

# Generated at 2022-06-25 03:37:41.282165
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs={}) # placeholder for test, no real data



# Generated at 2022-06-25 03:37:45.002608
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    # no assertion required, just test if it runs without exception

    ansible_j_s_o_n_decoder_0.object_hook(pairs={})



# Generated at 2022-06-25 03:37:53.136308
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:37:57.242273
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'foo'}
    res = ansible_json_decoder.object_hook(pairs)
    exp = {'__ansible_vault': 'foo'}

    assert res == exp


# Generated at 2022-06-25 03:38:01.544098
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('hello')
    pairs_0 = {'__ansible_vault': 'hello'}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs_0) == ansible_vault_encrypted_unicode_0

# Generated at 2022-06-25 03:38:08.035000
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    dict_0 = dict()
    dict_0['__ansible_vault'] = "foo"
    dict_0['__ansible_unsafe'] = "foo"
    ansible_j_s_o_n_decoder_0.object_hook(dict_0)


# Generated at 2022-06-25 03:38:18.770609
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:38:24.391371
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder.parse('{}')
    ansible_j_s_o_n_decoder.parse('{"foo": "bar"}')


# Generated at 2022-06-25 03:38:32.067796
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Testing parameters
    pairs = {"a": "b"}
    ansible_j_s_o_n_decoder_0.set_secrets(pairs)
    # Testing return type
    assert isinstance(ansible_j_s_o_n_decoder_0.object_hook(pairs), dict)

# Generated at 2022-06-25 03:38:38.068794
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults = {'default': VaultLib()}

# Generated at 2022-06-25 03:38:41.679274
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    pairs = dict()
    assert isinstance(ansible_j_s_o_n_decoder.object_hook(pairs), dict)

# Generated at 2022-06-25 03:38:50.459990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0._vaults['default'] = {}
    ansible_j_s_o_n_decoder_0._vaults['default']._secrets = {}
    string_0 = '!!!ANSIBLE VAULT!!!\n'
    string_0 += '$ANSIBLE_VAULT;1.2;AES256'
    string_0 += '\n63337065393866333536663839616464'
    string_0 += '\n34626461613764666631366433323334'
    string_0 += '\n32653436373364656539643734373930'

# Generated at 2022-06-25 03:38:57.852975
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for error cases
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test for success cases
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(b'\x00\x00\x00\x00\x00')

# Generated at 2022-06-25 03:39:06.801548
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_object_hook = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:39:18.310903
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:39:25.607835
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    pairs = dict()
    key = 'test1'
    value = 'testvalue'
    pairs[key] = value

    ansible_j_s_o_n_encoder_0.method_check(False)
    ret = ansible_j_s_o_n_decoder_0.object_hook(pairs)
    assert ret == pairs

# Generated at 2022-06-25 03:39:33.273077
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_decoder_0.set_secrets('12345')
    # Testing json loads with object_hook
    with open('/etc/ansible/hosts') as hosts_file:
        ansible_hosts_str = hosts_file.read()
    ansible_hosts_json = json.loads(ansible_hosts_str, cls=AnsibleJSONDecoder)
    assert isinstance(ansible_hosts_json, dict)

    # Testing json dumps with cls=AnsibleJSONEncoder
    ansible_hosts_back_to_str = json.dumps(ansible_hosts_json, cls=AnsibleJSONEncoder)
    ansible

# Generated at 2022-06-25 03:39:43.422524
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    values_1 = {"__ansible_vault": "some encrypted data", "__ansible_unsafe": "some unsafe data"}
    values_1_fallback = values_1.copy()
    ret_1 = ansible_j_s_o_n_decoder_1.object_hook(values_1)
    assert ret_1['__ansible_vault'] is not None
    assert ret_1['__ansible_unsafe'] is not None
    assert isinstance(ret_1['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(ret_1['__ansible_unsafe'], bytes)
    assert values_1 == values_1_fallback

# Generated at 2022-06-25 03:39:49.479450
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets('mysecret')
    ansible_j_s_o_n_decoder_1.object_hook({'__ansible_vault': 'myvault', '__ansible_unsafe': 'myunsafe'})

# Generated at 2022-06-25 03:39:55.618981
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({}) == {}
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo'}) == 'foo'


# Generated at 2022-06-25 03:40:05.213201
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    input_json_0 = '{"__ansible_vault": "my_encrypted_value"}'
    expected_value = AnsibleVaultEncryptedUnicode('my_encrypted_value')
    ansible_j_s_o_n_decoder_0.set_secrets(['hunter2'])
    result = ansible_j_s_o_n_decoder_0.decode(input_json_0)
    assert (result == expected_value)



# Generated at 2022-06-25 03:40:11.187716
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_var_1 = {"__ansible_unsafe":"__ansible_unsafe__"}
    test_input_str_1 = json.dumps(test_var_1)
    test_out_1 = ansible_j_s_o_n_decoder_0.decode(test_input_str_1)
    assert test_out_1 == wrap_var(test_var_1['__ansible_unsafe'])


# Generated at 2022-06-25 03:40:18.098741
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    # Test 1:

# Generated at 2022-06-25 03:40:23.503575
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(
        {'__ansible_unsafe': 'abc'}
    )


# Generated at 2022-06-25 03:40:25.124203
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:40:29.810594
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    input_result_pairs = {}
    result = ansible_j_s_o_n_decoder_0.object_hook(input_result_pairs)
    assert result == {}


# Generated at 2022-06-25 03:40:40.814113
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:40:48.250585
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    test_pairs_0 = {"__ansible_vault": "yYBBikTQ2BQKjwL8T7Wyd6U="}
    assert ansible_j_s_o_n_decoder_0.object_hook(test_pairs_0) == {"__ansible_vault": "yYBBikTQ2BQKjwL8T7Wyd6U="}

# Generated at 2022-06-25 03:40:56.118288
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': 'test_value_2', '__ansible_unsafe': 'test_value_3', }
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    # Write code that will call the method under test
    result = ansible_j_s_o_n_encoder.encode()
    assert result == '{"__ansible_vault": "test_value_2", "__ansible_unsafe": "test_value_3"}'

# Generated at 2022-06-25 03:40:59.108180
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:41:11.951088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('secret')
    p = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\ntest\n'}
    assert isinstance(decoder.object_hook(p)['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    p = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.2;AES256;test\ntest\n'}
    assert isinstance(decoder.object_hook(p)['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 03:41:14.580775
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Test case
    ansible_j_s_o_n_decoder_0.object_hook({"test": 'test'})


# Generated at 2022-06-25 03:41:27.766416
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    vault_lib_0 = VaultLib()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('value', vault_lib_0)
    ansible_vault_encrypted_unicode_1.vault = vault_lib_0
    ansible_vault_encrypted_unicode_1.vault_secret = 'default'
    ansible_vault_encrypted_unicode_1.unicode_value = 'value'
    ansible_vault_encrypted_unicode_1.unicode_text = 'value'
    ansible_vault_encrypted_unicode_1.text

# Generated at 2022-06-25 03:41:37.446778
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:41:44.885376
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_vault_lib_0 = VaultLib()

    ansible_vault_lib_0.secrets = ['password']

    ansible_j_s_o_n_decoder_0.set_secrets(ansible_vault_lib_0.secrets)


# Generated at 2022-06-25 03:41:48.617080
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(value='')
    pairs_0 = {'__ansible_vault': ansible_v_a_u_l_t_encrypted_unicode_0}
    assert(ansible_j_s_o_n_decoder_0.object_hook(pairs_0) == pairs_0)


# Generated at 2022-06-25 03:41:53.758489
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_instance = AnsibleJSONDecoder()

    assert ansible_json_decoder_instance.object_hook() is None
    assert ansible_json_decoder_instance.object_hook({}) is None


# Generated at 2022-06-25 03:41:59.669563
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    # Run the method
    ansible_j_s_o_n_decoder_0.object_hook(ansible_v_a_u_l_t_encrypted_unicode_0)

# Generated at 2022-06-25 03:42:06.872350
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    # Default args
    assert ansible_json_decoder_0.object_hook({}) == {}, "The returned value is wrong"
    # 1 args
    assert ansible_json_decoder_0.object_hook({'test_key': 'test_value'}) == {'test_key': 'test_value'}, "The returned value is wrong"


# Generated at 2022-06-25 03:42:14.533593
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Should raise a json.JSONDecodeError when given an invalid JSON string
    try:
        ansible_j_s_o_n_decoder_0.object_hook('INVALID_JSON')
    except json.JSONDecodeError:
        assert True
    else:
        assert False

    # Should have the following output when given a valid JSON string
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets('secret123')

# Generated at 2022-06-25 03:42:23.955949
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    value_0 = {'item_one' : 1, 'item_two' : 2,}

    # Test with the default for
    # the __ansible_unsafe__key
    # being False
    actual_1 = ansible_j_s_o_n_decoder_2.object_hook(value_0)
    assert actual_1 == value_0


# Generated at 2022-06-25 03:42:31.869980
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['Kjbx9pJFyD+4C4PDdSF1Qw=='])
    ansible_j_s_o_n_decoder_0.object_hook({'a': 'b'})

# Generated at 2022-06-25 03:42:37.651602
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs = {}
    assert ansible_j_s_o_n_decoder_0.object_hook(pairs) == pairs


# Generated at 2022-06-25 03:42:40.946942
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert(ansible_j_s_o_n_decoder_0.object_hook == None)


# Generated at 2022-06-25 03:42:43.835422
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    ansible_json_decoder_1 = AnsibleJSONDecoder()

# Tests for class AnsibleJSONDecoder

# Generated at 2022-06-25 03:42:49.185928
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'encrypted-value'}
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Act
    result = ansible_json_decoder_0.object_hook(pairs)
    # Assert
    assert isinstance(result, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-25 03:42:53.457559
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert ansible_j_s_o_n_decoder_0.object_hook() == expected_results_0


# Generated at 2022-06-25 03:43:01.564211
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder(
        )

# Generated at 2022-06-25 03:43:04.478048
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(['a'])
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')

# Generated at 2022-06-25 03:43:12.128217
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # Some tests to cover the Vault block (which is modelled after Yaml's
    # object_representer)
    # no vault data
    test_dict = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256', u'secret': u'secretdata'}
    assert ansible_j_s_o_n_decoder_0.object_hook(test_dict) == test_dict
    # with vault data
    test_dict = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256', u'secret': u'secretdata'}
    AnsibleJSONDecoder.set_secrets('password')


# Generated at 2022-06-25 03:43:25.103671
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == {'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}

# Generated at 2022-06-25 03:43:27.328401
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_1 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:43:35.127615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    secret = 'bar'
    AnsibleJSONDecoder.set_secrets([secret])
    # Call
    result_0 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'foo'})
    result_1 = ansible_j_s_o_n_decoder_0.object_hook({'__ansible_unsafe': 'var'})
    # Verify
    assert(result_0.decrypt(secret) == 'foo')
    assert(result_1.get_value() == 'var')

# Generated at 2022-06-25 03:43:39.759470
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_obj = AnsibleJSONDecoder()

    # Providing a wrong type of argument 'wrong_arg' to the method
    # object_hook of class AnsibleJSONDecoder
    with pytest.raises(TypeError) as excinfo:
        ansible_json_decoder_obj.object_hook(wrong_arg)
    assert 'object_hook() takes exactly 2 arguments (1 given)' in str(excinfo.value)



# Generated at 2022-06-25 03:43:42.989437
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()


# Generated at 2022-06-25 03:43:48.725963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_decoder_0._vaults = {'default': ansible_vault_encrypted_unicode_0}
    assert ansible_j_s_o_n_decoder_0.object_hook({'__ansible_vault': 'abcdefg'}) == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 03:43:56.182926
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Check that method object_hook is returning a dict
    assert isinstance(test_case_0.ansible_j_s_o_n_decoder_0.object_hook({'a': 'b'}), dict)


# Generated at 2022-06-25 03:44:01.644217
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_v_a_u_l_t_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_v_a_u_l_t_encrypted_unicode_0.vault = ansible_j_s_o_n_decoder_0._vaults.get('default')
    ansible_j_s_o_n_decoder_0.object_hook({"__ansible_vault": ansible_v_a_u_l_t_encrypted_unicode_0})

# Generated at 2022-06-25 03:44:08.090914
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    key_value = {"a":1}
    ansible_json_decoder_object_hook_0 = AnsibleJSONDecoder.object_hook(key_value)
    assert ansible_json_decoder_object_hook_0 is not None


# Generated at 2022-06-25 03:44:12.586608
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO: Add test cases for object_hook
    # The code of test_case_0 is commented because the method object_hook of class AnsibleJSONDecoder
    # raises: TypeError: 'str' object is not callable
    # ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # ansible_j_s_o_n_decoder_0.object_hook()
    pass


# Generated at 2022-06-25 03:44:22.646987
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook('pairs')



# Generated at 2022-06-25 03:44:26.500040
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_lib_0 = VaultLib()
    ansible_vault_enc_unsafe_0 = AnsibleVaultEncryptedUnicode()
    ansible_j_s_o_n_encoder_0.vault = ansible_vault_lib_0
    ansible_vault_enc_unsafe_0.vault = ansible_vault_lib_0
    ansible_vault_enc_unsafe_0.data = 'abc123'
    ansible_vault_enc_unsafe_0.vault_id = ansible_vault_enc_unsafe_0.v

# Generated at 2022-06-25 03:44:34.037378
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    assert ansible_j_s_o_n_decoder_0 is not None, "AnsibleJSONDecoder Object not initialized"

    assert ansible_j_s_o_n_decoder_0.object_hook({"key": "value"}) is not None, "Modified dictionary: {}".format(ansible_j_s_o_n_decoder_0.object_hook({"key": "value"}))



# Generated at 2022-06-25 03:44:40.191488
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.object_hook({'var': '2'})


# Generated at 2022-06-25 03:44:46.264674
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Mock the result of __ansible_vault
    with patch('ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode') as mock_ansible_vault_encrypted_unicode_0:
        mock_ansible_vault_encrypted_unicode_0.return_value.vault = VaultLib()

        # Call AnsibleJSONDecoder.object_hook
        result = AnsibleJSONDecoder.object_hook(
            {'__ansible_vault': AnsibleVaultEncryptedUnicode()})
        assert result == mock_ansible_vault_encrypted_unicode_0.return_value

    # Mock the result of __ansible_unsafe
    with patch('ansible.utils.unsafe_proxy.wrap_var') as mock_wrap_var_1:
        mock

# Generated at 2022-06-25 03:44:54.907951
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    object_hook_pairs = {}
    object_hook_pairs['__ansible_vault'] = 'AnsibleVaultEncryptedUnicode'
    object_hook_pairs['__ansible_unsafe'] = 'wrap_var'
    result = ansible_j_s_o_n_decoder_0.object_hook(object_hook_pairs)
    assert type(result) == dict
    assert '__ansible_vault' in result
    assert type(result['__ansible_vault']) == AnsibleVaultEncryptedUnicode
    assert '__ansible_unsafe' in result
    assert result['__ansible_unsafe'] == 'wrap_var'


# Generated at 2022-06-25 03:44:58.557474
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(secrets=None)
    object_hook = ansible_j_s_o_n_decoder_0.object_hook()
    assert object_hook is not None

# Generated at 2022-06-25 03:45:02.367070
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    my_dict = {}
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_decoder_0.object_hook(my_dict)

# Generated at 2022-06-25 03:45:07.751479
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    dict = dict(key = 0)
    dict = json.dumps(dict)
    dict = AnsibleJSONDecoder.object_hook(dict)
    assert dict == dict

# Generated at 2022-06-25 03:45:13.254835
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j_s_o_n_d_0 = AnsibleJSONDecoder()
    j_s_o_n_d_0.set_secrets('fubar')
    j_s_o_n_d_0.object_hook({})


# Generated at 2022-06-25 03:45:37.594418
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    x = u'{ "__ansible_unsafe": "hello world" }'
    y = u'{ "__ansible_vault": "hello world" }'
    secrets = ['this is a password']

    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_1.set_secrets(secrets)

    z = json.loads(x, cls=ansible_j_s_o_n_decoder_1.__class__)
    assert z['__ansible_unsafe'] == 'hello world'

    z = json.loads(y, cls=ansible_j_s_o_n_decoder_1.__class__)

# Generated at 2022-06-25 03:45:43.305313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.object_hook(pairs=None) # TypeError: unhashable type: 'NoneType'

# Generated at 2022-06-25 03:45:54.505333
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Routine to test decoding a JSON string
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

# Generated at 2022-06-25 03:45:59.387434
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    pairs_0 = {}
    keys_0 = ['__ansible_unsafe']
    assert not ansible_j_s_o_n_decoder_0.object_hook(pairs_0) == keys_0
    assert not pairs_0 == keys_0


# Generated at 2022-06-25 03:46:03.544997
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook('pairs') == 'pairs'


# Generated at 2022-06-25 03:46:08.051196
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test 0
    set_secrets(['hello_world'])
    assert 0 == 0


# Generated at 2022-06-25 03:46:15.234842
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    #
    # Test hash properties.
    #
    data = json.loads('{"__ansible_vault": "asdf", "__ansible_unsafe": "abcdefg"}', cls=AnsibleJSONDecoder)

    assert isinstance(data, dict)
    assert len(data) == 2
    assert data['__ansible_vault'] == "asdf"
    assert data['__ansible_unsafe'] == "abcdefg"


# Generated at 2022-06-25 03:46:17.549141
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder_0 = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder_0.object_hook({}), dict)

# Generated at 2022-06-25 03:46:30.143903
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-25 03:46:36.759306
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_0.set_secrets(['test'])
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('''test''')
    ansible_vault_encrypted_unicode_0 = ansible_j_s_o_n_decoder_0.object_hook(
        {'__ansible_vault': ansible_vault_encrypted_unicode_0})
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('''test''')
    ansible_vault_encrypted_unicode_1 = ansible_j_s_o_n_decoder_0

# Generated at 2022-06-25 03:47:15.757116
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    # TODO: Validate correct behavior of AnsibleJSONDecoder.object_hook


# Generated at 2022-06-25 03:47:20.915190
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()
    assert ansible_j_s_o_n_decoder_0.object_hook() == {}



# Generated at 2022-06-25 03:47:25.891565
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    ansible_j_s_o_n_decoder = AnsibleJSONDecoder()
    pairs = dict()

    # Exercise
    res = ansible_j_s_o_n_decoder.object_hook(pairs)

    # Verify
    assert res == {}


# Generated at 2022-06-25 03:47:31.332091
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_0 = AnsibleJSONDecoder()

    result = ansible_j_s_o_n_decoder_0.object_hook('')
    assert result == {}


# Generated at 2022-06-25 03:47:41.471353
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_j_s_o_n_decoder_1 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2 = AnsibleJSONDecoder()
    ansible_j_s_o_n_decoder_2.set_secrets([{'vault_id': '0x600a54b4ebf6', 'vault_password': 'bar'}])
    result = ansible_j_s_o_n_decoder_2.object_hook({'__ansible_unsafe': 'msg'})
    assert result == 'msg'
    assert result == wrap_var('msg')