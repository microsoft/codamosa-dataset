

# Generated at 2022-06-17 05:49:11.007173
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:49:23.268553
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:30.486650
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    if sys.version_info[0] < 3:
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleJSONDecoder(unittest.TestCase):

        def test_object_hook(self):
            decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:43.813180
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:57.532962
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:50:06.397490
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:50:17.475953
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:27.275133
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:38.594568
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test', 'test': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:50:50.197300
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n'}) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n')
    assert decoder.object_hook({'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n'}) == wrap_var('$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n')

# Generated at 2022-06-17 05:50:57.189901
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:51:10.194106
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for the __ansible_vault key

# Generated at 2022-06-17 05:51:18.083908
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:28.843192
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:51:39.068789
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:51:51.114770
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:00.270911
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:10.730379
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:22.652932
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:52:35.228230
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:52:41.284680
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:48.318416
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for wrap_var
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

# Generated at 2022-06-17 05:52:56.118159
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for __ansible_vault

# Generated at 2022-06-17 05:53:06.043321
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:21.524208
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:30.238282
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:36.281530
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:44.639855
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:53:59.687375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:10.279566
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:22.662491
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'vault'}) == AnsibleVaultEncryptedUnicode('vault')
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe'}) == wrap_var('unsafe')
    assert decoder.object_hook({'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe'}) == AnsibleVaultEncryptedUnicode('vault')
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe', '__ansible_vault': 'vault'}) == wrap_var('unsafe')

# Generated at 2022-06-17 05:54:34.032183
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:44.196297
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:55.610032
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)
    assert decoder.object_hook({'__ansible_vault': 'test'}).vault.secrets == ['test']

    # Test for AnsibleUnsafeText
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)
    assert decoder.object_hook({'__ansible_unsafe': 'test'}).value == 'test'

# Generated at 2022-06-17 05:55:06.829805
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])
    assert isinstance(decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n393935376664356537383534663334373537333734663735353736343336393537666435653738353466333437353733373466373535373634333639\n'}), AnsibleVaultEncryptedUnicode)

    # Test with __ansible_unsafe
    assert wrap_var('test') == decoder.object_hook({'__ansible_unsafe': 'test'})

# Generated at 2022-06-17 05:55:17.040066
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:31.989103
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:55:36.681350
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')


# Generated at 2022-06-17 05:55:50.784809
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:00.657549
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:56:11.397887
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:23.943878
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for __ansible_vault

# Generated at 2022-06-17 05:56:34.119576
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:48.147719
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with vault
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_text = vault_text.replace('\n', '')
    vault_text = vault_text.replace('\r', '')
    vault_text = vault_text.replace(' ', '')
    vault_text = vault_text.replace('\t', '')
    vault_text = vault_text.replace('\x0b', '')
    vault_text = vault_text.replace('\x0c', '')


# Generated at 2022-06-17 05:56:59.399770
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:57:10.588541
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:57:24.120079
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:38.510688
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:57:48.160310
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test_value'}) == AnsibleVaultEncryptedUnicode('test_value')
    assert decoder.object_hook({'__ansible_unsafe': 'test_value'}) == wrap_var('test_value')
    assert decoder.object_hook({'__ansible_vault': 'test_value', '__ansible_unsafe': 'test_value'}) == AnsibleVaultEncryptedUnicode('test_value')

# Generated at 2022-06-17 05:58:01.560496
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:58:23.012949
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:58:33.194574
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:58:42.896297
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:58:57.249401
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test AnsibleJSONDecoder.object_hook()
    """
    # Test with __ansible_vault

# Generated at 2022-06-17 05:59:06.410435
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()