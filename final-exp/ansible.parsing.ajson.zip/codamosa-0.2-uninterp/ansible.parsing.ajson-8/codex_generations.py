

# Generated at 2022-06-17 05:49:21.138888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:29.581394
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEnc

# Generated at 2022-06-17 05:49:42.766203
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:57.419203
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:03.392324
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:17.105888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:27.210136
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:37.770948
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == wrap_var('foo')

# Generated at 2022-06-17 05:50:51.935961
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:50:59.738646
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:12.734204
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:51:23.242615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

    # Test with __ansible_unsafe
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')

    # Test with other key
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:51:31.944366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:45.678880
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:53.488722
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    result = decoder.object_hook({'__ansible_vault': 'test'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None
    assert result.vault.secrets == ['test']

    # Test for unsafe
    result = decoder.object_hook({'__ansible_unsafe': 'test'})
    assert isinstance(result, wrap_var)
    assert result.__str__() == 'test'

    # Test for normal
    result = decoder.object_hook({'__ansible_normal': 'test'})
    assert result == {'__ansible_normal': 'test'}

# Generated at 2022-06-17 05:52:02.218931
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    data = json.loads('{"__ansible_vault": "test"}', cls=decoder)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is not None
    assert data.vault.secrets == ['test']

    # Test with unsafe
    decoder = AnsibleJSONDecoder()
    data = json.loads('{"__ansible_unsafe": "test"}', cls=decoder)
    assert isinstance(data, wrap_var)
    assert data.value == 'test'

# Generated at 2022-06-17 05:52:11.199711
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_vault': 'bar'})

# Generated at 2022-06-17 05:52:22.695294
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:52:34.541587
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for wrap_var
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

    # Test for normal object
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:52:49.000690
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:53:00.543478
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:06.751984
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode
    secret = 'secret'
    vault = VaultLib(secrets=[secret])

# Generated at 2022-06-17 05:53:22.274556
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:53:30.618842
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:40.018319
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:50.799866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEnc

# Generated at 2022-06-17 05:54:03.150116
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:54:10.521397
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')


# Generated at 2022-06-17 05:54:24.268362
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:38.696255
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:54.958252
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:06.792919
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:55:17.039868
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == wrap_var('foo')

# Generated at 2022-06-17 05:55:27.050192
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:34.799350
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:43.322487
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:54.540720
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:04.438105
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:16.460993
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:26.060226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:36.494384
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:49.856157
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:03.656960
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:14.550501
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:27.331167
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:41.486669
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    json_str = '{"__ansible_vault": "vault_value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == 'vault_value'

    # Test for __ansible_unsafe
    json_str = '{"__ansible_unsafe": "unsafe_value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, wrap_var)
    assert json_obj == 'unsafe_value'

    # Test for normal json
    json_str = '{"normal_key": "normal_value"}'


# Generated at 2022-06-17 05:57:50.655254
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:57:57.162138
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for wrap_var
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

    # Test for pairs
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:58:06.463219
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:15.826850
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for AnsibleUnsafeText
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), AnsibleUnsafeText)

    # Test for other
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:58:36.875537
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:58:50.270554
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:59:03.217813
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:59:09.713104
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test_secret'])