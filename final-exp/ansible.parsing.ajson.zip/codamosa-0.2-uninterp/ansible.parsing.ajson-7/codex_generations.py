

# Generated at 2022-06-17 05:49:21.458849
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for vault
    vault_secrets = ['vault_secret']

# Generated at 2022-06-17 05:49:31.872718
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:44.590638
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:49:57.650490
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:05.059286
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:13.940229
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')

# Generated at 2022-06-17 05:50:26.562630
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')

# Generated at 2022-06-17 05:50:36.565810
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:44.016508
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "vault_value", "__ansible_unsafe": "unsafe_value"}'
    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(json_str)
    assert decoded['__ansible_vault'] == 'vault_value'
    assert decoded['__ansible_unsafe'] == 'unsafe_value'

# Generated at 2022-06-17 05:50:55.304091
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:06.746907
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)
    assert decoder.object_hook({'__ansible_vault': 'test'}).vault == decoder._vaults['default']

    # Test for wrap_var
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

# Generated at 2022-06-17 05:51:15.901109
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:28.660500
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_vault': 'bar'})

# Generated at 2022-06-17 05:51:39.034748
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:51:51.115235
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:59.872264
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    json_str = '{"__ansible_vault": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == "test"

    # Test for AnsibleUnsafeText
    json_str = '{"__ansible_unsafe": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, str)
    assert json_obj == "test"

    # Test for normal json
    json_str = '{"key": "value"}'

# Generated at 2022-06-17 05:52:04.854882
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:12.691198
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:52:24.032085
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:36.021288
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:52:42.705111
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:52:52.767605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:52:57.744732
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    json_str = '{"__ansible_vault": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == "test"

    # Test with __ansible_unsafe
    json_str = '{"__ansible_unsafe": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, wrap_var)
    assert json_obj == "test"

    # Test with __ansible_vault and __ansible_unsafe

# Generated at 2022-06-17 05:53:06.715980
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:53:22.273665
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

    # Test for __ansible_vault

# Generated at 2022-06-17 05:53:30.619131
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_vault': 'test'})

# Generated at 2022-06-17 05:53:36.534877
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:44.787707
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with vault secret
    vault_secret = VaultSecret('test')
    AnsibleJSONDecoder.set_secrets(vault_secret)
    decoder = AnsibleJSONDecoder()
    data = {'__ansible_vault': 'test'}
    result = decoder.object_hook(data)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == vault_secret

    # Test with unsafe secret
    data = {'__ansible_unsafe': 'test'}
    result = decoder.object_hook(data)
    assert result == wrap_var('test')

    # Test with no secret

# Generated at 2022-06-17 05:53:59.821186
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:07.222160
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    vault_password = 'vault_password'

    vault_lib = VaultLib(vault_password)
    vault_text = vault_lib.encrypt('secret')

    # Test for AnsibleVaultEncryptedUnicode
    pairs = {'__ansible_vault': vault_text}
    decoder = AnsibleJSONDecoder()
    decoded = decoder.object_hook(pairs)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault is None
    assert decoded.vault_password is None

# Generated at 2022-06-17 05:54:24.685836
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:34.697314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:41.983784
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test with __ansible_unsafe
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), AnsibleUnsafeText)

# Generated at 2022-06-17 05:54:55.861294
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for vault

# Generated at 2022-06-17 05:55:06.865865
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:17.066860
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:55:29.911687
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    json_str = '{"__ansible_vault": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == 'test'

    # Test with __ansible_unsafe
    json_str = '{"__ansible_unsafe": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, wrap_var)
    assert json_obj == 'test'

# Generated at 2022-06-17 05:55:38.335177
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:47.360741
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:55.208810
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for __ansible_vault

# Generated at 2022-06-17 05:56:13.936552
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    json_str = '{"__ansible_vault": "vault_value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == 'vault_value'

    # Test for __ansible_unsafe
    json_str = '{"__ansible_unsafe": "unsafe_value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, wrap_var)
    assert json_obj == 'unsafe_value'

    # Test for normal key
    json_str = '{"normal_key": "normal_value"}'


# Generated at 2022-06-17 05:56:23.610345
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:56:33.484555
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')

# Generated at 2022-06-17 05:56:47.602568
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:56:53.595141
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    test_string = '{"__ansible_vault": "vault_test"}'
    test_json = json.loads(test_string, cls=AnsibleJSONDecoder)
    assert isinstance(test_json, AnsibleVaultEncryptedUnicode)
    assert test_json == 'vault_test'

    # Test for wrap_var
    test_string = '{"__ansible_unsafe": "unsafe_test"}'
    test_json = json.loads(test_string, cls=AnsibleJSONDecoder)
    assert test_json == 'unsafe_test'

# Generated at 2022-06-17 05:57:01.048027
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:57:11.013378
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:17.156238
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:28.073308
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    decoded = decoder.decode('{"__ansible_vault": "test"}')
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault is not None

    # Test for AnsibleUnsafeText
    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode('{"__ansible_unsafe": "test"}')
    assert isinstance(decoded, str)
    assert decoded.__class__.__name__ == 'AnsibleUnsafeText'

    # Test for AnsibleUnsafeBytes
    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode

# Generated at 2022-06-17 05:57:41.856953
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')

# Generated at 2022-06-17 05:57:57.249899
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for AnsibleUnsafeText
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

    # Test for other
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:58:06.492132
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:16.763949
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')

# Generated at 2022-06-17 05:58:23.546512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "vault_value", "__ansible_unsafe": "unsafe_value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert json_obj['__ansible_vault'] == 'vault_value'
    assert json_obj['__ansible_unsafe'] == 'unsafe_value'

# Generated at 2022-06-17 05:58:33.417182
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:46.416557
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}
    assert decoder.object

# Generated at 2022-06-17 05:59:00.803620
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for vault
    vault_pass = 'test_pass'
    vault_secrets = [('default', vault_pass)]
    vault = VaultLib(secrets=vault_secrets)
    vault_data = vault.encrypt('test_data')
    vault_data_json = json.dumps({'__ansible_vault': vault_data})
    vault_data_decoded = json.loads(vault_data_json, cls=AnsibleJSONDecoder)
    assert isinstance(vault_data_decoded, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-17 05:59:15.470737
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])