

# Generated at 2022-06-17 05:49:21.405058
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:49:31.872969
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:37.308212
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}
    assert decoder.object

# Generated at 2022-06-17 05:49:43.307237
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:57.474398
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:10.098756
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:26.040637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:37.399006
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:51.510935
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:50:58.629698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)
    assert decoder.object_hook({'__ansible_vault': 'test'}).vault.secrets == ['test']

    # Test for wrap_var
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')

    # Test for normal value
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:51:10.362750
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:18.118298
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:51:27.749775
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    vault = decoder.object_hook({'__ansible_vault': 'test'})
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vault.secrets == ['test']

    # Test for unsafe
    unsafe = decoder.object_hook({'__ansible_unsafe': 'test'})
    assert unsafe == wrap_var('test')

    # Test for normal
    normal = decoder.object_hook({'test': 'test'})
    assert normal == {'test': 'test'}

# Generated at 2022-06-17 05:51:38.964621
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:51.115158
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:54.118306
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')

# Generated at 2022-06-17 05:52:07.877037
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:12.660503
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for wrap_var
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

# Generated at 2022-06-17 05:52:23.386554
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:52:35.668912
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:52:41.692366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:52.044271
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:04.195469
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:17.789241
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for wrap_var
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

    # Test for normal value
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:53:28.992014
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    json_string = '{"__ansible_vault": "vault_value"}'
    json_dict = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert isinstance(json_dict, AnsibleVaultEncryptedUnicode)
    assert json_dict == 'vault_value'

    # Test with __ansible_unsafe
    json_string = '{"__ansible_unsafe": "unsafe_value"}'
    json_dict = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert isinstance(json_dict, wrap_var)
    assert json_dict == 'unsafe_value'

    # Test with both __ansible_vault and __ansible_unsafe

# Generated at 2022-06-17 05:53:42.126004
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:51.463663
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for __ansible_vault
    json_str = '{"__ansible_vault": "test_vault"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == "test_vault"

    # Test for __ansible_unsafe
    json_str = '{"__ansible_unsafe": "test_unsafe"}'

# Generated at 2022-06-17 05:54:03.495125
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:12.948901
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:54:22.806713
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:54:39.100977
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:54:53.084698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:55:01.535032
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:06.645070
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:16.944149
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:26.509278
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:55:37.099195
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:55:43.097500
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:55:56.304605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:56:06.330125
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:56:18.175722
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:30.753845
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:44.676418
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:55.796010
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    assert isinstance(json.loads('{"__ansible_vault": "foo"}', cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)
    # Test for AnsibleUnsafeText
    assert isinstance(json.loads('{"__ansible_unsafe": "foo"}', cls=AnsibleJSONDecoder), AnsibleUnsafeText)
    # Test for AnsibleUnsafeBytes
    assert isinstance(json.loads('{"__ansible_unsafe": "foo"}', cls=AnsibleJSONDecoder, encoding='utf-8'), AnsibleUnsafeBytes)
    # Test for AnsibleUnsafeDict

# Generated at 2022-06-17 05:57:06.777922
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:57:21.304114
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:31.457519
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{'vault_id': 'default', 'password': 'secret'}]
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:39.536916
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    test_data = '{"__ansible_vault": "test"}'
    test_data_decoded = json.loads(test_data, cls=AnsibleJSONDecoder)
    assert isinstance(test_data_decoded, AnsibleVaultEncryptedUnicode)
    assert test_data_decoded == "test"

    # Test for AnsibleUnsafeText
    test_data = '{"__ansible_unsafe": "test"}'
    test_data_decoded = json.loads(test_data, cls=AnsibleJSONDecoder)
    assert isinstance(test_data_decoded, wrap_var)
    assert test_data_decoded == "test"

    # Test for AnsibleUnsafeText

# Generated at 2022-06-17 05:57:50.523684
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:59.665821
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:14.087228
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:19.974857
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:30.605213
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:42.421005
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:48.912946
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')

# Generated at 2022-06-17 05:59:02.396040
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:59:16.633204
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()