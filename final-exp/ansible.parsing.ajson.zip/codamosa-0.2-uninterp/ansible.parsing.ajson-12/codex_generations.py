

# Generated at 2022-06-17 05:49:20.932847
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:49:29.549746
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == wrap_var('foo')
    assert decoder.object_hook({'foo': 'bar'}) == {'foo': 'bar'}

# Generated at 2022-06-17 05:49:42.727673
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:57.422974
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:10.038277
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:50:26.008787
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with vault
    secrets = ['secret']
    vault = VaultLib(secrets=secrets)
    vault_text = vault.encrypt('test')
    vault_dict = {'__ansible_vault': vault_text}
    vault_obj = AnsibleJSONDecoder.object_hook(vault_dict)
    assert isinstance(vault_obj, AnsibleVaultEncryptedUnicode)
    assert vault_obj.vault == vault

    # Test with unsafe
    unsafe_dict = {'__ansible_unsafe': 'test'}
    unsafe_obj = AnsibleJSON

# Generated at 2022-06-17 05:50:36.495321
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:50:50.463097
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:50:55.449288
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:51:05.690897
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'test'
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'test'}
    result = decoder.object_hook(pairs)
    assert result == AnsibleVaultEncryptedUnicode('test')
    assert result.vault == VaultLib(secrets=secrets)

    pairs = {'__ansible_unsafe': 'test'}
    result = decoder.object_hook(pairs)
    assert result == wrap_var('test')

# Generated at 2022-06-17 05:51:15.932795
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:51:28.660421
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:37.334888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'vault'}) == AnsibleVaultEncryptedUnicode('vault')
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe'}) == wrap_var('unsafe')
    assert decoder.object_hook({'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe'}) == AnsibleVaultEncryptedUnicode('vault')

# Generated at 2022-06-17 05:51:50.260936
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:52:00.414134
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:09.221486
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:22.425918
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    json_data = '{"__ansible_vault": "test"}'
    decoded_data = AnsibleJSONDecoder().decode(json_data)
    assert isinstance(decoded_data, AnsibleVaultEncryptedUnicode)
    assert decoded_data == 'test'

    # Test with __ansible_unsafe
    json_data = '{"__ansible_unsafe": "test"}'
    decoded_data = AnsibleJSONDecoder().decode(json_data)
    assert decoded_data == wrap_var('test')

    # Test with __ansible_vault and __ansible_unsafe
    json_data = '{"__ansible_vault": "test", "__ansible_unsafe": "test"}'
    decoded_data

# Generated at 2022-06-17 05:52:30.605615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:36.475684
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:52:41.440527
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:56.429809
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:05.956060
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test\n63313162333963376231623332613761323162323232323232323232323232323\n'}
    result = decoder.object_hook(pairs)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == decoder._vaults['default']

# Generated at 2022-06-17 05:53:21.458435
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:53:29.971383
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:53:39.940369
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:50.736140
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test for __ansible_vault
    json_data = '{"__ansible_vault": "test"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(['test'])
    assert ansible_json_decoder.decode(json_data) == AnsibleVaultEncryptedUnicode('test')

    # test for __ansible_unsafe
    json_data = '{"__ansible_unsafe": "test"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.decode(json_data) == wrap_var('test')

    # test for __ansible_vault and __ansible_unsafe

# Generated at 2022-06-17 05:54:03.114476
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    secrets = ['secret']
    vault = VaultLib(secrets=secrets)

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:54:17.472468
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:28.966824
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

    # Test for __ansible_unsafe
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')

    # Test for other keys
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:54:40.568499
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:54:55.490591
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    data = '{"__ansible_vault": "test"}'
    result = decoder.decode(data)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None

    # Test for wrap_var
    decoder = AnsibleJSONDecoder()
    data = '{"__ansible_unsafe": "test"}'
    result = decoder.decode(data)
    assert isinstance(result, dict)
    assert result['__ansible_unsafe'] == 'test'

# Generated at 2022-06-17 05:55:06.830450
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for __ansible_vault

# Generated at 2022-06-17 05:55:17.038555
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:26.574301
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:55:37.125987
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:46.916911
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:55:54.912674
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:56:04.468713
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    secret = 'secret'
    vault = VaultLib(secrets=[secret])
    vault_text = vault.encrypt('test')
    vault_text_json = json.dumps({'__ansible_vault': vault_text})
    vault_text_json_decoded = json.loads(vault_text_json, cls=AnsibleJSONDecoder)
    assert isinstance(vault_text_json_decoded, AnsibleVaultEncryptedUnicode)
    assert vault_text_json_decoded.vault == vault
    assert vault_text_json_decoded.vault

# Generated at 2022-06-17 05:56:11.015274
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:23.917819
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')

# Generated at 2022-06-17 05:56:35.056686
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:56:48.911068
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:56:57.015326
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for wrap_var
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), AnsibleUnsafeText)

# Generated at 2022-06-17 05:57:05.219854
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:57:13.482075
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:57:25.031612
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:31.888875
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    result = decoder.object_hook({'__ansible_vault': 'test'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None
    assert result.vault.secrets == ['test']
    assert result.vault.secrets_filename is None
    assert result.vault.password is None
    assert result.vault.password_files == []
    assert result.vault.identity_list is None
    assert result.vault.identity_only is False
    assert result.vault.role_name is None
    assert result.vault.ssh_common_args is None
   

# Generated at 2022-06-17 05:57:41.916985
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:55.674532
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:05.838362
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:30.570717
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:42.391844
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:58:49.818516
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    decoded = decoder.object_hook({'__ansible_vault': 'test'})
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault is not None
    assert decoded.vault.secrets == ['test']

    # Test for unsafe
    decoder = AnsibleJSONDecoder()
    decoded = decoder.object_hook({'__ansible_unsafe': 'test'})
    assert isinstance(decoded, wrap_var)
    assert decoded.value == 'test'

    # Test for normal
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:58.738499
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:59:07.877238
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()