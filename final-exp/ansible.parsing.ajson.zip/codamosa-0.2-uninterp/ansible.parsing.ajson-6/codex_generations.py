

# Generated at 2022-06-17 05:49:22.713906
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:49:30.071353
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:49:43.076806
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    secret = 'secret'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secret)

# Generated at 2022-06-17 05:49:57.476081
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n353038353437373039343635666535393466643730666438376639353038353437373039343635666535393466643730666438376639\n'}
    decoded = decoder.decode(json.dumps(data))

# Generated at 2022-06-17 05:50:04.541548
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'test'}
    assert decoder.object_hook(pairs) == AnsibleVaultEncryptedUnicode('test')
    pairs = {'__ansible_unsafe': 'test'}
    assert decoder.object_hook(pairs) == wrap_var('test')
    pairs = {'__ansible_vault': 'test', '__ansible_unsafe': 'test'}
    assert decoder.object_hook(pairs) == AnsibleVaultEncryptedUnicode('test')
    pairs = {'__ansible_unsafe': 'test', '__ansible_vault': 'test'}
    assert decoder.object_hook(pairs) == AnsibleVaultEncryptedUnicode('test')


# Generated at 2022-06-17 05:50:15.402847
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:50:26.895261
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with vaulted data

# Generated at 2022-06-17 05:50:36.967184
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    test_data = '{"__ansible_vault": "vault_data"}'
    decoded_data = AnsibleJSONDecoder().decode(test_data)
    assert isinstance(decoded_data, AnsibleVaultEncryptedUnicode)
    assert decoded_data == 'vault_data'

    # Test with __ansible_unsafe
    test_data = '{"__ansible_unsafe": "unsafe_data"}'
    decoded_data = AnsibleJSONDecoder().decode(test_data)
    assert isinstance(decoded_data, wrap_var)
    assert decoded_data == 'unsafe_data'

    # Test with both __ansible_vault and __ansible_unsafe

# Generated at 2022-06-17 05:50:50.972796
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with vault
    vault_password = 'secret'
    vault_secrets = [('default', vault_password)]
    vault = VaultLib(secrets=vault_secrets)

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(vault_secrets)

    # Test with vault

# Generated at 2022-06-17 05:50:59.033207
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:10.760494
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:51:18.220352
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:28.846092
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['foo'])
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n'}
    result = decoder.object_hook(pairs)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == decoder._vaults['default']
    assert result.vault.secrets == ['foo']
    assert result.vault.decrypt(result) == 'bar'

    # Test with __ansible_unsafe
    pairs = {'__ansible_unsafe': 'bar'}
    result = decoder.object_hook(pairs)

# Generated at 2022-06-17 05:51:35.525615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:49.731319
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for __ansible_vault
    secret = 'test_secret'
    vault = VaultLib(secrets=[secret])
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = vault

# Generated at 2022-06-17 05:52:04.600968
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:52:11.717267
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')

# Generated at 2022-06-17 05:52:22.874226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo', '__ansible_vault': 'bar'}) == wrap_var('foo')

# Generated at 2022-06-17 05:52:35.380849
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:47.513613
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:53:00.521714
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib()

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:53:07.035774
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:53:22.517122
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:30.292262
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:36.329352
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:44.671081
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    json_str = '{"__ansible_vault": "vault_value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == 'vault_value'

    # Test for AnsibleUnsafeText
    json_str = '{"__ansible_unsafe": "unsafe_value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, wrap_var)
    assert json_obj == 'unsafe_value'

    # Test for AnsibleVaultEncryptedUnicode and AnsibleUnsafeText
    json_

# Generated at 2022-06-17 05:53:59.754001
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:54:04.506604
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:54:18.417851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:32.537123
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:54:44.375118
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:54:51.335295
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')
    assert decoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == {'__ansible_vault': AnsibleVaultEncryptedUnicode('foo'), '__ansible_unsafe': wrap_var('bar')}

# Generated at 2022-06-17 05:55:00.871523
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:08.737914
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:17.961257
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:55:32.781752
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['password']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    # Test for __ansible_vault
    data = '{"__ansible_vault": "vault_value"}'
    result = decoder.decode(data)
    assert result['__ansible_vault'] == 'vault_value'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault == decoder._vaults['default']
    # Test for __ansible_unsafe
    data = '{"__ansible_unsafe": "unsafe_value"}'
    result = decoder.decode(data)

# Generated at 2022-06-17 05:55:42.327856
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    test_data = '{"__ansible_vault": "test"}'
    test_data_dict = json.loads(test_data, cls=AnsibleJSONDecoder)
    assert isinstance(test_data_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Test for wrap_var
    test_data = '{"__ansible_unsafe": "test"}'
    test_data_dict = json.loads(test_data, cls=AnsibleJSONDecoder)
    assert isinstance(test_data_dict['__ansible_unsafe'], wrap_var)

    # Test for normal data
    test_data = '{"normal": "test"}'

# Generated at 2022-06-17 05:55:55.950718
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:56:10.707811
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:56:23.860375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:47.352068
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:56:56.124899
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:06.777301
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:18.286806
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for AnsibleUnsafeText
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'test'}), wrap_var)

    # Test for other cases
    assert decoder.object_hook({'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-17 05:57:28.490147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # test for __ansible_vault

# Generated at 2022-06-17 05:57:42.265613
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:57:55.940910
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_unsafe': 'test', '__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-17 05:58:05.964561
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for __ansible_vault

# Generated at 2022-06-17 05:58:18.430714
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:30.461618
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for __ansible_vault

# Generated at 2022-06-17 05:59:02.002029
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:59:16.247896
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for __ansible_vault
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n3537373334366637353766353637346535343336373637353565363336333736\n36353737333436663735376635363734653534333637363735356536333633373\n6\n'}
    decoder.object_hook(pairs)
    assert isinstance(pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # Test for __ansible_unsafe