

# Generated at 2022-06-17 05:49:13.363714
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:49:23.974652
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    json_str = '{"__ansible_vault": "test"}'
    obj = decoder.decode(json_str)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault is not None
    assert obj.vault.secrets == ['test']

    # Test with __ansible_unsafe
    decoder = AnsibleJSONDecoder()
    json_str = '{"__ansible_unsafe": "test"}'
    obj = decoder.decode(json_str)
    assert isinstance(obj, dict)
    assert obj['__ansible_unsafe'] == 'test'

# Generated at 2022-06-17 05:49:38.080883
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:49:48.047237
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:00.455226
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:50:14.907305
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:50:22.880869
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:50:32.592922
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:39.889647
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:50:53.686325
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:08.552415
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:17.898515
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:51:28.314041
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    test_json = '{"__ansible_vault": "test_value"}'
    test_dict = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert isinstance(test_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert test_dict['__ansible_vault'].vault is None

    # Test for AnsibleUnsafeText
    test_json = '{"__ansible_unsafe": "test_value"}'
    test_dict = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert test_dict['__ansible_unsafe'] == 'test_value'

# Generated at 2022-06-17 05:51:35.260251
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:51:45.941650
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:51:53.372803
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:52:07.255134
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:20.757478
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:52:28.597651
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for vault

# Generated at 2022-06-17 05:52:42.959370
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'vault'}) == AnsibleVaultEncryptedUnicode('vault')
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe'}) == wrap_var('unsafe')
    assert decoder.object_hook({'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe'}) == AnsibleVaultEncryptedUnicode('vault')
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe', '__ansible_vault': 'vault'}) == wrap_var('unsafe')

# Generated at 2022-06-17 05:52:55.078504
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:05.932972
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:53:21.391490
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for __ansible_vault
    vault_password = 'vault_password'
    vault_secrets = [vault_password]
    vault_lib = VaultLib(secrets=vault_secrets)
    vault_text = vault_lib.encrypt('vault_text')
    vault_dict = {'__ansible_vault': vault_text}
    vault_json = json.dumps(vault_dict)
    vault_pairs = json.loads(vault_json, cls=AnsibleJSONDecoder)
    vault_value = vault_

# Generated at 2022-06-17 05:53:30.168455
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:53:35.411938
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    json_str = '{"__ansible_vault": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == "test"

    # Test for __ansible_unsafe
    json_str = '{"__ansible_unsafe": "test"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, wrap_var)
    assert json_obj == "test"

# Generated at 2022-06-17 05:53:43.948578
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:53:59.084014
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:54:07.165901
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:54:15.041707
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:25.818556
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:38.231048
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:54:44.573147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])

# Generated at 2022-06-17 05:54:57.019561
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-17 05:55:11.114445
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:55:22.841860
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:55:35.637886
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-17 05:55:50.065452
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    # Test for __ansible_vault
    json_str = '{"__ansible_vault": "vault_str"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)
    assert json_obj == 'vault_str'

    # Test for __ansible_unsafe
    json_str = '{"__ansible_unsafe": "unsafe_str"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj, wrap_var)
    assert json_obj == 'unsafe_str'

    # Test for AnsibleVaultEncryptedUn

# Generated at 2022-06-17 05:56:00.440666
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=secrets)
    vault_text = vault.encrypt('test')
    vault_text_encoded = vault_text.encode('utf-8')

    # Test for vault
    pairs = {'__ansible_vault': vault_text_encoded}
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    decoded_pairs = decoder.object_hook(pairs)

# Generated at 2022-06-17 05:56:14.465420
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:25.610744
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    json_str = '{"__ansible_vault": "test"}'
    decoded = AnsibleJSONDecoder().decode(json_str)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded == 'test'

    # Test for AnsibleUnsafeText
    json_str = '{"__ansible_unsafe": "test"}'
    decoded = AnsibleJSONDecoder().decode(json_str)
    assert decoded == 'test'

    # Test for AnsibleUnsafeText
    json_str = '{"__ansible_unsafe": "test", "__ansible_vault": "test"}'
    decoded = AnsibleJSONDecoder().decode(json_str)

# Generated at 2022-06-17 05:56:48.682977
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:56:59.980337
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])

# Generated at 2022-06-17 05:57:08.811861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:22.940468
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['test'])
    result = decoder.object_hook({'__ansible_vault': 'test'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None

    # Test for AnsibleUnsafeText
    result = decoder.object_hook({'__ansible_unsafe': 'test'})
    assert isinstance(result, AnsibleUnsafeText)
    assert result == 'test'

    # Test for normal text
    result = decoder.object_hook({'test': 'test'})
    assert isinstance(result, dict)
    assert result['test'] == 'test'

# Generated at 2022-06-17 05:57:31.306640
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:44.726041
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:57:59.092944
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 05:58:07.110358
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:17.423734
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:26.288468
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-17 05:58:53.725255
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    test_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n3633373066373938643365303634373565653439336637356565353735373035646635383566\n3034653635363835306637393864336530363437356565343933663735656535373537303564\n6635383566\n'}
    test_decoder = AnsibleJSONDecoder()
    assert isinstance(test_decoder.object_hook(test_data), AnsibleVaultEncryptedUnicode)

    # Test for wrap_var

# Generated at 2022-06-17 05:59:04.257379
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])