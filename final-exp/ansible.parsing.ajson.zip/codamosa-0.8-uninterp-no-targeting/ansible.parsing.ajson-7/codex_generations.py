

# Generated at 2022-06-20 22:56:06.025269
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import json
    import types
    import copy

    from ansible.module_utils.common.json import AnsibleJSONDecoder

    import unittest

    class TestAnsibleJSONDecoder(unittest.TestCase):
        def test_custom_object_hook(self):
            # Make sure object_hook returns something other than Pairs
            # and that it is callable
            test_dict = {'__ansible_vault': 'some_value'}
            self.assertNotEqual(AnsibleJSONDecoder.object_hook(test_dict), test_dict)
            self.assertTrue(callable(AnsibleJSONDecoder.object_hook(test_dict)))

            # Test that an object_hook is set by default when instantiating
            # an AnsibleJSONDecoder
            ajd = AnsibleJSONDec

# Generated at 2022-06-20 22:56:14.253977
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets(secrets=['foobar'])
    d = AnsibleJSONDecoder()
    text = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256" "1234567890"}'
    obj = d.decode(text)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault.secrets == ['foobar']
    assert obj == '1234567890'
    assert '1234567890' == str(obj)

    text = '{"__ansible_unsafe": "&#34;Hello there&#34;"}'
    obj = d.decode(text)
    assert obj == '"Hello there"'
    assert '"Hello there"' == str(obj)

# Generated at 2022-06-20 22:56:16.458275
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret']
    try:
        ansible_json_decoder = AnsibleJSONDecoder.set_secrets(secrets)
        ansible_json_decoder = AnsibleJSONDecoder()
        assert ansible_json_decoder._vaults['default'].secrets == secrets
    except Exception:
        raise

# Generated at 2022-06-20 22:56:27.211453
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap

# Generated at 2022-06-20 22:56:31.532482
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test AnsibleJSONDecoder.__init__(self)
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.__init__() is None


# Generated at 2022-06-20 22:56:40.393028
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_data = {'__ansible_unsafe': '{{vault_pass}}', '__ansible_vault': 'AQAAAK8WkHt7IwAAB2jFxvZ8CAgA='}
    test_result = decoder.object_hook(test_data)
    assert isinstance(test_result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(test_result['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-20 22:56:52.531375
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:57:01.632973
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    secret = 'dummy_secret'
    json_data = '{"__ansible_vault": "$ANSIBLE_VAULT;1.2;AES256;dummy_salt_here\n' + secret + '\n"}'
    decoder = AnsibleJSONDecoder.set_secrets(secret)

    # Act
    # Get the object_hook method of AnsibleJSONDecoder
    object_hook = AnsibleJSONDecoder._object_hook.__get__(decoder, AnsibleJSONDecoder)
    result = object_hook(json.loads(json_data))

    # Assert
    assert result == 'dummy_secret'

# Generated at 2022-06-20 22:57:04.970534
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, json.JSONDecoder)



# Generated at 2022-06-20 22:57:09.290078
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    with open('/tmp/.ci.yml', 'r') as f:
        #dec = AnsibleJSONDecoder()
        dec = AnsibleJSONDecoder.AnsibleJSONDecoder()
        dec.decode(f.read())

# Generated at 2022-06-20 22:57:20.747942
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'vault'}
    ansible_vault = decoder.object_hook(pairs)
    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)
    assert ansible_vault.value == 'vault'

    unsafe = decoder.object_hook({'__ansible_unsafe': 'unsafe'})
    assert isinstance(unsafe, wrap_var.UnsafeWrapper)
    assert unsafe == 'unsafe'

    assert decoder.object_hook({'normal': 'normal'}) == {'normal': 'normal'}

# Generated at 2022-06-20 22:57:24.028278
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    Test decoding a dict containing __ansible_vault and __ansible_unsafe keys
    to produce an AnsibleVaultEncryptedUnicode.
    '''

    # Arrange
    # For testing, use a different VaultLib from the default
    secrets = ['foo']
    vault = VaultLib(secrets=secrets)
    test_decoder = AnsibleJSONDecoder()
    test_decoder._vaults['default'] = vault
    test_value = { "__ansible_vault": "bar", "__ansible_unsafe": "unsafe" }

    # Act
    test_decoded_dict = test_decoder.object_hook(test_value)

    # Assert
    assert isinstance(test_decoded_dict, AnsibleVaultEncryptedUnicode)
    assert test_

# Generated at 2022-06-20 22:57:27.242331
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    # Test that it is actually an instance of AnsibleJSONDecoder and json.JSONDecoder
    assert isinstance(decoder, AnsibleJSONDecoder)
    assert isinstance(decoder, json.JSONDecoder)



# Generated at 2022-06-20 22:57:38.216291
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import os
    import tempfile
    vault_password = 'ansible'
    vault_file = tempfile.NamedTemporaryFile(suffix='.yml', delete=False)
    vault_file_path = vault_file.name
    with open(vault_file_path, 'w') as f:
        f.write(vault_password)
    vault_file.close()

    vault_dict = {'vault_password_file': vault_file_path}
    decoder = AnsibleJSONDecoder(encoding='utf-8', object_pairs_hook=dict, vault_dict=vault_dict)
    ansible_vault = True
    ansible_unsafe = True

# Generated at 2022-06-20 22:57:44.896700
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({"__ansible_vault": "ABCDEFG"}).vault_id == "A" * 32
    assert decoder.object_hook({"__ansible_unsafe": "hello"}).getvalue() == "hello"
    assert decoder.object_hook({"__ansible_unsafe": "{{ a }}"}).getvalue() == ""

# Generated at 2022-06-20 22:57:50.044396
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    obj = json.loads(s, cls=AnsibleJSONDecoder)
    assert obj == ['foo', {'bar': ['baz', None, 1.0, 2]}]

# Unit Test for method set_secrets of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:57:57.405451
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils.common._text import to_bytes

    vault_password = "mypassword"
    vault_secrets = [vault_password]
    AnsibleJSONDecoder.set_secrets(vault_secrets)

# Generated at 2022-06-20 22:58:08.091004
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''Unit test for constructor of class AnsibleJSONDecoder'''
    import sys
    import io

    def my_print(x):
        sys.stdout.write(x)
        sys.stdout.write("\n")
        pass

    # reset output
    sys.stdout = io.StringIO()

    # string with '__ansible_vault'
    s = '{"__ansible_vault" : "mocked_stored_value"}'
    # expected output
    expected = 'mocked_stored_value'
    # this is needed to mock the '__ansible_vault' value
    AnsibleJSONDecoder.set_secrets('vaultpass')
    # decode string
    decoded = json.loads(s, cls=AnsibleJSONDecoder)
    # print result
   

# Generated at 2022-06-20 22:58:15.020010
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    data = {'__ansible_vault': 'decrypted'}
    assert decoder.object_hook(data) == AnsibleVaultEncryptedUnicode(data['__ansible_vault'])

    data = {'__ansible_unsafe': 'decrypted'}
    assert decoder.object_hook(data) == wrap_var(data['__ansible_unsafe'])


# Generated at 2022-06-20 22:58:25.402694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ["secret_key"]

# Generated at 2022-06-20 22:58:33.571911
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:41.152391
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    fake_secret = 'Vaulted:$ANSIBLE_VAULT;7.3;AES256\n6363366661623036666135333830643439623932306461613661323632313062343231376366313\n6626362323633346466316335313531653265663465303931303366653966623865653335396430\n6363366661623036666135333830643439623932306461613661323632313062343231376366313\n6626362323633346466316335313531653265663\n'

# Generated at 2022-06-20 22:58:53.465923
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class TestJSONDecoder(AnsibleJSONDecoder):
        def __init__(self, *args, **kwargs):
            kwargs['object_hook'] = self.object_hook
            super(TestJSONDecoder, self).__init__(*args, **kwargs)

        def object_hook(self, pairs):
            for key in pairs:
                value = pairs[key]
                if key == '__ansible_vault':
                    value = AnsibleVaultEncryptedUnicode(value)
                    return value
            return pairs

    # Test AnsibleJSONDecoder.object_hook with vault hash

# Generated at 2022-06-20 22:59:03.782028
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [None]
    AnsibleJSONDecoder.set_secrets(secrets)
    assert secrets == AnsibleJSONDecoder._vaults['default'].secrets

    with open('test.json', 'w') as f:
        json.dump({'foo': 'bar'}, f, cls=AnsibleJSONEncoder, indent=4)

    with open('test.json') as f:
        data = json.load(f, cls=AnsibleJSONDecoder)

    assert type(data) == dict
    assert data['foo'] == 'bar'
    assert json.dumps(data, cls=AnsibleJSONEncoder, indent=4) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-20 22:59:12.973305
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Encrypted var
    secret_var = {
        '__ansible_vault': "U2FsdGVkX1+D5f5ES+41ySuKrBT7aMfJvo6Q+M2XKXQ="
    }
    # Unencrypted var
    var = {
        'name': 'test',
        'age': 10,
    }
    # Serialize both vars
    secret_var_dumped = json.dumps(secret_var, cls=AnsibleJSONEncoder)
    var_dumped = json.dumps(var, cls=AnsibleJSONEncoder)

    # Test good secret and var loads
    assert json.loads(secret_var_dumped, cls=AnsibleJSONDecoder) == secret_var

# Generated at 2022-06-20 22:59:21.358723
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {'password': 'secret'}
    AnsibleJSONDecoder.set_secrets(secrets)
    input = '{"x": "abc", "y": "def", "__ansible_unsafe": "test", "__ansible_vault": "' + secrets["password"] + '"}'
    output = json.loads(input, cls=AnsibleJSONDecoder)
    assert output['__ansible_unsafe'].data == 'test'
    assert output['__ansible_vault'].decrypt(secrets["password"]) == ''

# Generated at 2022-06-20 22:59:33.524736
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # empty dictionary
    assert AnsibleJSONDecoder.object_hook({}) == {}


# Generated at 2022-06-20 22:59:41.582321
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:52.626683
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {
        "__ansible_vault": "TEST_VAULT",
        "__ansible_unsafe": True
    }
    results = decoder.object_hook(pairs)

    assert(isinstance(results['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(hasattr(results['__ansible_vault'], 'vault'))
    assert(results['__ansible_unsafe'] == wrap_var(True))
    assert(results['__ansible_unsafe']._has_been_wrapped == True)
    assert(results['__ansible_unsafe']._original == True)

# Generated at 2022-06-20 23:00:01.198064
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"__ansible_vault": "my_password"}
    ansible_json_decoder = AnsibleJSONDecoder()
    result = ansible_json_decoder.object_hook(data)
    assert result['__ansible_vault'] == "my_password"
    assert result['__ansible_vault'].vault is not None

    data = {"__ansible_unsafe": "my_password"}
    ansible_json_decoder = AnsibleJSONDecoder()
    result = ansible_json_decoder.object_hook(data)
    assert result['__ansible_unsafe'] == "my_password"



# Generated at 2022-06-20 23:00:15.718225
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:28.446826
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import pytest
    from tempfile import NamedTemporaryFile

    test_vault_dict = dict(
        vault = {
            'vault_key': 'vault_value',
            'vault_sub_key': { 'sub_value': 'vault_sub_value' }
        },
        no_vault = {
            'no_vault_key': 'no_vault_value',
            'no_vault_sub_key': { 'sub_value': 'no_vault_sub_value' }
        })


# Generated at 2022-06-20 23:00:36.594858
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = '$ANSIBLE_VAULT;1.1;AES256\n39303533303664343838636365346261376134613337613764386130646530666435336664343534\n34313036353639306437663564373430643562653837323962663132303733636335666435633834\n39666435336664343534343130363536393064376635643734306435626538373239626631323037\n33636335666435633834396664323335396664326536306637346365333833633134343539333537\n6238\n'
    decoder = AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-20 23:00:37.841605
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:47.233275
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    expected_result = {'value': 'final', '__ansible_vault': {'value': 'vaulted'}, '__ansible_unsafe': {'value': 'unsafe'}}

    test_dict = {'value': 'final', '__ansible_vault': {'value': 'vaulted'}, '__ansible_unsafe': {'value': 'unsafe'}}
    test_json = json.dumps(test_dict)

    decoder = AnsibleJSONDecoder()
    assert decoder.decode(test_json) == expected_result



# Generated at 2022-06-20 23:00:56.899695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.decode('{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible\n34613439353665353039343963633566353336313536653532626431613239643963383830\n39643232346362353534623861612b\n"}') == '$ANSIBLE_VAULT;1.1;AES256;ansible\n34613439353665353039343963633566353336313536653532626431613239643963383830\n39643232346362353534623861612b\n'

# Generated at 2022-06-20 23:01:08.629697
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    from ansible.module_utils.six.moves import StringIO

    def capture(func, *args, **kwargs):
        """Capture the stdout of a function call."""
        stdout = sys.stdout
        sys.stdout = StringIO()
        ret = func(*args, **kwargs)
        sys.stdout.seek(0)
        value = sys.stdout.read()
        sys.stdout = stdout
        return ret, value

    def test(msg, expected, *args, **kwargs):
        """Test JSONDecoder.object_hook."""
        ret, output = capture(json.loads, *args, **kwargs)
        assert ret == expected, output
        ret, output = capture(AnsibleJSONDecoder.object_hook, *args, **kwargs)
       

# Generated at 2022-06-20 23:01:19.478178
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert(AnsibleJSONDecoder.__bases__[0] == json.JSONDecoder)
    assert(AnsibleJSONDecoder.__init__.__defaults__ == ())
    assert(AnsibleJSONDecoder.__init__.__closure__ == ())
    assert(AnsibleJSONDecoder.__init__.__code__.co_argcount == 2)
    assert(AnsibleJSONDecoder.__init__.__code__.co_varnames == ('self', '*args', '**kwargs'))
    assert(AnsibleJSONDecoder.__dict__['object_hook'].__defaults__ == ())
    assert(AnsibleJSONDecoder.__dict__['object_hook'].__closure__ == ())

# Generated at 2022-06-20 23:01:31.144924
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'}) == {'__ansible_vault': 'test', '__ansible_unsafe': 'test'}
    value = decoder.object_hook({'__ansible_vault': 'test'})['__ansible_vault']
    assert type(value) == AnsibleVaultEncryptedUnicode
    assert value.vault == None
    assert value.unencrypted_string == 'test'

    value = decoder.object_hook({'__ansible_unsafe': 'test'})['__ansible_unsafe']
    assert type(value) == str
    assert value.startswith('$ANSIBLE_VAULT')

# Generated at 2022-06-20 23:01:32.387300
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert jd

# Generated at 2022-06-20 23:01:47.717234
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Test object_hook function
    # Test AnsibleVaultEncryptedUnicode instance
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:01:54.698788
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(strict=False)

    # Testing for __ansible_vault
    string = '{"__ansible_vault": "VALUE"}'
    data = json.loads(string, cls=AnsibleJSONDecoder)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)

    # Testing for __ansible_unsafe
    string = '{"__ansible_unsafe": "VALUE"}'
    data = json.loads(string, cls=AnsibleJSONDecoder)
    assert data == 'VALUE'

# Generated at 2022-06-20 23:02:05.884973
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test set_secrets
    TEST_SECRETS = ['foo']
    AnsibleJSONDecoder.set_secrets(TEST_SECRETS)
    assert AnsibleJSONDecoder._vaults['default']
    assert AnsibleJSONDecoder._vaults['default'].secrets == TEST_SECRETS

    # Test object_hook
    result = AnsibleJSONDecoder.object_hook(None, {'__ansible_vault': 'my_vault_string'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == AnsibleJSONDecoder._vaults['default']

    TEST_UNSAFE_STRING = 'test_unsafe_string'

# Generated at 2022-06-20 23:02:06.908023
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder._vaults == {}

# Generated at 2022-06-20 23:02:18.175443
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import tempfile
    import textwrap

    # This test uses some fixtures with AnsibleVaultEncryptedUnicode objects
    # those are not available in the test environment. So we are going to use
    # VaultLib with a tempfile to create those objects, this is not ideal but
    # that's all we can do at the moment.
    temp_secrets = tempfile.mkstemp()[1]
    vault = VaultLib([temp_secrets])


# Generated at 2022-06-20 23:02:24.753948
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_json = json.dumps(
        {'username': 'bob', 'password': '$ANSIBLE_VAULT;1.1;AES256;bob;bob;bob;bob;bob;bob;bob'},
        cls=AnsibleJSONEncoder
    )

    assert isinstance(json.loads(test_json), dict)

# Generated at 2022-06-20 23:02:36.003103
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:44.271010
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'jeHd9G/fJFomn6/fH6+mUjL5ZmY5ZGJhZjFiNjJk'
    json_obj = AnsibleJSONDecoder(object_hook = AnsibleJSONDecoder.object_hook)
    json_str = json.dumps(wrap_var({'foo': 'bar'}), cls=AnsibleJSONEncoder)
    assert json_obj.decode(json_str) == {'foo': 'bar'}

# Generated at 2022-06-20 23:02:47.748827
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder._vaults == {}
    assert AnsibleJSONDecoder.set_secrets
    assert AnsibleJSONDecoder.object_hook
    assert AnsibleJSONEncoder.default

# Generated at 2022-06-20 23:02:50.048546
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook != AnsibleJSONDecoder.object_hook


# Generated at 2022-06-20 23:03:09.755226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    ansible_vault_decoder = AnsibleJSONDecoder()
    json_output = ansible_vault_decoder.object_hook(pairs)

    assert isinstance(json_output, AnsibleVaultEncryptedUnicode) is True
    assert isinstance(json_output.vault, VaultLib) is False


# Generated at 2022-06-20 23:03:18.356601
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '''
    {
        "__ansible_unsafe": "{{ foo | to_json }}",
        "__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          643836613564646134386431636331323937616235316334323639656439663162663231653637\n          3333303734653230653231313066303737666539301a3536363562396264363739383736333665\n          613362643861313966653930613035653435623334623361643439646638333936387082\n          "
    }
    '''
    secrets = ['a_secret']

    # Test

# Generated at 2022-06-20 23:03:23.709339
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')



# Generated at 2022-06-20 23:03:32.638779
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode_text = enc.default(AnsibleVaultEncryptedUnicode('test'))
    result = dec.object_hook(json.loads(ansible_vault_encrypted_unicode_text))
    assert result['__ansible_vault'] == 'test'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(result['__ansible_vault'].vault, VaultLib)

# Generated at 2022-06-20 23:03:35.183139
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"__ansible_vault": "This is a test"}
    assert AnsibleJSONDecoder().object_hook(obj).data == "This is a test"

# Generated at 2022-06-20 23:03:36.167580
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:03:39.313106
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)

# Generated at 2022-06-20 23:03:49.436071
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    v = VaultLib(password_file='/tmp/abc.txt')

# Generated at 2022-06-20 23:03:53.323192
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = {'a': 1, 'b': 2}
    data_encoded = json.dumps(data, cls=AnsibleJSONEncoder)
    assert AnsibleJSONDecoder.decode(data_encoded) == data

# Generated at 2022-06-20 23:04:04.574454
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test if constructor works without arguments
    decoder = AnsibleJSONDecoder()
    assert decoder is not None
    assert not decoder.parse_float is None
    assert not decoder.parse_int is None
    assert not decoder.parse_constant is None
    assert decoder.strict is True
    assert not decoder.scan_once is None
    assert not decoder.object_hook is None
    assert not decoder.object_pairs_hook is None

    # Test if constructor works with arguments
    decoder = AnsibleJSONDecoder(parse_float=0, parse_int=0, parse_constant=0, strict=False,
                                 object_hook=0, object_pairs_hook=0)
    assert decoder is not None
    assert decoder.parse_float == 0

# Generated at 2022-06-20 23:04:35.392176
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)



# Generated at 2022-06-20 23:04:36.848097
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert(isinstance(jd.decode("{}"), dict))

# Generated at 2022-06-20 23:04:38.265252
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None


# Generated at 2022-06-20 23:04:39.273771
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder()

AnsibleJSONDecoder()

# Generated at 2022-06-20 23:04:43.267433
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret

    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'abc'}) == 'abc'
    msg = "Expected call to AnsibleJSONDecoder.set_secrets() before using the decoder"
    assert 'default' not in decoder._vaults, msg
    decoder.set_secrets([VaultSecret('password', 'hash', 'encryption_key')])
    assert 'default' in decoder._vaults, msg

# Generated at 2022-06-20 23:04:44.374297
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert jd

# Generated at 2022-06-20 23:04:55.398435
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    import json
    import os


# Generated at 2022-06-20 23:04:56.800565
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, json.JSONDecoder)


# Generated at 2022-06-20 23:04:58.089456
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test valid constructor
    assert AnsibleJSONDecoder is not None


# Generated at 2022-06-20 23:05:00.370494
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_instance = AnsibleJSONDecoder()
    assert isinstance(test_instance, AnsibleJSONDecoder), 'test_instance is not an instance of AnsibleJSONDecoder'
