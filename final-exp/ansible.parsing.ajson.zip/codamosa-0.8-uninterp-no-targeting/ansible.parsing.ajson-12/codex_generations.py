

# Generated at 2022-06-20 22:56:04.804460
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """
    test_AnsibleJSONDecoder checks if the constructor for AnsibleJSONDecoder
    creates an instance of the AnsibleJSONDecoder class
    """
    try:
        AnsibleJSONDecoder()
    except NameError:
        raise AssertionError("AnsibleJSONDecoder constructor failed")


# Generated at 2022-06-20 22:56:09.268277
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''
    Check if construction of class AnsibleJSONDecoder returns correct
    object type.
    '''
    assert(isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder))



# Generated at 2022-06-20 22:56:11.247516
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Construct an object of class AnsibleJSONDecoder
    AnsibleJSONDecoder()

# Generated at 2022-06-20 22:56:14.087945
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    decoder = AnsibleJSONDecoder()
    assert str(decoder) == 'AnsibleJSONDecoder()'

# Generated at 2022-06-20 22:56:26.021052
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:56:31.346721
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import ansible.module_utils.common.json as ajcj

    assert ajcj.json.JSONDecoder.object_hook != ajcj.AnsibleJSONDecoder.object_hook
    assert ajcj.json.JSONEncoder != ajcj.AnsibleJSONEncoder

# Generated at 2022-06-20 22:56:33.053981
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-20 22:56:39.885352
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.decode('{"__ansible_unsafe": "foo"}') == {'__ansible_unsafe': 'foo'}
    assert ansible_json_decoder.decode('{"__ansible_vault": "bar"}') == {'__ansible_vault': "bar"}


# Generated at 2022-06-20 22:56:52.098041
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    secret = "secret"
    secret_encoded = "$ANSIBLE_VAULT;" + VaultLib.encrypt(secret) + ";"
    secret_unsafe = wrap_var(secret_encoded)

    encoder = AnsibleJSONDecoder()
    decoded = {'ansible_vault': secret_encoded, 'ansible_unsafe': secret_encoded}
    encoder.object_hook(decoded)

    assert decoded['ansible_vault'].vault == None
    assert decoded['ansible_vault'] == secret_encoded
    assert isinstance(decoded['ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:56:57.008485
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # given
    secrets = 'test-secrets'
    args = []
    kwargs = {}

    # when
    decoder = AnsibleJSONDecoder(secrets=secrets, *args, **kwargs)

    # then
    assert decoder._vaults['default'].secrets == secrets

# Generated at 2022-06-20 22:57:06.253078
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_jsonstr = '{"__ansible_vault":"$ANSIBLE_VAULT;1.1;AES256\n33633362386236393533633765366138633733616663330a66346666616636326561343233316639333761346138636165306463966\n353836656330373135646665343363643035653331356433323734623562613762353335303766376239660a3038663836336635646238\n383739353031303261393065","answer":42}'
    decoded_json = json.loads(test_jsonstr, cls=AnsibleJSONDecoder)
    print(decoded_json)
    assert 'answer' in decoded_json

# Generated at 2022-06-20 22:57:16.612207
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = json.loads('{"a":1, "b": {"c": "ABC def GHI", "d": "{{ novar }}", "e": "{{ var }}"}, "f": "{{ var }}"}', cls=AnsibleJSONDecoder)
    assert d == {"a": 1, "b": {"c": "ABC def GHI", "d": "{{ novar }}", "e": "{{ var }}"}, "f": "{{ var }}"}
    assert d['a'] == 1
    assert isinstance(d['b'], dict)
    assert d['b']['c'] == "ABC def GHI"
    assert d['b']['d'] == "{{ novar }}"
    assert d['b']['e'] == "{{ var }}"
    assert d['f'] == "{{ var }}"

    decoder

# Generated at 2022-06-20 22:57:23.332583
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # test with __ansible_vault
    assert isinstance(decoder.object_hook({u'__ansible_vault': 'test_value'})['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # test with __ansible_unsafe
    assert decoder.object_hook({u'__ansible_unsafe': 'test_value'})['__ansible_unsafe'] == wrap_var('test_value')

# Generated at 2022-06-20 22:57:30.256877
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder()
    sample = {'__ansible_unsafe': '$ANSIBLE_VAULT;1.2;AES256;default\n3438383936353736353465333730366330666239323835343531343837363366366530626139316230\n3261653737366466623730646532306434326632303132646637373661326336323164316464623062\n34326330393836643337613838333363306161367d'}
    h = d.object_hook(sample)
    # print(h.vault.decrypt(h))
    assert h.original == sample['__ansible_unsafe']

# Generated at 2022-06-20 22:57:40.250899
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create an instance of AnsibleJSONDecoder
    ansible_json_decoder = AnsibleJSONDecoder()

    # Create an '__ansible_vault' key-value pair

# Generated at 2022-06-20 22:57:51.633106
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault = {'__ansible_vault': 'vault'}
    ansible_unsafe = {'__ansible_unsafe': 'unsafe'}
    normal = {'normal': 'normal'}
    secrets = 'test'

    assert AnsibleJSONDecoder.object_hook(ansible_vault) == ansible_vault
    assert AnsibleJSONDecoder.object_hook(ansible_unsafe) == ansible_unsafe
    assert AnsibleJSONDecoder.object_hook(normal) == normal
    assert type(AnsibleJSONDecoder.object_hook(ansible_vault)['__ansible_vault']) == AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 22:57:56.601780
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder().object_hook({'__ansible_vault': '1234'}) == AnsibleVaultEncryptedUnicode('1234')
    assert AnsibleJSONDecoder().object_hook({'__ansible_vault': '1234', '__ansible_unsafe': 'abcd'}) == \
        AnsibleVaultEncryptedUnicode('1234')
    assert AnsibleJSONDecoder().object_hook({'drink': 'tea'}) == {'drink': 'tea'}


# Generated at 2022-06-20 22:58:03.984109
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': 'mytest'}
    ansible_decoder = AnsibleJSONDecoder()
    object_value = ansible_decoder.object_hook(pairs)
    assert object_value.startswith("$ANSIBLE_VAULT;")
    assert object_value.endswith(";")
    assert object_value.split(';') == ['$ANSIBLE_VAULT', '1.1', 'AES256', 'mytest']

# Generated at 2022-06-20 22:58:14.881036
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decode_dict_1 = {
        "__ansible_vault": "test_vault_string_1"
    }
    decode_dict_2 = {
        "__ansible_unsafe": "test_unsafe_string_2"
    }
    vault_string_1 = "test_vault_string_1"
    unsafe_string_2 = "test_unsafe_string_2"

    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).\
                                               object_hook(decode_dict_1) == AnsibleVaultEncryptedUnicode(vault_string_1)
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).\
                                               object_hook(decode_dict_2) == wrap

# Generated at 2022-06-20 22:58:16.020050
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder


# Generated at 2022-06-20 22:58:27.826697
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # vault lib
    v = VaultLib(['test'])
    v._get_file_vault_secret = lambda: 'test_vault_secret'

    # ansible vault encrypted unicode
    av_enc_unico = AnsibleVaultEncryptedUnicode('test_vault_encrypted_unicode')
    av_enc_unico.vault = v
    av_enc_unico.vault.load_encrypted_data()
    av_enc_unico.vault.decrypt()

    # ansiblejsonencoder
    aje = AnsibleJSONEncoder()
    aje.vault = v

    # ansible json decoder
    ajd = AnsibleJSONDecoder()
    ajd.set_secrets(['test'])

    # json data

# Generated at 2022-06-20 22:58:29.441244
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    encoder = AnsibleJSONDecoder()
    isinstance(encoder, json.JSONDecoder)

# Generated at 2022-06-20 22:58:39.277077
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Test whether all of the default variables are present.
    ansible_decoder = AnsibleJSONDecoder()
    assert ansible_decoder.object_hook
    assert ansible_decoder.encoding == 'utf-8'
    assert ansible_decoder.object_pairs_hook == (lambda pairs: dict(pairs))
    assert ansible_decoder.parse_float == (lambda x: json.decoder.JSONDecoder.parse_float(x))
    assert ansible_decoder.parse_int == (lambda x: json.decoder.JSONDecoder.parse_int(x))
    assert ansible_decoder.parse_constant == (lambda x: json.decoder.JSONDecoder.parse_constant(x))
    assert ansible_decoder.strict == False

# Generated at 2022-06-20 22:58:51.213955
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()

    vault_value = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n6162636465666768696A6B6C6D6E6F707172737475767778797A0A\n')
    vault_value.vault = VaultLib()
    vault_string = encoder.encode({'__ansible_vault': vault_value})
    vault_dict = decoder.decode(vault_string)
    vault_object = vault_dict[u'__ansible_vault']

    assert type(vault_object) == AnsibleVaultEncryptedUnicode
    assert vault_object == vault_value

# Generated at 2022-06-20 22:59:00.357981
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    str_json = '{"__ansible_unsafe": "something", "__ansible_vault": "something", "other": "something"}'
    data = AnsibleJSONDecoder().decode(str_json)

    assert isinstance(data['__ansible_unsafe'], str)
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(data['other'], str)

    str_json = '{"__ansible_unsafe": "something", "__ansible_vault": "something"}'
    data = AnsibleJSONDecoder().decode(str_json)

    assert isinstance(data['__ansible_unsafe'], str)

# Generated at 2022-06-20 22:59:07.894343
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestVaultLib:
        def decrypt(self, value):
            return 'bar'

    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = TestVaultLib()

    assert decoder.object_hook({'__ansible_vault': 'vault_value'}) == 'bar'
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe_value'}) == wrap_var('unsafe_value')

# Generated at 2022-06-20 22:59:14.698843
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # class AnsibleJSONDecoder is not a old-style class
    assert not issubclass(AnsibleJSONDecoder, object)

    json_string = '{"key": "__ansible_vault__"}'
    json_data = json.loads(json_string)
    assert json_data['key'] == '__ansible_vault__'

    json_string = '{"key": "__ansible_vault__", "__ansible_vault": "value"}'
    json_data = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert isinstance(json_data['key'], AnsibleVaultEncryptedUnicode)

    # Remove __ansible_vault
    json_string = json_string.replace('__ansible_vault', '')
    json_data

# Generated at 2022-06-20 22:59:15.793446
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-20 22:59:17.294701
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder()
    assert cls is not None

# Generated at 2022-06-20 22:59:29.116415
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    my_vault = VaultLib(secrets=[b'asdf'])
    my_unencoded_string = "hello world, this is an unencoded string"
    my_encoded_string = b'$ANSIBLE_VAULT;1.1;AES256;ansible\n' + b'30363563396231316462303633663733326661393562366531353235313830343834626334626435\n' + b'6365633438663839653465353666336666316433393065316465620a653335373965343730633630\n' + b'31343466623831386165323266326537346462393339353734656634326266623565643135313963\n'

# Generated at 2022-06-20 22:59:38.864943
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_string = "{\"__ansible_vault\": \"{\\\"ciphertext\\\": \\\"my_ciphertext\\\", \\\"sig\\\": \\\"my_sig\\\", \\\"version\\\": 1}\", \"__ansible_unsafe\": true}"
    dec = AnsibleJSONDecoder(test_string)
    assert isinstance(dec, AnsibleJSONDecoder)
    assert isinstance(dec.object_hook, object)


# Generated at 2022-06-20 22:59:44.952226
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:52.810865
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['foo', 'bar']
    json_decoder = AnsibleJSONDecoder()
    json_decoder.set_secrets(secrets)

    # We can access the initialized parameter 'object_hook' of the instance.
    assert callable(json_decoder.object_hook)

    # The instance of AnsibleJSONDecoder return by the constructor has the vault
    # initialized.
    assert json_decoder._vaults['default'].secrets == secrets

# Generated at 2022-06-20 23:00:02.826161
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """this is a test for method object_hook of class AnsibleJSONDecoder
    """
    #case1:dict contains keys __ansible_vault and __ansible_unsafe both
    json_str = u'{"__ansible_vault": "AAAgAEAAAADAANwAAAAAAwAAAAAAAAA=",' \
               u'"__ansible_unsafe":"__ansible_unsafe"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(['password'])
    result = ansible_json_decoder.decode(json_str)

# Generated at 2022-06-20 23:00:10.176395
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook(None) is None
    assert AnsibleJSONDecoder.object_hook({}) == {}

    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': '1'}) == AnsibleVaultEncryptedUnicode("1")
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': '1'}) == wrap_var("1")


# Generated at 2022-06-20 23:00:18.118712
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:23.318376
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_str = '{"__ansible_vault": "12345"}'
    json_data = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_data, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-20 23:00:26.640913
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class AnsibleJSONDecoderTest(AnsibleJSONDecoder):
        pass

    assert AnsibleJSONDecoderTest().parse_string('{"hello": "world"}') == {'hello': 'world'}

# Generated at 2022-06-20 23:00:29.349704
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert isinstance(decoder, AnsibleJSONDecoder)

# Generated at 2022-06-20 23:00:37.152358
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # NOTE: json.loads doesn't accept byte strings, so we need
    # to encode it to a unicode string
    step1 = "this is a simple test"
    step2 = step1.encode('utf-8')
    step3 = step2.decode('utf-8')
    step4 = '{"test": "%s"}' % step3
    step5 = step4.encode('utf-8')
    step6 = step5.decode('utf-8')
    step7 = '{"test": "%s"}' % step6
    step8 = step7.encode('utf-8')
    step9 = step8.decode('utf-8')

    step10 = json.loads(step9, cls=AnsibleJSONDecoder)
    step11 = json.loads(step9)

    assert step

# Generated at 2022-06-20 23:00:51.339953
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:53.370992
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)


# Generated at 2022-06-20 23:01:05.433287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'secret'
    vault_id = 'vault-id'

# Generated at 2022-06-20 23:01:13.953496
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Unit test for method object_hook of class AnsibleJSONDecoder
    # Input arguments for method object_hook
    pairs = {
            '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;root\n3462316435396636633830336330623133353631316564633032333665336162653934366432610a6435393064393532613266613764303238623432393665623863396263356236656234360a62663562393433663736626433626539383738343033636562626163323761623663373934\n',
            '__ansible_unsafe': {'test_dict': 'test_value'}
    }

    # Output of method object_hook

# Generated at 2022-06-20 23:01:22.234850
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '''
{
  "names": [
    {
      "first_name": "John",
      "last_name": "Smith",
      "age": 25
    },
    {
      "first_name": "Jane",
      "last_name": "Doe",
      "age": 32
    }
  ]
}
'''

    output = json.loads(json_data, cls=AnsibleJSONDecoder)
    if output:
        print('OK')
    else:
        print('Failed')


# Generated at 2022-06-20 23:01:23.793560
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()


# Generated at 2022-06-20 23:01:24.833861
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:33.389900
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"__ansible_vault": "vaulted_value", "__ansible_unsafe": "unsafe_value"}'
    decoded = json.loads(data, cls=AnsibleJSONDecoder)
    assert decoded['__ansible_vault'].vault is None
    assert decoded['__ansible_unsafe'].data == 'unsafe_value'
    secrets = 'password'
    AnsibleJSONDecoder.set_secrets(secrets)
    decoded = json.loads(data, cls=AnsibleJSONDecoder)
    assert decoded['__ansible_vault'].vault.secrets == [secrets]

# Generated at 2022-06-20 23:01:38.894868
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    decoder = AnsibleJSONDecoder()

    vault = decoder.decode('''{"__ansible_vault": "some_vault_text", "some_other_data": "some_other_data_text"}''')
    assert vault['__ansible_vault'] == "some_vault_text"

# Generated at 2022-06-20 23:01:47.519706
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    encrypted_text = '$ANSIBLE_VAULT;1.1;AES256\n6239363439383433656466356564663334393865633234303962313335613064353365646463623964\n3238306262353266636564653036316434663536653430623534333637613965653567636662623463\n3333643037633961656160653137336666643939613035363964616164366439626163663866623062\n3737303966663238303636396635666137303337366538393966336562396635333762356233386134\n35663836\n'

# Generated at 2022-06-20 23:02:05.775126
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test that a vault object is being created from the JSON data
    test_data = {"__ansible_vault": "test_value"}
    test_obj = AnsibleJSONDecoder.object_hook(test_data)
    assert isinstance(test_obj, AnsibleVaultEncryptedUnicode)
    assert test_obj.data == test_data['__ansible_vault']

    # Test that a unsafe object is being created from the JSON data
    test_data = {"__ansible_unsafe": "test_value"}
    test_obj = AnsibleJSONDecoder.object_hook(test_data)
    assert hasattr(test_obj, '_ansible_unsafe_passed')

# Generated at 2022-06-20 23:02:16.925118
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import os
    import collections

    # Test __ansible_vault

# Generated at 2022-06-20 23:02:21.319403
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import text_type

    b = boolean(True, strict=False)

    assert type(b) is bool
    assert b is True

    b = boolean("true", strict=False)

    assert type(b) is bool
    assert b is True

    b = boolean("true", strict=True)
    assert isinstance(b, text_type)
    assert b == 'true'

# Generated at 2022-06-20 23:02:29.798152
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils._text import to_bytes
    data = json.loads('''{
        "__ansible_vault": "0Ab4Z$2a",
        "__ansible_unsafe": 1234
    }''', cls=AnsibleJSONDecoder)
    assert data['__ansible_vault'] == '0Ab4Z$2a'
    assert data['__ansible_unsafe'] == 1234

    data = json.loads(to_bytes('''{
        "__ansible_unsafe": "hello world"
    }'''), cls=AnsibleJSONDecoder)
    assert data['__ansible_unsafe'] == 'hello world'


# Generated at 2022-06-20 23:02:30.460479
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:02:35.745205
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert json.loads('{"__ansible_vault": "ansible"}', cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode('ansible')
    assert json.loads('{"__ansible_unsafe": "ansible"}', cls=AnsibleJSONDecoder) == wrap_var('ansible')

# Generated at 2022-06-20 23:02:39.299495
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # pylint: disable=unused-argument

    obj = AnsibleJSONDecoder()
    #assert(obj == 'AnsibleJSONDecoder')

# Generated at 2022-06-20 23:02:44.903543
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:48.528410
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_string = '{"a": 5, "__ansible_vault": "vault_text", "__ansible_unsafe": 5}'
    new_decode = AnsibleJSONDecoder()
    assert json.loads(test_string, cls=new_decode) == {'a': 5, '__ansible_vault': 'vault_text', '__ansible_unsafe': 5}


# Generated at 2022-06-20 23:02:49.157914
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:11.068724
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    #
    # Success cases
    #
    payload1 = '''{
        "__ansible_vault": "abcd",
        "__ansible_unsafe": "1234",
        "id": "418"
    }'''

    payload2 = '''{
        "__ansible_vault": "abcd",
        "__ansible_unsafe": "1234",
        "id": "418"
    }'''
    payload3 = '''{
        "__ansible_vault": "abcd",
        "__ansible_unsafe": "1234",
        "id": "418"
    }'''


# Generated at 2022-06-20 23:03:18.952281
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-20 23:03:27.098203
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Arrange
    json_s = '''{
        "__ansible_vault": "testing"
    }'''
    secrets = ['testing']

    # Act
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(secrets)
    result = json.loads(json_s, cls=ansible_json_decoder)

    # Assert
    assert result == {'__ansible_vault': 'testing'}


# Generated at 2022-06-20 23:03:36.849830
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:47.557508
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:57.496346
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder()

    # Test that __ansible_vault is decoded as
    # AnsibleVaultEncryptedUnicode
    pairs = {
        "__ansible_vault": "my_vault_value",
    }
    ans = jd.object_hook(pairs)
    assert isinstance(ans, AnsibleVaultEncryptedUnicode)
    assert ans == "my_vault_value"

    # Test that other key are not decoded
    pairs = {
        "__ansible_other_key": "my_other_value",
    }
    ans = jd.object_hook(pairs)
    assert isinstance(ans, dict)
    assert ans == pairs

    # Test that __ansible_unsafe is decoded as
    # AnsibleUnsafeText


# Generated at 2022-06-20 23:04:04.662574
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test using just the base class
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None

    # Test after setting a vault
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets('secret')
    assert decoder.object_hook is not None
    assert not decoder._vaults['default'].secrets is None


if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 23:04:14.921105
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import unittest
    import json
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    class TestAnsibleJSONDecoderObjectHook(unittest.TestCase):
        def test_AnsibleJSONDecoder_object_hook(self):
            test_json = json.dumps({'different_key':'test', '__ansible_vault':'this is encoded', '__ansible_unsafe':'test'})
            test_res = AnsibleJSONDecoder.object_hook({'different_key':'test', '__ansible_vault':'this is encoded', '__ansible_unsafe':'test'})
            test

# Generated at 2022-06-20 23:04:24.378922
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '[{"__ansible_vault": "vaulted_data_here", "__ansible_unsafe": "unsafe_data_here"}]'

    # Setup
    AnsibleJSONDecoder.set_secrets(['my_secret_password'])
    ansible_json_decoder = AnsibleJSONDecoder()

    # Execute
    result = ansible_json_decoder.decode(json_data)

    # Verify
    expected_result = [{"__ansible_vault": "vaulted_data_here", "__ansible_unsafe": "unsafe_data_here"}]
    assert result == expected_result


# Generated at 2022-06-20 23:04:33.892857
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Set key in vault and encrypt the string
    plain_string = 'hello'
    vault_pass = 'mypass'

    v = VaultLib(vault_pass)
    vault_string = v.encrypt(plain_string)

    # Create a json string to be decrypted
    json_string = '{"__ansible_vault": "' + str(vault_string) + '"}'

    # Decrypt the vault string using AnsibleJSONDecoder and compare
    a = AnsibleJSONDecoder.set_secrets([vault_pass])
    decoded_output = json.loads(json_string, cls=AnsibleJSONDecoder)

    assert decoded_output['__ansible_vault'] == plain_string

# Generated at 2022-06-20 23:05:25.754406
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # decoder = AnsibleJSONDecoder()
    # value = decoder.object_hook({"__ansible_vault": "blah"})
    # assert type(value) == AnsibleVaultEncryptedUnicode
    # assert value.vault == None
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets("blah")
    value = decoder.object_hook({"__ansible_vault": "blah"})
    assert type(value) == AnsibleVaultEncryptedUnicode
    assert value.vault != None
    assert value.vault.secrets == "blah"
    value = decoder.object_hook({"__ansible_unsafe": "blah"})
    assert type(value) == AnsibleUnsafeText

# Generated at 2022-06-20 23:05:26.855100
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:05:27.401500
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-20 23:05:30.236729
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jsondec = AnsibleJSONDecoder()
    # assert jsondec is not None
    assert jsondec._vaults == {}



# Generated at 2022-06-20 23:05:33.814055
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    d = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert d


encoders = {
    AnsibleVaultEncryptedUnicode: AnsibleJSONEncoder.encrypt_value,
}


# Generated at 2022-06-20 23:05:43.067186
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from unittest import TestCase

    class TestAnsibleJSONDecoder(TestCase):

        def test_object_hook(self):

            # check vault string
            decoder = AnsibleJSONDecoder(vault_secrets=[123])
            self.assertEqual(decoder.object_hook({'__ansible_vault': 'asdf'}), AnsibleVaultEncryptedUnicode('asdf'))

            # check unsafe string
            decoder = AnsibleJSONDecoder()
            self.assertDictEqual(decoder.object_hook({'__ansible_unsafe': {'__ansible_module_stderr': 'test'}}), {'__ansible_unsafe': 'test'})

            # not for vaults or unsafe strings

# Generated at 2022-06-20 23:05:53.497194
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest

    class Test(unittest.TestCase):
        def test_AnsibleJSONDecoder_object_hook(self):
            from ansible.vars.unsafe_proxy import wrap_var

            secrets = [b'abcdefghijklmnop']
            AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-20 23:06:01.584807
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible import constants

    # prepare secrets
    secrets = [{'secret1': 'secret1'}]

    # set secrets to decoder class
    AnsibleJSONDecoder.set_secrets(secrets)

    # prepare test data