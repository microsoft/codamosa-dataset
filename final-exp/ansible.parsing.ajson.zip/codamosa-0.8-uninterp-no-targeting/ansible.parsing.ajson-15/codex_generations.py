

# Generated at 2022-06-20 22:56:02.722097
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {'__ansible_vault': 'aA=='}
    decoder = AnsibleJSONDecoder()
    # decoder.object_hook returns a AnsibleVaultEncryptedUnicode
    assert isinstance(decoder.object_hook(data), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:56:12.577907
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets({"vault1": "secret1", "vault2": "secret2"})

# Generated at 2022-06-20 22:56:24.965387
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Setup
    data = '{"__ansible_vault": "something", "__ansible_unsafe": "something"}'
    secrets = ['my_test_secret']
    expected_vault = AnsibleVaultEncryptedUnicode('something')

    # Setup decoder
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

    # Execute
    decoded = decoder.decode(data)

    # Assert
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['__ansible_vault'].vault.secrets == secrets 
    assert decoded['__ansible_vault'].vault.secrets == expected_vault.vault.secrets

# Generated at 2022-06-20 22:56:36.072132
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestVaultLib(object):
        def decrypt(self, cipher, rawtext):
            cipher = json.loads(cipher)
            plain = ''
            for c in rawtext:
                plain += chr(ord(c) ^ cipher[0])
            return plain

    secret = 'a'
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-20 22:56:40.268696
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, json.JSONDecoder)

    assert ansible_json_decoder.object_hook != {}


# Generated at 2022-06-20 22:56:47.532888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    string = """{"__ansible_vault": "my_vault_password", "__ansible_unsafe": "my_unsafe_value"}"""
    my_dict = json.loads(string, cls=AnsibleJSONDecoder)
    assert isinstance(my_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(my_dict['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-20 22:56:55.127503
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    secret = VaultSecret('secret')
    decoder = AnsibleJSONDecoder()

    # Note that decoder._vaults is not set here because we don't need it in the test

    # Test AnsibleVaultEncryptedUnicode object
    pairs = {'__ansible_vault': 'value'}
    assert decoder.object_hook(pairs) is pairs
    pairs = {'__ansible_vault': AnsibleVaultEncryptedUnicode('value')}
    assert isinstance(decoder.object_hook(pairs)['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Test AnsibleUnsafeText object
   

# Generated at 2022-06-20 22:56:59.611142
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    raw = '{"__ansible_unsafe": "unsafe"}'
    json_pairs = json.loads(raw)
    assert decoder.object_hook(json_pairs) == {'__ansible_unsafe': wrap_var('unsafe')}

# Generated at 2022-06-20 22:57:07.423248
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    from ansible.parsing.vault import VaultSecret

    d = AnsibleJSONDecoder()

    display.vvvvv('===== ansible_json_decoder_bootstrap: test_AnsibleJSONDecoder =====')
    display.vvvvv('===== ansible_json_decoder_bootstrap: decorated_object_hook  =====')

    # Create secret object
    secrets = [
        VaultSecret('mypassword', 'mypassword'),
        VaultSecret('other_secret', 'other_secret')
    ]

    # Set secret value
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test string

# Generated at 2022-06-20 22:57:17.256756
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'pw'
    secrets = [secret]


# Generated at 2022-06-20 22:57:22.991064
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets('secret')
    data = json.loads('{"__ansible_vault": "test"}', cls=AnsibleJSONDecoder)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is not None
    assert data == 'test'

# Generated at 2022-06-20 22:57:31.429447
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import json
    from ansible.parsing.vault import VaultLib

    # setup some test data
    test_data = '{ "testkey": "testvalue" }'

    # check that we can decode plain text (base case)
    try:
        mytest = json.loads(test_data)
    except Exception as e:
        raise e

    # check that we can decode plain text after initializing an AnsibleJSONDecoder
    try:
        json.loads(test_data, cls=AnsibleJSONDecoder)
    except Exception as e:
        raise e

    # check that we can decode an encrypted value
    vault_password = 'testpassword'
    vault_secrets = [('default', vault_password)]

# Generated at 2022-06-20 22:57:34.207569
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder_obj = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder_obj, AnsibleJSONDecoder)

# Generated at 2022-06-20 22:57:37.976329
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    decoder.object_hook({'__ansible_vault': 'this is an encrypted string'})
    decoder.object_hook({'__ansible_unsafe': 'this is an unsafe object'})


# Generated at 2022-06-20 22:57:42.905920
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_value_dict = {"__ansible_vault": "123456", "__ansible_unsafe": "safe"}
    assert AnsibleJSONDecoder().object_hook(test_value_dict) == {"__ansible_vault": "123456", "__ansible_unsafe": "safe"}



# Generated at 2022-06-20 22:57:43.900366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-20 22:57:54.960917
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:01.360939
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder
    cls._vaults = {}
    cls.set_secrets(['test'])
    decoder = cls()
    assert decoder.__class__.__name__ == 'AnsibleJSONDecoder'
    assert decoder._vaults['default'].__class__.__name__ == 'VaultLib'

# Generated at 2022-06-20 22:58:10.631154
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s = '{"x": "test", "__ansible_vault": "AQAAAAAAAAAAAAAAAAAO5c5VTbW8Guz//lLJ2AgDhJJCwN/LLYvHyB+yQIBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQQsbAAAAAAA", "a": "3"}'

    # Test simple object with no additional __ansible_vault field
    try:
        o = json.loads(s, cls=AnsibleJSONDecoder)
    except Exception as e:
        assert False, "Unexpected exception %s" % str(e)

    assert len(o) == 3, "Wrong number of keys/values returned"

# Generated at 2022-06-20 22:58:11.297258
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 22:58:22.961446
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class TestEncoder(AnsibleJSONEncoder):
        def _iterencode(self, o, markers=None):
            if isinstance(o, insecure_secret):
                yield json.dumps({ "__ansible_unsafe": o.value })
            else:
                yield super(TestEncoder, self)._iterencode(o, markers)

    class insecure_secret(object):
        def __init__(self, value):
            self.value = value

    secrets = ['foo']
    encoder = TestEncoder()

    # test unsafe_secret type
    data = insecure_secret('bar')
    json_data = encoder.encode(data)
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

# Generated at 2022-06-20 22:58:32.752771
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Note: We don't need to test decoding of the vault data because it
    # is already tested in module_utils.parsing.vault.test_vault
    # This test is used to ensure that we properly handle the
    # `__ansible_unsafe` attribute in the JSON data

    # Test with an object containing __ansible_unsafe
    yaml_string = '{"__ansible_unsafe": "{{ test_var }}"}'
    json_string = '{"__ansible_unsafe": "__ansible_unsafe__ansible_unsafe__"}'

    assert AnsibleJSONDecoder().decode(json_string) == \
        yaml.load(yaml_string, Loader=yaml.FullLoader)

    # Test with an object containing a nested __ansible_unsafe
    yaml_string

# Generated at 2022-06-20 22:58:40.950098
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # test__ansible_vault
    pairs = {'__ansible_vault': 'test', 'key': 'value'}
    result = decoder.object_hook(pairs)
    assert(isinstance(result, AnsibleVaultEncryptedUnicode))
    assert(result.vault == None)
    assert(result == 'test')
    # test__ansible_unsafe
    pairs = {'__ansible_unsafe': '$$$test$$$', 'key': 'value'}
    result = decoder.object_hook(pairs)
    assert(isinstance(result, wrap_var))
    assert(result.value == '$test$')
    # test_others

# Generated at 2022-06-20 22:58:53.465932
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    with open('./test/lib/ansible/parsing/module_utils/common/data/unsafe_vars.json', 'r') as f:
        unsafe_vars = f.read()
    json_obj = json.loads(unsafe_vars, cls=AnsibleJSONDecoder)

    assert json_obj['array'] == [1, 2, 3], \
        'Error loading unsafe array'

    assert json_obj['dict'] == {'foo': 'bar'}, \
        'Error loading unsafe dict'

    assert json_obj['list'] == ['foo', 'bar'], \
        'Error loading unsafe list'

    assert json_obj['string'] == 'foo', \
        'Error loading unsafe string'

    assert json_obj['integer'] == 1, \
        'Error loading unsafe integer'



# Generated at 2022-06-20 22:59:01.535816
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:07.159150
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    secrets = ["super_secret_password"]

    assert(len(AnsibleJSONDecoder._vaults) == 0)

    obj = AnsibleJSONDecoder(["super_secret_password"])

    assert(len(AnsibleJSONDecoder._vaults) == 1)
    assert(obj._vaults['default'].secrets == secrets)

# Generated at 2022-06-20 22:59:12.346091
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_dict = dict(__ansible_vault='test_vault',__ansible_unsafe='test_unsafe')
    test_obj = AnsibleJSONDecoder().object_hook(test_dict)
    assert isinstance(test_obj, dict)
    assert isinstance(test_obj.get('__ansible_vault'), AnsibleVaultEncryptedUnicode)
    assert isinstance(test_obj.get('__ansible_unsafe'), dict)


# Generated at 2022-06-20 22:59:24.140388
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:35.847575
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    import json

    secrets = [b'12345']
    vault = VaultLib(secrets)

    # Test for vault
    text = vault.encrypt('secret')
    data = json.loads(text, cls=AnsibleJSONDecoder)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is vault

    text = '{"__ansible_vault": "%s"}' % text
    data = json.loads(text, cls=AnsibleJSONDecoder)
    assert isinstance(data, dict)
    assert '__ansible_vault' in data
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:59:42.684504
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import sys

    # Mocked object to be used in methods object_hook & set_secrets
    class VaultLibMock():

        def __init__(self):
            self.secrets = None

        def load(self, secret):
            return secret * 2

        def dump(self, data):
            return str(data) * 2

    # Create a mocked object to be used in the method object_hook below
    vault_lib = VaultLibMock()

    # Mocked method object_hook to be used in the mocked class AnsibleJSONDecoder below
    def object_hook(self, pairs):

        # Get an object which will wrap a value
        wrap_var(pairs)

        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                value = AnsibleVaultEncrypted

# Generated at 2022-06-20 22:59:49.986729
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder()

    # AnsibleJSONDecoder has a class method, set_secrets
    assert hasattr(cls, 'set_secrets')
    # AnsibleJSONDecoder has an instance method, object_hook
    assert hasattr(cls, 'object_hook')

# Generated at 2022-06-20 23:00:01.109928
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(strict=False)

    # test case: the standard type object will be return directly
    class Foo(object):
        def __init__(self, key):
            self.key = key

    class_obj = Foo("test")
    assert decoder.object_hook(class_obj) == class_obj

    # test case: the standard json format string will be return directly
    # standard string is {"a": "b"}
    standard_string = '{"a": "b"}'
    assert decoder.object_hook(standard_string) == standard_string

    # test case: the string like {"__ansible_vault": "xxxxxx"} will convert to AnsibleVaultEncryptedUnicode
    vault_value = "xxxxxx"

# Generated at 2022-06-20 23:00:03.022450
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook([]) == {}


# Generated at 2022-06-20 23:00:06.002484
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert json.loads('{"__ansible_unsafe": "abc"}', cls=AnsibleJSONDecoder) == dict(__ansible_unsafe="abc")


# Generated at 2022-06-20 23:00:16.489385
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_content = '$ANSIBLE_VAULT;1.1;AES256\n33316230376535353561666437396263616439656466653664353737616232666664360a3963313134346437303762326334616366636534386633363530646362316533643430a3839333130316563633638646637613066363664663936643038366135353633643035\n'  # noqa
    json_string = '{"__ansible_vault": "%s", "__ansible_unsafe": "bad_password"}' % (vault_content)  # noqa
    vault_pass = 'bad_password'

# Generated at 2022-06-20 23:00:28.696675
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret

    # Test vault handling
    test_pairs = {'__ansible_vault': 'foo'}
    decoder = AnsibleJSONDecoder()
    obj = decoder.object_hook(test_pairs)
    assert obj['__ansible_vault'] == 'foo'
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Test vault handling with vault password set
    secrets = [VaultSecret('foobar', 'password')]
    decoder.set_secrets(secrets)
    obj = decoder.object_hook(test_pairs)
    assert obj['__ansible_vault'] == 'foo'

# Generated at 2022-06-20 23:00:32.675415
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:38.066405
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = {'password': 'foo'}
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults['default'] == VaultLib(secrets=secrets)

    data = AnsibleJSONDecoder().decode('{ "__ansible_unsafe": "password" }')
    assert data == wrap_var('password')

# Generated at 2022-06-20 23:00:40.138522
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    dec = AnsibleJSONDecoder()
    assert dec.object_hook([]) == {}


# Generated at 2022-06-20 23:00:51.670603
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_data = u'$ANSIBLE_VAULT;1.1;AES256\n' \
                 u'35616363393036346531333261653066613232383537376132356337323066373738663333343064\n' \
                 u'6234376433356238336137323163323136646633386431396330623364433303961393634346334\n' \
                 u'38303866343532613331343265393730366163636536386462616638393635633664303966353738\n' \
                 u'38343762346361303431326262396133353065666361643538333131666262303666653933306138\n' \
                

# Generated at 2022-06-20 23:00:59.075274
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import os
    import tempfile

    secrets = tempfile.mkstemp()
    password = 'test'
    test_data = dict()
    test_data['test_key'] = 'test_value'
    test_data['test_key2'] = 'test_value2'
    test_data['test_unprotected'] = 'unprotected'

    test_file = tempfile.NamedTemporaryFile()
    with test_file as tf:
        os.close(secrets[0])
        with VaultLib(secrets[1]) as vault:
            data = vault.encrypt(AnsibleJSONEncoder.encode(test_data))
            tf.write(data)
            tf.flush()
            AnsibleJSONDecoder.set_secrets(password)
            test_decoded = AnsibleJSONDecoder().dec

# Generated at 2022-06-20 23:01:10.139680
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_secrets = ['vault_secret0', 'vault_secret1']
    import copy
    import os

    decoder_dut = AnsibleJSONDecoder()
    decoder_dut.set_secrets(vault_secrets)

    # Test for decoder AnsibleVaultEncryptedUnicode
    test_data = {
        'module_name': 'test_module',
        'module_args': {
            'a': 'test_a',
            'b': 'test_b',
            '__ansible_vault': 'vault_content'
        }
    }
    test_data_expected = copy.deepcopy(test_data)

# Generated at 2022-06-20 23:01:18.844520
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({}) == {}

    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'abc'}) == AnsibleVaultEncryptedUnicode('abc')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'abc'}) == AnsibleVaultEncryptedUnicode.from_safe_text('abc')
    try:
        AnsibleJSONDecoder.object_hook({'__not_ansible_vault': 'abc'})
        assert False, "should not be reached"
    except TypeError:
        # TypeError: encoding without a string argument
        assert True

# Generated at 2022-06-20 23:01:30.498250
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from _ast import Str
    from types import IntType
    decoder = AnsibleJSONDecoder()
    val_dict = dict()
    val_dict['__ansible_unsafe'] = "test"
    val_dict['__ansible_vault'] = "test"
    val_dict['test'] = "test"
    val_dict['test2'] = 1
    val_dict['test3'] = True
    val_dict['test4'] = [1, 2, 3]
    val_dict['test5'] = None
    result_dict = decoder.object_hook(val_dict)
    assert isinstance(result_dict['__ansible_unsafe'], Str)
    assert result_dict['test2'] == 1
    assert result_dict['test3'] is True

# Generated at 2022-06-20 23:01:37.501842
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()
    # Test AnsibleVaultEncryptedUnicode
    pairs = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\n333465643766306439383562613164363364306265343563643864383330343363646436333666\n336432636138313461323735386664623233646434373936313437353038346665313432353062\n343033373935666332653935\n'}
    decoded_pairs = dec.object_hook(pairs)
    assert isinstance(decoded_pairs, AnsibleVaultEncryptedUnicode)
    assert decoded_pairs.vault == None
   

# Generated at 2022-06-20 23:01:46.495811
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import pytest
    from units.compat.mock import patch
    from ansible.cache.vault import VaultLib, VaultSecret

    vault_key = '/tmp/vault_key'
    vault_pass = 'vault_pass'
    secret = VaultSecret(vault_key, vault_pass)

    def set_secrets(secrets):
        cls = AnsibleJSONDecoder
        cls._vaults['default'] = VaultLib(secrets=secrets)

    def object_hook(pairs):
        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                return value
        return pairs

    def object_hook_vault(pairs):
        for key in pairs:
            value = pairs[key]


# Generated at 2022-06-20 23:01:56.850223
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    ans_vault = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;init\n33353330663166653437633631653966346239616333346562383433326661643137373033333533\n34653734353036323337666365363363333735343733636430663561306664323330663533393166\n34353330353465313233396239313638343832336436363339313131336430343666383131386531\n333165303163346535613830336535386635363965\n'
    }

# Generated at 2022-06-20 23:02:05.042089
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    secrets = "correct horse battery staple"
    decoder.set_secrets(secrets)
    assert decoder._vaults["default"].secrets == secrets

    json_data = '{"__ansible_vault": "AQAj7Dr1IzwJdwLgFo24rHpYrYnRNoRlJ1shTg=="}'

    obj = decoder.object_hook(json.loads(json_data))
    assert obj
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:02:06.453949
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:02:07.971292
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    #TODO: add unit test for class constructor
    pass

# Generated at 2022-06-20 23:02:18.909925
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    pair = {'__ansible_vault': 'value'}

    instance = AnsibleJSONDecoder()
    result = instance.object_hook(pair)

    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:02:26.687161
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    cls = AnsibleJSONDecoder
    cls.set_secrets('123')
    d = '''{ "__ansible_vault": "b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='" }'''
    actual = cls.decode(d)['__ansible_vault'].decrypted
    expected = 'abcdefghijklmnopqrstuvwxyz'

    assert actual == expected


# Generated at 2022-06-20 23:02:39.300012
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:44.903757
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import yaml
    from ansible.parsing.yaml import objects
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    secrets = [os.environ['SECRET']]
    AnsibleJSONDecoder.set_secrets(secrets)

    loader = DataLoader()
    options = {"connection": "local", "module_path": ['./library/']}
    passwords = {}

# Generated at 2022-06-20 23:02:51.086974
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': '8WcKPtTbwjKsDpvKB8G7BoewpXRxVxhB4v4kV7jKq3MgV7EuSv'}) == AnsibleVaultEncryptedUnicode('8WcKPtTbwjKsDpvKB8G7BoewpXRxVxhB4v4kV7jKq3MgV7EuSv')
    assert decoder.object_hook({'__ansible_unsafe': 42}) == wrap_var(42)
    assert decoder.object_hook({'key': 'value'}) == {'key': 'value'}


# Generated at 2022-06-20 23:03:02.830894
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test the result of object_hook() when the key is '__ansible_vault'
    def _test_ansible_vault(value):
        result = AnsibleJSONDecoder.object_hook({'__ansible_vault': value})
        assert isinstance(result, AnsibleVaultEncryptedUnicode)
        assert result == value
        assert result.vault == 'default'

    _test_ansible_vault('test_value')
    _test_ansible_vault(1)

    # Test the result of object_hook() when the key is '__ansible_unsafe'
    def _test_ansible_unsafe(value):
        result = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': value})
        assert isinstance(result, AnsibleUnsafeText)


# Generated at 2022-06-20 23:03:14.065084
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class DummyVault(VaultSecret):
        """ Dummy class for unit testing only """
        def encrypt(self, b, key, iv=None, cipher=None, mode=None, m=None, k=None, salt=None, h=None, salt_size=None, is_json=False):
            return "encrypted_value"

        def decrypt(self, b, key, iv=None, cipher=None, mode=None, m=None, k=None, salt=None, h=None, salt_size=None, is_json=False):
            return "decrypted_value"


# Generated at 2022-06-20 23:03:25.102368
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;myuser\n34353233666133336434633361366338333866363561386630333437643735343035366330323331\n39306136373437333935323034356163353831663162333232365f\n', "a": "b"}

# Generated at 2022-06-20 23:03:26.582752
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test init
    assert(AnsibleJSONDecoder)


# Generated at 2022-06-20 23:03:27.812705
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:03:44.193195
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ad = AnsibleJSONDecoder()
    assert not hasattr(ad, '_vaults')

# Generated at 2022-06-20 23:03:52.110626
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultSecret

    # Test if decoding a dictionary with a key named __ansible_vault will set the vault attribute
    mock_vault_secret = VaultSecret('test secret')
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(mock_vault_secret)
    json_data = StringIO('{"__ansible_vault": "$ANSIBLE_VAULT;1.2;AES256"}')
    json_data = json.load(json_data, cls=ansible_json_decoder)
    assert mock_vault_secret == json_data.vault
    assert mock_vault_secret == ansible_json_decoder._vaults

# Generated at 2022-06-20 23:03:55.018607
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    data = decoder.decode('{"__ansible_unsafe": []}')
    assert(data == [])

# Generated at 2022-06-20 23:03:58.829461
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_obj = "{\"__ansible_vault\": \"$ANSIBLE_VAULT;1.1;AES256\"}"
    assert isinstance(json.loads(test_obj, cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:04:10.650959
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:04:14.228247
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # setup
    v = {'vaut_password': 'foo'}
    AnsibleJSONDecoder.set_secrets(**v)
    # body
    decoder = AnsibleJSONDecoder()
    # should return a class AnsibleJSONDecoder
    assert isinstance(decoder, AnsibleJSONDecoder)

# Generated at 2022-06-20 23:04:25.148597
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def _assert_object_hook(decrypted, data):
        secret = 'secret'
        AnsibleJSONDecoder.set_secrets([secret])
        decoded = json.loads(data, cls=AnsibleJSONDecoder)

        assert decoded == decrypted
        assert isinstance(decoded, dict)
        assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
        assert decoded['__ansible_vault'].vault

    def _assert_object_hook_unsafe(decrypted, data):
        secret = 'secret'
        AnsibleJSONDecoder.set_secrets([secret])

# Generated at 2022-06-20 23:04:35.471995
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import tempfile
    import shutil
    import os
    import glob

    # Test Vault
    (fd, vault_file) = tempfile.mkstemp()

# Generated at 2022-06-20 23:04:42.467379
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ('123',)
    # json string, with de-serialized vault object
    json_str = '{"__ansible_vault": "test", "__ansible_unsafe": "test"}'
    # empty dict for decoded json pairs
    pairs = dict()

    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    # make json decoder class
    decode = AnsibleJSONDecoder()
    # make json load, sending string, decoder class, and pairs for json objects
    load = json.loads(json_str, cls=decode, object_pairs_hook=pairs)
    # get pairs of decoded json object
    pairs = load.copy()

    # assert that object pairs hook is AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:04:43.505652
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:05:26.232557
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_pass = 'secret'
    secrets = [b'secret']
    value = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    json_str = json.dumps(value, cls=AnsibleJSONEncoder)
    json_str = json_str.replace('$ANSIBLE_VAULT;1.1;AES256', '$ANSIBLE_VAULT;1.1;AES256;' + vault_pass)
    AnsibleJSONDecoder.set_secrets(secrets)
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert json_obj['__ansible_vault'] == '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-20 23:05:33.609312
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_string = '{"key": "value","__ansible_vault": "[vault]", "__ansible_unsafe": "unsafe_value"}'
    ansible_json = '{"key": "value","__ansible_vault": "[vault]", "__ansible_unsafe": "unsafe_value"}'
    decoded_json = AnsibleJSONDecoder().decode(json_string)
    assert ansible_json == json.dumps(decoded_json, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 23:05:41.461782
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'hunter2'
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=None)
    ansible_json_decoder.set_secrets(secrets)
    assert isinstance(ansible_json_decoder, json.JSONDecoder)
    assert ansible_json_decoder._vaults['default'] is not None
    ansible_vault_encrypted_unicode = ansible_json_decoder.object_hook({'__ansible_vault': 'random_val'})
    assert isinstance(ansible_vault_encrypted_unicode, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:05:51.745193
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_str = """{"k1":"v1", "k2":"v2", "k3":3, "k4":"v4", \
    "__ansible_vault": "encrypted data", "__ansible_unsafe": "unsafe data"}"""
    json_dict = json.loads(json_str, cls=AnsibleJSONDecoder)

    assert isinstance(json_dict['k1'], str)
    assert isinstance(json_dict['k2'], str)
    assert isinstance(json_dict['k3'], int)
    assert isinstance(json_dict['k4'], str)

    assert isinstance(json_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:05:57.264644
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "TEST VALUE"}
    returned = dec.object_hook(pairs)
    assert isinstance(returned, AnsibleVaultEncryptedUnicode)


# To use it, simply append to the json.load() function
# Example:
#   json.load(data_file, cls=AnsibleJSONDecoder)