

# Generated at 2022-06-20 22:55:59.528792
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:56:04.370420
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
   test_json = '{"__ansible_unsafe": "{{hostvars.test_host}}"}'
   json_obj = AnsibleJSONDecoder().decode(test_json)
   assert(json_obj['__ansible_unsafe'] == '{{hostvars.test_host}}')

# Generated at 2022-06-20 22:56:10.520564
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder(strict=False)
    assert ansible_json_decoder._strict == False
    assert ansible_json_decoder.parse_float == float
    assert ansible_json_decoder.parse_int == int
    assert ansible_json_decoder.parse_constant == float
    assert ansible_json_decoder.strict == False


# Generated at 2022-06-20 22:56:22.574977
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()

    safe_native_string = enc.encode(wrap_var('foo'))
    unsafe_native_string = enc.encode(wrap_var('unsafe_foo'))

    vault_string = enc.encode(wrap_var('vault_foo'))
    vault_string_dict = {"__ansible_vault": vault_string}

    assert dec.decode(safe_native_string) == 'foo'
    assert dec.decode(unsafe_native_string) == 'unsafe_foo'

    assert dec.decode(encrypted_string) == vault_string
    assert dec.decode(encrypted_string_dict) == vault_string_dict

# Generated at 2022-06-20 22:56:32.294719
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with the only one key
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('vault_secret')
    try:
        result = decoder.object_hook({'__ansible_vault': 'value'})
    except:
        result = False

    assert(isinstance(result, AnsibleVaultEncryptedUnicode))

    # Test with more keys
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('vault_secret')
    try:
        result = decoder.object_hook({'__ansible_vault': 'value', '__ansible_unsafe': 'value'})
    except:
        result = False

    assert(isinstance(result, dict))

# Generated at 2022-06-20 22:56:39.948493
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert hasattr(AnsibleJSONDecoder, '_vaults')
    assert isinstance(AnsibleJSONDecoder._vaults, dict)
    assert hasattr(AnsibleJSONDecoder, 'set_secrets')
    assert isinstance(AnsibleJSONDecoder.set_secrets, classmethod)
    assert hasattr(AnsibleJSONDecoder, 'object_hook')
    assert isinstance(AnsibleJSONDecoder.object_hook, classmethod)


# Generated at 2022-06-20 22:56:52.150694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # import needed libs
    import os
    import unittest
    import tempfile

    # create ansible vault password file
    pwfile_fd, pwfile_path = tempfile.mkstemp(suffix='.pw')
    with os.fdopen(pwfile_fd, 'w') as pwfile:
        pwfile.write('secret')

    # create ansible vault yaml file
    vfile_fd, vfile_path = tempfile.mkstemp(suffix='.yml')
    vfile_content = "test\n"
    with os.fdopen(vfile_fd, 'w') as vfile:
        vfile.write(vfile_content)

    # create ansible vault encrypted yaml file
    encrypted_content = "!vault |\n" + vault_pass

# Generated at 2022-06-20 22:56:59.236821
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_json = '{"__ansible_vault": "This is an __ansible_vault", "test_key": "test_value"}'
    decoded_json = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert decoded_json["__ansible_vault"] == "This is an __ansible_vault"
    assert decoded_json["test_key"] == "test_value"


# Generated at 2022-06-20 22:57:02.429808
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    res = json.loads('''[{"__ansible_vault": "vaulted_data"}]''', cls=AnsibleJSONDecoder)
    assert len(res) == 1
    assert res[0].vault is not None


# Generated at 2022-06-20 22:57:14.049797
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Make sure that the decoder detects __ansible_vault
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:57:24.807806
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({}) == {}
    assert decoder.object_hook({'__ansible_vault': 'some data'}) == AnsibleVaultEncryptedUnicode('some data')
    assert decoder.object_hook({'__ansible_unsafe': {'this': 'is', '__ansible_unsafe_variables': ['a', 'dict'], '__ansible_unsafe_bytes': 'some', 'other': 'stuff'}}) == {'this': 'is', 'a': 'dict', 'some': b'bytes', 'other': 'stuff'}


# Generated at 2022-06-20 22:57:33.924367
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'secret'
    secrets = [ (secret, 'dummy') ]
    json_data = '{"__ansible_vault": "__ANSIBLE_VAULT;1.1;AES256\n' + secret + '\n"}'
    decoded = AnsibleJSONDecoder.decode(json_data)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded._vault is None
    assert decoded.encoding == 'AES256'
    AnsibleJSONDecoder.set_secrets(secrets)
    assert decoded._vault.secrets == secrets

# Generated at 2022-06-20 22:57:41.330660
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Use an arbitrary password to create the VaultLib object
    vault = VaultLib(secrets=['secret1'])
    vault_str = vault.dump('YWJjZA==')

    # Use an arbitrary password to create the AnsibleJSONDecoder object
    decoder = AnsibleJSONDecoder(object_hook=lambda pairs: pairs)
    decoder.set_secrets(secrets=['secret1'])
    data = decoder.decode('{"__ansible_vault": "%s"}' % vault_str)

    assert data == {'__ansible_vault': u'abcda'}, \
        "AnsibleJSONDecoder fails to decrypt AnsibleVaultEncryptedUnicode string"

# Generated at 2022-06-20 22:57:52.362133
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var
    dec = AnsibleJSONDecoder()

    # test for __ansible_vault
    dec._vaults = {'default': type('default', (object, ), {'decrypt': lambda self, value: value})()}
    result = dec.object_hook({'__ansible_vault': 'value'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # test for __ansible_unsafe
    result = dec.object_hook({'__ansible_unsafe': 'value'})
    assert isinstance(result, AnsibleUnsafeText)

    # test for anything without __ansible_vault or __ansible_unsafe

# Generated at 2022-06-20 22:57:54.960319
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    # test object hook
    assert not decoder.object_hook({'__ansible_vault': 'test'})
    # test init
    assert decoder.object_hook

# Generated at 2022-06-20 22:58:06.719849
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    data = json.dumps({
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible1234567;4567890321654987021345867',
        '__ansible_unsafe': 'You should see this'
    }, cls=AnsibleJSONEncoder)

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['ansible1234567'])

    data = json.loads(data, cls=decoder)
    assert isinstance(data, dict)
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:58:12.392209
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({}) == {}
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')


# Generated at 2022-06-20 22:58:14.331407
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        AnsibleJSONDecoder([])
        assert False
    except:
        assert True


# Generated at 2022-06-20 22:58:21.657690
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    json_str = '{"__ansible_unsafe": "{{lookup("file", "./test.txt")}}", "__ansible_vault": "vault_test"}'
    decoded_json_str = decoder.decode(json_str)
    assert isinstance(decoded_json_str['__ansible_unsafe'].obj, str)
    assert isinstance(decoded_json_str['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:58:30.148667
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:40.047214
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    data = {
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;atestkey\n" +
                           "36353233633763376234313733386533366262316335613434383738303732313230366533\n" +
                           "6537616466653862500a383465646534616635376136636262356163336536396366623837\n" +
                           "31633038323563663937613734646631633764663565646636356466\n",
        "__ansible_unsafe": "hello world"
    }

    dec = AnsibleJSONDecoder()
    obj = dec.decode(json.dumps(data))

    assert isinstance

# Generated at 2022-06-20 22:58:51.994229
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six.moves import StringIO

    # Construct fake secret file
    secret_file = StringIO()
    vault_secret = VaultSecret('foo', 'bar')

# Generated at 2022-06-20 22:59:00.837126
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # prepare data
    vault_secret = 'this is my vault secret'
    vault_string = '__ansible_vault; this is my vault string data'
    unsafe_string = '__ansible_unsafe; this is my unsafe string data'
    safe_string = 'this is my safe string data'
    list_of_strings = [vault_string, unsafe_string, safe_string]
    json_string = json.dumps(list_of_strings, cls=AnsibleJSONEncoder)

    # initialize
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(vault_secret)

    # test
    decoded = decoder.decode(json_string)
    assert len(decoded) == 3

# Generated at 2022-06-20 22:59:11.609216
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secrets = {'secret': 'password'}
    AnsibleJSONDecoder.set_secrets(secrets)
    key = '__ansible_vault'

# Generated at 2022-06-20 22:59:16.815856
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    obj = json.dumps({'key': 'value'}, cls=AnsibleJSONEncoder)
    AnsibleJSONDecoder.set_secrets(['password1', 'password2'])
    decoded_obj = AnsibleJSONDecoder().decode(obj)
    assert decoded_obj.__eq__({'key': 'value'})

# Generated at 2022-06-20 22:59:28.665013
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'secret'
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-20 22:59:30.535667
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder.set_secrets is not None

# Generated at 2022-06-20 22:59:33.425679
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()

    assert AnsibleJSONEncoder()


if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 22:59:41.558881
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'test_string'
    try:
        from vault_cli import VaultCLI
    except ImportError:
        pass
    else:
        vault = VaultCLI(secrets_data=secrets)
        vault.write('secret_key', {'secret_value': 'secret_data'})
        secrets = vault.secrets['secret_key']

    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults['default'].secrets == secrets

    # Variables values

# Generated at 2022-06-20 22:59:53.919114
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Create a dict with a key
    dict_with_key = dict()
    dict_with_key["__ansible_vault"] = "hello"

    # Create a dict with a key and a value
    dict_with_key_and_value = dict()
    dict_with_key_and_value["__ansible_vault"] = "hello"

    # Create a dict with a key and a value
    dict_with_key_and_value_unsafe = dict()
    dict_with_key_and_value_unsafe["__ansible_unsafe"] = "hello"

    # Create a dict without a key
    dict_without_key = dict()
    dict_without_key["__ansible_something"] = "hello"

    # Create the decoder
    decoder = AnsibleJSONDecoder()

    #

# Generated at 2022-06-20 22:59:58.690677
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for non-string value
    pairs = {'a':5}
    decoder = AnsibleJSONDecoder()
    unsafe_value = decoder.object_hook(pairs)
    assert unsafe_value == {'a': 5}

# Generated at 2022-06-20 23:00:06.313337
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_str = '{"__ansible_vault": "AES256:sRwy+p1e0/8CvS/S/o2K3q0/vg1sDNaRNPFy4x8zwj4\n", "__ansible_unsafe": false}'
    output = json.loads(test_str, cls=AnsibleJSONDecoder)
    assert '__ansible_vault' in output
    assert '__ansible_unsafe' in output



# Generated at 2022-06-20 23:00:16.631394
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:22.378316
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'})
    decoder.object_hook({'__ansible_unsafe': '$ANSIBLE_UNSAFE'})


# Generated at 2022-06-20 23:00:29.818286
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_id = 'vault_id'
    vault_secrets = [b'vault_secret']
    vault_secrets_dict = {vault_id: vault_secrets}

    json_decoder = AnsibleJSONDecoder()
    assert json_decoder._vaults == {}

    json_decoder.set_secrets(vault_secrets_dict)
    assert json_decoder._vaults['default'] is not None
    assert json_decoder._vaults['default'].secrets == vault_secrets_dict

# Generated at 2022-06-20 23:00:30.331979
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder



# Generated at 2022-06-20 23:00:41.547595
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Generate AnsibleVaultEncryptedUnicode object
    v_string = '$ANSIBLE_VAULT;1.1;AES256\n383634363261353661633135390a65353431306433323662653433303331393133653362316265393\n36336161633239316462653264323030356134313631650a37383962323134666533316632323565\n61303034386466353562383064613234316338616336363337636365666562323563623535396134\n32383132306638\n'
    v_string_expected = 'VaultLib not initialized'

# Generated at 2022-06-20 23:00:52.947929
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test normal case, no vault
    decoder = AnsibleJSONDecoder()

    data = dict(
        k1='v1',
    )
    assert decoder.object_hook(data) == data

    # Test __ansible_vault
    decoder = AnsibleJSONDecoder()

    data = dict(
        k1='v1',
        k2='v2',
        __ansible_vault='jd983hd983hfu9382jbd982bd982bd982b',
    )
    assert isinstance(decoder.object_hook(data)['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoder.object_hook(data)['__ansible_vault'].vault is None
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-20 23:01:04.780556
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:14.293510
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_pass_file_path = u'/tmp/xxx'

    vault_secrets = [vault_pass_file_path]
    secrets = '/'.join(vault_secrets)

    plain_text = u'This is plain text'
    cipher_text = u'$ANSIBLE_VAULT;1.1'

    # Test the condition when ansible vault is disabled in code
    AnsibleJSONDecoder.set_secrets([])

    json_decoder = AnsibleJSONDecoder()
    result = json_decoder.object_hook({u'__ansible_vault': cipher_text})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is None

    result = json_decoder.object_hook({u'__ansible_unsafe': cipher_text})


# Generated at 2022-06-20 23:01:27.859745
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
    decoder = AnsibleJSONDecoder.set_secrets(secrets=secret)
    j = json.dumps({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\nzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz\nzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz\nz1OvVk/0Ag/b3g8S/Y0agA==\n'}, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 23:01:33.756339
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'test value'

    decoder = AnsibleJSONDecoder(object_pairs_hook=dict)
    decoder.set_secrets(secrets)

    json_value = json.dumps({'__ansible_vault': 'test value'}, cls=AnsibleJSONEncoder)
    decoded_object = decoder.decode(json_value)

    assert decoded_object == {'__ansible_vault': 'test value'}

# Generated at 2022-06-20 23:01:39.829617
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets(b"test")
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    obj = decoder.decode('{ "__ansible_vault": "test" }')
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault is not None

# Generated at 2022-06-20 23:01:41.658824
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None


# Generated at 2022-06-20 23:01:50.177272
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:55.317470
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    data = '{"__ansible_vault": "VaultString", ' \
           '"__ansible_unsafe": "UnsafeText"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    # execute
    result = ansible_json_decoder.object_hook(json.loads(data))
    # assert
    assert result['__ansible_vault'] == AnsibleVaultEncryptedUnicode('VaultString')
    assert result['__ansible_unsafe'] == AnsibleUnsafeText('UnsafeText')



# Generated at 2022-06-20 23:02:06.150317
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class AnsibleJSONDecoderTest:
        def __init__(self):
            self.file_path = None
            self.file_content = None
            self.json_dict = {}
            self.json_string = None

    test_obj = AnsibleJSONDecoderTest()
    test_obj.file_path = "./test.json"
    test_obj.file_content = "String of file"
    test_obj.json_dict["Vault"] = "String of vault"
    test_obj.json_string = '''{"Vault": "String of vault"}'''
    json_obj = json.loads(test_obj.json_string)
    for key, value in json_obj.items():
        # Check if object will be decoded as string and return as dict
        assert(isinstance(value, str))


# Generated at 2022-06-20 23:02:07.158524
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO
    assert True

# Generated at 2022-06-20 23:02:10.490354
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Constructor should return an object of class AnsibleJSONDecoder
    obj = AnsibleJSONDecoder()
    assert isinstance(obj, AnsibleJSONDecoder)


# Generated at 2022-06-20 23:02:21.336390
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:30.447522
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['mypassword']
    test_json_input = {'__ansible_vault': 'mypassword'}
    test_json_expected_output = {'__ansible_vault': AnsibleVaultEncryptedUnicode('mypassword')}

    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=secrets)
    decoded = decoder.object_hook(test_json_input)
    assert(decoded == test_json_expected_output)

# Generated at 2022-06-20 23:02:32.449717
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['password']
    jd = AnsibleJSONDecoder.set_secrets(secrets)



# Generated at 2022-06-20 23:02:33.174049
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:02:36.885399
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = json.JSONDecoder()
    assert decoder.object_hook == None

    d = AnsibleJSONDecoder()
    assert d.object_hook == d.object_hook
    assert d._vaults == {}



# Generated at 2022-06-20 23:02:48.533075
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;some_keys;some_value;some_checksum\nU2FsdGVkX18UWSG6/gjJhP0/0xq3MOL/DYss99F0bbY=\n'}
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:02:49.585848
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder(object_pairs_hook=AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-20 23:02:51.484168
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ''' Unit test for constructor of class AnsibleJSONDecoder '''
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:59.361756
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder
    assert isinstance(decoder, json.JSONDecoder)
    assert decoder.object_hook
    assert isinstance(decoder.object_hook, AnsibleJSONDecoder.object_hook.__class__)
    assert '__ansible_vault' not in decoder._json_decoder__vaults
    assert 'default' not in decoder._json_decoder__vaults


# Generated at 2022-06-20 23:03:09.385429
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:14.508974
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    fake_secret = 'fake_secret'
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    decoder.set_secrets(fake_secret)
    assert decoder._vaults['default'] == VaultLib(secrets=fake_secret)
    assert decoder._vaults['default'].secrets == fake_secret


# Generated at 2022-06-20 23:03:32.004506
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    item = (decoder.object_hook(dict(__ansible_vault="foo")))
    assert isinstance(item, AnsibleVaultEncryptedUnicode)

    decoder = AnsibleJSONDecoder()
    item = (decoder.object_hook(dict(__ansible_vault="foo", __ansible_unsafe="bar")))
    assert isinstance(item, AnsibleVaultEncryptedUnicode)
    assert isinstance(item.__ansible_unsafe__, dict)
    assert item.__ansible_unsafe__['data'] == "bar"

# Generated at 2022-06-20 23:03:43.408814
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import ansible.utils.unsafe_proxy
    from ansible.parsing.vault import VaultLib
    import copy
    import json

    # Set vault password and create ansible vault object
    vault_password = 'test_password'
    vault = VaultLib([vault_password])

    # Create and decode some encrypted variable
    encrypted_value = vault.encrypt('test_value')
    decoded_value = AnsibleJSONDecoder.object_hook({'__ansible_vault': encrypted_value})

    # Assert that decoded value is AnsibleVaultEncryptedUnicode object
    assert isinstance(decoded_value, AnsibleVaultEncryptedUnicode)

    # Assert that AnsibleVaultEncryptedUnicode object has a vault attribute
    assert hasattr(decoded_value, 'vault')



# Generated at 2022-06-20 23:03:46.985413
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_dict = {'__ansible_vault': 'vault test'}
    ansible_unsafe_dict = {'__ansible_unsafe': 'unsafe test'}
    ansible_vault_json_str = json.dumps(ansible_vault_dict)
    ansible_unsafe_json_str = json.dumps(ansible_unsafe_dict)

    ansible_vault_dict_load = json.loads(ansible_vault_json_str, cls=AnsibleJSONDecoder)
    ansible_unsafe_dict_load = json.loads(ansible_unsafe_json_str, cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 23:03:56.535037
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'secret'

    # AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:04:05.190957
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Normal test for object_hook
    value = decoder.object_hook({'__ansible_vault': 'test_value'})
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.vault == None
    assert value == 'test_value'

    # Normal test for object_hook with __ansible_unsafe
    value = decoder.object_hook({'__ansible_unsafe': 'test_value'})
    assert isinstance(value, wrap_var)
    assert value == 'test_value'

# Generated at 2022-06-20 23:04:15.343316
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'hello'
    vault_json = '{"__ansible_vault": "U2FsdGVkX1/hvYXI0R8sLtTycH2lJQk6UFeutRJRJMI="}'
    unsafe_json = '{"__ansible_unsafe": "something"}'

    decoder = AnsibleJSONDecoder.set_secrets(secret)
    vault_dict = json.loads(vault_json, cls=AnsibleJSONDecoder)
    unsafe_dict = json.loads(unsafe_json, cls=AnsibleJSONDecoder)


# Generated at 2022-06-20 23:04:18.914935
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = open('/tmp/vault_secret', 'r').read()
    decoder = AnsibleJSONDecoder()
    # this is the first test
    decoder.set_secrets(secrets)
    print(decoder)

# Generated at 2022-06-20 23:04:20.961948
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert isinstance(a, json.JSONDecoder)


# Generated at 2022-06-20 23:04:22.618919
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_decoder = AnsibleJSONDecoder




# Generated at 2022-06-20 23:04:32.451606
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs1 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\nblah\n'}
    pairs2 = {'__ansible_unsafe': {'__ansible_arguments': ['test_module', 'my_argument'], '__ansible_module__': 'test_module'}}
    pairs3 = {'ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\nblah\n'}

    decoder = AnsibleJSONDecoder()

    assert isinstance(decoder.object_hook(pairs1), AnsibleVaultEncryptedUnicode)
    assert hasattr(decoder.object_hook(pairs1), 'vault')
    assert decoder.object_hook(pairs1).vault == 'default'

# Generated at 2022-06-20 23:04:58.977884
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # GIVEN
    ansible_vault_string = "{'__ansible_vault': 'ansible-vault value', 'some_key': 'some_value'}"
    # THEN
    AnsibleJSONDecoder.set_secrets('test_secret')
    result = AnsibleJSONDecoder().decode(ansible_vault_string)
    assert result['__ansible_vault'] == 'ansible-vault value'
    assert result['__ansible_vault'].vault.secrets == 'test_secret'
    assert result['some_key'] == 'some_value'


# Generated at 2022-06-20 23:05:03.672564
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [ 'foo' ]
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

    import ansible.parsing.vault as vault
    value = vault.encrypt_string("bar", secrets=secrets)
    value = vault.encrypt_string("bar", secrets=secrets)
    data = '{ "__ansible_vault": "' + value + '"}'
    obj = json.loads(data, cls=decoder)
    assert obj['__ansible_vault'] == 'bar'



# Generated at 2022-06-20 23:05:05.375125
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """ Test constructor of class AnsibleJSONDecoder """
    pass

# Generated at 2022-06-20 23:05:11.772662
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_input = '{"__ansible_vault": "foo", "__ansible_unsafe": "bar"}'
    obj = json.loads(test_input, cls=AnsibleJSONDecoder)

    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:05:16.427534
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """
    AnsibleJSONDecoder.__init__()
    """
    import json
    json_decoder = json.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    ansible_json_decoder = AnsibleJSONDecoder()

    assert(json_decoder.object_hook == ansible_json_decoder.object_hook)

# Generated at 2022-06-20 23:05:24.713628
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:05:31.030788
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    secrets = ['secret']

    # No secrets set
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

    # Secrets set
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults['default'].secrets == secrets



# Generated at 2022-06-20 23:05:40.931712
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['12345']

# Generated at 2022-06-20 23:05:43.601859
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)


# Generated at 2022-06-20 23:05:53.500654
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = "foobar"