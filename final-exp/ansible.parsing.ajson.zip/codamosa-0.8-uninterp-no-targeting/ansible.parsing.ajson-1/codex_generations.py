

# Generated at 2022-06-20 22:55:59.166861
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jsonDecoder = AnsibleJSONDecoder()
    assert(jsonDecoder is not None)

# Generated at 2022-06-20 22:56:00.830404
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO: Add unit test here
    pass


# Generated at 2022-06-20 22:56:11.412124
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test when key is __ansible_vault
    pairs = {
        "foo": "bar",
        "__ansible_vault": "foo"
    }
    obj = decoder.object_hook(pairs)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault == None
    assert obj == "foo"

    # Test when key is __ansible_unsafe
    pairs = {
        "foo": "bar",
        "__ansible_unsafe": True
    }
    obj = decoder.object_hook(pairs)
    assert obj == True
    assert obj.__class__.__name__ == 'bool'

    # Test when key is neither __ansible_vault nor __ansible_unsafe


# Generated at 2022-06-20 22:56:20.461631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = ['{"__ansible_vault": "123", "__ansible_unsafe": "ABC"}']
    json_decoder = AnsibleJSONDecoder()
    for item in data:
        json_data = json.loads(item, cls=json_decoder)
        assert json_data.get('__ansible_vault') == '123'
        assert json_data.get('__ansible_unsafe') == 'ABC'


# Test function for class AnsibleJSONDecoder

# Generated at 2022-06-20 22:56:29.813111
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets(['123'])

# Generated at 2022-06-20 22:56:35.008391
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=lambda d: {'a': d[u'a']})
    # test when the key is a string
    assert decoder.object_hook({'a': '1'}) == {'a': '1'}
    # test when the key is a unicode
    assert decoder.object_hook({u'a': u'1'}) == {'a': '1'}

# Generated at 2022-06-20 22:56:47.585074
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-20 22:56:50.476843
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '{"__ansible_vault": "string", "__ansible_unsafe": 5}'
    json.loads(data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 22:56:56.648413
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'$thisWillNotBeUsed']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 22:57:01.199188
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder_instance = AnsibleJSONDecoder()
    vault_class = AnsibleVaultEncryptedUnicode("test")
    assert decoder_instance.object_hook({'__ansible_vault': vault_class.get_decrypted_text()}) == {"__ansible_vault": vault_class}


# Generated at 2022-06-20 22:57:13.872088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test variable with value_type: bool
    variable = {'__ansible_unsafe': True}
    assert AnsibleJSONDecoder.object_hook(variable) == wrap_var(True)

    # test variable with value_type: string
    variable = {'__ansible_unsafe': 'test'}
    assert AnsibleJSONDecoder.object_hook(variable) == wrap_var('test')

    # test variable with value_type: int
    variable = {'__ansible_unsafe': 1}
    assert AnsibleJSONDecoder.object_hook(variable) == wrap_var(1)

    # test variable with value_type: list
    variable = {'__ansible_unsafe': [1, 2, 3]}

# Generated at 2022-06-20 22:57:19.108104
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=None)

    assert ansible_json_decoder._vaults == {}, '_vaults instance variable not initialized correctly'
    assert ansible_json_decoder.object_hook is not None, 'object_hook instance variable not initialized correctly'

# Generated at 2022-06-20 22:57:27.904468
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '{"__ansible_vault": "VnZvbHVtZVJ1bGUgLXNlY3JldCBrZXk=", "__ansible_unsafe": {"foo": "bar"} }'
    json_secrets = {"vault_password": "vaultrule -secret key"}
    json_decoder = AnsibleJSONDecoder.set_secrets(json_secrets)
    decoded_json = AnsibleJSONDecoder(object_pairs_hook=json_decoder)
    decoded_json = decoded_json.decode(json_data)
    assert decoded_json["__ansible_vault"] == "VnZvbHVtZVJ1bGUgLXNlY3JldCBrZXk="
    assert decoded_

# Generated at 2022-06-20 22:57:28.609612
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 22:57:29.987777
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder, 'AnsibleJSONDecoder class'



# Generated at 2022-06-20 22:57:36.324575
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j = json.loads('{"__ansible_vault": "[vault.encrypted]", "__ansible_unsafe": "unsafe"}', cls=AnsibleJSONDecoder)
    assert isinstance(j, dict)
    assert isinstance(j['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(j['__ansible_unsafe'], str)



# Generated at 2022-06-20 22:57:43.160861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from datetime import datetime as dt
    from ansible.module_utils._text import to_native

    key = to_native(dt.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'))[:-3].encode()
    secret = to_native(dt.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'))[:-3]

    # Escaping the required characters is part of the test of this method
    test_secret = secret.replace('\\', '\\\\').replace('"', '\\"').replace('/', '\\/')

    # Set up vault and object
    vault = VaultLib(secrets=[key])
    encrypted_object = vault.encrypt(test_secret)

    # Instantiate

# Generated at 2022-06-20 22:57:53.545111
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Ensure that the "__ansible_vault" json key returns an AnsibleVaultEncryptedUnicode object
    import json
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    json_blob = '''
    {
        "__ansible_vault": "encrypted data",
        "__ansible_unsafe": "unsafe data"
    }
    '''
    secrets = ['pass123']
    ansiblejson_decoder = AnsibleJSONDecoder()
    ansiblejson_decoder.set_secrets(secrets)
    result = json.loads(json_blob, cls=ansiblejson_decoder)

# Generated at 2022-06-20 22:57:54.590582
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-20 22:57:56.815630
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder([])
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-20 22:58:07.687896
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = { "obj": { "__ansible_vault": "this value is encrypted" } }
    obj = AnsibleJSONDecoder(data)
    assert obj._vaults == {}

    ansible_vault_passwords = {'default': 'asdf'}
    obj = AnsibleJSONDecoder.set_secrets(ansible_vault_passwords)
    assert obj == None

    ansible_vault_passwords = {'default': 'asdf'}
    AnsibleJSONDecoder.set_secrets(ansible_vault_passwords)
    obj = AnsibleJSONDecoder(data)
    assert obj._vaults != {}



# Generated at 2022-06-20 22:58:14.282698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_decoder = AnsibleJSONDecoder()
    secret = 'foo'
    encrypted_text = ansible_json_encoder.encode(AnsibleVaultEncryptedUnicode(secret))
    ansible_json_decoder.set_secrets([secret])

    assert ansible_json_decoder.decode(encrypted_text) == secret

# Generated at 2022-06-20 22:58:22.021985
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    q = b'{"k": "__ansible_vault", "v": "v"}'
    x = json.loads(q, cls=AnsibleJSONDecoder)
    assert isinstance(x, dict)

    x = json.loads(q, cls=AnsibleJSONDecoder, object_hook=lambda x: x)
    assert isinstance(x, dict)

    x = json.loads(q, cls=AnsibleJSONDecoder, object_hook=lambda x: x['k'])
    assert isinstance(x, str)



# Generated at 2022-06-20 22:58:31.496627
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultSecret

    vault_pass = VaultSecret('vault_pass', password='pwd')

    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(vault_pass)
    assert decoder._vaults['default'].secrets[0]._password == 'pwd'

    decoder = AnsibleJSONDecoder()
    assert type(decoder.decode('{"__ansible_unsafe": "test"}')) == dict

    decrypt = AnsibleJSONDecoder()
    decrypt.set_secrets(vault_pass)

# Generated at 2022-06-20 22:58:40.259306
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'ansible'
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-20 22:58:42.907428
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secrets']
    sut = AnsibleJSONDecoder()
    sut.set_secrets(secrets)


# Generated at 2022-06-20 22:58:54.689197
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret1']

# Generated at 2022-06-20 22:58:55.271019
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-20 22:59:07.006763
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {
        'not_encrypted': 'test_string',
        '__ansible_vault': 'vault_encrypted_string',
        '__ansible_unsafe': 'unsafe_string'
    }

    vault_decoder = AnsibleJSONDecoder.object_hook(data)

    assert isinstance(vault_decoder['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert '__ansible_unsafe' in vault_decoder
    assert 'not_encrypted' in vault_decoder

    vault_decoder_lazy_value = vault_decoder['__ansible_unsafe']

    assert isinstance(vault_decoder_lazy_value, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:59:13.195155
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import json

    my_JSON_decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    my_data = '{"key1":"value1", "__ansible_vault": "foo", "__ansible_unsafe": "spam"}'
    my_obj = my_JSON_decoder.decode(my_data)
    assert my_obj == {
        'key1': 'value1',
        '__ansible_vault': 'foo',
        '__ansible_unsafe': AnsibleUnsafeText('spam')
    }

# Generated at 2022-06-20 22:59:28.768067
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.module_utils.six import PY3

    class MyCount(object):
        def __init__(self, num):
            self.num = num

        def __str__(self):
            return str(self.num)

        def __eq__(self, other):
            return self.num == other

    class MyString(object):
        def __init__(self, string):
            self.string = string

        def __str__(self):
            return str(self.string)

        def __eq__(self, other):
            return self.string == other


# Generated at 2022-06-20 22:59:39.108473
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    expected_result = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;myuserid\n1234\n'}
    input_data = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;myuserid\n1234\n"}'
    result = json.loads(input_data, cls=AnsibleJSONDecoder, parse_float=None, parse_int=None, parse_constant=None, object_pairs_hook=None)

    assert(expected_result == result)

    expected_result = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;myuserid\n1234\n'}

# Generated at 2022-06-20 22:59:41.911334
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ["junk", "foo", "bar", "baz"]
    AnsibleJSONDecoder.set_secrets(secrets)

    decoder = AnsibleJSONDecoder()
    assert decoder is not None


# Generated at 2022-06-20 22:59:43.938618
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Create an instance of class AnsibleJSONDecoder by calling the constructor
    assert AnsibleJSONDecoder()


# Generated at 2022-06-20 22:59:56.706735
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    json_decoder = AnsibleJSONDecoder()
    # For object with __ansible_vault as key, should return AnsibleVaultEncryptedUnicode object
    pairs = {'__ansible_vault': 'value'}
    assert isinstance(json_decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)
    # For object with __ansible_unsafe as key, should return unwrapped value
    pairs = {'__ansible_unsafe': [1, 2, 3]}
    assert json_decoder.object_hook(pairs) == [1, 2, 3]
    # For obect without special keys, should return as-is
    pairs = {'foo': 'bar'}

# Generated at 2022-06-20 23:00:00.672383
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets(['password'])
    decoder = AnsibleJSONDecoder()

    # This will not raise any exception
    decoder.decode(u'{"__ansible_vault": "AES256:VaultTests/ansible_vault_password"}')

# Generated at 2022-06-20 23:00:07.566641
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.__class__.__name__ == 'AnsibleJSONDecoder'
    assert decoder.__class__.__bases__[0].__name__ == 'JSONDecoder'
    assert decoder.__class__.__bases__[0].__bases__[0].__name__ == 'object'
    assert decoder.__dict__['object_hook']() == {}

# Generated at 2022-06-20 23:00:13.713674
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert decoder.vaults == {}

    secrets = ['blah']
    decoder.set_secrets(secrets)

    assert decoder.vaults['default'].secrets == secrets

if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 23:00:20.744623
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j_str = '''
{
    "__ansible_vault": "ASDASDSAFSAFASDSAF",
    "a": "b"
}
'''
    obj = AnsibleJSONDecoder().decode(j_str)
    if isinstance(obj, dict) and 'a' in obj and obj['a'] == 'b':
        return True


# Generated at 2022-06-20 23:00:30.642656
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    std_jsonDecoder = json.JSONDecoder()
    assert std_jsonDecoder is not None
    assert hasattr(std_jsonDecoder, 'object_hook')
    assert std_jsonDecoder.object_hook is None
    std_jsonDecoder.object_hook = 1
    assert std_jsonDecoder.object_hook == 1

    ansible_jsonDecoder = AnsibleJSONDecoder()
    assert ansible_jsonDecoder is not None
    assert hasattr(ansible_jsonDecoder, 'object_hook')
    assert callable(ansible_jsonDecoder.object_hook)
    ansible_jsonDecoder.object_hook = 1
    assert ansible_jsonDecoder.object_hook == 1


# Generated at 2022-06-20 23:00:42.918993
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Test data
    sample_input = '{"test": "test_text", "test2": "test_text2"}'
    sample_output = {"test": "test_text", "test2": "test_text2"}

    # Initialize decoder
    ajd = AnsibleJSONDecoder()

    # Convert JSON to dictionary using AnsibleJSONDecoder
    output_dict = json.loads(sample_input, cls=ajd)

    # Test if dictionary created is same as sample_output
    assert output_dict == sample_output

# Generated at 2022-06-20 23:00:55.142469
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # ensure string is not deserialized
    json.loads('"__ansible_vault"', cls=AnsibleJSONDecoder)
    # ensure string is not deserialized
    json.loads('"__ansible_unsafe"', cls=AnsibleJSONDecoder)
    # ensure AnsibleVaultEncryptedUnicode is correctly deserialized
    assert isinstance(json.loads('{"__ansible_vault": "value"}', cls=AnsibleJSONDecoder)['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # ensure wrap_var is correctly deserialized
    assert isinstance(json.loads('{"__ansible_unsafe": "value"}', cls=AnsibleJSONDecoder)['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-20 23:00:58.997851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'hello'}) == wrap_var('hello')
    assert decoder.object_hook({'__ansible_unsafe': {'foo': 'bar'}}) == wrap_var({'foo': 'bar'})

# Generated at 2022-06-20 23:01:02.562399
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = '2'
    secrets = [secret]
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secrets

# Generated at 2022-06-20 23:01:11.242990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # create a AnsibleUnsafeText
    unsafe_text = AnsibleUnsafeText('unsafe_text')
    # create a dict to be decoded by AnsibleJSONDecoder
    json_data = {}
    json_data['__ansible_unsafe'] = unsafe_text
    # create a AnsibleJSONDecoder object
    json_decoder = AnsibleJSONDecoder()
    # test AnsibleJSONDecoder.object_hook()
    object_hook_data = json_decoder.object_hook(json_data)
    assert object_hook_data['__ansible_unsafe'].data == unsafe_text

# Generated at 2022-06-20 23:01:21.663302
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = '$ANSIBLE_VAULT;1.1;AES256\n33346662353437316135646532616166356539326361613261333935666230376634623061633562310a39666365336331616538343833316435393366373632366135636431336338643432623264380a3430666663386231303335303333353861623431363038353934613235636334636332656265\n'
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 23:01:24.206766
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, AnsibleJSONDecoder)



# Generated at 2022-06-20 23:01:34.109018
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'ansible'
    json_str = '{"__ansible_vault": "AQAAAAEAAAB+L6UJG6UY7fX9+uyx30Jl0vhQlQ7VxtRwQeO7kFvC8Wc5V5rAX3uqInVbv5rJFV7Rg2wFQP7vN8hcWGBzr5Pqxu/7A=="}'

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([secret])
    data = decoder.decode(json_str)

    assert data['__ansible_vault'] == AnsibleVaultEncryptedUnicode(data['__ansible_vault'])

# Generated at 2022-06-20 23:01:35.551751
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:38.042013
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # no errors should be raised
    AnsibleJSONDecoder()


# Generated at 2022-06-20 23:01:54.313799
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.json.loader import AnsibleJSONDecoder
    s = ''' {
        "__ansible_vault": "data",
        "__ansible_unsafe": true
    }'''
    secret = 'secret'
    AnsibleJSONDecoder.set_secrets(secret)
    secret_decoder = AnsibleJSONDecoder()
    decoded = secret_decoder.decode(s)
    assert decoded == {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('data'),
        '__ansible_unsafe': 'not safe: true',
    }



# Generated at 2022-06-20 23:01:58.308375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    def _load(value):
        return json.loads(value, cls=AnsibleJSONDecoder)

    # Test for secret variable
    d = _load(
        '{"__ansible_vault": "123"}'
    )
    assert isinstance(d, AnsibleVaultEncryptedUnicode)

    # Test for unsafe variable
    d = _load(
        '{"__ansible_unsafe": "123"}'
    )
    assert d == {'__ansible_unsafe': '123'}

    # Test for mixed variable
    d = _load(
        '{"__ansible_vault": "456", "__ansible_unsafe": "123"}'
    )
    assert isinstance(d, dict)

# Generated at 2022-06-20 23:02:06.709895
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test with no arguments and no keyword arguments
    test_object = AnsibleJSONDecoder()
    assert test_object.object_hook is not None
    assert test_object._vaults == {}

    # Test with keyword arguments
    test_object = AnsibleJSONDecoder(object_hook=None,
                                     _vaults={'default': VaultLib()})
    assert test_object.object_hook is None
    assert test_object._vaults == {'default': VaultLib()}

    # Test with keyword arguments
    test_object = AnsibleJSONDecoder(object_hook=None,
                                     _vaults={})
    assert test_object.object_hook is None
    assert test_object._vaults == {}

# Generated at 2022-06-20 23:02:17.995928
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'value', '__ansible_unsafe': 'value'}
    ansible_vault_value = {'__ansible_vault': 'value'}
    ansible_vault_object = '__ansible_vault'
    ansible_unsafe_value = {'__ansible_unsafe': 'value'}
    ansible_unsafe_object = '__ansible_unsafe'

    ansible_vault_result = obj.object_hook(ansible_vault_value)
    assert ansible_vault_result.__class__.__name__ == ansible_vault_object
    ansible_unsafe_result = obj.object_hook(ansible_unsafe_value)
    assert ansible_

# Generated at 2022-06-20 23:02:28.554220
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_decoder = AnsibleJSONDecoder(strict=True, object_pairs_hook=None)
    json_value_1 = json.dumps({"__ansible_unsafe": "test"}, cls=AnsibleJSONEncoder)
    json_value_2 = json.dumps({"__ansible_vault": "test"}, cls=AnsibleJSONEncoder)
    json_value_3 = json.dumps({"__ansible_vault": {"__ansible_vault": "test"}}, cls=AnsibleJSONEncoder)
    json_value_4 = json.dumps({"__ansible_unsafe": {"__ansible_vault": "test"}}, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 23:02:31.330534
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, json.JSONDecoder)


# Generated at 2022-06-20 23:02:40.567436
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret
    secret = VaultSecret('ansible').value
    encrypt = '$ANSIBLE_VAULT;1.1;AES256\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    encrypt += 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    encrypt += '\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa='
    AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder().decode(encrypt) == 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'

# Generated at 2022-06-20 23:02:50.568676
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = json.loads(
        '{ "__ansible_vault": "s3cr3t", "__ansible_unsafe": "abc" }',
        cls=AnsibleJSONDecoder,
    )
    assert '__ansible_vault' in result
    assert '__ansible_unsafe' in result

    vault_value = result['__ansible_vault']
    assert isinstance(vault_value, AnsibleVaultEncryptedUnicode)
    assert 's3cr3t' in vault_value
    assert vault_value.vault

    unsafe_value = result['__ansible_unsafe']
    assert isinstance(unsafe_value, str)
    assert 'abc' in unsafe_value



# Generated at 2022-06-20 23:02:53.911806
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder
    assert json.JSONDecoder
    # Constructor of AnsibleJSONDecoder class
    assert AnsibleJSONDecoder().__init__

# Generated at 2022-06-20 23:03:04.458469
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Unsecured vars
    data = json.dumps({'__ansible_unsafe': 'unsafe'})
    assert AnsibleJSONDecoder().decode(data)['__ansible_unsafe'] == 'unsafe'

    # Secured vars without secrets
    data = json.dumps({'__ansible_vault': 'vault'})
    assert isinstance(AnsibleJSONDecoder().decode(data)['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Secured vars with secrets
    data = json.dumps({'__ansible_vault': 'vault'})
    AnsibleJSONDecoder.set_secrets(['password'])
    assert AnsibleJSONDecoder().decode(data)['__ansible_vault'] == 'vault'

# Generated at 2022-06-20 23:03:21.531172
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    o = AnsibleJSONDecoder()
    assert o



# Generated at 2022-06-20 23:03:24.052559
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=None)
    assert decoder.object_hook is not None


# Generated at 2022-06-20 23:03:34.872075
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Random unicode key value mapping
    d = {u"foo": u"bar"}
    assert d == AnsibleJSONDecoder().object_hook(d)
    # AnsibleVaultEncryptedUnicode with vault
    assert AnsibleVaultEncryptedUnicode(u"this is secret", vault=None) == AnsibleJSONDecoder().object_hook({u"__ansible_vault": u"this is secret"})
    # AnsibleVaultEncryptedUnicode without vault
    assert AnsibleVaultEncryptedUnicode(u"this is secret", vault=None) == AnsibleJSONDecoder().object_hook({u"__ansible_vault": u"this is secret"})
    # AnsibleVaultEncryptedUnicode with vault

# Generated at 2022-06-20 23:03:44.532621
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj1 = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'abcdef'})
    assert isinstance(obj1, AnsibleVaultEncryptedUnicode), \
        "Failed to create an AnsibleVaultEncryptedUnicode object using the method object_hook of class AnsibleJSONDecoder"
    obj2 = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': {'a': 'b'}})
    assert isinstance(obj2, wrap_var), \
        "Failed to create an UnsafeProxy object using the method object_hook of class AnsibleJSONDecoder"


# Generated at 2022-06-20 23:03:48.876221
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ans_encoded_str = json.dumps({'a': 'b', 'c': '__ansible_vault'}, cls=AnsibleJSONEncoder)
    result = json.loads(ans_encoded_str, cls=AnsibleJSONDecoder)

    assert isinstance(result['c'], AnsibleVaultEncryptedUnicode) == True

# Generated at 2022-06-20 23:03:59.439008
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:04:05.788688
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_text = '''{
        "ansible": {
          "vars": {
            "json_variable": "{{ ansible_vault_variable }}"
          }
        }
    }'''
    result = json.loads(json_text, cls=AnsibleJSONDecoder)
    assert(isinstance(result['ansible']['vars']['json_variable'], AnsibleVaultEncryptedUnicode))

# Generated at 2022-06-20 23:04:12.874109
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    json_data = '{ "__ansible_vault": "test" }'
    json_object = json.loads(json_data, object_hook=decoder.object_hook)

    #ensure object_hook returns AnsibleVaultEncryptedUnicode
    assert isinstance(json_object, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:04:19.012798
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    input_str = '''{"__ansible_vault": "vault-encrypted-value", "__ansible_unsafe": "unsafe-value"}'''
    expected_output = {"__ansible_vault": "vault-encrypted-value", "__ansible_unsafe": "unsafe-value"}

    decoder = AnsibleJSONDecoder()
    actual_output = decoder.decode(input_str)

    assert actual_output == expected_output



# Generated at 2022-06-20 23:04:29.251293
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    dec = AnsibleJSONDecoder()

    # test __ansible_vault

# Generated at 2022-06-20 23:05:11.575921
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder(object_hook=None)
    assert a._vaults == {}
    assert a.object_hook == a.object_hook

# Generated at 2022-06-20 23:05:20.686265
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:05:24.793462
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    value = dict(__ansible_vault='asdfghjkl', __ansible_unsafe='qwertyuio')
    answer = dict(__ansible_vault=AnsibleVaultEncryptedUnicode('asdfghjkl'), __ansible_unsafe=wrap_var('qwertyuio'))
    assert AnsibleJSONDecoder.object_hook(value) == answer



# Generated at 2022-06-20 23:05:30.075004
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json.loads('{"foo": 42}', cls=AnsibleJSONDecoder)
    json.loads('{"__ansible_vault": "bar"}', cls=AnsibleJSONDecoder)
    json.loads('{"__ansible_unsafe": 5}', cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 23:05:38.412835
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    secrets.append('test1')
    secrets.append('test2')
    secrets.append('test3')
    test_dict = dict(__ansible_unsafe='badValue')
    actual = AnsibleJSONDecoder.object_hook(test_dict)
    assert actual == dict(__ansible_unsafe=wrap_var('badValue'))
    test_dict1 = dict(__ansible_vault='test')
    expected = AnsibleVaultEncryptedUnicode('test')
    expected.vault = VaultLib(secrets=secrets)
    actual = AnsibleJSONDecoder.object_hook(test_dict1)
    assert actual == expected

# Generated at 2022-06-20 23:05:45.534511
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import glob
    import pytest
    import json
    import re

    basepath = os.path.join(os.path.dirname(__file__), 'vault_decoder')
    json_files = glob.glob(basepath + '/*.json')

    for filename in json_files:
        with open(filename) as json_file:
            json_data = json.load(json_file, cls=AnsibleJSONDecoder)
            json_file.close()

        original_json = filename.replace('.json', '') + '.test'

        with open(original_json) as test_file:
            test_data = test_file.read()
            test_file.close()


# Generated at 2022-06-20 23:05:54.862214
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:05:59.979629
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder(object_hook=encoder.default)
    encode_data = {"test": "secret", '__ansible_unsafe': 'unsafe'}

    data = json.loads(encoder.encode(encode_data), object_hook=decoder.object_hook)
    assert data['test'] == "secret"
    assert data['__ansible_unsafe']  == 'unsafe'