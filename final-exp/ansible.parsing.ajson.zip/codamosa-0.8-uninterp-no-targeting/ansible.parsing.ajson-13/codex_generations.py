

# Generated at 2022-06-20 22:56:02.959267
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test for successful decryption
    payload = '{"one": "secret", "__ansible_vault": "one"}'
    encrypted_field = '{"__ansible_vault": "one"}'
    result = json.loads(payload, cls=AnsibleJSONDecoder)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault is not None
    assert result['one'] == 'secret'
    assert json.dumps(result, cls=AnsibleJSONEncoder, sort_keys=True) == payload
    assert json.dumps(result['__ansible_vault'], cls=AnsibleJSONEncoder, sort_keys=True) == encrypted_field

    # Test for failure to decrypt

# Generated at 2022-06-20 22:56:11.187844
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    sec = {'secretkey': 'secretvalue'}
    decoder = AnsibleJSONDecoder.set_secrets(sec)
    input_str = '{"__ansible_vault": "blahblah"}'
    ansible_vault_str = json.loads(input_str, cls=AnsibleJSONDecoder)
    assert ansible_vault_str.vault, 'No vault created'
    assert ansible_vault_str.vault.secrets, 'No secrets'
    assert ansible_vault_str.vault.secrets['secretkey'] == 'secretvalue'

# Generated at 2022-06-20 22:56:24.301730
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:56:33.530608
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret']
    json_data = '''
{
    "__ansible_vault": "vaulted_data"
}'''
    json_decoder = AnsibleJSONDecoder.set_secrets(secrets)
    decoded = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['__ansible_vault'].vault == VaultLib(secrets=secrets)


# Generated at 2022-06-20 22:56:37.720515
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

    assert(ansible_json_decoder.object_hook is not None)

    assert(ansible_json_decoder._vaults == {})



# Generated at 2022-06-20 22:56:50.318778
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_dict = {'ansible_vault': 'fake__ansible_vault', 'ansible_unsafe': 'fake__ansible_unsafe'}
    test_json_encoded = json.dumps(test_dict, cls=AnsibleJSONEncoder)
    decoder = AnsibleJSONDecoder()
    test_json_decoded = decoder.decode(test_json_encoded)
    assert test_json_decoded['ansible_vault'] == test_dict['ansible_vault'], 'AnsibleJSONDecoder failed to decode \'__ansible_vault\''
    assert test_json_decoded['ansible_unsafe'] == test_dict['ansible_unsafe'], 'AnsibleJSONDecoder failed to decode \'__ansible_unsafe\''
    assert test_

# Generated at 2022-06-20 22:57:00.319156
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ''' test_AnsibleJSONDecoder_object_hook
    '''
    d = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n356463343231636233623234630a343635646366393'}
    decoder = AnsibleJSONDecoder()
    ret = decoder.object_hook(d)
    assert ret['__ansible_vault'] == '$ANSIBLE_VAULT;1.1;AES256\n356463343231636233623234630a343635646366393'
    assert isinstance(ret['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:57:08.634958
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret_data = "'Rosetta'"
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(password=secret_data)
    assert decoder
    assert len(decoder._vaults.keys()) == 1
    assert 'default' in decoder._vaults
    assert decoder._vaults['default'].secrets == secret_data
    assert decoder._vaults['default'].secrets_type == 'password'


# Generated at 2022-06-20 22:57:11.354083
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'test'
    json_decoder = AnsibleJSONDecoder(secret)

    assert json_decoder.vaults == {'default': VaultLib(secrets=secret)}

# Generated at 2022-06-20 22:57:20.210817
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:57:28.352161
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Template
    # { "__ansible_vault": "vault_data",
    #   "__ansible_unsafe": True }
    json_string_vault_data = '{"__ansible_vault": "vault_data", "__ansible_unsafe": True}'
    # Load ansible vaults
    decoder.set_secrets("test_secret")
    # Decode json string
    decoded_json = decoder.decode(json_string_vault_data)
    assert decoded_json['__ansible_vault'] == "vault_data"
    assert decoded_json['__ansible_unsafe'] == True

# Generated at 2022-06-20 22:57:34.685045
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    key = '__ansible_vault'
    value = 'vault_key'
    test_dict = {key: value}
    test_json = json.dumps(test_dict, cls=AnsibleJSONEncoder)
    decoded = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert decoded[key] == AnsibleVaultEncryptedUnicode(value)

# Generated at 2022-06-20 22:57:36.764933
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook is not None

    assert AnsibleJSONDecoder.set_secrets is not None

# Generated at 2022-06-20 22:57:42.486512
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ["hunter2"]
    result = json.loads('''{
        "__ansible_unsafe": "user",
        "__ansible_vault": "AQAAPQBNBm1vZGUwMDAACg=="
    }''', cls=AnsibleJSONDecoder, secrets=secrets)
    assert isinstance(result['__ansible_unsafe'], wrap_var)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].decrypt('hunter2') == "mode0000"


# Generated at 2022-06-20 22:57:47.059148
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = "This is a secret"
    set_secrets = AnsibleJSONDecoder.set_secrets
    set_secrets([secret])
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults['default'].secrets[0] == secret



# Generated at 2022-06-20 22:57:49.360585
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.decode('') == None



# Generated at 2022-06-20 22:57:52.163433
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'bar'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([secret])
    assert decoder._vaults['default'].secrets == [secret]

# Generated at 2022-06-20 22:57:53.034368
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder()

# Generated at 2022-06-20 22:58:04.493422
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import random

    secrets = ['test_1', 'test_2', 'test_3']

    ansible_vault_data = {
        "ansible_vault_password": random.choice(secrets)
    }

    test_ansible_vault_data = json.dumps(ansible_vault_data)

    AnsibleJSONDecoder.set_secrets(secrets)
    ansible_vault_decoder = AnsibleJSONDecoder()
    ansible_vault_data_decoded = ansible_vault_decoder.decode(test_ansible_vault_data)

    assert isinstance(ansible_vault_data_decoded, dict)
    assert 'ansible_vault_password' in ansible_vault_data_decoded

# Generated at 2022-06-20 22:58:05.893964
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    assert d._vaults == {}

# Generated at 2022-06-20 22:58:08.547541
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 22:58:10.042520
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder



# Generated at 2022-06-20 22:58:11.911748
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder
    assert decoder._vaults == {}

# Generated at 2022-06-20 22:58:18.372706
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = "12345"
    class TestAnsibleJSONDecoder(AnsibleJSONDecoder):
        pass
    TestAnsibleJSONDecoder.set_secrets(secret)
    decoder = TestAnsibleJSONDecoder()
    assert( isinstance(decoder, TestAnsibleJSONDecoder) )
    assert( isinstance(decoder, json.JSONDecoder) )
    assert( decoder._vaults )

# Unit test setting and getting secret

# Generated at 2022-06-20 22:58:28.066777
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    # Test for ansible unsafe string
    result = decoder.object_hook({'__ansible_unsafe': u'$ANSIBLE_VAULT;1.1;AES256'})
    assert result == '$ANSIBLE_VAULT;1.1;AES256'

    # Test for ansible vault
    vault_data = {'__ansible_vault': u'!vault |\n          '}
    result = decoder.object_hook(vault_data)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result == vault_data['__ansible_vault']

    # Test for json object without ansible vault and unsafe string
    vault_data = {'__ansible_vault': '$ANSIBLE_VAULT'}

# Generated at 2022-06-20 22:58:33.038672
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test for AnsibleJSONDecoder.object_hook
    """

    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'some_value'}) == wrap_var('some_value')
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'some_value'}) == AnsibleVaultEncryptedUnicode('some_value')

# Generated at 2022-06-20 22:58:34.987692
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-20 22:58:41.709346
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secret_data1 = [
        {'key1': 'value1'},
        {'key2': 'value2'},
        {'key3': 'value3'},
    ]

    secret_data2 = [
        {'key3': 'value3'},
        {'key2': 'value2'},
        {'key1': 'value1'},
    ]

    dummy_secrets = ['secret_data1', 'secret_data2']

    AnsibleJSONDecoder.set_secrets(dummy_secrets)

    # Start the test
    with open('test_AnsibleJSONDecoder_object_hook.json') as test_json:
        json_data = json.load(test_json)

    assert json_data['secret_data1'] == secret_data1
    assert json_data

# Generated at 2022-06-20 22:58:53.593805
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test with a vault object
    vault_data = '$ANSIBLE_VAULT;1.1;AES256\n603864663037643362396565353063646665346435343335333730346232626661633561326536\ncG9zdGdyZXMxCg==\n'
    secret_data = 'test'

    decoder.set_secrets(secret_data)
    out = decoder.object_hook({'__ansible_vault': vault_data})
    assert isinstance(out, AnsibleVaultEncryptedUnicode)

    # Test with a unsafe object

# Generated at 2022-06-20 22:59:04.818680
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:11.531798
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansiblejsonencoder = AnsibleJSONEncoder()
    ansiblejsonencoder = ansiblejsonencoder.encode({'__ansible_vault': 'someciphertext'})
    ansiblejsondecoder = AnsibleJSONDecoder()
    ansiblejsondecoder = ansiblejsondecoder.decode(ansiblejsonencoder)
    assert ansiblejsondecoder == 'someciphertext'

# Generated at 2022-06-20 22:59:18.357684
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_str = '{"foo": "bar", "__ansible_unsafe": "baz"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)

    assert json_obj.foo == "bar"
    assert json_obj.__ansible_unsafe == "baz"
    assert json_obj['foo'] == "bar"
    assert json_obj['__ansible_unsafe'] == "baz"

# Generated at 2022-06-20 22:59:21.809148
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'test_secret'
    AnsibleJSONDecoder.set_secrets(secrets=secrets)
    assert AnsibleJSONDecoder._vaults == {'default': VaultLib(secrets=secrets)}

# Generated at 2022-06-20 22:59:33.926747
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Initialize vault with a password and set it in the AnsibleJSONDecoder class
    vault_password = "password"
    vault = VaultLib(secrets=[vault_password])
    AnsibleJSONDecoder.set_secrets(vault.secrets)

    # Create a dict with a VaultLib encrypted string and an unsafe value
    s = '{"__ansible_vault": "U2FsdGVkX1+aY6aaUnc6iPZlw6j2g1ksWc6vfKyvpA0=", "__ansible_unsafe": "This is a value"}'

    # Call object_hook() method of AnsibleJSONDecoder and retrieve decoded dict
    d = AnsibleJSONDecoder().object_hook(json.loads(s))

    # The decoded dict contains a VaultLib encrypted string


# Generated at 2022-06-20 22:59:37.911079
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    j = AnsibleJSONDecoder()
    assert isinstance(j, json.JSONDecoder)
    assert callable(j.object_hook)



# Generated at 2022-06-20 22:59:38.770879
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder, object)

# Generated at 2022-06-20 22:59:49.606925
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:00.834302
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    a_json_string = '''
    {"__ansible_vault": "foo", "__ansible_unsafe": "bar"}
    '''

    a_json_element = {"__ansible_vault": "foo", "__ansible_unsafe": "bar"}

    # Create decoder object and set the secret key
    # verify that the object_hook function converts the json string and element correctly
    a_decoder = AnsibleJSONDecoder()
    a_decoder.set_secrets("firstsecret")
    assert a_decoder.object_hook(a_json_element) == {'__ansible_vault': {'data': u'foo', 'vault': VaultLib(secrets=["firstsecret"])}, '__ansible_unsafe': {'data': u'bar'}}
    assert a_dec

# Generated at 2022-06-20 23:00:04.475225
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_string = '{"__ansible_vault": "foo"}'
    assert json.loads(json_string, cls=AnsibleJSONDecoder)['__ansible_vault'] == "foo"


# Generated at 2022-06-20 23:00:15.717969
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansibleJsonDecoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:00:28.137993
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {
        "__ansible_vault": "!vault|12345",
        "__ansible_unsafe": "!unsafe|12345",
    }

    data = json.dumps(obj, cls=AnsibleJSONEncoder)
    decoded = json.loads(data, cls=AnsibleJSONDecoder)

    # Make sure that object_hook has the desired effect
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['__ansible_unsafe'] == wrap_var('12345')

# Generated at 2022-06-20 23:00:36.371733
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils.six.moves import StringIO
    data = json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=AnsibleJSONEncoder)
    result = json.load(StringIO(data), cls=AnsibleJSONDecoder)
    assert result == ['foo', {'bar': ['baz', None, 1, 2]}]

    # test vault
    data = json.dumps(['foo', {'bar': AnsibleVaultEncryptedUnicode('bar')}], cls=AnsibleJSONEncoder)
    result = json.load(StringIO(data), cls=AnsibleJSONDecoder)
    assert result == ['foo', {'bar': AnsibleVaultEncryptedUnicode('bar')}]

    # test

# Generated at 2022-06-20 23:00:44.373460
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    je = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    ansible_vault_dict = {
        "__ansible_vault": "this is vaulted"
    }
    result = je.decode(json.dumps(ansible_vault_dict))
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault is None

# Generated at 2022-06-20 23:00:52.434195
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set up the test
    key = '__ansible_vault'
    value = 'I am encrypted vault string'
    pairs = {
        key: value
    }

    # Execute the method under test
    decoder = AnsibleJSONDecoder()
    decrypted_pairs = decoder.object_hook(pairs)

    # Verify the results
    if(decrypted_pairs[key] != value):
        raise AssertionError("[ansible.parsing.json.ansible_json.AnsibleJSONDecoder.object_hook()] returned an unexpected value")

# Generated at 2022-06-20 23:00:59.457192
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text = '{"__ansible_vault": "ciphertext", "plaintext": "value", "__ansible_unsafe": "value"}'
    json_object = {'__ansible_vault': 'ciphertext', 'plaintext': 'value', '__ansible_unsafe': 'value'}
    assert json.loads(json_text, cls=AnsibleJSONDecoder) == json_object


# Generated at 2022-06-20 23:01:10.298650
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # It's possible to construct an AnsibleJSONDecoder without supplying any secrets, but in that case the decoder
    # wont be able to decode any encrypted values.
    AnsibleJSONDecoder()

    # Supplying secrets allows to decode encrypted values.
    AnsibleJSONDecoder.set_secrets('password')

    # Following values contain an encrypted AnsibleVaultEncryptedUnicode which will be decoded with the decoder.

# Generated at 2022-06-20 23:01:20.527488
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Parameters
    pairs = {}

# Generated at 2022-06-20 23:01:30.794479
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for vault object
    result = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'abc'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # Test for unsafe object
    result = AnsibleJSONDecoder().object_hook({'__ansible_unsafe': 'abc'})
    assert result._value == 'abc'
    assert result._unsafe == True

    # Test for normal object
    assert AnsibleJSONDecoder().object_hook({'__ansible_normal': 'abc'}) == {'__ansible_normal': 'abc'}

# Generated at 2022-06-20 23:01:33.935492
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['foo', 'bar']
    decoder = AnsibleJSONDecoder(secrets=secrets)
    assert decoder._vaults['default'].secrets == secrets
    assert decoder.object_hook == decoder.object_hook


# Generated at 2022-06-20 23:01:43.060575
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    
    data = {
                "__ansible_vault": "crid=1234",
                "__ansible_unsafe": "crid=5678"
            }

    decoded_data = AnsibleJSONDecoder().object_hook(data)
    
    assert repr(decoded_data['__ansible_vault']) == repr(AnsibleVaultEncryptedUnicode('crid=1234'))
    assert decoded_data['__ansible_unsafe'] == wrap_var('crid=5678')

if __name__ == "__main__":
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-20 23:01:55.242516
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_vault': 'value'}) == AnsibleVaultEncryptedUnicode('value')
    assert decoder.object_hook({'__ansible_unsafe': 'value'}) == wrap_var('value')

# Generated at 2022-06-20 23:02:05.267850
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Unsafe string should be wrapped by unsafe proxy when __ansible_unsafe is present."""

    json_decoder = AnsibleJSONDecoder()

    pairs={}
    pairs['key'] = 'value'
    assert json_decoder.object_hook(pairs) == pairs

    pairs={}
    pairs['__ansible_unsafe'] = 'value'
    assert json_decoder.object_hook(pairs).__unicode__() == 'value'

    pairs={}
    pairs['key'] = 'value'
    pairs['__ansible_unsafe'] = 'value2'
    assert json_decoder.object_hook(pairs).__unicode__() == 'value2'

# Generated at 2022-06-20 23:02:07.106755
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)



# Generated at 2022-06-20 23:02:13.909552
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    ansible_vault_object = {'__ansible_vault': 'bar'}
    result = json.loads(json.dumps(ansible_vault_object), cls=d)
    assert result['__ansible_vault'] == 'bar'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-20 23:02:25.209712
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultSecret

    secrets = ['myvault']
    v = VaultLib(secrets=secrets)
    ciphertext = v.encrypt(b'foo')

    # Test AnsibleVaultEncryptedUnicode
    data = dict(__ansible_vault=ciphertext.decode('utf-8'))
    decoded = AnsibleJSONDecoder.object_hook(data)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert secret_eq(decoded.vault.secrets, secrets)
    decoded_secret = decoded.vault.decrypt(decoded)
    assert isinstance(decoded_secret, VaultSecret)
    assert decoded_

# Generated at 2022-06-20 23:02:32.054149
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    password = "test"

# Generated at 2022-06-20 23:02:35.953933
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('password')
    assert isinstance(decoder, json.JSONDecoder)
    assert decoder._vaults['default'].secrets == 'password'


# Generated at 2022-06-20 23:02:43.039001
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_decoder = AnsibleJSONDecoder()
    assert isinstance(test_decoder, json.JSONDecoder)
    assert test_decoder.object_hook({"__ansible_unsafe": "unsafe_string"}) == wrap_var("unsafe_string")
    assert test_decoder.object_hook({"__ansible_vault": "encrypted_string"}) == AnsibleVaultEncryptedUnicode("encrypted_string")


# Generated at 2022-06-20 23:02:47.353460
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vaults = dict(default=VaultLib())
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook, vaults=vaults)
    assert decoder.object_hook
    assert decoder.vaults == vaults

# Generated at 2022-06-20 23:02:50.903163
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()

    # should add vault and unsafe to dict
    d = json.loads(enc.encode({'a': 'b', '__ansible_vault': '1234', '__ansible_unsafe': '5678'}), cls=dec)
    assert isinstance(d['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(d['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-20 23:03:15.858471
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # {}
    value = decoder.object_hook({})
    assert value == {}

    # {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n653162326439626639623831636235663365393064613961323137623661346364330316539\n3434353561616665653636353439336139613138376233613836663033656637343930326437\n3438378a\n'}

# Generated at 2022-06-20 23:03:16.853808
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    assert AnsibleJSONEncoder

# Generated at 2022-06-20 23:03:28.604443
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'dummy'

# Generated at 2022-06-20 23:03:37.384637
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:38.816351
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert 'object_hook' in AnsibleJSONDecoder.__dict__


# Generated at 2022-06-20 23:03:47.474299
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Imports must be done inside the function as this method is called from ansible/parsing/dataloader/__init__
    # and json is not yet imported
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    d = AnsibleJSONDecoder()

    result = d.object_hook({})
    assert result == {}

    assert type(d.object_hook({'__ansible_vault': 'value'})[0]) is AnsibleVaultEncryptedUnicode

    assert type(d.object_hook({'__ansible_unsafe': 'value'})[0]) is wrap_var

# Generated at 2022-06-20 23:03:57.324549
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test 1
    ans_vault = u'$ANSIBLE_VAULT;1.1;AES256\n61353639356434643265643033316632316538646432343733383539373637336466353831393739\n65653261653235633963626664396330666433313766646532626333'
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': ans_vault}) == AnsibleVaultEncryptedUnicode(ans_vault)

    # Test 2
    ans_unsafe = '{{some_data}}'
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': ans_unsafe}) == wrap_

# Generated at 2022-06-20 23:04:09.336023
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret1', 'secret2', 'secret3']
    secrets_dict = {'default': secrets}
    @classmethod
    def set_secrets(cls, secrets):
        cls._vaults['default'] = VaultLib(secrets=secrets)
    # set_secrets function from classmethod is used
    AnsibleJSONDecoder.set_secrets = set_secrets
    # using object_hook function from class to catch the vault object
    AnsibleJSONDecoder.object_hook = None
    # creating instance of class AnsibleJSONDecoder
    ansibledecoder_instance = AnsibleJSONDecoder()
    # setting secrets for the class vault
    ansibledecoder_instance.set_secrets(secrets_dict)
    # function object_hook is set

# Generated at 2022-06-20 23:04:12.673286
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['test_secret']
    decoder = AnsibleJSONDecoder(object_hook=decoder.object_hook)
    decoder.set_secrets(secrets)
    assert decoder._vaults['default'].secrets == secrets

# Generated at 2022-06-20 23:04:13.437066
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:04:55.701315
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # No decryption if no _vaults['default'] defined

# Generated at 2022-06-20 23:05:02.998952
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    json_str = '''{
        "test_str": "str",
        "test_int": 123,
        "test_float": 0.123,
        "test_bool_true": true,
        "test_bool_false": false,
        "test_none": null,
        "test_list_empty": [],
        "test_list_with_value": [1, 2, 3],
        "test_dict_empty": {},
        "test_dict_with_value": {
            "a": "b"
        }
    }'''


# Generated at 2022-06-20 23:05:13.863482
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:05:17.804937
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder._vaults, dict)
    assert len(decoder._vaults) > 0
    assert hasattr(decoder, 'object_hook')
    assert isinstance(decoder.object_hook, classmethod)


# Generated at 2022-06-20 23:05:25.485937
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import copy

    def _wrap_var(data):
        # return a copy of the data that is wrapped in an AnsibleUnsafeText instance
        # this is to verify that wrap_var is called once and only once for each value
        return wrap_var(copy.deepcopy(data))

    assert AnsibleJSONDecoder.object_hook({}) == {}
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;blahblahblah'}) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;blahblahblah')

# Generated at 2022-06-20 23:05:26.480725
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder


# Generated at 2022-06-20 23:05:33.216893
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # set the default vault on the class
    # this should be called by the ansible.runner.connection_plugins.__init__
    AnsibleJSONDecoder.set_secrets(
        {'default': {
            'vault_password': 'some_vault_password',
            'other_vault_password': 'some_other_vault_password',
        }})

    a_j_d = AnsibleJSONDecoder()
    assert a_j_d



# Generated at 2022-06-20 23:05:34.748722
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'dummy'
    assert secrets == AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 23:05:36.002125
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-20 23:05:44.429011
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Create a test vault for encrypting and decrypting the data
    vault_pass = 'secret'
    test_vault = VaultLib(vault_pass)
    data = dict(value='mysecret')
    encrypted_data = test_vault.dump(data)

    # Set the vault password to be used by the decoder
    secrets = {'default': vault_pass}
    AnsibleJSONDecoder.set_secrets(secrets)

    # Create an instance of class AnsibleJSONDecoder
    ansible_json_decoder = AnsibleJSONDecoder()

    # Decode the data
    decoded_data = json.loads(encrypted_data, cls=ansible_json_decoder)

    # Assert
    assert (isinstance(decoded_data['value'], AnsibleVaultEncryptedUnicode))

