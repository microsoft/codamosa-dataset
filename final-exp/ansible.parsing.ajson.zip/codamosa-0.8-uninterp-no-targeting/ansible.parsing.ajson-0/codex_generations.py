

# Generated at 2022-06-20 22:55:59.846930
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test for constructor function
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Generated at 2022-06-20 22:56:10.917539
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import json
    import pprint
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-20 22:56:17.467095
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_json = {}
    test_json['__ansible_vault'] = "some string"
    test_json['__ansible_unsafe'] = "some string"
    test_json['abc'] = "abc"

    decoded_json = AnsibleJSONDecoder.decode(test_json)

    assert decoded_json == test_json

# Generated at 2022-06-20 22:56:23.373303
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '{"__ansible_vault": "123"}'
    decoded = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-20 22:56:25.731154
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()

# Generated at 2022-06-20 22:56:36.501393
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    json_encoded_encrypted_string = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n353062626362396239646661633462343561323063656634636431356465\n643035656439333831636364383162393666613236626664313131346461\n3835343564333562326264633733\n"}'


# Generated at 2022-06-20 22:56:38.046728
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder=AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-20 22:56:50.582881
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = dict(__ansible_vault='1.2.3')
    value = AnsibleJSONDecoder().object_hook(data)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.vault is None

    # Set up custom vault secret for AnsibleJSONDecoder
    vault_secrets = dict(default='password')
    AnsibleJSONDecoder.set_secrets(vault_secrets)
    value = AnsibleJSONDecoder().object_hook(data)
    assert value.vault is not None

    data = dict(__ansible_unsafe='unsafe')
    value = AnsibleJSONDecoder().object_hook(data)
    assert isinstance(value, unicode)
    assert value == 'unsafe'

    data = dict(value='safe')

# Generated at 2022-06-20 22:56:53.940454
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [ 'foo' ]
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert secrets == decoder._vaults['default'].secrets

# Test the object_hook function in AnsibleJSONDecoder

# Generated at 2022-06-20 22:56:58.886432
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = {
        'foo': 'bar',
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo'
    }

    assert(json.loads(json.dumps(data), cls=AnsibleJSONDecoder) == data)



# Generated at 2022-06-20 22:57:06.305620
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Given
    secrets = ['dummy']
    AnsibleJSONDecoder.set_secrets(secrets)

    # When
    ansible_json_decoder = AnsibleJSONDecoder()

    # Then
    assert ansible_json_decoder.parse_string('{"foo":"bar"}') == {'foo': 'bar'}

# Generated at 2022-06-20 22:57:10.716391
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # This test has been added to test the AnsibleJSONDecoder class.
    if six.PY3:
        return
    data = b'{"a": {"__ansible_vault": "this is a vault encrypted string"}}'
    decoded_data = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(decoded_data['a'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:57:12.546153
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
	a = AnsibleJSONDecoder()
	assert type(a) is AnsibleJSONDecoder


# Generated at 2022-06-20 22:57:15.382799
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_decoder = AnsibleJSONDecoder()
    assert test_decoder.object_hook is not None


# Generated at 2022-06-20 22:57:17.957275
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, AnsibleJSONDecoder)



# Generated at 2022-06-20 22:57:27.179123
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:57:36.926990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_val = "123456"
    secrets = [secret_val]
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

    value = AnsibleVaultEncryptedUnicode('__ANSIBLE_VAULT__;vault_password')
    value.vault = AnsibleJSONDecoder._vaults['default']

    assert decoder.object_hook({'__ansible_vault': '__ANSIBLE_VAULT__;vault_password'}) == value
    assert decoder.object_hook({'__ansible_unsafe': '$ANSIBLE_NET_USERNAME'}) == wrap_var('$ANSIBLE_NET_USERNAME')

# Generated at 2022-06-20 22:57:38.561264
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder().object_hook({'__ansible_vault': 'vault_value'})



# Generated at 2022-06-20 22:57:50.160946
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 22:57:57.478563
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 22:58:08.711306
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    secrets = [VaultSecret('hmac_key', b'super-secret', b'sha256')]
    AnsibleJSONDecoder.set_secrets(secrets)
    # The test data come from vars/main.yml in ansible/test/playbooks/vault_text_key.yml
    test_data = {"__ansible_unsafe": "{{password}}"}
    json_data = json.dumps(test_data, cls=AnsibleJSONEncoder)
    assert '"__ansible_unsafe": "{{password}}"' in json_data
    data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert isinstance

# Generated at 2022-06-20 22:58:14.042141
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    data = {'__ansible_vault': 'foo', '__ansible_unsafe': 'Hello world!'}
    assert decoder.object_hook(data) == {'__ansible_vault': u'foo', '__ansible_unsafe': 'Hello world!'}



# Generated at 2022-06-20 22:58:25.063964
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    secrets = [b'foo', b'bar']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 22:58:28.356064
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_unsafe": "test data"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert json_obj == wrap_var('test data')

    json_str = '{"__ansible_vault": "YVBhcmVudAo="}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert json_obj == AnsibleVaultEncryptedUnicode('YVBhcmVudAo=')


# Generated at 2022-06-20 22:58:37.902650
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """This is a unit test for testing the constructor of class AnsibleJSONDecoder.
    It is not intended to actually be run as a unit test, but rather just
    as a simple way to see the output from calling the constructor with
    various arguments.
    """
    from pprint import pprint
    pprint(dict(**AnsibleJSONDecoder().__dict__))
    pprint(dict(**AnsibleJSONDecoder(object_hook=lambda x: x).__dict__))
    pprint(dict(**AnsibleJSONDecoder(object_hook=None).__dict__))
    pprint(dict(**AnsibleJSONDecoder(array_size=True).__dict__))
    pprint(dict(**AnsibleJSONDecoder(pairs_hook=None).__dict__))

# Generated at 2022-06-20 22:58:49.609677
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    decoder = AnsibleJSONDecoder()
    decoder._vaults = {'default': None}
    samples = {
        'simple_string': {"__ansible_vault": "sample_string",},
        'unsafe_string': {"__ansible_unsafe": "sample_string",},
        'enc_unsafe_string': {"__ansible_vault": "sample_string", "__ansible_unsafe": "sample_string",},
    }

    for key in samples:
        result = decoder.object_hook(samples[key])
        if key == 'simple_string':
            assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:58:59.477402
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_text = "some_text"
    # Test case #1
    decoded = AnsibleJSONDecoder.object_hook({'__ansible_vault': vault_text})
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault is None

    # Test case #2
    decoded = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': vault_text})
    assert isinstance(decoded, wrap_var)
    assert decoded.data == vault_text

    # Test case #3
    decoded = AnsibleJSONDecoder.object_hook({})
    assert decoded == {}

    # Test case #4

# Generated at 2022-06-20 22:59:09.765119
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets('ansible')
    testdict = {}
    testdict['__ansible_vault'] = '$ANSIBLE_VAULT;1.1;AES256;ansible;39393939'
    testdict['__ansible_unsafe'] = '__ansible_unsafe_value'
    test_json = json.dumps(testdict, cls=AnsibleJSONEncoder)
    test_json = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert isinstance(test_json[0], AnsibleVaultEncryptedUnicode)
    assert isinstance(test_json[1], wrap_var)

# Generated at 2022-06-20 22:59:16.713113
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test1'}) == AnsibleVaultEncryptedUnicode('test1')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'test2'}) == wrap_var('test2')
    assert AnsibleJSONDecoder.object_hook({'test3': 'test3'}) == {'test3': 'test3'}


# Generated at 2022-06-20 22:59:21.809819
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    sample_data = '{"foo": [1, 3], "bar": {"baz": 2, "booze": "abc"}}'
    decoded = AnsibleJSONDecoder().decode(sample_data)
    assert decoded == {"foo": [1, 3], "bar": {"baz": 2, "booze": "abc"}}

# Generated at 2022-06-20 22:59:28.767866
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    password = str(b'$ecr3t')
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(password)
    assert decoder._vaults
    assert decoder._vaults['default']
    assert decoder._vaults['default'].secrets == password

# Generated at 2022-06-20 22:59:38.531631
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert(jd.object_hook == AnsibleJSONDecoder.object_hook)
    assert(jd.parse_float == float)
    assert(jd.parse_int == int)
    assert(jd.parse_constant == json.decoder.JSONDecoder().parse_constant)
    assert(jd.strict == True)
    assert(jd.object_pairs_hook == None)
    assert(jd.decode == None)
    assert(jd.skipkeys == False)
    assert(jd.ensure_ascii == True)
    assert(jd.bigint_as_string == False)

# Generated at 2022-06-20 22:59:44.773599
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:57.005079
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [ 'secret1', 'secret2' ]
    json_str = '''
    {
        "variable1": "secret1",
        "variable2": "secret2",
        "__ansible_vault": "VaultString",
        "__ansible_unsafe": "TestVault"
    }
    '''
    AnsibleJSONDecoder.set_secrets(secrets)

    decoded = json.loads(json_str, cls=AnsibleJSONDecoder)

    assert decoded['variable1'] == "secret1"
    assert decoded['variable2'] == "secret2"
    assert decoded['__ansible_vault'] == "VaultString"
    assert decoded['__ansible_unsafe'] == "TestVault"

# Generated at 2022-06-20 23:00:04.912095
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test AnsibleJSONDecoder.object_hook()
    """
    simple_test = '{"test": "test"}'
    simple_test_out = '{"test": "test"}'


# Generated at 2022-06-20 23:00:09.659030
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = {'vault_id': 'test_id', 'vault_password': 'test_password'}
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 23:00:14.214448
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    j = b'{"__ansible_unsafe": {"__ansible_vault": "boo"}}'
    d = AnsibleJSONDecoder()
    res = d.decode(j)
    assert(res['__ansible_unsafe']['__ansible_vault'] == 'boo')

# Generated at 2022-06-20 23:00:15.196838
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:00:27.791921
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = json.loads('{ "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible\r\n3861386435303138346162333461626262333333636536663338353865366561323036316565\r\n3065653138313365373635623066646136316331343466653838326233353038353165613333\r\n3039633836363730323962333534373338663130626231303035653465323133363435396363\r\n6330306363366630663536623238626265326536383634333034393036346332623633\r\n" }',
        cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 23:00:31.010298
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(["magic"])

    assert decoder.object_hook({"__ansible_vault": "blah"}) == AnsibleVaultEncryptedUnicode("blah")

# Generated at 2022-06-20 23:00:37.785332
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # TODO: find out how to test
    pass

if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 23:00:44.631692
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = json.dumps({'__ansible_unsafe': 'abc', '__ansible_vault': 'abc'}, cls=AnsibleJSONEncoder)
    data = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(data['__ansible_unsafe'], dict)
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:00:45.252803
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:00:53.421523
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    print(a)
    b = AnsibleJSONDecoder('abc')
    print(b)
    c = AnsibleJSONDecoder(5)
    print(c)
    d = AnsibleJSONDecoder(3.4)
    print(d)
    e = AnsibleJSONDecoder(True)
    print(e)
    f = AnsibleJSONDecoder([1,2,3])
    print(f)
    g = AnsibleJSONDecoder({'a':1,'b':2})
    print(g)


# Generated at 2022-06-20 23:01:00.436947
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
	# Initialize instance of class AnsibleJSONDecoder
	json_decoder = AnsibleJSONDecoder()

	# Set member variable 'object_hook' to method object_hook
	json_decoder.object_hook = json_decoder.object_hook

	# Check name of json_decoder
	assert(json_decoder.__class__.__name__ == "AnsibleJSONDecoder")

	return 0


# Generated at 2022-06-20 23:01:01.113077
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-20 23:01:11.435803
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    secrets = 'testpwd'
    vault = VaultLib(secrets=[secrets])

    # Make a vaulted string
    string1 = 'hello'
    vaulted_string1 = vault.encrypt(string1)
    vaulted_string1_json = json.dumps(vaulted_string1)
    vaulted_object1 = AnsibleJSONDecoder().object_hook(json.loads(vaulted_string1_json))
    assert vaulted_string1 == vaulted_object1
    assert vaulted_string1_json == json.dumps(vaulted_object1)

    # Make a vaulted list
    list1 = ['item1', 'item2']
    vaulted_list1 = vault.encrypt(list1)
    vaulted

# Generated at 2022-06-20 23:01:23.311704
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test normal behaviour of AnsibleJSONDecoder
    a = '{"__ansible_vault": "s3cr3t", "foo": "bar"}'
    decoded = json.loads(a, cls=AnsibleJSONDecoder)
    assert isinstance(decoded, dict)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['__ansible_vault'] == 's3cr3t'
    assert decoded['foo'] == 'bar'
    assert decoded['__ansible_vault'].vault is None

    # Test behaviour when not supplying AnsibleVaultEncryptedUnicode class

# Generated at 2022-06-20 23:01:30.162696
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'bar', b'foo']
    s = '''
{
    "__ansible_vault": "AQAAABAAAAAQ/ve8A16FxxjOtEwQPRg1"
}
'''
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    data = decoder.decode(s)
    assert data['__ansible_vault'] == 'foo'

# Generated at 2022-06-20 23:01:35.365967
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import inspect
    args, _, _, defaults = inspect.getargspec(json.JSONDecoder)
    defaults = dict(zip(reversed(args), reversed(defaults)))

    ajd = AnsibleJSONDecoder()

    assert getattr(ajd, '_vaults') == {}
    assert callable(getattr(ajd, 'object_hook'))
    assert defaults['object_hook'] is None
    assert getattr(ajd, 'object_hook') != defaults['object_hook']

# Generated at 2022-06-20 23:01:51.328519
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_in = '''{
        "foo": "bar",
        "__ansible_vault": "ENC[foo]",
        "__ansible_unsafe": "foo"
    }'''

    cls = AnsibleJSONDecoder()
    cls.set_secrets(['foo'])
    data = json.loads(json_in, cls=cls)

    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(data['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-20 23:02:02.711928
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'if i were a bra i would be a well structured one'
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 23:02:09.293975
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:02:20.509237
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:30.019276
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:41.846643
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets_json = """
    {
        "default": {
            "password": "some_multiple_word_phrase"
        }
    }
    """
    secrets = json.loads(secrets_json)
    AnsibleJSONDecoder.set_secrets(secrets)

    def test_case(payload):
        decoded = json.loads(payload, cls=AnsibleJSONDecoder)
        assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:02:53.776265
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()

    # If there is no key '__ansible_unsafe' or '__ansible_vault', it should return pairs
    pairs = dict(test_key='test_value')
    assert pairs == decoder.object_hook(pairs)

    # If there is key '__ansible_unsafe', it should return wrapped value
    test_value = dict(test_key='test_value')
    pairs = dict(__ansible_unsafe=encoder.encode(test_value))
    assert test_value == decoder.object_hook(pairs)

    # If there is key '__ansible_vault', it should return AnsibleVaultEncryptedUnicode object
    test_value = 'test_value'
    pairs = dict

# Generated at 2022-06-20 23:03:04.343341
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder
    assert AnsibleJSONDecoder()
    assert AnsibleJSONDecoder()
    assert AnsibleJSONDecoder()
    assert AnsibleJSONDecoder(object_hook=None)
    assert AnsibleJSONDecoder(object_hook=None, object_pairs_hook=None)
    assert AnsibleJSONDecoder(object_hook=None, object_pairs_hook=None, parse_float=None)
    assert AnsibleJSONDecoder(object_hook=None, object_pairs_hook=None, parse_float=None, parse_int=None)
    assert AnsibleJSONDecoder(object_hook=None, object_pairs_hook=None, parse_float=None, parse_int=None,
                              parse_constant=None)

# Generated at 2022-06-20 23:03:15.547672
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    def set_secrets(secrets):
        cls = AnsibleJSONDecoder
        cls._vaults['default'] = VaultLib(secrets=secrets)

    vault_id = '$ANSIBLE_VAULT;1.1;AES256'
    vault_content = 'BASE64CONTENT'
    vault_json = '{"__ansible_vault": "%s;%s"}' % (vault_id, vault_content)

    # Assert that vault_json can be successfully decoded
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('password')
    assert decoder.decode(vault_json)['__ansible_vault'] == vault_id
    assert decoder.decode(vault_json)['__ansible_vault'].text == vault_content

# Generated at 2022-06-20 23:03:26.637309
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Tests the method object_hook of class AnsibleJSONDecoder using the following conditions:
    # - one key-value pair is __ansible_vault
    # - the value of the key-value pair __ansible_vault is a .vault file
    # - __ansible_vault key-value pair is followed by another key-value pair
    # - the second key-value pair is __ansible_unsafe
    default_secrets = [{'test_key': 'test_value'}]
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(default_secrets)


# Generated at 2022-06-20 23:03:54.769835
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def assertObject(expected, data):
        observed = AnsibleJSONDecoder().decode(data)

        assert(expected == observed)


# Generated at 2022-06-20 23:04:02.498483
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with correct input
    correct_input = {'__ansible_vault': 'encrypted_data'}
    result = AnsibleJSONDecoder.object_hook(correct_input)
    assert result == AnsibleVaultEncryptedUnicode(correct_input['__ansible_vault'])

    # Test with wrong input
    wrong_input = {'__ansible_vault1': 'encrypted_data'}
    result = AnsibleJSONDecoder.object_hook(wrong_input)
    assert result == wrong_input


# Generated at 2022-06-20 23:04:06.382510
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    result = d.decode('{"__ansible_vault": "foo", "__ansible_unsafe": "bar"}')
    assert result == {'__ansible_unsafe': 'bar', '__ansible_vault': 'foo'}

# Generated at 2022-06-20 23:04:12.133270
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = """{"__ansible_unsafe": "UNSAFE_STR", "foo": "bar"}"""
    json_obj = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert json_obj['__ansible_unsafe'] == "UNSAFE_STR"
    assert json_obj['foo'] == "bar"

# Generated at 2022-06-20 23:04:18.963951
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc_vars = ['some_var']
    enc_text = {"some_key": "some_value"}
    dec_text = {"some_key": "some_value"}

# Generated at 2022-06-20 23:04:29.209364
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestObject:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.__class__ == other.__class__ and self.value == other.value

    secrets = ['secret1']
    vault_value = '$ANSIBLE_VAULT;1.2;AES256;default_secret\n36343330366630336537633631666134626337363962356162333532386363363931326238633165\n3836306635643462313338326166643435653437306335626535373738363837'
    unsafe_value = '__ansible_unsafe'
    obj_value = {'a': 1, 'b': 2}

# Generated at 2022-06-20 23:04:38.812699
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']

    j = json.JSONDecoder()
    decoded = j.decode('{"__ansible_vault": "encrypted_value"}')
    assert decoded == {"__ansible_vault": "encrypted_value"}

    j = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoded = j.decode('{"__ansible_vault": "encrypted_value"}')
    assert decoded == {"__ansible_vault": "encrypted_value"}

    j = AnsibleJSONDecoder()
    decoded = j.decode('{"__ansible_vault": "encrypted_value"}')
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    j = AnsibleJSONDecoder()


# Generated at 2022-06-20 23:04:47.285374
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test without args
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)
    # Test with first arg (testing the inheritance of JSONDecoder)
    assert isinstance(AnsibleJSONDecoder(10), AnsibleJSONDecoder)
    # Test with dictionary
    assert isinstance(AnsibleJSONDecoder({}), AnsibleJSONDecoder)
    assert isinstance(AnsibleJSONDecoder(object_hook={}), AnsibleJSONDecoder)
    # Test with function
    assert isinstance(AnsibleJSONDecoder(lambda: True), AnsibleJSONDecoder)
    # Test with unknown arg
    assert isinstance(AnsibleJSONDecoder(foo='bar'), AnsibleJSONDecoder)
    # Test with positional args

# Generated at 2022-06-20 23:04:55.023088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Initialize decoder and key pairs
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault':'vault_value', '__ansible_unsafe':'unsafe_value'}
    # Checks if the object hook return is correct
    assert decoder.object_hook(pairs) == {'__ansible_vault': 'vault_value', '__ansible_unsafe': 'unsafe_value'}

# Generated at 2022-06-20 23:04:55.892903
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder._vaults == {}

# Generated at 2022-06-20 23:05:31.029766
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test secret with vault
    pairs = {'__ansible_vault': 'vault_content', '__ansible_unsafe': 'unsafe_content'}
    decoder.object_hook(pairs)
    assert pairs == {'__ansible_vault': AnsibleVaultEncryptedUnicode('vault_content'), '__ansible_unsafe': wrap_var('unsafe_content')}

    # Test secret without vault
    pairs = {'__ansible_vault': 'secret', '__ansible_unsafe': 'unsafe_content'}
    decoder.object_hook(pairs)

# Generated at 2022-06-20 23:05:40.929166
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Note: VaultLib is loaded from ansible.parsing.vault
    # To unit test this code, we need to create a VaultLib
    # from ansible.parsing.vault.VaultLib and pass a secret in the form
    # of a VaultSecret object created from ansible.parsing.vault
    # We are using "abcd" as a secret.
    vault_secret = VaultSecret("abcd")
    vault_lib = VaultLib(vault_secrets=[vault_secret])
    # AnsibleJSONDecoder.set_secrets expects a dictionary of vault_lib


# Generated at 2022-06-20 23:05:51.104895
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['hunter2']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)


# Generated at 2022-06-20 23:05:51.635081
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:05:57.456940
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # If a constructor of AnsibleJSONDecoder is provided,
    # make sure it's called.
    class MyDecoder(json.JSONDecoder):
        def __init__(self, *args, **kwargs):
            self.called = True
            super(MyDecoder, self).__init__(*args, **kwargs)

    decoder = AnsibleJSONDecoder(cls=MyDecoder)
    assert decoder.called
