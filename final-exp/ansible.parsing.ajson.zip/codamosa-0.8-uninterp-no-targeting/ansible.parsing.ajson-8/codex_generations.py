

# Generated at 2022-06-20 22:55:56.079891
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # negative test
    try:
        # initialization
        ansible_json_decoder_test_01 = AnsibleJSONDecoder(object_hook=None)
        # verify
        assert False
    except AssertionError as e:
        assert True

    # positive test
    # initialization
    ansible_json_decoder_test_02 = AnsibleJSONDecoder()
    # verify
    assert ansible_json_decoder_test_02.object_hook


# Generated at 2022-06-20 22:56:06.901077
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Unit test for method object_hook of class AnsibleJSONDecoder
    # Input:
    #   pairs: Dictionary in which key is the name of an attribute and value is the value of that attribute
    # Output: pairs

    # False case 1: pairs is a empty dictionary; Expected pairs is the same pairs
    pairs = {}
    obj = AnsibleJSONDecoder()
    assert obj.object_hook(pairs) == pairs

    # True case 1: pairs has 1 attribute and value of that attribute is encrypted; Expected value is not encrypted

# Generated at 2022-06-20 22:56:14.895611
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secrets = [b'111111']
    decoder.set_secrets(secrets)

    pairs = dict(__ansible_vault=b'$ANSIBLE_VAULT;1.1;AES256\n35623366663831366432646564306432356430323931636536633564383533643065396636643265\n656161666639386464323635306635356136633535303962626132316632343331\n',
                 __ansible_unsafe='somedata')

    decoded_pairs = decoder.object_hook(pairs)

    assert decoded_pairs['__ansible_vault'] == 'somedata'

# Generated at 2022-06-20 22:56:23.250881
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:56:26.219274
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder._vaults == {}
    assert ansible_json_decoder.object_hook is not None



# Generated at 2022-06-20 22:56:31.532023
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    sve = AnsibleVaultEncryptedUnicode('encrypted')
    assert {'__ansible_vault': sve} == decoder.object_hook({'__ansible_vault': 'encrypted'})


# Generated at 2022-06-20 22:56:43.781930
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # __ansible_vault
    secrets = ['my_secret']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 22:56:55.867250
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import collections

    json_str = '{"__ansible_vault": "AES256$b0f5bf16a543f6d7$e85b2a9a9f0b20c65499b11eea07016b7c37f0a55a953"}'
    vault_password = 'secret'

    AnsibleJSONDecoder.set_secrets([vault_password])

    dict_object = json.loads(json_str, object_hook=AnsibleJSONDecoder.object_hook)

    assert isinstance(dict_object, collections.OrderedDict), \
        "AnsibleJSONDecoder.object_hook() has not created an ORDict instance, but %s" % type(dict_object)


# Generated at 2022-06-20 22:57:04.841049
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import os
    import tempfile

    test_vault_password = "test_vault_password"
    test_vault_password_file_name = "test_vault_password_file"
    test_vault_password_file = open(test_vault_password_file_name, "w")
    test_vault_password_file.write(test_vault_password)
    test_vault_password_file.close()

    (test_fd, test_name) = tempfile.mkstemp()
    test_file = os.fdopen(test_fd, 'w')

# Generated at 2022-06-20 22:57:15.594435
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:57:22.946975
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = []

    secrets.append({'vault_id': 'default', 'password': 'test'})

    json_string = '{"__ansible_vault": "dGVzdA=="}'
    result = AnsibleJSONDecoder.set_secrets(secrets)

    assert result is None

    result = json.loads(json_string, cls=AnsibleJSONDecoder)

    assert result['__ansible_vault'] == 'test'

# Generated at 2022-06-20 22:57:26.777750
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder._vaults == {}
    assert ansible_json_decoder.object_hook == ansible_json_decoder.object_hook
    assert not hasattr(ansible_json_decoder._vaults, 'default')

# Generated at 2022-06-20 22:57:28.235501
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder is not None



# Generated at 2022-06-20 22:57:38.943361
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:57:42.960472
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s = '{"c": "d"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.decode(s) == {"c": "d"}



# Generated at 2022-06-20 22:57:53.351181
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder(object_hook=None)
    assert decoder.object_hook is not None

    pairs = {'ansible_vault': 'kafka'}
    expected_pairs = 'kafka'
    ret = decoder.object_hook(pairs)
    assert ret['ansible_vault'] == expected_pairs

    pairs = {'__ansible_vault': 'kafka'}
    expected_pairs = {'__ansible_vault': 'kafka'}
    ret = decoder.object_hook(pairs)
    assert ret['__ansible_vault'] == expected_pairs

    pairs = {'__ansible_unsafe': 'kafka'}

# Generated at 2022-06-20 22:58:04.894735
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class JSONDecoderTest(AnsibleJSONDecoder):
        object_meta = False

    json_data = '{"x": "y", "__ansible_vault": "__ansible_vault__", "__ansible_unsafe": "__ansible_unsafe__", "__ansible_no_log": "__ansible_no_log__"}'
    decoded_data = {u'x': u'y', u'__ansible_vault': u'__ansible_vault__', u'__ansible_unsafe': u'__ansible_unsafe__', u'__ansible_no_log': u'__ansible_no_log__'}

    decoder = JSONDecoderTest()
    decoded_result1 = decoder.decode(json_data)
    assert decoded_data

# Generated at 2022-06-20 22:58:12.432985
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:25.063393
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.2;AES256;my_vault\n336135623236396466333861333935346133373765316335323532353237306435336334626235\n316636646638303937386364323134306437623431616331366431636638346263386335343265\n376635346537326232630a38376338616339316334343732633433366665306166633235353139\n326535653433653264383136623539333630653964626263643130396635333636306637376535\n343735\n") == dec

# Generated at 2022-06-20 22:58:32.197396
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from collections import namedtuple
    FakeVault = namedtuple("Vault", ['decrypt', 'is_encrypted_data'])
    fake_vault = FakeVault(decrypt=lambda x: x, is_encrypted_data=lambda x: True)
    AnsibleJSONDecoder._vaults['default'] = fake_vault
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    k = '__ansible_vault'
    # Test that the decoder respects the vault and properly creates a VaultEncryptedUnicode
    assert isinstance(decoder.decode('{"' + k + '": "foo"}')[k], AnsibleVaultEncryptedUnicode)

    # Test that the decoder ignores unrecognized keys

# Generated at 2022-06-20 22:58:44.299091
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    import sys
    if sys.version_info[0] == 2 and sys.version_info[1] < 7:
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleJSONDecoder(unittest.TestCase):
        def test_ansible_vault(self):
            input = {"a": "b", "__ansible_vault": "encryptedtext"}
            expect = {"a": "b", "__ansible_vault": "encryptedtext"}
            with self.assertRaises(AttributeError):
                json.loads(json.dumps(input), cls=AnsibleJSONDecoder, object_hook=AnsibleJSONDecoder.object_hook)


# Generated at 2022-06-20 22:58:53.541448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = u'secret-string'
    AnsibleJSONDecoder.set_secrets(secrets)

    json_str = '{"__ansible_vault": "my_secret"}'
    assert AnsibleJSONDecoder().object_hook(json.loads(json_str)) == AnsibleVaultEncryptedUnicode('my_secret', vault=VaultLib(secrets=secrets))

    json_str = '{"__ansible_unsafe": "my_unsafe"}'
    assert AnsibleJSONDecoder().object_hook(json.loads(json_str)) == wrap_var('my_unsafe')

# Generated at 2022-06-20 22:58:56.201986
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = {'__ansible_vault': 'AAA'}
    json_decoder = AnsibleJSONDecoder()

    assert result == json_decoder.object_hook(result)


# Generated at 2022-06-20 22:58:59.590700
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)
    assert AnsibleJSONDecoder.set_secrets is not None
    assert AnsibleJSONDecoder.object_hook is not None



# Generated at 2022-06-20 22:59:00.729240
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:02.464850
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class_ = AnsibleJSONDecoder()
    assert class_


# Generated at 2022-06-20 22:59:08.422520
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'password'
    # Initialize class object
    ans_json_decoder = AnsibleJSONDecoder()
    ans_json_decoder.set_secrets(secrets)
    assert secrets == ans_json_decoder._vaults['default'].secrets

if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 22:59:14.347700
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    secrets = 'password'
    obj = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secrets)
    assert secrets == obj._vaults['default'].secrets

    secrets = 'password'
    obj = AnsibleJSONDecoder(None)
    AnsibleJSONDecoder.set_secrets(secrets)
    assert secrets == obj._vaults['default'].secrets

# Generated at 2022-06-20 22:59:26.160302
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Create an instance of AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()

    # Mock of the method load_vault_secrets of class VaultLib
    def load_vault_secrets():
        pass

    decoder._vaults['default'] = VaultLib(secrets=['test'])
    decoder._vaults['default'].load_vault_secrets = load_vault_secrets

    test_dict = {'__ansible_vault': 'test_data',
                 '__ansible_unsafe': 'test_unsafe'}
    decoded_string = decoder.object_hook(test_dict)

    assert decoded_string['__ansible_vault'] == 'test_data'
    assert decoded_string['__ansible_unsafe'] == 'test_unsafe'

# Generated at 2022-06-20 22:59:37.311690
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import re
    import textwrap
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-20 22:59:39.839457
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert (a)


# Generated at 2022-06-20 22:59:42.768276
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).object_hook).object_hook({'key': 'value'})

# Generated at 2022-06-20 22:59:55.271089
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils._text import to_text
    import ansible.utils.unsafe_proxy as unsafe_proxy

    test_secrets = ['my_secret']
    test_object_hook_pairs = {u'test1' : u'test2', u'__ansible_vault': u'$VAULT|1.1$HEX$AES256$foo$bar', u'__ansible_unsafe': u'$ANSIBLE_UNSAFE$foo'}
    _vaults = {}
    _vaults['default'] = VaultLib(secrets=test_secrets)
    vault = _vaults['default']

    # Is the function object_hook returning the expected AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-20 22:59:56.449198
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert(False)



# Generated at 2022-06-20 22:59:58.689123
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Create an instance
    ajd = AnsibleJSONDecoder()
    assert ajd is not None


# Generated at 2022-06-20 23:00:05.847565
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    o = AnsibleJSONDecoder()
    assert o._vaults == {}, "The default value for the _vaults attribute is not an empty dictionary"
    assert o.parse_float == float, "The parse_float attribute has been incorrectly set"
    assert o.parse_int == int, "The parse_int attribute has been incorrectly set"
    assert o.parse_constant == json._constants.JSONConstants._constants, "The parse_float attribute has been incorrectly set"


# Generated at 2022-06-20 23:00:08.220765
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Initialization
    decoder = AnsibleJSONDecoder()

    # Assertion
    assert decoder is not None

# Generated at 2022-06-20 23:00:13.880673
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert json.JSONDecoder == AnsibleJSONDecoder.__bases__[0]
    assert object == AnsibleJSONDecoder.__bases__[1].__bases__[0]
    assert type == AnsibleJSONDecoder.__bases__[1].__bases__[1]
    assert AnsibleJSONDecoder.object_hook == json.JSONDecoder.object_hook

# Generated at 2022-06-20 23:00:26.235534
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [u'bar']
    json_string_vault = b'{"__ansible_vault": "AQDy1J5pfS7bYMLtzJkQZd2Wc9X4Vq3Mkz4wVfD5C5p7K46mG"}'
    json_string_unsafe = b'{"__ansible_unsafe": "foo"}'

    json_string_vault_wrapped = b'{"__ansible_vault": {"__ansible_vault": "AQDy1J5pfS7bYMLtzJkQZd2Wc9X4Vq3Mkz4wVfD5C5p7K46mG"}}'

# Generated at 2022-06-20 23:00:30.439719
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # test default init
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None

    # test init with object_hook
    decoder = AnsibleJSONDecoder(object_hook=lambda x: x)
    assert decoder.object_hook is not None


# Generated at 2022-06-20 23:00:36.531533
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret, VaultPassword
    secrets = [VaultSecret('default', [VaultPassword('password')])]
    assert secrets == AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 23:00:44.037986
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

    assert ansible_json_decoder.object_hook({"__ansible_vault": "*** VAULT STRING ***"}) == AnsibleVaultEncryptedUnicode("*** VAULT STRING ***")
    assert ansible_json_decoder.object_hook({"__ansible_unsafe": "{{ 'foo': 'bar' }}"}) == wrap_var("{{ 'foo': 'bar' }}")

# Generated at 2022-06-20 23:00:45.103335
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()


# Generated at 2022-06-20 23:00:45.563450
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:00:57.008015
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # __ansible_vault
    json_data = '{"__ansible_vault":"test"}'
    json_decoder = AnsibleJSONDecoder()
    json_decode = json_decoder.decode(json_data)
    assert isinstance(json_decode['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert json_decode['__ansible_vault'].vault is None
    # __ansible_unsafe
    assert isinstance(wrap_var(json_decode['__ansible_vault']), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:00:58.714248
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = {'password': 'MyVaultPassword'}
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(secrets)
    assert ansible_json_decoder._vaults['default']._secrets == secrets


# Generated at 2022-06-20 23:01:09.061762
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    data1 = {"__ansible_vault": "vault_value"}
    data2 = {"__ansible_unsafe": "unsafe_value"}

    result1 = AnsibleJSONDecoder().object_hook(data1)
    assert isinstance(result1, AnsibleVaultEncryptedUnicode)
    assert result1.vault == None
    assert repr(result1) == repr(data1)

    result2 = AnsibleJSONDecoder().object_hook(data2)
    assert result2 == wrap_var(data2)
    assert repr(result2).startswith('<ansible.utils.unsafe_proxy.AnsibleUnsafeText object at 0x')


# Generated at 2022-06-20 23:01:19.276347
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set secrets
    secrets = "12345"
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test ansible vault
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    result = decoder.object_hook(pairs)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault._secrets == secrets

    # Test ansible unsafe
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_unsafe': 'test'}
    result = decoder.object_hook(pairs)
    assert isinstance(result, wrap_var)
    assert result == 'test'

# Generated at 2022-06-20 23:01:30.943057
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import ansible.constants as C

    opts = [('key1', 'value1'), ('key2', 'value2')]
    vault_value = 'cGFzc3dvcmQ='
    password_value = 'password'

    # test secret vault
    json_text = '{"__ansible_vault": "%s"}' % vault_value
    AnsibleJSONDecoder.set_secrets(C.DEFAULT_VAULT_PASSWORD_FILE)
    decoded_text = json.loads(json_text, cls=AnsibleJSONDecoder)
    assert decoded_text == {'__ansible_vault': password_value}

    # test unsafe

# Generated at 2022-06-20 23:01:42.367759
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded_data = None
    vault_password = 'testpassword'
    json_data = "{\"__ansible_vault\": \"vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          393630646565353266363934653136613564333131376464613231333965663136346138616433\n          613465373063633030656533336362393933336132353138\n          \", \"__ansible_unsafe\":  \"value\"}"

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(vault_password)
    decoded_data = decoder.decode(json_data)

    assert decoded_data['__ansible_unsafe'] == 'value'


# Generated at 2022-06-20 23:01:55.369984
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    # Test 1, AnsibleVaultEncryptedUnicode
    test_dict = {}

# Generated at 2022-06-20 23:01:57.422293
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert(isinstance(AnsibleJSONDecoder(), json.JSONDecoder))

# Generated at 2022-06-20 23:02:06.874861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test = '{"__ansible_vault":"my_value"}'
    decoded = AnsibleJSONDecoder().decode(test)
    assert decoded == {'__ansible_vault': AnsibleVaultEncryptedUnicode("my_value")}
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    test = '{"__ansible_unsafe":"my_value"}'
    decoded = AnsibleJSONDecoder().decode(test)
    assert decoded == {'__ansible_unsafe': wrap_var("my_value")}
    assert isinstance(decoded['__ansible_unsafe'], wrap_var)


# Generated at 2022-06-20 23:02:13.301996
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [u"foo"]
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    assert decoder.decode('{"__ansible_vault": "value"}') == {u'__ansible_vault': u'value'}
    assert decoder.decode('{"__ansible_unsafe": "value"}') is u'value'

# Generated at 2022-06-20 23:02:24.753902
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # "__ansible_vault" key
    checksum = "sha1:55edb9179c98850178fcd2e6dda94b6f7c57eec6"
    ansible_vault_value = {"__ansible_vault": "dGVzdA==\n", "__ansible_vault_checksum": checksum}
    result = AnsibleJSONDecoder.object_hook(ansible_vault_value)
    assert result['__ansible_vault'].vault is None
    assert result['__ansible_vault'].vault.decrypt(result['__ansible_vault'].encode('utf-8')) == 'test'
    # "__ansible_unsafe" key

# Generated at 2022-06-20 23:02:36.004529
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    import tempfile
    import os
    import shutil

    class FakeArgs(object):
        passwords = None
        vault_password_file = None
        output_file = None
        new_vault_password_file = None

    _tempdir = tempfile.mkdtemp()


# Generated at 2022-06-20 23:02:44.321966
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    password = 'ansible'
    secret = 'This is my secret'
    # encrypt secret
    cipher = AnsibleJSONEncoder().encode_vaulttext(password, secret)
    # Decrypt secret
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets([password])
    secret_decrypted = ansible_json_decoder.decode(cipher)
    # Test if answer is the same as secret
    assert secret_decrypted == AnsibleVaultEncryptedUnicode(secret)


# Generated at 2022-06-20 23:02:46.544543
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-20 23:02:56.086798
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()


# Generated at 2022-06-20 23:03:05.565559
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import io
    import json
    import os
    import tempfile

    from ansible.module_utils.common.json import AnsibleJSONEncoder

    json_data = '''
{
    "foo": "bar",
    "__ansible_vault": "test",
    "__ansible_unsafe": "test"
}'''   # noqa

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(delete=False)

    # Write json data to the file
    tmpfile.write(json_data.encode('utf-8'))

    # Close the file
    tmpfile.close()

    with open(tmpfile.name, 'r') as fp:
        data = json.load(fp, cls=AnsibleJSONDecoder, encoding='utf-8')

    #

# Generated at 2022-06-20 23:03:26.892434
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:35.939506
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Given a vault secret
    secret = '1111'

    # Given an instance of AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()

    # When I set the secret for class AnsibleJSONDecoder
    AnsibleJSONDecoder.set_secrets({'default': secret})

    # And I load some json with a vault content
    payload = '{"__ansible_vault": "some content"}'
    vault_content = decoder.decode(payload)[0]

    # Then the secret has been set for the vault
    vault = vault_content.vault
    assert secret == vault.secrets[0]


if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 23:03:46.843035
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:56.278311
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert json.loads(json.dumps({'__ansible_unsafe': 'unsafe value'}), cls=AnsibleJSONDecoder) == wrap_var('unsafe value')

# Generated at 2022-06-20 23:04:07.165618
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [b"ultrasecret"]
    json_data = b'{"__ansible_vault": "AQA8oPyRHQt9XAAAAAJjtk/IW8qy1DdTmTtUSPw==", "__ansible_unsafe": "not_so_secret"}'
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=None)
    ansible_json_decoder.set_secrets(secrets)
    ret = ansible_json_decoder.decode(json_data)
    assert ret == {
        u'__ansible_vault': b'ultrasecret\n',
        u'__ansible_unsafe': u'not_so_secret'
    }

# Generated at 2022-06-20 23:04:10.903348
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = {'__ansible_vault': u'ASDFASDFASDF'}
    assert type(AnsibleJSONDecoder().decode(json.dumps(data))) is dict


# Generated at 2022-06-20 23:04:16.866367
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {'__ansible_vault': 'some_vault_value'}
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook(data) == {'__ansible_vault': AnsibleVaultEncryptedUnicode('some_vault_value')}

    data = json.dumps(data, cls=AnsibleJSONEncoder)
    decoder = AnsibleJSONDecoder()
    assert decoder.decode(data) == {'__ansible_vault': AnsibleVaultEncryptedUnicode('some_vault_value')}

# Generated at 2022-06-20 23:04:26.376915
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test AnsibleVaultEncryptedUnicode
    data = '{"__ansible_vault": "VGFibGVAdGFibGVAZ21haWwuY29t"}'
    secret = 'something something something'
    result = AnsibleJSONDecoder.object_hook(json.loads(data))
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert (result.vault.decrypt(result)) == secret
    assert result != secret

    # Test unsafe_proxy
    data = '{"__ansible_unsafe": "something something something"}'
    result = AnsibleJSONDecoder.object_hook(json.loads(data))
    assert result != 'something something something'
    assert result == 'something something something'

# Generated at 2022-06-20 23:04:36.584788
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:04:41.054114
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_secrets = ["Testing", "Testing", "Testing"]
    test_decoder = AnsibleJSONDecoder()
    test_decoder.set_secrets(test_secrets)
    with open("test_data/vaulted.json", 'r') as vaulted_json:
        test_ansible_json = vaulted_json.read()
    test_decoder.decode(test_ansible_json)
    assert test_decoder



# Generated at 2022-06-20 23:05:13.945748
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Given
    v = AnsibleJSONDecoder()

    # When __ansible_vault exists

# Generated at 2022-06-20 23:05:16.466867
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    something = AnsibleJSONDecoder()

    assert something.object_hook is not None
    assert json.JSONDecoder.object_hook is None


# Generated at 2022-06-20 23:05:24.713203
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults = {'default': {}}
    value = '$ANSIBLE_VAULT;1.2;AES256;test\n9d2618e7fef898c3c3dba3ab6a4241b4c4b4b7f18d9e8fc7b237f50b038dceca\n'
    decoded_value = decoder.object_hook({'__ansible_vault': value})
    assert isinstance(decoded_value, AnsibleVaultEncryptedUnicode)
    assert decoded_value == value
    assert decoded_value.vault == {}

# Generated at 2022-06-20 23:05:27.360152
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=None)
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-20 23:05:30.519523
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Constructor of AnsibleJSONDecoder
    # AnsibleJSONDecoder()
    decoder = AnsibleJSONDecoder()
    assert decoder is not None


# Generated at 2022-06-20 23:05:40.227859
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # The input must be a dict
    assert AnsibleJSONDecoder.object_hook(None) == None
    assert AnsibleJSONDecoder.object_hook(()) == None

    # The input can be empty dict
    assert AnsibleJSONDecoder.object_hook({}) == {}

    # The input can have a key __ansible_vault
    input_dict = {'__ansible_vault': 'the vault'}
    assert isinstance(AnsibleJSONDecoder.object_hook(input_dict), AnsibleVaultEncryptedUnicode)

    # The input can have a value __ansible_unsafe
    input_dict = {'__ansible_unsafe': 'the unsafe'}
    assert isinstance(AnsibleJSONDecoder.object_hook(input_dict), dict)

# Generated at 2022-06-20 23:05:41.200536
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder


# Generated at 2022-06-20 23:05:44.414598
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.__dict__['object_hook'] == decoder.object_hook


# Generated at 2022-06-20 23:05:50.068440
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class test_class:
        def __init__(self):
            self._vaults = None
            self.value = None

        @staticmethod
        def object_hook(pairs):
            return None

    decoder = AnsibleJSONDecoder()

    assert decoder.value is None
    assert decoder._vaults is None
    assert decoder.object_hook == decoder._object_hook
    assert isinstance(test_class, AnsibleJSONDecoder) is False
