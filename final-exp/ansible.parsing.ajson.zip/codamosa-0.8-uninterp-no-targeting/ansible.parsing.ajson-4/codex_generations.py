

# Generated at 2022-06-20 22:55:55.605265
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    encoder = AnsibleJSONEncoder()
    vault1 = {
        "vault_password": "12345"
    }
    json_data = encoder.encode(vault1)
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets("12345")
    decoder.decode(json_data)

# Generated at 2022-06-20 22:55:58.250920
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        testAnsibleJSONDecoder = AnsibleJSONDecoder()
        print(testAnsibleJSONDecoder)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-20 22:56:04.040147
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [b'foo', b'bar']
    dec = AnsibleJSONDecoder()
    dec.set_secrets(secrets)
    res = dec.decode('{"__ansible_vault": "this is a vault value"}')

    # The result should be of type AnsibleVaultEncryptedUnicode
    assert isinstance(res, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:56:13.388799
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder._vaults = {'my_vault': VaultLib(secrets=['secret1', 'secret2'])}

    decoder = AnsibleJSONDecoder()
    decoded = decoder.object_hook({'__ansible_vault': 'magic!'})

    assert 'magic!' == str(decoded)
    assert AnsibleVaultEncryptedUnicode == type(decoded)
    assert AnsibleJSONEncoder == type(decoded.vault.encryptor)
    assert ['secret1', 'secret2'] == decoded.vault.secrets

    decoded = decoder.object_hook({'__ansible_vault': {'vault_id': 'my_vault', 'enc': 'magic again!'}})
    assert 'magic again!' == str(decoded)
    assert Ansible

# Generated at 2022-06-20 22:56:25.463034
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = "abcd"
    secrets_as_list = secrets.split("\n")
    from ansible.parsing.vault import VaultSecret
    vault_secret = VaultSecret(secrets_as_list)

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets_as_list)

# Generated at 2022-06-20 22:56:26.615237
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 22:56:31.531553
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_decoder = AnsibleJSONDecoder()
    assert(ansible_decoder.object_hook == ansible_decoder.object_hook)

if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 22:56:35.046408
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['mysecret']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    assert secrets == decoder._vaults['default'].secrets


# Generated at 2022-06-20 22:56:39.099691
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['fake_password']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert len(AnsibleJSONDecoder._vaults) > 0
    assert AnsibleJSONDecoder._vaults['default'] is not None

# Generated at 2022-06-20 22:56:41.521581
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder._vaults['default'] = 'default_secrets'
    new_pairs = ansible_json_decoder.object_hook({'__ansible_vault': 's3cr3t'})
    assert new_pairs.data == 's3cr3t'
    assert new_pairs.vault == 'default_secrets'



# Generated at 2022-06-20 22:56:45.023818
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)

# Generated at 2022-06-20 22:56:56.478764
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['my_secret', 'my_other_secret']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Create a JSON string which contains an Ansible Vault object.
    # Re-create the vault object by deserializing the string
    # using AnsibleJSONDecoder.
    # Verify that the vault object was deserialized correctly.

# Generated at 2022-06-20 22:57:02.918115
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['test_pass']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

    # Value is expected to be plain string
    json_string = '{"foo": "bar"}'
    assert decoder.decode(json_string) == {u'foo': u'bar'}

    # Value is expected to be a AnsibleVaultEncryptedUnicode object
    # with the _vaults property set

# Generated at 2022-06-20 22:57:14.534698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test __ansible_vault
    s = json.dumps({'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;test_user;test_role_test_env;test_role_test_env;test_role_test_env\nYWJjZGVmZ2hpamtsbW5vcAo=\n', 'test_key': 'test_value'}, cls=AnsibleJSONEncoder)
    data = json.loads(s, cls=AnsibleJSONDecoder)
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert data['__ansible_vault'].vault_id is None
    assert data['__ansible_vault'].vault is None

# Generated at 2022-06-20 22:57:25.269422
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Check __ansible_vault
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;test_user;test_id;test_vault_password'}
    assert isinstance(decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)
    # Check __ansible_unsafe
    pairs = {'__ansible_unsafe': 'password'}
    assert isinstance(decoder.object_hook(pairs), wrap_var)
    # Check __ansible_vault and __ansible_unsafe

# Generated at 2022-06-20 22:57:27.039089
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    def object_hook(pairs):
        return pairs

    assert AnsibleJSONDecoder(object_hook=object_hook)

# Generated at 2022-06-20 22:57:29.165984
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder_object = AnsibleJSONDecoder()
    assert isinstance(decoder_object, json.JSONDecoder)


# Generated at 2022-06-20 22:57:39.792854
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # scenario 1: json string with __ansible_vault
    json_string = '{"__ansible_vault": "test_ansible_vault"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    result = ansible_json_decoder.object_hook(json.loads(json_string))

    assert result == AnsibleVaultEncryptedUnicode('test_ansible_vault')

    # scenario 2: json string with __ansible_vault and __ansible_unsafe
    json_string = '{"__ansible_vault": "test_ansible_vault", "__ansible_unsafe": "_test_ansible_unsafe"}'
    result = ansible_json_decoder.object_hook(json.loads(json_string))


# Generated at 2022-06-20 22:57:51.192186
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"foo":"value", "__ansible_vault":"encrypted value", "__ansible_unsafe":{"bar":"value"},"what":"up"}'
    j = AnsibleJSONDecoder()
    r = json.loads(data, cls=j.__class__)

    assert isinstance(r['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # Change the __ansible_vault value to be decrypted

# Generated at 2022-06-20 22:57:53.396060
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook
    assert decoder.object_hook != None


# Generated at 2022-06-20 22:58:05.818729
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '{"foo": "bar", "baz": true}'
    result = AnsibleJSONDecoder().object_hook(json.loads(json_string))
    assert(result == {'foo': 'bar', 'baz': True})

    json_string = '{"__ansible_vault": 123, "baz": true}'
    result = AnsibleJSONDecoder().object_hook(json.loads(json_string))
    assert(isinstance(result, AnsibleVaultEncryptedUnicode))

    json_string = '{"__ansible_unsafe": 123, "baz": true}'
    result = AnsibleJSONDecoder().object_hook(json.loads(json_string))
    assert(isinstance(result, wrap_var))



# Generated at 2022-06-20 22:58:16.803037
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import json

    secrets = {'vault_password': 'secret', 'vault_id': 'vault_id'}

# Generated at 2022-06-20 22:58:21.604469
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test if __init__ initializes a class AnsibleJSONDecoder with correct parameters
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook == ansible_json_decoder.object_hook

# test the method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:30.115853
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:58:31.055675
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    assert AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:39.955669
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.vault import VaultSecret

    secret = VaultSecret('password')
    AnsibleJSONDecoder.set_secrets([secret])

    # Vaulted string
    data = '{"__ansible_vault": "vaulted_string"}'
    decoded = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert secret.decrypt(decoded) == 'vaulted_string'

    # Unsafe string
    data = '{"__ansible_unsafe": "unsafe_string"}'
    decoded = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(decoded, str)
    assert decoded == 'unsafe_string'

    # Normal string

# Generated at 2022-06-20 22:58:50.057504
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'password']
    input_str = '{ "__ansible_vault": "AES256:0feR+5D5l6RDzYwZ0BJZzB+8Gc3qXbF0fEJOPq3GqJ2eDZ0Mha4M4F1cOz\nJJRX9lA==\n" }'
    result = json.loads(input_str, cls=AnsibleJSONDecoder)
    assert result == AnsibleVaultEncryptedUnicode('8f1d65d7197f74e6', vault=VaultLib(secrets=secrets))

# Generated at 2022-06-20 22:58:59.725166
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import ansible.parsing.dataloader

    json_str = '''{
        "__ansible_unsafe": {
            "__ansible_vault": "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        }
    }'''

    ret = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(json_str)
    print(ret)

    ret[1]['__ansible_vault'] = ansible.p

# Generated at 2022-06-20 22:59:01.442360
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert '_vaults' in dir(AnsibleJSONDecoder)

# Generated at 2022-06-20 22:59:11.867878
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:25.781403
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n'
    secret += '396237346136626130336639653962343238373135626363383737353432303936336364366161333\n'
    secret += '62303938633035643939333035316663396363656237626633326665663739636437623338300a6366\n'
    secret += '3761666133323663353630663239323966333762356330643830656435393964663138636663316266\n'

# Generated at 2022-06-20 22:59:37.910858
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:39.912053
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = AnsibleJSONDecoder()
    assert hasattr(obj, '_vaults')
    assert isinstance(obj, json.JSONDecoder)


# Generated at 2022-06-20 22:59:47.125558
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # setup
    dec = AnsibleJSONDecoder()
    # test
    def test(pairs):
        return dec.object_hook(pairs)
    # test
    assert test({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert test({'__ansible_unsafe': 'foo'}) == AnsibleUnsafeText('foo')

# Generated at 2022-06-20 22:59:55.025848
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_json = '{ "test" : "test value", "test_list" : [ "value1", "value2" ] }'
    decoded_value = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert "test" in decoded_value
    assert "test_list" in decoded_value
    assert decoded_value['test'] == "test value"
    assert decoded_value['test_list'] == [ "value1", "value2" ]


# Generated at 2022-06-20 23:00:03.989773
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:06.842629
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_decoder = AnsibleJSONDecoder()
    assert isinstance(json_decoder, json.JSONDecoder)



# Generated at 2022-06-20 23:00:16.770554
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:18.962862
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = AnsibleJSONDecoder()
    assert obj._vaults == {}



# Generated at 2022-06-20 23:00:28.929887
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    result = dataloader.load_from_file('../test/test.json')
    result['vault_value'].unlock('password')
    assert(result['vault_value_raw'] == 'test')

    result = dataloader.load_from_file('../test/test.yml')
    result['vault_value'].unlock('password')
    assert(result['vault_value_raw'] == 'test')

    result = dataloader.load_from_file('../test/test.yml')
    assert(result['vault_value'].vault == None)


if __name__ == "__main__":
    import nose

# Generated at 2022-06-20 23:00:33.521316
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:36.181028
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'test'
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults['default'].secrets == 'test'

# Generated at 2022-06-20 23:00:38.010614
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert a._vaults == {}

# Generated at 2022-06-20 23:00:42.567110
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib

    import json
    import os
    import unittest


# Generated at 2022-06-20 23:00:46.722080
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    du = {"__ansible_vault": "something", "__ansible_unsafe": "something_else"}
    assert json.loads(json.dumps(du), cls=AnsibleJSONDecoder) == du



# Generated at 2022-06-20 23:00:57.632660
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:09.291765
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['foo']
    AnsibleJSONDecoder.set_secrets(secrets)
    # Encoded string of AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:01:11.436933
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder(object_hook=json.load)  # Just test while it doesn't raise any exception

# Generated at 2022-06-20 23:01:13.712294
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert type(ansible_json_decoder) == AnsibleJSONDecoder


# Generated at 2022-06-20 23:01:14.521260
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:24.413881
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)



# Generated at 2022-06-20 23:01:28.826035
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Initializing an AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()
    assert decoder is not None
    # Initializing an AnsibleJSONDecoder with arguments
    decoder = AnsibleJSONDecoder([], object_hook=decoder.object_hook)
    assert decoder is not None


# Generated at 2022-06-20 23:01:31.701461
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder.__name__ == 'AnsibleJSONDecoder'
    assert AnsibleJSONDecoder.__bases__ == (json.JSONDecoder,)

# Generated at 2022-06-20 23:01:36.881479
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets(None)

    json_v = json.loads('{"__ansible_vault": ""}', cls=AnsibleJSONDecoder)
    assert isinstance(json_v[0], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:01:38.624239
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder
    assert json.JSONDecoder

# Generated at 2022-06-20 23:01:42.066269
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

    decoder = AnsibleJSONDecoder(object_hook=decoder.object_hook)
    assert decoder._vaults == {}


# Generated at 2022-06-20 23:01:50.519402
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:01.802851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    unencrypted_path = {'path': '/tmp/foo'}
    encrypted_path = {'path': '/tmp/foo', '__ansible_vault': 'foo'}
    unsafe_path = {'path': '/tmp/foo', '__ansible_unsafe': {'value': '/tmp/foo'}}

    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook(unencrypted_path) == unencrypted_path
    assert decoder.object_hook(enc.encode(unencrypted_path)) == unencrypted_path

    assert decoder.object_hook(encrypted_path) == encrypted_path
    assert decoder.object_hook(enc.encode(encrypted_path)) == encrypted_path


# Generated at 2022-06-20 23:02:08.712838
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:10.547275
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None

# Generated at 2022-06-20 23:02:31.181750
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

    assert(ansible_json_decoder.object_hook == ansible_json_decoder.object_hook)


# Generated at 2022-06-20 23:02:42.826605
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_secrets = "notasecret"
    expect_vault_secrets = vault_secrets
    json_str = """{
        "__ansible_vault": "mycipher",
        "__ansible_unsafe": "myuser:mypasswd"
    }"""

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder.set_secrets(vault_secrets)

    assert decoder._vaults['default'].secrets == expect_vault_secrets
    decoded = decoder.decode(json_str)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['__ansible_unsafe'], wrap_var)



# Generated at 2022-06-20 23:02:53.426430
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:58.408206
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    ansible_decoder = AnsibleJSONDecoder()
    json_ansible = {"__ansible_unsafe": "input_text"}
    json_input = json.dumps(json_ansible)

    ret = ansible_decoder.decode(json_input)
    assert ret == json_ansible



# Generated at 2022-06-20 23:03:06.405760
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    data_dict = {}
    json_str = json.dumps(data_dict)

    # Initialize the decoder with the secret key
    vault_secret_key = 'ANSIBLE'
    decoder = AnsibleJSONDecoder.set_secrets([vault_secret_key])

    # Verify that the decoder has attributes vault_secret_key, vault_secrets and data_dict
    assert decoder.vault_secret_key == 'ANSIBLE'
    assert decoder.vault_secrets == ['ANSIBLE']
    assert decoder.data_dict == {}

    # Decode the JSON string
    decoder_output = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert decoder_output == data_dict

# Generated at 2022-06-20 23:03:09.273775
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    error = "Test failed, "
    try:
        # Test default constructor
        decoder = AnsibleJSONDecoder()

        # Test constructor with arguments
        decoder = AnsibleJSONDecoder(
            object_hook=AnsibleJSONDecoder.object_hook
        )
    except Exception as e:
        return error + str(e)

    return True

# Generated at 2022-06-20 23:03:11.279274
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)


# Generated at 2022-06-20 23:03:13.880721
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        AnsibleJSONDecoder()
    except Exception:
        raise AssertionError("Error while creating AnsibleJSONDecoder instance.")



# Generated at 2022-06-20 23:03:24.570077
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    ansible_json_encoder = AnsibleJSONEncoder()
    
    # Create test data structure
    data = {
        "a_number_value": 1,
        "a_string_value": "foo",
        "true_value": True,
        "false_value": False,
        "null_value": None,
        "a_vault_password": {
            "__ansible_vault": "vault_value"
        }
    }
    key = []
    key.append("secret")

    encoded_data = ansible_json_encoder.encode(data)
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(key)

# Generated at 2022-06-20 23:03:25.688254
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass



# Generated at 2022-06-20 23:04:14.565905
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text_1 = '''
    {
        "__ansible_vault": "encrypeted text",
        "__ansible_unsafe": "unsafe value"
    }
    '''
    json_text_2 = '''
    {
        "__ansible_vault": "encrypeted text"
    }
    '''
    json_text_3 = '''
    {
        "__ansible_unsafe": "unsafe value"
    }
    '''

    # Test for __ansible_vault and __ansible_unsafe.
    ansible_decoder = AnsibleJSONDecoder()
    ansible_decoder._vaults['default'] = "secret_password"

# Generated at 2022-06-20 23:04:25.513809
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Unit test for method object_hook of class AnsibleJSONDecoder
    # Scenario 1:
    # When:
    # - Value of key is not a string
    # Then:
    # - It should return the value

    decoder = AnsibleJSONDecoder()
    pairs = { "key1": 'abc', "key2": {}, "key3": []}
    result = decoder.object_hook(pairs)
    assert result['key1'] == 'abc'
    assert result['key2'] == dict()
    assert result['key3'] == list()

    # Unit test for method object_hook of class AnsibleJSONDecoder
    # Scenario 2:
    # When:
    # - Key is __ansible_vault
    # Then:
    # - It should return the AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:04:27.753143
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansibleDecoder = AnsibleJSONDecoder(["hey"])
    assert ansibleDecoder.object_hook("hey") == "hey"


# Generated at 2022-06-20 23:04:30.308017
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    # Check the type of variable
    assert isinstance(decoder, AnsibleJSONDecoder)

# Generated at 2022-06-20 23:04:37.664011
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=lambda pairs: pairs)

    assert decoder.object_hook({'__ansible_vault': 'test_value'}) == AnsibleVaultEncryptedUnicode('test_value')
    assert decoder.object_hook({'__ansible_unsafe': 'test_value'}) == wrap_var('test_value')
    assert decoder.object_hook({'__ansible_vault': 'test_value', '__ansible_unsafe': 'test_value'}) == AnsibleVaultEncryptedUnicode('test_value')

# Generated at 2022-06-20 23:04:39.613637
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder._vaults == {}
    assert AnsibleJSONDecoder.set_secrets
    assert AnsibleJSONDecoder.object_hook



# Generated at 2022-06-20 23:04:42.770923
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_str = '{"__ansible_vault": "foo"}'
    decoder = AnsibleJSONDecoder()
    decoder_secret = AnsibleJSONDecoder()
    secret = ["foo"]
    decoder_secret.set_secrets(secret)
    assert decoder.decode(test_str).vault == None
    assert decoder_secret.decode(test_str).vault.secrets == secret

# Generated at 2022-06-20 23:04:55.177775
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    res = decoder.object_hook(({'__ansible_vault': '$ANSIBLE_VAULT;1.1;ABCD\n1234567890123456789012345678901234567890\n01234567890123456789012345678901234567890'}))
    assert res.vault.secrets == ['default']
    assert res.vault.secrets_filename == ['']
    assert res.vault.is_encrypted('') == True
    assert res.vault.is_encrypted('foo') == False
    assert res.vault.is_encrypted('foo') == False
    assert res.vault.is_encrypted('') == True

# Generated at 2022-06-20 23:05:02.674530
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create an instance of class AnsibleJSONDecoder
    # Expect the pairs of the dictionary to be returned
    # with the key '__ansible_vault' being replaced by an
    # instance of AnsibleVaultEncryptedUnicode
    # and the key '__ansible_unsafe' being replaced by
    # a proxy object of class AnsibleUnsafeText
    json_decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_vault': '123',
        '__ansible_unsafe': 'text',
        'key': 'value'
    }

    # Call method object_hook of class AnsibleJSONDecoder
    # Expect the return value to be a dictionary such as
    # { '__ansible_vault': <instance of AnsibleVaultEncryptedUnicode>,
    #   '

# Generated at 2022-06-20 23:05:09.306843
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert type(AnsibleJSONDecoder.object_hook({'__ansible_vault': 'foo'})) == AnsibleVaultEncryptedUnicode
    assert type(AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'foo'})) == unicode
    assert AnsibleJSONDecoder.object_hook({'bar': 'foo'}) == {'bar': 'foo'}
