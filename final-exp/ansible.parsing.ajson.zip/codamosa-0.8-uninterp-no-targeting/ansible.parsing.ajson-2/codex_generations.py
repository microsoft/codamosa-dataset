

# Generated at 2022-06-20 22:55:53.468849
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_constant == float
    assert decoder.strict == True

# Generated at 2022-06-20 22:55:59.614393
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

    # Test if object_hook function is called
    object_hook_called = False
    def object_hook(pairs):
        nonlocal object_hook_called
        object_hook_called = True
        return pairs

    decoder = AnsibleJSONDecoder(object_hook=object_hook)
    decoder.decode('{}')
    assert object_hook_called is True

# Generated at 2022-06-20 22:56:10.721683
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = "{'vault_password': 'foo'}"
    try:
        AnsibleJSONDecoder.set_secrets(json.loads(secrets))
    except ValueError as e:
        assert Exception(e)

# Generated at 2022-06-20 22:56:23.974791
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = dict(pairs=True, boolean1=False, boolean2=True, integer1=1, integer2=2, string1='str1', string2='str2',
                 list1=[1, 2, 3], list2=[4, 5, 6], dict1=dict(k1='v1', k2='v2'), dict2=dict(k3='v3', k4='v4'))

    result1 = decoder.object_hook(pairs)
    assert result1 == pairs

    pairs['__ansible_vault'] = 'encrypted_value'
    pairs['__ansible_unsafe'] = 'unsafe_value'
    result2 = decoder.object_hook(pairs)

# Generated at 2022-06-20 22:56:35.785830
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert decoder.object_hook({'__ansible_vault': 'encrypted value'}).vault is None
    decoder.set_secrets('my_secret_password')
    assert decoder.object_hook({'__ansible_vault': 'encrypted value'}).vault is not None
    assert decoder.object_hook({'__ansible_vault': 'encrypted value'}).vault.decrypt('my_secret_password') == 'encrypted value'
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'decrypted value'}), wrap_var)

# Generated at 2022-06-20 22:56:48.375673
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Add a test secret to the vault
    decoder._vaults['default'] = VaultLib(secrets=["supersecret"])
    # Make sure it can decrypt __ansible_vault blocks

# Generated at 2022-06-20 22:56:58.265399
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test initialize from AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()

    # Test for a protected key/value pair
    data = dict(__ansible_vault='this is vaulted data')
    assert decoder.object_hook(data).data == 'this is vaulted data'

    # Test for a protected key/value pair
    data = dict(__ansible_unsafe='this is vaulted data')
    assert decoder.object_hook(data) == 'this is vaulted data'

    # Test for an unprotected key/value pair
    data = dict(normal_key='this is not vaulted data')
    assert decoder.object_hook(data) == data

# Generated at 2022-06-20 22:57:06.348895
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_string = '{"__ansible_vault": "AES256!Vault!$!&", "__ansible_unsafe": "&@*$T*^!"}'
    ansible_json_decoder_instance = AnsibleJSONDecoder(
        object_hook=AnsibleJSONDecoder.object_hook)
    ansible_json_decoder_instance.set_secrets([{'x': 1, 'y': 2}])
    result_dict = json.loads(test_string, cls=ansible_json_decoder_instance)
    assert isinstance(result_dict['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)
    assert result_dict['__ansible_vault'].value == 'AES256!Vault!$!&'

# Generated at 2022-06-20 22:57:16.690201
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    # Test for vault with default vault when default vault exists
    test_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    secrets = ['1234567890']
    AnsibleJSONDecoder.set_secrets(secrets)
    test_AnsibleJSONDecoder = AnsibleJSONDecoder()
    result = test_AnsibleJSONDecoder.object_hook(test_dict)
    expected_result = {'__ansible_vault': AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')}
    expected_result['__ansible_vault'].vault = VaultLib(secrets)
    assert result == expected_result

    # Test

# Generated at 2022-06-20 22:57:17.188793
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 22:57:27.468926
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.six import PY3

    # Test the json decoder object hook method when there is no __ansible_vault key
    decoder = AnsibleJSONDecoder()
    pairs = dict(a='some', b='dictionary')
    decoder_out = decoder.object_hook(pairs)
    assert decoder_out == pairs

    # Test the json decoder object hook method with __ansible_vault key
    decoder = AnsibleJSONDecoder()
    pairs = dict(a='some', b='dictionary', __ansible_vault='dc0e2e7db82de962a61fe6d8e1ea4a6a')
    decoder_out = decoder.object_hook(pairs)

# Generated at 2022-06-20 22:57:36.924139
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test object_hook with __ansible_vault
    obj = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'yolo', '__ansible_unsafe': "unsafe"})
    assert type(obj) is AnsibleVaultEncryptedUnicode
    assert obj.decrypt() == "yolo"

    # Test object_hook with __ansible_unsafe
    obj = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'yolo', '__ansible_unsafe': "unsafe"})
    assert type(obj) is AnsibleVaultEncryptedUnicode
    assert obj.decrypt() == "yolo"

# Generated at 2022-06-20 22:57:43.407963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set secrets for VaultLib
    secrets = [b'$uper$ecret']
    AnsibleJSONDecoder.set_secrets(secrets)
    # Check if VaultLib is set
    assert AnsibleJSONDecoder._vaults['default'].secrets, secrets
    # Test object_hook

# Generated at 2022-06-20 22:57:53.545432
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:04.993603
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = [u'vault-password']
    data = u'{"__ansible_vault": "vault-password"}'

    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secret)
    decoded = decoder.decode(data)
    vault = decoded['__ansible_vault']

    assert hasattr(vault, 'vault')
    assert vault.vault is not None
    assert vault.vault.secrets == secret
    assert vault.vault._get_text('vault-password') == 'vault-password'

    # set_secrets() creates a default vault and it is used when we create a new
    #   AnsibleJSONDecoder() instance with no vault specified.
    decoder = AnsibleJSONDecoder()
    decoded = decoder

# Generated at 2022-06-20 22:58:07.010898
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Verify that the constructor does not fail
    json_decoder = AnsibleJSONDecoder()
    assert json_decoder is not None



# Generated at 2022-06-20 22:58:15.353530
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = """'{"ansible_facts": {"key": "val"}, "__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n         ..."}'"""
    decoder = AnsibleJSONDecoder(json_data)
    assert isinstance(decoder.raw_decode(), dict)
    assert isinstance(decoder.raw_decode(), dict)
    assert isinstance(decoder.raw_decode(), dict)
    assert isinstance(decoder.raw_decode(), dict)
    

# Generated at 2022-06-20 22:58:17.666507
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    x = AnsibleJSONDecoder()
    assert x is not None

# Unit tests for method AnsibleJSONDecoder.set_secrets

# Generated at 2022-06-20 22:58:19.803391
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder.set_secrets is not None
    assert AnsibleJSONDecoder._vaults['default'] is not None

# Generated at 2022-06-20 22:58:29.083067
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()
    # original string
    normal_str = 'some plain text'
    # vault-encrypted string
    vault_str = '$ANSIBLE_VAULT;1.1;AES256\n34333736643034653734393833356566363635653365386638356134666565373338653837333733\n30616636343833363737353466353437663437346634363266333634336365653830643563313738\n3565653334396631333533356265386130663964'
    # unsafe string

# Generated at 2022-06-20 22:58:33.088786
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    x = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)


# Generated at 2022-06-20 22:58:37.224321
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [u'vaultpass123']
    decoder = AnsibleJSONDecoder()
    assert decoder.__class__.__name__ == 'AnsibleJSONDecoder'
    decoder.set_secrets(secrets)
    assert decoder._vaults['default'].secrets == secrets



# Generated at 2022-06-20 22:58:49.397760
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:59.369366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Unit test for method object_hook of class AnsibleJSONDecoder"""
    import textwrap
    import pytest


# Generated at 2022-06-20 22:59:10.674119
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:22.213058
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:28.179932
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = AnsibleJSONDecoder().object_hook({
        '__ansible_vault': 'value1',
        '__ansible_unsafe': 'value2'
    })
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['__ansible_unsafe'] == wrap_var('value2')

# Generated at 2022-06-20 22:59:38.719713
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    json_data = {'foo': 'bar',
                 '__ansible_vault': 'foo',
                 '__ansible_unsafe': 'bar'}

    secrets = ['password']
    v = VaultLib(secrets=secrets)

    d1 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    d2 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    d3 = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    AnsibleJSONDecoder.set_secrets(secrets)
    # Raise error: object_hook is not callable

# Generated at 2022-06-20 22:59:39.516488
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()



# Generated at 2022-06-20 22:59:50.950741
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secret = 'secret'

    obj_from_json = json.loads('{"__ansible_vault": "U2FsdGVkX1/I1QKdQFuAmgJ2Q6nXo+Z3zq3KjMkIY6Y=", "__ansible_unsafe": "test"}', cls=AnsibleJSONDecoder, parse_float=None, parse_int=None, parse_constant=None, object_pairs_hook=None)

    # cannot test vault decryption without supplying secret key
    # see https://github.com/ansible/ansible/blob/devel/lib/ansible/parsing/vault/init.py#L423
    AnsibleJSONDecoder.set_secrets(secret)

    # assert obj_from_json.__getitem__

# Generated at 2022-06-20 23:00:05.168475
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:16.045963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def object_hook(pairs):
        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                value = AnsibleVaultEncryptedUnicode(value)
                value.vault = VaultLib(secrets='1234567890')
                return value
            elif key == '__ansible_unsafe':
                return wrap_var(value)

        return pairs


# Generated at 2022-06-20 23:00:24.673263
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_pw = 'secret'
    secrets = [ vault_pw ]

    # Construct the decoder with secrets so that __ansible_vault objects can be decrypted
    test_decoder = AnsibleJSONDecoder()
    test_decoder.set_secrets(secrets)

    # Check that the decoder has been initialized with the correct vault
    assert test_decoder.decode('{"__ansible_vault": "test"}') == u'test'

# Generated at 2022-06-20 23:00:29.644147
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    assert not AnsibleJSONDecoder._vaults
    assert AnsibleJSONDecoder('{"foo":"bar"}')
    
    decoder = AnsibleJSONDecoder.set_secrets(secrets=['bar', 'baz'])
    assert AnsibleJSONDecoder._vaults

    assert AnsibleJSONDecoder('{"foo":"bar"}')
    assert AnsibleJSONDecoder('{"__ansible_unsafe":"bar"}')
    assert AnsibleJSONDecoder('{"__ansible_vault":"bar"}')


# Generated at 2022-06-20 23:00:33.342100
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # secret data
    secret_data = 'my_long_password'
    # set secrets to the class _vaults
    AnsibleJSONDecoder.set_secrets(secret_data)
    # input data

# Generated at 2022-06-20 23:00:45.102925
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import os
    import sys
    import unittest

    from ansible.module_utils.six.moves import StringIO

    class TestModuleCli(unittest.TestCase):

        # test AnsibleJSONDecoder: constructor
        def test_constructor(self):
            decoder = AnsibleJSONDecoder()

            # test if patern is correctly set
            self.assertEqual(decoder.parse_constant, json.decoder.JSONDecoder.parse_constant)

            # test if patern is correctly set
            self.assertEqual(decoder.parse_constant, json.decoder.JSONDecoder.parse_constant)

    suite = unittest.TestLoader().loadTestsFromModule(TestModuleCli())
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-20 23:00:51.320024
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class TestVault(object):

        def loads(self, s):
            return s

    test_vault = TestVault()

    # Set a default vault for the AnsibleJSONDecoder
    AnsibleJSONDecoder.set_secrets('test_secret')

    # Encode some test data
    ts = {
        'a': 'b',
        '__ansible_vault': 'foobar',
        '__ansible_unsafe': {'c': 'd'},
    }

    j = json.dumps(ts, cls=AnsibleJSONEncoder)

    # Test it with the AnsibleJSONDecoder
    ts2 = json.loads(j, cls=AnsibleJSONDecoder)

    assert ts2['__ansible_vault'].vault == test_vault

    # Test the

# Generated at 2022-06-20 23:00:55.046337
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'my_secrets'
    obj = AnsibleJSONDecoder()
    assert obj._vaults == {}
    obj.set_secrets(secrets)
    assert obj._vaults['default'].secrets == secrets

# Generated at 2022-06-20 23:01:00.379686
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Arrange
    secrets = 'test_secret'
    exp_vault = VaultLib(secrets=secrets)

    # Act
    decoder = AnsibleJSONDecoder.set_secrets(secrets)

    # Assert
    assert decoder._vaults['default'] == exp_vault


# Generated at 2022-06-20 23:01:09.977042
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;somekey\n62316431642316431643164316431643164=\n'
    }
    value = ansible_json_decoder.object_hook(pairs)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.vault.secrets == ['somekey']
    assert value == '$ANSIBLE_VAULT;1.1;AES256;somekey\n62316431642316431643164316431643164=\n'



# Generated at 2022-06-20 23:01:19.751002
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:01:26.991279
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    dec = AnsibleJSONDecoder()
    assert isinstance(dec, json.JSONDecoder)
    assert isinstance(dec, AnsibleJSONDecoder)
    assert dec._vaults == {}
    dec.set_secrets('test_vault_secrets')
    dec._vaults['default'] = VaultLib(secrets='test_vault_secrets')
    assert dec._vaults['default'] == VaultLib(secrets='test_vault_secrets')


# Generated at 2022-06-20 23:01:35.893012
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # A test secret to encrypt the test text below
    secret = 'secret'

    # The text below is encrypted using Python and the secret above

# Generated at 2022-06-20 23:01:45.745439
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:47.194157
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook, object)

# Generated at 2022-06-20 23:01:51.935086
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [('password', 'vault'), ('username', 'vault')]
    AnsibleJSONDecoder.set_secrets(secrets)
    data = [{
        "__ansible_vault": "vault password:vaultusername:vault",
        "password": "test123",
        "__ansible_unsafe": "test123"
    }]
    assert AnsibleJSONDecoder().decode(json.dumps(data)) == data

# Generated at 2022-06-20 23:01:54.087796
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

    assert ansible_json_decoder is not None

# Generated at 2022-06-20 23:02:05.376733
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    with open('./tests/fixtures/vault.json', 'r') as f:
        vault_str = f.read()
    with open('./tests/fixtures/vault.json', 'rb') as f:
        vault_bytes = f.read()
    with open('./tests/fixtures/vault.json', 'rb') as f:
        decoder = AnsibleJSONDecoder(f)
        vault_obj = decoder.decode()

    # test str
    decoder = AnsibleJSONDecoder(vault_str)
    vault_obj_str = decoder.decode()
    assert vault_obj == vault_obj_str

    # test bytes
    decoder = AnsibleJSONDecoder(vault_bytes)
    vault_obj_bytes = decoder.decode()
    assert vault

# Generated at 2022-06-20 23:02:10.761242
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = json.JSONDecoder()
    pairs = decoder.decode('{"__ansible_vault": "blah"}')
    pairs_object_hook = AnsibleJSONDecoder().object_hook(pairs)
    assert isinstance(pairs_object_hook, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-20 23:02:21.514892
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_encrypted_unicode = '$ANSIBLE_VAULT;1.1;AES256\r\n37356461633066363738373833306637363639356431383136643233623664343339643835613130\r\ncb88f25d6efd47e8c5b5e7fc5cf9e12f7c827e25aab7c1fe34d05eea91f8e513\r\n'
    test_dict = {'key1': 'value1', 'key2': 'value2', 'key3': ansible_vault_encrypted_unicode}
    secrets = ['test_secrets']
    # Create instance of AnsibleJSONDecoder class
    ansible_json_decoder = AnsibleJSONDecoder()


# Generated at 2022-06-20 23:02:42.045653
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secretpassword']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert secrets == AnsibleJSONDecoder._vaults['default'].secrets

# Generated at 2022-06-20 23:02:52.681175
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    vault_pass = 'vault_pass'
    decoder.set_secrets([vault_pass])

    # Check if a vault variable gets decrypted

# Generated at 2022-06-20 23:02:58.669918
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = json.dumps({'__ansible_unsafe': 'unsafe'}, cls=AnsibleJSONEncoder)
    assert json.loads(obj) == {'__ansible_unsafe': 'unsafe'}


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 23:03:06.968262
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:03:11.641298
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test if the class can be instantiated with no arguments
    AnsibleJSONDecoder()
    # test if the class can be instiated with arguments
    AnsibleJSONDecoder(object_hook=lambda x: None)
    AnsibleJSONDecoder(object_hook=lambda x: None, strict=False)

# Generated at 2022-06-20 23:03:18.805521
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    if sys.version_info[0:2] < (2, 7):
        import unittest2 as unittest  # python 2.6 needs backported unittest features
    else:
        import unittest

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleJSONDecoderObjectHook(unittest.TestCase):
        def test_object_hook_vault(self):
            secrets = [b'vault-password']
            AnsibleJSONDecoder.set_secrets(secrets)
            payload = '{"__ansible_vault": "vault-content"}'
           

# Generated at 2022-06-20 23:03:25.102371
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_vault': 'bar'}) == AnsibleVaultEncryptedUnicode('bar')
    assert decoder.object_hook({'__ansible_unsafe': 'bar'}) == wrap_var('bar')

# Generated at 2022-06-20 23:03:33.721529
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = """
    {
        "__ansible_vault": "MY_ANSIBLE_VAULT_ENCODED_STRING",
        "__ansible_unsafe": "MY_ANSIBLE_UNSAFE_STRING"
    }
    """

    decoder = AnsibleJSONDecoder()
    decoded = json.loads(data, cls=decoder.__class__)

    assert decoded['__ansible_vault']
    assert decoded['__ansible_unsafe']

    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:03:35.856578
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    f = AnsibleJSONDecoder()
    assert f is not None


# Generated at 2022-06-20 23:03:40.271469
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': 'some_value'}
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook(pairs)  # calls object_hook() of parent class
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:04:22.216588
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['foo']
    AnsibleJSONDecoder.set_secrets(secrets)
    
    json_data = '{"__ansible_vault": "bar"}'
    obj = AnsibleJSONDecoder().decode(json_data)

    assert obj == {'__ansible_vault': 'bar'}
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:04:29.209300
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test object_hook
    data = {
        'a': 'b',
        '__ansible_vault': 'vaulting',
        '__ansible_unsafe': {'a': 'b'}
    }
    enc = AnsibleJSONEncoder()
    encoded = enc.encode(data)
    dec = AnsibleJSONDecoder()
    dec.set_secrets(['test'])
    decoded = json.loads(encoded, cls=dec.__class__)
    assert not hasattr(decoded, 'object_hook')



# Generated at 2022-06-20 23:04:35.742729
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = """
            {
                "__ansible_vault": "hello"
            }
        """

    decoder = AnsibleJSONDecoder()
    secret = 'password'
    decoder.set_secrets(secret)
    result = decoder.decode(obj)
    assert(isinstance(result, dict))
    assert('__ansible_vault' in result)
    assert(result['__ansible_vault'] == 'hello')


# Generated at 2022-06-20 23:04:37.992214
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(encoding='utf-8')
    assert decoder is not None


# Generated at 2022-06-20 23:04:43.835517
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret1 = '$ANSIBLE_VAULT;1.1;AES256;test\n36623764303466303166613664306663303332373837343063653363333335376661326533306534\n37656363626565616331386134616161363139313231316461303833306431336166616439323862\n64333830643938336235396339313536373463613936303366303635616239376265666539643565\n39306561666561623662663838646532353430663132363138316236\n'

# Generated at 2022-06-20 23:04:46.601842
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
     decoder = AnsibleJSONDecoder()
     json_decode = json.loads('{"key":"value"}', cls=AnsibleJSONDecoder)
     assert json_decode == {'key': 'value'}



# Generated at 2022-06-20 23:04:51.365516
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder
    assert isinstance(ansible_json_decoder, json.JSONDecoder)



# Generated at 2022-06-20 23:04:55.339395
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_decoder = AnsibleJSONDecoder({"A": 1}, vault_secrets=["vault"])
    assert vault_decoder.vaults["default"]
    assert vault_decoder.vaults["default"].secrets == ["vault"]
    assert vault_decoder.vaults["default"].password is None

# Generated at 2022-06-20 23:04:57.074373
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_decoder = AnsibleJSONDecoder(object_hook=False)
    assert json_decoder.object_hook is False


# Generated at 2022-06-20 23:05:03.864606
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import ansible.parsing.yaml.objects as yaml_objects
    test_decoder = AnsibleJSONDecoder()
    test_dict = {
        'some_key': 'some_value',
        'some_other_key': 'some_other_value'
    }
    yaml_object_ansible_vault_encryption = "any_value"
    yaml_object_ansible_vault = yaml_objects.AnsibleVaultEncryptedUnicode(yaml_object_ansible_vault_encryption)
    yaml_object_ansible_unsafe = "any_value"
    yaml_object_ansible_unsafe_proxy = wrap_var(yaml_object_ansible_unsafe)
    test_dict_with_yaml_object_ansible_vault