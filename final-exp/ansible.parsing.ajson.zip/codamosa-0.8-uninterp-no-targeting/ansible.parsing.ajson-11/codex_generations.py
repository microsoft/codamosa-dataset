

# Generated at 2022-06-20 22:56:04.931452
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secret_key = "s3cr3tP@ssw0rd"
    secret_data = "something"
    vault_data = "$ANSIBLE_VAULT;1.1;AES256\n" + \
        "663331333933633262633163343637643937366436376239626262373636613832316662663565\n" + \
        "660a0a626162326239303633646164623163396138626530663835656634393065333536666236\n" +\
        "3430393636623931313466363439616431383134323837663837386631\n"

    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-20 22:56:11.628030
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

    decoder = AnsibleJSONDecoder(
        object_hook=AnsibleJSONDecoder.object_hook,
        _vaults={'another' : 'vault'})
    assert decoder._vaults == {'another': 'vault'}

    decoder = AnsibleJSONDecoder(
        object_hook=AnsibleJSONDecoder.object_hook)
    assert decoder._vaults == {}


# Generated at 2022-06-20 22:56:17.682243
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=None)

    # Testing if 'object_hook' is set on construction
    assert decoder.object_hook == AnsibleJSONDecoder.object_hook

    # Testing if '_vaults' is set on construction
    assert decoder._vaults == {}



# Generated at 2022-06-20 22:56:22.416746
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # https://github.com/ansible/ansible/issues/57051
    # Test that the constructor of class AnsibleJSONDecoder sets
    # the object_hook function to the object_hook method
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-20 22:56:32.153754
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    data = {'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256',
            '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    result = decoder.object_hook(data)  # expected to return {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256', '__ansible_var': '$ANSIBLE_VAULT;1.1;AES256'}
    assert result['__ansible_vault'] == '$ANSIBLE_VAULT;1.1;AES256'
    assert result['__ansible_unsafe'] == '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-20 22:56:45.239229
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [ 'test_secrets' ]

# Generated at 2022-06-20 22:56:48.596441
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secrets = "test_vault_pass"
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-20 22:56:59.978708
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest

    test_data = {
        'host': 'host1'
    }

# Generated at 2022-06-20 22:57:07.700165
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def object_hook(pairs):
        for key in pairs:
            value = pairs[key]


# Generated at 2022-06-20 22:57:17.438542
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Tests Object Hook of AnsibleJSONDecoder"""

    import json
    import unittest

    class AnsibleJSONDecoderTestCase(unittest.TestCase):
        """Tests Object Hook of AnsibleJSONDecoder"""

        def setUp(self):
            """Configure Test Object"""
            self.json_string = '{"__ansible_vault": "some encrypted vault data", "__ansible_unsafe": "some unsafe data", "a_key": "some value"}'

        def test_object_hook_method(self):
            """Test the object_hook method of AnsibleJSONDecoder"""

            from ansible.parsing.vault import VaultLib
            from ansible.utils.unsafe_proxy import AnsibleUnsafeText

            # Load JSON into dictionary

# Generated at 2022-06-20 22:57:23.459323
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'foo'}
    assert decoder.object_hook(pairs).encrypted_data == 'foo'

    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_unsafe': 'foo'}
    assert decoder.object_hook(pairs).text == 'foo'

# Generated at 2022-06-20 22:57:25.096501
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder
    assert isinstance(AnsibleJSONDecoder, object)


# Generated at 2022-06-20 22:57:36.409528
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'foobar'

    d = AnsibleJSONDecoder()
    assert d._vaults == {}

    d.set_secrets(secrets)
    assert isinstance(d._vaults['default'], VaultLib)
    assert isinstance(d._vaults['default'].secrets, unicode)
    assert d._vaults['default'].secrets == secrets

    json_ansible_vault_obj = {
        "__ansible_vault": "test"
    }
    ansible_vault_decoded_obj = d.decode(json.dumps(json_ansible_vault_obj))
    assert isinstance(ansible_vault_decoded_obj, dict)

# Generated at 2022-06-20 22:57:43.204291
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    my_json = json.dumps(dict(__ansible_vault='my_vault'), cls=AnsibleJSONEncoder)
    assert json.loads(my_json, cls=AnsibleJSONDecoder) == dict(__ansible_vault=AnsibleVaultEncryptedUnicode('my_vault'))
    assert json.loads(json.dumps(dict(__ansible_unsafe=dict(foo='bar')), cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder) == dict(__ansible_unsafe=dict(foo='bar'))


assert json.loads('{}') == {}
assert json.loads('{"foo": "bar"}') == {'foo': 'bar'}

# Generated at 2022-06-20 22:57:51.237660
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_vault_obj = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
    }

    ansible_unsafe_obj = {
        '__ansible_unsafe': 'PASSWORD',
    }

    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook(ansible_vault_obj), AnsibleVaultEncryptedUnicode)
    assert isinstance(decoder.object_hook(ansible_unsafe_obj), dict)



# Generated at 2022-06-20 22:57:56.340642
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jsonText = '''{
    "__ansible_vault": "my encrypted string",
    "__ansible_unsafe": "my unsafe string"
}'''
    dec = AnsibleJSONDecoder()
    dec._vaults['default'] = VaultLib(secrets='default')
    d = dec.decode(jsonText)
    assert isinstance(d["__ansible_vault"], AnsibleVaultEncryptedUnicode)
    assert isinstance(d["__ansible_unsafe"], AnsibleUnsafeText)

# Generated at 2022-06-20 22:58:07.405334
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(["secret"])

    # test with '__ansible_vault'
    pairs = {'__ansible_vault': 'value'}
    decoded = decoder.object_hook(pairs)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault is decoder._vaults['default']

    # test with '__ansible_unsafe'
    pairs = {'__ansible_unsafe': 'value'}
    decoded = decoder.object_hook(pairs)
    assert isinstance(decoded, wrap_var)
    assert decoded.getvalue() == 'value'

    # test with other key
    pairs = {'other': 'value'}


# Generated at 2022-06-20 22:58:10.486138
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        json.loads("""{"key":"value"}""", cls=AnsibleJSONDecoder)
    except Exception:
        return False
    else:
        return True

# Generated at 2022-06-20 22:58:11.605317
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 22:58:17.715003
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
   decoder = AnsibleJSONDecoder()
   assert decoder.object_hook({'__ansible_vault': 'string', 'key': 'value'}) == {'__ansible_vault': 'string', 'key': 'value'}

# Generated at 2022-06-20 22:58:28.900383
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # normal key-value pairs
    ret = decoder.object_hook({'a': 'A', 'b': 'B'})
    assert ret['a'] == 'A'
    assert ret['b'] == 'B'

    # key-value pair with __ansible_vault
    ret = decoder.object_hook({'a': 'A', '__ansible_vault': 'B'})
    assert ret['a'] == 'A'
    assert ret['__ansible_vault'] == AnsibleVaultEncryptedUnicode('B')

    # key-value pair with __ansible_unsafe
    ret = decoder.object_hook({'a': 'A', '__ansible_unsafe': 'B'})
    assert ret['a'] == 'A'
   

# Generated at 2022-06-20 22:58:38.364096
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(secrets=['secret'])
    enc = vault.encrypt('test')
    myobj = {'var': enc}
    myobjstring = json.dumps(myobj)
    myobjstring = myobjstring.replace('"', '"')  # workaround because 'json.loads' will remove the (necessary) escaped quotes
    myobjstring = myobjstring.replace('\\', '\\\\')  # workaround because 'json.loads' will not remove the non-necessary escaped backslashes
    dec = AnsibleJSONDecoder()

    AnsibleJSONDecoder.set_secrets(['secret'])
    dec.decode(myobjstring)
    assert enc == myobj['var']
    assert myobj['var'].v

# Generated at 2022-06-20 22:58:45.935950
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    results = decoder.object_hook({'__ansible_vault': 'something', '__ansible_unsafe': 'something_else'})
    assert isinstance(results['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(results['__ansible_unsafe'], AnsibleUnsafeText)


JSON_ENCODER = AnsibleJSONEncoder()
JSON_DECODER = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:58:57.083639
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_key = 'password'
    json_data = {
        'secure': '$ANSIBLE_VAULT;1.1;AES256\n'
                  '393938616266333137643437376431356264643531643835633962653466333435663036386661\n'
                  '656430333864653437643037333661366131383066356437663436363335643730653366653937\n'
                  '3734663863393566376364\n',
        'not_secure': 'This value is not encrypted'
    }
    # First, decode without setting ansible vault
    decoder_1 = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:59:09.280851
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import json
    import pytest
    from tempfile import NamedTemporaryFile
    from ansible.parsing.yaml import load as yaml_load
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultSecret

    # Ensure that the tests run in a consistent path
    os.chdir(os.path.dirname(__file__))

    with NamedTemporaryFile() as vault_file:
        vault_file.write(b'\n'.join([to_bytes('%s' % ''.join(["1" for x in range(8)]))]))
        vault_file.flush()

        # Initialize Vault

# Generated at 2022-06-20 22:59:16.712616
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    expect_result = {'key1': 'value1', 'key2': 'value2'}
    ansible_dict = {'key1': 'value1', 'key2': 'value2'}
    encoded_str = json.dumps(ansible_dict, cls=AnsibleJSONEncoder)
    decoded_str = json.loads(encoded_str, cls=AnsibleJSONDecoder)
    result = ansible_dict == decoded_str
    assert result == True


# Generated at 2022-06-20 22:59:28.511147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    secrets = ['vaultpass']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:59:38.938906
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = b'{"__ansible_vault": "VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV", "__ansible_unsafe": {"b": "AAAAAA=="}}'
    v = GuessJSONDecoder(d)
    expect = {'__ansible_vault': 'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV', '__ansible_unsafe': {'b': 'AAAAAA=='}}

# Generated at 2022-06-20 22:59:42.232046
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets('test')
    import json
    data = {'test': 'test'}
    assert json.loads(json.dumps(data), cls=AnsibleJSONDecoder) == {'test': 'test'}

# Generated at 2022-06-20 22:59:54.645375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common._collections_compat import MutableMapping

    # TODO: Replace with __jsonclass__ hack when 2.6 compatibility is dropped
    class _AnsibleJSONDecoderTester(MutableMapping):
        def __getitem__(self, key):
            if key == 'test':
                return 'test'
            else:
                return None

    json_class_test = _AnsibleJSONDecoderTester

    # Generate a string that is similar to what we expect to get in json.
    # While unpickling we'll make sure that the object hook is called.
    pairs = {'__ansible_vault': 'value', '__ansible_unsafe': 'value'}
    pairs['__jsonclass__'] = ['test', {}]

# Generated at 2022-06-20 22:59:59.497731
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = AnsibleJSONDecoder()

    assert obj is not None

# Generated at 2022-06-20 23:00:12.059675
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    y = """
    foo:
    - 1
    - 2
    - 3
    """
    yaml_list = yaml.load(y)
    assert isinstance(yaml_list, dict) is True, 'yaml.load should return a dict, got %s' % type(yaml_list)
    assert 'foo' in yaml_list, 'key "foo" should be in dict'
    assert isinstance(yaml_list['foo'], list) is True, 'value of key "foo" should be list, got %s' % type(yaml_list['foo'])
    assert isinstance(yaml_list['foo'][0], int) is True, 'first element of list should be int, got %s' % type(yaml_list['foo'][0])

# Generated at 2022-06-20 23:00:15.102281
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({"__ansible_unsafe": "value"}) == "value"
    assert decoder.object_hook({"__ansible_vault": "value"}) == "value"

# Generated at 2022-06-20 23:00:27.690490
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import datetime

# Generated at 2022-06-20 23:00:30.266931
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=lambda pairs: pairs)
    assert isinstance(decoder, json.JSONDecoder)


# Generated at 2022-06-20 23:00:41.492310
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test regular JSON
    test_json = json.loads('{"test": "json"}', cls=AnsibleJSONDecoder)
    assert test_json == {"test": "json"}

    # Test ansible_vault JSON
    test_json = json.loads('{"test": "json", "__ansible_vault": "test_vault"}', cls=AnsibleJSONDecoder)
    assert isinstance(test_json, dict)
    assert isinstance(test_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert test_json['__ansible_vault'] == "test_vault"

    # Test ansible_unsafe JSON

# Generated at 2022-06-20 23:00:53.399941
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def dict_equal(a, b):
        return all(item in b.items() for item in a.items())

    decoder = AnsibleJSONDecoder()
    from_vault_ansible = {'__ansible_vault': 'vault:vaultstring'}
    vault_encrypted_obj = AnsibleVaultEncryptedUnicode(from_vault_ansible['__ansible_vault'])
    decoder_hook_obj = decoder.object_hook(from_vault_ansible)
    assert type(decoder_hook_obj) == type(vault_encrypted_obj)

    from_unsafe_ansible = {'__ansible_unsafe': 'safe:unsafe'}
    safe_obj = wrap_var(from_unsafe_ansible['__ansible_unsafe'])

# Generated at 2022-06-20 23:01:05.496817
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:07.779424
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Very simple test to verify that the decoder is created from
    # the expected class
    d = AnsibleJSONDecoder()
    assert d.__class__.__name__ == 'AnsibleJSONDecoder'

# Generated at 2022-06-20 23:01:10.752989
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is decoder.object_hook


# Generated at 2022-06-20 23:01:29.232648
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # testing jason.JSONDecoder
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.json import AnsibleJSONDecoder
    # testing jason.JSONDecoder
    # testing object_hook()
    # testing object_hook() with ansible_vault
    # testing object_hook() with ansible_unsafe
    vault = VaultLib(secrets=['test_password'])
    txt = """{ "__ansible_vault": "U2FsdGVkX19UzZliFoV+eydwKcQH7eOC8y9XVgMn1A=" }"""
    j = json.loads(txt, cls=AnsibleJSONDecoder)
    # All 'dict' class objects can be used with isinstance function

# Generated at 2022-06-20 23:01:31.318603
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert isinstance(jd, json.JSONDecoder)


# Generated at 2022-06-20 23:01:43.142966
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with empty dict
    assert AnsibleJSONDecoder.object_hook({}) == {}

    # Test with simple dict with unsafe proxy
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': '{"test": "test"}'}) == wrap_var({'test': 'test'})

    # Test with simple dict with vault
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test'}).value == 'test'
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test'})._decrypted_value == 'test'

    # Test with empty vault
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': ''}).value == ''

# Generated at 2022-06-20 23:01:46.190227
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert a._vaults == {}
    a = AnsibleJSONDecoder(object_hook=a.object_hook)
    assert a._vaults == {}

# Generated at 2022-06-20 23:01:55.243142
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-20 23:02:06.147051
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    if sys.version_info < (2,7,12):
        assert True
        return
    import unittest
    import random
    import string
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultLib

    from ansible.parsing.vault import VaultLib
    import ansible.parsing.vault

    class VaultDict(dict):

        def __init__(self, secrets):
            self.secrets = secrets

    class VaultLibMock(VaultLib):

        def __init__(self, secrets):
            self.secrets = secrets

        def load(self):
            return VaultDict(self.secrets)


# Generated at 2022-06-20 23:02:17.405946
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # setup
    json_text = """
    {
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible_test_user66763fb6e92434f76e6f0d2b5b5c5381ba2cjrwe33r",
        "__ansible_unsafe": "__ansible_unsafe_text"
    }
    """

    # run
    json_decoded = json.loads(json_text, cls=AnsibleJSONDecoder)

    # verify

# Generated at 2022-06-20 23:02:27.840238
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = json.loads(
        '{"foo": {"__ansible_vault": "vault_text", "__ansible_unsafe": "unsafe_text"}, "bar": "baz"}',
        object_hook=AnsibleJSONDecoder.object_hook
    )

    assert isinstance(decoded['foo']['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['foo']['__ansible_vault'] == 'vault_text'
    assert decoded['foo']['__ansible_unsafe'] == 'unsafe_text'
    assert decoded['bar'] == 'baz'


__all__ = ['AnsibleJSONEncoder', 'AnsibleJSONDecoder']

# Generated at 2022-06-20 23:02:34.565774
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json = r'''
    {
        "__ansible_vault": "vault_test",
        "__ansible_unsafe": "unsafe_test"
    }
    '''
    result = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert result["__ansible_vault"] == "vault_test"
    assert result["__ansible_unsafe"] == "unsafe_test"

# Generated at 2022-06-20 23:02:35.017757
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-20 23:02:57.329512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import from_json
    import os


# Generated at 2022-06-20 23:03:02.740646
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = {'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256'}
    json_decode_data = AnsibleJSONDecoder().object_hook(json_data)
    assert isinstance(json_decode_data, dict)
    assert '__ansible_unsafe' in json_decode_data.keys()


# Generated at 2022-06-20 23:03:05.077602
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # init class
    secrets = ['secret']
    decoder = AnsibleJSONDecoder(secrets=secrets)

    assert decoder._vaults['default']


# Generated at 2022-06-20 23:03:16.191309
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultError

    # test __ansible_vault

# Generated at 2022-06-20 23:03:27.406194
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class AnsibleJSONDecoderProxy(AnsibleJSONDecoder):
        def __init__(self):
            self.infos = []
            super(AnsibleJSONDecoderProxy, self).__init__()

        def object_hook(self, pairs):
            self.infos.append(('start', pairs))
            ret = super(AnsibleJSONDecoderProxy, self).object_hook(pairs)
            self.infos.append(('end', ret))
            return ret

    j = AnsibleJSONDecoderProxy()

    # empty pairs
    assert j.decode('{}') == {}
    assert j.infos == [('start', {}), ('end', {})]

    # pairs with __ansible_vault and __ansible_unsafe
    j = AnsibleJSONDecoderProxy()

# Generated at 2022-06-20 23:03:37.025116
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # testing unsafe var
    unsafe = {'__ansible_unsafe': True}
    unsafe_result = decoder.object_hook(unsafe)
    assert unsafe is unsafe_result

    # testing vault

# Generated at 2022-06-20 23:03:39.765294
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    dec = AnsibleJSONDecoder(foo='bar')
    assert dec.foo == 'bar'
    assert dec.object_hook(_) is _


# Generated at 2022-06-20 23:03:43.096926
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    assert d._vaults == {}
    d = AnsibleJSONDecoder([])
    assert d._vaults == {}



# Generated at 2022-06-20 23:03:49.620949
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Tests the method object_hook of class AnsibleJSONDecoder.

    In the end, all values with the key '__ansible_unsafe' should be a
    AnsibleUnsafeProxy object with the value of the key '__ansible_unsafe'.
    """
    testvals = ['hello', b'world', 1, True, None, {'__ansible_unsafe': 'hello'}]

    for val in testvals:
        result = AnsibleJSONDecoder().object_hook({'__ansible_unsafe': val})
        assert result == wrap_var(val)

# Generated at 2022-06-20 23:04:00.003902
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test if object_hook is working properly and if ansible_vault and unsafe are properly decrypted
    def secret(string):
        return '"' + string + '"'

    input = '''{"__ansible_vault": "vault_data", "__ansible_unsafe" : {"key":"value"}}'''
    expected_output = {'__ansible_vault': '"vault_data"', '__ansible_unsafe': {'key': 'value'}}
    AnsibleJSONDecoder.set_secrets(secret)
    content = json.loads(input, cls=AnsibleJSONDecoder)
    assert content == expected_output

    # Test if object_hook is working properly and if ansible_vault and unsafe are properly decrypted

# Generated at 2022-06-20 23:04:37.938801
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {}

# Generated at 2022-06-20 23:04:43.830813
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_decoder = AnsibleJSONDecoder()
    test_decoder._vaults['default'] = VaultLib(secrets='secret')
    test_ret_dict = test_decoder.object_hook({'__ansible_vault': 'abc', '__ansible_unsafe': 'abc'})
    test_ansible_vault = AnsibleVaultEncryptedUnicode('abc')
    test_ansible_vault.vault = test_decoder._vaults['default']
    assert test_ret_dict['__ansible_vault'] == test_ansible_vault
    assert test_ret_dict['__ansible_unsafe'] == wrap_var('abc')

# Generated at 2022-06-20 23:04:44.952612
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert not jd._vaults

# Generated at 2022-06-20 23:04:52.050413
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'vault text'}) == AnsibleVaultEncryptedUnicode('vault text')
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe text'}) == wrap_var('unsafe text')
    assert decoder.object_hook({'something': 'else'}) == {'something': 'else'}

# Generated at 2022-06-20 23:04:54.945965
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [42]
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert decoder._vaults['default'] == VaultLib(secrets=secrets)


# Generated at 2022-06-20 23:04:58.390504
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['ansible']
    AnsibleJSONDecoder.set_secrets(secrets)
    a = AnsibleJSONDecoder()
    # make sure the object_hook method is called
    a.object_hook = lambda pairs: None
    assert a.object_hook == a.object_hook

# Generated at 2022-06-20 23:05:02.177278
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    basic_json = '{"b_key": "b_value"}'
    ans_json_decoder = AnsibleJSONDecoder()
    basic_dict = json.loads(basic_json, cls=json.JSONDecoder)
    ans_dict = json.loads(basic_json, cls=ans_json_decoder.__class__)
    assert basic_dict == ans_dict


# Generated at 2022-06-20 23:05:06.432356
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """
    Test that the constructor of AnsibleJSONDecoder does not raise
    any exceptions.
    """
    # check for expected argument count
    AnsibleJSONDecoder(object_hook=None)
    AnsibleJSONDecoder()



# Generated at 2022-06-20 23:05:08.300082
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder


# Generated at 2022-06-20 23:05:17.960841
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = dict(a=1, b="hello")
    json_data = json.dumps(data, cls=AnsibleJSONEncoder)
    assert json_data == '{"a": 1, "b": "hello"}'

    # Unit test for constructor of class AnsibleJSONDecoder
    json_data = json.dumps(dict(ansible_vault=42, foo="bar"), cls=AnsibleJSONEncoder)
    assert json_data == '{"__ansible_vault": 42, "foo": "bar"}'

    # Unit test for constructor of class AnsibleJSONDecoder
    json_data = json.dumps(dict(ansible_unsafe="{{ foo }}"), cls=AnsibleJSONEncoder)
    assert json_data == '{"__ansible_unsafe": "{{ foo }}"}'