

# Generated at 2022-06-20 22:56:11.224522
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'password'

    # Test case with vault encrypted string
    keys = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    encrypted = 'ansible_test_string'
    keys['__ansible_vault'] = keys['__ansible_vault'] + '\n' + encrypted
    keys = json.dumps(keys)
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    keys = decoder.decode(keys)
    assert hasattr(keys['__ansible_vault'], 'vault')
    assert hasattr(keys['__ansible_vault'], 'vault_password')
    assert keys['__ansible_vault'].vault_password == secrets

# Generated at 2022-06-20 22:56:18.198931
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets(['mysecret'])
    j = '''{"__ansible_vault": "vault:mysecret", "__ansible_unsafe": "to be encrypted"}'''
    d = json.loads(j, cls=AnsibleJSONDecoder)
    assert type(d) == dict


# Generated at 2022-06-20 22:56:24.605026
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    raw_data = '{"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          623736366436316364653634356465333864653332316431386332666331356336356334363330\n          63326266323432613531353135313531353135313531353100\n          "}'
    decoder = AnsibleJSONDecoder()
    secrets = {'default' : 'secret'}
    decoder.set_secrets(secrets)
    data = decoder.decode(raw_data)
    vault = data['__ansible_vault']

# Generated at 2022-06-20 22:56:31.845655
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_text = '{"__ansible_vault": "encrypted_data", "__ansible_unsafe": "unsafe_data"}'
    expected = {'__ansible_vault': 'encrypted_data', '__ansible_unsafe': 'unsafe_data'}

    decoder = AnsibleJSONDecoder(expected)
    assert decoder.decode(json_text) == expected

# Generated at 2022-06-20 22:56:32.816684
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-20 22:56:34.019314
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:56:46.898452
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText

    secrets = 'foobar'

# Generated at 2022-06-20 22:56:58.470819
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder(object_hook=decoder.object_hook)

    test_data = {'__ansible_vault': '12345'}
    result = decoder.object_hook(test_data)

    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert type(result) == AnsibleVaultEncryptedUnicode
    assert result.vault is None

    test_data = {'__ansible_unsafe': '12345'}
    result = decoder.object_hook(test_data)

    assert isinstance(result, AnsibleUnsafeText)
    assert type(result) == AnsibleUnsafeText


# Generated at 2022-06-20 22:57:05.939270
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_string = '''{
        "a": "string",
        "boolean": true,
        "dict": {"foo": "bar"},
        "float": 1.5,
        "int": 1,
        "__ansible_vault": "foo",
        "__ansible_unsafe": "bar"
    }'''
    secrets = 'secret'
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    json_dict = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert json_dict['__ansible_vault'].vault == VaultLib(secrets=secrets)
    assert json_dict['__ansible_unsafe'] == "bar"

# Generated at 2022-06-20 22:57:09.475523
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, json.JSONDecoder)
    assert ansible_json_decoder.object_hook


# Generated at 2022-06-20 22:57:19.691738
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set up test input and expected output
    input = '[{"__ansible_vault": "test_vault"}, {"__ansible_unsafe": "test_unsafe"}]'
    expected = [{'__ansible_vault': 'test_vault'}, {'__ansible_unsafe': 'test_unsafe'}]

    # Run the test and assert that the results are as expected
    result = json.loads(input, cls=AnsibleJSONDecoder)
    assert result == expected

# Generated at 2022-06-20 22:57:21.218053
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook

# Generated at 2022-06-20 22:57:23.335705
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder != None

# Generated at 2022-06-20 22:57:24.971373
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None


# Generated at 2022-06-20 22:57:26.819512
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    # verify object_hook is set
    assert decoder.object_hook



# Generated at 2022-06-20 22:57:37.936497
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:57:47.462985
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = """"""
    d = AnsibleJSONDecoder()
    r = d.decode(s)
    assert r == {}
    s = """[1,2,3]"""
    r = d.decode(s)
    assert r == [1,2,3]
    s = """{"__ansible_vault": "VjBPR2Q2aVJaVzF0Y0d4c1pTND0=", "__ansible_vault_password": "hidden"}"""
    r = d.decode(s)
    assert r['__ansible_vault_password'] == 'hidden'

# Generated at 2022-06-20 22:57:55.971855
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['hunter2']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secrets

    # Test without vault key
    test_data = '{"key1": "value1", "key2": "value2"}'
    test_object = json.loads(test_data, cls=AnsibleJSONDecoder)
    assert test_object == {"key1": "value1", "key2": "value2"}

    # Test with vault key
    test_data = '{"key1": "value1", "__ansible_vault": "encrypted_value", "key2": "value2"}'
    test_object = json.loads(test_data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 22:58:06.114692
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    with open('xml.out', 'r') as file:
        doc=file.read()
        decoded = json.loads(doc, cls=AnsibleJSONDecoder, parse_int=None, parse_float=None, parse_constant=None, object_pairs_hook=None, **{})

    with open('xml.out.json', 'r') as file:
        assert(decoded == json.load(file, cls=AnsibleJSONDecoder, parse_int=None, parse_float=None, parse_constant=None, object_pairs_hook=None, **{}))

if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-20 22:58:17.166007
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # pylint: disable=too-many-lines
    aje = AnsibleJSONEncoder()

    # test unsafe
    val = AnsibleJSONDecoder().decode(aje.encode(dict(__ansible_unsafe='stuff')))

    assert isinstance(val, AnsibleJSONEncoder.AnsibleUnsafeText)
    assert val == 'stuff'

    # test unsafe
    val = AnsibleJSONDecoder().decode(aje.encode(dict(__ansible_unsafe=dict(__ansible_unsafe='stuff'))))

    assert isinstance(val, AnsibleJSONEncoder.AnsibleUnsafeText)
    assert isinstance(val, AnsibleJSONEncoder._AnsibleUnsafeDict)

# Generated at 2022-06-20 22:58:21.445592
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()
    assert enc._vaults == dec._vaults

    # dec.set_secrets()
    return 0

# Generated at 2022-06-20 22:58:26.163870
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    secrets = ['password']

    # Test secrets parameter of class method
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test constructor of class method
    decoder = AnsibleJSONDecoder()

    result = decoder.object_hook({'__ansible_vault': 'blah'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:58:35.928749
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Complex example from test_vault/test_vars/vault-var-complex.json

# Generated at 2022-06-20 22:58:48.070827
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # initialize class attributes
    AnsibleJSONDecoder._vaults = {}
    AnsibleJSONDecoder.set_secrets(None)

    # code under test
    class Dummy(object):
        pass

    class DummyEncoder(object):
        def __init__(self, *args, **kwargs):
            self.num_calls = 0
        def default(self, obj):
            self.num_calls += 1
            return "dummy"

    # set up testing data
    decoder = AnsibleJSONDecoder()
    data = { 'a' : 'A', 'b' : 1234, 'c' : '{{ lookup_var() }}', 'd' : Dummy() }
    data_str = json.dumps(data, cls=AnsibleJSONEncoder)

    # test normal case
   

# Generated at 2022-06-20 22:58:58.138969
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    test_secrets = ['super_secret_password']
    test_json_string_1 = '{"__ansible_vault": "AQD3EXAMPLEyvhz9XgMzOXJ6Y0r"}'
    test_json_string_2 = '{"__ansible_unsafe": "*"}'

    # test for '__ansible_vault' in json string
    AnsibleJSONDecoder.set_secrets(test_secrets)
    decoder = AnsibleJSONDecoder()
    decoder.object_hook(json.loads(test_json_string_1))

    # test for '__ansible_uunsafe' in json string
    decoder.object_hook(json.loads(test_json_string_2))



# Generated at 2022-06-20 22:59:09.765610
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText

    secrets = ('ansible', 'pw')
    AnsibleJSONDecoder.set_secrets(secrets)

    input_data = {"__ansible_vault": "test_vault"}
    expected = AnsibleVaultEncryptedUnicode(input_data["__ansible_vault"])
    expected.vault = AnsibleJSONDecoder._vaults['default']

    result = AnsibleJSONDecoder.object_hook(input_data)
    assert result == expected

    input_data = {"__ansible_unsafe": "test_unsafe"}
    expected = AnsibleUnsafeText(input_data["__ansible_unsafe"])

    result = AnsibleJSON

# Generated at 2022-06-20 22:59:12.578612
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['S3Cr3T']
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert isinstance(decoder, AnsibleJSONDecoder)

# Generated at 2022-06-20 22:59:20.911743
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_unsafe = '''{"__ansible_unsafe": "{{some_unsafe_var}}"}'''
    ansible_vault = '''{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256"}'''

    d = AnsibleJSONDecoder()
    assert d.object_hook(json.loads(ansible_unsafe)) == wrap_var('{{some_unsafe_var}}')
    assert isinstance(d.object_hook(json.loads(ansible_vault)), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:59:32.315554
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnDec=AnsibleJSONDecoder()
    assert isinstance(AnDec, json.JSONDecoder)
    AnsibleJSONDecoder.set_secrets(None)

    # Test if object_hook method can run properly
    assert AnDec.object_hook({'__ansible_vault': 'aaaaa', '__ansible_unsafe': 'bbbbbb'}) == {'__ansible_vault': 'aaaaa', '__ansible_unsafe': 'bbbbbb'}
    assert AnDec.object_hook({'__ansible_vault': 'aaaaa', '__ansible_plain': 'bbbbbb'}) == {'__ansible_vault': 'aaaaa', '__ansible_plain': 'bbbbbb'}

# Generated at 2022-06-20 22:59:35.525916
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test new_object is called
    class TestDecoder(AnsibleJSONDecoder):
        def new_object(self):
            return {}

    assert TestDecoder().new_object() is not None


# Generated at 2022-06-20 22:59:43.890843
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 22:59:45.561461
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-20 22:59:58.070073
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_data = '$ANSIBLE_VAULT;1.1;AES256\n363834383036653539346539333238656164626563306566336232643036363738623238\n343736393337663064393836383466366139336637353132643632316366316662386532\n393766653564373965646632333763393734646536333430643639396538323165646536\n65666638653866645a\n'
    unsafe_data = '$ANSIBLE_UNSAFE'

    decoder = AnsibleJSONDecoder()
    vault_obj = decoder.object_hook({'__ansible_vault': vault_data})
    unsafe_obj = decoder.object

# Generated at 2022-06-20 23:00:10.176530
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test single-level object
    obj = {
        "key1": "value1",
        "key2": "value2",
        "__ansible_vault": "vaulted_value",
        "__ansible_unsafe": "value3"
    }
    decoded_obj = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(json.dumps(obj))
    assert decoded_obj == {
        "key1": "value1",
        "key2": "value2",
        "__ansible_vault": "vaulted_value",
        "__ansible_unsafe": "value3"
    }
    assert isinstance(decoded_obj["__ansible_vault"], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:00:14.464341
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'value'}) == wrap_var('value')
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'value'}) == AnsibleVaultEncryptedUnicode('value')


# Generated at 2022-06-20 23:00:22.219513
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Ensure unsafe flag is set
    import ansible.module_utils.basic
    ansible.module_utils.basic.BOOL_CACHE = (True, False)

    it = {"__ansible_unsafe": "{{hello}}"}
    decoder = AnsibleJSONDecoder()
    assert str(decoder.object_hook(it)) == "'{{hello}}'"
    assert it == {"__ansible_unsafe": "{{hello}}"}

# Generated at 2022-06-20 23:00:24.250765
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert hasattr(AnsibleJSONDecoder, 'set_secrets')


# Generated at 2022-06-20 23:00:26.636617
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        AnsibleJSONDecoder()
    except BaseException as e:
        assert False, 'Unexpected exception raised: {0}'.format(e)

# Generated at 2022-06-20 23:00:31.096289
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_decoder = AnsibleJSONDecoder()
    assert json_decoder._vaults == {}, "_vaults is not initialized correctly"

    json_decoder = AnsibleJSONDecoder(object_hook=json_decoder.object_hook)
    assert json_decoder._vaults == {}, "_vaults is not initialized correctly"


# Generated at 2022-06-20 23:00:38.145582
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_data = {
        'foo': 'bar',
        'baz': {
            'qux': 42,
            'secret_value': {
                '__ansible_vault': 'vault_placeholder'
            },
            'unsafe_value': {
                '__ansible_unsafe': True
            }
        }
    }

    assert json.dumps(test_data, cls=AnsibleJSONEncoder) == '{"baz": {"qux": 42, "unsafe_value": {}, "secret_value": {}}, "foo": "bar"}'
    assert json.loads('{"baz": {"qux": 42, "unsafe_value": {}, "secret_value": {}}, "foo": "bar"}', cls=AnsibleJSONDecoder) == test_data


# Unit

# Generated at 2022-06-20 23:00:53.399628
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test __ansible_vault key
    decoder = AnsibleJSONDecoder()
    test_string = '''
            {
                "__ansible_vault": "test_string"
            }
        '''
    secrets = [u'123']
    decoder.set_secrets(secrets)
    assert decoder.decode(test_string) == {"__ansible_vault": b'YW55c3RyaW5n'}

    # test __ansible_unsafe key
    test_string = '''
            {
                "__ansible_unsafe": "test_string"
            }
        '''
    assert decoder.decode(test_string) == {"__ansible_unsafe": u'test_string'}

    # test other key value

# Generated at 2022-06-20 23:01:03.047924
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}
    test_dict = json_decoder.object_hook(pairs)
    assert isinstance(test_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(test_dict['__ansible_unsafe'], wrap_var)
    assert test_dict['__ansible_vault'].unprotected() == 'foo'
    assert test_dict['__ansible_unsafe'] == 'bar'



# Generated at 2022-06-20 23:01:12.736123
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = b"Hello"
    AnsibleJSONDecoder.set_secrets(secret)

    data = {}
    data['__ansible_vault'] = b' test_AnsibleJSONDecoder_object_hook'
    data['__ansible_unsafe'] = b' test_AnsibleJSONDecoder_object_hook'

    enc_text = AnsibleJSONEncoder().encode(data)
    dec_data = AnsibleJSONDecoder().decode(enc_text)

    assert isinstance(dec_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert dec_data['__ansible_vault'].vault is not None
    assert dec_data['__ansible_vault'].vault._secrets is not None

# Generated at 2022-06-20 23:01:19.075685
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:19.660631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-20 23:01:26.943052
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test with empty constructor

    assert AnsibleJSONDecoder() is not None

    # Test with empty constructor
    dec = AnsibleJSONDecoder(object_hook = AnsibleJSONDecoder.object_hook)

    assert dec is not None

    # Test with factory function - should return the same class
    dec_factory = json.JSONDecoder.new_object_hook(AnsibleJSONDecoder.object_hook)

    assert dec_factory == AnsibleJSONDecoder.object_hook

# Generated at 2022-06-20 23:01:30.697574
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, json.JSONDecoder)
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)



# Generated at 2022-06-20 23:01:37.566041
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ''' unit test for method object_hook of class AnsibleJSONDecoder '''
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    with patch('ansible.parsing.vault.VaultLib') as mock_vault_lib:
        mock_vault = MagicMock()
        mock_vault_lib.return_value = mock_vault

        decoder = AnsibleJSONDecoder()

        pairs = {
            '__ansible_vault': 'ansible-vault value',
        }
        ansible_vault = decoder.object_hook(pairs)
        assert ansible_vault == AnsibleVaultEncryptedUnicode('ansible-vault value')
        assert ansible_vault.vault == mock_v

# Generated at 2022-06-20 23:01:38.682261
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:01:40.129394
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-20 23:01:55.645204
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-20 23:02:06.235844
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n3635373335663938653833343661396262666631326539333736386265363530376539353832666330\n6130376534303830616134653766393033613063393836623035396435333262326637336431613837\n6631623266336164643735656562363163316535393963396230646535\n'
    secret = AnsibleVaultEncryptedUnicode(secret)

    # Test case: When secret is not None and object_hook is not None
    ansibleJSONDecoder = AnsibleJSONDecoder(secret, object_hook=json.loads)

    assert ansibleJSONDecoder.object_hook == json

# Generated at 2022-06-20 23:02:07.260195
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-20 23:02:18.131895
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # pylint: disable=protected-access
    assert AnsibleJSONDecoder._vaults == {}
    assert AnsibleJSONDecoder.set_secrets(['pass']) == None
    assert len(AnsibleJSONDecoder._vaults) == 1
    assert AnsibleJSONDecoder._vaults['default']._secrets == ['pass']
    assert isinstance(AnsibleJSONDecoder._vaults['default'], VaultLib)
    assert AnsibleJSONDecoder.set_secrets(None) == None
    assert AnsibleJSONDecoder._vaults == {}
    assert AnsibleJSONDecoder.set_secrets(['pass']) == None
    assert AnsibleJSONDecoder._vaults['default']._secrets == ['pass']


# Generated at 2022-06-20 23:02:26.608515
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    print('Testing AnsibleJSONDecoder class initialized with all params')
    AnsibleJSONDecoder()
    print('Testing AnsibleJSONDecoder class initialized with no params')
    AnsibleJSONDecoder(encoding='utf-8')
    print('Testing AnsibleJSONDecoder class initialized with no object_hook param')
    AnsibleJSONDecoder(object_hook=json.JSONDecoder)
    print('Testing AnsibleJSONDecoder class initialized with no params')
    AnsibleJSONDecoder(encoding='utf-8', object_hook=json.JSONDecoder)


# Generated at 2022-06-20 23:02:30.000873
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    assert decoder.object_hook == decoder.object_hook



# Generated at 2022-06-20 23:02:41.795771
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b"vaultpassword"]
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    pairs = {
        "__ansible_vault": "enc_data:dec_data",
        "__ansible_unsafe": "unsafe_data",
    }
    assert "__ansible_vault" in pairs
    assert "__ansible_unsafe" in pairs
    result = decoder.object_hook(pairs)
    assert "__ansible_vault" not in result
    assert "__ansible_unsafe" not in result
    assert isinstance(result["__ansible_vault"], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:02:52.501992
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_secrets = ['vaultpass']

# Generated at 2022-06-20 23:03:03.951939
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']

# Generated at 2022-06-20 23:03:15.149143
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''Test AnsibleJSONDecoder.object_hook'''

    # success case:

# Generated at 2022-06-20 23:03:36.150676
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:03:47.018775
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import random
    import string
    import sys

    def rand_str(length):
        return ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase) for _ in range(length))

    # Init a vault and get a secret
    vault_pwd = rand_str(15)
    vault_string = rand_str(15)
    vault_name = rand_str(15)
    vault_path = './' + vault_name

    vault = VaultLib(vault_pwd)
    vault_encoded = vault.encode(vault_string)

    # Init a AnsibleJSONDecoder instance,
    # before we can use this instance, we have to set secrets for vault
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:03:56.617932
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    json_str = '{ "__ansible_vault": "vault text", "__ansible_unsafe": "unsafe text" }'

    # Decode json_str
    decoded_pairs = json.loads(json_str, cls=AnsibleJSONDecoder)
    vault_text = decoded_pairs['__ansible_vault']
    unsafe_text = decoded_pairs['__ansible_unsafe']

    # Check AnsibleVaultEncryptedUnicode object is generated
    assert isinstance(vault_text, AnsibleVaultEncryptedUnicode)
    assert vault_text.data == 'vault text'
    assert not vault_text.vault

    # Check AnsibleUnsafeText object is

# Generated at 2022-06-20 23:03:58.133833
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder


# Generated at 2022-06-20 23:04:09.838631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_obj = {"a":{"b":"bla"},"__ansible_vault":":vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3235313239613934633162626532323562316538336130323861323133636338316564653163323963\n          6537666533346434633635316335616339396466643237643630353430626539636139303539616132\n          323462643934336466323361320000\n          ","c":"bli"}
    json_str = json.dumps(json_obj, cls=AnsibleJSONEncoder)
    json_decoded = json.loads(json_str, cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 23:04:14.381645
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_vault': '1234'}) == {'__ansible_vault': '1234'}
    assert decoder.object_hook({'__ansible_unsafe': '1234'}) == {'__ansible_unsafe': '1234'}


# Generated at 2022-06-20 23:04:17.074453
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder == json.JSONDecoder.__new__(AnsibleJSONDecoder)

# Generated at 2022-06-20 23:04:20.729530
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"key1": AnsibleVaultEncryptedUnicode("value1")}
    other_obj = {"key1": "value1"}
    AnsibleJSONDecoder.object_hook(obj)

    assert obj == other_obj

# Generated at 2022-06-20 23:04:30.866439
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-20 23:04:39.899553
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = {'spam': 'eggs'}
    # d = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;spam\n633366616236333632656439373039376162366537346233343137613161336266623239396636\n616430666531316432626335626539666163623230663065636534353636663063363231623433\n323734333462343163366236333636366165356665363966366532333365336138653331613835\n383665396432633033623162313363336262623838623662393937643264326564646236653737\n3937366534

# Generated at 2022-06-20 23:05:16.186132
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    #__ansible_vault attribute with value of '$ANSIBLE_VAULT;1'
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1'}
    decoder = AnsibleJSONDecoder()
    decoded = decoder.object_hook(pairs)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault is None
    assert decoded == '$ANSIBLE_VAULT;1'

# Unit tests for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:05:24.513472
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    a = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # test __ansible_vault

# Generated at 2022-06-20 23:05:35.038207
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  import unittest

  class AnsibleJSONDecoderTestCase(unittest.TestCase):
    def test_AnsibleJSONDecoder_object_hook(self):
      class TestObject(dict):
        def __init__(self, pairs):
          self.pairs = pairs

      # Convert object to pairs.
      pairs = {
        'b': "a"
      }
      pairs.update({'a': 1})

      # Test with valid '__ansible_vault' key.
      test_object = TestObject(pairs)

# Generated at 2022-06-20 23:05:43.864420
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # secret test

# Generated at 2022-06-20 23:05:49.728752
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class MyClass():
        def __init__(self):
            self.data = []

        def object_hook(self, pairs):
            self.data.append(pairs)

    ansible_json_decoder = AnsibleJSONDecoder(MyClass())
    test_data = {'key': 'value'}
    ret = ansible_json_decoder.decode(json.dumps(test_data))
    assert ret.data[0] == test_data



# Generated at 2022-06-20 23:05:54.261289
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '{"__ansible_vault": "vault_data"}'
    ansjson_data = AnsibleJSONDecoder().decode(json_data)
    vault_data = ansjson_data['__ansible_vault']
    assert isinstance(vault_data, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-20 23:06:02.223708
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']