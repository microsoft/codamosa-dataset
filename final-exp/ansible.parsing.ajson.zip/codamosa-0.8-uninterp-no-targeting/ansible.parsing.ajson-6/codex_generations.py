

# Generated at 2022-06-20 22:56:10.522313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'test'

    # Test AnsibleVaultEncryptedUnicode
    AnsibleJSONDecoder.set_secrets(secrets)
    s = '{ "__ansible_vault": "test" }'
    assert isinstance(json.loads(s, cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)
    assert len(AnsibleJSONDecoder._vaults['default']._secrets) == 1
    assert AnsibleJSONDecoder._vaults['default']._secrets == [secrets]

    # Test wrap_var
    s = '{ "__ansible_unsafe": "test" }'
    assert json.loads(s, cls=AnsibleJSONDecoder) == {'__ansible_unsafe': 'test'}

    # Test not wrapped variables

# Generated at 2022-06-20 22:56:15.316177
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"__ansible_vault": "foo"}'
    result = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:56:20.012114
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret
    decoder = AnsibleJSONDecoder()
    # Test __init__ for class AnsibleJSONDecoder
    assert decoder.object_hook == decoder.object_hook
    assert isinstance(decoder, json.JSONDecoder)


# Generated at 2022-06-20 22:56:26.924395
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible_vault
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode('{"__ansible_vault": "@pass@"}') == AnsibleVaultEncryptedUnicode("@pass@")

    # ansible_unsafe
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode('{"__ansible_unsafe": "password"}') == wrap_var("password")


# Generated at 2022-06-20 22:56:37.102274
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """
    AnsibleJSONDecoder class constructor
    """
    cls = AnsibleJSONDecoder()

    # no whitespace stripping
    string = '{"foo": "bar"}'
    assert cls.decode(string) == {u'foo': u'bar'}

    # a custom whitespace string is defined
    string = '{"foo": "bar"}'
    assert cls.decode(string) == {u'foo': u'bar'}

    # whitespace stripping is enabled
    string = '{"foo": "bar"}  \n'
    assert cls.decode(string) == {u'foo': u'bar'}

    # decoding an UNICODE string
    string = '{"foo": "bar"}'
    assert cls.decode(string) == {u'foo': u'bar'}

# Generated at 2022-06-20 22:56:49.733628
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # xfa_json = {
    #         "asdf": "asdfasdf",
    #         "__ansible_vault": "asdf",
    #         "__ansible_unsafe": "asdf",
    #         "__ansible_unsafe__asdf": "asdfasdf"
    #     }
    #
    # xfa_json_test = json.dumps(xfa_json).encode()
    #
    # new_json = AnsibleJSONDecoder().decode(xfa_json_test)
    #
    # assert isinstance(new_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # assert isinstance(new_json['__ansible_unsafe'], AnsibleUnsafeText)

    assert True

# Generated at 2022-06-20 22:56:53.940954
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert AnsibleVaultEncryptedUnicode('foo') == decoder.object_hook({'__ansible_vault': 'foo'})

# Generated at 2022-06-20 22:56:59.284315
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = { '__ansible_vault' : 'AAABBB==' }
    value = decoder.object_hook(pairs)
    assert type(value) == AnsibleVaultEncryptedUnicode
    assert value.vault == decoder._vaults['default']


# Generated at 2022-06-20 22:57:05.796718
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_unsafe":"string", "__ansible_vault":"string"}'
    json_list = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_list['__ansible_unsafe'], wrap_var)
    assert isinstance(json_list['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 22:57:16.279198
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j = json.loads("{\"__ansible_vault\": \"$ANSIBLE_VAULT;1.2;AES256;test;test\"}", cls=AnsibleJSONDecoder)
    assert j.startswith("$ANSIBLE_VAULT;1.2;AES256;test;test")
    AnsibleJSONDecoder.set_secrets(["pass"])
    j2 = json.loads("{\"__ansible_vault\": \"$ANSIBLE_VAULT;1.2;AES256;test;test\"}", cls=AnsibleJSONDecoder)
    assert j2.startswith("test")
    j3 = json.loads("{\"__ansible_unsafe\": {\"test\": \"test\"}}", cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 22:57:23.335351
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''Test the constructor of class AnsibleJSONDecoder'''
    # Construct the object
    ansible_json_decoder = AnsibleJSONDecoder()
    # Check if the object is an instance of class AnsibleJSONDecoder
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)


# Generated at 2022-06-20 22:57:30.258924
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    vault_data1 = AnsibleVaultEncryptedUnicode('1:1:$ANSIBLE_VAULT;1.1;AES256\n616e73756c7465642d76616e756c74\n')
    vault_data2 = AnsibleVaultEncryptedUnicode('1:2:$ANSIBLE_VAULT;1.1;AES256\n616e73756c7465642d76616e756c74\n')
    vault_data3 = AnsibleVaultEncryptedUnicode('1:2:$ANSIBLE_VAULT;1.1;AES256\n616e73756c7465642d76616e756c74\n')
    unsafe_data1 = wrap_var('ansible-unsafe')
    unsafe_

# Generated at 2022-06-20 22:57:40.252891
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    # Test encrypted string
    secrets = "hunter2"
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-20 22:57:44.687798
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

    decoder_2 = AnsibleJSONDecoder(object_hook=decoder.object_hook)
    assert decoder_2._vaults == {}

# Generated at 2022-06-20 22:57:53.695138
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = {'password': 'mysecret'}
    decoder = AnsibleJSONDecoder()
    # make sure the default object_hook is the one we wanted
    assert decoder.object_hook == decoder.object_hook
    # set a vault for the decoder
    decoder.set_secrets(secrets)
    # create a json.loads decoder
    json_decoder = json.loads('{"__ansible_vault": "myencryptedstring"}', 
                              cls=AnsibleJSONDecoder
                              )
    # make sure we get an AnsibleVaultEncryptedUnicode object
    assert isinstance(json_decoder.get('__ansible_vault'), 
                      AnsibleVaultEncryptedUnicode
                      )

# Generated at 2022-06-20 22:58:01.256258
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jsonval = json.dumps({"__ansible_vault": "value"})
    secrets = [hash("secret")]
    assert secrets[0] == hash("secret")
    AnsibleJSONDecoder.set_secrets(secrets)
    decoded = json.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(jsonval)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded.vault, VaultLib)

# Generated at 2022-06-20 22:58:10.122970
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create a dummy VaultLib, as it's difficult to load one from a real file
    secret = [{'test_password': '$6$n3qD3KjA$d8uP7sUeET6Dp34sPlxyjJz1aQG1T6Av38T6TvNiEJaglR7J9XOAXEKr90uNl8J0mtG3fcq3WP/aVuZ/0UeO6.'}]
    vault = VaultLib(secrets=secret)
    AnsibleJSONDecoder._vaults['default'] = vault

    # Check that an encrypted string is decrypted

# Generated at 2022-06-20 22:58:14.974077
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert json.loads('{"__ansible_vault": "test_value"}', cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode('test_value')
    assert json.loads('{"__ansible_unsafe": "test_value"}', cls=AnsibleJSONDecoder) == wrap_var('test_value')

# Generated at 2022-06-20 22:58:25.403344
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
        import unittest
        import sys
        from ansible.module_utils._text import to_text

        class AnsibleJSONDecoderTest(unittest.TestCase):

            def test_array_constructor(self):

                class Foo(json.JSONDecoder): pass

                dec = Foo(object_hook=[])

                self.assertTrue(len(dec.object_hook) == 0)

            def test_str_constructor(self):

                class Foo(json.JSONDecoder): pass

                dec = Foo(object_hook='foo')

                self.assertTrue(dec.object_hook == 'foo')

            def test_callable_constructor(self):

                class Foo(json.JSONDecoder): pass

                def foo(pairs):
                    return pairs

                dec = Foo(object_hook=foo)


# Generated at 2022-06-20 22:58:25.955426
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 22:58:37.547992
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    secrets = """
    $ANSIBLE_VAULT;1.1;AES256
    30613764343962383561383064316138663534623136333965623764386561623362336130336265
    35303964626662363435663765313330633235353436653561653436613066396565346133633632
    36383863333436393166623763666932633935636639663137336133336561346139323662633665
    63386665653538336537626431316165653463333738386361323538306666623436383965663331
    3465
    """


# Generated at 2022-06-20 22:58:40.603695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    assert(str(AnsibleJSONDecoder.object_hook({
        '__ansible_vault': 'example'
        })) == "uansible-vault-example")

# Generated at 2022-06-20 22:58:46.454995
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ''' ansible.module_utils.common.json_dict '''
    json_text = json.dumps({'__ansible_unsafe': 'VARIABLE_NAME'})
    obj = AnsibleJSONDecoder.object_hook(json_text)
    assert obj == {'__ansible_unsafe': 'VARIABLE_NAME'}


# Generated at 2022-06-20 22:58:57.457865
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 22:59:06.539980
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "adfg", "__ansible_unsafe": "adfg"}'
    secrets = 'adfg'
    ansible_json_decoder = AnsibleJSONDecoder.set_secrets(secrets)
    ansible_json_decoder = AnsibleJSONDecoder()
    result = ansible_json_decoder.decode(json_str)
    assert isinstance(result, dict)
    assert result['__ansible_vault'] == secrets
    assert result['__ansible_unsafe'] == secrets

# Generated at 2022-06-20 22:59:12.940202
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = VaultLib.hash_password('password')
    json_string = '{"foo": "bar", "__ansible_vault": "' + secret + '", "__ansible_unsafe": { "name": "foo" } }'

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([secret])

    # This should work
    data = decoder.decode(json_string)

    # This should not work
    secret = VaultLib.hash_password('bad_password')
    decoder.set_secrets([secret])
    data = decoder.decode(json_string)

# Generated at 2022-06-20 22:59:24.754039
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['test_default'])
    decoder._vaults['other'] = VaultLib(secrets=['test_other'])


# Generated at 2022-06-20 22:59:35.980369
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_file = 'test_file'
    test_data = {
        '__ansible_vault': 'test_data',
        '__ansible_unsafe': '__ansible_unsafe'
    }

    with open(test_file, 'w') as f:
        f.write(json.dumps(test_data, cls=AnsibleJSONEncoder))

    with open(test_file, 'r') as f:
        decoded_data = json.load(f, cls=AnsibleJSONDecoder)

    assert isinstance(decoded_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded_data['__ansible_unsafe'], AnsibleUnsafeText)

# Generated at 2022-06-20 22:59:42.741605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    secret_data = {'test': 'secret'}

    # with __ansible_vault

# Generated at 2022-06-20 22:59:55.421333
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    pairs = decoder.object_hook({
        '__ansible_vault': 'test1',
        '__ansible_unsafe': 'test2',
        '__ansible_vault_id': 'test3',
        '__ansible_vault_secret': 'test4',
    })

    assert isinstance(pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert pairs['__ansible_vault'].vault.secrets == ['test4']
    assert pairs['__ansible_unsafe'] == 'test2'
    assert pairs['__ansible_vault_id'] == 'test3'
    assert pairs['__ansible_vault_secret'] == 'test4'

# Generated at 2022-06-20 23:00:00.590699
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ["test_secret"]

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    # No assertion, no exception means success!



# Generated at 2022-06-20 23:00:12.691954
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'ANSIBLE_MODULE_ARGS': {'foo': '$ANSIBLE_VAULT;1.2;AES256;my_secret_key\n63336331613261353132353936346363306163356237353062623839353531353837393137613566\n39663737633162323164353632626537353266343539343733636565663538336634333335623835\n613735393365373230386334333238313764\n', 'bar': 'value'}})

    # set up a test vault with a known key
    test_vault = VaultLib(secrets=['my_secret_key'])

# Generated at 2022-06-20 23:00:13.658314
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder, object)

# Generated at 2022-06-20 23:00:15.321281
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    dec = AnsibleJSONDecoder()
    assert dec.parse_string("[0]") == [0]

# Generated at 2022-06-20 23:00:25.417585
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test load string with vault
    secret = 'foo'
    data = '{"__ansible_vault": "bar"}'
    AnsibleJSONDecoder.set_secrets(secret)
    decoder = AnsibleJSONDecoder()
    # test load string with vault
    result = decoder.decode(data)
    assert result == {'__ansible_vault': 'bar'}

    # test load string with unsafe
    data = '{"__ansible_unsafe": "bar"}'
    result = decoder.decode(data)
    assert result == {'__ansible_unsafe': 'bar'}

# Generated at 2022-06-20 23:00:34.645732
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-20 23:00:47.036602
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(dict_type=dict)

# Generated at 2022-06-20 23:00:49.602563
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'secret'
    vault_secret = AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder._vaults['default'] == vault_secret

# Generated at 2022-06-20 23:00:56.463003
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoded_data = decoder.object_hook({'__ansible_vault': 'foo'})
    assert isinstance(decoded_data, AnsibleVaultEncryptedUnicode)
    assert decoded_data == 'foo'

    decoded_data = decoder.object_hook({'__ansible_unsafe': 'foo'})
    assert decoded_data == wrap_var('foo')



# Generated at 2022-06-20 23:01:06.156097
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class Item(object):
        def __init__(self, value):
            self.value = value

    # Empty dictionary
    obj = Item({})
    assert not isinstance(obj.value, AnsibleVaultEncryptedUnicode)

    # '__ansible_vault' not in dictionary
    obj = Item({'foo': 'bar'})
    assert not isinstance(obj.value, AnsibleVaultEncryptedUnicode)

    # '__ansible_vault' in dictionary
    obj = Item({'__ansible_vault': 'bar'})
    assert isinstance(obj.value, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:01:10.956745
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None


# Generated at 2022-06-20 23:01:14.250149
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "vault_value"}'
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'vault_value'}) == {'__ansible_vault': 'vault_value'}


# Generated at 2022-06-20 23:01:20.126696
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleUnsafeLoader

    AnsibleJSONDecoder.set_secrets([b'youllneverguess'])

# Generated at 2022-06-20 23:01:31.668668
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_test = '$ANSIBLE_VAULT;1.1;AES256\n333262626364363331333631613563383061376430653165643339356435623339663732613564\n383333336331613831336163386334643136326331653231633032333537313432376262666331\n373735633164333936383263626338\n'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets("mypassword")
    res = decoder.decode('{"__ansible_vault": "' + ansible_vault_test + '"}')
    assert res['__ansible_vault'] == ansible_vault_test

# Generated at 2022-06-20 23:01:33.037791
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    c = AnsibleJSONDecoder()

# Generated at 2022-06-20 23:01:44.156342
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()
    assert(json.loads('{"mystring": "string example", "myfloat": 3.42}', cls=AnsibleJSONDecoder) ==
           json.loads('{"mystring": "string example", "myfloat": 3.42}'))
    assert(json.loads('{"__ansible_vault": "' + 'A'*80 + '"}', cls=AnsibleJSONDecoder) ==
           json.loads('{"__ansible_vault": "' + 'A'*80 + '"}'))
    assert(json.loads('{"__ansible_unsafe": 1}', cls=AnsibleJSONDecoder) ==
           json.loads('{"__ansible_unsafe": 1}'))

# Generated at 2022-06-20 23:01:52.454788
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '{"__ansible_vault": "1234"}'
    decoded_json_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert isinstance(decoded_json_data, AnsibleVaultEncryptedUnicode)
    assert decoded_json_data == '1234'
    assert decoded_json_data.vault

    json_data = '{"__ansible_vault": "1234", "__ansible_unsafe": "test"}'
    decoded_json_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert isinstance(decoded_json_data, dict)
    assert decoded_json_data['__ansible_vault'] == "1234"
    assert decoded_json_data

# Generated at 2022-06-20 23:02:04.067138
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # json.loads loads str
    #
    # See: https://docs.python.org/2/library/json.html#json.loads
    #
    #
    # all the data types of the object_hook must be str because json.loads
    # doesn't accept bytes.
    #
    # See: https://docs.python.org/2/library/functions.html#json.loads

    # ensure that unset vaults (which is the expected behavior) will cause an error
    # as it should
    decoder = AnsibleJSONDecoder()
    raw = r'''{"__ansible_vault": "vault-txt-value"}'''
    try:
        decoder.decode(raw)
        assert False
    except ValueError as e:
        assert 'No vault secrets found' in str(e)

   

# Generated at 2022-06-20 23:02:15.292596
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = "secret"
    json_string = "{\"__ansible_vault\":\"$ANSIBLE_VAULT;ANSIBLE_VAULT_PASSWORD_ENV=VAULT_PASS;!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          306135666533356630626534663339613562396162333566663939366531613765303333333366\n          61336630616163313431376130633335346137336532323361615a396463323066343933393137\n          3233653333336463323432653536376238303732\"}"
    AnsibleJSONDecoder.set_secrets(secret)
    decoded_json = AnsibleJSONDecoder().decode(json_string)
   

# Generated at 2022-06-20 23:02:26.606771
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary vars directory and vault password file
    varsdir = os.path.join(tmpdir, 'vars')
    vault_password_file = os.path.join(varsdir, 'vault_password.txt')

    os.makedirs(varsdir)

    with open(vault_password_file, 'w') as f:
        f.write('secrets')

    # Create temporary vault file
    vault_file = os.path.join(tmpdir, 'vault.yml')

    with open(vault_file, 'w') as f:
        f.write('vault_var: !vault |\n')
        f.write

# Generated at 2022-06-20 23:02:31.538624
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-20 23:02:43.083312
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    simple_example = dict(a=1)
    decorated_example = dict(a=1, __ansible_vault='encrypted-string', __ansible_unsafe='unsafe-value')

    decoded = json.loads(json.dumps(decorated_example, cls=AnsibleJSONEncoder))
    assert decoded == simple_example
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['__ansible_unsafe'], wrap_var)

    decoded = json.loads(json.dumps(simple_example, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder)
    assert decoded == simple_example


# Generated at 2022-06-20 23:02:48.689467
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    data = {'__ansible_unsafe': '$ANSIBLE_VAULT;'}
    decoded = decoder.object_hook(data)
    assert isinstance(decoded, dict)
    assert isinstance(decoded['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-20 23:02:55.813606
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vul = VaultLib(secrets='abc123')
    AnsibleJSONDecoder.set_secrets(vul)
    ans_json = '{"__ansible_vault": "test"}'
    json_dump_ans_json = json.dumps(json.loads(ans_json), cls=AnsibleJSONEncoder)
    json_load_ans_json = json.loads(json_dump_ans_json, cls=AnsibleJSONDecoder)
    assert isinstance(json_load_ans_json, dict)

# Generated at 2022-06-20 23:02:57.664194
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder("{}")
    assert cls._vaults == {}

# Generated at 2022-06-20 23:03:05.226940
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['mysecrets']
    AnsibleJSONDecoder.set_secrets(secrets)
    data = {
        '__ansible_vault': 'test',
        '__ansible_unsafe': "I'm unsafe"
    }

    json_data = json.dumps(data, cls=AnsibleJSONEncoder)

    ansible_data = json.loads(json_data, cls=AnsibleJSONDecoder)

    assert ansible_data['__ansible_vault'] == data['__ansible_vault']
    assert ansible_data['__ansible_unsafe'] == data['__ansible_unsafe']

# Generated at 2022-06-20 23:03:09.875100
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # no constructor args
    dec = AnsibleJSONDecoder()
    assert dec._vaults == {}

    # TODO
    # vault data
    # dec = AnsibleJSONDecoder()
    # assert dec._vaults == {}

# Generated at 2022-06-20 23:03:18.413944
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['mysecret']
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-20 23:03:19.496010
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()

# Generated at 2022-06-20 23:03:31.765326
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test object hook with Vault object
    # Use Vault object from Ansible
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-20 23:03:49.511385
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test case: __ansible_vault
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'aGVsbG93b3JsZA==\n'}) == AnsibleVaultEncryptedUnicode('aGVsbG93b3JsZA==\n')
    assert AnsibleVaultEncryptedUnicode('aGVsbG93b3JsZA==\n') != 'aGVsbG93b3JsZA==\n'
    # Test case: __ansible_unsafe
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'hello world'}) == wrap_var('hello world')

# Generated at 2022-06-20 23:03:54.770866
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    _vaults = {}
    secrets = [['default']]
    _vaults['default'] = VaultLib(secrets=secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    assert decoder.object_hook == decoder.object_hook
    decoder.object_hook(pairs={'__ansible_vault': 'sdadad'})
    decoder.object_hook(pairs={'__ansible_unsafe': 'asdafa'})



# Generated at 2022-06-20 23:04:05.581823
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    d = {'__ansible_vault': 'foo'}
    e = json.dumps(d, cls=AnsibleJSONEncoder)
    obj = json.loads(e, cls=AnsibleJSONDecoder)
    assert obj['__ansible_vault'] == d['__ansible_vault']
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_vault'].vault, VaultLib)

    d = {'__ansible_unsafe': 'foo'}

# Generated at 2022-06-20 23:04:12.671794
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "value", "__ansible_unsafe": "value"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_obj['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:04:13.863965
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder

# Generated at 2022-06-20 23:04:20.332806
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():  # pylint: disable=redefined-outer-name

    class FakeVaultLib:
        def __init__(self):
            self.secrets = ["foo"]

    secrets = ["bar"]
    vault = FakeVaultLib()
    obj = AnsibleJSONDecoder(object_hook=vault.object_hook, secrets=secrets)
    obj.set_secrets(secrets)
    assert obj._vaults["default"].secrets == secrets

# Generated at 2022-06-20 23:04:30.552895
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('test')
    assert 'test' == ansible_vault_encrypted_unicode.vaulted_data

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('test', vault='test_vault')
    assert 'test' == ansible_vault_encrypted_unicode.vaulted_data
    assert 'test_vault' == ansible_vault_encrypted_unicode.vault

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('test', vault='test_vault', version='test_version')
    assert 'test' == ansible_vault_encrypted_unicode.vaulted_data
    assert 'test_vault' == ansible_

# Generated at 2022-06-20 23:04:34.612468
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['password']
    AnsibleJSONDecoder.set_secrets(secrets)
    try:
        decoder = AnsibleJSONDecoder()
    except:
        assert False, 'Test to create object of class AnsibleJSONDecoder failed'
    assert True



# Generated at 2022-06-20 23:04:38.408087
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text = '''
    {
        "__ansible_vault": "some text",
        "__ansible_unsafe": "12345"
    }
    '''

    import pdb; pdb.set_trace()
    json.loads(json_text, cls=AnsibleJSONDecoder, strict=False)

# Generated at 2022-06-20 23:04:44.413035
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    decoded_json = decoder.decode('{"__ansible_vault": "encrypted string"}')
    assert isinstance(decoded_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    decoder.set_secrets(["secret"])
    decoded_json = decoder.decode('{"__ansible_vault": "AQDTC4X++urQkQ==\n"}')
    assert decoded_json['__ansible_vault'] == "password"

# Generated at 2022-06-20 23:05:17.139498
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible-config is using the AnsibleJSONEncoder to encode the data and the
    # AnsibleJSONDecoder to decode the data. Only accept the same data as the
    # Encoder will produce.
    #
    # Tests for unsafe_proxy and vault encrypted values

    # Create two VaultLib instances for testing
    v1 = VaultLib(secrets=['secret1'])
    v2 = VaultLib(secrets=['secret2'])

    # Create data for testing the decoder method object_hook

# Generated at 2022-06-20 23:05:18.846602
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_passwd = "hunter2"
    AnsibleJSONDecoder.set_secrets([vault_passwd])

# Generated at 2022-06-20 23:05:25.987608
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test AnsibleVaultEncryptedUnicode
    obj = json.loads('{"__ansible_vault": "dGVzdA=="}', cls=AnsibleJSONDecoder)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault is None
    assert obj == "test"

    obj = json.loads('{"__ansible_vault": "dGVzdA=="}', cls=AnsibleJSONDecoder)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault is None
    assert obj == "test"

    # test wrap_var
    obj = json.loads('{"__ansible_unsafe": "dGVzdA=="}', cls=AnsibleJSONDecoder)

# Generated at 2022-06-20 23:05:33.373770
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    raw_json = '{"key": "value", "__ansible_vault": "vault_value"}'
    secrets = ["secret1", "secret2"]
    expected_result = {"key": "value", "__ansible_vault": "vault_value"}
    # Act
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    result = decoder.decode(raw_json)
    # Assert
    assert result == expected_result


# Generated at 2022-06-20 23:05:42.688829
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'mysecret'
    encoded = '$ANSIBLE_VAULT;1.1;AES256\n3335303636656164633435316563353437323334353733383766653137393265633833663932\n3737363332306231376363326237613735616435336566653566613833620a3938366433303436\n6564666261346338376162383466656435663964386262656265363036613765336436393234\n393363376165316537326562353533393537386638\n'

    decoded = AnsibleJSONDecoder.decode(encoded)
    assert decoded['__ansible_vault'] == encoded

    AnsibleJSONDecoder.set

# Generated at 2022-06-20 23:05:51.972697
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestVault:
        pass
    vault = TestVault()
    vault.decrypt = lambda txt: '123'
    vault.decrypt_unlocked = lambda txt: '123'
    vault.is_encrypted_data = lambda txt: False
    vault.patched_vault_secret = 'secret'

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    # Test that encrypted string from vault is parsed
    text = '{"__ansible_vault": "AAAAAQ"}'
    decoder._vaults['default'] = vault
    json_text = decoder.decode(text)
    assert json_text['__ansible_vault'] == '123'

    # Test that encrypted string without vault is parsed as AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:05:55.480076
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Constructor of class AnsibleJSONDecoder shall not fail
    test_json_decoder = AnsibleJSONDecoder()
    assert type(test_json_decoder) is AnsibleJSONDecoder


# Generated at 2022-06-20 23:05:59.510626
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_text = '{"__ansible_vault": "abc"}'
    secrets = ['123']
    AnsibleJSONDecoder.set_secrets(secrets)
    result = AnsibleJSONDecoder().decode(json_text)
    assert isinstance(result, dict)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)