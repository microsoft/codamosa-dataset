

# Generated at 2022-06-11 08:28:38.231353
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:28:48.434583
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json_data = [('{"__ansible_vault": "1234", "argument": "value"}',
                       'Vault variables are replaced with AnsibleVaultEncryptedUnicode objects'),
                      ('{"__ansible_unsafe": "1234", "argument": "value"}',
                       'Unsafe variables are replaced with _AnsibleUnsafeText objects'),
                      ('{"__nothing": "1234", "argument": "value"}',
                       'Normal variables are not replaced')]
    for (input_data, message) in test_json_data:
        hook = AnsibleJSONDecoder.object_hook(json.loads(input_data))

        # Test if hook is the correct type
        assert isinstance(hook, dict), message


# Generated at 2022-06-11 08:28:55.661932
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for strings
    raw_str = '{"str": "Hello", "foo": "Bar", "bar": "Foo"}'
    str_decoded = '{"str": "Hello", "foo": "Bar", "bar": "Foo"}'
    decoded_str = json.dumps(json.loads(raw_str, cls=AnsibleJSONDecoder), cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    assert decoded_str == str_decoded

    # Test for vault encrypted strings

# Generated at 2022-06-11 08:29:02.543433
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_bytes
    secrets = 'foobar'.encode('utf-8')
    vault = VaultLib(secrets=[secrets])
    vault_str = '$ANSIBLE_VAULT;1.1;AES256\n'.encode('utf-8') + vault.encrypt(to_bytes('foo: bar', errors='surrogate_or_strict'))
    AnsibleJSONDecoder.set_secrets(secrets)
    val = json.loads(vault_str, cls=AnsibleJSONDecoder)
    assert val == 'foo: bar'

# Generated at 2022-06-11 08:29:08.438425
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault = {'test': 'vaulted secret'}
    vault_str = json.dumps(vault)
    vault_ansible_str = json.dumps({'__ansible_vault': vault_str})
    decoded = json.loads(vault_ansible_str, cls=AnsibleJSONDecoder)
    assert str(decoded) == vault_str

# Generated at 2022-06-11 08:29:17.738740
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO: remove this test when we have a test suit
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib()

    # Test: simple
    pairs = {'__ansible_vault': "-----BEGIN ENCRYPTED VALUE-----\njXIuagcQq3qAhl3bJIpRDw==\n-----END ENCRYPTED VALUE-----"}
    obj = decoder.object_hook(pairs)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault == decoder._vaults['default']

# Generated at 2022-06-11 08:29:29.135465
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = []
    secrets.append(dict(id='test_decoder_vault1', password='TestVault1'))
    secrets.append(dict(id='test_decoder_vault2', password='TestVault2'))

    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-11 08:29:38.894283
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_input = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256", "__ansible_unsafe": "ANSIBLE_UNSAFE"}'
    json_output = '{"__ansible_vault": "Vaulted!", "__ansible_unsafe": "Unsafe!"}'

    output = AnsibleJSONDecoder(json_input)
    # Check that AnsibleVaultEncryptedUnicode and unsafe proxy objects are created
    assert isinstance(json.loads(json_input, cls=AnsibleJSONDecoder), dict)
    # Check that AnsibleJSONEncoder encodes AnsibleVaultEncryptedUnicode and unsafe proxy objects

# Generated at 2022-06-11 08:29:48.243452
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '12345678901234567890abcdef'
    ansible_secrets = {"default": secret}
    AnsibleJSONDecoder.set_secrets(ansible_secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:29:59.598173
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{'id': 'aaaa-bbbb-cccc-dddd', 'secret': 'password'}]
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:30:09.231897
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Given
    import json
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes

    secret = to_bytes('This is a test')
    vault = VaultLib(secrets=[secret, 'foo'])
    vault_password_file = to_unicode('foo.txt')

# Generated at 2022-06-11 08:30:19.496723
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    class AnsibleJSONDecoder_object_hook(unittest.TestCase):
        def test__ansible_vault(self):
            enc = AnsibleJSONEncoder()
            dec = AnsibleJSONDecoder()
            enc_json = enc.encode({"__ansible_vault": "test"})
            dec_json = dec.decode(enc_json)
            self.assertIsInstance(dec_json, AnsibleVaultEncryptedUnicode)

        def test__ansible_unsafe(self):
            enc = AnsibleJSONEncoder()
            dec = AnsibleJSONDecoder()
            enc_json = enc.encode({"__ansible_unsafe": "test"})
            dec_json = dec.decode(enc_json)

# Generated at 2022-06-11 08:30:30.507149
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    src_data = {'example_field': '$ANSIBLE_VAULT;1.1;AES256;ansib\nle\n67989f81208fe9b41488fd2cb5c0f56dac50e887cdb82a5a5e5cf5ec5b9c786a\n351653738061480d8b27c17b3503a6f3c6e859fb7888c9f48289e7c25366c1a6\n'}

# Generated at 2022-06-11 08:30:37.710929
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Tests on Ansible's vault
    obj = json.loads('{"__ansible_vault": "test"}', cls=AnsibleJSONDecoder, parse_float=None, parse_int=None, parse_constant=None, object_pairs_hook=None)
    assert obj.__class__.__name__ == 'AnsibleVaultEncryptedUnicode'
    assert obj == 'AES256$9e15de8a46cc4bcb80d04b47e98057bc$f8d6b58e65b5fa5ae5f619b2e2277a1d5a7b5ba19b856ae3eba6f40a734c6623'

    # Tests on ansible's vault without password

# Generated at 2022-06-11 08:30:48.957637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as AnsibleVaultEnc
    from ansible.module_utils._text import to_text
    from ansible.utils.unsafe_proxy import ANSIBLE_KEEP_REMOTE_FILES

    # Set Secrets before the test
    secrets = ['abcd']
    AnsibleJSONDecoder.set_secrets(secrets)

    assert AnsibleJSONDecoder._vaults['default'] is not None
    decoder = AnsibleJSONDecoder(object_pairs_hook=AnsibleJSONEncoder.dict_to_ordereddict)
    # Test case 1:
    #   - pairs contains __ansible_vault
    #   - value is not unicode

# Generated at 2022-06-11 08:31:00.943187
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    def test_object_hook(pairs):
        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                value = AnsibleVaultEncryptedUnicode(value)
                if self._vaults:
                    value.vault = self._vaults['default']
                return value
            elif key == '__ansible_unsafe':
                return wrap_var(value)

        return pairs

    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 08:31:11.060941
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    from ansible.parsing.vault import VaultEditor

    class TestCase(unittest.TestCase):
        def setUp(self):
            ''' Unit test for AnsibleJSONDecoder object hook'''
            #test data

# Generated at 2022-06-11 08:31:16.797296
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoded = decoder.object_hook({'__ansible_vault': 'vault_value'})
    assert decoded == AnsibleVaultEncryptedUnicode('vault_value')
    decoded = decoder.object_hook({'__ansible_unsafe': 'unsafe_value'})
    assert decoded == wrap_var('unsafe_value')

# Generated at 2022-06-11 08:31:27.511713
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # given
    ansible_vault = {
        "__ansible_vault": "value"
    }

    ansible_unsafe = {
        "__ansible_unsafe": "value"
    }

    # when
    ansible_vault_result = AnsibleJSONDecoder().object_hook(ansible_vault)
    ansible_unsafe_result = AnsibleJSONDecoder().object_hook(ansible_unsafe)

    # then
    assert(isinstance(ansible_vault_result, AnsibleVaultEncryptedUnicode))
    assert(ansible_vault_result.startswith("$ANSIBLE_VAULT;"))

    assert(isinstance(ansible_unsafe_result, AnsibleUnsafeText))

# Generated at 2022-06-11 08:31:37.893229
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import six

    # Create a secret

# Generated at 2022-06-11 08:31:47.278662
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = "test"
    string_to_encrypt = "foobar"
    secret1 = "test1"
    string_to_encrypt1 = "foobar1"
    json_data = json.dumps({'__ansible_vault': string_to_encrypt, '__ansible_unsafe': string_to_encrypt1}, cls=AnsibleJSONEncoder)
    print("json_data: " + json_data)
    AnsibleJSONDecoder.set_secrets(secret)
    AnsibleJSONDecoder._vaults['default'].secrets.append(secret1)
    json_data_decoded = json.loads(json_data, cls=AnsibleJSONDecoder)
    decrypted_string = json_data_decoded['__ansible_vault'].vault.dec

# Generated at 2022-06-11 08:31:57.956478
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Unit test for method object_hook of class AnsibleJSONDecoder
    """
    data = {
        "__ansible_unsafe": "value",
        "__ansible_vault": "value"
    }
    result = json.loads(json.dumps(data), cls=AnsibleJSONDecoder)
    assert result['__ansible_vault'] == 'value'
    assert result['__ansible_unsafe'] == 'value'

    secrets = ['test']
    json.loads(json.dumps(data), cls=AnsibleJSONDecoder.set_secrets(secrets))
    vault = getattr(result['__ansible_vault'], 'vault')
    assert vault.secrets[0] == 'test'

# Generated at 2022-06-11 08:32:05.457679
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:12.698346
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    object_hook_result = decoder.object_hook({"__ansible_vault": "hello world", "__ansible_unsafe": "hello world"})
    assert isinstance(object_hook_result, dict)
    assert "__ansible_vault" in object_hook_result
    assert isinstance(object_hook_result["__ansible_vault"], AnsibleVaultEncryptedUnicode)
    assert "__ansible_unsafe" in object_hook_result
    assert isinstance(object_hook_result["__ansible_unsafe"], unicode)

# Generated at 2022-06-11 08:32:16.364390
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '[{"__ansible_vault": "AQAXj7YaZ1F+V9eJtQrzV7Msj+n56lJm/meGGGw=="}]'
    secrets = ['secret']
    actual_result = json.loads(data, cls=AnsibleJSONDecoder, secrets=secrets)
    assert actual_result[0].obj_type is AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 08:32:24.918180
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'PASSWORD']
    secrets_no_vault = [b'NON_ENCRYPTED']
    secrets_no_vault_ok = [b'OK']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test encrypted variable

# Generated at 2022-06-11 08:32:35.608145
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:32:47.527319
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:51.712556
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils.six import PY3
    if PY3:
        unicode = str

    # Init secret

# Generated at 2022-06-11 08:33:02.316778
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secret = 'foo'
    decoder.set_secrets(secret)

    # testing encrypted var
    data = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.2;AES256;ansible_test\nasdfasdfasdfasdf\n'}
    result = decoder.object_hook(data)
    assert result['__ansible_vault'].vault == decoder._vaults['default']
    assert result['__ansible_vault'].vault._secrets[0] == secret

    # testing unsafe var
    data = {u'__ansible_unsafe': u"{{ '{' }}" }
    result = decoder.object_hook(data)
    assert result['__ansible_unsafe'] == u

# Generated at 2022-06-11 08:33:13.164932
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    vault_id = "junk_vault_id"
    secret = "junk_secret"
    secret_string = "junk_secret_string"
    encrypted_string = AnsibleJSONEncoder.encrypt(secret_string, vault_id, [secret])
    v = encoder.vaults.get(vault_id)
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([secret])

    # Test for encrypted data
    for s in v.secrets:
        v.secrets.remove(s)
    v.secrets.append(secret)
    assert(secret_string == decoder.decode(encoded_string)['__ansible_vault'])

# Generated at 2022-06-11 08:33:24.168087
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults = {
        'default': VaultLib(secrets=['test_password'])
    }


# Generated at 2022-06-11 08:33:29.173734
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {
        '__ansible_vault': 'ansible',
        '__ansible_unsafe': 'ansible'
    }

    json_obj = json.dumps(obj, cls=AnsibleJSONEncoder)

    result = AnsibleJSONDecoder().decode(json_obj)

    assert result == obj

# Generated at 2022-06-11 08:33:39.817108
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    def _assert(pairs, expected):
        decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
        value = decoder.object_hook(pairs)
        assert value == expected

    # test __ansible_vault

# Generated at 2022-06-11 08:33:50.498528
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestVault(object):
        @staticmethod
        def load_vault_data(data):
            return 'data'

        def decrypt(self, data):
            return 'decrypted'

    vault = TestVault()

    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = vault

    d1 = {'__ansible_vault': 'data'}
    d2 = decoder.object_hook(d1)
    assert d2['__ansible_vault'] == 'decrypted'

    d3 = {'__ansible_unsafe': 'data'}
    d4 = decoder.object_hook(d3)
    assert d4['__ansible_unsafe'] == 'data'
    assert d4['__ansible_unsafe'].__class__.__name

# Generated at 2022-06-11 08:34:00.952615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import base64
    import sys

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    secrets = [base64.b64encode('test_vault_pass')]
    AnsibleJSONDecoder.set_secrets(secrets)

    # encrypted values
    s = StringIO('''{"__ansible_vault": "''' + base64.b64encode('Hello World').decode('utf-8') + '''"}''')
    result = json.load(s, cls=AnsibleJSONDecoder)

    assert result == AnsibleVaultEncryptedUnicode(base64.b64encode('Hello World').decode('utf-8'))
    value = result.get_decrypted_text()
    assert value

# Generated at 2022-06-11 08:34:05.549343
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    raw = dict(__ansible_vault='VaultLib', __ansible_unsafe='unsafe')
    value = AnsibleJSONDecoder(raw)
    assert value['__ansible_vault'].get_decrypted_text() == 'VaultLib'
    assert value['__ansible_unsafe'] == 'unsafe'

# Generated at 2022-06-11 08:34:14.706781
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # case 1: Vault Key
    test_dict = {"key1": "value1", "key2": "value2", "key3": "value3", "__ansible_vault": "value4"}
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(json.dumps(test_dict))["__ansible_vault"] == test_dict["__ansible_vault"]

    # case 2: Unsafe Key
    test_dict = {"key1": "value1", "key2": "value2", "key3": "value3", "__ansible_unsafe": "value4"}

# Generated at 2022-06-11 08:34:23.259197
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert len(AnsibleJSONDecoder._vaults) == 0
    secrets = ['secret1', 'secret2', 'secret3']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:34:29.497836
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {
      "__ansible_vault": "toto",
      "__ansible_unsafe": "titi"
    }
    decoded = AnsibleJSONDecoder().object_hook(data)

    assert(isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(decoded['__ansible_vault'].vault is None)
    assert(decoded['__ansible_unsafe'] == wrap_var('titi'))

# Generated at 2022-06-11 08:34:44.625588
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:48.064026
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    obj = AnsibleJSONDecoder().object_hook({'__ansible_unsafe': 'foo'})
    assert obj == wrap_var('foo')

    obj = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'foo'})
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.data == 'foo'


if __name__ == '__main__':
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-11 08:34:55.256159
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # test for vault
    obj_vault = decoder.object_hook({'__ansible_vault': '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          333331392c6531396639313932643265346530323737313635633433613338636564323332313863\n          66366332380a61386164326463316361653731633136613231346238633661363136623964373863\n          386437636362620a3134373861613139656231376166626235343736383362383161353635313336\n          37656636346130\n          '})
    assert obj_vault

# Generated at 2022-06-11 08:35:06.044315
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    enc = AnsibleJSONEncoder()
    class vault:
        def decrypt(self, string):
            return string

    # Test for AnsibleVaultEncryptedUnicode
    d = AnsibleJSONDecoder()
    d._vaults = {'default': vault()}
    decoded = d.decode(enc.encode(AnsibleVaultEncryptedUnicode('foo')))
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded, str)
    assert decoded == 'foo'

    # Test for unsafe variable
    d = AnsibleJSONDecoder()
    decoded = d.decode(enc.encode(wrap_var({'foo': 'bar'})))
    assert decoded['foo'] == 'bar'

# Generated at 2022-06-11 08:35:09.603425
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '{"__ansible_unsafe": "abc"}'
    test_decoder = AnsibleJSONDecoder()
    result = test_decoder.decode(data)
    assert result == wrap_var("abc")


# Generated at 2022-06-11 08:35:18.695608
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'password'
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault':'$ANSIBLE_VAULT;1.2;AES256;default;dummy\n6162636465666768696a6b6c6d6e6f707172737475767778797a0a\n'}
    result = decoder.object_hook(pairs)

    assert(result.vault == decoder._vaults['default'])
    assert(str(result) == 'abcdefghijklmnopqrstuvwxyz')

# Generated at 2022-06-11 08:35:30.241963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {
        "__ansible_unsafe": "abc",
        "__ansible_vault": "def"
    }
    # test AnsibleJSONDecoder.object_hook()
    decoded = AnsibleJSONDecoder().object_hook(test_data)
    assert isinstance(decoded['__ansible_unsafe'], str)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # test AnsibleJSONDecoder.set_secrets()
    AnsibleJSONDecoder.set_secrets({"__ansible_vault": "abc"})
    decoded = AnsibleJSONDecoder().object_hook(test_data)
    assert isinstance(decoded['__ansible_vault'].vault, VaultLib)
    #

# Generated at 2022-06-11 08:35:35.738058
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "plaintext", "__ansible_unsafe": "plaintext"}
    pairs = decoder.object_hook(pairs)
    assert (isinstance(pairs["__ansible_vault"], AnsibleVaultEncryptedUnicode))
    assert (isinstance(pairs["__ansible_unsafe"], AnsibleVaultEncryptedUnicode))

# Generated at 2022-06-11 08:35:43.747506
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:56.544473
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:14.129874
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    cases = [
        ({"__ansible_vault": "vault"}, AnsibleVaultEncryptedUnicode("vault")),
        ({"__ansible_unsafe": "unsafe"}, wrap_var("unsafe")),
        ({"__ansible_vault": "vault", "__ansible_unsafe": "unsafe"}, {"__ansible_vault": "vault", "__ansible_unsafe": "unsafe"}),
        ({"test": "test"}, {"test": "test"})
    ]

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets("test")

    for (test_case, expected) in cases:
        assert decoder.object_hook(test_case) == expected

# Generated at 2022-06-11 08:36:22.284148
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()

    # Test vault
    decoder.set_secrets(['secrets'])
    value = 'my_password'
    value_encoded = encoder.encode({'__ansible_vault': value})
    value_decoded = decoder.decode(value_encoded)
    assert isinstance(value_decoded, AnsibleVaultEncryptedUnicode)
    assert value_decoded == value

    # Test unsafe
    value = """
    ---
    - hosts: localhost
      tasks:
      - name: test a jinja2 template
        template:
          src: "{{ lookup('file', '{{ foo }}') }}"
          dest: /tmp/test
    """

# Generated at 2022-06-11 08:36:30.666389
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """ Tests if method object_hook returns a message with right attributes """
    decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_vault': 'vault_text',
        '__ansible_unsafe': 'unsafe_text',
    }

    obj = decoder.object_hook(pairs)

    assert obj.__class__.__name__ == 'AnsibleVaultEncryptedUnicode'
    assert obj == 'vault_text'
    assert obj.vault == None

    assert pairs['__ansible_unsafe'] == 'unsafe_text'



# Generated at 2022-06-11 08:36:39.311334
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Unit test for method object_hook of class AnsibleJSONDecoder"""
    obj = AnsibleJSONDecoder()
    assert obj._vaults == {}
    pairs = {'__ansible_vault': "test", '__ansible_unsafe': "test1"}
    result = obj.object_hook(pairs)
    assert result['__ansible_vault'] == "test"
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_unsafe'] == "test1"
    assert isinstance(result['__ansible_unsafe'], str)



# Generated at 2022-06-11 08:36:49.688639
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:59.635276
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_one = b'$ANSIBLE_VAULT;1.1;AES256\n6136356633653061633764396237613761316363613137646330656435393464383266396431666\n3936663537343636613646373862626165343837336565393132303733653534656637636363138\n653536383038\n'

# Generated at 2022-06-11 08:37:08.387356
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = json.loads('''{
        "key1": {
            "key2": {
                "__ansible_vault": "my_vault_encoded_content",
                "sub_key": {
                    "sub_sub_key": {
                        "__ansible_unsafe": "my_unsafe_encoded_content"
                    }
                }
            }
        }
    }''', cls=AnsibleJSONDecoder)

    assert type(data['key1']['key2']) == AnsibleVaultEncryptedUnicode
    assert type(data['key1']['key2']['sub_key']['sub_sub_key']) == wrap_var


# Generated at 2022-06-11 08:37:19.089292
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class VaultLibMock:

        def __init__(self, secrets):
            pass

    secrets = ['password']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert len(AnsibleJSONDecoder._vaults) > 0

    json_string = r'''{
        "__ansible_unsafe": {
            "type": "str",
            "value": "{{password}}"
        },
        "__ansible_vault": {
            "type": "str",
            "value": "password",
            "ciphertext": "{{vault_password}}"
        }
    }'''

    pairs = json.loads(json_string, cls=AnsibleJSONDecoder)
    for key in pairs:
        value = pairs[key]


# Generated at 2022-06-11 08:37:26.800097
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['top_secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    data = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible\n393061653239643033386232373863346465653831613532343135313163386262623363353334\n393930366537353466373033663561316437343039626438336130323335396435623831383636\n6532393034663835\n"}'

# Generated at 2022-06-11 08:37:36.692687
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Vault
    pairs = {
        '__ansible_vault': 'vault_value',
    }
    value = decoder.object_hook(pairs)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value == 'vault_value'
    assert value.vault is None
    assert value.vault is not decoder._vaults.get('default')

    # Unsafe
    pairs = {
        '__ansible_unsafe': True,
    }
    value = decoder.object_hook(pairs)
    assert value == {"__ansible_unsafe": True}
    assert value.get('__ansible_unsafe') is True

    # Unhandled

# Generated at 2022-06-11 08:38:03.535493
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    text = """{
        "a": "example",
        "__ansible_vault": "example_vault",
        "__ansible_unsafe": "example_unsafe"
    }
    """

    ansiblejson_decoder = AnsibleJSONDecoder()
    obj = json.loads(text, cls=ansiblejson_decoder)
    assert obj['a'] == 'example'
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert obj['__ansible_vault'].vault is None
    assert obj['__ansible_unsafe'] == 'example_unsafe'

    ansiblejson_decoder.set_secrets(['test_secret'])
    obj = json.loads(text, cls=ansiblejson_decoder)

# Generated at 2022-06-11 08:38:09.442765
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ["634e14b1-af40-40a5-ad8a-c2948a75f06b"]
    x = AnsibleJSONDecoder.set_secrets(secrets)
    with open( 'file_content.txt', 'r' ) as myFile:
        for line in myFile:
            d = json.loads(line, cls=AnsibleJSONDecoder)
            print(d)


# Generated at 2022-06-11 08:38:17.482656
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:38:28.112752
# Unit test for method object_hook of class AnsibleJSONDecoder