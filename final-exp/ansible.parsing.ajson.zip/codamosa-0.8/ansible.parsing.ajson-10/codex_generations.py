

# Generated at 2022-06-11 08:28:37.105771
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_str = '$ANSIBLE_VAULT;1.1;AES256'
    secrets = ['supersecretpass0123456789', 'supersecretpass9876543210']
    vault = VaultLib(secrets=secrets)

# Generated at 2022-06-11 08:28:40.700116
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': '1234'}) == \
        AnsibleVaultEncryptedUnicode('1234')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': '1234'}) == \
        wrap_var('1234')



# Generated at 2022-06-11 08:28:49.664262
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault':'test_vault'}) == AnsibleVaultEncryptedUnicode('test_vault')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe':'test_unsafe'}) == wrap_var('test_unsafe')
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault':'test_vault', '__ansible_unsafe':'test_unsafe','test':'test_value'}) == {'__ansible_vault':'test_vault', '__ansible_unsafe':'test_unsafe','test':'test_value'}

# Generated at 2022-06-11 08:28:52.683907
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    answer = {}
    answer['__ansible_vault'] = 'test'
    answer['__ansible_unsafe'] = 'test'

    decoder = AnsibleJSONDecoder()
    decoded_answer = decoder.object_hook(answer)
    print(decoded_answer.__dict__)

# Generated at 2022-06-11 08:28:54.905448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    item = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'this string is unsafe'})
    print(item)

if __name__ == '__main__':
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-11 08:29:04.132099
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test1', 'test2']

    class TestClass(object):
        def __init__(self):
            self.secrets = secrets

        def __getattr__(self, name):
            return self.secrets

    vault_str = '$ANSIBLE_VAULT;1.2;AES256;default\n6666666666666666666666666666666666666666666666666666666666666666\n6666666666666666666666666666666666666666666666666666666666666666\n6666666666666666666666666666666666666666666666666666666666666666\n6666666666666666666666666666666666666666666666666666666666666666\n66666666666666666666666666666666666666666666\n'
    vault_dict_1 = dict(__ansible_vault=vault_str,
                        __ansible_vault_password=secrets[0],
                        __ansible_vault_identity=secrets[0])

# Generated at 2022-06-11 08:29:14.193643
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    obj = decoder.object_hook({'key1': 'value1', 'key2': 'value2'})
    assert(obj == {'key1': 'value1', 'key2': 'value2'})

    obj = decoder.object_hook({'__ansible_vault': 'value1', 'key2': 'value2'})
    assert(isinstance(obj, AnsibleVaultEncryptedUnicode))
    assert(obj == 'value1')
    assert(obj.vault is None)

    obj = decoder.object_hook({'__ansible_unsafe': 'value1', 'key2': 'value2'})
    assert(obj == wrap_var('value1'))

# Generated at 2022-06-11 08:29:20.662289
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test that AnsibleVaultEncryptedUnicode is returned
    # when __ansible_vault is in pairs.
    pairs = {}
    pairs['__ansible_vault'] = 'somestring'
    AnsibleJSONEncoder.set_secrets({'password': None})
    decoder = AnsibleJSONDecoder()
    pairs = decoder.object_hook(pairs)
    assert type(pairs[-1]) == AnsibleVaultEncryptedUnicode

    # Test that wrap_var is returned
    # when __ansible_unsafe is in pairs.
    pairs = {}
    pairs['__ansible_unsafe'] = 'somestring'
    decoder = AnsibleJSONDecoder()
    pairs = decoder.object_hook(pairs)

# Generated at 2022-06-11 08:29:32.044999
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class FakeVaultLib(object):
        def __init__(self, param):
            self.secret = param

    class FakeAnsibleJSONEncoder(object):
        @staticmethod
        def encode(d, **kwargs):
            return d

    # test with vault
    test_vault = FakeVaultLib('dummy')
    AnsibleJSONDecoder._vaults['default'] = test_vault

# Generated at 2022-06-11 08:29:40.319199
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # class attributes initialization
    _vaults = {'default': True}
    vault_lib = VaultLib(secrets='ansible')

    # instance of class AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()

    # test into AnsibleJSONDecoder.object_hook with key == '__ansible_vault'
    assert decoder.object_hook({'__ansible_vault': 'some value'}) == \
           AnsibleVaultEncryptedUnicode('some value')

    # test into AnsibleJSONDecoder.object_hook with key == '__ansible_unsafe'
    assert decoder.object_hook({'__ansible_unsafe': 'some value'}) == \
           wrap_var('some value')

    # test attributes of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:45.538172
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault':'value1','__ansible_unsafe':'value2','other':'value3'}) == {'__ansible_vault':'value1','__ansible_unsafe':'value2','other':'value3'}

# Generated at 2022-06-11 08:29:56.266608
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    def get_object_hook(pairs):
        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                value = AnsibleVaultEncryptedUnicode(value)
                if self._vaults:
                    value.vault = self._vaults['default']
                return value
            elif key == '__ansible_unsafe':
                return wrap_var(value)

        return pairs

    # Test case with __ansible_vault
    json_obj = {u'__ansible_vault': u'1234567890' }
    AnsibleJSONDecoder._vaults = {}
    assert(get_object_hook(json_obj) == json_obj)
    # Test case with __ansible_unsafe

# Generated at 2022-06-11 08:30:06.655888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import yaml
    SECRET = os.getenv('ANSIBLE_VAULT_PASSWORD_FILE', '')
    SECRET = open(SECRET).read()
    data_str = '{"__ansible_vault": "U2FsdGVkX18f6JHx6e8U6Wnk+YsVmPmGv/8VnWq+3q7eBJxTvQ8VdWyHBXQ+I/Nyzdv1eVfeWZozj/wFn1BWxogJ8tbWtI2A", "__ansible_unsafe": {"__ansible_unsafe_new_var": "blabla"}}'
    AnsibleJSONDecoder.set_secrets(SECRET)

# Generated at 2022-06-11 08:30:16.849849
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import io
    if sys.version_info[0] >= 3:
        univ_type = str
        byte_type = bytes
    else:
        univ_type = unicode
        byte_type = str


# Generated at 2022-06-11 08:30:23.956484
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'VAULTED', '__ansible_unsafe': 'UNSAFE'})
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert obj['__ansible_vault'] == 'VAULTED'
    assert obj['__ansible_vault'].vault is None
    assert obj['__ansible_unsafe'].value == 'UNSAFE'



# Generated at 2022-06-11 08:30:33.944464
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    # test vault object
    vault = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.2;AES256;acme\n3432423542324fdfgfdgfdgfdgfdgfdgfdgfdgfdsafdfdfdfdfd")
    vault.vault = VaultLib(secrets=['secret'])
    pairs = {'__ansible_vault': str(vault)}
    decoded = decoder.object_hook(pairs)
    assert decoded['__ansible_vault'] == vault

    pairs = {'__ansible_vault': {'__ansible_vault': str(vault)}}
    decoded = decoder.object_hook(pairs)

# Generated at 2022-06-11 08:30:44.792974
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:53.814488
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml import load
    from ansible.parsing.vault import VaultEditor

    TEST_VAULT = VaultEditor({})
    TEST_STRING = '$ANSIBLE_VAULT;1.1;AES256\n3435643765653539306664376533373363353564393737643832306137313761313330353730383931610a343661333138633665616263356536346231656234666130346436306464393835636164386634650a35646539376430373565633937666538343336373665643137653664653738303366376537386330'

# Generated at 2022-06-11 08:31:03.391242
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class test_pairs(object):
        def __init__(self, pairs):
            self.pairs = pairs

    class test_AnsibleVaultEncryptedUnicode(object):
        def __init__(self, value):
            self.value = value
            self.vault = None

    test_pairs_obj = {'__ansible_vault': 'vault_test', '__ansible_unsafe': 'unsafe_test'}
    test_pairs_obj = test_pairs(test_pairs_obj)

    test_AnsibleJSONDecoder_obj = AnsibleJSONDecoder()
    test_AnsibleJSONDecoder_obj.set_secrets('secrets_test')


# Generated at 2022-06-11 08:31:09.319786
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder()
    test_data = {'__ansible_vault': 'test_vault_string', 'unencrypt': 'unencrypt_string'}
    ret = d.object_hook(test_data)
    assert(ret['__ansible_vault'].data == 'test_vault_string' and ret['unencrypt'] == 'unencrypt_string')

# Generated at 2022-06-11 08:31:19.288900
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Setup
    decoder = AnsibleJSONDecoder()
    decoder._vaults = {'default': VaultLib()}
    plaintext = 'some plaintext'
    ciphertext = b'AQAAABAAAAAQ7AGOKQ2hkBw7DdHWpYV0q3F3GWmxvx8hkW4bFrAjA4DAAEAAQAAnQGNotovg7quFLztDQyWxjxPRlDNyD6F1fEtrZde0zw'
    data = {
        '__ansible_vault': ciphertext,
        '__ansible_unsafe': plaintext,
    }

    # Test
    result = decoder.object_hook(data)

    # Verify

# Generated at 2022-06-11 08:31:26.510422
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    source_dict = {'__ansible_vault': 'my_secret', '__ansible_unsafe': 'my_unsafe', 'other_key': 'value'}
    expected_dict = {'__ansible_vault': AnsibleVaultEncryptedUnicode('my_secret'), '__ansible_unsafe': wrap_var('my_unsafe'), 'other_key': 'value'}
    actual_dict = json.loads(json.dumps(source_dict))

    assert expected_dict == actual_dict

# Generated at 2022-06-11 08:31:35.698498
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Different kind of ansible objects: vault, unsafe, special AnsibleModule args
    ansible_objects = json.loads('''
    {
      "__ansible_vault": "VGVzdA==",
      "__ansible_unsafe": true,
      "key": "value",
      "key2": "value2"
    }''', cls=AnsibleJSONDecoder)

    vault_value = ansible_objects.get('__ansible_vault')
    assert isinstance(vault_value, AnsibleVaultEncryptedUnicode)
    assert vault_value == 'Test'

    assert ansible_objects.get('__ansible_unsafe') == True

# Generated at 2022-06-11 08:31:45.136314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    json_strings = [
        '{"__ansible_vault": "ENC[...]"}',
        '{"__ansible_vault": "ENC[...]", "foo": "bar"}',
        '{"__ansible_unsafe": "ENC[...]"}',
        '{"__ansible_unsafe": "ENC[...]", "foo": "bar"}'
    ]
    for json_string in json_strings:
        pairs = json.loads(json_string, cls=AnsibleJSONDecoder)
        assert isinstance(pairs, dict)
        assert '__ansible_vault' in pairs or '__ansible_unsafe' in pairs


# Generated at 2022-06-11 08:31:56.518077
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:04.890075
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:07.227455
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    o = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'value'})
    assert isinstance(o, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-11 08:32:14.138585
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    payload = dict(__ansible_vault='$ANSIBLE_VAULT;1.2;AES256;foo\n')
    output = decoder.object_hook(payload)
    assert isinstance(output, dict)
    assert isinstance(output['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert output['__ansible_vault'].original_bytes == b'$ANSIBLE_VAULT;1.2;AES256;foo\n'
    assert output['__ansible_vault'].vault is None

    payload = dict(__ansible_unsafe='foobar')
    output = decoder.object_hook(payload)
    assert isinstance(output, dict)

# Generated at 2022-06-11 08:32:18.885444
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    the_string = '''
    {
        "__ansible_unsafe": "test string",
        "__ansible_vault": "test vault"
    }
    '''

    decoder = AnsibleJSONDecoder.set_secrets(['mysecret'])
    json.loads(the_string, cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:32:27.554639
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    text = """
    {
        "a": {"b": "123"},
        "b": {"__ansible_vault": "c"},
        "c": {"__ansible_unsafe": "d"},
        "d": 123,
        "e": "123",
        "f": [1, 2, 3]
    }
    """
    vault_password = 'test secret'
    secrets = [f'{vault_password}']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    result = json.loads(text, cls=decoder)
    assert result['a'] == {'b': '123'}
    assert result['b'] == AnsibleVaultEncryptedUnicode("c")
    assert result['c'] == 'd'
   

# Generated at 2022-06-11 08:32:39.373211
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    json_content = '{"__ansible_vault": "vault_content"}'
    ansible_vault_encoded_unicode = AnsibleVaultEncryptedUnicode('vault_content')
    json_decoder = AnsibleJSONDecoder()
    assert json_decoder.object_hook(json.loads(json_content)) == {'__ansible_vault': ansible_vault_encoded_unicode}
    json_content = '{"__ansible_unsafe": "unsafe_content"}'
    safe_string = wrap_var('unsafe_content')

# Generated at 2022-06-11 08:32:51.747265
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:02.316626
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 08:33:11.973358
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = AnsibleLoader(DataLoader(), None)

# Generated at 2022-06-11 08:33:22.497574
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import os
    import pytest
    from ansible.parsing.vault import VaultLib

    filepath = os.path.abspath(os.path.join(os.path.dirname(sys.argv[0]), '../../examples/files/vault/test_vault.yml'))


# Generated at 2022-06-11 08:33:29.421184
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Create a dict that contains an AnsibleVaultEncryptedUnicode
    ansible_json_decoder = AnsibleJSONDecoder()
    test_data = {'__ansible_vault': "my_secret"}
    result = ansible_json_decoder.object_hook(test_data)

    # Assert the result of the object_hook function
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:33:40.025476
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{
        'secret/devops': {
            'devops_ansible_password': 'devops_ansible_password'
        }
    }]

# Generated at 2022-06-11 08:33:50.712170
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """tes_AnsibleJSONDecoder_object_hook"""
    import os
    import yaml
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def get_playbook_vars():
        loader = DataLoader()
        var_mgr = VariableManager()
        var_mgr.set_loader(loader=loader)
        var_names = ['playbook_dir', 'inventory_dir', 'inventory_file']

# Generated at 2022-06-11 08:34:01.170916
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_secret = 'vault_secret'
    ansible_vault_str = '$ANSIBLE_VAULT;1.1;AES256\n35643864616137656138343937366531393937613961333137613138373638653961396663376164\n34663736336535373362366539333835343966343962366262656338616337666332666436306339\n32666431346339616131376633383066343936643162343162306236643163366163623336643638\n31316663313235666432616432316533343662346362313766663133633262653236316635633365\n36333764356433383664'



# Generated at 2022-06-11 08:34:06.936229
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "TEST", "__ansible_unsafe": "TEST"}'
    obj = json.loads(s, cls=AnsibleJSONDecoder)
    assert isinstance(obj, dict)
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_unsafe'], str)



# Generated at 2022-06-11 08:34:13.966232
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:22.735317
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:32.656990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test string with __ansible_vault value
    data = '{"__ansible_vault": "foo"}'
    result = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # Test string with __ansible_vault value
    data = '{"__ansible_unsafe": "foo"}'
    result = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(result, AnsibleUnsafeText)

    # Test string with __ansible_vault value with a vaultid
    data = '{"__ansible_vault__id1": "foo"}'
    result = json.loads(data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:34:43.720632
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test AnsibleVaultEncryptedUnicode is created with default AnsibleVault instance
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;abcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcd', '__ansible_vault_password': 'secrets'}
    print(json.dumps(pairs))
    jd = AnsibleJSONDecoder(pairs)
    d = jd.object_hook(pairs)
    assert(isinstance(d['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(d['__ansible_vault'].vault.secrets == None)
    # test AnsibleVaultEncryptedUnic

# Generated at 2022-06-11 08:34:52.533822
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {
        u'__ansible_unsafe': u'This is unsafe data',
        u'__ansible_vault': u'vault_data',
        '__other_safe': 'This is safe data',
    }
    # make sure vault decoding is disabled, otherwise AnsibleVaultEncryptedUnicode is not returned
    AnsibleJSONDecoder.set_secrets(None)
    decoder = AnsibleJSONDecoder()
    decode = decoder.decode(json.dumps(test_data))
    assert isinstance(decode['__ansible_unsafe'], wrap_var)
    assert decode['__ansible_unsafe'] == u'This is unsafe data'
    assert isinstance(decode['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decode

# Generated at 2022-06-11 08:34:57.935093
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {'__ansible_vault': 'foo'}
    decoder = AnsibleJSONDecoder()
    decrypted_obj = decoder.object_hook(obj)
    assert decrypted_obj.data == 'foo'

    # Assert __ansible_vault was removed
    assert decrypted_obj.data == obj.pop('__ansible_vault')



# Generated at 2022-06-11 08:35:07.936712
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-11 08:35:15.487299
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from collections import OrderedDict
    json_str = {'__ansible_unsafe': u'password', '__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\r\nv.c6h8EyJ.x.y'}
    json_str = json.dumps(json_str)
    json_data = json.loads(json_str, object_hook=AnsibleJSONDecoder.object_hook)
    assert isinstance(json_data, OrderedDict)

# Generated at 2022-06-11 08:35:23.016022
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ["vaultpassword"]
    AnsibleJSONDecoder.set_secrets(secrets)
    i = '''
    {
        "foo": "thevalue",
        "bar": "the other value",
        "__ansible_vault": "vaultpassword",
        "__ansible_unsafe": "foobar"
    }
    '''

    j = json.loads(i)

    assert j['__ansible_vault'] == "vaultpassword"
    assert j['__ansible_unsafe'] == "foobar"

# Generated at 2022-06-11 08:35:30.555141
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    text = '{"__ansible_vault": "foo", "__ansible_unsafe": "bar"}'

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    obj = json.loads(text, cls=decoder)

    assert isinstance(obj, dict)
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-11 08:35:37.301631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = """{"__ansible_vault": "AES256:CbmZ7zQJxAuVwLhIpKjy7vceaUIBXcG5Z5z5Y1lhZ1U="}"""
    decoded = AnsibleJSONDecoder().decode(data)
    assert decoded.vault.vault_password == "cbmZ7zqjxAuvwLhIpKjy7vceaUibXcG5Z5z5y1lhZ1U="
    assert decoded == AnsibleVaultEncryptedUnicode('AES256:CbmZ7zQJxAuVwLhIpKjy7vceaUIBXcG5Z5z5Y1lhZ1U=')


# Generated at 2022-06-11 08:35:42.221963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = "test"
    json_str = '{"__ansible_vault": "test"}'
    ansible_json = AnsibleJSONDecoder.set_secrets(secrets)
    decoded_data = ansible_json.decode(json_str)
    assert decoded_data['__ansible_vault'] == 'test'
    assert isinstance(decoded_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:35:54.928798
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Check __ansible_vault
    input_data = {u'__ansible_vault': 'VAULTED_DATA', u'b': u'B'}
    result = decoder.object_hook(input_data)
    assert result[u'__ansible_vault'] == 'VAULTED_DATA'

    # Check __ansible_unsafe
    input_data = {u'__ansible_unsafe': 'UNSAFE_DATA', u'b': u'B'}
    result = decoder.object_hook(input_data)
    assert result[u'__ansible_unsafe'] == 'UNSAFE_DATA'

    # Test no changes are made if no valid keys

# Generated at 2022-06-11 08:36:03.447739
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:13.419206
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Given
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-11 08:36:21.955189
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Unit test for method object_hook of class AnsibleJSONDecoder.
    """
    ansible_json_decoder = AnsibleJSONDecoder()

    # test against JSON string
    pairs = {'key1': {'__ansible_vault': 'value1', 'key2': 'value2'}}
    result = ansible_json_decoder.object_hook(pairs)['key1']['__ansible_vault']
    assert isinstance(result, AnsibleVaultEncryptedUnicode) and result == 'value1'

    # test against obj
    pairs = {'key1': {'__ansible_unsafe': 'value1', 'key2': 'value2'}}

# Generated at 2022-06-11 08:36:32.730691
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test for converting AnsibleVaultEncryptedUnicode
    test_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n'
                                   '36336165663965366233316635323531353165313866616134393261613531333135633438663861\n'
                                   '39386365316532333339326434353839373239623231373365396235633236386362656532303164\n'
                                   '3437306639376139343561\n'}
    ansible_json_decoder = AnsibleJSONDecoder()
    decoder_output = ansible_json_decoder.object_hook(test_data)

# Generated at 2022-06-11 08:36:38.118131
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = dict(__ansible_vault='test', __ansible_unsafe='test')
    decoder = AnsibleJSONDecoder()

    expected = dict(__ansible_vault=data.get('__ansible_vault'), __ansible_unsafe=wrap_var('test'))
    actual = decoder.object_hook(data)

    assert expected == actual



# Generated at 2022-06-11 08:36:48.823155
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = dict(__ansible_vault='test')
    result = AnsibleJSONDecoder().object_hook(obj)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result == 'test'

    obj = dict(__ansible_vault='test', __ansible_unsafe=dict(a=1))
    result = AnsibleJSONDecoder().object_hook(obj)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None
    assert result == 'test'
    assert result.unsafe_proxy is not None
    assert result.unsafe_proxy == dict(a=1)
    assert result.vault == result.unsafe_proxy['__ansible_unsafe']['__ansible_vault']

# Generated at 2022-06-11 08:36:58.999170
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Simple test case

# Generated at 2022-06-11 08:37:13.143440
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook([]) is None
    assert decoder.object_hook([{'a': 1}]) == {'a': 1}
    assert decoder.object_hook([{'a': 1, '__ansible_vault': '123'}]) == AnsibleVaultEncryptedUnicode('123')
    assert decoder.object_hook([{'a': 1, '__ansible_unsafe': '$123'}]).__ansible_unsafe__ == True
    assert decoder.object_hook([{'__ansible_vault': '123'}]) == AnsibleVaultEncryptedUnicode('123')
    assert decoder.object_hook([{'__ansible_unsafe': '$123'}]).__ansible_unsafe__ == True

# Generated at 2022-06-11 08:37:23.081231
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:37:31.846147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''test object_hook method of AnsibleJSONDecoder class'''
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': '"my vault string"'}) == AnsibleVaultEncryptedUnicode('"my vault string"')
    assert decoder.object_hook({'__ansible_unsafe': '"my unsafe string"'}) == 'my unsafe string'
    assert decoder.object_hook({'__ansible_vault': '"my vault string"', '__ansible_unsafe': '"my unsafe string"'}) == {'__ansible_unsafe': 'my unsafe string', '__ansible_vault': AnsibleVaultEncryptedUnicode('"my vault string"')}


# Generated at 2022-06-11 08:37:41.942257
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import os
    import random
    import string
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    testcase_obj = {}
    testcase_obj['__ansible_vault'] = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(32)])

    testcase_str = json.dumps(testcase_obj, cls=AnsibleJSONEncoder)
    testcase_str = json.loads(testcase_str, cls=AnsibleJSONDecoder)

    assert isinstance(testcase_str, dict)

    assert isinstance(testcase_str.get('__ansible_vault'), AnsibleVaultEncryptedUnicode)
    assert testcase_str.get('__ansible_vault')

# Generated at 2022-06-11 08:37:51.151147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets_dict = {'password': 'mypass'}
    AnsibleJSONDecoder.set_secrets(secrets_dict)

# Generated at 2022-06-11 08:38:01.330913
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # AnsibleVaultEncryptedUnicode test case
    data = '''{
        "__ansible_vault": "foo"
    }'''
    actual_result = AnsibleJSONDecoder().decode(data)
    expected_result = {'__ansible_vault': 'foo'}
    assert actual_result == expected_result

    # wrap_var test case
    data = '''{
        "__ansible_unsafe": "foo"
    }'''
    actual_result = AnsibleJSONDecoder().decode(data)
    expected_result = {'__ansible_unsafe': 'foo'}
    assert actual_result == expected_result

    # no match test case
    data = '''{
        "__ansible_foo": "bar"
    }'''
    actual_result

# Generated at 2022-06-11 08:38:10.784987
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['password1', 'password2', 'password3']
    json_data = '''
{
    "__ansible_unsafe": "{{ password }}",
    "__ansible_vault": "vaultpassword"
}
'''
    AnsibleJSONDecoder.set_secrets(secrets)
    data = AnsibleJSONDecoder().decode(json_data)
    assert type(data) is dict
    assert data['__ansible_unsafe'].data == '{{ password }}'
    assert data['__ansible_vault'].data == 'vaultpassword'
    assert data['__ansible_vault'].vault is not None


# Generated at 2022-06-11 08:38:18.026129
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"__ansible_vault": '$ANSIBLE_VAULT;1.1;AES256;test\n633333336564633766343236323962376436623739347a2b2b4a3b2b4d4e6430\n3935623333653734633464326338613930373564373131346166336430383764\n35643036613037610a3336353638313737356430366134313861323134613861\n6131333362366632653666353931633233656436393061346134303735646136\n3261663938663336373936643538\n',
         "foo": "bar"}
    secret  = ['ansible']
    AnsibleJSONDec

# Generated at 2022-06-11 08:38:28.758683
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test 1
    input_dict = {'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;test\n32663730666431666533613233316232626161323663623632356163313030363466356538663065\n39656262316533373331313966386164316537616132626363386235323065373035396133386130\n62346338616561643965653761666262626434636565656331323931616366396464623831646162\n6233666162353066643133346263323233663433666433633739643839386433613762653566', '__ansible_unsafe': False}

