

# Generated at 2022-06-11 08:28:35.840635
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:28:42.961881
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:28:49.128010
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    json_decoder = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode = json_decoder.object_hook({'__ansible_vault': '1234'})
    if isinstance(ansible_vault_encrypted_unicode, AnsibleVaultEncryptedUnicode):
        print("ansible_vault_encrypted_unicode: %s" % ansible_vault_encrypted_unicode)
        return True
    else:
        return False

# Generated at 2022-06-11 08:28:52.255449
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder().object_hook({"__ansible_vault": "foo"}) == AnsibleVaultEncryptedUnicode(u"foo")
    assert AnsibleJSONDecoder().object_hook({"__ansible_unsafe": "foo"}) == wrap_var("foo")

# Generated at 2022-06-11 08:28:58.356620
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:03.281621
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = dict(
        __ansible_vault="$ANSIBLE_VAULT;1.1;AES256;test\no\n1234\n",
        __ansible_unsafe="<test>",
    )

    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook(pairs)

    assert result['__ansible_vault'].vault.secrets == ['test']
    assert result['__ansible_vault'].vault.password == '1234'
    assert result['__ansible_unsafe'] == 'UNSAFE_PROXY:<test>'


# Generated at 2022-06-11 08:29:08.843104
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {'__ansible_vault': 'some_text'}
    ansible_decoder = AnsibleJSONDecoder()
    result = ansible_decoder.object_hook(test_data)
    assert isinstance(result, dict)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:29:18.016114
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets(secrets=["hunter2"])

# Generated at 2022-06-11 08:29:29.493929
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    cls = AnsibleJSONDecoder()
    pairs = {}

# Generated at 2022-06-11 08:29:39.163124
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Unit test for AnsibleJSONDecoder class
    """
    class _args(object):
        """
        Dummy class for unit testing
        """
        def __init__(self):
            self.ask_vault_pass = False
            self.vault_password_file = False

    # Create an instance of AnsibleJSONDecoder for testing
    my_decoder = AnsibleJSONDecoder()

    # Test with dictionary containing an encrypted string
    # The AnsibleVaultEncryptedUnicode class is imported from ansible.parsing.yaml.objects

# Generated at 2022-06-11 08:29:49.335637
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '''{ "__ansible_unsafe": "{{some_var}}", "__ansible_vault": "{{some_var}}" }'''

    result = AnsibleJSONDecoder().decode(json_str)
    assert isinstance(result, dict)
    assert isinstance(result["__ansible_unsafe"], AnsibleVaultEncryptedUnicode)
    assert isinstance(result["__ansible_vault"], AnsibleVaultEncryptedUnicode)

    result = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(json_str)
    assert isinstance(result, dict)
    assert isinstance(result["__ansible_unsafe"], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:30:00.808748
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test 1: test.vault
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:30:09.269712
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test unwrapping AnsibleVaultEncryptedUnicode
    value1 = {u'__ansible_vault': u'example'}
    value2 = {u'__ansible_vault': u'example', u'__ansible_unsafe': True}
    value3 = {u'__ansible_vault': u'example', u'__ansible_unsafe': False}

    decoder = AnsibleJSONDecoder()
    value1_1 = decoder.object_hook(value1)
    value2_1 = decoder.object_hook(value2)
    value3_1 = decoder.object_hook(value3)

    assert isinstance(value1_1, AnsibleVaultEncryptedUnicode)
    assert value1_1._text == 'example'

# Generated at 2022-06-11 08:30:17.227202
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    vault_password = 'test_password'
    vault_data = AnsibleVaultEncryptedUnicode('test_data', vault_password)
    vault_dict = {'__ansible_vault': vault_data}

    def object_hook(pairs):
        return pairs

    json_str = json.dumps(vault_dict, indent=4, cls=AnsibleJSONEncoder)
    json_dict = json.loads(json_str, cls=AnsibleJSONDecoder, object_hook=object_hook)

    assert json_dict['__ansible_vault'] == vault_data

# Generated at 2022-06-11 08:30:28.029524
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:36.524585
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-11 08:30:44.010869
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    data = json.loads(
        '{"__ansible_unsafe": "unsafe string", "__ansible_vault": "vault encrypted unicode", "regular key": "regular value"}',
        cls=AnsibleJSONDecoder
    )

    assert data['__ansible_unsafe'] == wrap_var('unsafe string')
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert data['regular key'] == 'regular value'

# Generated at 2022-06-11 08:30:53.327161
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:31:03.115502
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'password'
    class TestObj_object_hook():
        def __init__(self, value):
            self.value = value

    AnsibleJSONDecoder.set_secrets(secrets)
    value = dict(
        key1='value1',
        key2=TestObj_object_hook('value2'),
        __ansible_vault='str_encrypted',
        __ansible_unsafe='str_unsafe'
    )

    result = AnsibleJSONDecoder().object_hook(value)
    assert result['key1'] == 'value1'
    assert result['key2'].value == 'value2'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].value == 'str_encrypted'

# Generated at 2022-06-11 08:31:11.997307
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    string = '{"__ansible_vault": "vault_value"}'
    obj = AnsibleJSONDecoder().decode(string)
    assert obj['__ansible_vault'] == 'vault_value'
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    string = '{"__ansible_unsafe": "unsafe_value"}'
    obj = AnsibleJSONDecoder().decode(string)
    assert obj['__ansible_unsafe'] == 'unsafe_value'
    assert isinstance(obj['__ansible_unsafe'], AnsibleUnsafeText)

# Generated at 2022-06-11 08:31:23.585733
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    password = "password"
    decoder.set_secrets(password)

# Generated at 2022-06-11 08:31:34.024701
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_text

    from ansible.parsing.vault import VaultSecret

    decoder = AnsibleJSONDecoder()
    secrets = [VaultSecret('secret', 'password')]
    decoder.set_secrets(secrets)

    # It should decrypt the __ansible_vault field.

# Generated at 2022-06-11 08:31:41.362931
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Unit test for method object_hook of class AnsibleJSONDecoder
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder().object_hook).decode('{"__ansible_vault": "ANX=="}') == AnsibleVaultEncryptedUnicode('ANX==')
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder().object_hook).decode('{"__ansible_unsafe": "unsafe"}') == wrap_var('unsafe')



# Generated at 2022-06-11 08:31:51.951635
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    def assert_is_ansible_vault(value):
        assert isinstance(value, AnsibleVaultEncryptedUnicode)
        assert isinstance(value.vault, VaultLib)

    def assert_is_unsafe(value):
        assert type(value).__name__ == 'AnsibleUnsafeText'

    # Create the decoder with and without vault
    decoder = AnsibleJSONDecoder()
    decoder_with_vault = AnsibleJSONDecoder()
    decoder_with_vault._

# Generated at 2022-06-11 08:31:56.723552
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder_instance = AnsibleJSONDecoder()

    # Test ansible_vault
    # ansible_vault
    ansible_vault_result = decoder_instance.object_hook({"__ansible_vault": "aabbcc"})
    assert(isinstance(ansible_vault_result, AnsibleVaultEncryptedUnicode))
    assert(ansible_vault_result == "aabbcc")

    # Test ansible_unsafe
    ansible_unsafe_result = decoder_instance.object_hook({"__ansible_unsafe": "aabbcc"})
    assert(isinstance(ansible_unsafe_result, str))
    assert(ansible_unsafe_result == "aabbcc")

# Generated at 2022-06-11 08:32:04.933147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    my_ansible_vault_in_json = """{
        "__ansible_vault": "testvault",
        "__ansible_unsafe": "testunsafe"
    }"""

    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets('testsecret')
    my_json_object = json.loads(my_ansible_vault_in_json, cls=ansible_json_decoder)
    assert isinstance(my_json_object, dict)
    assert len(my_json_object.keys()) == 2
    assert isinstance(my_json_object['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:32:14.220424
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Scenario1: decrypt test
    # Expected result: decrypt data successfully
    decrypted_data = {
        'encrypted': '$ANSIBLE_VAULT;1.1;AES256;user\n12222222222\n',
        'plain': 'test',
        '__ansible_vault': {
            'cipher': 'AES256',
            'version': '1.1',
            'vault_id': 'user',
            'hmac': None
        }
    }
    secret = 'password'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secret)
    decrypted_data = json.loads(json.dumps(decrypted_data), cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:32:20.771998
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json = b'{"__ansible_unsafe": "abc", "__ansible_vault": "abc"}'
    json_decoder = AnsibleJSONDecoder()
    json_decoder.set_secrets(['secret'])
    decoded = json_decoder.decode(test_json)
    assert type(decoded['__ansible_vault'].vault) == VaultLib
    assert type(decoded['__ansible_unsafe']) == type(wrap_var('abc'))

# Generated at 2022-06-11 08:32:27.810038
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    src_json = '{"__ansible_unsafe": "on", "__ansible_vault": "ANSIBLE_VAULT;1.1;AES256;foo\\n123456\\n"}'
    obj = json.loads(src_json, cls=AnsibleJSONDecoder)
    assert obj['__ansible_unsafe'] == "on"
    assert obj['__ansible_vault'] == AnsibleVaultEncryptedUnicode('ANSIBLE_VAULT;1.1;AES256;foo\n123456\n')


# Generated at 2022-06-11 08:32:38.634690
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:51.236049
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [('$ANSIBLE_VAULT;', '$ANSIBLE_VAULT;')]
    AnsibleJSONDecoder.set_secrets(secrets)

    unsafe = ('$ANSIBLE_VAULT;', '$ANSIBLE_VAULT;')
    data = json.loads('{"__ansible_unsafe": "%s"}' % AnsibleJSONEncoder().encode(unsafe), cls=AnsibleJSONDecoder)
    assert data == {'__ansible_unsafe': unsafe}

# Generated at 2022-06-11 08:33:01.795547
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import copy

    AnsibleJSONDecoder._vaults['default'] = VaultLib(password='password')


# Generated at 2022-06-11 08:33:11.610021
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test plain text
    text = '{"foo": "text"}'
    data = json.loads(text, cls=AnsibleJSONDecoder)
    assert data['foo'] == 'text'

    # Test vault
    text = '{"foo": "text", "__ansible_vault": "ENC[foo]"}'
    data = json.loads(text, cls=AnsibleJSONDecoder)
    assert data['foo'] == 'ENC[foo]'

    # Test unsafe
    text = '{"foo": "text", "__ansible_unsafe": "foo"}'
    data = json.loads(text, cls=AnsibleJSONDecoder)
    assert data['foo'] == 'foo'

    # Test vault and unsafe

# Generated at 2022-06-11 08:33:22.079394
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:33.354100
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {'vault_password': 'x'}
    json_data = '''
        {
            "__ansible_vault": "encrypted",
            "__ansible_unsafe": "unsafe"
        }
    '''

    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    result = decoder.decode(json_data)

    assert isinstance(result, dict)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault.secrets == secrets
    assert isinstance(result['__ansible_unsafe'], str)
    assert result['__ansible_unsafe'] == 'unsafe'

# Generated at 2022-06-11 08:33:42.773130
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    temp_json_string = """{"__ansible_vault": "AnsibleVaultEncryptedUnicode", "__ansible_unsafe": "wrap_var"}"""
    temp_decoded_json = json.loads(temp_json_string, cls=AnsibleJSONDecoder)
    assert temp_decoded_json['__ansible_vault'] == "AnsibleVaultEncryptedUnicode"
    assert temp_decoded_json["__ansible_unsafe"] == "wrap_var"
    assert temp_decoded_json['__ansible_vault'].__class__.__name__ == "AnsibleVaultEncryptedUnicode"
    assert temp_decoded_json["__ansible_unsafe"].__class__.__name__ == "SafeText"


# Generated at 2022-06-11 08:33:53.986106
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': 'the vault', '__ansible_unsafe': 'the var'}

    def object_hook(self, pairs):
        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                value = AnsibleVaultEncryptedUnicode(value)
                if self._vaults:
                    value.vault = self._vaults['default']
                return value
            elif key == '__ansible_unsafe':
                return wrap_var(value)

        return pairs

    AnsibleJSONDecoder._vaults['default'] = 'default vault'
    result = object_hook(AnsibleJSONDecoder, pairs)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:33:56.714128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'XXX'}) == {'__ansible_vault': 'XXX'}

# Generated at 2022-06-11 08:34:03.643444
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {
        '__ansible_vault': 'encrypted_string',
        '__ansible_unsafe': 'should_be_marked_as_unsafe',
        'key': 'value'
    }

    plain_data = AnsibleJSONDecoder.object_hook(test_data)

    assert plain_data['__ansible_vault'] == 'encrypted_string'
    assert plain_data['__ansible_unsafe'].is_safe_attribute() is False
    assert isinstance(plain_data['key'], str)

# Generated at 2022-06-11 08:34:12.852098
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # fixture
    ansible_vault_str = '$ANSIBLE_VAULT;1.2;AES256;myuser;mypassword'
    unsafe_value = {'__ansible_unsafe': True, 'password': ansible_vault_str}
    vault_value = {'__ansible_vault': ansible_vault_str}
    safe_value = {'__ansible_safe': True, 'password': ansible_vault_str}

    test_cases = [
        ('', {}),
        ('{"__ansible_vault": "string"}', vault_value),
        ('{"__ansible_unsafe": true}', unsafe_value),
        ('{"__ansible_safe": true}', safe_value),
    ]

    for (raw, expected) in test_cases:
        got

# Generated at 2022-06-11 08:34:24.645742
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:34.972706
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    v = {"__ansible_vault": "string"}
    a = AnsibleJSONDecoder(v)
    assert isinstance(a.object_hook(v), AnsibleVaultEncryptedUnicode)
    assert isinstance(a.object_hook(v).vault, VaultLib)
    assert a.object_hook(v).vault == a._vaults['default']
    assert a.object_hook(v).vault.get_vault_id() == 'default'
    assert a.object_hook(v).data == "string"

    AnsibleJSONDecoder.set_secrets("test password")
    assert isinstance(a.object_hook(v), AnsibleVaultEncryptedUnicode)
    assert isinstance(a.object_hook(v).vault, VaultLib)
    assert a.object_

# Generated at 2022-06-11 08:34:46.099797
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    Function used for unit test for method object_hook of class AnsibleJSONDecoder
    '''
    # Test to handle case when pairs is empty
    pairs = None
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook(pairs) == {}

    # Test to handle normal case
    pairs = {"1": "a"}
    assert ansible_json_decoder.object_hook(pairs) == {"1": "a"}

    # Test to handle case when key is __ansible_vault
    pairs = {"__ansible_vault": "a"}
    assert ansible_json_decoder.object_hook(pairs) == AnsibleVaultEncryptedUnicode("a")

    # Test to handle case when key is __ansible_unsafe

# Generated at 2022-06-11 08:34:53.979072
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secrets = {'default': 'vault_pass' }
    decoder.set_secrets(secrets)
    ansible_vault = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\r\n633831656439336564'}
    decoder.object_hook(ansible_vault)
    assert ansible_vault['__ansible_vault'].vault == VaultLib(secrets=secrets)

    ansible_unsafe = {'__ansible_unsafe': {'__ansible_arguments': ['test']} }
    decoder.object_hook(ansible_unsafe)

# Generated at 2022-06-11 08:35:04.764148
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import itertools
    import pytest

    class C(object):
        pass

    class D(object):
        pass

    class E(D):
        pass

    if hasattr(json.JSONDecoder, 'object_hook'):
        # use json decoder that is only added in Python 2.7+
        class JSONDecoder(json.JSONDecoder):
            def object_hook(self, pairs):
                # note that we pass ``pairs`` to the ``super`` constructor
                # so that it can be accessed by the ``test_pairs`` fixture
                super(JSONDecoder, self).__init__(pairs=pairs)
                for key, value in pairs.items():
                    if key == '__ansible_vault':
                        return AnsibleVaultEncryptedUnicode(value)

# Generated at 2022-06-11 08:35:14.877504
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    AnsibleJSONDecoder.set_secrets(secrets)
    data = {
        '__ansible_vault': 'dGVzdA==',
        '__ansible_unsafe': 'false',
    }
    data_json = json.dumps(data, cls=AnsibleJSONEncoder)
    result_data = json.loads(data_json, cls=AnsibleJSONDecoder)
    assert result_data['__ansible_vault'].vault.secrets == ['test']
    assert result_data['__ansible_vault'].vault.decrypt(result_data['__ansible_vault']) == 'test'
    assert result_data['__ansible_unsafe'] == wrap_var('false')

# Generated at 2022-06-11 08:35:26.132026
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:35:36.386385
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:44.185427
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AVU = AnsibleVaultEncryptedUnicode
    # Return AnsibleVaultEncryptedUnicode object every time it sees input
    #  of __ansible_vault
    json_data = json.loads(
        '{"__ansible_unsafe":"test","__ansible_vault":"test"}',
        cls=AnsibleJSONDecoder
    )
    assert isinstance(json_data['__ansible_unsafe'], str)
    assert json_data['__ansible_unsafe'] == 'test'
    assert isinstance(json_data['__ansible_vault'], AVU)
    assert json_data['__ansible_vault'] == 'test'

    # Return the first AnsibleVaultEncryptedUnicode object every time it sees
    #  input of __ansible_vault

# Generated at 2022-06-11 08:35:57.007383
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_unsafe': 123, '__ansible_vault': '_vault_'}
    assert isinstance(AnsibleJSONDecoder.object_hook(pairs), dict)

    pairs = {'__ansible_unsafe': 123, '__ansible_vault': '_vault_'}
    assert isinstance(AnsibleJSONDecoder.object_hook(pairs)['__ansible_unsafe'], wrap_var)

    pairs = {'__ansible_unsafe': 123, '__ansible_vault': '_vault_'}
    assert isinstance(AnsibleJSONDecoder.object_hook(pairs)['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    pairs = {}
    assert not AnsibleJSONDecoder.object

# Generated at 2022-06-11 08:36:08.019437
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class v():
        def __init__(self, id, name):
            self.id = id
            self.name = name

    decoder = AnsibleJSONDecoder()
    for obj in [v('id', 'name')]:
        # json_decode from jsonutils.safe_load, to have value as string
        item = decoder.object_hook(json.loads('{"__v": "'+ obj.name +'", "__p": "'+ obj.id +'"}'))
        assert item['__p'] == obj.id
        assert item['__v'] == obj.name

# Generated at 2022-06-11 08:36:16.304820
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from io import StringIO

    json_data = """
{"s": "string",
 "v": {"__ansible_vault": "string"},
 "u": {"__ansible_unsafe": "string"}}
"""
    data = json.load(StringIO(json_data), cls=AnsibleJSONDecoder)
    assert data['s'] == 'string'
    assert isinstance(data['v'], AnsibleVaultEncryptedUnicode)
    assert data['v'].vault is None
    assert isinstance(data['u'], wrap_var)
    assert data['u']._obj == 'string'

# Generated at 2022-06-11 08:36:23.554174
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test __ansible_vault
    secrets = ['foo']
    json_str = r'{"__ansible_vault": "foo"}'
    decoded = json.loads(json_str, cls=AnsibleJSONDecoder)
    expected = AnsibleVaultEncryptedUnicode(b'foo')
    expected.vault = VaultLib(secrets=secrets)
    assert decoded == expected

    # Test __ansible_unsafe
    json_str = r'{"__ansible_unsafe": "foo"}'
    decoded = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert decoded == 'foo'

# Generated at 2022-06-11 08:36:34.046209
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test object_hook without __ansible_vault
    data = json.loads('{"a": "b"}', cls=AnsibleJSONDecoder)
    assert data == {'a': 'b'}
    # test object_hook with __ansible_vault

# Generated at 2022-06-11 08:36:44.986074
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder(ensure_ascii=True)
    dec = AnsibleJSONDecoder(object_hook=enc.object_hook, strict=False)

    pairs = dec.object_hook({
        "__ansible_vault": "value",
        "__ansible_unsafe": "value",
        "__ansible_module_name": "value",
        "__ansible_arguments": "value",
        "__ansible_facts": "value",
    })
    assert pairs.get("__ansible_vault", None) == "value"
    assert pairs.get("__ansible_unsafe", None) == "value"
    assert pairs.get("__ansible_module_name", None) == "value"

# Generated at 2022-06-11 08:36:53.190510
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json

    test_json_data = r'''
    {
        "__ansible_unsafe": "unsafe_str",
        "__ansible_vault": "vault_str",
        "__ansible_ignore__": "ignore_str",
        "key": "value"
    }
    '''
    test_json_data_object = AnsibleJSONDecoder().decode(test_json_data)
    assert test_json_data_object.get("__ansible_unsafe") == "unsafe_str"
    assert test_json_data_object.get("__ansible_vault") == "vault_str"
    assert test_json_data_object.get("__ansible_ignore__") == "ignore_str"
    assert test_json_data_object.get("key")

# Generated at 2022-06-11 08:37:01.643369
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest


# Generated at 2022-06-11 08:37:11.417742
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    import sys

    # Class used to mock a variable instance
    class Mock(object):
        def __init__(self, value):
            self.value = value

    # Simple test to make sure mocking works
    def simple_test(decode_string, expected_value):
        value = json.loads(decode_string, cls=AnsibleJSONDecoder)
        if value != expected_value:
            sys.stderr.write("Failed to decode: %s.  Expected %s, got %s"
                             % (decode_string, expected_value, value))

    # Unit test for AnsibleJSONDecoder.object_hook method

# Generated at 2022-06-11 08:37:21.793064
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    ansible_vault_json_data = '{"__ansible_vault": "vault_value"}'
    ansible_unsafe_json_data = '{"__ansible_unsafe": "unsafe_value"}'

    # Plain json string
    normal_data = '{"key": "value"}'

    assert isinstance(AnsibleJSONDecoder(ansible_vault_json_data).object_hook(), AnsibleVaultEncryptedUnicode)
    assert isinstance(AnsibleJSONDecoder(ansible_unsafe_json_data).object_hook(), dict)

# Generated at 2022-06-11 08:37:30.587778
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest


# Generated at 2022-06-11 08:37:48.715688
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.dataloader import DataLoader
    from ansible_collections.testns.testcoll.plugins.module_utils.test_module_utils import AnsibleVaultEncryptedUnicode as AVU
    secr = 'testsecret'
    AnsibleJSONDecoder.set_secrets([secr])
    expected_secret = secr.encode('utf-8')
    vstr = AVU(u'thisisatest').encode()
    data = json.loads(json.dumps({u'__ansible_vault': vstr}), cls=AnsibleJSONDecoder)
    assert isinstance(data, AVU) and data.vault._secrets == [secr.encode()]
    dl = DataLoader()
    vdata = dl.load_from_file

# Generated at 2022-06-11 08:37:53.217620
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    def an_object_hook_test_fixture(json_key_value_map):
        x = {'k': 'v'}
        return x

    decoder = AnsibleJSONDecoder()
    decoder.object_hook = an_object_hook_test_fixture
    assert decoder.object_hook({'k': 'v'}) == {'k': 'v'}

# Generated at 2022-06-11 08:38:04.005532
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets([ "password" ])
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n6162636465666768696a6b6c6d6e6f707172737475767778797a0a\n'}
    ansible_vault_object_hook = ansible_json_decoder.object_hook(pairs)

# Generated at 2022-06-11 08:38:14.139985
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Given
    json_proper_format = {
        "a": "b",
        "c": "d",
        "e": "f",
        "__ansible_vault": "vault(test1)",
        "__ansible_unsafe": "$test2"
    }

    # When
    AnsibleJSONDecoder._vaults['default'] = VaultLib({'test1': 'test1', 'test2': 'test2'})
    ansible_json_decoder = AnsibleJSONDecoder()
    dict_result = json.loads(json.dumps(json_proper_format), cls=ansible_json_decoder)

    # Then
    assert dict_result["a"] == "b"
    assert dict_result["c"] == "d"

# Generated at 2022-06-11 08:38:24.706802
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json

    secrets = ['my_secret_value']

    # __ansible_vault section