

# Generated at 2022-06-11 08:28:33.751036
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    my_decoder = AnsibleJSONDecoder()
    json_dict = my_decoder.object_hook({'__ansible_vault': 'fake_vault'})
    assert json_dict == AnsibleVaultEncryptedUnicode('fake_vault')



# Generated at 2022-06-11 08:28:40.906844
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n363533376263393563363162390a39353362396332333962353164636532353\n66393837626331653239373035346536620a6433383664656531623166393334\n3166613432346266663864396463336538353265643436306437323835643639\n66346561383239336466\n',
        '__ansible_unsafe': "REDACTED",
    }

    json.loads(json.dumps(d), cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:28:50.960604
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Confirm it handles UTF-16 json cleanly
    class MyUnicode(object):
        def __init__(self, unicode_string):
            self.unicode_string = unicode_string

        def __str__(self):
            return self.unicode_string

    class MyJson(object):
        def __init__(self, data):
            self.data = data

    decrypt_str = 'this str should not be encrypted'
    data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
            '__ansible_unsafe': MyJson(MyUnicode(decrypt_str))}
    secrets = 'ansible'
    value = AnsibleVaultEncryptedUnicode(data['__ansible_vault'])
    value.v

# Generated at 2022-06-11 08:28:57.141535
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    variable_1 = b'{"__ansible_vault": "AQDjSbdsav+903x2L8CZ4H4hKAhsmg+4a0bDehBpJq0cEdyrwk9XgxOeZdR\n2YBS5IA5D+"}'
    payload = decoder.decode(variable_1)

    assert '__ansible_vault' in payload
    assert isinstance(payload['__ansible_vault'], AnsibleVaultEncryptedUnicode) == True


# Generated at 2022-06-11 08:29:01.903360
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "vault_data"}'
    vault_pass = 'pass'
    decoded = AnsibleJSONDecoder.object_hook(json.loads(json_str))
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault is None
    AnsibleJSONDecoder.set_secrets([vault_pass])
    decoded = AnsibleJSONDecoder.object_hook(json.loads(json_str))
    assert decoded.vault._secrets[0] == vault_pass

# Generated at 2022-06-11 08:29:12.915092
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['my_secret'])
    decoder._vaults['other'] = VaultLib(secrets=['other_secret'])

    # Case with Vault
    expected = {'private_key': AnsibleVaultEncryptedUnicode('enc_data', vault=decoder._vaults['default'])}

# Generated at 2022-06-11 08:29:24.273919
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Try with empty json
    try:
        AnsibleJSONDecoder([]).object_hook({})
    except Exception as e:
        raise AssertionError('Caught exception when object_hook was called with empty json') from e

    # Try with empty json and a "__ansible_vault" key
    try:
        AnsibleJSONDecoder([]).object_hook({'__ansible_vault': 'AAAAAA'})
    except Exception as e:
        raise AssertionError('Caught exception when object_hook was called with empty json and "__ansible_vault" key') from e

    # Try with empty json, a "__ansible_unsafe" key and a __ansible_vault key

# Generated at 2022-06-11 08:29:35.062550
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    plaintext = 'Sample string'
    json_plaintext = json.dumps(plaintext)
    encrypted_output = ['$ANSIBLE_VAULT;1.2;AES256', '3736646637373366303864386538373630336430656534383539646537376433353738303334646330', '306634393739636331303762616532653232']
    encrypted_unencrypted_output = '\n'.join(encrypted_output)
    import base64


# Generated at 2022-06-11 08:29:44.733625
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'foo'
    vault = VaultLib(secrets=secrets)
    AnsibleJSONDecoder.set_secrets(secrets=secrets)
    # Test for ansible vault
    data = {'__ansible_vault': 'encrypted_value'}
    ansible_vault = AnsibleJSONDecoder().object_hook(data)
    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)
    assert ansible_vault.vault == vault
    # Test for unsafe_proxy
    data['__ansible_unsafe'] = 'unsafe_value'
    ansible_unsafe = AnsibleJSONDecoder().object_hook(data)
    assert isinstance(ansible_unsafe, dict)

# Generated at 2022-06-11 08:29:55.256260
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:03.744947
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    j_dict = {'__ansible_vault': 'vault_val', '__ansible_unsafe': 'unsafe_val'}
    result_dict = decoder.object_hook(j_dict)
    assert type(result_dict['__ansible_vault']) == AnsibleVaultEncryptedUnicode
    assert type(result_dict['__ansible_unsafe']) == AnsibleUnsafeText



# Generated at 2022-06-11 08:30:14.745663
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_yaml = '''
        - hosts: all
          tasks:
            - name: Regular task line
              yum:
                name: "{{ packages }}"
                state: present
    '''

# Generated at 2022-06-11 08:30:25.467885
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import AnsibleJSONDecoder
    #the vault_secret is not required to pass the test because __ansible_vault is not tested
    vault_secret = None
    # create a vault object
    vault = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n1234567890123456789012345678901234567890')
    # create a unsafe object
    unsafe = wrap_var(u'unsafe object')
    # create a json object with vault and unsafe
    input_json = {'__ansible_vault': '1234567890123456789012345678901234567890',
                  '__ansible_unsafe': 'unsafe object'}
    # create an Ansible

# Generated at 2022-06-11 08:30:31.488494
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"__ansible_vault": "vault_text", "__ansible_unsafe": "unsafe_text"}
    json_data = json.loads(json.dumps(data), cls=AnsibleJSONDecoder)
    assert json_data["__ansible_vault"] == "vault_text"
    assert json_data["__ansible_unsafe"] == "unsafe_text"


# Generated at 2022-06-11 08:30:38.025132
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:49.220438
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets(['test'])


# Generated at 2022-06-11 08:30:59.806417
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data1 = {'__ansible_vault': AnsibleVaultEncryptedUnicode('my_value1')}
    data2 = {'__ansible_unsafe': 'unsafe_value'}
    value1 = AnsibleJSONDecoder().object_hook(data1)
    value2 = AnsibleJSONDecoder().object_hook(data2)
    assert value1 == data1['__ansible_vault']
    assert value2 == wrap_var(data2['__ansible_unsafe'])
    assert isinstance(data1['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(value2, wrap_var)



# Generated at 2022-06-11 08:31:09.163475
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """unit testing for AnsibleJSONDecoder object_hook function"""
    decoder = AnsibleJSONDecoder()

    pairs_dict = dict()
    pairs_dict['__ansible_vault'] = 'abcd'
    pairs_dict['__ansible_unsafe'] = 'efgh'

    pairs_dict_1 = dict()
    pairs_dict_1['__ansible_vault'] = 'efgh'

    ansible_vault_obj = decoder.object_hook(pairs_dict)
    ansible_unsafe_obj = decoder.object_hook(pairs_dict_1)

    assert isinstance(ansible_vault_obj, AnsibleVaultEncryptedUnicode)
    assert ansible_vault_obj.vault, "vault object is not created; object_hook function not working"

# Generated at 2022-06-11 08:31:18.616997
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:31:23.991762
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secret = 'secret'
    decoder.set_secrets(secret)

    assert decoder.object_hook({'__ansible_vault': 'value1'}).vault.secrets == secret
    assert decoder.object_hook({'__ansible_unsafe': 'value1'}).__ansible_unsafe__ == True

# Generated at 2022-06-11 08:31:31.536056
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    pairs={'__ansible_unsafe': "mysecret"}
    pairs2={'__ansible_vault': "mysecret"}

    assert decoder.object_hook(pairs) == wrap_var(pairs['__ansible_unsafe'])
    assert isinstance(decoder.object_hook(pairs2), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:31:35.941917
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "foobar", "__ansible_unsafe": "foobar"}

    result = decoder.object_hook(pairs)

    assert isinstance(result, dict)
    assert isinstance(result["__ansible_vault"], AnsibleVaultEncryptedUnicode)
    assert isinstance(result["__ansible_unsafe"], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:31:45.591050
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.__init__ import __version__ as ansible_version
    assert ansible_version != '', \
        "Unable to import variable '__version__' from ansible module"

    vault_pwd = 'secret'

# Generated at 2022-06-11 08:31:56.689048
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # The expected data structure does not need to be JSON serializable
    # so we disable the loop detection check.
    import sys
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    sys._getframe = lambda level: None

    # Set default secret
    secrets = ['foo']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test object_hook with AnsibleVaultEncryptedUnicode
    data = {"__ansible_vault": '2.1$f70798b4c4201c15d9a75b9a8077ba2c8bc3fc57b053e9835ec10f8dc8cdb78a'}
    expected = AnsibleVaultEncryptedUnic

# Generated at 2022-06-11 08:32:04.931512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secrets = [b'11', b'22']

# Generated at 2022-06-11 08:32:14.262541
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # wrap_var
    assert AnsibleJSONDecoder.object_hook({u'__ansible_unsafe': u'@'}) == wrap_var(u'@')
    # ansible_vault
    v = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;blah\nblah\nblah'}
    assert AnsibleJSONDecoder.object_hook(v) == AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256;blah\nblah\nblah')
    # not ansible_unsafe
    assert AnsibleJSONDecoder.object_hook({u'not': u'ansible_unsafe'}) == {u'not': u'ansible_unsafe'}
    


# Generated at 2022-06-11 08:32:23.665102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Prepare b64 encoded vault and unsafe text
    vault_text = '$ANSIBLE_VAULT;1.1;AES256;test\n65383861666134646362646162373066623238356164633831346331383837663339653230\n376336323239373532616138303730393730323730326666326266650a3361323038353363\n36396436303765376638393330656434353664663961303935313130663733643834396466\n6332313331656536666534376636393565393363610a'
    vault_b64encoded = vault_text.encode('utf-8').encode('base64').strip()

    unsafe_text

# Generated at 2022-06-11 08:32:32.571976
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    arg_pairs = {
        '__ansible_vault': 'ASDWQEEWSDWQ',
        '__ansible_unsafe': 'ASDWQEEWSDWQ',
    }
    AnsibleJSONDecoder._vaults['default'] = VaultLib(secrets=['ASDWQEEWSDWQ'])
    object_hook = AnsibleJSONDecoder.object_hook(None, arg_pairs)
    assert object_hook.get('__ansible_vault') == 'ASDWQEEWSDWQ'
    assert object_hook.get('__ansible_unsafe') == 'ASDWQEEWSDWQ'



# Generated at 2022-06-11 08:32:40.520656
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    raw_data = [
        (
            '''{"__ansible_vault": "test"}''',
            AnsibleVaultEncryptedUnicode('test')
        ),
        (
            '''{"__ansible_unsafe": "test"}''',
            wrap_var('test')
        ),
        (
            '''{"normal": "test"}''',
            {'normal': 'test'}
        )
    ]

    for data in raw_data:
        result = AnsibleJSONDecoder().object_hook(json.loads(data[0]))
        assert result == data[1]

# Generated at 2022-06-11 08:32:52.621460
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '{ "__ansible_vault": "9AOEruhAl7kYwvRApWxjGw==", "__ansible_unsafe": "--unsafe text--"  }'
    secret_key = 'password'
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    ansible_json_decoder.set_secrets(secret_key)
    # decode json
    json_dict_decoded = json.loads(json_string, cls=ansible_json_decoder)
    assert json_dict_decoded['__ansible_vault'] == "9AOEruhAl7kYwvRApWxjGw=="

# Generated at 2022-06-11 08:33:01.380743
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    l = json.loads('{"__ansible_vault": "hello", "__ansible_unsafe": "world"}', cls=AnsibleJSONDecoder)
    assert isinstance(l['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert l['__ansible_vault'].vault is None
    assert l['__ansible_unsafe'].password == 'world'
    assert l['__ansible_unsafe'].encoding == 'utf-8'


# Generated at 2022-06-11 08:33:09.392682
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_input = '{"__ansible_vault": "vaulted_object", "__ansible_unsafe": "unsafe_object", "regular_object": "regular_object"}'
    test_output = {'__ansible_vault': u'vaulted_object', '__ansible_unsafe': b'unsafe_object', 'regular_object': u'regular_object'}

    answer = json.loads(test_input, cls=AnsibleJSONDecoder)
    assert answer == test_output, 'object_hook did not convert the objects as expected'



# Generated at 2022-06-11 08:33:19.337609
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    for input in [
            # dict with __ansible_vault
            {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'},
            # dict with __ansible_unsafe
            {'__ansible_unsafe': '!!!python/str:ansible.parsing.yaml.objects.SafeText'},
    ]:
        res = AnsibleJSONDecoder().object_hook(input)

        # assert type is AnsibleVaultEncryptedUnicode
        assert(type(res) is AnsibleVaultEncryptedUnicode or type(res) is AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-11 08:33:26.766938
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secrets = [{'some': 'default'}]
    decoder.set_secrets(secrets)

    assert decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'})
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe_variable_name'})

# Generated at 2022-06-11 08:33:35.020296
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({u'__ansible_vault': u'VAULT_DATA'}) == AnsibleVaultEncryptedUnicode(u'VAULT_DATA')
    assert decoder.object_hook({u'__ansible_unsafe': True}) == wrap_var(True)
    assert decoder.object_hook({u'__ansible_vault': u'VAULT_DATA', u'__ansible_unsafe': True}) == [AnsibleVaultEncryptedUnicode(u'VAULT_DATA'), wrap_var(True)]

# Generated at 2022-06-11 08:33:40.065529
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_vault': 'value_vault'}) is not None
    assert decoder.object_hook({'__ansible_unsafe': 'value_unsafe'}) is not None
    assert decoder.object_hook({'__ansible__': 'value_ansible'}) is not None

# Generated at 2022-06-11 08:33:50.750495
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['vaultpass'], vault_password_file='test/unit/myvaultpass')


# Generated at 2022-06-11 08:34:01.230380
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:34:10.691102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [dict(secret1='test1'), dict(secret2='test2'), dict(secret3='test3')]

# Generated at 2022-06-11 08:34:19.997036
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [ b'$ANSIBLE_VAULT;1.2;AES256;ansible\no298455713651351' ]

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder.set_secrets(secrets)

    # pylint: disable=unused-variable
    test_data = {
        'test': "test",
        '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;ansible\no298455713651351',
        '__ansible_unsafe': '$ANSIBLE_VAULT;1.2;AES256;ansible\no298455713651351'
    }


# Generated at 2022-06-11 08:34:31.457311
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # given this data on input
    PAYLOAD = '''
{
    "name": "test name",
    "password": "test password",
    "__ansible_vault": "secret"
}
    '''
    # when we call the object_hook function
    ansible_json_decoder = AnsibleJSONDecoder(PAYLOAD)
    ansible_json_decoder.set_secrets(['test secret'])
    data = ansible_json_decoder.object_hook(PAYLOAD)
    # then we should get this data on output
    EXPECTED = {
        'name': 'test name',
        'password': 'test password',
        '__ansible_vault': 'secret',
        }
    assert data == EXPECTED

# Generated at 2022-06-11 08:34:36.530196
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = json.loads('{"__ansible_unsafe": "foo", "__ansible_vault": "bar"}', cls=AnsibleJSONDecoder)
    assert result == {'__ansible_unsafe': wrap_var('foo'), '__ansible_vault': AnsibleVaultEncryptedUnicode('bar')}



# Generated at 2022-06-11 08:34:47.203290
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # There is no __ansible_vault and __ansible_unsafe key
    json_dict = {"a": "b"}
    assert decoder.object_hook(json_dict) == json_dict
    # There is a __ansible_vault key but no __ansible_unsafe key
    json_dict = {"a": "b", "__ansible_vault": "c"}
    assert decoder.object_hook(json_dict) == AnsibleVaultEncryptedUnicode("c")
    # There is a __ansible_unsafe key but no __ansible_vault key
    json_dict = {"a": "b", "__ansible_unsafe": "c"}
    assert decoder.object_hook(json_dict) == wrap_var("c")


# Generated at 2022-06-11 08:34:55.566535
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = decoder.object_hook({'__ansible_unsafe': '{{ test }}', '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\r\n38363837323837336333316233653231306565666639343730653364613735373966623234\r\n36663338376238653635343037343233653333353330393835383562643230666234373230\r\n37353639353865383365333337353231316565353730643963383664656566633138383464\r\n36323563313636353438396664343338333836\r\n'})

# Generated at 2022-06-11 08:35:06.335325
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 08:35:17.204597
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # AnsibleVaultEncryptedUnicode object case
    dict_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n3772626262316532393238316464386534643763343361343633313863333037323930393530376237\n3938353739623164633863386437616361333133353061303231363733353537616434396530323535\n3933373830343930663334373035363136656239633763313062323166656365656339623138666538\n6565353430303139303764356636643561363364\n'}
    ret

# Generated at 2022-06-11 08:35:26.331803
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    vault_pairs = {"__ansible_vault": "xxxxx"}
    vault_result = decoder.object_hook(vault_pairs)
    assert repr(vault_result) == repr(vault_pairs)
    unsafe_pairs = {"__ansible_unsafe": {"x": "xxxxx"}}
    unsafe_result = decoder.object_hook(unsafe_pairs)
    assert repr(unsafe_result) == repr(unsafe_pairs)
    none_result = decoder.object_hook({})
    assert repr(none_result) == repr({})

# Generated at 2022-06-11 08:35:34.250739
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {
        "foo": "bar",
        "__ansible_vault": "vaultpassword",
        "__ansible_unsafe": "http://example.com/api/users/12345/",
    }
    result = decoder.object_hook(pairs)
    assert isinstance(result, dict)
    assert 'foo' in result
    assert result['__ansible_vault'] == "vaultpassword"
    assert result['__ansible_unsafe'] == "http://example.com/api/users/12345/"

# Generated at 2022-06-11 08:35:42.762944
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import ansible_native_override_defaults

# Generated at 2022-06-11 08:35:52.349817
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # single instance of decoder
    data = AnsibleJSONDecoder().decode('{"__ansible_unsafe": "unsafe"}')
    assert data == {'__ansible_unsafe': 'unsafe'}
    # multiple instances of decoder,
    # as this part is also used in ansible.parsing.dataloader
    data = AnsibleJSONDecoder().decode('{"__ansible_unsafe": "unsafe"}')
    assert data == {'__ansible_unsafe': 'unsafe'}


# Generated at 2022-06-11 08:36:01.976993
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '{"__ansible_unsafe": "unsafe"}'
    json_dict = {"__ansible_unsafe": "unsafe"}

    # test when key __ansible_unsafe exists in json_string
    json_dict_from_json_string = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert json_dict_from_json_string == json_dict

    # test when key __ansible_unsafe not exists in json_string
    json_dict_from_json_string = json.loads('{}', cls=AnsibleJSONDecoder)
    assert json_dict_from_json_string == {}


# Generated at 2022-06-11 08:36:11.601282
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1', 'secret2']
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    data_loader._vault.secrets = secrets

    decoder = AnsibleJSONDecoder()

    # Is it really necessary to use a variable to store the result of object_hook?
    pairs = {
        '__ansible_vault': 'value',
        '__ansible_unsafe': 'value',
    }

    result = decoder.object_hook(pairs)

    # The correct way to get the result of object_hook is by returning this
    # variable?
    assert result == {
        '__ansible_vault': 'value',
        '__ansible_unsafe': 'value',
    }

# Generated at 2022-06-11 08:36:20.924387
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    pairs1 = decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n34356433396562656339316662303435356335396336663262616234336233346630363563653563\na85a4f25c966b4d4bb08c6fbd87d8fdb2bba6d4c6d4b6cdf9f9a148777eeda4a\n'})
    assert isinstance(pairs1, AnsibleVaultEncryptedUnicode), "decoder.object_hook() is not AnsibleVaultEncryptedUnicode"


# Generated at 2022-06-11 08:36:31.624623
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Create test object instance
    ansible_json_decoder = AnsibleJSONDecoder()

    # Test object_hook method

# Generated at 2022-06-11 08:36:42.079497
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_encoded = '''
    {
        "__ansible_unsafe": {
            "__ansible_type__": "string",
            "__ansible_value__": "abc"
        },
        "__ansible_vault": {
            "__ansible_type__": "str",
            "__ansible_value__": "123"
        }
    }'''
    json_decoder = AnsibleJSONDecoder()
    data = json_decoder.decode(json_encoded)
    assert isinstance(data, dict)
    assert isinstance(data['__ansible_unsafe'], list)
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-11 08:36:51.625659
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # backup the original vault
    global orig_vaults
    orig_vaults = AnsibleJSONDecoder._vaults


# Generated at 2022-06-11 08:36:57.702989
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vars = {"a": {"__ansible_vault": "vault_value", "__ansible_unsafe": True}}
    vars_str = '{"a": {"__ansible_vault": "vault_value", "__ansible_unsafe": true}}'
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook(vars) == json.loads(vars_str)



# Generated at 2022-06-11 08:37:06.412623
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    templar = Templar(None)

# Generated at 2022-06-11 08:37:15.813117
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for vault
    AnsibleJSONDecoder.set_secrets(['test'])
    data = '[{"ansible_facts": {"__ansible_vault": "vault-value"}}]'
    assert json.loads(data, cls=AnsibleJSONDecoder)[0]['ansible_facts']['__ansible_vault'].vault.secrets == ['test']

    # Test for unsafe
    data = '[{"ansible_facts": {"__ansible_unsafe": "unsafe-value"}}]'
    assert json.loads(data, cls=AnsibleJSONDecoder)[0]['ansible_facts']['__ansible_unsafe'].value == 'unsafe-value'

# Generated at 2022-06-11 08:37:20.270128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = json.loads(json.dumps({"__ansible_vault": {"__ansible_vault": ""}}), cls=AnsibleJSONDecoder)
    assert isinstance(decoded['__ansible_vault']["__ansible_vault"], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:37:32.229291
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    _vault_test_data = [
        {
            'input': {'__ansible_vault': 'test'},
            'output': AnsibleVaultEncryptedUnicode('test'),
        },
        {
            'input': {'__ansible_unsafe': 'test'},
            'output': b'test',
        },
        {
            'input': 'test',
            'output': 'test',
        }
    ]

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    for test in _vault_test_data:
        assert decoder.object_hook(test['input']) == test['output']

# Generated at 2022-06-11 08:37:42.401642
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import UNSAFE_PROXY_TEXTS

    vault_secret = VaultSecret('secret')
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_vault': 'U2FsdGVkX1/zUI6UW8/CepZ5TFfsk80pPZG0Yb5Xl9c='}) == AnsibleVaultEncryptedUnicode('U2FsdGVkX1/zUI6UW8/CepZ5TFfsk80pPZG0Yb5Xl9c=')

# Generated at 2022-06-11 08:37:46.626311
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    json_dict = {b'__ansible_vault': 'value'}
    result = decoder.object_hook(json_dict)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-11 08:37:51.904440
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()

    value = encoder.encode(dict(
        foo="bar",
        __ansible_unsafe={"secret": "secret"},
        baz="quux",
    ))
    decoded = decoder.decode(value)
    assert isinstance(decoded['foo'], str)
    assert isinstance(decoded['baz'], str)
    assert decoded['__ansible_unsafe']['secret'] == 'secret'

# Generated at 2022-06-11 08:37:58.326643
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_obj = AnsibleJSONDecoder().object_hook(
        {'__ansible_vault': 'encrypted'}
        )
    assert isinstance(ansible_vault_obj, AnsibleVaultEncryptedUnicode)
    assert ansible_vault_obj._text == 'encrypted'
    assert ansible_vault_obj.vault
    assert ansible_vault_obj.vault.secrets == ['default']



# Generated at 2022-06-11 08:38:09.037663
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'password']
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-11 08:38:17.286587
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = json.loads("""{
      "__ansible_unsafe": "{{ some_password }}",
      "__ansible_vault": "AES256:1E/pY6NZGZAaMAx0D/h/+5r5QaN5xkVfZuLvlL3j7wg="
        }""", cls=AnsibleJSONDecoder, parse_float=None, parse_int=None, parse_constant=None, object_pairs_hook=None)

    assert json_data['__ansible_unsafe'] == wrap_var("{{ some_password }}")

# Generated at 2022-06-11 08:38:27.931704
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:38:33.400189
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'test'
    # Use the AnsibleJSONDecoder class itself to parse the vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    vault = decoder.decode('{"__ansible_vault": "my vault"}')
    assert vault.vault.secrets == 'test'

    unsafe = decoder.decode('{"__ansible_unsafe": "my unsafe"}')
    assert unsafe.obj == 'my unsafe'