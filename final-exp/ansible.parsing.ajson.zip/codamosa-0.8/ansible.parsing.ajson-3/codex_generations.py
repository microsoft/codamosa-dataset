

# Generated at 2022-06-11 08:28:34.323291
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode(u'test')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'text'}) == wrap_var('text')

# Generated at 2022-06-11 08:28:41.840809
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set up secrets for the vault
    secrets = ['secret1', 'secret2', 'secret3']

    # Create the encrypted data
    # this is the format of the data that is created when using the vault

# Generated at 2022-06-11 08:28:48.010322
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    text = b'{\n    "__ansible_unsafe": "Vm0wd2QyUXlVWGxWV0d4V1YwZDRWMVl3WkRSV01WbDNXa1JTVjAxV2JETlhhMUpUVmpBeFYySkVU"\n}'
    secrets = [b'password']
    result = AnsibleJSONDecoder.decode(text)
    assert result['__ansible_unsafe'] == 'I love you'

# Generated at 2022-06-11 08:28:57.192123
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    secrets = [b'secret0', b'secret1']

    # test AnsibleVaultEncryptedUnicode
    pairs = {'__ansible_vault': b'encrypted'}
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    decoded = decoder.object_hook(pairs)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)
    assert decoded.vault._secrets == secrets
    assert decoded._txt == b'encrypted'

    # test AnsibleUnsafeText / wrap_var

# Generated at 2022-06-11 08:29:03.452814
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible_vault and ansible_unsafe case
    my_dumps = json.dumps({
        '__ansible_vault': 'my_ansible_vault_value',
        '__ansible_unsafe': 'my_ansible_unsafe_value',
        '__ansible_normal': 'my_ansible_normal_value'
    }, cls=AnsibleJSONEncoder)
    my_pairs = json.loads(my_dumps, cls=AnsibleJSONDecoder)
    assert my_pairs['__ansible_vault'] == 'my_ansible_vault_value'
    assert my_pairs['__ansible_unsafe'].data == 'my_ansible_unsafe_value'

# Generated at 2022-06-11 08:29:10.769569
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "asd123"}'
    ansible_vault_json_decoder = AnsibleJSONDecoder(json_str)
    ansible_vault_json_decoder.set_secrets(['test'])
    ansible_vault = ansible_vault_json_decoder.decode(json_str)['__ansible_vault']
    assert ansible_vault.vault.secrets == ['test']

# Generated at 2022-06-11 08:29:16.433569
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert json.loads('{"__ansible_vault": "test"}', cls=AnsibleJSONDecoder) == {'__ansible_vault': 'test'}
    assert json.loads('{"__ansible_unsafe": "test"}', cls=AnsibleJSONDecoder) == {'__ansible_unsafe': 'test'}
    assert json.loads('{"test": "test"}', cls=AnsibleJSONDecoder) == {'test': 'test'}

# Generated at 2022-06-11 08:29:27.560567
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:37.838096
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # arrange
    object_hook_test = AnsibleJSONDecoder()
    test_obj = {"__ansible_vault": "4e596077"}

    # act
    ansible_vault_obj = object_hook_test.object_hook(test_obj)
    # assert
    assert isinstance(ansible_vault_obj, AnsibleVaultEncryptedUnicode)
    assert ansible_vault_obj == "4e596077"

    # arrange
    object_hook_test = AnsibleJSONDecoder()
    test_obj = {"__ansible_unsafe": "hostname"}

    # act
    ansible_vault_obj = object_hook_test.object_hook(test_obj)
    # assert

# Generated at 2022-06-11 08:29:44.412463
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:56.015799
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secret = 'secret'
    decoder.set_secrets(secret)

    # test __ansible_vault
    data_encrypted = {'__ansible_vault': 'secret'}
    data_decrypted = decoder.decode(json.dumps(data_encrypted))
    assert data_decrypted == AnsibleVaultEncryptedUnicode('secret')
    assert data_decrypted.vault == decoder._vaults['default']
    assert data_decrypted.vault.secrets == secret

    # test __ansible_unsafe
    data = {'__ansible_unsafe': secret}
    assert decoder.decode(json.dumps(data)) == wrap_var(secret)

    # test non __ansible_* key

# Generated at 2022-06-11 08:30:06.510346
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap
    from ansible.parsing.yaml.loader import AnsibleLoader

    json_obj = '{"dict1": {"__ansible_vault": "vault_value"}, "__ansible_unsafe": "123"}'

# Generated at 2022-06-11 08:30:16.651164
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Different scenarios during test
    # 1. The key is not '__ansible_vault', and the value is not a dict
    # 2. The key is '__ansible_vault' and the value is not a dict
    # 3. The key is '__ansible_vault' and the value is a dict
    # 4. The value is a dict with keys and values
    # 5. The value is a dict with keys but no value

    # First argument is always pairs
    pairs = {}

    # First test
    pairs['key'] = 'value'
    d = AnsibleJSONDecoder()
    ret = d.object_hook(pairs)
    assert ret == pairs

    # Second test
    pairs = {'__ansible_vault': 'value'}
    ret = d.object_hook(pairs)

# Generated at 2022-06-11 08:30:27.358187
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = """
{
    "__ansible_unsafe": "{{ var_to_unwrap }}",
    "__ansible_vault": "{$ANSIBLE_VAULT;1.1;AES256;ansible$d3NqV2JNNmJ0TFlXY2lhcFlJdDNmT0pDbXZOUzUyNndUZTV0bHdTcw==$Y73oJMsnVdbaC6X9NS6MIMFR6Uedx6Dh+lYriwVy1p0=}"
}
"""

# Generated at 2022-06-11 08:30:31.741336
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test'}) == \
           AnsibleVaultEncryptedUnicode('test')

    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'test'}) == \
           wrap_var('test')

# Generated at 2022-06-11 08:30:38.217066
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    data = '{"__ansible_unsafe": "{{ var }}", "__ansible_vault": "vault"}'
    result = decoder.decode(data)
    assert isinstance(result['__ansible_unsafe'], wrap_var)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault


# We may want to remove this class in the future
# but for now we're keeping it for backwards compatibility

# Generated at 2022-06-11 08:30:49.347774
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault = '$ANSIBLE_VAULT;1.1;AES256\n35393837383562336635333766333564383436373462316262636239663633306265373564613430\n623263303466383435333938343533343332636231643133306634350a3335343334633962656635\n66343964313565396338636562326264653936333564613961366131623066323162366134613731\n36656232623234623061616561323063'
    json_value_ansible_vault = '{"__ansible_vault": "' + ansible_vault + '"}'
    json_value_ansible_vault_dec

# Generated at 2022-06-11 08:31:01.370119
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test data
    x = {'__ansible_vault': 'ANSIBLE_VAULT;1.2;AES256\n3275734e5535686659706778753670634a6f344a774941517247314a58427447'}
    y = {'__ansible_unsafe': '$ecret'}

    # Unit test
    a = AnsibleJSONDecoder()
    assert isinstance(a.object_hook(x), AnsibleVaultEncryptedUnicode)
    assert isinstance(a.object_hook(y), str)

# Generated at 2022-06-11 08:31:11.760532
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    d = AnsibleJSONDecoder()
    d.set_secrets(['secret1', 'secret2'])

    # Test a AnsibleVaultEncryptedUnicode object
    json_str = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;abcdefghijklmnop\nabcdefghijklmnop"}'
    object_hook_result = d.object_hook(json.loads(json_str))
    assert isinstance(object_hook_result, AnsibleVaultEncryptedUnicode)
    assert isinstance(object_hook_result.vault, VaultLib)

    # Test an unsafe dictionary
    # The "__ansible_unsafe" key

# Generated at 2022-06-11 08:31:12.485866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert 0

# Generated at 2022-06-11 08:31:20.631976
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['hunter2']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:31:27.913088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '1234'
    AnsibleJSONDecoder.set_secrets([secret])
    data_in = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;default\n'}
    data_out = json.loads(json.dumps(data_in), cls=AnsibleJSONDecoder)
    assert hasattr(data_out, 'vault')
    assert data_out.vault.secrets == [secret]



# Generated at 2022-06-11 08:31:38.294827
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Arrange
    decoder = AnsibleJSONDecoder()
    decoder.vault = VaultLib()

    # This is the test data that contains several __ansible_vault objects
    # (see its JSON representation below)
    test_data = {u'__ansible_vault': u'version 1',
                 u'__ansible_unsafe': True,
                 u'this_is_a_var': u'Hello',
                 u'with_a_json_obj': [u'foo', u'bar'],
                 u'nested_ansible_vault_obj': {u'__ansible_vault': u'version 2'}}
    # JSON representation of the test data

# Generated at 2022-06-11 08:31:46.899902
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoded_dict = json.dumps({'a': 'b'}, cls=AnsibleJSONEncoder)

    decoded_dict = json.loads(encoded_dict, cls=AnsibleJSONDecoder)
    assert type(decoded_dict) == dict
    assert decoded_dict['a'] == 'b'

    # username:password
    encoded_dict = json.dumps({'__ansible_vault': 'credential'}, cls=AnsibleJSONEncoder)

    decoded_dict = json.loads(encoded_dict, cls=AnsibleJSONDecoder)
    assert type(decoded_dict) == AnsibleVaultEncryptedUnicode
    assert decoded_dict == 'credential'

    # username:password

# Generated at 2022-06-11 08:31:57.997326
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test __ansible_vault:spam
    json_string = b'{"__ansible_vault": "spam"}'
    vault_string = b'{"__ansible_vault": "spam"}'
    decode_string = json.loads(json_string, cls=AnsibleJSONDecoder)

    assert vault_string == AnsibleJSONEncoder().encode(decode_string)

    # Test __ansible_unsafe:spam
    json_string = b'{"__ansible_unsafe": "spam"}'
    vault_string = b'{"__ansible_unsafe": "spam"}'
    decode_string = json.loads(json_string, cls=AnsibleJSONDecoder)

    assert vault_string == AnsibleJSONEncoder().encode(decode_string)

# Generated at 2022-06-11 08:32:05.482308
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import json

    test_json_data = {"string": "test_string", "num": 123,
                      "list": ["a", "list", "of", "strings"],
                      "dict": {"key1": "value1", "key2": "value2"},
                      "unicode": u'\u00e9',
                      "__ansible_vault": "test_vault",
                      "__ansible_unsafe": "test_unsafe"}
    test_json_data_json = json.dumps(test_json_data)

    # test default return value
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:32:12.042601
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_decoder = AnsibleJSONDecoder()
    assert json_decoder.object_hook({'__ansible_vault': 'value_ansible_vault'}) == AnsibleVaultEncryptedUnicode('value_ansible_vault')
    assert json_decoder.object_hook({'__ansible_unsafe': 'value_ansible_unsafe'}) == wrap_var('value_ansible_unsafe')
    assert json_decoder.object_hook({'key': 'value'}) == {'key': 'value'}

# Generated at 2022-06-11 08:32:18.591424
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_dict = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;'
                    '6368616e676520746869732070617373776f726420746f206120736563726574',
        '__ansible_unsafe': {
            'hello': 'world',
        }
    }

    before = '$ANSIBLE_VAULT;1.1;AES256;' \
             '6368616e676520746869732070617373776f726420746f206120736563726574'

    after = 'change this password to a secret'

    # init json decoder
    jsonDecoder = AnsibleJSONDecoder()
    # init vault with secret
    jsonDecoder.set_

# Generated at 2022-06-11 08:32:26.080022
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:32:35.146314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(password=None, secrets=['test'])

    # Test for AnsibleVaultEncryptedUnicode
    test_data = {"__ansible_vault": "test"}
    result = decoder.object_hook(test_data)
    assert result.__class__.__name__ == "AnsibleVaultEncryptedUnicode"

    # Test for wrap_var
    test_data = {"__ansible_unsafe": "test"}
    result = decoder.object_hook(test_data)
    assert result.__class__.__name__ == "AnsibleUnsafeText"

# Generated at 2022-06-11 08:32:49.247541
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    assert {'__ansible_vault': 'password'} == decoder.object_hook({u'__ansible_vault': 'password'})

    assert {'__ansible_vault': 'password', 'hey': 'hello'} == decoder.object_hook({u'__ansible_vault': 'password', u'hey': 'hello'})

    assert {'__ansible_vault': 'password'} == decoder.object_hook({u'hey': 'hello', u'__ansible_vault': 'password'})


# Generated at 2022-06-11 08:32:56.510533
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc_value = b'\x00\x05\x02\x19\x03\x8c\x9f\x88\x0e\xfc\xce\x06\xcb\xa4\xdc\xc2\x89\xdd\x81\x06\x1d\x1a\xa1\xd7\x8a\xc2\x99\x94\xe4\x8e\x89\x9b\x1f\xdf\xca\x00\x96\x87\x08\x04\xe9\xa1\x87\x9c'

# Generated at 2022-06-11 08:33:07.835318
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:16.929974
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:28.283187
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:33.208636
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pair = {'__ansible_vault': 'test', '__ansible_unsafe': 'test2'}
    result = AnsibleJSONDecoder.object_hook(pair)
    assert result == {'__ansible_vault': 'test', '__ansible_unsafe': 'test2'}


# Generated at 2022-06-11 08:33:40.921057
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class A():
        def __init__(self, x):
            self.x = x

        def __eq__(self, other):
            return self.x == other.x

    a = A(42)

    assert json.loads('{"x": 42}', cls=AnsibleJSONDecoder) == {"x": 42}
    assert json.loads('{"__ansible_unsafe": {"x": 42}}', cls=AnsibleJSONDecoder) == a
    assert json.loads('{"__ansible_vault": "x"}') == AnsibleVaultEncryptedUnicode('x')

# Generated at 2022-06-11 08:33:48.865557
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # GIVEN: A variable to be converted to AnsibleVaultEncryptedUnicode
    variable = '$ANSIBLE_VAULT;1.1;AES256'

    # WHEN: Call the method object_hook with a dict that contains the variable
    ansible_json_decoder = AnsibleJSONDecoder()
    result = ansible_json_decoder.object_hook({'__ansible_vault': variable})

    # THEN: The result should be an AnsibleVaultEncryptedUnicode object
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:33:53.681412
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder()
    test_dict = {'__ansible_vault': 'some_value'}
    assert isinstance(jd.object_hook(test_dict), dict)
    assert isinstance(jd.object_hook(test_dict)['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:34:01.170450
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # GIVEN
    decoder = AnsibleJSONDecoder()

    # WHEN
    data = {'__ansible_unsafe': 'world'}
    decoded = decoder.object_hook(data)

    # THEN
    assert decoded.__class__.__name__ == 'AnsibleUnsafeText'
    assert decoded == 'world'

    # WHEN
    data = {'__ansible_vault': 'world'}
    decoded = decoder.object_hook(data)

    # THEN
    assert decoded.value == 'world'


# Generated at 2022-06-11 08:34:13.774805
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class Test_class(object):
        def __init__(self, my_var):
            self.my_var = my_var
        def set_secrets(cls, secrets):
            cls._vaults = {'default': VaultLib(secrets=secrets)}

    tst = Test_class('test')
    my_str = '{"__ansible_vault": "test"}'
    my_secrets = [b'\x89\xef9\x9e\xef\x8f\x0c\xc3\x01\x0f\x89S\x99\xbe\xd5\xb7\xac\x83U\xec\xa5\x8b\x1d\xaaJ\xef\xf8\x8d\x01\x19?']
   

# Generated at 2022-06-11 08:34:18.359789
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'foo', 'a': 'b'}) == AnsibleVaultEncryptedUnicode('foo')
    assert ('__ansible_unsafe', 'foo') in AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'foo', 'a': 'b'}).items()

# Generated at 2022-06-11 08:34:22.709903
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    value1 = '724a2a19d2cd51c5afc92ac7dd32cd9f'
    value2 = '__ansible_unsafe'
    decoder = AnsibleJSONDecoder(value1, value2)
    pairs = {}
    pairs[value1] = value2
    assert decoder.object_hook(pairs) == "value2"


# Generated at 2022-06-11 08:34:32.656027
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder._vaults == {}
    assert 'default' not in AnsibleJSONDecoder._vaults
    # Test when __ansible_vault is present but no vault password is set
    test_dict = {'__ansible_vault': 'somestring'}
    decoded_test_dict = AnsibleJSONDecoder().object_hook(test_dict)
    assert isinstance(decoded_test_dict, AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded_test_dict, dict)
    assert decoded_test_dict['__ansible_vault'] == 'somestring'
    assert '__ansible_vault' in decoded_test_dict
    assert AnsibleJSONDecoder._vaults == {}
    assert 'default' not in AnsibleJSONDecoder._

# Generated at 2022-06-11 08:34:43.710767
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:52.535279
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    with open("../test/test_vault_json.json") as f:
        loaded_json = json.load(f, cls=AnsibleJSONDecoder)

    decoder.set_secrets("hello")

    # vault data
    print("vault data:")
    for i in loaded_json['password']:
        print(i, loaded_json['password'][i])

    # unsafe data
    print("unsafe data:")
    for i in loaded_json['sensitive']:
        print(i, loaded_json['sensitive'][i])

    # normal data
    print("normal data:")
    for i in loaded_json['normal']:
        print(i, loaded_json['normal'][i])



# Generated at 2022-06-11 08:35:03.215082
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'password']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test for '__ansible_vault'

# Generated at 2022-06-11 08:35:12.580726
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()

    # vault
    vault_str = enc.encode(u'foo')
    assert vault_str == json.dumps({u'__ansible_vault': u'foo'}, cls=AnsibleJSONEncoder)
    assert dec.decode(vault_str) == u'foo'

    # unsafe
    unsafe_str = enc.encode(u'bar')
    assert unsafe_str == json.dumps({u'__ansible_unsafe': u'bar'}, cls=AnsibleJSONEncoder)
    assert dec.decode(unsafe_str) == u'bar'

    # inner unsafe and vault
    v_enc = AnsibleJSONEncoder()

# Generated at 2022-06-11 08:35:23.824067
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import textwrap

    creds = dict(
        secret=u'$6$QEkPwjVb$mSZS7RLgymCmZU6XKUvJ/ibJC/8nUhGjK/VlkvNuZhW8sKjGn9X2Q49ClPZI0x8xHSd0w.OKD2BNTKtZM1tZ.',
        salt=u'QEkPwjVb'
    )

# Generated at 2022-06-11 08:35:33.735960
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    pairs = {'__ansible_vault': 'test'}
    assert AnsibleJSONDecoder.object_hook(pairs) == {'__ansible_vault': 'test'}

    pairs = {'__ansible_unsafe': 'test'}
    assert AnsibleJSONDecoder.object_hook(pairs) == {'__ansible_unsafe': 'test'}

    pairs = {'__ansible_vault': 'test', '__ansible_unsafe': 'test'}
    vault_obj = AnsibleVaultEncryptedUnicode('test')
    assert AnsibleJSONDecoder.object_hook(pairs) == {'__ansible_vault': vault_obj, '__ansible_unsafe': 'test'}

# Generated at 2022-06-11 08:35:53.512711
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    value = 'my secret password'
    vault_secrets = ['my-secret-password']
    encrypted_unicode_object = json.dumps({'__ansible_vault': value}, cls=AnsibleJSONEncoder).encode()
    decoded = AnsibleJSONDecoder.object_hook({'__ansible_vault': value})

    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)

    AnsibleJSONDecoder.set_secrets(vault_secrets)

    decoded = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(encrypted_unicode_object)

    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:36:02.611760
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:09.845835
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['foobar']
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(secrets)
    json_object = ansible_json_decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'})
    assert isinstance(json_object, AnsibleVaultEncryptedUnicode)
    assert hasattr(json_object.vault, '_secrets')
    assert json_object.vault._secrets == secrets


# Generated at 2022-06-11 08:36:19.473049
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from collections import namedtuple
    import json

    data = '''{
        "__ansible_vault": "V2.0",
        "__ansible_unsafe": "V1.0"
    }'''

    named_tuple = namedtuple('Fake_AnsibleVaultEncryptedUnicode', 'vault')
    encoder = AnsibleJSONDecoder()
    encoder.set_secrets('hackme')

    result = encoder.decode(data)

    # Note: How can I test the result of AnsibleVaultEncryptedUnicode class?
    #       The value of result will be decoded after object_hook is called
    #       (In this case, named_tuple)
    assert isinstance(result['__ansible_unsafe'], named_tuple) == True




# Generated at 2022-06-11 08:36:30.664839
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['123', '123']

# Generated at 2022-06-11 08:36:41.420869
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class Answer: pass
    class OriginalDict(dict): pass
    secrets = b'secret'
    AnsibleJSONDecoder.set_secrets(secrets)
    hook = AnsibleJSONDecoder.object_hook

    # test __ansible_vault

# Generated at 2022-06-11 08:36:50.871542
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # the expected input pairs parameter is a map, here we use a list to test
    test_input_pairs = [{'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;'}, {'__ansible_unsafe': 'example of unsafe value'}]

    # test __ansible_vault
    decoder = AnsibleJSONDecoder()
    ret = decoder.object_hook(test_input_pairs[0])
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)

    # test __ansible_unsafe
    decoder = AnsibleJSONDecoder()
    ret = decoder.object_hook(test_input_pairs[1])
    assert ret.startswith('{unsafe}')

# Generated at 2022-06-11 08:36:58.773628
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansiblejson_decoder = AnsibleJSONDecoder()
    assert ansiblejson_decoder.object_hook({'__ansible_vault': 'test_value'}) == AnsibleVaultEncryptedUnicode('test_value')
    assert ansiblejson_decoder.object_hook({'__ansible_unsafe': 'test_value'}) == wrap_var('test_value')
    assert ansiblejson_decoder.object_hook({'test_key': 'test_value'}) == {'test_key': 'test_value'}
    assert ansiblejson_decoder.object_hook({}) == {}

# Generated at 2022-06-11 08:37:08.129114
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:37:18.885481
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    test_secret = ['foo']
    vault_lib = VaultLib(secrets=test_secret)


# Generated at 2022-06-11 08:37:41.686186
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = {}

    # Test object_hook
    d["__ansible_vault"] = '1234567890'
    method = AnsibleJSONDecoder.object_hook
    key, value = method(d)
    assert key == '__ansible_vault'
    assert value == '1234567890'

    # Test object_hook for another json
    d["__ansible_vault"] = '1234567890'
    d["__ansible_unsafe"] = 'value'
    method_2 = AnsibleJSONDecoder.object_hook
    key, value = method_2(d)
    assert key == '__ansible_vault'
    assert value == '1234567890'

# Generated at 2022-06-11 08:37:49.930814
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    j = '{"__ansible_vault": "vault_value", "__ansible_unsafe": "ansible_unsafe"}'
    d = AnsibleJSONDecoder()
    result = d.object_hook(json.loads(j))
    assert result == {'__ansible_vault': AnsibleVaultEncryptedUnicode('vault_value'), '__ansible_unsafe': AnsibleUnsafeText('ansible_unsafe')}

if __name__ == '__main__':
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-11 08:37:54.758135
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # when
    vault_data = "my vault data"
    vault_json = '{"__ansible_vault": "%s"}' % vault_data
    vault_obj = AnsibleJSONDecoder.object_hook(json.loads(vault_json))

    # then
    assert vault_obj.data == vault_data
    assert vault_obj.vault is None



# Generated at 2022-06-11 08:38:05.293888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': b'$ANSIBLE_VAULT;1.2;AES256;ansible\n3639653437643437323036653161383737623462653461666636366161386136\n3431663133343330306334396634373633386334376164633934303734373132\n333538326330343936356434396665\n'})

# Generated at 2022-06-11 08:38:15.233522
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:38:25.930099
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:38:34.988163
# Unit test for method object_hook of class AnsibleJSONDecoder