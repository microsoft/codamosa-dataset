

# Generated at 2022-06-11 08:28:33.615115
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoded = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256\n363535326365363233633961326231303137373865383465306333383962393931653164363336\n3537383437383634316339396231663736636366633613039373135313434633761653135356361\n3462363336396566623265333639653634313033356466303765666535386630653831333538\n"}'
    decoded = 'A SECRET'

    assert AnsibleJSONDecoder(encoded).decode()[0] == decoded

# Generated at 2022-06-11 08:28:41.312221
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleJSONDecoder(unittest.TestCase):
        def test_ansible_vault(self):
            json_blob = '{"__ansible_vault": "my vaulted value"}'
            ansible_vault_decoder = AnsibleJSONDecoder()
            ansible_vault_decoder.set_secrets(['my_vault_secret'])
            decoded = json.loads(json_blob, cls=ansible_vault_decoder)
            self.assertIsInstance(decoded, dict)
            self.assertIn('__ansible_vault', decoded)

# Generated at 2022-06-11 08:28:51.289666
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:28:57.343334
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def sample_object_hook(obj):
        raise Exception('sample_object_hook')

    result = AnsibleJSONDecoder(object_hook=sample_object_hook).object_hook({'__ansible_vault': 'sample_vault'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is None

    result = AnsibleJSONDecoder(object_hook=sample_object_hook).object_hook({'__ansible_unsafe': 'sample_unsafe'})
    assert isinstance(result, wrap_var)
    assert isinstance(result.data, str)
    assert result.data == 'sample_unsafe'

    class SampleVault:
        pass

    vault = SampleVault()
    AnsibleJSONDecoder.set_secrets('sample_secrets')

# Generated at 2022-06-11 08:29:03.564273
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets("secret")

    # Test __ansible_unsafe
    unsafe_object = decoder.object_hook({'__ansible_unsafe': {'a': 1}})
    assert unsafe_object == wrap_var({'a': 1})

    # Test __ansible_vault

# Generated at 2022-06-11 08:29:14.492559
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:22.352035
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder()
    assert jd.object_hook({}) == {}

    p = { 'foo' : 'bar', 'baz' : 42 }
    assert jd.object_hook(p) == p

    p = { 'foo' : 'bar', '__ansible_vault' : 'hunter2' }
    assert jd.object_hook(p) == p
    assert jd.object_hook(p)['foo'] == 'bar'
    assert jd.object_hook(p)['__ansible_vault'] == 'hunter2'

# Generated at 2022-06-11 08:29:33.349387
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # test object_hook with object having key __ansible_vault
    pairs = { "__ansible_vault": "test" }
    value = decoder.object_hook(pairs)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value._encrypted_data == "test"

    # test object_hook with object having key __ansible_unsafe
    pairs = { "__ansible_unsafe": "test" }
    value = decoder.object_hook(pairs)
    assert isinstance(value, wrap_var)
    assert value.value == "test"

    # test object_hook with object having key other than __ansible_vault or __ansible_unsafe

# Generated at 2022-06-11 08:29:38.505133
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    key = '__ansible_vault'
    value = 'ASDF1234'
    pairs = {key:value}
    expected = AnsibleVaultEncryptedUnicode(value)
    # Act
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook(pairs)
    # Assert
    isinstance(result[key], AnsibleVaultEncryptedUnicode)
    assert result[key]==expected


# Generated at 2022-06-11 08:29:47.307261
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '''{
        "__ansible_unsafe": "{SHA}nFCebWjxfaLbHHG1Qk5UU4trbvQ=",
        "dict_val": {
            "foo": "bar",
            "baz": "qux"
        }
    }'''
    decoder = AnsibleJSONDecoder(object_pairs_hook=dict)
    result = decoder.decode(s)

    assert isinstance(result['__ansible_unsafe'], wrap_var.AnsibleUnsafeText)
    assert 'sha1' in result['__ansible_unsafe']
    assert 'dict_val' in result
    assert isinstance(result['dict_val'], dict)



# Generated at 2022-06-11 08:29:59.649208
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    If __ansible_vault is in the pairs, then return it in AnsibleVaultEncryptedUnicode
    """
    pairs = {"__ansible_vault": "123"}
    cls = AnsibleJSONDecoder()
    assert cls.object_hook(pairs) == AnsibleVaultEncryptedUnicode(pairs["__ansible_vault"])

    """
    If __ansible_vault is in the pairs and vaults secrets is provided, then return it in AnsibleVaultEncryptedUnicode
    with vault property set to a VaultLib object containing default vault
    """
    pairs = {"__ansible_vault": "123"}
    cls = AnsibleJSONDecoder()
    secret = "secret"
    cls.set_secrets(secret)

# Generated at 2022-06-11 08:30:08.738723
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    class TestAnsibleJSONDecoder(unittest.TestCase):
        def test_AnsibleJSONDecoder_object_hook(self):
            from ansible.module_utils.common._collections_compat import Mapping

            decoder = AnsibleJSONDecoder()
            self.assertIsInstance(decoder.object_hook({'__ansible_vault': 'foo'}), AnsibleVaultEncryptedUnicode)
            self.assertIsInstance(decoder.object_hook({'__ansible_unsafe': 'foo'}), AnsibleUnsafeText)
            self.assertIsInstance(decoder.object_hook({'__ansible_unsafe': {'bar': 'foo'}}), Mapping)

# Generated at 2022-06-11 08:30:17.291013
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"test": "data"}
    r = AnsibleJSONDecoder().object_hook(data)
    assert r == data

    data = {'__ansible_vault': 'vaultdata'}
    r = AnsibleJSONDecoder().object_hook(data)
    assert isinstance(r, AnsibleVaultEncryptedUnicode)
    assert r.value == 'vaultdata'
    assert r.vault is None

    data = {'__ansible_unsafe': 'creds'}
    r = AnsibleJSONDecoder().object_hook(data)
    assert r.__ansible_unsafe__ == True



# Generated at 2022-06-11 08:30:28.098769
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:35.846630
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib()

    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;my_vault;my_vault;my_vault', '__ansible_unsafe': '123'}
    pairs_decoded = decoder.object_hook(pairs)

    assert isinstance(pairs_decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert pairs_decoded['__ansible_vault'].vault is not None
    assert pairs_decoded['__ansible_unsafe'] == wrap_var('123')


# Generated at 2022-06-11 08:30:40.446655
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_obj = dict(__ansible_vault='some_password')
    expected_result = dict(__ansible_vault=AnsibleVaultEncryptedUnicode('some_password'))
    assert(AnsibleJSONDecoder().decode(json_obj) == expected_result)



# Generated at 2022-06-11 08:30:51.162438
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test case 1:
    # excepted is __ansible_vault is in pairs
    ansible_json_decoder = AnsibleJSONDecoder()

    class test_AnsibleVaultEncryptedUnicode(object):
        pass

    ansible_json_decoder.set_secrets('123456')

    pairs = {'__ansible_vault': '123456', 'key1': 'value1'}

    excepted = {'__ansible_vault': test_AnsibleVaultEncryptedUnicode, 'key1': 'value1'}

# Generated at 2022-06-11 08:30:53.326000
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '{"__ansible_unsafe": "{{{{ var }}}}"}'
    assert AnsibleJSONDecoder().decode(data) == {'__ansible_unsafe': wrap_var('{{ var }}')}

# Generated at 2022-06-11 08:31:02.855088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_pairs = {
        '__ansible_vault': 'test-123',
        '__ansible_unsafe': 'test-456'
    }
    vault_password = 'test-vault-password'
    encoder = AnsibleJSONEncoder()
    json_str = encoder.encode(test_pairs)

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets((vault_password,))
    decoded_pairs = decoder.decode(json_str)
    assert decoded_pairs['__ansible_vault'] == AnsibleVaultEncryptedUnicode('test-123')
    assert decoded_pairs['__ansible_unsafe'] == wrap_var('test-456')

# Generated at 2022-06-11 08:31:07.606447
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    json_str = '{"__ansible_vault": "encrypt string", "__ansible_unsafe": "unsafe string"}'

    assert decoder.decode(json_str) == {"__ansible_vault": "encrypt string", "__ansible_unsafe": "unsafe string"}

# Generated at 2022-06-11 08:31:15.410151
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_vault': 'vault_string',
        '__ansible_unsafe': 'unsafe_string'
    }
    assert decoder.object_hook(pairs) == {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('vault_string'),
        '__ansible_unsafe': AnsibleUnsafeText('unsafe_string')
    }

# Generated at 2022-06-11 08:31:23.541701
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestVault(object):
        def load(self, data, **kwargs):
            return 'TEST'
    secrets = {'default': TestVault()}
    AnsibleJSONDecoder.set_secrets(secrets)
    value = json.loads('{"__ansible_vault": "####", "__ansible_unsafe": "TEST", "other": "value"}', cls=AnsibleJSONDecoder)

    assert(value == {
        '__ansible_unsafe': 'TEST',
        '__ansible_vault': 'TEST',
        'other': 'value'
    })

# Generated at 2022-06-11 08:31:33.976842
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    import json

    secret = 'hello world'
    v = VaultLib(secrets=[secret])
    payload = {'__ansible_vault': v.encrypt(secret).decode('utf-8')}
    payload_str = json.dumps(payload, cls=AnsibleJSONEncoder)

    # Assume object hook will run
    # use None as hook_value to check if hook_str is an instance of class AnsibleVaultEncryptedUnicode
    hook_value = None
    hook_str = AnsibleJSONDecoder.object_hook({'__ansible_vault': hook_value})
    assert hook_str == hook_value
    hook_str = AnsibleJSONDec

# Generated at 2022-06-11 08:31:44.292462
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    avm = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    secrets = ['test']
    AnaibleJSONDecoder.set_secrets(secrets)
    assert isinstance(AnaibleJSONDecoder.object_hook({'__ansible_vault': 'test'}), AnsibleVaultEncryptedUnicode)

    # Test for AnsibleUnsafeText
    assert isinstance(AnaibleJSONDecoder.object_hook({'__ansible_unsafe': 'test'}), AnsibleUnsafeText)

    # Test for dict
    assert isinstance(AnaibleJSONDecoder.object_hook({}), dict)

    # Test for list

# Generated at 2022-06-11 08:31:55.528945
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    from ansible.parsing.yaml.objects import SafeRepresenter

    json_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n30383963393231656338333238626365623333393537363736383033633139373531366537373330\n39343064386331383964663564613966616637643333343961363438356339663432626566333833\n333666326264\n', '__ansible_unsafe': True}
    vault_secret_file = '%s/tests/vault_secrets' % os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-11 08:32:04.082703
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:13.274805
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set up object to be decoded
    pairs = {'__ansible_vault': 'string_to_encrypt',
             '__ansible_unsafe': 'string_to_encrypt'}

    # Set up class with given secret
    AnsibleJSONDecoder.set_secrets('secret')

    # Decode object
    for key in pairs:
        value = pairs[key]
        decoded_value = AnsibleJSONDecoder.object_hook(value)

        # Vault is decoded
        if key == '__ansible_vault':
            try:
                decoded_value.data
                decoded_value.vault.decrypt(value)
                assert True == True
            except:
                assert True == False

        # Unsafe is wrapped

# Generated at 2022-06-11 08:32:22.848868
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:32:25.261861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {'__ansible_unsafe': 'abcde'}
    result = AnsibleJSONDecoder.object_hook(test_data)
    assert result.__class__.__name__ == 'AnsibleUnsafeText'
    assert result.__ansible_unsafe__ == test_data['__ansible_unsafe']

# Generated at 2022-06-11 08:32:30.964974
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os

    json_file = os.path.join(os.path.dirname(__file__), 'fixtures', 'object_hook.json')

    with open(json_file) as f:
        dump_json = f.read()

    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook(json.loads(dump_json)) == json.loads(dump_json)


# Generated at 2022-06-11 08:32:43.410559
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    AnsibleJSONDecoder.set_secrets(["secret"])

# Generated at 2022-06-11 08:32:52.765570
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Creates and populates test data
    input_json = '''
        {
            "__ansible_vault": "My_Password",
            "__ansible_unsafe": "your_password"
        }
    '''

    # Call the method under testing
    decoder = AnsibleJSONDecoder()
    output_json = decoder.object_hook(json.loads(input_json))

    # Result verification
    assert output_json['__ansible_vault'] == 'My_Password'
    assert output_json['__ansible_unsafe'] == '******'


# Generated at 2022-06-11 08:33:03.631390
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secrets = ['123456789']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test for value of __ansible_vault

# Generated at 2022-06-11 08:33:12.288486
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import types
    test_json = '{"__ansible_unsafe":{"__ansible_untrusted":{"__ansible_module_name":"test_mod","__ansible_module_args":{"test_arg_key":"test_arg_value"}}}}'
    test_result = {"__ansible_unsafe":{"__ansible_untrusted":{"__ansible_module_name":"test_mod","__ansible_module_args":{"test_arg_key":"test_arg_value"}}}}

    assert json.loads(test_json, cls=AnsibleJSONDecoder) == test_result
    assert isinstance(json.loads(test_json, cls=AnsibleJSONDecoder)['__ansible_unsafe'], types.FunctionType)

# Generated at 2022-06-11 08:33:22.982804
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_secrets = ['test']
    AnsibleJSONDecoder.set_secrets(test_secrets)
    test_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n3933326261346131613863393462333162316564663132633265393863303530643631313438626262\n3436666132653936356530367d0a', '__ansible_unsafe': False, 'a': 'b', 'c': 'd'}
    assert 'b' == AnsibleJSONDecoder(test_data).decode()['a']
    assert False == AnsibleJSONDecoder(test_data).decode()['__ansible_unsafe']

# Generated at 2022-06-11 08:33:34.049335
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:43.162873
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    plain_text = 'top-secret'
    vault_text = '$ANSIBLE_VAULT;1.1;AES256;ansible\n35633136653662343335396436616332323934356332396266316139376465363564346535613334\n3630356535313934663964303234636232336464326662333837666334330a356465373764303363\n63363461623562656639383566366537333030613437343032613261323461633663613133643835\n3533366634353231643533'

# Generated at 2022-06-11 08:33:54.338300
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = {
        'username': 'user',
        'password': 'someVaultPassword',
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\nkSzQcI2teP+f4P8gYq4AKgHb5p+V0nWX9ktqrZk1N/04Nxh/jjRmDwjAse/aQhf/\n/XQfzZBUNkGmELzMx57CeA==\n'
    }
    secrets = ['someVaultPassword']

# Generated at 2022-06-11 08:33:57.945688
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '''
{
"__ansible_vault": "a"
}
'''
    dec = AnsibleJSONDecoder()
    assert dec.decode(data)['__ansible_vault'] is not None


# Generated at 2022-06-11 08:34:07.829204
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [u'foo', u'bar']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:34:16.957131
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # AnsibleVaultEncryptedUnicode
    assert isinstance(AnsibleJSONDecoder.object_hook({'__ansible_vault': 'value'}), AnsibleVaultEncryptedUnicode)

    # AnsibleUnsafeText
    assert str(AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'value'})) == 'value'


# Generated at 2022-06-11 08:34:24.792916
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    if not hasattr(AnsibleJSONDecoder, '_vaults'):
        AnsibleJSONDecoder._vaults = {}
        AnsibleJSONDecoder._vaults['default'] = None
    # json is None
    json = None
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook(json) is None

    # json is {}
    json = {}
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook(json) == json

    # json is {'__ansible_unsafe': 'test'}
    json = {'__ansible_unsafe': 'test'}
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder

# Generated at 2022-06-11 08:34:33.052382
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    input_dict = json.loads('{"__ansible_vault": "foo", "__ansible_unsafe": "bar"}')

    # Test that AnsibleVaultEncryptedUnicode value is properly set
    assert isinstance(input_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert input_dict['__ansible_vault'] == "foo"

    # Test that callable is properly added to __ansible_unsafe value
    assert callable(input_dict['__ansible_unsafe'])
    assert input_dict['__ansible_unsafe']() == "bar"

# Generated at 2022-06-11 08:34:44.192092
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    input_data = """{
        "param1": "value1",
        "param2": "value2",
        "__ansible_vault": "7VbGd+uK8VQ2CfugYkDWdIej+0va9JWACyzvcpjKU+O6efHNQLOVPTgYJ+ZB2f/k",
        "param3": "value3",
        "param4": "value4",
        "__ansible_unsafe": "abcd"
    }"""

# Generated at 2022-06-11 08:34:50.285811
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test __ansible_vault
    data = '{"__ansible_vault": "value"}'
    result = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # Test __ansible_unsafe
    data = '{"__ansible_unsafe": "value"}'
    result = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(result, dict)
    assert '__ansible_unsafe' in result
    assert str(result['__ansible_unsafe']) == 'value'

    # Test string
    data = '{"a": "value"}'
    result = json.loads(data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:35:00.108625
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # given
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=[b"UNIT_TEST"])

# Generated at 2022-06-11 08:35:08.865073
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    vault_data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256', vault_identifier='password')
    assert decoder.object_hook({'__ansible_vault': vault_data.vault_text}) == vault_data
    assert decoder.object_hook({'__ansible_unsafe': vault_data.vault_text}) == wrap_var(vault_data.vault_text)
    assert decoder.object_hook({'__ansible_unsafe': vault_data.vault_text}) == wrap_var(vault_data.vault_text)

# Generated at 2022-06-11 08:35:19.907988
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import sys
    import json

    if sys.version_info >= (3, 0):
        long_type = int
    else:
        long_type = long

    data = '{"__ansible_vault": "AES256:zDH5DGnKjjQ2sqZDlBk6+GVM0srxIN2QxPijJbA6g0U=:mH6/JpDmf1N/E4lLWJ/8R/My9zwoYamTj+oqN3AxDrSLAyn1F4I4E4jxW8A=="}'
    json_obj = json.loads(data)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:35:31.380102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {'passwordhash': 'password'}
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

# Generated at 2022-06-11 08:35:33.266525
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': {'password': 'passw0rd'}}) == wrap_var({'password': 'passw0rd'})

# Generated at 2022-06-11 08:35:43.459100
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj_hook = AnsibleJSONDecoder().object_hook
    assert obj_hook({'__ansible_vault': 'abc'}) == AnsibleVaultEncryptedUnicode('abc')
    assert obj_hook({'__ansible_unsafe': 'abc'}) == wrap_var('abc')
    assert obj_hook({'__ansible_vault': 'abc', '__ansible_unsafe': 'abc'}) == wrap_var(AnsibleVaultEncryptedUnicode('abc'))
    assert obj_hook({'abc': 'abc'}) == {'abc': 'abc'}

# Generated at 2022-06-11 08:35:56.390980
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:04.188218
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    encrypted_value = "$ANSIBLE_VAULT;2.0;AES256;ansible\n34376136313230303361313433363935303364376361633836646336633462366832626361323861\n36306466633561333234636465333564353832616662356139376630363363663864383430646535\n65623463393563616464663939646664616366626334353561333436653235343338363131316630\n35616230663939396533383566653337353036363832343137313337333262663038353065633431\n6633\n"

# Generated at 2022-06-11 08:36:14.475725
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # VaultLib.decrypt will not be called if vault_secrets is None.
    AnsibleJSONDecoder.set_secrets(None)

    # __ansible_vault
    # Not decrypted because vault is not set (vault_secrets is None)

# Generated at 2022-06-11 08:36:22.439506
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.json import AnsibleJSONDecoder

    # Testing __ansible_vault key
    assert isinstance(json.loads(json.dumps({'__ansible_vault': 'foo'}, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)
    assert isinstance(json.loads(json.dumps({'__ansible_vault': 'foo'}), cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)

    # Testing __ansible_unsafe key

# Generated at 2022-06-11 08:36:33.197356
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:44.134227
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:52.769193
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test Data
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:36:55.815532
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    data = {'__ansible_vault': 'test'}
    pairs = decoder.object_hook(data)
    assert isinstance(pairs, AnsibleVaultEncryptedUnicode)
    assert pairs.vault is None
    assert pairs.vdata == data['__ansible_vault']

    data = {'__ansible_unsafe': 'test'}
    pairs = decoder.object_hook(data)
    assert isinstance(pairs, AnsibleUnsafeText)
    assert pairs.value == data['__ansible_unsafe']

# Generated at 2022-06-11 08:37:03.883464
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:37:15.901932
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    js = '{"__ansible_vault": "foo"}'
    result = json.loads(js, cls=AnsibleJSONDecoder)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result == "foo"



# Generated at 2022-06-11 08:37:24.916086
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Make sure the callback method is called when the data is decoded.
    """

# Generated at 2022-06-11 08:37:32.101278
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test process vault
    obj = decoder.object_hook({'__ansible_vault': 'some_data'})
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)

    # Test process unsafe var
    obj = decoder.object_hook({'__ansible_unsafe': 'some_data'})
    assert isinstance(obj, wrap_var)

    # Test ignore another obj
    obj = decoder.object_hook({'key': 'some_data'})
    assert obj == {'key': 'some_data'}



# Generated at 2022-06-11 08:37:42.192211
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create a plaintext AnsibleVaultEncryptedUnicode object and a wrapper object
    plaintext = AnsibleVaultEncryptedUnicode(u"some unencrypted text")
    vault_wrapper = wrap_var(plaintext)
    # Create a JSON string which represents it and a JSON string for the wrapper object
    json1 = json.dumps(plaintext, cls=AnsibleJSONEncoder)
    json2 = json.dumps(vault_wrapper, cls=AnsibleJSONEncoder)
    # Load and decode the JSON strings
    converted1 = json.loads(json1, cls=AnsibleJSONDecoder)
    converted2 = json.loads(json2, cls=AnsibleJSONDecoder)
    # Assert that the two objects are equal
    assert plaintext == converted1
    assert vault_wrapper

# Generated at 2022-06-11 08:37:48.833862
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault = VaultLib(secrets=[{'password': 'secret'}])

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder._vaults['default'] = vault

    hashed_str = vault.encrypt('value')
    json_str = '{"__ansible_vault": "%s"}' % hashed_str

    assert isinstance(decoder.decode(json_str), AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-11 08:37:58.821221
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'secret'
    expected = 'bar'

# Generated at 2022-06-11 08:38:09.595128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;a1b2c3d4e5f6a7b8c9d0\na1b2c3d4e5f6a7b8c9d0\na1b2c3d4e5f6a7b8c9d0\na1b2c3d4e5f6a7b8c9d0\na1b2c3d4e5f6a7b8c9d0\na1b2c3d4e5f6a7b8c9d0\n",
        "__ansible_unsafe": "\"{{ my_password }}\""
    }


# Generated at 2022-06-11 08:38:11.594899
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for method object_hook of class AnsibleJSONDecoder
    assert AnsibleJSONDecoder.object_hook

# Generated at 2022-06-11 08:38:12.174235
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-11 08:38:22.089599
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # This is a bit of a hack, there should probably be a better way
    # to get at this function, but this works right now, so we'll
    # leave it for now.
    decoder = AnsibleJSONDecoder()