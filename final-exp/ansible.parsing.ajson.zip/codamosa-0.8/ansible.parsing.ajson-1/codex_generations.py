

# Generated at 2022-06-11 08:28:36.156266
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '''{
    "name": "foo",
    "value": {"__ansible_unsafe": "{{foo}}"},
    "value2": {"__ansible_vault": "password" }
    }'''

    json_dict = json.loads(json_string, cls=AnsibleJSONDecoder)

    assert json_dict['value2'] == "password"
    assert json_dict['value'].get_wrapped_var() == "{{foo}}"

# Generated at 2022-06-11 08:28:43.164694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.text.converters import to_bytes
    jd = AnsibleJSONDecoder()
    secret = "sample_vault_encrypted_pass"
    jd.set_secrets([to_bytes(secret)])

# Generated at 2022-06-11 08:28:52.868610
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults = {}
    decoder._vaults['default'] = VaultLib()

    # Test case 1: simple
    expected = AnsibleVaultEncryptedUnicode('123')
    expected.vault = decoder._vaults['default']
    got = decoder.object_hook({'__ansible_vault': '123'})
    assert expected == got

    # Test case 2: composite
    expected = AnsibleVaultEncryptedUnicode('123')
    expected.vault = decoder._vaults['default']
    got = decoder.object_hook({'a': '1', '__ansible_vault': '123', 'b': '3'})
    assert expected == got

    # Test cae 3: missing vault

# Generated at 2022-06-11 08:29:01.691808
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secret = 'thisismysecret'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n363463643662323165653730643637616235396565643336356463346565323638316532333433\n39383730306336303231336331643834383230653131646635306366623962350a643131653264\n353939356130633039336533323764393336363435666433346664363834643330356465326430\n33386438353431636330326662383836333665366339653631303566323539\n'

    # vault is not decrypted

# Generated at 2022-06-11 08:29:08.282532
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    test_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}

    # Exercise
    actual = AnsibleJSONDecoder().object_hook(test_dict)

    # Verify
    expected = AnsibleVaultEncryptedUnicode(test_dict['__ansible_vault'])
    assert actual == expected
    assert actual.vault is AnsibleJSONDecoder._vaults['default']

# Generated at 2022-06-11 08:29:12.992998
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {'__ansible_unsafe': '__ansible_unsafe_value',
           '__ansible_vault': '__ansible_vault_value',
           'key1': 'value1',
           'key2': 'value2'}
    secrets = ['secret1', 'secret2']
    json_decoder = AnsibleJSONDecoder
    json_decoder.set_secrets(secrets)
    json_obj = json_decoder.object_hook(obj)
    assert json_obj['__ansible_vault'].data == obj['__ansible_vault']
    assert json_obj['__ansible_vault'].vault.secrets == secrets

# Generated at 2022-06-11 08:29:23.502354
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 5:
        assert (AnsibleJSONDecoder().object_hook([('key', 'val')]) == {'key': 'val'})
        assert (AnsibleJSONDecoder().object_hook([('__ansible_unsafe', {'key': 'val'})]) == {'key': 'val'})
    else:
        assert (AnsibleJSONDecoder().object_hook({'key': 'val'}) == {'key': 'val'})
        assert (AnsibleJSONDecoder().object_hook({'__ansible_unsafe': {'key': 'val'}}) == {'key': 'val'})

# Generated at 2022-06-11 08:29:34.400121
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '{"__ansible_vault": "mysecret"}'
    data = AnsibleJSONDecoder().decode(json_data)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data == "mysecret"
    assert data.vault is None

    json_data = '{"__ansible_vault": "mysecret", "__ansible_unsafe": "password"}'
    data = AnsibleJSONDecoder().decode(json_data)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data == "mysecret"
    assert data.vault is None

    my_secrets = [b'test']
    json_data = '{"__ansible_vault": "mysecret"}'
    AnsibleJSONDecoder.set_sec

# Generated at 2022-06-11 08:29:43.999694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import AnsibleJSONDecoder


# Generated at 2022-06-11 08:29:50.148071
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '{ "__ansible_vault": "VAULT PASSWORD", "__ansible_unsafe": "UNSAFE"}'
    decoded = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert decoded['__ansible_vault'] == 'VAULT PASSWORD'
    assert decoded['__ansible_unsafe'] == 'UNSAFE'
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-11 08:30:03.506180
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test = '''{
        "test_string": "hello world",
        "test_dict": {
            "a": 1,
            "b": true,
            "c": false,
            "d": null
        },
        "__ansible_vault": "my vault data"
    }'''
    obj = AnsibleJSONDecoder().decode(test)

    assert type(obj) is dict
    assert obj['test_string'] == "hello world"
    assert type(obj['test_dict']) is dict
    assert obj['test_dict']['a'] == 1
    assert obj['test_dict']['b'] is True
    assert obj['test_dict']['c'] is False
    assert obj['test_dict']['d'] is None

# Generated at 2022-06-11 08:30:14.425420
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:22.435381
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test the method object_hook from the class AnsibleJSONDecoder.
    """
    AnsibleJSONDecoder.set_secrets('secret')
    pairs = {'__ansible_vault': 'test'}
    decoded = AnsibleJSONDecoder().object_hook(pairs)
    assert(isinstance(decoded, AnsibleVaultEncryptedUnicode))
    # Assert that default vault has been set
    assert(decoded.vault == AnsibleJSONDecoder._vaults['default'])
    assert(AnsibleJSONEncoder().default(decoded) == 'test')

# Generated at 2022-06-11 08:30:32.908382
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:43.077499
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'old_secret1']

# Generated at 2022-06-11 08:30:49.746085
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    #arrange
    pairs = {'__ansible_vault': 'vault_value'}
    pairs.update({'__ansible_unsafe': 'unsafe_value'})
    decoder = AnsibleJSONDecoder()

    #act
    res = decoder.object_hook(pairs)

    #assert
    assert res['__ansible_vault'] == 'vault_value'
    assert res['__ansible_unsafe'] == 'unsafe_value'

# Generated at 2022-06-11 08:31:01.825497
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:31:12.536633
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets(['AnsibleJSONDecoder_test'])
    decoder = AnsibleJSONDecoder(object_pairs_hook=dict)
    text1 = '{' \
            '    "__ansible_unsafe": "test",' \
            '    "__ansible_vault": "0g6k1fW/rv+yP/Jw/acpfvaJjA4v4koYXZpzGp8GRxBaSzH36"' \
            '}'
    text2 = '{' \
            '    "__ansible_unsafe": "test",' \
            '    "__ansible_vault": {"vault": "default", "secret": "AnsibleJSONDecoder_test"}' \
            '}'
    

# Generated at 2022-06-11 08:31:18.286984
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n3539....."
    }) == AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n3539.....")
    assert decoder.object_hook({
        "__ansible_unsafe": "{{ password }}"
    }) == wrap_var("{{ password }}")

# Generated at 2022-06-11 08:31:29.354739
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = list(['a','b','c','d','e','f','g','h','i','j','k'])
    json_text = """{"__ansible_vault": "AES256:xuV7R812ZG77V/sBX1/QO7sEh3qc/i7w29m0lhb7m0Zv","__ansible_unsafe": true}"""

    # Note that you need to set the secrects for the instance of the class to use for decryption
    # This is done in the ansible.module_utils.common.json.AnsibleJSONDencoder
    json_decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder._object_hook)
    AnsibleJSONDecoder.set_secrets(secrets)
    decoded_

# Generated at 2022-06-11 08:31:38.790216
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"__ansible_vault": "123456", "__ansible_unsafe": "hello", "__ansible_safe": "world"}

    vault_secrets = (r"$ANSIBLE_VAULT;1.1;AES256", "123456")
    AnsibleJSONDecoder.set_secrets(vault_secrets)

    decoder = AnsibleJSONDecoder()
    actual = decoder.object_hook(data)
    assert actual["__ansible_vault"] == "123456"
    assert actual["__ansible_unsafe"] == "hello"
    assert actual["__ansible_safe"] == "world"

# Generated at 2022-06-11 08:31:47.194606
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = "abcd"
    class decoder(AnsibleJSONDecoder):
        def object_hook(self, pairs):
            for key in pairs:
                if key == '__ansible_vault':
                    value = AnsibleVaultEncryptedUnicode(pairs[key])
                    if self._vaults:
                        value.vault = self._vaults['default']
                    return value
                elif key == '__ansible_unsafe':
                    return wrap_var(pairs[key])
            return pairs

    # Using valid vault secret
    decoder.set_secrets([secret])
    decoder_obj = decoder()
    in_data = '{"__ansible_vault": "abcd"}'
    out_data = decoder_obj.decode(in_data)

# Generated at 2022-06-11 08:31:52.404824
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"key1": "value1", "key2": "value2"}
    exp_result = {u'key1': u'value1', u'key2': u'value2'}
    ans_json = AnsibleJSONDecoder()
    result = ans_json.object_hook(obj)
    assert result == exp_result


# Generated at 2022-06-11 08:31:57.428838
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    in_value = dict(__ansible_vault="dummy", __ansible_unsafe="dummy2")
    out_value = AnsibleJSONDecoder().object_hook(in_value)
    assert isinstance(out_value, AnsibleVaultEncryptedUnicode)
    assert isinstance(out_value, str)
    assert isinstance(out_value.vault, VaultLib)
    assert out_value.unencrypted_value == "dummy"
    assert out_value.get_decrypted_text() == "dummy"
    assert out_value.is_encrypted() is True

    in_value = dict(__ansible_unsafe="dummy3")
    out_value = AnsibleJSONDecoder().object_hook(in_value)
    assert out_value == wrap_var("dummy3")

# Generated at 2022-06-11 08:32:05.082669
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    jsonDecoder = AnsibleJSONDecoder()
    pairs = jsonDecoder.object_hook({'__ansible_vault': 'value1', '__ansible_unsafe': 'value2', 'key3': 'value3'})
    assert isinstance(pairs, dict)
    assert len(pairs) == 3
    assert isinstance(pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert pairs['__ansible_vault'] == 'value1'
    assert isinstance(pairs['__ansible_unsafe'], unicode)
    assert pairs['__ansible_unsafe'] == 'value2'
    assert isinstance(pairs['key3'], unicode)
    assert pairs['key3'] == 'value3'

    jsonDecoder = Ansible

# Generated at 2022-06-11 08:32:10.544204
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder('{"foo": "bar"}',
                              object_hook=AnsibleJSONDecoder.object_hook).decode() == {"foo": "bar"}
    assert AnsibleJSONDecoder('{"__ansible_unsafe": "bar"}',
                              object_hook=AnsibleJSONDecoder.object_hook).decode() == {"__ansible_unsafe": wrap_var("bar")}



# Generated at 2022-06-11 08:32:20.305884
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:32:30.154388
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()

    # Test for __ansible_vault
    s = encoder.encode({
        'a': 'b',
        '__ansible_vault': 'c'
    })
    d = decoder.decode(s)
    assert d['a'] == 'b'
    assert isinstance(d['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert d['__ansible_vault'] == 'c'

    # Test for __ansible_unsafe
    s = encoder.encode({
        'a': 'b',
        '__ansible_unsafe': 'c'
    })
    d = decoder.decode(s)
    assert d['a'] == 'b'

# Generated at 2022-06-11 08:32:30.812615
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-11 08:32:41.350498
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data1 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test1\nc2VjcmV0MQo=\n'}
    data2 = {'__ansible_unsafe': 'secret2'}
    data3 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test1\nc2VjcmV0MQo=\n',
             '__ansible_unsafe': 'secret2'}

    assert AnsibleJSONDecoder().object_hook(data1) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test1\nc2VjcmV0MQo=\n'}

# Generated at 2022-06-11 08:32:49.358172
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    pairs = {}
    pairs['__ansible_vault'] = 'bar'
    result = decoder.object_hook(pairs)
    assert( isinstance(result, AnsibleVaultEncryptedUnicode))



# Generated at 2022-06-11 08:32:55.406692
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    load = json.load(open('test/unit/utils/test_vault.json'), cls=AnsibleJSONDecoder)
    assert isinstance(load['value'], AnsibleVaultEncryptedUnicode)
    assert load['value'].vault.secrets == ['01234567890123456789012345678901']

    load = json.load(open('test/unit/utils/test_unsafe.json'), cls=AnsibleJSONDecoder)
    assert isinstance(load['value'], wrap_var)
    assert str(load['value']) == '5'

# Generated at 2022-06-11 08:33:06.802580
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:14.038275
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = "abc"
    # test for vault attribute in AnsibleVaultEncryptedUnicode
    test_string = """{"__ansible_vault": "hash"}"""
    ansible_vault_encrypted_unicode_with_vault = AnsibleJSONDecoder.object_hook(json.loads(test_string))
    AnsibleJSONDecoder.set_secrets(secrets)
    ansible_vault_encrypted_unicode = AnsibleJSONDecoder.object_hook(json.loads(test_string))
    assert ansible_vault_encrypted_unicode.unsafe_data == ansible_vault_encrypted_unicode_with_vault.unsafe_data
    assert ansible_vault_encrypted_unicode.vault == ansible_vault_encrypted_unicode_with_vault.vault

# Generated at 2022-06-11 08:33:21.869519
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = """{"__ansible_vault":"$ANSIBLE_VAULT;1.2;AES256;some data"}"""
    secrets = [b'protected']
    secrets = list(reversed(secrets))
    AnsibleJSONDecoder.set_secrets(secrets)
    value = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert value.vault.secrets == secrets
    assert value == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;some data')

# Generated at 2022-06-11 08:33:31.379457
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    testvals = [
        (
            '{"__ansible_vault": "AAA"}',
            {'__ansible_vault': 'AAA'},
        ),
        (
            '{"__ansible_vault": "AAA"}',
            {'__ansible_vault': AnsibleVaultEncryptedUnicode('AAA')},
        ),
        (
            '{"__ansible_unsafe": "AAA"}',
            {'__ansible_unsafe': wrap_var('AAA')},
        ),
    ]

    for testdata, expected in testvals:
        data = json.loads(testdata, cls=AnsibleJSONDecoder)
        assert data == expected

# Generated at 2022-06-11 08:33:32.941843
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    values = {}
    values['__ansible_vault'] = "test"
    assert(AnsibleJSONDecoder().object_hook(values) is not None)

    values['__ansible_unsafe'] = "test"
    assert(AnsibleJSONDecoder().object_hook(values) is not None)

# Generated at 2022-06-11 08:33:42.517314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    :return:
    """
    import sys
    import io

    output = io.StringIO()
    sys.stdout = output

    # set key:value pairs
    key1 = '__ansible_vault'
    key2 = '__ansible_unsafe'

# Generated at 2022-06-11 08:33:49.967314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder()
    s = '{"__ansible_unsafe": "str_val", "__ansible_vault": "vault_val"}'
    r = json.loads(s, cls=AnsibleJSONDecoder)
    assert r['__ansible_unsafe'] == 'str_val'
    assert isinstance(r['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert r['__ansible_vault'] == 'vault_val'

# Generated at 2022-06-11 08:34:00.009253
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # method object_hook' of class AnsibleJSONDecoder returns pairs
    assert AnsibleJSONDecoder.object_hook({'a': 1, 'b': 'abc'}) == {'a': 1, 'b': 'abc'}
    # method object_hook' of class AnsibleJSONDecoder returns pairs
    assert AnsibleJSONDecoder.object_hook({'a': 1, 'b': 'abc', '__ansible_vault': '12345'}) == {'a': 1, 'b': 'abc', '__ansible_vault': '12345'}
    # method object_hook' of class AnsibleJSONDecoder returns pairs
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 2}) == {'__ansible_unsafe': 2}

# Generated at 2022-06-11 08:34:13.581305
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
        '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256',
    }

    # test with no vault
    ans_json_decoder = AnsibleJSONDecoder()
    ans_json_unserialized_object = ans_json_decoder.object_hook(pairs)

    assert isinstance(ans_json_unserialized_object['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert ans_json_unserialized_object['__ansible_vault'].vault is None


# Generated at 2022-06-11 08:34:22.484412
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    variable = '$ANSIBLE_VAULT;1.1;AES256\n'
    variable += '3661623934333066336232336361633662386533323161333261343861653531333235633562323966\n'
    variable += '6232653635313133653730393935393730316332363830663431626263380a36653133396536356136\n'
    variable += '3934336666353365376466363664663362303539633365623134613531326135623532393738646330\n'

# Generated at 2022-06-11 08:34:26.699032
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook(
        {"__ansible_vault": "AAAA", "__ansible_unsafe": "BBBB"}
    ) == {
        "__ansible_vault": AnsibleVaultEncryptedUnicode("AAAA"),
        "__ansible_unsafe": wrap_var("BBBB")
    }



# Generated at 2022-06-11 08:34:37.979287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    print("Testing AnsibleJSONDecoder object_hook")
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    # Tests for boolean conversion
    boolean_tests = {
        'true': True,
        'false': False,
        'yes': True,
        'no': False,
        'on': True,
        'off': False,
        '1': True,
        '0': False,
        1: True,
        0: False,
    }

    boolean_msg = "Failed to convert %s to boolean"
    for test in boolean_tests:
        test_val = boolean(test)
        assert test_val == boolean_tests[test], boolean_msg % test

    # Tests for file encoding

# Generated at 2022-06-11 08:34:47.602829
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    pairs = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;val',
        '__ansible_unsafe': '{"some":{"thing":"here"}}'
    }
    decoder.object_hook(pairs)
    assert isinstance(pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert pairs['__ansible_vault'].unlocked_value == 'val'
    assert isinstance(pairs['__ansible_unsafe'], wrap_var)
    assert pairs['__ansible_unsafe'].unlocked_value == '{"some":{"thing":"here"}}'

# Generated at 2022-06-11 08:34:56.308936
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secret_text = '$ANSIBLE_VAULT;1.1;AES256\n313739663533323866663433646361636262386166613837306131383830663732656531326536633236\n3639633961643739363930313035383638373365396665343738373230393831343962366437633239\n383339363533316166343361306665\n'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])
    result = decoder.object_hook({'__ansible_vault': secret_text})

    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None

# Generated at 2022-06-11 08:35:06.785731
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 08:35:13.241583
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text = '{"__ansible_vault": "vault_value", "__ansible_unsafe": "unsafe_value"}'
    json_obj = json.loads(json_text, cls=AnsibleJSONDecoder)
    assert isinstance(json_obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_obj['__ansible_unsafe'], (bytes, type(None)))

# Generated at 2022-06-11 08:35:24.612256
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder()
    # Test AnsibleVaultEncryptedUnicode with vault

# Generated at 2022-06-11 08:35:32.505808
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # test __ansible_vault
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')

    # test __ansible_unsafe
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')

    # test others
    assert decoder.object_hook({'a': 'test'}) == {'a': 'test'}

# Load json file and dump as string

# Generated at 2022-06-11 08:35:53.921995
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    data = '''{
        "__ansible_vault": "VjBya2QxUmtwbUZwWFhKcDZYMWpXZz09Cg==",
        "__ansible_unsafe": {"foo": "bar", "baz": {"bas": "qux"}}
    }'''
    assert {'__ansible_vault': 'VjBya2QxUmtwbUZwWFhKcDZYMWpXZz09Cg==',
            '__ansible_unsafe': {'foo': 'bar', 'baz': {'bas': 'qux'}}} == json.loads(data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:36:02.861958
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    # Test vaulted variable

# Generated at 2022-06-11 08:36:10.028046
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = "password"
    AnsibleJSONDecoder.set_secrets(secrets)
    assert isinstance(json.loads('{"__ansible_vault": "vault"}', cls=AnsibleJSONDecoder),
                      AnsibleVaultEncryptedUnicode)

    # TODO: Right now there is no use of wrap_var. Need to find use case to add unit test.
    # assert isinstance(json.loads('{"__ansible_unsafe": "var"}', cls=AnsibleJSONDecoder),
    #                   wrap_var)

# Generated at 2022-06-11 08:36:19.630769
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleMapping,  \
        AnsibleSequence,  \
        AnsibleUnicode,  \
        AnsibleVaultEncryptedUnicode

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    dec = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:36:30.855737
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import os
    import shutil
    import tempfile
    import yaml

    tmpdir = tempfile.mkdtemp()
    oldwd = os.getcwd()

# Generated at 2022-06-11 08:36:41.676585
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Prepare a test case
    _input = {}
    _input['__ansible_vault'] = '$ANSIBLE_VAULT;1.1;AES256\n63316333306532643933653636383436623531343834333333623066323432376636313530\n31623135386462616561356663633533373433623463633562626661613134373032323634\n3136353662623431350a353836396437333864346266313561376132303630643465366433\n65653334646639316361646235336263656465613361356265306437623130643234623335\n38643836613836393536\n'

# Generated at 2022-06-11 08:36:42.404646
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert False

# Generated at 2022-06-11 08:36:51.769376
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret_1 = VaultSecret('70726f6f66@!%^*@#$!#$')
    secret_2 = VaultSecret('11111@@@')
    vault_1 = VaultLib(secrets=[secret_1, secret_2])

    secret_3 = VaultSecret('22222')
    vault_2 = VaultLib(secrets=[secret_3])

    vault_dict = {'default': vault_1, 'second': vault_2}


# Generated at 2022-06-11 08:37:01.030795
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    data = decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n1234\nabcd\n'})

    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is not None
    assert data == '$ANSIBLE_VAULT;1.1;AES256\n1234\nabcd\n'

    data = decoder.object_hook({'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256\n1234\nabcd\n'})

    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is None

# Generated at 2022-06-11 08:37:10.729790
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # set up a fake vault
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    fake_vault = DataLoader().load_from_file('./test/units/compat/data/fake_vault_pass')
    AnsibleJSONDecoder.set_secrets(fake_vault)

    # parse json

# Generated at 2022-06-11 08:37:37.241560
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    # Set up some vault variables
    vault_name = 'vault_test'
    vault_secret = b'$ANSIBLE_VAULT;1.2;AES256;vault_test\n313233343536373839303132333435363738393031323334353637383930313233343536373839303132333435363738393031323334353637383930\n313233343536373839303132333435363738393031323334353637383930313233343536373839303132333435363738393031323334353637383930\n'
    vault_passwords = dict(vault_test=vault_secret)

# Generated at 2022-06-11 08:37:41.599160
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    data = '{"__ansible_vault": "vaulted"}'
    loader = AnsibleJSONDecoder.set_secrets(secrets)
    decoded = json.loads(data, object_hook=loader.object_hook)
    assert decoded == AnsibleVaultEncryptedUnicode('vaulted')

# Generated at 2022-06-11 08:37:47.134645
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': '@'}) == AnsibleVaultEncryptedUnicode('@')
    assert decoder.object_hook({'__ansible_unsafe': '@'}) == wrap_var('@')
    assert decoder.object_hook({'other': '@'}) == {'other': '@'}

# Generated at 2022-06-11 08:37:52.556987
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_unsafe': 'ansible_value'}
    ansible_json_decoder = AnsibleJSONDecoder()
    dict = ansible_json_decoder.object_hook(pairs)
    assert dict['ansible_value'] == 'ansible_value'
    pairs = {'__ansible_vault': 'ansible_value_vault'}
    dict = ansible_json_decoder.object_hook(pairs)
    assert dict.data == 'ansible_value_vault'

# Generated at 2022-06-11 08:38:03.350495
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    secrets = ['python']
    AnsibleJSONDecoder.set_secrets(secrets)
    result = AnsibleJSONDecoder(object_hook=json.JSONDecoder.object_hook)
    assert result._vaults['default'] == VaultLib(secrets=secrets)

    pairs = { '__ansible_vault': 'VGVzdA==\n' }
    expected = AnsibleVaultEncryptedUnicode('VGVzdA==\n')
    expected.vault = VaultLib(secrets=secrets)
    result.object_hook(pairs)

# Generated at 2022-06-11 08:38:13.635693
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    pairs = {
        '__ansible_vault': 'abc',
        '__ansible_unsafe': 'abc',
    }
    secret = [{'vault_id': 'default', 'secret': 'secret'}]
    decoder = AnsibleJSONDecoder.set_secrets(secret)
    decoder = AnsibleJSONDecoder()

    # Act
    result = decoder.object_hook(pairs)

    # Assert
    assert(isinstance(result, dict) == True)
    assert(result.get('__ansible_vault') == 'abc')
    assert(isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode) == True)
    assert(result.get('__ansible_unsafe') == 'abc')

# Generated at 2022-06-11 08:38:19.798787
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_unsafe': 'test val'}) == wrap_var('test val')
    assert decoder.object_hook({'__ansible_vault': 'test val'}) == AnsibleVaultEncryptedUnicode('test val')
    assert decoder.object_hook({'test key': 'test val'}) == {'test key': 'test val'}



# Generated at 2022-06-11 08:38:30.249491
# Unit test for method object_hook of class AnsibleJSONDecoder