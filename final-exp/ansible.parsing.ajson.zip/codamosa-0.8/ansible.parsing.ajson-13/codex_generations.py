

# Generated at 2022-06-11 08:28:37.213941
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:28:46.093648
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:28:55.460864
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Create AnsibleJSONDecoder instance
    ansible_json_decoder = AnsibleJSONDecoder()

    # Parse input argument pairs
    pairs = {
        'key1': 'value1',
        'key2': 'value2',
        '__ansible_vault': 'vault_value',
        '__ansible_unsafe': 'unsafe_value'
    }

    # Get object from pairs
    obj = ansible_json_decoder.object_hook(pairs)

    # Check if the object is in the expected format
    assert isinstance(obj, dict), "The object is not in the expected format"
    assert len(obj) == 4, "The object is not in the expected format"
    assert obj['key1'] == 'value1', "The object is not in the expected format"

# Generated at 2022-06-11 08:29:04.740631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'PASSWORD'}) == wrap_var('PASSWORD')

# Generated at 2022-06-11 08:29:14.696857
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # We have to set secrets for testing
    AnsibleJSONDecoder.set_secrets('test')

    answer = AnsibleJSONDecoder().object_hook({"__ansible_vault": "encryptedtext"})
    assert isinstance(answer, AnsibleVaultEncryptedUnicode) is True
    assert answer.data == "encryptedtext"
    assert isinstance(answer.vault, VaultLib) is True

    answer = AnsibleJSONDecoder().object_hook({"__ansible_unsafe": "safetext"})
    assert isinstance(answer, AnsibleVaultEncryptedUnicode) is not True
    assert hasattr(answer, 'data') is False
    assert hasattr(answer, 'vault') is False


# Generated at 2022-06-11 08:29:23.103185
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'v1'}
    ret = decoder.object_hook(pairs)
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)
    assert decoder._vaults == {}

    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_unsafe': 'v1'}
    ret = decoder.object_hook(pairs)
    assert isinstance(ret, dict)
    assert ret['__ansible_unsafe'] == 'v1'
    pass



# Generated at 2022-06-11 08:29:34.060888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    unsafe_data = {"__ansible_unsafe": "this_is_unsafe"}
    decoded_unsafe_data = AnsibleJSONDecoder.object_hook(unsafe_data)
    assert type(decoded_unsafe_data) == dict
    assert decoded_unsafe_data["__ansible_unsafe"] == wrap_var("this_is_unsafe")
    vault_data = {"__ansible_vault": "my_super_secret_value"}
    decoded_vault_data = AnsibleJSONDecoder.object_hook(vault_data)
    assert type(decoded_vault_data) == AnsibleVaultEncryptedUnicode
    decoded_vault_data.decrypt()
    assert decoded_vault_data == "my_super_secret_value"



# Generated at 2022-06-11 08:29:43.428062
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:51.134831
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [u'password']
    secrets_string = u'password'

# Generated at 2022-06-11 08:30:00.392182
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for vault
    secret = "my string"
    dict_value = {
        '__ansible_vault': secret
    }
    expected_result = AnsibleVaultEncryptedUnicode(secret)

    result = decoder.object_hook(dict_value)

    assert result == expected_result

    # Test for unsafe
    value = {
        '__ansible_unsafe': True
    }
    expected_result = wrap_var(True)

    result = decoder.object_hook(value)

    assert result == expected_result

# Generated at 2022-06-11 08:30:09.447154
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # pylint: disable=protected-access
    # pylint: disable=invalid-name
    import pytest

    from ansible.parsing.vault import VaultSecret, VaultAES256
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    def check_object_hook(secret, data, value, vault_id='default'):
        cls = AnsibleJSONDecoder.__dict__['__class__']
        cls._vaults = {}
        cls._vaults['default'] = VaultLib(secrets=[VaultSecret(secret=secret)])
        decoded = cls().decode(data)
        assert value == decoded['value']
        assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:30:12.514172
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """ ansible.module_utils.basic.json.AnsibleJSONDecoder.object_hook() method tested """

    # Start testing
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 08:30:23.044772
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    import ansible.parsing.vault as vault
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secrets = [{'secret': 'mysecret'}]

# Generated at 2022-06-11 08:30:31.284336
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe':
        {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;xxxxxxxxxxxx\n4561xxxxxxxxxxxxxx\nxxxxxxxxxxxxxxxxxx\nxxxxxxxxxxxxxx\nxx==\n'}}) \
        == {'__ansible_unsafe': {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;xxxxxxxxxxxx\n4561xxxxxxxxxxxxxx\nxxxxxxxxxxxxxxxxxx\nxxxxxxxxxxxxxx\nxx==\n'}}



# Generated at 2022-06-11 08:30:36.975825
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # \u2714 is checkmark
    dict_input = {'__ansible_vault': 'vault_value', '__ansible_unsafe': u'\u2714'}
    dict_output = decoder.object_hook(dict_input)

    # The expected results are not a dictionary.
    assert isinstance(dict_output, dict) is False
    assert isinstance(dict_output, AnsibleVaultEncryptedUnicode) is True
    assert dict_output._ansible_vault_secret == 'vault_value'



# Generated at 2022-06-11 08:30:48.316433
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'secret'
    secrets = [secret]
    # Data to be decoded
    test_data_1 = '{"__ansible_vault": "AAAA", "foo": "bar"}'
    test_data_2 = '{"__ansible_unsafe": 42}'

    # Set up to use the test decoder
    test_decoder = AnsibleJSONDecoder
    test_decoder.set_secrets(secrets)
    # Decode the test data
    decoded_data_1 = json.loads(test_data_1, cls=test_decoder)
    decoded_data_2 = json.loads(test_data_2, cls=test_decoder)
    # Check that the decoded data is as expected

# Generated at 2022-06-11 08:31:00.269769
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = dict(ansible_facts=dict(a='b', c='d', __ansible_vault='abcd', __ansible_unsafe='what else'))
    secrets = dict(default_password='key')
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(json.dumps(data))
    assert decoded == {"ansible_facts": {'a': 'b', 'c': 'd', '__ansible_vault': 'abcd', '__ansible_unsafe': 'what else'}}
    assert decoded['ansible_facts']['__ansible_vault'].vault.secrets == secrets
    assert decoded['ansible_facts']['__ansible_vault'].vault

# Generated at 2022-06-11 08:31:06.714633
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup fixture_data
    fixture_data = """{
        "__ansible_vault": "foo",
        "__ansible_unsafe": "bar"
    }"""

    # Setup expectations
    expected_value = {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('foo'),
        '__ansible_unsafe': wrap_var('bar'),
    }

    # Perform decoder testing
    decoded = AnsibleJSONDecoder().decode(fixture_data)

    # Perform unit tests
    assert decoded == expected_value

# Generated at 2022-06-11 08:31:13.178723
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = '$ANSIBLE_VAULT;1.1;AES256'
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256', '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256'}
    assert decoder.object_hook(data) == data

# Generated at 2022-06-11 08:31:19.172666
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    This is a test function to test object_hook method
    """
    test_data = {
        '__ansible_vault': 'vault_data',
        '__ansible_unsafe': 'unsafe_data'
    }
    res_object_hook = AnsibleJSONDecoder.object_hook(test_data)
    assert res_object_hook["__ansible_vault"] == 'vault_data'
    assert repr(res_object_hook["__ansible_unsafe"]) == "AnsibleUnsafeText(unsafe_data)"

# Generated at 2022-06-11 08:31:27.865216
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    obj = decoder.object_hook({"test": "123"})
    assert obj == {"test": "123"}

    obj = decoder.object_hook({"__ansible_vault": "AAAAAA=="})
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.startswith('$ANSIBLE_VAULT;')

    obj = decoder.object_hook({"__ansible_unsafe": "passed"})
    assert obj == "passed"

# Generated at 2022-06-11 08:31:38.244686
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:31:46.870429
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test the regular case
    test_ansible_json_encoder_obj = AnsibleJSONEncoder()
    d_regular = {'foo': 'bar', 'baz': 'qux'}
    test_ansible_json_encoder_obj.encode(d_regular)
    test_json_string = ''.join(test_ansible_json_encoder_obj.output)
    test_ansible_json_decoder_obj = AnsibleJSONDecoder()
    # The decoder output should be the same as the input
    assert test_ansible_json_decoder_obj.decode(test_json_string) == d_regular

    # Test the case when __ansible_vault key is present in the input JSON string
    # The decoder output should be an AnsibleVaultEncryptedUnicode object


# Generated at 2022-06-11 08:31:57.956211
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # pylint: disable=unsubscriptable-object,too-many-function-args
    # Test with AnsibleVaultEncryptedUnicode
    vault = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'xxx'})
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vault is None
    assert vault == 'xxx'

    # Test with wrap_var
    wrapped_var = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'xxx'})
    assert isinstance(wrapped_var, AnsibleUnsafeText)
    assert wrapped_var == 'xxx'

    # Test with an empty dict
    dict_var = AnsibleJSONDecoder.object_hook({})
    assert isinstance(dict_var, dict)


# Generated at 2022-06-11 08:32:05.456804
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Encrypted vault
    cipher_text = b'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          34333132313431383132363538393637373631316433333466363637333535643133386564303335\n          31346162643936383263386361623066383034663839656436643163643065643137333634643061\n          33333964356366633765656664363430646533353035663130646233\n'
    plain_text = vault_password = 'vault_password'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(plain_text)

# Generated at 2022-06-11 08:32:09.385043
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = AnsibleJSONDecoder.object_hook(json.loads('{"__ansible_unsafe": "{{my_var}}"}'))
    # AnsibleJSONDecoder is not needed for the test
    assert decoded['__ansible_unsafe'] == wrap_var('{{my_var}}')

# Generated at 2022-06-11 08:32:19.182941
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dummy_vault = ["$ANSIBLE_VAULT;1.1;AES256;ansible;"
                   "1234567890123456789012345678901234567890123456789012345678901234"
                   "5678901234567890123456789012345678901234567890123456789012345678"
                   "90123456789012345678901234567890"]
    jdec = AnsibleJSONDecoder()
    jdec._vaults = {'default': VaultLib(secrets=dummy_vault)}

    data = {'__ansible_vault': '1234567890'}

    obj = jdec.object_hook(data)
    assert hasattr(obj, 'vault')

# Generated at 2022-06-11 08:32:26.345130
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:34.294072
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = """{"__ansible_vault": "ansible-vault 2.6.2......"}"""
    json_dict = {"__ansible_vault": "ansible-vault 2.6.2......"}
    result = 'ansible-vault 2.6.2......'
    decoded = AnsibleJSONDecoder()
    assert decoded.object_hook(json_dict) == AnsibleVaultEncryptedUnicode(result)
    assert json.loads(json_str, object_hook=decoded.object_hook) == result



# Generated at 2022-06-11 08:32:38.682365
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {
        "__ansible_vault": "bogus",
        "__ansible_unsafe": "bogus",
    }

    assert isinstance(json.loads(json.dumps(obj, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder), dict)

# Generated at 2022-06-11 08:32:52.657113
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test case:
    # 1. Has __ansible_vault attribute
    # 2. Has __ansible_unsafe attribute
    # 3. Has both __ansible_vault and __ansible_unsafe attributes
    # 4. Has no __ansible_vault nor __ansible_unsafe attribute
    test_data = [
        {'__ansible_vault': '__VAULT__', '__ansible_unsafe': '__UNSAFE__'},
        {'__ansible_vault': '__VAULT__'},
        {'__ansible_unsafe': '__UNSAFE__'},
        {'foo': 'bar'},
    ]

# Generated at 2022-06-11 08:33:03.529938
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import base64
    import json

    secrets = [b'1234567890']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(["1234567890"])

    # test the json decoder
    decrypted = b'{"a": "data"}'
    payload = json.dumps({'__ansible_vault': base64.b64encode(decrypted).decode('utf-8')})
    result = decoder.decode(payload)
    assert result == {'a': 'data'}

    # test the yaml decoder

# Generated at 2022-06-11 08:33:04.568611
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass



# Generated at 2022-06-11 08:33:13.264107
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:24.307035
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = []
    secrets.append('secret')
    secrets.append('secret2')
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    v1 = json.dumps({'__ansible_vault': 'vault data'}, cls=AnsibleJSONEncoder)
    v2 = json.dumps({'__ansible_unsafe': 'unsafe value'}, cls=AnsibleJSONEncoder)
    s1 = '{"__ansible_vault": "vault data"}'
    s2 = '{"__ansible_unsafe": "unsafe value"}'
    assert(v1 == s1)
    assert(v2 == s2)

# Generated at 2022-06-11 08:33:31.814942
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = [
        '{"__ansible_vault": "foo"}',
        '{"__ansible_vault": "foo", "__ansible_unsafe": "bar"}',
        '{"__ansible_unsafe": "bar", "__ansible_vault": "foo"}',
        '{"__ansible_unsafe": "bar"}'
    ]
    for data in test_data:
        assert(isinstance(AnsibleJSONDecoder(data), AnsibleVaultEncryptedUnicode))


# Generated at 2022-06-11 08:33:38.362671
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Create a sample Ansible secret
    secret = 'ansible-secret'

    testobj = dict(__ansible_vault=secret)

    # Create an instance of AnsibleJSONDecoder
    decoder_inst = AnsibleJSONDecoder()

    # Set the secret to be used for decryption
    set_secrets = getattr(decoder_inst.__class__, 'set_secrets')
    set_secrets(secrets=secret)

    # Decrypt
  

# Generated at 2022-06-11 08:33:49.032823
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Failing test: check handling of an encrypted attribute
    def test_encrypted_variable_decoding_fails_without_a_vault():
        data = '{"__ansible_vault": "foo"}'
        decoded = json.loads(data, cls=AnsibleJSONDecoder)
        assert type(decoded) == dict
        assert decoded['__ansible_vault'] == 'foo'

    # Test handling of a normal attribute
    def test_non_encrypted_variable_decoding():
        data = '{"foo": "bar"}'
        decoded = json.loads(data, cls=AnsibleJSONDecoder)
        assert type(decoded) == dict
        assert decoded == {'foo': 'bar'}

    # Test handling of an encrypted attribute

# Generated at 2022-06-11 08:33:59.595990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    pairs = jd.object_hook({
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
        '__ansible_unsafe': '!vault |',
    })

    assert(isinstance(pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode) is True)
    assert(hasattr(pairs['__ansible_vault'], 'vault') is True)
    assert(hasattr(pairs['__ansible_vault'], 'vault') is True)
    assert(pairs['__ansible_vault'].value == '$ANSIBLE_VAULT;1.1;AES256')


# Generated at 2022-06-11 08:34:09.377489
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:18.689327
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"__ansible_unsafe": "ya"}
    data_json = json.dumps(data, cls=AnsibleJSONEncoder)
    results = json.loads(data_json, cls=AnsibleJSONDecoder)
    assert results['__ansible_unsafe'] == wrap_var("ya")
    assert isinstance(results['__ansible_unsafe'], wrap_var("ya").__class__)

# Generated at 2022-06-11 08:34:25.684257
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.json import AnsibleJSONDecoder

    # Create a JSON string
    test_json_string = u'{"name": "Jeff", "__ansible_vault": "VGVzdA=="}'
    # Create a JSON decoder with password "password"
    test_json_decoder = AnsibleJSONDecoder(secrets=[('default', 'password')])
    # Decode the JSON string
    test_json_object = json.loads(test_json_string, cls=test_json_decoder)

    # test_json_object must be a Python dictionary with keys "name" and "__ansible_vault"
    assert isinstance(test_json_object, dict)
    assert len(test_json_object)

# Generated at 2022-06-11 08:34:36.580411
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:46.148481
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = """{
    "__ansible_unsafe": {
        "name": "whatever",
        "value": "/bin/foo"
    },
    "__ansible_vault": "dasdasdasd"
}
"""
    json_dict = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert json_dict.get("__ansible_unsafe").get("value") == "/bin/foo"
    assert str(json_dict.get("__ansible_vault")) == "dasdasdasd"

# Make a JSON output class that will output AnsibleSafeText and AnsibleVaultEncryptedUnicode values as strings

# Generated at 2022-06-11 08:34:53.953278
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Unit test for method object_hook of class AnsibleJSONDecoder."""
    import os

    import pytest

    from ansible.parsing.vault import VaultLib

    s = VaultLib(secrets=['secret'])


# Generated at 2022-06-11 08:35:04.764948
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # base64 encoded string of "0123456789"
    b64_str = b'MDEyMzQ1Njc4OQ=='
    # base64 encoded string of "abcdefghij"
    b64_str2 = b'YWJjZGVmZ2hpag=='
    # base64 encoded string of "This is a long key"
    b64_str_long = b'VGhpcyBpcyBhIGxvbmcga2V5'

    # An encrypted Ansible Vault string
    ansible_vault_str = b'$ANSIBLE_VAULT;1.1;AES256\n' + b64_str2 + b'\n' + b64_str + b'\n'

    # An encrypted Ansible Vault string with 256 bit key
    ansible_vault

# Generated at 2022-06-11 08:35:12.849788
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['passw0rd']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

    pairs1 = {'__ansible_vault': 'passw0rd'}
    pairs2 = {'__ansible_unsafe': 'passw0rd'}
    pairs3 = {'__ansible_vault': 'passw0rd', '__ansible_unsafe': 'passw0rd'}

    decoder.object_hook(pairs1)
    decoder.object_hook(pairs2)
    decoder.object_hook(pairs3)


# Generated at 2022-06-11 08:35:24.192934
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:34.380855
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    json_decoder._vaults['default'] = VaultLib(secrets=['test'])

    decoded_data = json_decoder.decode('{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n"}')
    assert isinstance(decoded_data, AnsibleVaultEncryptedUnicode)
    assert decoded_data.vault == json_decoder._vaults['default']

    decoded_data = json_decoder.decode('{"__ansible_unsafe": "Secret information"}')
    assert decoded_data == wrap_var('Secret information')


# Generated at 2022-06-11 08:35:42.835597
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test, that AnsibleJSONDecoder will decrypt vaulted variables to
    AnsibleVaultEncryptedUnicode.
    """
    # generate test data
    vaulted_data = []

    # Create a vault
    vlt = VaultLib()
    vlt_secret = ['vlt_secret']

    # generate secret data
    secrets = ['secret_1', 'secret_2', 'secret_3']

    # encrypt secrets to vault
    vaulted_secrets = [vlt.encrypt(s) for s in secrets]

    # generate decrypted data
    data = []
    for secret in secrets:
        data.append({'__ansible_vault': vlt.encrypt(secret)})

# Generated at 2022-06-11 08:36:00.391856
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_decoder = AnsibleJSONDecoder()

    # test for Vault data

# Generated at 2022-06-11 08:36:05.669477
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{'secret': 'cb'}]
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test __ansible_vault
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:36:10.441278
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {
        'key1': 'value1',
        'key2': 'value2'
    }

    pairs = decoder.object_hook(pairs)

    assert pairs['key1'] == 'value1'
    assert pairs['key2'] == 'value2'



# Generated at 2022-06-11 08:36:19.669630
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # test for __ansible_vault
    vault_data = json.dumps({'__ansible_vault': 'encrypted value'})
    assert decoder.decode(vault_data) == AnsibleVaultEncryptedUnicode('encrypted value')

    # test for __ansible_unsafe
    unsafe_data = json.dumps({'__ansible_unsafe': 'unsafe value'})
    assert decoder.decode(unsafe_data) == wrap_var('unsafe value')

    # test for no special key
    unsafe_data = json.dumps({'key': 'unsafe value'})
    assert decoder.decode(unsafe_data) == {'key': 'unsafe value'}

# Generated at 2022-06-11 08:36:30.903824
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml


# Generated at 2022-06-11 08:36:41.674329
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import ansible.constants as C
    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText

    d = AnsibleJSONDecoder()
    d.set_secrets(C.DEFAULT_VAULT_SECRET_FILE)


# Generated at 2022-06-11 08:36:51.389635
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    decoder = AnsibleJSONDecoder()

    # test 1, pass a dict with __ansible_vault item

# Generated at 2022-06-11 08:36:56.775611
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    json_data = '{"__ansible_unsafe": "This is a string that should be marked as unsafe."}'
    decoded_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert decoded_data['__ansible_unsafe'] == wrap_var(u"This is a string that should be marked as unsafe.")


# Generated at 2022-06-11 08:37:05.066906
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:37:09.687711
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': ['{{', 'password', '}}'], '__ansible_vault': 'vaultvalue'}) == {'__ansible_unsafe': ['{{', 'password', '}}'], '__ansible_vault': 'vaultvalue'}


# Generated at 2022-06-11 08:37:34.792921
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.json import AnsibleJSONDecoder


# Generated at 2022-06-11 08:37:44.878867
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    vault_encrypted_unicode = '$ANSIBLE_VAULT;1.2;AES256;ansible_secret'
    decoded_data = json.loads('{"__ansible_vault": "%s"}' % vault_encrypted_unicode,
                              cls=AnsibleJSONDecoder)
    assert isinstance(decoded_data, dict)
    assert isinstance(decoded_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded_data['__ansible_vault'] == AnsibleVaultEncryptedUnicode(vault_encrypted_unicode)
    assert decoded_data['__ansible_vault'].vault is None

    # Test for AnsibleUnsafe?
    # AnsibleUn

# Generated at 2022-06-11 08:37:50.643372
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.collections import ImmutableDict
    get_decoded_value = AnsibleJSONDecoder().object_hook
    assert isinstance(get_decoded_value({'a': 'b'}), dict)
    assert isinstance(get_decoded_value({'__ansible_vault': 'a'}), AnsibleVaultEncryptedUnicode)
    assert isinstance(get_decoded_value({'__ansible_unsafe': 'a'}), ImmutableDict)

# Generated at 2022-06-11 08:37:57.685497
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    vault_id = 'test_vault_id'
    test_data = {
        "before": {
            "__ansible_vault": vault_id,
        },
        "after": {
            "__ansible_vault": AnsibleVaultEncryptedUnicode(vault_id),
        }
    }
    AnsibleJSONDecoder.set_secrets('default')
    assert(decoder.decode(json.dumps(test_data)) == test_data)

# Generated at 2022-06-11 08:38:08.436425
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """ Tests for the AnsibleJSONDecoder class"""
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader

    decoder = AnsibleJSONDecoder()
    loader = AnsibleLoader(None, None, object_pairs_hook_cb=decoder.object_hook)
    data = loader.load({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test\n3132333435363738393031323334353637383930313233343536373839303132\n'})
    assert(isinstance(data, dict))
    assert(isinstance(data['__ansible_vault'], objects.AnsibleVaultEncryptedUnicode))

# Generated at 2022-06-11 08:38:16.957888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test AnsibleVaultEncryptedUnicode object creation
    test_input = '{"__ansible_vault": "test value"}'
    decoder = AnsibleJSONDecoder()
    pairs = decoder.decode(test_input)
    assert isinstance(pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert pairs['__ansible_vault'] == "test value"

    # Test AnsibleUnsafeText object creation
    test_input = '{"__ansible_unsafe": "test value"}'
    decoder = AnsibleJSONDecoder()
    pairs = decoder.decode(test_input)
    assert isinstance(pairs['__ansible_unsafe'], wrap_var._AnsibleUnsafeText)
    assert pairs['__ansible_unsafe']

# Generated at 2022-06-11 08:38:27.606419
# Unit test for method object_hook of class AnsibleJSONDecoder