

# Generated at 2022-06-11 08:28:38.155630
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class MockVault:
        def decrypt(self, data):
            return 'mockdecrypted_' + data

    class MockVaultLib:
        def __init__(self, vaults):
            self.vaults = vaults

        def get_vault_secret(self, vault_id):
            return self.vaults[vault_id]

    fake_vault_lib = MockVaultLib({'test_test_test': MockVault()})
    decoder = AnsibleJSONDecoder(vaults=fake_vault_lib)

    data = {'__ansible_vault': 'test_test_test'}
    result = decoder.object_hook(data)

    assert result.vault == fake_vault_lib
    assert result.vault_id == 'test_test_test'
   

# Generated at 2022-06-11 08:28:48.328431
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test 1 - Test object_hook with a vault and a non vault text
    test_dict = {
        "__ansible_vault": "It is a vault text",
        "__ansible_unsafe": "It is a unsafe text",
    }
    result = AnsibleJSONDecoder().object_hook(test_dict)
    assert result.__ansible_vault == 'It is a vault text'
    assert result.__ansible_unsafe == 'It is a unsafe text'
    assert isinstance(result.__ansible_vault, AnsibleVaultEncryptedUnicode)

    # Test 2 - Test object_hook with only a vault text
    test_dict = {
        "__ansible_vault": "It is a vault text",
    }

# Generated at 2022-06-11 08:28:55.609733
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Given
    secrets = [b'vault_password']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

    # When

# Generated at 2022-06-11 08:29:01.361566
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)
    encoded = '''{
        "__ansible_vault": " "
    }'''

    decoded = AnsibleJSONDecoder().decode(encoded)
    assert isinstance(decoded, dict)
    assert decoded['__ansible_vault'] == AnsibleVaultEncryptedUnicode(' ')
    assert decoded['__ansible_vault'].secrets == secrets

# Generated at 2022-06-11 08:29:12.113232
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    test_data = {"__ansible_vault": "6c70736567617661696c65646578"}
    test_data = ansible_json_decoder.object_hook(test_data)

    assert '__ansible_vault' in test_data
    assert isinstance(test_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(test_data['__ansible_vault'].vault, VaultLib)
    assert test_data['__ansible_vault'].vault.secrets == []
    assert test_data['__ansible_vault'].vault.password == None
    assert test_data['__ansible_vault'].vault.keys == []


# Generated at 2022-06-11 08:29:18.209510
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = {"__ansible_vault":"my vault value", "__ansible_unsafe":"my unsafe value"}

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    decoded = decoder.decode(json.dumps(d))

    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['__ansible_unsafe'], AnsibleUnsafeText)

# Generated at 2022-06-11 08:29:28.457817
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for safe_eval
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder.decode('{"__ansible_unsafe": "{{ foo }}"}')
    decoder.decode('{"__ansible_unsafe": "{{ foo }}", "other": "{{ bar }}"}')

    # Test for vault_encrypted
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder.decode('{"__ansible_vault": "AAAA"}')
    decoder.decode('{"__ansible_vault": "AAAA", "other": "{{ bar }}"}')

# Generated at 2022-06-11 08:29:38.428087
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import tempfile

    my_vault_password = 'secret'


# Generated at 2022-06-11 08:29:40.394661
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # should handle an empty dictionary without raising exception
    decoder.object_hook({})

# Generated at 2022-06-11 08:29:49.430746
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    #Setup
    data = '''{
        "hosts": ["host1","host2"],
        "vars": {"ansible_become": true },
        "__ansible_vault": "vault text",
        "__ansible_unsafe": "unsafe text"
    }'''

    decoder = AnsibleJSONDecoder(data)
    decoded_data = decoder.decode(data)

    # Exercise
    output_data = decoder.object_hook(decoded_data)

    # Verify
    assert output_data['__ansible_vault'] == "vault text"
    assert output_data['__ansible_unsafe'] == "unsafe text"
    assert output_data['hosts'] == ["host1","host2"]

# Generated at 2022-06-11 08:30:02.841531
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    import sys
    import json

    class AnsibleJSONDecoderTester(unittest.TestCase):
        # test if the object_hook method converts AnsibleVaultEncryptedUnicode object
        def test_object_hook(self):
            # method object_hook returns the raw string from json, if the json contains key '__ansible_vault'
            decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:30:13.574602
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for existence of json'ey object
    json_object_hook = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n'
                           '3964643...\n',
        '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256\n'
                            '3964643...\n'
    }

    # Test for existence of json'ey object
    ansible_json_decoder = AnsibleJSONDecoder()
    new_json_object_hook = ansible_json_decoder.object_hook(json_object_hook)
    assert new_json_object_hook['__ansible_vault'] == json_object_hook['__ansible_vault']

# Generated at 2022-06-11 08:30:24.297472
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:32.960803
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    secrets = None
    AnsibleJSONDecoder.set_secrets(secrets)
    assert 'default' in AnsibleJSONDecoder._vaults

    assert(type(decoder.decode('{"__ansible_unsafe": true}')) is dict)

    assert(type(decoder.decode('{"__ansible_vault": "foo"}')) is AnsibleVaultEncryptedUnicode)
    assert(decoder.decode('{"__ansible_vault": "foo"}').vault == AnsibleJSONDecoder._vaults['default'])



# Generated at 2022-06-11 08:30:43.126289
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "AQAAABAAAA"}'
    json_str_2 = '{"__ansible_vault": "AQAAABAAAA", "__ansible_unsafe": "should_not_be_a_string"}'
    json_str_3 = '{"__ansible_vault": "AQAAABAAAA", "__ansible_unsafe": {"should": "be_a_dict"}}'
    secrets = ['test']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert isinstance(json.loads(json_str, cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:30:52.909025
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import unittest

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    class TestAnsibleJSONDecoder(unittest.TestCase):
        def setUp(self):
            secrets = 'some_super_secure_string'
            self.credentials = '1234567890'
            self.secrets = VaultLib(secrets=[secrets])
            AnsibleJSONDecoder.set_secrets(secrets)
            self.vaulted_data = {'__ansible_vault': self.credentials}

# Generated at 2022-06-11 08:31:02.924861
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test case 1
    # input data
    json_data = '{"__ansible_vault": "some encrypted data", "__ansible_unsafe": "some unsafe data"}'
    json_secrets = ['secret1','secret2']
    # set secrets
    AnsibleJSONDecoder.set_secrets(json_secrets)
    # decode json
    decoded_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    # check AnsibleVaultEncryptedUnicode
    assert isinstance(decoded_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded_data['__ansible_vault'].vault._secrets == json_secrets
    # check unsafe data

# Generated at 2022-06-11 08:31:14.023609
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestClass(object):
        fake_secret = 'fake_secret'

    obj = TestClass()
    AnsibleJSONDecoder.set_secrets(obj)

    valid_ciphertext = '$ANSIBLE_VAULT;1.1;AES256;ansible\n33303837626131663937306664643766643036656436333563393163626565383133333936306433\n65613434346161323266333539363636613233383536333036653438306132313261333539663665\n6363633265306434353665363330\n'

# Generated at 2022-06-11 08:31:18.042362
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_value = {
        "vault": "secret",
        "__ansible_unsafe": "$this is safe"}
    value = AnsibleJSONDecoder.object_hook(test_value)
    assert isinstance(value, dict)
    assert isinstance(value["vault"], str)
    assert isinstance(value["__ansible_unsafe"], str)

# Generated at 2022-06-11 08:31:26.984563
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets=["test"]
    AnsibleJSONDecoder.set_secrets(secrets)

    data = {
        'test': 'test',
        '__ansible_vault': 'test',
        '__ansible_unsafe': 'test'
    }

    result = AnsibleJSONDecoder().object_hook(data)
    assert result['test'] == 'test'
    assert result['__ansible_vault']
    assert result['__ansible_vault'].unvault() == 'test'
    assert result['__ansible_unsafe']
    assert result['__ansible_unsafe'].data == 'test'

# Generated at 2022-06-11 08:31:30.018271
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """ This function is used to test the AnsibleJSONDecoder's object_hook function """
    assert True

# Generated at 2022-06-11 08:31:40.424990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:31:47.851311
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # safe data
    data = {'NotSafe': 'NotSafe'}
    decoded = decoder.decode(json.dumps(data))
    assert data == decoded

    # unsafe data
    data = {'__ansible_unsafe': 'safe'}
    decoded = decoder.decode(json.dumps(data))
    assert 'safe' == getattr(decoded.get('__ansible_unsafe', None), 'value', None)

    # vault data
    data = {'__ansible_vault': 'safe'}
    decoded = decoder.decode(json.dumps(data))
    assert 'safe' == getattr(decoded.get('__ansible_vault', None), 'vault_text', None)

    # unsafe

# Generated at 2022-06-11 08:31:57.788818
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    unsafe_text = 'mytext'
    json_encoded_unsafe_text = '{"__ansible_unsafe": "%s"}' % unsafe_text
    json_decoder = AnsibleJSONDecoder()
    unsafe_proxy = json_decoder.object_hook({"__ansible_unsafe": "mytext"})
    assert(isinstance(unsafe_proxy, AnsibleUnsafe))
    assert(unsafe_proxy._unsafe_proxy_inner == unsafe_text)
    assert(json.loads(json_encoded_unsafe_text, cls=json_decoder)._unsafe_proxy_inner == unsafe_text)

# Generated at 2022-06-11 08:32:05.374303
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:14.725507
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    import json
    import io

    # Initialize
    test_json = io.StringIO('{"__ansible_unsafe" : "test unsafe string"}').read()
    vault = VaultLib(["password"])
    test_json_vault = json.dumps({"__ansible_vault": vault.encrypt("test vault string")})
    test_json_vault = io.StringIO(test_json_vault).read()
    ansible_json_decoder = AnsibleJSONDecoder.AnsibleJSONDecoder()

    # Test no object prefix found
    test_json_no

# Generated at 2022-06-11 08:32:24.019785
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import base64

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vaultlib import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    PASS = b'hello world'
    # construct ansible vault encrypted file
    # taken from https://docs.ansible.com/ansible/devel/dev_guide/developing_modules_documenting.html#json-formatting

# Generated at 2022-06-11 08:32:34.526874
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    decoder = AnsibleJSONDecoder()

    # Test
    pairs = {'__ansible_vault': 'ansible'}
    ansible_vault = decoder.object_hook(pairs)
    pairs['__ansible_vault'] = ansible_vault
    assert pairs == {'__ansible_vault': 'ansible'}

    pairs = {'__ansible_unsafe': 'ansible'}
    ansible_unsafe = decoder.object_hook(pairs)
    pairs['__ansible_unsafe'] = ansible_unsafe
    assert pairs == {'__ansible_unsafe': 'ansible'}

    pairs = {'ansible': 'ansible'}
    ansible = decoder.object_hook(pairs)

# Generated at 2022-06-11 08:32:45.279769
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:52.582528
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder == decoder.object_hook({})
    assert decoder == decoder.object_hook({'__ansible_vault': 'string'})
    assert decoder == decoder.object_hook({'__ansible_unsafe': 'string'})
    assert decoder != decoder.object_hook({'__ansible_vault': 'string', '__ansible_unsafe': 'string'})

# Generated at 2022-06-11 08:33:05.335317
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    source = str()
    # GIVEN an empty string
    # WHEN converting to json
    result = json.loads(source, object_hook=decoder.object_hook) # noqa
    # THEN assert result is None
    assert result is None

    source = str("""{
    "list": [1, 2, 3],
    "string": "some text",
    "value": 42
    }""")
    # GIVEN a string to a json object
    # WHEN converting to json
    result = json.loads(source, object_hook=decoder.object_hook) # noqa
    # THEN assert result is not None and is a dictionary
    assert result is not None
    assert isinstance(result, dict)



# Generated at 2022-06-11 08:33:11.464120
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jsonstring = """{"__ansible_vault" : "testvault", "__ansible_unsafe": "testunsafe"}"""

    # Test method object_hook of class 'AnsibleJSONDecoder'
    json_data = json.loads(jsonstring, cls=AnsibleJSONDecoder)

    assert json_data['__ansible_vault'] == 'testvault'
    assert json_data['__ansible_unsafe'] == 'testunsafe'



# Generated at 2022-06-11 08:33:21.933476
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Dummy secrets
    secrets = [
        {'vault_id': 'default'},
        {'vault_id': 'vault:vault_id'},
    ]

    # Dummy data

# Generated at 2022-06-11 08:33:33.211320
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    
    test_secrets = [
        'secret1',
        'secret2',
        'secret3'
    ]
    
    vault_text = "$ANSIBLE_VAULT;1.2;AES256;default\n"
    vault_text += "666f6f626172213a206561323263646239353437633731643238393130376630323063370a\n"
    vault_text += "343039386438653161373935313564653834643138313236376666636132336661323839620a\n"
    vault_text += "383161323233336636303433386438363161346634316464653535623162336637336163610a\n"

# Generated at 2022-06-11 08:33:42.130547
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    vault_pass = "vault_pass"
    decoder.set_secrets(vault_pass)
    # test __ansible_vault
    res = decoder.object_hook({'__ansible_vault': "vault_data"})
    assert isinstance(res, AnsibleVaultEncryptedUnicode)
    assert isinstance(res.vault, VaultLib)
    assert hasattr(res.vault, 'secrets')
    assert vault_pass == res.vault.secrets
    # test __ansible_unsafe
    res = decoder.object_hook({'__ansible_unsafe': "unsafe_data"})
    assert isinstance(res, wrap_var)

# Generated at 2022-06-11 08:33:47.165709
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({}) == {}
    assert decoder.object_hook({'__ansible_vault': ''}) == AnsibleVaultEncryptedUnicode('')
    assert decoder.object_hook({'__ansible_unsafe': ''}) == wrap_var('')

# Generated at 2022-06-11 08:33:57.997794
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:07.870276
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Simple check for AnsibleVaultEncryptedUnicode object
    json_str = '{"ansible_vault": "@9q3fh98qfhew8"}'
    json_dict = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_dict['ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Simple check for wrap_var object
    json_str = '{"ansible_unsafe": "value"}'
    json_dict = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_dict['ansible_unsafe'], wrap_var)

    # Simple check for both objects

# Generated at 2022-06-11 08:34:12.299041
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common._collections_compat import Mapping

    test_data = '{"__ansible_vault": "test"}'
    test_password = 'test_password'
    AnsibleJSONDecoder.set_secrets([test_password])
    decoded = json.loads(test_data, cls=AnsibleJSONDecoder)
    assert isinstance(decoded, Mapping)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:34:13.675196
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    assert isinstance(AnsibleJSONDecoder.object_hook(None, None), dict)

# Generated at 2022-06-11 08:34:25.477256
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {
        "__ansible_vault": "ANSIBLE_VAULT;1.1;AES256\n3931383533306666343639346661653534633763643865386366303164653265326534316531396332\n3430653830383338333136396530326566336339626261333463613361323962663639306232613065\n3337383430646535373965316363316366393834376139636535323239336662633639306564343931\n303732663836642f7d681327c\n",
        "__ansible_unsafe": {
            "some_nested_key": "some_value"
        }
    }

    assert obj == json.loads

# Generated at 2022-06-11 08:34:36.199227
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test_vault_text_is_decoded
    vault_json = '{"__ansible_vault": "_AAAAAQAAAAIAAADA1f9X9JFgvR8UhYDw2Z21zY2d1Y3JlZW5lc3M="}'
    decoded_vault = json.loads(vault_json, cls=AnsibleJSONDecoder)
    expected_result = AnsibleVaultEncryptedUnicode('mypassword')
    assert decoded_vault == {'__ansible_vault': expected_result}
    assert decoded_vault['__ansible_vault'].vault == AnsibleJSONDecoder._vaults['default']

    # test_unsafe_is_wrapped

# Generated at 2022-06-11 08:34:46.931424
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    import json

    class DummyVault(object):
        def __init__(self, *args, **kwargs):
            pass

    secret = 'secret'
    vault_id = '1234567890'
    ansible_vault = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;' + vault_id + secret}
    raw = {'__ansible_vault': secret}
    \
    ansible_json_decoder = AnsibleJSONDecoder(None, None, None)

# Generated at 2022-06-11 08:34:55.215717
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()

    # Test empty dict
    json_string = "{" + "}"
    expected = {}
    assert(ansible_json_decoder.object_hook(pairs=expected) == expected)

    # Test single item in dict
    json_string = "{" + '"__ansible_vault": "test"' + "}"
    expected = {'__ansible_vault': 'test'}
    assert(ansible_json_decoder.object_hook(pairs=expected) == expected)

    # Test multiple item in dict
    json_string = "{" + "}"
    expected = {'__ansible_vault': 'test', '__ansible_unsafe': 'test', 'normal': 'test'}

# Generated at 2022-06-11 08:35:06.001871
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'test_pass'

# Generated at 2022-06-11 08:35:16.793936
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {'__ansible_vault': 'abc', '__ansible_unsafe': 'abc'}
    decoder = AnsibleJSONDecoder()
    obj2 = decoder.object_hook(obj)

    vault = obj.get('__ansible_vault')
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.decrypt() == 'abc'
    vault = obj2.get('__ansible_vault')
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.decrypt() == 'abc'

    unsafe = obj.get('__ansible_unsafe')
    assert not isinstance(unsafe, AnsibleVaultEncryptedUnicode)
    unsafe = obj2.get('__ansible_unsafe')

# Generated at 2022-06-11 08:35:25.982696
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class FakeVault:
        def __init__(self, secrets=None):
            self.secrets = secrets

        def decrypt(self, data):
            return data+self.secrets

    secret = 'some_secret'

    json_data = {'__ansible_vault': secret}
    vaults = {'default': FakeVault(secrets=secret)}
    data_decoded = json.loads(
        json.dumps(json_data),
        cls=AnsibleJSONDecoder,
        vaults=vaults
    )

    assert data_decoded['__ansible_vault'] == secret+secret

# Generated at 2022-06-11 08:35:36.297930
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    AnsibleJSONDecoder.set_secrets(dict(vault_password='test'))
    test_json = json.dumps({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n3533333639333031343630343335323330313335303362303130633262666600\n'})

# Generated at 2022-06-11 08:35:44.132308
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    raw = '''
{"__ansible_vault": "V2VzdCBJc2xhbmQgU3VwZXJtaXNzaW9uIFJlcG9ydA==\n", "__ansible_vault__identifier": "wally@django"}
    '''

    # class AnsibleJSONDecoder(json.JSONDecoder)
    # def object_hook(self, pairs):
    # # note, this is just a demo of how the vault system is used, not a real test of the json parsing itself
    #     for key in pairs:
    #         if key == '__ansible_vault':
    #             value = AnsibleVaultEncryptedUnicode(pairs[key])
    #             if self._vaults:
    #                 value.vault = self._vaults

# Generated at 2022-06-11 08:35:56.953455
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.parser import AnsibleParser

    vault_db = {'default': {'filename': '.vault_pass', 'password': 'secret'}}
    AnsibleJSONDecoder.set_secrets(vault_db['default'])
    # load data from vault
    test_data_vault = AnsibleParser().parse('test2.yaml')[0]
    # load data from unsafe
    test_data_unsafe = AnsibleParser().parse('test3.yaml')[0]
    # load data from python
    test_data_python = AnsibleParser().parse('test4.yaml')[0]
    # load data from custom object
    test_data_custom = AnsibleParser().parse('test5.yaml')[0]

    test_data = {}
    test_

# Generated at 2022-06-11 08:36:16.618838
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # TODO: add proper testing here, got to learn first.
    decoder = AnsibleJSONDecoder()
    # Test the decoding of an ansible_vault'd string

# Generated at 2022-06-11 08:36:25.737011
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # value is dict and include "__ansible_vault" key
    object_hook_dict = decoder.object_hook({"__ansible_vault": "aGVsbG8gd29ybGQ="})
    assert isinstance(object_hook_dict, AnsibleVaultEncryptedUnicode)
    assert object_hook_dict._value == "aGVsbG8gd29ybGQ="

    # value is dict and include "__ansible_unsafe" key
    object_hook_dict = decoder.object_hook({"__ansible_unsafe": "aGVsbG8gd29ybGQ="})
    assert isinstance(object_hook_dict, wrap_var)

# Generated at 2022-06-11 08:36:36.272446
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # tests that all data returns without being modified
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode('{ "key": "value" }') == {"key": "value"}
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode('{ "__ansible_unsafe": "value" }') == {"__ansible_unsafe": "value"}

    # test that data is correctly wrapped via __ansible_unsafe
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode('{ "__ansible_unsafe": "value" }').unsafe_proxy.value == "value"

    # test that data is correctly wrapped via __ansible_vault

# Generated at 2022-06-11 08:36:47.322787
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # test wrap_var
    x = decoder.object_hook({'__ansible_unsafe': "{{some_value}}"})
    assert x == wrap_var("{{some_value}}")
    # test decryption
    decoder.set_secrets(['hunter2'])
    x = decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n383136626261656135333934303938373530633231626337616231653836613034663934363833\nb\nsecret'})
    # encrypted form is a unicode string, decrypted form is a byte string
    assert x == 'secret' and isinstance(x, type(''))

# Generated at 2022-06-11 08:36:58.255128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test various value scenarios of the method object_hook of class AnsibleJSONDecoder
    """
    test_data = [
        { '__ansible_vault': '0123' },
        { '__ansible_vault': '0123', 'sample': '5678' },
        { 'sample': '5678' },
        { '__ansible_vault': '0123', '__ansible_unsafe': True },
        { '__ansible_unsafe': True },
        { '__ansible_unsafe': True, 'sample': '5678' }
    ]

    for pairs in test_data:
        value = AnsibleJSONDecoder().object_hook(pairs)

# Generated at 2022-06-11 08:37:02.505258
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    #setup
    ansible_json_decoder = AnsibleJSONDecoder()
    # test
    test_dict = {'__ansible_unsafe': '$var'}
    actual_returned_obj = ansible_json_decoder.object_hook(test_dict)
    #assert
    assert actual_returned_obj['__ansible_unsafe'] == '$var'

# Generated at 2022-06-11 08:37:06.640936
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'vault'}) == AnsibleVaultEncryptedUnicode('vault')
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe'}) == wrap_var('unsafe')



# Generated at 2022-06-11 08:37:16.031932
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_vault': 'some_encrypted_string',
        '__ansible_unsafe': 'some_unsafe_string',
        'some_key_2': 'value_2',
        'some_key_3': 'value_3'
    }
    assert ansible_json_decoder.object_hook(pairs) == {
        '__ansible_vault': 'some_encrypted_string',
        '__ansible_unsafe': 'some_unsafe_string',
        'some_key_2': 'value_2',
        'some_key_3': 'value_3'
    }

# Generated at 2022-06-11 08:37:23.560764
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = json.dumps({'bar': 'foo'})

    # Create a vault with one secret
    vault = VaultLib(secrets=[secret])
    encrypted = vault.encrypt(json.dumps('BAR'))

    # Create a AnsibleVault object
    ansible_vault = AnsibleVaultEncryptedUnicode(encrypted)
    ansible_vault.vault = vault

    # Check the object_hook method
    assert AnsibleJSONDecoder({}, object_hook=AnsibleJSONDecoder.object_hook).\
        object_hook({'__ansible_vault': encrypted}) == ansible_vault

# Generated at 2022-06-11 08:37:30.248115
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # __ansible_vault should return a AnsibleVaultEncryptedUnicode object
    data = {'__ansible_vault': "reader"}
    cls = AnsibleJSONDecoder()
    assert isinstance(cls.object_hook(data), AnsibleVaultEncryptedUnicode)

    # __ansible_unsafe should return a proxied object
    data = {'__ansible_unsafe': "reader"}
    cls = AnsibleJSONDecoder()
    assert isinstance(cls.object_hook(data), AnsibleUnsafeText)

# Generated at 2022-06-11 08:37:58.776643
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test vault strings
    testdata = [{
        '__ansible_vault': 'foo',
    }]
    assert json.loads(json.dumps(testdata), cls=AnsibleJSONDecoder) == [{
        '__ansible_vault': AnsibleVaultEncryptedUnicode('foo'),
    }]
    assert json.loads(json.dumps(testdata, cls=AnsibleJSONEncoder),
                     cls=AnsibleJSONDecoder) == [{
                         '__ansible_vault': AnsibleVaultEncryptedUnicode('foo'),
                     }]

    # Test unsafe strings
    testdata = [{
        '__ansible_unsafe': 'foo',
    }]

# Generated at 2022-06-11 08:38:09.544312
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # set __ansible_vault in pairs
    pairs = {'__ansible_vault': 'foo'}

    # mock VaultLib
    mocked_VaultLib = VaultLib()
    mocked_VaultLib.secrets = 'foo secret'
    mocked_VaultLib.secret_id = 'foo'

    # create mock class
    class MockedAnsibleJSONDecoder(json.JSONDecoder):
        _vaults = {'default': mocked_VaultLib}

        def __init__(self, *args, **kwargs):
            kwargs['object_hook'] = self.object_hook
            super(json.JSONDecoder, self).__init__(*args, **kwargs)

        @classmethod
        def set_secrets(cls, secrets):
            cls._vaults['default'] = Vault

# Generated at 2022-06-11 08:38:17.532169
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest

    secrets = 'foo'
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults == {'default': VaultLib(secrets=secrets)}

    assert AnsibleJSONDecoder.object_hook({}) == {}

    assert AnsibleJSONDecoder.object_hook({'k': 'v'}) == {'k': 'v'}


# Generated at 2022-06-11 08:38:28.156704
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class MockVaultLib(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.decrypted = 'testdata'

        def decrypt(self, data):
            return self.decrypted

    vault = MockVaultLib()
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = vault
