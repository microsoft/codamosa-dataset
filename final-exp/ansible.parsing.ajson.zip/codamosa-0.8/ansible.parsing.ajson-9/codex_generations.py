

# Generated at 2022-06-11 08:28:36.692502
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dct = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n',
        '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256\n'
    }
    decoded = AnsibleJSONDecoder.object_hook(dct)
    assert isinstance(decoded, dict)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:28:43.359833
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ajd = AnsibleJSONDecoder()
    secrets = [b'12345', b'54321']
    ajd.set_secrets(secrets)
    

# Generated at 2022-06-11 08:28:53.016354
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_passwd = "test_vault_password"

# Generated at 2022-06-11 08:28:58.685151
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '1234567890'
    decoder = AnsibleJSONDecoder.set_secrets(secret)
    my_dict = {'name' : 'my_name', 'password' : 'my_password', '__ansible_vault' : 'my_vault'}
    result = json.dumps(my_dict, cls=AnsibleJSONEncoder)
    print(result)
    assert result == '{"name": "my_name", "__ansible_unsafe": "my_vault"}'

# Generated at 2022-06-11 08:29:04.353982
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:29:15.059753
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    inp = {'a': 'b', '__ansible_vault': 'vault-value'}
    secret = 'secret'
    vault = VaultLib(secrets=[secret])
    out = AnsibleJSONDecoder.object_hook(inp)
    assert out['a'] == 'b'
    assert isinstance(out['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert out['__ansible_vault'].vault == vault

    inp = {'a': 'b', '__ansible_unsafe': 'unsafe-value'}


# Generated at 2022-06-11 08:29:23.915393
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from collections import namedtuple
    _vault = namedtuple('_vault', ['decrypt'])
    vault = _vault(lambda x: 'bar')
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    decoder._vaults['default'] = vault
    assert decoder.object_hook({'__ansible_vault': 'foo'}).vault == vault
    assert decoder.object_hook({'__ansible_unsafe': 'foo'}) == wrap_var('foo')

# Generated at 2022-06-11 08:29:34.754929
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class TestAnsibleJSONDecoder(AnsibleJSONDecoder):
        pass

    decoder = TestAnsibleJSONDecoder()

    # object_hook must return a dict
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'me'}), dict)

    # object_hook must return a dict
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'me'}), dict)

    # object_hook must return a dict
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'me'}), dict)

    # object_hook must return a dict
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'me'}), dict)

    # object_hook must return a dict

# Generated at 2022-06-11 08:29:44.322985
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    print("Test AnsibleJSONDecoder.object_hook()")
    decrypt_text = '1234'
    secrets = [decrypt_text]
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:29:54.093256
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:03.505483
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dump = {u'__ansible_unsafe': u'$(grep f /etc/passwd)'}
    decoded = AnsibleJSONDecoder().object_hook(dump)
    assert decoded == {"__ansible_unsafe": wrap_var(u'$(grep f /etc/passwd)')}

dump = {u'__ansible_unsafe': u'$(grep f /etc/passwd)'}
assert AnsibleJSONEncoder().encode(dump) == '{"__ansible_unsafe": "$$(grep f /etc/passwd)"}'

# Generated at 2022-06-11 08:30:14.425648
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets_mock = {'secret_test': '__ansible_vault'}
    kwargs_mock = {'object_hook': None}
    json_data = '{"__ansible_vault": "test"}'
    var_to_return = AnsibleVaultEncryptedUnicode('test')

    AnsibleJSONDecoder.set_secrets(secrets_mock)
    decoder = AnsibleJSONDecoder(**kwargs_mock)

    # Make sure the __ansible_vault key is preserved
    assert decoder.object_hook({'__ansible_vault': 'test'}) == {'__ansible_vault': 'test'}

    # Make sure the __ansible_vault key returns a vaulted object

# Generated at 2022-06-11 08:30:20.596098
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '''
    {
        "__ansible_vault" : "vault",
        "__ansible_unsafe" : "unsafe"
    }
    '''
    decoded_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert decoded_data['__ansible_vault'] == "vault"
    assert decoded_data['__ansible_unsafe'] == "unsafe"



# Generated at 2022-06-11 08:30:28.259964
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault = {'__ansible_vault': 'foo'}
    ansible_unsafe = {'__ansible_unsafe': 'bar'}
    ansible_decoder = AnsibleJSONDecoder()
    vault_value = AnsibleVaultEncryptedUnicode('foo')
    safe_value = wrap_var('bar')

    assert ansible_decoder.object_hook(ansible_vault) == vault_value
    assert ansible_decoder.object_hook(ansible_unsafe) == safe_value

# Generated at 2022-06-11 08:30:35.941319
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Encrypted data
    value = '$ANSIBLE_VAULT;1.1;AES256\nblahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblah\nblahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblahblah\nblahblahblahblahblahblahblahblahblahblahblahblahblahblah'
    pairs = {'__ansible_vault': value}

    decoder = AnsibleJSONDecoder(pairs)

    assert decoder.object_hook(pairs) == pairs



# Generated at 2022-06-11 08:30:47.444428
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:55.116821
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    doc = {
        "__ansible_unsafe": 'yes',
        "__ansible_vault": 'VaultEncryptedUnicode'
    }

    from ansible.module_utils.common._collections_compat import IterableUserDict
    assert isinstance(
        json.loads(json.dumps(doc, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder),
        IterableUserDict
    )

# Generated at 2022-06-11 08:31:03.967748
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ('pass1', 'pass2', 'pass3')
    AnsibleJSONDecoder.set_secrets(secrets)

    obj = { '__ansible_vault': 'vault_value' }
    decoded_obj = json.loads(json.dumps(obj), cls=AnsibleJSONDecoder)
    vault = decoded_obj[0]
    assert vault == 'vault_value'
    assert vault.vault == AnsibleJSONDecoder._vaults['default']

    obj = { '__ansible_unsafe': 'unsafe_value' }
    decoded_obj = json.loads(json.dumps(obj), cls=AnsibleJSONDecoder)
    assert decoded_obj[0] == 'unsafe_value'

# Generated at 2022-06-11 08:31:14.740722
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    json_output = encoder.encode({
        'from': wrap_var('foo@bar.com'),
        'to': ['foo@baz.com'],
        'to_encrypted': AnsibleVaultEncryptedUnicode('foo@baz.com'),
    })
    json_output = json.loads(json_output)

    assert AnsibleJSONDecoder.object_hook(json_output)['from'] == wrap_var('foo@bar.com')
    assert AnsibleJSONDecoder.object_hook(json_output)['to'] == ['foo@baz.com']
    assert isinstance(AnsibleJSONDecoder.object_hook(json_output)['to_encrypted'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:31:24.570307
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Testing handling of __ansible_vault
    vault_test_object = {'__ansible_vault': 'test1'}
    vault_test_json = json.dumps(vault_test_object)

    json_decoder = AnsibleJSONDecoder()
    result = json_decoder.decode(vault_test_json)
    assert isinstance(result, dict) and isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Testing handling of __ansible_unsafe with a dictionary
    unsafe_test_object = {'__ansible_unsafe': 'test2'}
    unsafe_test_json = json.dumps(unsafe_test_object)

    json_decoder = AnsibleJSONDecoder()
    result = json_decoder.dec

# Generated at 2022-06-11 08:31:36.007299
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    json_data = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256;o2QmVhRbIt8Sw0WscMMvOQ==\n1234567890"}'
    decrypted_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert decrypted_data.vault.decrypt(decrypted_data) == '1234567890'

    json_data = '{"__ansible_unsafe": "{{secret}}"}'
    decrypted_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert decrypted_data == '{{secret}}'


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-11 08:31:42.945529
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [u'123']
    AnsibleJSONDecoder.set_secrets(secrets)
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;my_key_id\r\n\r\nVGVzdDEyMw==\r\n'}
    result = AnsibleJSONDecoder().object_hook(pairs)

    assert result['__ansible_vault'] == 'VGVzdDEyMw==\r\n'

# Generated at 2022-06-11 08:31:53.845929
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:00.331713
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # used in unit test of method parse
    assert isinstance(AnsibleJSONDecoder().object_hook({'__ansible_vault': '123'}), AnsibleVaultEncryptedUnicode)
    assert isinstance(AnsibleJSONDecoder().object_hook({'__ansible_unsafe': '123'}), str)
    # used in unit test of method parse
    assert AnsibleJSONDecoder().object_hook({'__ansiblevault': '123'}) == {'__ansiblevault': '123'}


# Generated at 2022-06-11 08:32:08.902798
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def make_vault_secret(secret):
        if isinstance(secret, bytes):
            secret = secret.decode('utf-8')
        return {
            'version': 1,
            'secrets': [
                {'secret': secret, 'keys': [
                    {'enc': 'aes', 'hmac': 'sha256', 'key': 'foo'}],
                 'salt': 'salty'}
            ],
        }

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(make_vault_secret(b'bar'))

    # Test vault variable

# Generated at 2022-06-11 08:32:14.950933
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
        '__ansible_unsafe': 'unsafe'
    }

    json_decoded = AnsibleJSONDecoder().decode(json.dumps(test_data))
    assert isinstance(json_decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert json_decoded['__ansible_unsafe'] == wrap_var('unsafe')

# Generated at 2022-06-11 08:32:17.852427
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder('', object_hook=AnsibleJSONDecoder.object_hook).get_object_hook() == AnsibleJSONDecoder.object_hook

# Generated at 2022-06-11 08:32:24.206272
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_input = '''{
    "__ansible_vault": "vault",
    "__ansible_unsafe": {"test": "unsafe" },
    "test": "plain"
    }'''
    json_data = json.loads(json_input, cls=AnsibleJSONDecoder)
    assert isinstance(json_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_data['__ansible_unsafe'], dict)
    assert isinstance(json_data['test'], str)
    assert json_data['test'] == 'plain'


# Generated at 2022-06-11 08:32:34.758913
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import re
    import sys

    h = {}
    for i in sys.modules.keys():
        if re.search('ansible\.module_utils', i):
            h[i] = sys.modules[i]
    h['ansible.parsing.dataloader'] = sys.modules['ansible.parsing.dataloader']

    from ansible.parsing.json_objects import AnsibleJSONDecoder
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes

    class MatchNone(object):
        def __eq__(self, other):
            return other is None

    class Match(dict):
        """ Used to match strings or regex on key or values"""


# Generated at 2022-06-11 08:32:45.492910
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Case 1: An AnsibleVaultEncryptedUnicode object is created when __ansible_vault is passed
    decoder = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "foo"}
    value = decoder.object_hook(pairs)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)

    # Case 2: An HostVars object is created when __ansible_unsafe is passed
    # and the wrapped object is a hostvars object
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:32:55.753404
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test function for AnsibleJSONDecoder.object_hook()
    """

# Generated at 2022-06-11 08:33:07.185103
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:16.277310
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # test for ansible_unsafe
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'str'}) == AnsibleUnsafeText('str')

    # test for ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([{'secret': 'password'}])
    assert isinstance(decoder.object_hook({'__ansible_vault': 'str'}), AnsibleVaultEncryptedUnicode)
    assert decoder.object_hook({'__ansible_vault': 'str'}).vault is not None

    # no specific key, return original pairs

# Generated at 2022-06-11 08:33:23.700496
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    result = decoder.object_hook({'__ansible_vault': 'test'})
    assert type(result) is AnsibleVaultEncryptedUnicode

    result = decoder.object_hook({'__ansible_unsafe': 'test'})
    assert type(result) is wrap_var
    assert result.value == 'test'

    result = decoder.object_hook({'test': 'test'})
    assert type(result) is dict

# Generated at 2022-06-11 08:33:33.016850
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Unit test for method object_hook of class AnsibleJSONDecoder
    """
    ansible_vault_dict = {"__ansible_vault": "@c2lzY2FsbAo="}
    ansible_unsafe_dict = {"__ansible_unsafe": "pass"}

    test_vault_result = AnsibleJSONDecoder.object_hook(ansible_vault_dict)
    test_unsafe_result = AnsibleJSONDecoder.object_hook(ansible_unsafe_dict)

    assert isinstance(test_vault_result, AnsibleVaultEncryptedUnicode)
    assert isinstance(test_unsafe_result, dict)

# Generated at 2022-06-11 08:33:42.549539
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': {'__ansible_string__': 'hello world!'}}) == wrap_var({'__ansible_string__': 'hello world!'})
    assert decoder.object_hook({'__ansible_vault': 'hello world!'}).encoded_data == 'hello world!'
    assert decoder.object_hook({'__ansible_vault': 'hello world!'}).vault == AnsibleJSONDecoder._vaults['default']
    assert decoder.object_hook({'__ansible_vault': 'hello world!'}).vault == AnsibleJSONDecoder._vaults['default']



# Generated at 2022-06-11 08:33:46.338488
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = json.loads('{"__ansible_vault": "ABCD1234"}', cls=AnsibleJSONDecoder)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:33:50.649188
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '{"__ansible_vault": "foo"}'
    AnsibleJSONDecoder.set_secrets(["foo"])
    assert isinstance(json.loads(json_data, cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:34:01.082790
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for __ansible_vault
    original_string = 'test_vault'

# Generated at 2022-06-11 08:34:10.575709
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    ansible/module_utils/common/json.py
    unit test for method object_hook of class AnsibleJSONDecoder
    """
    from ansible.module_utils.common.json import AnsibleJSONDecoder, AnsibleJSONEncoder, AnsibleJSONEncoderForVault

    vault_pwd = 'vault_test'
    vault_secrets = [b'vault_test']
    vault_data = '{"__ansible_vault": "vault_test"}'
    data = '{"__ansible_vault": "vault_test", "__ansible_unsafe": "unsafe"}'

    # test vault data
    AnsibleJSONDecoder.set_secrets(vault_secrets)
    decoder = AnsibleJSONDecoder()
    decoded_vault_data = decoder

# Generated at 2022-06-11 08:34:20.943819
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Ensure that the method AnsibleJSONDecoder.object_hook correctly decodes an
    encrypted value and a string wrapped in __ansible_unsafe."""
    # Setup the decoder
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('test_password')
    # Test an encrypted value

# Generated at 2022-06-11 08:34:29.790070
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:40.942984
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = { '__ansible_vault': 'aGVsbG8gd29ybGQ=\n' }
    assert(decoder.object_hook(pairs)['__ansible_vault'] == 'aGVsbG8gd29ybGQ=\n')
    pairs = { '__ansible_unsafe': 'aGVsbG8gd29ybGQ=\n' }
    assert(decoder.object_hook(pairs)['__ansible_unsafe'] == 'aGVsbG8gd29ybGQ=\n')

# Generated at 2022-06-11 08:34:45.467230
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    my_json_str = b'{"__ansible_vault": "vault_str"}'
    my_json_obj = json.loads(my_json_str, cls=AnsibleJSONDecoder)
    assert my_json_obj == {"__ansible_vault": "vault_str"}

# Generated at 2022-06-11 08:34:53.558629
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test that a vault encrypted payload is decrypted by the wrapper class
    vault = dict(__ansible_vault="$ANSIBLE_VAULT;1.1;AES256;ansible\n303132333435363738396162636465663930313233343536373839616263646566\n")
    vault_payload = decoder.object_hook(vault)
    assert hasattr(vault_payload, 'vault')
    assert vault_payload() == "0123456789abcdef90123456789abcdef"
    # Test that a unsafe payload is decrypted by the wrapper class

# Generated at 2022-06-11 08:35:04.312781
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_var = {}
    vault_id = 'default'
    test_var['__ansible_vault'] = "{'vault_id':'%s'}" % vault_id
    res = decoder.object_hook(test_var)
    assert res['__ansible_vault'].vault.secrets == ['secret']
    assert not res['__ansible_vault'].vault.salt
    vault = VaultLib(secrets=['secret'], salt='salt')
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = vault
    res = decoder.object_hook(test_var)
    assert res['__ansible_vault'].vault.secrets == ['secret']

# Generated at 2022-06-11 08:35:12.255676
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Initialize object
    decoder = AnsibleJSONDecoder()

    # Unsafe variable
    pairs = {'__ansible_unsafe': '$ANSIBLE_NOCOLOR'}
    assert decoder.object_hook(pairs) == {'__ansible_unsafe': wrap_var('$ANSIBLE_NOCOLOR')}

    # Vault Variable
    pairs = {'__ansible_vault': '$ANSIBLE_NOCOLOR'}
    assert decoder.object_hook(pairs) == {'__ansible_vault': AnsibleVaultEncryptedUnicode('$ANSIBLE_NOCOLOR')}

# Generated at 2022-06-11 08:35:23.446596
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:28.322817
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    data = {"__ansible_vault": "foo"}
    ret = decoder.object_hook(data)

    assert isinstance(ret, AnsibleVaultEncryptedUnicode)
    assert ret.vault is None
    assert ret == "foo"

# Generated at 2022-06-11 08:35:37.028220
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = ('{"__ansible_vault": "encrypted"}')
    obj_dict = json.loads(obj, cls=AnsibleJSONDecoder)
    assert obj_dict['__ansible_vault'] == 'encrypted'

    obj = ('{"__ansible_unsafe": "unsafe"}')
    obj_dict = json.loads(obj, cls=AnsibleJSONDecoder)
    assert obj_dict['__ansible_unsafe'] == 'unsafe'

    obj = ('{"key": "value"}')
    obj_dict = json.loads(obj, cls=AnsibleJSONDecoder)
    assert obj_dict['key'] == 'value'


# Generated at 2022-06-11 08:35:45.205826
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:35:52.757631
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    test_AnsibleJSONDecoder_object_hook
    """
    data = json.loads('{"__ansible_vault": "somesecretvalue"}', cls=AnsibleJSONDecoder)
    assert("__ansible_vault" not in data)
    assert(data["somesecretvalue"])
    assert(data["somesecretvalue"].is_encrypted)



# Generated at 2022-06-11 08:36:02.118684
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:11.731952
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_pwd = 'my secret'

# Generated at 2022-06-11 08:36:18.957394
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Given
    json_with_vault = '{"__ansible_vault": "encrypted_vault_value"}'
    vault_secrets = ['v']
    expected_result = AnsibleVaultEncryptedUnicode('encrypted_vault_value')

    # When
    AnsibleJSONDecoder.set_secrets(vault_secrets)
    result = AnsibleJSONDecoder().decode(json_with_vault)

    # Then
    print(result)
    assert result['__ansible_vault'] == expected_result



# Generated at 2022-06-11 08:36:29.852875
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = 'test_vault'

    pairs = {
        '__ansible_vault': 'test_ansible_vault',
        '__ansible_unsafe': 'test_ansible_unsafe'
    }
    result = decoder.object_hook(pairs)
    assert result['__ansible_vault']._encrypted_data == 'test_ansible_vault'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault == 'test_vault'
    assert result['__ansible_unsafe']._data == 'test_ansible_unsafe'

# Generated at 2022-06-11 08:36:38.017172
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    assert(json.loads('{"__ansible_vault": "vault_val"}', cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode(value='vault_val'))
    assert(json.loads('{"__ansible_vault": "vault_val"}', cls=AnsibleJSONDecoder) == {"__ansible_vault": "vault_val"})
    assert(json.loads('{"__ansible_unsafe": "unsafe_val"}', cls=AnsibleJSONDecoder) == wrap_var('unsafe_val'))

# Generated at 2022-06-11 08:36:48.740510
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class MockVaultLib(VaultLib):
        def decrypt(self):
            return ""

    vault_lib = MockVaultLib(secrets=['test'])
    obj = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'})

    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj == 'test'

    obj = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test', 'test': 'test'})

    assert isinstance(obj, dict)
    assert 'test' in obj.keys()
    assert obj['test'] == 'test'

    obj = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'test', 'test': 'test'})

# Generated at 2022-06-11 08:36:58.962456
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # a mock vault secret to decrypt
    vault_secret = '$ANSIBLE_VAULT;1.1;AES256;james\n3830623634666235333064663538316661383064663033653561343836656361623065653934\n6663386232376634306566366262666632363131613331386166623930393833383761623734\n3337383738306566356437613165393832306133336561326232653737613362306636653965\n6362626163653033643565\n'

    # two sample values
    sam1 = {'__ansible_vault': vault_secret}

# Generated at 2022-06-11 08:37:08.259823
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.yaml import objects

    v = VaultSecret([VaultAES256('mysecretkey')])
    objects.AnsibleJSONDecoder.set_secrets(v.secrets)

# Generated at 2022-06-11 08:37:19.523464
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.plugins.vars

    secret = '123456'
    vault = AnsibleVaultEncryptedUnicode.from_raw(secret, {})
    vault_dict = {'__ansible_vault': vault.encode('utf-8')}

    var_manager = ansible.plugins.vars.VarsModule()
    vault_dict = var_manager.vars_loader.decrypt_vault(vault_dict, {})

    assert(isinstance(vault_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(secret == vault_dict['__ansible_vault'].decrypt())

# Generated at 2022-06-11 08:37:27.055052
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    # encrypted data

# Generated at 2022-06-11 08:37:36.957064
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secret = "abcdefgh"
    decoder.set_secrets(secret)

    # most likely scenario
    pairs = {
        '__ansible_vault': '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          63636264636465666768\n          '
    }
    obj = decoder.object_hook(pairs)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.value == secret

    # __ansible_vault with non-vault value
    pairs = {
        '__ansible_vault': 'not a vault value'
    }
    obj = decoder.object_hook(pairs)
    assert obj == pairs

    # __ansible

# Generated at 2022-06-11 08:37:40.580682
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  source = b'{"__ansible_vault": "vault_value"}'
  result = '{"__ansible_vault": "vault_value"}'
  assert json.loads(source, cls=AnsibleJSONDecoder) == json.loads(result)

# Generated at 2022-06-11 08:37:50.165810
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Init test input data
    raw_vault = r'$ANSIBLE_VAULT;1.1;AES256;ansible\ntesting1234567890\n93778922828837792253725782291295377824327289377289378291278\n'
    vault = {'__ansible_vault': raw_vault}

    unsafe = {'__ansible_unsafe': False}

    normal = {'ansible': 'testing', 'ansible_unsafe': False, 'ansible_vault': 'VAULTED'}

    # Init to
    to = AnsibleJSONDecoder()

    # Encrypt vault data
    to.set_secrets({"vault_password_file": "../_data/vault_password.txt"})

    # Check result

# Generated at 2022-06-11 08:38:00.267093
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # When there is no __ansible_vault field, directly return pairs
    pairs = {'foo': 'bar'}
    assert AnsibleJSONDecoder.object_hook(pairs) == pairs

    # When there is __ansible_vault field, but no secrets, return the AnsibleVaultEncryptedUnicode object with vault field = None
    pairs = {'foo': 'bar', '__ansible_vault': 'vaulted_data'}
    assert isinstance(AnsibleJSONDecoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)
    assert AnsibleJSONDecoder.object_hook(pairs).vault is None

    # When there is __ansible_vault field, return the AnsibleVaultEncryptedUnicode object with vault field = vaultlib
    secrets = VaultLib()


# Generated at 2022-06-11 08:38:06.302276
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    vault_encrypt = {'__ansible_vault': 'vault_view'}
    ansible_json_decoder.vault_view = {'__ansible_vault': 'vault_view'}
    assert ansible_json_decoder.object_hook(vault_encrypt) == vault_encrypt['__ansible_vault']

# Generated at 2022-06-11 08:38:15.021923
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {'__ansible_vault': 'teststring'}
    result = AnsibleJSONDecoder.object_hook(data)
    assert(result.vault == None)
    assert(isinstance(result, AnsibleVaultEncryptedUnicode))
    assert(str(result) == 'teststring')
    assert(result.vault.secrets[0] == None)
    assert(result.vault.secrets[1] == None)
    
    data = {'__ansible_unsafe':'teststring'}
    result = AnsibleJSONDecoder.object_hook(data)
    assert(isinstance(result, wrap_var))
    assert(result.val =='teststring')

# Generated at 2022-06-11 08:38:22.396990
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_file = '../../../test/ansible/new_vault_password'
    with open(secret_file, 'r') as f:
        password = ''.join(f.readlines()[:1])

    decoder = AnsibleJSONDecoder.set_secrets(password)
    decoded_object = json.loads('{"__ansible_vault": "test"}', cls=AnsibleJSONDecoder)
    assert decoded_object.vault.decrypt(decoded_object) == 'test'

# Generated at 2022-06-11 08:38:28.848976
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(strict=False)
    ansible_vault_data = {
        "__ansible_vault": "secret_data",
        "foo": "bar",
    }
    assert decoder.object_hook(ansible_vault_data)["__ansible_vault"].data == "secret_data"
    assert decoder.object_hook(ansible_vault_data)["foo"] == "bar"
