

# Generated at 2022-06-11 08:28:36.077999
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:28:43.117034
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults['default'] == VaultLib(secrets=secrets)
    # AnsibleVaultEncryptedUnicode object
    key, value = '__ansible_vault', '$ANSIBLE_VAULT;1.1;AES256'
    decoded = AnsibleJSONDecoder().object_hook({key: value}).get(key)
    expected = AnsibleVaultEncryptedUnicode(value)
    assert decoded.vault == VaultLib(secrets=secrets)
    assert decoded == expected
    # unsafe variable
    key, value = '__ansible_unsafe', 'test'

# Generated at 2022-06-11 08:28:52.827824
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    test_secrets = dict()

# Generated at 2022-06-11 08:29:01.599408
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test case 1
    test_json = '{"__ansible_vault": "test_encryption"}'
    test_secrets = ['test_secret']
    is_secrets_applied = False
    AnsibleJSONDecoder.set_secrets(test_secrets)
    for key in json.loads(test_json, cls=AnsibleJSONDecoder):
        if key == '__ansible_vault' and isinstance(json.loads(test_json, cls=AnsibleJSONDecoder)[key],
                                                   AnsibleVaultEncryptedUnicode):
            is_secrets_applied = True
            break
    assert is_secrets_applied
    # test case 2
    test_json = '{"__ansible_unsafe": "test_unsafe_value"}'

# Generated at 2022-06-11 08:29:12.563161
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = json.loads('{"__ansible_vault": "my_vault"}', cls=AnsibleJSONDecoder)
    assert type(decoded) is AnsibleVaultEncryptedUnicode
    assert decoded == "my_vault"
    assert type(json.loads('{"__ansible_unsafe": "my_unsafe"}', cls=AnsibleJSONDecoder)) is not AnsibleVaultEncryptedUnicode
    assert 'my_unsafe' in json.loads('{"__ansible_unsafe": "my_unsafe"}', cls=AnsibleJSONDecoder).keys()
    # Ensure object_hook is called
    assert str(json.loads('{"__ansible_vault": "my_vault"}', cls=AnsibleJSONDecoder)) == "my_vault"

# Generated at 2022-06-11 08:29:20.090546
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = '''
{
    "data": "Test",
    "data_secure": {"__ansible_vault": "Hello World"},
    "data_unsafe": {"__ansible_unsafe": "Hello World"}
}
'''
    test_decoder = AnsibleJSONDecoder()
    results = json.loads(test_data, cls=test_decoder)
    assert results['data'] == 'Test'
    assert results['data_secure'] == 'Hello World'
    assert results['data_unsafe'] == 'Hello World'



# Generated at 2022-06-11 08:29:23.865601
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
       pairs = { '__ansible_vault': 'vault', '__ansible_unsafe': 'secret' }
       dec = AnsibleJSONDecoder()
       assert dec.object_hook(pairs) == 'secret'

# Generated at 2022-06-11 08:29:34.709327
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Setup
    secrets = 'secret'
    enc = [
        {
            "__ansible_vault": "vault1"
        },
        {
            "__ansible_vault": "vault2",
            "key": "value"
        },
        {
            "__ansible_vault": "vault3",
            "key": "value",
            "__ansible_unsafe": "unsafe1"
        }
    ]

# Generated at 2022-06-11 08:29:44.278582
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    yaml_str = """---
- hosts: localhost
  tasks:
  - name: read a secret
    debug:
      msg: '{{ my_secret }}'
    vars:
      my_secret: '{{ vault_my_secret }}'
"""

# Generated at 2022-06-11 08:29:51.504838
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.module_utils.common.json import AnsibleJSONEncoder

    # Case 1 - Non-vault case
    data_in = {'__ansible_unsafe': 'test'}
    expected_ret = {'__ansible_unsafe': wrap_var('test')}
    assert(AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(json.dumps(data_in)) == expected_ret)

    # Case 2 - Vault case
    data_in = {'__ansible_vault': 'test'}
    encoder = AnsibleJSONEncoder()
    vault_data = encoder.encode(data_in)
    vault_data = vault_data[14:-1]

# Generated at 2022-06-11 08:29:59.344196
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test for method object_hook of class AnsibleJSONDecoder
    """
    decoder = AnsibleJSONDecoder()

    pairs = {'__ansible_vault': 'value'}
    res = decoder.object_hook(pairs)

    assert True == ansible_vault_encrypted_unicode_compare(res, AnsibleVaultEncryptedUnicode('value'))


# Generated at 2022-06-11 08:30:08.298481
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test for method object_hook of class AnsibleJSONDecoder
    #
    # If the input value is not a dictionary or a json string, then leave the value as it is,
    # otherwise convert the value to an AnsibleVaultEncryptedUnicode instance.
    json_obj = {"__ansible_vault": "encrypted_string"}
    new_obj = AnsibleJSONDecoder.object_hook(json_obj)
    assert isinstance(new_obj, AnsibleVaultEncryptedUnicode)
    assert isinstance(new_obj.vault, VaultLib)

    json_str = """{"__ansible_vault": "encrypted_string"}"""
    new_str = AnsibleJSONDecoder.object_hook(json_str)
    assert isinstance(new_str, str)

# Generated at 2022-06-11 08:30:18.643155
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    myjson = '''{
        "test_key_value": "test_value",
        "test_key_vault": {
            "__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          61633837373966323731653661643735656465383764306161333763653964363537666563383664\n          30333263633331636234313931633061376339626662323930626164633931373231666637626332\n          383239343738616136633762363934\n          "
        }
    }'''


# Generated at 2022-06-11 08:30:26.247144
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import wrap_var

    json_object_hook = AnsibleJSONDecoder().object_hook
    assert json_object_hook({'__ansible_vault': 'some string'}).data == 'some string'
    assert isinstance(json_object_hook({'__ansible_vault': 'some string'}), AnsibleVaultEncryptedUnicode)
    assert wrap_var("some string") == json_object_hook({'__ansible_unsafe': 'some string'})

# Generated at 2022-06-11 08:30:34.430742
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = '''{
        "__ansible_vault": "blablablablablabla",
        "__ansible_unsafe": "blablablablablabla",
        "key1": "value1"
        }'''

    json_decoder = AnsibleJSONDecoder()
    result = json_decoder.object_hook(json.loads(pairs))

    # Test for class AnsibleVaultEncryptedUnicode
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Test for class AnsibleUnsafeText
    assert isinstance(result['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-11 08:30:45.256578
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Setup
    str_list = ['__ansible_vault', '__ansible_unsafe']
    secret_list = [u'123', u'abc']
    json_dict = dict(zip(str_list, secret_list))
    vault_lib = VaultLib(secrets=['123'])

    # Test
    result = AnsibleJSONDecoder.object_hook(json_dict)

    # Verify
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == vault_lib

    # Test
    result = AnsibleJSONDecoder.object

# Generated at 2022-06-11 08:30:45.918328
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-11 08:30:54.384045
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestCase:
        def __init__(self, data):
            self.data = data
        def call(self):
            self.encoder = AnsibleJSONEncoder()
            self.decoder = AnsibleJSONDecoder()
            self.encoded = json.dumps(self.data, cls=self.encoder)
            self.decoded = json.loads(self.encoded, cls=self.decoder)
        def assertVal(self):
            assert type(self.decoded) is type(self.data)
            assert self.decoded == self.data
    # test unwrap_proxy
    tc1 = TestCase({'a': 1, 'b': 2, 'c': {'x': 1, 'y': 2}})
    tc1.call()
    tc1.assertVal()
    #

# Generated at 2022-06-11 08:31:00.453651
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    try:
        test_json_string = '{"__ansible_vault": "test", "__ansible_unsafe": [1, 2, 3]}'
        expected_result = {'__ansible_vault': 'test', '__ansible_unsafe': [1, 2, 3]}
        assert AnsibleJSONDecoder().object_hook(json.loads(test_json_string)) == expected_result
    except Exception as e:
        raise e

# Generated at 2022-06-11 08:31:10.252129
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # ansible.utils.unsafe_proxy.AnsibleUnsafeText
    s = "{\"__ansible_unsafe\": \"7fdda582f1332d6c3f6b4d4c4f6d8c6b\"}"
    dec = AnsibleJSONDecoder()
    data = dec.decode(s)
    assert data == u'7fdda582f1332d6c3f6b4d4c4f6d8c6b'
    assert type(data) is unicode

    # ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 08:31:16.414906
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)

    input_dict = {'__ansible_vault': 'test'}

    json_obj = AnsibleJSONDecoder()
    decoded_dict = json_obj.object_hook(input_dict)

    assert decoded_dict.vault == VaultLib(secrets=secrets)

# Generated at 2022-06-11 08:31:27.039180
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'ansible']
    AnsibleJSONDecoder.set_secrets(secrets)

    content = {
        "__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          643364611632366439356661636335616334636135356566333862636536653262313161366366\n          640a34633639356661633761323561316131303134363565663365323439343531336362653863\n          612a\n          ",
        "bar": 123,
        "foo": "abc"
    }


# Generated at 2022-06-11 08:31:37.436336
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import sys
    import os; sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    from test_vault import VaultLibTestCase

    secrets = ['secret0']
    json_text = '{"__ansible_vault": "vault_encrypted_data", "__ansible_unsafe": "some_data"}'
    expected_value = {'__ansible_vault': VaultLibTestCase.encrypted_text_v1,
                      '__ansible_unsafe': 'some_data'}

    # test object_hook
    AnsibleJSONDecoder.set_secrets(secrets)
    result = AnsibleJSONDecoder().decode(json_text)
    assert result == expected_value

# Generated at 2022-06-11 08:31:42.276191
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({"__ansible_vault": "YmFy"}) == AnsibleVaultEncryptedUnicode("YmFy")
    assert AnsibleJSONDecoder.object_hook({"__ansible_unsafe": "YmFy"}) == wrap_var("YmFy")

# Generated at 2022-06-11 08:31:49.699020
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"__ansible_unsafe": "True", "__ansible_vault": "adsfadsf"}
    ansible = AnsibleJSONDecoder()
    result = ansible.object_hook(obj)
    assert type(result['__ansible_unsafe']) == type(wrap_var(True))
    assert type(result['__ansible_vault']) == type(AnsibleVaultEncryptedUnicode('adsfadsf'))
    assert result['__ansible_vault'].vault == ansible._vaults['default']

# Generated at 2022-06-11 08:31:56.190039
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['baz', 'qux']
    json_str = '{"__ansible_vault": "foo", "__ansible_unsafe": "bar"}'
    decoded = AnsibleJSONDecoder.object_hook(json.loads(json_str))
    assert decoded['__ansible_vault'].vault.secrets == secrets
    assert decoded['__ansible_unsafe'] == wrap_var('bar')

# Generated at 2022-06-11 08:32:04.599369
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()

    assert ansible_json_decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;kdajsdfkljsadlkfjalskdjfaskljfdskasdfskasfdskasdfskasdskjdskjfksjdskjfskjdfskjdkfjs'})['__ansible_vault'] == '$ANSIBLE_VAULT;1.1;AES256;kdajsdfkljsadlkfjalskdjfaskljfdskasdfskasfdskasdfskasdskjdskjfksjdskjfskjdfskjdkfjs'

    assert ansible_json_decoder.object_

# Generated at 2022-06-11 08:32:13.867996
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'somekey': 'someval'}) == {'somekey': 'someval'}

    test_vault_id = '123'

# Generated at 2022-06-11 08:32:23.338604
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:32.511998
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'secret'
    encData = AnsibleJSONEncoder.encode_vaulttext(secret)

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    dec = decoder.decode(encData)

    assert isinstance(dec, AnsibleVaultEncryptedUnicode)

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder.set_secrets(['secret'])
    dec = decoder.decode(encData)

    assert isinstance(dec, AnsibleVaultEncryptedUnicode)

    assert dec.decrypt() == secret


# Generated at 2022-06-11 08:32:45.589901
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:52.196894
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': 'vault_value'}
    pairs_expected = AnsibleVaultEncryptedUnicode('vault_value')
    secret = ['vault_secret']
    vault = AnsibleJSONDecoder.set_secrets(secret)
    result = AnsibleJSONDecoder.object_hook(pairs)
    assert result == pairs_expected

# Generated at 2022-06-11 08:33:02.928325
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:08.925626
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"test": 10, "__ansible_vault": "something is wrong", "__ansible_unsafe": "something is wrong"}
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook(data) == \
        {"test": 10, "__ansible_vault": AnsibleVaultEncryptedUnicode("something is wrong"), "__ansible_unsafe": wrap_var("something is wrong")}



# Generated at 2022-06-11 08:33:18.725359
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    t = unittest.TestCase('__init__')


# Generated at 2022-06-11 08:33:23.861355
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "vault_value", "__ansible_unsafe": "unsafe_value"}'
    o = AnsibleJSONDecoder().decode(s)
    assert o['__ansible_vault'] == 'vault_value'
    assert o['__ansible_unsafe'] == 'unsafe_value'

# Generated at 2022-06-11 08:33:34.817718
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Vault password should be ansible
    secrets = ['ansible']
    AnsibleJSONDecoder.set_secrets(secrets)

    class Dummy(object):
        def __init__(self, val):
            self.val = val

    # todo: fix variable type conflict between Dummy and AnsibleVaultEncryptedUnicode
    AnsibleJSONDecoder._vaults['default'] = 'Dummy'
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:33:40.322726
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:50.982360
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleVaultEncryptedUnicode
    vault = { '__ansible_vault': "vault_value" }
    secrets = ["secret-1", "secret-2"]
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    decoded_vault = decoder.object_hook(vault)
    assert isinstance(decoded_vault, AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded_vault.vault, VaultLib)

    # Test for  AnsibleUnsafeText


# Generated at 2022-06-11 08:34:01.453559
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import json

    # Encrypted with password 'password'
    # {
    #     "_comment": "Encrypted with Ansible Vault; the old vault password was 'password'",
    #     "__ansible_vault": "U2FsdGVkX1+hI6gjwzy+aL3UkSk5q5q5nX+5TVBgRik="
    # }

# Generated at 2022-06-11 08:34:12.894267
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jtext = '{"__ansible_vault": "ansible", "__ansible_unsafe": "ansible"}'
    jtext2 = '{"__ansible_vault": "ansible", "__ansible_unsafe": "ansible", "__ansible_vault": "ansible-2"}'
    jtext3 = '{"__ansible_vault": "ansible", "__ansible_vault": "ansible2"}'
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'ansible'}) == {u'__ansible_vault': u'ansible'}
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'ansible'}) == {u'__ansible_unsafe': u'ansible'}
    assert Ans

# Generated at 2022-06-11 08:34:21.964401
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import sys
    import unittest
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE

    # Change the sys path to make sure the unit test is independent
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.join(current_dir, '..', '..', '..')

    # Change the sys path to make sure the unit test is independent
    sys.path.pop(0)
    sys.path.insert(0, base_dir)

    # Python 3.8 change: environment variable PYTHONWARNINGS no longer supported.
    # Ignore ResourceWarning generated by the following code.

# Generated at 2022-06-11 08:34:31.707858
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secret = "SuperSecrets"
    decoder._vaults['default'] = VaultLib(secrets=secret)
    pairs = {'__ansible_vault': "vault_value",
             '__ansible_unsafe': "unsafe_value"}
    encrypted_obj = decoder.object_hook(pairs)
    assert isinstance(encrypted_obj, AnsibleVaultEncryptedUnicode)
    assert encrypted_obj == "vault_value"
    assert encrypted_obj.vault == decoder._vaults['default']
    # test on the non-encrypted object
    pairs = decoder.object_hook(pairs)
    assert pairs['__ansible_unsafe'] == "unsafe_value"

# Generated at 2022-06-11 08:34:42.768110
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {
        'password': 'hunter2',
        'secret': 's3kr3t',
    }
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    decoder_obj = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:34:47.467784
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    s = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;'
    }
    result = decoder.object_hook(s)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:34:54.871544
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secrets = [u'secret1', u'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)
    # test with __ansible_vault
    data = decoder.decode('{"__ansible_vault": "secret1"}')
    assert data._text == u'secret1'
    assert data.vault.secrets == secrets
    # test with __ansible_vault and different indentation
    # data = decoder.decode('{"__ansible_vault": "secret1",}')
    # assert data._text == u'secret1'
    # assert data.vault.secrets == secrets
    # test with __ansible_vault and __ansible_unsafe

# Generated at 2022-06-11 08:35:05.659351
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Creation of an AnsibleJSONDecoder object
    ansibleJSONDecoder = AnsibleJSONDecoder()
    secret = "test_secret"

# Generated at 2022-06-11 08:35:16.330760
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from jinja2 import Markup

    secret_db = {'password': 'pwd'}
    AnsibleJSONDecoder.set_secrets(secret_db)


# Generated at 2022-06-11 08:35:21.217726
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    res = AnsibleJSONDecoder().object_hook({"__ansible_vault": "test", "__ansible_unsafe": "test"})
    assert isinstance(res, dict)
    assert res['__ansible_vault'] == "test"
    assert res['__ansible_unsafe'].data == "test"

# Generated at 2022-06-11 08:35:32.463053
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import from_json
    from ansible.parsing.vault import VaultLib
    import random
    import string

    random_password = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(16))
    vault_lib = VaultLib(random_password)
    vault_encrypted_string = vault_lib.encrypt('leo')
    vault_encrypted_string_in_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n' + vault_encrypted_string + '\n'}


# Generated at 2022-06-11 08:35:44.973212
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    test_obj = {
        '1': AnsibleVaultEncryptedUnicode('test', vault=VaultLib(secrets=secrets)),
        '2': wrap_var('test')
    }
    test_str = json.dumps(test_obj, cls=AnsibleJSONEncoder)
    payload = json.loads(test_str)
    AnsibleJSONDecoder.set_secrets(secrets)
    test_obj_decoded = json.loads(test_str, cls=AnsibleJSONDecoder)

    assert type(payload['1']) == str
    assert type(payload['2']) == str
    assert test_obj_decoded['1'] == test_obj['1']

# Generated at 2022-06-11 08:35:57.602459
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook(
        {
            '__ansible_vault': 'vaulted value',
        }
    ) == AnsibleVaultEncryptedUnicode('vaulted value')

    # test that the vault exists, but it is not used
    assert AnsibleJSONDecoder.object_hook(
        {
            '__ansible_vault': 'vaulted value',
            '__ansible_vault__': None,
        }
    ) == AnsibleVaultEncryptedUnicode('vaulted value')

    # vaulted string in a list

# Generated at 2022-06-11 08:36:04.019147
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = "test_secrets"
    decoder = AnsibleJSONDecoder
    decoder.set_secrets(secrets)
    object_hook = decoder.object_hook(
        {"__ansible_vault": "test_ansible_vault",
         "__ansible_unsafe": "test_ansible_unsafe"})

    assert isinstance(object_hook['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert object_hook['__ansible_vault'].vault._secrets == secrets
    assert object_hook['__ansible_unsafe'].value == 'test_ansible_unsafe'

# Generated at 2022-06-11 08:36:14.229673
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_secrets = ['password123']

# Generated at 2022-06-11 08:36:22.336860
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # No __ansible_vault or __ansible_unsafe key
    test_dict = {'a': 'b'}
    actual = decoder.object_hook(test_dict)
    assert actual == test_dict

    # __ansible_vault key
    test_dict = {'a': 'b', '__ansible_vault': 'c'}
    actual = decoder.object_hook(test_dict)
    assert isinstance(actual, AnsibleVaultEncryptedUnicode)
    assert actual == test_dict['__ansible_vault']

    # __ansible_unsafe key
    test_dict = {'a': 'b', '__ansible_unsafe': 'c'}
    actual = decoder.object_hook(test_dict)

# Generated at 2022-06-11 08:36:29.136391
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    result = decoder.decode('{"__ansible_vault": "vault", "__ansible_unsafe": "unsafe", "key": "value"}')
    assert result == {u'key': u'value', u'__ansible_vault': u'vault', u'__ansible_unsafe': u'unsafe'}


# Generated at 2022-06-11 08:36:32.455676
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    args = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256', '__ansible_unsafe': "!unsafe"}

    result = decoder.object_hook(args)

    assert result["__ansible_vault"].vault
    assert result["__ansible_unsafe"] == wrap_var("!unsafe")

# Generated at 2022-06-11 08:36:43.369760
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_decoder = AnsibleJSONDecoder()
    # input data
    input_json = {"__ansible_vault": "!vault |\n$ANSIBLE_VAULT;1.2;AES256;default;default\n$ANSIBLE_VAULT",
                  "__ansible_unsafe": "$ANSIBLE_VAULT"}
    # expected result
    expected_result_dict = {"__ansible_vault": "!vault |\n$ANSIBLE_VAULT;1.2;AES256;default;default\n$ANSIBLE_VAULT",
                            "__ansible_unsafe": "$ANSIBLE_VAULT"}

    # test AnsibleJSONDecoder.object_hook()
    decoded_input_dict = ansible_vault_decoder.object_hook(input_json)

# Generated at 2022-06-11 08:36:52.361231
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n3561623439656532333130346363303539333035633566653636663538333936356536353563326638\nb2f1f7d9feeb8fa4e4f3a3e12de4e8c2\n'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([secret])

    # decode an object
    data = '{"__ansible_vault": "3561623439656532333130346363303539333035633566653636663538333936356536353563326638", "__ansible_unsafe": "SEVMTE8="}'
    obj = decoder.decode(data)
    assert type

# Generated at 2022-06-11 08:37:01.303429
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [
        '$ANSIBLE_VAULT;1.1;AES256\r\n366635343130656431666238363830386565663332316237333539323236336634653566386139340a6233393362306463616262623165343234616565343536313464383436623331393133386166350a613962616263663037326564333566643534666465356664356561396366353833363934646364\r\n'
    ]
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:37:16.918287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_str = """$ANSIBLE_VAULT;1.1;AES256
356433363766326333623036323631643430353630383331323336396433396535353035343962
38376162626662396437663531626435336436613862320a376436366230333965643233366137
386664313136356364353464373735643562316362333361393838316333353163346631646334
31623531643936310a39613762336131623634303333303264303231656534313266353338
""".strip()

    # Test with no secrets

# Generated at 2022-06-11 08:37:25.542362
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_password = 'secret'
    vault = VaultLib()

    # Check without vault
    secret_txt = 'hello world'
    encrypted_txt = vault.encrypt(secret_txt)
    json_encoded_txt = '{"__ansible_vault": "%s"}' % encrypted_txt
    json_decoded_txt = json.loads(json_encoded_txt, cls=AnsibleJSONDecoder)
    assert json_decoded_txt == AnsibleVaultEncryptedUnicode(encrypted_txt)
    assert json_decoded_txt.vault is None

    # Check with vault
    json_decoded_txt.vault = vault
    assert json_decoded_txt.vault is vault
    assert ansible_decode(json_encoded_txt, vault) == secret_txt
    assert ans

# Generated at 2022-06-11 08:37:35.340661
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault = VaultLib(['mysecret'])
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['mysecret'])
    result = decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;test\n1234\n'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result == '1234'
    assert result.vault == vault
    result = decoder.object_hook({'__ansible_unsafe': '$ANSIBLE_VAULT;1.2;AES256;test\n1234\n'})
    assert result == '$ANSIBLE_VAULT;1.2;AES256;test\n1234\n'

# Generated at 2022-06-11 08:37:45.415534
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 08:37:52.059016
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test for case: __ansible_vault
    d = json.loads('{"__ansible_vault": "123456"}', cls=AnsibleJSONDecoder)
    assert d.vault is None
    # Test for case: __ansible_unsafe
    d = json.loads('{"__ansible_unsafe": "123456"}', cls=AnsibleJSONDecoder)
    assert d.value is None
    # Test for case: no __ansible_*
    d = json.loads('{"test": "123456"}', cls=AnsibleJSONDecoder)
    assert type(d) is dict

# Generated at 2022-06-11 08:38:02.795861
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:38:13.236234
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-11 08:38:23.601261
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    password = 'myvaultpassword'
    dec = AnsibleJSONDecoder()
    ret = dec.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n37333238666434393862626231613733\n38303639393162373435333166633638\n39303131396465653864666664633761\n64306337623462283364306638303561\n6361313664623537\n'})
    assert ret.vault is None
    assert ret.vault_password is None
    assert ret.decrypt(password) == AnsibleVaultEncryptedUnicode('hello').decrypt(password)


# Generated at 2022-06-11 08:38:33.104686
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = b'$ANSIBLE_VAULT;1.1;AES256\n333465646333366638616236383563613261326133616232373834386530333763362626262346361\n3936346661666334636661396162326530346533363536366237653336393564343039396665313230\n3932633139393631343239383634363737633462616363663438663439306633396234663735306665\n636637313962373563386265346539373035\n'