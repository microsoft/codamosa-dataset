

# Generated at 2022-06-11 08:28:37.214243
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  json_str = r'{"a": 1, "b": 2, "__ansible_vault": "$ANSIBLE_VAULT;1.0;AES;ansible_vault_password123abc...", "c": 3}'
  decoder = AnsibleJSONDecoder()
  json_obj = decoder.decode(json_str)
  assert isinstance(json_obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
  assert json_obj['__ansible_vault'].startswith('$ANSIBLE_VAULT;')
  json_str2 = r'{"a": 1, "b": 2, "__ansible_unsafe": "$ANSIBLE_VAULT;1.0;AES;ansible_vault_password123abc...", "c": 3}'
  json

# Generated at 2022-06-11 08:28:43.648098
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # given
    secrets = ['test']
    v = VaultLib(secrets=secrets)
    json_encrypted_string = v.dump(['test_string'])
    # when
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook({'__ansible_vault': json_encrypted_string})
    # then
    assert type(result) is AnsibleVaultEncryptedUnicode
    assert result.vault.dump(['test_string']) == json_encrypted_string

    # given
    secrets = ['test']
    json_encrypted_string = VaultLib(secrets=secrets).dump(['test_string'])
    # when
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secrets)
    result = decoder.object

# Generated at 2022-06-11 08:28:53.277856
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import ansible.module_utils.common.json
    secret = "123456"
    ansible.module_utils.common.json.AnsibleJSONDecoder.set_secrets(secret)
    json_str = '{"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3132333435363738393031323334353637383930313233343536373839303132\n          3334353637383930313233343536373839303132333435363738393031323334\n          35363738393031323334\n          "}\n'

# Generated at 2022-06-11 08:29:02.148814
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_ansible_vault = '$ANSIBLE_VAULT;1.1;AES256;myusername\n33343630366634386236633562616262633764386338613439373364653036646534666431\n64303332330161336433306566663537656563343039656334653261303265333134373331\n31396433396664303665633762643737633939363137643561303964626132383761303066\n656637646533626365626434383034616365373565393365\n'
    data = {'__ansible_vault': test_ansible_vault}

# Generated at 2022-06-11 08:29:13.154595
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from datetime import datetime

    decoder = AnsibleJSONDecoder()
    ansible_vault = decoder.object_hook({'__ansible_vault': 'foo'})

    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)
    assert ansible_vault == 'foo'
    assert ansible_vault.vault is None

    # Test vault with secrets
    decoder.set_secrets(['secret'])
    ansible_vault = decoder.object_hook({'__ansible_vault': 'foo'})
    assert ansible_vault.vault is not None

    # Test __ansible_unsafe
    unsafe = decoder.object_hook({'__ansible_unsafe': 'foo'})
    assert unsafe == 'foo'
    assertis

# Generated at 2022-06-11 08:29:17.564865
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode(u'test')


ansible_encoder = AnsibleJSONEncoder()
ansible_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:29:28.917038
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256'}
    decoded_obj = AnsibleJSONDecoder().object_hook(obj)

    assert isinstance(decoded_obj, dict) and len(decoded_obj) == 1
    assert '__ansible_vault' in decoded_obj
    assert isinstance(decoded_obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded_obj['__ansible_vault'].vault is None

    secrets = 'foo'
    AnsibleJSONDecoder.set_secrets(secrets)
    decoded_obj = AnsibleJSONDecoder().object_hook(obj)

    assert isinstance(decoded_obj, dict) and len(decoded_obj)

# Generated at 2022-06-11 08:29:33.668858
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({}) == {}
    assert decoder.object_hook({'__key': '__value'}) == {'__key': '__value'}
    assert str(decoder.object_hook({'__ansible_vault': '__value'})) == '$ANSIBLE_VAULT;1.1;AES256'

    assert decoder.object_hook({'__ansible_unsafe': {'__k1': '__v1', '__k2': '__v2'} }) == {'__ansible_unsafe': {'__k1': '__v1', '__k2': '__v2'} }

# Generated at 2022-06-11 08:29:42.770802
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)

    assert decoder.decode('{"__ansible_vault": "long_encrypted_string", "__ansible_unsafe": "plain_text"}') == dict(
        __ansible_vault=u'long_encrypted_string', __ansible_unsafe=u'plain_text')
    assert decoder.decode('{"__ansible_vault": "long_encrypted_string"}') == dict(
        __ansible_vault=u'long_encrypted_string')
    assert decoder.decode('{"__ansible_unsafe": "plain_text"}') == dict(__ansible_unsafe=u'plain_text')

# Generated at 2022-06-11 08:29:50.786572
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    decoder = AnsibleJSONDecoder()
    assert decoder
    secret = 'test-secrets'
    decoder.set_secrets(secret)


# Generated at 2022-06-11 08:30:04.064633
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.utils.unsafe_proxy import wrap_var

    test_json = json.dumps(
        {'__ansible_unsafe': '__ansible_unsafe__',
         '__ansible_vault': '__ansible_vault__'},
        cls=AnsibleJSONEncoder)

    secrets = [{'__ansible_vault': 'THE_VAULT_PASS_FROM_SECRETS'}]

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets=secrets)
    result = decoder.decode(s=test_json)

    assert isinstance(result['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-11 08:30:14.745572
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:30:25.468670
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    print("json_module_utils.test_AnsibleJSONDecoder_object_hook")

    import pprint

    json_s = """
        {
            "__ansible_unsafe": "{k:123}",
            "__ansible_vault": "VGhpcyBpcyB0aGUgb3JpZ2luYWwgY29udGVudHMsIHdoaWNoLCBvbiBkZW1hbmRzLCBzaG91bGQgbmV2ZXIgYmUgdmlzaWJsZSBpbiB0aGUgQ2xvdWQK"
        }
    """
    decoder = AnsibleJSONDecoder(json_s)
    d = decoder.decode()

    pprint.pprint(d)


# Generated at 2022-06-11 08:30:35.036218
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text = """{
    "__ansible_unsafe": "clamav-daemon restart",
    "__ansible_vault": "clamav-daemon restart"
}"""
    decoder = AnsibleJSONDecoder()
    json_dict = json.loads(json_text, cls=decoder)
    assert json_dict['__ansible_unsafe'] == "clamav-daemon restart"
    assert json_dict['__ansible_vault'] == "clamav-daemon restart"

    json_text = """{
    "__ansible_unsafe": "clamav-daemon restart"
}"""
    decoder = AnsibleJSONDecoder()
    json_dict = json.loads(json_text, cls=decoder)


# Generated at 2022-06-11 08:30:46.292018
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import from_json
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    secret1 = 'b3BlbnNlY3JldAo='
    secret2 = 'YW5zaWJsZQo='
    secrets = {'default': secret1, 'foo': secret2}
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-11 08:30:54.276628
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    jdecoder = AnsibleJSONDecoder()
    jdecoder.set_secrets(secrets)
    # test if method object_hook returns an object of type AnsibleVaultEncryptedUnicode
    pairs = {'__ansible_vault': 'test'}
    vault_encrypt_string = jdecoder.object_hook(pairs)
    assert isinstance(vault_encrypt_string, AnsibleVaultEncryptedUnicode)
    # test if method object_hook returns an object of type AnsibleVaultEncryptedUnicode
    pairs = {'__ansible_unsafe': 'test'}
    unsafe_string = jdecoder.object_hook(pairs)
    assert isinstance(unsafe_string, unsafe_proxy)

# Generated at 2022-06-11 08:31:03.431968
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test pairs with key '__ansible_vault'
    pairs = {'__ansible_vault': 'value'}
    assert isinstance(decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)
    assert decoder.object_hook(pairs).vault == None

    # Test pairs with key '__ansible_unsafe'
    pairs = {'__ansible_unsafe': 'value'}
    assert decoder.object_hook(pairs) == 'value'

    # Test pairs without keys '__ansible_vault' and '__ansible_unsafe'
    pairs = {'key': 'value'}
    assert decoder.object_hook(pairs) == pairs



# Generated at 2022-06-11 08:31:12.856980
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_value = '$ANSIBLE_VAULT;1.2;AES256;test\n3335616538333165650a3863653539643433626332333234643934313231333865663338353432\n64636462386437313135643262613537646136613939346638303462383534333261336239383531\n3939393335666162636465622e\n'
    assert AnsibleJSONDecoder.object_hook(dict(__ansible_vault=test_value)) == \
        AnsibleVaultEncryptedUnicode(test_value)


# Generated at 2022-06-11 08:31:20.431955
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible_collections.notstdlib.moveitallout.plugins.filter.encrypt import encrypt

    json_str = '{"__ansible_vault": "oldvalue", "__ansible_unsafe": "oldvalue"}'
    assert json.loads(json_str, cls=AnsibleJSONDecoder) == {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('oldvalue'),
        '__ansible_unsafe': AnsibleJSONEncoder.wrap_var('oldvalue')
    }

    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)

    json_str = '{"__ansible_vault": "oldvalue", "__ansible_unsafe": "oldvalue"}'

# Generated at 2022-06-11 08:31:31.534581
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {
        '_raw_params': '__ansible_unsafe=__ansible_vault=foo',
        '_uses_shell': False,
        '_raw_params_split': [
            '__ansible_unsafe=__ansible_vault=foo'
        ]
    }
    decoded = AnsibleJSONDecoder().decode(json.dumps(test_data))

    assert isinstance(decoded['_raw_params'], str)
    assert isinstance(decoded['_uses_shell'], bool)
    assert isinstance(decoded['_raw_params_split'], list)
    assert len(decoded['_raw_params_split']) == 1
    assert isinstance(decoded['_raw_params_split'][0], str)

# Generated at 2022-06-11 08:31:44.021798
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'test_secret'
    AnsibleJSONDecoder.set_secrets(secrets)

    input_data = dict(
        __ansible_vault='$ANSIBLE_VAULT;1.1;AES256;ansible\n356364306161333236353334346265363739626435663538396437366164373435633933343264\n35396434343164653366386366323636626235663665613431300a3334653064622d39633934612d\n343533382d633866302d38663339366532336466613935630a',
        __ansible_unsafe='Hello World'
    )


# Generated at 2022-06-11 08:31:55.146757
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import pytest
    if sys.version_info >= (2, 7):
        from unittest import TestCase
    else:
        from unittest2 import TestCase

    class TestJSONDecoder(TestCase):
        vault_password = None

        def setUp(self):
            self.vault_password = 'test_password'

        def test_vault_object_hook(self):
            test_json = '''
            {
              "__ansible_vault": "thevaultencryptedstring"
            }
            '''

            decoder = AnsibleJSONDecoder()
            AnsibleJSONDecoder.set_secrets([self.vault_password])
            decrypted_json = decoder.decode(test_json)

# Generated at 2022-06-11 08:32:03.811353
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json_data = """{
        "private_key_file": "/etc/ssl/private/ansible_ssl.key",
        "__ansible_vault": "Vault(0.1)\nbXktZm9vYmFyLXBhc3N3b3JkCg=="
    }"""
    secrets = ['my-foobar-password']
    expected = {
        'private_key_file': '/etc/ssl/private/ansible_ssl.key',
        '__ansible_vault': 'Vault(0.1)\nbXktZm9vYmFyLXBhc3N3b3JkCg==',
    }

    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:32:11.240343
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_string = '$ANSIBLE_VAULT;1.1;AES256\nMTIzNDU2Nzg5MDEyMzQ1Njc4OTM0NTY3ODkwMTIzNDU2Nzg5\nMDEyMzQ1Njc4\n'
    eu = AnsibleVaultEncryptedUnicode(vault_string)
    
    decoder=AnsibleJSONDecoder()
    decoder.object_hook({"__ansible_vault":vault_string})
    decoder.object_hook({"__ansible_unsafe":"not_safe"})



# Generated at 2022-06-11 08:32:18.104342
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ret = AnsibleJSONDecoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test\n66343963366233363331376361396663616233346232303264643464313564653835623133373533\n65376630626637633034653965336437376431363634356637373361353265316530393766383637\n61313330363736', '__ansible_unsafe': 'test unsafe'})

# Generated at 2022-06-11 08:32:26.329407
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['hunter2']

    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert decoder is None

    # The following could also be written as:
    #   result = json.loads('{"__ansible_vault":"$ANSIBLE_VAULT;1.1;AES256;tester\n340349350331333465386364343935313035316266326535343035643736636338323438663436\n393734666364616135653737646661356534373035373033666433653862393633373332336533\n62343038300a333436376239653534643339343831653235326261323136613331366561636533\n32343338

# Generated at 2022-06-11 08:32:34.244015
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    secrets = ['test']
    decoder = AnsibleJSONDecoder
    decoder.set_secrets(secrets)
    text = AnsibleUnsafeText('unsafe')
    pairs = {'__ansible_unsafe': text}
    assert text == decoder.object_hook(pairs)
    pairs = {'__ansible_vault': 'test'}
    assert isinstance(decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:32:40.521023
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = json.loads(b'{"__ansible_vault": "!"}', cls=AnsibleJSONDecoder)

    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is None

    result = json.loads(b'{"__ansible_vault": "!"}', cls=AnsibleJSONDecoder, object_hook=None)

    assert result == {'__ansible_vault': '!'}

# Generated at 2022-06-11 08:32:52.620349
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Decoding json with value __ansible_vault
    j = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:32:59.079469
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # test for vault
    assert isinstance(decoder.object_hook({'__ansible_vault': 'encrypted_text'})['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # test for unsafe
    assert isinstance(decoder.object_hook({'__ansible_unsafe': True})['__ansible_unsafe'], wrap_var.__class__)


# Generated at 2022-06-11 08:33:11.197910
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from collections import OrderedDict
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 08:33:16.423184
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{"password": "abc"}]
    AnsibleJSONDecoder.set_secrets(secrets)

    json_blob = '{"__ansible_vault": "ABC"}'
    parsed = json.loads(json_blob, cls=AnsibleJSONDecoder)

    assert parsed == AnsibleVaultEncryptedUnicode(json_blob)


# Generated at 2022-06-11 08:33:22.281043
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    v = VaultLib(['dummy'])
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = v
    test_dict = {}
    dec1 = decoder.object_hook({"__ansible_vault": "test"})
    assert isinstance(dec1, AnsibleVaultEncryptedUnicode)
    assert dec1.vault._secrets == v._secrets

# Generated at 2022-06-11 08:33:31.370514
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()
    unsafe = wrap_var('/my/password')
    vault = AnsibleVaultEncryptedUnicode('test')

    json_data = [('{"__ansible_unsafe": "%s"}' % unsafe) %
                 ('{"__ansible_vault": "%s" }' % enc.default(vault))]

    for data in json_data:
        json_object = json.loads(data, cls=dec)
        assert json_object['__ansible_unsafe'] == unsafe
        assert json_object['__ansible_vault'] == vault

# Generated at 2022-06-11 08:33:41.540128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set up
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets=['secret_passphrase'])
    dictionary = {'__ansible_vault': 'test_value',
                  '__ansible_unsafe': 'test_value'}

    # Execute
    output = decoder.object_hook(pairs=dictionary)

    # Verify
    assert isinstance(output, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:33:52.415551
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test __ansible_vault key and AnsibleVaultEncryptedUnicode value
    v = decoder.object_hook({'__ansible_vault': 'foo'})
    assert isinstance(v, AnsibleVaultEncryptedUnicode)
    assert v.vault is None
    assert v == AnsibleVaultEncryptedUnicode('foo')

    # Test __ansible_unsafe key and AnsibleUnsafeText value
    v = decoder.object_hook({'__ansible_unsafe': 'foo'})
    assert isinstance(v, AnsibleUnsafeText)
    assert v == 'foo'

    # Test 1st key not defined in AnsibleJSONDecoder.object_hook()

# Generated at 2022-06-11 08:33:58.580299
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = dict(a=1, __ansible_vault='test', b=2)
    obj = AnsibleJSONDecoder().object_hook(obj)
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert obj['__ansible_vault'].data == 'test'
    assert obj['__ansible_vault'].vault == AnsibleJSONDecoder._vaults['default']

# Generated at 2022-06-11 08:34:08.364502
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:34:14.360230
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:34:21.570709
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # data is an AnsibleVaultEncryptedUnicode from VaultLib
    json_data = '{ "__ansible_vault": "vault_string", "__ansible_unsafe": "unsafe_string" }'
    json_decoder = AnsibleJSONDecoder()
    json_decoded = json.loads(json_data, cls=json_decoder.__class__)
    assert isinstance(json_decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_decoded['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:34:33.702032
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test without __ansible_vault
    value = AnsibleJSONDecoder().object_hook({'key': 'value'})
    assert value == {'key': 'value'}

    # Test with __ansible_vault
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])
    value = decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;9.9;AES256\n'
                                                    '333032313931333834653638353865376537336635666132326630393536646231373830363566\n'
                                                    '39326163643233393137623164313334643635376236613337306633\n'})

# Generated at 2022-06-11 08:34:44.844448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.yaml import objects

    secrets = [VaultSecret('password', 'default')]
    vault = VaultLib(secrets=secrets)
    ciphertext = vault.encrypt('foo')

    with tempfile.NamedTemporaryFile() as f:
        f.write('bar: __ansible_vault |\n')
        f.write('  {}\n'.format(ciphertext))
        f.flush()

        with open(f.name, 'rb') as f:
            decoder = AnsibleJSONDecoder.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
            result = decoder.decode(f.read())
            assert result

# Generated at 2022-06-11 08:34:51.603501
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode
    vault_value_1 = '$ANSIBLE_VAULT;1.1;AES256\n122233344556677889900aabbccddeeff!'
    json_value_1 = { "__ansible_vault": vault_value_1}
    json_result_1 = json.dumps(json_value_1, cls=AnsibleJSONEncoder)
    ansible_result_1 = json.loads(json_result_1, cls=AnsibleJSONDecoder)
    assert ansible_result_1['__ansible_vault'] == vault_value_1

    # Test for AnsibleUnsafeText
    unsafe_value_1 = 'unsafe_value_1'

# Generated at 2022-06-11 08:35:01.726201
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # testing __ansible_vault
    plain_text = 'foobar'
    vault_dict = {'__ansible_vault': plain_text}
    decoded_dict = decoder.object_hook(vault_dict)
    assert type(decoded_dict) is AnsibleVaultEncryptedUnicode
    assert decoded_dict.vault == decoder._vaults['default']
    assert decoded_dict == plain_text

    # testing __ansible_unsafe
    test_dict = {'foo': 'bar'}
    unsafe_dict = {'__ansible_unsafe': test_dict}
    assert decoder.object_hook(unsafe_dict) == wrap_var(test_dict)

# Generated at 2022-06-11 08:35:06.825007
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = json.loads('{"__ansible_vault": "my_secret", "__ansible_unsafe": "my_unsafe"}', cls=AnsibleJSONDecoder)

    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['__ansible_unsafe'], wrap_var)


# Generated at 2022-06-11 08:35:17.710977
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = """{
      "__ansible_vault": "vault encrypted data",
      "__ansible_unsafe": "unsafe var",
      "normal_var": "value of normal var"
    }"""
    decoded = json.loads(data, cls=AnsibleJSONDecoder)
    # object_hook method call happens before setting _vaults attribute since it is done inside of __init__
    decoded['__ansible_vault'].vault = VaultLib(secrets=['ansible'])
    decoded['__ansible_vault'] = decoded['__ansible_vault'].decrypt()
    decoded['__ansible_unsafe'] = decoded['__ansible_unsafe'].get()

# Generated at 2022-06-11 08:35:29.230314
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Set an encoder that is used for testing AnsibleJSONEncoder for purposes of converting the various ansible vars (unsafe, vault)
    AnsibleJSONEncoder.set_encoder(AnsibleJSONEncoder.encoder)

    # Set a set of secrets
    AnsibleJSONDecoder.set_secrets('test')

    # example of code from: EncryptedDict.__init__

# Generated at 2022-06-11 08:35:33.993519
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'secret'
    decoder = AnsibleJSONDecoder.set_secrets(secret)
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;'}
    result = decoder.object_hook(pairs)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:35:42.586512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class TestAnsibleJSONDecoder(AnsibleJSONDecoder):
        def __init__(self):
            super(TestAnsibleJSONDecoder, self).__init__()


# Generated at 2022-06-11 08:35:55.405793
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:03.822696
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    value = dict()
    value['__ansible_vault'] = '$ANSIBLE_VAULT;1.1;AES256;bob\n123456ghijk7890ab=\n'
    result = decoder.object_hook(value)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == decoder._vaults['default']

# Generated at 2022-06-11 08:36:13.965207
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()

    # test non-vault and non-unsafe value
    non_vault_non_unsafe_value = "foo"
    non_vault_non_unsafe_pairs = {'test': non_vault_non_unsafe_value}
    assert non_vault_non_unsafe_value == dec.object_hook(non_vault_non_unsafe_pairs)['test']

    # test vault value
    vault_value = "bar"
    vault_pairs = {'__ansible_vault': vault_value}
    assert isinstance(dec.object_hook(vault_pairs), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:36:20.723149
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook({'__ansible_unsafe': "string"})
    assert result.__class__.__name__ == 'AnsibleUnsafeText'
    assert result.__html__() == "string"

    result = decoder.object_hook({'__ansible_vault': "string"})
    print(result.__class__, dir(result))
    assert result.__class__.__name__ == 'AnsibleVaultEncryptedUnicode'
    assert result.vault is not None
    assert result == "string"

# Generated at 2022-06-11 08:36:31.623897
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['hunter2']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Encrypted variable

# Generated at 2022-06-11 08:36:42.644752
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys

    # There is no good way to test object_hook method
    # of JSONDecoder.

    # The reason is:  The object_hook method will be
    # executed while parsing the input JSON data by
    # the method 'raw_decode'.
    # But there is no mechanism to intercept the call
    # to raw_decode and modify the normal behavior.
    #
    # Hence, we are testing the output of the method
    # load of JSONDecoder, which internally uses the
    # method 'raw_decode'.

    # We are using the below code to achieve this.
    # https://stackoverflow.com/questions/40217409/testing-a-custom-json-decoder

# Generated at 2022-06-11 08:36:51.901186
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:37:01.122888
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText


# Generated at 2022-06-11 08:37:10.882029
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '12345'
    AnsibleJSONDecoder.set_secrets([secret])
    valid_ansible_json = """
    {
        "__ansible_vault": "DdKaFkPudTAAAQAF2QAAAABkZWxldGUK",
        "__ansible_unsafe": "c2VjcmV0cyBtYXkgZG8gZ3JlYXQgd29ybGQgaGVybWVzc2FyeQ=="
    }
    """
    json_decoder = AnsibleJSONDecoder()
    valid_pairs = json_decoder.decode(valid_ansible_json)
    assert '__ansible_vault' in valid_pairs
    assert '__ansible_unsafe' in valid_pairs
   

# Generated at 2022-06-11 08:37:14.883841
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:37:17.545498
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'sensitive'}) == wrap_var('sensitive')



# Generated at 2022-06-11 08:37:37.159960
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:37:45.500589
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n3531213165333861323231346539666264336561623262623663303638336437343530346361626\n6633235613861626633323163653637363363366231\n', '__ansible_unsafe': 'vault'}
    pairs = decoder.object_hook(pairs)
    assert pairs['__ansible_unsafe'] == 'vault'
    assert pairs['__ansible_vault'].vault is None

# Generated at 2022-06-11 08:37:52.832694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    class C(object):
        pass
    c = C()
    c.b = 'my secret'

# Generated at 2022-06-11 08:38:01.954918
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'gAAAAABdsasdfsdfsdfsdfsdfsdfsd', '__ansible_unsafe': 'gAAAAABdsasdfsdfsdfsdfsdfsdfsd'}
    result = decoder.object_hook(pairs)
    expected = {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('gAAAAABdsasdfsdfsdfsdfsdfsdfsd'),
        '__ansible_unsafe': wrap_var('gAAAAABdsasdfsdfsdfsdfsdfsdfsd')
    }
    assert result == expected

# Generated at 2022-06-11 08:38:12.836408
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:38:23.010782
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test that AnsibleVaultEncryptedUnicode is properly handled by the decoder
    test_dict = {
        '__ansible_vault': 'test_value'
    }
    decoded_dict = decoder.object_hook(test_dict)

    assert '__ansible_vault' not in decoded_dict
    assert '__ansible_unsafe' not in decoded_dict

    assert isinstance(decoded_dict['vaulted_value'], AnsibleVaultEncryptedUnicode)
    assert decoded_dict['vaulted_value'] == 'test_value'

    # Test that unsafe wrapper is properly handled by the decoder
    test_dict = {
        '__ansible_unsafe': 'test_value'
    }
    decoded

# Generated at 2022-06-11 08:38:32.583116
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class FakeVault:
        def load(self, sec):
            return sec
    class FakeVaultLib:
        def __init__(self, vault):
            self.vault = vault

    jsonstr = '{"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          306138313931333232633064643066366532663264356534366235366461333765626162383436\n          396131626330656430363534383133393137353430373833383361336133366537633036373065\n          39336666373561363362\n          "}'
    v = FakeVaultLib(FakeVault())