

# Generated at 2022-06-11 08:28:35.565193
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    json_string = '''
    {
        "__ansible_vault": "value1",
        "__ansible_unsafe": "value2"
    }
    '''

    ansible_json_decoder = AnsibleJSONDecoder()
    json_dict = json.loads(json_string, cls=ansible_json_decoder)
    assert isinstance(json_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_dict['__ansible_unsafe'], str)

# Generated at 2022-06-11 08:28:42.765375
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # Test for '__ansible_vault' value

# Generated at 2022-06-11 08:28:52.522006
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # FIXME: tests are not meant to run in parallel.
    # This is a temporary solution that allows the test to pass with
    # python@2.7 and python@3.4 until we drop python@2.7 support.
    # See https://github.com/ansible/ansible/issues/51886.
    AnsibleJSONDecoder._vaults = {}
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-11 08:28:58.594356
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    In this test, the method parent_hook will be tested.
    The parent_hook method is called when we have an object in the json.
    In other words, the method object_hook will be called when the type of the
    data is a dict.
    '''
    #Creating the json string that will be tested.
    #This string is an example of a json file with a vault string.

# Generated at 2022-06-11 08:29:04.293092
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    decoded_pairs = decoder.object_hook({'__ansible_unsafe': 'value'})
    assert decoded_pairs == wrap_var('value')

    # This works on the assumption that the vault password is 'blah'
    decoder.set_secrets('blah')

    decoded_pairs = decoder.object_hook({'__ansible_vault': {'encrypted_value': 'e6c167d6bdd2e2a60eefa9d0e1d8fe7f0d0f25b2ece27195d0725d67f0217686'}})
    assert isinstance(decoded_pairs, AnsibleVaultEncryptedUnicode)
    assert decoded_pairs.vault is not None
   

# Generated at 2022-06-11 08:29:11.075864
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook( dict(__ansible_vault="abc") ) == AnsibleVaultEncryptedUnicode("abc")
    assert decoder.object_hook( dict(__ansible_unsafe="abc") ) == "abc"
    assert decoder.object_hook( dict(__ansible_vault="abc", __ansible_unsafe="def") ) == AnsibleVaultEncryptedUnicode("abc")



# Generated at 2022-06-11 08:29:19.260109
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import os
    from ansible.parsing.vault import VaultEditor

    # Set up vault password:
    vault_pass_file = '/tmp/test_module_utils_common_json.vault'
    with open(vault_pass_file, 'w') as f:
        f.write('mock_vault_password')

    # Set up vault encrypted file:
    vault_file = '/tmp/test_module_utils_common_json.vault.yml'
    ve = VaultEditor(vault_pass_file)
    ve.create_file(vault_file)

# Generated at 2022-06-11 08:29:28.664644
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    _input = '''{
    "__ansible_vault": "vault_contents",
    "__ansible_unsafe": {"group1": {"host1": {"var1": "value", "var2": null}}}
}'''
    _expected = {
        '__ansible_vault': "vault_contents",
        '__ansible_unsafe': {'group1': {'host1': {'var1': 'value', 'var2': None}}}
    }

    json_decoder = AnsibleJSONDecoder()

    result = json_decoder.decode(_input)

    assert result == _expected


# Generated at 2022-06-11 08:29:34.400171
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded_data = json.loads('{"__ansible_vault": "foo", "__ansible_unsafe": "bar"}', cls=AnsibleJSONDecoder)
    assert isinstance(decoded_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded_data['__ansible_unsafe'] == wrap_var('bar')



# Generated at 2022-06-11 08:29:38.604366
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets("test")

    assert decoder.object_hook({'__ansible_vault':'test'}).unwrap() == "test"
    assert decoder.object_hook({'__ansible_unsafe':'test'}).unwrap() == "test"

# Generated at 2022-06-11 08:29:47.983988
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    value = '$ANSIBLE_VAULT;1.1;AES256\n32313935346635393063326262396432383637306430636330336432653038396531383433313963\n39643965666664656639623739613365643330386436663064353033316466353832396639356166\n323566646138313035366364616130643035\n'
    expected = AnsibleVaultEncryptedUnicode(value)

    decoder = AnsibleJSONDecoder()
    decoded = decoder.object_hook({'__ansible_vault': value})
    assert decoded == expected


# Generated at 2022-06-11 08:29:59.157295
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # test __ansible_vault
    decoded_value = decoder.decode('{"__ansible_vault": "hello world"}')
    assert isinstance(decoded_value, AnsibleVaultEncryptedUnicode)
    assert decoded_value == "hello world"
    assert decoded_value.vault is None

    # test __ansible_unsafe
    decoded_value = decoder.decode('{"__ansible_unsafe": "hello world"}')
    assert decoded_value['__ansible_unsafe']._text == 'hello world'
    assert decoded_value['__ansible_unsafe']._interpreter == 'default'


# Generated at 2022-06-11 08:30:08.423439
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['ansible'])


# Generated at 2022-06-11 08:30:18.777360
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test vault
    secret_vault = "test_secret"
    json_str = '{"__ansible_vault": "test_data", "key": "value"}'
    secrets = [secret_vault]
    AnsibleJSONDecoder.set_secrets(secrets=secrets)
    decoded = AnsibleJSONDecoder().decode(json_str)
    assert decoded['__ansible_vault'] == AnsibleVaultEncryptedUnicode("test_data", vault=VaultLib(secrets=secrets))
    assert decoded['key'] == "value"

    # Test unsafe
    json_str = '{"__ansible_unsafe": "test_data", "key": "value"}'
    decoded = AnsibleJSONDecoder().decode(json_str)

# Generated at 2022-06-11 08:30:29.720596
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(b'SECRETS')


# Generated at 2022-06-11 08:30:34.856423
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': '["enc1","enc2","enc3"]',
             '__ansible_unsafe': '{"k1":"v1"}'}
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook(pairs) == {'__ansible_vault': '["enc1","enc2","enc3"]',
                                          '__ansible_unsafe': {"k1":"v1"}}

# Generated at 2022-06-11 08:30:45.916104
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''json_decoder_object_hook.py: test_AnsibleJSONDecoder_object_hook

    Unit test for method object_hook of class AnsibleJSONDecoder
    '''
    # test decoding an ansible vault
    test_vault = json.loads('{"__ansible_vault": "vault goes here"}', cls=AnsibleJSONDecoder)
    assert isinstance(test_vault, AnsibleVaultEncryptedUnicode)

    # test decoding an unsafeproxy object
    test_unsafe = json.loads('{"__ansible_unsafe": "unsafe item"}', cls=AnsibleJSONDecoder)
    assert isinstance(test_unsafe, wrap_var)

    # test decoding normal json

# Generated at 2022-06-11 08:30:54.384258
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class AnsibleVaultEncryptedUnicodeMocked(AnsibleVaultEncryptedUnicode):
        def __init__(self, datum, *args, **kwargs):
            self.datum = datum
            self.vault = None

    class YouShallNotPass(object):
        pass

    class VaultLibMocked(VaultLib):
        def __init__(self, secrets=None):
            self.secrets = secrets

    AnsibleJSONDecoder.set_secrets('foobar')
    data = {
        '__ansible_vault': 'secret',
        '__ansible_unsafe': 'secret',
    }
    ansible_json_decoder = AnsibleJSONDecoder()
    # ansible_json_decoder.object_hook should return AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 08:31:01.825148
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.vault import VaultSecret

    # Setup
    test_secrets = VaultSecret(password_file="test_vault_password_file")
    AnsibleJSONDecoder.set_secrets(test_secrets)

    d = AnsibleJSONDecoder()
    vaulted_data = d.decode('{"__ansible_vault": "test_vaulted_data"}')

    # Test
    assert vaulted_data == AnsibleVaultEncryptedUnicode("test_vaulted_data", vault=d._vaults['default'])



# Generated at 2022-06-11 08:31:12.536944
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import os

    ansible_module_shared_libs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../lib'))
    ansible_module_shared_libs_path = os.path.join(ansible_module_shared_libs_path, 'ansible', 'module_utils')

    sys.path.append(ansible_module_shared_libs_path)

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # Encrypted Vault example:
    # ansible_module_shared_libs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../lib'

# Generated at 2022-06-11 08:31:24.140287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'secret'
    secrets2 = 'secret2'
    vault = VaultLib(secrets=secrets)
    vault2 = VaultLib(secrets=secrets2)

    # test object hook for __ansible_vault
    data = '{"__ansible_vault": fake_cipher}'
    data = json.loads(data, cls=AnsibleJSONDecoder)
    # Test that __ansible_vault is decoded to type AnsibleVaultEncryptedUnicode
    assert isinstance(data, AnsibleVaultEncryptedUnicode)

    # test object hook for __ansible_unsafe
    data = '{"__ansible_unsafe": "fake_cipher"}'
    data = json.loads(data, cls=AnsibleJSONDecoder)
    # Test that __ansible

# Generated at 2022-06-11 08:31:34.538584
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_data = {'__ansible_vault': "AQA7V11wNzNrOtrP+/FcE0C2Q9mhmbiG0oIAa0w="}
    ansible_unsafe_data = {'__ansible_unsafe': "AQA7V11wNzNrOtrP+/FcE0C2Q9mhmbiG0oIAa0w="}
    normal_data = {'key': "value"}

    decoder = AnsibleJSONDecoder()

    ansible_vault_object = decoder.object_hook(ansible_vault_data)
    ansible_unsafe_object = decoder.object_hook(ansible_unsafe_data)
    normal_object = decoder.object_hook

# Generated at 2022-06-11 08:31:38.919354
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # create input data
    data = {'__ansible_unsafe': 'test', '__ansible_vault': 'stuff'}
    json_data = json.dumps(data)
    # create instance of Decoder
    decoder = AnsibleJSONDecoder()
    # call the decode method with json data to test the object_hook
    result = decoder.decode(json_data)
    # verify the result
    assert isinstance(result, dict)
    assert '__ansible_unsafe' in result
    assert result['__ansible_unsafe'] == 'test'
    assert '__ansible_vault' in result
    assert result['__ansible_vault'] == 'stuff'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 08:31:47.279871
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\nblahblahblah\n'}) == AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\nblahblahblah\n')
    assert decoder.object_hook({u'__ansible_unsafe': u'blahblahblah'}) == wrap_var(u'blahblahblah')

# Generated at 2022-06-11 08:31:58.271716
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    class MyAnsibleJSONDecoder(AnsibleJSONDecoder):
        def object_hook(self, pairs):
            return pairs['__ansible_unsafe']

    plaintext_vault_secret = b'hello world'
    plaintext_vault_password = to_text(b'VaultPasswordHere')

    def run_test_case(input_str, output_str):
        output_str = to_text(output_str)

        decoded = json.loads(to_text(input_str), cls=MyAnsibleJSONDecoder)
        assert decoded == output_

# Generated at 2022-06-11 08:32:05.659403
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import os
    import shutil
    import tempfile
    import copy

    test_passed = False
    test_failed = False
    vault_secret = str(b'hello')
    vault = VaultLib(secrets=[vault_secret])

    # Create temp directory
    temp_path = tempfile.mkdtemp()
    temp_path2 = tempfile.mkdtemp()


# Generated at 2022-06-11 08:32:15.042406
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()
    def _assert(pairs, expected, vault=None):
        result = dec.object_hook(pairs)
        assert result == expected

        if vault is not None:
            assert result.vault == vault

    # assert __ansible_vault without decryption is decoded to AnsibleVaultEncryptedUnicode
    _assert({u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\r\n...'},
        AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\r\n...'))

    # assert __ansible_unsafe

# Generated at 2022-06-11 08:32:24.310652
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class Defaults(object):
        # Default values for the test
        vault_password = 'default-vault-password'
        vault_secrets  = ['/path/to/default/vaultfile']

    # Create an Encoder with the default settings and use it to encode a data
    # structure containing an AnsibleVaultEncryptedUnicode reference
    defaults = Defaults()
    encoder  = AnsibleJSONEncoder(defaults)
    data     = {'__ansible_vault': 'ansible_vault_encrypted_value'}
    encoded  = encoder.encode(data)

    # Create a Decoder with the default settings, give it the password and ask
    # it to decode the JSON encoded data structure
    decoder  = AnsibleJSONDecoder(defaults)

# Generated at 2022-06-11 08:32:34.897396
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [u'testsecret']
    secrets = [u'testsecret']
    obj = json.loads('{"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          6331636534633662366434316631333336331636334316236633230326131633863353433363234\n          63616436333737393665343536656534633039356536303264383434363833663363343135613164\n          343338323139373334393932303063343733393233000000", "__ansible_unsafe": {"_text":  "ABC"}}', object_hook=AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-11 08:32:40.471534
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    my_json = "{\"__ansible_vault\" : \"vault_value\" }"
    decoded_json = json.loads(my_json, cls=AnsibleJSONDecoder)
    assert decoded_json['__ansible_vault'] == "vault_value"
    assert isinstance(decoded_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:32:54.838623
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:59.936704
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '{"__ansible_unsafe": "TEST", "__ansible_vault": "TEST"}'
    result = AnsibleJSONDecoder().decode(json_string)
    assert result == {'__ansible_unsafe': 'TEST', '__ansible_vault': 'TEST'}

# Generated at 2022-06-11 08:33:09.310522
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    a = AnsibleJSONDecoder()
    a._vaults['default'] = VaultLib()
    test_dict1 = {
        '__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;XXXXX....',
    }
    test_dict2 = {
        '__ansible_unsafe': {'a':1},
    }
    assert(isinstance(a.object_hook(test_dict1)['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(a.object_hook(test_dict2)['__ansible_unsafe'] == {'a':1})

# Generated at 2022-06-11 08:33:16.278089
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_unsafe': 'unsafe_string',
             '__ansible_vault': 'my_secret',
             'normal_key': 'some_value'}
    test_dict = AnsibleJSONDecoder().object_hook(pairs)

    assert isinstance(test_dict['__ansible_unsafe'], unicode)
    assert isinstance(test_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(test_dict['normal_key'], unicode)



# Generated at 2022-06-11 08:33:23.144847
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = dict()
    obj['__ansible_vault'] = "12345"
    json_str = json.dumps(obj)
    ansible_json_decoder = AnsibleJSONDecoder()
    result = ansible_json_decoder.decode(json_str)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'] == "12345"



# Generated at 2022-06-11 08:33:34.206255
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\nbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\nbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\nbbbbbbbbbbbbbbbbbbbbbbbbbbb=\n',
                 '__ansible_unsafe': True}
    json_str = json.dumps(json_dict)
    data = AnsibleJSONDecoder.decode(json_str)
    assert isinstance(data, dict)
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
   

# Generated at 2022-06-11 08:33:43.016211
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''ansible.module_utils.common.json_utils.AnsibleJSONDecoder.object_hook()'''
    pairs = {'__ansible_vault': 'this is a vaulted password\n'}
    decoded_vaulted_password = AnsibleJSONDecoder.object_hook(pairs)
    assert isinstance(decoded_vaulted_password, AnsibleVaultEncryptedUnicode)
    assert decoded_vaulted_password == 'this is a vaulted password'

    pairs = {'__ansible_unsafe': True}
    decoded_unsafe_variable = AnsibleJSONDecoder.object_hook(pairs)
    assert decoded_unsafe_variable is True
    assert decoded_unsafe_variable == True

# Generated at 2022-06-11 08:33:54.238041
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestInput:
        def __init__(self, value):
            self.value = value


    # test with none-dict object
    test_input = TestInput(1)
    assert AnsibleJSONDecoder.object_hook(test_input) == test_input

    # test with dict object
    test_input = {'a': 1}
    assert AnsibleJSONDecoder.object_hook(test_input) == test_input

    # test with AnsibleVaultEncryptedUnicode object
    test_input = {'__ansible_vault': 'AQICDDmGjj6U5X9UidMkUpmCrdhru1gDcfa6UeY6wH4R+zE'}

# Generated at 2022-06-11 08:34:04.514966
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('secret')


# Generated at 2022-06-11 08:34:13.625653
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleMapping
    
    test_data = {
        'a': 'b',
        '__ansible_vault': 'gAAAAABfL9XOMmZ1VAQZJynhGRdjvYa1R4y4n4tHCJ_DZvSP8BFLW_xG_nKFHknn1vQ8MUEFJyTovTcTnuD0Q2U_7KxlZjaFPftlVuUmJwKj734Ueqy6U0=',
        '__ansible_unsafe': 'c'
    }

    decoder = AnsibleJSONDecoder()
    ret = decoder.object_hook(test_data)
    assert isinstance(ret, AnsibleMapping)


# Generated at 2022-06-11 08:34:25.712814
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # __ansible_vault
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'foo bar baz'}) == AnsibleVaultEncryptedUnicode('foo bar baz')

    # __ansible_unsafe
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'foo bar baz'}) == wrap_var('foo bar baz')

    # no value
    assert AnsibleJSONDecoder.object_hook({}) == {}



# Generated at 2022-06-11 08:34:36.642827
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:34:41.197964
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    :_vaults is a class member, so it is expected that both decoders
    share the same vault object.
    """
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import Ansi

# Generated at 2022-06-11 08:34:46.433798
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ob = {
        "__ansible_vault": "abcdefghij2090e+//=",
    }
    new_ob = AnsibleJSONDecoder().object_hook(ob)
    assert isinstance(new_ob, AnsibleVaultEncryptedUnicode)
    assert new_ob.data == "abcdefghij2090e+//="


# Generated at 2022-06-11 08:34:51.041427
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json = r"""
    {
        "__ansible_unsafe": "ansible",
        "__ansible_vault": "ansible"
    }
    """
    decoder = AnsibleJSONDecoder()
    result = decoder.decode(test_json)
    assert result == {'__ansible_unsafe':wrap_var('ansible'),
                      '__ansible_vault':AnsibleVaultEncryptedUnicode('ansible')}

# Generated at 2022-06-11 08:35:01.182639
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:09.876034
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault = '$ANSIBLE_VAULT;1.1;AES256;foobarbbq\n663961623561326264633631323533623463373463613865663337623362316666343030323661343\n3936653865343536343938653337356566353136306639653366653634346132356363646265396235\n3836633634653164303439623165323434303864616161663464373965643836\n'

    test = '{"__ansible_vault": "%s"}' % ansible_vault
    secrets = [ansible_vault]

    encrypted = AnsibleJSONDecoder.decode(test)
    AnsibleJSONDecoder.set_secrets

# Generated at 2022-06-11 08:35:17.356397
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestJSONDecoder(AnsibleJSONDecoder):
        pass
    decoder = TestJSONDecoder()

    def _test(pairs):
        return decoder.object_hook(pairs)

    data = '{"__ansible_vault": "$ANSIBLE_VAULT;1.2;AES256;abcdefgh\nabcdefghi=\n"}'
    result = json.loads(data, object_hook=_test)
    assert isinstance(result, AnsibleVaultEncryptedUnicode), result

# Generated at 2022-06-11 08:35:26.071918
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test vault
    vault_object = decoder.object_hook({'__ansible_vault': u'gAAAAABY981Hjk'})
    assert isinstance(vault_object, AnsibleVaultEncryptedUnicode)
    assert isinstance(vault_object.vault, VaultLib)
    # Test unsafe
    unsafe_object = decoder.object_hook({'__ansible_unsafe': u'{{ 100 }}'})
    assert isinstance(unsafe_object, wrap_var)
    assert unsafe_object.value == 100

# Generated at 2022-06-11 08:35:36.351041
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:36:00.593024
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(strict=False)

# Generated at 2022-06-11 08:36:04.216056
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    cls_obj = AnsibleJSONDecoder()
    cls_obj.set_secrets(['fake_pass'])
    assert cls_obj.object_hook(dict(__ansible_vault='$ANSIBLE_VAULT;1.2;AES256;foo\nbar')) == ('bar',)

# Generated at 2022-06-11 08:36:14.564439
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'test_secret'

# Generated at 2022-06-11 08:36:22.460216
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    my_json = """{
        "foo": {
            "__ansible_vault": "decrypted_foo",
            "__ansible_unsafe": "safe_foo"
        },
        "bar": "bar"
    }"""

    vault_secrets = {'default': 'secret_key'}

    # Set vault secrets for testing
    AnsibleJSONDecoder.set_secrets(vault_secrets)

    decoded = json.loads(my_json, cls=AnsibleJSONDecoder)

    # Unsetting vault secrets
    AnsibleJSONDecoder.set_secrets(None)

    assert decoded['foo']['__ansible_vault'].vault.secrets == vault_secrets
    assert decoded['foo']['__ansible_vault'].vault.secrets

# Generated at 2022-06-11 08:36:33.250529
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import io
    import textwrap
    import yaml


# Generated at 2022-06-11 08:36:37.033968
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:43.804505
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{'key': '1234567890', 'vault_id': None}]
    AnsibleJSONDecoder.set_secrets(secrets)
    enc_string = AnsibleJSONEncoder(None, sort_keys=True).encode(dict(key="value"))
    # test decryption of vault variable
    entry = json.loads(enc_string, cls=AnsibleJSONDecoder)
    assert entry.get('__ansible_vault') == "value"

# Generated at 2022-06-11 08:36:52.599319
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import collections
    import pytest
    from ansible.parsing.vault import VaultLib

    decoder = AnsibleJSONDecoder()

    # test no vault instance

# Generated at 2022-06-11 08:37:01.418513
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set __ansible_vault value
    ansible_vault = {}
    ansible_vault['__ansible_vault'] = AnsibleVaultEncryptedUnicode('value')
    # Set __ansible_unsafe value
    ansible_unsafe = {}
    ansible_unsafe['__ansible_unsafe'] = 'value'
    # Set __ansible_vault and __ansible_unsafe value
    ansible_vault_unsafe = {}
    ansible_vault_unsafe['__ansible_vault'] = AnsibleVaultEncryptedUnicode('value')
    ansible_vault_unsafe['__ansible_unsafe'] = 'value'

    # Set ansible vault for decoder
    secrets = ['secret']

# Generated at 2022-06-11 08:37:11.176988
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultEditor
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    secrets = [
        # legacy vault password used by Ansible < 2.4
        {'vault_password_file': 'pw1'},
        # new vault password introduced in Ansible 2.4
        {'vault_password': 'pw2'},
    ]
    vault = VaultEditor('password', json.dumps(secrets, cls=AnsibleJSONEncoder))
    input_value = vault.encrypt(b'hello')
    json_value = {'__ansible_vault': input_value.data}
    decoded_value = AnsibleJSONDecoder().object_hook(json_value)

# Generated at 2022-06-11 08:37:34.652752
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def my_object_hook(pairs):
        pass

    def my_object_pairs_hook(pairs):
        pass

    # Test simple cases
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=my_object_hook, object_pairs_hook=my_object_pairs_hook)
    assert ansible_json_decoder.object_hook == my_object_hook
    assert ansible_json_decoder.object_pairs_hook == my_object_pairs_hook

    ansible_json_decoder = AnsibleJSONDecoder(object_hook=my_object_hook)
    assert ansible_json_decoder.object_hook == my_object_hook
    assert ansible_json_decoder.object_pairs_hook == None

    ansible_json_dec

# Generated at 2022-06-11 08:37:44.760305
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secrets = b'$ANSIBLE_VAULT;1.1;AES256\n356262633534393230333735303661373366373731633662326534663635653163653638316166\n363634363236643833383962313732626364333830326631633332333834303565333830386538\n636161313765363464666535646636623461623635646639386134363862316463356361663835\n3836353739625a637a764b31656469496f453d3d0a\n'.decode('utf-8')

# Generated at 2022-06-11 08:37:52.462373
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'my secret value'

    data_with_vault_key = '''{
    "key1": "value1",
    "key2": "value2",
    "__ansible_vault": "encrypted_value3",
    "key4": "value4"
}'''

    data_with_unsafe_key = '''{
    "key1": "value1",
    "key2": "value2",
    "__ansible_unsafe": "unsafe_value3",
    "key4": "value4"
}'''

    data_without_special_key = '''{
    "key1": "value1",
    "key2": "value2",
    "key3": "value3",
    "key4": "value4"
}'''

    # initialize the

# Generated at 2022-06-11 08:37:55.963114
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json = {"test1": "test1", "test2": "test2", "test3": "test3"}
    result = AnsibleJSONDecoder().object_hook(test_json)
    assert result == test_json


# Generated at 2022-06-11 08:38:05.381455
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestAnsibleJSONDecoder(AnsibleJSONDecoder):
        # Small class to get access to the object_hook method
        def __init__(self):
            pass

    decoder = TestAnsibleJSONDecoder()
    pairs = {'__ansible_vault': {'__ansible_vault_password': "wrong_password"},
             '__ansible_unsafe': {'__ansible_unsafe_key':"fake_value"}}
    result = decoder.object_hook(pairs)

    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(result['__ansible_unsafe'], AnsibleUnsafe)

# Generated at 2022-06-11 08:38:15.270591
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    secrets = [u'H@ck0rz']
    decoder.set_secrets(secrets)
    # json_data = json.loads('{"__ansible_unsafe": "{{ * }}"}', cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:38:22.345523
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    the_json = '{ "__ansible_vault": "abc", "__ansible_unsafe": "def" }'
    obj = json.loads(the_json, cls=AnsibleJSONDecoder)

    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_unsafe'], dict)
    assert obj['__ansible_unsafe']['__ansible_val'] == 'def'

# Generated at 2022-06-11 08:38:32.073144
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # JSON that includes '__ansible_unsafe' and '__ansible_vault'
    # as keys, and AnsibleVaultEncryptedUnicode, and
    # AnsibleUnsafeText as values.
    json_text = '''{
    "a": "b",
    "__ansible_unsafe": "abc",
    "c": {
        "d": "e",
        "__ansible_vault": "ansible-vault encrypted data"
    }
    }'''
    # Parse json text with AnsibleJSONDecoder.
    # Check that AnsibleUnsafeText and AnsibleVaultEncryptedUnicode are used.
    result = json.loads(json_text, cls=AnsibleJSONDecoder)
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText