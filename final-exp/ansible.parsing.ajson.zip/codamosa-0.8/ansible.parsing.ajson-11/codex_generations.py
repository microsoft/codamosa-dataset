

# Generated at 2022-06-11 08:28:38.233537
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '''{"__ansible_vault": "AES256_f10c3d0e2dc90b865d5e5a5f5b5640baa02f8a9f5c5d5b2f", "name": "someone"}'''
    json_string_expected = '{u"name": "someone", u"__ansible_vault": u"AES256_f10c3d0e2dc90b865d5e5a5f5b5640baa02f8a9f5c5d5b2f"}'
    result_decode = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert json.dumps(result_decode, cls=AnsibleJSONEncoder) == json_string_expected

# Generated at 2022-06-11 08:28:48.435038
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '$ANSIBLE_VAULT;9.9;AES256'
    secret_text = 'secret'
    encrypted_secret = {
        '__ansible_vault': '$ANSIBLE_VAULT;9.9;AES256\n353830326137313135353736353739653230383266373865363630353361303032373431613631323262616333363\n3365623662323665363130376333633637303936353638393330663437633839336335316532353232336538343839\n63373436386265353066363664626263656337623162393465\n',
        'some_attr': 'some_attr_value',
    }
    decoded_

# Generated at 2022-06-11 08:28:55.662313
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:04.953102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import datetime
    import re
    import pytest
    from ansible.parsing.vault import VaultSecret

    secret = VaultSecret('password')

    vault = AnsibleVaultEncryptedUnicode('test')
    vault.vault = VaultLib(secrets=[secret])

    # Need to set a password:
    vault.vault.decrypt(vault)

    # Set secrets to global vault
    AnsibleJSONDecoder.set_secrets([secret])

    secret_val = 'secret_val'
    data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n' + vault.vault.encrypt(secret_val) + '\n'}
    decoded = AnsibleJSONDecoder().decode(json.dumps(data))

# Generated at 2022-06-11 08:29:15.412951
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:23.502385
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestVault(object):
        def decrypt(self, data):
            return "This is a test"

    vaults = {'default': TestVault()}

    decoder = AnsibleJSONDecoder.set_secrets(vaults)

    # Testing a non-encrypted variable
    input_value = '"test"'

    # Testing for encrypted variable
    input_value_encrypted = '{"__ansible_vault": "This is a test"}'

    decoded_value = decoder.decode(input_value_encrypted)

    assert decoded_value == "This is a test"

# Generated at 2022-06-11 08:29:34.399878
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets('password')
    json_content = """{"__ansible_unsafe":"$ANSIBLE_VAULT;1.2;AES256;default\n38616132356331373934383665396235356630326631633363386536343961393236656665393361\n31343164303733373561653836613834643361396631616630663161323332626337623134366565\n61653565396437\n"}"""

# Generated at 2022-06-11 08:29:44.000476
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    test_data = """{
        "__ansible_vault": "Vault password: test\n\\n$ANSIBLE_VAULT;1.1;AES256\n3034376437333163636237633731366632613761376237386236306666396465383734393737326166\n3932393666643933613961346132333733623431323833346365323830396665366538646231666136\n613664326138623331666461623836306433363834323765366466353663366232336336\n",
        "__ansible_unsafe": true,
        "plaintext": "text"
    }"""

    # VaultLib and VaultKey objects are needed for processing
    # vault-encrypted

# Generated at 2022-06-11 08:29:50.147600
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    results = decoder.object_hook({'__ansible_unsafe': '{{foo}}', '__ansible_vault': 'x'})
    assert isinstance(results['__ansible_unsafe'], AnsibleUnsafeText)
    assert isinstance(results['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(results['__ansible_vault'].vault, VaultLib)



__all__ = (
    'AnsibleJSONEncoder',
    'AnsibleJSONDecoder',
)

# Generated at 2022-06-11 08:30:01.296305
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = "secret"
    json_list = [{'__ansible_vault': 'UTF-8 Unicode text'},
                 {'__ansible_unsafe': 'encoded string'}]
    json_str = json.dumps(json_list)
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secret)
    test_list = json.loads(json_str, cls=decoder)
    assert isinstance(test_list[0], AnsibleVaultEncryptedUnicode)
    assert test_list[0].encode('UTF-8') == json_list[0]['__ansible_vault']
    assert test_list[1] == json_list[1]['__ansible_unsafe']

# Generated at 2022-06-11 08:30:09.601640
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:19.845243
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    secrets = ['vaultpassword']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:30:24.299398
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    my_dict = {"foo": "bar", "__ansible_vault": "ABC"}
    assert(isinstance(AnsibleJSONDecoder().object_hook(my_dict)['__ansible_vault'], AnsibleVaultEncryptedUnicode))



# Generated at 2022-06-11 08:30:34.174657
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:44.948577
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:30:53.907250
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    This method can be moved to a test case file in the future
    Target: To test if the decoder can decrypt the base64 string in the JSON file and wrap the value
    with the class AnsibleVaultEncryptedUnicode.
    '''
    secrets = 'super-secret-password'

# Generated at 2022-06-11 08:31:03.448731
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # empty mapping
    assert AnsibleJSONDecoder().object_hook({}) == {}
    # empty list
    assert AnsibleJSONDecoder().object_hook([]) == []
    # test if an AnsibleVaultEncryptedUnicode is added as a vault attribute

# Generated at 2022-06-11 08:31:14.595733
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:31:24.342227
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    ToDo:
        - check backslash substitution (e.g. \\n \\t)
    """

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class DummyVault(VaultLib):
        """ Dummy class for testing purpose"""

        def _check_secrets(self):
            return {}

        def decrypt(self, text):
            return '[decrypted string]'

    dut = AnsibleJSONDecoder(object_hook=None)
    vault = DummyVault()
    dut.set_secrets(vault)
    # Set variables

# Generated at 2022-06-11 08:31:34.719733
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import ansible.parsing.dataloader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as AV
    from ansible.parsing.vault import VaultLib

    # Load the fake vault secrets
    secrets_dir = os.path.join(os.path.dirname(ansible.parsing.dataloader.__file__), 'tests', 'Secrets')
    AnsibleJSONDecoder.set_secrets(secrets_dir)

    load = AnsibleJSONDecoder().decode

# Generated at 2022-06-11 08:31:43.310875
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_secrets = ['foo']
    test_encoded = '{ "__ansible_vault": "abc", "__ansible_unsafe": "foo" }'
    test_decoded = {'__ansible_vault': 'abc', '__ansible_unsafe': 'foo'}

    AnsibleJSONDecoder.set_secrets(test_secrets)
    decoder = AnsibleJSONDecoder()
    assert decoder.decode(test_encoded) == test_decoded

# Generated at 2022-06-11 08:31:54.319163
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:02.900239
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = """{
        "__ansible_vault": "!vault |\n    $ANSIBLE_VAULT;1.1;AES256\n    xxxxxxx",
        "__ansible_unsafe": "!vars |\n    $ANSIBLE_VAULT;1.1;AES256\n    xxxxxxx"
    }"""
    secrets = dict(vault_password='my_password')
    AnsibleJSONDecoder.set_secrets(secrets)

    actual = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(actual['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(actual['__ansible_unsafe'], str)

# Generated at 2022-06-11 08:32:07.641460
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # nova
    assert decoder.object_hook({
        '__ansible_vault': 'bar'
    }) == AnsibleVaultEncryptedUnicode('bar')

    # antiga
    assert decoder.object_hook({
        '__ansible_unsafe': 'bar'
    }) == wrap_var('bar')

    # desconhecida
    assert decoder.object_hook({
        'foo': 'bar'
    }) == { 'foo': 'bar' }

# Generated at 2022-06-11 08:32:14.477959
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:23.845036
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['foobarbaz']
    AnsibleJSONDecoder.set_secrets(secrets)
    test_dict = dict(__ansible_vault=dict(__ansible_vault__encrypted_data='encrypted content',
                                          __ansible_vault__version='1.1'))
    test_dict2 = dict(__ansible_unsafe=dict(__ansible_unsafe__raw_body='raw body',
                                            __ansible_unsafe__version='1.1'))
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook(test_dict)
    result2 = decoder.object_hook(test_dict2)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:32:34.391695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_decoder = AnsibleJSONDecoder()

    # Make sure dictionary with a key of __ansible_vault is returned as AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 08:32:45.126241
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # represents the vault encrypted data
    obj1 = json.loads('{"__ansible_vault": "123"}', cls=AnsibleJSONDecoder)
    assert obj1 == AnsibleVaultEncryptedUnicode('123')

    # represents the vault encrypted data
    obj2 = json.loads('{"__ansible_vault": "123"}', cls=decoder)
    assert obj2 == AnsibleVaultEncryptedUnicode('123')

    # represents the unsafe text
    obj3 = json.loads('{"__ansible_unsafe": "123"}', cls=AnsibleJSONDecoder)


# Generated at 2022-06-11 08:32:55.404572
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    password = 'dummy_ansible_password'

    # Just to initialize VaultLib, cipher and iv_cipher
    AnsibleJSONDecoder.set_secrets([password, ])


# Generated at 2022-06-11 08:33:02.878788
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_file = tempfile.NamedTemporaryFile(delete=False)
    v = VaultLib(secrets=[vault_file.name])
    secrets = v.encrypt('asdf')
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = v

    assert decoder.object_hook({'__ansible_vault': secrets}) == b'asdf'
    assert decoder.object_hook({'__ansible_unsafe': 'asdf'}) == b'asdf'

# Generated at 2022-06-11 08:33:06.060364
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['testsecret']
    Ansi

# Generated at 2022-06-11 08:33:12.229141
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for a vault secret
    vault = decoder.object_hook({'__ansible_vault': 'hello'})
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault == 'hello'
    assert vault.vault == None

    # Test for an unsafe secret
    unsafe = decoder.object_hook({'__ansible_unsafe': 'hello'})
    assert isinstance(unsafe, AnsibleString)
    assert unsafe == 'hello'

# Generated at 2022-06-11 08:33:15.925434
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_json = '{"__ansible_vault": "vault stuff"}'
    assert (decoder.decode(test_json) == {"__ansible_vault": "vault stuff"})



# Generated at 2022-06-11 08:33:23.144584
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    value = {
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;test;test_data;test\n"
    }

    decoder = AnsibleJSONDecoder()
    value_decoded = decoder.object_hook(value)

    assert isinstance(value_decoded, AnsibleVaultEncryptedUnicode)
    assert not value_decoded.vault
    assert str(value_decoded) == 'test_data'



# Generated at 2022-06-11 08:33:30.745689
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    cls = AnsibleJSONDecoder
    obj = cls()
    obj.object_hook({'__ansible_vault': 'foo'})

# Ensure the class AnsibleJSONDecoder isn't loaded twice
if '_loaded' not in globals():
    _loaded = True
    if not isinstance(json.JSONEncoder, AnsibleJSONEncoder):
        json.JSONEncoder = AnsibleJSONEncoder
    if not isinstance(json.JSONDecoder, AnsibleJSONDecoder):
        json.JSONDecoder = AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:41.042584
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded_unsafe_proxy_obj = {'__ansible_unsafe': 'unsafe_data'}
    encoded_unsafe_proxy_obj = json.dumps(decoded_unsafe_proxy_obj)
    expected_unsafe_proxy_obj = AnsibleJSONDecoder().decode(encoded_unsafe_proxy_obj)
    assert expected_unsafe_proxy_obj['__ansible_unsafe'] == 'unsafe_data'

    decoded_vault_obj = {'__ansible_vault': 'vault_data'}
    encoded_vault_obj = json.dumps(decoded_vault_obj)
    expected_vault_obj = AnsibleJSONDecoder().decode(encoded_vault_obj)

# Generated at 2022-06-11 08:33:51.891847
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('test_secret')

# Generated at 2022-06-11 08:34:02.273296
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_key = 'password'
    secrets = {'default': secret_key}
    json_string = '{"__ansible_vault": "my_secret"}'
    raw_json = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert str(raw_json) == "b'ANSIBLE_VAULT;1.1;AES256'", "Expected vault string"
    AnsibleJSONDecoder.set_secrets(secrets)
    json_string = '{"__ansible_vault": "my_secret"}'
    raw_json = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert str(raw_json) == "b'ANSIBL'", "Expected decrypted string"
    raw_json = json.loads(json_string)

# Generated at 2022-06-11 08:34:07.533623
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    wrapped = decoder.object_hook({'__ansible_unsafe': b'unsafe'})
    assert isinstance(wrapped, AnsibleJSONEncoder.SafeText)

    vaulted = decoder.object_hook({'__ansible_vault': 'vault'})
    assert isinstance(vaulted, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:34:16.735796
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # TODO: Make this classmethod generic
    def _set_secrets(cls, secrets):
        cls._vaults['default'] = VaultLib(secrets=secrets)

    # Initialize class
    ansible_json_decoder = AnsibleJSONDecoder()

    # Add VaultLib class to class
    _set_secrets(ansible_json_decoder, secrets=['myvaultsecret'])


# Generated at 2022-06-11 08:34:19.341119
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    vau

# Generated at 2022-06-11 08:34:26.760836
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    import base64
    import json
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 08:34:34.670706
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    :return: None
    '''
    ansible_json_decoder = AnsibleJSONDecoder()
    secret_test = ['$test', '$test2']
    ansible_json_decoder.set_secrets(secret_test)
    assert ansible_json_decoder.object_hook({"__ansible_vault": "test"}) == AnsibleVaultEncryptedUnicode('test')
    assert ansible_json_decoder.object_hook({"__ansible_unsafe": "test"}) == wrap_var("test")

# Generated at 2022-06-11 08:34:45.816565
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    text = """
    {
        "__ansible_unsafe": "unsafe",
        "__ansible_vault": "vault"
    }
    """

    decoder = AnsibleJSONDecoder()
    value = decoder.decode(text)
    assert value == {
        '__ansible_unsafe': 'unsafe',
        '__ansible_vault': 'vault',
    }
    assert isinstance(value['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    with open("/tmp/unsafe", "w") as file_p:
        file_p.write("unsafe")
    with open("/tmp/vault", "w") as file_p:
        file_p.write("vault")

    value = decoder.decode(text)

# Generated at 2022-06-11 08:34:53.349929
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    is_unsafe = False
    secrets = ['hunter2']
    item = {"__ansible_vault":"$ANSIBLE_VAULT;1.1;AES256\n3135663933656566353337386534336535393233633037393032313162663839383462333133386334\na\n"}
    vault = VaultLib(secrets=secrets)
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(item.get('__ansible_vault'))
    ansible_vault_encrypted_unicode.vault = vault
    assert AnsibleJSONDecoder._vaults['default'] == vault
    assert ansible_vault_encrypted_unicode.vault == vault

# Generated at 2022-06-11 08:35:04.112131
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:14.124267
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # prepare data for test
    import types
    import collections
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # use string of unicode as password
    password = '中文字符'
    # initialize vault secret
    vault_secrets = [ (password, 'default') ]
    vault = VaultLib(vaults=[(password, 'default', 1)])
    # map to store pairs of key and value
    pairs = {}
    # key of pair to be tested
    key = '__ansible_vault'
    # value of pair to be tested

# Generated at 2022-06-11 08:35:24.458486
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    json_data = '{"__ansible_vault": "123456"}'
    json_decoder = AnsibleJSONDecoder()
    assert(isinstance(json_decoder.decode(json_data), AnsibleVaultEncryptedUnicode))
    json_data = '{"__ansible_unsafe": "123456"}'
    assert(isinstance(json_decoder.decode(json_data), AnsibleUnsafeText))
    json_data = '{"__ansible_none": "123456"}'
    assert("123456" == json_decoder.decode(json_data)["__ansible_none"])


# Generated at 2022-06-11 08:35:32.462363
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook({
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
        '__ansible_unsafe': '$ANSIBLE_UNSAFE'
    })
    assert result[0].__class__ == AnsibleVaultEncryptedUnicode
    assert result[0].vault == None
    assert result[1].__class__ == wrap_var
    assert result[1]._data == '$ANSIBLE_UNSAFE'


# Generated at 2022-06-11 08:35:36.609977
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create an AnsibleJSONDecoder object
    ans_decoder = AnsibleJSONDecoder()
    # Create the dictonary to be parsed by the object_hook method
    pairs_a = {'a': 'b'}
    res_a = ans_decoder.object_hook(pairs_a)
    assert res_a == pairs_a
    # Create the dictonary to be parsed by the object_hook method
    pairs_vault = {'__ansible_vault': 'secret'}
    res_vault = ans_decoder.object_hook(pairs_vault)
    assert isinstance(res_vault, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:35:45.409049
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    cases = [
        ('{"__ansible_vault": "value"}', AnsibleVaultEncryptedUnicode('value')),
        ('{"__ansible_unsafe": "value"}', wrap_var('value')),
        ('{"other": "value"}', {'other': 'value'}),
        ('"string"', 'string'),
    ]

    decoder = AnsibleJSONDecoder()
    for case in cases:
        assert decoder.object_hook(json.loads(case[0])) == case[1]


# Generated at 2022-06-11 08:35:57.999432
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault = {
        'vault_id': 'secret',
        'password': 'ansible'
    }
    unsafe = 'ansible'

    # Test object_hook with vault
    assert json.loads('{"__ansible_vault": "YW5zaWJsZQ=="}', cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode("ansible")
    assert json.loads('{"__ansible_vault": "YW5zaWJsZQ=="}', cls=AnsibleJSONDecoder, object_hook=AnsibleJSONDecoder.object_hook) == AnsibleVaultEncryptedUnicode("ansible")
    assert json.loads('{"__ansible_vault": "YW5zaWJsZQ=="}', cls=AnsibleJSONDecoder).v

# Generated at 2022-06-11 08:36:04.791267
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:09.097351
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    data = '{"__ansible_unsafe": "some text", "some_key": "some value"}'
    assert decoder.decode(data) == {"__ansible_unsafe": wrap_var("some text"), "some_key": "some value"}

# Generated at 2022-06-11 08:36:18.878499
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'hunter2'
    decoder = AnsibleJSONDecoder.set_secrets(secret)
    assert decoder.object_hook({'__ansible_unsafe': '$SHELL'}) == wrap_var('$SHELL')

# Generated at 2022-06-11 08:36:29.761996
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault = u"""$ANSIBLE_VAULT;1.1;AES256
61376633306566393536623064333738636162613335373830333739356466343264376637353033
3764396366396162383362643835303639653633663430a66313463366232616663373565663565
62393465643330383938353132386365663231646231393538663830356632633634376565393830
66653534613431320a34353366316362346631623631636335623162653639373437373264313133
37393465623462323432633831666232346332346336"""
    decoded_

# Generated at 2022-06-11 08:36:40.456743
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;ansible_test_hash\n/7Xmu8d/xVQsDdqMmT+TJJw==\n'}) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;ansible_test_hash\n/7Xmu8d/xVQsDdqMmT+TJJw==\n')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': '{{ secret_password }}'}) == wrap_var('{{ secret_password }}')

# Generated at 2022-06-11 08:36:49.303043
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {
        "key": "value",
        "key2": "$ANSIBLE_VAULT;1.1;AES256\n35363738393031323334353637383930"
    }

    json_data = json.dumps(data, cls=AnsibleJSONEncoder)
    decoded_data = json.loads(json_data, cls=AnsibleJSONDecoder)

    assert(decoded_data.get("key2") == "$ANSIBLE_VAULT;1.1;AES256\n35363738393031323334353637383930")
    assert(decoded_data.get("key") == "value")

# Generated at 2022-06-11 08:36:57.398433
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{'test': 'testing'}, {'test': 'testing'}]
    AnsibleJSONDecoder.set_secrets(secrets)

    v_object = json.load(open('../../lib/ansible/playbook/vault.py'), cls=AnsibleJSONDecoder)
    assert v_object['__ansible_vault'] != 'encrypted'

    u_object = json.load(open('../../lib/ansible/playbook/unsafe_proxy.py'), cls=AnsibleJSONDecoder)
    assert u_object['__ansible_unsafe'] != 'test'

# Generated at 2022-06-11 08:37:04.888963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_strings = [
        '{"__ansible_vault": "vault_test_string"}',
        '{"__ansible_vault": {"value": "vault_test_dict"}}',
        '{"__ansible_unsafe": "unsafe_test_string"}',
        '{"__ansible_unsafe": {"value": "unsafe_test_dict"}}'
    ]
    for string in test_strings:
        result = decoder.decode(string)
        assert isinstance(result, dict)
        assert list(result)[0] in ['__ansible_vault', '__ansible_unsafe']


# Generated at 2022-06-11 08:37:19.620243
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    "Assert that object_hook returns vaulted unicode or unsafe object"
    encryped_unicode_json = json.dumps(
        {
            '__ansible_vault': 'vaulted data'
        },
        cls=AnsibleJSONEncoder
    )
    json_data = json.loads(encryped_unicode_json, cls=AnsibleJSONDecoder)
    assert isinstance(json_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert json_data['__ansible_vault'].vault

    unsafe_object_json = json.dumps(
        {
            '__ansible_unsafe': 'unsafe object'
        },
        cls=AnsibleJSONEncoder
    )

# Generated at 2022-06-11 08:37:27.105389
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    value = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n373766636462336230316437363865373365613963666563643536363065353463366239313466\n313565643966356430623135316431386133613664363763396365633864346566326166356664\n663638\n', # noqa
    }

    result = decoder.object_hook(value)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault is None


# Generated at 2022-06-11 08:37:33.214963
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()

    text = encoder.encode(dict(foo=dict(__ansible_vault='encrypted'),
                               bar=dict(__ansible_unsafe='junk')))

    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(text)

    assert isinstance(decoded['foo'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['bar'], AnsibleUnsafe)

# Generated at 2022-06-11 08:37:41.118968
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class FakeVault:
        def __init__(self, *args, **kwargs):
            pass

    # Wrap a variable to __ansible_unsafe
    TEST_VARIABLE = "test_variable"
    unsafe = wrap_var(TEST_VARIABLE)
    unsafe_pairs = {'__ansible_unsafe': str(unsafe)}
    unsafe_json = json.dumps(unsafe_pairs, cls=AnsibleJSONEncoder)
    json_variable = json.loads(unsafe_json, cls=AnsibleJSONDecoder)
    assert json_variable == unsafe

# Generated at 2022-06-11 08:37:50.549659
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    expected_result = {'a': 2, 'b': AnsibleVaultEncryptedUnicode('test'), '__ansible_unsafe': 1}

# Generated at 2022-06-11 08:38:00.709411
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:38:11.695294
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test values that should return unchanged
    test_value = 'string'
    assert AnsibleJSONDecoder.object_hook({ '__ansible_unsafe': test_value }) == test_value
    test_value = 42
    assert AnsibleJSONDecoder.object_hook({ '__ansible_unsafe': test_value }) == test_value
    test_value = { 'key': 'value' }
    assert AnsibleJSONDecoder.object_hook({ '__ansible_unsafe': test_value }) == test_value
    test_value = ['item']
    assert AnsibleJSONDecoder.object_hook({ '__ansible_unsafe': test_value }) == test_value
    test_value = False
    assert AnsibleJSON

# Generated at 2022-06-11 08:38:18.419035
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Wrapping an existing variable with __ansible_unsafe key
    existing_dict = dict(some_key=dict(some_value=True))
    test_dict = {'__ansible_unsafe': existing_dict}
    decoded_dict = json.loads(json.dumps(test_dict), cls=AnsibleJSONDecoder)
    assert isinstance(decoded_dict, dict)
    assert '__ansible_unsafe' not in decoded_dict
    assert 'some_key' in decoded_dict
    assert 'some_value' in decoded_dict['some_key']
    assert decoded_dict['some_key']['some_value'] == True
    assert decoded_dict == existing_dict

    # Wrapping an existing variable with __ansible_vault key

# Generated at 2022-06-11 08:38:29.114001
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = '$ANSIBLE_VAULT;1.1;AES256\n'
    secrets += '317839656231623837623236346466396335643235613864663032653836326434613531333764\n'
    secrets += '396665623838663565376533353561346539313761396265653533343339633065313837616361\n'
    secrets += '6334636436373534306132650a3363316230623233396336353964663438646636346466356234\n'
    secrets += '643735376539356363353236653631666162313635343531333166393866613231333235643538\n'