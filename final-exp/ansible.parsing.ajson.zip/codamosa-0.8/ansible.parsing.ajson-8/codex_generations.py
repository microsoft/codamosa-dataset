

# Generated at 2022-06-11 08:28:31.466677
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    text = '{"key": "value"}'
    result = decoder.decode(text)
    assert result == {u'key': u'value'}


# Generated at 2022-06-11 08:28:37.099856
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    AnsibleJSONDecoder.set_secrets(secrets)

    d = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "mypassword", "__ansible_unsafe": {"a": 1, "b": 3}}
    hook = d.object_hook(pairs)

    assert hook['__ansible_vault'].vault.secrets == secrets
    assert hook['__ansible_unsafe'].data == {'a': 1, 'b': 3}

# Generated at 2022-06-11 08:28:39.850536
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    sys.path.append('/home/jenkins/workspace/test_integration/test/utils')
    o = AnsibleJSONDecoder()
    pairs = {'__ansible_unsafe': 'foo'}
    assert o.object_hook(pairs) == pairs

# Generated at 2022-06-11 08:28:47.478433
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "1.1$0123456789abcdef01234567", "__ansible_unsafe": "yes"}'
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)

    assert json_obj['__ansible_unsafe'] == wrap_var('yes')
    assert not isinstance(json_obj['__ansible_unsafe'], str)
    assert isinstance(json_obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:28:56.754401
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:06.494910
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '''
    {
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;myuser;mypassword"
    }
    '''
    value = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert value.get('__ansible_vault') == '$ANSIBLE_VAULT;1.1;AES256;myuser;mypassword'
    assert isinstance(value.get('__ansible_vault'), AnsibleVaultEncryptedUnicode)

    # Create a vault object for AnsibleJSONDecoder
    secrets = ['mypassword']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Decode again
    value = json.loads(json_str, cls=AnsibleJSONDecoder)

# Generated at 2022-06-11 08:29:16.396230
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:29:27.510224
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:29:37.799484
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test AnsibleVaultEncryptedUnicode
    input = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n61646d696e5f6e616d65', 'other': True}
    result = decoder.object_hook(input)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is None
    assert result.unencrypted_value == 'adamin_name'

    # Test safe_var
    input = {'__ansible_unsafe': '$.some_var'}
    result = decoder.object_hook(input)
    assert result.__class__.__name__ == 'SafeText'

# Generated at 2022-06-11 08:29:44.391720
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    import json
    import sys

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-11 08:29:53.272298
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    try:
        from json.decoder import JSONDecodeError
    except ImportError:
        JSONDecodeError = ValueError
    encoder = AnsibleJSONEncoder()
    decodr = AnsibleJSONDecoder(encoding='utf-8')
    string = encoder.encode(
        dict(__ansible_vault='$ANSIBLE_VAULT;1.2;AES256;dev\r\n343134393539323834373139\r\n343134393539323834373139\r\n')
    )
    decodr.set_secrets(['test'])
    decodr.decode(string)

# Generated at 2022-06-11 08:30:04.915240
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import from_json

    # In case of dictionary containing __ansible_vault and __ansible_unsafe
    data = {'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe', 'other': 'other'}
    result = from_json(json.dumps(data), AnsibleJSONDecoder)
    assert(result['__ansible_vault'] == 'vault')
    assert(str(result['__ansible_vault']) == 'vault')
    assert(result['__ansible_vault'].__class__.__name__ == 'AnsibleVaultEncryptedUnicode')
    assert(result['__ansible_unsafe'] == 'unsafe')

# Generated at 2022-06-11 08:30:15.087719
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup the vault password
    secrets = [{'default': 'test'}]
    AnsibleJSONDecoder.set_secrets(secrets)

    # Setup the JSON string

# Generated at 2022-06-11 08:30:25.752852
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with vaulted content
    data = b'{"__ansible_vault": "test"}'
    decoder = AnsibleJSONDecoder()
    decrypted = decoder.decode(data)

    assert decrypted['__ansible_vault'] is not None
    assert decrypted['__ansible_vault'] == "test"

    # Test with unsafe content
    data = b'{"__ansible_unsafe": "test"}'
    decoder = AnsibleJSONDecoder()
    decrypted = decoder.decode(data)

    assert decrypted['__ansible_unsafe'] is not None
    assert decrypted['__ansible_unsafe'] == "test"

    # Test with safe content
    data = b'{"safe": "test"}'
    decoder = AnsibleJSONDecoder()
    decrypted

# Generated at 2022-06-11 08:30:30.903789
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({}) == {}
    assert decoder.object_hook({'__ansible_vault': 'something'}) == AnsibleVaultEncryptedUnicode('something')
    assert decoder.object_hook({'__ansible_unsafe': 'something'}) == wrap_var('something')

# Generated at 2022-06-11 08:30:37.852074
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secr = [{'password': 'ansible'}]
    obj = AnsibleJSONDecoder.set_secrets(secr)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secr
    unsafe_json = '{"__ansible_unsafe": "&"}'
    decode_unsafe_json = AnsibleJSONDecoder.decode(unsafe_json)
    assert decode_unsafe_json == {'__ansible_unsafe': u'&'}
    vault_json = '{"__ansible_vault": "{PLAINTEXT}"}'
    decode_vault_json = AnsibleJSONDecoder().decode(vault_json)
    assert decode_vault_json == {'__ansible_vault': u'{PLAINTEXT}'}

# Generated at 2022-06-11 08:30:49.090349
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['kek'])


# Generated at 2022-06-11 08:30:59.594071
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # if the string '__ansible_vault' is in the payload, then it will call the object_hook of class AnsibleJSONDecoder which will
    # create a AnsibleVaultEncryptedUnicode object.
    # As per the code, the value of __ansible_vault will be decrypted by the VaultLib class
    value = json.loads(open('/Users/glenn/Documents/ansible-2.7.9/lib/ansible/module_utils/facts/hardware/ibm/lenovo/ibm_lenovo_firmware.json', 'r').read(), cls=AnsibleJSONDecoder)
    print("The value is: ", value)

# Generated at 2022-06-11 08:31:05.961694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    single_secret = {'default': {'vault_password_file': 'some_file'}}
    AnsibleJSONDecoder.set_secrets(single_secret)

    assert isinstance(json.loads('{"__ansible_vault": "vault value"}', cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)
    assert isinstance(json.loads('{"__ansible_unsafe": "unsafe value"}', cls=AnsibleJSONDecoder), AnsibleUnsafeText)

# Required for testing
from ansible.parsing.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-11 08:31:12.102697
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # case1.
    decoded = '{"__ansible_vault": "mysecret", "__ansible_unsafe": "mysecret2"}'
    actual = AnsibleJSONDecoder.object_hook(json.loads(decoded))
    expected = {'__ansible_vault': 'mysecret', '__ansible_unsafe': 'mysecret2'}
    assert actual == expected


# Generated at 2022-06-11 08:31:17.239007
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_value = '''{
        "a": 1,
        "b": {"c": 2}
    }'''
    json_object = json.loads(json_value, cls=AnsibleJSONDecoder)
    assert json_object['a'] == 1
    assert json_object['b']['c'] == 2


# Generated at 2022-06-11 08:31:28.066121
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create test object
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)


# Generated at 2022-06-11 08:31:36.181838
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '{"__ansible_vault": "encoded_vault_string_is_here", "__ansible_unsafe": "i am unsafe"}'

    decoder = AnsibleJSONDecoder(json_data)
    result = decoder.object_hook(json_data)

    assert result['__ansible_vault'].vault.secrets == ['default']
    assert isinstance(result['__ansible_vault'].value, bytes)

    assert result['__ansible_unsafe']._value == 'i am unsafe'
    assert result['__ansible_unsafe']._unsafe_proxy._wrap

# Generated at 2022-06-11 08:31:45.723608
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:31:56.943441
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:32:04.501065
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest

    class TestAnsibleJSONDecoder(unittest.TestCase):

        def setUp(self):
            self.encoder = AnsibleJSONEncoder()
            secrets = {'default': VaultSecret('secret123')}
            AnsibleJSONDecoder.set_secrets(secrets)

        def tearDown(self):
            AnsibleJSONDecoder._vaults = {}


# Generated at 2022-06-11 08:32:13.735684
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = dict()
    pairs.update({u'__ansible_unsafe': u'$ANSIBLE_VAULT;1.1;AES256;myvault\n34653964333435613431666232613335653730313065383563326365366662336236353963663366\n34643738323231626336643433356430343562363939356632643738333234353430326565326530\n6439626163613337343732316331363033326631660a323633663061613961353036663733626235\n61343031'
                                            })

# Generated at 2022-06-11 08:32:23.227792
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-11 08:32:33.652431
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ajd = AnsibleJSONDecoder()

    # It should decode a dict with a key '__ansible_vault'
    vault_dict = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n39646237623461623461376234613764376436137613643716432713463764\n39376437643761376137643764376437643'
    }
    decoded_dict = ajd.object_hook(vault_dict)
    assert isinstance(decoded_dict, dict)
    assert len(decoded_dict) == 1

# Generated at 2022-06-11 08:32:44.297226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1', 'secret2', 'secret3']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

    # Test vault hook
    value_without_vault = json.loads('{"a":1, "b":2}', cls=AnsibleJSONDecoder)
    assert isinstance(value_without_vault, dict) is True
    assert value_without_vault == {"a":1, "b":2}


# Generated at 2022-06-11 08:32:55.436997
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['password']
    secrets_str = secrets[0]
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # Test case for AnsibleVaultEncryptedUnicode
    result = json.loads(str(AnsibleJSONEncoder().default(dict(
        __ansible_vault=AnsibleVaultEncryptedUnicode(secrets_str)))), cls=decoder)
    assert result == AnsibleVaultEncryptedUnicode(secrets_str)

    # Test case for wrap_var

# Generated at 2022-06-11 08:33:06.803226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # this test requires pytest
    import pytest


# Generated at 2022-06-11 08:33:10.924684
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import json_dict
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook(json_dict(__ansible_vault='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')) == AnsibleVaultEncryptedUnicode('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')

# Generated at 2022-06-11 08:33:21.266865
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder()

# Generated at 2022-06-11 08:33:32.380671
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.basic import AnsibleModule

    # Test for __ansible_vault

# Generated at 2022-06-11 08:33:42.238885
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:33:53.400715
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    # Test with non vault and non unsafe objects
    non_vault_and_unsafe_pairs = {
        "a": 1,
        "b": "sample"
    }
    assert decoder.object_hook(non_vault_and_unsafe_pairs) == non_vault_and_unsafe_pairs

    # Test with vault object
    vault_pairs = {"__ansible_vault": "some_vault_value"}
    assert isinstance(decoder.object_hook(vault_pairs), AnsibleVaultEncryptedUnicode)

    # Test with unsafe object
    unsafe_pairs = {"__ansible_unsafe": 1234}
    assert isinstance(decoder.object_hook(unsafe_pairs), wrap_var)



# Generated at 2022-06-11 08:33:59.361605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '''{ "__ansible_vault": "vaultdata", "__ansible_unsafe": "unsafedata"}'''
    decoded = AnsibleJSONDecoder().decode(json_data)
    assert(isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(isinstance(decoded['__ansible_unsafe'], wrap_var))

# Generated at 2022-06-11 08:34:04.771173
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    fp = open('test/ansible_json_decoder_test.json')
    json_data = json.load(fp, cls=AnsibleJSONDecoder)
    assert json_data['__ansible_vault'] == '$ANSIBLE_VAULT;1.1;AES256'
    assert json_data['__ansible_unsafe'] == {}
    fp.close()

# Generated at 2022-06-11 08:34:09.658517
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "test"}'
    decoder = AnsibleJSONDecoder()

    v = decoder.decode(s)
    assert isinstance(v, AnsibleVaultEncryptedUnicode)
    assert v == 'test'

    decoder.set_secrets(['test'])
    assert v.vault == decoder._vaults['default']

# Generated at 2022-06-11 08:34:20.827125
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({}) == {}
    assert decoder.object_hook({u'__ansible_vault': u'c3BlY3JhbUBleGFtcGxlLm9yZwo='}) == AnsibleVaultEncryptedUnicode(u'c3BlY3JhbUBleGFtcGxlLm9yZwo=')

# Generated at 2022-06-11 08:34:25.028748
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = "hello"
    x = {'__ansible_vault': "world"}
    AnsibleJSONDecoder.set_secrets(secrets)
    y = AnsibleJSONDecoder().object_hook(x)
    assert y._text == "world"
    assert isinstance(y, AnsibleVaultEncryptedUnicode)
    assert y.vault._secrets == secrets


# Generated at 2022-06-11 08:34:35.559600
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test AnsibleVaultEncryptedUnicode
    vault_secrets = [{'password': 'ansible'}]
    decoder.set_secrets(vault_secrets)
    test_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n313865333835623164323135663066626139633662386163346231663436333436383531303733\n39353366626538306665346465353737386533313861636500\n'}

# Generated at 2022-06-11 08:34:44.937123
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test = decoder.object_hook({
        '__ansible_vault': '$AES$h7sF9LWxRxuQ0rGw7qkOwwhTm7VvD9sIDW8sTJ6s/s0=',
        '__ansible_unsafe': 'This should be wrapped in a var.'
    })
    assert str(test['__ansible_vault']) == '$ANSIBLE_VAULT;1.1;AES256'
    assert test['__ansible_unsafe'] == wrap_var('This should be wrapped in a var.')

# Generated at 2022-06-11 08:34:51.724970
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # initialize the decoder
    decoder = AnsibleJSONDecoder()
    # Check vault variable
    print(decoder._vaults)
    # set secrets

# Generated at 2022-06-11 08:34:56.466403
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = '{"__ansible_unsafe": "ANSIBLESTUFF"}'
    expected_data = {"__ansible_unsafe": "ANSIBLESTUFF"}
    decoded_data = {}
    decoder = AnsibleJSONDecoder()
    decoded_data = decoder.decode(test_data)
    assert expected_data == decoded_data

# Generated at 2022-06-11 08:34:59.677184
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')



# Generated at 2022-06-11 08:35:09.096558
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from __main__ import AnsibleJSONDecoder
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    decoder = AnsibleJSONDecoder()
    pairs = dict()
    pairs['__ansible_unsafe'] = '$ANSIBLE_VAULT;1.1;AES256;vault2;\n383863336536363931333332626138613631396134376561393831656232623862623863663238636336\n343330643461333532356362353762333733653664626233356364383862363133353237636132613334\n30316564363435643835316262623961633563623166623331'

# Generated at 2022-06-11 08:35:19.960746
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:31.430859
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:43.387694
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:35:56.295586
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    json_decoder = AnsibleJSONDecoder()
    vault = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;apple\n3537396538373864393634646662643233663033643162343131633236643162346633323963316363\n363010\n')

# Generated at 2022-06-11 08:36:01.016713
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': 'dGVzdA==', '__ansible_unsafe': 'test'}
    d = AnsibleJSONDecoder.object_hook(pairs)
    assert isinstance(d['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(d['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-11 08:36:10.657295
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secrets = {'vault_password': 'secret', 'default_vault_id': 'vault_password'}
    secrets2 = {'vault_password': 'secret', 'default_vault_id': 'vault_password'}

    # Create a AnsibleVaultEncryptedUnicode object to use in testing
    value = AnsibleVaultEncryptedUnicode('test_data')
    value.vault = VaultLib(secrets=secrets)

    # Create a AnsibleVaultEncryptedUnicode object to use in testing
    value2 = AnsibleVaultEncryptedUnicode('test_data')
    value2.vault = VaultLib(secrets=secrets2)

    # Turn the AnsibleV

# Generated at 2022-06-11 08:36:20.162315
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(b'foo')

# Generated at 2022-06-11 08:36:30.272582
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ["a_secret_string"]
    AnsibleJSONDecoder.set_secrets(secrets)
    test_dict = {'__ansible_vault': 'bWFuIHdvcmtfZmxhZyA9IHRydWU=', '__ansible_unsafe': 'a_string_variable'}
    actual = AnsibleJSONDecoder().object_hook(test_dict)
    expected = {'__ansible_vault': u'bWFuIHdvcmtfZmxhZyA9IHRydWU=', '__ansible_unsafe': u'a_string_variable'}
    assert actual == expected

# to be used from pytest fixtures

# Generated at 2022-06-11 08:36:33.299684
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    obj = decoder.object_hook({'__ansible_unsafe': 'foo'})

    assert str(obj) == 'foo'



# Generated at 2022-06-11 08:36:44.298180
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-11 08:36:52.875492
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # default_secrets_path is set to None, so no vault loaded
    decoder = AnsibleJSONDecoder()
    example = '''
    {
        "__ansible_vault": "bar",
        "__ansible_unsafe": "foo"
    }'''
    result = decoder.decode(example)
    assert type(result['__ansible_vault']) == AnsibleVaultEncryptedUnicode
    assert result['__ansible_unsafe'] == wrap_var('foo')

    # default_secrets_path is set to a file path, so vault is loaded
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['/this/should/not/exist'])

# Generated at 2022-06-11 08:37:01.501359
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = {'__ansible_unsafe': '$.123',
                 '__ansible_vault': '$.123',
                 '__ansible_vault__123': '$.456',
                 '__ansible_vault__456': '$.789',
                 '__ansible_vault__789': '$.abc',
                 '__ansible_vault__abc': '$.def',
                 '__ansible_vault__def': '$.ABC',
                 '__ansible_vault__ABC': '$.DEF',
                 '__ansible_vault__DEF': '$.123',
                 '__ansible_vault__314': '$.$',
                 }
    decoder_test = AnsibleJSONDecoder()
    result = decoder_test.object_hook(json_data)

# Generated at 2022-06-11 08:37:09.640477
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-11 08:37:20.271946
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # unittest does not support subTest() so we reuse this function for each test
    # The test case name is the part after "test_".
    def test_case(case, json_text, expected):
        if isinstance(json_text, str):
            json_text = json_text.encode()
        print("sub Test: {}".format(case))
        obj = json.loads(json_text, cls=AnsibleJSONDecoder)
        print("val: {}, {}".format(type(obj), obj))
        assert obj == expected

    # Test of vault
    test_case("vault", '{"__ansible_vault": "vault_pass"}', AnsibleVaultEncryptedUnicode("vault_pass"))
    # Test of unsafe

# Generated at 2022-06-11 08:37:27.425636
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({ 'key':'value' }) == { 'key':'value' }

# Generated at 2022-06-11 08:37:37.368716
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    module = {
        "__ansible_vault": "vault"
    }

    an = AnsibleJSONDecoder(module)
    assert an.object_hook(module)
    assert isinstance(an.object_hook(module), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:37:46.940303
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"a": {"__ansible_vault": "12345678901234567890123456789012"}}'
    decoded_json_str = AnsibleJSONDecoder().decode(json_str)
    assert isinstance(decoded_json_str['a'], AnsibleVaultEncryptedUnicode)
    assert decoded_json_str['a'].vault.secrets == []

    json_str = '{"a": {"__ansible_unsafe": false}}'
    decoded_json_str = AnsibleJSONDecoder().decode(json_str)
    assert isinstance(decoded_json_str['a'], wrap_var)
    assert decoded_json_str['a'].value is False

# Generated at 2022-06-11 08:37:55.578755
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()

    # Passwords should be decrypted when item is AnsibleVaultEncryptedUnicode
    secrets = ['1234']
    AnsibleJSONDecoder.set_secrets(secrets)
    data = enc.encode({'_ansible_vault': '34hbkK1X0s7Gx8xhDl7Mzw==', 'id': 'password'})
    assert json.loads(data, cls=AnsibleJSONDecoder) == {u'_ansible_vault': u'1234', u'id': u'password'}

    # Unknown_variable should be wrapped when item is unsage
    data = enc.encode({'__ansible_unsafe': '{{ unknown_variable }}'})

# Generated at 2022-06-11 08:38:06.208283
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest


# Generated at 2022-06-11 08:38:15.815780
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class AnsibleJSONDecoder_test(AnsibleJSONDecoder):
        def __init__(self, *args, **kwargs):
            AnsibleJSONDecoder.__init__(self, *args, **kwargs)

    test_data = {
            b'test_value_1': b'value_1',
            b'__ansible_unsafe': b'value_2',
            b'__ansible_vault': b'value_3'
        }

    decoder = AnsibleJSONDecoder_test()

# Generated at 2022-06-11 08:38:22.958894
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_dict = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256',
        '__ansible_unsafe': {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256'}
    }

    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook(test_dict)
    assert isinstance(result['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 08:38:32.584066
# Unit test for method object_hook of class AnsibleJSONDecoder