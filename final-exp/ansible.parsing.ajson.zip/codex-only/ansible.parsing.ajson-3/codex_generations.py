

# Generated at 2022-06-23 04:40:09.181956
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Given
    import json
    data = { "__ansible_vault": "somevaulttext", "__ansible_unsafe": "unsafevalue" }

    # When
    decoded = AnsibleJSONDecoder().object_hook(data)
    assert json.dumps(decoded, cls=AnsibleJSONEncoder) == '{"__ansible_vault": "somevaulttext", "__ansible_unsafe": "unsafevalue"}'

    # When
    decoded = AnsibleJSONDecoder().object_hook( [ ("key1", "value1"), ("key2", "value2") ] )
    assert json.dumps(decoded, cls=AnsibleJSONEncoder) == '{"key1": "value1", "key2": "value2"}'

# vim: expandtab

# Generated at 2022-06-23 04:40:15.985566
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Unit test for constructor of class AnsibleJSONEncoder
    #
    # Args:
    #     this func has no argument
    #
    # Returns:
    #     this func returns no value
    #
    # Raises:
    #     this func has no exception
    #
    # Examples:
    #      >>> test_AnsibleJSONDecoder()
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder is not None


# Generated at 2022-06-23 04:40:26.923527
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test with normal data, no vault, no unsafe
    json_string = '''
    {
    "changed": false,
    "ping": "pong"
    }
    '''
    json_decoder = AnsibleJSONDecoder()
    assert isinstance(json_decoder, json.JSONDecoder)
    assert json_decoder.object_hook

    # test with vault
    json_string = '''
    {
    "__ansible_vault": "data"
    }
    '''
    test_vault = VaultLib()
    json_decoder = AnsibleJSONDecoder()
    json_decoder.set_secrets(test_vault)
    assert isinstance(json_decoder, json.JSONDecoder)
    assert json_decoder.object_hook
    data = json_dec

# Generated at 2022-06-23 04:40:29.142819
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    arg1 = {"__ansible_vault": "value1", "__ansible_unsafe": "value2"}
    obj = AnsibleJSONDecoder(arg1)
    obj.object_hook()
    '''
    assert True

# Generated at 2022-06-23 04:40:40.233682
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:44.238087
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test if user pass in arguments
    decoder = AnsibleJSONDecoder(object_hook=None, encoding='utf-8')
    assert decoder.object_hook is None
    assert decoder.encoding == 'utf-8'

# Generated at 2022-06-23 04:40:46.652036
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_obj = AnsibleJSONDecoder()
    assert test_obj._vaults == {}



# Generated at 2022-06-23 04:40:48.038630
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_decoder, json.JSONDecoder)


# Generated at 2022-06-23 04:40:48.780086
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-23 04:40:56.242031
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    a_map = {
        '__ansible_vault': '$ANSIBLE_VAULT;$encrypted_data',
        '__ansible_unsafe': '[ingest_ssl_certificate]',
    }

    AnsibleJSONDecoder._vaults = {}

    vault_secret = VaultSecret('password')
    vault_lib = VaultLib(secrets=vault_secret)
    AnsibleJSONDecoder._vaults['default'] = vault_lib

    obj = AnsibleJSONDecoder.object_hook(a_map)
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert obj

# Generated at 2022-06-23 04:41:05.182601
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():  # noqa: A001
    secrets = ['secret1', 'secret2']
    secrets2 = ['secret3']
    try:
        assert(AnsibleJSONDecoder.set_secrets(secrets) == None)
        assert(AnsibleJSONDecoder.set_secrets(secrets2) == None)
    except AssertionError:
        return 1

    x = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    json_string = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\naW5zcGxhc2Vk\nb3V0Cg==\n"}'

# Generated at 2022-06-23 04:41:06.511040
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert hasattr(AnsibleJSONDecoder, '_vaults')
    assert AnsibleJSONDecoder._vaults == {}

# Generated at 2022-06-23 04:41:17.827041
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:30.322252
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test value with the __ansible_vault
    s = b'{"__ansible_vault": "foo"}'

    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(s)

    assert(isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(str(decoded['__ansible_vault']) == 'foo')

    # Test value with the __ansible_unsafe
    s = b'{"__ansible_unsafe": "foo"}'

    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(s)

    assert(isinstance(decoded['__ansible_unsafe'], AnsibleUnsafeText))

# Generated at 2022-06-23 04:41:41.976218
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:53.487161
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:55.189077
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert not hasattr(AnsibleJSONDecoder, '_vaults')
    assert AnsibleJSONDecoder is not None

# Generated at 2022-06-23 04:42:03.209302
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [
        {'password': 'secret'}
    ]
    secrets_json = json.dumps(secrets)

    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

    # Decode JSON string with decoding object hook
    decoded = decoder.decode(secrets_json)

    assert decoded[0]['password'] == 'secret'


# Generated at 2022-06-23 04:42:17.079909
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:27.379365
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """Unit test for constructor of class AnsibleJSONDecoder"""

    assert AnsibleJSONDecoder is not None

    #Test case #1 from class AnsibleJSONEncoder
    dirty_json = json.dumps({"B": "b"})
    clean_json = AnsibleJSONEncoder().encode({"A": "a", "B": "b"})

    assert AnsibleJSONDecoder().decode(dirty_json) == {"B": "b"}
    assert AnsibleJSONDecoder().decode(clean_json) == {"A": "a", "B": "b"}

# Generated at 2022-06-23 04:42:38.748634
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class MockVaultObject(object):
        def __init__(self, obj):
            self.obj = obj

    test_decoder = AnsibleJSONDecoder(object_hook = MockVaultObject)

    # test __ansible_vault
    test_input_raw = '{"__ansible_vault": "test_value"}'
    expected_raw = '{"__ansible_vault": "test_value"}'
    result_raw = json.dumps(json.loads(test_input_raw, object_hook = test_decoder.object_hook), cls=AnsibleJSONEncoder)
    assert result_raw == expected_raw

    # test __ansible_unsafe
    test_input_raw = '{"__ansible_unsafe": "test_value"}'

# Generated at 2022-06-23 04:42:49.562110
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test the object_hook method of class AnsibleJSONDecoder
    # The json is:
    # {
    #     "__ansible_vault": "value",
    #     "__ansible_unsafe": "value"
    # }
    secrets = ["test_secret"]

    # initialize object to test
    test_json = json.dumps({'__ansible_vault': 'value', '__ansible_unsafe': 'value'}, cls=AnsibleJSONEncoder)
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(test_json)

    # The expected values

# Generated at 2022-06-23 04:42:58.159685
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test vault
    assert decoder.object_hook(dict(__ansible_vault='A')) == AnsibleVaultEncryptedUnicode('A')

    # Test unsafe strings
    assert decoder.object_hook(dict(__ansible_unsafe='A')) == wrap_var('A')

    # Test everything else
    assert decoder.object_hook(dict(expected_result='A')) == dict(expected_result='A')

# Generated at 2022-06-23 04:43:10.144345
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test that a vault string is converted to AnsibleVaultEncryptedUnicode
    test_value = "__ansible_vault"
    test_value_object = {'__ansible_vault': 'test_string'}
    result = AnsibleJSONDecoder.object_hook(test_value_object)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].decrypted == "test_string"
    # test that a vault string with a vault_id is converted to a AnsibleVaultEncryptedUnicode
    # Note that the vault_password must be 12 characters long.

# Generated at 2022-06-23 04:43:18.737307
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Negative test
    dr = json.decoder.JSONDecoder()
    dr_result = dr.decode('{"__ansible_vault": "dummy"}')
    assert not isinstance(dr_result, AnsibleVaultEncryptedUnicode)

    # Positive test
    dr = AnsibleJSONDecoder()
    dr_result = dr.decode('{"__ansible_vault": "dummy"}')
    assert isinstance(dr_result, AnsibleVaultEncryptedUnicode)
    dr_result = dr.decode('{"__ansible_unsafe": "dummy"}')
    assert isinstance(dr_result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:43:27.130877
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:33.366388
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_password = ['testpass1']
    test_dict = {'key': 'value', '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;user\n32463456324532463245324632453213235436346324532453245324532453245324532453245324532453245324532453245324532453245324532453245\n'}

# Generated at 2022-06-23 04:43:39.141422
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class Args():
        def __init__(self):
            self.__ansible_vault = "vault"
        def get(self):
            return self.__ansible_vault


    args = Args()
    answer = AnsibleJSONDecoder.object_hook(args.__dict__)
    assert answer == args.__dict__

# Generated at 2022-06-23 04:43:50.565619
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # We can not validate the result as we need to use the secret to decrypt vault
    secret = 'some password'
    obj = AnsibleJSONDecoder()
    obj.set_secrets(secret)

# Generated at 2022-06-23 04:44:02.360173
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:44:06.300128
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    x = AnsibleJSONDecoder()
    assert x.object_hook

# Generated at 2022-06-23 04:44:15.537784
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:19.931325
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:31.002031
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # a string
    assert isinstance(json.loads(json.dumps('hello'), cls=AnsibleJSONDecoder), str)

    # a datetime object
    from datetime import datetime
    assert isinstance(json.loads(json.dumps(datetime.now()), cls=AnsibleJSONDecoder), datetime)

    # an encrypted string without secret
    enc_str = '$ANSIBLE_VAULT;9.9;TEST\n'
    encrypted = AnsibleVaultEncryptedUnicode(enc_str)
    assert json.loads(json.dumps(encrypted), cls=AnsibleJSONDecoder) == encrypted

    # an encrypted string with secret
    AnsibleJSONDecoder.set_

# Generated at 2022-06-23 04:44:39.433331
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "vault_text"}'
    json_obj = AnsibleJSONDecoder().decode(json_str)
    assert type(json_obj['__ansible_vault']) == AnsibleVaultEncryptedUnicode
    assert json_obj['__ansible_vault'].vault is None
    assert json_obj['__ansible_vault'].vaulted is True

    json_str = '{"__ansible_unsafe": "unsafe_text"}'
    json_obj = AnsibleJSONDecoder().decode(json_str)
    assert type(json_obj['__ansible_unsafe']) == AnsibleUnsafeText


# Generated at 2022-06-23 04:44:49.243055
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import os

    # Make a temp file with vault content
    (fd, vault_file) = tempfile.mkstemp()
    os.close(fd)

    vault_pass = os.urandom(16).encode('hex')
    vault_content = "{0}".format(os.urandom(16).encode('hex'))
    vault = VaultLib([vault_pass])
    vault.write(vault_content, vault_file)

    # Create a JSON object with vault encrypted data
    data = {'__ansible_vault': vault.encrypt(vault_content)}
    data_json = AnsibleJSONEncoder().encode(data)

    # Decode JSON with provided vault password

# Generated at 2022-06-23 04:45:00.914770
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [
        {'test': 'bar'},
        {'test1': 'bar'},
        {'test2': 'bar'},
    ]
    vault_pass = 'testpass123'
    json_data = '{"test": "bar"}'

# Generated at 2022-06-23 04:45:16.201187
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['vault_password.txt']
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-23 04:45:22.975257
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert hasattr(AnsibleJSONDecoder, '_vaults')
    assert hasattr(AnsibleJSONDecoder, 'object_hook')
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert AnsibleJSONDecoder.__init__


# Generated at 2022-06-23 04:45:25.908961
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    l = None
    try:
        l = AnsibleJSONDecoder()
    except:
        assert(False)
    assert(l is not None)

# Generated at 2022-06-23 04:45:37.822896
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    secrets = ['hush']
    secrets_vault = VaultLib(secrets=secrets)
    loader = DataLoader()
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    data = dict(my_vault_secret='This is a secret', __ansible_vault=loader.encode_text('This is a secret', vault_password=secrets))

    assert json.loads(json.dumps(data, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder) == data
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:45:50.107396
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = dict(__ansible_vault='$ANSIBLE_VAULT;1.1;AES256;test\n3935386233363266373065646635386539303537306335376433323032316436\n3862626235346161333038663635303435363762623335336260623964336562\n633634346635373266633961\n', value=1)

# Generated at 2022-06-23 04:45:58.897491
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    
    assert AnsibleJSONDecoder.set_secrets('b6e1b6e8-6da3-d3e6-00a6-1a50b2ec6bfa')
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'Hello, World!'}) == AnsibleVaultEncryptedUnicode('Hello, World!')
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'Hello, World!'}) == wrap_var('Hello, World!')

# Generated at 2022-06-23 04:46:07.859749
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with ansible vault
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n396161333562303533336462313934633762643934326537383766306261666337623665383636\n303439306532376164303533616332376165306632313537666538333166653665613635613266\ntest_value','__ansible_unsafe':'test_value'}
    ans_decoder = AnsibleJSONDecoder()
    ans_obj = ans_decoder.object_hook(pairs)
    assert(ans_obj['__ansible_vault'] == 'test_value')

# Generated at 2022-06-23 04:46:20.215492
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import sys
    if sys.version_info < (3, 5):
        return
    import json
    import pytest
    from ansible.parsing.vault import VaultLib

    secrets = ["HASH"]
    secrets = secrets
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    assert isinstance(decoder.vaults['default'], VaultLib)

    pytest.raises(TypeError, AnsibleJSONDecoder, 1)
    pytest.raises(TypeError, AnsibleJSONDecoder, object_hook=1)

    l = []
    for i in range(10):
        l += [i]
    decoder = json.JSONDecoder()
    decoder.object_hook = lambda x: x

# Generated at 2022-06-23 04:46:31.262762
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansible_string = '''
    {
        "__ansible_vault": "{vault_encrypted_text}",
        "__ansible_unsafe": "unsafe_variable"
    }
    '''

    # Create AnsibleJSONDecoder object
    decoder = AnsibleJSONDecoder()

    # Set secrets
    secrets = 'secret_password'
    AnsibleJSONDecoder.set_secrets(secrets)

    # Encrypt secret text
    vault_encrypted_text = AnsibleJSONEncoder.vault_encode_text('secret_text', secrets)

    # Replace the string
    ansible_string = ansible_string.replace('{vault_encrypted_text}', vault_encrypted_text)

    # Simulate object_hook for decoding

# Generated at 2022-06-23 04:46:42.837250
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # pylint: disable=protected-access
    # In the future, we can expose these class-level functions.
    assert not AnsibleJSONDecoder._vaults
    secrets = ['test']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults
    json_decoder = AnsibleJSONDecoder()
    assert json_decoder.object_hook

# Generated at 2022-06-23 04:46:53.631007
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Given

# Generated at 2022-06-23 04:47:01.093024
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test_secret']
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:47:03.076998
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder



# Generated at 2022-06-23 04:47:14.897186
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = json.JSONDecoder
    assert decoder != AnsibleJSONDecoder
    assert '__ansible_unsafe' not in json.decoder.scanstring.__code__.co_varnames
    assert '__ansible_vault' not in json.decoder.scanstring.__code__.co_varnames

    decoder = json.JSONDecoder()
    assert decoder.object_hook == None

    decoder = AnsibleJSONDecoder()
    assert hasattr(decoder.object_hook, '__code__')
    assert '__ansible_unsafe' in decoder.object_hook.__code__.co_varnames
    assert '__ansible_vault' in decoder.object_hook.__code__.co_varnames


# Generated at 2022-06-23 04:47:15.838739
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-23 04:47:23.695493
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['foo']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secrets
    result = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'})
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(result['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-23 04:47:31.301496
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    secrets = ['mypassword']
    json_data = '{"__ansible_vault": "mypassword"}'

    json_object = json.loads(json_data, cls=AnsibleJSONDecoder)

    # Ensure the value was decoded successfully
    assert isinstance(json_object, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:47:47.130044
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from six import PY3


# Generated at 2022-06-23 04:47:54.483457
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_data = "vault_password"
    unsafe_data = "unsafe_data"
    data = {"__ansible_vault": vault_data, "__ansible_unsafe": unsafe_data}

    decoder = AnsibleJSONDecoder(*args, **{})
    decoder.set_secrets([vault_data])

    result = decoder.object_hook(data)

    assert result["__ansible_vault"] == vault_data
    assert result["__ansible_unsafe"] == unsafe_data


# Generated at 2022-06-23 04:47:56.022175
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert isinstance(jd, AnsibleJSONDecoder)


# Generated at 2022-06-23 04:48:04.037677
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = '$ANSIBLE_VAULT;1.1;AES256\n66393566623963316463323237326337366363630663335653831633735663313431323330633662333\n363163306238316462633762663238656637353437306532303837376636323031633032393863643135\n373066373533313231323066333531313261303362333435366534643263646130656462616434303338\n353466333664666461313066343265356166663364313038643433626632382e000a'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    json_str

# Generated at 2022-06-23 04:48:15.179767
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = AnsibleJSONDecoder.set_secrets({"default" : "testvaultpassword"})


# Generated at 2022-06-23 04:48:17.668212
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None
    assert decoder.object_hook is decoder.object_hook

# Generated at 2022-06-23 04:48:21.422771
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = ['1234567890']
    AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secret

# Load_json test is in test_helper_module.py

# Generated at 2022-06-23 04:48:32.784276
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['supersecret']

    # test with always unsafe __ansible_unsafe
    insecure_dict = {"__ansible_unsafe": "always unsafe"}
    json_dict = json.dumps(insecure_dict, cls=AnsibleJSONEncoder)
    decoded_json = json.loads(json_dict, cls=AnsibleJSONDecoder)
    assert decoded_json == insecure_dict

    # test with vaulted __ansible_vault
    vaulted_str = "vaulted str"

# Generated at 2022-06-23 04:48:44.623045
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    def test_vault_1(pairs):
        assert pairs['__ansible_vault'].vault is decoder._vaults['default']

# Generated at 2022-06-23 04:48:49.492863
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder._vaults == {}
    assert AnsibleJSONDecoder.set_secrets(secrets="new_secrets") is None
    assert AnsibleJSONDecoder._vaults == {'default': VaultLib(secrets='new_secrets')}



# Generated at 2022-06-23 04:49:01.017944
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder._vaults == {}, "ansible_json_decoder._vaults"
    ansible_json_decoder = AnsibleJSONDecoder("test_secret")
    assert ansible_json_decoder._vaults == {}, "ansible_json_decoder._vaults"
    ansible_json_decoder = AnsibleJSONDecoder("test_secret", "object_hook")
    assert ansible_json_decoder._vaults == {}, "ansible_json_decoder._vaults"
    ansible_json_decoder = AnsibleJSONDecoder("test_secret", "object_hook", "json_object_hook")

# Generated at 2022-06-23 04:49:11.713557
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:21.532917
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest


# Generated at 2022-06-23 04:49:31.745957
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n' + \
    '6336333761333132313366323430643265613861623339623335616366353064663961663137\n' + \
    '39366438323931303362386331633734643334633262630a6632613566643331353339316435\n' + \
    '6134623831333236356634303839383437623438373735363138393937363363353034357d39\n' + \
    '62343930653034373534363d0a\n'
    obj = AnsibleJSONDecoder.object_hook({'__ansible_vault': secret})
    assert obj._text

# Generated at 2022-06-23 04:49:35.316507
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """This is a autogenerated test to verify that the constructor
    of the class AnsibleJSONDecoder is working as expected.

    """

    # Testing the constructor
    decoder = AnsibleJSONDecoder()



# Generated at 2022-06-23 04:49:37.624403
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:49:50.073897
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    obj = decoder.decode('{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;test\r\n666\r\n"}')
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj == '$ANSIBLE_VAULT;1.1;AES256;test\r\n666\r\n'

    obj = decoder.decode('{"__ansible_unsafe": {"__ansible_module_name": "copy", "__ansible_module_args": {"dest": "/etc/hosts", "content": "$ANSIBLE_VAULT;1.1;AES256;test\r\n666\r\n"}, "__ansible_arguments": []}}')

# Generated at 2022-06-23 04:49:52.723422
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Assume the method called the constructor of class AnsibleJSONDecoder
    assert getattr(AnsibleJSONDecoder, '__init__')

# Generated at 2022-06-23 04:49:55.063818
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    x = AnsibleJSONDecoder()
    assert x
    assert isinstance(x, json.JSONDecoder)


# Generated at 2022-06-23 04:49:55.749491
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:49:58.303870
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Unit test for constructor of class AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook
    assert hasattr(decoder, '_vaults')

# Generated at 2022-06-23 04:50:07.088823
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'hello'