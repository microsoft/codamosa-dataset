

# Generated at 2022-06-23 04:40:02.730541
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    j = '''
    {"foo": "bar"}
    '''

    ansible_json = AnsibleJSONDecoder()
    obj = ansible_json.decode(j)

    assert isinstance(obj, dict)
    assert obj['foo'] == 'bar'

# Generated at 2022-06-23 04:40:05.524694
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder({'__ansible_vault': 'google.com'}).object_hook(
        {'__ansible_vault': 'google.com'}) == AnsibleVaultEncryptedUnicode('google.com')

# Generated at 2022-06-23 04:40:17.276086
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    def assert_pairs_returned(pairs, expected):
        assert decoder.object_hook(pairs) == expected

    assert_pairs_returned({}, {})

    assert_pairs_returned(
        {'__ansible_vault': 'baz'},
        AnsibleVaultEncryptedUnicode('baz')
    )
    v = AnonVault()
    AnsibleJSONDecoder._vaults['default'] = v
    assert_pairs_returned(
        {'__ansible_vault': 'baz'},
        AnsibleVaultEncryptedUnicode('baz')
    )
    assert AnsibleJSONDecoder._vaults['default'] == v

# Generated at 2022-06-23 04:40:28.378949
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class Foo():
        def __init__(self, pairs):
            for key, value in pairs.items():
                if key == '__ansible_vault':
                    self.__ansible_vault = value
                elif key == '__ansible_unsafe':
                    self.__ansible_unsafe = value
                else:
                    setattr(self, key, value)

        def __repr__(self):
            return '{}({!r})'.format(self.__class__.__name__, self.__dict__)

    my_decoder = AnsibleJSONDecoder(object_hook=Foo)
    s = '{"__ansible_vault":"xyz"}'
    out = my_decoder.decode(s)
    assert isinstance(out, Foo)
    assert out.__ans

# Generated at 2022-06-23 04:40:38.455433
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\nblahblahblah\nblahblahblah\nblahblahblah\n","__ansible_unsafe": {"__ansible_unsafe": True}}'
    res = AnsibleJSONDecoder().decode(s)
    assert isinstance(res['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(res['__ansible_unsafe'], dict)
    assert isinstance(res['__ansible_unsafe']['__ansible_unsafe'], wrap_var)


# Generated at 2022-06-23 04:40:47.486912
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Arrange
    secret = "devops"
    enc_raw = vault_encode(secret, "devops")
    unsafe_str = "abc? <p>&</p>"
    unsafe_enc_str = "!unsafe " + unsafe_str

    raw_json = '{ "__ansible_vault": "' + enc_raw + '", ' \
               '"__ansible_unsafe": "' + unsafe_enc_str + '" }'
    json_obj = json.loads(raw_json, cls=AnsibleJSONDecoder)

    # Assert
    assert isinstance(json_obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_obj['__ansible_unsafe'], AnsibleUnsafeText)

# Generated at 2022-06-23 04:40:56.826332
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:04.244297
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    _base_data = {
        "__ansible_vault": "VGFkZGxleQ==",
        "__ansible_unsafe": {"foo": "bar"},
        "baz": "boo"
    }

    # vault is none
    our_decoder = AnsibleJSONDecoder()
    decoded_data = our_decoder.decode(json.dumps(_base_data))

    assert(isinstance(decoded_data['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(decoded_data['__ansible_vault'].vault is None)
    assert(decoded_data['__ansible_unsafe'] == wrap_var(_base_data['__ansible_unsafe']))

# Generated at 2022-06-23 04:41:17.502786
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    def test_object_hook(pairs):

        assert pairs == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\r\n'}, 'invalid pairs'

        return AnsibleVaultEncryptedUnicode(pairs['__ansible_vault'])

    decoder = AnsibleJSONDecoder(object_hook=test_object_hook)

    # Test json decoder object_hook
    decoded = decoder.decode('{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\\r\\n"}')
    assert decoded == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\r\n'), 'invalid decoded'

    # Test class method object_hook
    decoded

# Generated at 2022-06-23 04:41:30.018482
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test for AnsibleVaultEncryptedUnicode
    data = '''{
        "__ansible_vault": "MY_VAULT_SECRET"
    }'''
    secret = 'secret'
    data_decoded = json.loads(data, cls=AnsibleJSONDecoder)

    if 'default' not in AnsibleJSONDecoder._vaults:
        AnsibleJSONDecoder.set_secrets(secret)

    if not isinstance(data_decoded, dict):
        module.fail_json(msg='JSON decoded data is not dict')

# Generated at 2022-06-23 04:41:41.654980
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    json_text = '''{ "key1": "value1", "key2": "value2", "key3": "value3", "key4": "value4" }'''
    json_text_vault = '''{ "key1": "value1", "key2": "value2", "key3": "value3", "key4": { "__ansible_vault": "value4" } }'''

# Generated at 2022-06-23 04:41:53.228753
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:04.973682
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'secret'
    secrets = secrets.encode()
    AnsibleJSONDecoder._vaults = {}
    obj = AnsibleJSONDecoder()
    data = dict(__ansible_vault=secrets)
    assert obj.object_hook(data) == dict(__ansible_vault=AnsibleVaultEncryptedUnicode(secrets))
    assert obj.object_hook(dict(__ansible_unsafe=secrets)) == dict(__ansible_unsafe=wrap_var(secrets))
    AnsibleJSONDecoder.set_secrets(secrets)
    assert obj.object_hook(data) == dict(__ansible_vault=AnsibleVaultEncryptedUnicode(secrets))

# Generated at 2022-06-23 04:42:15.704168
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = {'ansible_vault': 'xxxx', '__ansible_unsafe': 'yyyy'}
    json_data_copy = {'ansible_vault': 'xxxx', '__ansible_unsafe': 'yyyy'}
    json_data_copy.update({'__ansible_vault': 'xxxx'})
    json_data_copy.update({'__ansible_unsafe': wrap_var('yyyy')})
    assert AnsibleJSONDecoder().object_hook(json_data) == json_data_copy

# Generated at 2022-06-23 04:42:25.120922
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-23 04:42:28.221849
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # This test should pass
    d = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:42:39.472829
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # include the secret to decode the vault string
    secrets = ['secret']
    # set the secret for class AnsibleJSONDecoder
    AnsibleJSONDecoder.set_secrets(secrets)
    # define the vault string to be decoded
    json_str = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n3534643333376234643065386336313465363339613039363932626665613765303338316465346562\n3934623031623636663836396634353763636262666339353038306333653064613837633539393430\n3532306534373937356534323035323339623235373065\n"}'
    json_object = json.loads

# Generated at 2022-06-23 04:42:41.218845
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder(object_hook=None)

# Generated at 2022-06-23 04:42:50.510572
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Create test_data
    test_data = {"a": 1, "b": 2}
    # Check that json.dumps(test_data, cls=AnsibleJSONEncoder) == test_data
    assert json.dumps(test_data, cls=AnsibleJSONEncoder) == json.dumps(test_data)
    # Check that json.dumps(test_data, cls=AnsibleJSONEncoder) == test_data
    assert json.loads(json.dumps(test_data, cls=AnsibleJSONEncoder)) == json.loads(json.dumps(test_data))
    # Check that json.dumps(test_data, cls=AnsibleJSONEncoder) == test_data

# Generated at 2022-06-23 04:42:51.713289
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-23 04:43:04.067127
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json

    class DummySecrets(object):
        def __init__(self):
            pass

        def decrypt(self, value):
            return value

    vault_list = ['$ANSIBLE_VAULT;1.2;AES256;test\n',
                  '3835333632656666323663373933646430346436353664643064636239633566623933356466393b',
                  '6566393065343033636333630646565353663666134633962363934383930376434353137316331\n']
    vault_bytes = b''.join([x.encode('utf-8') for x in vault_list])
    vault_data = vault_bytes.decode('utf-8')
    encoder = AnsibleJSONEncoder

# Generated at 2022-06-23 04:43:12.150299
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:43:23.754591
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n......\n'}
    vault_value = AnsibleJSONDecoder().object_hook(vault_data)
    assert type(vault_value) == dict
    assert vault_value['__ansible_vault'].vault == None

    unsafe_data = {'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256\n......\n'}
    unsafe_value = AnsibleJSONDecoder().object_hook(unsafe_data)
    assert type(unsafe_value) == dict
    assert unsafe_value['__ansible_unsafe'] == '$ANSIBLE_VAULT;1.1;AES256\n......\n'

# Generated at 2022-06-23 04:43:35.852976
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:37.618173
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets("")
    assert decoder is not None

# Generated at 2022-06-23 04:43:48.197707
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = "abcd"
    secrets_tuple = (secrets,)

    AnsibleJSONDecoder.set_secrets(secrets_tuple)
    assert secrets_tuple == AnsibleJSONDecoder._vaults['default'].secrets


# Generated at 2022-06-23 04:43:59.986886
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Check object_hook from base JSONDecoder is called
    class TestDecoder(AnsibleJSONDecoder):
        def object_hook(self, pairs):
            return 'Hello world'

    # Test with default constructor
    decoder = TestDecoder()
    assert decoder.decode('[{"a": "b"}]') == 'Hello world'

    # Test with custom object_hook
    decoder = TestDecoder(object_hook=lambda pairs: 'foobar')
    assert decoder.decode('[{"a": "b"}]') == 'foobar'

    # Test with custom object_hook and default object_hook
    decoder = TestDecoder(object_hook=lambda pairs: 'foobar')
    assert decoder.decode('[{"a": "b"}]') == 'foobar'


# Generated at 2022-06-23 04:44:02.181567
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert json.loads('{"foo": "bar"}', cls=AnsibleJSONDecoder) == {'foo': 'bar'}

# Generated at 2022-06-23 04:44:07.118694
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # tests.unit.parsing.vault_test.VaultLibTestCase.test_decrypt_dict_1
    secrets = ['foo']
    obj = AnsibleJSONDecoder()
    obj.set_secrets(secrets)
    # check if vault is properly set
    # if it is set, then the set_secrets(secrets)
    # should be called in the constructor
    assert obj._vaults['default'].secrets == secrets

# Generated at 2022-06-23 04:44:11.351870
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    value = '$ANSIBLE_VAULT;1.1;AES256\n3462354652354'
    decoded_value = AnsibleJSONDecoder().object_hook({'__ansible_vault': value})

    assert decoded_value == AnsibleVaultEncryptedUnicode(value)


# Generated at 2022-06-23 04:44:14.568727
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder(object_hook=None)



# Generated at 2022-06-23 04:44:22.829560
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    if __name__ == '__main__':
        decoder = AnsibleJSONDecoder()
        json_str = '{"__ansible_vault": "my__ansible_vault", "__ansible_unsafe": "my__ansible_unsafe"}'
        result = decoder.decode(json_str)
        assert '__ansible_vault' and '__ansible_unsafe' in result
        assert result['__ansible_vault'] == 'my__ansible_vault'
        assert result['__ansible_unsafe'] == 'my__ansible_unsafe'


# Generated at 2022-06-23 04:44:34.623719
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = dict(vault_password='VaultPassword')
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:44:45.481701
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;dummy_id\n'
                               '32323223323232323232323232323232323232323232323232323232323232323\n'
                               '7878787888888888888888888888888888888888888888888888888888888888\n'
                               '==\n'}

    decoded = AnsibleJSONDecoder().decode(json.dumps(data))
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:44:57.288270
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Verify that the default values are set
    # when no arguments are specified in the constructor
    d = AnsibleJSONDecoder()
    assert d.object_hook is AnsibleJSONDecoder.object_hook
    assert d.parse_float is json.JSONDecoder.parse_float
    assert d.parse_int is json.JSONDecoder.parse_int
    assert d.parse_constant is json.JSONDecoder.parse_constant
    assert d.strict is json.JSONDecoder.strict
    assert d.object_pairs_hook is json.JSONDecoder.object_pairs_hook

    # Verify that the object_hook is set to object_hook
    # when the object_hook argument is specified in the constructor

# Generated at 2022-06-23 04:45:01.929459
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;blah'}) == {'__ansible_vault': AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;blah')}

# Generated at 2022-06-23 04:45:17.122542
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class AnsibleJSONDecoderMock(AnsibleJSONDecoder):

        def __init__(self, *args, **kwargs):
            self.pairs = dict()
            super(AnsibleJSONDecoderMock, self).__init__(*args, **kwargs)

        def object_hook(self, pairs):
            self.pairs = pairs
            return super(AnsibleJSONDecoderMock, self).object_hook(pairs)

    vault_string = '$ANSIBLE_VAULT;1.1;AES256\n3861393635393037626438656166613838336630646264623134' \
                   '39383634333033326131383533623039613563396232366338630a3362656566333839343536346638'

# Generated at 2022-06-23 04:45:29.748337
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    foo = {"__ansible_vault": "foo"}
    f = open('./vault.txt', 'w')
    f.write('hello')
    f.close()
    json.dumps(foo, cls=AnsibleJSONEncoder)
    secret = [{'vault_id': 'default', 'password_files': ['./vault.txt'], 'vault_password_files': [], 'new_vault_password_file': None}]
    AnsibleJSONDecoder.set_secrets(secret)
    assert(json.loads(json.dumps(foo, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder)['__ansible_vault'] == foo['__ansible_vault'])

# Generated at 2022-06-23 04:45:32.196539
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:45:35.626593
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ["123"]
    decoder = AnsibleJSONDecoder
    decoder.set_secrets(secrets)
    assert decoder._vaults['default'] == VaultLib(secrets=secrets)
# Test the method object_hook of the class AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:40.100766
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    decoder = AnsibleJSONDecoder
    obj_dict = {}
    encoder = json.JSONEncoder

    assert isinstance(decoder, object)
    assert isinstance(obj_dict, dict)
    assert isinstance(encoder, object)


# Generated at 2022-06-23 04:45:40.976463
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:45:53.711284
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = {
        'my_value': 'my_string',
        '__ansible_unsafe': 'data',
        '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;this_is_not_real_data\n396164623364636134633932326536386131346533622d326435353164623962610a323238316539363035383332323562633139'
    }
    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(json.dumps(data))

    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['__ansible_unsafe'], str)

# Generated at 2022-06-23 04:45:57.286868
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Assert that a new instance of AnsibleJSONDecoder class is created
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)


# Generated at 2022-06-23 04:46:06.829745
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [
        '6e2$gs7Y8Kv/uR+%cI9g1W2e8m5C5m7+cyG3q3b7Ca1A5p5a6c0A9d1Q2h8v0uA7',
        'e123C7b8H5v5f7V4c9B4p7V8z4i4j7V5w5f5S7V8z4i4j7V5w5f5S7V8z4i4j7V5w'
    ]

    ad = AnsibleJSONDecoder
    ad.set_secrets(secrets)


# Generated at 2022-06-23 04:46:11.426883
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret_text = "secret text"
    encoded_value = 'U2FsdGVkX19N6c12U5O5X5x/B/JLdzK5/J/ZRwznZhI='
    json_encoder = AnsibleJSO

# Generated at 2022-06-23 04:46:23.221157
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_data_1 = {
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n3235316531393437626535613036363363383262643431376162353338636161373834383266630a356635623166663239386633336539336331663534393432336238316239623636626663360a31623133363366623333356365393334636239393638616462386332396331626265663061360a64383532363737346639383862613936393864346461656233336764393864643533306465\n",
    }

# Generated at 2022-06-23 04:46:35.160522
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:46:45.097066
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # from ansible.parsing.vault import VaultLib
    # from ansible.utils.unsafe_proxy import wrap_var

    vault_id = 'default'
    vault_pass = 'vault_pass'
    secret = 'mysecret'

    decoder = AnsibleJSONDecoder()

    def assert_object_hook(pairs, expected):
        assert expected == decoder.object_hook(pairs)

    # key '__ansible_vault'
    assert_object_hook({
        '__ansible_vault': secret,
    }, AnsibleVaultEncryptedUnicode(secret))

    # key '__ansible_unsafe'
    credentials = dict(
        login='user',
        password='p@ssw0rd'
    )


# Generated at 2022-06-23 04:46:55.660584
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dicts = dict()
    obj = AnsibleJSONDecoder()
    # Call object_hook
    with open('/tmp/test_AnsibleJSONDecoder_object_hook.json', 'r') as t_file:
        for line in t_file:
            json_data = json.loads(line, cls=obj)
        # print(json_data)
        # print(json_data['name'].data)
        # print(json_data['__ansible_vault'].vault.decrypt(json_data['__ansible_vault'].data))
        # print(json_data['__ansible_unsafe'].data)
        # print(json_data['__ansible_unsafe'].value)
        dicts['name'] = json_data['name'].data

# Generated at 2022-06-23 04:47:06.754381
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_text = '''{
      "foo": "bar",
      "baz": {
        "__ansible_unsafe": "{{lookup('pipe', 'whoami')}}",
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n"
      }
    }'''
    decoded_data = AnsibleJSONDecoder().decode(json_text)
    assert decoded_data['foo'] == 'bar'
    assert decoded_data['baz']['__ansible_vault'] is not None
    assert decoded_data['baz']['__ansible_unsafe'] is not None
    assert decoded_data['baz']['__ansible_vault'] != decoded_data['baz']['__ansible_unsafe']

# Generated at 2022-06-23 04:47:09.057102
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert issubclass(AnsibleJSONDecoder, json.JSONDecoder)


# Generated at 2022-06-23 04:47:18.944718
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class MockVaultLib(object):
        def __init__(self):
            self.secrets = {}

    decoder = AnsibleJSONDecoder()
    vault_lib = MockVaultLib()
    decoder.set_secrets(vault_lib.secrets)

    pairs = {}
    secret = '$ANSIBLE_VAULT;1.2;AES256;user;1234\n654321\n'
    pairs['__ansible_vault'] = secret
    ret = decoder.object_hook(pairs)
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)

    pairs = {}
    unsafe = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;user;1234\n654321\n')

# Generated at 2022-06-23 04:47:28.647013
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    json_str_1 = '{"__ansible_vault": "my encrypted string"}'
    json_str_2 = '{"__ansible_unsafe": "my unsafe string"}'

    decoder = AnsibleJSONDecoder()
    decoded_json_1 = decoder.decode(json_str_1)
    decoded_json_2 = decoder.decode(json_str_2)

    assert decoded_json_1["__ansible_vault"] == 'my encrypted string'
    assert decoded_json_1["__ansible_vault"].vault.secrets is None
    assert decoded_json_2["__ansible_unsafe"] == 'my unsafe string'

# Generated at 2022-06-23 04:47:36.863471
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    json_data = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    json.dumps(json_data)

    s = '[{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}]'

    obj = json.loads(s)
    assert len(obj) == 1

    assert obj[0].get('a') == 1
    assert obj[0].get('b') == 2
    assert obj[0].get('c') == 3
    assert obj[0].get('d') == 4
    assert obj[0].get('e') == 5



# Generated at 2022-06-23 04:47:40.121613
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['test_secret']
    decoder = AnsibleJSONDecoder()
    assert 'default' not in decoder._vaults
    AnsibleJSONDecoder.set_secrets(secrets)
    assert decoder._vaults['default'] == VaultLib(secrets=secrets)



# Generated at 2022-06-23 04:47:42.418080
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder

# Generated at 2022-06-23 04:47:46.489265
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder

    cls._vaults = {}
    assert not cls._vaults

    cls._vaults = {'default': VaultLib(secrets={})}
    assert cls._vaults

    cls._vaults = {}

# Generated at 2022-06-23 04:47:54.882666
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:58.461660
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:48:08.117057
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    secrets = ['secret1']
    vault = VaultLib(secrets=secrets)

    # Case: Vault found
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n61316162313861333538633863666366306234646537356438373339656337310a326637336230643635336431323133366635336234383934643765366239630a6434386564346332663935663837623663323164646232646466393864383633\n'}
    result = AnsibleJSONDecoder.object_hook(pairs)

# Generated at 2022-06-23 04:48:14.961972
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for valid vault key
    obj = decoder.object_hook({'__ansible_vault': 'foo'})
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault is None
    assert obj.vault_secret is None

    # Test for multiple valid vault keys
    obj = decoder.object_hook({'__ansible_vault': 'foo', '__ansible_vault_secret': 'bar'})
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault is None
    assert obj.vault_secret is None

    # Test for valid unsafe key
    obj = decoder.object_hook({'__ansible_unsafe': 'foo'})

# Generated at 2022-06-23 04:48:24.745591
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'ansible'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    test_str = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;bbbbbbbbbbbbbbbbbbbbbbbb\nbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\nbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb8=\n"}'
    test_dict = json.loads(test_str, cls=AnsibleJSONDecoder)
    assert test_dict['__ansible_vault'] == 'ansible'

# Generated at 2022-06-23 04:48:25.676430
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-23 04:48:26.676983
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:48:37.944860
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # GIVEN constructor of class AnsibleJSONDecoder
    ansible_json_decoder_obj = AnsibleJSONDecoder()

    # WHEN object hook function is called
    data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;abcdefghijklmnopqrstuvwxyz123456000'}
    ansible_json_decoder_obj.object_hook(data)

    # THEN AnsibleVaultEncryptedUnicode class object is returned
    assert isinstance(data.get('__ansible_vault')) is True

    # GIVEN constructor of class AnsibleJSONDecoder
    ansible_json_decoder_obj = AnsibleJSONDecoder()

    # WHEN object hook function is called

# Generated at 2022-06-23 04:48:43.574858
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '{"__ansible_vault" : "dGVzdA==", "__ansible_unsafe": "dGVzdA=="}'
    assert(json.loads(json_data, cls=AnsibleJSONDecoder) == {u'__ansible_vault': u'test', u'__ansible_unsafe': u'test'})


# Generated at 2022-06-23 04:48:54.248746
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    my_data = dict(
        ['a'],
        __ansible_vault=dict(
            ['b']
        ),
        __ansible_unsafe=dict(
            ['c']
        )
    )
    # Test AnsibleJSONDecoder's constructor
    data = json.loads(json.dumps(my_data), cls=AnsibleJSONDecoder)
    assert data['a']['__ansible_vault']['b'].startswith('$ANSIBLE_VAULT')
    assert type(data['a']['__ansible_vault']['b']) is AnsibleVaultEncryptedUnicode
    assert data['a']['__ansible_unsafe']['c'] == u'c'

# Generated at 2022-06-23 04:49:02.734046
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_dict = {
        "__ansible_unsafe": "ansible_unsafe_test",
        "__ansible_vault": "ansible_vault_test"
    }

    decoder = AnsibleJSONDecoder()
    decoded_dict = decoder.object_hook(test_dict)

    assert '__ansible_unsafe' in decoded_dict
    assert '__ansible_vault' in decoded_dict
    assert '__ansible_unsafe' not in test_dict
    assert '__ansible_vault' not in test_dict

    assert decoded_dict['__ansible_vault'].vault is None

# Generated at 2022-06-23 04:49:11.776235
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '{"__ansible_vault": "something_encrypted", "__ansible_unsafe": "something_unsafe"}'

    decoder = AnsibleJSONDecoder()

    decoded_data = decoder.decode(json_data)

    assert isinstance(decoded_data["__ansible_vault"], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded_data["__ansible_unsafe"], wrap_var)
    assert decoded_data["__ansible_vault"].vault is None
    assert decoded_data["__ansible_unsafe"].value == "something_unsafe"

# Generated at 2022-06-23 04:49:13.571076
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook
    assert not AnsibleJSONDecoder._vaults

# Generated at 2022-06-23 04:49:16.811923
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert(jd)

# Generated at 2022-06-23 04:49:28.194174
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import sys
    import os

    # Set ansible vault password
    vault_password = 'password123'
    vault_string = '$ANSIBLE_VAULT;1.1;AES256\n6133643965363431346165663435306639393566316262623265363163653766613463623936652\na135613233376566383738663935333737366236613736653832303637363738616465306131633\n633338616365616234306336643834643763633163633234333865363639353064663235623938\n3139366238323435306437613862323038'
    vault_json = '{"__ansible_vault": "' + vault_

# Generated at 2022-06-23 04:49:39.332484
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-23 04:49:49.248686
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    data = """
    {
      "foo": "bar",
      "__ansible_vault": "foo",
      "__ansible_unsafe": "foo"
    }
    """

    # create an instance of AnsibleJSONDecoder class
    a_json_decoder = AnsibleJSONDecoder()

    # set the vault
    a_json_decoder.set_secrets('default')

    # decode the data
    json_data = json.loads(data, cls=AnsibleJSONDecoder, parse_int=None, parse_constant=None, object_pairs_hook=None)

    # test the result
    assert json_data['__ansible_vault'] == "foo"

# Generated at 2022-06-23 04:49:55.542878
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # vault is depracted at 2.10 release. it should be removed in Ansible 2.11
    assert isinstance(json.loads('{"__ansible_vault": "foo"}', cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)

    assert isinstance(json.loads('{"__ansible_unsafe": "foo"}', cls=AnsibleJSONDecoder), wrap_var)

# Generated at 2022-06-23 04:50:04.312789
# Unit test for method object_hook of class AnsibleJSONDecoder