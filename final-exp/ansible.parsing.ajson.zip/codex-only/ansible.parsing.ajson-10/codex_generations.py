

# Generated at 2022-06-23 04:40:08.891605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'dummy secret'
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(secrets)
    pairs = {
        '__ansible_vault': 'vault value',
        '__ansible_unsafe': 'unsafe value',
        'regular' : 'regular value'
    }
    pairs_values = pairs.values()
    object_hook_value = ansible_json_decoder.object_hook(pairs)
    assert object_hook_value.__class__.__name__ == 'dict'
    assert object_hook_value['__ansible_unsafe'] == 'unsafe value'
    assert object_hook_value['regular'] == 'regular value'
    assert object_hook_value['__ansible_vault'].__

# Generated at 2022-06-23 04:40:18.068025
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    Test the AnsibleJSONDecoder object_hook method
    '''
    encoder = AnsibleJSONEncoder()
    encoded_string = encoder.encode(wrap_var({'password': 'ANANSIBLEPASSWORD'}))
    assert encoded_string == '{"__ansible_unsafe": "eyAicGFzc3dvcmQiOiAiQU5BTlNJQkxFUEFTU1dPUkQiIH0="}'
    decoder = AnsibleJSONDecoder()
    decoded_string = decoder.decode(encoded_string)
    assert decoded_string == {'password': 'ANANSIBLEPASSWORD'}

# Generated at 2022-06-23 04:40:29.218655
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {'vault_password': 'test'}
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert isinstance(decoder, type)

    # Object is decrypted

# Generated at 2022-06-23 04:40:40.233228
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.module_utils.six import binary_type

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['vaultpassword'])

    # ansible_vault

# Generated at 2022-06-23 04:40:47.489899
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Constructor without Argument
    ansiblejson_decoder = AnsibleJSONDecoder()
    assert 'default' not in ansiblejson_decoder._vaults
    assert '__ansible_vault' in ansiblejson_decoder.object_hook({'__ansible_vault': 'abc'})
    assert 'abc' in ansiblejson_decoder.object_hook({'__ansible_vault': 'abc'})['__ansible_vault']
    assert '__ansible_unsafe' in ansiblejson_decoder.object_hook({'__ansible_unsafe': 'abc'})
    assert 'abc' in ansiblejson_decoder.object_hook({'__ansible_unsafe': 'abc'})['__ansible_unsafe']

    # Constructor with Argument
    ansiblejson_decoder

# Generated at 2022-06-23 04:40:56.825871
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    This is a unit test for checking the object_hook method of class
    AnsibleJSONDecoder.
    :return:
    """
    unsafe = 'test_unsafe'
    vault = 'test_vault'

    data = {"__ansible_unsafe": unsafe}
    decoded_data = json.loads(json.dumps(data), cls=AnsibleJSONDecoder)
    assert decoded_data['__ansible_unsafe'].value == unsafe
    assert decoded_data['__ansible_unsafe'] == unsafe

    data = {"__ansible_vault": vault}
    decoded_data = json.loads(json.dumps(data), cls=AnsibleJSONDecoder)
    assert decoded_data['__ansible_vault'] == vault



# Generated at 2022-06-23 04:41:03.249908
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_str = '{"__ansible_vault": "AQAAR1YRXm0CXl9jybYUm0F6Og34Pq3w"}'
    expected = {'__ansible_vault': 'AQAAR1YRXm0CXl9jybYUm0F6Og34Pq3w'}

    # pylint: disable=protected-access
    decoder = AnsibleJSONDecoder()
    res = decoder.decode(json_str)
    assert res == expected
    assert isinstance(res['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:41:15.566428
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets('foo')

    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode('{"__ansible_vault": "bar"}')
    assert decoded == {'__ansible_vault': 'bar'}
    assert decoder._vaults['default'] is decoded['__ansible_vault'].vault

    decoded = decoder.decode('{"__ansible_unsafe": "baz"}')
    assert decoded == {'__ansible_unsafe': b'baz'}

    decoded = decoder.decode('{"__ansible_vault": "bar", "__ansible_unsafe": "baz"}')

# Generated at 2022-06-23 04:41:19.747500
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'test_secret'
    secret_json = json.dumps({'test_secret': 'foo'}, cls=AnsibleJSONEncoder)
    secret_vault_json = json.dumps({'__ansible_vault': secret_json}, cls=AnsibleJSONEncoder)

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets=[secret])

    assert decoder.decode(secret_vault_json) == {'__ansible_vault': secret_json}



# Generated at 2022-06-23 04:41:30.119260
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    expected_value = dict(__ansible_vault='9d50b24e-29c5-41af-a2a8-d1daa5e5a', __ansible_unsafe=dict(name='value'))
    json_data = json.dumps(expected_value, cls=AnsibleJSONEncoder)
    actual_value = json.loads(json_data, cls=AnsibleJSONDecoder)
    assert actual_value['__ansible_vault'] == expected_value['__ansible_vault']
    assert actual_value['__ansible_unsafe'] == expected_value['__ansible_unsafe']

# Generated at 2022-06-23 04:41:38.272349
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES2562829c42f9e27eec2943bfe88db0013c1b8fe04c399364b99d7b93fcea1a8c6e70'}
    data = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES2562829c42f9e27eec2943bfe88db0013c1b8fe04c399364b99d7b93fcea1a8c6e70"}'
    assert AnsibleJSONDecoder().object_hook(ansible_vault) == json.loads(data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-23 04:41:50.609619
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Testing __ansible_vault
    s = '{"__ansible_vault": "9DYHJ6+aUwWamuV7z+kE17bVBHiJH6vv+ZVdhX9Y3YqHJcGw+Sm5IF5g5+E3qMdj"}'
    res = json.loads(s, cls=AnsibleJSONDecoder, parse_int=None, parse_float=None, parse_constant=None, object_hook=None, object_pairs_hook=None, **{})
    assert type(res) == AnsibleVaultEncryptedUnicode

    # Testing __ansible_unsafe
    s = '{"__ansible_unsafe": "something"}'

# Generated at 2022-06-23 04:41:57.631575
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_key = '$ANSIBLE_VAULT;1.1;AES256'
    vault_data = 'testvaultdata'
    vd = vault_key + '\n' + vault_data
    jd = '{"__ansible_vault":"{}"}'.format(vd)
    check = json.loads(jd, cls=AnsibleJSONDecoder)
    assert check == {'__ansible_vault': AnsibleVaultEncryptedUnicode(vd)}

    secret_vault_key = '$ANSIBLE_VAULT;1.1;AES256;CIPHER|ANSIBLE_VAULT'
    secret_vault_data = 'testsecretvaultdata'
    svd = secret_vault_key + '\n' + secret_vault_data

# Generated at 2022-06-23 04:42:13.521577
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from unittest import TestCase
    import json

    class FakeVault(object):
        pass

    class FakeVaultLib(object):
        def __init__(self, *args, **kwargs):
            self._vault = FakeVault()

    class MyTestCase(TestCase):
        def setUp(self):
            self.vault = FakeVaultLib()
            AnsibleJSONDecoder.set_secrets(secrets=None)


# Generated at 2022-06-23 04:42:24.230410
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    Json_string = """
    {
        "test": "some string",
        "__ansible_vault": "b2JieQAANl9tYWNoaW5lLnB5Bgkx",
        "test2": "other string",
        "__ansible_unsafe": "some unsafe string"
    }
    """

    # Without set_secrets()
    Adec = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    AnsibleJSONDecoder.set_secrets(["this_is_a_secret"])

    ansible_vault_obj = Adec.decode(Json_string)["__ansible_vault"]

# Generated at 2022-06-23 04:42:37.973634
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    J = AnsibleJSONDecoder()

    # Check whether '__ansible_unsafe' is correctly handled.
    assert J.object_hook({'__ansible_unsafe': {'private': 'foo'}}) == wrap_var({'private': 'foo'})

    # Check whether the returned object is correctly handled by the default unicode_rep=ascii

# Generated at 2022-06-23 04:42:44.289240
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_data = {"password": "secret", "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n393065643734363334353337666136636361323266303230316465373230303562326537353332\n653835643633323662383065643534393232643038643565656333373162626239303135303264\n313536663434623866643065366232363238393337396231656334333038316334616333393466\n3666353663\n"}

    json.dumps(json.loads(json.dumps(test_data), cls=AnsibleJSONDecoder), cls=AnsibleJSONEncoder)

# Generated at 2022-06-23 04:42:53.795953
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['test'])

    # test a AnsibleVaultEncryptedUnicode object
    # that represent a encrypted text

# Generated at 2022-06-23 04:42:59.966744
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook == decoder.object_hook
    assert decoder.decode('{"__ansible_unsafe": {"__ansible_module_version": 2}}') == {"__ansible_unsafe": wrap_var({"__ansible_module_version": 2})}


# Generated at 2022-06-23 04:43:08.298332
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    input_str = '''
{
    "__ansible_vault": "myEncryptedValue",
    "__ansible_unsafe": {"a": "abc", "b": "def"}
}
'''
    secrets = [{'id': 'default', 'password': 'secret'}]
    AnsibleJSONDecoder.set_secrets(secrets)

    result = AnsibleJSONDecoder().decode(input_str)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(result['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-23 04:43:14.604308
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    fake_secrets = ['passw0rd']

    try:
        # Very simple initialization
        AnsibleJSONDecoder()

        # Initialization with secrets used to decrypt Ansible Vault sensitive data
        AnsibleJSONDecoder.set_secrets(fake_secrets)
        AnsibleJSONDecoder()
    except Exception:
        assert False, 'AnsibleJSONDecoder could not be initialized'

# Generated at 2022-06-23 04:43:20.390307
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    json_encoder = AnsibleJSONEncoder()
    json_decoder = AnsibleJSONDecoder()

    x = AnsibleVaultEncryptedUnicode('test')
    y = json.loads(json_encoder.encode(x), cls=json_decoder)
    assert isinstance(y, AnsibleVaultEncryptedUnicode)
    assert y.vault

# Generated at 2022-06-23 04:43:32.546779
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    test_secrets = ['somepassword']
    AnsibleJSONDecoder.set_secrets(test_secrets)

    # Test basic usage of the object_hook method
    test_input = {
        'a': 'A',
        'b': 'B',
        'c': 'C',
        '__ansible_unsafe': 'unsafe',
        '__ansible_vault': '1234'
    }
    expected = {
        'a': 'A',
        'b': 'B',
        'c': 'C',
        '__ansible_unsafe': wrap_var('unsafe'),
        '__ansible_vault': AnsibleVaultEncryptedUnicode('1234')
    }

# Generated at 2022-06-23 04:43:35.231282
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder, object)


# Generated at 2022-06-23 04:43:46.799263
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:43:57.903515
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:02.628754
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    decoder2 = AnsibleJSONDecoder()
    assert decoder2._vaults == {}
    decoder.set_secrets(['test'])
    assert decoder._vaults != {}
    assert decoder2._vaults != {}

# Generated at 2022-06-23 04:44:10.030563
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:11.018027
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder.__init__

# Generated at 2022-06-23 04:44:23.815047
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = vault_secret = 'password'
    vault_password = 'secret'
    secret_plain = 'bar'
    secret_json = '{"__ansible_vault": "U2FsdGVkX18BfCKCBA+T8x1x6TzSyGjdT6UZ0sX9D6QP62oP/yC+j8kJxnxmTzTdCh6/sU6m9XapJdd2lryq3+4Q/8dgMxzPCNh4S+pSzx41Ndb9XDLg==", "__ansible_unsafe": true}'
    secret_json_decrypted = '{"__ansible_vault": "bar", "__ansible_unsafe": true}'


# Generated at 2022-06-23 04:44:30.618050
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test get ansible_vault
    pairs = {'__ansible_vault': 'AAAAAQAA'}
    assert AnsibleJSONDecoder().object_hook(pairs) == AnsibleVaultEncryptedUnicode(pairs['__ansible_vault'])

    # test get ansible_vault
    pairs = {'__ansible_unsafe': 'test'}
    assert AnsibleJSONDecoder().object_hook(pairs) == wrap_var('test')

# Generated at 2022-06-23 04:44:33.673814
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)


# Generated at 2022-06-23 04:44:41.436389
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '''{
        "test_1": "test_1", 
        "test_2": "test_2", 
        "test_3": {
            "test_3": "test_3",
            "__ansible_vault": "test_3"
        }
    }'''
    data_secrets = 'test_secrets'
    p = AnsibleJSONDecoder(data_secrets)
    decoded = p.decode(data)
    assert decoded['test_1'] == 'test_1'
    assert decoded['test_2'] == 'test_2'
    assert decoded['test_3']['test_3'] == 'test_3'
    assert decoded['test_3']['__ansible_vault'] == 'test_3'
    assert decoded

# Generated at 2022-06-23 04:44:50.222101
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook(dict(__ansible_unsafe="1")) == dict(__ansible_unsafe=wrap_var("1"))
    assert decoder.object_hook(dict(__ansible_vault="1")) == dict(__ansible_vault=AnsibleVaultEncryptedUnicode("1"))
    # other key will be ignored:
    assert decoder.object_hook(dict(key="1")) == dict(key="1")

# Generated at 2022-06-23 04:44:51.739376
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder



# Generated at 2022-06-23 04:45:06.405440
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:11.006903
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class A:
        pass

    a = A()
    result = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': a})
    assert id(result) == id(a)
    assert result._ansible_unsafe

# Generated at 2022-06-23 04:45:20.759426
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ''' object_hook method of class AnsibleJSONDecoder '''
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import json

    secret = 'test'
    vault = VaultLib(secrets=secret)
    encr_str = vault.encrypt('test_str')
    encr_pairs = {'__ansible_vault': encr_str}
    decr_pairs = json.dumps(encr_pairs, cls=AnsibleJSONEncoder)
    decr_pairs = json.loads(decr_pairs, cls=AnsibleJSONDecoder)

# Generated at 2022-06-23 04:45:22.095682
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import collections
    import unittest

    # This method is tested in parsing/vault/test_vault.py
    pass

# Generated at 2022-06-23 04:45:33.498394
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_string = """
{
    "nested_dict": {
        "key1": "value1",
        "key2": "value2"
    },
    "nested_list": [
        "abc",
        "123"
    ]
}
"""

    json_dict = json.loads(json_string, cls=AnsibleJSONDecoder)

    assert isinstance(json_dict, dict)
    assert isinstance(json_dict['nested_dict'], dict)
    assert isinstance(json_dict['nested_list'], list)

    # Test case: if we use json.load function, it will only call str() function
    # which will return a string for every key-value pair. So the json_dict is
    # always a normal python dictionary.

# Generated at 2022-06-23 04:45:35.965971
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:45:47.901327
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ["abcdefghijklmnopqrstuvwxyz"]
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

    # Test normal case
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;foo\n37373539396136613332326134633662396165623032333463373037626665356237656430\n3937366566313134376331366436343538333834303661646262374b754554386832333283\n4b4a4b4c63334f6c5a6c5678704763347a4b4f4f694561785a59\n'}

# Generated at 2022-06-23 04:45:58.752381
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import json
    import sys
    import types

    data = {'__ansible_unsafe': 'unsafe_string'}
    json_data = json.dumps(data)
    # Should still be a string
    assert isinstance(json_data, type(''))

    decoded_data = json.loads(json_data, cls=AnsibleJSONDecoder)
    # Should now be of type AnsibleUnsafeText
    assert isinstance(decoded_data['__ansible_unsafe'], types.UnicodeType)

    assert decoded_data['__ansible_unsafe'] == 'unsafe_string'

# Generated at 2022-06-23 04:46:04.037837
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'secrettt'
    AnsibleJSONDecoder.set_secrets(secret)
    decoder = AnsibleJSONDecoder()
    data = dict(__ansible_vault='hello')
    ansible_vault_encrypted_unicode = decoder.object_hook(data)
    assert isinstance(ansible_vault_encrypted_unicode, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:46:10.346445
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = json.loads('{"__ansible_vault": "foobar", "__ansible_unsafe": "baz"}', cls=AnsibleJSONDecoder)
    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert data['__ansible_vault'] == "foobar"
    assert data['__ansible_unsafe'] == "baz"

# Generated at 2022-06-23 04:46:22.497755
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    This is a unit test for method object_hook of class AnsibleJSONDecoder
    '''
    enc = AnsibleJSONEncoder()
    pairs = enc.encode({'__ansible_unsafe': '$VARIABLE'})
    pairs = json.loads(pairs)

    dec = AnsibleJSONDecoder()
    data = dec.object_hook(pairs)
    assert '__ansible_unsafe' in data
    assert hasattr(data['__ansible_unsafe'], '__ansible_unsafe__') is True
    assert data['__ansible_unsafe'].__ansible_unsafe__() == '$VARIABLE'


# Generated at 2022-06-23 04:46:27.968027
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = "password"
    jsonObject = {"__ansible_vault": "secret", "__ansible_unsafe": "unsafe"}
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert decoder == None
    assert isinstance(json.loads(json.dumps(jsonObject), cls=AnsibleJSONDecoder), dict) == True


# Generated at 2022-06-23 04:46:40.576897
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()
    encoded_vault_value = encoder.encode({'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;test\n6363346537343332346461653961613937666631323064393334643737336432303131623335623863\n393966353337356165383462353933656231356533366239336138300a623431316632626266633936\n3563393530343332383232626661373834393430626339653137663565386633313336396130326232\n3138353836363139366330393834\n'})
    decoder = AnsibleJSONDecoder()
    decoded_v

# Generated at 2022-06-23 04:46:48.509244
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # initialize decoder
    ajd = AnsibleJSONDecoder()

    # test ansible objects (secure, unsafe)
    test_obj = {
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible\n323831326338616661333331386337306234383938396263316233333834643636370a35343064663939386633333034393961393131633930326134363231343437300a3534376466613033376139323066363937373934643835386437623336423239\n",
        "__ansible_unsafe": "This is an unsafe object"
    }
    obj = ajd.decode(json.dumps(test_obj))


# Generated at 2022-06-23 04:46:58.370233
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:11.155271
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
     # GIVEN
     # Define variables and data for test
     ansible_vault_dict = {'vault_pwd': 'secret'}
     ansible_vault_dict_json = json.dumps(ansible_vault_dict)
     ansible_vault_dict_json_with_header = '{"__ansible_vault": "%s"}' % ansible_vault_dict_json
     ansible_vault_dict_loaded = json.loads(ansible_vault_dict_json_with_header, cls=AnsibleJSONDecoder)
     ansible_vault_dict_expected = {'__ansible_vault': ansible_vault_dict}

     # WHEN
     # Call AnsibleJSONDecoder.object_hook to get loaded dictionary
     # THEN
     # Ass

# Generated at 2022-06-23 04:47:20.238402
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # This test is not supposed to work with vault data. A new secret is
    # generated for each test.

    # Init the vault lib with a temporary secret
    secret = b'test_secret'
    vault_lib = VaultLib(secrets=[secret])

    # Encrypt the message 'test_message'
    vault_text = vault_lib.encrypt(b'test_message')

    # Decrypt back the message 'test_message' using the standard Ansible's
    # decoder
    decoded_vault = AnsibleJSONDecoder.object_hook({'__ansible_vault': vault_text})
    assert(decoded_vault.vault.secrets[0] == secret)
    assert(decoded_vault.data == b'test_message')

    # Normal message
    decoded_normal = AnsibleJSON

# Generated at 2022-06-23 04:47:29.479611
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1', 'secret2']
    test_pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;mysecrets\n1234567890abcdefghijklmnopqrstuvwxyz1234\n1234567890abcdefghijklmnopqrstuvwxyz1234\n1234\n',
                  '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256;mysecrets\n1234567890abcdefghijklmnopqrstuvwxyz1234\n1234567890abcdefghijklmnopqrstuvwxyz1234\n1234\n'}
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:47:38.990480
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap

    secrets = ['password', 's3cr3t']
    s = '''{
        "foo": "bar",
        "dict": {
            "__ansible_vault": "1.1;AES256;password",
            "vault_variable": "secret"
        },
        "__ansible_unsafe": "{{ vault_variable }}"
    }'''


# Generated at 2022-06-23 04:47:48.267835
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONDecoder.set_secrets('test-vault-password')

# Generated at 2022-06-23 04:47:49.294945
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder


# Generated at 2022-06-23 04:47:54.587909
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['test']
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder(object_hook=decoder.object_hook)
    assert secrets == decoder._vaults['default'].secrets
    assert decoder._vaults['default'].secrets[0] == 'test'

# Generated at 2022-06-23 04:48:02.805554
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # When __ansible_vault is defined, then AnsibleVaultEncryptedUnicode should be returned

# Generated at 2022-06-23 04:48:13.727289
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import io
    import json
    json.dumps([[1, 2, 3], {'4': 5, '6': 7}], cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

    sample_dict = {"__ansible_unsafe": "abc"}
    print(json.dumps(sample_dict, cls=AnsibleJSONEncoder, indent=4))
    print(json.dumps(sample_dict, cls=AnsibleJSONEncoder, sort_keys=True, indent=4))

    AnsibleJSONDecoder.set_secrets(['secret'])

# Generated at 2022-06-23 04:48:24.952489
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ajd = AnsibleJSONDecoder()

    # Test for case when key is '__ansible_vault'
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    assert ajd.object_hook(pairs) == AnsibleVaultEncryptedUnicode(pairs['__ansible_vault'])

    # Test for case when key is '__ansible_unsafe'
    pairs = {'__ansible_unsafe': 'value'}
    assert ajd.object_hook(pairs) == wrap_var(pairs['__ansible_unsafe'])

    # Test for when key is neither of two
    pairs = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

# Generated at 2022-06-23 04:48:31.767605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    # unsafe
    res = decoder.object_hook({u'__ansible_unsafe': u'$ANSIBLE_VAULT'})
    assert res == wrap_var(u'$ANSIBLE_VAULT')

    # vault
    res = decoder.object_hook({u'__ansible_vault': u'$ANSIBLE_VAULT'})
    assert res.vault == ''

    decoder.set_secrets(['secret'])
    res = decoder.object_hook({u'__ansible_vault': u'$ANSIBLE_VAULT'})
    assert isinstance(res.vault, VaultLib)
    assert res.vault.secrets == ['secret']

    # others

# Generated at 2022-06-23 04:48:43.805353
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:48:52.571173
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    mydict = {'one': 'two', 'three': 'four', 'five': AnsibleVaultEncryptedUnicode('six')}
    myjson = json.dumps(mydict)
    ansible_json = AnsibleJSONDecoder().decode(myjson)
    mydict_new = {'one': 'two', 'three': 'four', 'five': 'six'}
    assert ansible_json == mydict_new, 'Expected: %s, Got: %s' % (mydict_new, ansible_json)
    ansible_json = AnsibleJSONDecoder().decode(myjson)
    assert ansible_json == mydict_new, 'Expected: %s, Got: %s' % (mydict_new, ansible_json)

# Generated at 2022-06-23 04:49:03.119171
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test']
    obj = dict(__ansible_vault='$ANSIBLE_VAULT;1.1;AES256;testhost\n35386439393034363637333466356434353461353633346464313331393032376264663139613664\n3365653834653234356237636535662d383338662d343739322d386438342d636562623332656630\n35386538366234363362626231316200656634376662353965306531326163336561323363353435\n39326531\n', __ansible_unsafe='unsafe')

    result = AnsibleJSONDecoder.object_hook(obj)

# Generated at 2022-06-23 04:49:13.832137
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder()

    # test for AnsibleVaultEncryptedUnicode
    pairs = {'__ansible_vault': 'dummy encrypted text'}
    obj = jd.object_hook(pairs)
    assert type(obj) == AnsibleVaultEncryptedUnicode
    assert '__ansible_vault' not in obj

    # test for AnsibleUnsafeText
    pairs = {'__ansible_unsafe': 'dummy unsafe text'}
    obj = jd.object_hook(pairs)
    assert type(obj) == str
    assert '__ansible_unsafe' not in obj

    # test for no special object
    pairs = {'some_key': 'some_value'}
    obj = jd.object_hook(pairs)

# Generated at 2022-06-23 04:49:25.244941
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_dict = {
        u'a': u'a',
        u'b': u'b',
        u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;ansible\r\n3338373039376265626231666337613030636135363363323730363935656135346430336564366\r\n36466463613733643931643732613761626264613338316661653537373262356532666435336639\r\n64353330316162303462613462386566616130393537663739366262653263383732\r\n'}

# Generated at 2022-06-23 04:49:29.635171
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    _ansible_json_decoder = AnsibleJSONDecoder()

    assert vars(_ansible_json_decoder) == {'object_hook': _ansible_json_decoder.object_hook}

# Generated at 2022-06-23 04:49:40.158210
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:43.190280
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    instance = AnsibleJSONDecoder()
    assert isinstance(instance, AnsibleJSONDecoder)


# Generated at 2022-06-23 04:49:45.025601
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()

    assert isinstance(a, AnsibleJSONDecoder)

# Generated at 2022-06-23 04:49:46.621567
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder().__class__.__name__ == 'AnsibleJSONDecoder'


# Generated at 2022-06-23 04:49:57.006280
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_bytes

    ansible_jdec = AnsibleJSONDecoder()
    ansible_jdec_with_method = AnsibleJSONDecoder(ansible_jdec.object_hook)

    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 04:50:04.801343
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # test ansible vault data
    ansible_vault_data = {"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n3538323830383632316536666265353337653134396534303338343831313939663562313164\n326536393364343062636531353137346234633831356262613230393332366138613661356530\n613534316366633862336337343866656538333839396631333136613963356233346438636132\n386334376463316663346262636639656637636229\n"}
    ansible_vault_json_data = json.dumps(ansible_vault_data)

   