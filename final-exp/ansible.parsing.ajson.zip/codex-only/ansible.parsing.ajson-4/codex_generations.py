

# Generated at 2022-06-23 04:40:04.218144
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_str = """{"__ansible_vault": "mysecret", "__ansible_unsafe": "myvar"}"""
    json_obj = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert(isinstance(json_obj['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(isinstance(json_obj['__ansible_unsafe'], wrap_var))


# Generated at 2022-06-23 04:40:07.203131
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder().object_hook)
    assert isinstance(decoder, json.JSONDecoder)
    assert decoder.object_hook == AnsibleJSONDecoder().object_hook


# Generated at 2022-06-23 04:40:11.315029
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '{"__ansible_vault": "el1taXNjaWVudHJvbGwK"}'
    json_decoder = AnsibleJSONDecoder()
    json_obj = json_decoder.decode(data)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:40:18.865237
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = "secret"
    ansible_var = json.dumps({'__ansible_vault': 'test_text', '__ansible_unsafe': 'unsafe_text'}, cls=AnsibleJSONEncoder)
    AnsibleJSONDecoder.set_secrets(secret)
    ansible_var = json.loads(ansible_var, cls=AnsibleJSONDecoder)
    assert ansible_var['__ansible_vault'] == 'VaultLib(***)'
    assert ansible_var['__ansible_unsafe'] == "<ansible.utils.unsafe_proxy.AnsibleUnsafeText object>"

# Generated at 2022-06-23 04:40:30.022309
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_file = ".vault_pass.txt"
    if not os.path.exists(secret_file):
        # if this file is not here, we need to create it
        with open(secret_file, 'w') as f:
            f.write("12345")
    # https://stackoverflow.com/questions/30918781/how-to-call-an-instance-method-from-a-class
    # https://stackoverflow.com/questions/6760685/creating-a-singleton-in-python
    # https://stackabuse.com/python-singletons/
    # https://stackoverflow.com/questions/17658033/python-dictionary-of-functions-where-the-key-is-the-function-name
    # https://stackoverflow.com

# Generated at 2022-06-23 04:40:38.173227
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = { '__ansible_unsafe': 'test_unsafe_value' }
    pairs_modified = decoder.object_hook(pairs)
    assert(type(pairs_modified['__ansible_unsafe']) == unicode)
    pairs = { '__ansible_vault': 'test_vault_value' }
    pairs_modified = decoder.object_hook(pairs)
    assert(type(pairs_modified['__ansible_vault']) == AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-23 04:40:41.361430
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # created object of AnsibleJSONDecoder class
    obj = AnsibleJSONDecoder()
    # check that the object is created
    assert obj is not None


# Generated at 2022-06-23 04:40:51.646121
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import PY3

    secrets = ['testpass1', 'testpass2']
    test_dict1 = dict(__ansible_vault="encrypted text")
    test_dict2 = dict(__ansible_unsafe="unsafe text")

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

    j = json.JSONDecoder(object_hook=decoder.object_hook)

    if PY3:
        ansible_vault_class = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 04:40:59.558838
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # construct an instance of AnsibleJSONDecoder
    ajd = AnsibleJSONDecoder()

    # construct an AnsibleJSONEncoder instance
    aje = AnsibleJSONEncoder()

    # assert the object hook works as expected
    # using the same data as in https://github.com/ansible/ansible/pull/40402
    assert ajd.object_hook({"__ansible_vault": "$$$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$"}) == AnsibleVaultEncryptedUnicode("$$$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$2$")
    assert ajd.object_

# Generated at 2022-06-23 04:41:06.603371
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = json.loads('{ "__ansible_vault": "value"}', cls=AnsibleJSONDecoder)
    assert data.vault is None
    data = json.loads('{ "__ansible_vault": "value", "__ansible_unsafe": "value"}', cls=AnsibleJSONDecoder)
    assert data.vault is None
    data = json.loads('{ "__ansible_unsafe": "value"}', cls=AnsibleJSONDecoder)
    assert isinstance(data, wrap_var)
    data = json.loads('{ "key": "value"}', cls=AnsibleJSONDecoder)
    assert data == {"key": "value"}

# Generated at 2022-06-23 04:41:13.689992
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s ='{"__ansible_vault": "foo"}'
    jd = AnsibleJSONDecoder()
    s2 = jd.decode(s)
    assert s2 == {'__ansible_vault': AnsibleVaultEncryptedUnicode('foo')}
    assert s2['__ansible_vault'].vault

    s3 = jd.decode('{"__ansible_unsafe": "foo"}')
    assert s3 == {'__ansible_unsafe': 'UnsafeProxy(str, foo)'}

# Generated at 2022-06-23 04:41:20.484024
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    # ansible-vault string with VaultLib secret
    s = '{"__ansible_vault": "VaultLib(SOME_SECRET_HERE)"}'
    vault_secret = 'SOME_SECRET_HERE'

    # Create AnsibleJSONDecoder with ansible vault secret
    AnsibleJSONDecoder.set_secrets(vault_secret)
    ansible_json_decoder = AnsibleJSONDecoder(s)

    # call object_hook method with ansible vault string
    object_hook_result = ansible_json_decoder.object_hook({'__ansible_vault': 'VaultLib(SOME_SECRET_HERE)'})

    # verify result is an AnsibleVaultEncryptedUnicode and has assigned secret


# Generated at 2022-06-23 04:41:20.977120
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()

# Generated at 2022-06-23 04:41:22.948883
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test with no args
    obj = AnsibleJSONDecoder()
    assert obj.object_hook == AnsibleJSONDecoder.object_hook
    # test with args
    obj = AnsibleJSONDecoder(object_hook=True)
    assert obj.object_hook != AnsibleJSONDecoder.object_hook


# Generated at 2022-06-23 04:41:33.335774
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;testuser;\n123',
             '__ansible_unsafe': '123123',
             '__ansible_unsafe2': '123'}
    temp = AnsibleJSONDecoder()

    result1 = temp.object_hook(pairs)
    assert isinstance(result1[pairs.keys()[0]], AnsibleVaultEncryptedUnicode)
    assert result1['__ansible_unsafe'].value == '123123'
    assert result1['__ansible_unsafe2'] == '123'
    assert '__ansible_unsafe2' in result1

# Generated at 2022-06-23 04:41:44.790280
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:56.791694
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Verify object_hook is initialized
    meta_hook = AnsibleJSONDecoder()
    assert meta_hook.object_hook is not None

    # Verify that AnsibleVaultEncryptedUnicode is returned for __ansible_vault
    with open('test/unit/utils/artifactory/encrypted_file') as f:
        json_text = f.read()
    secret_hook = AnsibleJSONDecoder()
    secret_hook.set_secrets(['ansible'])
    json_object = secret_hook.decode(json_text)
    decrypted_value = json_object['__ansible_vault']
    assert isinstance(decrypted_value, AnsibleVaultEncryptedUnicode)

    # Verify that AnsibleUnsafeProxy is returned for __ansible_unsafe
    unsafety_hook = Ans

# Generated at 2022-06-23 04:41:58.893329
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert hasattr(AnsibleJSONDecoder, '_vaults')
    assert isinstance(AnsibleJSONDecoder._vaults,dict)



# Generated at 2022-06-23 04:42:02.586799
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    
    # Unit test for method object_hook of class AnsibleJSONDecoder from line 59 to line 70
    pass


# Generated at 2022-06-23 04:42:16.785913
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    result = ansible_json_decoder.object_hook({})
    assert result == {}

    result = ansible_json_decoder.object_hook({'__ansible_vault': 'content'})
    assert str(result) == "!vault |\n          content"
    assert result.vault == None

    result = ansible_json_decoder.object_hook({'__ansible_unsafe': 'content'})
    assert str(result) == "<ansible.utils.unsafe_proxy.AnsibleUnsafeText object at 0x7f77c2f7d150>"



# Generated at 2022-06-23 04:42:29.169839
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:37.478774
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test __init__()
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook

    # test set_secrets()
    decoder.set_secrets(secrets=['secret'])
    assert decoder._vaults['default'] != None

    # test object_hook()
    result = decoder.object_hook(pairs={'__ansible_unsafe':'value'})
    assert result != None
    assert result.__dict__['_ansible_unsafe_proxy_class'] == str('value')

# Generated at 2022-06-23 04:42:39.974219
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    kwargs = dict(object_hook=None)
    ansible_json_decoder = AnsibleJSONDecoder(kwargs)
    assert (ansible_json_decoder.object_hook == None)

# Generated at 2022-06-23 04:42:49.962163
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_str = '{"__ansible_vault": "encrypted_str","__ansible_unsafe": "unsafe_str"}'
    secrets = ["password1", "password2"]
    AnsibleJSONDecoder.set_secrets(secrets)

    test_ob = AnsibleJSONDecoder()
    ob = test_ob.decode(test_str)
    assert len(ob) == 2
    assert ob["__ansible_vault"] == "encrypted_str"
    assert ob["__ansible_vault"].vault.secrets == secrets
    assert ob["__ansible_unsafe"] == "unsafe_str"
    assert ob["__ansible_unsafe"].__class__ == wrap_var("test").__class__

# This is required to test the class since pytest does not load it automatically


# Generated at 2022-06-23 04:43:02.151252
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os


# Generated at 2022-06-23 04:43:10.828049
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:21.330467
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''The AnsibleJSONDecoder class is meant to be used to instantiate a
    json.JSONDecoder object. Its object_hook method will unpack the data
    dictionary and process the contents. This test ensures that
    AnsibleJSONDecoder can be instantiated and run in the same manner as
    json.JSONDecoder.'''

    # Setup data for testing
    test_data = "{\"a\": \"b\", \"c\": [{ \"__ansible_vault\": \"AQAAAAEAAAB7DA==\" }, 1, 2, 3]}"
    test_obj = {'a': 'b', 'c': [{'__ansible_vault': 'AQAAAAEAAAB7DA=='}, 1, 2, 3]}
    json_obj = json.loads(test_data)

    # Instantiate AnsibleJSONDecoder class


# Generated at 2022-06-23 04:43:33.416273
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class DummyVault:
        def __init__(self):
            self.secrets = ['blah']
            self.decrypt = lambda x: 'foo'

    test_pairs = {
        '__ansible_vault': 'blah',
        '__ansible_unsafe': 'blah',
        '__ansible_no_log': True,
        'blah': 'blah',
    }
    test_pairs_decoded = {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('blah'),
        '__ansible_unsafe': wrap_var('blah'),
        '__ansible_no_log': True,
        'blah': 'blah',
    }

    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder._v

# Generated at 2022-06-23 04:43:45.005545
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:47.619479
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    raw = u'{"__ansible_vault": "value"}'
    expected = {u'__ansible_vault': 'value'}
    assert decoder.decode(raw) == expected

# Generated at 2022-06-23 04:43:53.354163
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'password'
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:43:57.326514
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder._vaults == {}
    assert ansible_json_decoder.object_hook == ansible_json_decoder.object_hook


# Generated at 2022-06-23 04:44:05.201458
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    module = AnsibleModule(
        argument_spec = dict(
            jsonstring=dict(required=True)
        ),
    )
    # Initialize decoder
    Decoder = AnsibleJSONDecoder()
    Decoder._vaults = dict()
    Decoder._vaults['default'] = VaultLib(secrets=["hunter2"])

    decoded = Decoder.decode(module.params['jsonstring'])
    decoded.vault.secrets = ["hunter2"]
    vault_data = decoded.vault.decrypt(decoded)

    module.exit_json(changed=False, msg=vault_data)

# Generated at 2022-06-23 04:44:05.786583
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert (AnsibleJSONDecoder() is not None)

# Generated at 2022-06-23 04:44:11.951448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded_json = AnsibleJSONDecoder.decode('{ "__ansible_unsafe": "$ansible"}')
    assert decoded_json == wrap_var("$ansible")

    decoded_json = AnsibleJSONDecoder.decode('{ "__ansible_vault": "ansible"}')
    assert decoded_json.prefix == '$ANSIBLE_VAULT;'
    assert decoded_json.vault is None

# Generated at 2022-06-23 04:44:22.418188
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_data = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;testaccounttestuser00000000',
        '__ansible_unsafe': 'abcdefg',
    }
    assert decoder.object_hook(test_data) == {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;testaccounttestuser00000000'),
        '__ansible_unsafe': AnsibleUnsafeText('abcdefg'),
    }

AnsibleJSONEncoder = AnsibleJSONEncoder  # noqa

# Generated at 2022-06-23 04:44:34.146968
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # prepare secret vars to decrypt vault variables
    secret_vars = {'vault_password': 'test'}

    # create test object with vault var

# Generated at 2022-06-23 04:44:46.068379
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:52.984997
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'secret1'
    AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder._vaults['default']
    assert AnsibleJSONDecoder._vaults['default'].secrets == secret

    assert AnsibleJSONDecoder is not json.JSONDecoder
    assert AnsibleJSONDecoder.__init__ is not json.JSONDecoder.__init__


# Generated at 2022-06-23 04:44:58.863159
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "1234"}'
    decoder = AnsibleJSONDecoder()

    value = decoder.object_hook(json.loads(json_str))
    assert '__ansible_vault' in value
    assert value['__ansible_vault'] == "1234"
    assert isinstance(value['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:45:07.300512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    cls = AnsibleJSONDecoder
    cls.set_secrets(["password"])

    pairs = { "__ansible_vault": "data" }
    v = cls().object_hook(pairs)
    assert isinstance(v, AnsibleVaultEncryptedUnicode)
    assert isinstance(v.vault, VaultSecret)
    assert v.vault.secrets == ["password"]
    assert v.vault.decrypt(v) == 'data'

    # with __ansible_vault and __ansible_unsafe keys

# Generated at 2022-06-23 04:45:19.055788
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets="ansible")

    # Test for vault encrypted string
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n3132333435363738393031323334353637383930313233343536373839303132\n3939393939393939393939393939393939393939393939393939393939393939\n3939393939393939393939393939393939393939393939393939393939393939'}
    expected_result = AnsibleVaultEncryptedUnicode(vault_text=pairs['__ansible_vault'])
    expected_result

# Generated at 2022-06-23 04:45:31.316414
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_json_data = '{"__ansible_vault": "AES256"}'
    assert json.loads(ansible_vault_json_data, cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode('AES256')

    ansible_vault_json_data = '{"__ansible_vault": ["AES256", "AES256"]}'
    assert json.loads(ansible_vault_json_data, cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode(['AES256', 'AES256'])

    ansible_unsafe_json_data = '{"__ansible_unsafe": "AES256"}'

# Generated at 2022-06-23 04:45:37.000733
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoded_data = json.loads('{"__ansible_vault": "value"}', cls=AnsibleJSONDecoder)
    assert isinstance(decoded_data, AnsibleVaultEncryptedUnicode)
    assert decoded_data.vault is None

    decoded_data = json.loads('{"__ansible_unsafe": "value"}', cls=AnsibleJSONDecoder)
    assert decoded_data.unwrap() == 'value'



# Generated at 2022-06-23 04:45:39.451678
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=myObjHook)
    assert decoder.object_hook == myObjHook



# Generated at 2022-06-23 04:45:52.224842
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test that __ansible_vault is decrypted correctly
    decoder.set_secrets('foo')
    test_string = '{"__ansible_vault": "AgJVBAAAAoD+gAAAAAAAAwAAAAYAEQAAABOdWxsLXRlc3R1c2VyAERPTkUAAAAAAAAA\nAAAABJHQGz+Wc0vM2QPlXCJLbRE+PECIxboeCZzfkYcYBKyNl/E1NO/nX9A="}'
    test_dict = json.loads(test_string, cls=AnsibleJSONDecoder)
    assert(isinstance(test_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode))


# Generated at 2022-06-23 04:46:03.530130
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n' \
             '636331396134656265363930353334376565383034326536653130653562366634356466336563\n' \
             '6439636262646165373061383933316138376136376535643836346466306564\n' \
             '653438653232386265646539636264363161376639353666333833613334393066343163326236\n' \
             '3835383162333066653537663330363430\n'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secret)

# Generated at 2022-06-23 04:46:08.311530
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_dict = {'__ansible_unsafe': "passw0rd"}
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook, strict=False)
    assert decoder.decode(json.dumps(test_dict)) == test_dict


# Generated at 2022-06-23 04:46:09.674647
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # nothing to test
    pass



# Generated at 2022-06-23 04:46:10.707474
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:17.296660
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {'a': 1, '__ansible_vault': b'vault: value', 'b': 2}
    decoded = AnsibleJSONDecoder.object_hook(obj)

    assert AnsibleVaultEncryptedUnicode(b'vault: value') == decoded['__ansible_vault']
    assert 1 == decoded['a']
    assert 2 == decoded['b']


# Generated at 2022-06-23 04:46:28.244352
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Unsafe value
    s = '{"__ansible_unsafe": true}'
    results = AnsibleJSONDecoder().decode(s)
    assert hasattr(results, '__ansible_unsafe__')

    # Vault value
    s = '{"__ansible_vault": "mysecret"}'
    results = AnsibleJSONDecoder().decode(s)
    assert isinstance(results, AnsibleVaultEncryptedUnicode)
    assert results.vault is None

    # Unsafe var should be preserved in vault object
    s = '{"__ansible_vault": "mysecret", "__ansible_unsafe": "unsafe"}'
    results = AnsibleJSONDecoder().decode(s)
    assert hasattr(results, '__ansible_unsafe__')

    # Unsafe var should

# Generated at 2022-06-23 04:46:40.086017
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsiJSONDec = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'test_vault'}

    ansible_vault = AnsiJSONDec.object_hook(pairs)
    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)
    assert ansible_vault == 'test_vault'
    assert isinstance(ansible_vault.vault, VaultLib)

    pairs = {'__ansible_unsafe': 'test_unsafe'}
    ansible_unsafe = AnsiJSONDec.object_hook(pairs)
    assert ansible_unsafe == 'test_unsafe'
    assert isinstance(ansible_unsafe, AnsibleUnsafeText)

# Generated at 2022-06-23 04:46:44.373533
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '{"__ansible_vault": "vaultdata", "__ansible_unsafe": "unsafedata"}'
    res = AnsibleJSONDecoder().decode(data)
    assert res['__ansible_vault'] == 'vaultdata'
    assert res['__ansible_unsafe'] == 'unsafedata'



# Generated at 2022-06-23 04:46:55.161986
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Note that AnsibleJSONDecoder.set_secrets was never called to set secrets
    secrets = "this is the secrets"
    ansible_json_decoder = AnsibleJSONDecoder()
    pairs = {
        "__ansible_vault": "ZW5jb2RlZCB2YXVsdCB0ZXh0",
        "__ansible_unsafe": AnsibleVaultEncryptedUnicode("ZW5jb2RlZCB2YXVsdCB0ZXh0", vault=None),
        "__unknown_key": "value"
    }
    result = ansible_json_decoder.object_hook(pairs)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:46:55.900612
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:46:58.757353
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    password = 'password'
    decoder = AnsibleJSONDecoder.set_secrets([password])
    assert decoder._vaults['default'] is not None
    assert decoder._vaults['default'].secrets == [password]

# Generated at 2022-06-23 04:47:07.826443
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_strings = [
        '{"__ansible_vault": "example_password"}',
        '{"__ansible_unsafe": {"a": "b", "b": "c"}}',
    ]

    for test_string in test_strings:
        ansible_json_decoder = AnsibleJSONDecoder(test_string, object_hook=AnsibleJSONDecoder.object_hook)
        x = ansible_json_decoder.decode(test_string)
        print("type(x): %s" % type(x))


# Generated at 2022-06-23 04:47:18.429579
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils.common._json_compat import json

    test_secret = 'foo'

# Generated at 2022-06-23 04:47:23.085566
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    res = AnsibleJSONDecoder("{\"__ansible_vault\": \"1\"}", vault_secrets=['changeme'])
    assert json.loads("{\"__ansible_vault\": \"1\"}") != res

# Generated at 2022-06-23 04:47:35.502812
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'foo'
    raw_json = '{"__ansible_vault": "vault_encrypted_data", "__ansible_unsafe": "unsafe_data"}'
    json_data = json.loads(raw_json, cls=AnsibleJSONDecoder)
    assert isinstance(json_data, dict)
    assert isinstance(json_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert json_data['__ansible_vault'] == 'vault_encrypted_data'
    assert isinstance(json_data['__ansible_unsafe'], AnsibleUnsafeText)
    assert str(json_data['__ansible_unsafe']) == 'unsafe_data'

# Generated at 2022-06-23 04:47:37.934951
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)


# Generated at 2022-06-23 04:47:49.748759
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:51.665168
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    x = AnsibleJSONDecoder()
    assert isinstance(x, json.JSONDecoder)

# Generated at 2022-06-23 04:47:59.780825
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test with an AnsibleVaultEncryptedUnicode object
    aveu = AnsibleVaultEncryptedUnicode("testString")
    pairs = {
        "__ansible_vault": "testString"
    }
    aved = AnsibleJSONDecoder()
    aved.object_hook(pairs)
    assert aved.object_hook(pairs) == {"__ansible_vault": aveu}

    # Test with an __ansible_unsafe object
    pairs = {
        "__ansible_unsafe": "testString"
    }
    aved = AnsibleJSONDecoder()
    aved.object_hook(pairs)
    assert aved.object_hook(pairs) == pairs

    # Test with a non-specialized object
    pairs = {"test": "test"}

# Generated at 2022-06-23 04:48:08.552403
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # object_hook should be no-op if no ansible_* key is present
    assert decoder.object_hook({'__ansible_bar': 'foo'}) == {'__ansible_bar': 'foo'}

    # object_hook should return appropriate object if ansible_vault is present
    assert isinstance(decoder.object_hook({'__ansible_vault': 'baz'}), AnsibleVaultEncryptedUnicode)

    # object_hook should return appropriate object if __ansible_unsafe is present
    assert isinstance(decoder.object_hook({'__ansible_unsafe': 'baz'}), wrap_var)

# Generated at 2022-06-23 04:48:20.271033
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets('dummypassword')

    # (pairs=None, **kwargs)
    ansible_json_decoder = AnsibleJSONDecoder()
    assert 'object_hook' in ansible_json_decoder.kwargs
    assert ansible_json_decoder.kwargs['object_hook'] == ansible_json_decoder.object_hook

    # (pairs=None, object_hook=None, parse_float=None, parse_int=None, parse_constant=None, strict=True, object_pairs_hook=None)
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=ansible_json_decoder.object_hook)
    assert 'object_hook' in ansible_json_decoder.kwargs
    assert ansible_json

# Generated at 2022-06-23 04:48:31.696993
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('password')

# Generated at 2022-06-23 04:48:43.807056
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Load the test data
    from ansible.test.utils import load_fixture

    test_str = load_fixture('json_ansible_vault.py')
    # Load the expected results
    expected_txt = load_fixture('json_ansible_vault_decoded.py')
    expected_obj = load_fixture('json_ansible_vault_decoded.json')

    # Instanciate the decoder
    vault_password = 'test'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([vault_password])

    # Run the test
    test_obj = decoder.decode(test_str)
    assert test_obj == expected_obj, test_obj

# Generated at 2022-06-23 04:48:46.165314
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    def test_object_hook(pairs):
        return pairs

    assert test_object_hook == AnsibleJSONDecoder().object_hook

# Generated at 2022-06-23 04:48:47.464152
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

# Generated at 2022-06-23 04:48:49.622089
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder


# Generated at 2022-06-23 04:48:53.504259
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'devops']
    test_object_hook_in_json_decoder = AnsibleJSONDecoder.set_secrets(secrets)
    actual = AnsibleJSONDecoder.object_hook()
    expected = {}
    assert actual == expected

# Generated at 2022-06-23 04:48:55.027098
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:49:04.480435
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:07.885312
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test without arguments
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, AnsibleJSONDecoder)
    # Test with arguments, passed to the super class
    decoder = AnsibleJSONDecoder(skipkeys=True, strict=True)
    assert isinstance(decoder, AnsibleJSONDecoder)


# Generated at 2022-06-23 04:49:16.051839
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for instance with vault data
    json_string = json.dumps({'a': 'The data to encrypt', '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n353735333738343362313836366637313034643230666437643935366265363865643762616464\n636332373864656634643762616137613962343264653338633935643762633864383935643463\n3936333637626135313531323165376463663330383537626537\n'}, cls=AnsibleJSONEncoder)
    VaultLib.set_vault_secrets('mypassword')

# Generated at 2022-06-23 04:49:23.149116
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'dummy'}) == AnsibleVaultEncryptedUnicode('dummy')
    assert decoder.object_hook({'__ansible_vault': 'dummy', '__ansible_unsafe': 'dummy'}) == AnsibleVaultEncryptedUnicode('dummy')
    assert decoder.object_hook({}) == {}

# Generated at 2022-06-23 04:49:32.043484
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    cls = AnsibleJSONDecoder
    cls.set_secrets('dummy')
    decoder = cls()
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode == type(decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;dummy\n396234653437653438303831\n'}))
    from ansible.utils.unsafe_proxy import wrap_var
    assert wrap_var({'foo': 'bar'}) == decoder.object_hook({'__ansible_unsafe': {'foo': 'bar'}})

# Generated at 2022-06-23 04:49:36.030232
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import os
    import tempfile

    fd, tmp = tempfile.mkstemp()
    os.close(fd)
    os.unlink(tmp)
    d = AnsibleJSONDecoder()
    assert isinstance(d, AnsibleJSONDecoder)

# Generated at 2022-06-23 04:49:40.237376
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''
    Test constructor of AnsibleJSONDecoder
    :return:
    '''
    try:
        AnsibleJSONDecoder()
    except Exception as ex:
        raise AssertionError("AnsibleJSONDecoder constructor not working. Error: %s" % str(ex))


# Generated at 2022-06-23 04:49:47.243453
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert {'__ansible_vault': 'encrypted_value'} == decoder.decode('{"__ansible_vault": "encrypted_value"}')
    assert {'__ansible_unsafe': 'unsafe_marker'} == decoder.decode('{"__ansible_unsafe": "unsafe_marker"}')
    assert {'key': 'value'} == decoder.decode('{"key": "value"}')

# Generated at 2022-06-23 04:49:53.162177
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_pass = 'secret'
    decoder = AnsibleJSONDecoder
    decoder.set_secrets(vault_pass)
    test_json = '{"__ansible_vault": "123"}'
    json_decoded = json.loads(test_json, cls=AnsibleJSONDecoder)
    assert AnsibleVaultEncryptedUnicode('123') == json_decoded



# Generated at 2022-06-23 04:50:03.034377
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from nose.tools import assert_equal

    ansible_json_decoder = AnsibleJSONDecoder()

    # Test for returning AnsibleVaultEncryptedUnicode
    pairs = {'__ansible_vault': 'foo'}
    result = ansible_json_decoder.object_hook(pairs)
    assert_equal(isinstance(result, AnsibleVaultEncryptedUnicode), True)
    assert_equal(result, 'foo')

    # Test for returning wrap_var
    pairs = {'__ansible_unsafe': 'foo'}
    result = ansible_json_decoder.object_hook(pairs)
    assert_equal(isinstance(result, wrap_var), True)

    # Test for returning original pairs
    pairs = {'foo': 'bar'}
    result = ansible_