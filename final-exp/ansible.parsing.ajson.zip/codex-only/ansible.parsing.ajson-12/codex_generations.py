

# Generated at 2022-06-23 04:40:09.035330
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:19.126488
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    #test empty vault and empty AnsibleVaultEncryptedUnicode
    assert AnsibleJSONDecoder.set_secrets(secrets={}) != None
    assert AnsibleJSONDecoder().object_hook({}) != None

    #test one vault item and one AnsibleVaultEncryptedUnicode
    assert AnsibleJSONDecoder.set_secrets(secrets={'vault': 'pw'}) != None
    assert AnsibleJSONDecoder().object_hook({'__ansible_vault': 'vault'}) != None

    #test one vault item, one AnsibleVaultEncryptedUnicode and one unsafe value
    assert AnsibleJSONDecoder.set_secrets(secrets={'vault': 'pw'}) != None

# Generated at 2022-06-23 04:40:21.752198
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder
    a = AnsibleJSONDecoder()
    assert a

# Generated at 2022-06-23 04:40:23.001753
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()._vaults == dict()

# Generated at 2022-06-23 04:40:32.570931
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:41.791724
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:40:51.866754
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    if decoder.object_hook(dict(a=1)) == dict(a=1):
        raise AssertionError()
    if decoder.object_hook(dict(__ansible_vault=1)) != AnsibleVaultEncryptedUnicode(1):
        raise AssertionError()
    if decoder.object_hook(dict(__ansible_unsafe=1)) != wrap_var(1):
        raise AssertionError()
    if decoder.object_hook(dict(__ansible_vault=1, __ansible_unsafe=2)) != AnsibleVaultEncryptedUnicode(1):
        raise AssertionError()

# Generated at 2022-06-23 04:40:52.341589
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:41:02.701974
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:09.978420
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_unsafe': 'myvar', '__ansible_vault': 'MYVAULT'}
    obj = decoder.object_hook(pairs)
    assert obj['__ansible_vault'].vault is None
    assert obj['__ansible_unsafe'] == 'myvar'

# Generated at 2022-06-23 04:41:22.193632
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import base64
    from ansible.module_utils.common.json import from_json

    secret = '$ANSIBLE_NET_AUTH_PASS'
    key_string = 'string'
    value_string = 'my_secret'

    # Create dictionary to be serialized
    my_dict = {}
    my_dict[key_string] = value_string
    # Create encrypted string to be used for test
    encrypted_value_string = base64.b64encode(value_string.encode('utf-8'))
    encrypted_value_string = encrypted_value_string.decode('utf-8')
    encrypted_string = '$ANSIBLE_VAULT;' + encrypted_value_string + ';'
    my_dict['__ansible_vault'] = encrypted_string

    # Encrypt test string
    vault

# Generated at 2022-06-23 04:41:30.866681
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
     decoder = AnsibleJSONDecoder()
     pairs = {u'key1': u'val1', u'__ansible_vault': u'abc', u'__ansible_unsafe': u'xxxxx', u'key2': u'val2'}
     result = decoder.object_hook(pairs)
     assert result == {u'key1': u'val1', u'__ansible_vault': u'abc', u'__ansible_unsafe': 'xxxxx', u'key2': u'val2'}


# Generated at 2022-06-23 04:41:39.314702
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    key = '__ansible_unsafe'
    value = 'test_value'
    test_json_input = json.dumps({key: value})
    ansible_json_output = json.loads(test_json_input, cls=AnsibleJSONDecoder)
    assert ansible_json_output[key] == value
    assert isinstance(ansible_json_output[key], wrap_var)


# This overloads the standard AnsibleJSONEncoder to whitelist
# special types that exist in the types module, like for example
# boolean.

# Generated at 2022-06-23 04:41:43.474579
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Given
    secrets = ['foo', 'bar']
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    # When
    decoder = AnsibleJSONDecoder()
    # Then
    assert decoder._vaults['default'] == secrets


# Generated at 2022-06-23 04:41:54.827947
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_plaintext = u'abcdefg'
    ansible_vault_encrypted = u'$ANSIBLE_VAULT;1.2;AES256;sammy\n343138366561353735376233346536356633353033626234626264633932393331303465646332383\n65353336663064306635646632363064656635316339623162383237616232646432626662346561\n32363338303536346231643561626635396364623365653935383465303866316133343335303466\n636336663563656134343831623762313734\n'


# Generated at 2022-06-23 04:41:56.786451
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    my_decoder = AnsibleJSONDecoder()
    print(my_decoder)

# Generated at 2022-06-23 04:42:04.548458
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder
    from ansible.vars.unsafe_proxy import wrap_var
    object = decoder.object_hook({'__ansible_unsafe': 123})
    assert isinstance(object, wrap_var)
    object = decoder.object_hook({'__ansible_vault': 123})
    assert isinstance(object, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:42:19.019098
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    sample = """{
    "__ansible_vault": "V!vault!25DxV1ZhVDdZJyd1eipWhn+WtPupn+YRIyc7Q2f+rW5nX9E1agZh83iE0tNsPm+0p",
    "__ansible_unsafe": "safe"
}"""

    d = AnsibleJSONDecoder()
    r = d.decode(sample)

    assert isinstance(r['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(r['__ansible_unsafe'], AnsibleUnsafeText)

# Generated at 2022-06-23 04:42:21.301420
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_pw = 'sample_password'
    AnsibleJSONDecoder.set_secrets(vault_pw)
    return AnsibleJSONDecoder()


# Generated at 2022-06-23 04:42:27.052741
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for vaulted password
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:38.554060
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # test AnsibleJSONDecoder._fake_encode_password
    # for AnsibleVaultEncryptedUnicode
    secret_data = [{"pass": "ansible"}]
    AnsibleJSONDecoder.set_secrets(secret_data)

# Generated at 2022-06-23 04:42:40.924064
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import sys

    # Python 2 and 3 compatibility
    assert sys.version_info >= (3,5)
    assert sys.version_info.major == 3
    assert sys.version_info.minor == 5

# Generated at 2022-06-23 04:42:50.300371
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # ansible_vault test
    ansible_vault = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test value'})
    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)
    assert ansible_vault.vault is None

    # ansible_vault with secret test
    vault = AnsibleJSONDecoder.set_secrets('secret')
    ansible_vault_with_secret = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test value'})
    assert ansible_vault_with_secret.vault is not None

    # ansible_unsafe test
    ansible_unsafe = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'test value'})

# Generated at 2022-06-23 04:43:02.549070
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # The method to be tested
    def _test(pairs):
        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                value = AnsibleVaultEncryptedUnicode(value)
                if self._vaults:
                    value.vault = self._vaults['default']
                return value
            elif key == '__ansible_unsafe':
                return wrap_var(value)

        return pairs


    # only plain string is supported currently.
    # If a type of object, such as list or dict, is supported later on, please add more test cases.

# Generated at 2022-06-23 04:43:15.151336
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-23 04:43:23.051299
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test with no secrets
    decoder = AnsibleJSONDecoder()

    json_str = u'{"__ansible_vault": "dGVzdA=="}'
    try:
        decoder.decode(json_str)
        assert False, 'decode should have failed with no vault'
    except ValueError as e:
        assert 'Vault password must be set to decrypt' in str(e), 'Not the expected error'

    # set secrets
    decoder.set_secrets('test')
    decoded = decoder.decode(json_str)

    assert decoded['__ansible_vault'] == u'test'

# Generated at 2022-06-23 04:43:26.066503
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder().object_hook({'__ansible_vault': 'vaulted'})
    AnsibleJSONDecoder().object_hook({'__ansible_unsafe': 'unsafe'})

# Generated at 2022-06-23 04:43:38.248469
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:41.517825
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = {'__ansible_vault': '789012'}
    x = AnsibleJSONDecoder()
    e = x.object_hook(d)
    assert e.data == '789012'
    assert not e.vault

# Generated at 2022-06-23 04:43:45.528225
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # expected result is the same object with identical content but with a different object id
    decoder = AnsibleJSONDecoder()
    json_data = '{"__ansible_vault": "ENC[foo]"}'
    result = decoder.decode(json_data)
    assert result == {"__ansible_vault": "foo"}



# Generated at 2022-06-23 04:43:56.578986
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib

    # Bunch of fake values by type
    fake_pairs = {
        'a_string': 'string',
        'an_integer': 0,
        'a_float': 0.0,
        'a_bool': False,
        'a_list': [],
        'a_dict': {},
        'an_object': object(),
    }

    # Secret used to decrypt the vault string
    fake_secret = 'fake_secret'

    # Fake vault string
    fake_vault_string = "@7A0ej1$(WA"

    # Fake vaulted string
    fake_vaulted_string = fake_vault_string
    fake_vaulted_string = AnsibleVaultEncryptedUnicode(fake_vaulted_string)

# Generated at 2022-06-23 04:44:06.748764
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    if not hasattr(AnsibleJSONDecoder, '_vaults'):
        AnsibleJSONDecoder._vaults = {}

# Generated at 2022-06-23 04:44:14.404510
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(password='password')

    # replace the vault with a VaultLib
    obj_hooked = decoder.object_hook({'__ansible_vault': 'foo'})
    assert isinstance(obj_hooked, AnsibleVaultEncryptedUnicode)

    # the __ansible_unsafe attribute is the only one that is handled,
    # all the others are ignored
    obj_hooked = decoder.object_hook({'__ansible_unsafe': 'bar'})
    assert isinstance(obj_hooked, AnsibleUnsafeText)

# Generated at 2022-06-23 04:44:25.436358
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'hush'
    AnsibleJSONDecoder.set_secrets(secret)
    s = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256\n36303336656635346531613333306635643331623136346632316532353064333636636162353234\n66343831663033373566383538666433353364653834383937366435656564373236656437333637\n39613635373766653230653664666362626565306134366462333862663566656539663963323262\n336664393530643665386433\n"}'

# Generated at 2022-06-23 04:44:31.002866
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    # Check the object hook
    pairs = decoder.object_hook({"__ansible_vault": "fake_vault"})
    assert(isinstance(pairs, AnsibleVaultEncryptedUnicode))

    pairs = decoder.object_hook({"__ansible_unsafe": "fake_unsafe"})
    assert(pairs == wrap_var("fake_unsafe"))

# Generated at 2022-06-23 04:44:32.781360
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert jd.object_hook is not None

# Generated at 2022-06-23 04:44:40.914430
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class TestClass(object):
        def __init__(self):
            pass

    # Test A: Test if using __ansible_vault as key in pairs will
    # return an AnsibleVaultEncryptedUnicode object, which will
    # be used for AnsibleVaultEncryptedUnicode serialization.
    pairs = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'
    }
    assert isinstance(AnsibleJSONDecoder.object_hook(pairs), AnsibleVaultEncryptedUnicode) is True

    # Test B: Test if other keys in pairs, e.g. __ansible_unsafe
    # will be processed properly

# Generated at 2022-06-23 04:44:43.343417
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook != None


# Generated at 2022-06-23 04:44:55.413055
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:01.499712
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    s = str(json.dumps({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}, cls=AnsibleJSONEncoder))

    obj = json.loads(s, cls=AnsibleJSONDecoder)
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-23 04:45:16.720805
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:17.759450
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder()

# Generated at 2022-06-23 04:45:26.499491
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    when(VaultLib).decrypt(any).thenReturn(AnsibleVaultEncryptedUnicode('***'))
    decoder = AnsibleJSONDecoder()

    # decrypt doesn't work for class AnsibleVaultEncryptedUnicode
    assert (decoder.decode('{"__ansible_vault": "test"}') !=
            json.loads('{"__ansible_vault": "test"}'))



# Generated at 2022-06-23 04:45:38.495088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:45:50.261767
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert (AnsibleJSONDecoder.object_hook(json.loads('{"foo": "bar"}')) == {'foo': 'bar'})
    assert (AnsibleJSONDecoder.object_hook(json.loads('{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;user\ndata\n"}')) ==
            {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;user\ndata\n'})
    assert (AnsibleJSONDecoder.object_hook(json.loads('{"__ansible_unsafe": "user\ndata\n"}')) ==
            {'__ansible_unsafe': 'user\ndata\n'})


# Generated at 2022-06-23 04:46:02.447230
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:03.002803
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:46:09.390350
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # This test requires a Python version < 3.0
    if not hasattr(json.decoder, 'object_hook'):
        return

    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode('{"a": "b", "c": "d"}')
    assert decoded == {u'a': u'b', u'c': u'd'}


# Generated at 2022-06-23 04:46:18.236885
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_pair = decoder.object_hook({'__ansible_vault': 'test value'})
    assert test_pair == AnsibleVaultEncryptedUnicode('test value')

    test_pair = decoder.object_hook({'__ansible_unsafe': 'test value'})
    assert test_pair == wrap_var('test value')

    test_pair = decoder.object_hook({'test': 'test value'})
    assert test_pair == {'test': 'test value'}



# Generated at 2022-06-23 04:46:19.529252
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder([])

# Generated at 2022-06-23 04:46:30.557238
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_secret = 'test'
    test_value = '@test'
    test_dict = '{"__ansible_vault": "test"}'
    test_vault_dict = {"my_var1": test_value, "my_var2": 2}

    # verify that the vault lib is setup with the right secret
    AnsibleJSONDecoder.set_secrets(test_secret)

    # test for non vault encrypted text
    test_dict_json = json.loads(test_dict)
    assert(test_dict_json == {"__ansible_vault": "test"})

    # coverage for encrypted text
    test_vault_dict_json = json.loads(json.dumps(test_vault_dict), cls=AnsibleJSONDecoder)

# Generated at 2022-06-23 04:46:42.346132
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:42.970658
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:46:53.763863
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    pairs = {
        '__ansible_vault': 'AQAAAAEAAAD+AADpvx8OnAMHtgd5b5g5Fsv9n0iPeQ2aDGZn0iZp5xvx8OniAAAAAAA'
        'AAAAAAAB9iRc8o7Y+Yp1BZc1djhvA4wqdDn4QfQ2aGVsbG8gV29ybGQgV2FsdAAAAA==',
        '__ansible_unsafe': {'key': 'value'}
    }

    json_decoder = AnsibleJSONDecoder()
    pairs = json_decoder.object_hook(pairs)

    assert isinstance(pairs, dict)

# Generated at 2022-06-23 04:46:59.126210
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert json.loads('{}', cls=AnsibleJSONDecoder) == {}
    assert json.loads('{"__ansible_vault": "ansible"}', cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode('ansible')
    assert json.loads('{"__ansible_vault": "ansible"}', cls=AnsibleJSONDecoder).vault == VaultLib(secrets=[])
    assert json.loads('{"__ansible_unsafe": "ansible"}', cls=AnsibleJSONDecoder) == wrap_var('ansible')


# Generated at 2022-06-23 04:47:00.611058
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:47:09.696156
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Create an empty dict
    pairs = dict()
    # Add a key to dict, with value which has spaces
    pairs['test_key'] = 'test_value with space'

    # Create a instance of class AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()

    # Get the outcome of calling object_hook() on the dict
    out = decoder.object_hook(pairs)

    # Test the outcome
    assert out == pairs
    assert out['test_key'] == 'test_value with space'

# Generated at 2022-06-23 04:47:11.667805
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)


# Generated at 2022-06-23 04:47:12.999300
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None

# Generated at 2022-06-23 04:47:22.645802
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j = AnsibleJSONDecoder()

    assert j.object_hook(dict(__ansible_vault='$ANSIBLE_VAULT;1.1;AES256',))['__ansible_vault'].value == '$ANSIBLE_VAULT;1.1;AES256'
    assert j.object_hook(dict(__ansible_unsafe='$ANSIBLE_VAULT;1.1;AES256',))['__ansible_unsafe'].value == '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-23 04:47:35.241777
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup test
    AnsibleJSONDecoder.set_secrets(123)
    s = '{"foo": "bar"}'

    # Exercise
    result = AnsibleJSONDecoder().object_hook(json.loads(s))

    # Verify
    assert result['foo'] == 'bar'
    assert not isinstance(result['foo'], AnsibleVaultEncryptedUnicode)

    # Exercise
    s = '{"__ansible_vault": "foo"}'
    result = AnsibleJSONDecoder().object_hook(json.loads(s))

    # Verify
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # Exercise
    s = '{"__ansible_unsafe": "foo"}'
    result = AnsibleJSONDecoder().object_hook(json.loads(s))

    #

# Generated at 2022-06-23 04:47:43.181489
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:52.217395
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Testing with a simple string (unencrypted)
    test_string = '{"__ansible_unsafe": "simple_string"}'
    result = AnsibleJSONDecoder().decode(test_string)
    assert(result == 'simple_string')

    # Testing with a encrypted variable
    if AnsibleJSONEncoder.has_vault_secret():
        test_string = '{"__ansible_vault": "AQAoAFpBZnN3ZWsJbWsCP1sEAAAAAlpaNg+j7yPcMVC9XQ2g/F8Tv/ZJw=="}'
        result = AnsibleJSONDecoder().decode(test_string)
        assert(type(result) == AnsibleVaultEncryptedUnicode)

        # Testing with a encrypted variable when __ansible_

# Generated at 2022-06-23 04:47:55.437267
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'a'}) == AnsibleVaultEncryptedUnicode('a')

    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'b'}) == wrap_var('b')


# Generated at 2022-06-23 04:48:01.714989
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d1 = AnsibleJSONDecoder()
    test_data = {'__ansible_unsafe': 'VXNlIHRoaXMgd2l0aCBjYXV0aW9uIQ=='}
    ABC = d1.decode(test_data)
    assert ABC['__ansible_unsafe'] == 'Use this with caution!'

# Generated at 2022-06-23 04:48:06.727023
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    SECRET = ['test_secret', '1234567890']
    data = json.dumps({'__ansible_vault': 'test'}, cls=AnsibleJSONEncoder)
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(SECRET)

    assert decoder.decode(data) == {'__ansible_vault': 'test'}


# Generated at 2022-06-23 04:48:18.751960
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    if sys.version_info < (2, 7):
        # Python versions < 2.7 do not support ordered dictionaries
        import collections
        if not isinstance(dict, collections.OrderedDict):
            # Install the ordereddict backport
            import ordereddict
            sys.modules['collections'].OrderedDict = ordereddict.OrderedDict

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    decoder = AnsibleJSONDecoder()
    secret = 'secret'
    password = 'password'
    AnsibleJSONDecoder.set_secrets({'default': password})

    # Test the __ansible_vault key case
    decoded_vault = decoder.object_hook({'__ansible_vault': secret})

# Generated at 2022-06-23 04:48:28.869014
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '{"__ansible_vault": "c2FtcGxlCg=="}'
    vault_password = "secret"
    secrets = [vault_password]

    # Set vault password
    AnsibleJSONDecoder.set_secrets(secrets)

    # Load JSON data
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_object_hook = ansible_json_decoder.object_hook(json_data)
    ansible_json_decoder.decode(json_data)

    # Get the vault password from the decoded object
    plaintext = getattr(ansible_object_hook, "vault_password", None)
    plaintext = getattr(plaintext, "password", None)

    assert plaintext

    # Get the plaintext of the value of

# Generated at 2022-06-23 04:48:38.035719
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    pairs = {"__ansible_unsafe": "This is unsafe", "__ansible_vault": "Encrypted vault"}
    # Test value should be different from pairs
    assert pairs != decoder.object_hook(pairs)
    # Test value should be instance of AnsibleVaultEncryptedUnicode and
    # AnsibleUnsafeText
    assert isinstance(decoder.object_hook(pairs).get("__ansible_vault"), AnsibleVaultEncryptedUnicode)
    assert isinstance(decoder.object_hook(pairs).get("__ansible_unsafe"), AnsibleUnsafeText)


# Generated at 2022-06-23 04:48:46.735245
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])
    simple_json = '''
    {
        "__ansible_vault": {\
          "encrypted_val": "noC/z/KZbOoL/eTP+RmfQ2l4mGKm4Yp9z0q3wsHkF48=",\
          "hash_val": "b3"\
        }\
    }'''
    pairs = decoder.decode(simple_json)
    assert isinstance(pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:48:51.956183
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '''{
    "__ansible_vault": "vault_encrypted_text"
}'''

    ansible_decoders = AnsibleJSONDecoder()
    ansible_decoders.set_secrets(secrets='test')

    assert isinstance(json.loads(data, cls=ansible_decoders), AnsibleVaultEncryptedUnicode)
    assert ansible_decoders._vaults['default'].secrets == 'test'

# Generated at 2022-06-23 04:49:03.037031
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    secrets = [{'vault_id': 'default', 'password': 'secret'}]
    AnsibleJSONDecoder.set_secrets(secrets)

    secret = {'one': 'two'}
    secret_vault = AnsibleVaultEncryptedUnicode.load(secret, password='secret')

    assert AnsibleJSONDecoder.object_hook({"__ansible_vault": secret_vault.vault.dump(secret)}) == {'one': 'two'}

    unsafe = "bar"

# Generated at 2022-06-23 04:49:04.307086
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:09.114239
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(dict())
    data = {"__ansible_vault": "foo"}
    ret = decoder.object_hook(data)
    assert ret['__ansible_vault'] == "foo"
    data = {"__ansible_unsafe": "{'a': 'b'}"}
    ret = decoder.object_hook(data)
    assert ret['__ansible_unsafe'] == "{'a': 'b'}"



# Generated at 2022-06-23 04:49:10.160878
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-23 04:49:17.761701
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'asdf'
    json_string = '''{
            "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible\\n39343835646161326133333133316366343637383361633732616232613837323035653263356366\\n3262646337313230373334613433313564393637333430396461343166616666393836353662646239\\n6336383338303665323435663435353166633235663331663933643962386264636362316132386332\\n36653330326534623831636436393564313864326236616432663338303366\\n"
    }'''

    Ansible

# Generated at 2022-06-23 04:49:29.182099
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    secrets = 'secret'
    AnsibleJSONDecoder.set_secrets(secrets)

    enc_obj_hook = AnsibleJSONEncoder()
    # enc_obj_hook.set_secrets(secrets)
    # vault_obj is the object of type AnsibleVaultEncryptedUnicode
    vault_obj = enc_obj_hook.object_hook(b'vault')

    obj_hook = AnsibleJSONDecoder()

    # Test when the key is '__ansible_vault'
    pairs = {'__ansible_vault': b'vault'}
    vault_json = json.dumps(pairs)
    obj = obj_hook.object_hook(json.loads(vault_json))
    # Check if the AnsibleVaultEncryptedUnicode object returned is of the same type as

# Generated at 2022-06-23 04:49:39.820772
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '''
{
  "example": {
    "__ansible_vault": "redacted",
    "__ansible_unsafe": "redacted"
  }
}
'''
    with open('test_json_data.json', 'w') as fileobj:
        fileobj.write(data)
    with open('test_json_data.json', 'r') as fileobj:
        json_data = json.load(fileobj)
        assert json_data['example'] == {'__ansible_vault': 'redacted',
                                        '__ansible_unsafe': 'redacted'}

        secrets = ['secretpassword']
        AnsibleJSONDecoder.set_secrets(secrets)
        json_data2 = json.load(fileobj, cls=AnsibleJSONDecoder)


# Generated at 2022-06-23 04:49:50.241188
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_decoder = AnsibleJSONDecoder()
    ansible_decoder.set_secrets(['s3cr3t'])

    # test the __ansible_unsafe variable
    json_string = '{"__ansible_unsafe": "{{ variable }}"}'
    python_dictionary = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert python_dictionary.ansible_unsafe == "{{ variable }}"

    # test the __ansible_vault variable
    json_string = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256"}'
    python_dictionary = json.loads(json_string, cls=AnsibleJSONDecoder)

# Generated at 2022-06-23 04:49:56.524695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-23 04:49:57.223435
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True

# Generated at 2022-06-23 04:49:58.619405
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_decoder = AnsibleJSONDecoder()
    assert test_decoder is not None


# Generated at 2022-06-23 04:50:07.563535
# Unit test for method object_hook of class AnsibleJSONDecoder