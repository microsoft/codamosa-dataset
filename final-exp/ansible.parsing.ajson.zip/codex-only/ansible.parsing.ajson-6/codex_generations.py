

# Generated at 2022-06-23 04:40:08.332671
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = dict(key='value')
    data = AnsibleJSONDecoder().object_hook(pairs)
    assert data == pairs

    pairs = dict(__ansible_vault='value')
    data = AnsibleJSONDecoder().object_hook(pairs)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is None
    assert data.data == 'value'

    pairs = dict(__ansible_unsafe='value')
    data = AnsibleJSONDecoder().object_hook(pairs)
    assert data == wrap_var(pairs)

# Generated at 2022-06-23 04:40:18.588019
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:29.750276
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:38.497838
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'my_secret'
    plain_data = dict(
        __ansible_vault=secret,
    )
    json_data = json.dumps(plain_data, cls=AnsibleJSONEncoder)

    vault = {}
    json_obj = json.loads(json_data, cls=AnsibleJSONDecoder, object_hook=AnsibleJSONDecoder.object_hook)
    assert isinstance(json_obj, AnsibleVaultEncryptedUnicode)

    json_obj.vault = VaultLib(secrets=[secret])
    assert json_obj == secret

# Generated at 2022-06-23 04:40:39.095073
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder()


# Generated at 2022-06-23 04:40:47.702466
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for __ansible_vault
    encrypted_str = '$ANSIBLE_VAULT;1.1;AES256\n3633356566643036396434376537303932613339653466386339336665353563396262623163623135\n393037396137313162396338613265666538646636373637343564613036643136630a656233343138\n3031383839316138363035366665326365663835386533343339393762323763613332343137616363\n3134666634356263323031376362656636313163313230333433363565653036\n'

# Generated at 2022-06-23 04:40:56.990219
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os

    secrets = [VaultSecret('default', password='mypass')]
    secrets[0]._load()

    path = os.path.dirname(os.path.abspath(__file__))
    content = VaultEditor._new_file(secrets, path=path)
    editor = VaultEditor(content, path=path)
    editor.vault.secrets = secrets
    editor.dump()

    # Testing the construct
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

# Generated at 2022-06-23 04:41:03.384156
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap
    decoder = AnsibleJSONDecoder()

    before = textwrap.dedent("""
        {
            "foo": "bar",
            "__ansible_vault": "encrypted string",
            "__ansible_unsafe": "unsafe string"
        }""").strip()
    after = AnsibleJSONDecoder().object_hook(json.loads(before))
    print(after)

if __name__ == '__main__':
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-23 04:41:15.604363
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    @decoder.object_hook
    def _object_hook(pairs):
        for key in pairs:
            value = pairs[key]
        return pairs

    # test AnsibleVaultEncryptedUnicode object
    vaulted = AnsibleVaultEncryptedUnicode('test')

    result = _object_hook({'__ansible_vault': vaulted})
    assert result == vaulted
    assert result.vault is None

    default_vault_lib = VaultLib(secrets=['test_pass'])
    decoder.set_secrets(default_vault_lib.secrets)

    result = _object_hook({'__ansible_vault': vaulted})
    assert result == vaulted
    assert result.vault == default_vault_lib



# Generated at 2022-06-23 04:41:28.987911
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    j_str = json.dumps(dict(a=5, b='hello', c={'1': 'world'}))
    j_obj = json.loads(j_str)
    assert j_obj  # sanity check

    # vault
    v_val = "vault_val"
    v_obj = json.loads(json.dumps(dict(__ansible_vault=v_val)))
    assert isinstance(v_obj, AnsibleVaultEncryptedUnicode)
    assert v_obj == v_val

    # unsafe
    u_val = "unsafe_val"
    u_obj = json.loads(json.dumps(dict(__ansible_unsafe=u_val)))
    assert isinstance(u_obj, wrap_var)
    assert u_obj == u_val

    #

# Generated at 2022-06-23 04:41:31.914323
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    assert decoder._vaults['default']

# Generated at 2022-06-23 04:41:43.568293
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Prepare test data
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secret = VaultSecret('my_secret')
    vault_secret.filename = 'testvault_filename'
    vault_secret.password = 'testvault_password'
    vault_secret.vault_id = 'testvault_id'

    AnsibleJSONDecoder.set_secrets(['my_secret'])

    # Create AnsibleJSONDecoder instance
    decoder = AnsibleJSONDecoder()

    # Test AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 04:41:46.232506
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=None)
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-23 04:41:57.625382
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Given
    decoder = AnsibleJSONDecoder()
    data = {"nested_dict": {"__ansible_vault": "nested_dict"}, "__ansible_vault": "dict"}

    # When
    decoded = json.loads(json.dumps(data), cls=AnsibleJSONDecoder)

    # Then
    assert isinstance(decoded, dict)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['nested_dict']['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['__ansible_vault'].vault is None
    assert decoded['nested_dict']['__ansible_vault'].vault is None

# Generated at 2022-06-23 04:41:59.550883
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None


# Generated at 2022-06-23 04:42:15.498630
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['mysecret']
    AnsibleJSONDecoder.set_secrets(secrets)
    d = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:18.698114
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)


# Generated at 2022-06-23 04:42:25.965415
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:38.053163
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:42.702248
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'unsafe'}) == wrap_var('unsafe')

# Generated at 2022-06-23 04:42:51.468838
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def object_hook(pairs):
        for key in pairs:
            value = pairs[key]
            if key == '__ansible_vault':
                return AnsibleVaultEncryptedUnicode(value)
            elif key == '__ansible_unsafe':
                return wrap_var(value)
        return pairs

# Generated at 2022-06-23 04:43:03.832100
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import AnsibleJSONDecoder
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({"__ansible_vault": "my secret string",
                                "__ansible_unsafe": "my unsafe string"}) == \
        {"__ansible_vault": AnsibleVaultEncryptedUnicode("my secret string"),
         "__ansible_unsafe": wrap_var("my unsafe string")}
    assert decoder.object_hook({"__ansible_vault": "my secret string"}) == {"__ansible_vault": AnsibleVaultEncryptedUnicode("my secret string")}

# Generated at 2022-06-23 04:43:10.164958
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.decode('"foo"') == "foo"

    decoder = AnsibleJSONDecoder(object_hook=None)
    assert decoder.decode('[{"__ansible_vault": "foo"}]') == [{"__ansible_vault": "foo"}]

    decoder = AnsibleJSONDecoder(object_hook=decoder.object_hook)
    assert decoder.decode('{"__ansible_unsafe": "foo"}') == {"__ansible_unsafe": "foo"}



# Generated at 2022-06-23 04:43:11.894511
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder() is not None


# Generated at 2022-06-23 04:43:13.638043
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, json.JSONDecoder)


# Generated at 2022-06-23 04:43:23.834023
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    test_list = [
        {
            "__ansible_vault": "vault_encrypted_data"
        },
        {
            "__ansible_unsafe": 1234
        }
    ]

    decoded_results = json.loads(json.dumps(test_list, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder)
    for pair in decoded_results:
        key = pair.keys()[0]
        if key == '__ansible_vault':
            assert(isinstance(pair[key], AnsibleVaultEncryptedUnicode))
        elif key == '__ansible_unsafe':
            assert(isinstance(pair[key], wrap_var))

# Generated at 2022-06-23 04:43:25.107416
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert type(a) is AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:32.917085
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # data without __ansible_vault and __ansible_unsafe
    data = {'foo': 'test'}
    assert AnsibleJSONDecoder().object_hook(data) == {'foo': 'test'}

    # data with __ansible_vault nd __ansible_unsafe
    data = {'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe'}
    assert AnsibleJSONDecoder().object_hook(data) == AnsibleVaultEncryptedUnicode('vault')



# Generated at 2022-06-23 04:43:44.840640
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Test __ansible_vault
    in_obj_dict = {'__ansible_vault': 'value'}
    exp_obj_dict = {'__ansible_vault': 'value'}
    exp_obj_dict['__ansible_vault'].vault = None
    out_obj_dict = decoder.object_hook(in_obj_dict)
    assert out_obj_dict.__class__ == dict
    assert out_obj_dict == exp_obj_dict

    # Test __ansible_unsafe
    # NOTE:
    #   At the moment we can't have tests for the wrap_var
    #   method in the AnsibleJSONDecoder class, because the
    #   module_utils/common/json.py doesn't have the module
   

# Generated at 2022-06-23 04:43:56.381326
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:02.497538
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_input = {
        "__ansible_unsafe": "{{ ansible_facts.ipv4.address }}"
    }
    json_output = {
        u'__ansible_unsafe': wrap_var('{{ ansible_facts.ipv4.address }}')
    }
    assert AnsibleJSONDecoder.object_hook(json_input) == json_output

# Generated at 2022-06-23 04:44:06.629383
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:12.222421
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    import json

    # This test is only valid if AnsibleJSONEncoder is used to encode
    # the object
    # Setup the object to encode and then decode

# Generated at 2022-06-23 04:44:24.306935
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:44:26.239193
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)


# Generated at 2022-06-23 04:44:33.976399
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def test(a, b):
        obj= {
            '__ansible_vault': 'value',
            '__ansible_test': 'value'
        }
        decoded_obj = AnsibleJSONDecoder.object_hook(obj)
        assert decoded_obj['__ansible_vault'] == AnsibleVaultEncryptedUnicode('value')
        assert decoded_obj['__ansible_test'] == 'value'

    test('test', 'b')

# Generated at 2022-06-23 04:44:41.608408
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():


    obj = '''{
        "__ansible_unsafe": {
            "test": {
                "test": 1
            }
        },
        "test": "test"
    }'''

    class TestSecrets(object):

        def __init__(self, secrets):
            self._secrets = secrets

        @property
        def vault_passwords(self):
            return self._secrets

    secrets = {'default': 'hi'}
    secrets = TestSecrets(secrets)
    AnsibleJSONDecoder.set_secrets(secrets)

    result = json.loads(obj, cls=AnsibleJSONDecoder)
    assert result['test'] == 'test'
    assert isinstance(result['__ansible_unsafe'], dict)

# Generated at 2022-06-23 04:44:44.991882
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    assert(d.object_hook)



# Generated at 2022-06-23 04:44:56.864131
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [ 'secret' ]
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder(object_hook=None)

    encrypted_text = AnsibleVaultEncryptedUnicode('!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          35653633623463336566383330663136653366393530663032316266396332396563306439323861\n          33346161306437313064653935646330623863363633316235636233376261377d\n          ', vault=decoder._vaults['default'])

    decrypted_text = AnsibleJSONDecoder.object_hook(decoder, encrypted_text)
    assert decrypted_

# Generated at 2022-06-23 04:45:06.720801
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_value = 'my secret'
    _secrets = [secret_value]
    AnsibleJSONDecoder.set_secrets(_secrets)

    # test object_hook with AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 04:45:17.988624
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for encrypted string
    secret_text = 'insecure_password'
    obj = {'__ansible_vault': secret_text}
    result = AnsibleJSONDecoder.object_hook(obj)
    assert result['__ansible_vault'] == secret_text
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    # Test for unsafe_proxy
    obj = {'__ansible_unsafe': secret_text}
    result = AnsibleJSONDecoder.object_hook(obj)
    assert result['__ansible_unsafe'] == secret_text
    assert result['__ansible_unsafe']._data == secret_text

    # Test for non-encrypted string
    obj = {'__ansible_vault': 'Not an encrypted string'}


# Generated at 2022-06-23 04:45:20.409137
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert isinstance(jd, json.JSONDecoder)

# Generated at 2022-06-23 04:45:32.584915
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # First we need to generate a VaultLib object.
    # We do this by using a dummy password.
    vault_lib = VaultLib()
    vault_lib.secrets = vault_lib.decrypt_file('./test/integration/vault_secret_file', password='secret')

    # Then we can create a decoder passing vault_lib to it.
    # We can now decode an VaultEncryptedUnicode.

    input = '''{
        "__ansible_vault": "encrypted data"
    }'''
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(vault_lib.secrets)
    output = decoder.decode(input)
    assert(type(output) == dict)

# Generated at 2022-06-23 04:45:41.498850
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # first test on decrypted data
    json_input = '{"thekey": "thevalue"}'
    assert AnsibleJSONDecoder().decode(json_input) == json.loads(json_input)

    # second test on encrypted data
    json_input = '{"__ansible_vault": "ansible-vault encrypt thevalue"}'
    assert AnsibleJSONDecoder.set_secrets(['secret'])
    out = AnsibleJSONDecoder().decode(json_input)
    assert isinstance(out['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert out['__ansible_vault'].vault.secrets == ['secret']
    assert str(out['__ansible_vault']) == 'thevalue'

    # third test on encrypted data without known password
   

# Generated at 2022-06-23 04:45:46.212107
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_data = '{"a": "b", "__ansible_unsafe": "c"}'
    expected = {'a': 'b', '__ansible_unsafe': wrap_var('c')}

    assert expected == AnsibleJSONDecoder().object_hook(json.loads(json_data))



# Generated at 2022-06-23 04:45:59.404498
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class FakeVaultLib(object):
        def is_encrypted(self, data):
            return False
        def decrypt(self, data):
            return data

    data = '{"foo":"bar"}'
    ansible_decoder = AnsibleJSONDecoder(encoding='ascii')
    ansible_decoder._vaults['default'] = FakeVaultLib()
    parsed = json.loads(data, cls=ansible_decoder.__class__)
    assert parsed == dict(foo="bar")


# Generated at 2022-06-23 04:46:08.099667
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "vault key"}'

    secret = 'vault key'
    json_decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secret)
    json_object = json_decoder.decode(json_str)
    assert json_object['__ansible_vault'] == 'vault key'
    assert json_object['__ansible_vault'].vault.secrets == ['vault key']



# Generated at 2022-06-23 04:46:09.878841
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert a is not None

# Generated at 2022-06-23 04:46:21.990427
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # __ansible_vault
    test_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test;test;test;test',
                 '__ansible_vault_test': 'test'}
    parsed_data = decoder.object_hook(test_data)
    assert isinstance(parsed_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # __ansible_unsafe
    test_data = {'__ansible_unsafe': '{{test}}'}
    parsed_data = decoder.object_hook(test_data)
    assert isinstance(parsed_data['__ansible_unsafe'], wrap_var)
    # not interesting
   

# Generated at 2022-06-23 04:46:33.366692
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test data:
    # 1. An AnsibleVaultEncryptedUnicode and an AnsibleUnsafeText
    # 2. A dictionary that includes 3 AnsibleVaultEncryptedUnicode,
    #    and an AnsibleUnsafeText
    # 3. A dictionary that includes a dictionary, and
    #    an AnsibleUnsafeText
    # 4. A normal dictionary
    test_data = {
        '__ansible_vault': 'test_value1',
        '__ansible_unsafe': 'test_value2'
    }

# Generated at 2022-06-23 04:46:34.470899
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:46:37.445589
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder
    x = AnsibleJSONDecoder()
    assert(isinstance(x, json.JSONDecoder))

# Generated at 2022-06-23 04:46:46.356161
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.tests import data_loader
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 04:46:56.691984
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for no vault in decoder
    decoder = AnsibleJSONDecoder()
    input_data = {"__ansible_vault": "super_secret", "other": "value"}

    output_data = decoder.object_hook(input_data)
    assert output_data['__ansible_vault'] == "super_secret"
    assert output_data['other'] == "value"

    # Test for  vault in decoder
    secrets = {"test_vault": "secret"}
    AnsibleJSONDecoder.set_secrets(secrets)
    output_data = decoder.object_hook(input_data)
    assert output_data['__ansible_vault'].vault == VaultLib(secrets=secrets)

    # Test for __ansible_unsafe

# Generated at 2022-06-23 04:46:59.231359
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test if the object_hook is set
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook


# Generated at 2022-06-23 04:46:59.828460
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:47:12.651755
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:13.233000
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:47:20.130593
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    l_json = '{"__ansible_vault": "my_password"}'
    AnsibleJSONDecoder.set_secrets('my_password')
    assert json.loads(l_json, cls=AnsibleJSONDecoder) == {'__ansible_vault': AnsibleVaultEncryptedUnicode('my_password')}
    l_json = '{"__ansible_unsafe": "my_password"}'
    assert json.loads(l_json, cls=AnsibleJSONDecoder) == {'__ansible_unsafe': wrap_var('my_password')}

# Generated at 2022-06-23 04:47:31.302541
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """Test for decoding of ansible_vault
    """
    test_string = '''
    {
        "__ansible_vault": "hello"
    }
    '''

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['foo'])
    assert decoder.decode(test_string).__ansible_vault == 'hello'

    # with open(sys._getframe().f_code.co_filename, 'r') as f:
    #     print(decoder.decode(f))



# Generated at 2022-06-23 04:47:47.129073
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [u'123']
    with open('test_AnsibleJSONDecoder.json', 'rb') as f:
        content = json.load(f, cls=AnsibleJSONDecoder)
        assert type(content) == dict
        assert u'__ansible_vault' in content
        assert type(content[u'__ansible_vault']) == AnsibleVaultEncryptedUnicode
        assert type(content[u'__ansible_vault'].vault) == VaultLib
        assert u'__ansible_unsafe' in content
        assert type(content[u'__ansible_unsafe']) == dict
        assert u'dict_key' in content[u'__ansible_unsafe']

# Generated at 2022-06-23 04:47:48.639491
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder



# Generated at 2022-06-23 04:47:59.233070
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # this is a json encoded and encrypted vault string
    vault_string = '$ANSIBLE_VAULT;1.1;AES256\n63643034313363656135623762656635333461623538636661636533643736653438616362633037\n63316135316532353266626238336339396462313937366530373834366238653537643062363965\n366466396533\n'

    # this is the vault's password
    vault_password = 'myvaultpassword'

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(vault_password)

    # we set a vault protected key, value pair
    data = {'__ansible_vault': vault_string}

    # we

# Generated at 2022-06-23 04:48:06.814955
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    input_data = {'__ansible_vault': 'vault_value', '__ansible_unsafe': 'unsafe_value'}
    output_data = decoder.object_hook(input_data)
    assert isinstance(output_data,
                      AnsibleVaultEncryptedUnicode), "__ansible_vault does not produce an instance of AnsibleVaultEncryptedUnicode"
    assert isinstance(output_data,
                      AnsibleVaultEncryptedUnicode), "__ansible_unsafe does not produce an instance of AnsibleUnsafeText"

# Generated at 2022-06-23 04:48:10.809422
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ivars = dict(ansible_vault="test")
    decoder = AnsibleJSONDecoder()
    for v in decoder.object_hook(ivars):
        assert v == 'test'


# Generated at 2022-06-23 04:48:21.213705
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "foo"}'
    assert AnsibleJSONDecoder(object_hook=None).decode(json_str) == {u'__ansible_vault': u'foo'}
    assert AnsibleJSONDecoder()(json_str) == {u'__ansible_vault': u'foo'}

    json_str = '{"__ansible_unsafe": "foo"}'
    assert AnsibleJSONDecoder(object_hook=None).decode(json_str) == {u'__ansible_unsafe': u'foo'}
    assert AnsibleJSONDecoder()(json_str) == {u'__ansible_unsafe': u'foo'}

# Generated at 2022-06-23 04:48:28.800715
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    class MockVault(object):
        def __init__(self, secrets):
            self.secrets = secrets

    # Create fake vault object to load on the decoder
    mock_vault = MockVault(secrets=['secret'])

    d = AnsibleJSONDecoder(object_hook=None)
    assert d.object_hook is not None

    # Test setting vault object
    d.set_secrets(secrets=['secret'])
    assert d._vaults['default'] == mock_vault


# Generated at 2022-06-23 04:48:34.170188
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder_object = AnsibleJSONDecoder()

    assert decoder_object.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder_object.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')

# Generated at 2022-06-23 04:48:39.077350
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ["foo", "bar"]
    AnsibleJSONDecoder.set_secrets(secrets)
    assert(AnsibleJSONDecoder._vaults['default'].secrets == secrets)
    assert(AnsibleJSONDecoder._vaults['default'].is_initialized() == True)

# Generated at 2022-06-23 04:48:46.777849
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap
    secrets = ['foo']
    json_str = textwrap.dedent("""\
        {
            "__ansible_vault": "bar",
            "__ansible_unsafe": "baz"
        }""")
    expected_pairs = {
        '__ansible_vault': u'bar',
        '__ansible_unsafe': 'baz'
    }
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    decoded = json.loads(json_str, cls=decoder.__class__)
    assert decoded == expected_pairs, \
        "Expected {} but got {}".format(expected_pairs, decoded)

# Generated at 2022-06-23 04:48:52.294883
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    context = {
        '__ansible_vault': 'encrypted',
        '__ansible_unsafe': '__ansible_unsafe',
        'foo': 'bar'
    }
    output = AnsibleJSONDecoder.object_hook(context)
    assert isinstance(output['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert output['__ansible_unsafe'] == '__ansible_unsafe'
    assert output['foo'] == 'bar'



# Generated at 2022-06-23 04:49:03.078354
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test 1: decrypting unicode
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets('mypass')

# Generated at 2022-06-23 04:49:13.524279
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault":"$VAULT;1.1;AES256\n3533363733663937356664313134386465653964356238633164383033356438616232393339\n656638666630663565303239323861656564346365616238326234613036\n","__ansible_unsafe":"b\'shell_out(\\\'echo \\\"hi\\\"\\\')\'"}'

    value = AnsibleJSONDecoder().object_hook(json.loads(json_str))


# Generated at 2022-06-23 04:49:24.411472
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest

    class JSONDecoder(unittest.TestCase):

        vault_text = '$ANSIBLE_VAULT;1.2;AES256;ansible\n393636323065326538613037623461383735613033383937393538623933636530663835383331393133313331333533323133343330643432333134\n30646230386438343064396531633163613965316163323536396262343530343833616566643530666433633261353863646133623036643539313163\n6239613565356662363633396632343264663965366137363565386534633164373534653561303733396630'
        vault

# Generated at 2022-06-23 04:49:29.802254
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    def_secrets = ['defaultpwd']
    AnsibleJSONDecoder.set_secrets(secrets=def_secrets)
    ans_json_dec = AnsibleJSONDecoder()
    assert ans_json_dec._vaults['default'] == def_secrets

# Generated at 2022-06-23 04:49:31.454356
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:49:36.707917
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_secret = '{"__ansible_vault": "vault_value"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets('password')
    result = ansible_json_decoder.decode(json_secret)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:49:42.944209
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data1 = {'__ansible_vault': b'foo'}
    assert AnsibleJSONDecoder().object_hook(data1) == AnsibleVaultEncryptedUnicode(b'foo')

    data2 = {'__ansible_unsafe': 'foo'}
    assert AnsibleJSONDecoder().object_hook(data2) == wrap_var('foo')

# Generated at 2022-06-23 04:49:55.162195
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:50:04.692355
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_dict = {'test_key': 'test_value'}
    assert AnsibleJSONDecoder().object_hook(test_dict) == {'test_key': 'test_value'}

    test_dict_with_safe = {'test_key': 'test_value', '__ansible_unsafe': 'unsafe_value'}
    assert AnsibleJSONDecoder().object_hook(test_dict_with_safe) == {'test_key': 'test_value',
                                                                     '__ansible_unsafe': 'unsafe_value'}

    test_dict_with_vault = {'test_key': 'test_value', '__ansible_vault': 'vault_value'}