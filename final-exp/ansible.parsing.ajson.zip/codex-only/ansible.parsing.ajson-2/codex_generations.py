

# Generated at 2022-06-23 04:40:08.533256
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test case 1: plain data.
    assert {} == AnsibleJSONDecoder().object_hook({})

    # Test case 2: data contains AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import wrap_var

    value = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;aaaa\naaaaaaaaaaa...'}
    obj = AnsibleJSONDecoder().object_hook(value)
    assert AnsibleVaultEncryptedUnicode == obj.__class__
    assert VaultLib == obj.vault.__class__

    # Test case 3: data contains __ansible_uns

# Generated at 2022-06-23 04:40:18.776291
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:29.986273
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:30.900332
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert a

# Generated at 2022-06-23 04:40:38.989013
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    text = '{"__ansible_vault": "c2VjcmV0Cg=="}'
    d = AnsibleJSONDecoder()
    assert isinstance(d.decode(text), AnsibleVaultEncryptedUnicode)

    text = '{"__ansible_unsafe": "password"}'
    d = AnsibleJSONDecoder()
    assert isinstance(d.decode(text), wrap_var)

    text = '{"foo": "bar"}'
    d = AnsibleJSONDecoder()
    assert isinstance(d.decode(text), dict)

# Generated at 2022-06-23 04:40:47.671933
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        json.loads(json.dumps({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;bob\nVVQ0b2xGQzlibm5XeEV5aEJUNVAyTEJ0Q2N3SFNqbGV4TWg4dWxZRFlVRFpIZz09\nCg==\n'}), cls=AnsibleJSONDecoder, encoding='utf-8')
    except AttributeError as e:
        assert("_vaults" in str(e))
    else:
        assert("_vaults" in str(e))


# Generated at 2022-06-23 04:40:56.718223
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class MockVaultLib:
        def __init__(self):
            self.secrets = ['foo', 'bar']

    mock_valt = MockVaultLib()
    j = '{"__ansible_vault": "AQABAIKkisY=", "__ansible_unsafe": "unsafe"}'
    AnsibleJSONDecoder.set_secrets(['foo', 'bar'])
    output = AnsibleJSONDecoder().object_hook(json.loads(j))
    assert(output['__ansible_vault'] == 'AQABAIKkisY=')
    assert(output['__ansible_unsafe'] == 'unsafe')
    assert(output['__ansible_vault'].vault.secrets == ['foo', 'bar'])

# Generated at 2022-06-23 04:41:04.153708
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import traceback
    import yaml

    class MyAnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        def __repr__(self):
            return "%s" % self._chunks[0]
    AnsibleVaultEncryptedUnicode = MyAnsibleVaultEncryptedUnicode

    class MyVaultLib(VaultLib):
        def __init__(self, vault_password=None, **kwargs):
            super(MyVaultLib, self).__init__(vault_password=vault_password, **kwargs)

        def decrypt(self, vdata):
            return vdata
    VaultLib = MyVaultLib

    class MyWrapVar(wrap_var):
        def __repr__(self):
            return "%s" % self._value


# Generated at 2022-06-23 04:41:09.307334
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # case -1, __ansible_vault is empty string
    pairs = {'__ansible_vault': ''}
    # set a dummy vault so AnsibleVaultEncryptedUnicode.vault is not None
    AnsibleJSONDecoder.set_secrets('dummy vault')
    ansible_vault_obj = AnsibleJSONDecoder().object_hook(pairs)
    assert isinstance(ansible_vault_obj, AnsibleVaultEncryptedUnicode)
    assert ansible_vault_obj.vault

    # case -2, __ansible_vault is not empty string
    pairs = {'__ansible_vault': 'not empty'}
    ansible_vault_obj = AnsibleJSONDecoder().object_hook(pairs)

# Generated at 2022-06-23 04:41:10.195186
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder



# Generated at 2022-06-23 04:41:22.351448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import types

    d = {'__ansible_vault': 'foo'}
    r = AnsibleJSONDecoder().object_hook(d)
    assert isinstance(r, AnsibleVaultEncryptedUnicode)
    assert r.vault is None
    assert len(r.vault.secrets) == 0

    d = {'__ansible_vault': 'foo'}
    AnsibleJSONDecoder.set_secrets(['secret'])
    r = AnsibleJSONDecoder().object_hook(d)
    assert isinstance(r, AnsibleVaultEncryptedUnicode)
    assert isinstance(r.vault, VaultLib)
    assert isinstance(r.vault.secrets, types.ListType)
    assert len(r.vault.secrets) == 1


# Generated at 2022-06-23 04:41:27.928151
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Create an instance of the class AnsibleJSONDecoder
    ansible_json_decoder = AnsibleJSONDecoder()

    # assert to test the value of class variable 
    # and we expect the value of class variable 
    # to be None
    assert str(ansible_json_decoder._vaults) == '{}'


# Generated at 2022-06-23 04:41:39.529551
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:42.030574
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    assert decoder.object_hook == decoder.object_hook

# Generated at 2022-06-23 04:41:49.315502
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    ret = decoder.object_hook({})
    assert ret == {}

    ret = decoder.object_hook({'__ansible_unsafe': 'unsafe'})
    assert ret == 'unsafe'

    ret = decoder.object_hook({'__ansible_vault': 'vault'})
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-23 04:42:00.204144
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = AnsibleJSONDecoder(encoding='utf-8')

# Generated at 2022-06-23 04:42:03.633741
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = AnsibleJSONDecoder()
    obj.set_secrets(secrets=['hello'])
    assert obj._vaults['default'] is not None

# Generated at 2022-06-23 04:42:17.815751
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:25.482539
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    import json
    import textwrap

    vault = VaultLib([('default', 'password')])
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([('default', 'password')])

    assert decoder.decode(
        json.dumps({'__ansible_unsafe': {'secret': 'value'}})
    ) == {'__ansible_unsafe': {'secret': 'value'}}

    result = decoder.decode(
        json.dumps({
            '__ansible_vault': vault.encrypt(json.dumps('from_vault').encode('utf-8')).decode('utf-8')
        }))
    assert result['__ansible_vault'] == 'from_vault'

# Generated at 2022-06-23 04:42:35.705105
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert (
        json.dumps(json.loads('{"__ansible_vault": "dummy"}', cls=AnsibleJSONDecoder), cls=AnsibleJSONEncoder)
        == '{"__ansible_vault": "dummy"}'
    )
    assert (
        json.dumps(json.loads('{"__ansible_unsafe": "dummy"}', cls=AnsibleJSONDecoder), cls=AnsibleJSONEncoder)
        == '{"__ansible_unsafe": "dummy"}'
    )

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 04:42:45.215181
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:50.522828
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test no arguments
    ansible_json_decoder = AnsibleJSONDecoder()
    
    # Test arguments
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=ansible_json_decoder.object_hook)

if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:56.666713
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''Testing AnsibleJSONDecoder constructors'''
    decoder = AnsibleJSONDecoder()
    ansible_json_decoder = AnsibleJSONDecoder
    
    assert (type(decoder) == type(ansible_json_decoder)), 'AnsibleJSONDecoder type mismatch'

# Generated at 2022-06-23 04:43:02.330241
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_data = {'__ansible_vault': 'foo'}
    test_data2 = {'__ansible_unsafe': 'bar'}
    assert decoder.object_hook(test_data) == AnsibleVaultEncryptedUnicode('foo')
    assert decoder.object_hook(test_data2) == wrap_var('bar')

# Generated at 2022-06-23 04:43:10.992211
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "foo", "__ansible_unsafe": "bar"}
    string = "\\\\x00"

# Generated at 2022-06-23 04:43:15.373335
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder().__class__.__name__ == 'AnsibleJSONDecoder'

if __name__ == "__main__":
    test_AnsibleJSONDecoder()

# Generated at 2022-06-23 04:43:17.569412
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    value = decoder.object_hook({'__ansible_vault': 'test'})
    assert type(value) is AnsibleVaultEncryptedUnicode

    value = decoder.object_hook({'__ansible_unsafe': 'test'})
    assert type(value) is wrap_var

# Generated at 2022-06-23 04:43:26.649782
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def params(self):
            return {}

        def fail_json(self, **args):
            pass

        def exit_json(self, **args):
            pass

    # The key must be the same as defined in
    # ansible.constants.STRING_CONVERSION_ACTION_KEYS
    # if the key is not defined, the unsafe_proxy will not be handled
    # properly
    json_data = """
    {
        "__ansible_unsafe": ["test"]
    }
    """
    json_object = AnsibleJSONDecoder.set_secrets(None)

# Generated at 2022-06-23 04:43:38.735394
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Initialize Vault Object under test
    vault = VaultLib(secrets=['foo'])

    # Encrypted value
    text = vault.encrypt('foo')
    pairs = {'__ansible_vault': text}
    decoded_pairs = AnsibleJSONDecoder.object_hook(pairs)
    assert(isinstance(decoded_pairs, AnsibleVaultEncryptedUnicode))

    # Safe value
    pairs = {'__ansible_unsafe': 'foo'}
    decoded_pairs = AnsibleJSONDecoder.object_hook(pairs)
    assert(decoded_pairs == 'foo')

    # Safe value


# Generated at 2022-06-23 04:43:50.135679
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # json_str = '{"foo":"bar", "__ansible_vault": "1234", "__ansible_unsafe": "123"}'
    json_obj = {
        'foo': 'bar',
        '__ansible_vault': '1234',
        '__ansible_unsafe': '123'
    }
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets('ansible')
    json_obj_load = ansible_json_decoder.object_hook(json_obj)
    assert json_obj_load == {'foo': 'bar', '__ansible_vault': '1234', '__ansible_unsafe': '123'}


# Generated at 2022-06-23 04:44:01.957393
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class VaultDecoder:
        def __init__(self):
            self.secrets = ['myvaultsecret']
            self.passwords = {}

    classes = VaultDecoder()
    AnsibleJSONDecoder.set_secrets(classes.secrets)
    decoder = AnsibleJSONDecoder()

    # Assert that '__ansible_vault' string is converted to AnsibleVaultEncryptedUnicode.

# Generated at 2022-06-23 04:44:08.868563
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({}) == {}

    # vault
    secret = 'test-secret'
    decoder.set_secrets(secret)
    decoder = AnsibleJSONDecoder()
    output = decoder.object_hook({"__ansible_vault": "1"})
    assert isinstance(output, AnsibleVaultEncryptedUnicode)
    assert output.vault._secrets == secret
    assert output.data == "1"

    # unsafe
    unsafe = wrap_var(True)
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({"__ansible_unsafe": "1"}) == unsafe

# Generated at 2022-06-23 04:44:15.712331
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jstr = '{"__ansible_vault": "testvault"}'
    d = AnsibleJSONDecoder()
    data = d.decode(jstr)
    assert(type(data['__ansible_vault']) == AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:44:26.487479
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:36.772368
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = 'test_password'
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-23 04:44:47.079760
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class AnsibleVaultEncryptedUnicode_class(AnsibleVaultEncryptedUnicode):
        def __init__(self, value):
            super(AnsibleVaultEncryptedUnicode_class, self).__init__(value)
            self.value = value
            self.vault = None

    pairs_without_vault = {'__ansible_vault': 'password'}
    decoder = AnsibleJSONDecoder()
    value = decoder.object_hook(pairs_without_vault)
    assert isinstance(value, AnsibleVaultEncryptedUnicode_class)
    assert value.value == 'password'
    assert value.vault is None
    # If a vault exist for the decoder, then the object should be stored in this vault.
    AnsibleJSONDecoder._vaults

# Generated at 2022-06-23 04:44:53.388033
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ["password1", "password2"]
    AnsibleJSONDecoder.set_secrets(secrets)
    assert(AnsibleJSONDecoder(encoding="utf-8")._vaults == AnsibleJSONDecoder._vaults)
    assert(AnsibleJSONDecoder(encoding="utf-8")._vaults['default'].secrets == secrets)



# Generated at 2022-06-23 04:44:54.435823
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:09.483534
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoded = json.loads('{"__ansible_unsafe": "__ansible_unsafe__"}',
                         cls=AnsibleJSONDecoder)
    assert decoded == wrap_var('__ansible_unsafe__')
    # Check __ansible_unsafe__ is not json.loads-decoded
    decoded = json.loads('{"__ansible_unsafe": {"foo": "bar"}}',
                         cls=AnsibleJSONDecoder)
    assert decoded == {'__ansible_unsafe': '{"foo": "bar"}'}
    decoded = json.loads('{"__ansible_vault": "__VAULT__"}',
                         cls=AnsibleJSONDecoder)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:45:16.680605
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test case-1
    kwargs_test_case1 = {'object_hook': 'object_hook'}
    test_case1 = AnsibleJSONDecoder(kwargs_test_case1)
    assert test_case1.object_hook == 'object_hook'
    assert test_case1.parse_float is None
    assert test_case1.parse_int is None
    assert test_case1.parse_constant is None
    assert test_case1.strict is None

# Generated at 2022-06-23 04:45:25.809509
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import json
    import six

    # Verify that AnsibleJSONDecoder can be constructed
    if six.PY3:
        # Python 3.x
        assert isinstance(AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook), json.JSONDecoder)
    else:
        # Python 2.x
        assert isinstance(AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook), json.decoder.JSONDecoder)

# Generated at 2022-06-23 04:45:28.520176
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    x = "this is a test"
    y = AnsibleJSONEncoder().encode(x)

    z = AnsibleJSONDecoder().decode(y)
    assert z == x

# Generated at 2022-06-23 04:45:35.367378
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    assert decoder.object_hook == decoder.object_hook
    try:
        AnsibleJSONDecoder.set_secrets(['this_is_a_password_pairs'])
    except Exception:
        assert False
    assert decoder._vaults != {}
    assert decoder.object_hook == decoder.object_hook



# Generated at 2022-06-23 04:45:38.757905
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # SetStrictVersion(True)
    assert "__ansible_unsafe" not in str(AnsibleJSONDecoder)
    # SetStrictVersion(False)

# Generated at 2022-06-23 04:45:45.482622
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    Function to test object_hook of AnsibleJSONDecoder
    '''
    # Test Case 1: Check if object_hook properly decrypts an ansible vault encrypted string
    vault_password = 'test_pass'
    vault_secrets = [vault_password]

# Generated at 2022-06-23 04:45:53.272651
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode type
    test_vaulted_data = '$ANSIBLE_VAULT;1.2;AES256;foo\nbar=='
    secret_data = AnsibleJSONDecoder.object_hook({'__ansible_vault': test_vaulted_data})
    assert isinstance(secret_data, AnsibleVaultEncryptedUnicode)

    assert secret_data.vault

# Generated at 2022-06-23 04:45:57.234536
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''Unit test for constructor of class AnsibleJSONDecoder'''
    json_decoder = AnsibleJSONDecoder()
    ret = json_decoder.decode('{"__ansible_vault": "blah"}')
    assert ret == AnsibleVaultEncryptedUnicode('blah')
    ret = json_decoder.decode('{"__ansible_unsafe": "blah"}')
    assert ret == wrap_var('blah')

# Generated at 2022-06-23 04:46:06.278806
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    unsafe_values = {'__ansible_unsafe': 'test', '__test': 'test'}
    result = decoder.object_hook(unsafe_values)

    assert isinstance(result['__ansible_unsafe'], wrap_var), "The result of object_hook is not AnsibleUnsafeText"
    assert result['__ansible_unsafe'].value == 'test', "The unsafe value is not set in the result"

    vault_values = {'__ansible_vault': 'test', '__test': 'test'}
    result = decoder.object_hook(vault_values)


# Generated at 2022-06-23 04:46:13.860113
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    v = AnsibleVaultEncryptedUnicode("test")
    assert d.object_hook({'__ansible_vault': v}) == v
    assert d.object_hook({'__ansible_unsafe': "'test'"}) == "'test'"
    assert d.object_hook({'nothing': "test"}) == {'nothing': "test"}
    assert d.object_hook({'__ansible_vault': v, 'other': "test"}) == v

# Generated at 2022-06-23 04:46:25.597556
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 04:46:31.158737
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    decoded = AnsibleJSONDecoder().object_hook({'__ansible_unsafe': 'secret_value'})
    assert isinstance(decoded, AnsibleUnsafeText)
    assert isinstance(decoded.text, str)
    assert decoded.text == 'secret_value'

# Generated at 2022-06-23 04:46:41.188006
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    decoder = AnsibleJSONDecoder()
    vaulted_json = '{"__ansible_vault": "foo"}'
    unsafe_json = '{"__ansible_unsafe": "foo"}'
    assert isinstance(decoder.decode(vaulted_json)['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoder.decode(unsafe_json)['__ansible_unsafe'] == wrap_var('foo')

# Generated at 2022-06-23 04:46:42.392634
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

AnsibleJSONEncoder

# Generated at 2022-06-23 04:46:43.992175
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)



# Generated at 2022-06-23 04:46:50.718083
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj_str = '{"__ansible_vault": "test_ansible_vault"}'
    obj = json.loads(obj_str, cls=AnsibleJSONDecoder)
    assert isinstance(obj, dict)
    assert obj == {"__ansible_vault": u'test_ansible_vault'}

if __name__ == "__main__":
    import nose
    nose.run(defaultTest=__name__)

# Generated at 2022-06-23 04:46:59.287200
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['ansible'])

# Generated at 2022-06-23 04:47:12.183385
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # create a pair of key/value
    # key = __ansible_vault, value = *content*
    # key = __ansible_unsafe, value = *content*
    pairs = {'__ansible_vault': '*content*', '__ansible_unsafe': '*content*'}
    # create an instance of AnsibleJSONDecoder
    ansible_json_decoder = AnsibleJSONDecoder()
    # call object_hook method
    result_pairs = ansible_json_decoder.object_hook(pairs)
    # check if the value of the key __ansible_vault is encrypted
    assert isinstance(result_pairs['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    # check if the value of the key __ansible_unsafe is a wrapped

# Generated at 2022-06-23 04:47:17.358707
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = '{"__ansible_vault": "my_ansible_vault"}'
    result = AnsibleJSONDecoder().decode(test_data)
    assert isinstance(result, dict)
    assert result['__ansible_vault'] == 'my_ansible_vault'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:47:25.024442
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # This is a function so it can be run in both Python 2 and 3
    decoder = AnsibleJSONDecoder()

    # Test with empty dictionary
    assert decoder.object_hook({}) == {}

    # Test with dictionary containing vault item
    assert isinstance(decoder.object_hook({'__ansible_vault': None}), AnsibleVaultEncryptedUnicode)

    # Test with dictionary containing unsafe item
    assert isinstance(decoder.object_hook({'__ansible_unsafe': None}), dict)

# Generated at 2022-06-23 04:47:36.906870
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_str = b"""$ANSIBLE_VAULT;1.1;AES256
3363646331333964393030626665396334316236383438313265643534323261373164633431336
33364376393938646562620a61396332373236613561323131613662323363316431323030396534
63383730356661623234613435386565363966333965663565313064653061
"""
    text_str = b"""{"__ansible_vault": "%s"}""" % vault_str
    json_obj = AnsibleJSONDecoder.object_hook(json.loads(text_str))

# Generated at 2022-06-23 04:47:44.988566
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import os
    import tempfile

    def _test_decoder():
        # construct a runnable module
        module_name = tempfile.mktemp(prefix='ansible_module_')
        module_name = os.path.basename(module_name)
        test_module_path = tempfile.mktemp()
        test_module_path = os.path.basename(test_module_path)
        test_module_fd = open(test_module_path, 'w')
        test_module_fd.write("#!/usr/bin/python\nimport json\nprint(json.dumps({'a':1}))\n")
        test_module_fd.close()

        # construct a runnable playbook
        playbook_path = tempfile.mktemp()
        playbook_path = os.path.basename

# Generated at 2022-06-23 04:47:54.447435
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    def _t(obj, expected, secrets=None):
        # NOTE: we get the object back twice, once in object_pairs_hook and
        # once in the object_hook.
        obj = json.loads(json.dumps(obj, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder, object_pairs_hook=lambda x: x, strict=False)
        obj = json.loads(json.dumps(obj, cls=AnsibleJSONEncoder), cls=AnsibleJSONDecoder, object_pairs_hook=lambda x: x, strict=False)
        assert obj == expected


# Generated at 2022-06-23 04:47:59.524480
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['a', 'b', 'c']
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    assert decoder.object_hook == {'__ansible_vault': AnsibleVaultEncryptedUnicode, '__ansible_unsafe': wrap_var}
    assert isinstance(decoder, json.JSONDecoder)

# Generated at 2022-06-23 04:48:09.323022
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:48:10.220710
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:48:21.476483
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:48:32.834493
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import pytest

    def assert_valid_object_hook(pairs, expected):
        actual = AnsibleJSONDecoder().object_hook(pairs)
        assert expected == actual


# Generated at 2022-06-23 04:48:44.736866
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [b'ansible']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:48:53.683184
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Arrange
    secrets = "testing"
    test_encoded_string = '{"__ansible_vault": "encrypted_string"}'
    test_decoded_string = 'decrypted_string'

    # Act
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    decoded_string = decoder.decode(test_encoded_string)

    # Assert
    assert isinstance(decoded_string, dict)
    assert decoded_string.get('__ansible_vault') == test_decoded_string


# Generated at 2022-06-23 04:48:55.181469
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook

# Generated at 2022-06-23 04:49:03.158771
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class ObjectHookTest():
        pass

    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets('test')
    pairs = {'__ansible_vault': True, '__ansible_unsafe': True}
    value = ansible_json_decoder.object_hook(pairs)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.vault.secrets == 'test'
    assert value == True
    assert isinstance(pairs, ObjectHookTest)
    assert pairs.__ansible_unsafe == True


# Generated at 2022-06-23 04:49:13.871857
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:22.796802
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '''
    {
        "__ansible_vault": "dGVzdA==",
        "__ansible_unsafe": {"__ansible_no_log": true}
    }'''

    # given the above string, we should get a fancy object back
    result = AnsibleJSONDecoder(data, object_hook=AnsibleJSONDecoder.object_hook)
    assert result == {'__ansible_unsafe': {'__ansible_no_log': True}, '__ansible_vault': 'dGVzdA=='}

# Generated at 2022-06-23 04:49:28.616378
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [
        {'default': 'abcdefgh'},
    ]

    decoder = AnsibleJSONDecoder()
    assert not hasattr(decoder, '_vaults')

    decoder.set_secrets(secrets)
    assert hasattr(decoder, '_vaults')
    assert 'default' in decoder._vaults
    assert decoder._vaults['default'] is not None


# Generated at 2022-06-23 04:49:39.423960
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_value = 'test_secret_value'
    vault_id = 'test_vault_id'
    vault_password = 'test_vault_password'
    vault_password_file = 'test_vault_password_file'

    test_json = '{"__ansible_vault": "test_vault__ansible_vault", "__ansible_unsafe": "test_unsafe__ansible_unsafe"}'
    test_dic = {'__ansible_vault': 'test_vault__ansible_vault', '__ansible_unsafe': 'test_unsafe__ansible_unsafe'}

    # create the class object
    ansible_decoder = AnsibleJSONDecoder()

    # test the decode method

# Generated at 2022-06-23 04:49:50.202605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ["password1", "password2"]
    # secrets = [""]
    AnsibleJSONDecoder.set_secrets(secrets)
    # vault_string = b'$ANSIBLE_VAULT;1.1;AES256;default\n38313939653365646162353337356566393661303634306633633036313635303438396131643239\n63346231326262383564633562346365643538306134333836316232356565393561613538316561\n67343164323538353866386436666535303339383538393231386265643861646233326264326437\n32313865326163323330383935376563353139613531633463636

# Generated at 2022-06-23 04:49:57.141391
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [u"decrypted_secret"]
    AnsibleJSONDecoder.set_secrets(secrets)
    json_decoder = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "some_encrypted_value", "__ansible_unsafe": "some_value"}
    assert json_decoder.object_hook(pairs) == {"__ansible_vault": AnsibleVaultEncryptedUnicode("some_encrypted_value"), "__ansible_unsafe": wrap_var("some_value")}



# Generated at 2022-06-23 04:50:04.906893
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    enc = 'c2RzZGV2OiFkM2Q2NzA1ZmM0ZmVjZDkyMmMwYjNhYzA3ZWM5YmY5YWY5YjY5NjIxM2RiYjRiY2JhMzFjZGQ0ZGY2Y2Y='
    obj = '{"__ansible_vault": "%s"}' % enc
    dec = AnsibleJSONDecoder()
    dec.set_secrets([b'8HwWUdvzcU6FgWS1'])
    assert dec.decode(obj) == {'__ansible_vault': AnsibleVaultEncryptedUnicode(enc)}