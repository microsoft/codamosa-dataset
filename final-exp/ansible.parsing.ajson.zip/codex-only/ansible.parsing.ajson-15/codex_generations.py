

# Generated at 2022-06-23 04:40:06.747118
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    expected_dict = {
        '__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;',
        '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256;'
    }
    actual_dict = {
        '__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;',
        '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256;'
    }
    dec = AnsibleJSONDecoder()
    returned_dict = dec.object_hook(actual_dict)
    assert expected_dict == returned_dict


# Generated at 2022-06-23 04:40:14.482781
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [b'VaultPasswordKey']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

    # Test
    pairs = {'__ansible_vault': '12345'}
    result = decoder.object_hook(pairs)
    assert result.vault.secrets == secrets
    assert result == '12345'

    # Test
    pairs = {'__ansible_unsafe': '12345'}
    result = decoder.object_hook(pairs)
    assert result == '12345'

# Generated at 2022-06-23 04:40:19.030440
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    instance = AnsibleJSONDecoder()

    # Check the object type
    assert isinstance(instance, AnsibleJSONDecoder)
    # Check the init method
    assert isinstance(instance, json.JSONDecoder)

# Unit test to check the set_secrets method of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:23.623304
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # No error when no secrets are provided
    decoder = AnsibleJSONDecoder()

    # Load secrets when secrets are provided
    secrets = [b'password']
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:40:33.125716
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    x = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:40:42.129960
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-23 04:40:48.153361
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from json import loads
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import wrap_var
    loader = DataLoader()
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['itsasecret'])

    original_dict = dict(
        some_string='Hello World!',
        some_number=12345,
        some_unicode_string=u'\u2713',
        some_safe_string=wrap_var('Hello World!'),
        some_vault_string=loader.load_from_file('test/unit/vars/main.yml')['vault_string_plaintext'],
    )

# Generated at 2022-06-23 04:40:55.664890
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest

    # Test case 1: __ansible_vault exists and VaultLib is loaded
    data_in = {"__ansible_vault": "AQAAAAAAAAAA",
               "my_variable": "my_value"
               }

# Generated at 2022-06-23 04:41:01.124033
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    json_dict = {
        '__ansible_vault': '__ansible_vault__'
    }
    ansible_obj = decoder.object_hook(json_dict)
    # The decoder should return a AnsibleVaultEncryptedUnicode object
    assert isinstance(ansible_obj, AnsibleVaultEncryptedUnicode)
    # The AnsibleVaultEncryptedUnicode object should have a vault attribute which is a VaultLib object
    assert isinstanc

# Generated at 2022-06-23 04:41:04.708838
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, AnsibleJSONDecoder)
    assert hasattr(decoder, 'object_hook')
    assert decoder._vaults == {}
    assert isinstance(decoder._vaults, dict)

# Generated at 2022-06-23 04:41:09.306331
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    module = None
    pairs = {'__ansible_vault': 'encrypted text'}
    decoder = AnsibleJSONDecoder(object_hook=JSONDecoder.object_hook)
    assert isinstance(decoder.object_hook(module, pairs['__ansible_vault']), AnsibleVaultEncryptedUnicode) == True
    assert isinstance(decoder.object_hook(module, pairs), dict) == True



# Generated at 2022-06-23 04:41:15.028768
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    # The test succeeds if no exception is raised
    str = '{"__ansible_unsafe": "{{ my_password }}", "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n3532633466653636618162...\n"}'
    ansible_json_decoder.decode(str)


# Generated at 2022-06-23 04:41:17.332406
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder.__init__ is json.JSONDecoder.__init__

# Generated at 2022-06-23 04:41:25.203870
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_json_decoder = AnsibleJSONDecoder()
    test_dict = {'__ansible_vault':'test_text','__ansible_unsafe':'test_var'}
    ansible_json_decoder.object_hook(test_dict)
    assert test_dict['__ansible_vault'] == 'test_text'
    assert test_dict['__ansible_unsafe'] == 'test_var'


# Generated at 2022-06-23 04:41:29.505981
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import unittest

    test = unittest.TestCase()

    obj = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'asdf', '__ansible_unsafe': 'asdf'})
    test.assertTrue(isinstance(obj, AnsibleVaultEncryptedUnicode))
    test.assertEqual(obj, 'asdf')
    test.assertTrue(hasattr(obj, 'vault'))

    obj = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'asdf'})
    test.assertTrue(isinstance(obj, AnsibleVaultEncryptedUnicode))
    test.assertEqual(obj, 'asdf')
    test.assertFalse(hasattr(obj, 'vault'))

    obj = AnsibleJSON

# Generated at 2022-06-23 04:41:31.122430
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook

# Generated at 2022-06-23 04:41:34.151863
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test custom json decoder
    assert isinstance(json.loads('{"__ansible_vault": "foo"}', cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:41:37.622027
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Unit test to test functionality of class AnsibleJSONDecoder, method object_hook()

# Generated at 2022-06-23 04:41:49.932452
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import os
    import unittest
    import json
    sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
    from lib import ansible_json_decoder
    class TestSequenceFunctions(unittest.TestCase):
        decoder = ansible_json_decoder.AnsibleJSONDecoder()

# Generated at 2022-06-23 04:41:57.524844
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [u'p@ssw0rd']
    secrets_str = u'[u"p@ssw0rd"]'
    data_dict = {'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;\naaa',
                 '__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256;\naaa'}
    data = json.dumps(data_dict).encode('utf-8')
    data_raw = '{"__ansible_vault":"MTMxMjM0NTY3ODkwQUFBQUFBQUFBQUFB","__ansible_unsafe":"JW5vdCBhIHNlY3JldA=="}'

    # test object_hook method of class AnsibleJSONDecoder
    Ansible

# Generated at 2022-06-23 04:42:00.303055
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert json.loads('{"foo": "quux"}', cls=AnsibleJSONDecoder) == {"foo": "quux"}

# Generated at 2022-06-23 04:42:02.068538
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-23 04:42:03.267339
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Unit Test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-23 04:42:17.149433
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    enc = AnsibleJSONEncoder()
    dec = AnsibleJSONDecoder()
    enc_value = enc.encode({"__ansible_unsafe": "str"})
    dec_value = dec.decode(enc_value)
    assert dec_value['__ansible_unsafe'] == 'str'
    enc_value = enc.encode({"__ansible_vault": "str"})
    dec_value = dec.decode(enc_value)
    assert dec_value['__ansible_vault'] == 'str'
    assert dec_value['__ansible_vault'].vault is not None
    enc_value = enc.encode({"__ansible_vault": "str", "__ansible_unsafe": "str"})

# Generated at 2022-06-23 04:42:24.967339
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_str = json.dumps({'__ansible_unsafe': 'foo'})
    assert(json.loads(test_str, cls=AnsibleJSONDecoder).value == 'foo')

    test_str = json.dumps({'__ansible_vault': 'foo'})
    assert(json.loads(test_str, cls=AnsibleJSONDecoder).value == 'foo')



# Generated at 2022-06-23 04:42:33.356696
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {"ansible_facts": {"__ansible_vault": "vault_value"}}

    result = json.loads(
        json.dumps(obj),
        cls=AnsibleJSONDecoder,
        object_hook=AnsibleJSONDecoder.object_hook,
    )

    assert result['ansible_facts']['__ansible_vault'] == "vault_value"


# Generated at 2022-06-23 04:42:39.119940
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test'})
    assert d.data == 'test'

    d = AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'test'})
    assert d == wrap_var('test')

    d = AnsibleJSONDecoder.object_hook({'__unknown': 'test'})
    assert d == {'__unknown': 'test'}

# Generated at 2022-06-23 04:42:49.635248
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    input_data = '{"__ansible_vault": "value"}'
    expected_value = AnsibleVaultEncryptedUnicode(input_data)

    actual_value = AnsibleJSONDecoder().object_hook({'__ansible_vault': input_data})

    assert expected_value.vault is not None
    assert actual_value.vault is not None
    assert expected_value.vault.secrets == actual_value.vault.secrets

    # Add a vault to the decoder
    password = "my_password"
    vault = VaultLib(password)
    AnsibleJSONDecoder.set_secrets(vault.secrets)
    expected_value.vault = vault
    expected_value = expected_value.decrypt(password)

    actual_value = actual_value.decrypt(password)

# Generated at 2022-06-23 04:42:51.561998
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    result = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert result.object_hook == AnsibleJSONDecoder.object_hook

# Generated at 2022-06-23 04:42:57.229731
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder(object_hook = AnsibleJSONDecoder.object_hook).object_hook({
        '__ansible_vault': 'test'
        }) == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-23 04:43:03.762457
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    obj = decoder.object_hook({'__ansible_vault': 'xyz', '__ansible_unsafe': 'abc'})
    assert isinstance(obj, dict)
    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_unsafe'], dict)
    assert obj['__ansible_unsafe']['data'] == 'abc'



# Generated at 2022-06-23 04:43:10.093080
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.parse_string('{"__ansible_vault": "V2FsdHlDcmVhdGVkQnlBbnNpYmxlCg=="}') == {'__ansible_vault': AnsibleVaultEncryptedUnicode('V2FsdHlDcmVhdGVkQnlBbnNpYmxlCg==')}
    assert decoder.parse_string('{"__ansible_unsafe": "dangerous"}') == {'__ansible_unsafe': wrap_var('dangerous')}

# Generated at 2022-06-23 04:43:13.762471
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;user;1234567890'}
    assert AnsibleJSONDecoder.object_hook(d) == d



# Generated at 2022-06-23 04:43:24.935332
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    json_string = """
    {
        "key": "value",
        "key2": "value2"
    }
    """
    json_object = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert json_object['key'] == 'value'
    assert json_object['key2'] == 'value2'

    json_string = """
    {
        "key": "value",
        "__ansible_vault": "test"
    }
    """
    json_object = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert json_object['key'] == 'value'
    assert isinstance(json_object['__ansible_vault'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:43:37.158705
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import sys
    import re
    import six
    import unittest
    import shutil

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleJSONDecoder(unittest.TestCase):
        vault_file = 'test/sanity/vault/test.yml'
        vault_password_file = 'test/integration/vault/.vault_pass.txt'
        vault_password = None

        def setUp(self):
            self.vault_password = to_text(open(self.vault_password_file, 'rb').read().rstrip())
            self.vault

# Generated at 2022-06-23 04:43:48.733638
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test with secrets, which is necessary for AnsibleJSONDecoder to decode an __ansible_vault key
    secrets = 'my_secret'
    ajd = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    ajd.set_secrets(secrets)

    # Test with a dictionary that has only primitive types
    a = {'a': 'b', 'c': 3}
    b = json.dumps(a, cls=AnsibleJSONEncoder)
    c = json.loads(b, cls=AnsibleJSONDecoder)
    assert a == c

    # Test with a dictionary that has __ansible_vault and __ansible_unsafe

# Generated at 2022-06-23 04:43:56.677893
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s = '''
{
    "__ansible_unsafe": "{{ lookup('pipe', 'echo password') }}",
    "__ansible_vault": "vault_test"
}
'''
    j = json.loads(s, cls=AnsibleJSONDecoder)
    assert isinstance(j, dict)
    assert len(j) == 2
    secrets = ['vault_test']
    AnsibleJSONDecoder.set_secrets(secrets)
    assert j['__ansible_vault'].vault.secrets == secrets


# Generated at 2022-06-23 04:44:06.823425
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    json_str1 = '{"__ansible_unsafe":"${file(/etc/shadow)}"}'
    decoder = AnsibleJSONDecoder()
    rtn = decoder.decode(json_str1)
    assert rtn['__ansible_unsafe'] == wrap_var('${file(/etc/shadow)}')


# Generated at 2022-06-23 04:44:08.175759
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder


# Generated at 2022-06-23 04:44:16.197776
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    vault = VaultLib('supersecret')

# Generated at 2022-06-23 04:44:26.774553
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import types
    import unittest

    # FIXME: provide proper unit tests
    class AnsibleJSONDecoderTests(unittest.TestCase):
        def test_object_hook(self):
            from ansible.parsing.vault import VaultLib
            from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

            # Test for vault

# Generated at 2022-06-23 04:44:37.030145
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:44:40.454626
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256"}'
    o = AnsibleJSONDecoder(s)

    assert isinstance(o, AnsibleJSONDecoder)

# Generated at 2022-06-23 04:44:50.260776
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import copy, types

    # Prepare objects for test
    str_template = ''  # string template for assert
    test_object = {}
    test_object_ansible_vault = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    test_object_ansible_unsafe = {'__ansible_unsafe': '<strong>foo</strong>'}

    # Without ansible_vault or ansible_unsafe
    str_template = '{"foo": "bar"}'
    res = AnsibleJSONDecoder().object_hook(copy.deepcopy(test_object))
    assert str(res) == str_template

    # With ansible_vault

# Generated at 2022-06-23 04:45:00.553020
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class TestAnsibleJSONDecoder(AnsibleJSONDecoder):
        def object_hook(self, pairs):
            return pairs

    # Test object_hook, __ansible_vault and __ansible_unsafe
    json_data = '{"__ansible_vault": "!!! VAULT !!!", "__ansible_unsafe": "!!! UNSAFE !!!"}'
    decoder = TestAnsibleJSONDecoder()
    decode_data = decoder.decode(json_data)
    assert decode_data['__ansible_vault'] == "!!! VAULT !!!"
    assert decode_data['__ansible_unsafe'] == "!!! UNSAFE !!!"



# Generated at 2022-06-23 04:45:08.401499
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    text = """
        {
            "__ansible_vault": "abcdef==",
            "__ansible_unsafe": "abcdef=="
        }
    """

    # set _vaults as empty dict, and vault is uninit
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets=[])
    ret = decoder.decode(text)
    assert isinstance(ret['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert ret['__ansible_vault'].vault is None
    assert isinstance(ret['__ansible_unsafe'], wrap_var)
    assert ret['__ansible_unsafe'].value == 'abcdef=='

    # set _vaults as not empty dict, and vault is init
    decoder

# Generated at 2022-06-23 04:45:19.601079
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """Test AnsibleJSONDecoder.object_hook

    Args:
        test_name (str): name of test
        input_text (str): text to be decode
        expected_result (str): expected decoded value
    """
    # pylint: disable=W0613

    # Declare test
    def ansible_json_decoder_object_hook_test(test_name, input_text, expected_result):
        decoded_value = json.loads(input_text, cls=AnsibleJSONDecoder)
        assert decoded_value == expected_result

    # Run test

# Generated at 2022-06-23 04:45:28.735285
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Initialize the class with the default settings
    encoder = AnsibleJSONDecoder()

    # Create a dummy value and a string to hold the JSON that is to be decoded
    dummy_value = AnsibleJSONEncoder().encode('value')
    json_string = '{"__ansible_unsafe": "%s"}' % dummy_value

    # Decode the JSON string, evaluate the result and compare
    decoded_value = encoder.decode(json_string)
    assert eval(decoded_value['__ansible_unsafe']) == 'value'

# Generated at 2022-06-23 04:45:31.923770
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '''{"__ansible_vault": "str"}'''
    assert type(json.loads(json_data, cls=AnsibleJSONDecoder)) == AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 04:45:34.311004
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert hasattr(AnsibleJSONDecoder, 'object_hook')

# Generated at 2022-06-23 04:45:38.700786
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import json
    decoder = json.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    def get_hook():
        return decoder.object_hook

    assert AnsibleJSONDecoder.object_hook == get_hook()

# Generated at 2022-06-23 04:45:50.459686
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'vault_test'})
    expected = AnsibleVaultEncryptedUnicode('vault_test')
    assert result == expected
    assert result._vault is None
    result = AnsibleJSONDecoder.set_secrets('123')
    assert result._vaults['default'].secrets == '123'
    result = AnsibleJSONDecoder().object_hook({'__ansible_vault': 'vault_test'})
    assert result._vault == result._vaults['default']
    result = AnsibleJSONDecoder().object_hook({'__ansible_unsafe': 'unsafe_test'})
    assert result == 'unsafe_test'

# Generated at 2022-06-23 04:45:55.039249
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '{"__ansible_vault": "test"}'
    decoder = AnsibleJSONDecoder()
    assert decoder.decode(json_data)['__ansible_vault'] == "test"


# Generated at 2022-06-23 04:46:05.094164
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {
        "default": "abcdefghijklmnop12345678"
    }
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

# Generated at 2022-06-23 04:46:09.623392
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder
    assert (type(decoder.object_hook) is type(AnsibleJSONDecoder.object_hook))
    assert (decoder.object_hook is AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-23 04:46:12.223534
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Test __init__()
    assert (isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder))



# Generated at 2022-06-23 04:46:23.972076
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Since we are not passing any parameter to AnsibleJSONDecoder,
    # vault dictionary in the class is empty.
    json_data = '{"a": "b"}'
    ansible_decoder = AnsibleJSONDecoder()

    assert ansible_decoder.decode(json_data) == json.loads(json_data)

    # After setting secrets and decrypting, vault dictionary has the secrets.
    secrets = ['password']
    ansible_decoder.set_secrets(secret=secrets)

    json_data = json.dumps({"__ansible_vault": "VGVzdA==\n", "__ansible_vault__password": "password"})
    ansible_json = ansible_decoder.decode(json_data)

    # Vault dictionary in the class is not empty after setting secrets.

# Generated at 2022-06-23 04:46:26.221469
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    json_str = '{"name": "james", "age": "12-year-old"}'
    decoder = AnsibleJSONDecoder(json_str)
    assert decoder.decode() == {u'age': u'12-year-old', u'name': u'james'}

# Generated at 2022-06-23 04:46:38.762021
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import datetime

    # Test with Vault Key
    raw_json = '{"__ansible_vault": "YW55IGNhcm5hbCBwbGVhcw=="}'
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoded_json = decoder.decode(raw_json)
    assert hasattr(decoded_json, 'vault')
    assert decoded_json.vault
    assert decoded_json.vault.decrypt(decoded_json) == "any carna basleas"
    assert json.dumps(decoded_json, cls=AnsibleJSONEncoder) == '{"__ansible_vault": "YW55IGNhcm5hbCBwbGVhcw=="}'

# Generated at 2022-06-23 04:46:40.619558
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    my_decoder = AnsibleJSONDecoder()
    assert isinstance(my_decoder, AnsibleJSONDecoder)

# Generated at 2022-06-23 04:46:41.474064
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONEncoder



# Generated at 2022-06-23 04:46:42.307630
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:53.140807
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import base64
    def base64decode(src):
        return base64.b64decode(src)

    class FakeClass(object):
        def __init__(self, password):
            self.password = password
    def set_secrets(secrets):
        return FakeClass('bogus')

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets = set_secrets
    decoder.base64decode = staticmethod(base64decode)


# Generated at 2022-06-23 04:47:00.808346
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:13.465538
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:16.473034
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    obj = {'__ansible_vault': 'foo'}
    j = AnsibleJSONDecoder()
    assert j.object_hook(obj) == AnsibleVaultEncryptedUnicode('foo')

# Generated at 2022-06-23 04:47:19.618938
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    encoded = json.dumps(dict(__ansible_unsafe="unsafe"), cls=AnsibleJSONEncoder)
    actual = json.loads(encoded, cls=AnsibleJSONDecoder)
    assert actual == wrap_var('unsafe')

# Generated at 2022-06-23 04:47:29.420040
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Validate that object_hook returns a dict
    json_data = json.dumps({"k": "__ansible_vault"})
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.decode(json_data), dict)

    # Validate that object_hook handles the __ansible_vault tag
    json_data = json.dumps({"k": "__ansible_vault"})
    decoder._vaults['default'] = VaultLib(secrets='password')
    decoded_data = decoder.decode(json_data)
    assert isinstance(decoded_data, dict) is True
    assert isinstance(decoded_data['k'], AnsibleVaultEncryptedUnicode) is True
    assert decoded_data['k'].vault == decoder._v

# Generated at 2022-06-23 04:47:34.998960
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoded = json.loads('{"test": "test"}', cls=AnsibleJSONDecoder)
    assert not hasattr(decoded, 'vault')
    assert not hasattr(decoded, 'secret')

    decoded = json.loads('{"__ansible_unsafe": "test"}', cls=AnsibleJSONDecoder)
    assert hasattr(decoded, 'vault')
    assert hasattr(decoded, 'secret')

    secrets = ['password']
    AnsibleJSONDecoder.set_secrets(secrets)

    decoded = json.loads('{"__ansible_vault": "test"}', cls=AnsibleJSONDecoder)
    assert hasattr(decoded, 'vault')
    assert isinstance(decoded.vault, VaultLib)

# Generated at 2022-06-23 04:47:42.963964
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    import sys

    class AnsibleJSONDecoder_object_hookUnitTests(unittest.TestCase):
        
        def test_decoder_hook_decodes_vault(self):
            test_json = '''{"__ansible_vault": "VjBUIlZiWEpZVlZKU0VXVFZiQkV5V0d0dllrVkpaVmhNU0VScmFuYg=="}'''
            test_secret = "this is a secret"
            self.assertIsInstance(AnsibleJSONDecoder.set_secrets(test_secret), VaultLib)
            expected_result = 'this is a secret'

# Generated at 2022-06-23 04:47:52.113747
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:56.326407
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "value", "__ansible_unsafe": "value"}
    result = decoder.object_hook(pairs)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(result['__ansible_unsafe'], AnsibleUnsafeText)



# Generated at 2022-06-23 04:47:58.174098
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = json.loads('{"foo": "bar"}', cls=AnsibleJSONDecoder)
    assert a.get('foo') == 'bar'

# Generated at 2022-06-23 04:47:58.892806
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder
    assert decoder._vaults == {}


# Generated at 2022-06-23 04:48:02.760819
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = ['4', '4', '4']
    data = '{"__ansible_vault": "4", "__ansible_unsafe": "4"}'
    decoder = AnsibleJSONDecoder.set_secrets(secret)
    decoder.decode(data)

# Generated at 2022-06-23 04:48:07.439144
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder, type)


# Generated at 2022-06-23 04:48:18.423855
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {"__ansible_vault": "secret"}
    value = decoder.object_hook(pairs)
    assert value.vault.secrets == [""]
    assert value.vault.secrets != ""
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value == "VaultPassword(AES256)$f75a341f9a63391db84bc5f7b5d5e3c7"
    pairs = {"__ansible_unsafe": "$VARIABLE"}
    value = decoder.object_hook(pairs)
    assert value.value == "$VARIABLE"
    assert isinstance(value, AnsibleUnsafeText)

# Generated at 2022-06-23 04:48:28.627426
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test __ansible_vault key
    pairs = {'__ansible_vault': 'vault_password_1'}
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)
    assert pairs['__ansible_vault'].vault.secrets == ['vault_password_1']

    # Test __ansible_vault key without secret
    pairs = {'__ansible_vault': 'vault_password_2'}
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)
    assert pairs['__ansible_vault'].vault.secrets == []

    # Test __ansible_unsafe key

# Generated at 2022-06-23 04:48:35.091227
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'foo'}) == AnsibleVaultEncryptedUnicode('foo')
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'foo', '__ansible_unsafe': 'bar'}) == dict(
        __ansible_vault=AnsibleVaultEncryptedUnicode('foo'),
        __ansible_unsafe=wrap_var('bar'))
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'bar', '__ansible_vault': 'foo'}) == dict(
        __ansible_vault=AnsibleVaultEncryptedUnicode('foo'),
        __ansible_unsafe=wrap_var('bar'))



# Generated at 2022-06-23 04:48:43.832298
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test cases
    # {'__ansible_vault': <AnsibleVaultEncryptedUnicode>}
    # {'__ansible_unsafe': <unsafeProxy>}
    # {}
    # {'hi': 1, 'hello': 2}

    x = AnsibleJSONDecoder()
    case1 = x.object_hook({'__ansible_vault': '1234567'})
    assert type(case1) == AnsibleVaultEncryptedUnicode
    case2 = x.object_hook({'__ansible_unsafe': '1234567'})
    assert type(case2) == dict
    case3 = x.object_hook(dict())
    assert type(case3) == dict
    case4 = x.object_hook({'hi': 1, 'hello': 2})
   

# Generated at 2022-06-23 04:48:46.619681
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert type(ansible_json_decoder) is AnsibleJSONDecoder


# Generated at 2022-06-23 04:48:57.183370
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"__ansible_vault": "encrypted", "plain": "text"}'
    secrets = [{'vault_password': 'encrypted_password'}]
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder.decode(data)
    assert decoder._vaults['default'] == VaultLib(secrets=secrets)
    assert decoder.object_hook({"test":{"__ansible_vault":"encrypted", "__ansible_unsafe":"safe"}}) == {'test': {'__ansible_vault': u'encrypted', '__ansible_unsafe': 'safe'}}

# Generated at 2022-06-23 04:49:04.200812
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # test for ansible_vault
    json_decoder = AnsibleJSONDecoder()
    test_dict = {'__ansible_vault': 'testvalue'}
    result = json_decoder.object_hook(test_dict)
    assert result == AnsibleVaultEncryptedUnicode('testvalue')


    # test for ansible_unsafe
    json_decoder = AnsibleJSONDecoder()
    test_dict = {'__ansible_unsafe': 'testvalue'}
    result = json_decoder.object_hook(test_dict)
    assert result == wrap_var('testvalue')

# Generated at 2022-06-23 04:49:13.890562
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Arrange
    kv1 = { '__ansible_vault': 'dummy_vault' }
    kv2 = { '__ansible_unsafe': 'dummy_unsafe' }
    kv3 = { 'k1': 'v1' }

    # Act
    v = AnsibleJSONDecoder().object_hook(kv1)
    v2 = AnsibleJSONDecoder().object_hook(kv2)
    v3 = AnsibleJSONDecoder().object_hook(kv3)

    # Assert
    # FIXME: object_hook should return an AnsibleVaultEncryptedUnicode object
    assert isinstance(v, str)
    assert isinstance(v2, str)
    assert isinstance(v3, dict)

# Generated at 2022-06-23 04:49:19.166537
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Assign 
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = "default"

    # Act
    default_vault = decoder._vaults['default']

    # Assert
    assert default_vault == "default"

# Generated at 2022-06-23 04:49:30.014921
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    e = AnsibleJSONEncoder()

    # Test that AnsibleJSONDecoder can successfully convert an encrypted string
    # output by AnsibleJSONEncoder.
    encrypted_text = e.encode(
        {'__ansible_vault': '0123456789', '__ansible_unsafe': '0123456789'}
    )
    decrypted_text = d.decode(encrypted_text)

    if not isinstance(decrypted_text['__ansible_vault'], AnsibleVaultEncryptedUnicode):
        raise AssertionError
    # Test that __ansible_unsafe successfully converted back to unicode
    if not isinstance(decrypted_text['__ansible_unsafe'], unicode):
        raise AssertionError

# Generated at 2022-06-23 04:49:34.144355
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # creating the instance of AnsibleJSONDecoder
    decoder = AnsibleJSONDecoder()

    # testing the type
    assert isinstance(decoder, json.JSONDecoder)
    assert isinstance(decoder, AnsibleJSONDecoder)



# Generated at 2022-06-23 04:49:38.410734
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder._vaults == {}

    AnsibleJSONDecoder.set_secrets(secrets=['secret'])
    assert AnsibleJSONDecoder._vaults['default'].secrets == ['secret']

# Generated at 2022-06-23 04:49:41.361630
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None



# Generated at 2022-06-23 04:49:43.228486
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({'__ansible_unsafe': 'teststring'}) == wrap_var('teststring')

    vault = AnsibleVaultEncryptedUnicode('teststring')
    assert decoder.object_hook({'__ansible_vault': 'teststring'}) == vault

# Generated at 2022-06-23 04:49:52.019831
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def test_assert_equal(val1, val2):
        assert val1 == val2

    def test_assert_not_equal(val1, val2):
        assert val1 != val2

    secrets = 'secret'
    AnsibleJSONDecoder.set_secrets(secrets)
    # test an encrypted value
    encrypted_val = '$ANSIBLE_VAULT;1.1;AES256;username\n32323232323232323232323232323232323232323232323232323232323232323\n'
    test_assert_equal(AnsibleJSONDecoder().decode(encrypted_val), AnsibleVaultEncryptedUnicode(encrypted_val))

    # test a wrapping value

# Generated at 2022-06-23 04:50:02.191496
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import tempfile
    import os

    from ansible.parsing.vault import VaultEditor

    class Vault():
        def __init__(self, secret):
            self._secrets = [secret]

        def unprotect(self, data):
            return data

    vault_secret = "vault_secret"
    var1 = '{"__ansible_vault": "vaulted_data", "__ansible_unsafe": "unsafe_data"}'
    var2 = '{"__ansible_vault": "vaulted_data"}'
    var3 = '{"__ansible_unsafe": "unsafe_data"}'
    var4 = '{"__ansible_vault": "vaulted_data1", "__ansible_vault": "vaulted_data2"}'