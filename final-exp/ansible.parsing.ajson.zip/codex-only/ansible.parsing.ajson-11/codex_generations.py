

# Generated at 2022-06-23 04:40:08.892692
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Decode input (AnsibleJSONEncoder.default)
    json_str = '{'\
            '"__ansible_vault":'\
                '{'\
                    '"encrypted_vault": "XXXXX", '\
                    '"version": 1, '\
                    '"cipher": "XXXXX", '\
                    '"salt": "XXXXX", '\
                    '"hmac": "XXXXX", '\
                    '"hmac_version": 1'\
                '}'\
            '}'
    decoder = AnsibleJSONDecoder()
    ansible_vault_obj = decoder.decode(json_str)
    # Note that object_hook has returned AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-23 04:40:12.741247
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret1', 'secret2', 'secret3']
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert decoder == 'default'
    assert secrets == ['secret1', 'secret2', 'secret3']

# Generated at 2022-06-23 04:40:23.864438
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [ '$ANSIBLE_VAULT;1.1;AES256',
                '33613334336535343662333239653165353638663965366635386262306535333633303638633235',
                '34333830633963356432363339356636333662643234616232383237653833383939366336396361',
                '38393639613735343466363061653935', '' ]
    AnsibleJSONDecoder.set_secrets(secrets)

    ansible_json_decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:40:25.901940
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder.__init__('AnsibleJSONDecoder') == None

# Generated at 2022-06-23 04:40:32.643879
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'testsecret'
    AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secret

    test_data = (
        '{"__ansible_vault": "testvault"}',
        '{"__ansible_unsafe": "testunsafe"}',
        '{"__ansible_vault": "testvault", "__ansible_unsafe": "testunsafe"}'
    )

    for t_data in test_data:
        assert json.loads(t_data, cls=AnsibleJSONDecoder)



# Generated at 2022-06-23 04:40:33.727848
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder


# Generated at 2022-06-23 04:40:42.444695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Case 1: (__ansible_vault, __ansible_unsafe) first
    decoder = AnsibleJSONDecoder()
    pairs = {u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;ansibleuser;test', 
             u'__ansible_unsafe': u'\u00a9\u2665\u2139'
            }
    expected = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256;ansibleuser;test')
    assert decoder.object_hook(pairs) == expected

# Generated at 2022-06-23 04:40:46.847089
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert json.JSONDecoder.__class__ == type(ansible_json_decoder)


# Generated at 2022-06-23 04:40:50.526984
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Ensure the constructor passes the parent class arguments
    json_decoder = AnsibleJSONDecoder(object_hook=lambda o: o, strict=False)
    assert json_decoder.object_hook is not None
    assert not json_decoder.strict

# Generated at 2022-06-23 04:40:53.719559
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    j = AnsibleJSONDecoder()
    assert isinstance(j, json.JSONDecoder)
    assert isinstance(j, AnsibleJSONDecoder)
    assert isinstance(j.object_hook, AnsibleJSONDecoder.object_hook)
    assert j.object_hook(None) == None


# Generated at 2022-06-23 04:40:54.472341
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:41:01.173477
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  import ansible.parsing.vault as vault
  from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
  from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-23 04:41:05.514077
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    error = False
    try:
        AnsibleJSONDecoder()
    except Exception as ex:
        print('\ntest_AnsibleJSONDecoder() failed. Exception msg: {0}'.format(ex))
        error = True
    finally:
        assert error is False

# Generated at 2022-06-23 04:41:06.265507
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert jd


# Generated at 2022-06-23 04:41:11.075160
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    secrets = ['password']
    AnsibleJSONDecoder.set_secrets(secrets)


# Generated at 2022-06-23 04:41:11.752554
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:41:12.128724
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:41:18.803526
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    v = decoder.object_hook({'__ansible_vault': 'test_secret'})
    assert v is not None
    assert isinstance(v, AnsibleVaultEncryptedUnicode)
    assert v.vault is None

    decoder.set_secrets(['not_the_secret'])
    v = decoder.object_hook({'__ansible_vault': 'test_secret'})
    assert v is not None
    assert isinstance(v, AnsibleVaultEncryptedUnicode)
    assert 'test_secret' not in str(v)
    assert '$ANSIBLE_VAULT' not in str(v)
    assert 'test_secret' in str(v.vault.decrypt(str(v)))

    decoder.set_sec

# Generated at 2022-06-23 04:41:31.122766
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import to_native

    decoder = AnsibleJSONDecoder()
    data = {'__ansible_vault': 'secret'}
    result = decoder.object_hook(data)

    test_obj = AnsibleVaultEncryptedUnicode('secret')
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert test_obj == result
    assert test_obj.vault == result.vault
    assert result.vault is None

    result = decoder.object_hook({'__ansible_unsafe': AnsibleVaultEncryptedUnicode('secret')})
    assert to_native(result)
    assert isinstance(result, str)  # FIXME: unsafe strings should be unicode

# Generated at 2022-06-23 04:41:42.705603
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

    # Test the object_hook function when one of the keys is __ansible_vault.
    # The value of '__ansible_vault' is replaced by an AnsibleVaultEncryptedUnicode object.
    ansible_json_decoder.secret = "secrets"
    test_dict = {"__ansible_vault": "vault_value"}
    assert isinstance(ansible_json_decoder.object_hook(test_dict), dict)
    assert isinstance(ansible_json_decoder.object_hook(test_dict)["__ansible_vault"],
                      AnsibleVaultEncryptedUnicode)

    # Test the object_hook function when one of the keys is __ansible_unsafe.
    # The value of '__ans

# Generated at 2022-06-23 04:41:44.834117
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # No error raised in constructor
    json.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)


# Generated at 2022-06-23 04:41:56.876238
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:12.655352
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test __init__
    obj = AnsibleJSONDecoder()
    assert obj._vaults == {}
    assert obj.object_hook == obj.object_hook
    assert obj.parse_array == json.decoder.JSONDecoder.parse_array
    assert obj.parse_constant == json.decoder.JSONDecoder.parse_constant
    assert obj.parse_float == json.decoder.JSONDecoder.parse_float
    assert obj.parse_int == json.decoder.JSONDecoder.parse_int
    assert obj.parse_object == json.decoder.JSONDecoder.parse_object
    assert obj.parse_string == json.decoder.JSONDecoder.parse_string
    assert obj.strict == json.decoder.JSONDecoder.strict
    assert obj.scan_once == json.scanner

# Generated at 2022-06-23 04:42:25.047968
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import unittest
    decoder = AnsibleJSONDecoder()

    # __ansible_vault
    json_string = '{"__ansible_vault": "x_unsafe"}'
    ansible_vault_object = decoder.decode(json_string)
    assert isinstance(ansible_vault_object, AnsibleVaultEncryptedUnicode)
    assert ansible_vault_object.vault is None
    assert ansible_vault_object == 'x_unsafe'

    # __ansible_unsafe
    json_string = '{"__ansible_unsafe": "x_unsafe"}'
    ansible_unsafe_object = decoder.decode(json_string)
    assert isinstance(ansible_unsafe_object, wrap_var)

# Generated at 2022-06-23 04:42:30.449958
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ad = AnsibleJSONDecoder()
    assert ad.decode('{"__ansible_unsafe": "unsafe"}') == wrap_var('unsafe')
    assert ad.decode('{"__ansible_vault": "vault"}') == AnsibleVaultEncryptedUnicode('vault')
    assert ad.decode('{"key": "value"}') == { "key": "value" }
    assert ad.decode('[1,2]') == [1,2]



# Generated at 2022-06-23 04:42:40.598338
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:43.961300
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder()
    assert hasattr(d, '_vaults')
    assert d._vaults == {}
    assert d.object_hook == d._object_hook



# Generated at 2022-06-23 04:42:51.065434
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = {"baz": "qux", "foo": "bar", "spam": "eggs", "__ansible_vault": "foo"}
    try:
        decoded = json.loads(json.dumps(d), cls=AnsibleJSONDecoder)
    except TypeError as e:
        raise AssertionError('json.loads() raised TypeError unexpectedly: {}'.format(e))
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode), \
        'Unexpected type of loaded AnsibleVaultEncryptedUnicode: {}'.format(type(decoded['__ansible_vault']))

# Generated at 2022-06-23 04:43:03.466512
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_secret = 'password'

    # test with no argument passed
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(vault_secret)

    # test with a secret passed
    obj = {'unicode_string': u'\u2713', 'regular_string': 'string', 'int': 1, 'float': 10.0, 'list': [0, "a"], 'dict': {'a': 'a'}}
    json_string = encoder.encode(obj)
    #print(json_string)

# Generated at 2022-06-23 04:43:11.811857
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils.six import PY3
    import sys

    # Python 2 requires a "u" prefix before strings
    # and python 3 requires a "b" prefix before strings.
    # With the 3.6 series, "u" is removed and
    # a "u" prefix is no longer accepted.
    if PY3:
        prefix = 'b'
    else:
        if sys.version_info < (3, 6):
            prefix = 'u'
        else:
            prefix = ''

    d = AnsibleJSONDecoder()
    o = '''{
        "__ansible_vault": "%s%s",
    }''' % (prefix, 'test\n')
    j = json.loads(o, cls=d.__class__)

# Generated at 2022-06-23 04:43:22.565569
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:27.397259
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [{'vault_password': 'SuperSecretPassword'}]
    decoder = AnsibleJSONDecoder.set_secrets(secrets)

    test_value = {'test_key': 'test_value'}
    test_unsafe = {'__ansible_unsafe': test_value}

    decoded = json.loads(json.dumps(test_unsafe), cls=AnsibleJSONDecoder)

    assert decoded == wrap_var(test_value)


# Generated at 2022-06-23 04:43:39.455227
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:43:48.962689
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''Unit test for method object_hook of class AnsibleJSONDecoder'''
    from ansible.module_utils.basic import ArgumentSpec

    secrets = ["hello", "world"]
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=secrets)

    INPUT_JSON = '''
    {
        "__ansible_vault": "123456"
    }'''

    decoded_dict = decoder.decode(INPUT_JSON)
    assert isinstance(decoded_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode) is True
    assert decoded_dict['__ansible_vault'] == "123456"


# Generated at 2022-06-23 04:44:00.095702
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # With __ansible_unsafe in input
    json_str = '{"__ansible_unsafe": "{{ lookup(\'pipe\', \'whoami\') }}"}'
    decoded = AnsibleJSONDecoder().decode(json_str)
    assert decoded == {'__ansible_unsafe': u"{{ lookup('pipe', 'whoami') }}"}
    assert not isinstance(decoded, dict)
    assert not isinstance(decoded['__ansible_unsafe'], basestring)

    # Without __ansible_unsafe in input
    json_str = '{"key": "val"}'
    decoded = AnsibleJSONDecoder().decode(json_str)
    assert decoded == {u'key': u'val'}

# Generated at 2022-06-23 04:44:06.740776
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, json.JSONDecoder)

# Generated at 2022-06-23 04:44:12.744413
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test_secret']
    data = '{"__ansible_vault": "test_string"}'
    cls = AnsibleJSONDecoder()
    cls.set_secrets(secrets)
    result = json.loads(data, cls=cls)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None
    assert result['__ansible_vault']
    assert str(result) == data

# Generated at 2022-06-23 04:44:15.503963
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert(AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook) is not None)

# Generated at 2022-06-23 04:44:26.303944
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    encoder = AnsibleJSONEncoder()
    secret = encoder.default(u'password')

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets([secret])


# Generated at 2022-06-23 04:44:36.617007
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # test with dictionary
    def test_dict():
        pairs = {"__ansible_vault": '$ANSIBLE_VAULT;1.1;AES256;test1234\n1234567890123456\n1234567890123456\n1234567890123456\n1234567890123456\n003954757269616e5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c\n', "key": "value"}
        actual = decoder.object_hook(pairs)


# Generated at 2022-06-23 04:44:39.741586
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test creating instance of AnsibleJSONDecoder
    try:
        AnsibleJSONDecoder()
    except:
        raise AssertionError()


# Generated at 2022-06-23 04:44:49.796681
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import re
    import sys
    import types
    import uuid
    from datetime import datetime

    # stdlib imports
    import json

    # local imports
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.parsing.vault import VaultEditor

    import pytest


    #
    # Tests without secrets
    #

    assert json.loads(json.dumps({'__ansible_unsafe': 'xyz'}),
                      cls=AnsibleJSONDecoder) == wrap_var('xyz')

    assert json.loads(json.dumps({'__ansible_vault': 'xyz'}),
                      cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode('xyz')

    #
    #

# Generated at 2022-06-23 04:44:51.629628
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder(object_hook=None)


# Generated at 2022-06-23 04:44:57.682346
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'vault_value', '__ansible_unsafe': 'unsafe_value'}
    ob = d.object_hook(pairs)

    assert ob.get('__ansible_vault') == 'vault_value'
    assert ob.get('__ansible_unsafe') == 'unsafe_value'

# Generated at 2022-06-23 04:45:02.037970
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    for key in {'__ansible_vault', '__ansible_unsafe'}:
        assert key in AnsibleJSONDecoder.object_hook(dict(({key: 'value'}))).keys()
    assert 'other' not in AnsibleJSONDecoder.object_hook(dict(({'other': 'value'}))).keys()

# Generated at 2022-06-23 04:45:09.476883
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Input
    raw = '{"__ansible_vault": "AES256:SOME_VAULT_CONTENT", "__ansible_unsafe": "Secret content"}'
    obj = json.loads(raw, cls=AnsibleJSONDecoder)
    # Output
    assert obj['__ansible_vault'] == "AES256:SOME_VAULT_CONTENT"
    assert obj['__ansible_unsafe'] == "Secret content"
    assert obj['__ansible_unsafe']._resource_name == "Secret content"

    # Input

# Generated at 2022-06-23 04:45:20.008892
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    f = open('ansible_json_decoder_object_hook_results.json')
    expected_results = json.load(f)
    f.close()

    # Used by this class' object_hook() method
    secrets = {
        'default': {
            'vault_password': 'secret',
            'vault_identity': 'default',
        }
    }
    AnsibleJSONDecoder.set_secrets(secrets)

    # Inject the AnsibleJSONDecoder class into the json library
    json.JSONDecoder = AnsibleJSONDecoder
    
    f = open('ansible_json_decoder_object_hook_input.json')
    input_data = json.load(f)
    f.close()

    # Set the initialized JSONDecoder object to complex_example_data
    complex_

# Generated at 2022-06-23 04:45:23.194132
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook


# Generated at 2022-06-23 04:45:30.691012
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoded = decoder.decode('{"__ansible_vault": "value"}')
    assert(hasattr(decoded['__ansible_vault'], 'vault'))
    assert(decoded['__ansible_vault'] == 'value')

    decoded = decoder.decode('{"__ansible_unsafe": "value"}')
    assert(decoded['__ansible_unsafe'] == 'value')

# Generated at 2022-06-23 04:45:40.341859
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = "vault"
    test_AnsibleJSONDecoder = AnsibleJSONDecoder()
    object_hook = test_AnsibleJSONDecoder.object_hook({u'__ansible_vault': u'secrets'})
    assert object_hook.vault == secrets
    object_hook = test_AnsibleJSONDecoder.object_hook({u'__ansible_unsafe': u'vault'})
    assert object_hook.data == secrets
    object_hook = test_AnsibleJSONDecoder.object_hook({u'__ansible_unsafe': u'vault', u'__ansible_vault': u'secrets'})
    assert object_hook == {u'__ansible_vault': u'secrets', u'__ansible_unsafe': u'vault'}


# Generated at 2022-06-23 04:45:53.221964
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook({"__ansible_vault": "my_vault"}) == AnsibleVaultEncryptedUnicode("my_vault")
    assert ansible_json_decoder.object_hook({"__ansible_unsafe": "my_unsafe"}) == wrap_var("my_unsafe")
    assert ansible_json_decoder.object_hook({"__ansible_vault": "my_vault", "__ansible_unsafe": "my_unsafe"}) == {"__ansible_vault": AnsibleVaultEncryptedUnicode("my_vault"), "__ansible_unsafe": wrap_var("my_unsafe")}


# Generated at 2022-06-23 04:45:58.021363
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = {'default': 'test'}

    assert AnsibleJSONDecoder.set_secrets(secrets)
    assert type(AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)) == AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:01.834011
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_decoder = AnsibleJSONDecoder()
    pair = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n'
    }
    result = json_decoder.object_hook(pair)



# Generated at 2022-06-23 04:46:11.534039
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\n[...]"}'
    secret = 'mysecret'
    vault = VaultLib(secrets=[secret])
    encrypted = AnsibleVaultEncryptedUnicode(json.loads(json_text)['__ansible_vault'])
    encrypted.vault = vault
    encrypted.load_encryption_data()
    encrypted.vault._decrypt(secret)
    assert json.loads(json_text, cls=AnsibleJSONDecoder) == encrypted

# Generated at 2022-06-23 04:46:21.253069
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test for constructor
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook is not None
    assert decoder.parse_string is not None
    assert decoder.parse_int is not None
    assert decoder.parse_constant is not None
    assert decoder.strict is not None
    assert decoder.scan_once is not None
    assert decoder.object_pairs_hook is not None

    assert decoder.indent is 0
    assert decoder.max_nesting is 20
    assert decoder.encoding is 'utf-8'
    assert decoder.object_hook is not None


# Generated at 2022-06-23 04:46:23.509401
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_decoder, json.JSONDecoder)


# Generated at 2022-06-23 04:46:28.197640
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': {'test': True}}) == {'test': True}
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')



# Generated at 2022-06-23 04:46:33.548660
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': 'automation'}) == wrap_var('automation')
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'automation'}) == AnsibleVaultEncryptedUnicode('automation')

# Generated at 2022-06-23 04:46:42.154571
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret_password']

# Generated at 2022-06-23 04:46:47.009246
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = json.loads('{"__ansible_vault": "value"}', cls=AnsibleJSONDecoder)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is not None

    data = json.loads('{"__ansible_vault": "value"}')
    assert isinstance(data, dict)

# Generated at 2022-06-23 04:46:48.406623
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder()
    assert(cls)

# Generated at 2022-06-23 04:46:54.517320
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Success case with the default args
    success = AnsibleJSONDecoder()
    assert isinstance(success, json.JSONDecoder)

    # Success case with a custom object_hook
    def custom_object_hook(pair):
        return dict()

    success = AnsibleJSONDecoder(object_hook=custom_object_hook)
    assert success.object_hook is custom_object_hook


# Generated at 2022-06-23 04:46:59.040703
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Get a secret for the vault
    secrets = ['asdf']

    # Create a test string
    teststr = '{"__ansible_vault": "asdf", "__ansible_unsafe": ""}'

    # Create a new decoder
    json_decoder = AnsibleJSONDecoder()
    json_decoder.set_secrets(secrets)

    # Decode the test string
    json_decoder.decode(teststr)

# Generated at 2022-06-23 04:47:04.301563
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test Data
    test_data = [
        {"__ansible_vault": "test"},
        {"__ansible_unsafe": "test"}
    ]

    # Prepare test
    decoder = AnsibleJSONDecoder()

    # Execute test
    object_hook_data = [
        decoder.object_hook(pairs) for pairs in test_data
    ]

    # Assert test
    assert isinstance(object_hook_data[0], AnsibleVaultEncryptedUnicode)
    assert isinstance(object_hook_data[1], dict)
    assert '__ansible_unsafe' in object_hook_data[1]
    assert isinstance(object_hook_data[1]['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-23 04:47:04.952369
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:47:06.754904
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder(object_hook=None) is not None

# Generated at 2022-06-23 04:47:17.537633
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_vault = AnsibleVaultEncryptedUnicode('AQDtT8Tt2SAidRW1h98tZFxv9X4tumysYI1TOkM7\n')
    vault_data = '{"__ansible_vault": "AQDtT8Tt2SAidRW1h98tZFxv9X4tumysYI1TOkM7\n"}'
    plain_data = '{"keyword": "value"}'

    # Test without secrets
    decoder = AnsibleJSONDecoder()
    assert json.loads(vault_data, cls=decoder) == {'__ansible_vault': ansible_vault}
    assert json.loads(plain_data, cls=decoder) == {'keyword': 'value'}

# Generated at 2022-06-23 04:47:28.449117
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common._json_compat import json_loads

    decoder = AnsibleJSONDecoder()

    # check __ansible_vault

# Generated at 2022-06-23 04:47:31.832356
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """
    Test if the class AnsibleJSONDecoder can be created
    """
    assert AnsibleJSONDecoder()

# Generated at 2022-06-23 04:47:37.878845
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_decoder, json.JSONDecoder)


# Generated at 2022-06-23 04:47:46.826022
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['testsecret']
    AnsibleJSONDecoder.set_secrets(secrets)
    test_dict = {'__ansible_vault': '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  64306233366165653566343662646539386564373936316339343536306533303031316139393534\n  39646635666162373335643033633734346239623436356364663134310a66303633326362663166\n  33396131633831616630656262396162333431663164376163383636663537396134363964623331\n  36663962383962396232316537333932\n'}
   

# Generated at 2022-06-23 04:47:49.158972
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = "AES256"
    AnsibleJSONDecoder.set_secrets(secret)
    d = AnsibleJSONDecoder()
    assert(d)

# Generated at 2022-06-23 04:47:59.760590
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # It should be able to parse a string
    raw = '{"key": "value"}'

    obj = json.loads(raw, cls=AnsibleJSONDecoder)

    assert obj == {'key': 'value'}

    # It should be able to parse an int
    raw = '{"key": 123}'

    obj = json.loads(raw, cls=AnsibleJSONDecoder)

    assert obj == {'key': 123}

    # It should be able to parse an list
    raw = '{"key": [1, 2, 3]}'

    obj = json.loads(raw, cls=AnsibleJSONDecoder)

    assert obj == {'key': [1, 2, 3]}

    # It should be able to parse an dict
    raw = '{"key": {"key": "value"}}'



# Generated at 2022-06-23 04:48:07.199967
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # set the default vault
    secret = 'password'
    password = u'secret'
    AnsibleJSONDecoder.set_secrets({'default': password})

    data = {}

# Generated at 2022-06-23 04:48:10.656693
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = AnsibleJSONDecoder("test", "vault")

    assert obj is not None
    assert isinstance(obj, json.JSONDecoder)
    assert obj._vaults == dict()

# Generated at 2022-06-23 04:48:21.882700
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:48:32.885887
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """This function is to test AnsibleJSONDecoder.object_hook() method"""
    text = '{"__ansible_vault": "U2FsdGVkX19wcHNjaGVkXzFfWFNJOTV6cUN1bkU1V0U2NElUR0VuUg==\n", "__ansible_unsafe": true}'
    decoder = AnsibleJSONDecoder()
    data = decoder.decode(text)
    assert data == {'__ansible_unsafe': True, '__ansible_vault': 'U2FsdGVkX19wcHNjaGVkXzFfWFNJOTV6cUN1bkU1V0U2NElUR0VuUg==\n'}

# Generated at 2022-06-23 04:48:44.776397
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook({}) == {}

    assert decoder.object_hook(
        {'__ansible_vault': 'abcd1234'}
    ) == AnsibleVaultEncryptedUnicode('abcd1234')

    assert decoder.object_hook(
        {'__ansible_unsafe': 'abcd1234'}
    ) == wrap_var('abcd1234')

    assert decoder.object_hook(
        {'__ansible_vault': 'abcd1234', '__ansible_unsafe': 'efgh5678'}
    ) == AnsibleVaultEncryptedUnicode('abcd1234')


# Generated at 2022-06-23 04:48:55.868611
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # For json containing non-encrypted objects
    decoder = AnsibleJSONDecoder()
    non_encrypted_json = json.dumps({'test_key': 'test_value'}, cls=AnsibleJSONEncoder)
    decoded_json = json.loads(non_encrypted_json, cls=AnsibleJSONDecoder)
    assert(decoded_json['test_key'] == 'test_value')

    # For json containing __ansible_vault-encrypted objects
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['secret'])

# Generated at 2022-06-23 04:48:58.173258
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder('[{ "__ansible_vault": "sample value" }]'), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:49:10.472840
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    # Case 1: Only vault, no unsafe
    pairs1 = {'__ansible_vault': 'vault_value'}
    result1 = AnsibleJSONDecoder().object_hook(pairs1)
    assert isinstance(result1, AnsibleVaultEncryptedUnicode)
    assert result1.vault is None
    assertresult1 == 'vault_value'

    # Case 2: No vault, only unsafe
    pairs2 = {'__ansible_unsafe': 'unsafe_value'}
    result2 = AnsibleJSONDecoder().object_hook(pairs2)
    assert isinstance(result2, wrap_var)
    assert result

# Generated at 2022-06-23 04:49:20.162468
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets('topsecret')
    json_str = '''{"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35316331366438663837376631326465363764386162306532313234656535373037666531393163\n          31336466343638323437333866356336663961613761323434346133376239323237313638366465\n          33323666643663646438653533383065356534396434302120139a9c23ef8d2f2e2a1751f0d6d74\n          "}\n'''

# Generated at 2022-06-23 04:49:23.548966
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder_hook = AnsibleJSONDecoder()
    assert hasattr(decoder_hook, 'object_hook')
    assert isinstance(decoder_hook, json.JSONDecoder)

# Generated at 2022-06-23 04:49:32.942929
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    password = 'test_password'
    json_encoded = '{"__ansible_vault": "U2Fucy1CYW5nYSAyNTUK"}'
    ansible_json_encoded = '{"__ansible_vault": "U2Fucy1CYW5nYSAyNTUK", "__ansible_unsafe": "U2Fucy1CYW5nYSAyNTUK"}'

    test_vault = VaultLib(password)
    encoded = test_vault.encrypt(password)

    json_decoder = AnsibleJSONDecoder()
    json_decoder.set_secrets(password)
    decoded = json_decoder.decode(json_encoded)
    assert decoded['__ansible_vault'] == encoded
    assert AnsibleVaultEncrypted

# Generated at 2022-06-23 04:49:42.615821
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets=['test'])
    encrypted_value = '$ANSIBLE_VAULT;1.0;AES256;ansible\n363435333036346665623535393038646534363266363039653966636162336461633437306635\n313334353032333434333736343038353833363339313932316434393231366335623661333762\n373834383336656430326362373839663235653439636236613562356633383366353930386132\n6536\n'
    pairs = {'__ansible_vault': encrypted_value, '__ansible_unsafe': 'ABC'}

# Generated at 2022-06-23 04:49:44.221205
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

# Generated at 2022-06-23 04:49:51.803046
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['a_very_secret_password']
    AnsibleJSONDecoder.set_secrets(secrets)

    data = {
        '__ansible_vault': '8e4304c4a29a67a17c2bc8cf9c932f695f52dbc0776b837006f4c0a4',
        '__ansible_unsafe': 'a string',
        'simple_dict': {
            'a': 'b',
            'c': 'd'
        },
        'simple_list': [1, 2, 3, 4]
    }
    assert AnsibleJSONDecoder().decode(json.dumps(data)) == data



# Generated at 2022-06-23 04:50:02.021580
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [{'vault_id': 'default', 'password': 'secret'}]