

# Generated at 2022-06-23 04:40:08.854700
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test object_hook() with AnsibleVaultEncryptedUnicode object
    def test_with_vault(value):
        encoder = AnsibleJSONDecoder()

        decoded_value = encoder.object_hook(value)

        assert decoded_value == 'This is encrypted.\n'
        assert isinstance(decoded_value, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:40:10.059411
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder

# Generated at 2022-06-23 04:40:20.916974
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret_string = 'Secret'
    secret_string_encrypted = '$ANSIBLE_VAULT;1.1;AES256'
    secret_string_encoded = "$ANSIBLE_VAULT;1.1;AES256;6e160da6d4c6b1b4\n36376135613839666564336635336237626138376265653061323461616461396339313162363238\n3566653634303337656539306366663663323461323733643333664664303539373439333236613037\n32303262636332353134313\n"

# Generated at 2022-06-23 04:40:31.106322
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    obj = {
        'foo': 'bar',
        '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;user;bG9zdAou\nblabla',
        '__ansible_unsafe': 'baz'
    }

    vault = VaultLib('mypass')

# Generated at 2022-06-23 04:40:39.903730
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault_value = '$ANSIBLE_VAULT;1.1;AES256\n34623462346235643t6sdsdf3sdfasdg47t354s35t42s3t2s35t45wtsdfcs\n'
    ansible_json = {
        '__ansible_vault': ansible_vault_value,
    }
    json_str = json.dumps(ansible_json, cls=AnsibleJSONEncoder)
    ansible_json2 = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert ansible_json2 == ansible_json


# Generated at 2022-06-23 04:40:48.035102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    json_str = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;user@host\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaa=="}'
    ansible_vault_object = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;user@host\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaa==')

    result = AnsibleJSONDecoder().object_hook(json.loads(json_str))

# Generated at 2022-06-23 04:40:55.556171
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for value of key '__ansible_vault'
    data = {'__ansible_vault': 'blah'}
    result = AnsibleJSONDecoder.object_hook(data)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.value == 'blah'

    # Test for value of key '__ansible_unsafe'
    data = {'__ansible_unsafe': 'blah'}
    result = AnsibleJSONDecoder.object_hook(data)
    assert isinstance(result, wrap_var)
    assert result.value == 'blah'

    # Test for other values
    data = {'1': 'blah'}
    result = AnsibleJSONDecoder.object_hook(data)
    assert result == data

# Generated at 2022-06-23 04:41:03.176447
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert hasattr(decoder, 'object_hook')
    assert decoder.object_hook

if __name__ == "__main__":
    import sys, os
    import unittest
    sys.path.append('../../')
    from units.mock.patch import Patch

    old_system_path = sys.path

# Generated at 2022-06-23 04:41:15.483137
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['hunter2']
    secrets_dict = {'default': 'hunter2'}
    json_string = '''{
        "__ansible_vault": "blahblahblah"
        "__ansible_unsafe": "blahblahblah"
    }'''
    decoded = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert decoded['__ansible_vault'] == "blahblahblah"
    assert decoded['__ansible_unsafe'] == "blahblahblah"
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:41:24.281335
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text = '{ "__ansible_unsafe": "data", "__ansible_vault": "data"}'
    decoded = AnsibleJSONDecoder().decode(json_text)
    assert isinstance(decoded, dict)
    assert isinstance(decoded.get('__ansible_unsafe'), AnsibleUnsafeText)
    assert isinstance(decoded.get('__ansible_vault'), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:41:25.361597
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder()
    assert a

# Generated at 2022-06-23 04:41:37.064028
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:39.582388
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=lambda obj: obj)
    assert decoder.object_hook


# Generated at 2022-06-23 04:41:51.619755
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {
        "abc": "abc_val",
        "key": "val",
        "__ansible_vault": "vault_val",
        "__ansible_unsafe": "unsafe_val"
    }

    result = AnsibleJSONDecoder().object_hook(data)

    assert type(result) is dict
    assert result['abc'] == 'abc_val'
    assert result['key'] == 'val'
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'] == 'vault_val'
    assert isinstance(result['__ansible_unsafe'], wrap_var)
    assert result['__ansible_unsafe'] == 'unsafe_val'


# Generated at 2022-06-23 04:41:56.600714
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_dict = {
        "__ansible_vault": "vault text",
        "__ansible_unsafe": "unsafe string"
    }
    vault_password = "mypassword"
    AnsibleJSONDecoder.set_secrets([vault_password])
    decoder = AnsibleJSONDecoder()
    decoded = decoder.decode(json.dumps(json_dict))

    assert isinstance(decoded["__ansible_vault"], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded["__ansible_unsafe"], str)

# Generated at 2022-06-23 04:42:01.349399
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = "secret"
    json_data = """{
        "__ansible_vault": "SomeVaultData",
        "__ansible_vault": "SomeVaultData",
        "__ansible_vault": "SomeVaultData"
    }"""

    try:
        ansible_json_decoder = AnsibleJSONDecoder()
        ansible_json_decoder.set_secrets(secrets)
    except Exception as e:
        assert True == False, "AnsibleJSONDecoder constructor: " + str(e)
    else:
        assert True == True, "AnsibleJSONDecoder constructor: ok"


# Generated at 2022-06-23 04:42:02.586565
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-23 04:42:16.786965
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, AnsibleSequence, AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var

    txt = 'This is a secret string!'
    unsafe_txt = 'unsafe'

    v = VaultLib(secrets=['secrets'])
    av = AnsibleVaultEncryptedUnicode(txt, vault=v)

# Generated at 2022-06-23 04:42:25.216129
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib('hunter2')
    expected = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;ansible\n'
                                            '32673166386435666561393766333437386364343033643061386131633936326530396363623635\n'
                                            '38653037323139646165653865383539613431376163633666326263376232663633313166393861\n'
                                            '333461303935343665373332633535640a', vault)

    decoder = Ans

# Generated at 2022-06-23 04:42:28.337079
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import sys
    if sys.version_info[0] < 3:
        input_str = '{"test": "value"}'
    else:
        input_str = '{"test": "value"}'.encode('utf-8')

    # test default
    decoder = AnsibleJSONDecoder()
    res = decoder.decode(input_str)
    assert(res['test'] == 'value')

    # test if 'object_hook' is set
    decoder = AnsibleJSONDecoder(object_hook=lambda x: x)
    res = decoder.decode(input_str)
    assert(res['test'] == 'value')


# Generated at 2022-06-23 04:42:39.193482
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:49.600831
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Positive test
    test_value = 'test'
    input_value = '{"__ansible_vault": "' + test_value + '"}'
    assert_value = {'__ansible_vault': test_value}
    output_value = json.loads(input_value, cls=AnsibleJSONDecoder)
    assert output_value == assert_value

    # Positive test
    test_value = 'test'
    input_value = '{"__ansible_unsafe": "' + test_value + '"}'
    output_value = json.loads(input_value, cls=AnsibleJSONDecoder)
    assert output_value['__ansible_unsafe'] == test_value

    # Negative test
    test_value = 'test'

# Generated at 2022-06-23 04:43:01.702220
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:43:06.809102
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['vaultpassword']
    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert decoder.object_hook({'__ansible_vault': 'value'}) == AnsibleVaultEncryptedUnicode('value')
    assert decoder.object_hook({'__ansible_unsafe': 'value'}) == wrap_var('value')

# Generated at 2022-06-23 04:43:09.528530
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Create encrypted secret
    vault = VaultLib()
    secret = 'TestingSecret'
    encrypted_secret = vault.encrypt(secret)
    # Create AnsibleJSONEncoder instance
    json_decoder = AnsibleJSONDecoder()
    # Set secret
    AnsibleJSONDecoder.set_secrets(vault.secrets)
    # Try to decode
    decoded_object = json_decoder.decode(encrypted_secret)
    # Check if decoding was successful
    assert decoded_object == secret


# Generated at 2022-06-23 04:43:19.788028
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()

    # Test vault support
    secrets = ["vault_secret"]
    dec.set_secrets(secrets)

# Generated at 2022-06-23 04:43:24.304249
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder().object_hook({'__ansible_vault': 123}) == AnsibleVaultEncryptedUnicode(123)
    assert AnsibleJSONDecoder().object_hook({'__ansible_unsafe': 123}) == wrap_var(123)
    assert AnsibleJSONDecoder().object_hook({'test': 123}) == {'test': 123}

# Generated at 2022-06-23 04:43:36.469686
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Given
    secrets = [
        ('default', '$A$BCD')
    ]
    original_data = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;ansible\n63313164313233613664396164386434623961623134343635326432326330656664656231333463\n39666634643737333666326432303938656430626532366330343366373732666631323937656666\n38363865353263343364396534663835\n'
    }

    # When
    result = json.loads(json.dumps(original_data), cls=AnsibleJSONDecoder)

    # Then

# Generated at 2022-06-23 04:43:48.092035
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_cases = [
        (
            {"__ansible_vault": "vault_value"},
            AnsibleVaultEncryptedUnicode('vault_value'),
        ),
        (
            {"__ansible_vault": "vault_value", "key": "value"},
            AnsibleVaultEncryptedUnicode('vault_value'),
        ),
        (
            {"__ansible_vault": "vault_value", "__ansible_unsafe": "value"},
            AnsibleVaultEncryptedUnicode('vault_value'),
        ),
        (
            {"__ansible_unsafe": "value"},
            wrap_var('value'),
        ),
    ]


# Generated at 2022-06-23 04:43:59.880348
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['foo', 'bar', 'baz']
    secrets_json = json.dumps(secrets)
    encrypted = '$ANSIBLE_VAULT;1.1;AES256;ansible\n3632343033643634666439376133346262623134633961623166643465336436393665333462376335\n66373761366561326233633032653034623463343637623437366231\n'
    vault = AnsibleJSONDecoder(secrets=secrets)
    vault.set_secrets(secrets)

    # test AnsibleJSONEncoder.default() for AnsibleVaultEncryptedUnicode
    test_vault = AnsibleVaultEncryptedUnicode(encrypted)
    assert vault.decode(secrets_json)

# Generated at 2022-06-23 04:44:08.293384
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    en = AnsibleJSONEncoder()
    # test object_hook is used
    d = json.loads(en.encode({"a": "b"}), cls=AnsibleJSONDecoder)
    assert(d)

    # test Vault objects work

# Generated at 2022-06-23 04:44:14.110776
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Plain JSON load
    assert json.loads('{"one": 1}', cls=AnsibleJSONDecoder) == {"one": 1}
    # Ansible vault safe
    assert json.loads('{"__ansible_vault": "x"}', cls=AnsibleJSONDecoder) == AnsibleVaultEncryptedUnicode("x")
    # Ansible unsafe load
    assert json.loads('{"__ansible_unsafe": "x"}', cls=AnsibleJSONDecoder) == wrap_var("x")

# Generated at 2022-06-23 04:44:25.263639
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    secret_data = {'vault_password': '123'}
    vault = VaultLib(secrets=secret_data)

# Generated at 2022-06-23 04:44:28.840547
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_json = {}
    test_json["__ansible_vault"] = "encrypted_text"

    dict_ = AnsibleJSONDecoder(test_json)
    assert dict_.decode() == {"__ansible_vault": "encrypted_text"}

# Generated at 2022-06-23 04:44:36.885119
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_json_decoder = AnsibleJSONDecoder()
    test_json_decoder.object_hook({'__ansible_vault': '12345'})
    test_json_decoder.object_hook({'__ansible_unsafe': '12345'})
    test_json_decoder.object_hook({'__ansible_vault': '12345', '__ansible_unsafe': '12345'})
    test_json_decoder.object_hook({'__ansible_vault': '12345', '__ansible_unsafe': '12345', '__ansible_vault_': '12345'})

# Generated at 2022-06-23 04:44:43.862101
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    s = VaultSecret('test_secret')
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(s)

    assert AnsibleVaultEncryptedUnicode('foo', vault=decoder._vaults['default']).text == 'foo'
    assert isinstance(decoder.decode('{"__ansible_vault": "foo"}'), AnsibleVaultEncryptedUnicode)
    assert isinstance(decoder.decode('{"__ansible_unsafe": "foo"}'), AnsibleUnsafeText)

    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:44:55.912642
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class DummyVaultLib(object):
        def __init__(self, secrets):
            self.secrets = secrets

        def load(self, value):
            return json.loads(value)

        def decrypt(self, value):
            return value

    decoder = AnsibleJSONDecoder()

    vault = AnsibleVaultEncryptedUnicode('test_value')
    vault._vault = DummyVaultLib(secrets=['test_password'])


# Generated at 2022-06-23 04:45:03.864645
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder=AnsibleJSONDecoder()
    json_data = json.dumps({'__ansible_vault': 'VAULT_DATA'}, cls=AnsibleJSONEncoder)
    ansible_vault_data = decoder.decode(json_data)
    assert ansible_vault_data['__ansible_vault'] == 'VAULT_DATA'

if __name__ == "__main__":
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-23 04:45:04.669159
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()

# Generated at 2022-06-23 04:45:17.198126
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test decrypting an encrypted string
    d = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(['foo'])

# Generated at 2022-06-23 04:45:25.036690
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    data = {'a': '1', 'b': '2'}
    encoded = json.dumps(data, cls=AnsibleJSONEncoder)
    encoded_obj = json.loads(encoded, cls=AnsibleJSONDecoder)

    assert encoded_obj['a'] == '1'
    assert encoded_obj['b'] == '2'

# Generated at 2022-06-23 04:45:31.522705
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import copy
    raw = {'__ansible_vault': 'myvault', '__ansible_unsafe': 'myunsafe'}
    secret = [None, 'mypassword']
    j = AnsibleJSONDecoder()
    j.set_secrets(secret)
    y = j.decode(json.dumps(raw))

    assert(y == {'__ansible_vault': 'myvault', '__ansible_unsafe': 'myunsafe'})


# Generated at 2022-06-23 04:45:37.643228
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=None, parse_float=None, parse_int=None,
                                              parse_constant=None, strict=None, object_pairs_hook=None)
    assert ansible_json_decoder



# Generated at 2022-06-23 04:45:44.242654
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = {"a": 1, "__ansible_vault": "vault-value", "__ansible_unsafe": "unsafe-value"}
    d1 = AnsibleJSONDecoder().object_hook(d)
    assert d1['a'] == 1
    assert hasattr(d1['__ansible_vault'], 'vault')
    assert d1['__ansible_unsafe'].val == "unsafe-value"


# Generated at 2022-06-23 04:45:56.775025
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    decoder = AnsibleJSONDecoder()

    # Test for value of AnsibleVaultEncryptedUnicode type
    test_data = {
        '__ansible_vault': 'vaulted_value'
    }
    assert isinstance(decoder.object_hook(test_data), AnsibleVaultEncryptedUnicode)

    # Test for value of unsafe_proxy type
    test_data = {
        '__ansible_unsafe': 'unsafe_value'
    }
    assert isinstance(decoder.object_hook(test_data), dict)

    # Test for normal value, should return the same string
    unsafe_value = "unsafe_value"
    assert decoder.object_hook(unsafe_value) == unsafe_value

# Generated at 2022-06-23 04:45:58.991520
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    dec = AnsibleJSONDecoder()
    assert isinstance(dec, json.JSONDecoder)
    assert dec.object_hook

# Generated at 2022-06-23 04:46:06.904626
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    class TestVaultLib(VaultLib):
        def _decrypt(self, value):
            return 'decrypted-value'
    test_vault = TestVaultLib()
    TestAnsibleJSONDecoder = AnsibleJSONDecoder
    TestAnsibleJSONDecoder._vaults = {'default': test_vault}

    assert TestAnsibleJSONDecoder.object_hook(object, {'__ansible_vault': '__ANSIBLE_VAULT;1.1;AES256;hex_test'}) == AnsibleVaultEncryptedUnicode('__ANSIBLE_VAULT;1.1;AES256;hex_test')


# Generated at 2022-06-23 04:46:09.433870
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    secrets = "secret"
    decoder.set_secrets(secrets)
    assert decoder

# Generated at 2022-06-23 04:46:21.569152
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 04:46:29.508947
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    s = '{__ansible_vault:$ANSIBLE_VAULT;1.2;AES256;ansible@ubuntu1.localdomain64763'
    vault_lib = VaultLib(secrets=['ansible'])
    assert AnsibleJSONDecoder.object_hook(json.loads(s)) == {'__ansible_vault': AnsibleVaultEncryptedUnicode(s)}



# Generated at 2022-06-23 04:46:41.550690
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    ansiblejson_decoder = AnsibleJSONDecoder()

    # Testing default object hook
    json_string = '{"a": {"__ansible_vault": "encrypted_string"}}'
    pairs = ansiblejson_decoder.object_hook(json.loads(json_string))
    assert pairs['a'].value == 'encrypted_string'

    # Testing with object hook
    json_string = '{"a": {"__ansible_vault": "encrypted_string"}, ' \
                    '"__ansible_unsafe": "unsafe_string"}'
    pairs = ansiblejson_decoder.object_hook(json.loads(json_string))
    assert pairs['a'].value == 'encrypted_string'
    assert wrap_var(pairs['__ansible_unsafe']).value == 'unsafe_string'

# Generated at 2022-06-23 04:46:52.332448
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder()

    secrets = b'$ANSIBLE_VAULT;1.1;AES256\n33376435623335623631356439306564383061386164653331636338616662343039333465306137\n34623862363835383661303539343536386633393032336534656162643231656235323238433930\n6636653539653632316166393964623335313033376537613166393539\n'

    class DummyStruct:
        pass

    dummy = DummyStruct()

# Generated at 2022-06-23 04:46:59.319515
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader

    secret = 'dummy_secret'
    json_data = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256;ansible\n' + secret + '\n"}'
    json_data_unsafe = '{"__ansible_unsafe": "YWJjZGVm\nZ2hpamtsbW5vcA==\n"}'
    tempdir = tempfile.mkdtemp()
    secrets_filename = os.path.join(tempdir, 'passwords.txt')
    with open(secrets_filename, 'w') as f:
        f.write('dummy_secret')

    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:47:12.186611
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import datetime, os, sys
    try:
        import builtins
    except ImportError:
        import __builtin__ as builtins
    try:
        from unittest import mock
    except ImportError:
        import mock

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # patching builtin modules is not thread safe
    mocked_builtins = mock.Mock()
    mocked_builtins.__json_mod__ = json
    mocked_builtins.__json_mod_attr_list__ = ['JSONEncoder', 'JSONDecoder']

    with mock.patch.dict('sys.modules', {'builtins': mocked_builtins}):
        from ansible.module_utils.common.json import AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:22.176991
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    test_string = "{'name': 'joe', 'msg': {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\r\n...snip...\r\n'}}"
    expected_output = {'name': 'joe', 'msg': {'__ansible_vault': "b'$ANSIBLE_VAULT;1.1;AES256\r\n...snip...\r\n'", "__ansible_vault_secret": None}}
    actual_output   = decoder.decode(test_string)
    assert actual_output == expected_output

# Generated at 2022-06-23 04:47:32.817951
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class A(dict):
        pass

    test_data = A({
        '__ansible_vault': 'bla',
        '__ansible_unsafe': {},
    })

    assert isinstance(AnsibleJSONDecoder.object_hook(test_data), AnsibleVaultEncryptedUnicode) is True
    assert isinstance(AnsibleJSONDecoder.object_hook({'__ansible_unsafe': {}}), dict) is True
    assert isinstance(AnsibleJSONDecoder.object_hook({}), dict) is True



# Generated at 2022-06-23 04:47:47.430658
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # check construction without parameters
    try:
        a = AnsibleJSONDecoder()
    except TypeError as err:
        assert False, "An unexpected TypeError occurred:" + str(err)

    # TODO: verify that vault is not set (?)
    # TODO: verify that constructor sets a hook for object creation?

    # check construction with parameters
    try:
        a = AnsibleJSONDecoder(object_hook=lambda dict: dict)
        # TODO: verify that vault is not set (?)
    except TypeError as err:
        assert False, "An unexpected TypeError occurred:" + str(err)

    # check construction with parameter set_secrets

# Generated at 2022-06-23 04:47:58.068078
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder._vaults = {
        'default': VaultLib(secrets=['secret'])
    }

    # Test __ansible_vault
    value = decoder.object_hook({'__ansible_vault': '7'})
    assert value == AnsibleVaultEncryptedUnicode('7')
    assert value.vault is not None

    # Test __ansible_unsafe
    value = decoder.object_hook({'__ansible_unsafe': True})
    assert isinstance(value, wrap_var)

    # Test no key
    value = decoder.object_hook({'key': 7})
    assert value == {'key': 7}



# Generated at 2022-06-23 04:48:05.814664
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    def check_unsafe(obj):
        return isinstance(obj, AnsibleJSONEncoder.AnsibleUnsafe)


# Generated at 2022-06-23 04:48:09.349650
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_decoder = AnsibleJSONDecoder()
    assert isinstance(json_decoder, AnsibleJSONDecoder)
    assert json_decoder.object_hook == json_decoder.object_hook

# Generated at 2022-06-23 04:48:11.064864
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None

# Generated at 2022-06-23 04:48:12.967101
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansiblejsonDecoder = AnsibleJSONDecoder()
    assert ansiblejsonDecoder


# Generated at 2022-06-23 04:48:20.476088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_data = {'__ansible_vault': 'hashed_password', '__ansible_unsafe': 'unsafe_password'}
    expected_output = {'__ansible_vault': 'hashed_password', '__ansible_unsafe': 'unsafe_password'}
    assert expected_output == decoder.object_hook(test_data)

# Generated at 2022-06-23 04:48:21.840779
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None

# Generated at 2022-06-23 04:48:28.207947
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(strict=False, object_pairs_hook=None)
    contents = dict()
    contents['__ansible_vault'] = {}
    contents['__ansible_unsafe'] = {}
    content = json.dumps(contents)
    result = decoder.decode(content)
    assert '__ansible_vault' in result
    assert '__ansible_unsafe' in result

# Generated at 2022-06-23 04:48:30.395581
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder is not None

# Generated at 2022-06-23 04:48:42.370662
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:48:51.257701
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': "$ANSIBLE_VAULT;1.1;AES256;abc1\n6162633131\n"}
    value = decoder.object_hook(pairs)
    assert(isinstance(value, AnsibleVaultEncryptedUnicode))
    assert(value.decrypt() == 'abc11')
    return True

__all__ = ["AnsibleJSONEncoder", "AnsibleJSONDecoder"]

# Generated at 2022-06-23 04:49:02.995709
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:04.912528
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:49:10.752333
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    jd = AnsibleJSONDecoder()
    data = {}
    data['__ansible_vault'] = 'myvault'
    vault = AnsibleVaultEncryptedUnicode('myvault')
    assert jd.object_hook(data) == vault
    data['__ansible_unsafe'] = 'unsafe'
    unsafe = wrap_var('unsafe')
    assert jd.object_hook(data) == unsafe


# Generated at 2022-06-23 04:49:19.228344
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    sec = '$ANSIBLE_VAULT;1.1;AES256 66373765613030356162396536346633343663313563666137626566373061393437303366353832\n30373335333635663837383465393363313432376264316465656563393739623761616365373566\n34336431613665633932393962333262613436363465336635303831636135376232633231326539\n66316137356665376263336235353664623165303239316366\n'
    jd = AnsibleJSONDecoder()
    secret_list = ['test']
    jd.set_secrets(secret_list)
    jd.object_

# Generated at 2022-06-23 04:49:29.001537
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()

    # test safe mode
    pairs = dec.object_hook({'__ansible_unsafe': 'foo'})
    assert pairs['__ansible_unsafe'].text == 'foo'

    assert dec.object_hook({'__ansible_vault': 'foo'}).data == 'foo'

    # test unsafe mode
    dec.object_hook({'__ansible_unsafe': 'foo'})[
        '__ansible_unsafe'].unsafe_proxy = 'bar'
    assert dec.object_hook({'__ansible_unsafe': 'foo'})[
        '__ansible_unsafe'] == 'bar'



# Generated at 2022-06-23 04:49:39.692480
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''
    Test: Constructor of AnsibleJSONDecoder
    '''
    key = 'grazer'
    value = 'TEST'

# Generated at 2022-06-23 04:49:52.335288
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"__ansible_vault": { "__ansible_vault": "foo" }}'
    assert isinstance(json.loads(data, cls=AnsibleJSONDecoder), AnsibleVaultEncryptedUnicode)
    assert isinstance(json.loads('{"a":"b"}', cls=AnsibleJSONDecoder), dict)
    assert isinstance(json.loads(data, cls=AnsibleJSONDecoder), dict)
    assert isinstance(json.loads('[1,2,3]', cls=AnsibleJSONDecoder), list)
    assert isinstance(json.loads('1', cls=AnsibleJSONDecoder), int)
    assert isinstance(json.loads('"a"', cls=AnsibleJSONDecoder), str)

# Generated at 2022-06-23 04:50:00.770558
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    raw_data = '{"__ansible_vault": "cGFzc3dvcmQ="}'
    encoder = AnsibleJSONDecoder()
    decoded = encoder.decode(raw_data)
    assert type(decoded) is dict
    assert '__ansible_vault' in decoded
    assert decoded['__ansible_vault'] == "cGFzc3dvcmQ="
    assert type(decoded['__ansible_vault']) is AnsibleVaultEncryptedUnicode
    assert decoded['__ansible_vault'].vault == None
