

# Generated at 2022-06-23 04:40:01.550232
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # the vault object hook is tested in test_ansible_vault.py
    pass

# Generated at 2022-06-23 04:40:05.112623
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json = b'{ "__ansible_vault": "test" }'
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook(test_json)
    assert result == {}
    assert isinstance(decoder.object_hook(test_json), dict)



# Generated at 2022-06-23 04:40:08.447395
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    kwargs = {}
    my_decoder = AnsibleJSONDecoder(**kwargs)
    assert isinstance(my_decoder, AnsibleJSONDecoder)

    expected_vaults = {}
    assert my_decoder._vaults == expected_vaults



# Generated at 2022-06-23 04:40:19.030441
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    ansible_vault_secret = 'testpassword'
    decoder.set_secrets([ansible_vault_secret])


# Generated at 2022-06-23 04:40:28.252096
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {'__ansible_vault': 'YXXXaFBrLzBjbnk5dAo=',
                 '__ansible_unsafe': '{{lookup("pipe", "echo hello")}}'}
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['mYseCrEt'])
    value = decoder.object_hook(test_data)
    assert isinstance(value['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert 'hello' in str(value['__ansible_unsafe'])



# Generated at 2022-06-23 04:40:39.538064
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    class MyEncoder(AnsibleJSONEncoder):
        _vaults = {}

    # Configure Vault
    my_vault = VaultLib(secrets=['secret123'])
    enc = MyEncoder()
    # Encrypt string
    encrypted_string = enc.encode(u'my-string-to-encrypt')
    # Encrypt an existing object
    secret_obj = {'mysecret': 'supersecret'}
    enc = MyEncoder()
    enc.prepend_vault = my_vault
    encrypted_secret = enc.encode(secret_obj)

    # Create decoder with the correct vault
    dec = AnsibleJSONDecoder()
    dec.set_secrets(['secret123'])

    # Test string decryption
    decrypted_string = dec.decode(encrypted_string)


# Generated at 2022-06-23 04:40:47.874589
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:51.447295
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test init of AnsibleJSONDecoder
    json_decoder = AnsibleJSONDecoder()
    assert isinstance(json_decoder, json.JSONDecoder)
    assert json_decoder.object_hook

# Generated at 2022-06-23 04:40:59.375551
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import os

    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    passwd_file = os.path.join('test', 'unit', 'parsing', 'vault', 'test_vault.txt')
    test_passphrase = 'ansible'

# Generated at 2022-06-23 04:41:05.996326
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_json_object_hook = '{"test_key": "test_value", "test_key2": {"test_key3": "test_value2"}}'
    test_unsafe_value_before = '{{ test_unsafe_value }}'
    test_unsafe_value_after = {'__ansible_unsafe': u'test_unsafe_value'}

# Generated at 2022-06-23 04:41:12.497793
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils.common.json import json, set_vault_secrets

    secret = 'value'

    set_vault_secrets([secret])

    serialized = json.dumps({'vault': secret}, cls=AnsibleJSONEncoder)
    data = json.loads(serialized)
    assert isinstance(data['vault'], AnsibleVaultEncryptedUnicode)

    assert data['vault'].decrypt() == secret

# Generated at 2022-06-23 04:41:19.187453
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"a": "b", "__ansible_unsafe": {"c": "d"}, "__ansible_vault": "vault_value"}'
    decoder = AnsibleJSONDecoder(json.loads)
    # Don't use '**decoder' or positional argument 'object_hook' will not be passed in:
    #   File "/usr/lib64/python2.7/json/decoder.py", line 362, in raw_decode
    #     if not self.object_hook and not kw.get('object_hook', None):
    # TypeError: object_hook() got an unexpected keyword argument 'object_hook'
    result = decoder.decode(json_str)
    assert result['a'] == 'b'

# Generated at 2022-06-23 04:41:27.120468
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    pairs = {"__ansible_vault": "value"}
    ansible_vault_obj = decoder.object_hook(pairs)
    assert isinstance(ansible_vault_obj, AnsibleVaultEncryptedUnicode)

    pairs = {"__ansible_unsafe": "value"}
    unsafe_obj = decoder.object_hook(pairs)
    assert isinstance(unsafe_obj, wrap_var)

# Generated at 2022-06-23 04:41:35.754379
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:47.367901
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Tests the behavior of AnsibleJSONDecoder.object_hook()
    # when given a regular value
    # Given
    regular_value = {"a": "b"}
    decoder = AnsibleJSONDecoder()
    # When
    value = decoder.object_hook(regular_value)
    # Then
    assert value == regular_value

    # Tests the behavior of AnsibleJSONDecoder.object_hook()
    # when given an Ansible Vault encrypted value
    # Given
    vault_text = u"$ANSIBLE_VAULT;1.1;AES256\n" + \
                 "foo" * 256 + \
                 "=" * 256 + \
                 "foo" * 256 + \
                 "\n"
    decoder = AnsibleJSONDecoder()
    # When

# Generated at 2022-06-23 04:41:58.591717
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import json
    if sys.version_info >= (3, 0):
        long = int
    try:
        import yaml
    except ImportError:
        return

# Generated at 2022-06-23 04:42:03.860938
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    sample_json = '''{"a": 1, "b": 2, "c": 3}'''
    sample_decoded_json = json.loads(sample_json)
    sample_ansible_json = '''{"a": 1, "b": 2, "__ansible_unsafe": "c", "__ansible_vault": "d"}'''
    ansible_decoded_json = AnsibleJSONDecoder().decode(sample_ansible_json)
    assert sample_decoded_json['a'] == ansible_decoded_json['a']
    assert sample_decoded_json['b'] == ansible_decoded_json['b']
    assert isinstance(ansible_decoded_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:42:10.445508
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder = AnsibleJSONDecoder(object_hook = ansible_json_decoder.object_hook)

# Generated at 2022-06-23 04:42:14.688920
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['foo', 'bar']
    assert secrets == AnsibleJSONDecoder.set_secrets(secrets)
    assert secrets == AnsibleJSONDecoder._vaults['default'].secrets
    # Reset value
    AnsibleJSONDecoder._vaults['default'] = None

# Generated at 2022-06-23 04:42:27.256340
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:32.562489
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    text = '{"__ansible_vault": "test-value"}'
    result = AnsibleJSONDecoder().decode(text)
    vault_obj = result['__ansible_vault']
    assert vault_obj.vault is None, 'VaultLib missing'
    assert vault_obj.vdata == 'test-value', 'Wrong data'

    vault_obj = AnsibleVaultEncryptedUnicode('test-value')
    result = AnsibleJSONEncoder().encode({'__ansible_vault': vault_obj})
    assert result == text, '__ansible_vault data not encoded properly'

    # The vault lib is set when the text is decoded
    text = '{"__ansible_vault": "test-value"}'

# Generated at 2022-06-23 04:42:41.497657
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [b'password']
    # secrets_bytes are converted to base64 encoded strings since "passwords" are required to be strings in
    # VaultLib
    secrets_bytes = [s.encode('utf-8') for s in secrets]
    vault_dict = {'__ansible_vault': 'example text'}
    json_string = json.dumps(vault_dict, cls=AnsibleJSONEncoder)
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secrets_bytes)
    json_object = decoder.decode(json_string)
    assert isinstance(json_object['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert json_object['__ansible_vault'].value == 'example text'


# Generated at 2022-06-23 04:42:50.730271
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:42:56.082954
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder.__name__ == 'AnsibleJSONDecoder'
    assert type(AnsibleJSONDecoder) == type
    assert AnsibleJSONDecoder.__module__ == __name__


# Generated at 2022-06-23 04:43:07.565564
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    vault_pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;id;blahblahblah...'}
    vault_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;id;blahblahblah...'}
    unsafe_pairs = {'__ansible_unsafe': '"{{lookup(\'password\', \'foo file=bar baz=bam\')}}"'}
    unsafe_dict = {'__ansible_unsafe': '"{{lookup(\'password\', \'foo file=bar baz=bam\')}}"'}

    encrypted_vault1 = decoder.object_hook(vault_pairs)
   

# Generated at 2022-06-23 04:43:10.395495
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible_collections.ansible.community.plugins.module_utils.common.removed import removed
    removed()

# Generated at 2022-06-23 04:43:21.086653
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test empty constructor
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)
    assert ansible_json_decoder.object_hook is not None

    # Test constructor with arguments
    ansible_json_decoder = AnsibleJSONDecoder(parse_constant=42)
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)
    assert ansible_json_decoder.object_hook is not None

    # Test constructor with kwargs
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=42)
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)
    assert ansible_json_decoder.object_hook == 42


# Generated at 2022-06-23 04:43:24.171157
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder is not None


# Generated at 2022-06-23 04:43:25.554772
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:43:34.061879
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '''{
    "__ansible_vault": "data",
    "__ansible_unsafe": "data",
    "foo": "bar"
}'''
    data = json.loads(json_data, cls=AnsibleJSONDecoder)

    assert isinstance(data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(data['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)
    assert data['foo'] == 'bar'



# Generated at 2022-06-23 04:43:36.639897
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = {'foo': ['bar', 'baz', 'bam'], '__ansible_vault': 'sometext', '__ansible_unsafe': 'something'}
    j = json.dumps(obj, cls=AnsibleJSONEncoder)
    d = json.loads(j, cls=AnsibleJSONDecoder)
    assert obj == d

# Generated at 2022-06-23 04:43:48.219088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder()
    assert(d.object_hook({'__ansible_vault': 'TEST'}) == AnsibleVaultEncryptedUnicode('TEST'))
    assert(d.object_hook({'__ansible_unsafe': 'TEST'}) == wrap_var('TEST'))
    assert(d.object_hook({'__ansible_vault': 'TEST', '__ansible_unsafe': 'TEST'}) == AnsibleVaultEncryptedUnicode('TEST'))
    assert(d.object_hook({'__ansible_vault': {'__ansible_unsafe': 'TEST'}}) == AnsibleVaultEncryptedUnicode({'__ansible_unsafe': 'TEST'}))

# Generated at 2022-06-23 04:43:53.665275
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import tempfile
    import os

    test_pairs = {'__ansible_vault': ['$ANSIBLE_VAULT;1.1;AES256\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaa==\n'], 'var': 'data'}

    # test_pairs is no VaultEncryptedUnicode, so we need set vault as default
    with tempfile.NamedTemporaryFile(mode='w+') as tmp:
        ansible_vault_secrets = tmp.name
        os.chmod(tmp.name, 0o600)
        tmp.write('12345')
        tmp.seek(0)

        AnsibleJSONDecoder._vaults = {}
        AnsibleJSONDecoder.set_secrets(secrets=[ansible_vault_secrets, ])

        #

# Generated at 2022-06-23 04:44:00.040664
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)
    assert isinstance(AnsibleJSONDecoder.set_secrets('test'), classmethod)
    assert isinstance(AnsibleJSONDecoder.object_hook('test'), str)
    decoder = json.JSONDecoder(*args, **kwargs)
    assert isinstance(decoder(), json.JSONDecoder)

# Generated at 2022-06-23 04:44:05.521916
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = [
        {
            "__ansible_vault": "test_value"
        }
    ]
    data = json.dumps(data, cls=AnsibleJSONEncoder)

    assert isinstance(json.loads(data, cls=AnsibleJSONDecoder), list)
    assert isinstance(json.loads(data, cls=AnsibleJSONDecoder)[0]['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:44:14.753493
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

    test_data1 = {'test': 1}
    test_data2 = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    test_data3 = {'__ansible_unsafe': dict(name='example', password='password')}

    assert test_data1 == decoder.decode(json.dumps(test_data1))
    assert test_data2 == decoder.decode(json.dumps(test_data2))
    assert test_data3 == decoder.decode(json.dumps(test_data3))

# Unit test to make sure the AnsibleJSONEncoder is working as expected

# Generated at 2022-06-23 04:44:15.412306
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:44:20.192584
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_dict = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;test\n1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
                 '__ansible_unsafe': '1234567890',
                 'key2': '$ANSIBLE_VAULT;1.1;AES256;test\n1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'}
    secret_list = ['test']
    AnsibleJSONDecoder.set_secrets(secret_list)

# Generated at 2022-06-23 04:44:23.064097
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert jd._vaults == {}


ANSIBLE_JSON_ENCODER = AnsibleJSONEncoder
ANSIBLE_JSON_DECODER = AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:34.894989
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    encoder = AnsibleJSONEncoder()

    # Set test secret
    secret = b'$ANSIBLE_VAULT;1.1;TESTING'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secret)

    # Test encoding with vault
    vault_data = {'__ansible_vault': b'value'}
    json_data = encoder.encode(vault_data)
    assert '__ansible_vault' in json_data
    assert 'VAULT' not in json_data

    # Test decoding with vault
    decoded_data = decoder.decode(json_data)
    assert decoded_data['__ansible_vault'] == b'value'
    assert decoded_data['__ansible_vault'].vault.secrets == secret



# Generated at 2022-06-23 04:44:38.337621
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    my_cls = AnsibleJSONDecoder()

    assert isinstance(my_cls, AnsibleJSONDecoder)

# Generated at 2022-06-23 04:44:48.444670
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = {'secrets': '$ANSIBLE_VAULT;1.2;AES256;ansible\n3335393064383039316232323664393762323463376564326265396633316230636537613630\n3439666663616335643937383335343964663161653732643161366333393733616437646539\n3134333165623331663163656138613366383639663330645a\n'}
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)

# Generated at 2022-06-23 04:45:00.124950
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Pass in a dictionary of secrets to the class constructor
    secrets = {'key1': 'mysecret', 'key2': 'mysecret'}
    AnsibleJSONDecoder.set_secrets(secrets)
    # Create an instance of class AnsibleJSONDecoder with the default constructor
    ansible_json_decoder = AnsibleJSONDecoder()
    # Create an instance of class AnsibleJSONDecoder with the constructor taking in *args and **kwargs
    ansible_json_decoder_args = AnsibleJSONDecoder(10, 1000, separators=(',', ':'), strict=True)
    # Create an instance of class AnsibleJSONEncoder
    ansible_json_encoder = AnsibleJSONEncoder()
    # Create a dictionary for encrypted string

# Generated at 2022-06-23 04:45:15.702272
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    class TestObject(object):

        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

    testobj = TestObject("test obj")


# Generated at 2022-06-23 04:45:17.666008
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None
    assert decoder.object_hook is not None

# Generated at 2022-06-23 04:45:30.606882
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Test json input with __ansible_vault
    ansible_json_str = '{"key1": "value1", "key2": "value2", "key3": "value3", "__ansible_vault": "vault_value"}'
    ansible_json = json.loads(ansible_json_str, cls=AnsibleJSONDecoder)
    assert ansible_json == {"key1": "value1", "key2": "value2", "key3": "value3", "__ansible_vault": ansible_json["__ansible_vault"]}

# Generated at 2022-06-23 04:45:33.749542
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert type(jd) == AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:46.109287
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # We need to pass an empty dict as the first argument to object_hook because
    # of how json.JSONDecoder is implemented.
    # In our test case, the first argument should be ignored as we don't make
    # use of it
    decoder = AnsibleJSONDecoder({})
    decoder.set_secrets('password')


# Generated at 2022-06-23 04:45:55.149628
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_passwords = ['secret1', 'secret2']
    json_str = '{"__ansible_vault": "vault_password"}'
    json_obj = json.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(json_str)
    vault_obj = AnsibleVaultEncryptedUnicode('vault_password')
    vault_obj.vault = VaultLib(secrets=test_passwords)

    assert json_obj == vault_obj

# Generated at 2022-06-23 04:46:05.158058
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ''' Unit test for constructor of class AnsibleJSONEncoder '''
    decoder = AnsibleJSONDecoder()

    secrets = [
        dict(
            vault_id='default',
            vault_password='ansible'
        )
    ]

    decoder.set_secrets(secrets)

    # decode a AnsibleVaultEncryptedUnicode object
    test_vault = '$ANSIBLE_VAULT;1.1;AES256\n' \
                 '63316235663634353965373633656237353133356164613336633637656664613161323165636165\n' \
                 '38363234626535376237656566656237623832613630343732\n'

    decoder.decode(test_vault)



# Generated at 2022-06-23 04:46:13.344422
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import StringIO

    test_data = StringIO.StringIO(u'''{
        "one": "Hello",
        "two": "${{'Hello'}} World",
        "three": {
            "__ansible_vault": "Hello World",
            "__ansible_unsafe": true
        }
    }''')

    secrets = ["My Secret"]
    j = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secrets)
    json.load(test_data, cls=j)

# Generated at 2022-06-23 04:46:24.928762
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:32.337622
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Unit test for AnsibleJSONDecoder.object_hook method
    test_obj = AnsibleJSONDecoder()
    result = test_obj.object_hook({'__ansible_vault': 'test', '__ansible_unsafe': 'test'})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == test_obj._vaults['default']

if __name__ == "__main__":
    test_AnsibleJSONDecoder_object_hook()

# Generated at 2022-06-23 04:46:43.620892
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.six import text_type
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:46:51.088768
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # should not pass anything to the constructor
    # but this is required to access the static member
    # of class AnsibleJSONEncoder
    ansible_json_decoder = AnsibleJSONDecoder(
        object_hook=ansible_json_decoder.object_hook
    )
    assert hasattr(ansible_json_decoder, '_vaults')

    # assert that the static member is set up on the instance
    assert isinstance(ansible_json_decoder._vaults, dict)

# Generated at 2022-06-23 04:46:55.660477
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_vault_data = '$ANSIBLE_VAULT;1.1;AES256;foo\nbar\nbaz\ndone'
    json_object = json.loads(test_vault_data, cls=AnsibleJSONDecoder)
    assert json_object == AnsibleVaultEncryptedUnicode(test_vault_data)


# Generated at 2022-06-23 04:47:06.305432
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({}) == {}
    assert decoder.object_hook({' not a key': 'test value'}) == {' not a key': 'test value'}

    pairs = decoder.object_hook({'__ansible_vault': 'test value'})
    assert pairs.__class__.__name__ == 'AnsibleVaultEncryptedUnicode'
    assert pairs.vault is None
    assert str(pairs) == str('test value')

    pairs = decoder.object_hook({'__ansible_unsafe': 'test value'})
    assert pairs.__class__.__name__ == 'AnsibleUnsafeText'
    assert str(pairs) == str('test value')

# Generated at 2022-06-23 04:47:10.321321
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    decoder = AnsibleJSONDecoder(object_hook=decoder.object_hook)
    assert decoder._vaults == {}

# Generated at 2022-06-23 04:47:11.695768
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ["12345"]
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:47:18.028695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dict_obj = dict()
    dict_obj['__ansible_vault'] = '12345'
    dict_obj['__ansible_unsafe'] = '12345'
    default_value = {'__ansible_vault': '12345', '__ansible_unsafe': '12345'}
    try:
        from collections import UserDict
        assert(dict_obj == default_value)
    except ImportError:
        assert(dict_obj.__dict__ == default_value)

# Generated at 2022-06-23 04:47:28.778358
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:47:38.220501
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
  # Test object_hook when key is equal to '__ansible_vault'
  result = AnsibleJSONDecoder.object_hook({ '__ansible_vault': 'p$c$oD4lW/s8sO1yppT/H0GQTcgP8EEw3Z4zteM4x'})
  assert type(result) == AnsibleVaultEncryptedUnicode

  # Test object_hook when key is equal to '__ansible_unsafe'
  result = AnsibleJSONDecoder.object_hook({ '__ansible_unsafe': 'p$c$oD4lW/s8sO1yppT/H0GQTcgP8EEw3Z4zteM4x'})
  assert type(result) == str or type(result) == unicode

# Generated at 2022-06-23 04:47:40.828560
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret_list = ['a', 'b']
    assert AnsibleJSONDecoder(secret_list)
    assert AnsibleJSONDecoder.set_secrets(secret_list)
    assert AnsibleJSONDecoder._vaults['default']


# Generated at 2022-06-23 04:47:45.414116
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # test set_secrets method of class AnsibleJSONDecoder
    assert getattr(AnsibleJSONDecoder, 'set_secrets')

    # test constructor of class AnsibleJSONDecoder
    assert getattr(AnsibleJSONDecoder, '__init__')

# Generated at 2022-06-23 04:47:47.710438
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    foo = AnsibleJSONDecoder(object_hook=lambda decoded: decoded)
    assert foo.object_hook is not None

# Generated at 2022-06-23 04:47:58.359228
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test with simple value
    value = { 'foo': 'bar' }

    decoder = AnsibleJSONDecoder()
    decoded_value = decoder.object_hook(value)

    assert('foo' in decoded_value)
    assert(decoded_value['foo'] == 'bar')

    # Test with secret value

# Generated at 2022-06-23 04:48:07.996303
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Tests method object_hook in class AnsibleJSONDecoder
    """
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    json_data = '{"__ansible_vault": "dummy_value"}'
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_vault_encrypted_unicode = ansible_json_decoder.object_hook(
        json.loads(json_data))
    assert(isinstance(ansible_vault_encrypted_unicode,
                      AnsibleVaultEncryptedUnicode))
    assert (ansible_vault_encrypted_unicode == 'dummy_value')
    json_data = '{"__ansible_unsafe": "dummy_value"}'
    ansible_unsafe_text = ansible_json_dec

# Generated at 2022-06-23 04:48:13.969296
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pairs = {
        'hello': 'world',
        '__ansible_vault': 'encrypted_text'
    }
    decoder = AnsibleJSONDecoder()
    parsed_json = decoder.object_hook(pairs)
    assert isinstance(parsed_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert parsed_json['hello'] == 'world'

# Generated at 2022-06-23 04:48:22.369067
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    payload = {
        '__ansible_vault': 'dGVzdA==',
        '__ansible_unsafe': 'ansible_var',
    }

    decoded_payload = decoder.object_hook(payload)

    assert isinstance(decoded_payload['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded_payload['__ansible_unsafe'].data == 'ansible_var'



# Generated at 2022-06-23 04:48:31.476739
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test with data that should not be decoded
    data = {'test': 'test_data'}
    pairs = decoder.object_hook(data)
    assert pairs == data

    # Test with data that should be decoded
    data = {'__ansible_vault': 'test_data', '__ansible_unsafe': 'test_data'}
    pairs = decoder.object_hook(data)
    assert pairs['__ansible_vault'].vault is None
    assert pairs['__ansible_unsafe'] == wrap_var('test_data')



# Generated at 2022-06-23 04:48:38.225460
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    result = {
        "__ansible_unsafe": "abc",
        "__ansible_vault": "secret"
    }

    assert AnsibleJSONDecoder.object_hook(result) == {
        "__ansible_unsafe": wrap_var("abc"),
        "__ansible_vault": AnsibleVaultEncryptedUnicode("secret")
    }

# Generated at 2022-06-23 04:48:46.319250
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    with open('data/json-decoder_payload.json') as f:
        input_data = f.readlines()
    payload = "".join(input_data)

    # create a AnsibleJSONDecoder object instance
    json_decoder = AnsibleJSONDecoder()
    # set a secret password
    json_decoder.set_secrets("hush")
    # decode a json string
    result = json_decoder.decode(payload)

    # test the result
    assert(result[0] == 'Hello')
    assert(result[1]['name'] == 'Alice')

# Generated at 2022-06-23 04:48:52.219710
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # old_style = '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\nblah\n"}'
    new_style = '{"__ansible_vault": "$ANSIBLE_VAULT;2.0;AES256;blah"}'
    decoder = AnsibleJSONDecoder()
    value = decoder.object_hook(json.loads(new_style))
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.vault is None

# Generated at 2022-06-23 04:49:03.078458
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import sys
    import unittest
    import inspect

    # Insert this directory to sys.path in order to import vault.py
    sys.path.insert(1, inspect.getabsfile(inspect.currentframe()))
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secrets = ['foo']  # needed for VaultLib.load()
    decoder = AnsibleJSONDecoder()

    test_data = [
        ('foo', 'foo'),
        ('__ansible_vault===foo', AnsibleVaultEncryptedUnicode('foo'))
    ]

    # Run tests
    for test_input, expected in test_data:
        decoder.set_secrets(secrets)
        result = decoder

# Generated at 2022-06-23 04:49:13.525016
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils import basic
    import sys

    # Generated from packetbeat/packetbeat-6.4.2-amd64.deb

# Generated at 2022-06-23 04:49:25.088686
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    def object_hook(pairs):
        for key in pairs:
            value = pairs[key]
            return value

    module_args = json.JSONDecoder(object_hook=object_hook)
    assert isinstance(module_args, json.JSONDecoder)

    #inits empty objecthook
    module_args = AnsibleJSONDecoder()
    assert isinstance(module_args, json.JSONDecoder)
    assert module_args.object_hook is not None
    assert module_args.parse_float is None
    assert module_args.parse_int is None
    assert module_args.parse_constant is None

    #inits with all kind of json arguments

# Generated at 2022-06-23 04:49:32.226003
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert {
        "__ansible_unsafe": "{{ foo }}"
    } == AnsibleJSONDecoder().object_hook({
        "__ansible_unsafe": "{{ foo }}"
    })

    assert {"__ansible_vault": "vault_data"} == AnsibleJSONDecoder().object_hook({
        "__ansible_vault": "vault_data"
    })


# Generated at 2022-06-23 04:49:37.798682
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"__ansible_vault": "vaultcontent"}
    value = AnsibleVaultEncryptedUnicode(data["__ansible_vault"])
    value_expected = {key: value}
    decoder = AnsibleJSONDecoder()
    decoder._vaults = {"default": VaultLib()}
    result = decoder.object_hook(data)
    assert value_expected == result

# Generated at 2022-06-23 04:49:50.246636
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_pairs = {
        '__ansible_vault': 'my_secret_value',
        '__ansible_unsafe': 'my_unsafe_value'
    }
    # Test for __ansible_vault
    decoded_pairs = AnsibleJSONDecoder.object_hook(json_pairs)
    expected_result = AnsibleVaultEncryptedUnicode('my_secret_value')
    assert(isinstance(decoded_pairs, type(expected_result)))
    assert(decoded_pairs.data == expected_result.data)
    decoded_pairs._decrypted_data()
    assert(decoded_pairs.data == 'my_secret_value')

    # Test for __ansible_unsafe

# Generated at 2022-06-23 04:49:51.236066
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        AnsibleJSONDecoder()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 04:49:52.723337
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder is not None

# Generated at 2022-06-23 04:49:56.337909
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'test'}
    result = decoder.object_hook(pairs)
    assert result == AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-23 04:50:05.477625
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder('{"__ansible_vault": "test"}')
    assert jd.decode('{"__ansible_vault": "test"}') == {'__ansible_vault': u'test'}
    assert isinstance(jd.decode('{"__ansible_vault": "test"}')['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert jd.decode('{"__ansible_unsafe": "test"}') == {'__ansible_unsafe': u'test'}
    assert isinstance(jd.decode('{"__ansible_unsafe": "test"}', {"__ansible_unsafe": "test"})['__ansible_unsafe'], AnsibleUnsafeText)