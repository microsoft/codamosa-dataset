

# Generated at 2022-06-23 04:40:07.467200
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    #__ansible_vault
    pairs = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook(pairs), AnsibleVaultEncryptedUnicode)

    #__ansible_unsafe
    pairs = {'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256'}
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder.object_hook(pairs), str)


# Generated at 2022-06-23 04:40:13.861310
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    f = open("./tests/unit/output/encrypt_vault_json")
    json_content = f.read()
    f.close()
    secret = 'foo'
    try:
        json.loads(json_content, cls=AnsibleJSONDecoder)
    except ValueError as e:
        assert str(e) == "The vault password must be a string or unicode object"
        pass
    AnsibleJSONDecoder.set_secrets(secret)
    loaded = json.loads(json_content, cls=AnsibleJSONDecoder)
    assert loaded['vault_id'] == 'ansible_vault_bar'
    assert loaded['vault_pw'] == 'foo'
    assert loaded['vault_file'] == './tests/unit/fixtures/vault_test_file'

# Generated at 2022-06-23 04:40:21.248826
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    AnsibleJSONEncoder._vaults['test'] = VaultLib('test')
    data = {
        'foo': 'bar',
        '__ansible_vault': 'foo',
    }
    decoded = AnsibleJSONDecoder().object_hook(data)
    assert decoded.get('foo') == 'bar'
    assert isinstance(decoded.get('__ansible_vault'), AnsibleVaultEncryptedUnicode)
    assert decoded.get('__ansible_vault')._vault == 'test'

# Generated at 2022-06-23 04:40:31.336678
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {
        '__ansible_vault': 'something',
        '__ansible_unsafe': 123,
        'manual_key': 'ABCD',
    }

    # Nothing to decode, no vault password
    decoded = AnsibleJSONDecoder().decode(json.dumps(data))
    assert decoded['__ansible_vault'] == 'something'
    assert decoded['__ansible_unsafe'] == 123
    assert decoded['manual_key'] == 'ABCD'
    assert hasattr(decoded['__ansible_vault'], 'vault') is False

    # Nothing to decode, password provided but is invalid
    AnsibleJSONDecoder.set_secrets('pass')
    decoded = AnsibleJSONDecoder().decode(json.dumps(data))
    assert decoded

# Generated at 2022-06-23 04:40:36.836299
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # Unsafe value
    assert decoder.object_hook({'__ansible_unsafe': 'val'}) == wrap_var('val')
    # Encrypted value
    assert isinstance(decoder.object_hook({'__ansible_vault': 'val'}), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:40:39.318865
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets([])

# Generated at 2022-06-23 04:40:46.312476
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:47.263074
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)



# Generated at 2022-06-23 04:40:50.845128
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'secret!'
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secret)
    assert decoder._vaults['default'].secrets == secret



# Generated at 2022-06-23 04:40:58.766884
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jsonData = {
        "__ansible_vault": "testVault",
        "__ansible_unsafe": "testUnsafe"
    }
    decodedData = AnsibleJSONDecoder().decode(json.dumps(jsonData))
    assert isinstance(decodedData['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decodedData['__ansible_unsafe'], wrap_var)
    assert decodedData['__ansible_vault'].vault is None
    assert not decodedData['__ansible_unsafe'].vault
    assert decodedData['__ansible_vault'].vault_text == "testVault"
    assert decodedData['__ansible_unsafe'].value == "testUnsafe"

# Generated at 2022-06-23 04:41:01.226623
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'test'
    json_decoder = AnsibleJSONDecoder()
    json_decoder.set_secrets(secret)
    assert json_decoder._vaults['default'] == VaultLib(secrets=secret)



# Generated at 2022-06-23 04:41:13.185228
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:41:17.166748
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_str = '''{
        "__ansible_unsafe": "eval $(ssh-agent -s)"
    }'''

    result = json.loads(json_str, cls=AnsibleJSONDecoder)

    assert result['__ansible_unsafe'] == 'eval $(ssh-agent -s)'
    assert result['__ansible_unsafe']._unsafe_proxy_wrapper is True

# Generated at 2022-06-23 04:41:18.256233
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Basic test for class instantiation
    a = AnsibleJSONDecoder()
    assert a



# Generated at 2022-06-23 04:41:18.667316
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:41:30.866900
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var, ANSIBLE_VARIABLE_PREFIX, UNSAFE_VARIABLE_MARKER

    # Initialize unit test encrypted string
    secrets = ['my_secret']
    vault_lib = VaultLib(secrets=secrets)
    encrypted_string = vault_lib.encrypt(b"my_secret_string")
    encrypted_string = encrypted_string[7:]

    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

# Generated at 2022-06-23 04:41:37.521356
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secret = 'foo'
    data = '{"__ansible_vault": {"__ansible_vault": "janesecret"}}'
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets(secret)
    assert decoder.object_hook(json.loads(data)) == {"__ansible_vault": AnsibleVaultEncryptedUnicode("janesecret")}



# Generated at 2022-06-23 04:41:40.018012
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = "password"
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder is not None

# Generated at 2022-06-23 04:41:41.597656
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    ansible_decoder = AnsibleJSONDecoder()
    assert ansible_decoder

# Generated at 2022-06-23 04:41:47.990379
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': 'dGVzdA==\n', '__ansible_unsafe': 'secret'}
    obj = decoder.object_hook(pairs)

    assert isinstance(obj['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(obj['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-23 04:41:59.200552
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    text = u'{"__ansible_unsafe": "<script>alert(\'hello\')</script>"}'
    res = json.loads(text, cls=AnsibleJSONDecoder)
    assert res['__ansible_unsafe'] == wrap_var('<script>alert(\'hello\')</script>')

    # test set_secrets
    cls = AnsibleJSONDecoder.__class__

    test_secret = 'mytestsecret'
    test_unencrypted = 'mytestvalue'

# Generated at 2022-06-23 04:42:15.246505
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    my_vault_dict = decoder.object_hook({'__ansible_vault': "this is ansible vault"})
    assert isinstance(my_vault_dict, AnsibleVaultEncryptedUnicode)
    assert my_vault_dict.vault.secrets == ['']
    assert my_vault_dict == "this is ansible vault"

    secrets = ['secret1', 'secret2']
    AnsibleJSONDecoder.set_secrets(secrets)
    my_vault_dict = decoder.object_hook({'__ansible_vault': "this is ansible vault"})
    assert isinstance(my_vault_dict, AnsibleVaultEncryptedUnicode)
    assert my_vault_dict.vault.secrets

# Generated at 2022-06-23 04:42:25.091298
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import random
    import os
    secrets = [('default', os.urandom(16))]
    AnsibleJSONDecoder.set_secrets(secrets)

    results = []
    while len(results) <= 1000:
        test_dict = {}
        key_len = random.randint(0, 20)
        for i in range(0, key_len):
            test_dict['key{}'.format(i)] = random.randint(0, 100)
        test_dict['__ansible_vault'] = 'my-secret'
        results.append(test_dict)

    for test_object in results:
        res = AnsibleJSONDecoder().object_hook(test_object)
        assert isinstance(res['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:42:37.984970
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    test function
    '''
    import json
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['defaulttestvalue'])

    obj_hook_dict = {'__ansible_vault': 'testvalue', '__ansible_unsafe': 'testvalue2'}
    result = decoder.object_hook(obj_hook_dict)

    assert(isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode))
    assert(isinstance(result['__ansible_unsafe'], dict))

    # decode the encrypted_data and assert the decoded value

# Generated at 2022-06-23 04:42:49.367210
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

    assert ansible_json_decoder.object_hook({}) == {}
    assert ansible_json_decoder.object_hook({'__ansible_vault': 'abc123'}) == AnsibleVaultEncryptedUnicode('abc123')
    assert ansible_json_decoder.object_hook({'__ansible_vault': 'abc123', '__ansible_unsafe': 'def456'})['__ansible_vault'] == AnsibleVaultEncryptedUnicode('abc123')
    assert ansible_json_decoder.object_hook({'__ansible_vault': 'abc123', '__ansible_unsafe': 'def456'})['__ansible_unsafe'] == wrap_var('def456')

# Generated at 2022-06-23 04:42:55.180607
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    secret = "secret"
    decoder.set_secrets([secret])

    encrypted = "$ANSIBLE_VAULT;1.1;AES256\n3436336535653436333239633162613162333539333033376265643163343164383934663534\n6462333662353432643462326336"
    pairs = {'__ansible_vault': encrypted}

    try:
        json.loads(json.dumps(pairs), cls=AnsibleJSONDecoder)
    except TypeError:
        assert False

    assert True

# Generated at 2022-06-23 04:43:06.280569
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # tests of case with vault
    json_string = ('{"a_password" : "value", '
                   '"__ansible_vault": "cGFzc3dvcmQ="}')
    secrets = ['password']
    AnsibleJSONDecoder.set_secrets(secrets)
    result = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert result['a_password'] == "value"
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault is not None
    assert result['__ansible_vault'].vault.secrets == secrets

# Generated at 2022-06-23 04:43:11.300586
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # Testing case: decoder is called
    json_test = json.dumps('abc', cls=AnsibleJSONEncoder)
    assert json.loads(json_test, cls=AnsibleJSONDecoder) == 'abc'

# Generated at 2022-06-23 04:43:22.085974
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook({u'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;test\n0000000000'})
    if not isinstance(result, AnsibleVaultEncryptedUnicode):
        raise AssertionError('AnsibleJSONDecoder.object_hook() should return instance of AnsibleVaultEncryptedUnicode')

    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook({u'__ansible_unsafe': 'test'})
    if not isinstance(result, unicode):
        raise AssertionError('AnsibleJSONDecoder.object_hook() should return instance of unicode')

# Generated at 2022-06-23 04:43:25.660167
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultLib
    test_secrets = 'test'
    vault_lib = VaultLib(secrets='test')
    AnsibleJSONDecoder.set_secrets(test_secrets)
    assert AnsibleJSONDecoder()._vaults['default'].secrets == vault_lib.secrets

# Generated at 2022-06-23 04:43:37.829802
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    value = {'__ansible_vault': 'xxxxxxxxx'}
    decoded_value = decoder.object_hook(value)
    assert isinstance(decoded_value, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:43:44.569312
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test that empty json string doesn't raise any exception
    AnsibleJSONDecoder('')
    AnsibleJSONDecoder('{}')
    AnsibleJSONDecoder('{"__ansible_vault": "Vaulted"}')
    AnsibleJSONDecoder('{"__ansible_unsafe": "unsafe_string: \"__ansible_unsafe\""}')


# Unit tests for class AnsibleJSONEncoder

# Generated at 2022-06-23 04:43:51.227559
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    inputs = {
        '__ansible_vault': 'foo',
        '__ansible_unsafe': 'bar'
    }

    expected = {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('foo'),
        '__ansible_unsafe': 'bar'
    }

    assert decoder.object_hook(inputs) == expected


# Generated at 2022-06-23 04:44:02.933208
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json1 = '''{
            "abc": 123,
            "__ansible_vault": "def",
            "ghi": "jkl"
        }'''

    json2 = '''{
            "abc": 123,
            "__ansible_unsafe": {
                "type": "str",
                "value": "mno"
            },
            "__ansible_vault": {
                "type": "str",
                "value": "pqr"
            }
        }'''

    vault_pass = 'secret'
    vault_secrets_file = '/path/to/secrets.file'

    # Should raise an exception when calling json.loads() with AnsibleJSONDecoder object
    # and no vault passwords are set

# Generated at 2022-06-23 04:44:14.719991
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:44:24.828415
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    sut = AnsibleJSONDecoder()

    # Test case no secrets by default
    assert {} == sut.object_hook({'__ansible_vault': 'my_content'})

    # Test case for AnsibleVaultEncryptedUnicode
    passwords = {'default': 'secret'}
    AnsibleJSONDecoder.set_secrets(passwords)
    assert AnsibleVaultEncryptedUnicode('my_content') == sut.object_hook({'__ansible_vault': 'my_content'})

    # Test case for wrap_var
    assert wrap_var({'some': 'value'}) == sut.object_hook({'__ansible_unsafe': {'some': 'value'}})

# Generated at 2022-06-23 04:44:35.558810
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(['password'])
    ansible_vault = json.dumps('$ANSIBLE_VAULT;1.1;AES256', cls=AnsibleJSONEncoder)
    pairs = json.loads(json.dumps({"__ansible_vault": ansible_vault}), cls=decoder)
    assert pairs['__ansible_vault'] == '$ANSIBLE_VAULT;1.1;AES256'
    assert pairs['__ansible_vault'] != '$ANSIBLE_VAULT;1.1;AES256'
    assert isinstance(pairs, dict)
    assert len(pairs) == 1

# Generated at 2022-06-23 04:44:47.009064
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['dummy']
    AnsibleJSONDecoder.set_secrets(secrets)
    # First line is the vault string with new line
    # Second line is the vault string in plain text

# Generated at 2022-06-23 04:44:58.591366
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # test normal construction
    with open('test_AnsibleJSONDecoder.json', 'r') as json_input_file:
        json_input = json_input_file.readlines()
    json_text = ''.join(json_input);
    json_object = json.loads(json_text, cls=AnsibleJSONDecoder)

    assert json_object['secret'] == "vaulted"
    assert json_object['nothing_special'] == "not_vaulted"

    # test empty string construction
    json_text = ''
    json_object = json.loads(json_text, cls=AnsibleJSONDecoder)

    # test construction with string
    json_text = '''{"a": "b"}'''

# Generated at 2022-06-23 04:45:00.220856
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)

# Generated at 2022-06-23 04:45:15.793318
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:21.438061
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils._text import to_native

    jd = AnsibleJSONDecoder()
    data = '{"test": 3}'

    res = jd.decode(data)

    assert 'test' in res
    assert res['test'] == 3

# Generated at 2022-06-23 04:45:23.927187
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_decoder = AnsibleJSONDecoder()
    assert test_decoder.object_hook

# Generated at 2022-06-23 04:45:28.468846
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # arrange
    json_str = '{"hello": "world"}'

    # act
    decoded = json.loads(json_str, cls=AnsibleJSONDecoder)

    # assert
    assert decoded['hello'] == 'world'



# Generated at 2022-06-23 04:45:32.006179
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'VaultEncryptedSecretString'
    json_decoder = AnsibleJSONDecoder()
    json_decoder.set_secrets(secrets = secrets)
    assert json_decoder.vaults['default'] == VaultLib(secrets = secrets)

# Generated at 2022-06-23 04:45:41.012643
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secret = VaultSecret('mysecret')
    vault_editor = VaultEditor(vault_secret)
    vault_password_file = vault_editor.create_file()
    vault_password_file.close()
    vault_secret.set_vault_password_file(vault_password_file.name)
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(vault_secret)
    # Use fixture with encrypted data and UnsafeText

# Generated at 2022-06-23 04:45:46.159049
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    s = '{"__ansible_vault": "vault", "__ansible_unsafe": "unsafe"}'
    assert decoder.object_hook(json.loads(s)) == {'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe'}

# Generated at 2022-06-23 04:45:50.971492
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    json_decoder = json.JSONDecoder()
    assert ansible_json_decoder.object_hook == json_decoder.object_hook


# Generated at 2022-06-23 04:46:01.112110
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoded = json.loads(
        '{"__ansible_vault": "sjdkfhaskjdhfksjhdfkjshdfjks", '
        '"__ansible_unsafe": "sjdfhkjsdhfksdfjsdkfhsdfhsdfjsd"}',
        cls=AnsibleJSONDecoder,
        object_hook=AnsibleJSONDecoder.object_hook
    )

    assert decoded[u'__ansible_vault'] == u'sjdkfhaskjdhfksjhdfkjshdfjks'


if __name__ == '__main__':
    test_AnsibleJSONDecoder()

# Generated at 2022-06-23 04:46:13.168406
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    # test AnsibleVaultEncryptedUnicode
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    # test wrap_var
    with pytest.raises(Exception):
        AnsibleJSONDecoder.object_hook({'__ansible_unsafe': {'__ansible_module_name': "json_decoder_test"}})
    # test AnsibleVaultEncryptedUnicode
    # vault is not initialized
    with pytest.raises(Exception):
        AnsibleJSONDecoder.object_hook({'__ansible_vault': 'test'})

# Test the class method set_secrets

# Generated at 2022-06-23 04:46:15.977115
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'secret'
    AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder()


# Generated at 2022-06-23 04:46:17.554735
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder is not None


# Generated at 2022-06-23 04:46:25.114249
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    #JSONDecoder constructor takes instancemethod object as json_decoder argument
    decoder = json.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    json_string = '{"__ansible_unsafe":"foo"}'
    assert decoder.decode(json_string) == {"__ansible_unsafe":"foo"}
    json_string = '{"__ansible_vault":"foo"}'
    assert decoder.decode(json_string) == AnsibleVaultEncryptedUnicode("foo")

# Generated at 2022-06-23 04:46:27.827591
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, json.JSONDecoder)



# Generated at 2022-06-23 04:46:38.809345
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    encoder = AnsibleJSONEncoder(sort_keys=True)
    decoder = AnsibleJSONDecoder()
    json_input = encoder.encode({'__ansible_vault': '$ANSIBLE_VAULT;\n0.9\n$ANSIBLE_VAULT;1.0;AES256\nAAAAA==\n'})
    obj = decoder.decode(json_input)
    assert(type(obj) == AnsibleVaultEncryptedUnicode)
    assert(obj.data == '$ANSIBLE_VAULT;\n0.9\n$ANSIBLE_VAULT;1.0;AES256\nAAAAA==\n')

# Generated at 2022-06-23 04:46:47.327062
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test cases

# Generated at 2022-06-23 04:46:52.834376
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret']
    test_obj = AnsibleJSONDecoder()
    test_obj.set_secrets(secrets)
    assert test_obj._vaults['default'] is not None
    assert test_obj._vaults['default'].secrets == secrets
    assert type(test_obj.object_hook('')) is str

# Generated at 2022-06-23 04:46:55.821341
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret1']
    assert secrets == AnsibleJSONDecoder.set_secrets(secrets)
    assert secrets == [v.secrets for v in AnsibleJSONDecoder._vaults.values()][0]


# Generated at 2022-06-23 04:46:59.559414
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''
    Test the constructor of AnsibleJSONDecoder
    '''
    # create a variable
    value = {'foo1': 'bar1'}
    # create the object
    ansible_json_decoder = AnsibleJSONDecoder()
    # invoke the object
    result = ansible_json_decoder.decode(json.dumps(value))
    # assert
    assert result == value, 'JSONDecoder constructor failed!'

# Generated at 2022-06-23 04:47:07.923503
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    text = '{"__ansible_vault": "ASDFAIHDFLAHSDJFLSDJALFJ"}'

    data = AnsibleJSONDecoder.decode(text)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)

    text = '{"__ansible_unsafe": "ASDFAIHDFLAHSDJFLSDJALFJ"}'

    data = AnsibleJSONDecoder.decode(text)
    assert isinstance(data, wrap_var)

# Generated at 2022-06-23 04:47:14.721005
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_json_str = '{"__ansible_vault": "test", "__ansible_unsafe": "test2"}'
    decoded_json = AnsibleJSONDecoder().decode(test_json_str)
    assert isinstance(decoded_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded_json['__ansible_unsafe'], wrap_var)



# Generated at 2022-06-23 04:47:20.505783
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['secret']
    AnsibleJSONDecoder.set_secrets(secrets)

    # Create a dictionary
    data = {'foo': 'bar', 'baz': 42}

    # Encoded the dictionary into a JSON string
    data_json_string = json.dumps(data, cls=AnsibleJSONEncoder)

    # Decode the JSON string into the original data
    data_reconstructed = json.loads(data_json_string, cls=AnsibleJSONDecoder)

    assert data == data_reconstructed

# Generated at 2022-06-23 04:47:29.505413
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:38.146516
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    '''

    :return:
    '''

    def object_hook(pairs):
        for key in pairs:
            value = pairs[key]
            if key == 'a':
                return {'b': value}
            elif key == '__ansible_vault':
                return {'__ansible_vault': value}
            elif key == '__ansible_unsafe':
                return {'__ansible_unsafe': value}
        return pairs

    ansible_json_decoder = AnsibleJSONDecoder(object_hook=object_hook)

    json_str = '{"a": "1"}'
    ansible_json_decoder.decode(json_str)

# Generated at 2022-06-23 04:47:49.959118
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = dict(__ansible_vault='$ANSIBLE_VAULT;1.1;AES256;joe\n3333323333323033333313835333333373333303437353633333310a3736333735343334333233353330393333383032333033323533\n393535333330333333353431373331343137313330333833333337333733')
    test_data['__ansible_unsafe'] = dict(value='I was unsafe')


# Generated at 2022-06-23 04:48:00.427225
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Failed to wrap invalid unsafe
    unsafe_obj = dict()
    unsafe_obj['__ansible_unsafe'] = 'test_unsafe'
    result_unsafe = AnsibleJSONDecoder.object_hook(unsafe_obj)
    assert result_unsafe.get('__ansible_unsafe') == 'test_unsafe'

    # Failed to wrap valid unsafe
    unsafe_obj['__ansible_unsafe'] = dict()
    unsafe_obj['__ansible_unsafe']['__ansible_module__'] = 'test'
    unsafe_obj['__ansible_unsafe']['__ansible_arguments__'] = dict()
    unsafe_obj['__ansible_unsafe']['__ansible_arguments__']['a'] = 1

# Generated at 2022-06-23 04:48:12.907635
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Set up
    data = {}
    ansible_vault_value = 'sample'
    ansible_unsafe_value = 'sample'
    data['__ansible_vault'] = ansible_vault_value
    data['__ansible_unsafe'] = ansible_unsafe_value

    # Test
    decoder = AnsibleJSONDecoder()
    result = decoder.object_hook(data)
    assert result['__ansible_vault'] == ansible_vault_value
    assert result['__ansible_unsafe'] == ansible_unsafe_value

    # Tear down
    data.clear()

# Generated at 2022-06-23 04:48:17.647732
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    assert decoder.object_hook == decoder.object_hook


# Generated at 2022-06-23 04:48:27.390984
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Testing with __ansible_vault when there are no vaults
    j = {'__ansible_vault': 'vaultvalue1'}
    assert j == json.loads(json.dumps(j), cls=AnsibleJSONDecoder)

    # Testing with __ansible_vault and there are vaults
    j2 = {'_ansible_vault': 'vaultvalue2', '__ansible_vault': 'vaultvalue3', '__ansible_unsafe': 'unsafevalue'}
    AnsibleJSONDecoder.set_secrets(['mysecret'])
    assert j2 == json.loads(json.dumps(j2), cls=AnsibleJSONDecoder)



# Generated at 2022-06-23 04:48:38.460285
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import os
    import tempfile

    script_dir = os.path.dirname(os.path.realpath(__file__))
    f = open(os.path.join(script_dir, 'data', 'AnsibleJSONDecoder_object_hook.json'))
    data = f.read()
    f.close()
    data = json.loads(data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-23 04:48:41.645587
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': True}) == wrap_var(True)
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': 'abc'}) == AnsibleVaultEncryptedUnicode('abc')



# Generated at 2022-06-23 04:48:54.694648
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [
        'this-is-a-secret'
    ]

# Generated at 2022-06-23 04:49:04.277226
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Setup
    decoder = AnsibleJSONDecoder()
    payload = {
        "stringType": "string value",
        "numberType": 123,
        "__ansible_vault": "test_vault",
        "__ansible_unsafe": "test_unsafe"
    }
    # Execute
    result = decoder.object_hook(payload)
    # Verify
    # Values that are not recognized are not modified
    assert result['stringType'] == payload['stringType']
    assert result['numberType'] == payload['numberType']
    # Values that are recognized are modified
    assert type(result['__ansible_vault']) is AnsibleVaultEncryptedUnicode
    assert result['__ansible_vault'].vault is None
    assert result['__ansible_vault'].data

# Generated at 2022-06-23 04:49:06.709186
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = AnsibleJSONDecoder()
    assert isinstance(obj, AnsibleJSONDecoder)
    assert isinstance(obj, json.JSONDecoder)

# Generated at 2022-06-23 04:49:09.284557
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    try:
        ansible_json_decoder = AnsibleJSONDecoder()
    except Exception as e:
        assert False, "Failed to use constructor of class AnsibleJSONDecoder in ansible.module_utils.common.json."


# Generated at 2022-06-23 04:49:11.140218
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert issubclass(AnsibleJSONDecoder, json.JSONDecoder)


# Generated at 2022-06-23 04:49:13.600343
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}

    # test whether object_hook function is properly set
    assert decoder.object_hook == decoder._vaults

# Generated at 2022-06-23 04:49:18.772903
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    results = json.loads('{"key": "value"}', cls=AnsibleJSONDecoder)
    assert isinstance(results, dict)
    assert results['key'] == 'value'
    assert len(results) == 1


# Generated at 2022-06-23 04:49:27.109950
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = json.loads('{"__ansible_vault": "ZV7jGQYrnyXg3hq3g5y5Mg=="}', cls=AnsibleJSONDecoder)
    assert isinstance(decoded, AnsibleVaultEncryptedUnicode)

    decoded = json.loads('{"__ansible_unsafe": "ZV7jGQYrnyXg3hq3g5y5Mg=="}', cls=AnsibleJSONDecoder)
    assert isinstance(decoded, AnsibleUnsafeText)

# Generated at 2022-06-23 04:49:38.362521
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:44.795416
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_text = ('{"__ansible_vault": "AES256:cs31JGvzOwT1T0xzBditMVNNMv1j7854EIeQX6HlLko=\n", "__ansible_unsafe": "unsafe_test"}')
    data_input = json.loads(json_text, cls=AnsibleJSONDecoder)
    assert isinstance(data_input['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(data_input['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-23 04:49:47.040754
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook
    assert decoder._vaults == {}


# Generated at 2022-06-23 04:49:57.200853
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ''' unit test for AnsibleJSONDecoder.object_hook() '''

    # a toy json structure
    structure = {'a': '1', '__ansible_vault': {'password': 'secret'}}
    # create the json decoder using it's default object_hook method
    default_object_hook_decoder = AnsibleJSONDecoder()
    # decode the json
    pairs = default_object_hook_decoder.decode(json.dumps(structure))
    # the returned dictionary
    assert isinstance(pairs, dict)
    # there should be two keys
    assert len(pairs) == 2
    # the first should be 'a'
    assert 'a' in pairs
    # and should have a string value of '1'
    assert isinstance(pairs['a'], str)
    assert pairs

# Generated at 2022-06-23 04:50:01.788175
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded = json.loads(json.dumps({
        'foo': 'bar',
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n34626163313...'
    }), cls=AnsibleJSONDecoder)

    assert isinstance(decoded['foo'], str)
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)