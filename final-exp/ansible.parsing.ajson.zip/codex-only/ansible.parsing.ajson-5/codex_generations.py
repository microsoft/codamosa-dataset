

# Generated at 2022-06-23 04:40:09.780848
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_obj = {'__ansible_unsafe': '$bar', 'baz': 'qux'}
    # Unit test for __main__.AnsibleJSONDecoder.set_secrets
    AnsibleJSONDecoder.set_secrets(['password'])
    # Unit test for __main__.AnsibleJSONDecoder.object_hook
    decoder = AnsibleJSONDecoder.object_hook(test_obj)
    assert decoder['__ansible_unsafe'] == wrap_var('$bar')
    assert decoder['baz'] == 'qux'


# Generated at 2022-06-23 04:40:12.041604
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder._vaults == {}
    assert AnsibleJSONDecoder().object_hook({'__ansible_unsafe':'password'}) == wrap_var('password')

# Generated at 2022-06-23 04:40:14.243799
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

    assert decoder.object_hook

# Generated at 2022-06-23 04:40:22.259935
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoded_json = '{"__ansible_vault": "This is encrypted"}'
    default_vault = VaultLib()
    AnsibleJSONDecoder.set_secrets("mysecret")
    decoded_object = AnsibleJSONDecoder().decode(decoded_json)
    encrypted_message = str(decoded_object['__ansible_vault'])
    decoded_message = default_vault.decrypt(encrypted_message)
    assert decoded_message == "This is encrypted", "Vaulted message was not decoded correctly"



# Generated at 2022-06-23 04:40:30.562086
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-23 04:40:40.710779
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    def _test_fixtures():
        yield dict(json_data=('{"__ansible_vault": "123"}'),
                   expected=AnsibleVaultEncryptedUnicode('123'))
        yield dict(json_data=('{"__ansible_unsafe": "123"}'),
                   expected=wrap_var('123'))
        yield dict(json_data=('{"a": "2", "__ansible_unsafe": "123"}'),
                   expected=dict(a='2', __ansible_unsafe=wrap_var('123')))

# Generated at 2022-06-23 04:40:43.102646
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert isinstance(AnsibleJSONDecoder(), json.JSONDecoder)

# Generated at 2022-06-23 04:40:47.564690
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'superdupersecret'
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(secrets)
    assert ansible_json_decoder._vaults['default'] is not None

# Generated at 2022-06-23 04:40:50.024803
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook is not None

# Generated at 2022-06-23 04:40:50.718286
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()



# Generated at 2022-06-23 04:40:56.241893
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test for AnsibleVaultEncryptedUnicode class
    assert isinstance(json.loads('{"__ansible_vault": "ABCDEFGHIJKLMNOPQRSTUVWXYZ"}',
                        cls=AnsibleJSONDecoder).obj, AnsibleVaultEncryptedUnicode) is True
    # Test for wrap_var
    assert isinstance(json.loads('{"__ansible_unsafe": "ABCDEFGHIJKLMNOPQRSTUVWXYZ"}',
                        cls=AnsibleJSONDecoder).obj, wrap_var) is True

# Generated at 2022-06-23 04:40:58.012949
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    d = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert d is not None


# Generated at 2022-06-23 04:41:03.790264
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    vault_secret = VaultSecret('foo')
    vault_secret.set_vault_id('foo')

    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(vault_secret)

    assert decoder.decode('{"__ansible_vault": "blah"}') == AnsibleVaultEncryptedUnicode('blah')
    assert decoder.decode('{"__ansible_unsafe": "blah"}') == AnsibleUnsafeText('blah')

# Generated at 2022-06-23 04:41:04.244665
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert 0 == 1

# Generated at 2022-06-23 04:41:17.504174
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:22.402497
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    my_vars = json.loads('{"key":"value", "__ansible_vault": "test"}', cls=AnsibleJSONDecoder)
    assert 'key' in my_vars
    assert '__ansible_vault' in my_vars


# Generated at 2022-06-23 04:41:27.981649
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = '{"__ansible_vault": "my_secret"}'
    json_data = json.loads(data, cls=AnsibleJSONDecoder)
    assert isinstance(json_data, AnsibleVaultEncryptedUnicode)
    assert bytes == type(json_data.vault._VaultLib__secrets)



# Generated at 2022-06-23 04:41:39.581775
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['secret1']
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:41:46.125241
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s = """
    {
        "__ansible_vault": "hello"
    }
    """

    d = AnsibleJSONDecoder()
    d.set_secrets(['secret'])
    obj = d.decode(s)
    assert isinstance(obj, dict)
    assert b'hello' == obj.get('__ansible_vault').vault.decrypt(obj.get('__ansible_vault'))

# Generated at 2022-06-23 04:41:57.538866
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_pairs = {"__ansible_vault": "my-secret-string"}

    # Create object_hook
    hook = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).object_hook

    # Test object hook
    assert hook(test_pairs) == {"__ansible_vault": "my-secret-string"}

    # Set a secret
    AnsibleJSONDecoder.set_secrets(["my-secret"])
    hook = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).object_hook

    # Test object hook
    assert hook(test_pairs) == {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('my-secret-string')
    }


# Generated at 2022-06-23 04:42:08.809414
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    # test with secrets
    secrets = ['a', 'b']
    decoder = AnsibleJSONDecoder(object_hook=lambda x: x, secrets=secrets)
    # test if secrets are stored
    assert decoder._vaults['default'].secrets == secrets
    assert decoder._vaults['default'].password is None

    # test without secrets
    decoder = AnsibleJSONDecoder(object_hook=lambda x: x)
    assert decoder._vaults == {}

# Generated at 2022-06-23 04:42:10.575008
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()


# Generated at 2022-06-23 04:42:15.628581
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['test_secret']

# Generated at 2022-06-23 04:42:25.121209
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    fp = open("./test/data/test_ansible_json_decoder_object_hook.json", "r")
    json_data = json.load(fp, cls=AnsibleJSONDecoder)
    assert json_data is not None
    assert json_data['name'] == 'ansible-json-decoder'
    assert type(json_data['value']) == str

# Generated at 2022-06-23 04:42:37.973264
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '''{
        "__ansible_vault": "ANSIBLE_VAULT;1.2;AES256;ansible\n39623862303534333630343166626333393362353334663463623761633832376263313236386566\n376432393165383337663734613033373035326131666232626234313761320a613136396538646131\n3730666565646637386332626331623865366535393065613335326162653166396638643866306439\n373262623139323834373939303837353839\n"
    }'''
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:39.188045
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder

# Generated at 2022-06-23 04:42:49.680168
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_pass = '$ANSIBLE_VAULT;1.1;AES256'
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=[vault_pass])

# Generated at 2022-06-23 04:42:55.843124
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'password'
    decoder = AnsibleJSONDecoder()
    assert(not decoder._vaults)
    decoder.set_secrets(secret)
    assert(len(decoder._vaults) == 1)
    assert(decoder._vaults['default'])
    assert(decoder._vaults['default'].secrets == secret)

# Generated at 2022-06-23 04:43:07.338903
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:18.531559
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Test that the object_hook converts vault and unsafe variables.
    """
    # Since we can't access the real _vaults value in the AnsibleJSONDecoder,
    # we just pass the vault_secrets to AnsibleVaultEncryptedUnicode.
    vault_secrets = ["thisisatest"]

    # vault
    data = '{"__ansible_vault": "instance.secret_key"}'
    json_dict = json.loads(data,
        cls=AnsibleJSONDecoder,
        # vault_secrets=vault_secrets
        )
    assert isinstance(json_dict, AnsibleVaultEncryptedUnicode)
    assert json_dict == "instance.secret_key"

    # unsafe

# Generated at 2022-06-23 04:43:27.019160
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"__ansible_vault": "TestVaultEncryptedUnicode"}'
    j = AnsibleJSONDecoder()
    obj = j.decode(data)
    assert obj['__ansible_vault'] == "TestVaultEncryptedUnicode"

    data = '{"__ansible_unsafe": "TestUnsafeProxy"}'
    j = AnsibleJSONDecoder()
    obj = j.decode(data)
    assert obj['__ansible_unsafe'] == "TestUnsafeProxy"

# Generated at 2022-06-23 04:43:39.093605
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    mock_dict1 = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\ndGhhdCdzIGEgdmF1bHQga2V5\n',
        '__ansible_unsafe': '{changed: True, foo: bar}',
    }

    mock_dict2 = {
        u'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\ndGhhdCdzIGEgdmF1bHQga2V5\n',
        u'__ansible_unsafe': '{changed: True, foo: bar}',
    }

    mock_json1 = json.dumps(mock_dict1, cls=AnsibleJSONEncoder)
    mock_json2 = json.d

# Generated at 2022-06-23 04:43:48.891328
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.common.json import (
        AnsibleJSONEncoder,
        AnsibleJSONDecoder,
    )
    import json

    plain_text = "plain_text"

    # Make instance of AnsibleDumper
    dumper = AnsibleDumper()

    # Make instance of AnsibleJSONEncoder
    json_encoder = AnsibleJSONEncoder()

    # Make instance of AnsibleJSONDecoder
    json_decoder = AnsibleJSONDecoder()

    # Convert to JSON
    json_data = json.loads(json_encoder.encode(dumper.representer.represent_str(plain_text)), cls=AnsibleJSONDecoder)

    # assert_equal

# Generated at 2022-06-23 04:44:00.838148
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # case 1: no object_hook, return dict
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': '1234'}
    result = decoder.object_hook(pairs)
    assert result == pairs

    # case 2: call object_hook, not decrypt
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': '1234'}
    result = decoder.object_hook(pairs)
    assert result == pairs

    # case 3: call object_hook, return AnsibleVaultEncryptedUnicode
    decoder = AnsibleJSONDecoder()
    pairs = {'__ansible_vault': '1234'}
    AnsibleJSONDecoder.set_secrets(['1234'])
    result = decoder.object

# Generated at 2022-06-23 04:44:08.326231
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_vars = {'foo': 'bar'}

    json_vars = json.dumps(test_vars, cls=AnsibleJSONEncoder)

    # Test 1
    json_vars_bytes = json_vars.encode('utf-8')
    decoded_vars = json.loads(json_vars_bytes, cls=AnsibleJSONDecoder)

    assert decoded_vars == test_vars, "AnsibleJSONDecoder test1 failed"

    # Test 2
    decoded_vars = json.loads(json_vars, cls=AnsibleJSONDecoder)

    assert decoded_vars == test_vars, "AnsibleJSONDecoder test2 failed"

# Generated at 2022-06-23 04:44:16.265079
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()

    # Test empty dict
    assert dec.object_hook({}) == {}

    # Test that with a __ansible_vault key, the decoded value is an AnsibleVaultEncryptedUnicode object
    dec_vault = dec.object_hook({'__ansible_vault': 'foo'})
    assert isinstance(dec_vault, AnsibleVaultEncryptedUnicode)
    assert dec_vault == 'foo'

    # Test that with a __ansible_unsafe key, the decoded value is wrapped with wrap_var
    # Test that wrap var returns an object of type AnsibleUnsafeText
    unsafe_text_obj = wrap_var('foo')
    dec_unsafe = dec.object_hook({'__ansible_unsafe': 'foo'})

# Generated at 2022-06-23 04:44:16.977610
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    pass

# Generated at 2022-06-23 04:44:19.861741
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """Unit test for constructor of class AnsibleJSONDecoder"""

    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder

# Generated at 2022-06-23 04:44:26.877349
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    values = {'foo': 'bar'}
    assert AnsibleJSONDecoder.object_hook(values) == values

    values = {'__ansible_unsafe': '/bin/rm -rf /'}
    assert AnsibleJSONDecoder.object_hook(values) == wrap_var('/bin/rm -rf /')

    values = {'__ansible_vault': '123456'}
    assert isinstance(AnsibleJSONDecoder.object_hook(values), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:44:35.515705
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_obj = {'__ansible_vault': 'gAAAAABdf5vHGdS5S_0gMCZhNfZGv-HNcVLn', '__ansible_unsafe': 'Not safe'}
    decoder = AnsibleJSONDecoder()
    assert decoder.decode(json.dumps(json_obj)) == \
        {'__ansible_vault': AnsibleVaultEncryptedUnicode("gAAAAABdf5vHGdS5S_0gMCZhNfZGv-HNcVLn"), '__ansible_unsafe': wrap_var("Not safe")}

# Generated at 2022-06-23 04:44:45.721968
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    # Set secret value in class variable
    decoder.set_secrets('password')
    data = {
        '__ansible_vault': 'vault_text',
        '__ansible_unsafe': 'safe_var'
    }
    data_to_decode = json.dumps(data)
    actual = decoder.decode(data_to_decode)
    # Verify secret value is set
    assert actual['__ansible_vault'].vault.secrets == ['password']
    # Verify value for __ansible_unsafe is returned
    assert 'safe_var' == actual['__ansible_unsafe']

# Generated at 2022-06-23 04:44:57.554924
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:06.783397
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:45:18.026468
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:45:30.647838
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()

    # Test with the AnsibleVaultEncryptedUnicode
    # Test set_secrets

# Generated at 2022-06-23 04:45:32.976742
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    my_decoder = AnsibleJSONDecoder()
    assert hasattr(my_decoder, 'object_hook')

# Generated at 2022-06-23 04:45:38.806137
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class AnsibleJSONDecoderTest(AnsibleJSONDecoder):
        pass

    jd_test = AnsibleJSONDecoderTest()
    assert isinstance(jd_test, AnsibleJSONDecoderTest)
    assert jd_test.object_hook is not None


# Generated at 2022-06-23 04:45:51.278986
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = '$ANSIBLE_VAULT;1.1;AES256\n36373338666434356664353438643861306435373761343435306439343339366561636337663133\n35343735333166643637376635363635333035373936343339326435343836623332623561643131\n33383566616233306361363833383038363539626635643033636438393962363065343130663362\n62326262623730666231623230333031636431383632626363666530623938343564616539383530\n37376330623201650a'
    decoder = AnsibleJSONDecoder()
    decoder.set_sec

# Generated at 2022-06-23 04:45:52.719191
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    def object_hook(pairs):
        return pairs

    decoder = AnsibleJSONDecoder(object_hook=object_hook)
    assert decoder.object_hook == object_hook


# Generated at 2022-06-23 04:45:58.465333
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    secret_encoded = {"__ansible_vault": "MYVAULT"}
    secret_decoded = {"__ansible_vault": AnsibleVaultEncryptedUnicode("MYVAULT")}
    assert decoder.decode(secret_encoded) == secret_decoded

# Generated at 2022-06-23 04:46:01.478103
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ''' ansible.module_utils.common.json.AnsibleJSONDecoder should be a subclass of json.JSONDecoder'''
    assert issubclass(AnsibleJSONDecoder, json.JSONDecoder)

# Generated at 2022-06-23 04:46:08.840892
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import timeit
    import os
    t = timeit.Timer()
    json_file = os.path.join(os.path.dirname(__file__), "data/fixtures.json")
    s = t.timeit(number=1, stmt='AnsibleJSONDecoder().decode(open("%s").read())' % json_file)
    assert s > 0



# Generated at 2022-06-23 04:46:17.190699
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = '$ANSIBLE_VAULT;1.1;AES256\
    39643433633139313231656132393437326564663365643931643964656334626566343761666364\
    653135313532663963393962636631666230336236633939623661636533393731396161393337\
    6135336535'
    decoder = AnsibleJSONDecoder()
    decoder = AnsibleJSONDecoder.set_secrets(secret)

# Generated at 2022-06-23 04:46:23.749077
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert type(decoder.object_hook({'__ansible_vault': 'bar'})) is AnsibleVaultEncryptedUnicode
    assert type(decoder.object_hook({'__ansible_vault': 'bar'}).vault) is VaultLib
    assert type(decoder.object_hook({'__ansible_unsafe': 'bar'})) is str

# Generated at 2022-06-23 04:46:35.771866
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:45.765345
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleSequence

    secret_value = "abc123"
    vault_string = b"$ANSIBLE_VAULT;" + secret_value.encode("utf-8") + b";" +\
        AnsibleVaultEncryptedUnicode("my_secret_value", vault=VaultLib(secrets=[secret_value])).encode("utf-8")

    data = {
        "__ansible_unsafe": "my_unsafe_value",
        "__ansible_vault": vault_string
    }

    unsafe_proxy_value = wrap_var("my_unsafe_value")
    decoded_values = json.loads(json.dumps(data), cls=AnsibleJSONDecoder)


# Generated at 2022-06-23 04:46:53.452987
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [['password1', 'password2'], 'password3']
    decoder = AnsibleJSONDecoder()
    decoder.set_secrets(secrets)
    vault_str = '{"__ansible_vault":"vault_pwd"}'
    expected = {'__ansible_vault': AnsibleVaultEncryptedUnicode('vault_pwd')}
    expected['__ansible_vault'].vault = decoder._vaults['default']
    assert decoder.decode(vault_str) == expected

# Generated at 2022-06-23 04:47:00.993561
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.parsing.yaml import objects
    from ansible.utils.unsafe_proxy import set_unsafe_proxy_tempfile
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    set_unsafe_proxy_tempfile()

    decoder = AnsibleJSONDecoder()
    secret = 'this-is-not-so-secret'


# Generated at 2022-06-23 04:47:09.561400
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = ['foo']
    data = {"ansible_vault": "asdfasdf"}
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(secrets)
    ob = json.loads(json.dumps(data), cls=ansible_json_decoder.__class__)
    assert isinstance(ob, AnsibleVaultEncryptedUnicode)
    assert ob.vault is not None



# Generated at 2022-06-23 04:47:19.244335
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;myhost\n          6364376239613164623662633235396432616362333161306434323064636665\n          6138366233363566653830313762393965313033376363363531316433363961\n          303534386633336131\n          "}
    decoder = AnsibleJSONDecoder()
    # TODO: catch exception if vault password is not set
    # decoder.set_secrets("password")
    decoded_data = decoder.decode(json.dumps(data))
    encrypted_data = decoded_data.decode('utf-8')
    # TODO: catch exception

# Generated at 2022-06-23 04:47:21.097756
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ad = AnsibleJSONDecoder(object_hook=None)
    assert ad.object_hook is not None


# Generated at 2022-06-23 04:47:29.847170
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import ansible.utils.vars
    from ansible.parsing.vault import AVAILABLE_KEY_TYPES


# Generated at 2022-06-23 04:47:36.048156
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '''{
                    "__ansible_vault": "test",
                    "__ansible_unsafe": "test" 
                  }'''

    try:
        assert AnsibleJSONDecoder.object_hook(json_data) == {'__ansible_unsafe': 'test', '__ansible_vault': u'test'}
        assert AnsibleJSONDecoder.set_secrets("test_secrets") == None
    except AssertionError:
        print("Failed")


# Generated at 2022-06-23 04:47:43.907522
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap
    from ansible.module_utils.common.json import from_json
    encrypted_vault_text = textwrap.dedent('''\
        {
            "__ansible_vault": "foo"
        }''')
    decrypted_vault_text = textwrap.dedent('''\
        {
            "__ansible_vault": "bar"
        }''')
    unsafe_text = textwrap.dedent('''\
        {
            "__ansible_unsafe": true
        }''')
    safe_text = textwrap.dedent('''\
        {
            "__ansible_unsafe": false
        }''')

# Generated at 2022-06-23 04:47:52.612552
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import random
    import string

    random_variable = "".join(random.choice(string.ascii_lowercase) for _ in range(10))

    # Unit test for object_hook method with `__ansible_vault` key
    vault_id = ''.join(random.choice(string.ascii_lowercase) for _ in range(10))
    my_secret = ''.join(random.choice(string.ascii_lowercase) for _ in range(10))
    vault_password_file = os.path.join(os.getcwd(), '%s.txt' % vault_id)
    with open(vault_password_file, 'w') as f:
        f.write('%s\n' % my_secret)

    my_str = 'hello world'
    enc

# Generated at 2022-06-23 04:48:02.312713
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:48:11.382212
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({"__ansible_vault": "vault_test"}) == AnsibleVaultEncryptedUnicode("vault_test")
    assert decoder.object_hook({"__ansible_unsafe": "unsafe_test"}) == wrap_var("unsafe_test")
    assert decoder.object_hook({"key": "value"}) == {"key": "value"}
    assert decoder.object_hook({"key": "value", "__ansible_unsafe": "unsafe_test"}) == {"key": "value", "__ansible_unsafe": "unsafe_test"}

# Generated at 2022-06-23 04:48:22.615454
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # simple value
    assert decoder.object_hook({}) == {}

    # ansible vault with secrets
    secrets = [dict(src='/tmp/file/name.yml', vault_id='default')]
    decoder.set_secrets(secrets)
    value = decoder.object_hook({'__ansible_vault': {'enc': '$ANSIBLE_VAULT;1.1;AES256\n...\n'}})
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.vault.secrets == secrets

    # ansible vault without secrets
    secrets = []
    decoder.set_secrets(secrets)

# Generated at 2022-06-23 04:48:32.166849
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.six.moves import StringIO

    secrets = 'test'
    AnsibleJSONDecoder.set_secrets(secrets)

    json_data = StringIO('''
    {
        "__ansible_vault": "foo",
        "__ansible_unsafe": "bar"
    }''')

    obj = json.load(json_data, cls=AnsibleJSONDecoder)

    # check that the vault was decrypted
    assert obj['__ansible_vault'] == "foo"

    # check that the unsafe was wrapped
    assert isinstance(obj['__ansible_unsafe'], wrap_var)


# Generated at 2022-06-23 04:48:34.515889
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder

# Generated at 2022-06-23 04:48:44.974032
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    decoder._vaults['default'] = VaultLib(secrets=['default_secret'])
    pairs = {'foo': 42, '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;default;32423423423fdfffdff234234234', '__ansible_unsafe': wrap_var('bar')}
    data = decoder.object_hook(pairs)
    assert data['foo'] == 42
    assert data['__ansible_vault'].data == 'bar'
    assert data['__ansible_vault'].vault.secrets == ['default_secret']
    assert data['__ansible_unsafe'] == wrap_var('bar')


# Imported for backwards compat

# Generated at 2022-06-23 04:48:46.354046
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder is not None



# Generated at 2022-06-23 04:48:48.101068
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    obj = AnsibleJSONDecoder()
    assert isinstance(obj, AnsibleJSONDecoder)


# Generated at 2022-06-23 04:48:58.529343
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    s = decoder.object_hook({"k1": "v1", "k2": "v2"})
    assert s == {"k1": "v1", "k2": "v2"}
    s = decoder.object_hook({"k1": "{{ some_var }}", "k2": "v2", "__ansible_unsafe": True})
    assert s == {"k1": "{{ some_var }}", "k2": "v2"}
    s = decoder.object_hook({"k1": "{{ some_var }}", "k2": "v2", "__ansible_vault": "ABCDEFG"})
    assert isinstance(s, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-23 04:49:01.627470
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()
    assert AnsibleJSONDecoder() is not AnsibleJSONDecoder()



# Generated at 2022-06-23 04:49:12.724141
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import tempfile

    decoder = AnsibleJSONDecoder()

    # Test object_hook will decrypt vaulted string
    test_string = 'vaulted_string'
    secrets = ['test']
    AnsibleJSONDecoder.set_secrets(secrets)
    vault_string = decoder._vaults['default'].encrypt(test_string)
    vault_string_string = json.dumps({'__ansible_vault': vault_string}, cls=AnsibleJSONEncoder)
    assert json.loads(vault_string_string, cls=AnsibleJSONDecoder) == test_string

    # Test object_hook will not decrypt other strings

# Generated at 2022-06-23 04:49:20.700404
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import io
    import json
    import os
    import pytest

    test_dir = os.path.dirname(__file__)
    fixture_file = os.path.join(test_dir, 'json_fixture.json')

    class TestJSONDecoder(AnsibleJSONDecoder):
        def __init__(self, *args, **kwargs):
            self._vaults['default'] = VaultLib(filename='/this/path/does/not/exist')
            super(TestJSONDecoder, self).__init__(*args, **kwargs)

    with open(fixture_file) as f:
        fixture = f.read()
    obj = json.loads(fixture, cls=TestJSONDecoder)

    assert isinstance(obj['vault'], AnsibleVaultEncryptedUnicode)
   

# Generated at 2022-06-23 04:49:23.080107
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, AnsibleJSONDecoder)


# Generated at 2022-06-23 04:49:32.656970
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    test_passwords = {"default": "foo"}
    AnsibleJSONDecoder.set_secrets(test_passwords)

    # Test for AnsibleVaultEncryptedUnicode
    test_str = "abcd"
    test_val = AnsibleVaultEncryptedUnicode(test_str)
    if test_val.vault is None:
        test_val.vault = VaultLib(secrets=test_passwords)


# Generated at 2022-06-23 04:49:38.874223
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '{"__ansible_vault": "test", "__ansible_unsafe": "test"}'
    d = json.loads(s, cls=AnsibleJSONDecoder)
    assert d['__ansible_vault'] == 'test'
    assert '__ansible_vault' in d
    assert d['__ansible_unsafe'] == 'test'
    assert '__ansible_unsafe' in d


# Generated at 2022-06-23 04:49:51.432960
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Test 1: Test unmarshalling of an encrypted variable
    test_1_raw_input = '{"__ansible_vault": "AQDz1j+ec2QZvA=="}'
    test_1_expected_output = AnsibleVaultEncryptedUnicode(b'AQDz1j+ec2QZvA==')
    # Assume vault password is 'mypassword'
    test_1_expected_output.vault = VaultLib(secrets=['mypassword'])

    test_1_result = AnsibleJSONDecoder.object_hook(json.loads(test_1_raw_input))
    assert test_1_result == test_1_expected_output

    # Test 2: Test unmarshalling of an unsafe variable

# Generated at 2022-06-23 04:49:59.508505
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    v = '$ANSIBLE_VAULT;1.1;AES256'
    assert AnsibleJSONDecoder.object_hook({'__ansible_vault': v}) == AnsibleVaultEncryptedUnicode(v)
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': v}) == AnsibleUnsafeText(v)
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': "{{}}"}) == AnsibleUnsafeText("{{}}")

# Generated at 2022-06-23 04:50:08.280640
# Unit test for method object_hook of class AnsibleJSONDecoder