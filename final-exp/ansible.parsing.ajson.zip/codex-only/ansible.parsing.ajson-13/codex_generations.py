

# Generated at 2022-06-23 04:40:08.256807
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    # This is a very basic test: we only want to know that the object_hook
    # receives the dictionary of key/values for each object.
    # We need to perform more specific tests, but AnsibleVaultEncryptedUnicode
    # and wrap_var are not easily unit tested and require too much mocking.
    # TODO: add those specific tests?

    # Setting up some mocks
    def mock_AnsibleVaultEncryptedUnicode_init(self, val) -> None:
        self.value = val
    m = AnsibleVaultEncryptedUnicode.__init__
    AnsibleVaultEncryptedUnicode.__init__ = mock_AnsibleVaultEnc

# Generated at 2022-06-23 04:40:18.511144
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    encrypted_text = u'$ANSIBLE_VAULT;1.1;AES256\n6661393066643439636332616237313236303837303861366435336432636338323632323137303665\n6536333965343536626565306533383535626337303836336639353236636330303935626137363933\n3438353837393361\n'
    text = u'hello world'


# Generated at 2022-06-23 04:40:29.669960
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = []
    secrets.append('secret1')
    secrets.append('secret2')
    secrets.append('secret3')
    AnsibleJSONDecoder.set_secrets(secrets)
    obj = json.loads('''{"__ansible_vault": "c2VjcmV0MQ==\nsecret1\nc2VjcmV0Mg==\nsecret2\nc2VjcmV0Mw==\nsecret3"}''', cls=AnsibleJSONDecoder)
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj == "c2VjcmV0MQ==\nsecret1\nc2VjcmV0Mg==\nsecret2\nc2VjcmV0Mw==\nsecret3"



# Generated at 2022-06-23 04:40:40.296892
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:47.514927
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:40:54.578439
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    if decoder.object_hook({'__ansible_vault': '1234'}) != \
            AnsibleVaultEncryptedUnicode('1234'):
        raise AssertionError("Failed to instantiate AnsibleVaultEncryptedUnicode object from JSON")
    if decoder.object_hook({'__ansible_unsafe': '1234'}) != \
            wrap_var('1234'):
        raise AssertionError("Failed to instantiate an unsafe object from JSON")

# Generated at 2022-06-23 04:40:55.342075
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:01.173061
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.module_utils._text import to_bytes

    secrets = ['test']

    decoder = AnsibleJSONDecoder.set_secrets(secrets)
    assert decoder._vaults['default'] == VaultLib(secrets=secrets)

    test_data = ('{"__ansible_vault": "AnsibleVaultEncryptedUnicode: value: $ANSIBLE_VAULT;6.1;AES256"}\n')
    result = json.loads(to_bytes(test_data), cls=AnsibleJSONDecoder)

    assert result.__class__ == AnsibleVaultEncryptedUnicode
    assert result.vault == AnsibleJSONDecoder._vaults['default']

# Generated at 2022-06-23 04:41:03.024566
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, json.JSONDecoder)



# Generated at 2022-06-23 04:41:13.484021
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ansible_vault = '$ANSIBLE_VAULT;1.1;AES256'
    value = 'ansible_vault_value'

    decoder_test = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    # Test ansible_vault
    assert isinstance(decoder_test.object_hook({'__ansible_vault': ansible_vault + ';' + value}), AnsibleVaultEncryptedUnicode)

    # Test ansible_unsafe
    assert decoder_test.object_hook({'__ansible_unsafe': value}) == wrap_var(value)

# Generated at 2022-06-23 04:41:15.379458
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder



# Generated at 2022-06-23 04:41:28.672422
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [u'vaultpassword']
    json_data = '{"__ansible_vault": "ANSIBLE_VAULT;1.1;AES256\n36346231363831353266633939326661636561376132376331626539653137616364613161663033\n35366636303566653134376332653061303639306461613562646137623430383163653235323665\n313362666f386364\n", "__ansible_unsafe": {"some_secret": "password"}}'

    decoder = AnsibleJSONDecoder(json_data)
    result = decoder.decode(json_data)
    decoder.set_secrets(secrets)
    assert decoder
    assert result

# Generated at 2022-06-23 04:41:36.687138
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    json_data = dict(foo="bar", bar={"baz": "quux"})
    my_json_decoder = AnsibleJSONDecoder()
    jsonEncoded = json.dumps(json_data, cls=AnsibleJSONEncoder)
    json_data_decoded = json.loads(jsonEncoded, cls=my_json_decoder)
    assert isinstance(json_data_decoded['bar'], dict)
    assert json_data_decoded['bar']['baz'] == 'quux'

# Generated at 2022-06-23 04:41:48.712946
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:57.011053
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import pickle
    from ansible.parsing.vault import VaultLib

    # TEST: when arguments are passed
    decoder = AnsibleJSONDecoder(encoding='utf-8', object_hook=None)

    assert decoder.encoding == 'utf-8'
    assert decoder.object_hook == AnsibleJSONDecoder.object_hook

    # TEST: when no arguments are passed
    decoder = AnsibleJSONDecoder()
    assert decoder.encoding == 'utf-8'
    assert decoder.object_hook == AnsibleJSONDecoder.object_hook



# Generated at 2022-06-23 04:41:57.583581
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass



# Generated at 2022-06-23 04:42:04.644498
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = {'__ansible_vault': 'blah blah blah'}
    json_string = json.dumps(data, cls=AnsibleJSONEncoder)
    decoded_data = json.loads(json_string, cls=AnsibleJSONDecoder)
    assert decoded_data['__ansible_vault'] == data['__ansible_vault']

# Generated at 2022-06-23 04:42:10.726564
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    jd = AnsibleJSONDecoder()
    assert isinstance(jd, AnsibleJSONDecoder)


# Unit tests for class AnsibleJSONEncoder

# Generated at 2022-06-23 04:42:14.595929
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"__ansible_vault": "dGVzdA=="}'
    json.loads(data, cls=AnsibleJSONDecoder,
               object_hook=AnsibleJSONDecoder.object_hook)


# Generated at 2022-06-23 04:42:16.138423
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    default_decoder = AnsibleJSONDecoder()
    assert default_decoder.object_hook


# Generated at 2022-06-23 04:42:28.633179
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import ansible.module_utils.basic
    import ansible.module_utils._text

    # test data

# Generated at 2022-06-23 04:42:35.201641
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    test_pair = {'__ansible_vault': "vault_encrypted_data"}
    result = decoder.object_hook(test_pair)
    assert isinstance(result, dict)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault is None

# Generated at 2022-06-23 04:42:39.309769
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = '{"key": "value"}'
    decoded_value = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook).decode(json_data)
    assert isinstance(decoded_value, dict)
    assert 'key' in decoded_value

# Generated at 2022-06-23 04:42:42.942994
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'password'
    AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secret

# Generated at 2022-06-23 04:42:48.531022
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    stream = json.dumps({'__ansible_unsafe': 'abc$(def)'}, cls=AnsibleJSONEncoder)
    data = json.loads(stream, cls=AnsibleJSONDecoder)
    assert data == wrap_var('abc$(def)')
    data = json.loads(stream)
    assert data != wrap_var('abc$(def)')
    print("AnsibleJSONDecoder.object_hook passed all tests")

# Generated at 2022-06-23 04:42:53.149441
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert 'default' not in AnsibleJSONDecoder._vaults
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert isinstance(decoder, AnsibleJSONDecoder)
    assert AnsibleJSONDecoder._vaults
    assert isinstance(AnsibleJSONDecoder._vaults['default'], VaultLib)


# Generated at 2022-06-23 04:42:58.234853
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook
    assert isinstance(ansible_json_decoder, json.JSONDecoder)



# Generated at 2022-06-23 04:43:07.224698
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    data = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansiblesecret\n616263\n',
        '__ansible_unsafe': 'unsafe'
    }
    decoded = decoder.decode(json.dumps(data))
    assert isinstance(decoded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert decoded['__ansible_unsafe'] == data['__ansible_unsafe']



# Generated at 2022-06-23 04:43:13.546301
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_string_list = ["test_string"]
    test_json_object = '{"__ansible_unsafe": "test_string"}'
    test_json_object_with_vault = '{"__ansible_vault": "test_string"}'
    test_json_object_with_unknown_key = '{"unknown_key": "test_string"}'
    secrets = [b'test_secret']

    def object_hook(self, pairs):
        for key in pairs:
            value = pairs[key]

            if key == '__ansible_vault':
                value = AnsibleVaultEncryptedUnicode(value)
                if self._vaults:
                    value.vault = self._vaults['default']
                return value
            elif key == '__ansible_unsafe':
                return wrap

# Generated at 2022-06-23 04:43:24.148680
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    dec = AnsibleJSONDecoder()
    dec.set_secrets("test")
    assert dec.object_hook({'__ansible_unsafe': 'test'}).kind == 'unsafe'
    assert dec.object_hook({'__ansible_vault': 'test'}).__class__ == AnsibleVaultEncryptedUnicode
    assert dec.object_hook({'__ansible_vault': 'test'}).vault._secrets == "test"
    assert dec.object_hook({'a': 'test'}) == {'a': 'test'}
    assert dec.object_hook({'__ansible_vault': 'test', 'a': 'test'}) == {'__ansible_vault': 'test', 'a': 'test'}

# Generated at 2022-06-23 04:43:36.285852
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'password'

# Generated at 2022-06-23 04:43:47.928271
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:43:55.284347
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder()
    assert isinstance(ansible_json_decoder, AnsibleJSONDecoder)
    assert ansible_json_decoder.parse_constant(u'__ansible_vault') == AnsibleVaultEncryptedUnicode
    assert ansible_json_decoder.parse_constant(u'__ansible_unsafe') == wrap_var
    assert ansible_json_decoder.parse_constant(u'__ansible_test') == 'test'


# Generated at 2022-06-23 04:44:02.629611
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    secret = 'Password'
    encrypted_secret = VaultLib([secret]).encrypt(secret)

    j = '{ "__ansible_vault": "' + encrypted_secret + '" }'
    r = AnsibleJSONDecoder.set_secrets(['Password'])
    o = json.loads(j, cls=AnsibleJSONDecoder)
    assert o == AnsibleUnsafeText(secret)

# Generated at 2022-06-23 04:44:03.103259
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder() is not None

# Generated at 2022-06-23 04:44:14.185901
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_vault': 'my_secret'
    }
    decoded_pairs = json_decoder.object_hook(pairs)
    assert isinstance(decoded_pairs, AnsibleVaultEncryptedUnicode), 'decoded_pairs should be of type AnsibleVaultEncryptedUnicode'

    json_decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_unsafe': 'my_unsafe_data'
    }
    decoded_pairs = json_decoder.object_hook(pairs)
    assert isinstance(decoded_pairs, str), 'decoded_pairs should be of type str'

# Generated at 2022-06-23 04:44:15.389792
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_decoder = AnsibleJSONDecoder()
    output = json.loads('{"__ansible_unsafe": "secret"}')
    assert output == wrap_var('secret')

# Generated at 2022-06-23 04:44:22.874499
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoded = json.loads('{"__ansible_vault": "ansible"}', cls=AnsibleJSONDecoder)
    assert(isinstance(decoded, AnsibleVaultEncryptedUnicode))

    decoded = json.loads('{"__ansible_vault": "ansible", "__ansible_unsafe": "ansible"}', cls=AnsibleJSONDecoder)
    assert(isinstance(decoded, AnsibleVaultEncryptedUnicode))
    assert(isinstance(decoded.vault, VaultLib))

# Generated at 2022-06-23 04:44:30.312142
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_data = {"__ansible_vault": "vault contents"}
    ansible_json = AnsibleJSONDecoder()
    ansible_json.set_secrets("secret")
    decoded_json_data = json.loads(json.dumps(json_data), cls=AnsibleJSONDecoder)
    assert decoded_json_data != json_data
    assert decoded_json_data["__ansible_vault"] == "vault contents"


# Generated at 2022-06-23 04:44:39.503543
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # load json data
    json_data = open("/tmp/json_data.json")
    data = json.load(json_data)
    # output: {u'name': u'Dave', u'__ansible_vault': u'$ANSIBLE_VAULT;1.2;AES256;foo;3632363232313134383336363431313832323732343136336631303266663137646538633363623137623762626132333063646332323035383038346633653862653362316666643534303231323362626137656361643330636430336634373066643938666437383438306535393637333261356163636434376630373364326465363737

# Generated at 2022-06-23 04:44:42.862511
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder()
    pairs = d.object_hook({'__ansible_vault': 'secret'})
    assert isinstance(pairs, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:44:55.088696
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # AnsibleJSONDecoder().object_hook(<some object>)
    # should return the <some object> when there is no __ansible_unsafe key
    # or __ansible_vault key in it, or it should return a wrapped object when
    # there is a __ansible_unsafe key in it.
    test_obj = {
        'key1': 'value1',
        'key2': 'value2',
        '__ansible_unsafe': 1,
        'key3': 'value3',
        'key4': 'value4',
    }

    decoder = AnsibleJSONDecoder()
    wrapped_obj = decoder.object_hook(test_obj)

    # The __ansible_unsafe key should be removed
    assert '__ansible_unsafe' not in wrapped_obj

    # The

# Generated at 2022-06-23 04:44:56.564246
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder(encoding='ascii')


# Generated at 2022-06-23 04:44:59.249101
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decode_obj=AnsibleJSONDecoder()
    assert decode_obj

# Generated at 2022-06-23 04:45:08.075679
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_secrets = ['test_secrets']

    decoder = AnsibleJSONDecoder()
    decoder_with_secrets = AnsibleJSONDecoder(secrets=test_secrets)

    assert not decoder._vaults
    assert decoder_with_secrets._vaults['default'].secrets == test_secrets


# Generated at 2022-06-23 04:45:13.318469
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    data = {
        "__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35353666383037373361323135653633393634333233333436636137373762613232356432373365\n          35396139623431616264363335303863343765653462343039626530633236656639393935316430\n          63663939\n          ",
        "__ansible_unsafe": "{{ foo }}",
    }

    c = AnsibleJSONDecoder()
    result = c.object_hook(data)

    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:45:22.580822
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    """
    Returns:
    """
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:45:25.654546
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert decoder is not None

# Generated at 2022-06-23 04:45:27.071249
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder


# Generated at 2022-06-23 04:45:39.986128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import json
    import os
    import sys

    # Test for keys that are part of AnsibleUnsafeText:
    unsafe_test_data = {"__ansible_unsafe": "some\nvalue"}
    unsafe_test_encoded_data = AnsibleJSONEncoder().encode(unsafe_test_data)
    unsafe_test_decoded_data = json.loads(unsafe_test_encoded_data, cls=AnsibleJSONDecoder)
    assert isinstance(unsafe_test_decoded_data, dict)
    assert len(unsafe_test_decoded_data) == 1
    assert isinstance(unsafe_test_decoded_data['__ansible_unsafe'], AnsibleUnsafeText)
    assert unsafe_

# Generated at 2022-06-23 04:45:52.806168
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    import json

    # test for '__ansible_vault'

# Generated at 2022-06-23 04:46:03.922653
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:16.088107
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:19.313323
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert hasattr(decoder, '_vaults')
    assert decoder._vaults == {}



# Generated at 2022-06-23 04:46:20.372359
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    cls = AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:31.407724
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import textwrap

    secrets = [
        b'vault-password'
    ]

    jd = AnsibleJSONDecoder
    jd.set_secrets(secrets)


# Generated at 2022-06-23 04:46:34.637235
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    assert AnsibleJSONDecoder is not None
    assert AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook) is not None

# Generated at 2022-06-23 04:46:44.560175
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    test_data = {}
    test_data['__ansible_vault'] = 'C0VMRjE='

    test_decoder = AnsibleJSONDecoder()
    result = test_decoder.object_hook(test_data)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert result['__ansible_vault'].vault is None

    test_decoder.set_secrets('some_secret')
    result = test_decoder.object_hook(test_data)
    assert isinstance(result['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(result['__ansible_vault'].vault, VaultLib)
    assert result['__ansible_vault'].vault._sec

# Generated at 2022-06-23 04:46:46.480685
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    class_ins = AnsibleJSONDecoder()
    assert class_ins is not None

# Generated at 2022-06-23 04:46:47.435028
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder()


# Generated at 2022-06-23 04:46:50.932747
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test for __init__ of class AnsibleJSONDecoder
    ansiblejsonDecoder = AnsibleJSONDecoder()
    assert isinstance(ansiblejsonDecoder, json.JSONDecoder)

# Generated at 2022-06-23 04:46:52.379789
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder

# Generated at 2022-06-23 04:47:00.346739
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    import tempfile

    _vaults = {}
    _vaults['default'] = VaultLib(os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE'))


# Generated at 2022-06-23 04:47:13.049501
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    #data = '{"__ansible_vault": "AQDqJR3QFYzWOlxM+rBX9J9hGcrRzW8fvE+bTcDRje84sVJnW8+GzHbX9aYn0TgBPtTlDtQQfPY9KjFc8R/Wp/vZN/CkLWra/K8xQ2bPz3T9K9Tcl0o0nhWze1ZtjKk=", "__ansible_unsafe": true}'

# Generated at 2022-06-23 04:47:18.124091
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # test for __ansible_vault
    test_data = {"__ansible_vault": "AAAAAAAAAA"}
    AnsibleJSONDecoder.set_secrets(["s3cr3t"])
    decoded_data = json.loads(json.dumps(test_data))
    assert decoded_data.vault.secrets == ["s3cr3t"]


# Generated at 2022-06-23 04:47:24.944277
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import os
    test_data = os.path.join(os.path.dirname(__file__), '..', '..', 'test_data')
    with open(os.path.join(test_data, 'test_parser.json')) as f:
        json_data = json.load(f)
    assert isinstance(json_data['test_dict']['vault_string'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 04:47:31.514142
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder(object_hook=None)
    assert a is not None
    assert a.object_hook is not None
    b = AnsibleJSONDecoder(object_hook=lambda x: x)
    assert b is not None
    assert b.object_hook is not None

# Generated at 2022-06-23 04:47:47.229034
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    test_data = '{"__ansible_vault": "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  35653430666234633235373166323965663238363266313961316431623361323137313262633065\n  36660a62636637663537323033376136623863353037666238613263626666316232393638356663\n  62626236366134\n"}'
    test_data_encoded = json.loads(test_data, cls=AnsibleJSONDecoder)
    test_data_decoded = json.loads(test_data, cls=json.JSONDecoder)


# Generated at 2022-06-23 04:47:57.864005
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    vault_password = 'ansible'
    vault_data_text = '$ANSIBLE_VAULT;1.1;AES256\n36376235393366613730663565353064363266633961626135316436363437323238336237313532626\nc30a6d597560447f0c3a67f6e11d6361d0a47a02355b9df6d3d7758da607df748b3c6712d523abd98c\n6823fbebe9e9d99f2c2d8'
   

# Generated at 2022-06-23 04:48:07.913295
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    a = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    assert '"__ansible_vault":' in str(a)
    assert "object_hook=AnsibleJSONDecoder.object_hook" in str(a)
    assert '"__ansible_unsafe": "This is not safe to embed in the program"' in str(AnsibleJSONDecoder().decode("""{
        "__ansible_unsafe": "This is not safe to embed in the program"
    }"""))
    assert '"__ansible_vault": "This is something secure we want to encrypt"' in str(AnsibleJSONDecoder().decode("""{
        "__ansible_vault": "This is something secure we want to encrypt"
    }"""))

# Generated at 2022-06-23 04:48:08.787182
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass

# Generated at 2022-06-23 04:48:15.912088
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)

    pairs = {'__ansible_vault': '@vault'}
    assert decoder.object_hook(pairs) == AnsibleVaultEncryptedUnicode('@vault')

    pairs = {'__ansible_unsafe': '$password'}
    assert decoder.object_hook(pairs) == wrap_var('$password')

# Generated at 2022-06-23 04:48:17.957863
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert isinstance(decoder, AnsibleJSONDecoder)

# Generated at 2022-06-23 04:48:28.308029
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    s = '''{
    "test_key": "test_value",
    "test_key2": "@test_value2",
    "test_key3": "@@test_value3",
    "test_key4": "@test_vault:test_value4",
    "test_key5": "@@test_vault:test_value5",
    "__ansible_unsafe": "test_value6",
    "__ansible_vault": "test_value7",
    "__ansible_vault__test_vault": "test_value8"
}'''

# Generated at 2022-06-23 04:48:39.002464
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import string
    import random

    def random_string(size):
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))


# Generated at 2022-06-23 04:48:48.151520
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    vault_pwd = 'vault_pwd'
    secert_key = 'test_vault_key'
    vault_secert = dict(secert_key=secert_key)
    json_str = json.dumps({'__ansible_vault': vault_pwd, '__ansible_unsafe': 'foo'}, cls=AnsibleJSONEncoder)
    ansible_json_decoder = AnsibleJSONDecoder()
    ansible_json_decoder.set_secrets(vault_secert)
    decoded_value = ansible_json_decoder.decode(json_str)
    assert hasattr(decoded_value['__ansible_vault'], 'decrypt')
    assert decoded_value['__ansible_unsafe'] == 'foo'

# Generated at 2022-06-23 04:48:51.440714
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # just check it does not dump an exception,
    # the internals are tested above.
    json.loads('{"a": 1}', cls=AnsibleJSONDecoder)

# Generated at 2022-06-23 04:49:02.995136
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Set necessary AnsibleJSONDecoder attributes
    AnsibleJSONDecoder._vaults = {}
    vault_password = '$ANSIBLE_VAULT'
    vault_password_file = None
    AnsibleJSONDecoder.set_secrets(secret=[vault_password, vault_password_file])

    # Construct a json to test
    foo = {'__ansible_vault': 'vault'}

    # Convert json object to string
    foo_str = json.dumps(foo, cls=AnsibleJSONEncoder)

    # Convert string to ansible vault object
    vault_decoder = json.JSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    foo_converted = vault_decoder.decode(foo_str)

    # Check whether the converted object is vault object or not


# Generated at 2022-06-23 04:49:04.306663
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:11.980699
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test with vault key
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'test'}) == AnsibleVaultEncryptedUnicode('test')
    assert decoder.object_hook({'__ansible_vault': 'test', 'key': 'value'}) == {'key': 'value', '__ansible_vault': AnsibleVaultEncryptedUnicode('test')}

    # Test with unsafe key
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_unsafe': 'test'}) == wrap_var('test')

# Generated at 2022-06-23 04:49:16.194006
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = '{"foo": "bar"}'
    decoder = AnsibleJSONDecoder()

    assert decoder.decode(data) == {'foo': 'bar'}

# Generated at 2022-06-23 04:49:18.354612
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook == decoder.object_hook


# Generated at 2022-06-23 04:49:29.755718
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    ''' test if object_hook can handle all possible json encodings '''

    vault_data = "{'username': 'admin', 'password': '123456'}"

# Generated at 2022-06-23 04:49:30.548394
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-23 04:49:32.925567
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    """ Create a ansiblejson decoder object and make sure it is not None """
    assert AnsibleJSONDecoder() is not None


# Generated at 2022-06-23 04:49:38.460149
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({"__ansible_vault": "test"}) == AnsibleVaultEncryptedUnicode("test")
    assert decoder.object_hook({"__ansible_unsafe": "test"}) == wrap_var("test")
    assert decoder.object_hook({"bar": "test"}) == {"bar": "test"}



# Generated at 2022-06-23 04:49:49.596307
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    assert True
    #raw_data = {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\n33306236326237363766376462366663633234663338313134323461376137383338373361346338\n36333834313130663037656634373864353431316639653762393534313930636234386265323865\n31343465386664346532326136323863323237643835336265383332326262653838623436306430\n64363835366163303464393937633861356230346463306462366533666438303936386664323934\n643130653865353563356465333734

# Generated at 2022-06-23 04:49:52.382305
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansible_json_decoder = AnsibleJSONDecoder(object_hook=False)
    assert ansible_json_decoder.object_hook is not None


# Generated at 2022-06-23 04:50:00.074800
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    j = json.dumps({'ansible_vault': 'ansible_vault', 'ansible_unsafe': 'ansible_unsafe'}, cls=AnsibleJSONEncoder)
    decoded = json.loads(j, cls=AnsibleJSONDecoder)
    assert isinstance(decoded['ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(decoded['ansible_unsafe'], AnsibleVaultEncryptedUnicode)