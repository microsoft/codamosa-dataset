

# Generated at 2022-06-23 04:40:07.429758
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:40:13.838890
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.parsing.vault import VaultLib

    class AnsibleJSONDecoderTests(object):

        def setUp(self):
            self.decoder = AnsibleJSONDecoder()
            AnsibleJSONDecoder.set_secrets(['super_secret'])

        def tearDown(self):
            del self.decoder
            AnsibleJSONDecoder._vaults = {}

        def test_object_hook(self):
            # An AnsibleVaultEncryptedUnicode object should be returned when
            # an object containing the key '__ansible_vault' is detected.
            data = {'__ansible_vault': 'test'}
            result = self.decoder.object_hook(data)
            assert isinstance(result, AnsibleVaultEncryptedUnicode)

            # The decoder should

# Generated at 2022-06-23 04:40:24.308774
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    d = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:40:31.977273
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [
        {
            'secret': 'test',
            'version': 1.1,
            'contents': 'test',
        }
    ]
    args = ['', '', '', '', True, False, False, False, None, None, '', '', False, False, False, False, False, None, None, '', True, None, True, None, None, False, None, None, None, None, {}, {}, False, True, None, None]

    with AnsibleJSONDecoder.set_secrets(secrets):
        assert AnsibleJSONDecoder(*args)

# Generated at 2022-06-23 04:40:33.339888
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    foo = AnsibleJSONDecoder()
    return foo


# Generated at 2022-06-23 04:40:40.416677
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    d = '{"__ansible_unsafe":"$ANSIBLE_VAULT;1.1;AES256;myuser376387638763876387\neXo=\n"}'
    AnsibleJSONDecoder.set_secrets(['SECRET1', 'SECRET2'])
    assert isinstance(AnsibleJSONDecoder().decode(d), dict)

# Generated at 2022-06-23 04:40:43.588507
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # from ansible.inventory.vault import VaultLib
    test_obj = AnsibleJSONDecoder()
    assert test_obj._vaults == {}

# Generated at 2022-06-23 04:40:50.547738
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    data = """{"__ansible_unsafe": "should be unsafe"}"""
    result = json.loads(data, cls=AnsibleJSONDecoder)
    assert result == {'__ansible_unsafe': wrap_var('should be unsafe')}

    data = """{"__ansible_vault": "@!my_password"}"""
    result = json.loads(data, cls=AnsibleJSONDecoder)
    assert result == {'__ansible_vault': AnsibleVaultEncryptedUnicode('@!my_password')}

# Generated at 2022-06-23 04:40:58.475633
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [ b"unit_test" ]
    AnsibleJSONDecoder.set_secrets(secrets)

    obj = json.loads('{"__ansible_unsafe": "@password"}', cls=AnsibleJSONDecoder)
    assert obj == wrap_var("@password")

    # This should be commented out as the vault class is not included in the unit tests
    # No vault password is provided here
    #obj = json.loads('{"__ansible_vault": "YW55IGtleQo=\n"}', cls = AnsibleJSONDecoder)
    #assert obj == AnsibleVaultEncryptedUnicode('any key')


# Generated at 2022-06-23 04:41:03.662351
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_data = '''{"ansible_username": "George", "ansible_password": "Rudy", "ansible_connection": "winrm", "ansible_winrm_server_cert_validation": "ignore"}'''
    test_struct = {'ansible_username': 'George', 'ansible_password': 'Rudy', 'ansible_connection': 'winrm', 'ansible_winrm_server_cert_validation': 'ignore'}

    assert test_struct == json.loads(test_data, cls=AnsibleJSONDecoder)

# Generated at 2022-06-23 04:41:15.809067
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    import sys
    # AnsibleJSONDecoder class is tested, not AnsibleJSONDecoder object. Create the decoder object only to get the secret key.
    ansible_json_decoder = AnsibleJSONDecoder()
    secret = ansible_json_decoder._vaults['default'].secrets[0]
    # Prepare a set of simple arguments to be passed to the method object_hook of the class AnsibleJSONDecoder.

# Generated at 2022-06-23 04:41:22.616142
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    ansiblejson = AnsibleJSONDecoder()
    assert ansiblejson.decode('{"__ansible_vault": "abc"}') == {'__ansible_vault': 'abc'}
    assert ansiblejson.decode('{"__ansible_unsafe": "abc"}') == {'__ansible_unsafe': 'abc'}

# Generated at 2022-06-23 04:41:32.094100
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_str = '''{
        "__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256;ansible",
        "__ansible_unsafe": "__ansible_unsafe",
        "__ansible_other": "__ansible_other"
    }'''

    json_dict = json.loads(json_str, cls=AnsibleJSONDecoder)
    assert isinstance(json_dict['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_dict['__ansible_unsafe'], type(wrap_var('')))



# Generated at 2022-06-23 04:41:43.755888
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:41:55.149675
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from yaml import load
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-23 04:41:59.550400
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = "test"
    AnsibleJSONDecoder.set_secrets(secrets)
    assert AnsibleJSONDecoder._vaults['default'].secrets == "test"

v = AnsibleVaultEncryptedUnicode("test")
t = type(v)


# Generated at 2022-06-23 04:42:15.499228
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    test_case_data = [
        (
            'rHVhbCBieXRlcyA9IDEyMzQ1Njc4OTA=',
            AnsibleVaultEncryptedUnicode('hual bytes = 1234567890', 'default'),
        ),
        (
            'rHVhbCBieXRlcyA9IDEyMzQ1Njc4OTA=',
            AnsibleVaultEncryptedUnicode('hual bytes = 1234567890', 'vault_id'),
        ),
    ]

    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:42:25.123842
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    encoder = AnsibleJSONEncoder()
    decoder = AnsibleJSONDecoder()

    my_unsafe_text = AnsibleUnsafeText('unsafe')
    result = decoder.object_hook(dict(__ansible_unsafe=my_unsafe_text))
    assert result == my_unsafe_text
    assert isinstance(result, AnsibleUnsafeText)

    vault_passwd = 'testpasswd'
    vault_decoder_object = AnsibleVaultEncryptedUnicode(encoder.encode({'test_key': 'test_value'}))
    decoder.set_secrets([vault_passwd])

# Generated at 2022-06-23 04:42:29.103215
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert json.loads('{"var": "value"}', cls=AnsibleJSONDecoder) == {'var': 'value'}

# Generated at 2022-06-23 04:42:32.621760
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook({'__ansible_vault': 'string'}) == AnsibleVaultEncryptedUnicode('string')

# Generated at 2022-06-23 04:42:37.206512
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    pairs = {
        '__ansible_vault': 'demo'
    }
    result = decoder.object_hook(pairs)
    assert result.__class__ == AnsibleVaultEncryptedUnicode
    assert result == 'demo'

# Generated at 2022-06-23 04:42:46.730522
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Build a string to be decoded and a dict to be compared
    dict_string = """
        {
            "string": "string",
            "int": 1,
            "float": 1.0,
            "list": [1, 2, 3],
            "dict": {"one": 1, "two": 2, "three": 3},
            "__ansible_unsafe": {
                "__ansible_vault": "vault"
            }
        }
        """

# Generated at 2022-06-23 04:42:54.492358
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    ansible.module_utils.common.json.AnsibleJSONDecoder object_hook test method
    '''
    json_str = '{"__ansible_vault": "123", "__ansible_unsafe": "456", "k": "v"}'
    decoder = AnsibleJSONDecoder()
    AnsibleJSONDecoder.set_secrets('123')
    result = decoder.decode(json_str)
    decoder.set_secrets(None)
    assert result.get('__ansible_vault', False) == '123'
    assert result.get('__ansible_unsafe', False) == '456'
    assert result.get('k', False) == 'v'

# Generated at 2022-06-23 04:42:57.445850
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    akd_json = AnsibleJSONDecoder()
    assert isinstance(akd_json, json.JSONDecoder)


# Generated at 2022-06-23 04:43:02.253086
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    from ansible.module_utils._text import to_bytes
    # Return a JSON object from JSON serialized string
    json_object = json.loads(to_bytes('{"__ansible_unsafe":"$ANSIBLE_VAULT;1.2;AES256;user1\n33306436346530346566363337613961323133653934646434393064306164393338663135\n36613035393034633035613331633732303236373531303462650a39353634393235663036\n39386534396139613231333763366564333532626134616166333635336266303731643066\n62383366623735663131643338343862610a"}'))

    # Create an instance

# Generated at 2022-06-23 04:43:10.622706
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = ['test']
    json_str = '{"__ansible_unsafe": "test"}'

    original_set_secrets = AnsibleJSONDecoder.set_secrets
    original_encoder = AnsibleJSONEncoder.encoder

    try:
        AnsibleJSONEncoder.encoder = {}
        AnsibleJSONDecoder.set_secrets = lambda *args, **kwargs: None
        AnsibleJSONDecoder.set_secrets(secrets)
        d = AnsibleJSONDecoder()
        result = d.decode(json_str)
        assert result['__ansible_unsafe'] == 'test'
    finally:
        AnsibleJSONDecoder.set_secrets = original_set_secrets
        AnsibleJSONEncoder.encoder = original_encoder

# Generated at 2022-06-23 04:43:12.826883
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    vault_password_file = '/path/to/vault_password_file'
    decoder = AnsibleJSONDecoder(vault_password_file=vault_password_file)
    assert vault_password_file == decoder.vault_password_file

# Generated at 2022-06-23 04:43:23.951766
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    secrets = [
        'My Vault Password',
    ]
    decoder = AnsibleJSONDecoder.set_secrets(secrets)

    pairs = {
        'some_key': 'some_value',
    }
    pairs_unexpected = {
        'some_key': 'some_value',
        '__ansible_vault': 'some_encrypted_value',
    }
    pairs_expected = {
        'some_key': 'some_value',
        '__ansible_vault': 'some_encrypted_value',
        '__ansible_vault__': 'some_vault',
    }

    result = decoder.object_hook(pairs)
    assert result == pairs
    result = decoder.object_hook(pairs_unexpected)

# Generated at 2022-06-23 04:43:36.095128
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 04:43:37.829904
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

    assert decoder is not None


# Generated at 2022-06-23 04:43:44.519249
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_unsafe = '{"__ansible_unsafe": "__ansible_unsafe"}'
    json_vault = '{"__ansible_vault": "__ansible_vault"}'
    decoder = AnsibleJSONDecoder()
    assert decoder.decode(json_unsafe) == wrap_var('__ansible_unsafe')
    assert decoder.decode(json_vault) == AnsibleVaultEncryptedUnicode('__ansible_vault')

# Generated at 2022-06-23 04:43:51.531136
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # Test __init__ with no arguments: should not raise exception
    AnsibleJSONDecoder()
    # Test __init__ with valid arguments: should not raise exception
    AnsibleJSONDecoder(encoding = 'utf-8')
    AnsibleJSONDecoder(encoding = 'utf-8', object_hook=None)
    AnsibleJSONDecoder(encoding = 'utf-8', object_hook=None, parse_float=None)
    AnsibleJSONDecoder(encoding = 'utf-8', object_hook=None, parse_float=None,
                       parse_int=None)
    AnsibleJSONDecoder(encoding = 'utf-8', object_hook=None, parse_float=None,
                       parse_int=None, parse_constant=None)

# Generated at 2022-06-23 04:44:03.101978
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    # Protect import other modules like pywin32
    try:
        from ansible.module_utils.common.win_dsc import DscResource
    except ImportError:
        pass
    else:
        assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': {'DscResource': {'ModuleName': 'dsc'}}}) == {'__ansible_unsafe': {DscResource: {'ModuleName': 'dsc'}}}
    assert AnsibleJSONDecoder.object_hook({'__ansible_unsafe': {'module': {'ModuleName': 'ansible.module_utils.ansible_release'}}}) == {'__ansible_unsafe': {'module': {'ModuleName': 'ansible.module_utils.ansible_release'}}}



# Generated at 2022-06-23 04:44:14.524307
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import unittest
    import yaml
    class TestAnsibleJSONDecoderObjectHook(unittest.TestCase):
        def setUp(self):
            self.encoded = '{"__ansible_unsafe": "{{ var }}"}'
            self.decoder = AnsibleJSONDecoder()

        def test_object_hook(self):
            decoded = self.decoder.decode(self.encoded)
            self.assertIsInstance(decoded['__ansible_unsafe'], wrap_var)
            self.assertEqual(yaml.safe_load(self.encoded)['__ansible_unsafe'], decoded['__ansible_unsafe'].data)

    unittest.main(argv=[''], exit=False)

# Generated at 2022-06-23 04:44:15.504901
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:44:22.283626
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_string = '{"__ansible_vault": "1", "__ansible_unsafe": "1"}'
    json_data = json.loads(json_string, cls=AnsibleJSONDecoder)

    # Check the result
    assert isinstance(json_data['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(json_data['__ansible_unsafe'], AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 04:44:25.262965
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret = 'secret'
    AnsibleJSONDecoder.set_secrets(secret)
    assert AnsibleJSONDecoder._vaults['default'].secrets == secret

# Generated at 2022-06-23 04:44:35.718875
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    # When key __ansible_vault is present, return a AnsibleVaultEncryptedUnicode object
    pairs = {'__ansible_vault': 'This is a vault value'}
    returned_pairs = decoder.object_hook(pairs)
    assert isinstance(returned_pairs, AnsibleVaultEncryptedUnicode)
    assert returned_pairs == 'This is a vault value'
    # Test with multiple keys, ensure __ansible_vault is not lost
    pairs = {'__ansible_vault': 'This is a vault value', 'value': 'This is not a vault value'}
    returned_pairs = decoder.object_hook(pairs)

# Generated at 2022-06-23 04:44:47.009027
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import json
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    assert json.dumps({'my_key': 'my_value'}, sort_keys=True, cls=AnsibleJSONEncoder) == '{"my_key": "my_value"}'
    assert json.dumps({'my_key': 'my_value', '__ansible_vault': 'my_value_vault'}, sort_keys=True, cls=AnsibleJSONEncoder) == '{"__ansible_vault": "my_value_vault", "my_key": "my_value"}'

# Generated at 2022-06-23 04:44:57.054935
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    s = '''\
{
  "__ansible_vault": "vault_mock",
  "__ansible_unsafe": "unsafe_mock"
}'''
    decoded_json = AnsibleJSONDecoder().decode(s)

    assert decoded_json['__ansible_vault'] == b'vault_mock'
    assert isinstance(decoded_json['__ansible_vault'], AnsibleVaultEncryptedUnicode)

    assert decoded_json['__ansible_unsafe'] == 'unsafe_mock'
    assert isinstance(decoded_json['__ansible_unsafe'], str)


# Generated at 2022-06-23 04:45:03.668761
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

    # Test for AnsibleVaultEncryptedUnicode replacement
    value = decoder.object_hook({'__ansible_vault': 'value'})
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value == 'value'

    # Test for unsafe proxy replacement
    value = decoder.object_hook({'__ansible_unsafe': 'value'})
    assert wrap_var(value) == 'value'

# Generated at 2022-06-23 04:45:05.763076
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = [u'12345']
    ansible_json_decoder = AnsibleJSONDecoder(secrets=secrets)
    assert ansible_json_decoder.secrets == secrets

# Generated at 2022-06-23 04:45:12.225214
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    test_secrets = ['foo']

    obj = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook,
                             secrets=test_secrets)

    obj.set_secrets(test_secrets)

    assert obj._vaults == {'default': VaultLib(secrets=test_secrets)}



# Generated at 2022-06-23 04:45:16.721259
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    json_text = '''{
        "A": true,
        "B": "B"
        }'''
    json_dict = json.loads(json_text, cls=AnsibleJSONDecoder)
    assert json_dict == {u'A': True, u'B': u'B'}


# Generated at 2022-06-23 04:45:29.792313
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # Test with encrypted value
    d = AnsibleJSONDecoder()
    d.set_secrets('pass')

# Generated at 2022-06-23 04:45:40.019373
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:45:45.959168
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    test_json = {'__ansible_vault': 'vault_value', '__ansible_unsafe': 'ansible_unsafe'}
    dumped = json.dumps(test_json, cls=AnsibleJSONEncoder)
    assert dumped == '{"__ansible_vault": "vault_value", "__ansible_unsafe": "ansible_unsafe"}'

    loaded = json.loads(dumped, object_hook=AnsibleJSONDecoder.object_hook)
    assert loaded == test_json
    assert isinstance(loaded['__ansible_vault'], AnsibleVaultEncryptedUnicode)
    assert isinstance(loaded['__ansible_unsafe'], wrap_var)

# Generated at 2022-06-23 04:45:48.933106
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder(object_hook=None)
    assert decoder.object_hook is not None


# Generated at 2022-06-23 04:46:01.295219
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:14.119172
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'thisisavaultpassword'
    AnsibleJSONDecoder.set_secrets(secrets)

# Generated at 2022-06-23 04:46:25.848175
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()
    obj = decoder.object_hook({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;ansible\n313765613338623531666561343962326635343736306162393161636132313365393534333534\n333566373439393263323461393536346565366363373130616133656665303561623839343732\n656135363633373537663464386538376630313336396538646637353966\n'})
    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault is None

    decoder = AnsibleJSONDecoder()
    obj = dec

# Generated at 2022-06-23 04:46:27.311630
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test constructor
    AnsibleJSONDecoder('', '')

# Generated at 2022-06-23 04:46:29.509558
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
  assert isinstance(AnsibleJSONDecoder(), AnsibleJSONDecoder)


# Generated at 2022-06-23 04:46:41.558224
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    # If you wanna test AnsibleJSONDecoder with a custom vault password,
    # please uncomment the bellow line.
    # vault_pass = 'your_password'
    vault_pass = None
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder.set_secrets(vault_pass)

    # Test with __ansible_vault
    vault_secret = 'super secret'

# Generated at 2022-06-23 04:46:52.332192
# Unit test for constructor of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:46:59.532621
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    AnsibleJSONDecoder.set_secrets(secrets)
    decoder = AnsibleJSONDecoder()
    decoded_json_data = decoder.decode(json_data)
    assert decoded_json_data == json.loads(json_data)

    json_1 = '{"a": {"__ansible_vault": "some_val"}}'
    assert decoder.decode(json_1)['a'] == 'some_val'
    assert isinstance(decoder.decode(json_1)['a'], AnsibleVaultEncryptedUnicode)

    assert decoder.decode(json_1)['a'].vault == VaultLib(secrets=secrets)


# Generated at 2022-06-23 04:47:12.366945
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    json_str = '{"__ansible_vault": "gAAAAABggkFcZV_IElC8l7xXSvjYb7Fnsl6D-hqV4Kp4XTi7zKjJ1x_q3r5r0AozeNAt-jKGQwEI0HAARyuQKHZlhks8g7SmD9aalYKm-iLp22sk0w=="}'

# Generated at 2022-06-23 04:47:13.692313
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    assert AnsibleJSONDecoder(object_hook = object_hook)


# Generated at 2022-06-23 04:47:19.033848
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secrets = 'password'
    decoder = AnsibleJSONDecoder(object_hook=AnsibleJSONDecoder.object_hook)
    decoder.set_secrets(secrets)

    assert isinstance(decoder, AnsibleJSONDecoder)
    assert isinstance(decoder.object_hook, AnsibleJSONDecoder.object_hook)
    assert decoder._vaults['default'].secrets == secrets


# Generated at 2022-06-23 04:47:29.419771
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:47:30.832475
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder._vaults == {}
    assert isinstance(decoder, AnsibleJSONDecoder)

# Generated at 2022-06-23 04:47:35.625989
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test AnsibleJSONDecoder(self, *args, **kwargs)
    # AnsibleJSONDecoder.object_hook is initialized.
    ansible_json_decoder = AnsibleJSONDecoder()
    assert ansible_json_decoder.object_hook



# Generated at 2022-06-23 04:47:47.928016
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    '''
    object_hook() Transform each top-level key and value
    '''

    # Change the value of unsafe_proxy_var so that it
    # can be compared in the test
    wrap_var.unsafe_proxy_var = '__ansible_unsafe'

    # Create an instance of AnsibleJSONDecoder
    ansible_json_decoder = AnsibleJSONDecoder()

    # Create an AnsibleVaultEncryptedUnicode object
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('ABCD')

    # Create an unsafe variable
    unsafe_var = wrap_var(['test_unsafe_var1', 'test_unsafe_var2'])

    # Create a test dictionary

# Generated at 2022-06-23 04:47:58.562695
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    decoder = AnsibleJSONDecoder()

# Generated at 2022-06-23 04:48:06.156791
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    decoder = AnsibleJSONDecoder()
    encrypted_data = {'__ansible_vault': 'aaa'}
    unsafe_data = {'__ansible_unsafe': 'aaa'}

    data = decoder.object_hook(encrypted_data)
    assert type(data) is AnsibleVaultEncryptedUnicode and data._data == 'aaa'
    data = decoder.object_hook(unsafe_data)
    assert type(data) is AnsibleUnsafeText and data._data == 'aaa'



# Generated at 2022-06-23 04:48:10.481938
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    secret_string = "hello world"
    decoder = AnsibleJSONDecoder.set_secrets(secrets=secret_string)
    assert decoder._vaults['default'].secrets == secret_string


# Generated at 2022-06-23 04:48:21.736398
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    import sys
    import os
    import pytest

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../lib'))

    from ansible.parsing.vault import VaultLib

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    from ansible.module_utils.common.json import AnsibleJSONEncoder


# Generated at 2022-06-23 04:48:32.681531
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.parse_string('{"__ansible_vault": "test"}') == {'__ansible_vault': u'test'}
    assert decoder.parse_string('{"__ansible_unsafe": "test"}') == {'__ansible_unsafe': u'test'}
    json.JSONDecoder.__init__(decoder, object_hook=decoder.object_hook)
    assert decoder.parse_string('{"__ansible_vault": "test"}') == {'__ansible_vault': u'test'}
    assert decoder.parse_string('{"__ansible_unsafe": "test"}') == {'__ansible_unsafe': u'test'}


# Generated at 2022-06-23 04:48:44.573417
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    j = '{"__ansible_vault": "vault value", "__ansible_unsafe": "unsafe value"}'
    assert json.loads(to_bytes(j), cls=AnsibleJSONDecoder) == {
        '__ansible_vault': AnsibleVaultEncryptedUnicode('vault value'),
        '__ansible_unsafe': wrap_var('unsafe value')
    }

    j = '{"__ansible_vault": "vault value", "__ansible_unsafe": "unsafe value"}'

# Generated at 2022-06-23 04:48:55.665609
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:04.903228
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:07.275826
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    decoder = AnsibleJSONDecoder()
    assert decoder.object_hook
    assert decoder._vaults

# Generated at 2022-06-23 04:49:14.417937
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    # test set_secrets
    j_decoder = AnsibleJSONDecoder
    secrets = ['secret']
    j_decoder.set_secrets(secrets= secrets)
    assert secrets == j_decoder._vaults['default'].secrets
    # test object_hook
    object_hook = j_decoder.object_hook(j_decoder, {'__ansible_vault': 'vault', '__ansible_unsafe': 'unsafe'})
    assert object_hook == {'__ansible_vault': AnsibleVaultEncryptedUnicode('vault'),
                           '__ansible_unsafe': wrap_var('unsafe')}

# Generated at 2022-06-23 04:49:25.420650
# Unit test for method object_hook of class AnsibleJSONDecoder

# Generated at 2022-06-23 04:49:34.492486
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    import os
    import tempfile
    import yaml

    try:
        __import__('cryptography')
    except ImportError:
        import pytest
        pytest.skip("missing required cryptography library", allow_module_level=True)


# Generated at 2022-06-23 04:49:46.830084
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():

    import json
    import unittest

    class TestAnsibleJSONDecoder(unittest.TestCase):

        def setUp(self):
            self.jsonstr = '{"foo": "bar"}'
            self.obj = {'foo': AnsibleJSONEncoder().encode('bar')}
            self.vaultencoded = AnsibleJSONEncoder().encode({'__ansible_vault': 'bar'})
            self.vaultobj = AnsibleVaultEncryptedUnicode('bar')
            self.vaultdict = {'__ansible_vault': self.vaultencoded}
            self.unsafestr = AnsibleJSONEncoder().encode({'__ansible_unsafe': 'bar'})

# Generated at 2022-06-23 04:49:57.162017
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():
    import pytest
    secrets = ['mysecret']

# Generated at 2022-06-23 04:49:58.019099
# Unit test for constructor of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder():
    pass


# Generated at 2022-06-23 04:50:02.827910
# Unit test for method object_hook of class AnsibleJSONDecoder
def test_AnsibleJSONDecoder_object_hook():

    d = AnsibleJSONDecoder()
    s = json.dumps({'__ansible_unsafe': 5}, cls=AnsibleJSONEncoder)
    assert d.decode(s) == wrap_var(5)

    d = AnsibleJSONDecoder()
    s = json.dumps({'__ansible_vault': 5}, cls=AnsibleJSONEncoder)
    assert isinstance(d.decode(s), AnsibleVaultEncryptedUnicode)