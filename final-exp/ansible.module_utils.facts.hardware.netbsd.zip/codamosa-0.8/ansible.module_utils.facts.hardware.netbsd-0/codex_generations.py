

# Generated at 2022-06-11 02:45:07.402630
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    from ansible.module_utils import basic
    sysctl_mock = {'machdep': {
      'dmi': {
        'system-vendor': '',
        'system-product': '',
        'system-version': '',
        'system-serial': '',
        'system-uuid': ''
        }
      }
    }
    mod = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hw = NetBSDHardware(module=mod)
    hw.sysctl = sysctl_mock

    expected_facts = {'processor_count': '2', 'processor_cores': '2', 'processor': ['ARMv5teJ', 'ARMv5teJ']}
    assert hw.populate() == expected_facts



# Generated at 2022-06-11 02:45:16.495173
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = FakeAnsibleModule()
    collector = NetBSDHardwareCollector(module=module)

    hardware_facts = collector.populate()
    assert hardware_facts
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']

    assert hardware_facts['system_vendor']
    assert hardware_facts['product_serial']
    assert hardware_facts['product_name']
    assert hardware_facts['product_uuid']
    assert hardware_facts['product_version']



# Generated at 2022-06-11 02:45:25.938008
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Testing with a mock of sysctl
    sysctl_mock = {
        'machdep.dmi.system-product': 'product',
        'machdep.dmi.system-version': 'version',
        'machdep.dmi.system-uuid': 'uuid',
        'machdep.dmi.system-serial': 'serial',
        'machdep.dmi.system-vendor': 'vendor',
    }
    hardware = NetBSDHardware(module=None, sysctl=sysctl_mock)
    dmi_facts = hardware.get_dmi_facts()

# Generated at 2022-06-11 02:45:35.348434
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    netbsdHardware = NetBSDHardware()
    netbsdHardware.module = None
    # Test scenario #1
    cpu_facts = netbsdHardware.get_cpu_facts()
    assert cpu_facts["processor_cores"] == 1
    assert cpu_facts["processor_count"] == 1
    assert cpu_facts["processor"][0] == "ARMv7 Processor rev 1 (v7l)"
    # Test scenario #2
    cpu_facts = netbsdHardware.get_cpu_facts()
    assert cpu_facts["processor_cores"] == 1
    assert cpu_facts["processor_count"] == 1
    assert cpu_facts["processor"][0] == "Intel(R) Core(TM) i5-2415M CPU @ 2.30GHz"

# Generated at 2022-06-11 02:45:40.313159
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    m = NetBSDHardware()
    facts = {}
    facts = m.populate()

    assert facts['mounts'] is not None
    assert 'mounts' in facts
    assert 'mount' in facts['mounts'][0]
    assert 'device' in facts['mounts'][0]
    assert 'fstype' in facts['mounts'][0]
    assert 'options' in facts['mounts'][0]
    assert 'size_total' in facts['mounts'][0]
    assert 'size_available' in facts['mounts'][0]
    assert 'space_used' in facts['mounts'][0]
    assert 'space_free' in facts['mounts'][0]

    assert facts['processor'] is not None
    assert 'processor' in facts

# Generated at 2022-06-11 02:45:44.677865
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = NetBSDHardware({}).get_cpu_facts()
    assert cpu_facts['processor'][0] == 'Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-11 02:45:52.716928
# Unit test for method populate of class NetBSDHardware

# Generated at 2022-06-11 02:45:57.672663
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_collector = NetBSDHardwareCollector()
    netbsd_facts = netbsd_collector.collect()
    netbsd_hardware_facts = netbsd_facts['ansible_facts']['ansible_hardware']

    assert netbsd_hardware_facts['swaptotal_mb'] == 1023
    assert netbsd_hardware_facts['processor_count'] == 1


# Generated at 2022-06-11 02:46:08.075298
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    # Test when machdep.dmi.system-* mibs are not available
    netbsd_hardware.sysctl = {'machdep.dmi.system-vendor': 'Vendor'}
    dmi_facts = netbsd_hardware.get_dmi_facts()
    assert len(dmi_facts) == 1
    # Test when machdep.dmi.system-* mibs are available

# Generated at 2022-06-11 02:46:17.921662
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    nhw = NetBSDHardware()
    nhw.module = type('AnsibleModule', (), {})
    nhw.sysctl = {
        'machdep.dmi.system-product': 'SB410',
        'machdep.dmi.system-version': '1.0',
        'machdep.dmi.system-uuid': '44454C4C-5100-1046-8030-B2C04F594A32',
        'machdep.dmi.system-serial': 'LK9381050C',
        'machdep.dmi.system-vendor': 'System manufacturer',
        'machdep.dmi.bios-vendor': 'Phoenix Technologies LTD'
    }


# Generated at 2022-06-11 02:48:09.050210
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    expected_result = {'product_name': 'PowerEdge R630', 'product_version': 'Not Specified', 'system_vendor': 'Dell Inc.', 'product_uuid': '3A4326C5-5153-3246-3146-54474E373230', 'product_serial': 'D42R0R'}
    # Test on x86_64

# Generated at 2022-06-11 02:48:19.817436
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    sysctl = {
        'machdep.dmi.system-product' : 'MacBookPro8,2',
        'machdep.dmi.system-version' : '1.0',
        'machdep.dmi.system-uuid' : 'CF64A9D8-C4A4-4B4D-B993-EC8F2A10CBBF',
        'machdep.dmi.system-serial' : 'C02F7C5KDTH2',
    }
    hardware = NetBSDHardware({})
    hardware.sysctl = sysctl
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'MacBookPro8,2'
    assert dmi_facts['product_version'] == '1.0'


# Generated at 2022-06-11 02:48:23.628569
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsdhwcollector_obj = NetBSDHardwareCollector()
    assert netbsdhwcollector_obj._platform == "NetBSD"
    assert netbsdhwcollector_obj._fact_class == NetBSDHardware


# Generated at 2022-06-11 02:48:31.438870
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_module = type('module', (object,), {
        'params': {'gather_timeout': 10},
        'get_mount_size': get_mount_size,
    })

    netbsd_hw = NetBSDHardware(module=netbsd_module)
    facts = netbsd_hw.populate()

    assert 'mounts' in facts

    assert 'MemTotal_mb' in facts
    assert 'SwapTotal_mb' in facts
    assert 'MemFree_mb' in facts
    assert 'SwapFree_mb' in facts

    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'processor' in facts

# Generated at 2022-06-11 02:48:39.309505
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = None
    sysctl = {
        'machdep.dmi.system-product': 'my_product',
        'machdep.dmi.system-version': 'my_version',
        'machdep.dmi.system-uuid': 'my_uuid',
        'machdep.dmi.system-serial': 'my_serial',
        'machdep.dmi.system-vendor': 'my_vendor',
    }

    hw = NetBSDHardware(module=module, sysctl=sysctl)
    dmi_facts = hw.get_dmi_facts()


# Generated at 2022-06-11 02:48:40.591859
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    HWC = NetBSDHardwareCollector()
    assert HWC is not None

# Generated at 2022-06-11 02:48:51.315096
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    hw = NetBSDHardware(dict(module=dict()))

# Generated at 2022-06-11 02:48:56.321123
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] != 'NA'
    assert cpu_facts['processor_count'] > 0
    assert len(cpu_facts['processor']) == cpu_facts['processor_cores'] * cpu_facts['processor_count']

# Generated at 2022-06-11 02:49:03.350154
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_collector = NetBSDHardwareCollector(module=module,
                                                 timeout=10,
                                                 sleep=1,
                                                 collect_default=False)

    facts = hardware_collector.collect()

    assert isinstance(facts['ansible_local']['hardware']['processor'], list)
    assert isinstance(facts['ansible_local']['hardware']['processor_cores'], (str, int))
    assert isinstance(facts['ansible_local']['hardware']['processor_count'], int)
    assert isinstance(facts['ansible_local']['hardware']['memfree_mb'], int)

# Generated at 2022-06-11 02:49:06.412330
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    hardware.get_cpu_facts() == {'processor': [], 'processor_cores': 'NA', 'processor_count': 0}
