

# Generated at 2022-06-11 02:45:03.698441
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    memory_facts = {
        'MemTotal': 12345,
        'SwapTotal': 45678,
        'MemFree': 6789,
        'SwapFree': 8765,
    }

    cpu_facts = {
        'processor': ['foo', 'bar'],
        'processor_count': 4,
        'processor_cores': 5,
    }

    mount_facts = {
        'mounts': [
            {'device': '/dev/wd0a',
             'mount': '/home',
             'fstype': 'fstype',
             'options': 'rw',
             'size_total': 9999999999,
             'size_available': 8080808080,
             'space_used': 88888888}
        ]
    }


# Generated at 2022-06-11 02:45:08.712395
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    """Test the populate() method of NetBSDHardware
    Check if no exceptions are thrown and that the right dictionary is returned.
    """
    from ansible.module_utils.facts.collector.netbsd import NetBSDHardware
    hardware = NetBSDHardware({})
    hardware.populate()
    assert isinstance(hardware.data, dict)

# Generated at 2022-06-11 02:45:12.666913
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    class mock_module:
        def __init__(self):
            self.params = {}
    class mock_sysctl:
        def __init__(self):
            self.machdep = {}
    mock_module = mock_module()
    mock_sysctl = mock_sysctl()
    mock_sysctl.machdep = {'dmi.system-product': 'product_name',
                           'dmi.system-version': 'product_version',
                           'dmi.system-uuid': 'product_uuid',
                           'dmi.system-serial': 'product_serial',
                           'dmi.system-vendor': 'system_vendor', }
    netbsd_hardware.sysctl = mock_sysctl
    netbsd_

# Generated at 2022-06-11 02:45:13.688496
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    NetBSDHardware().populate()

# Generated at 2022-06-11 02:45:23.689868
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    module = type('MockModule', (object,), {})()
    setattr(module, 'get_file_lines', lambda path: ['MemTotal:      16715176 kB',
                                                    'MemFree:       15836696 kB',
                                                    'SwapTotal:      1048572 kB',
                                                    'SwapFree:       1048572 kB'])
    setattr(module, 'fail_json', lambda msg: sys.exit(1))

    hardware = NetBSDHardware(module)
    memory_facts = hardware.get_memory_facts()

    # MemTotal of the host in KB
    assert memory_facts['memtotal_mb'] == 16715
    assert memory_facts['swaptotal_mb'] == 1048
    assert memory_facts['memfree_mb'] == 15836
    assert memory_facts

# Generated at 2022-06-11 02:45:30.107822
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    facts = NetBSDHardware()
    res = facts.populate()
    assert 'Mounts' in res
    assert 'memtotal_mb' in res
    assert res['memtotal_mb'] > 0
    assert 'memfree_mb' in res
    assert res['memfree_mb'] > 0
    assert 'swaptotal_mb' in res
    assert 'swapfree_mb' in res
    assert 'processor_count' in res
    assert res['processor_count'] > 0
    assert 'processor' in res
    assert 'processor_cores' in res
    assert res['processor_cores'] > 0
    assert 'product_name' in res
    assert len(res['product_name']) > 0
    assert 'product_version' in res
    assert len(res['product_version']) > 0

# Generated at 2022-06-11 02:45:39.173241
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    test = NetBSDHardware(dict())
    test.module = type('obj', (object,), {'get_bin_path': lambda _, x: x})
    test.content = {'machdep.hw_ncpu': 8,
                    'machdep.hw_cpu_freq': 800,
                    'machdep.hw_cacheconfig': ['8192', '3'],
                    'machdep.hw_cachesize': ['16777216', '16777216', '8388608', '8388608'],
                    'machdep.hw_model': 'Intel(R) Core(TM) i7-2600K CPU @ 3.40GHz',
                    'machdep.hw_vendor': 'GenuineIntel'}
    assert test.get_cpu_facts()['processor_count'] == 8


# Generated at 2022-06-11 02:45:41.491981
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    obj = NetBSDHardwareCollector()
    assert obj._fact_class == NetBSDHardware
    assert obj._platform == 'NetBSD'

# Generated at 2022-06-11 02:45:43.637320
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    collector = NetBSDHardwareCollector()
    assert isinstance(collector, NetBSDHardwareCollector)
    assert collector.platform == 'NetBSD'

# Generated at 2022-06-11 02:45:50.209874
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    obj = NetBSDHardware()
    obj.module.get_file_contents = lambda a: 'MemTotal: 32453432 kB\nMemFree: 4343344 kB\nSwapTotal: 2342434 kB\nSwapFree: 1234324 kB'
    result = obj.get_memory_facts()
    assert result['memtotal_mb'] == 31504
    assert result['memfree_mb'] == 4254
    assert result['swaptotal_mb'] == 22968
    assert result['swapfree_mb'] == 12090


# Generated at 2022-06-11 02:47:48.132014
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = None
    facts = NetBSDHardwareCollector.collect(module=module)
    fact_name = 'processor_cores'
    assert facts[fact_name] == 'NA' or isinstance(facts[fact_name], int)
    assert isinstance(facts['processor_count'], int)
    for key in NetBSDHardware.MEMORY_FACTS:
        assert isinstance(facts[key.lower() + "_mb"], int)
    assert isinstance(facts['processor'], list)
    assert isinstance(facts['devices'], dict)
    assert isinstance(facts['mounts'], list)
    assert isinstance(facts['product_name'], str)

# Generated at 2022-06-11 02:47:51.094748
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    module = AnsibleModuleMock()
    x = NetBSDHardwareCollector(module=module)
    assert x.platform == 'NetBSD'
    assert x.sysctl == {}
    assert x.facts == {}


# Generated at 2022-06-11 02:47:55.777143
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()

    assert 'processor_count' in hardware.populate()
    assert 'processor_cores' in hardware.populate()
    assert 'processor' in hardware.populate()
    assert 'memtotal_mb' in hardware.populate()
    assert 'swaptotal_mb' in hardware.populate()
    assert 'mounts' in hardware.populate()

# Generated at 2022-06-11 02:48:04.586963
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    netbsd_hw = NetBSDHardware()
    netbsd_hw.module = dict()
    netbsd_hw.module['run_command'] = lambda x: "2"
    netbsd_hw.module['fail_json'] = False
    netbsd_hw.module['params'] = {}
    netbsd_hw.module['params']['filter'] = ('*')
    netbsd_hw.module['tmpdir'] = '/tmp/'

    facts_list = netbsd_hw.populate()
    assert facts_list['processor'] == ['Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz']
    assert facts_list['processor_count'] == '2'
    assert facts_list['processor_cores'] == '4'

# Generated at 2022-06-11 02:48:15.620998
# Unit test for method populate of class NetBSDHardware

# Generated at 2022-06-11 02:48:24.138788
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware(None)

    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'machdep.dmi.system-product',
        'machdep.dmi.system-version': 'machdep.dmi.system-version',
        'machdep.dmi.system-uuid': 'machdep.dmi.system-uuid',
        'machdep.dmi.system-serial': 'machdep.dmi.system-serial',
        'machdep.dmi.system-vendor': 'machdep.dmi.system-vendor',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()

# Generated at 2022-06-11 02:48:30.399303
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    test_input = '''MemTotal:      131072 kB
SwapTotal:     262144 kB
MemFree:         8376 kB
SwapFree:        4096 kB
'''
    test_output = {'memfree_mb': 8, 'memtotal_mb': 128,
                   'swapfree_mb': 4, 'swaptotal_mb': 256}
    h = NetBSDHardware()
    assert test_output == h.get_memory_facts(test_input)


# Generated at 2022-06-11 02:48:32.498924
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    c = NetBSDHardwareCollector({})
    assert c.platform == 'NetBSD'
    assert issubclass(c._fact_class, NetBSDHardware)


# Generated at 2022-06-11 02:48:41.593961
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class Fake_Module():
        pass

    class Fake_get_sysctl():
        def __init__(self, module, branches):
            self.branches = branches
            self.sysctl = {
                'machdep.dmi.system-vendor': 'Supermicro',
                'machdep.dmi.system-product': 'X9SCM-F',
                'machdep.dmi.system-version': 'None',
                'machdep.dmi.system-uuid': '564d4d3a-6b3a-11e7-8bd3-3c15c2f932f2',
                'machdep.dmi.system-serial': 'xxxxxxxxxxx'
            }

        def __getitem__(self, branch):
            return self.sysctl[branch]



# Generated at 2022-06-11 02:48:52.554349
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_facts = NetBSDHardware()

# Generated at 2022-06-11 02:50:52.566698
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    import platform
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.module = MockModule()
    netbsd_hardware.collector = NetBSDHardwareCollector()

    class MockSysctl(object):
        def read(self, path):
            path_parts = path.split('.')

            if len(path_parts) != 2 or path_parts[0] != 'machdep':
                raise IOError('Invalid path')

            if path_parts[1] == 'dmi.system-product':
                return 'Gigabyte Brix M1'
            elif path_parts[1] == 'dmi.system-version':
                return '1.0'

# Generated at 2022-06-11 02:50:54.042401
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hw = NetBSDHardware(dict())
    assert isinstance(hw.populate(), dict)



# Generated at 2022-06-11 02:50:56.002315
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    result = {}
    hardware_instance = NetBSDHardware({})
    hardware_instance.populate(result)

# Generated at 2022-06-11 02:51:03.312171
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    """Return a list of cpu facts"""

    ha = NetBSDHardware()

    expected_list = ['x86_64', 'sched_clock_hz', 'cputyp', 'ncpu', 'hw_ncpu',
                     'hw_ncpu_perf', 'hw_ncpu_possible', 'hw_ncpu_perf_possible',
                     'hw_cpuspeed', 'hw_cpuspeed_max', 'hw_cpuspeed_override']

    facts = ha.get_cpu_facts()

    # check for expected key names
    for key in expected_list:
        assert key in facts

    # check that the values returned are correct
    assert type(facts['ncpu']) is int
    assert type(facts['hw_ncpu']) is int

# Generated at 2022-06-11 02:51:07.023425
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    # Create a NetBSDHardware instance
    nhw = NetBSDHardware()

    # Populate the NetBSDHardware facts
    nhw_facts = nhw.populate()

    # Since NetBSD hardware facts can't be properly tested on non-NetBSD
    # systems and since we don't want to setup a NetBSD system for each run of
    # the unit test suite we will just test whether or not the NetBSDHardware
    # class is able to collect any fact at all.
    assert len(nhw_facts) > 0

# Generated at 2022-06-11 02:51:11.482120
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware({})
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'devices' in facts

# Generated at 2022-06-11 02:51:12.257166
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    HardwareCollector('NetBSD')


# Generated at 2022-06-11 02:51:21.056296
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    hardware = NetBSDHardware()

    hardware.module = MockModule()

    hardware.sysctl = {'machdep.dmi.system-product': 'Test product',
                       'machdep.dmi.system-version': '2.0',
                       'machdep.dmi.system-uuid': '0123456789abcdef',
                       'machdep.dmi.system-serial': '123456',
                       'machdep.dmi.system-vendor': 'Test vendor'}


# Generated at 2022-06-11 02:51:26.059176
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = None
    facts = NetBSDHardware(module).populate()

    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts



# Generated at 2022-06-11 02:51:35.296402
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    hardware = NetBSDHardware({'module_name':''})
    hardware.sysctl = {
        'machdep.dmi.system-product': 'product_name',
        'machdep.dmi.system-version': 'product_version',
        'machdep.dmi.system-uuid': 'product_uuid',
        'machdep.dmi.system-serial': 'product_serial',
        'machdep.dmi.system-vendor': 'system_vendor',
    }
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'product_name', "The product_name should be 'product_name'"