

# Generated at 2022-06-11 02:45:06.913476
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_out = {
        "MemTotal_mb": 3289,
        "SwapTotal_mb": 6719,
        "MemFree_mb": 3250,
        "SwapFree_mb": 6719,
        "processor_cores": 1,
        "system_vendor": "Quanta",
        "product_uuid": "000107-04-0772EE-C1482D-B7B3EB",
        "product_version": "1.0",
        "processor_count": 1,
        "processor": ["ARMv7 Processor rev 1 (v7l)"],
        "product_name": "QSSC-S4R/Appliance",
        "product_serial": "None"
    }


# Generated at 2022-06-11 02:45:09.922681
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    nhc = NetBSDHardwareCollector()
    assert nhc.platform == "NetBSD"
    assert nhc.fact_class == NetBSDHardware

# Generated at 2022-06-11 02:45:19.957897
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    def test_get_meminfo_content():
        return '''MemTotal:        2052048 kB
MemFree:          888060 kB
SwapTotal:       1048572 kB
SwapFree:         810020 kB'''


# Generated at 2022-06-11 02:45:21.271371
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    x = NetBSDHardwareCollector()
    assert x.platform == 'NetBSD'

# Generated at 2022-06-11 02:45:28.355065
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    from mock import patch
    from ansible.module_utils.facts import collector

    # Injects the mock of methods get_sysctl and get_mount_size
    # in the NetBSDHardware class
    with patch.object(NetBSDHardware, "get_sysctl") as m_get_sysctl:
        with patch.object(NetBSDHardware, "get_mount_size") as m_get_mount_size:
            # Stores the results of method get_dmi_facts in a dictionary
            netbsd_hardware = NetBSDHardware()
            results = netbsd_hardware.get_dmi_facts()

    # Asserts the method get_sysctl has been called by get_dmi_facts
    assert m_get_sysctl.called

    # Asserts the results of get_dmi_facts on the mocked object

# Generated at 2022-06-11 02:45:37.247697
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    os_sysctl_fixture = {'machdep.dmi.system-product': 'snake-oil',
                         'machdep.dmi.system-version': '1.0',
                         'machdep.dmi.system-uuid': '00000000-0000-0000-0000-000000000000',
                         'machdep.dmi.system-serial': '123456789',
                         'machdep.dmi.system-vendor': 'acme'}
    NetBSD_hw = NetBSDHardware({'module': None, 'sysctl': os_sysctl_fixture})
    dmi_facts = NetBSD_hw.get_dmi_facts()

    assert dmi_facts['product_name'] == 'snake-oil'
    assert dmi_facts['product_version'] == '1.0'


# Generated at 2022-06-11 02:45:41.446014
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hw = NetBSDHardware()
    # here we don't assert if the machine is supported or not
    # it's OK to have an empty dictionary if machine is not supported
    results = netbsd_hw.populate()
    assert isinstance(results, dict)
    assert results == {}

# Generated at 2022-06-11 02:45:50.565407
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # A list of sysctl mibs and their associated dmi fact names
    sysctl_to_dmi_fact = {
            'machdep.dmi.system-product': 'product_name',
            'machdep.dmi.system-vendor': 'system_vendor',
            'machdep.dmi.system-serial': 'product_serial',
            'machdep.dmi.system-version': 'product_version',
            'machdep.dmi.system-uuid': 'product_uuid',
    }

    # Test the happy path, i.e. all sysctl mibs present
    nhw = NetBSDHardware({}, {
        'machdep': { k: k for k in sysctl_to_dmi_fact },
    })


# Generated at 2022-06-11 02:45:55.240478
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    NetBSDHardware.MEMORY_FACTS = ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']
    hardware.get_memory_facts()
    assert hardware.memfree_mb != None
    assert hardware.memtotal_mb != None
    assert hardware.swapfree_mb != None
    assert hardware.swaptotal_mb != None


# Generated at 2022-06-11 02:46:01.163349
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = dict(rc=0, stdout="Product name: Test product\nSerial: 123-456-789\n")

    test_obj = NetBSDHardware(module)
    sysctl = dict()
    test_obj.sysctl = sysctl

    res = test_obj.get_dmi_facts()
    assert res == dict(product_name="Test product", product_serial="123-456-789")


# Generated at 2022-06-11 02:47:41.748505
# Unit test for method populate of class NetBSDHardware

# Generated at 2022-06-11 02:47:44.923239
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_harware = NetBSDHardwareCollector()
    assert netbsd_harware.hardware._platform == 'NetBSD'
    assert netbsd_harware.hardware._fact_class == 'NetBSDHardware'


# Generated at 2022-06-11 02:47:53.769874
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    data_dir_path = os.path.join(os.path.dirname(__file__), 'unit', 'data')
    sysctl_content = get_file_content(os.path.join(data_dir_path, 'sysctl'))

    class MockModule:
        params = {'gather_timeout': 10}

    class MockFactManager:
        def __init__(self, module):
            self.module = module

    class MockHardware:
        def __init__(self, module, fact_manager):
            self.module = module
            self.fact_manager = fact_manager
            self.sysctl = {}

    m = MockModule()
    fm = MockFactManager(m)
    h = MockHardware(m, fm)
    for line in sysctl_content.splitlines():
        data = line

# Generated at 2022-06-11 02:48:02.606255
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = NetBSDHardware()
    module.sysctl = {
        'machdep.dmi.system-product': 'ThinkPad T430',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': 'DUMMY-UUID',
        'machdep.dmi.system-serial': 'R9XKXRT',
        'machdep.dmi.system-vendor': 'LENOVO'
    }
    dmi_facts = module.get_dmi_facts()

# Generated at 2022-06-11 02:48:04.512986
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    test_class = NetBSDHardware(dict())
    ret = test_class.get_dmi_facts()
    test = ret == {}
    assert test

# Generated at 2022-06-11 02:48:15.555079
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    qemu_facts = {
        'processor_count': 1,
        'processor_cores': 'NA',
        'processor': ['ARMv7 Processor rev 2 (v7l)'],
        'memfree_mb': 15,
        'swapfree_mb': 0,
        'memtotal_mb': 15,
        'swaptotal_mb': 0,
        'product_name': 'Standard PC (i440FX + PIIX, 1996)',
        'product_version': 'pc-1.0',
        'product_uuid': '00000000-0000-0000-0000-000000000000',
        'product_serial': 'Not Specified',
        'system_vendor': 'Acme'
    }


# Generated at 2022-06-11 02:48:20.657576
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Get a NetBSDHardware instance, then assert it can generate a dict of facts
    # about the host's hardware.
    h = NetBSDHardware()
    hw_facts = h.populate()

    assert hw_facts['processor']
    assert hw_facts['memtotal_mb']
    assert hw_facts['memfree_mb']
    assert hw_facts['swaptotal_mb']
    assert hw_facts['swapfree_mb']


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 02:48:28.089323
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_module = type('module', (object,), dict(
        supplied_argument_spec=dict(
            gather_mount_points=dict(default=True, type="bool")
        )
    ))
    test_obj = NetBSDHardware(test_module)

    test_obj.populate()

    assert 'MemTotal_mb' in test_obj.facts
    assert 'SwapTotal_mb' in test_obj.facts
    assert 'MemFree_mb' in test_obj.facts
    assert 'SwapFree_mb' in test_obj.facts


# Generated at 2022-06-11 02:48:36.037464
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    hardware = NetBSDHardware({}, ansible_facts={})
    sysctl_to_dmi = {
        'machdep.dmi.system-product': 'product_name',
        'machdep.dmi.system-version': 'product_version',
        'machdep.dmi.system-uuid': 'product_uuid',
        'machdep.dmi.system-serial': 'product_serial',
        'machdep.dmi.system-vendor': 'system_vendor',
    }

    test_sysctl = {}
    test_sysctl.update(sysctl_to_dmi)
    test_dmi_facts = hardware.get_dmi_facts()

    assert(test_dmi_facts == sysctl_to_dmi)


# Generated at 2022-06-11 02:48:42.487503
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = AnsibleModule()
    set_module_args({'ANSIBLE_CALLABLE_WHITELIST': ['get_dmi_facts']})
    hardware = NetBSDHardwareCollector.collect(module)
    dmi_facts = hardware.get_dmi_facts()

    assert isinstance(dmi_facts, dict)
    # These keys should exist
    for k in ('product_name', 'product_version', 'system_vendor'):
        assert k in dmi_facts



# Generated at 2022-06-11 02:50:32.406391
# Unit test for method get_cpu_facts of class NetBSDHardware

# Generated at 2022-06-11 02:50:34.501108
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    NetBSDHardwareCollector.collect()

if __name__ == '__main__':
    test_NetBSDHardware_populate()

# Generated at 2022-06-11 02:50:36.659932
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    args = dict()
    obj = NetBSDHardware(args)
    result = obj.populate()
    assert result is not None

# Generated at 2022-06-11 02:50:39.192629
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    '''Unit test for populate method of class NetBSDHardware on NetBSD platform'''
    nb_hw = NetBSDHardware()
    nb_hw.module = None
    assert nb_hw.populate()

# Generated at 2022-06-11 02:50:41.085251
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    """Unit test for constructor of class NetBSDHardwareCollector"""
    collector = NetBSDHardwareCollector()
    assert collector.platform == 'NetBSD'

# Generated at 2022-06-11 02:50:42.488192
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.get_dmi_facts()

# Generated at 2022-06-11 02:50:50.692736
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()

    cpu_facts = hardware.get_cpu_facts()
    assert isinstance(cpu_facts, dict), \
        'get_cpu_facts should return a dictionary'
    assert 'processor' in cpu_facts, \
        "get_cpu_facts should return a 'processor' key"
    assert isinstance(cpu_facts['processor'], list), \
        "get_cpu_facts should return a 'processor' key that contains a list"
    assert 'processor_count' in cpu_facts, \
        "get_cpu_facts should return a 'processor_count' key"
    assert isinstance(cpu_facts['processor_count'], int), \
        "get_cpu_facts should return a 'processor_count' key that contains an int"

# Generated at 2022-06-11 02:50:55.499244
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    facts = NetBSDHardware(return_empty_facts=True, module=None).populate()

    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'processor' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts

# Generated at 2022-06-11 02:51:02.910154
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    sysctl = {
        'machdep.dmi.system-product': 'product_name',
        'machdep.dmi.system-version': 'product_version',
        'machdep.dmi.system-uuid': 'product_uuid',
        'machdep.dmi.system-serial': 'product_serial',
        'machdep.dmi.system-vendor': 'system_vendor',
        'machdep.dmi.board-name': 'board_name',
    }
    h = NetBSDHardware()
    h.sysctl = sysctl
    result = h.get_dmi_facts()

# Generated at 2022-06-11 02:51:08.161812
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    """ NetBSDHardware - populate
    When called it provides all the hardware information
    expected on a NetBSD system"""
    memory = NetBSDHardware.get_memory_facts()
    cpu = NetBSDHardware.get_cpu_facts()
    mount = NetBSDHardware.get_mount_facts()
    dmi = NetBSDHardware.get_dmi_facts()
    result = memory.update(cpu)
    result = result.update(mount)
    result = result.update(dmi)

# Generated at 2022-06-11 02:53:11.832449
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module_mock = type('module_mock', (), {})()
    hardware_mock = NetBSDHardware(module_mock)

    hardware_mock.sysctl = {
        'machdep.dmi.system-product': 'Dell Inc.',
        'machdep.dmi.system-version': 'Not Specified',
        'machdep.dmi.system-uuid': '1234',
        'machdep.dmi.system-serial': '1234',
        'machdep.dmi.system-vendor': 'Dell Inc.',
    }

    result = hardware_mock.get_dmi_facts()
