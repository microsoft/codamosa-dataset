

# Generated at 2022-06-24 22:10:09.829174
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:10:11.810596
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:10:14.414858
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hardware = NetBSDHardware()
    assert netbsd_hardware.populate()

# Generated at 2022-06-24 22:10:17.236686
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert isinstance(net_b_s_d_hardware_collector_0, NetBSDHardwareCollector)

# Generated at 2022-06-24 22:10:19.439215
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:21.933666
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    try:
        net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    except NameError as ne:
        print(ne)
if __name__ == '__main__':
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:10:24.991760
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:10:27.994380
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:10:30.980994
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    net_b_s_d_hardware_0.populate(collected_facts={'system': {'name': 'Linux'}})

# Generated at 2022-06-24 22:10:40.238479
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    # Preparing the monkey patch, simulating values returned by get_sysctl

# Generated at 2022-06-24 22:12:03.592869
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:09.422300
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': 'NA', 'memtotal_mb': 'NA', 'swapfree_mb': 'NA', 'swaptotal_mb': 'NA'}


# Generated at 2022-06-24 22:12:12.223191
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:12:16.954244
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware({})
    net_b_s_d_hardware_0.module = AnsibleModule(argument_spec={})
    net_b_s_d_hardware_0.collect()


# Generated at 2022-06-24 22:12:21.425037
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_cpu_facts() == {'processor': ['ARMv7 Processor rev 4 (v7l)'], 'processor_count': 1, 'processor_cores': 1}


# Generated at 2022-06-24 22:12:25.663320
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_1 = NetBSDHardware()
    net_b_s_d_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:12:30.288537
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

if __name__ == "__main__":
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:12:36.113853
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_cpu_facts() == {'processor': ['Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz'], 'processor_count': 2, 'processor_cores': 4}


# Generated at 2022-06-24 22:12:40.678192
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardwareCollector.fetch_all()
    collect_d = True
    try:
        test_case_0()
    except Exception as e:
        print(e)
        collect_d = False
    assert collect_d
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 22:12:46.334215
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware({}, None)
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'product_name', 'machdep.dmi.system-version': 'product_version', 'machdep.dmi.system-uuid': 'product_uuid', 'machdep.dmi.system-serial': 'product_serial', 'machdep.dmi.system-vendor': 'system_vendor'}

    net_b_s_d_hardware_1 = NetBSDHardware({}, None)

# Generated at 2022-06-24 22:14:05.897359
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware({"module": "NetBSDHardware"})
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:11.737000
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_cpu_facts() == {'processor': ['Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz'], 'processor_count': 1, 'processor_cores': 12}


# Generated at 2022-06-24 22:14:13.964916
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:14:17.902526
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    """
    Unit test for method populate of class NetBSDHardware
    """
    net_b_s_d_hardware_0 = NetBSDHardware()


if __name__ == "__main__":
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:14:20.858485
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # instantiate class NetBSDHardware
    net_b_s_d_hardware_0 = NetBSDHardware()

    # call method populate of class NetBSDHardware
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:23.058831
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    assert(net_b_s_d_hardware_0.populate() == dict())


# Generated at 2022-06-24 22:14:25.423880
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware({})
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:29.162936
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware_populate_0 = net_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:14:30.859129
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:14:36.271237
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert isinstance(net_b_s_d_hardware_collector_0, NetBSDHardwareCollector)


# Generated at 2022-06-24 22:17:57.262730
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    facts_list_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:18:02.194913
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.populate() == None, 'Test failed because expected None and got ' + str(net_b_s_d_hardware_0.populate()) + ' on line 61'


# Generated at 2022-06-24 22:18:04.390426
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:18:08.301138
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts = None
    net_b_s_d_hardware_0.module = None
    net_b_s_d_hardware_0.sysctl = None
    net_b_s_d_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:18:11.364886
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:18:16.832962
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0.module, {}, {}, {})
    assert not net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:18:22.535252
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()

    net_b_s_d_hardware.populate()
    assert net_b_s_d_hardware.cpu_facts == {'processor_cores': 'NA',
                                            'processor_count': 2,
                                            'processor': ['Geode(TM) Integrated Processor by AMD PCS',
                                                          'Geode(TM) Integrated Processor by AMD PCS']}



# Generated at 2022-06-24 22:18:24.985880
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:18:32.122319
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_h = NetBSDHardware
    net_b_s_d_h.platform = 'NetBSD'
    net_b_s_d_h.MEMORY_FACTS = ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']
    assert net_b_s_d_h.get_cpu_facts() == {'processor': ['Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'], 'processor_cores': 4, 'processor_count': 1}, 'Failed to get expected cpu facts'


# Generated at 2022-06-24 22:18:38.112179
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    input_params = {
        'module': 'fake_module',
    }

    expected_result = {
    }

    net_b_s_d_hardware_0 = NetBSDHardware(input_params)
    net_b_s_d_hardware_0.populate()
    result = net_b_s_d_hardware_0.data

    assert (result == expected_result)

