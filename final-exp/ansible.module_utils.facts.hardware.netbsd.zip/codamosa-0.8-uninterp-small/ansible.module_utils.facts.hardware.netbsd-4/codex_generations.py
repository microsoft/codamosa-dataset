

# Generated at 2022-06-24 22:10:33.271741
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:37.631560
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:43.019285
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    # An 'if' statement is used here to avoid a warning about the
    # 'collected_facts' argument being unused. This argument is used by some
    # hardware subclasses, but not by this one.
    if 'collected_facts' in net_b_s_d_hardware_0.populate.__code__.co_varnames:
        net_b_s_d_hardware_0.populate(collected_facts=None)

# Generated at 2022-06-24 22:10:49.160217
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    mem_key = 'MemTotal'
    if mem_key in net_b_s_d_hardware_0.net_b_s_d_hardware_collector._fact_class.MEMORY_FACTS:
        mem_key = 'MemTotal'
    else:
        mem_key = 'MemTotal'
    if mem_key in net_b_s_d_hardware_0.net_b_s_d_hardware_collector._fact_class.MEMORY_FACTS:
        mem_key = 'MemTotal'

# Generated at 2022-06-24 22:10:52.988273
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:10:58.636182
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    result = net_b_s_d_hardware_0.get_cpu_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:11:07.237439
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)

    # Set up test environment
    file_0_lines = list()
    file_0_lines.append('MemTotal:        8048632 kB')
    file_0_lines.append('SwapTotal:       5047360 kB')
    file_0_lines.append('MemFree:          994648 kB')
    file_0_lines.append('SwapFree:        5047360 kB')

    file_0 = file()
    file_0.name = '/proc/meminfo'
    file_0.closed = False
    file_0.mode = 'r'

# Generated at 2022-06-24 22:11:10.998948
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:11:14.619835
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:11:23.518605
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    collected_facts = {}
    net_b_s_d_hardware_0.populate(collected_facts=collected_facts)

# Generated at 2022-06-24 22:12:50.221375
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:12:52.719487
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.populate() is None


# Generated at 2022-06-24 22:12:54.993372
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    # Test with missing argument
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:12:58.929319
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=None)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:13:01.857317
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()

# Generated at 2022-06-24 22:13:03.957681
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=None)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:13:14.476666
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_h = {}
  
    netbsd_h['processor'] = ['Intel(R) Core(TM)2 Quad CPU Q6600 @ 2.40GHz']
    netbsd_h['processor_cores'] = 1
    netbsd_h['processor_count'] = 1
    netbsd_h['devices'] = {}
    netbsd_h['memfree_mb'] = 2118
    netbsd_h['memtotal_mb'] = 4048
    netbsd_h['swapfree_mb'] = 637400
    netbsd_h['swaptotal_mb'] = 637400

# Generated at 2022-06-24 22:13:23.730613
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(
        module=None
    )

    # Reset the mock_open context manager mocks.
    mock_open.reset_mock()

    # Call the under test get_dmi_facts method.
    result = net_b_s_d_hardware_0.get_dmi_facts()

    # Assert that the result is correct.
    assert result == {
        'system_vendor': 'Dell Inc.',
        'product_name': 'OptiPlex 7010',
        'product_serial': '28FF3K1',
        'product_uuid': '10CFB3D0-D4CF-11DE-B58F-FB2D21C7BD2C',
        'product_version': '01',
    }



# Generated at 2022-06-24 22:13:27.156612
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware_populate_0 = net_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:13:29.776342
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    test_case_0()
    assert net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:15:14.291269
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware({})

# Generated at 2022-06-24 22:15:23.720673
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=AnsibleModule)
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0.sysctl = {}
    net_b_s_d_hardware_0.json_data = {}
    net_b_s_d_hardware_0.module.params = {}
    net_b_s_d_hardware_collector_0.module = AnsibleModule
    net_b_s_d_hardware_collector_0.facts = {}
    net_b_s_d_hardware_0.module.params.update({"sysctl_path": "/sbin/sysctl"})
    net_b_s_d_hardware

# Generated at 2022-06-24 22:15:28.408215
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    return_value = net_b_s_d_hardware_0.get_cpu_facts()
    assert return_value is not None


# Generated at 2022-06-24 22:15:33.630196
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = type('',(),{'run_command':(lambda *_, **__: (0,'','')), })()
    net_b_s_d_hardware_0.sysctl = type('',(),{'get':(lambda *_, **__: ''), })()
    net_b_s_d_hardware_0.populate()
# Test class NetBSDHardware
test_NetBSDHardware_populate()


# Generated at 2022-06-24 22:15:45.065441
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    """Unit tests for method get_dmi_facts of class NetBSDHardware"""

    net_b_s_d_hardware_0 = NetBSDHardware(None)
    # Test with no setattr
    n_b_s_d_hardware_sysctl = {'machdep.dmi.system-product': 'OpenBSD', 'machdep.dmi.system-serial': '', 'machdep.dmi.system-vendor': '', 'machdep.dmi.system-uuid': '', 'machdep.dmi.system-version': ''}
    net_b_s_d_hardware_0.sysctl = n_b_s_d_hardware_sysctl
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}
    # Test with

# Generated at 2022-06-24 22:15:48.636744
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:15:51.146320
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0.platform == 'NetBSD'



# Generated at 2022-06-24 22:16:01.126051
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

# Generated at 2022-06-24 22:16:06.186961
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(None)
    mem_total = net_b_s_d_hardware_0.facts['memtotal_mb']
    assert type(mem_total) is int


# Generated at 2022-06-24 22:16:10.986583
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_ = NetBSDHardware()
    assert net_b_s_d_hardware_.get_dmi_facts() == {'system_vendor': 'NetBSD', 'product_uuid': '00000000-0000-0000-0000-000000000000', 'product_name': 'Not Specified', 'product_version': 'Not Specified', 'product_serial': 'Not Specified'}


# Generated at 2022-06-24 22:18:05.292523
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_dhardware_0 = NetBSDHardware()
    assert net_b_s_dhardware_0.get_cpu_facts() == {'processor_count': 1,
                                                   'processor': ['ARMv7 Processor rev 5 (v7l)'],
                                                   'processor_cores': 'NA'}

# Generated at 2022-06-24 22:18:14.646137
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(None)
    collected_facts = {'kernel': 'NetBSD'}
    net_b_s_d_hardware_return = net_b_s_d_hardware_0.populate(collected_facts)
    assert net_b_s_d_hardware_return['processor_count'] == 2
    assert net_b_s_d_hardware_return['processor_cores'] == 1
    assert net_b_s_d_hardware_return['processor'][0] == 'ARMv7 Processor rev 2 (v7l)'
    assert net_b_s_d_hardware_return['processor'][1] == 'ARMv7 Processor rev 2 (v7l)'

# Generated at 2022-06-24 22:18:19.274717
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.collect()
    assert isinstance(net_b_s_d_hardware_0, NetBSDHardware) == 1


# Generated at 2022-06-24 22:18:22.042895
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector is not None


# Generated at 2022-06-24 22:18:24.947845
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert isinstance(net_b_s_d_hardware_0.populate(), dict) == True


# Generated at 2022-06-24 22:18:31.271280
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_dmi_facts() == {
                'product_name': 'OpenBSD.org OpenBSD/amd64',
                'product_version': '6.6',
                'product_uuid': '00000000-0000-0000-0000-000000000000',
                'product_serial': '',
                'system_vendor': 'OpenBSD',
              }


# Generated at 2022-06-24 22:18:36.342482
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.collect()
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:18:43.915754
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = ansible_module_mock


# Generated at 2022-06-24 22:18:52.355163
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # NetBSDHardware.get_memory_facts() tests
    assert NetBSDHardware.get_memory_facts({}) == {}
    assert NetBSDHardware.get_memory_facts({'__ansible_no_log': False}) == {}
    assert NetBSDHardware.get_memory_facts({'__ansible_no_log': True}) == {}
    assert NetBSDHardware.get_memory_facts({'__ansible_no_log': 'on'}) == {}
    assert NetBSDHardware.get_memory_facts({'__ansible_no_log': ''}) == {}
    assert NetBSDHardware.get_memory_facts({'__ansible_no_log': '1'}) == {}
    assert NetBSDHardware.get_memory_facts({'__ansible_no_log': 1}) == {}
    assert NetBSDHardware.get_memory