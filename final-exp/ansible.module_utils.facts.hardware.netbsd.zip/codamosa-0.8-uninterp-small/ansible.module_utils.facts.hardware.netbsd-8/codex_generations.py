

# Generated at 2022-06-24 22:09:59.284642
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=None)
    net_b_s_d_hardware_1 = NetBSDHardware(module=None)


# Generated at 2022-06-24 22:10:03.107250
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:10:12.836002
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'Sun Ultra 40', 'machdep.dmi.system-version': '1.0', 'machdep.dmi.system-serial': '1234', 'machdep.dmi.system-vendor': 'Sun Microsystems', 'machdep.dmi.system-uuid': '1234'}

# Generated at 2022-06-24 22:10:18.417165
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MockModule()
    net_b_s_d_hardware_0.sysctl = dict()

    # call the method
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:10:21.151443
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=None, params=None)
    net_b_s_d_hardware_0.populate(collected_facts=None)


# Generated at 2022-06-24 22:10:22.991060
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    t_c_0 = test_case_0()

if __name__ == "__main__":
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:10:25.220318
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate([])

# Generated at 2022-06-24 22:10:29.753205
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = None
    collected_facts = {}
    net_b_s_d_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:10:33.297504
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    assert net_b_s_d_hardware_0.populate() is None

# Generated at 2022-06-24 22:10:35.201239
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:11:38.649387
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    assert isinstance(net_b_s_d_hardware_0, Hardware) is True
    assert isinstance(net_b_s_d_hardware_0, NetBSDHardware) is True
    assert hasattr(net_b_s_d_hardware_0, 'module') is True
    assert hasattr(net_b_s_d_hardware_0, 'sysctl') is True
    assert net_b_s_d_hardware_0.sysctl is None
    assert hasattr(net_b_s_d_hardware_0, 'MEMORY_FACTS') is True
    assert isinstance(net_b_s_d_hardware_0.MEMORY_FACTS, list) is True

# Generated at 2022-06-24 22:11:47.965120
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Initialize the class
    net_b_s_d_hardware = NetBSDHardware()

    # Fake module input parameters
    params = {'timeout': 10, 'config': {}}

    # Fake the AnsibleModule
    from ansible.module_utils.facts import ansible_module
    am = ansible_module.AnsibleModule(argument_spec=params)
    am.params = params

    # Assign module as NetBSDHardware's module class variable
    NetBSDHardware.module = am

    # Instantiate HardwareCollector class
    net_b_s_d_hardware_collector = NetBSDHardwareCollector()

    # Fake the values of sysctl(8)

# Generated at 2022-06-24 22:11:58.325892
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    # This sysctl would be loaded from /proc/cpuinfo
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'Latitude 5580','machdep.dmi.system-version': 'Not Specified','machdep.dmi.system-uuid': 'Not Specified','machdep.dmi.system-serial': 'PF0H6P2','machdep.dmi.system-vendor': 'Dell Inc.'}
    net_b_s_d_hardware_0.get_dmi_facts()
    return net_b_s_d_hardware_0.facts['product_name'] == 'Latitude 5580'


# Generated at 2022-06-24 22:12:02.706736
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}, 'The assertion failed'


# Generated at 2022-06-24 22:12:04.464683
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()


# Generated at 2022-06-24 22:12:15.485098
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts_0 = {}
    collected_facts_0['ansible_facts'] = {}
    ansible_facts_0 = {}
    collected_facts_0['ansible_facts'] = ansible_facts_0
    ansible_facts_0['ansible_system'] = 'Linux'
    ansible_facts_0['ansible_distribution'] = 'Debian GNU/Linux'
    ansible_facts_0['ansible_distribution_release'] = 'jessie/sid'
    ansible_facts_0['ansible_os_family'] = 'Debian'
    ansible_facts_0['ansible_distribution_version'] = '8'

# Generated at 2022-06-24 22:12:18.315873
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware = NetBSDHardwareCollector()
    assert(net_b_s_d_hardware)

# Generated at 2022-06-24 22:12:22.561457
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    try:
        net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
        test_case_0()
    except TypeError as err:
        # no setUp method
        raise err

if __name__ == "__main__":
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:12:25.018998
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:12:28.807260
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_populate_0 = NetBSDHardware()
    net_b_s_d_hardware_populate_0.populate()

# Generated at 2022-06-24 22:14:17.720232
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:14:28.184434
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_dmi_facts() == {
        'product_name': 'GA-MA785GM-US2H',
        'product_serial': 'LK10404029',
        'product_uuid': '8CD65E55-EACA-11DE-A2DA-8E44BAC10000',
        'product_version': 'NA',
        'system_vendor': 'Gigabyte Technology Co., Ltd.'
    }

test_cases = [
    test_case_0,
    test_NetBSDHardware_get_dmi_facts
]

if __name__ == '__main__':
    for t in test_cases:
        t()

# Generated at 2022-06-24 22:14:30.184596
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()



# Generated at 2022-06-24 22:14:32.285170
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.populate()

# Generated at 2022-06-24 22:14:41.238574
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    meminfo_file = """
    MemTotal: 1951704 kB
    MemFree: 329936 kB
    SwapTotal: 2097144 kB
    SwapFree: 0 kB
    """

    netbsd_hardware = NetBSDHardware()
    memory_facts = netbsd_hardware.get_memory_facts()
    if memory_facts['memtotal_mb'] != 1907 and memory_facts['memfree_mb'] != 322:
        raise Exception('Memory facts error')
    if memory_facts['swaptotal_mb'] != 2048 and memory_facts['swapfree_mb'] != 0:
        raise Exception('Swap facts error')


# Generated at 2022-06-24 22:14:52.224024
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.sysctl = {
        "machdep.dmi.system-product": "TEST-PRODUCT-NAME",
        "machdep.dmi.system-version": "TEST-PRODUCT-VERSION",
        "machdep.dmi.system-uuid": "TEST-PRODUCT-UUID",
        "machdep.dmi.system-serial": "TEST-PRODUCT-SERIAL",
        "machdep.dmi.system-vendor": "TEST-SYSTEM-VENDOR",
    }

# Generated at 2022-06-24 22:14:54.977513
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_populate_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_populate_0.populate()

# Generated at 2022-06-24 22:14:56.953302
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()



# Generated at 2022-06-24 22:14:58.901227
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:15:07.460405
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    hardware_0 = NetBSDHardware()
    hardware_0.module = Mock()
    hardware_0.sysctl = {'machdep.dmi.system-product': 'product_name',
                         'machdep.dmi.system-version': 'product_version',
                         'machdep.dmi.system-uuid': 'product_uuid',
                         'machdep.dmi.system-serial': 'product_serial',
                         'machdep.dmi.system-vendor': 'system_vendor'}

# Generated at 2022-06-24 22:17:32.164269
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # This will fail if the platform isn't NetBSD
    net_b_s_d_hardware_0 = NetBSDHardware()
    # This will fail if it takes more than 60 seconds or if it times out
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:34.434189
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:37.055105
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    assert(net_b_s_d_hardware_0.populate() != None)


# Generated at 2022-06-24 22:17:43.298671
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module.exit_json = lambda *args: args or None
    net_b_s_d_hardware_0.module.params = {
    }
    net_b_s_d_hardware_0.module.fail_json = lambda x: test_NetBSDHardware_get_memory_facts_1()

    def test_NetBSDHardware_get_memory_facts_1():
        test_dict = { 
            "ansible_facts": { 
                "memfree_mb": None, 
                "swapfree_mb": None, 
                "memtotal_mb": None, 
                "swaptotal_mb": None
            }, 
            "changed": False
        }

# Generated at 2022-06-24 22:17:46.368779
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_cpu_facts() is not False


# Generated at 2022-06-24 22:17:49.947904
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:51.945740
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:18:01.268463
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.sysctl = {'machdep.dmi.system-product':
                                 'QEMU Standard PC (i440FX + PIIX, 1996)',
                                 'machdep.dmi.system-version':
                                 'pc-i440fx-2.10', 'machdep.dmi.system-uuid':
                                 '00000000-0000-0000-0000-000000000000',
                                 'machdep.dmi.system-serial': '',
                                 'machdep.dmi.system-vendor': 'QEMU'}
    net_b_s_d_hardware.get_dmi_facts()


# Generated at 2022-06-24 22:18:03.806078
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    # Default usage.
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()

    return net_b_s_d_hardware_collector_0

# Generated at 2022-06-24 22:18:12.503413
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts = {}
    net_b_s_d_hardware_0.module.get_bin_path = lambda x: "/usr/bin/sysctl"

    # Test scenario 0
    net_b_s_d_hardware_0.populate(collected_facts)
    assert(net_b_s_d_hardware_0.data['devices']['smbuf'] == 260)
    assert(net_b_s_d_hardware_0.data['devices']['tap'] == 0)
    assert(net_b_s_d_hardware_0.data['devices']['lpt0'] == 0)