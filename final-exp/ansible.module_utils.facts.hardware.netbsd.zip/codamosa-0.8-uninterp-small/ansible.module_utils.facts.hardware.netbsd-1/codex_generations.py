

# Generated at 2022-06-24 22:09:42.278048
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:09:47.337032
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = ansible_mock
    net_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value='/bin/cat')

    assert net_b_s_d_hardware_0.get_cpu_facts() == {'processor_cores': 'NA', 'processor': ['PJ4B rev 1 (v7l) '], 'processor_count': 1}


# Generated at 2022-06-24 22:09:53.002645
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.module = "AnsibleModule"
    net_b_s_d_hardware.sysctl = {}
    net_b_s_d_hardware.sysctl['hw.physmem'] = "9223372036854775807"
    result = net_b_s_d_hardware.get_memory_facts()
    assert(result['memtotal_mb'] ==  9223372036854775807/1024/1024)


# Generated at 2022-06-24 22:10:02.481246
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hardware = NetBSDHardware()

# Generated at 2022-06-24 22:10:04.221519
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:10:06.627870
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    net_b_s_d_hardware_0 = NetBSDHardware()
    result = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:14.905651
# Unit test for method populate of class NetBSDHardware

# Generated at 2022-06-24 22:10:22.598200
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    test_dict = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-uuid': 'f0d6b661-7268-475a-8314-0906e0ce87c7',
        'machdep.dmi.system-version': '1.2-2',
        'machdep.dmi.system-vendor': 'Oracle Corporation'
    }
    net_b_s_d_hardware_0.sysctl = test_dict

# Generated at 2022-06-24 22:10:25.538999
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate(collected_facts=None)

# Generated at 2022-06-24 22:10:29.170176
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_case_0()
    net_b_s_d_hardware_0 = NetBSDHardware(module=None)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:11:14.695120
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    data = net_b_s_d_hardware_0.populate()
    assert data is not None
    assert data['dmi_info'] is not None
    assert data['dmi_info']['system_vendor'] == 'Unavailable'

# Generated at 2022-06-24 22:11:17.608955
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:11:20.635134
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_obj = NetBSDHardware()
    net_b_s_d_hardware_obj.populate()

# Generated at 2022-06-24 22:11:25.087655
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware = NetBSDHardware()
    assert (net_b_s_d_hardware.get_cpu_facts() == {'processor': ['Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz'], 'processor_count': 1, 'processor_cores': 2})


# Generated at 2022-06-24 22:11:26.285491
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    pass


# Generated at 2022-06-24 22:11:34.302944
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    # s == "physical id: 0"
    s = "physical id: 0"
    # dmi_facts == {'product_uuid': '50736d7-58aa-11e0-8629-001b21e7f2b2', 
    #               'system_vendor': 'NetBSD', 'product_serial': '', 
    #               'product_version': '', 'product_name': 'NetBSD'}
    dmi_facts = net_b_s_d_hardware_0.get_dmi_facts(s)


# Generated at 2022-06-24 22:11:43.331783
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0._module = net_b_s_d_hardware_0.module
    net_b_s_d_hardware_0._facts = net_b_s_d_hardware_0.facts
    net_b_s_d_hardware_0._module.params = {}
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:11:45.689578
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:11:53.897890
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netBSDHardware = NetBSDHardware()
    netBSDHardware.populate()
    # Asserts on memory facts
    assert 'memfree_mb' in netBSDHardware.facts
    assert 'swaptotal_mb' in netBSDHardware.facts
    assert 'memtotal_mb' in netBSDHardware.facts
    assert 'swapfree_mb' in netBSDHardware.facts
    # Asserts on CPU facts
    assert 'processor' in netBSDHardware.facts
    assert 'processor_cores' in netBSDHardware.facts
    assert 'processor_count' in netBSDHardware.facts
    # Asserts on mounts facts
    assert 'mounts' in netBSDHardware.facts
    # Asserts on dmi facts
    assert 'product_name' in netBSDHardware.facts
    assert 'product_version' in netBSDHardware.facts

# Generated at 2022-06-24 22:11:56.497292
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:12:40.991512
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    assert(NetBSDHardware.get_cpu_facts())


# Generated at 2022-06-24 22:12:44.584731
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = NetBSDHardware(None).get_cpu_facts()

    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor' in cpu_facts


# Generated at 2022-06-24 22:12:50.369609
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    var_0 = net_b_s_d_hardware_collector_0.platform

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:12:54.079157
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:12:56.050178
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    data = {'ansible_facts':{}}

    net_b_s_d_hardware_0 = NetBSDHardware(data)

    test_case_0()

# Generated at 2022-06-24 22:13:00.084150
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_1 = None
    var_0 = net_b_s_d_hardware_0.populate(var_1)


# Generated at 2022-06-24 22:13:02.737526
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_2 = NetBSDHardware()
    int_2 = 2607
    var_1 = net_b_s_d_hardware_2.get_dmi_facts(int_2)



# Generated at 2022-06-24 22:13:07.081770
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:11.366960
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    int_0 = 2607
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(int_0)


if __name__ == "__main__":
    test_case_0()
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:13:14.728626
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    var_1 = net_b_s_d_hardware_collector_0.has_new_facts()


# Generated at 2022-06-24 22:14:01.946831
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:14:07.276061
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.get_dmi_facts()
    var_1 = ()
    var_0 == var_1


# Generated at 2022-06-24 22:14:17.884457
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = 532
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    str_0 = 'netbsd.org'
    list_0 = ['machdep.dmi.system-vendor']
    dict_0 = {}
    dict_0['machdep.dmi.system-vendor'] = str_0
    dict_1 = {}
    net_b_s_d_hardware_0.sysctl = dict_1
    dict_1['machdep.dmi.system-vendor'] = str_0
    dict_2 = net_b_s_d_hardware_0.get_dmi_facts()
    map_0 = {'system_vendor': 'netbsd.org'}
    dict_3 = dict_2
   

# Generated at 2022-06-24 22:14:22.713788
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()
    os.system("pause")

# Generated at 2022-06-24 22:14:32.094887
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(8769)
    net_b_s_d_hardware_1 = NetBSDHardware(1228)
    net_b_s_d_hardware_2 = NetBSDHardware(834)
    net_b_s_d_hardware_3 = NetBSDHardware(3663)
    net_b_s_d_hardware_4 = NetBSDHardware(4970)
    net_b_s_d_hardware_5 = NetBSDHardware(80)
    net_b_s_d_hardware_6 = NetBSDHardware(9898)
    net_b_s_d_hardware_7 = NetBSDHardware(5462)
    net_b_s_d_hardware_8 = NetBSDHardware(6912)
    net

# Generated at 2022-06-24 22:14:36.830039
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:14:39.142676
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(['a', 'b', 'c'])


# Generated at 2022-06-24 22:14:41.973377
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():

    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)

    var_0 = net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:14:45.579339
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2109
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:47.582199
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    var_0 = NetBSDHardware(2607)
    var_0.populate(False)

# Generated at 2022-06-24 22:15:47.293827
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:15:50.505061
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:15:56.963918
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    int_0 = 2607
    var_0 = net_b_s_d_hardware_collector_0.fetch_all_facts(int_0)

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:16:00.014177
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.get_dmi_facts()
    assert None != var_0


# Generated at 2022-06-24 22:16:04.369410
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:16:06.991425
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:16:12.000162
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    int_1 = 2607
    net_b_s_d_hardware_1 = NetBSDHardware(int_1)
    var_0 = net_b_s_d_hardware_1.get_cpu_facts()
    var_1 = net_b_s_d_hardware_0.populate(var_0)

# Generated at 2022-06-24 22:16:21.254951
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    print('\n##### Testing NetBSDHardwareCollector(...) #####')

    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()

    net_b_s_d_hardware_collector_0.collection_type = 'NetBSDHardwareCollector'
    # Test assignment to a read-only property
    with pytest.raises(AttributeError):
        net_b_s_d_hardware_collector_0.fact_class = 'NetBSDHardware'

    # Test assignment to a read-only property
    with pytest.raises(AttributeError):
        net_b_s_d_hardware_collector_0.platform = 'NetBSD'

# Generated at 2022-06-24 22:16:27.118319
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.get_cpu_facts()
    net_b_s_d_hardware_0.get_cpu_facts()
    print("NetBSDHardware test_NetBSDHardware_get_cpu_facts returned:", var_0)


# Generated at 2022-06-24 22:16:32.164637
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    assert net_b_s_d_hardware_0.get_memory_facts() == {
        'memfree_mb': 977,
        'memtotal_mb': 2607,
        'swapfree_mb': 3891,
        'swaptotal_mb': 4095
    }



# Generated at 2022-06-24 22:17:53.974013
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Declare test values
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    dict_0 = {}

    # Call tested method
    result = net_b_s_d_hardware_0.populate(dict_0)

    # Create expected object
    dict_1 = {}
    dict_2 = {}
    dict_2['processor'] = []
    dict_2['processor_count'] = 0
    dict_2['processor_cores'] = 'NA'
    dict_1.update(dict_2)

    dict_3 = {}
    dict_3['memtotal_mb'] = 0
    dict_3['swaptotal_mb'] = 0
    dict_3['memfree_mb'] = 0

# Generated at 2022-06-24 22:17:58.228285
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    # Given the defaults
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0._platform == "NetBSD"
    assert net_b_s_d_hardware_collector_0._fact_class == NetBSDHardware


# Generated at 2022-06-24 22:18:06.939779
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    def get_mount_facts_stub():
        mounts = []
        mount_info = {
                        'mount': 'none',
                        'device': 'none',
                        'fstype': 'none',
                        'options': 'none',
                        'size_total': 0,
                        'size_available': 0,
                      }
        mounts.append(mount_info)
        return {'mounts': mounts}

    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.get_mount_facts = get_mount_facts_stub
    net_b_s_d_hardware_0.get_dmi_facts = get_mount_facts_stub
    var_0 = net_b_s

# Generated at 2022-06-24 22:18:11.532750
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    int_0 = 1004
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:18:18.610803
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_1 = {'processor_cores': 'NA', 'processor_count': 1, 'processor': ['ARMv7 Processor rev 3 (v7l)']}
    try:
        var_1 = net_b_s_d_hardware_0.get_cpu_facts()
    except TimeoutError:
        pass
    else:
        var_0 = net_b_s_d_hardware_0.populate(var_1)


# Generated at 2022-06-24 22:18:26.839810
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_1 = 2607
    net_b_s_d_hardware_1 = NetBSDHardware(int_1)

    # Test with a valid file
    sysctl_valid = {'machdep.dmi.system-vendor': 'Generic', 'machdep.dmi.system-uuid': '00000000-0000-0000-0000-000000000000', 'machdep.dmi.system-serial': 'Not Specified', 'machdep.dmi.system-version': 'Generic', 'machdep.dmi.system-product': 'Generic'}
    net_b_s_d_hardware_1.sysctl = sysctl_valid

    # Run method get_dmi_facts of class NetBSDHardware
    var_1 = net_b_s_d_hardware_1.get_dmi_facts()

# Generated at 2022-06-24 22:18:31.453219
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    random_int = randint(1, 10)
    net_b_s_d_hardware_0 = NetBSDHardware(random_int)
    net_b_s_d_hardware_1 = NetBSDHardware(random_int)
    net_b_s_d_hardware_1.populate(net_b_s_d_hardware_0)


# Generated at 2022-06-24 22:18:33.133294
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    # Compile regexes
    test_case_0()


# Generated at 2022-06-24 22:18:36.767506
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:18:39.519221
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 2607
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()
