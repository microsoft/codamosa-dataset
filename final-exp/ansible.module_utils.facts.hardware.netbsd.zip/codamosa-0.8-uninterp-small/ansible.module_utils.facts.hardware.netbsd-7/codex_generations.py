

# Generated at 2022-06-24 22:10:44.364777
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -1991
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    collected_facts_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:50.263054
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -3165
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    collected_facts = None

    # Call method populate
    # Parameters:
    #   collected_facts:
    net_b_s_d_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:11:00.052635
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    mount_facts = {}
    mount_facts['mounts'] = []
    mount_facts['mounts'].append({'mount': '/dev/sda1', 'device': '/dev/sda1', 'fstype': 'btrfs', 'options': 'rw,relatime,discard,space_cache,subvolid=5,subvol=/@/var', 'size_available': 779486596, 'size_total': 732084224, 'size_available_bytes': 82950678528, 'size_total_bytes': 77374509056})

# Generated at 2022-06-24 22:11:03.771437
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    int_0 = -1991
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:11:04.959008
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 22:11:14.100398
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -1991
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)

    net_b_s_d_hardware_1 = NetBSDHardware(int_0)
    net_b_s_d_hardware_1.sysctl = dict()
    net_b_s_d_hardware_1.sysctl['machdep.cpu_brand'] = 'QEMU Virtual CPU version 2.5+'
    net_b_s_d_hardware_1.sysctl['machdep.dmi.system-product'] = 'VirtualBox'
    net_b_s_d_hardware_1.sysctl['machdep.dmi.system-version'] = 'VirtualBox'

# Generated at 2022-06-24 22:11:23.081642
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = -1991
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0._module = object()
    net_b_s_d_hardware_0._module.get_bin_path = object()
    get_bin_path_0 = net_b_s_d_hardware_0._module.get_bin_path
    get_bin_path_0.return_value = '/bin/sh'

    # Call get_dmi_facts()
    dmi_facts_0 = net_b_s_d_hardware_0.get_dmi_facts()

    assert isinstance(dmi_facts_0, dict)
    assert 'bios_version' not in dmi_facts_0

# Generated at 2022-06-24 22:11:25.184792
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = -1979
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)


# Generated at 2022-06-24 22:11:28.597868
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -236
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)

    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:11:32.735974
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -938
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    assert isinstance(net_b_s_d_hardware_0.populate(), dict)



# Generated at 2022-06-24 22:13:20.038751
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()
    assert var_0 == None, 'return value of NetBSDHardware.populate() is None, but it should be of type dict'


# Generated at 2022-06-24 22:13:23.660914
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:27.343530
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 0
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    assert isinstance(net_b_s_d_hardware_0.populate(), dict)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 22:13:30.060360
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:13:34.186042
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    int_0 = -1989
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_0.collect(int_0)
    net_b_s_d_hardware_collector_0.collect()


# Generated at 2022-06-24 22:13:37.020419
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    try:
        int_0 = 0
        net_b_s_d_hardware_0 = NetBSDHardware(int_0)
        net_b_s_d_hardware_0.populate()
    except Exception:
        raise Exception


# Generated at 2022-06-24 22:13:44.726395
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = None
#    var_0 = {'machdep.dmi.system-product': 'VirtualBox', 'machdep.dmi.system-version': '1.2', 'machdep.dmi.system-uuid': '91BFBF39-E29C-4A1D-9A71-C4683B3A3146', 'machdep.dmi.system-serial': '0', 'machdep.dmi.system-vendor': 'innotek GmbH'}
    net_b_s_d_hardware_0.sysctl = var_0
    var_1 = net_b_s_d_hardware_0.get_

# Generated at 2022-06-24 22:13:48.883556
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -1886
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()
    assert isinstance(var_0, dict)



# Generated at 2022-06-24 22:13:58.002484
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = 0
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.populate()
    var_1 = net_b_s_d_hardware_0.get_cpu_facts()
    var_2 = net_b_s_d_hardware_0.get_memory_facts()
    var_3 = net_b_s_d_hardware_0.get_mount_facts()
    var_4 = net_b_s_d_hardware_0.get_dmi_facts()
    var_5 = net_b_s_d_hardware_0.platform
    var_6 = NetBSDHardware.platform
    var_7 = NetBSDHardware.MEMORY_FAC

# Generated at 2022-06-24 22:14:01.069426
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:15:58.453743
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    try:
        with timeout(10):
            test_case_0()
    except TimeoutError:
        print('timeout error')

# vim: expandtab

# Generated at 2022-06-24 22:16:00.793365
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    var_0 = net_b_s_d_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:16:11.278887
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    int_0 = -1813
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    int_1 = 17
    array_list_0 = list()
    str_0 = '/proc/cpuinfo'
    int_2 = 0
    int_3 = 0
    int_4 = 16
    int_5 = 16
    int_6 = 16
    int_7 = 0
    int_8 = 16
    int_9 = 0
    int_10 = 0
    int_11 = 0
    int_12 = 0
    str_1 = 'model name'
    str_2 = 'Dataplane Development Kit (DK) CPU Interface Unit'
    str_3 = 'processor'
    str_4 = '0'
    array_list_0.append(str_0)
   

# Generated at 2022-06-24 22:16:21.775918
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = -467298150
    int_1 = 200
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    dict_0 = {}
    net_b_s_d_hardware_0.sysctl = dict_0
    dict_1 = {'machdep.dmi.system-vendor': 'LENOVO',
              'machdep.dmi.system-product': '2104CTO',
              'machdep.dmi.system-version': None,
              'machdep.dmi.system-uuid': 'ABCD-1234',
              'machdep.dmi.system-serial': 'L1234567'}
    net_b_s_d_hardware_0.sysctl = dict_1
    net_b

# Generated at 2022-06-24 22:16:27.791574
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'product_name'}
    var_0 = net_b_s_d_hardware_0.get_dmi_facts()
    assert var_0 == {'product_name': 'product_name'}


# Generated at 2022-06-24 22:16:30.744345
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)

    var_0 = net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:16:34.156316
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    # Call get_dmi_facts with no argument.
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:16:38.169379
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    int_0 = -1989
    net_b_s_d_hardware_0 = NetBSDHardware(int_0)
    net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:16:40.386824
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:16:48.857228
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    var_2 = NetBSDHardware(None)
    var_3 = {'memfree_mb': 784, 'memtotal_mb': 956, 'swapfree_mb': 82, 'swaptotal_mb': 82, 'processor': ['Intel(R) Core(TM) i7-7700 CPU @ 3.60GHz'], 'processor_cores': 8, 'processor_count': 1, 'product_name': 'iMac18,3', 'product_serial': 'C02N8DY0FVH1', 'product_uuid': '19B9F9E9-D3AF-11E7-839E-1B67A4BFB137', 'product_version': '1.0', 'system_vendor': 'Apple Inc.'}
    f_1 = (var_2.populate(), var_3)