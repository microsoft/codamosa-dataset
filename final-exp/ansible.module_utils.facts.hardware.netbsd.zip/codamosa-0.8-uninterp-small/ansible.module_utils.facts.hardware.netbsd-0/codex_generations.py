

# Generated at 2022-06-24 22:09:57.923228
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    netbsd_hardware_0 = NetBSDHardware(None)
    netbsd_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:10:00.687971
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    dmi_facts_0 = NetBSDHardware().get_dmi_facts()


# Generated at 2022-06-24 22:10:07.737251
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    complex_0 = None
    str_0 = 'dm-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(complex_0, str_0)
    net_b_s_d_hardware_0 = NetBSDHardware(complex_0, str_0)
    collected_facts_0 = {'D': 'D'}
    # A call to populate() is made
    # There is no return value.
    net_b_s_d_hardware_0.populate(collected_facts_0)

# Generated at 2022-06-24 22:10:11.257669
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware({}, test_case_0)
    str_0 = None
#    assert isinstance(net_b_s_d_hardware_0.get_cpu_facts(), dict)


# Generated at 2022-06-24 22:10:15.061452
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    complex_0 = None
    str_0 = 'dm-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(complex_0, str_0)


# Generated at 2022-06-24 22:10:17.341563
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    complex_0 = None
    str_0 = 'dm-'
    NetBSDHardwareCollector(complex_0, str_0)


# Generated at 2022-06-24 22:10:21.872344
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    complex_0 = None
    str_0 = 'dm-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(complex_0, str_0)
    net_b_s_d_hardware_0 = NetBSDHardware({})
    result = net_b_s_d_hardware_0.get_dmi_facts()
    assert (result == {})


# Generated at 2022-06-24 22:10:32.238048
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    complex_0 = None
    str_0 = 'dm-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(complex_0, str_0)
    collected_facts_0 = {'MemFree': 'MemFree_0', 'SwapTotal': 'SwapTotal_0', 'MemTotal': 'MemTotal_0', 'SwapFree': 'SwapFree_0'}
    __args__ = {'module': 'module_0', 'collect_default': 'collect_default_0', 'collected_facts': 'collected_facts_0'}
    __kwargs__ = {'gather_subset': 'gather_subset_0', 'filter': 'filter_0'}

# Generated at 2022-06-24 22:10:35.097036
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    complex_1 = None
    str_1 = 'dm-'
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector(complex_1, str_1)


# Generated at 2022-06-24 22:10:40.563507
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    complex_0 = None
    str_0 = 'dm-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(complex_0, str_0)
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0, complex_0, str_0)
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:11:45.689243
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert(len(net_b_s_d_hardware_0.get_cpu_facts()) > 0)


# Generated at 2022-06-24 22:11:50.537629
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MagicMock(return_value='a')
    net_b_s_d_hardware_0.module.run_command = MagicMock(return_value='1')
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:11:58.848827
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    var_1 = net_b_s_d_hardware_0.get_cpu_facts()
    assert var_1 == {'processor': ['Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz', 'Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz', 'Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz', 'Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz'], 'processor_cores': 4, 'processor_count': 1}


# Generated at 2022-06-24 22:12:03.495676
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(str_0, str_0)
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.collect()

# Generated at 2022-06-24 22:12:07.456562
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    arg_0 = get_net_b_s_d_hardware()
    test_0 = arg_0.get_dmi_facts()
    assert test_0 != 'A'


# Generated at 2022-06-24 22:12:18.186923
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    current_dir = os.getcwd()
    file_path = os.path.join(current_dir, 'unit_tests/ansible_module_self_test_data/test_NetBSDHardware_populate_data.txt')
    fd = open(file_path, 'r')
    content = fd.read()
    fd.close()
    re_0 = re.compile(r'\w+')
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector('Test_case', 'Test_case')
    net_b_s_d_hardware_collector_0.module = object()
    net_b_s_d_hardware_collector_0.module.run_command = run_command
    net_b_s_d_hardware_collect

# Generated at 2022-06-24 22:12:21.035152
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    str_0 = '-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(str_0, str_0)



# Generated at 2022-06-24 22:12:24.450589
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0 = NetBSDHardwareCollector('arg_0', 'arg_1')
    hardware_1 = NetBSDHardware._populate(hardware_0, 'arg_0', 'arg_1', net_b_s_d_hardware_0)


# Generated at 2022-06-24 22:12:26.267413
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    test_case_0(str_0)


# Generated at 2022-06-24 22:12:33.272714
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    str_0 = '-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(str_0, str_0)
    net_b_s_d_hardware_0 = NetBSDHardware(str_0, str_0)
    net_b_s_d_hardware_0.populate()
    dict_0 = net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:13:32.536679
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    fact_module = {'module': 'test'}
    net_b_s_d_hardware_0 = NetBSDHardware(fact_module, {})
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:39.528666
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(None, None)
    str_0 = '-'
    # NetBSDHardware.get_dmi_facts(str_0)
    # test_NetBSDHardware_get_dmi_facts() defined to fail
    assert False


# Generated at 2022-06-24 22:13:45.907552
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = '-'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(str_0, str_0)

    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.collect()


if __name__ == '__main__':
    print("Testcase 0: " + str(test_case_0()))
    print("Testcase 1: " + str(test_NetBSDHardware_populate()))

# Generated at 2022-06-24 22:13:48.847872
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(str_0, str_0)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:13:57.979422
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(str_0, str_0, str_0)
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(str_0, str_0)
    net_b_s_d_hardware_0.module = net_b_s_d_hardware_collector_0

# Generated at 2022-06-24 22:13:58.921940
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    pass


# Generated at 2022-06-24 22:14:09.825866
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Test case with no sysctl
    net_b_s_d_hardware_0 = NetBSDHardware({'vars': {}}, False)
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}

    # Test case with sysctl

# Generated at 2022-06-24 22:14:10.774130
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 22:14:15.048031
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = 'Linux'
    str_1 = '-'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0, str_1)
    
    net_b_s_d_hardware_0.populate(str_1)


# Generated at 2022-06-24 22:14:19.827551
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = NetBSDHardwareCollector._platform
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(str_0, str_0)
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0._fact_class

    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:15:33.309509
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    var_0 = net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:15:36.446183
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)

    # Verify that populate raises a TimeoutError
    with pytest.raises(TimeoutError):
        net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:15:41.410864
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    tuple_0 = ()
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(tuple_0)
    assert net_b_s_d_hardware_collector_0 is not None, 'Could not create NetBSDHardwareCollector'


# Generated at 2022-06-24 22:15:44.434347
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:15:47.567791
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    var_0 = net_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:15:50.998255
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    var_0 = net_b_s_d_hardware_0.populate()
    assert var_0 == None


# Generated at 2022-06-24 22:15:57.186111
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    net_b_s_d_hardware_0.populate()

if __name__ == "__main__":
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:15:59.908714
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    var_0 = net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:16:04.066103
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:16:09.263731
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    net_b_s_d_hardware_0.module = None
    net_b_s_d_hardware_0.sysctl = None
    var_0 = net_b_s_d_hardware_0.populate()
    return var_0


# Generated at 2022-06-24 22:17:36.525325
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:39.100541
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    assert net_b_s_d_hardware_0.get_memory_facts() is None


# Generated at 2022-06-24 22:17:45.610048
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    """
        Unit test for constructor of class NetBSDHardwareCollector
    """
    # Create an object of the NetBSDHardwareCollector
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()

    # Call the member function get_facts of class NetBSDHardwareCollector
    var_0 = net_b_s_d_hardware_collector_0.get_facts()

# Generated at 2022-06-24 22:17:50.727085
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    net_b_s_d_hardware_0.get_cpu_facts()
    tuple_1 = ()
    net_b_s_d_hardware_1 = NetBSDHardware(tuple_1)

    test_case_0()


# Generated at 2022-06-24 22:17:55.203032
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    tuple_0 = ()
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(tuple_0)
    assert net_b_s_d_hardware_collector_0


# Generated at 2022-06-24 22:17:58.261688
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    tuple_0 = ()
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(tuple_0)
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.collect()


# Generated at 2022-06-24 22:18:01.758873
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)
    var_0 = net_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:18:06.864123
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():

    # Set up test environment (in this case a dictionary)
    tuple_0 = ()
    net_b_s_d_hardware_0 = NetBSDHardware(tuple_0)

    # Call method get_dmi_facts of net_b_s_d_hardware_0
    # There should be no exception
    try:
        net_b_s_d_hardware_0.get_dmi_facts()
    except:
        assert False, "Unexpected exception."


# Generated at 2022-06-24 22:18:15.333806
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    tuple_1 = ()
    net_b_s_d_hardware_1 = NetBSDHardware(tuple_1)
    tuple_2 = ()
    net_b_s_d_hardware_2 = NetBSDHardware(tuple_2)
    tuple_3 = ()
    net_b_s_d_hardware_3 = NetBSDHardware(tuple_3)
    tuple_4 = ()
    net_b_s_d_hardware_4 = NetBSDHardware(tuple_4)
    var_1 = net_b_s_d_hardware_1.populate(tuple_2)
    var_2 = net_b_s_d_hardware_2.populate(tuple_3)

# Generated at 2022-06-24 22:18:19.352771
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    tuple_0 = ()
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(tuple_0)
    return var_0

if __name__ == "__main__":
    test_case_0()
    test_NetBSDHardwareCollector()