

# Generated at 2022-06-24 22:10:30.671280
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    netbsd_hw = NetBSDHardware()
    cpu_facts = netbsd_hw.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5 CPU       M 430  @ 2.27GHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-24 22:10:40.085579
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():

    net_b_s_d_hardware_0 = NetBSDHardware()
    get_file_content_mock = mocker.patch('ansible_collections.ansible.community.plugins.module_utils.facts.hardware.netbsd.NetBSDHardware.get_file_content')
    get_file_content_mock.return_value = '''<html>
<body>
<h1>Hello World</h1>
<p>This is a paragraph.</p>
</body>
</html>'''

    get_file_lines_mock = mocker.patch('ansible_collections.ansible.community.plugins.module_utils.facts.hardware.netbsd.NetBSDHardware.get_file_lines')

# Generated at 2022-06-24 22:10:44.314249
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    hardware_facts = net_b_s_d_hardware_0.populate()
    assert hardware_facts['devices'] == {}


# Generated at 2022-06-24 22:10:53.711427
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    print('Test of method populate of class NetBSDHardware')
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()
    print('Type of net_b_s_d_hardware_0[\'devices\']: ' + str(type(net_b_s_d_hardware_0['devices'])))
    print('Type of net_b_s_d_hardware_0[\'devices\'][\'cpu\']: ' + str(type(net_b_s_d_hardware_0['devices']['cpu'])))

# Generated at 2022-06-24 22:10:56.218333
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:11:05.426043
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector()
    get_sysctl_1 = get_sysctl(self.module, ['machdep'])
    cpu_facts_1 = net_b_s_d_hardware_collector_1.get_cpu_facts()
    memory_facts_1 = net_b_s_d_hardware_collector_1.get_memory_facts()
    mount_facts_1 = {}
    net_b_s_d_hardware_collector_1.get_mount_facts()
    dmi_facts_1 = net_b_s_d_hardware_collector_1.get_dmi_facts()
    net_b_s_d_hardware_collector_1.populate()

    assert(True)

# Generated at 2022-06-24 22:11:14.578790
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    # From /proc/meminfo
    # MemTotal:        7938652 kB
    # MemFree:           61420 kB
    # SwapTotal:       8027228 kB
    # SwapFree:        7936160 kB
    #
    # 7938652/1024.0 = 7.7022705078125
    # 61420/1024.0 = 0.597076416015625
    # 8027228/1024.0 = 7.82586669921875
    # 7936160/1024.0 = 7.733795166015625

# Generated at 2022-06-24 22:11:23.473969
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=None)
    ansible_module_set_module_args_mock = (
        {
            'filter': '',
            'gather_subset': '!all',
            'gather_timeout': 10,
            '_ansible_check_mode': False,
            '_ansible_debug': False,
            '_ansible_diff': False,
            '_ansible_version': 2,
            '_ansible_module_name': 'setup',
            '_ansible_module_sourcedir': '/Users/gautier'
        }
    )


# Generated at 2022-06-24 22:11:26.368462
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    # Return a dictionary containing memory facts.
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert isinstance(net_b_s_d_hardware_0.get_memory_facts(), dict)


# Generated at 2022-06-24 22:11:29.141679
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:00.083442
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:03.090259
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware._module = None
    net_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:13:07.080643
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert isinstance(net_b_s_d_hardware_0.get_dmi_facts(), dict)


# Generated at 2022-06-24 22:13:09.856950
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:17.939937
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MagicMock()
    net_b_s_d_hardware_0.module.get_bin_path.return_value = 'dmidecode'
    net_b_s_d_hardware_0.module.run_command.return_value = ('Manufacturer: (Standard system devices)', '', 0)
    net_b_s_d_hardware_0.module.run_command.return_value = ('Serial Number: Not Specified', '', 0)
    net_b_s_d_hardware_0.module.run_command.return_value = ('Product Name: VirtualBox', '', 0)
    net_b_s_d_hardware_0.module

# Generated at 2022-06-24 22:13:21.678244
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()

    NetBSDHardware.populate(net_b_s_d_hardware_collector_0)


# Generated at 2022-06-24 22:13:25.864093
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MagicMock(return_value=None)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:34.586753
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    job_timeout_string = 'No timeout specified in configuration. Defaulting to 5m'
    job_timeout_number = 300
    get_mount_size_kernel_name = 'NetBSD'
    populate_iter_4 = {'mount': '/', 'device': '/dev/wd0a', 'used_pct': '90%',
                       'options': 'rw', 'fstype': 'ffs', 'size_total': '9.9G',
                       'size_available': '976.3M', 'size_used': '8.8G'}

# Generated at 2022-06-24 22:13:37.553868
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hardware_0 = NetBSDHardware({})
    netbsd_hardware_0.populate(collected_facts=['processor'])


# Generated at 2022-06-24 22:13:40.470075
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:16:56.492220
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_bsd_hardware = NetBSDHardware()
    net_bsd_hardware.get_cpu_facts()



# Generated at 2022-06-24 22:16:58.157140
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(None)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:01.614018
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_obj_0 = NetBSDHardware()
    net_b_s_d_hardware_obj_0.populate()

if __name__ == '__main__':
    for test_func in [test_case_0, test_NetBSDHardware_populate]:
        print("Running unit test: %s" % test_func.__name__)
        test_func()

# Generated at 2022-06-24 22:17:06.640057
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:17:16.603359
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    """ Test populate method of class NetBSDHardware """
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts_0 = {'kernel': 'Linux', 'hostname': 'foo', 'lsb': {'distribution': 'Ubuntu', 'distribution_major_version': '14', 'distribution_release': 'trusty', 'distribution_version': '14.04', 'major_release': 'Ubuntu', 'majrelease': '14', 'minrelease': '04'}, 'architecture': 'x86_64', 'ipv4': {'address': '10.0.2.15', 'netmask': '255.255.255.0', 'network': '10.0.2.0'}}

# Generated at 2022-06-24 22:17:19.323802
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
   net_b_s_d_hardware_0 = NetBSDHardware()
   net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:24.248648
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    ansible_facts = dict()
    ansible_facts['hardware'] = dict()
    ansible_facts['ansible_python_version'] = '2.6.1'

    net_b_s_d_hardware_0.populate(ansible_facts)

# Generated at 2022-06-24 22:17:26.871011
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    print("Testing method populate in class NetBSDHardware")
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:17:31.913960
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=None)
    net_b_s_d_hardware_0.populate()

test_case_0()

# Generated at 2022-06-24 22:17:34.278496
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()
