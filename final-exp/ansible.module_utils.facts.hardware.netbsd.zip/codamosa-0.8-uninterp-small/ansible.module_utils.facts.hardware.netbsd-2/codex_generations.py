

# Generated at 2022-06-24 22:10:35.347506
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    bytes_0 = b'\x7f\x8d\x8e'
    net_b_s_d_hardware_0 = NetBSDHardware(bytes_0)
    collected_facts = get_file_content('/dev/null')
    key, value = net_b_s_d_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:10:42.372311
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    bytes_0 = b'\x7f\x8d\x8e'
    net_b_s_d_hardware_0 = NetBSDHardware(bytes_0)
    memory_facts = net_b_s_d_hardware_0.get_memory_facts()
    assert isinstance(memory_facts, dict)
    assert len(memory_facts) == 4
    assert memory_facts['memfree_mb'] == memory_facts['memfree_mb']
    assert memory_facts['memtotal_mb'] == memory_facts['memtotal_mb']
    assert memory_facts['swapfree_mb'] == memory_facts['swapfree_mb']
    assert memory_facts['swaptotal_mb'] == memory_facts['swaptotal_mb']


# Generated at 2022-06-24 22:10:46.555929
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    print(NetBSDHardware.populate())
    print(NetBSDHardware.populate())
    print(NetBSDHardware.populate())
    print(NetBSDHardware.populate())
    print(NetBSDHardware.populate())
    print(NetBSDHardware.populate())
    print(NetBSDHardware.populate())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:10:54.377830
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    bytes_0 = b'\x7f\x8d\x8e'
    net_b_s_d_hardware_0 = NetBSDHardware(bytes_0)
    collected_facts_0 = get_mount_facts()
    collected_facts_1 = {'mounts': ['mounts']}
    net_b_s_d_hardware_0.populate(collected_facts_0)
    net_b_s_d_hardware_0.populate(collected_facts_1)
    net_b_s_d_hardware_1 = NetBSDHardware(net_b_s_d_hardware_0)
    assert(net_b_s_d_hardware_1.get_cpu_facts() == None)

# Generated at 2022-06-24 22:10:58.460080
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    bytes_0 = b'\x7f\x8d\x8e'
    net_b_s_d_hardware_0 = NetBSDHardware(bytes_0)

    # Call method
    net_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:11:02.121050
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    # Constructor test case - is an object of the class NetBSDHardwareCollector
    assert isinstance(net_b_s_d_hardware_collector_0, NetBSDHardwareCollector)


# Generated at 2022-06-24 22:11:06.348213
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    set_module_args({'sysctl': {'machdep': {'dmi': {'system-product': 'A product name',
                                                   'system-version': 'A product version',
                                                   'system-uuid': 'A product uuid',
                                                   'system-serial': 'A product serial',
                                                   'system-vendor': 'A vendor name'}}}})
    net_b_s_d_hardware_0 = NetBSDHardware(module=ansible_module)

# Generated at 2022-06-24 22:11:09.842333
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    bytes_0 = b'\x7f\x8d\x8e'
    net_b_s_d_hardware_0 = NetBSDHardware(bytes_0)

    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:11:16.877061
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    bytes_0 = b'\x7f\x8d\x8e'
    net_b_s_d_hardware_0 = NetBSDHardware(bytes_0)
    ansible_facts_0 = net_b_s_d_hardware_0.populate()
    assert ansible_facts_0 == {"processor_cores": "NA", "processor_count": 6, "swaptotal_mb": 4294967295, "memfree_mb": 4294967295, "mounts": [], "memtotal_mb": 4294967295, "processor": [], "swapfree_mb": 4294967295}, "ansible_facts_0 == b'\\x7f\\x8d\\x8e' failed"


# Generated at 2022-06-24 22:11:26.610690
# Unit test for method populate of class NetBSDHardware

# Generated at 2022-06-24 22:13:09.000784
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts = {}
    # collected_facts = dict(ansible_facts=dict())
    net_b_s_d_hardware_0.populate(collected_facts=collected_facts)


# Generated at 2022-06-24 22:13:13.795213
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts_0 = {}
    return_value_1 = net_b_s_d_hardware_0.populate(collected_facts_0)
    assert return_value_1 is not None


# Generated at 2022-06-24 22:13:17.332431
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(module=None)
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:13:24.375788
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    cpu_facts = {}
    cpu_facts['processor'] = ['Intel(R) Atom(TM) CPU  C2550  @ 2.40GHz']
    cpu_facts['processor_cores'] = 'NA'
    cpu_facts['processor_count'] = 1
    assert net_b_s_d_hardware_0.get_cpu_facts() == cpu_facts


# Generated at 2022-06-24 22:13:33.063893
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_bsd_hardware_0 = NetBSDHardware(set(), 'system_vendor', 'product_version', 'product_serial', 'product_name', 'product_uuid')
    net_bsd_hardware_0.sysctl = {'machdep.dmi.system-vendor': 'system_vendor_0', 'machdep.dmi.system-version': 'product_version_0', 'machdep.dmi.system-uuid': 'product_uuid_0', 'machdep.dmi.system-serial': 'product_serial_0', 'machdep.dmi.system-product': 'product_name_0'}
    net_b_s_d_hardware_0_result = net_bsd_hardware_0.get_dmi_facts()
    assert net_

# Generated at 2022-06-24 22:13:37.951854
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    facts_dict = dict()
    net_b_s_d_hardware_0 = NetBSDHardware(facts=facts_dict, module=None)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:13:42.795033
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    # executed for get_cpu_facts because NetBSDHardware is no more a subclass of Hardware
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.sysctl = {'machdep.cpu_id': '0xf6a'}
    net_b_s_d_hardware_0.collector = {'platform': 'NetBSD', 'sysctl.mib': {'machdep.cpu_id': '0xf6a'}}
    net_b_s_d_hardware_0.facts = {'processor': []}

# Generated at 2022-06-24 22:13:45.829668
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.sysctl = {}
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:13:49.037625
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:13:52.165953
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:15:46.285134
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0 = net_b_s_d_hardware_0.populate()
    net_b_s_d_hardware_0.module = None
    net_b_s_d_hardware_0.get_dmi_f

# Generated at 2022-06-24 22:15:49.096518
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_1 = NetBSDHardware()
    net_b_s_d_hardware_1.populate()



# Generated at 2022-06-24 22:15:51.495500
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:15:56.128345
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    
    ret = net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:16:00.620189
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware = NetBSDHardware()
    mem_facts = net_b_s_d_hardware.get_memory_facts()
    assert mem_facts["memtotal_mb"] >= mem_facts["swaptotal_mb"]
    assert mem_facts["swaptotal_mb"] >= mem_facts["swapfree_mb"]
    assert mem_facts["swaptotal_mb"] >= mem_facts["swapfree_mb"]

# Generated at 2022-06-24 22:16:07.034422
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = NetBSDHardware().get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert isinstance(cpu_facts['processor_count'], int)
    assert cpu_facts['processor_cores'] >= cpu_facts['processor_count']


if __name__ == "__main__":
    test_NetBSDHardware_get_cpu_facts()

# Generated at 2022-06-24 22:16:09.375257
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:16:20.499128
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MagicMock()


# Generated at 2022-06-24 22:16:23.533955
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:16:30.287121
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    # test populate
    net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    test_cases = [test_NetBSDHardware_populate]

    for test_case in test_cases:
        test_case()
    from ansible.module_utils.facts.netbsd.hardware import *
    netbsd_hardware_collector = NetBSDHardwareCollector()
    collected_facts = netbsd_hardware_collector.collect()

    print(collected_facts)