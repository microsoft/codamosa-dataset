

# Generated at 2022-06-24 22:10:14.768092
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_0.populate()


# Generated at 2022-06-24 22:10:17.974428
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    try:
        net_b_s_d_hardware_0.populate()
    except TimeoutError:
        pass


# Generated at 2022-06-24 22:10:20.074506
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:10:25.684024
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    # We need to use super() here to ensure that base class __init__ is called.
    # This is required because we only use the NetBSDHardwareCollector
    # constructor as a convenience (it sets the class/platform correctly).
    # If we don't call the base class constructor, platform will not be set and
    # the NetBSDHardware subclass will not be used.
    # See https://github.com/ansible/ansible/issues/33788
    # See https://github.com/ansible/ansible/pull/33790
    net_b_s_d_hardware_collector = super(NetBSDHardwareCollector, NetBSDHardwareCollector()).__init__()


# Generated at 2022-06-24 22:10:33.680075
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'product', 'machdep.dmi.system-version': 'version', 'machdep.dmi.system-uuid': 'uuid', 'machdep.dmi.system-serial': 'serial', 'machdep.dmi.system-vendor': 'vendor'}

    # Call method
    data = net_b_s_d_hardware_0.get_dmi_facts()
    assert data["product_name"] == "product"

    assert data["product_version"] == "version"

    assert data["product_uuid"] == "uuid"


# Generated at 2022-06-24 22:10:39.392176
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0._platform == 'NetBSD'
    assert not net_b_s_d_hardware_collector_0._fact_class == os.path

# Generated at 2022-06-24 22:10:43.143483
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:10:44.187127
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    pass


# Generated at 2022-06-24 22:10:49.255333
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Initialize test case
    net_b_s_d_hardware_0 = NetBSDHardware(None, "Example module")

    # Call actual function
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:10:50.833348
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware = NetBSDHardware('module')


# Generated at 2022-06-24 22:12:14.290597
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:12:21.992868
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    assert 'test_net_b_s_d_hardware_0' in globals(), "Function test_net_b_s_d_hardware_0 is not defined"
    float_0 = 0.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.get_memory_facts()
    assert var_0 is not None, "Return value from get_memory_facts is None"


# Generated at 2022-06-24 22:12:30.819909
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()
    assert var_0 == {'processor': ['ARMv7 Processor rev 1 (v7l)'], 'swaptotal_mb': 1, 'processor_count': 1, 'processor_cores': 3, 'memtotal_mb': 842, 'memfree_mb': 841, 'swapfree_mb': 1}



# Generated at 2022-06-24 22:12:34.752296
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    float_0 = 2447.0
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(float_0)


# Generated at 2022-06-24 22:12:41.356961
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Test for getting system facts for NetBSD.
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    sysctl_list_0 = ['machdep']
    var_0 = net_b_s_d_hardware_0.get_sysctl(sysctl_list_0)
    net_b_s_d_hardware_0.sysctl = var_0
    var_1 = net_b_s_d_hardware_0.populate()
    assert var_1['processor_count'] == 4
    assert var_1['processor_count'] == 4
    assert var_1['processor_cores'] == 2

# Generated at 2022-06-24 22:12:44.793649
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()
    var_1 = Outcomes(result=0, msg='successfully gathered NetBSD hardware facts', ansible_facts=var_0)
    return var_1



# Generated at 2022-06-24 22:12:53.802741
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = {'processor_count': 1, 'processor_cores': 'NA', 'processor': ['ARMv7 Processor rev 4 (v7l)']}
    var_1 = net_b_s_d_hardware_0.populate()
    var_2 = var_1.pop('devices')
    var_3 = var_1.pop('mounts')
    var_4 = assertDictEquals(var_1, var_0)

# Generated at 2022-06-24 22:12:56.577989
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    try:
        net_b_s_d_hardware_0.populate()
    except TimeoutError:
        pass


# Generated at 2022-06-24 22:13:00.456700
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_1 = NetBSDHardware(2447.0)
    net_b_s_d_hardware_1.populate()
    var_1 = net_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:13:04.552117
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    net_b_s_d_hardware_0.sysctl = {}
    var_0 = net_b_s_d_hardware_0.get_dmi_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:14:13.690454
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:14:14.659600
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:14:23.073777
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    float_0 = 761.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    str_0 = 'machdep.dmi.system-serial'
    str_1 = 'product_serial'
    net_b_s_d_hardware_0.sysctl.update({str_0: str_1})
    str_0 = 'machdep.dmi.system-vendor'
    str_1 = 'system_vendor'
    net_b_s_d_hardware_0.sysctl.update({str_0: str_1})
    str_0 = 'machdep.dmi.system-product'
    str_1 = 'product_name'

# Generated at 2022-06-24 22:14:26.258746
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()

test_case_0()

# Generated at 2022-06-24 22:14:30.809265
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 5969.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()

    assert var_0 is None

# Unit test case for function populate of class NetBSDHardware

# Generated at 2022-06-24 22:14:34.561348
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_case_0()
    test_case_0()

# Generated at 2022-06-24 22:14:38.967361
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:14:45.100972
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    print('Testing populate of NetBSDHardware')
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()
    print('may_need_to_update_mount_facts = ' + str(var_0))


# Generated at 2022-06-24 22:14:49.084877
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    print("Testing populate of class NetBSDHardware")
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:14:57.806115
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    mem_info = """MemTotal:    1007840 kB
SwapTotal:   1998844 kB
MemFree:       16076 kB
SwapFree:      96344 kB
""".split('\n')

    net_b_s_d_hardware_0 = NetBSDHardware(0)
    var_0 = net_b_s_d_hardware_0.get_memory_facts(mem_info)

    expected_dict = {'swaptotal_mb': 1950, 'memtotal_mb': 981, 'swapfree_mb': 93, 'memfree_mb': 15}
    assert var_0 == expected_dict



# Generated at 2022-06-24 22:17:54.891360
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2347.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:18:03.413132
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    cpu_facts = {}
    i = 0
    physid = 0
    sockets = {}

    cpu_facts['processor'] = []
    cpu_facts['processor'].append('Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz')
    i += 1
    sockets[0] = 4

    cpu_facts['processor_count'] = len(sockets)
    cpu_facts['processor_cores'] = reduce(lambda x, y: x + y, sockets.values())

    memory_facts = {}
    MEMORY_FACTS = ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']

    for line in get_file_lines("/proc/meminfo"):
        data = line.split(":", 1)
        key = data[0]

# Generated at 2022-06-24 22:18:08.335816
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Test case where sysctl return a value
    # We need to test with real sysctl data as the test would
    # fail with a TimeoutError

    fake_sysctl = {}
    net_b_s_d_hardware_0 = NetBSDHardware(2447.0, sysctl=fake_sysctl)
    net_b_s_d_hardware_0.get_dmi_facts()
    # Test case where sysctl raise a SubprocessError


# Generated at 2022-06-24 22:18:11.737654
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:18:14.111353
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:18:16.391185
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 3968.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:18:18.581652
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    float_0 = 2447.0
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(float_0)


# Generated at 2022-06-24 22:18:22.400342
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    float_0 = 2447.0
    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    var_0 = net_b_s_d_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:18:24.511449
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    pop_0 = NetBSDHardware.populate(test_NetBSDHardware_populate)
    assert pop_0 is not None


# Generated at 2022-06-24 22:18:33.293164
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    float_0 = 2447.0

    net_b_s_d_hardware_0 = NetBSDHardware(float_0)
    net_b_s_d_hardware_0.module.params = {}
    net_b_s_d_hardware_0.module.exit_json = lambda x: x
    net_b_s_d_hardware_0.module.fail_json = lambda x: x
