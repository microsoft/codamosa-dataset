

# Generated at 2022-06-24 22:10:06.979518
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:09.154191
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:10:11.537444
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:21.427045
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    _net_b_s_d_hardware_0 = NetBSDHardware()
    _net_b_s_d_hardware_0.module = None
    _net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'System Product Name', 'machdep.dmi.system-serial': 'System Serial Number', 'machdep.dmi.system-uuid': 'System UUID', 'machdep.dmi.system-vendor': 'System Vendor', 'machdep.dmi.system-version': 'System Version'}

# Generated at 2022-06-24 22:10:23.217287
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware("module")
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:10:28.738917
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    # Test against a known input and output
    net_b_s_d_hardware_0 = NetBSDHardware()
    output_0 = net_b_s_d_hardware_0.get_memory_facts()
    assert output_0['memtotal_mb'] == 32768
    assert output_0['memfree_mb'] == 5758


# Generated at 2022-06-24 22:10:30.466033
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():

    hw_collector_0 = NetBSDHardwareCollector()

# Testing get_cpu_facts()

# Generated at 2022-06-24 22:10:39.990814
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    from units.compat import unittest
    from units.compat.mock import patch, call, MagicMock

    required_params = {'cpuinfo_cpu_cores': '2',
                       'cpuinfo_cpu_mhz': '4040.322',
                       'cpuinfo_cpu_physical_id': '0',
                       'cpuinfo_cpu_vendor_id': 'GenuineIntel',
                       'cpuinfo_model_name': 'Intel(R) Xeon(R) CPU           X5460  @ 3.16GHz',
                       'cpuinfo_processor': '0',
                       'cpuinfo_processor_cores': '2',
                       'cpuinfo_processor_count': '1'}

    class NetBSDHardware(object):
        pass


# Generated at 2022-06-24 22:10:43.409939
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    assert net_b_s_d_hardware_0.populate() is None


# Generated at 2022-06-24 22:10:48.127454
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:11:53.414191
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:11:56.540397
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:12:00.655047
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MagicMock()

    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:09.872757
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.module = MagicMock()
    net_b_s_d_hardware.get_sysctl = MagicMock(return_value = {'machdep.dmi.system-product': 'product_name', 'machdep.dmi.system-version': 'product_version', 'machdep.dmi.system-uuid': 'product_uuid', 'machdep.dmi.system-serial': 'product_serial', 'machdep.dmi.system-vendor': 'system_vendor'})

# Generated at 2022-06-24 22:12:20.019501
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    net_b_s_d_hardware_0 = NetBSDHardware()

    collected_facts = {'ansible_processor': ['Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz'], 'ansible_processor_cores': 1, 'ansible_processor_count': 4, 'ansible_system_vendor': 'LENOVO', 'ansible_product_uuid': 'CBF2BAA5-62E8-11CB-ABD2-926C0029F8B8', 'ansible_product_version': 'ThinkCentre M82', 'ansible_product_serial': 'L0ZZ666', 'ansible_product_name': '2771CYG'}
    # Using collected_facts to pass values
    net_b_s_d_hardware_0.populate

# Generated at 2022-06-24 22:12:23.307900
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware_get_memory_facts_0 = net_b_s_d_hardware.get_memory_facts()



# Generated at 2022-06-24 22:12:29.237572
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    facts = net_b_s_d_hardware_0.populate()
    print(facts)

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:12:32.173918
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_1 = NetBSDHardware()
    # Try to collect system facts
    result = net_b_s_d_hardware_1.populate(collected_facts={})
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:12:35.444666
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netBSDHardware = NetBSDHardware()
    assert netBSDHardware.get_dmi_facts() == {u'system_vendor': u''}


# Generated at 2022-06-24 22:12:37.983949
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    __result_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:13:42.457423
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0 != None


# Generated at 2022-06-24 22:13:51.129869
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.sysctl = {'machdep.dmi.system-product': 'MacBookPro8,1', 'machdep.dmi.system-version': '1.0', 'machdep.dmi.system-uuid': '79B5C862-C5E5-5B48-AC0A-95B7A27B053A', 'machdep.dmi.system-serial': 'C02G715JFFH2', 'machdep.dmi.system-vendor': 'Apple Inc.'}
    retval = net_b_s_d_hardware.get_dmi_facts()

# Generated at 2022-06-24 22:13:53.125606
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:14:02.358656
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts = dict()

# Generated at 2022-06-24 22:14:10.681824
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(None)
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'NetBSD', 'machdep.dmi.system-serial': '123', 'machdep.dmi.system-vendor': 'http://www.NetBSD.org/', 'machdep.dmi.system-version': '7.0.2_PATCH', 'machdep.dmi.system-uuid': '8CACB3F4-45A3-11E9-8E67-3A3EAFD040F7'}

# Generated at 2022-06-24 22:14:13.067868
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware({})
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:23.119032
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts = {}

# Generated at 2022-06-24 22:14:25.136019
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.get_memory_facts()

# Generated at 2022-06-24 22:14:35.420213
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector.collect()

# Generated at 2022-06-24 22:14:38.971377
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_populate_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:16.281623
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    # Default / empty constructor
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:17:18.416293
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:17:20.901721
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(file_exists_mock)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:28.889516
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware({}, {}, {})
    net_b_s_d_hardware_0.module.get_bin_path = lambda x, opt_flags: ""
    net_b_s_d_hardware_0.module.run_command = lambda x, use_unsafe_shell: ("", "", 0)
    net_b_s_d_hardware_0.get_sysctl = get_sysctl
    net_b_s_d_hardware_0.sysctl = {}
    res = net_b_s_d_hardware_0.get_dmi_facts()
    assert res == {}

# Generated at 2022-06-24 22:17:32.513989
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():

    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_get_memory_facts()



# Generated at 2022-06-24 22:17:40.072821
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts_0 = {}
    returned_value_0 = net_b_s_d_hardware_0.populate(collected_facts_0)
    assert returned_value_0['memory_mb']['swaptotal_mb'] == 0
    assert returned_value_0['memory_mb']['memtotal_mb'] == 0
    assert returned_value_0['memory_mb']['swapfree_mb'] == 0
    assert returned_value_0['memory_mb']['memfree_mb'] == 0
    assert returned_value_0['processor'] == []
    assert returned_value_0['processors']['count'] == 0

# Generated at 2022-06-24 22:17:45.650529
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0.platform == 'NetBSD', \
        "Expected NetBSD" \
        ", but got: " + net_b_s_d_hardware_collector_0.platform



# Generated at 2022-06-24 22:17:47.954252
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(dict())
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:17:53.426596
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    test_case_0()
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_cpu_facts() == {}


# Generated at 2022-06-24 22:17:55.916300
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.populate() is not None