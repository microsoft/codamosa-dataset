

# Generated at 2022-06-24 22:10:26.611611
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    import sys
    import doctest

    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 22:10:33.766375
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0._module)
    facts = net_b_s_d_hardware_0.populate()
    dmi_facts = net_b_s_d_hardware_0.get_dmi_facts()
    assert 'product_serial' in dmi_facts
    assert 'system_vendor' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts


# Generated at 2022-06-24 22:10:43.506868
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    meminfo_test = ["MemTotal:        1009316 kB",
                    "MemFree:          800972 kB",
                    "SwapTotal:       1011708 kB",
                    "SwapFree:        1001396 kB"]
    net_b_s_d_hardware_0 = NetBSDHardware(
        module=AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True
        ),
        params=dict()
    )
    net_b_s_d_memory_test_0 = net_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:10:53.505879
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(module='ansible.module_utils.facts.hardware.net_b_s_d.NetBSDHardware',
        module_internal_info='test')
    net_b_s_d_hardware_0._module.sysctl = {'machdep.dmi.system-product': 'system-product',
        'machdep.dmi.system-version': 'system-version',
        'machdep.dmi.system-uuid': 'system-uuid',
        'machdep.dmi.system-serial': 'system-serial',
        'machdep.dmi.system-vendor': 'system-vendor'}
    result = net_b_s_d_hardware_0.get_dmi_facts()
   

# Generated at 2022-06-24 22:10:56.116894
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:10:58.762283
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.populate() is None


# Generated at 2022-06-24 22:11:07.313117
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    fail_count = 0
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MagicMock()
    net_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    net_b_s_d_hardware_0.module.fail_json = MagicMock()
    net_b_s_d_hardware_0.get_cpu_facts()
    try:
        net_b_s_d_hardware_0.module.run_command.assert_any_call(['sysctl', 'hw.ncpu'])
    except AssertionError as e:
        fail_count += 1

# Generated at 2022-06-24 22:11:09.265767
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:11:11.641273
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert not net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:11:14.840317
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_net_b_s_d_hardware_0 = NetBSDHardware()
    test_module_0 = test_net_b_s_d_hardware_0.populate({})
    assert isinstance(test_module_0, dict)



# Generated at 2022-06-24 22:12:43.389131
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    meminfo_content = """MemTotal:       8004444 kB
SwapTotal:      8004444 kB
MemFree:        4004444 kB
SwapFree:       4004444 kB"""
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_file_content = lambda x: meminfo_content
    net_b_s_d_hardware_0.is_file = lambda x: True
    result = net_b_s_d_hardware_0.get_memory_facts()
    assert (result['memfree_mb'] == 3906)
    assert (result['memtotal_mb'] == 7813)
    assert (result['swapfree_mb'] == 3906)

# Generated at 2022-06-24 22:12:46.915862
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert isinstance(net_b_s_d_hardware_collector_0, NetBSDHardwareCollector)


# Generated at 2022-06-24 22:12:55.629299
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value='/usr/bin/sysctl')

# Generated at 2022-06-24 22:13:03.592319
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = MagicMock()
    net_b_s_d_hardware_0.module.get_bin_path.return_value = "/usr/bin/dmidecode"

    net_b_s_d_hardware_0.module.run_command.return_value = (0, '', '')

    net_b_s_d_hardware_0.module.get_bin_path.return_value = ''

    # Call method
    result = net_b_s_d_hardware_0.get_dmi_facts()
    assert result['system_vendor'] == 'Dell Inc.'


# Generated at 2022-06-24 22:13:14.476258
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = None
    net_b_s_d_hardware_0.sysctl = {"machdep.dmi.system-product":"X9SCL-IF","machdep.dmi.system-version":"A1","machdep.dmi.system-uuid":"9b8a3d1f-38e6-fbb3-d8a0-fba778abf802","machdep.dmi.system-serial":"B1702752425","machdep.dmi.system-vendor":"Supermicro"}

    return net_b_s_d_hardware_0.get_dmi_facts()
test_NetBSDHardware_get_dmi_facts.solution

# Generated at 2022-06-24 22:13:23.731274
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_0.populate()
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.get_facts()
    net_b_s_d_hardware_0_value = net_b_s_d_hardware_0['ansible_net_b_s_d_hardware']
    
    net_b_s_d_hardware_0_value_get_memory_facts_0 = net_b_s_d_hardware_0_value.get_memory_facts()

# Generated at 2022-06-24 22:13:29.435760
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(dict())

    net_b_s_d_hardware_0.sysctl = get_sysctl(net_b_s_d_hardware_0.module, ['machdep'])
    dmi_facts = net_b_s_d_hardware_0.get_dmi_facts()
    return dmi_facts


# Generated at 2022-06-24 22:13:32.176063
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert_equals(net_b_s_d_hardware_0.populate(), None)


# Generated at 2022-06-24 22:13:43.336667
# Unit test for method get_dmi_facts of class NetBSDHardware

# Generated at 2022-06-24 22:13:51.746696
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts = {
    }
    get_file_lines_0 = get_file_lines('/proc/meminfo')
    net_b_s_d_hardware_0.get_memory_facts = get_memory_facts_0 = lambda: {'memtotal_mb': 5312}
    get_file_lines_1 = get_file_lines('/proc/cpuinfo')
    net_b_s_d_hardware_0.get_cpu_facts = get_cpu_facts_0 = lambda: {'processor': ['Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz']}
    get_file_content_0 = get_file_content('/etc/fstab')
    net_b_

# Generated at 2022-06-24 22:15:22.649241
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()

    get_dmi_facts_ret_val_0 = net_b_s_d_hardware_0.get_dmi_facts()

    assert not get_dmi_facts_ret_val_0

# Generated at 2022-06-24 22:15:26.737210
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.get_dmi_facts()


# Generated at 2022-06-24 22:15:28.278773
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware(None)
    assert net_b_s_d_hardware.populate()



# Generated at 2022-06-24 22:15:34.929246
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    module_0 = AnsibleModuleMock()
    net_b_s_d_hardware_0.module = module_0
    module_0.run_command.return_value = (0, "machdep.dmi.system-product=ProLiant DL380p Gen8\nmachdep.dmi.system-uuid=0019BAF2-2D7F-E311-8C7B-FA163E008E7D\nmachdep.dmi.system-version=1")

# Generated at 2022-06-24 22:15:38.393426
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0._platform == 'NetBSD'


# Generated at 2022-06-24 22:15:41.452113
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:15:44.675450
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    # Test with None parameter
    collected_facts_0 = net_b_s_d_hardware_collector_0.collect()
    for key in collected_facts_0:
        print("output for %s is %s " % (key, collected_facts_0[key]))

if __name__ == "__main__":
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:15:49.638989
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()


if __name__ == '__main__':
    # Unit test for method get_mount_facts of class NetBSDHardware
    test_NetBSDHardware_get_dmi_facts()
    test_case_0()

# Generated at 2022-06-24 22:15:58.054551
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware({})
    net_b_s_d_hardware_0.get_cpu_facts = lambda: {}
    net_b_s_d_hardware_0.get_memory_facts = lambda: {}
    net_b_s_d_hardware_0.get_mount_facts = lambda: {}
    net_b_s_d_hardware_0.get_dmi_facts = lambda: {}
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:16:00.073559
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

test_case_0()

# Generated at 2022-06-24 22:17:34.626108
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Set up mock source data
    mock_collected_facts = {}
    net_b_s_d_hardware_0 = NetBSDHardware()

    # Call method
    net_b_s_d_hardware_0.populate(mock_collected_facts)



# Generated at 2022-06-24 22:17:35.949244
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    pass


# Generated at 2022-06-24 22:17:39.798099
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    # test for class NetBSDHardware
    test_case_0()
    # test for method populate of class NetBSDHardware
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:17:43.416052
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_cpu_facts() == {}


# Generated at 2022-06-24 22:17:48.182313
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    out = net_b_s_d_hardware_0.get_cpu_facts()
    assert 'processor' in out.keys()
    assert 'processor_count' in out.keys()
    assert 'processor_cores' in out.keys()


# Generated at 2022-06-24 22:17:53.837421
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:57.414101
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_populate = NetBSDHardware()

    try:
        net_b_s_d_hardware_populate.populate()
    except:
        pass

# Generated at 2022-06-24 22:17:59.418015
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_bsd_hardware = NetBSDHardware()
    net_bsd_hardware.populate()

# Generated at 2022-06-24 22:18:02.401027
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_cpu_facts() != {}


# Generated at 2022-06-24 22:18:06.043703
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():

    net_b_s_d_hardware = NetBSDHardware()

    net_b_s_d_hardware._collect_platform_facts()

    net_b_s_d_hardware.get_dmi_facts()

    assert net_b_s_d_hardware.facts['dmi']
