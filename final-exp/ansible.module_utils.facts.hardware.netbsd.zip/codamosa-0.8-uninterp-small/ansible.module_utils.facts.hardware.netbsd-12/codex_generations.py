

# Generated at 2022-06-24 22:10:15.868247
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    # calling populate(arg=None)
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:10:18.345814
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:10:21.865987
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    #
    # Test NetBSDHardware.populate
    #
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    net_b_s_d_hardware_0.populate()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 22:10:30.489282
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    dict_0 = {
        'mibs': [
            'machdep.dmi.system-product',
            'machdep.dmi.system-version',
            'machdep.dmi.system-uuid',
            'machdep.dmi.system-serial',
            'machdep.dmi.system-vendor'
        ]
    }
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:10:33.141784
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Test the basic fact gathering, kernel version.
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    results = net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:10:40.411524
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    dict_0 = {}
    hardware_collector_0 = NetBSDHardwareCollector(dict_0)
    net_b_s_d_hardware_0 = NetBSDHardware(hardware_collector_0)
    assert net_b_s_d_hardware_0.populate() == {}
    assert net_b_s_d_hardware_0.populate() == {}
    assert net_b_s_d_hardware_0.populate() == {}
    assert net_b_s_d_hardware_0.populate() == {}
    assert net_b_s_d_hardware_0.populate() == {}


# Generated at 2022-06-24 22:10:47.923624
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    # Test with non-empty dictionary, with 4 elements
    net_b_s_d_hardware_0._module = {
        'run_command': lambda cmd, envs: (0, 'MemTotal:        2051560 kB\nSwapTotal:       2105116 kB\nMemFree:         1383748 kB\nSwapFree:        1950908 kB')
    }
    assert net_b_s_d_hardware_0.get_cpu_facts() == {
        'processor': ['model name'],
        'processor_count': 0,
        'processor_cores': 'NA'
    }

# Generated at 2022-06-24 22:10:52.079698
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    print('Testing get_dmi_facts')
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    net_b_s_d_hardware_0.sysctl = {}
    result = net_b_s_d_hardware_0.get_dmi_facts()
    print(result)
    assert result == {}



# Generated at 2022-06-24 22:11:02.320319
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    net_b_s_d_hardware_0.get_cpu_facts = MagicMock()
    net_b_s_d_hardware_0.get_memory_facts = MagicMock()
    net_b_s_d_hardware_0.get_mount_facts = MagicMock()
    net_b_s_d_hardware_0.get_dmi_facts = MagicMock()
    net_b_s_d_hardware_0.populate(None)

    net_b_s_d_hardware_0.get_cpu_facts.assert_called()
    net_b_s_d_hardware_0.get_memory_facts.assert_called

# Generated at 2022-06-24 22:11:06.449238
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    dict_0 = {}
    net_b_s_d_hardware_0 = NetBSDHardware(dict_0)
    net_b_s_d_hardware_0.module.get_bin_path = lambda x: "/usr/bin/dmidecode"
    net_b_s_d_hardware_0.module.run_command = lambda x, check_rc=None: ""
    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:12:28.158505
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    pass


# Generated at 2022-06-24 22:12:35.532158
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_1 = NetBSDHardware()
    net_b_s_d_hardware_2 = NetBSDHardware()
    net_b_s_d_hardware_3 = NetBSDHardware()
    net_b_s_d_hardware_4 = NetBSDHardware()
    net_b_s_d_hardware_5 = NetBSDHardware()
    net_b_s_d_hardware_6 = NetBSDHardware()
    net_b_s_d_hardware_7 = NetBSDHardware()
    net_b_s_d_hardware_8 = NetBSDHardware()
    net_b_s_d_hardware_9 = NetBSDHardware()
    net_b_s_d_

# Generated at 2022-06-24 22:12:36.541815
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    pass


# Generated at 2022-06-24 22:12:42.223163
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.populate()

if __name__ == "__main__":
    test_case_0()
    # test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:12:43.990654
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:12:48.556081
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:12:50.289585
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_NetBSDHardware = NetBSDHardware()
    test_NetBSDHardware.populate()


# Generated at 2022-06-24 22:12:52.994455
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert(net_b_s_d_hardware_collector_0.platform == 'NetBSD')


# Generated at 2022-06-24 22:12:55.820224
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = None
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:57.142545
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:14:16.416478
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:14:17.008277
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:14:21.794384
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:27.089081
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    print("test NetBSDHardwareCollector")
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0._platform == 'NetBSD'


# Generated at 2022-06-24 22:14:31.844148
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0._fact_class == NetBSDHardware
    assert net_b_s_d_hardware_collector_0._platform == 'NetBSD'


# Generated at 2022-06-24 22:14:38.499637
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:14:39.892761
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:14:49.629129
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    # Dummy module for testing
    class Module(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    mod = Module(name='ansible', timeout=60, cache_default_timeout=60)
    var_1 = net_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:14:54.468906
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:15:03.296258
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.populate()
    assert isinstance(var_0, dict)
    assert var_0.keys() == ['processor', 'swaptotal_mb', 'devices', 'processor_cores', 'memfree_mb', 'memtotal_mb', 'swapfree_mb', 'mounts', 'processor_count']
    assert isinstance(var_0['processor'], list)
    assert 'CPU' in var_0['processor'][0]
    assert 'CPU' in var_0['processor'][1]

# Generated at 2022-06-24 22:16:31.457469
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:16:35.798200
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    result_0 = net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:16:40.664182
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
  net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
  net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
  var_0 = net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:16:45.424082
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    """ Test for method populate of class NetBSDHardware"""
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:16:50.077555
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:16:56.454653
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.module = mock.Mock()
    net_b_s_d_hardware_0.module.get_bin_path.return_value = '/usr/sbin'
    net_b_s_d_hardware_0.get_sysctl = mock.Mock()

    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:16:57.645503
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector = NetBSDHardwareCollector()



# Generated at 2022-06-24 22:16:59.185498
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    print('')
    print('Testing method populate')
    test_case_0()


# Generated at 2022-06-24 22:17:03.017506
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():

    gathered_facts = {}

    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    # On NetBSD we cannot guarantee that /proc/meminfo exists.
    # if it does not, the value for memfree_mb will not be populated.
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    var_0 = net_b_s_d_hardware_0.populat

# Generated at 2022-06-24 22:17:09.912646
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector()
    net_b_s_d_hardware_1 = NetBSDHardware(net_b_s_d_hardware_collector_1)
    var_1 = net_b_s_d_hardware_1.populate()
    assert var_1['network_devices']['devices']['vnet0']['ipv4']['address'] == '10.0.2.15'
