

# Generated at 2022-06-24 22:10:28.985127
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector(b'\xb3w')
    assert net_b_s_d_hardware_collector_1.get_cpu_facts() == {}


# Generated at 2022-06-24 22:10:35.123582
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    h = NetBSDHardware()
    assert h.get_dmi_facts() == {'product_name': 'VirtualBox', 'product_serial': '0', 'product_uuid': 'c432aa90-b3a3-4739-9d6c-f6758e95d2fb', 'system_vendor': 'innotek GmbH'}

# Generated at 2022-06-24 22:10:43.889890
# Unit test for method get_cpu_facts of class NetBSDHardware

# Generated at 2022-06-24 22:10:52.587434
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    bytes_0 = b'\xb3w'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(bytes_0)
    module_0 = net_b_s_d_hardware_collector_0.module
    collected_facts_0 = {}
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.get_facts(
        collected_facts_0, module_0)
    value_0 = net_b_s_d_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:11:00.458593
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    bytes_0 = b'k\xcc\x7f\xa5\x1b\xb2\xd1\xed\x98\x88\xfa\xcd\xfd<\xea\xbd'
    bytes_1 = b'\xb3w'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(bytes_0)
    net_b_s_d_hardware_0 = net_b_s_d_hardware_collector_0.collect()

    assert net_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:11:04.104968
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    get_sysctl_0 = get_sysctl(any_0, list_0)
    net_b_s_d_hardware_0 = NetBSDHardware(get_sysctl_0)
    net_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:11:13.715373
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    bytes_0 = b'\xb3w'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(bytes_0)
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate({'machdep': {'dmi': {'system-product': 'NF10', 'system-version': '1.0', 'system-uuid': '1234', 'system-vendor': 'NetFPGA', 'system-serial': '5678'}}})

# Generated at 2022-06-24 22:11:18.060479
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    bytes_0 = b'\xb3w'
    net_b_s_d_hardware_0 = NetBSDHardware(bytes_0)
    net_memory_facts_0 = net_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:11:23.565979
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():

    bytes_0 = b'\xb3w'
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(bytes_0)



if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:11:27.945482
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(b'\xb3w')
    r0 = net_b_s_d_hardware_collector_0._fact_class.populate(net_b_s_d_hardware_collector_0, b'\xd3\xe3\xef\xe7\xb3w\xe7')
    assert r0 == {}


# Generated at 2022-06-24 22:13:03.803009
# Unit test for method populate of class NetBSDHardware

# Generated at 2022-06-24 22:13:06.864866
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hw = NetBSDHardware()
    collected_facts = {}
    hw.populate(collected_facts=collected_facts)


# Generated at 2022-06-24 22:13:08.756206
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()


# Generated at 2022-06-24 22:13:13.546083
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0._fact_class == NetBSDHardware
    assert net_b_s_d_hardware_collector_0._platform == 'NetBSD'

# Generated at 2022-06-24 22:13:15.890786
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Test case 0:
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()
    return True

# Generated at 2022-06-24 22:13:18.067956
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:13:21.769557
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.get_dmi_facts() is None


# Generated at 2022-06-24 22:13:24.433511
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_populate = NetBSDHardware()
    net_b_s_d_hardware_populate.populate()


# Generated at 2022-06-24 22:13:27.930818
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_1 = NetBSDHardware()
    dmi_facts = net_b_s_d_hardware_1.get_dmi_facts()
    assert dmi_facts


# Generated at 2022-06-24 22:13:30.201630
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    assert isinstance(NetBSDHardwareCollector(), HardwareCollector)
    assert isinstance(NetBSDHardwareCollector()._fact_class(), NetBSDHardware)



# Generated at 2022-06-24 22:15:03.581262
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    if net_b_s_d_hardware_0.module.get_bin_path('dmidecode', False) != None:
        if not net_b_s_d_hardware_0.module.check_mode:
            assert net_b_s_d_hardware_0.get_dmi_facts() == {'product_name': b'ThinkPad T440p', 'product_serial': b'R9H3VGK', 'system_vendor': b'LENOVO', 'product_uuid': b'4C4C4544-0046-4A10-8056-C4C04F503032', 'product_version': b'ThinkPad T440p'}
    else:
        assert net_b_s

# Generated at 2022-06-24 22:15:13.343922
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_1 = NetBSDHardware()
    net_b_s_d_hardware_1.sysctl = {'machdep.dmi.system-product': 'product_name', 'machdep.dmi.system-version': 'product_version', 'machdep.dmi.system-uuid': 'product_uuid', 'machdep.dmi.system-serial': 'product_serial', 'machdep.dmi.system-vendor': 'system_vendor', 'machdep.dmi.foo': 'bar'}

# Generated at 2022-06-24 22:15:22.318685
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(None)
    net_b_s_d_hardware_0.module = None
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'sda1'}
    net_b_s_d_hardware_0.get_dmi_facts()

    net_b_s_d_hardware_0 = NetBSDHardware(None)
    net_b_s_d_hardware_0.module = None
    net_b_s_d_hardware_0.sysctl = {}
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:15:26.372313
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:15:29.007680
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:15:32.893650
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    res = net_b_s_d_hardware_0.get_dmi_facts()
    assert res == {}


# Generated at 2022-06-24 22:15:40.907285
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.sysctl = {}

    for mib in NetBSDHardware.SYSCTL_TO_DMI:
        net_b_s_d_hardware.sysctl[mib] = 'test_value'

    dmi_facts_0 = NetBSDHardware.get_dmi_facts(net_b_s_d_hardware)
    expected_keys = NetBSDHardware.SYSCTL_TO_DMI.values()

    for k in dmi_facts_0:
        assert k in expected_keys

# Generated at 2022-06-24 22:15:42.865154
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert True



# Generated at 2022-06-24 22:15:46.581482
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()

#
# Unit test execution.
#
if __name__ == '__main__':
    test_case_0()
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:15:50.273163
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_1.collect()

# Generated at 2022-06-24 22:17:53.172925
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()


# Generated at 2022-06-24 22:18:02.154087
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = "fake_module"

    net_b_s_d_hardware_0.populate()

    assert isinstance(net_b_s_d_hardware_0.device_links, dict)
    assert len(net_b_s_d_hardware_0.device_links) == 0
    assert isinstance(net_b_s_d_hardware_0.devices, list)
    assert len(net_b_s_d_hardware_0.devices) == 0
    assert isinstance(net_b_s_d_hardware_0.memfree_mb, int)

# Generated at 2022-06-24 22:18:04.993254
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts_0 = net_b_s_d_hardware_0.populate()
    assert isinstance(collected_facts_0, dict)


# Generated at 2022-06-24 22:18:09.646388
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()

    net_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:18:12.185502
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_1 = NetBSDHardware()
    assert net_b_s_d_hardware_1.populate() == {}

# Generated at 2022-06-24 22:18:17.604161
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_sysctl = get_sysctl(None, ['machdep'])
    net_b_s_d_hardware_0.sysctl = net_b_s_d_hardware_sysctl
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:18:24.107410
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    net_b_s_d_hardware_0.sysctl = dict()
    # No error raised by this method
    result = net_b_s_d_hardware_0.get_dmi_facts()
    assert isinstance(result, dict), "'result' should be a 'dict' instance"


# Generated at 2022-06-24 22:18:28.511345
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    collected_facts_0 = {}
    hardware_facts_0 = net_b_s_d_hardware_0.populate(collected_facts_0)
    assert hardware_facts_0 is not None


# Generated at 2022-06-24 22:18:37.958323
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_1 = NetBSDHardware()
    net_b_s_d_hardware_1.module = None
    collect_dictionary = {}
    net_b_s_d_hardware_2 = NetBSDHardware()
    net_b_s_d_hardware_2.module = None
    collect_dictionary = {}
    net_b_s_d_hardware_2.module = None
    collect_dictionary = {}
    net_b_s_d_hardware_3 = NetBSDHardware()
    net_b_s_d_hardware_3.sysctl = get_sysctl(net_b_s_d_hardware_3.module, ['machdep'])
   

# Generated at 2022-06-24 22:18:46.809321
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()

    memfree_mb = net_b_s_d_hardware_0.get_memfree_mb()
    memtotal_mb = net_b_s_d_hardware_0.get_memtotal_mb()
    swapfree_mb = net_b_s_d_hardware_0.get_swapfree_mb()
    swaptotal_mb = net_b_s_d_hardware_0.get_swaptotal_mb()
    processor = net_b_s_d_hardware_0.get_processor()
    processor_cores = net_b_s_d_hardware_0.get_processor_cores()
    processor_count = net_b_s_d_hardware_0.get_processor