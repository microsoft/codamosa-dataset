

# Generated at 2022-06-24 22:10:17.053668
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = 'os_server'
    str_1 = 'memory_mb'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0)
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector(str_0)
    net_b_s_d_hardware_0.populate()
    assert net_b_s_d_hardware_0.facts['ansible_architecture'] == 'NA'
    assert net_b_s_d_hardware_0.facts['devices'] == {}
    assert net_b_s_d_hardware_0.facts[str_1] == None


# Generated at 2022-06-24 22:10:18.950835
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
  str_0 = 'decoy'
  net_b_s_d_hardware_0 = NetBSDHardware(str_0)


# Generated at 2022-06-24 22:10:22.815737
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_0.collect()

if __name__ == '__main__':
    # Constructor of class NetBSDHardware
    test_case_0()

    # Unit test for constructor of class NetBSDHardwareCollector
    test_NetBSDHardwareCollector()

# Generated at 2022-06-24 22:10:25.576307
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = 'zipinfo'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0)
    res_0 = net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:29.237186
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = 'mkfs.cramfs'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:10:32.722255
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = 'zipinfo'
    obj_0 = NetBSDHardware(str_0)
    obj_0.populate()


# Generated at 2022-06-24 22:10:34.104612
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(None)

# Generated at 2022-06-24 22:10:38.547841
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    str_0 = 'zipinfo'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0)

    net_b_s_d_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 22:10:40.741889
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    str_0 = 'zipinfo'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0)
    net_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:10:44.996520
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    str_0 = 'zipinfo'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0)
    # Call the method
    assert(net_b_s_d_hardware_0.get_cpu_facts() is None)


# Generated at 2022-06-24 22:12:03.446400
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:07.018602
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:12.170479
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_0 = NetBSDHardware(net_b_s_d_hardware_collector_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:15.514820
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector = NetBSDHardwareCollector()
    assert isinstance(net_b_s_d_hardware_collector, NetBSDHardwareCollector)


# Generated at 2022-06-24 22:12:19.841320
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()
    # Method call
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:12:22.006983
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

test_case_0()
test_NetBSDHardware_populate()

# Generated at 2022-06-24 22:12:26.214335
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_2 = NetBSDHardware()
    if NetBSDHardware.platform == 'NetBSD':
        net_b_s_d_hardware_2.populate()


# Generated at 2022-06-24 22:12:30.433250
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0._module = None
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:34.709899
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:12:39.379569
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    result = net_b_s_d_hardware_0.get_memory_facts()
    assert isinstance(result, dict)



# Generated at 2022-06-24 22:14:00.700559
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:14:11.087862
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware("module")
    dict0 = dict()
    dict0["OS-RELEASE"] = dict()
    dict0["OS-RELEASE"]["distro"] = "NetBSD"
    dict0["ansible_facts"] = dict()
    dict0["ansible_facts"]["hardware"] = dict()
    dict0["ansible_facts"]["hardware"]["uname_machine"] = "amd64"
    dict0["ansible_facts"]["hardware"]["platform"] = "NetBSD"
    dict0["ansible_facts"]["hardware"]["distribution_release"] = "6.1.5"

# Generated at 2022-06-24 22:14:13.451511
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:18.414867
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    net_b_s_d_hardware_0 = NetBSDHardware(dict(), list())
    net_b_s_d_hardware_0.module = AnsibleModule(argument_spec=dict())
    assert isinstance(net_b_s_d_hardware_0.get_cpu_facts(), dict)


# Generated at 2022-06-24 22:14:27.442532
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    # Testing if the net_b_s_d_hardware_collector_0 object is an instance of HardwareCollector
    if not (isinstance(net_b_s_d_hardware_collector_0, HardwareCollector)):
        raise Error('The object is not an instance of HardwareCollector')
    # Testing if the object is an instance of NetBSDHardwareCollector
    if not (isinstance(net_b_s_d_hardware_collector_0, NetBSDHardwareCollector)):
        raise Error('The object is not an instance of NetBSDHardwareCollector')


# Generated at 2022-06-24 22:14:29.961248
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware = NetBSDHardware()
    net_b_s_d_hardware.populate()

# Generated at 2022-06-24 22:14:32.804546
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    assert net_b_s_d_hardware_collector_0.populate() is None


# Generated at 2022-06-24 22:14:36.560592
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_collector_1 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_1.populate()


# Generated at 2022-06-24 22:14:39.223874
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware(None)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:14:43.069423
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    net_b_s_d_hardware = NetBSDHardware()
    result = net_b_s_d_hardware.get_memory_facts()
    assert (isinstance(result, dict))


# Generated at 2022-06-24 22:16:28.449144
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.sysctl = {'machdep.dmi.system-product': 'test_product_name', 'machdep.dmi.system-version': 'test_product_version', 'machdep.dmi.system-serial': 'test_product_serial', 'machdep.dmi.system-uuid': 'test_product_uuid', 'machdep.dmi.system-vendor': 'test_system_vendor'}

# Generated at 2022-06-24 22:16:29.345035
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    pass


# Generated at 2022-06-24 22:16:31.422658
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    try:
        test_case_0()
        print('test_case_0 passed')
    except:
        print('test_case_0 failed')


# Generated at 2022-06-24 22:16:35.958109
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # id: 0
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_collector_0 = NetBSDHardwareCollector()
    net_b_s_d_hardware_collector_0.module = None
    net_b_s_d_hardware_collector_0.populate()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:16:45.387482
# Unit test for method get_memory_facts of class NetBSDHardware

# Generated at 2022-06-24 22:16:48.188027
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()

    try:
        net_b_s_d_hardware_0.get_dmi_facts()
    except Exception:
        pass


# Generated at 2022-06-24 22:16:51.166102
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    assert net_b_s_d_hardware_0.populate() is None


# Generated at 2022-06-24 22:16:52.917268
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()



# Generated at 2022-06-24 22:16:55.872528
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:17:00.501700
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    net_b_s_d_hardware_0 = NetBSDHardware()
    net_b_s_d_hardware_0.sysctl = {}
    # Call get_dmi_facts of NetBSDHardware
    net_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:18:50.754449
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    str_0 = 'zipinfo'
    net_b_s_d_hardware_0 = NetBSDHardware(str_0)
    net_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:18:53.853499
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    string_0 = 'pam_access'
    net_b_s_d_hardware_0 = NetBSDHardware(string_0)
    net_b_s_d_hardware_0.populate()
