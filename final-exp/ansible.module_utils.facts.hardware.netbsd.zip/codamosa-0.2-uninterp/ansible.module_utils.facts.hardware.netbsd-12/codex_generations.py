

# Generated at 2022-06-17 00:13:15.647609
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:13:25.794990
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = None
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Marvell'
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:13:37.889404
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware({})
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '12345678-1234-1234-1234-123456789012',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'VirtualBox'
    assert dmi_facts['product_version'] == '1.2'
   

# Generated at 2022-06-17 00:13:45.048378
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '01234567-89ab-cdef-0123-456789abcdef',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'VirtualBox'
    assert dmi_facts['product_version'] == '1.2'
   

# Generated at 2022-06-17 00:13:49.148546
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = NetBSDHardware().get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3317U CPU @ 1.70GHz']

# Generated at 2022-06-17 00:13:54.750681
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['ARMv7 Processor rev 2 (v7l)']

# Generated at 2022-06-17 00:13:58.994659
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = NetBSDHardware().get_cpu_facts()
    assert cpu_facts['processor_count'] >= 1
    assert cpu_facts['processor_cores'] >= 1
    assert len(cpu_facts['processor']) == cpu_facts['processor_count']


# Generated at 2022-06-17 00:14:08.432591
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.module = MockModule()
    netbsd_hardware.module.get_bin_path = Mock(return_value='/bin/cat')
    netbsd_hardware.module.run_command = Mock(return_value=(0, '', ''))
    netbsd_hardware.module.params = {'gather_timeout': 10}

    netbsd_hardware.get_cpu_facts()
    netbsd_hardware.module.run_command.assert_called_once_with(['/bin/cat', '/proc/cpuinfo'])



# Generated at 2022-06-17 00:14:13.954129
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    hardware_collector = NetBSDHardwareCollector()
    assert hardware_collector._fact_class == NetBSDHardware
    assert hardware_collector._platform == 'NetBSD'

# Generated at 2022-06-17 00:14:23.591965
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.module.get_file_lines = Mock(return_value=['MemTotal:       16277500 kB',
                                                        'SwapTotal:      16277500 kB',
                                                        'MemFree:        16277500 kB',
                                                        'SwapFree:       16277500 kB'])
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 15861
    assert memory_facts['swaptotal_mb'] == 15861
    assert memory_facts['memfree_mb'] == 15861
    assert memory_facts['swapfree_mb'] == 15861



# Generated at 2022-06-17 00:17:28.910276
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['processor'][0] == 'ARMv7 Processor rev 1 (v7l)'
    assert hardware_facts['memtotal_mb'] == 992
    assert hardware_facts['memfree_mb'] == 992
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['product_name'] == 'Plug Computer'
    assert hardware_facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:17:35.819215
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class MockModule:
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/sbin/sysctl'

    class MockSysctl:
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def get(self, arg):
            return self.sysctl[arg]


# Generated at 2022-06-17 00:17:39.005276
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    NetBSDHardwareCollector()

# Generated at 2022-06-17 00:17:49.373457
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 685
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_serial'] == '00000000'
    assert hardware.facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert hardware

# Generated at 2022-06-17 00:17:55.781503
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 0 (v7l)']
    assert hardware.facts['memtotal_mb'] == 996
    assert hardware.facts['memfree_mb'] == 996
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Allwinner Technology'
    assert hardware.facts['product_name'] == 'sun8i'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:18:01.896650
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 16384
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:18:10.253089
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 7983
    assert hardware.facts['memfree_mb'] == 7983
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'MacBookPro10,1'
    assert hardware.facts['product_serial'] == 'C02KH0AZDFTY'

# Generated at 2022-06-17 00:18:14.748205
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.module.get_bin_path.return_value = '/usr/bin/dmidecode'
    hardware.get_cpu_facts()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1


# Generated at 2022-06-17 00:18:22.687090
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'Plug Computer'
    assert hardware.facts['product_version'] == '1.2'
    assert hardware.facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-17 00:18:31.441347
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 2 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Marvell'
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_serial'] == '1234567890'