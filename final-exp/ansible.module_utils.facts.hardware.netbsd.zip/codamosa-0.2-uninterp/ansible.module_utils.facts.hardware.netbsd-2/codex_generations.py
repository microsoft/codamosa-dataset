

# Generated at 2022-06-17 00:12:45.918308
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']

# Generated at 2022-06-17 00:12:53.066031
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz', 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz']

# Generated at 2022-06-17 00:13:03.729418
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz', 'Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 7073
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['product_name'] == 'VirtualBox'
    assert hardware.facts['product_serial'] == '0'


# Generated at 2022-06-17 00:13:11.975030
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = None
    hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2-3',
        'machdep.dmi.system-uuid': '01234567-89ab-cdef-0123-456789abcdef',
        'machdep.dmi.system-serial': '0123456789abcdef',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    hardware.populate()
    assert hardware.facts['product_name'] == 'VirtualBox'
    assert hardware.facts['product_version'] == '1.2-3'

# Generated at 2022-06-17 00:13:18.004926
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:13:24.936135
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Test with a mocked module
    module = MockModule()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 5983
    assert hardware.facts['swaptotal_mb'] == 8191
    assert hardware.facts['swapfree_mb'] == 8191
    assert hardware.facts['system_vendor'] == 'Apple Inc.'
    assert hardware.facts['product_name'] == 'MacBookPro10,1'

# Generated at 2022-06-17 00:13:36.069150
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 512
    assert hardware.facts['swaptotal_mb'] == 2048
    assert hardware.facts['swapfree_mb'] == 1024
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz']
    assert hardware.facts['system_vendor'] == 'Dell Inc.'
    assert hardware.facts['product_name'] == 'OptiPlex 790'
    assert hardware.facts['product_version'] == '01'

# Generated at 2022-06-17 00:13:41.823518
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware({})
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'devices' in facts

# Generated at 2022-06-17 00:13:44.542149
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw_collector = NetBSDHardwareCollector()
    assert netbsd_hw_collector._fact_class == NetBSDHardware
    assert netbsd_hw_collector._platform == 'NetBSD'

# Generated at 2022-06-17 00:13:56.454333
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = None
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['system_vendor'] == 'Apple Inc.'
    assert hardware.facts['product_name'] == 'MacBookAir7,2'

# Generated at 2022-06-17 00:15:09.093641
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.module = MockModule()
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '12345678-1234-1234-1234-123456789012',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()

# Generated at 2022-06-17 00:15:17.661892
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_serial'] == '00000000'
    assert hardware.facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert hardware

# Generated at 2022-06-17 00:15:28.978876
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': 'a1b2c3d4-e5f6-a7b8-c9d0-e1f2a3b4c5d6',
        'machdep.dmi.system-serial': '0123456789',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()

# Generated at 2022-06-17 00:15:36.814960
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['product_name'] == 'MacBookPro11,1'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:15:46.297777
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-3470 CPU @ 3.20GHz']
    assert hardware.facts['memtotal_mb'] == 7984
    assert hardware.facts['memfree_mb'] == 7984
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Apple Inc.'
    assert hardware.facts['product_name'] == 'Macmini6,1'
    assert hardware.facts['product_version'] == '1.0'


# Generated at 2022-06-17 00:15:57.265584
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    """
    Test the method get_dmi_facts of class NetBSDHardware
    """
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    class MockSysctl(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def __getitem__(self, key):
            return self.sysctl[key]

        def __contains__(self, key):
            return key in self.sysctl

    class MockHardware(NetBSDHardware):
        def __init__(self, module):
            self.module = module

        def get_sysctl(self, keys):
            return self.module.sysctl

    module = MockModule({})

# Generated at 2022-06-17 00:16:06.775434
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz', 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 4894
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['product_name'] == 'Macmini5,1'

# Generated at 2022-06-17 00:16:16.371440
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 7094
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['product_name'] == 'MacBookPro11,1'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:16:24.105231
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz', 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 13984
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['product_name'] == 'VMware Virtual Platform'
    assert hardware.facts['product_version'] == 'None'


# Generated at 2022-06-17 00:16:33.969236
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz', 'Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 4984
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['product_name'] == 'VirtualBox'

# Generated at 2022-06-17 00:17:46.778474
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.populate()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-3610QM CPU @ 2.30GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 7862
    assert hardware.facts['memfree_mb'] == 7862
    assert hardware.facts['swaptotal_mb'] == 7862
    assert hardware.facts['swapfree_mb'] == 7862

# Generated at 2022-06-17 00:17:55.280491
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class FakeModule(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl

    class FakeFactCollector(object):
        def __init__(self, sysctl):
            self.module = FakeModule(sysctl)

    sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2-3',
        'machdep.dmi.system-uuid': '01234567-89ab-cdef-0123-456789abcdef',
        'machdep.dmi.system-serial': '0123456789abcdef',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }

    hardware = NetBSDHardware

# Generated at 2022-06-17 00:18:04.945827
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['devices']['sda']['model'] == 'VBOX HARDDISK'
    assert hardware.facts['devices']['sda']['size'] == '10737418240'
    assert hardware.facts['devices']['sda']['vendor'] == 'ATA'
    assert hardware.facts['devices']['sda']['serial'] == 'VBeee1ba8-095e7b5'
    assert hardware.facts['devices']['sda']['host'] == 'ide0'
    assert hardware.facts['devices']['sda']['rev'] == '1.0'

# Generated at 2022-06-17 00:18:10.839317
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 15609
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['product_name'] == 'Macmini7,1'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:18:21.676876
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['swaptotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 512
    assert hardware.facts['swapfree_mb'] == 512
    assert hardware.facts['product_name'] == 'VirtualBox'
    assert hardware.facts['product_serial'] == '0'
    assert hardware.facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert hardware.facts['product_version'] == '1.2-3'

# Generated at 2022-06-17 00:18:30.051725
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Test with empty sysctl
    netbsd_hw = NetBSDHardware({})
    assert netbsd_hw.get_dmi_facts() == {}

    # Test with sysctl containing some DMI facts
    netbsd_hw = NetBSDHardware({'machdep.dmi.system-product': 'Foo',
                                'machdep.dmi.system-version': 'Bar',
                                'machdep.dmi.system-uuid': 'Baz',
                                'machdep.dmi.system-serial': 'Quux',
                                'machdep.dmi.system-vendor': 'Foobar'})

# Generated at 2022-06-17 00:18:41.412099
# Unit test for method get_cpu_facts of class NetBSDHardware

# Generated at 2022-06-17 00:18:44.998714
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw = NetBSDHardwareCollector()
    assert netbsd_hw.platform == 'NetBSD'
    assert netbsd_hw._fact_class == NetBSDHardware


# Generated at 2022-06-17 00:18:55.456933
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    facts = hardware.populate()
    assert facts['processor_cores'] == 'NA'
    assert facts['processor_count'] == 1
    assert facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert facts['memtotal_mb'] == 1024
    assert facts['memfree_mb'] == 992
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['system_vendor'] == 'Raspberry Pi Foundation'
    assert facts['product_name'] == 'Raspberry Pi 3 Model B Rev 1.2'
    assert facts['product_serial'] == '00000000e0d6d1c6'

# Generated at 2022-06-17 00:19:06.652047
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8092
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['product_name'] == 'MacBookPro11,3'
    assert hardware.facts['product_version'] == '1.0'
    assert hardware.facts['product_uuid']

# Generated at 2022-06-17 00:20:26.303243
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Test with empty sysctl
    sysctl = {}
    hardware = NetBSDHardware(module=None, sysctl=sysctl)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {}

    # Test with sysctl containing some DMI facts
    sysctl = {
        'machdep.dmi.system-product': 'product_name',
        'machdep.dmi.system-version': 'product_version',
        'machdep.dmi.system-uuid': 'product_uuid',
        'machdep.dmi.system-serial': 'product_serial',
        'machdep.dmi.system-vendor': 'system_vendor',
    }
    hardware = NetBSDHardware(module=None, sysctl=sysctl)
    dmi_

# Generated at 2022-06-17 00:20:34.522577
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    netbsd_hardware = NetBSDHardware()
    cpu_facts = netbsd_hardware.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor' in cpu_facts
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0
    assert len(cpu_facts['processor']) == cpu_facts['processor_count']


# Generated at 2022-06-17 00:20:45.390871
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class MockModule:
        def __init__(self):
            self.params = {}

    class MockSysctl:
        def __init__(self):
            self.mibs = {
                'machdep.dmi.system-product': 'VirtualBox',
                'machdep.dmi.system-version': '1.2-3',
                'machdep.dmi.system-uuid': '01234567-89ab-cdef-0123-456789abcdef',
                'machdep.dmi.system-serial': '0123456789ABCDEF',
                'machdep.dmi.system-vendor': 'innotek GmbH',
            }

        def __getitem__(self, key):
            return self.mibs[key]


# Generated at 2022-06-17 00:20:55.225896
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    # Test with empty sysctl
    hardware = NetBSDHardware({'module_setup': True})
    hardware.sysctl = {}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {}

    # Test with non-empty sysctl
    hardware = NetBSDHardware({'module_setup': True})
    hardware.sysctl = {
        'machdep.dmi.system-product': 'test_product',
        'machdep.dmi.system-version': 'test_version',
        'machdep.dmi.system-uuid': 'test_uuid',
        'machdep.dmi.system-serial': 'test_serial',
        'machdep.dmi.system-vendor': 'test_vendor',
    }

# Generated at 2022-06-17 00:21:02.069766
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = type('', (), {'get_bin_path': lambda self, x: '/sbin/sysctl'})
    module.run_command = lambda x: (0, 'machdep.dmi.system-product: "VirtualBox"\n'
                                        'machdep.dmi.system-version: "1.2-3"\n'
                                        'machdep.dmi.system-uuid: "4-5-6"\n'
                                        'machdep.dmi.system-serial: "7-8-9"\n'
                                        'machdep.dmi.system-vendor: "innotek GmbH"\n', '')
    hardware = NetBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts

# Generated at 2022-06-17 00:21:07.728603
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware


# Generated at 2022-06-17 00:21:18.472477
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 10897
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['product_name'] == 'MacBookPro11,1'

# Generated at 2022-06-17 00:21:26.251625
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '12345678-1234-1234-1234-123456789012',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'VirtualBox'
    assert dmi_facts['product_version'] == '1.2'

# Generated at 2022-06-17 00:21:29.784058
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:21:37.166065
# Unit test for method get_cpu_facts of class NetBSDHardware