

# Generated at 2022-06-17 00:14:02.633973
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.populate()
    assert netbsd_hardware.facts['processor_cores'] == 'NA'
    assert netbsd_hardware.facts['processor_count'] == 1
    assert netbsd_hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert netbsd_hardware.facts['memtotal_mb'] == 1012
    assert netbsd_hardware.facts['memfree_mb'] == 995
    assert netbsd_hardware.facts['swaptotal_mb'] == 0
    assert netbsd_hardware.facts['swapfree_mb'] == 0
    assert netbsd_hardware.facts['system_vendor'] == 'Generic'
    assert netbsd_

# Generated at 2022-06-17 00:14:12.165003
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Marvell'
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_serial'] == '1234567890'
    assert hardware.facts

# Generated at 2022-06-17 00:14:23.360833
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-4200U CPU @ 1.60GHz']
    assert hardware.facts['memtotal_mb'] == 3969
    assert hardware.facts['memfree_mb'] == 2155
    assert hardware.facts['swaptotal_mb'] == 2047
    assert hardware.facts['swapfree_mb'] == 2047
    assert hardware.facts['product_name'] == 'MacBookAir6,2'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:14:32.209918
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    class MockSysctl(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def get_sysctl(self, module, keys):
            return self.sysctl


# Generated at 2022-06-17 00:14:36.892133
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector.platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware


# Generated at 2022-06-17 00:14:42.806786
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    hardware.module = None
    hardware.sysctl = None
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts

# Generated at 2022-06-17 00:14:53.738387
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hw = NetBSDHardware({})
    netbsd_hw.module = MockModule()
    netbsd_hw.populate()
    assert netbsd_hw.facts['processor_count'] == 2
    assert netbsd_hw.facts['processor_cores'] == 2
    assert netbsd_hw.facts['processor'] == ['Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz', 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz']
    assert netbsd_hw.facts['memtotal_mb'] == 16384
    assert netbsd_hw.facts['memfree_mb'] == 16384
    assert netbsd_hw.facts['swaptotal_mb'] == 16384

# Generated at 2022-06-17 00:15:05.805171
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.sysctl = {'machdep.dmi.system-product': 'Test product',
                       'machdep.dmi.system-version': 'Test version',
                       'machdep.dmi.system-uuid': 'Test UUID',
                       'machdep.dmi.system-serial': 'Test serial',
                       'machdep.dmi.system-vendor': 'Test vendor'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'Test product'
    assert dmi_facts['product_version'] == 'Test version'
    assert dmi_facts['product_uuid'] == 'Test UUID'

# Generated at 2022-06-17 00:15:13.102347
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 7072
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['product_name'] == 'MacBookPro11,1'
    assert hardware.facts['product_serial'] == 'C02PQ0TDFVH7'

# Generated at 2022-06-17 00:15:24.672997
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '00000000-0000-0000-0000-000000000000',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'VirtualBox'
    assert dmi_facts['product_version'] == '1.2'

# Generated at 2022-06-17 00:17:54.444231
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['mounts']
    assert hardware_facts['system_vendor']
    assert hardware_facts['product_name']
    assert hardware_facts['product_serial']
    assert hardware_facts['product_uuid']
    assert hardware_facts['product_version']

# Generated at 2022-06-17 00:18:04.594993
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 512
    assert hardware.facts['memfree_mb'] == 498
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Marvell'
    assert hardware.facts['product_name'] == 'Kirkwood 88F6281'

# Generated at 2022-06-17 00:18:15.400409
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 804
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Raspberry Pi Foundation'
    assert hardware.facts['product_name'] == 'Raspberry Pi 3 Model B Rev 1.2'
    assert hardware.facts['product_serial'] == '00000000f8d9f8d9'

# Generated at 2022-06-17 00:18:18.550277
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    facts = hardware.populate()
    assert facts['processor_count'] > 0
    assert facts['processor_cores'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['swaptotal_mb'] > 0


# Generated at 2022-06-17 00:18:22.466215
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']


# Generated at 2022-06-17 00:18:30.890008
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    netbsd_hw = NetBSDHardware()
    netbsd_hw.module = MockModule()
    netbsd_hw.module.get_file_lines = Mock(return_value=['MemTotal:        8097444 kB',
                                                         'SwapTotal:       8388604 kB',
                                                         'MemFree:         5174088 kB',
                                                         'SwapFree:        8388604 kB'])
    netbsd_hw.get_memory_facts()
    assert netbsd_hw.facts['memtotal_mb'] == 7968
    assert netbsd_hw.facts['swaptotal_mb'] == 8192
    assert netbsd_hw.facts['memfree_mb'] == 5042
    assert netbsd_hw.facts['swapfree_mb'] == 8192

# Generated at 2022-06-17 00:18:41.928428
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'MacBookPro11,1'
    assert hardware.facts['product_serial'] == 'C02PV0W5FVH3'
    assert hardware.facts['product_uuid']

# Generated at 2022-06-17 00:18:53.365013
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 5 (v7l)', 'ARMv7 Processor rev 5 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 844
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0

# Generated at 2022-06-17 00:18:56.297059
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:19:05.959957
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl is not None
    assert hardware.facts['processor'] is not None
    assert hardware.facts['processor_cores'] is not None
    assert hardware.facts['processor_count'] is not None
    assert hardware.facts['memtotal_mb'] is not None
    assert hardware.facts['memfree_mb'] is not None
    assert hardware.facts['swaptotal_mb'] is not None
    assert hardware.facts['swapfree_mb'] is not None
    assert hardware.facts['devices'] is not None
