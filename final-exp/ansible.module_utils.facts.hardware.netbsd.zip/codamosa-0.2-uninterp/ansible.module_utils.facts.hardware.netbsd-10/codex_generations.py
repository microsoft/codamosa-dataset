

# Generated at 2022-06-17 00:13:30.954980
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:13:40.484663
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hw = NetBSDHardware()
    netbsd_hw.module = MockModule()
    netbsd_hw.populate()

    assert netbsd_hw.facts['processor_cores'] == 2
    assert netbsd_hw.facts['processor_count'] == 2
    assert netbsd_hw.facts['memtotal_mb'] == 1024
    assert netbsd_hw.facts['swaptotal_mb'] == 2048
    assert netbsd_hw.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:13:43.825897
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw = NetBSDHardwareCollector()
    assert netbsd_hw.platform == 'NetBSD'
    assert netbsd_hw.fact_class == NetBSDHardware


# Generated at 2022-06-17 00:13:51.554758
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    # Test for NetBSDHardware.get_cpu_facts()
    # Create a NetBSDHardware object
    hardware_obj = NetBSDHardware()
    # Call the method
    cpu_facts = hardware_obj.get_cpu_facts()
    # Assert the processor_count
    assert cpu_facts['processor_count'] == 1
    # Assert the processor_cores
    assert cpu_facts['processor_cores'] == 1
    # Assert the processor
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:14:01.937834
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] > 0
    assert hardware.facts['processor_cores'] > 0
    assert hardware.facts['memtotal_mb'] > 0
    assert hardware.facts['swaptotal_mb'] > 0
    assert hardware.facts['memfree_mb'] > 0
    assert hardware.facts['swapfree_mb'] > 0
    assert hardware.facts['processor']
    assert hardware.facts['system_vendor']
    assert hardware.facts['product_name']
    assert hardware.facts['product_serial']
    assert hardware.facts['product_uuid']
    assert hardware.facts['product_version']


# Generated at 2022-06-17 00:14:07.194887
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 15984
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['product_name'] == 'MacBookPro11,3'

# Generated at 2022-06-17 00:14:11.191685
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_hw = NetBSDHardware()
    netbsd_hw.module = MagicMock()
    netbsd_hw.module.get_bin_path.return_value = '/usr/bin/dmidecode'
    netbsd_hw.module.run_command.return_value = (0, '', '')
    netbsd_hw.populate()
    assert netbsd_hw.facts['devices']['system']['product']['name'] == 'VirtualBox'

# Generated at 2022-06-17 00:14:19.938961
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    hardware.module = MagicMock()
    hardware.module.get_bin_path.return_value = '/bin/cat'
    hardware.module.run_command.return_value = (0, 'MemTotal:        8058288 kB\nSwapTotal:       8388604 kB\nMemFree:         5263740 kB\nSwapFree:        8388604 kB\n', '')
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 7936
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 5134
    assert hardware.facts['swapfree_mb'] == 8192

# Generated at 2022-06-17 00:14:30.715232
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 896
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Marvell'
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:14:41.349651
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hw = NetBSDHardware()
    hw.module = MockModule()
    hw.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '12345678-1234-1234-1234-123456789012',
        'machdep.dmi.system-serial': '1234',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    facts = hw.populate()
    assert facts['processor'] == ['Intel(R) Core(TM) i5-2520M CPU @ 2.50GHz']
    assert facts['processor_cores'] == 2
    assert facts

# Generated at 2022-06-17 00:16:37.454796
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.sysctl = {'machdep.dmi.system-product': 'foo',
                       'machdep.dmi.system-version': 'bar',
                       'machdep.dmi.system-uuid': 'baz',
                       'machdep.dmi.system-serial': 'qux',
                       'machdep.dmi.system-vendor': 'quux'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'foo'
    assert dmi_facts['product_version'] == 'bar'
    assert dmi_facts['product_uuid'] == 'baz'
    assert dmi_facts['product_serial'] == 'qux'

# Generated at 2022-06-17 00:16:49.173000
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Raspberry Pi Foundation'
    assert hardware.facts['product_name'] == 'Raspberry Pi 3 Model B Rev 1.2'

# Generated at 2022-06-17 00:16:55.714306
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 512
    assert hardware.facts['swaptotal_mb'] == 2048
    assert hardware.facts['swapfree_mb'] == 1024
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['system_vendor'] == 'Apple Inc.'

# Generated at 2022-06-17 00:17:02.949323
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.module.get_file_lines = Mock(return_value=['MemTotal:        8098376 kB',
                                                        'MemFree:          926552 kB',
                                                        'SwapTotal:       8388604 kB',
                                                        'SwapFree:        8388604 kB'])
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 7938
    assert memory_facts['memfree_mb'] == 906
    assert memory_facts['swaptotal_mb'] == 8192
    assert memory_facts['swapfree_mb'] == 8192


# Generated at 2022-06-17 00:17:09.072048
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    netbsd_hw = NetBSDHardware()
    memory_facts = netbsd_hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['memfree_mb'] == 7072
    assert memory_facts['swaptotal_mb'] == 8192
    assert memory_facts['swapfree_mb'] == 8192

# Generated at 2022-06-17 00:17:14.814267
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    netbsd_hw = NetBSDHardware(module)
    netbsd_hw.populate()
    assert netbsd_hw.facts['processor_count'] == 1
    assert netbsd_hw.facts['processor_cores'] == 1
    assert netbsd_hw.facts['memtotal_mb'] == 1024
    assert netbsd_hw.facts['swaptotal_mb'] == 1024


# Generated at 2022-06-17 00:17:23.023611
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'devices' in facts


# Generated at 2022-06-17 00:17:29.235314
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv6-compatible processor rev 7 (v6l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Raspberry Pi Foundation'
    assert hardware.facts['product_name'] == 'Raspberry Pi Model B Rev 2'
    assert hardware.facts['product_serial'] == '00000000a9e5c8d7'


# Generated at 2022-06-17 00:17:38.436474
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 0 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Marvell'
    assert hardware.facts['product_name'] == 'Kirkwood 88F6281'
    assert hardware.facts['product_serial'] == '1234567890'

# Generated at 2022-06-17 00:17:46.577258
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    facts = hardware.populate()

    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'devices' in facts



# Generated at 2022-06-17 00:19:58.652740
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.populate()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['product_name'] == 'MacBookPro11,1'
    assert hardware.facts['product_serial'] == 'C02PV0R5G8QH'
    assert hardware.facts['product_uuid'] == '6E7F6C6D-C6E1-5E4E-B6E7-6C6DC6E15E4E'


# Generated at 2022-06-17 00:20:05.166486
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._platform == 'NetBSD'
    assert netbsd_hardware_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:20:10.870620
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.populate()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 7074
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['system_vendor'] == 'LENOVO'
    assert hardware.facts['product_name'] == '20BWS0CL00'
    assert hardware.facts['product_serial'] == 'R9F2N3C'

# Generated at 2022-06-17 00:20:13.979071
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz']


# Generated at 2022-06-17 00:20:18.754551
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '1a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d',
        'machdep.dmi.system-serial': '0123456789abcdef',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()

# Generated at 2022-06-17 00:20:24.243400
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz', 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz']


# Generated at 2022-06-17 00:20:32.993640
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 14096
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['product_name'] == 'MacBookPro11,1'

# Generated at 2022-06-17 00:20:44.519601
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 912
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Marvell'
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_version'] == '1.0'

# Generated at 2022-06-17 00:20:54.710051
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    facts = hardware.populate()
    assert facts['processor_cores'] == 'NA'
    assert facts['processor_count'] == 1
    assert facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert facts['memtotal_mb'] == 1024
    assert facts['swaptotal_mb'] == 2048
    assert facts['memfree_mb'] == 512
    assert facts['swapfree_mb'] == 1024
    assert facts['system_vendor'] == 'Allwinner Technology'
    assert facts['product_name'] == 'sun7i'
    assert facts['product_version'] == '1.0'
    assert facts['product_serial'] == '00000000'

# Generated at 2022-06-17 00:20:59.026084
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 4
