

# Generated at 2022-06-17 00:13:22.241092
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw_collector = NetBSDHardwareCollector()
    assert netbsd_hw_collector._platform == 'NetBSD'
    assert netbsd_hw_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:13:35.005875
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz']
    assert hardware.facts['memtotal_mb'] == 7984
    assert hardware.facts['memfree_mb'] == 7984
    assert hardware.facts['swaptotal_mb'] == 8191
    assert hardware.facts['swapfree_mb'] == 8191
    assert hardware.facts['system_vendor'] == 'Apple Inc.'
    assert hardware.facts['product_name'] == 'Macmini5,1'
    assert hardware.facts['product_version'] == '1.0'


# Generated at 2022-06-17 00:13:43.953361
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '12345678-1234-1234-1234-123456789abc',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'VirtualBox'
    assert dmi_facts['product_version'] == '1.2'

# Generated at 2022-06-17 00:13:55.938788
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 7936
    assert hardware.facts['memfree_mb'] == 7095
    assert hardware.facts['swaptotal_mb'] == 8191
    assert hardware.facts['swapfree_mb'] == 8191
    assert hardware.facts['product_name'] == 'MacBookPro11,1'
    assert hardware.facts['product_serial'] == 'C02PJ1JTG8WM'

# Generated at 2022-06-17 00:14:01.504291
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'devices' in facts



# Generated at 2022-06-17 00:14:04.596560
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz', 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz']

# Generated at 2022-06-17 00:14:14.198481
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 2
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8096
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['product_name'] == 'MacBookPro11,1'

# Generated at 2022-06-17 00:14:16.783370
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw_collector = NetBSDHardwareCollector()
    assert netbsd_hw_collector._platform == 'NetBSD'
    assert netbsd_hw_collector._fact_class == NetBSDHardware

# Generated at 2022-06-17 00:14:26.526846
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class MockModule:
        def __init__(self):
            self.params = {}

    class MockSysctl:
        def __init__(self):
            self.sysctl = {
                'machdep.dmi.system-product': 'ThinkPad T430',
                'machdep.dmi.system-version': 'Not Available',
                'machdep.dmi.system-uuid': 'C9A9C9A9-C9A9-C9A9-C9A9-C9A9C9A9C9A9',
                'machdep.dmi.system-serial': 'R9A9R9A9R9A9',
                'machdep.dmi.system-vendor': 'LENOVO',
            }


# Generated at 2022-06-17 00:14:34.798441
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'mounts' in facts
    assert 'product_name' in facts
    assert 'product_version' in facts
    assert 'product_uuid' in facts
    assert 'product_serial' in facts
    assert 'system_vendor' in facts

# Generated at 2022-06-17 00:16:29.219125
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()

    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'MacBookPro11,1'
    assert hardware.facts['product_serial'] == 'C02PQ0GUDVH7'

# Generated at 2022-06-17 00:16:36.117124
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']


# Generated at 2022-06-17 00:16:41.270989
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['memtotal_mb'] == 992
    assert hardware.facts['memfree_mb'] == 992
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_version'] == '1.0'
    assert hardware.facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert hardware

# Generated at 2022-06-17 00:16:49.696897
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'devices' in facts


# Generated at 2022-06-17 00:16:55.018317
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = NetBSDHardware().get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0
    assert cpu_facts['processor']

# Generated at 2022-06-17 00:16:58.792578
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = NetBSDHardware().get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']

# Generated at 2022-06-17 00:17:04.890964
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.populate()

    assert hardware.facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 512
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['product_name'] == 'SheevaPlug'
    assert hardware.facts['product_serial'] == '1234567890'
    assert hardware.facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-17 00:17:15.309153
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    netbsd_hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '00000000-0000-0000-0000-000000000000',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = netbsd_hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'VirtualBox'
    assert dmi_facts['product_version'] == '1.2'

# Generated at 2022-06-17 00:17:25.536954
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = NetBSDHardware(module)
    hardware.sysctl = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-version': '1.2',
        'machdep.dmi.system-uuid': '12345678-1234-1234-1234-123456789012',
        'machdep.dmi.system-serial': '0',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'VirtualBox'
    assert dmi_facts['product_version'] == '1.2'

# Generated at 2022-06-17 00:17:33.617498
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware_facts = NetBSDHardware()
    hardware_facts.populate()
    assert hardware_facts.data['processor']
    assert hardware_facts.data['processor_cores']
    assert hardware_facts.data['processor_count']
    assert hardware_facts.data['memtotal_mb']
    assert hardware_facts.data['memfree_mb']
    assert hardware_facts.data['swaptotal_mb']
    assert hardware_facts.data['swapfree_mb']
    assert hardware_facts.data['devices']

# Generated at 2022-06-17 00:21:29.818632
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware_collector = NetBSDHardwareCollector()
    assert netbsd_hardware_collector._fact_class == NetBSDHardware
    assert netbsd_hardware_collector._platform == 'NetBSD'

# Generated at 2022-06-17 00:21:37.189317
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = MagicMock()
    hardware.module.get_bin_path.return_value = '/sbin/dmidecode'
    hardware.module.run_command.return_value = (0, '', '')
    hardware.module.params = {'gather_timeout': 10}
    hardware.populate()
    assert hardware.facts['devices']['system']['product']['name'] == 'VirtualBox'
    assert hardware.facts['devices']['system']['product']['serial'] == '0'
    assert hardware.facts['devices']['system']['product']['uuid'] == '0'
    assert hardware.facts['devices']['system']['product']['vendor'] == 'innotek GmbH'