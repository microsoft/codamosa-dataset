

# Generated at 2022-06-20 17:29:35.350672
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    NetBSDHardware.MEMORY_FACTS = ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']
    hardware = NetBSDHardware()
    hardware.module = MockModule()
    hardware.module.get_file_lines = Mock(return_value=MOCK_MEMINFO_LINES)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == MEM_TOTAL
    assert memory_facts['swaptotal_mb'] == SWAP_TOTAL
    assert memory_facts['memfree_mb'] == MEM_FREE
    assert memory_facts['swapfree_mb'] == SWAP_FREE



# Generated at 2022-06-20 17:29:40.169006
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    class module():
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['']

    netbsd_hardware = NetBSDHardware(module)
    netbsd_hardware.get_memory_facts()



# Generated at 2022-06-20 17:29:41.724944
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsd_hardware = NetBSDHardware()


# Generated at 2022-06-20 17:29:52.920181
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    netbsd_hw = NetBSDHardware({'module_setup': True})
    mt_file = '/sys/devices/system/cpu/microcode/reload'

    # We can't use the real /proc/cpuinfo string as it would be different
    # for each machine.
    # We don't want to use a mock for get_file_content() because we want
    # to test the behaviour with an empty file.
    # We can't use the real /sys/devices/system/cpu/microcode/reload string
    # as it would be different for each machine.
    # So we mock both.

# Generated at 2022-06-20 17:29:58.014580
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    hardware_facts = NetBSDHardware(module).populate()
    expected_facts = {
        'system_vendor': 'Vendor string',
        'product_name': 'Product Name',
        'product_version': 'Version',
        'product_serial': 'Serial Number',
        'product_uuid': 'UUID',
    }

    for key in expected_facts:
        assert hardware_facts[key] == expected_facts[key]

# Mock module

# Generated at 2022-06-20 17:30:02.020964
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hw = NetBSDHardware()
    h = hw.populate()
    assert h['processor_count'] == 1
    assert h['processor_cores'] == 1
    assert h['memtotal_mb'] > 0

# Generated at 2022-06-20 17:30:13.338438
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    # Set of return values for mocked methods
    mocked_module = 'module'  # We test the class directly, here
    mocked_sysctl = {
        'machdep.dmi.system-product': 'System Product',
        'machdep.dmi.system-version': 'System Version',
        'machdep.dmi.system-uuid': 'System UUID',
        'machdep.dmi.system-serial': 'System Serial',
        'machdep.dmi.system-vendor': 'System Vendor',
    }

# Generated at 2022-06-20 17:30:21.643552
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    meminfo = ['MemTotal:        2048 kB',
               'MemFree:          256 kB',
               'SwapTotal:       16384 kB',
               'SwapFree:         512 kB']

    hardware = NetBSDHardware()
    hardware.file_exists = lambda f: True
    hardware.get_file_lines = lambda f: meminfo
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 2
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 16
    assert facts['swapfree_mb'] == 0



# Generated at 2022-06-20 17:30:26.457868
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    h = NetBSDHardware()
    facts = h.get_cpu_facts()
    assert(facts['processor_count'] >= 1)
    assert(isinstance(facts['processor'], list))
    assert(isinstance(facts['processor'][0], str))


# Generated at 2022-06-20 17:30:28.163060
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsd_hw = NetBSDHardware({})
    assert netbsd_hw.platform == 'NetBSD'

# Generated at 2022-06-20 17:32:09.542834
# Unit test for method populate of class NetBSDHardware

# Generated at 2022-06-20 17:32:16.466312
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    memory_facts = NetBSDHardware().get_memory_facts()

    assert 'memfree_mb' in memory_facts
    assert isinstance(memory_facts['memfree_mb'], int)

    assert 'memtotal_mb' in memory_facts
    assert isinstance(memory_facts['memtotal_mb'], int)

    assert 'swapfree_mb' in memory_facts
    assert isinstance(memory_facts['swapfree_mb'], int)

    assert 'swaptotal_mb' in memory_facts
    assert isinstance(memory_facts['swaptotal_mb'], int)

# Generated at 2022-06-20 17:32:19.044062
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    module = None
    hardwareCollector = NetBSDHardwareCollector(module)
    assert hardwareCollector._platform == 'NetBSD'
    assert hardwareCollector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 17:32:30.718569
# Unit test for method get_dmi_facts of class NetBSDHardware

# Generated at 2022-06-20 17:32:37.849250
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class TestModule:
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def run_command(self, cmd, check_rc=True):
            if check_rc and cmd[0] != '/sbin/sysctl':
                raise Exception('unexpected command: %s' % ' '.join(cmd))
            return self.sysctl

        def fail_json(self, *args, **kwargs):
            raise Exception('fail_json(%s, %s)' % (args, kwargs))


# Generated at 2022-06-20 17:32:39.537223
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware_facts = NetBSDHardware()
    hardware_facts.populate()

# Generated at 2022-06-20 17:32:42.047926
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw_collector = NetBSDHardwareCollector()
    assert netbsd_hw_collector._fact_class is NetBSDHardware
    assert netbsd_hw_collector._platform == 'NetBSD'

# Generated at 2022-06-20 17:32:46.988362
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    """
    Constructor test to check the class NetBSDHardware is working.
    """
    mod = AnsibleModule(
        argument_spec={}
    )
    # Test the constructor and the 'get_mount_facts' method
    netbsd_hardware = NetBSDHardware(mod)
    assert netbsd_hardware is not False

# Generated at 2022-06-20 17:32:50.468574
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    """
    Test module for NetBSD hardware class
    """
    hardware = NetBSDHardware()
    
    assert hardware.platform == 'NetBSD'
    assert hardware.MEMORY_FACTS == ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']

# Generated at 2022-06-20 17:32:53.046855
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    hardware.get_memory_facts()
    if hardware.memtotal_mb >= 0:
        print("Memory facts test case pass")



# Generated at 2022-06-20 17:34:46.660332
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hw = NetBSDHardware()
    assert hw.platform == 'NetBSD'
    assert hw.MEMORY_FACTS == ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']

# Generated at 2022-06-20 17:34:47.482631
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    NetBSDHardware()


# Generated at 2022-06-20 17:34:53.461176
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()

    populate_facts = hardware.populate()

    assert 'memtotal_mb' in populate_facts
    assert 'memfree_mb' in populate_facts
    assert 'swapfree_mb' in populate_facts
    assert 'swaptotal_mb' in populate_facts
    assert 'processor' in populate_facts
    assert 'processor_cores' in populate_facts
    assert 'processor_count' in populate_facts
    assert 'devices' in populate_facts


# Generated at 2022-06-20 17:35:01.844374
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    fact_module = AnsibleModuleMock()
    fact_module.params = {}

# Generated at 2022-06-20 17:35:10.926047
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    class ModuleMock(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')
    facts = NetBSDHardware(module=ModuleMock(path=['/fake']))
    x = facts.get_cpu_facts()
    assert x == {'processor': ['Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz'],
                 'processor_count': 1,
                 'processor_cores': 2}
    return x

# Generated at 2022-06-20 17:35:19.998909
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    module = None
    collected_facts = None
    data_mock = ['MemTotal:       16341940 kB', 'SwapTotal:      16672996 kB', 'MemFree:         1053308 kB', 'SwapFree:       16672996 kB']
    netbsd_hardware = NetBSDHardware(module, collected_facts)
    netbsd_hardware.get_file_lines = lambda filename: data_mock
    memory_facts = netbsd_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 15939
    assert memory_facts['swaptotal_mb'] == 16260
    assert memory_facts['memfree_mb'] == 1026
    assert memory_facts['swapfree_mb'] == 16260


# Generated at 2022-06-20 17:35:30.045823
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    meminfo_content = """MemTotal:       8178392 kB
SwapTotal:      4194296 kB
MemFree:        271112 kB
SwapFree:       1617716 kB
"""

    collected_facts = {
        'hw': NetBSDHardware({'module': None}),
    }
    NetBSDHardware._get_file_lines_stub = classmethod(lambda cls, path: meminfo_content.splitlines())
    facts = NetBSDHardware().populate()
    assert facts['memtotal_mb'] == 8178392 // 1024
    assert facts['swaptotal_mb'] == 4194296 // 1024
    assert facts['memfree_mb'] == 271112 // 1024
    assert facts['swapfree_mb'] == 1617716 // 1024


# Generated at 2022-06-20 17:35:32.178848
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    ins = NetBSDHardware() 
    res = ins.get_cpu_facts()
    assert res['processor_count'] > 0
    return


# Generated at 2022-06-20 17:35:34.341414
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hardware_facts = NetBSDHardware({})
    assert hardware_facts.platform == 'NetBSD'

# Generated at 2022-06-20 17:35:35.780354
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = FakeModule()
    NetBSDHardware().populate()