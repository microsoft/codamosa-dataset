

# Generated at 2022-06-20 17:28:50.838850
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd = NetBSDHardwareCollector()
    assert isinstance(netbsd, NetBSDHardwareCollector)
    assert netbsd._platform == 'NetBSD'


# Generated at 2022-06-20 17:28:51.961821
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsd_facts = NetBSDHardware()
    assert netbsd_facts.get('processor_count') > 0
    assert ('model_name' in netbsd_facts.get('processor'))

# Generated at 2022-06-20 17:28:54.419582
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hardware = NetBSDHardware({})
    assert hardware.facts['distribution'] == 'NetBSD'


# Generated at 2022-06-20 17:29:01.742900
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    hardware = NetBSDHardware(dict(), dict())
    hardware.sysctl = {
                        'machdep.dmi.system-product': 'foo',
                        'machdep.dmi.system-version': '1.0',
                        'machdep.dmi.system-uuid': '1',
                        'machdep.dmi.system-serial': 'A0A0',
                        'machdep.dmi.system-vendor': 'bar'
                      }
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['product_name'] == 'foo'
    assert dmi_facts['product_version'] == '1.0'
    assert dmi_facts['product_uuid'] == '1'

# Generated at 2022-06-20 17:29:03.906438
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    netbsd_hardware = NetBSDHardware()
    assert netbsd_hardware.get_memory_facts() == {'memtotal_mb': 825, 'swaptotal_mb': 0, 'memfree_mb': 717, 'swapfree_mb': 0}


# Generated at 2022-06-20 17:29:10.366319
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    """
    Test the constructor of class NetBSDHardwareCollector
    """
    # Init the NetBSDHardwareCollector object
    nhc = NetBSDHardwareCollector()
    # Check the instance
    assert isinstance(nhc, HardwareCollector)
    assert isinstance(nhc, NetBSDHardwareCollector)
    # Check the attributes
    assert isinstance(nhc._fact_class, NetBSDHardware)
    assert nhc._platform == 'NetBSD'


# Generated at 2022-06-20 17:29:17.746023
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    content = """MemTotal:        65536 kB
MemFree:          3584 kB
SwapTotal:      1179648 kB
SwapFree:       1009672 kB"""
    test_hardware = NetBSDHardware({})
    test_hardware.module = None
    result = test_hardware.get_memory_facts()
    assert result.get('memtotal_mb', 0) == 64
    assert result.get('memfree_mb', 0) == 3
    assert result.get('swaptotal_mb', 0) == 1152
    assert result.get('swapfree_mb', 0) == 984

# Generated at 2022-06-20 17:29:19.360413
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = NetBSDHardware({})
    result = hardware.get_cpu_facts()
    assert result['processor_count'] == 1
    assert result['processor_cores'] == 1



# Generated at 2022-06-20 17:29:28.489699
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    class ModuleStub:
        def fail_json(self, msg, **kwargs):
            raise AssertionError(msg)

    class NetBSDHardwareStub(NetBSDHardware):
        def __init__(self, module):
            self.module = module

    expected_dmi_facts = {
        'product_name': 'System Product Name',
        'product_version': 'System Version',
        'product_serial': 'System Serial Number',
        'product_uuid': 'System UUID',
        'system_vendor': 'System Vendor'
    }
    assert NetBSDHardwareStub(ModuleStub()).get_dmi_facts() == expected_dmi_facts

# Generated at 2022-06-20 17:29:41.020163
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    netbsd_hw = NetBSDHardware()

    # Test that fake data are well parsed

# Generated at 2022-06-20 17:30:35.509589
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    facts = NetBSDHardwareCollector()
    assert facts is not None


# Generated at 2022-06-20 17:30:37.066809
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    assert NetBSDHardwareCollector.platform == "NetBSD"
    assert NetBSDHardwareCollector._platform == "NetBSD"

# Generated at 2022-06-20 17:30:46.106877
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    # Test if processor_cores and processor_count are correctly calculated in get_cpu_facts method
    module = AnsibleModule(argument_spec={})
    netbsd_hardware_cls = NetBSDHardware(module)

    # Test with 1 socket and 1 core
    get_file_lines_mock = MagicMock(return_value=['cpu cores: 1', 'physical id: 0', 'model name: Intel(R) Core(TM) i7 CPU 920 @ 2.67GHz'])
    with patch('ansible.module_utils.facts.hardware.netbsd.get_file_lines', get_file_lines_mock):
        cpu_facts = netbsd_hardware_cls.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-20 17:30:51.749157
# Unit test for method get_cpu_facts of class NetBSDHardware

# Generated at 2022-06-20 17:31:00.403195
# Unit test for method get_cpu_facts of class NetBSDHardware

# Generated at 2022-06-20 17:31:06.319748
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware_facts = NetBSDHardware()
    assert hardware_facts == {
        'devices': {},
        'processor': [],
        'processor_cores': 'NA',
        'processor_count': 0,
        'memfree_mb': None,
        'memtotal_mb': None,
        'swapfree_mb': None,
        'swaptotal_mb': None
    }

# Generated at 2022-06-20 17:31:14.003916
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    netbsd_hardware_facts = NetBSDHardware()
    result = netbsd_hardware_facts.get_cpu_facts()
    cpuinfo_data = open("/proc/cpuinfo", "r").readlines()
    cpuinfo_proc = []
    cpuinfo_cores = []
    cpuinfo_physical_ids = []
    for data in cpuinfo_data:
        if "model name" in data:
            cpuinfo_proc.append(data.split(":")[1].split("\n")[0].strip())
        if "processor" in data:
            cpuinfo_physical_ids.append(data.split(":")[1].split("\n")[0].strip())

# Generated at 2022-06-20 17:31:16.460526
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hardware_facts = NetBSDHardware()
    assert hardware_facts.populate()['processor_cores'] is not 'NA'



# Generated at 2022-06-20 17:31:20.950256
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hardware = NetBSDHardwareCollector(None)
    assert netbsd_hardware._platform == 'NetBSD'
    assert netbsd_hardware._fact_class.platform == 'NetBSD'



# Generated at 2022-06-20 17:31:22.784586
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsd_hardware = NetBSDHardware({})
    assert netbsd_hardware.get_platform() == 'NetBSD'


# Generated at 2022-06-20 17:32:19.576170
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    test_facts = {}
    test_facts['processor'] = ['Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz']
    test_facts['processor_cores'] = 2
    test_facts['processor_count'] = 2
    test_facts['memfree_mb'] = 675
    test_facts['memtotal_mb'] = 4123
    test_facts['swapfree_mb'] = 1535
    test_facts['swaptotal_mb'] = 1535
    test_facts['devices'] = {}

# Generated at 2022-06-20 17:32:31.089407
# Unit test for method get_cpu_facts of class NetBSDHardware

# Generated at 2022-06-20 17:32:42.322194
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = MagicMock()
    hw = NetBSDHardware(module)
    hw.get_cpu_facts = MagicMock()
    hw.get_cpu_facts.return_value = dict(cpu1='cpu1')
    hw.get_memory_facts = MagicMock()
    hw.get_memory_facts.return_value = dict(mem1='mem1')
    hw.get_mount_facts = MagicMock()
    hw.get_mount_facts.return_value = dict(mount1='mount1')
    hw.get_dmi_facts = MagicMock()
    hw.get_dmi_facts.return_value = dict(dmi1='dmi1')
    collected_facts = dict(collected1='collected1')
    facts = hw.populate

# Generated at 2022-06-20 17:32:50.393903
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hw = NetBSDHardware()
    hw.module = DummyModule()
    collected_facts = {'ansible_architecture': 'amd64', 'ansible_machine_id': 'some_id',
                       'ansible_system': 'NetBSD', 'ansible_machine': 'amd64'}
    hw.populate(collected_facts)
    facts = hw.get_cpu_facts()
    assert 'Intel(R) Core(TM) i7-8550U CPU @ 1.80GHz' in facts['processor']
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 8

# Generated at 2022-06-20 17:32:54.417938
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    netbsd_facts = NetBSDHardware()
    facts = netbsd_facts.populate()
    assert len(facts) == 8
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts

# Generated at 2022-06-20 17:33:04.841152
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    mock_lines = [
        "MemTotal:        6071692 kB\n",
        "MemFree:         2538224 kB\n",
        "Cached:          1129940 kB\n",
        "SwapCached:            0 kB\n",
        "SwapTotal:             0 kB\n",
        "SwapFree:              0 kB\n"
    ]

    nh = NetBSDHardware()
    memory_facts = nh.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 5942
    assert memory_facts['memfree_mb'] == 2470
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-20 17:33:05.411206
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    NetBSDHardware()

# Generated at 2022-06-20 17:33:14.871401
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    from ansible.module_utils.facts.hardware.netbsd import NetBSDHardware
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.sysctl import get_sysctl
    import os

    nbsd_hw = NetBSDHardware({})
    nbsd_hw._module.params['gather_subset'] = ['all']

    # test get_cpu_facts()
    os.access = lambda f: True
    get_file_lines = lambda f: ['processor : 0', 'model name : Intel(R) Celeron(R) CPU N2930 @ 1.83GHz']

# Generated at 2022-06-20 17:33:16.822594
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsd_hw = NetBSDHardware({})
    assert netbsd_hw.platform == 'NetBSD'


# Generated at 2022-06-20 17:33:19.799420
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hardware_obj = NetBSDHardware()
    assert hardware_obj.platform == 'NetBSD'
    hardware_obj.populate()

# Generated at 2022-06-20 17:35:30.627855
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    import json
    from ansible.module_utils.facts.hardware.netbsd import NetBSDHardware

# Generated at 2022-06-20 17:35:35.405837
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    test_cpu_info = NetBSDHardware()
    cpu_facts = test_cpu_info.get_cpu_facts()

    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['ARMv7 Processor rev 1 (v7l)']

# Generated at 2022-06-20 17:35:43.801234
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    hardware = NetBSDHardware()
    hardware.module = MagicMock()
    hardware.module.get_bin_path.side_effect = lambda arg, *args, **kwargs: arg
    hardware.module.run_command.return_value = (
        0,
        """
machdep.dmi.system-vendor = foo
machdep.dmi.system-product = bar
machdep.dmi.system-version = baz
machdep.dmi.system-uuid = quux
machdep.dmi.system-serial = quuz
""",
        ""
    )
    results = hardware.get_dmi_facts()

# Generated at 2022-06-20 17:35:46.577005
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsd = NetBSDHardware(dict())
    assert netbsd.platform == 'NetBSD'
    assert netbsd.MEMORY_FACTS == ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']

# Generated at 2022-06-20 17:35:51.529586
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    hardware = NetBSDHardware()
    hardware.get_cpu_facts = lambda self: {'processor': ['Intel(R) Core(TM)2 Quad CPU Q9450 2.66GHz'], 'processor_count': 4, 'processor_cores': 4}
    hardware.get_memory_facts = lambda self: {'memtotal_mb': 8192, 'swaptotal_mb': 8192, 'memfree_mb': 6553, 'swapfree_mb': 8192}
    actual = hardware.get_memory_facts()
    expected = {'memtotal_mb': 8192, 'swaptotal_mb': 8192, 'memfree_mb': 6553, 'swapfree_mb': 8192}
    assert actual == expected

# Generated at 2022-06-20 17:35:54.576345
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    module = AnsibleModuleMock()
    hardware = NetBSDHardware(module)
    assert hardware is not None



# Generated at 2022-06-20 17:36:02.139071
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hardware = NetBSDHardware()
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'mounts' in facts
    assert 'system_vendor' in facts
    assert 'product_name' in facts
    assert 'product_serial' in facts
    assert 'product_uuid' in facts
    assert 'product_version' in facts

# Generated at 2022-06-20 17:36:11.753263
# Unit test for method get_cpu_facts of class NetBSDHardware

# Generated at 2022-06-20 17:36:23.114539
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    """
    NetBSDHardware - Populate (method)

    Test if module generate 'ansible_facts'
    """
    module = AnsibleModuleMock({'ansible_facts': {}})

    module.warn = mock.Mock()
    nh = NetBSDHardware()
    nh.module = module
    nh.sysctl = {}

    nh.get_cpu_facts = mock.Mock(return_value={})
    nh.get_memory_facts = mock.Mock(return_value={})
    nh.get_mount_facts = mock.Mock(return_value={})
    nh.get_dmi_facts = mock.Mock(return_value={})

    nh.populate()

    assert module.fail_json.called is False
    assert module.warn.called is False

# Generated at 2022-06-20 17:36:29.800779
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    import unittest

    class MockModule(object):
        def __init__(self, module_utils):
            self.params = {}
            self.module_utils = module_utils

    nh = NetBSDHardware()
    mock_module = MockModule(nh)
    nh.module = mock_module

    class TestNetBSDHardware(unittest.TestCase):
        def test_get_dmi_facts(self):
            dmi_facts = nh.get_dmi_facts()
            self.assertIsInstance(dmi_facts, dict)
            for fact in ['product_name', 'product_version', 'product_uuid',
                         'product_serial', 'system_vendor']:
                self.assertIn(fact, dmi_facts)

    suite = unittest.TestLoader().loadTests