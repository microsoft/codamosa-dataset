

# Generated at 2022-06-20 17:29:33.330567
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    nhw = NetBSDHardware(dict())
    assert nhw.sysctl == dict()
    assert nhw.platform == 'NetBSD'
    assert nhw.MEMORY_FACTS == ['MemTotal', 'SwapTotal', 'MemFree', 'SwapFree']

# Generated at 2022-06-20 17:29:46.206852
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    hardware = NetBSDHardware()
    hardware.module = None

# Generated at 2022-06-20 17:29:53.910902
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    m = NetBSDHardware()
    m.module = type('obj', (object,), {})

    m.module.params = {}
    m.module.warn = lambda *args, **kwargs: None
    m.module.fail_json = lambda *args, **kwargs: None
    m.module.exit_json = lambda *args, **kwargs: None
    m.module.run_command = lambda *args, **kwargs: (0, '/proc/cpuinfo', '')

    assert m.get_cpu_facts() == {'processor': [''], 'processor_count': 1, 'processor_cores': 'NA'}

# Generated at 2022-06-20 17:29:59.726400
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    m = NetBSDHardware({'ansible_facts': {'machdep': {'dmi': {'system-product': 'HVM domU',
                                                             'system-version': '1.0',
                                                             'system-uuid': '00000000000000000000000000000001',
                                                             'system-serial': '0x0000000000001',
                                                             'system-vendor': 'Xen'}}}})
    assert 'product_name' in m.get_dmi_facts()
    assert 'product_version' in m.get_dmi_facts()
    assert 'product_uuid' in m.get_dmi_facts()
    assert 'product_serial' in m.get_dmi_facts()
    assert 'system_vendor' in m.get_dmi_facts()

# Generated at 2022-06-20 17:30:03.400769
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw_col = NetBSDHardwareCollector()
    assert netbsd_hw_col._platform == 'NetBSD'
    assert netbsd_hw_col._fact_class is NetBSDHardware

# Generated at 2022-06-20 17:30:04.796451
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    obj = NetBSDHardwareCollector()
    assert obj.platform == 'NetBSD'

# Generated at 2022-06-20 17:30:16.238880
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    # Expected result:
    meminfo = {
        'memtotal_mb': 2,
        'swaptotal_mb': 0,
        'memfree_mb': 0,
        'swapfree_mb': 0
        }

    fake_meminfo = '/tmp/fake_meminfo.txt'
    fake_meminfo_content = '''MemTotal:         2 kB
MemFree:          0 kB
SwapTotal:        0 kB
SwapFree:         0 kB'''

    with open(fake_meminfo, 'w') as f:
        f.write(fake_meminfo_content)
    os.chmod(fake_meminfo, 0o644)

    assert NetBSDHardware().get_memory_facts(fake_meminfo) == meminfo
    os.remove(fake_meminfo)

# Generated at 2022-06-20 17:30:24.391352
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    test_dir = "tests/data/ansible_collections/ansible/community/plugins/modules/network/ios/test/unit/module_utils/facts/hardware/netbsd"
    with open(test_dir + "/meminfo", "r") as meminfo_file:
        meminfo = meminfo_file.read()

    mh = NetBSDHardware(None)
    test_mem_facts = dict(MemTotal_mb=4608,
                          SwapTotal_mb=4096,
                          MemFree_mb=4089,
                          SwapFree_mb=4096)
    mem_facts = mh.get_memory_facts(meminfo)
    assert mem_facts == test_mem_facts

# Generated at 2022-06-20 17:30:30.336973
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hardware_facts = NetBSDHardware()

    # Test for sysctl_facts
    assert not hardware_facts.sysctl

    # Test for cpu_facts
    assert hardware_facts.cpu_facts is None

    # Test for memory_facts
    assert hardware_facts.memory_facts is None

    # Test for dmi_facts
    assert hardware_facts.dmi_facts is None

    # Test for shell_facts
    assert hardware_facts.shell_facts is None



# Generated at 2022-06-20 17:30:39.145404
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    cpu_facts = {}
    netbsd_hardware = NetBSDHardware()
    cpu_facts = netbsd_hardware.get_cpu_facts()

    assert type(cpu_facts) is dict
    if 'processor' in cpu_facts:
        assert type(cpu_facts['processor']) is list
        assert type(cpu_facts['processor'][0]) is str
    if 'processor_count' in cpu_facts:
        assert type(cpu_facts['processor_count']) is int
    if 'processor_cores' in cpu_facts:
        assert type(cpu_facts['processor_cores']) is int or type(cpu_facts['processor_cores']) is str



# Generated at 2022-06-20 17:32:13.223501
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hwcollector = NetBSDHardwareCollector()
    assert netbsd_hwcollector._fact_class == NetBSDHardware
    assert netbsd_hwcollector._platform == 'NetBSD'

# Generated at 2022-06-20 17:32:15.378015
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsd = NetBSDHardware()
    if not netbsd.sysctl:
        return False
    if not netbsd.MEMORY_FACTS:
        return False

# Generated at 2022-06-20 17:32:27.321031
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    mod_mock = MagicMock()
    mod_mock.params = {'gather_subset': ['!all', 'hardware']}
    netbsd_hw = NetBSDHardware(mod_mock)
    netbsd_hw.get_cpu_facts = MagicMock(return_value={'processor': '2.7 GHz'})
    netbsd_hw.get_memory_facts = MagicMock(return_value={'memtotal_mb':8192})
    netbsd_hw.get_mount_facts = MagicMock(return_value={'mounts': ['A']})
    netbsd_hw.get_dmi_facts = MagicMock(return_value={'product_name': '201'})

# Generated at 2022-06-20 17:32:33.210840
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    hardware = Hardware()
    cpu_facts = hardware.get_cpu_facts()

    assert type(cpu_facts) == dict
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'][0] == 'Intel(R) Core(TM) i5-6500 CPU @ 3.20GHz'
    assert cpu_facts['processor'][1] == 'Intel(R) Core(TM) i5-6500 CPU @ 3.20GHz'

# Generated at 2022-06-20 17:32:38.356664
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    h = NetBSDHardware()
    facts = h.get_cpu_facts()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert facts['processor_cores'] == 'NA'
    assert facts['processor_count'] == 1


# Generated at 2022-06-20 17:32:42.010530
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    nbsd_hw = NetBSDHardware({})
    # we don't have any facts to test for NetBSD
    # so just make sure we don't have any exceptions
    assert len(nbsd_hw.platform) > 0
# end of test_NetBSDHardware


# Generated at 2022-06-20 17:32:51.751693
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware({'ansible_facts': {'machdep': {'dmi': {'system-product': 'VirtualBox',
                                                                          'system-serial': '0',
                                                                          'system-uuid': '7b02f2d8-7a68-4c42-bfb0-d08f9bba75cc',
                                                                          'system-version': 'VirtualBox',
                                                                          'system-vendor': 'innotek GmbH'}}}})

# Generated at 2022-06-20 17:32:55.246048
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    har_obj = NetBSDHardwareCollector()
    assert har_obj.platform == 'NetBSD'


# Generated at 2022-06-20 17:33:01.845786
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    hardware_obj = NetBSDHardware(dict())
    hardware_keys = hardware_obj.populate()

    assert 'devices' in hardware_keys
    assert 'processor' in hardware_keys
    assert 'processor_cores' in hardware_keys
    assert 'processor_count' in hardware_keys
    assert 'swaptotal_mb' in hardware_keys
    assert 'swapfree_mb' in hardware_keys
    assert 'memtotal_mb' in hardware_keys
    assert 'memfree_mb' in hardware_keys

# Generated at 2022-06-20 17:33:10.203588
# Unit test for method get_cpu_facts of class NetBSDHardware
def test_NetBSDHardware_get_cpu_facts():
    module = mock.Mock()
    cpu_facts = NetBSDHardware(module).get_cpu_facts()

    # The module_utils/facts/hardware/netbsd.py module has been tested
    # against netbsd/amd64 8.99.11 running in a virtual machine (QEMU)
    # with 2 CPU sockets x 2 CPU cores.
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == [u'Intel(R) Core(TM) i7-4610M CPU @ 3.00GHz'] * 4

# Generated at 2022-06-20 17:35:06.876859
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    nhc = NetBSDHardwareCollector()
    assert issubclass(nhc._fact_class, NetBSDHardware)

# Generated at 2022-06-20 17:35:08.682962
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_hw_collector = NetBSDHardwareCollector()
    assert netbsd_hw_collector._platform == NetBSDHardware.platform

# Generated at 2022-06-20 17:35:10.965518
# Unit test for constructor of class NetBSDHardware
def test_NetBSDHardware():
    netbsdhw = NetBSDHardware()
    assert netbsdhw.platform == 'NetBSD'


# Generated at 2022-06-20 17:35:16.384053
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    # Calling constructor of class NetBSDHardwareCollector
    netbsd_hw_collector = NetBSDHardwareCollector()
    # Testing attributes of object netbsd_hw_collector
    assert netbsd_hw_collector._fact_class == NetBSDHardware
    assert netbsd_hw_collector._platform == 'NetBSD'

# Generated at 2022-06-20 17:35:28.387240
# Unit test for method populate of class NetBSDHardware
def test_NetBSDHardware_populate():
    module = ansible_module_mock('fake_module')
    get_file_content = mock_open(read_data='/dev/sda1\n')
    get_file_lines = mock_open(read_data='MemTotal:        2053280 kB\n'
                                        'MemFree:         1174540 kB\n'
                                        'MemAvailable:    1645820 kB\n'
                                        'SwapTotal:       2097148 kB\n'
                                        'SwapFree:        2097148 kB\n'
                                        'SwapCached:           0 kB\n')


# Generated at 2022-06-20 17:35:38.299554
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hardware = NetBSDHardware()
    test_sysctl = {
        'machdep.dmi.system-product': 'product name',
        'machdep.dmi.system-version': 'product version',
        'machdep.dmi.system-uuid': 'product uuid',
        'machdep.dmi.system-serial': 'product serial',
        'machdep.dmi.system-vendor': 'system vendor',
    }
    netbsd_hardware.sysctl = test_sysctl
    result = netbsd_hardware.get_dmi_facts()

# Generated at 2022-06-20 17:35:45.326237
# Unit test for method get_dmi_facts of class NetBSDHardware
def test_NetBSDHardware_get_dmi_facts():
    netbsd_hw = NetBSDHardware(module=None)
    netbsd_hw.sysctl = {
        'machdep.dmi.system-product': 'Some product',
        'machdep.dmi.system-version': '1.2.3',
        'machdep.dmi.system-uuid': '01234567-89ab-cdef-0123-456789ABCDEF',
        'machdep.dmi.system-serial': 'system-12345678',
        'machdep.dmi.system-vendor': 'Some vendor',
    }
    dmi_facts = netbsd_hw.get_dmi_facts()
    assert dmi_facts['product_name'] == 'Some product'

# Generated at 2022-06-20 17:35:46.646746
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    netbsd_collector = NetBSDHardwareCollector()
    assert netbsd_collector.platform == "NetBSD"
    assert netbsd_collector._fact_class == NetBSDHardware


# Generated at 2022-06-20 17:35:47.856792
# Unit test for constructor of class NetBSDHardwareCollector
def test_NetBSDHardwareCollector():
    assert NetBSDHardwareCollector._platform == 'NetBSD'
    assert NetBSDHardwareCollector._fact_class == NetBSDHardware

# Generated at 2022-06-20 17:35:55.902582
# Unit test for method get_memory_facts of class NetBSDHardware
def test_NetBSDHardware_get_memory_facts():
    test_path = os.path.join(os.path.dirname(__file__), './outputs')
    test_file = 'NetBSDHardware_get_memory_facts.out'
    test_content = get_file_content(os.path.join(test_path, test_file))
    test_hardware = NetBSDHardware(module=None)
    result = test_hardware.get_memory_facts()

    assert type(result) is dict
    assert result == test_content
