

# Generated at 2022-06-23 21:40:54.560478
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name() in LastName.all()


# Generated at 2022-06-23 21:41:07.222037
# Unit test for method password of class Person
def test_Person_password():
    # Test 1
    # Expected result:
    #   '0+XsVyxc4*pzFlV!@': True
    #   '#': False
    #   '~': False
    #   'NA': False
    password = Person(seed=0).password()
    assert password == "0+XsVyxc4*pzFlV!@",\
        "Test 1 of function password of class Person failed."
    assert len(password) == 20,\
        "Test 2 of function password of class Person failed."

# Generated at 2022-06-23 21:41:08.846378
# Unit test for method views_on of class Person
def test_Person_views_on():
    rd = RandomData()
    assert rd.views_on() != ''

# Generated at 2022-06-23 21:41:20.292269
# Unit test for method telephone of class Person
def test_Person_telephone():
    assert re.fullmatch(r'\d{3}-\d{3}-\d{4}',
                        Person().telephone("###-###-####"))
    assert re.fullmatch(r'\d{3}-\d{3}-\d{4}',
                        Person().telephone("###-###-####"))
    assert re.fullmatch(r'\d{3}-\d{3}-\d{4}',
                        Person().telephone("###-###-####"))
    assert re.fullmatch(r'\d{3}-\d{3}-\d{4}',
                        Person().telephone("###-###-####"))
    assert re.fullmatch(r'\(444\) 222-3333',
                        Person().telephone("(###) ###-####"))
    assert re

# Generated at 2022-06-23 21:41:22.106194
# Unit test for method first_name of class Person
def test_Person_first_name():
    res = Person().first_name()
    assert res == 'Johann'


# Generated at 2022-06-23 21:41:24.616254
# Unit test for method gender of class Person
def test_Person_gender():
    p1 = Person().gender()
    assert (p1 == 'Male' or p1 == 'Female')
test_Person_gender()


# Generated at 2022-06-23 21:41:25.765670
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person(random.random())
    assert isinstance(person.blood_type(), str)

# Generated at 2022-06-23 21:41:32.289141
# Unit test for method name of class Person
def test_Person_name():
    assert Person.name() != ''
    assert Person.name() != None
    assert Person.name(gender = Gender.male) != ''
    assert Person.name(gender = Gender.male) != None
    assert Person.name(gender = Gender.female) != ''
    assert Person.name(gender = Gender.female) != None
    assert Person.name(gender = Gender.other) != ''
    assert Person.name(gender = Gender.other) != None


# Generated at 2022-06-23 21:41:34.896960
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    instance = Person('en')
    instance.random.seed(0)
    result = instance.social_media_profile()
    assert result == 'https://twitter.com/otryme3'


# Generated at 2022-06-23 21:41:39.965148
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with optional arguments
    random_nationality = Person().nationality(gender=Gender.male)
    assert isinstance(random_nationality,str)
    
    # Test with default
    default_nationality = Person().nationality()
    assert isinstance(random_nationality,str) 

# Generated at 2022-06-23 21:41:44.754027
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    zfcs = ['Asexuality',
        'Bisexuality',
        'Heterosexuality',
        'Homosexuality']
    for _ in range(10):
        x = Person().sexual_orientation()
        assert x in zfcs
    print('✔︎ Person.sexual_orientation() - ok')



# Generated at 2022-06-23 21:41:47.522323
# Unit test for method language of class Person
def test_Person_language():
    generator = Generator()
    actual = generator.person.language()
    assert isinstance(actual, str)
    assert 0 < len(actual) <= 22



# Generated at 2022-06-23 21:41:48.301429
# Unit test for method worldview of class Person
def test_Person_worldview():
    worldview = person.Person().worldview()
    assert worldview in worldviews

# Generated at 2022-06-23 21:41:56.372928
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person(random=Random())

    for _ in range(100):
        pattern = person.random.choice(CALLING_CODES)
        mask = person.random.choice(['#', '##', '###', '####'])
        mask = '{}-(###)-###-###'.format(pattern)
        phone = person.telephone(mask)

        assert re.fullmatch(r'\+{0}\(\d{{3}}\)\-\d{{3}}\-\d{{3}}'.format(pattern), phone)

    for _ in range(100):
        phone = person.telephone()

        assert re.fullmatch(r'\+\d+\-\(\d+\)\-\d+\-\d+', phone)



# Generated at 2022-06-23 21:42:02.302991
# Unit test for method name of class Person
def test_Person_name():
    person = Person(random=Random())

    # check first name
    first_name = person.name()
    assert isinstance(first_name, str)

    # check first name by gender
    first_name = person.name(Gender.male)
    assert isinstance(first_name, str)

    first_name = person.name(Gender.female)
    assert isinstance(first_name, str)

    # check first name by unicode gender
    first_name = person.name('male')
    assert isinstance(first_name, str)

    first_name = person.name('female')
    assert isinstance(first_name, str)

    # check first name by int gender
    first_name = person.name(0)
    assert isinstance(first_name, str)


# Generated at 2022-06-23 21:42:10.548619
# Unit test for method title of class Person
def test_Person_title():
    from faker import Faker
    from datetime import datetime
    from random import seed
    from unittest.mock import patch
    from faker.providers.person.en import Provider

    seed(datetime.now())
    fake = Faker(["en_UK"])
    f = Provider(fake)

    with patch('faker.providers.person.en.Provider.surname') as mock_surname:
        mock_surname.return_value = "Bill"
        assert f.title(title_type='prefix') == "Dr."
    
    

# Generated at 2022-06-23 21:42:11.329777
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person.random.choice


# Generated at 2022-06-23 21:42:12.841371
# Unit test for method identifier of class Person
def test_Person_identifier():
    for _ in range(100):
        identifier = Person().identifier('@@-@@/##')
        assert re.fullmatch(r'.{2}-.{2}/.{2}', identifier)



# Generated at 2022-06-23 21:42:16.485823
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from pyfaker.providers.person import Person
    from pyfaker.utils.enumerations import SocialNetwork
    from pyfaker.utils.exceptions import NonEnumerableError
    import re

    p = Person()

    # test use default enum class
    assert p.social_media_profile()
    assert re.match('https://[a-z.]+/[a-z]{3,}', p.social_media_profile())

    # test use enum class SocialNetwork
    assert p.social_media_profile(
            SocialNetwork.LINKEDIN) == 'https://linkedin.com/A254dfg33'



# Generated at 2022-06-23 21:42:19.205847
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person()
    result = p.work_experience()
    assert result is not None


# Generated at 2022-06-23 21:42:29.773036
# Unit test for method political_views of class Person

# Generated at 2022-06-23 21:42:38.109459
# Unit test for method gender of class Person
def test_Person_gender():
    test_cases = set([
        (Person().gender(),
         None,
         None),
        (Person().gender(iso5218=True),
         None,
         None),
        (Person().gender(symbol=True),
         None,
         None)
    ])
    for test_case in test_cases:
        assert test_case[0] in [i.value for i in Gender]
        assert test_case[1] in [0, 1, 2, 9]
        assert test_case[2] in GENDER_SYMBOLS


# Generated at 2022-06-23 21:42:39.443074
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()

    assert person.blood_type().isupper()

# Generated at 2022-06-23 21:42:43.250448
# Unit test for method political_views of class Person
def test_Person_political_views():
    political_views = ['Left-wing', 'Right-wing', 'Centrist', 'Communist', 'Capitalist', 'Authoritarian', 'Anarchist', 'Libertarian', 'Socialist', 'Democrat', 'Republican']
    for i in range(1000):
        assert(Person().political_views() in political_views)


# Generated at 2022-06-23 21:42:46.394454
# Unit test for method first_name of class Person
def test_Person_first_name():
    global data
    data = Person()
    assert data.first_name() == "Johann"



# Generated at 2022-06-23 21:42:48.666890
# Unit test for method gender of class Person
def test_Person_gender():
    gender = Person().gender()
    assert type(gender) is str
    assert gender in GENDER_TITLES

# Generated at 2022-06-23 21:42:54.039776
# Unit test for method last_name of class Person
def test_Person_last_name():
    """Test method last_name of class Person."""
    count = 10
    has_error = False

    fake = Faker()
    fake.add_provider(Person)

    for _ in range(count):
        last_name = fake.last_name()

        if not isinstance(last_name, str):
            has_error = True
            break

    assert not has_error, 'Method test_Person_last_name() has error(s)'

# Generated at 2022-06-23 21:43:04.752924
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person(seed=42)
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'

    p = Person(seed=42)
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'
    assert p.occupation() == 'Caterer'
    
    p = Person(seed=4245)
    assert p.occupation() == 'Financial Investigator'
    assert p.occupation() == 'Financial Investigator'


# Generated at 2022-06-23 21:43:14.582389
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person('en').identifier()[:2] in "0123456789", \
        "Identifier should start with digits"
    assert Person('en').identifier()[2:3] in " -", \
        "Identifier should have a space or symbol '-' at the second place"
    assert Person('en').identifier()[3:4] in "0123456789", \
        "Identifier should have digits after second place"
    assert Person('en').identifier()[4:5] in " -", \
        "Identifier should have symbol '-' or space after digits"
    assert Person('en').identifier()[5:6] in "0123456789", \
        "Identifier should have digits after symbol '-' or space"

# Generated at 2022-06-23 21:43:15.573589
# Unit test for method university of class Person
def test_Person_university():
    for _ in range(100):
        assert Person().university() in Person._data['university']


# Generated at 2022-06-23 21:43:17.128827
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(random=Random())
    assert callable(person.surname)


# Generated at 2022-06-23 21:43:20.504360
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    identifier = p.identifier('##/##/##-##')
    assert re.match('[0-9]{2}/[0-9]{2}/[0-9]{2}-[0-9]{2}', identifier)



# Generated at 2022-06-23 21:43:21.926100
# Unit test for method username of class Person
def test_Person_username():
    x = Person.username("llllllllllllll")
    assert x == "llllllllllllll"
    x = Person.username("AAAAAA")
    assert x == "AAAAAA"



# Generated at 2022-06-23 21:43:29.027836
# Unit test for method name of class Person
def test_Person_name():
    seed(2)
    p = Person()
    assert p.name() == 'Joaquin'
    assert p.name() == 'Frederick'
    assert p.name() == 'Alfred'
    assert p.name() == 'Randolph'
    assert p.name() == 'Robert'
    assert p.name() == 'Ramell'
    assert p.name() == 'Randall'
    assert p.name() == 'Joseph'
    assert p.name() == 'Berry'
    assert p.name() == 'Martin'

# Generated at 2022-06-23 21:43:30.521218
# Unit test for method telephone of class Person
def test_Person_telephone():
    r = Person('en')
    for i in range(1, 10):
        assert r.telephone()

# Generated at 2022-06-23 21:43:43.818878
# Unit test for method gender of class Person
def test_Person_gender():
    for _ in range(10):
        provider = Fake('ru_RU')
        gender = provider.gender()
        assert gender in provider._data['gender']
        assert isinstance(gender, str)
        assert gender == 'male' or gender == 'female'
    # Test iso5218
    for _ in range(10):
        provider = Fake('ru_RU')
        gender = provider.gender(iso5218=True)
        assert gender in [0, 1, 2, 9]
        assert isinstance(gender, int)
        assert gender == 1 or gender == 2
    # Test symbol
    for _ in range(10):
        provider = Fake('ru_RU')
        gender = provider.gender(symbol=True)
        assert gender in GENDER_SYMBOLS
        assert isinstance(gender, str)


# Generated at 2022-06-23 21:43:48.746697
# Unit test for method age of class Person
def test_Person_age():
    for i in range(100):
        min_age = i
        max_age = i + 1
        assert Person.age(min_age=min_age, max_age=max_age) in range(min_age, max_age)


# Generated at 2022-06-23 21:43:50.403623
# Unit test for method title of class Person
def test_Person_title():
    p = Person(random=MockRandom([0.5]))
    assert p.title(gender=Gender.MALE, title_type=TitleType.PREFIX) == 'Dr.'


# Generated at 2022-06-23 21:43:52.505325
# Unit test for method sex of class Person
def test_Person_sex():
    res = Person.sex()
    assert (res in GENDER_SYMBOLS.keys())

# Generated at 2022-06-23 21:43:55.417805
# Unit test for method password of class Person
def test_Person_password():
    p = Person(seed = 1)
    assert p.password(length = 10, hashed = True) == 'a7f0b6f9c7'


# Generated at 2022-06-23 21:44:03.334516
# Unit test for method first_name of class Person
def test_Person_first_name():

    # Simple test with default params
    assert Person().first_name()

    # Test with non-default params
    assert Person().first_name(Gender.Male)
    assert Person().first_name(Gender.Female)

    # Test with non-existent gender
    with pytest.raises(NonEnumerableError):
        Person().first_name('non-existent')

    # Test with non-existent gender
    with pytest.raises(AssertionError):
        Person().first_name(1)



# Generated at 2022-06-23 21:44:05.955460
# Unit test for method gender of class Person
def test_Person_gender():
    result = Person().gender(iso5218=True)
    assert result in (1, 2, 9)
    

# Generated at 2022-06-23 21:44:13.282801
# Unit test for method email of class Person
def test_Person_email():
    pytest.skip()
    provider = Person()

    # Is possible to generate random email
    assert provider.email()
    assert provider.email(unique=True)

    # Is possible to generate random email with a custom domain
    urls = ['google.com', 'example.com']
    assert provider.email(domains=urls)

    # If «unique» is True and the provider was seeded, raise ValueError
    provider.seed('0')

    with pytest.raises(ValueError):
        provider.email(unique=True)


# Generated at 2022-06-23 21:44:14.373272
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person.last_name()

# Generated at 2022-06-23 21:44:23.099311
# Unit test for method telephone of class Person
def test_Person_telephone():
    nose.tools.assert_equal(len(Person().telephone()), 16)
    nose.tools.assert_equal(len(Person().telephone(mask='###-##-##')), 10)
    nose.tools.assert_equal(len(Person().telephone(mask='##-##-##-##')), 10)
    nose.tools.assert_equal(len(Person().telephone(mask='#####')), 5)
    nose.tools.assert_equal(len(Person().telephone(mask='#######')), 7)
    nose.tools.assert_equal(len(Person().telephone(mask='######-##')), 9)
    nose.tools.assert_equal(len(Person().telephone(mask='###### ##')), 9)

# Generated at 2022-06-23 21:44:24.091871
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person().political_views() in _DATA['political_views']

# Generated at 2022-06-23 21:44:29.978806
# Unit test for method username of class Person
def test_Person_username():
    for i in range(10):
        p = Person()
        assert p.username()
        assert p.username('Ud')
        assert p.username('ld')
        assert p.username('U_d')
        assert p.username('U.d')
        assert p.username('UU-d')
        assert p.username('UU.d')
        assert p.username('UU_d')
        assert p.username('U-d')

    with pytest.raises(ValueError):
        p.username('bla')

    with pytest.raises(ValueError):
        p.username('_Ud')

    with pytest.raises(ValueError):
        p.username('dU_')

    with pytest.raises(ValueError):
        p.username('Ud-')


# Generated at 2022-06-23 21:44:38.044695
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    def check_degree(result: str):
        assert result in DEGREES
    p = Person()
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())
    check_degree(p.academic_degree())


# Generated at 2022-06-23 21:44:48.266107
# Unit test for method age of class Person
def test_Person_age():
    # Test of method age of class Person
    def test_age_val():
        """
        Test case with valid value
        """
        person = Person()
        assert person.age(minimum=18, maximum=65) in range(18,65)
    def test_age_val2():
        """
        Test case with valid value
        """
        person = Person()
        assert person.age(minimum=18) in range(18,150)
    def test_age_val3():
        """
        Test case with valid value
        """
        person = Person()
        assert person.age(maximum = 20) in range(0,20)
    def test_age_val4():
        """
        Test case with valid value
        """
        person = Person()

# Generated at 2022-06-23 21:44:54.674529
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    # Test with normal state
    def _(surnames: Union[tuple, list] = ('Turing', 'Berners-Lee', 'Ritchie')):
        assert p.surname(surnames = surnames) in surnames
    # Test with enum Gender
    def _(gender: Gender):
        assert isinstance(p.surname(gender = gender), str)
        assert p.surname(gender = gender) in p._data['surname'][gender.value]
    _(Gender.Female)
    _(Gender.Male)
    _(Gender.Androgyne)
    _(Gender.Androgynous)
    # Test with dict with enum Gender as keys

# Generated at 2022-06-23 21:45:03.321163
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Only run test if internet is available
    if not is_online():
        raise NetworkError('No internet connection. Skipping test...')

    faker = Faker(Person)
    valid_profiles = (
        'https://facebook.com/tgtg', 'https://twitter.com/tgtg',
        'https://instagram.com/tgtg', 'https://github.com/tgtg',
        'https://vk.com/id21721'
    )
    site = SocialNetwork.VK
    profile = faker.social_media_profile(site)

    assert profile in valid_profiles
 

# Generated at 2022-06-23 21:45:10.379678
# Unit test for method sex of class Person
def test_Person_sex():
    provider = Factory.create('en')
    for _ in range(10):
        assert provider.sex() in GENDER_TITLES
        assert provider.sex(symbol=True) in GENDER_SYMBOLS
        assert provider.sex(iso5218=True) in [0, 1, 2, 9]

        for gender in Gender:
            assert provider.sex(gender=gender) in GENDER_TITLES

        for gender in Gender:
            assert provider.sex(gender=gender, symbol=True) in \
                GENDER_SYMBOLS


# Generated at 2022-06-23 21:45:21.274560
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()

# Generated at 2022-06-23 21:45:22.781566
# Unit test for method name of class Person
def test_Person_name():
    try:
        Person().name()
    except Exception as e:
        print(e)

# Generated at 2022-06-23 21:45:25.080479
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person(random=Random())
    # Test call with wrong arguments
    assert person.work_experience() is None


# Generated at 2022-06-23 21:45:27.150639
# Unit test for method email of class Person
def test_Person_email():
    assert Person.email(Person) != Person.email(Person)

test_Person_email()

# Generated at 2022-06-23 21:45:30.380789
# Unit test for method identifier of class Person
def test_Person_identifier():
    methods = (
        (Person(), 'identifier', (), {}),
    )
    for method in methods:
        obj, name, passed_args, passed_kwargs = method
        result = getattr(obj, name)(*passed_args, **passed_kwargs)
        print(result)
        assert result is not None

# Generated at 2022-06-23 21:45:33.695568
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    person.gender()
    person.gender(symbol=True)
    person.gender(iso5218=True)
    
    
    

# Generated at 2022-06-23 21:45:36.800258
# Unit test for method email of class Person
def test_Person_email():
    print("Test test_Person_email")
    r = Person()
    m = r.email()
    assert type(m) == str


# Generated at 2022-06-23 21:45:38.853891
# Unit test for method gender of class Person
def test_Person_gender():
 # Test when gender is None
 assert Person().gender() in Gender._enums
 # Test when gender is object
 assert Person().gender(gender=Gender.MALE) in Gender._enums
 assert Person().gender(gender=Gender.FEMALE) in Gender._enums


# Generated at 2022-06-23 21:45:41.410708
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    print('Surname:', person.surname())

# Generated at 2022-06-23 21:45:44.068834
# Unit test for method views_on of class Person
def test_Person_views_on():
    items = [mock.Person().views_on() for i in range(20)]
    assert len(items) == len(set(items))


# Generated at 2022-06-23 21:45:50.873333
# Unit test for method university of class Person
def test_Person_university():
    p1 = Person()
    p2 = Person(locale='ru_RU')

    universities_p1 = [p1.university() for _ in range(100)]
    universities_p2 = [p2.university() for _ in range(100)]

    assert 'not found' not in universities_p1
    assert 'not found' not in universities_p2


# Generated at 2022-06-23 21:45:51.918577
# Unit test for method worldview of class Person
def test_Person_worldview():
    for i in range(20):
        print(Person().worldview())

if __name__ == '__main__':
    test_Person_worldview()

# Generated at 2022-06-23 21:46:01.485352
# Unit test for method title of class Person
def test_Person_title():
    # Check Person.title()
    assert Person().title() in ('Mr.', 'Ms.', 'Mrs.', 'Dr.', 'Prof.')
    assert Person().title(gender='female') in ('Ms.', 'Mrs.', 'Dr.', 'Prof.')
    assert Person().title(gender='male') in ('Mr.', 'Dr.', 'Prof.')
    assert Person().title(title_type='prefix') in ('Mr.', 'Ms.', 'Mrs.', 'Dr.', 'Prof.')
    assert Person().title(title_type='suffix') in ('Jr.', 'Sr.', 'II', 'III', 'IV')
    assert Person().title(title_type='suffix', gender='male') in ('Jr.', 'Sr.', 'II', 'III', 'IV')

# Generated at 2022-06-23 21:46:10.487865
# Unit test for method full_name of class Person
def test_Person_full_name():
    """Test for Person()."""
    from faker import Faker
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.person.zh_CN import Provider as PersonProvider2
    from faker.providers.person.nl_NL import Provider as PersonProvider3

    def test(prov):

        # Setup random locales
        Faker.seed(0)
        random = Faker.create()

        person = Person(random, prov)
        assert person.full_name() is not None
        assert person.full_name(gender=Gender.MALE) is not None
        assert person.full_name(gender=Gender.FEMALE) is not None

        assert person.name() is not None
        assert person.name(Gender.MALE) is not None
        assert person.name

# Generated at 2022-06-23 21:46:22.233911
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    assert p.title() in ['Mr.', 'Ms.', 'Mrs.', 'Dr.', 'Prof.', 'Miss.']
    assert p.title(gender=Gender.MALE) in ['Mr.', 'Dr.', 'Prof.']
    assert p.title(gender=Gender.FEMALE) in ['Ms.', 'Mrs.', 'Miss.']
    assert p.title(title_type=TitleType.PREFIX) in ['Mr.', 'Ms.', 'Mrs.', 'Dr.', 'Prof.', 'Miss.']
    assert p.title(title_type=TitleType.SUFFIX) in ['PhD.', 'DDS', 'MD', 'MD, PhD', 'PhD, MD']


# Generated at 2022-06-23 21:46:24.203682
# Unit test for method avatar of class Person
def test_Person_avatar():

    for i in range(4):
        assert len(Person().avatar()) > 0

# Generated at 2022-06-23 21:46:26.825973
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # GIVEN
    seed = 0
    provider = Person(seed=seed)
    # WHEN
    result = provider.blood_type()
    # THEN
    assert result == 'A+'

# Generated at 2022-06-23 21:46:36.992989
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    fake = Faker(locale='en')
    social_network = fake.social_network()
    assert social_network in SOCIAL_NETWORKS

    social_network = fake.random_element(social_network_list=list(SOCIAL_NETWORKS))
    assert social_network in SOCIAL_NETWORKS

    social_network = fake.social_network(website='facebook')
    assert social_network in SOCIAL_NETWORKS

    social_network = fake.social_network(website='http://www.facebook.com/')
    assert social_network in SOCIAL_NETWORKS

    social_network = fake.social_network(website='facebook.com')
    assert social_network in SOCIAL_NETWORKS

    social_network = fake.social_network(website='http://www.facebook.com')

# Generated at 2022-06-23 21:46:41.576975
# Unit test for method first_name of class Person
def test_Person_first_name():
    # Arrange
    gender_mock = MagicMock()

    # Act
    person = Person(seed=1)
    result = person.first_name(gender_mock)

    # Assert
    assert result == 'Любава'


# Generated at 2022-06-23 21:46:44.097500
# Unit test for method title of class Person
def test_Person_title():
    d = Person()
    result = d.title()
    assert result in ['Mrs.', 'Mr.', 'Ms.']


# Generated at 2022-06-23 21:46:44.789836
# Unit test for method avatar of class Person
def test_Person_avatar():
    pass

# Generated at 2022-06-23 21:46:45.882107
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person().identifier()


# Generated at 2022-06-23 21:46:49.751928
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    avatar = person.avatar()
    result = re.search('https://api.adorable.io/avatars/256/.+.png', avatar)
    assert result, "It's not link to avatar."
    print(avatar)

# Generated at 2022-06-23 21:46:52.285686
# Unit test for method height of class Person
def test_Person_height():
    r = Person()
    k = r.height(2.14, 2.15)
    assert k >= 2.14
    assert k <= 2.15


# Generated at 2022-06-23 21:46:56.119798
# Unit test for method weight of class Person
def test_Person_weight():
    provider = Faker.create(locale='en')
    assert provider.weight() in range(38, 90), 'weight method should be in range 38-90'


# Generated at 2022-06-23 21:46:57.264187
# Unit test for method worldview of class Person
def test_Person_worldview():
    pass


# Generated at 2022-06-23 21:46:59.718609
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert re.match(r'.+@.+\..+', person.email()) is not None

# Generated at 2022-06-23 21:47:01.219281
# Unit test for method sex of class Person
def test_Person_sex():
    assert Person().sex() in GENDERS
    

# Generated at 2022-06-23 21:47:08.592596
# Unit test for method political_views of class Person
def test_Person_political_views():
	for _ in range(100): # Run 100 times
		result = [
			'Authoritarianism',
			'Collectivism',
			'Communism',
			'Conservatism',
			'Conspiracy theory',
			'Fascism',
			'Liberalism',
			'Libertarianism',
			'Nationalism',
			'Politics of fear',
			'Politics of resentment',
			'Politics of scarcity',
			'Politics of technological determinism',
			'Radical centrism',
			'Social democracy',
			'Totalitarianism',
			'Tribalism',
			'Zionism'
		]

		assert provider.Person().political_views() in result

	

# Generated at 2022-06-23 21:47:15.631738
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person()
    profile = provider.social_media_profile(SocialNetwork.VK)

    re_pattern = r"https://vk.com/\w{3,30}"
    assert re.search(re_pattern, profile) is not None

    profile = provider.social_media_profile(SocialNetwork.TWITTER)

    re_pattern = r"https://twitter.com/\w{3,15}"
    assert re.search(re_pattern, profile) is not None



# Generated at 2022-06-23 21:47:23.963591
# Unit test for method worldview of class Person
def test_Person_worldview():
    """Unittest for method worldview of class Person."""
    # Create a seed
    seed = create_seed()
    # Create a Faker instance
    faker = Faker(seed)
    # Create a Person instance
    person = faker.person()
    # Create names for testing
    worldview_list = person._data['worldview']
    # Create test set
    test_set = set()
    # Loop for 100 times
    for _ in range(100):
        # Use method worldview() and add result to test set
        test_set.add(person.worldview())
    # Check if all names are in data
    assert test_set.issubset(worldview_list)

# Generated at 2022-06-23 21:47:31.370166
# Unit test for method views_on of class Person
def test_Person_views_on():
    random_vs = []
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())
    random_vs.append(Person().views_on())


    assert isinstance(random_vs, list)

# Generated at 2022-06-23 21:47:33.371351
# Unit test for method views_on of class Person
def test_Person_views_on():
    r = Provider().views_on()
    assert isinstance(r, str)

# Generated at 2022-06-23 21:47:36.044354
# Unit test for method avatar of class Person
def test_Person_avatar():
    # prepare the args
    pass

    # perform the test
    result = Person.avatar()

    # assert the result
    assert isinstance(result, str)

# Generated at 2022-06-23 21:47:44.205424
# Unit test for method title of class Person
def test_Person_title():
    """Unit test for method title of class Person."""
    # Also testing method _validate_enum
    gender, title_type = get_random_item(Gender, rnd=random), get_random_item(TitleType, rnd=random)
    provider = Provider(random=random)
    result = provider.title(gender, title_type)
    assert result is not None

    # If gender is invalid raise NonEnumerableError
    with pytest.raises(NonEnumerableError):
        provider.title(0)

    # If title_type is invalid raise NonEnumerableError
    with pytest.raises(NonEnumerableError):
        provider.title(gender, 5)

    # Testing None
    assert provider.title()
    assert provider.title(None)
    assert provider.title(title_type=None)
    assert provider

# Generated at 2022-06-23 21:47:45.918802
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person()
    assert isinstance(provider.sexual_orientation(), str)


# Generated at 2022-06-23 21:47:57.006159
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Test with default value
    print_test_title('Test method Person.blood_type()')
    getPerson = Person(seed=1)
    assert getPerson.blood_type() == 'A+'
    # Test with seed
    getPerson = Person(seed=2)
    assert getPerson.blood_type() == 'A-'
    assert getPerson.blood_type() == 'A-'
    assert getPerson.blood_type() == 'A-'
    # Test with seed and gender
    getPerson = Person(seed=3)
    assert getPerson.blood_type() == 'B+'
    assert getPerson.blood_type() == 'B+'
    assert getPerson.blood_type() == 'B+'
    # Test with seed and gender
    getPerson = Person(seed=3)
    assert getPerson.blood_

# Generated at 2022-06-23 21:48:00.806169
# Unit test for method password of class Person
def test_Person_password():

    provider = Person()
    for _ in range(100):
        #
        # Call method by default
        #
        result = provider.password()
        assert isinstance(result, str)
        assert len(result) == 8



# Generated at 2022-06-23 21:48:04.620141
# Unit test for method sex of class Person
def test_Person_sex():
    for i in range(100):
        assert get_random_item(Gender, rnd=Faker()) == 1 or get_random_item(Gender, rnd=Faker()) == 2 or get_random_item(Gender, rnd=Faker()) == 0


# Generated at 2022-06-23 21:48:13.490837
# Unit test for method identifier of class Person
def test_Person_identifier():
    # Arrange
    person = Person('en')
    expected = '07-97/04'
    mask1 = '##-##/##'
    mask2 = '##-##/##'
    mask3 = '##-##/##'
    # Act
    actual1 = person.identifier(mask1)
    actual2 = person.identifier(mask2)
    actual3 = person.identifier(mask3)
    # Assert
    assert len(actual1) == len(expected)
    assert len(actual2) == len(expected)
    assert len(actual3) == len(expected)
    assert len(actual1) == len(actual2)
    assert len(actual2) == len(actual3)
    assert len(actual3) == len(actual1)
    assert actual1 == actual2

# Generated at 2022-06-23 21:48:21.535800
# Unit test for constructor of class Person
def test_Person():
    from pprint import pprint

    provider = Person()

    # Person
    pprint(provider.name())
    pprint(provider.name(gender=Gender.MALE))
    pprint(provider.name(Gender.FEMALE))
    pprint(provider.first_name())
    pprint(provider.first_name(Gender.MALE))
    pprint(provider.first_name(Gender.FEMALE))
    pprint(provider.middle_name())
    pprint(provider.middle_name(Gender.MALE))
    pprint(provider.middle_name(Gender.FEMALE))
    pprint(provider.last_name())
    pprint(provider.last_name(Gender.MALE))

# Generated at 2022-06-23 21:48:24.302979
# Unit test for method height of class Person
def test_Person_height():
    fake = Person(random.seed(int(time())))
    height = fake.height()
    assert isinstance(height, str)



# Generated at 2022-06-23 21:48:26.383464
# Unit test for method password of class Person
def test_Person_password():
    with pytest.raises(ValueError):
        Person().password(hashed=True)



# Generated at 2022-06-23 21:48:29.627338
# Unit test for method university of class Person
def test_Person_university():
    for i in range(20):
        assert Person().university() in UNIVERSITIES

# Generated at 2022-06-23 21:48:33.858938
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    '''
    Test that random social network profile generated by
    method social_media_profile of class Person is successfull
    '''
    provider = Person()
    result = provider.social_media_profile()
    assert isinstance(result, str)

# Wrapper function around faker's seed function

# Generated at 2022-06-23 21:48:45.526109
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()

    phone1 = person.telephone()
    phone2 = person.telephone('+7963-409-11-22')
    phone3 = person.telephone('+7-(963)-409-11-22')
    phone4 = person.telephone('+7 (963) 409-11-22')
    phone5 = person.telephone('+7 **-*9-6-3 **4-0-9--1-1--2-2')
    phone6 = person.telephone('+7 *9-6-3 *4-0-9--1-1--2-2')
    phone7 = person.telephone('+7 (9-6-3) 4-0-9--1-1--2-2')

# Generated at 2022-06-23 21:48:49.674260
# Unit test for method last_name of class Person
def test_Person_last_name():
    from pydantic import ValidationError
    from tests.utils import Person, DummyPerson

    person = DummyPerson()
    for _ in range(100):
        try:
            Person(last_name=person.last_name())
        except ValidationError:
            pass

# Generated at 2022-06-23 21:48:55.376732
# Unit test for method username of class Person
def test_Person_username():
    from faker import Faker
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.internet.en_US import Provider as InternetProvider

    fake = Faker('en_US')
    fake.add_provider(PersonProvider)
    fake.add_provider(InternetProvider)

    result = fake.username()
    assert result is not None



# Generated at 2022-06-23 21:49:00.819376
# Unit test for method gender of class Person
def test_Person_gender():
    letter_g = Person().gender()
    assert letter_g in ["Male", "Female"]
    assert Person().gender(symbol = True) in ["♂", "♀"]
    assert Person().gender(iso5218 = True) in [0, 1, 2, 9]


# Generated at 2022-06-23 21:49:04.679384
# Unit test for method occupation of class Person
def test_Person_occupation():
  # initialize the class
  p = Person()

  # call the method and store the result
  r = p.occupation()

  # check if the result is in the list of results
  assert r in p._data['occupation']


# Generated at 2022-06-23 21:49:05.357813
# Unit test for constructor of class Person
def test_Person():
    Person()

# Generated at 2022-06-23 21:49:10.656337
# Unit test for method occupation of class Person
def test_Person_occupation():
    from datagenpy.provider import Provider
    rnd_seed = Provider.random.randrange(10000) * Provider.random.randrange(10000)
    prov = Provider(seed=rnd_seed)
    occ = prov.occupation()
    assert  occ == 'IT Architect'


# Generated at 2022-06-23 21:49:14.367686
# Unit test for method full_name of class Person
def test_Person_full_name():
    provider = Person(seed=1234)
    assert provider.full_name() == 'Василий Алексеев'
    assert provider.full_name(reverse=True) == 'Алексеев Василий'
    assert provider.full_name(gender=Gender.male) == 'Василий Алексеев'
    assert provider.full_name(gender=Gender.female) == 'Мария Горелова'


# Generated at 2022-06-23 21:49:19.353091
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    for _ in range(50):
        pt = Person()
        d = pt.academic_degree()
        assert d in pt._data['academic_degree']

# Generated at 2022-06-23 21:49:22.671774
# Unit test for method password of class Person
def test_Person_password():
    with Person.seed(12345):
        assert Person().password(length=10) == 'X0$0#q3z3Y'

# Generated at 2022-06-23 21:49:26.883609
# Unit test for method username of class Person
def test_Person_username():

    obj = Person(seed=1)

    assert obj.username('UU-d') == 'Tv4-5896'
    assert obj.username(template='UU-d') == 'Tv4-5896'
    assert obj.username() == 'h7'



# Generated at 2022-06-23 21:49:28.793889
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    generator = Factory.create()
    assert generator.blood_type() in BLOOD_GROUPS

# Generated at 2022-06-23 21:49:30.989804
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    worldview = p.worldview()
    print(worldview)
    assert worldview in p._data['worldview']

# Generated at 2022-06-23 21:49:38.625583
# Unit test for method gender of class Person
def test_Person_gender():

    # Test 1
    # Generate a random gender title
    assert Person().gender() in GENDERS

    # Test 2
    # Generate a random gender code
    assert Person().gender(iso5218=True) in GENDER_CODES

    # Test 3
    # Generate a random gender symbol
    assert Person().gender(symbol=True) in GENDER_SYMBOLS

# Generated at 2022-06-23 21:49:40.028110
# Unit test for method age of class Person
def test_Person_age():
    assert Person.age(birth_date='2000-06-05') == 20

# Generated at 2022-06-23 21:49:42.239896
# Unit test for method language of class Person
def test_Person_language():
    assert Person().language() == "Irish"


# Generated at 2022-06-23 21:49:44.772788
# Unit test for method last_name of class Person
def test_Person_last_name():

    assert Person.last_name.__doc__ == 'Generate a random last name.'
    assert Person().last_name() == Person().surname()



# Generated at 2022-06-23 21:49:46.993801
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert (p)


# Generated at 2022-06-23 21:49:49.975074
# Unit test for method weight of class Person
def test_Person_weight():
     from random import randint
     
     for i in range(10):
        x = randint(38, 90)
        assert Person().weight() == x


# Generated at 2022-06-23 21:49:55.407138
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person(seed=55)
    assert 'Алексеев' == person.last_name()
    assert 'Алексеева' == person.last_name(gender=Gender.FEMALE)


# Generated at 2022-06-23 21:50:04.776665
# Unit test for method gender of class Person
def test_Person_gender():
    """Unit test for method gender of class Person."""
    # Test 1
    # Get a random gender
    person = Person()
    gender = person.gender()

    # Test 2
    # Test a list of genders
    genders = [person.gender() for _ in range(1000)]
    assert set(genders) == {'Male', 'Female'}

    # Test 3
    # Test a random gender
    assert gender in GENDER_LIST

    # Test 4
    # Test a random gender code in the range from 0 to 9
    assert not gender or 0 <= gender <= 9

    # Test 5
    # Test a random gender symbol
    gender_symbol = person.gender(symbol=True)
    assert gender_symbol in GENDER_SYMBOLS

    # Test 6
    # Test a random gender code
    gender_

# Generated at 2022-06-23 21:50:06.398237
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()
    result = provider.telephone()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:50:10.926434
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    pr = Person()
    orientation = pr.sexual_orientation()
    assert orientation in [
        'Heterosexuality', 'Bisexuality', 'Homosexuality', 'Asexuality',
        'Pansexuality']
    orientation = pr.sexual_orientation(symbol=True)
    assert orientation in ['♂♀', '♂♂', '♀♀', 'X', 'X']

# Generated at 2022-06-23 21:50:15.971797
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    gender = p.gender()
    sexual_orientation = p.sexual_orientation()

    assert sexual_orientation in p._data['sexuality']
    assert type(sexual_orientation) == str
    assert sexual_orientation != None


# Generated at 2022-06-23 21:50:19.958143
# Unit test for method email of class Person
def test_Person_email():
    """Test function Person.email()"""
    assert Person().email() == 'a.coulter@gmail.com'
        

test_Person_email()

# Generated at 2022-06-23 21:50:22.346165
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    result = p.title()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:50:24.039553
# Unit test for method name of class Person
def test_Person_name():
    name = Person().name()
    assert len(name) > 0
    assert name[0].isupper()

# Generated at 2022-06-23 21:50:26.139603
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()
    assert worldview in worldviews

# Generated at 2022-06-23 21:50:27.754077
# Unit test for method height of class Person
def test_Person_height():
    obj = Person()
    res = obj.height(minimum=1.0, maximum=1.8)

    assert res > 1.0 and res < 1.8


# Generated at 2022-06-23 21:50:29.689999
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    result = provider.email()
    print(result)



# Generated at 2022-06-23 21:50:40.212213
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person().identifier() in [
        '07-97/04',
        '20-41/54',
        '19-31/69',
        '11-59/98',
        '52-10/57',
        '45-03/66'
    ]

    assert Person().identifier(mask='@###@@@') in [
        'QUEQPYON',
        'GRLJINXN',
        'NXRUKRJH',
        'PWVGRYVS',
        'QKPQMGHT',
        'AVDXANQQ'
    ]


# Generated at 2022-06-23 21:50:51.152917
# Unit test for method gender of class Person
def test_Person_gender():
    from pyffaker.enums import Gender

    p = Person()
    p.seed(44)

    for _ in range(10):
        assert p.gender() in ['Male', 'Female', 'Not applicable']
        assert p.gender(symbol=True) in ['♂', '♀', '⚲']

    for _ in range(10):
        assert p.gender(symbol=True) in ['♂', '♀', '⚲']

    p.reset_seed()
    random_sex = p.sex()
    p.seed(44)
    assert random_sex == p.sex()
    assert p.sex() in ['Male', 'Female', 'Not applicable']

    for _ in range(10):
        assert p.gender(iso5218=True) in [0, 1, 2, 9]

# Generated at 2022-06-23 21:51:00.814585
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    obj = Person()

    obj.random.seed(13)
    assert obj.social_media_profile() == 'https://telegram.me/joanlat'

    obj.random.seed(15)
    assert obj.social_media_profile() == 'https://instagram.com/joanlat'

    obj.random.seed(31)
    assert obj.social_media_profile('vkontakte') == 'https://vk.com/joanlat'

    obj.random.seed(42)
    assert obj.social_media_profile('twitter') == 'https://twitter.com/joanlat'

    obj.random.seed(69)
    assert obj.social_media_profile('facebook') == 'https://facebook.com/joanlat'
