

# Generated at 2022-06-23 21:40:59.364316
# Unit test for method nationality of class Person
def test_Person_nationality():
    from fake_ocean.resources.person import nationalities

    p1 = Person(nationality=nationalities)
    assert isinstance(p1.nationality, str)
    assert p1.nationality in nationalities

    p2 = Person(nationality=nationalities)
    assert isinstance(p2.nationality, str)
    assert p2.nationality in nationalities

    assert p1.nationality != p2.nationality

# Generated at 2022-06-23 21:41:03.596604
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    avatar = p.avatar()
    assert avatar.startswith('https://api.adorable.io/avatars/')
    assert avatar.endswith('.png')
    assert len(avatar.split('/')) == 5


# Generated at 2022-06-23 21:41:06.370701
# Unit test for method avatar of class Person
def test_Person_avatar():
    for i in range(100):
        assert isinstance(Person().avatar(), str)


# Unit tests for method blood_type of class Person

# Generated at 2022-06-23 21:41:09.282366
# Unit test for method worldview of class Person
def test_Person_worldview():
    np = Person()
    a = np.worldview()
    print(a)


if __name__ == "__main__":
    test_Person_worldview()

# Generated at 2022-06-23 21:41:13.898632
# Unit test for method identifier of class Person
def test_Person_identifier():
    locale = 'en'
    mask = '##-##/##'
    value = Person.identifier(locale, mask)
    assert re.fullmatch(r'\d\d-\d\d/\d\d', value) is not None



# Generated at 2022-06-23 21:41:17.760606
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    for i in range(0, number_of_tests):
        person = Person()
        degree = person.academic_degree()

        assert isinstance(degree, str)
        assert degree in set(ACADEMIC_DEGREES)


# Generated at 2022-06-23 21:41:20.616483
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    from faker.providers.person.en import Provider
    p = Provider
    assert p.academic_degree(p) in p._data['academic_degree']

# Generated at 2022-06-23 21:41:24.983405
# Unit test for method full_name of class Person
def test_Person_full_name():
    from faker_generator.faker_generator import FakerGenerator
    person = Person(FakerGenerator())
    full_name = person.full_name()
    assert full_name is not None
    assert full_name != ''
# Test for method username of class Person

# Generated at 2022-06-23 21:41:26.556119
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    assert person.social_media_profile(site=SocialNetwork.GITHUB) == 'https://github.com/some_user'

# Generated at 2022-06-23 21:41:32.327036
# Unit test for method sex of class Person
def test_Person_sex():
    your_seed = 0
    provider = Generator(your_seed)
    result = provider.sex()
    assert isinstance(result, str)
    assert result == 'Female'
    result = provider.sex(symbol=True)
    assert isinstance(result, str)
    assert result == '♀'
    result = provider.sex(iso5218=True)
    assert isinstance(result, int)
    assert result == 0


# Generated at 2022-06-23 21:41:35.243951
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    prv = Person()
    data = prv.blood_type()
    # A+
    assert re.match(r'^(A|B|AB|O)[+\-]$', data) == True


# Generated at 2022-06-23 21:41:46.553599
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(random=rnd)
    assert p.surname(gender=Gender.Male) in p._data['surname']['male']
    assert p.surname(gender=Gender.Female) in p._data['surname']['female']
    assert p.surname() in p._data['surname']['male'] + p._data['surname']['female']
    assert p.last_name(gender=Gender.Male) in p._data['surname']['male']
    assert p.last_name(gender=Gender.Female) in p._data['surname']['female']
    assert p.last_name() in p._data['surname']['male'] + p._data['surname']['female']


# Generated at 2022-06-23 21:41:49.519501
# Unit test for method worldview of class Person
def test_Person_worldview():
    instance = Person()
    assert isinstance(instance.worldview(), str)


# Generated at 2022-06-23 21:41:52.633317
# Unit test for method university of class Person
def test_Person_university():
    # Check output type
    university = Person().university()
    assert isinstance(university, str)
    # Check length of output
    assert len(university) >= 2 and len(university) <= 20


# Generated at 2022-06-23 21:41:55.660585
# Unit test for method full_name of class Person
def test_Person_full_name():
    libfaker.set_seed(1)
    expected = 'Sébastien Gibeault'
    actual = libfaker.Person().full_name(Gender.MALE)
    assert type(actual) is str
    assert actual == expected


# Generated at 2022-06-23 21:41:59.757773
# Unit test for method password of class Person
def test_Person_password():
    from pyfakefs.fake_filesystem_unittest import Patcher
    import os.path as path

    def _fake_randstr(n):
        return 'test'

    with Patcher() as patcher:
        patcher.fs.create_file(path.join('random', 'seed'))
        person = Person(seed=path.join('random', 'seed'))
        person.random.randstr = _fake_randstr

        assert person.password() == 'testtesttesttesttest'
        assert person.password(length=20) == 'testtesttesttesttesttesttesttesttesttest'
        assert person.password(length=5) == 'testtesttesttest'
        assert person.password(hashed=True) != 'testtesttest'
    pass

# Generated at 2022-06-23 21:42:01.435142
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in [
        'Negative',
        'Neutral',
        'Positive',
    ]



# Generated at 2022-06-23 21:42:06.126883
# Unit test for method email of class Person
def test_Person_email():
    random = RandomFactory('random')
    random.seed(0)

    personal1 = Person(seed=0)
    assert personal1.email() == 'georgetracka@hotmail.com'

    personal2 = Person(seed=0)
    assert personal2.email() == 'georgetracka@hotmail.com'

# Generated at 2022-06-23 21:42:07.456100
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    language = person.language()
    print(language)
test_Person_language()


# Generated at 2022-06-23 21:42:08.756118
# Unit test for method first_name of class Person
def test_Person_first_name():
    from faker.config import AddressNotFoundError
    p = Person()
    assert isinstance(p.first_name(), str)



# Generated at 2022-06-23 21:42:10.706254
# Unit test for method weight of class Person
def test_Person_weight():
    r = Person()
    r.random.seed(0)
    assert r.weight() == 54

# Generated at 2022-06-23 21:42:14.967952
# Unit test for method telephone of class Person
def test_Person_telephone():
    num_format = '{}-(###)-###-####'
    calling_code = '19'
    mask = num_format.format(calling_code)
    person = Person(seed=1)
    num = person.telephone(mask=mask)
    assert num == '19-464-303-1933'

# Generated at 2022-06-23 21:42:18.309667
# Unit test for method university of class Person
def test_Person_university():
    from .. import Person
    from .. import enums
    obj = Person(
        gender=enums.Gender.Male,
        seed=1234
    )
    result = obj.university()
    assert result == 'The University of Texas at Austin'



# Generated at 2022-06-23 21:42:23.250291
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person(seed=1234)
    assert person.worldview() == 'Buddhism'
    person = Person(seed=1337)
    assert person.worldview() == 'Traditionalism'
    person = Person(seed=0)
    assert person.worldview() == 'New Age'
    person = Person(seed=None)
    assert person.worldview() == 'New Age'

# Generated at 2022-06-23 21:42:24.799708
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    person.academic_degree()


# Generated at 2022-06-23 21:42:36.140566
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()

    assert p.telephone(mask='')
    assert p.telephone(mask='#'*10)
    assert p.telephone(mask='#'*11)
    assert p.telephone(mask='#'*12)
    assert p.telephone(mask='#'*13)
    assert p.telephone(mask='#'*14)
    assert p.telephone(mask='#'*15)
    assert p.telephone(mask='#'*16)
    assert p.telephone(mask='#'*17)
    assert p.telephone(mask='#'*18)
    assert p.telephone(mask='#'*19)
    assert p.telephone(mask='#'*20)
    assert p.telephone(mask='#'*21)
   

# Generated at 2022-06-23 21:42:38.224462
# Unit test for method first_name of class Person
def test_Person_first_name():
    a = Person()
    num = 10
    for i in range(num):
        res = a.first_name()
        assert res != None


# Generated at 2022-06-23 21:42:45.664502
# Unit test for method political_views of class Person

# Generated at 2022-06-23 21:42:47.967615
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    assert person.views_on() in ('Neutral', 'Positive', 'Negative')

# Generated at 2022-06-23 21:42:50.003851
# Unit test for method sex of class Person
def test_Person_sex():
    assert isinstance(Person().sex(), str)

# Generated at 2022-06-23 21:42:51.879773
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    assert type(p.height) == str
    assert len(p.height) == 4


# Generated at 2022-06-23 21:42:56.383825
# Unit test for method gender of class Person
def test_Person_gender():
    # Generate random gender by method gender of class Person
    actual_result = Person().gender()
    # Get expected result
    expected_result = get_random_item(Gender)
    # Assert - is gender equal to expected result
    assert actual_result == expected_result.value

# Generated at 2022-06-23 21:43:04.173838
# Unit test for method title of class Person
def test_Person_title():
    titles = (
        'Mr.', 'Ms.', 'Mrs.', 'Miss', 'Dr.', 'Prof.', 'Hon.', 'Rev.', 'Pr.'
    )

    person = Person()
    for i in range(20):
        title = person.title(Gender.MALE, TitleType.PREFIX)
        assert title in titles

    titles = ('Jr.', 'Sr.', 'I', 'II', 'III', 'IV')
    for i in range(20):
        title = person.title(Gender.MALE, TitleType.SUFFIX)
        assert title in titles

# Generated at 2022-06-23 21:43:06.918539
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person(random=Random())
    result = person.blood_type()
    assert type(result) == str
    

# Generated at 2022-06-23 21:43:08.509694
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person.identifier("@##-###") == "r14-009"



# Generated at 2022-06-23 21:43:11.604355
# Unit test for method password of class Person
def test_Person_password():
    words = set()
    p = Person(random=faker.generator.random.Random())
    for i in range(1000):
        words.add(p.password())
    assert len(words) == 1000



# Generated at 2022-06-23 21:43:13.497991
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for _ in range(100):
        n = Person().blood_type()
        assert_valid_blood_type(n)
        

# Generated at 2022-06-23 21:43:15.266409
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    degrees = Person.academic_degree(Person)
    assert degrees in ACADEMIC_DEGREES


# Generated at 2022-06-23 21:43:16.263423
# Unit test for method weight of class Person
def test_Person_weight():
    assert random.weight() >= 38

# Generated at 2022-06-23 21:43:19.277536
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person()
    p.year = 2016
    p.month = 8
    result = p.work_experience()
    expected = 'since 2016-08'
    assert result == expected, 'incorrect result of work_experience'


# Generated at 2022-06-23 21:43:21.044314
# Unit test for method age of class Person
def test_Person_age():
    '''
        Unit test for method age of class Person
    '''
    pass

# Generated at 2022-06-23 21:43:22.328859
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person(locale='en')
    assert provider.nationality() in NATIONALITY

# Generated at 2022-06-23 21:43:24.421995
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert isinstance(Person().first_name(), str)


# Generated at 2022-06-23 21:43:27.214741
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    for i in range(100):
        weight = person.weight()
        assert type(weight) == int
        assert 38 <= weight and weight <= 90
test_Person_weight()

# Generated at 2022-06-23 21:43:28.470846
# Unit test for method surname of class Person
def test_Person_surname():
    for x in range(10):
        assert isinstance(Person().surname(), str)

# Generated at 2022-06-23 21:43:34.447851
# Unit test for method email of class Person
def test_Person_email():
    person = Person(
        provider=locales.ru_RU,
        seed=0,
    )
    
    assert 'висажа12@yandex.com' == person.email(unique=True)
    assert 'foretime10@live.com' == person.email()
    assert 'foretime10@live.com' == person.email(unique=False)


# Generated at 2022-06-23 21:43:40.628648
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for _ in range(10):
        # blood_type()
        blood_type = Person().blood_type()
        assert  blood_type in ['O+', 'A+', 'B-', 'AB+', 'A-', 'AB-', 'B+', 'O-']
        print(blood_type)


# Generated at 2022-06-23 21:43:44.048550
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(1000):
        nationality = p.nationality()
        assert isinstance(nationality, str)
        
        assert nationality in NATIONALITIES
 

# Generated at 2022-06-23 21:43:47.464374
# Unit test for method university of class Person
def test_Person_university():
    provider = Person()
    result = provider.university()
    
    assert isinstance(result, str)
    assert result in provider._data['university']

# Generated at 2022-06-23 21:43:50.431334
# Unit test for method title of class Person
def test_Person_title():

    # Empty mask
    for i in range(100):
        title = Person().title()
        assert isinstance(title, str) and title


# Generated at 2022-06-23 21:43:54.041998
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    try:
        provider.email()
    except ValueError:
        print("ValueError was raised")
    else:
        assert False, "Not raised ValueError"


# Generated at 2022-06-23 21:43:59.601032
# Unit test for method surname of class Person
def test_Person_surname():
    names1 = [Person().surname(gender=Gender.male.name) for _ in range(15)]
    assert len(set(names1)) > 1
    
    names2 = [Person().surname(gender=Gender.female.name) for _ in range(15)]
    assert len(set(names2)) > 1
    
    names3 = [Person().surname() for _ in range(15)]
    assert len(set(names3)) > 1

# Generated at 2022-06-23 21:44:11.333955
# Unit test for method full_name of class Person
def test_Person_full_name():
    np.random.seed(1)
    p1 = Person(None, None)
    p2 = Person('male', None)
    p3 = Person(None, 'ru')
    p4 = Person('female', 'ru')
    assert p1.full_name() == 'Illidio Silva'
    assert p1.full_name(reverse=True) == 'Silva Illidio'
    assert p2.full_name() == 'Miguel Angel'
    assert p2.full_name(reverse=True) == 'Angel Miguel'
    assert p3.full_name() == 'Svetlana Svetlana'
    assert p4.full_name() == 'Oksana Ivanov'
    assert p4.full_name(reverse=True) == 'Ivanov Oksana'

# Generated at 2022-06-23 21:44:12.773008
# Unit test for method nationality of class Person
def test_Person_nationality():
    result = Person().nationality()
    print(result)


# Generated at 2022-06-23 21:44:14.777343
# Unit test for method first_name of class Person
def test_Person_first_name():
    temp = Person()
    assert isinstance(temp.first_name(), str)



# Generated at 2022-06-23 21:44:22.029741
# Unit test for method telephone of class Person

# Generated at 2022-06-23 21:44:23.668031
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    global person
    assert person.sexual_orientation() in SEXUAL_ORIENTATION, \
        "Return a random sexual orientation"

# Generated at 2022-06-23 21:44:25.827005
# Unit test for constructor of class Person
def test_Person():
    assert Person('User')
    assert Person(seed=1)
    assert Person(seed=1) == Person(seed=1)
    assert Person() != Person(seed=1)
    assert Person('User') != Person()


# Generated at 2022-06-23 21:44:28.302295
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    lst = []
    for i in range(100):
        lst.append(person.full_name())
    if not lst:
        raise AssertionError('There is no full name')
test_Person_full_name()

# Generated at 2022-06-23 21:44:39.009871
# Unit test for method weight of class Person
def test_Person_weight():
    from faker.providers.person.ru_RU import Provider as PersonRuProvider
    from faker.utils.types import Param, Tuple, Union
    from functools import partial
    from faker.providers.person.pt_PT import Provider as PersonPtProvider
    from faker.providers.person.zh_CN import Provider as PersonZhProvider
    provider = PersonZhProvider
    # provider.weight()
    provider.weight(38, 90)
    # Go through the Faker API and gather
    # all the provider methods and their parameters
    faker_obj = provider.faker
    provider_methods = [
        method for method in dir(provider) if callable(getattr(provider, method))
    ]

# Generated at 2022-06-23 21:44:42.829394
# Unit test for method password of class Person
def test_Person_password():
    person = Person()

    for _ in range(1000):
        password = person.password()
        assert len(password) >= 7
        assert len(password) < 9

        password = person.password(10)
        assert len(password) >= 10
        assert len(password) < 12

# Generated at 2022-06-23 21:44:45.488104
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    for i in range(1000):
        assert(p.weight() >= 38 and p.weight() <= 90)


# Generated at 2022-06-23 21:44:47.413686
# Unit test for method first_name of class Person
def test_Person_first_name():
    ran_str = Person().first_name()
    assert isinstance(ran_str, str)

# Generated at 2022-06-23 21:44:50.047581
# Unit test for method language of class Person
def test_Person_language():
    from faker import Faker
    fake = Faker()
    fake.add_provider(Person())

    assert isinstance(fake.language(), str)


# Generated at 2022-06-23 21:44:52.015678
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person.full_name() != 'Gladys Gilbert'


# Generated at 2022-06-23 21:44:55.172692
# Unit test for method university of class Person
def test_Person_university():
    generated = Person.university()
    expected = Person.random.choice(Person._data['university'])
    assert generated == expected


# Generated at 2022-06-23 21:44:56.304475
# Unit test for method views_on of class Person
def test_Person_views_on():
    for item in Person()._data['views_on']:
        assert item in Person().views_on

# Generated at 2022-06-23 21:45:01.914718
# Unit test for method language of class Person
def test_Person_language():
    with pytest.raises(TypeError):
        p = Person(language=123)
    with pytest.raises(TypeError):
        p = Person(language={})

    p = Person(language='en')
    assert p.language() in LANGUAGES_EN
    p = Person(language='ru')
    assert p.language() in LANGUAGES_RU



# Generated at 2022-06-23 21:45:03.602818
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    result = person.height()

    assert result is not None


# Generated at 2022-06-23 21:45:08.300050
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person(locale='en')

    data = []

    for _ in range(100):
        data.append(person.political_views())

    assert isinstance(data, list)
    assert len(data) == 100
    assert all(isinstance(v, str) for v in data)
    assert len(set(data)) > 1


# Generated at 2022-06-23 21:45:14.669121
# Unit test for method height of class Person
def test_Person_height():
    assert isinstance(Person().height(), str)
    assert isinstance(Person().height(minimum=0, maximum=2), str)
    assert isinstance(Person().height(minimum=0, maximum=0.5), str)
    assert isinstance(Person().height(minimum=5, maximum=6), str)
    assert isinstance(Person().height(minimum=5.5, maximum=6.5), str)

# Generated at 2022-06-23 21:45:16.546361
# Unit test for method worldview of class Person
def test_Person_worldview():
    obj = Person()
    func = obj.worldview
    assert isinstance(func(), str)

# Generated at 2022-06-23 21:45:19.148511
# Unit test for method occupation of class Person
def test_Person_occupation():
    for _ in range(100):
        occupation = Person.occupation()
        assert isinstance(occupation, str)


# Generated at 2022-06-23 21:45:22.543788
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    provider = Person()
    result = provider.academic_degree()
    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-23 21:45:26.108854
# Unit test for constructor of class Person
def test_Person():
    provider = Person()

    assert isinstance(provider, Person)
    assert isinstance(provider.random, Random)
    assert isinstance(provider._data, dict)


# Unit tests for method Person.name()

# Generated at 2022-06-23 21:45:27.603341
# Unit test for method sex of class Person
def test_Person_sex():
    sex = Person().sex()
    assert isinstance(sex, str)

# Generated at 2022-06-23 21:45:30.119985
# Unit test for method password of class Person
def test_Person_password():
    p = Person()
    assert re.match(r'[a-zA-Z0-9_]{8}', p.password())


# Generated at 2022-06-23 21:45:32.901186
# Unit test for method first_name of class Person
def test_Person_first_name():
    names = [
        'Alexandros',
        'Tatiana',
        'Teodor',
    ]
    gen = Person()
    for name in names:
        assert gen.first_name() == name

# Generated at 2022-06-23 21:45:37.788750
# Unit test for constructor of class Person
def test_Person():
    rnd = Generator()
    person = Person(random=rnd)
    
    assert hasattr(person, 'random') and isinstance(person.random, Generator)
    assert not person.seed
    assert hasattr(person, '_data') and person._data



# Generated at 2022-06-23 21:45:39.918693
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person('ru')
    assert len(person.academic_degree()) > 0

# Generated at 2022-06-23 21:45:45.365559
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert isinstance(p, Person)

    p = Person(seed=123)
    assert isinstance(p, Person)

    p = Person(rnd=Random())
    assert isinstance(p, Person)

    p = Person(rnd=Random(seed=123))
    assert isinstance(p, Person)

    Person(rnd=None)



# Generated at 2022-06-23 21:45:55.188187
# Unit test for method first_name of class Person
def test_Person_first_name():
    print('Test method first_name')
    p = Person()
    name = p.first_name()
    print('default -', name)
    name = p.first_name(gender=Gender.MALE)
    print('Gender.MALE -', name)
    name = p.first_name(gender=Gender.FEMALE)
    print('Gender.FEMALE -', name)
    # not Gender
    try:
        name = p.first_name(gender='Male')
    except Exception as ex:
        print(ex)



# Generated at 2022-06-23 21:45:58.190119
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() == 'Chinese'
    assert Person().nationality() == 'American'
    assert Person().nationality() == 'Malaysian'
    assert Person().nationality() == 'American'



# Generated at 2022-06-23 21:46:00.506939
# Unit test for method weight of class Person
def test_Person_weight():
    # Arrange
    person = Person()
    # Act
    weight = person.weight()
    # Assert
    assert weight <= 90
    

# Generated at 2022-06-23 21:46:03.545543
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person('test')
    views_on = p.views_on()
    assert views_on in p._data['views_on']


# Generated at 2022-06-23 21:46:04.969232
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() == "Male"
    

# Generated at 2022-06-23 21:46:06.607432
# Unit test for method height of class Person
def test_Person_height():
    assert Person.height() >= 1.5 and Person.height() <= 2.0
    assert isinstance(Person.height(), str)
    
test_Person_height()# Unit test for method weight of class Person

# Generated at 2022-06-23 21:46:08.586957
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person(seed=1)
    occupation = person.occupation()
    assert occupation == 'gardener'

# Generated at 2022-06-23 21:46:18.042960
# Unit test for method title of class Person
def test_Person_title():
    # prepare
    from faker.generator import random
    from faker.providers.person.en_US import Provider
    from faker.providers.person.person_en import TitleType
    p = Person('en_US')
    p.random = random.Random()
    p.localize = Provider.localize
    p.enum = Provider.enum
    p.random.seed(0)
    assert isinstance(p, Person)

    # execute
    result = p.title(title_type=TitleType.PREFIX)

    # verify
    assert result == 'Mrs.'


# Generated at 2022-06-23 21:46:24.295150
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person(seed=42)
    assert person.social_media_profile(site=SocialNetwork.FACEBOOK) == "https://facebook.com/0"
    assert person.social_media_profile(site=SocialNetwork.TWITTER) == "https://twitter.com/1"
    assert person.social_media_profile(site=SocialNetwork.INSTAGRAM) == "https://instagram.com/2"


# Generated at 2022-06-23 21:46:35.385938
# Unit test for method worldview of class Person
def test_Person_worldview():
    """
    This function tests Person.worldview() for correct output.
    """
    worldview_choices = ['Pantheism',
                         'Materialism',
                         'Marxism',
                         'Hedonism',
                         'Skepticism',
                         'Philosophical materialism',
                         'Cynicism',
                         'Philosophical optimism',
                         'Existentialism',
                         'Nihilism',
                         'Fatalism',
                         'Ubiquitous',
                         'Pessimism',
                         'Stoicism',
                         'Nebulism',
                         'Democratism',
                         'Altruism',
                         'Positivism',
                         'Philosophical idealism',
                         'Philosophy of life',
                         'Zooism',
                         'Egoism',
                         'Other']

# Generated at 2022-06-23 21:46:36.768536
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person.academic_degree() != ""


# Generated at 2022-06-23 21:46:45.619790
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    mask = '##-##/##'
    identifier = p.identifier(mask)
    assert re.match(r'(\d{2}-\d{2}/\d{2})', identifier)
    assert identifier.count("-") == 1
    assert identifier.count("/") == 1

if __name__ == '__main__':
    # Running unit tests
    test_Person_identifier()
    test_Person_telephone()
    test_Person_password()
    test_Person_name_surname()
    test_Person_surname()

# Generated at 2022-06-23 21:46:52.129565
# Unit test for method email of class Person
def test_Person_email():
    from person import Person
    from datetime import datetime
    from random import seed

    # get random seed
    now = datetime.now()
    seed(f"{now.month}/{now.day}/{now.year}")

    person = Person()

    assert person.email() == 'taylorgirl94@baidu.com'
    assert person.email() == 'johnny55@baidu.com'
    assert person.email() == 'lucas_fernandez@yahoo.com'
    assert person.email() == 'johnson@google.com'
    assert person.email() == 'mr.valdez@live.com'
    assert person.email() == 'cheque_1994@live.com'
    assert person.email() == 'johnny99@baidu.com'
    assert person

# Generated at 2022-06-23 21:47:01.055901
# Unit test for method gender of class Person
def test_Person_gender():
    test_cases = (
        ('Male', True), ('Male', False), ('Female', True), ('Female', False),
        ('Male', True), ('Male', False), ('Female', True), ('Female', False),
        ('Male', True), ('Male', False), ('Female', True), ('Female', False),
        ('Male', True), ('Male', False), ('Female', True), ('Female', False),
    )

    Person.seed(42)

    for tc in test_cases:
        assert Person().gender(symbol=tc[1]) == tc[0]


# Generated at 2022-06-23 21:47:04.634300
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    nationality = p.nationality(Gender.FEMALE)
    assert isinstance(nationality, str)
    assert nationality.title() in p._data['nationality'][Gender.FEMALE]

# Generated at 2022-06-23 21:47:08.626837
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # 7368-9488
    assert 7368 <= Person().work_experience(startswith=1990) <= 9488
    assert 7368 <= Person().work_experience(startswith=1990, finishswith=1998) <= 9488
    assert 7368 <= Person().work_experience(startswith=2000, finishswith=2018) <= 9488


# Generated at 2022-06-23 21:47:18.996357
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person(seed=int('80c23b33a0b6a69a1da8f66d', 16))
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person.gender() == 'male'
    assert person

# Generated at 2022-06-23 21:47:25.499802
# Unit test for method weight of class Person
def test_Person_weight():
    weights = [38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90]
    assert Person.weight(minimum=38, maximum=90) in weights

# Generated at 2022-06-23 21:47:27.194415
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    views = person.worldview()
    assert views in WORLDVIEWS



# Generated at 2022-06-23 21:47:29.355103
# Unit test for method first_name of class Person
def test_Person_first_name():
    g = Person()
    assert g.first_name() is not None

# Generated at 2022-06-23 21:47:31.201367
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    print(person.blood_type())


# Generated at 2022-06-23 21:47:33.947224
# Unit test for method avatar of class Person
def test_Person_avatar():
    for _ in range(100):
        string = Person.avatar()
        assert type(string) is str
test_Person_avatar()


# Generated at 2022-06-23 21:47:40.660902
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    assert type(person.avatar()) == str
    assert len(person.avatar()) == 48
    assert type(person.avatar(size=128)) == str
    assert len(person.avatar(size=128)) == 43
    assert type(person.avatar(size=512)) == str
    assert len(person.avatar(size=512)) == 53
    assert type(person.avatar(size=1024)) == str
    assert len(person.avatar(size=1024)) == 59



# Generated at 2022-06-23 21:47:43.399032
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person(random=Random())
    for site in SocialNetwork:
        url = person.social_media_profile(site=site)
        assert isinstance(url, str)
        assert url.startswith('https://')
        assert url.endswith(site.value)



# Generated at 2022-06-23 21:47:45.588213
# Unit test for method political_views of class Person
def test_Person_political_views():
    
    for _ in range(100):
        value = random.Random().choice(PERSON_DATA['political_views'])
        assert Person().political_views() == value


# Generated at 2022-06-23 21:47:46.486144
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    p = Provider()
    print(p.academic_degree())


# Generated at 2022-06-23 21:47:51.193511
# Unit test for method gender of class Person
def test_Person_gender():
    """Test method gender of class Person"""

    p = Person()

    assert p.gender() in ['male', 'female']
    assert p.gender(symbol=True) in ['♂', '♀']
    assert p.gender(iso5218=True) in [0, 1, 2, 9]



# Generated at 2022-06-23 21:47:57.375233
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    assert p.gender(symbol=False) in GENDERS
    assert p.gender(symbol=True) in GENDER_SYMBOLS
    assert p.sex() in GENDERS
    assert p.sex(symbol=True) in GENDER_SYMBOLS
    assert p.sex(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-23 21:48:02.349467
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    """
    Test cases for test_Person_social_media_profile
    """
    fake = Faker()
    profile = fake.social_media_profile(site=SocialNetwork.FACEBOOK)
    assert isinstance(profile, str), \
        "Test #1: Failed test_Person_social_media_profile"


# Generated at 2022-06-23 21:48:04.946074
# Unit test for method gender of class Person
def test_Person_gender():
    print('-- test_Person_gender --')
    # Create instance of class Person
    person = Person()
    print('Your gender is : ', person.gender())


# Generated at 2022-06-23 21:48:09.896177
# Unit test for method sex of class Person
def test_Person_sex():
    """Test case for method sex of class Person."""
    # Arrange
    provider = Person()

    # Act
    actual = provider.sex()

    # Assert
    assert actual in provider._data['sex']

# Generated at 2022-06-23 21:48:10.713672
# Unit test for method height of class Person
def test_Person_height():
    pass

# Generated at 2022-06-23 21:48:15.084079
# Unit test for method surname of class Person
def test_Person_surname():
    assert(Person().surname())
    assert(Person().last_name())
    assert(Person().last_name(gender=Gender.MALE))
    assert(Person().last_name(gender=Gender.FEMALE))
    assert(Person().surname(gender=Gender.MALE))
    assert(Person().surname(gender=Gender.FEMALE))



# Generated at 2022-06-23 21:48:20.020960
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    weight = p.weight()
    assert weight > 1, 'Wrong Return Value'
    assert weight < 200, 'Wrong Return Value'
    
    
    
    
    
    
    
    
    
    


print('Tests passed!')

# Example:
print(Person().weight())

# Output:
48

p = Person()
print(p.weight(20, 30))

# Output:
25


# Generated at 2022-06-23 21:48:21.781764
# Unit test for method weight of class Person
def test_Person_weight():
    provider = Person()
    w = provider.weight(50, 60)
    assert w >= 50
    assert w <= 60

# Generated at 2022-06-23 21:48:25.550615
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person(seed=0)
    actual = p.sexual_orientation()
    expected = "Bisexuality"
    assert_equal(actual, expected) # As of v0.4.0 this assert fails 


# Generated at 2022-06-23 21:48:28.879221
# Unit test for method height of class Person
def test_Person_height():
    obj = Person()
    assert isinstance(obj.height(), str) == True


# Generated at 2022-06-23 21:48:32.419966
# Unit test for method political_views of class Person
def test_Person_political_views():
    test_count = 1000
    key = 0
    result = []
    while key < test_count:
        person = Person.create(random=Random.create())
        political_view = person.political_views()
        if not political_view in result:
            result.append(political_view)
        key += 1
    print("Test method political_views of class Person:\tOK")


# Generated at 2022-06-23 21:48:34.099357
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person()
    for _ in range(10):
        assert p.social_media_profile()

# Generated at 2022-06-23 21:48:45.911700
# Unit test for method political_views of class Person
def test_Person_political_views():
    random_gen = RandomGenerator(seed=42)


# Generated at 2022-06-23 21:48:52.452402
# Unit test for method password of class Person
def test_Person_password():
    print("########## method password of class Person ##########")
    p1 = Person()
    print("p1.password(): ", p1.password())
    print("p1.password(hashed=True): ", p1.password(hashed=True))
    print("p1.password(length=20): ", p1.password(length=20))
    print("p1.password(length=50, hashed=True): ", p1.password(length=50, hashed=True))


# Generated at 2022-06-23 21:48:54.073112
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert len(Person().last_name()) >= 3


# Generated at 2022-06-23 21:49:05.207102
# Unit test for method first_name of class Person
def test_Person_first_name():
    # type: () -> None
    """Test generation of a random first name in class Person."""
    person = Person()

    assert isinstance(person.first_name(), str)
    for gender in Gender:
        assert isinstance(person.first_name(gender), str)

    # Check for existing of generated names
    for name in person.names(count=10):
        assert name in person._data['name']['both']

    for name in person.names(count=10, gender=Gender.MALE):
        assert name in person.names(gender=Gender.MALE)

    for name in person.names(count=10, gender=Gender.FEMALE):
        assert name in person.names(gender=Gender.FEMALE)

# Generated at 2022-06-23 21:49:07.662266
# Unit test for method nationality of class Person
def test_Person_nationality():
    persona = Person()
    assert persona.nationality() in persona._data['nationality']


# Generated at 2022-06-23 21:49:11.749869
# Unit test for method university of class Person
def test_Person_university():
    counter = 0
    for i in range(1000):
        result = Person().university()
        if isinstance(result, str): counter += 1
    print(counter/1000)

test_Person_university()


# Generated at 2022-06-23 21:49:16.451146
# Unit test for method title of class Person
def test_Person_title():
    assert len(Person().title()) > 0
    assert len(Person().title(Gender.male)) > 0
    assert len(Person().title(Gender.female)) > 0
    assert len(Person().title(Gender.androgyne)) > 0
    assert len(Person().title(gender=Gender.androgyne)) > 0
    assert len(Person().title(gender=Gender.androgynous)) > 0
    assert len(Person().title(TitleType.prefix)) > 0
    assert len(Person().title(TitleType.suffix)) > 0


# Generated at 2022-06-23 21:49:28.387979
# Unit test for method username of class Person
def test_Person_username():
    person = Person()

# Generated at 2022-06-23 21:49:33.385029
# Unit test for method telephone of class Person
def test_Person_telephone():
    for mask in (None, '', '###-##-##', '+7-(9##)-###-##-##'):
        assert re.match(r'^\+?\d{2,4}-?\d{2}-?\d{2}-?\d{2}-?\d{2}$',
                        Person().telephone(mask=mask))


# Unit tests for method identifier of class Person

# Generated at 2022-06-23 21:49:35.726087
# Unit test for method height of class Person
def test_Person_height():
    expected = len(Person().height())
    actual = 5
    assert expected == actual


# Generated at 2022-06-23 21:49:38.005305
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    degree = person.academic_degree()
    assert isinstance(degree, str)
    assert degree in person._data['academic_degree']



# Generated at 2022-06-23 21:49:39.715386
# Unit test for method name of class Person
def test_Person_name():
    p = Person()
    assert callable(getattr(p, 'name', None))

# Generated at 2022-06-23 21:49:42.332163
# Unit test for method sex of class Person
def test_Person_sex():
    with pytest.raises(NonEnumerableError):
        person.sex(gender=7)

# Generated at 2022-06-23 21:49:52.985996
# Unit test for method title of class Person
def test_Person_title():

    # -------- Positive tests --------

    # Call the method with title_type=TitleType.prefix and gender=None
    rnd_title = Person.title()
    assert rnd_title in titles_prefix

    # Call the method with title_type=TitleType.prefix and gender=Male
    rnd_title = Person.title(title_type=TitleType.prefix, gender=Male)
    assert rnd_title in titles_prefix_male

    # Call the method with title_type=TitleType.suffix and gender=Male
    rnd_title = Person.title(title_type=TitleType.suffix, gender=Male)
    assert rnd_title in titles_suffix_male

    # Call the method with title_type=TitleType.prefix, gender=Male and seed=99

# Generated at 2022-06-23 21:49:55.587269
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    fake = Faker()
    blood_types = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
    assert fake.blood_type() in blood_types


# Generated at 2022-06-23 21:49:58.911091
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Faker()
    assert provider.social_media_profile(site=SocialNetwork.FACEBOOK) == 'https://facebook.com/k6dv2odff9#4h'


# Generated at 2022-06-23 21:50:02.070854
# Unit test for method name of class Person
def test_Person_name():
    person = Person(seed=1)

    assert person.name(Gender.Male) == 'Kevin'
    assert person.name(Gender.Female) == 'Gladys'
    assert person.name() == 'Gladys'

# Generated at 2022-06-23 21:50:11.677669
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(10):
        random_nationality = Person().nationality()
        assert random_nationality in NATIONALITIES
        if random_nationality.endswith('ian'):
            assert random_nationality.endswith('ian')
        elif random_nationality.endswith('ish'):
            assert random_nationality.endswith('ish')
        elif random_nationality.endswith(('ese'or 'eese')):
            assert random_nationality.endswith(('ese'or 'eese'))

# Generated at 2022-06-23 21:50:23.349990
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    for _ in range(100):
        assert Person().social_media_profile() in [
            'http://facebook.com/Celloid1873',
            'http://twitter.com/Celloid1873',
            'http://flickr.com/Celloid1873',
            'http://googleplus.com/Celloid1873',
            'http://livejournal.com/Celloid1873',
            'http://instagram.com/Celloid1873',
            'http://vkontakte.com/Celloid1873',
            'http://skype.com/Celloid1873',
            'http://youtube.com/Celloid1873',
            'http://tumblr.com/Celloid1873'
        ]

test_Person_social_media_profile()


# Generated at 2022-06-23 21:50:34.831100
# Unit test for method telephone of class Person
def test_Person_telephone():
    """
    Method telephone should return the phone number with calling code.
    """
    rnd = Random()
    rnd.set_seed(int=42)
    per = Person(random=rnd)
    assert per.telephone() == "1-(337)-185-1024"
    assert per.telephone() == "376-(077)-415-4860"
    assert per.telephone() == "238-(447)-222-0520"
    assert per.telephone() == "244-(221)-844-1004"
    assert per.telephone() == "1-(161)-163-4321"
    assert per.telephone() == "52-(345)-223-4032"
    assert per.telephone() == "91-(741)-888-2974"

# Generated at 2022-06-23 21:50:36.750671
# Unit test for method age of class Person
def test_Person_age():
    person = Person()
    assert type(person.age()) == int
    pass

# Generated at 2022-06-23 21:50:41.875937
# Unit test for method political_views of class Person
def test_Person_political_views():
    # Arrange
    person = Person(seed=34)
    expected_result = ['Socialism', 'Socialism', 'Socialism', 'Socialism', 'Socialism', 'Socialism', 'Socialism', 'Socialism', 'Socialism', 'Socialism']
    # Act
    actual_result = [person.political_views() for _ in range(10)]
    # Assert
    assert actual_result == expected_result

# Generated at 2022-06-23 21:50:51.969825
# Unit test for method gender of class Person
def test_Person_gender():
    pr = Person(random=MockRandom())

    pr.random.choice.side_effect = (
        'Male', 'Female', 'Not applicable'
    )

    assert pr.gender() == 'Male'
    assert pr.gender() == 'Female'
    assert pr.gender() == 'Not applicable'
    assert pr.sex() == 'Male'
    assert pr.sex() == 'Female'
    assert pr.sex() == 'Not applicable'

    pr.random.choice.side_effect = ('123', '456', '789')

    assert pr.gender(iso5218=True) == '123'
    assert pr.gender(iso5218=True) == '456'
    assert pr.gender(iso5218=True) == '789'
    assert pr.sex(iso5218=True) == '123'

# Generated at 2022-06-23 21:50:55.198834
# Unit test for method avatar of class Person
def test_Person_avatar():
    testperson = Person()
    got = testperson.avatar()
    return got

print("test_Person_avatar: ",test_Person_avatar())
