

# Generated at 2022-06-23 21:41:04.055498
# Unit test for method avatar of class Person
def test_Person_avatar():
    # Save image to local disk
    import io, tempfile
    import requests as rq
    from PIL import Image

    person = Person()
    url = person.avatar()

    pth = tempfile.mkdtemp()

    r = rq.get(url)
    with open(pth + '/img.png', 'wb') as f:
        f.write(r.content)

    # Check dimensions of image
    img = Image.open(f.name)
    assert img.width == 256
    assert img.height == 256

    # Call Person.avatar() with size
    # and check dimensions of new image
    url = person.avatar(512)

    r = rq.get(url)

# Generated at 2022-06-23 21:41:06.461909
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    assert person.last_name(Gender.MALE) != ""
    
    

# Generated at 2022-06-23 21:41:07.901061
# Unit test for method language of class Person
def test_Person_language():
    p = Person()
    assert_instance(p.language(), str)

# Generated at 2022-06-23 21:41:10.968266
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person(random=Random())
    assert provider.sexual_orientation() in [
        'Heterosexuality', 'Homosexuality', 'Bisexuality'
    ]

# Generated at 2022-06-23 21:41:13.832759
# Unit test for method password of class Person
def test_Person_password():
  results = []
  for i in range(1, 100):
    results.append(Person().password(4))
  assert all(isinstance(i, str) for i in results)
  assert len(set(results)) == 100

  # Unit test for method identifier of class Person

# Generated at 2022-06-23 21:41:23.722295
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person("ru_RU") # We create an object
    sex = person.sex() # Select a random sex
    assert sex in ["Мужской", "Женский"]

    
    # We create an object
    person = Person("ru_RU")
    sex = person.sex()
    assert sex in ["Мужской", "Женский"]

    sex = person.sex(iso5218=True)
    assert sex in [1, 2]
    
    sex = person.sex(symbol=True)
    assert sex in ["♂", "♀"]


    
    # We create an object
    person = Person("en_US")
    sex = person.sex()

# Generated at 2022-06-23 21:41:31.684858
# Unit test for method views_on of class Person
def test_Person_views_on():
    from hypothesis import given
    from hypothesis import settings
    from hypothesis import strategies

    from .data import Data

    settings.register_profile(
        "ci",
        deadline=None,
        suppress_health_check=[HealthCheck.too_slow]
    )
    settings.load_profile("ci")

    @given(
        seed=strategies.integers(min_value=0, max_value=9999),
        gender=strategies.sampled_from(Data.GENDER_DATA),
        age=strategies.integers(min_value=1, max_value=99),
        is_adult=strategies.booleans()
    )
    def test(seed, gender, age, is_adult):
        random = Random()
        random.seed(seed)

        person = Person(random)
       

# Generated at 2022-06-23 21:41:33.624473
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    occupation = person.occupation()
    assert occupation in person._data['occupation']


# Generated at 2022-06-23 21:41:40.646084
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person(random=Random())

    # Test normal
    for i in range(0, 5):
        assert person.gender(iso5218=True) in [0, 1, 2, 9]
        assert person.gender() in person._data['gender']

    # Test arguments
    for i in range(0, 5):
        assert person.gender(symbol=True) in GENDER_SYMBOLS

# Generated at 2022-06-23 21:41:43.014368
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(None)
    assert p.nationality() in p._data['nationality']

test_Person_nationality()

# Generated at 2022-06-23 21:41:45.871782
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    name = person.first_name()
    assert isinstance(name, str) and len(name) > 3
    assert name[0].isupper()

# Generated at 2022-06-23 21:41:49.687748
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'nhdemartineau74@yahoo.ca'

# Generated at 2022-06-23 21:41:57.712198
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # create copy of method social_media_profile
    method = Person.social_media_profile.__func__
    # create object of class Person with random seed
    person = Person(seed=random.randint(0, 9999))
    # create dictionary with keys and values
    args = {}
    # create list with old values of object person
    old_values = [
            person._data,
            person.random,
        ]
    # create list with names of arguments
    params = [
            'site',
        ]
    # create list with values of arguments
    values = [
            None,
        ]
    # fill dictionary with keys and values
    for i, param in enumerate(params):
        args[param] = values[i]
    # call method for object person with args
    profile = method(person, **args)


# Generated at 2022-06-23 21:42:02.303551
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person.name()
    assert person.surname()
    assert person.full_name()
    assert person.username()
    assert person.password()
    assert person.email()
    assert person.social_media_profile()
    assert person.gender()
    assert person.height()
    assert person.weight()
    assert person.blood_type()
    assert person.sexual_orientation()
    assert person.nationality()
    assert person.university()
    assert person.academic_degree()
    assert person.language()
    assert person.telephone()
    assert person.avatar()

# Generated at 2022-06-23 21:42:04.003757
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert isinstance(Person().work_experience(), int)
    assert 0 <= Person().work_experience() <= 100
    assert 0 <= Person(maximum_years_in_job=150).work_experience() <= 150



# Generated at 2022-06-23 21:42:05.880831
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person()
    assert isinstance(person.identifier(), str)


# Generated at 2022-06-23 21:42:15.896319
# Unit test for method worldview of class Person
def test_Person_worldview():
    r = Person(seed=42)
    assert r.worldview() == "Christianity"
    assert r.worldview() == "Agnosticism"
    assert r.worldview() == "Christianity"
    assert r.worldview() == "Christianity"
    assert r.worldview() == "Christianity"
    assert r.worldview() == "Atheism"
    assert r.worldview() == "Buddhism"
    assert r.worldview() == "Atheism"
    assert r.worldview() == "Christianity"
    assert r.worldview() == "Christianity"
    assert r.worldview() == "Christianity"
    assert r.worldview() == "Taoism"
    assert r.worldview() == "Buddhism"

# Generated at 2022-06-23 21:42:22.540312
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()


# Generated at 2022-06-23 21:42:24.369619
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert isinstance(Person.political_views(seed=123,), str)

# Generated at 2022-06-23 21:42:35.662800
# Unit test for method telephone of class Person
def test_Person_telephone():
    from faker.providers.person import random
    from faker.utils.text import slugify
    from faker.providers.person.utils import mask_format
    from faker.providers.person.utils import digit_placeholder
    from iso3166 import countries
    locale = '_'

    kwargs = {
        'mask': '+##-###-###-###',
        'placeholder': '#',
    }

    calling_code = random.choice(CALLING_CODES)
    random_country = random.choice(list(countries))
    phone_ext = random.random_int(100, 999)

    number = random.custom_code(mask=kwargs['mask'], digit=kwargs['placeholder'])

    for country in countries:
        kwargs['mask'] = mask_

# Generated at 2022-06-23 21:42:37.569330
# Unit test for method university of class Person
def test_Person_university():
    test = Person('en')
    assert isinstance(test.university(), str)


# Generated at 2022-06-23 21:42:45.200209
# Unit test for method title of class Person
def test_Person_title():
    person = Person('en')
    assert person.title() in ('Dr', 'Ms', 'Mrs', 'Mr')
    assert person.title(title_type=TitleType.SUFFIX) in ('Jr', 'Sr', 'I', 'II')
    assert person.title(title_type=TitleType.PREFIX) in ('Prof', 'Dr', 'Mr')
    assert person.title(title_type=TitleType.PREFIX, gender=Gender.MALE) in ('Prof', 'Dr', 'Mr')
    assert person.title(title_type=TitleType.PREFIX, gender=Gender.FEMALE) in ('Prof', 'Dr', 'Mrs')
    assert person.title(title_type=TitleType.PREFIX, gender=Gender.NOT_SURE) in ('Prof', 'Dr', 'Ms')
# Test for

# Generated at 2022-06-23 21:42:52.693000
# Unit test for method password of class Person
def test_Person_password():
    from datagenerator.utils import SeedGenerator
    seed = SeedGenerator(b'1234567890abcdefghijklmnopqrstuvwxyz')

    rnd = Random(seed)
    p = Person(rnd)
    password_1 = p.password(seed)
    password_2 = p.password(seed)
    assert password_1 == password_2
    seed.new_seed()
    password_3 = p.password(seed)
    assert password_1 != password_3
    assert password_2 != password_3

# Generated at 2022-06-23 21:42:55.650925
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person(seed=1)
    result = person.sexual_orientation()
    assert result == 'Heterosexuality'

# Generated at 2022-06-23 21:42:57.863295
# Unit test for method political_views of class Person
def test_Person_political_views():
  x = Person()
  out = x.political_views()
  assert out in PERSON['political_views']



# Generated at 2022-06-23 21:43:03.214352
# Unit test for method height of class Person
def test_Person_height():
    """Test for method height of class Person."""

    from random import Random
    from datetime import datetime
    from .enums import Gender, SocialNetwork, Profile

    # Arrange
    random = Random(datetime.now())
    provider = Person(random)

    # Act
    height = provider.height()

    # Assert
    assert isinstance(height, str)



# Generated at 2022-06-23 21:43:07.549469
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    first_name = person.first_name()
    assert first_name != ''
    assert isinstance(first_name, str)
    assert first_name != None


# Generated at 2022-06-23 21:43:11.904088
# Unit test for method name of class Person
def test_Person_name():
    # Define test values
    gender = Gender.MALE
    first_names = ('Alexey', 'Oleg', 'Evgeniy', 'Artyom')
    instance = Person(first_names=first_names, seed=123)
    assert instance.name(gender) == 'Alexey'



# Generated at 2022-06-23 21:43:13.531343
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-23 21:43:22.361852
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    """Method sexual_orientation of class Person"""
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()
    assert 'Heterosexuality' == Person.sexual_orientation()


# Generated at 2022-06-23 21:43:23.733043
# Unit test for method height of class Person
def test_Person_height():
    height = Person().height()
    assert height is not None
    assert isinstance(height, str)

# Generated at 2022-06-23 21:43:30.271844
# Unit test for method first_name of class Person
def test_Person_first_name():
    cases = (
        ('Bradley', ('Bradley', ), {}),
        ('Harvey', ('Harvey', ), {'gender': Gender.male}),
        ('Walker', ('Walker', ), {'gender': Gender.male}),
        ('Kiara', ('Kiara', ), {'gender': Gender.female}),
        ('Ciara', ('Ciara', ), {'gender': Gender.female}),
    )
    for case, names, kwargs in cases:
        assert Person().first_name(*names, **kwargs) == case



# Generated at 2022-06-23 21:43:32.578748
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality() in data['nationality']

# Generated at 2022-06-23 21:43:35.987208
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    url = person.social_media_profile()

    assert url.startswith('https://')


# Unit tests for class Person

# Generated at 2022-06-23 21:43:47.367388
# Unit test for method username of class Person
def test_Person_username():
    from faker import Faker
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.person.hy_AM import Provider as PersonProviderhy_AM

    # Tests for English language
    fake_en = Faker(['en_US'])
    fake_en.add_provider(PersonProvider)
    assert fake_en.person.username()
    assert fake_en.person.username(template='U_d')
    assert fake_en.person.username(template='U.d')
    assert fake_en.person.username(template='U-d')
    assert fake_en.person.username(template='UU-d')
    assert fake_en.person.username(template='UU.d')
    assert fake_en.person.username(template='UU_d')
   

# Generated at 2022-06-23 21:43:52.606860
# Unit test for method sex of class Person
def test_Person_sex():
    p1 = Person()
    assert isinstance(p1.sex(), str)
    assert isinstance(p1.sex(symbol=True), str)
    assert isinstance(p1.sex(iso5218=True), int)
    
    assert p1.sex() == p1.gender()
    

# Generated at 2022-06-23 21:43:53.718483
# Unit test for method telephone of class Person
def test_Person_telephone():
    phone = Person().telephone()
    assert Phone().validate(phone)

# Generated at 2022-06-23 21:43:55.180249
# Unit test for method height of class Person
def test_Person_height():
    Person.height()
    # 1.68

# Generated at 2022-06-23 21:43:57.783708
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert len(Person().political_views()) == Person.political_views.return_type.__len__()


# Generated at 2022-06-23 21:43:59.037506
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person(random=Random())
    person.occupation()

# Generated at 2022-06-23 21:44:00.662210
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert isinstance(p, Person)



# Generated at 2022-06-23 21:44:03.289009
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Testing ``nationality``."""
    obj = Person()
    assert all(isinstance(obj.nationality(), str) for _ in range(100))



# Generated at 2022-06-23 21:44:04.311081
# Unit test for method username of class Person
def test_Person_username():
    assert Person.username()



# Generated at 2022-06-23 21:44:06.812232
# Unit test for method weight of class Person
def test_Person_weight():
    random = FakeRandom(4, 0.3, 90)
    person = Person(random)
    assert person.weight(38, 90) == 85

# Generated at 2022-06-23 21:44:14.145775
# Unit test for constructor of class Person
def test_Person():
    
    # Create a provider of data for the class Person and initialize it.
    person = Person(seed=43)

    # Check the attribute data for class Person.
    assert isinstance(person.data, dict)
    
    # Check the attribute locale for class Person.
    assert isinstance(person.locale, str)
    
    # Check the attribute seed for class Person.
    assert isinstance(person.seed, int)
    
    # Check the attribute random for class Person.
    assert isinstance(person.random, Random)

    # The same but create a provider of data for the class Person without seeding.
    person = Person()
    
    # Check the attribute data for class Person.
    assert isinstance(person.data, dict)
    
    # Check the attribute locale for class Person.

# Generated at 2022-06-23 21:44:22.970836
# Unit test for method title of class Person
def test_Person_title():
    # Test with male title (+)
    mock_gender = Gender.MALE
    mock_title_type = TitleType.PREFIX
    mock_data = {
        'title': {
            'male': {
                'prefix': ['Mr.', 'Mister', 'Dr.'],
                'suffix': ['Jr.', 'Sr.', 'I', 'II', 'III', 'IV', 'V'],
            },
            'female': {
                'prefix': ['Ms.', 'Mrs.', 'Madam', 'Dr.'],
                'suffix': ['Jr.', 'Sr.', 'I', 'II', 'III', 'IV', 'V'],
            },
        }
    }

    person = Person(mock_data)
    result = person.title(mock_gender, mock_title_type)

# Generated at 2022-06-23 21:44:27.659505
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    cases = (
        ('twitter', 'https://twitter.com/test'),
        ('facebook', 'https://facebook.com/test'),
        ('github', 'https://github.com/test'),
        ('vk', 'https://vk.com/test'),
        ('instagram', 'https://instagram.com/test'),
        ('telegram', 'https://telegram.me/test'),
    )

    for site, result in cases:
        person = Person(seed=1)
        assert person.social_media_profile(site) == result

# Generated at 2022-06-23 21:44:29.044120
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    assert isinstance(person.university(), six.string_types)

# Generated at 2022-06-23 21:44:35.527823
# Unit test for method age of class Person
def test_Person_age():
    import random
    random_byte = random.getrandbits(8)
    random_int = random.randint(0,10)
    random_float = random.uniform(0,1)
   
    assert_equal(Person().age(), random_int)
    assert_equal(Person().age(minimum=random_int,
                              maximum=0), random_int)
    assert_equal(Person(seed=random_byte).age(), random_int)

# Generated at 2022-06-23 21:44:38.002268
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    provider = Person()
    for _ in range(100):
        result = provider.blood_type()
        assert result in BLOOD_GROUPS



# Generated at 2022-06-23 21:44:48.272514
# Unit test for method email of class Person
def test_Person_email():
    # Set seed for testing.
    Person.seed(4545)
    temp = Person.email()
    assert temp == 'foretime10@live.com'
    # Set seed for testing.
    Person.seed(4545)
    temp = Person.email()
    assert temp == 'foretime10@live.com'
    # Set seed for testing.
    Person.seed(4545)
    temp = Person.email()
    assert temp == 'foretime10@live.com'
    # Set seed for testing.
    Person.seed(4545)
    temp = Person.email()
    assert temp == 'foretime10@live.com'
    # Set seed for testing.
    Person.seed(4545)
    temp = Person.email()
    assert temp == 'foretime10@live.com'
    # Set seed

# Generated at 2022-06-23 21:44:49.587730
# Unit test for method language of class Person
def test_Person_language():
    assert len(Person().language()) >= 3


# Generated at 2022-06-23 21:44:56.228791
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Arrange
    person = Person()
    person.random.seed(0)
    # Act
    res = person.telephone(mask='+7 (###) ####-####')
    exp = '+7 (422) 4949-9160'
    # Assert
    assert(res == exp)


# Generated at 2022-06-23 21:45:05.584361
# Unit test for method height of class Person
def test_Person_height():
    data = [
        {
            "input": {},
            "expected": 1.5,
            "strict": False
        },
        {
            "input": {"minimum": 1.5},
            "expected": 1.5,
            "strict": False
        },
        {
            "input": {"maximum": 2.0},
            "expected": True,
            "strict": False
        },
        {
            "input": {"minimum": 1.5, "maximum": 2.0},
            "expected": True,
            "strict": False
        },
        {
            "input": {"minimum": 1.5, "maximum": 2.0},
            "expected": True,
            "strict": False
        }
    ]

    def wrapper(func, dct: dict):
        inputData = dct

# Generated at 2022-06-23 21:45:07.091060
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    height = person.height()
    assert height
    assert isinstance(height, str)


# Generated at 2022-06-23 21:45:18.471810
# Unit test for method first_name of class Person
def test_Person_first_name():
    random.seed(0)

# Generated at 2022-06-23 21:45:20.171488
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    from faker import Faker
    fake=Faker()
    print(fake.academic_degree())

# Generated at 2022-06-23 21:45:29.990309
# Unit test for constructor of class Person
def test_Person():
    gen = Person()
    assert isinstance(gen, Person)
    assert gen.random.seed is None

    data = gen.random.dummy(count=1000)

    for gender in Gender:
        assert gender in data['gender']

    for orientation in Sexuality:
        assert orientation in data['sexuality']

    for network in SocialNetwork:
        assert network in data['social_network']

    for gender in Gender:
        for title in TitleType:
            assert title in data['title'][gender.name]

    assert isinstance(data['language'], list)
    assert isinstance(data['nationality'], dict)
    assert isinstance(data['nationality']['male'], list)
    assert isinstance(data['nationality']['female'], list)


# Generated at 2022-06-23 21:45:33.237039
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Arrange
    person = Person()

    # Act
    full_name = person.full_name()

    # Assert
    assert(full_name != '')


# Generated at 2022-06-23 21:45:43.070124
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    assert person.full_name(gender=Gender.FEMALE).split()[0] in list(FEMALE_NAMES)
    assert person.full_name(gender=Gender.MALE).split()[0] in list(MALE_NAMES)
    if isinstance(person.full_name().split()[0],str):
        gender = guess_gender(person.full_name().split()[0])
        gender = gender.name
        assert gender in list(Gender.__members__.keys())
        
test_Person_full_name()


# Generated at 2022-06-23 21:45:46.108683
# Unit test for method university of class Person
def test_Person_university():
    print('test_Person_university')
    p = Person()
    university_list = []
    university_list.append(p.university())
    assert len(university_list) > 0
    print(university_list)


# Generated at 2022-06-23 21:45:58.277266
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    provider = Person(seed=451)

    assert provider.blood_type() == 'B-'
    assert provider.blood_type() == 'B-'
    assert provider.blood_type() == 'B-'

    provider = Person(seed=451)
    assert provider.blood_type() == 'B-'

    provider = Person(seed=451)
    assert provider.blood_type() == 'B-'

    provider = Person(seed=451)
    assert provider.blood_type() == 'B-'

    provider = Person(seed=451)
    assert provider.blood_type() == 'B-'

    provider = Person(seed=451)
    assert provider.blood_type() == 'B-'

    provider = Person(seed=451)
    assert provider.blood_type() == 'B-'

    provider = Person(seed=451)

# Generated at 2022-06-23 21:46:05.273627
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person('en')
    person.random = Random()
    person.random.seed(1)
    assert person.sexual_orientation() == 'Transgender'
    assert person.random.choice(['Female homosexuality', 'Male homosexuality',
                                 'Heterosexuality']) == 'Male homosexuality'
    assert person.random.choice(['Female homosexuality', 'Male homosexuality',
                                 'Heterosexuality']) == 'Heterosexuality'
    assert person.random.choice(['Female homosexuality', 'Male homosexuality',
                                 'Heterosexuality']) == 'Female homosexuality'
    assert person.random.choice(['']) == ''
    assert person.random.choice(['']) == ''
    assert person.random.choice(['']) == ''
    assert person.random.choice(['']) == ''

# Generated at 2022-06-23 21:46:06.141963
# Unit test for method worldview of class Person
def test_Person_worldview():
    assert Person.worldview(Person()) in Person._data['worldview']


# Generated at 2022-06-23 21:46:10.839687
# Unit test for method gender of class Person
def test_Person_gender():
    for _ in range(1000):
        with Person.override_default_locale('en'):
            gender = Person().sex()
            assert gender in GENDERS
            assert gender in SEX_ENUM_CODES

        with Person.override_default_locale('ru'):
            gender = Person().sex()
            assert gender in GENDERS
            assert gender in SEX_ENUM_CODES

        with Person.override_default_locale('en'):
            gender = Person().sex(iso5218=True)
            assert gender in SEX_ISO5218_CODES

        with Person.override_default_locale('ru'):
            gender = Person().sex(iso5218=True)
            assert gender in SEX_ISO5218_CODES


# Generated at 2022-06-23 21:46:14.359605
# Unit test for method language of class Person
def test_Person_language():
    person = faker_locale_ru.Person()

    for _ in range(100):
        language = person.language()
        assert language in PERSON_LANGUAGES_RU


# Generated at 2022-06-23 21:46:17.187095
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    assert person.work_experience() is None

# Generated at 2022-06-23 21:46:18.826374
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    assert(type(p.gender()) == str)

# Generated at 2022-06-23 21:46:20.122271
# Unit test for method views_on of class Person
def test_Person_views_on():
    """Test the self.views_on() method."""
    data = ['Negative', 'Positive']
    assert Person.views_on(Mock()) in data

# Generated at 2022-06-23 21:46:23.243851
# Unit test for method avatar of class Person
def test_Person_avatar():
    """Test the method avatar of class Person."""
    person = Person()
    rv = person.avatar()

    assert "https://api.adorable.io/avatars/" in rv

# Generated at 2022-06-23 21:46:31.136437
# Unit test for method identifier of class Person
def test_Person_identifier():
    values = {
        '##-##/##': (lambda v: re.fullmatch(r'\d{2}-\d{2}/\d{2}', v)),
        '##T##T##T##T##T##T': (lambda v: re.fullmatch(r'\d{2}[A-Z]\d{2}[A-Z]\d{2}[A-Z]\d{2}[A-Z]\d{2}[A-Z]\d{2}', v)),
        '@@@@@#####': (lambda v: re.fullmatch(r'[A-Za-z]{5}\d{5}', v)),
    }


# Generated at 2022-06-23 21:46:36.683216
# Unit test for method worldview of class Person
def test_Person_worldview():
    """Test worldview of class Person."""
    worldviews = [
        'Agnosticism',
        'Atheism',
        'Christianity',
        'Hinduism',
        'Islam',
        'Judaism',
        'Paganism',
        'Pantheism',
    ]
    results = [Person().worldview() for _ in range(100)]
    assert all([i in worldviews for i in results])

# Generated at 2022-06-23 21:46:41.002758
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    result = person.full_name()
    assert isinstance(result, str), \
        f'Must be str, not {type(result).__name__}'
    assert result != '', \
        'Must be not empty str'


# Generated at 2022-06-23 21:46:47.495810
# Unit test for method full_name of class Person
def test_Person_full_name():
    person_g = Person()
    person_b = Person(gender=Gender.FEMALE)
    person_m = Person(gender=Gender.MALE)

    name_gender = person_g.full_name()

    name_male = person_m.full_name()
    name_female = person_b.full_name()

    assert name_male != name_female
    assert name_gender != name_male != name_female



# Generated at 2022-06-23 21:46:48.547187
# Unit test for method password of class Person
def test_Person_password():
    assert not Person.password() == Person.password()

test_Person_password()

# Generated at 2022-06-23 21:46:52.892265
# Unit test for method weight of class Person
def test_Person_weight():
    P = Person()
    assert callable(P.weight)
    res = P.weight()
    assert isinstance(res, int)
    res = P.weight(maximum=2000)
    assert isinstance(res, int)
    res = P.weight(minimum=1, maximum=10)
    assert isinstance(res, int)

# Generated at 2022-06-23 21:47:00.810908
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = Provider(123)
    test_cases = (
        {'gender': Gender.female, 'expected': 'Langosch'},
        {'gender': Gender.male, 'expected': 'Mattern'}
    )

    for arguments, expected in test_cases:
        with allure.step("Enter test data: {0}".format(arguments)):
            result = provider.last_name(**arguments)
            assert result == expected



# Generated at 2022-06-23 21:47:06.224290
# Unit test for constructor of class Person
def test_Person():
    # Constructor must check type of seed
    with pytest.raises(TypeError):
        Person(seed=1)

    # Constructor must return Person provider
    provider = Person(seed=None)
    assert isinstance(provider, Person)

    # Check type of public properties
    assert isinstance(provider.local, Local)
    assert isinstance(provider.random, Random)



# Generated at 2022-06-23 21:47:09.190862
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    result = person.avatar()
    assert isinstance(result, str)
    assert result.startswith('https://api.adorable.io/avatars')

# Generated at 2022-06-23 21:47:10.513909
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person(random=RND).nationality() in NATIONALITIES

# Generated at 2022-06-23 21:47:11.747784
# Unit test for method title of class Person
def test_Person_title():
    for _ in range(10):
        assert Person().title() in TITLES

# Generated at 2022-06-23 21:47:14.673282
# Unit test for method password of class Person
def test_Person_password():
    random_instance = Random()
    provider = Person(random_instance)

    assert isinstance(provider.password(), str)
import pytest


# Generated at 2022-06-23 21:47:18.416217
# Unit test for method password of class Person
def test_Person_password():
    assert len(Person().password()) == 8
    assert Person().password(16).isalnum()
    m = hashlib.md5()
    m.update('password'.encode())
    assert len(Person().password(hashed=True)) == 32


# Generated at 2022-06-23 21:47:23.329824
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    provider = Person()
    assert re.match(r'\d*\.\d{1} years', provider.work_experience())

# Generated at 2022-06-23 21:47:26.885385
# Unit test for method occupation of class Person
def test_Person_occupation():
    """Unit test for method occupation of class Person.
     
    :return: 
    :rtype: 
    
    """
    p = Person()
    sample = p.occupation()
    assert isinstance(sample, str)

# Generated at 2022-06-23 21:47:29.458418
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    assert p.sexual_orientation() in p._data['sexuality']

# Generated at 2022-06-23 21:47:31.676909
# Unit test for method language of class Person
def test_Person_language():

    person = Person()
    lang = person.language()

    assert lang in LANGUAGES


# Generated at 2022-06-23 21:47:33.187148
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    gender = person.gender()
    assert gender in ('Man', 'Woman')
    assert type(gender) is str



# Generated at 2022-06-23 21:47:39.014964
# Unit test for method full_name of class Person
def test_Person_full_name():
    from faker import random
    from pprint import pprint
    from faker.providers.person.ru_RU import Provider
    from faker.providers.person.en_US import Provider as Provider_en_US

    pprint(Provider._get_full_name(random),"Russian")
    pprint(Provider_en_US._get_full_name(random),"English USA")
    
test_Person_full_name()


# Generated at 2022-06-23 21:47:45.401520
# Unit test for method title of class Person
def test_Person_title():
    import json
    from pprint import pprint
    from pathlib import Path

    from faker import Faker
    from faker.config import DEFAULT_LOCALE

    fake = Faker()

    for gender in Gender:
        for title_type in TitleType:
            title = fake.title(gender, title_type)
            print(title)

    folder = Path('locales/{}'.format(DEFAULT_LOCALE))
    filename = 'title.json'
    path_name = folder.joinpath(filename)

    with open(str(path_name)) as f:
        data = json.load(f)

    pprint(data)
test_Person_title()


# Generated at 2022-06-23 21:47:47.940040
# Unit test for method avatar of class Person
def test_Person_avatar():
    from random import seed
    from pprint import pprint
    from faker.providers.date_time import datetime

    seed(int(datetime.now().strftime('%f')))
    person = Person(Random())
    pprint(person.avatar())

# Generated at 2022-06-23 21:47:51.655740
# Unit test for method language of class Person
def test_Person_language():
    # Initialization object
    person = Person()

    # Get a random language
    language = person.language()

    # Check result
    assert isinstance(language, str)



# Generated at 2022-06-23 21:48:01.612607
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert_true(isinstance(p, Person))
    assert_true(p.seed is None)
    assert_equal(p.random, Fal.random)
    assert_true(isinstance(p._data, dict))

    p = Person(seed=3)
    assert_true(isinstance(p, Person))
    assert_equal(p.seed, 3)
    assert_true(isinstance(p._data, dict))

    p = Person(data=UPPERCASE_DATA)
    assert_true(isinstance(p, Person))
    assert_equal(p.seed, Fal.random.seed)
    assert_equal(p._data, UPPERCASE_DATA)

# Generated at 2022-06-23 21:48:03.537328
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for i in range(10):
        assert type(Person().blood_type()) is str

# Generated at 2022-06-23 21:48:08.608490
# Unit test for method first_name of class Person
def test_Person_first_name():
    # GIVEN: Create a Person object
    person = Person()

    # WHEN
    name = person.first_name()

    # THEN
    assert isinstance(name, str)
    assert 0 < len(name) <= 50



# Generated at 2022-06-23 21:48:14.252918
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    assert len(person.first_name())>= 2
    name = person.first_name(gender=Gender.MALE)
    assert type(name) is str
    assert len(name) >= 2
    assert len(person.first_name(gender=Gender.FEMALE))>= 2
    assert type(person.first_name(gender=Gender.UNKNOWN)) is str


# Generated at 2022-06-23 21:48:18.556666
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    for i in range(100):
        assert re.match(
            r'^\+?\d{2,3}[-_\.]?\d{2,3}[-_\.]?\d{2,3}[-_\.]?\d{2,3}$',
            p.telephone())

# Generated at 2022-06-23 21:48:21.007104
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    result = person.sex()
    assert person.sex() in ("Male", "Female")
    assert isinstance(result, str)


# Generated at 2022-06-23 21:48:22.572058
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    sex = person.sex()
    assert sex in person._data['gender']
    

# Generated at 2022-06-23 21:48:23.658534
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    assert person.sex() in GENDERS


# Generated at 2022-06-23 21:48:25.456130
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    gender = Gender.FEMALE
    assert person.first_name(gender) in person._data['name'][gender.value]



# Generated at 2022-06-23 21:48:26.964113
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person(random=Random())
    weight = p.weight()
    assert weight >= 38
    assert weight <= 90


# Generated at 2022-06-23 21:48:29.263573
# Unit test for method avatar of class Person
def test_Person_avatar():
    obj = Person()
    assert isinstance(obj.avatar(), str)

# Generated at 2022-06-23 21:48:30.709345
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    country = person.nationality('Russia')

    assert type(country) == str
    assert country == 'Russia'

# Generated at 2022-06-23 21:48:38.238872
# Unit test for method username of class Person
def test_Person_username():
    p = Person(seed=1)

    # Test case 1
    assert p.username() == 'matthew23'

    # Test case 2
    p.random.seed(1)
    assert p.username('U-d') == 'C_10'

    # Test case 3
    p.random.seed(1)
    assert p.username('l-d') == 'ryand43'

    # Test case 4
    p.random.seed(1)
    assert p.username('Ud') == 'Ib79'

    # Test case 5
    p.random.seed(1)
    assert p.username('l.d') == 'robyn18'

    # Test case 6
    p.random.seed(1)
    assert p.username('l_d') == 'sharon36'

    # Test case 7

# Generated at 2022-06-23 21:48:41.370544
# Unit test for method last_name of class Person
def test_Person_last_name():
    result = []
    for i in range(100):
        result.append(Person.last_name(i) for i in range(100))
    assert len(list(set(result))) >= 90



# Generated at 2022-06-23 21:48:43.223584
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person."""
    Person()

# Generated at 2022-06-23 21:48:44.568753
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(50):
        worldview = Person.worldview()
        assert worldview in ['Atheism', 'Deism', 'Determinism', 'Pantheism', 'Transcendentalism']



# Generated at 2022-06-23 21:48:48.793548
# Unit test for method university of class Person
def test_Person_university():
    # arrange
    import random
    expected = "СПбГУ"
    rnd = random.Random(10)
    provider = Person(rnd)
    actual = provider.university()
    # assert
    assert actual == expected

# Generated at 2022-06-23 21:48:50.607181
# Unit test for method telephone of class Person
def test_Person_telephone():
    with pytest.raises(ValueError):
        Person().telephone(mask='#')



# Generated at 2022-06-23 21:48:57.301207
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from faker.providers.person import Person
    from faker.providers.date_time.en_CA import Provider as DateTimeProvider
    # Instantiation of Person class
    person_obj = Person(Person.random)
    # Creation a mock object for object DateTimeProvider
    # And adding it to class Person
    person_obj.date_time = DateTimeProvider(Person.random)
    # Invocation of work_experience method
    work_experience = person_obj.work_experience()
    # Execution of code of method work_experience
    if isinstance(work_experience, dict):
        # Check that dict contains key «start_date»
        assert 'start_date' in work_experience
        # Check that dict contains key «end_date»
        assert 'end_date' in work_experience
        #

# Generated at 2022-06-23 21:48:58.326457
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person(random=Random())
    assert isinstance(person.academic_degree(), str)

# Generated at 2022-06-23 21:49:01.600669
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    tester = Person
    error = False
    try:
        tester.social_media_profile()
    except Exception:
        error = True
    assert error is False

# Generated at 2022-06-23 21:49:10.793005
# Unit test for method last_name of class Person
def test_Person_last_name():
    from faker import Faker
    from faker import Provider
    from faker.providers.person.ru_RU import Provider as Provider_ru_RU
    from faker.providers.person.en_US import Provider as Provider_en_US
    from faker.providers.person.it_IT import Provider as Provider_it_IT
    from faker.providers.person.fa_IR import Provider as Provider_fa_IR
    from faker.providers.person.ja_JP import Provider as Provider_ja_JP
    from faker.providers.person.ar_EG import Provider as Provider_ar_EG
    from faker.providers.person.sl_SI import Provider as Provider_sl_SI
    from faker.providers.person.tr_TR import Provider as Provider_tr_TR

# Generated at 2022-06-23 21:49:13.503908
# Unit test for method name of class Person
def test_Person_name():
    assert person.name(Gender.MALE) in NAME_MALE
    assert person.name(Gender.FEMALE) in NAME_FEMALE


# Generated at 2022-06-23 21:49:19.761723
# Unit test for method sex of class Person
def test_Person_sex():
    """Unit test for method sex of class Person."""
    # all variants
    assert len(Person.sex.__annotations__) == 2, \
        "Person.sex() can have only two arguments ('iso5218' and 'symbol')."
    assert 'iso5218' in Person.sex.__annotations__, \
        "Person.sex() must have argument 'iso5218'."
    assert 'symbol' in Person.sex.__annotations__, \
        "Person.sex() must have argument 'symbol'."
    assert isinstance(Person.sex.__annotations__['iso5218'], bool), \
        "Person.sex() argument 'iso5218' must be a bool."

# Generated at 2022-06-23 21:49:22.624530
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    p = Person()
    assert type(p.academic_degree()) is str


# Generated at 2022-06-23 21:49:26.155259
# Unit test for method email of class Person
def test_Person_email():
    from fake import fake
    from fake.generator import Generator
    from fake.options import DEFAULT_LOCALE
    for _ in range(100):
        gen = Generator(DEFAULT_LOCALE)
        fake.email(gen)

# Generated at 2022-06-23 21:49:28.267257
# Unit test for method identifier of class Person
def test_Person_identifier():
    result = Person().identifier(mask='##-##/##')
    assert len(result) == 9
    assert re.fullmatch(r'\d{2}-\d{2}/\d{2}', result)


# Generated at 2022-06-23 21:49:31.029912
# Unit test for method height of class Person
def test_Person_height():
    np = Person()
    height = np.height()
    assert isinstance(height, str)
    assert "0.2f" in height


# Generated at 2022-06-23 21:49:38.626005
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(100):
        worldview = Person().worldview()
        assert worldview in ['Pantheism', 'Secularism', 'Agnosticism', 'Religion', 'Religion of Russia', 'Buddhism', 'Religion of Russia', 'Islam', 'Judaism', 'Religion of Russia', 'Christianity', 'Atheism']
        assert isinstance(worldview, str)


# Generated at 2022-06-23 21:49:50.336709
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    actual = Person(seed=14).social_media_profile()
    expected = 'https://facebook.com/fefi'
    assert actual == expected, "'{}' is not equals to '{}'".format(actual, expected)

    actual = Person(seed=24).social_media_profile(site=SocialNetwork.Vkontakte)
    expected = 'https://vk.com/dede'
    assert actual == expected, "'{}' is not equals to '{}'".format(actual, expected)

    actual = Person(seed=123).social_media_profile(site=SocialNetwork.Facebook)
    expected = 'https://facebook.com/uto'
    assert actual == expected, "'{}' is not equals to '{}'".format(actual, expected)

    actual = Person(seed=66).social_media

# Generated at 2022-06-23 21:49:55.505298
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Object initialization
    person_generator = Person('ru')
    # Get a random value
    blood_type = person_generator.blood_type()
    # Assertion about the correctness of the value received
    assert type(blood_type) is str
    

# Generated at 2022-06-23 21:49:58.806195
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person(seed=12)
    # testing get_random_item function from faker.utils
    assert person.blood_type() == person.random.choice(BLOOD_GROUPS)


# Generated at 2022-06-23 21:50:00.942865
# Unit test for method username of class Person
def test_Person_username():
    provider = Person(locale='en')
    for i in range(75):
        assert provider.username() != provider.username()


# Generated at 2022-06-23 21:50:10.972889
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from datetime import datetime

    p = Person()

    # First work experience
    res = p.work_experience()
    assert isinstance(res[0], datetime)
    assert isinstance(res[1], datetime)
    assert isinstance(res[2], str)
    assert isinstance(res[3], str)
    assert isinstance(res[4], str)

    # Second work experience
    res = p.work_experience()
    assert isinstance(res[0], datetime)
    assert isinstance(res[1], datetime)
    assert isinstance(res[2], str)
    assert isinstance(res[3], str)
    assert isinstance(res[4], str)



# Generated at 2022-06-23 21:50:16.997699
# Unit test for method username of class Person
def test_Person_username():
    seed = 8
    provider = Person(seed=seed)
    tail = 7260
    template = 'U_d'
    size = len(template)

    expected = 'A' + ''.join([str(i) for i in range(tail, tail + size)])

    assert provider.username(template=template) == expected

# Generated at 2022-06-23 21:50:20.703482
# Unit test for method weight of class Person
def test_Person_weight():
    for _ in range(50):
        provider = PersonProvider()
        assert provider.weight() >= 38
        assert provider.weight() <= 90
test_Person_weight()

# Generated at 2022-06-23 21:50:23.502363
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    result = person.social_media_profile(site=SocialNetwork.INSTAGRAM)
    expected = 'https://instagram.com/default'
    assert result == expected

# Generated at 2022-06-23 21:50:26.762068
# Unit test for method full_name of class Person
def test_Person_full_name():
    for _ in range(1000):
        person = Person()
        fname = person.full_name()
        assert isinstance(fname, str)
        assert fname



# Generated at 2022-06-23 21:50:28.342675
# Unit test for method email of class Person
def test_Person_email():
    # Call the function under test.
    obj = Person()
    result = obj.email()

    # Check the result.
    assert result is not None
    assert result != ''

# Generated at 2022-06-23 21:50:31.950200
# Unit test for method sex of class Person
def test_Person_sex():
    for i in range(10, 20):
        p = Person.create(seed = i)
        assert p.sex() in ('M', 'F', '0', '1', '2', '9')

# Generated at 2022-06-23 21:50:35.228804
# Unit test for constructor of class Person
def test_Person():
    person1 = Person()
    person2 = Person(locale='en')
    assert isinstance(person1, Person)
    assert isinstance(person2, Person)

# Unit tests for method Person.name()

# Generated at 2022-06-23 21:50:37.474206
# Unit test for method name of class Person
def test_Person_name():
    p = Person()
    # %timeit p.name()
    assert (p.name() != "ab")
    

# Generated at 2022-06-23 21:50:44.317138
# Unit test for method surname of class Person
def test_Person_surname():
    """Test for method surname of class Person"""

    person = Person()
    person.random = Random()
    person.random.seed(0)
    test_surname = person.surname(Gender.FEMALE)

    assert test_surname == "Болотникова", "Expect surname of class Person: 'Болотникова', but got {}".format(test_surname)


# Generated at 2022-06-23 21:50:47.658653
# Unit test for method height of class Person
def test_Person_height():
    from fakedata import FAKE
    height = FAKE.height(minimum=1.5, maximum=2.0)
    assert type(height) is str
    assert len(height) >= 4 and len(height) <= 5


# Generated at 2022-06-23 21:50:49.494975
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    result = Person.academic_degree()
    expected = isinstance(result, str)
    assert expected

# Generated at 2022-06-23 21:50:51.184580
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person(None)
    assert p.telephone('', '') is not None
    assert p.telephone('', '') is not ''

# Generated at 2022-06-23 21:50:53.103577
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    assert isinstance(person.academic_degree(), str)
