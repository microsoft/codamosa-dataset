

# Generated at 2022-06-23 21:40:58.813473
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    result = p.height()
    assert isinstance(result, str)
    assert len(result) == 4
    
    

# Generated at 2022-06-23 21:41:02.645489
# Unit test for method university of class Person
def test_Person_university():
    deg_arr = []
    for i in range(100):
        deg_arr.append(Person().university())
    # Test for multiple occurance
    assert len(set(deg_arr)) == len(deg_arr)


# Generated at 2022-06-23 21:41:06.556214
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert Person().social_media_profile().startswith("https://")
    assert Person().social_media_profile("Facebook").startswith("https://facebook.com/")
test_Person_social_media_profile()


# Generated at 2022-06-23 21:41:17.828153
# Unit test for method name of class Person
def test_Person_name():
    gen = Generator()
    res_int = isinstance(gen.name(), str)
    assert res_int == True
    res_int = isinstance(gen.name(gender=Gender.MALE), str)
    assert res_int == True
    res_int = isinstance(gen.name(gender=Gender.FEMALE), str)
    assert res_int == True
    res_int = isinstance(gen.name(gender=Gender.UNKNOWN), str)
    assert res_int == True
    res = gen.name()
    print(res)
    res = gen.name(gender=Gender.MALE)
    print(res)
    res = gen.name(gender=Gender.FEMALE)
    print(res)
    res = gen.name(gender=Gender.UNKNOWN)
    print(res)
#

# Generated at 2022-06-23 21:41:21.457098
# Unit test for method password of class Person
def test_Person_password():
    for _ in range(100):
        p = Person(random=Random())
        assert len(p.password()) == 8

        password = p.password(length=30, hashed=True)
        assert len(password) == 32



# Generated at 2022-06-23 21:41:28.127066
# Unit test for method avatar of class Person
def test_Person_avatar():
    from random import seed
    from voodoo.dsl import Person

    seed(42)
    person = Person()
    assert person.avatar() == 'https://api.adorable.io/avatars/256/fc41430b838b3f58de141d0b232e6e5c.png'
    assert person.avatar(size=128) == 'https://api.adorable.io/avatars/128/fc41430b838b3f58de141d0b232e6e5c.png'

# Generated at 2022-06-23 21:41:36.474889
# Unit test for method identifier of class Person
def test_Person_identifier():

    provider = Person()
    result = provider.identifier(mask='##-##/##')
    assert re.fullmatch('[0-9-/]*', result)

    mask='##-##/##'
    value = provider.identifier(mask=mask)
    assert len(value) == len(mask)


    provider = Person(seed=821)
    result = provider.identifier(mask='##-##/##')
    assert re.fullmatch('[0-9-/]*', result)

    # assert len(provider.__repr__()) == len(provider.__str__())
    repr(provider)
    str(provider)
    print(provider)

test_Person_identifier()


# Generated at 2022-06-23 21:41:47.435096
# Unit test for method username of class Person
def test_Person_username():
    random = Random()

    assert isinstance(Person(random).username(), str)

    username = Person(random).username(template='default')
    assert re.fullmatch(r'[a-z]+\.[\d]{4}', username)

    username = Person(random).username(template='U')
    assert re.fullmatch(r'[A-Z][a-z]+', username)

    username = Person(random).username(template='Ud')
    assert re.fullmatch(r'[A-Z][a-z]+[\d]{4}', username)

    username = Person(random).username(template='U_d')
    assert re.fullmatch(r'[A-Z][a-z]+_[\d]{4}', username)


# Generated at 2022-06-23 21:41:49.823200
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    assert person.views_on() != person.views_on()
    assert person.views_on() in ['Negative', 'Positive', 'Neutral']

# Generated at 2022-06-23 21:41:52.549214
# Unit test for constructor of class Person
def test_Person():
    random = Random()
    profile = Person(random)
    assert isinstance(profile, Person)
    assert isinstance(profile.random, Random)
    assert profile.seed is None


# Generated at 2022-06-23 21:41:55.585454
# Unit test for method nationality of class Person
def test_Person_nationality():
    try:
        person = Person()
        person.nationality()
    except KeyError as error:
        assert False, error.__str__()
    except NonEnumerableError as error:
        assert False, error.__str__()
    else:
        assert True


# Generated at 2022-06-23 21:41:57.482296
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Create object of class Person
    p = Person()
    
    # Check the type of return value
    assert type(p.nationality()) == str
    
    
    

# Generated at 2022-06-23 21:42:00.798852
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    gender = p.gender()
    assert gender in ('Male', 'Female', 'Other')


# Generated at 2022-06-23 21:42:02.241617
# Unit test for method full_name of class Person
def test_Person_full_name():
    check_name(Person().full_name, None)

# Generated at 2022-06-23 21:42:04.198051
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    name = person.last_name()
    assert name in LAST_NAMES

# Generated at 2022-06-23 21:42:06.867884
# Unit test for constructor of class Person
def test_Person():
    seed(0)
    provider = Person()
    assert provider.name() == 'Amy'
    assert provider.full_name() == 'Amy Bosworth'


# Generated at 2022-06-23 21:42:16.718935
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person.work_experience('Python', '2019-09-11', '2019-09-24') == '0 года 0 месяца'
    assert Person.work_experience('Python', '2019-09-11', '2020-09-10') == '1 года 0 месяцев'
    assert Person.work_experience('Python', '2019-09-11', '2020-09-11') == '1 года 1 месяц'
    assert Person.work_experience('Python', '2019-09-11', '2021-09-11') == '2 года 1 месяц'

# Generated at 2022-06-23 21:42:18.921508
# Unit test for method weight of class Person
def test_Person_weight():
    for i in range(1000):
        print(Person().weight())


# Generated at 2022-06-23 21:42:24.221450
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person(seed=123123)
    assert p.gender(symbol=False) == 'female'
    assert p.gender() == Gender.FEMALE
    assert p.gender(symbol=True) == '♀'
    assert p.gender(iso5218=True) == 2
    assert p.gender(3) == '♀'


# Generated at 2022-06-23 21:42:26.508356
# Unit test for method political_views of class Person
def test_Person_political_views():
    obj = Person(random=Random())
    res = obj.political_views()
    assert(isinstance(res, str))


# Generated at 2022-06-23 21:42:34.126160
# Unit test for method gender of class Person
def test_Person_gender():
    from random import Random
    rnd = Random(1)
    x = Person(rnd)
    # Test for method gender of class Person
    for _ in range(100):
        assert x.gender(iso5218=False, symbol=False) in GENDER_WORDS
        assert x.gender(iso5218=True, symbol=False) in GENDER_NUMBERS
        assert x.gender(iso5218=False, symbol=True) in GENDER_SYMBOLS

 

# Generated at 2022-06-23 21:42:43.328254
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    vk = Person().social_media_profile(SocialNetwork.VK)
    ok = Person().social_media_profile(SocialNetwork.Ok)
    tw = Person().social_media_profile(SocialNetwork.Twitter)
    fb = Person().social_media_profile(SocialNetwork.Facebook)
    yt = Person().social_media_profile(SocialNetwork.Youtube)
    st = Person().social_media_profile(SocialNetwork.Steam)
    hu = Person().social_media_profile(SocialNetwork.Habrahabr)
    gh = Person().social_media_profile(SocialNetwork.Github)
    li = Person().social_media_profile(SocialNetwork.LinkedIn)
    ti = Person().social_media_profile(SocialNetwork.Telegram)
    di = Person().social_media_profile(SocialNetwork.Discord)


# Generated at 2022-06-23 21:42:46.837925
# Unit test for constructor of class Person
def test_Person():
    t = Person(seed=0)
    assert t._data == PERSON_DATA
    assert t.seed == 0



# Generated at 2022-06-23 21:42:48.763601
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person(random=Random())
    assert p.political_views() == "Libertarian"


# Generated at 2022-06-23 21:42:50.581300
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert isinstance(person, Person)


# Generated at 2022-06-23 21:42:51.802975
# Unit test for method university of class Person
def test_Person_university():
    p = Person()
    assert p.university()



# Generated at 2022-06-23 21:42:53.504269
# Unit test for method age of class Person
def test_Person_age():
    john = Person(age=35)
    # Assert age
    assert john.age() == 35


# Generated at 2022-06-23 21:42:58.094094
# Unit test for method weight of class Person
def test_Person_weight():
    print('::: TESTING "WEIGHT" METHOD :::')
    person = Person()
    assert person.weight(38, 90) >= 38 or person.weight(38, 90) <= 90
    print('--- method "weight" is OK! ---')


# Generated at 2022-06-23 21:43:00.209941
# Unit test for constructor of class Person
def test_Person():
    obj = Person()
    assert isinstance(obj, Person)


# Generated at 2022-06-23 21:43:02.971711
# Unit test for method username of class Person
def test_Person_username():
    expected_output = 'l_d'
    output = Person.username(None, 'l_d')
    assert output == expected_output, f"Expected {expected_output}, got {output}"


# Generated at 2022-06-23 21:43:08.836622
# Unit test for method avatar of class Person
def test_Person_avatar():
    for _ in range(100):
        size = 256
        p = Person()
        url = p.avatar(size)
        assert url.startswith('https://api.adorable.io/avatars/')
        assert url.endswith('{}.png'.format(size))


# Generated at 2022-06-23 21:43:19.117772
# Unit test for method first_name of class Person
def test_Person_first_name():
    from faker import Faker
    from faker.config import DEFAULT_LOCALE, AvailableLocales
    from faker.providers.person.en_US import Provider

    faker = Faker()
    person = faker.providers[AvailableLocales.EN_US].add_provider(Provider)
    
    all_names_are_string = True
    
    for gender in Gender:
        for _ in range(25):
            expected = person.get_name(gender)
            actual = person.first_name(gender)
            all_names_are_string = type(expected) is str and type(actual) is str and all_names_are_string

    
    all_names_are_string = all_names_are_string
    
    assert all_names_are_string is True

# Generated at 2022-06-23 21:43:21.892082
# Unit test for method occupation of class Person
def test_Person_occupation():
    #arrange
    person = Person(seed=12345)
    expected = 'Software Developer'
    #act
    actual = person.occupation()
    #assert
    assert actual == expected
    

# Generated at 2022-06-23 21:43:24.751948
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    try:
        assert(isinstance(Person().sexual_orientation(), str))
    except:
        assert(False)

# Generated at 2022-06-23 21:43:26.459639
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email(unique=True)
    print(email)



# Generated at 2022-06-23 21:43:30.656055
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Generate an object
    per = Person()
    
    # Generate some values
    years = per.birth_date().year
    exp = per.work_experience(year = years)
    
    # Check the values
    assert exp.year <= years, "Actual value: {}. Should be less than: {}".format(exp.year, years)

# Generated at 2022-06-23 21:43:32.874465
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES


# Generated at 2022-06-23 21:43:35.841136
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()
    result = provider.telephone(mask = '8(###)###-##-##')
    assert result


# Generated at 2022-06-23 21:43:37.536108
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert person.height()

# Generated at 2022-06-23 21:43:48.151777
# Unit test for method first_name of class Person
def test_Person_first_name():
    from datamaker.data_classes import Person
    from datamaker.enums import Gender
    from datamaker.utils import assert_raises
    from datamaker.utils import assert_equal
    from datamaker.utils import assert_in

    p = Person(seed=0)

    assert_equal(
        p.first_name(),
        'Adam',
        desc='default first_name()')

    assert_equal(
        p.first_name(Gender.MALE),
        'Adam',
        desc='gender == Gender.MALE')

    assert_equal(
        p.first_name(Gender.FEMALE),
        'Eva',
        desc='gender == Gender.FEMALE')


# Generated at 2022-06-23 21:43:51.183564
# Unit test for method email of class Person
def test_Person_email():
    pr = Person()

    assert pr.email()
    assert pr.email(unique=True)
    assert pr.email(domains=('examp.com',))


# Generated at 2022-06-23 21:43:53.988121
# Unit test for method height of class Person
def test_Person_height():
    random.seed()
    p = Person()
    height = p.height()
    assert height >= 1.5 and height <= 2.0



# Generated at 2022-06-23 21:43:58.960106
# Unit test for method language of class Person
def test_Person_language():
    from faker.providers import person
    from faker.utils import text
    from faker.utils.distribution import choices_distribution

    fake = Faker()
    fake.add_provider(person.Provider)

    for _ in range(100):
        assert isinstance(fake.language(), text.StringType)
    assert choices_distribution(fake, fake.language, PHRASES) == 1

# Generated at 2022-06-23 21:44:02.993300
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    expected = 'Bisexuality'
    actual = Person().sexual_orientation()

    if expected == actual:
        print('PASS')
    else:
        print('FAIL')
        print('expected:', expected)
        print('actual:', actual)

# Generated at 2022-06-23 21:44:04.404110
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person(seed=0).academic_degree() == 'Doctor'

# Generated at 2022-06-23 21:44:12.534969
# Unit test for method worldview of class Person
def test_Person_worldview():
    worldviews = ['Pantheism', 'Secularism', 'Holistic', 'Deism', 'Agnosticism',
                  'Transcendentalism', 'Panentheism', 'Anthropocentrism', 'Naturalism',
                  'Humanism', 'Mysticism', 'Epicureanism', 'Egoism', 'Syncretism',
                  'Animism', 'Monism', 'Nihilism', 'Theism', 'Polytheism', 'Positivism',
                  'Nechayevism', 'Atheism', 'Solipsism', 'Materialism', 'Dualism', 'Logicism',
                  'Mentalism', 'Atheistic humanism', 'Fideism', 'Agnostic theism',
                  'Philosophical skepticism', 'Pantheistic naturalism', 'Philosophical materialism']

# Generated at 2022-06-23 21:44:21.957101
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person(random.Random(42))
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"

    person = Person(random.Random(42))
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"
    assert person.worldview() == "Spiritualist"

    person = Person(random.Random(21936))
    assert person.worldview() == "Idealist"

# Generated at 2022-06-23 21:44:24.545598
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person()
    for _ in range(100):
        result = p.blood_type()
        assert result in BLOOD_GROUPS
    print("test_Person_blood_type() - passed")



# Generated at 2022-06-23 21:44:25.767410
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    item = Person().sexual_orientation()
    assert isinstance(item, str)


# Generated at 2022-06-23 21:44:31.745457
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert p.name() is not None
    assert p.last_name() is not None
    assert p.full_name() is not None
    assert p.username() is not None
    assert p.password() is not None
    assert p.email() is not None
    assert p.social_media_profile() is not None
    assert p.gender() is not None
    assert p.height() is not None
    assert p.weight() is not None
    assert p.blood_type() is not None
    assert p.sexual_orientation() is not None
    assert p.occupation() is not None
    assert p.political_views() is not None
    assert p.worldview() is not None
    assert p.views_on() is not None
    assert p.nationality() is not None
    assert p

# Generated at 2022-06-23 21:44:34.031912
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    assert person.occupation() in person._data["occupation"]


# Generated at 2022-06-23 21:44:39.140923
# Unit test for method weight of class Person
def test_Person_weight():
    #``test_Person_weight`` should return an int
    assert type(Person().weight(min=10, max=25)) == int
    
    #result of test_Person_weight should be between given min and max values
    assert Person().weight(min=10, max=25) >= 10
    assert Person().weight(min=10, max=25) <= 25


# Generated at 2022-06-23 21:44:47.296000
# Unit test for constructor of class Person
def test_Person():
    # test of constructor with predefined seed
    provider = Person(seed=1)
    assert provider.name(Gender.MALE) == 'Андрей'
    assert provider.name(Gender.FEMALE) == 'Анна'
    assert provider.height() == '1.93'
    assert provider.weight() == 67
    assert provider.blood_type() == '0+'
    assert provider.email() == 'tatiana.1972@inmail24.com'
    assert provider.telephone() == '+5-(521)-252-9866'
    assert provider.telephone(mask='+0-(000)-000-000') == '+6-(003)-829-6047'

    # test of constructor without predefined seed
    provider = Person()

# Generated at 2022-06-23 21:44:51.008712
# Unit test for method title of class Person
def test_Person_title():
    person = Person(locale = 'en')
    title = person.title(gender= Gender.MALE, title_type = TitleType.PREFIX)
    assert title in person._data['title'][0][0]
    
    

# Generated at 2022-06-23 21:44:55.115800
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    assert re.match(r'[a-zA-Z][a-zA-Z0-9]{2,20}',
                    person.username())



# Generated at 2022-06-23 21:44:58.443043
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    res = person.username(template='U_d')
    assert res.startswith('U')
    assert res.find('_') != -1
    assert res.find('d') != -1
    assert res.find('d') != -1
    # default template
    res = person.username()
    assert res.find('l') != -1
    assert res.find('d') != -1
    # invalid template
    with pytest.raises(ValueError):
        person.username(template='U..d')


# Generated at 2022-06-23 21:45:04.183609
# Unit test for method identifier of class Person
def test_Person_identifier():
    pr = Person()
    assert type(pr.identifier()) == str
    assert re.fullmatch(r'\d\d-\d\d/\d\d', pr.identifier()) is not None
    assert re.fullmatch(r'\d\d-\d\d/\d\d', pr.identifier(mask='##-##/##')) is not None
test_Person_identifier()


# Generated at 2022-06-23 21:45:08.172964
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(100):
        p = Person()
        surname = p.surname()
        assert surname in SURNAMES

        for gender in Gender:
            if gender == Gender.any:
                continue

            surname = p.surname(gender)
            assert surname in SURNAMES[gender]

# Generated at 2022-06-23 21:45:10.708518
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()
    assert worldview in worldview_data
    
test_Person_worldview()

# Generated at 2022-06-23 21:45:19.472988
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person(locale='ru')
    for _ in range(10):
        assert provider.surname(gender=Gender.FEMALE) in provider._data['surname']['FEMALE']
        assert provider.surname(gender=Gender.MALE) in provider._data['surname']['MALE']
        assert provider.surname(gender='MALE') in provider._data['surname']['MALE']
        assert provider.surname(gender='FEMALE') in provider._data['surname']['FEMALE']

# Generated at 2022-06-23 21:45:27.603508
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    sex = person.sex()
    assert sex in person._data['gender']
    sex_symbol = person.sex(symbol=True)
    assert sex_symbol in GENDER_SYMBOLS
    assert person.sex(iso5218=True) in (0, 1, 2, 9)
    assert person.sex(iso5218=True) != person.sex(iso5218=True)
    assert person.sex(symbol=True) != person.sex(symbol=True)
    assert person.sex() != person.sex()

# Generated at 2022-06-23 21:45:33.906245
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldviews = person.worldview()

# Generated at 2022-06-23 21:45:37.955291
# Unit test for method identifier of class Person
def test_Person_identifier():
    from tests.faker_of_faker import Faker
    _faker = Faker()
    result = _faker.person.identifier()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:45:46.224037
# Unit test for method email of class Person
def test_Person_email():
    rv = Person().email()
    assert isinstance(rv, str)

    rv = Person().email(domains=('@gmail.com', '@yandex.ru'))
    assert isinstance(rv, str)

    # Trying to use the «unique» parameter with a seeded provider
    provider = Person(seed='123')
    with pytest.raises(ValueError) as exc_info:
        provider.email(unique=True)

    exc = exc_info.value
    assert 'You cannot use «unique» parameter with a seeded provider' in str(exc)

# Generated at 2022-06-23 21:45:49.491995
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person(random.Random(0))
    assert provider.sexual_orientation()=='Homosexuality'

# Generated at 2022-06-23 21:45:53.026317
# Unit test for method gender of class Person
def test_Person_gender():
    names = [Person().gender() for _ in range(100)]
    assert len(names) == 100 and all(x in GENDER for x in names) is True
    

# Generated at 2022-06-23 21:46:01.946626
# Unit test for method telephone of class Person
def test_Person_telephone():
    print('Testing Person.telephone')

    # SEED = 2020
    # random.seed(SEED)

    p = Person()
    p.seed(2020)

    masks = ['+7-(###)-###-####', '+7-(###)-######']
    n = len(masks)
    for _ in range(n):
        print(p.telephone())

    def printer(mask):
        return p.telephone(mask=mask)

    for _ in range(n):
        print(printer('+7-(###)-###-####'))
        print(printer('+7-(###)-######'))

if __name__ == '__main__':

    # Unit test for method telephone of class Person.
    test_Person_telephone()

# Generated at 2022-06-23 21:46:04.550022
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    assert(person.weight(30, 90) >= 30 and person.weight(30, 90) <= 90)

# Generated at 2022-06-23 21:46:09.290051
# Unit test for method full_name of class Person
def test_Person_full_name():
    provider = Person()
    format_output(provider.full_name(), "Johann Wolfgang")
    format_output(provider.full_name(Gender.MALE), "Johann Wolfgang")
    format_output(provider.full_name(Gender.FEMALE), "Alice Aaliyah")
    format_output(provider.full_name(reverse=True), "Wolfgang Johann")


# Generated at 2022-06-23 21:46:11.455780
# Unit test for method blood_type of class Person
def test_Person_blood_type():

    # If the length of the list is the same
    assert len(Person.blood_type()) == len(BLOOD_GROUPS)


# Generated at 2022-06-23 21:46:17.133828
# Unit test for constructor of class Person
def test_Person():
    tz = Person(locale='ru_RU')

    assert(isinstance(tz, Person))
    assert(tz._data.get('gender') is not None)
    assert(tz._data.get('occupation') is not None)


# Unit tests for enumerable types

# Generated at 2022-06-23 21:46:27.334538
# Unit test for method full_name of class Person
def test_Person_full_name():
    """Test method full_name()."""
    from .enums import Gender

    def validate_full_name(full_name: str, gender: Gender):
        """Validate «full_name»."""
        from .enums import TitleType

        prefixes = provider.title(
            gender=gender,
            title_type=TitleType.PREFIX,
        )

        suffixes = provider.title(
            gender=gender,
            title_type=TitleType.SUFFIX,
        )

        assert full_name.startswith(prefixes)
        assert full_name.endswith(suffixes)

    provider = Person()

    full_name = provider.full_name()

    validate_full_name(full_name=full_name, gender=Gender.MALE)

    full_name = provider.full

# Generated at 2022-06-23 21:46:32.037294
# Unit test for method age of class Person
def test_Person_age():
    for _ in range(10):
        age = Person().age(minimum=3, maximum=10)
        assert 3 <= age <= 10

    for _ in range(10):
        age = Person(seed=None).age(minimum=3, maximum=10)
        assert 3 <= age <= 10

# Generated at 2022-06-23 21:46:32.595783
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname()


# Generated at 2022-06-23 21:46:38.914409
# Unit test for method worldview of class Person
def test_Person_worldview():
    import datetime

    # Initialize random number generator
    random = Random()

    # Seed the random number generator
    seed = random.seed(datetime.datetime.now())

    # Create person object from seed
    person = Person(seed=seed)

    # Invoke method worldview of class Person and store result
    result = person.worldview()

    # Check if result is an instance of str
    assert isinstance(result, str)

    # Check if result is in list worldview
    assert result in person._data['worldview']

test_Person_worldview()

# Generated at 2022-06-23 21:46:41.967607
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    p = Person(seed=14)
    p = Person(locale='ru')

# Unit tests for methods of class Person

# Generated at 2022-06-23 21:46:52.330601
# Unit test for method age of class Person
def test_Person_age():
    """
    Test for generation of random age.
    """
    rnd = Random()
    rnd.set_seed_from(848)
    person = Person(random=rnd)

    age = person.age()
    assert_equal(27, age)

    age = person.age(minimum=18, maximum=68)
    assert_equal(44, age)

    age = person.age(minimum=7, maximum=19)
    assert_equal(14, age)

    age = person.age(minimum=1, maximum=1)
    assert_equal(1, age)

    age = person.age(minimum=1, maximum=10)
    assert_equal(8, age)

    age = person.age(minimum=10, maximum=10)
    assert_equal(10, age)

    age = person

# Generated at 2022-06-23 21:47:00.082647
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person(seed=1)
    assert p.first_name(Gender.male)=='Johann'
    assert p.first_name(Gender.female)=='Olivia'
    assert p.first_name()=='Shawn'
    assert p.first_name(Gender.male)=='Johann'
    assert p.first_name(Gender.female)=='Olivia'
    assert p.first_name()=='Shawn'


# Generated at 2022-06-23 21:47:03.108116
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    with pytest.raises(AttributeError):
        p.views_on = '1'
    assert p.views_on() in ('-', '0', '1', '2')

# Generated at 2022-06-23 21:47:04.496323
# Unit test for method language of class Person
def test_Person_language():
    person = faker.factory.create('en_US')
    assert isinstance(person.language(), str)


# Generated at 2022-06-23 21:47:06.268524
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    result = person.occupation()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:47:14.978881
# Unit test for method username of class Person
def test_Person_username():
    from faker import Faker
    p = Person(Faker())

    assert p.username('U_d') is not None
    assert p.username('U.d') is not None
    assert p.username('U-d') is not None
    assert p.username('UU-d') is not None
    assert p.username('UU.d') is not None
    assert p.username('UU_d') is not None
    assert p.username('ld') is not None
    assert p.username('l-d') is not None
    assert p.username('Ud') is not None
    assert p.username('l.d') is not None
    assert p.username('l_d') is not None

    assert p.username(template='U_d') is not None
    assert p.username(template='U.d') is not None

# Generated at 2022-06-23 21:47:19.995189
# Unit test for method gender of class Person
def test_Person_gender():
    import random
    from pydantic import ValidationError

    person = Person

    gender = person.gender()
    assert gender in person._data['gender']

    gender = person.sex()
    assert gender in person._data['gender']

    gender = person.gender(iso5218=True)
    assert gender in [0, 1, 2, 9]

    with pytest.raises(ValidationError):
        gender = person.gender(iso5218=1)

    gender = person.gender(symbol=True)
    assert gender in person._data['gender_symbols']

    with pytest.raises(ValidationError):
        gender = person.gender(symbol=1)

    rnd = random.Random(x=1)
    person.random = rnd
    gender = person.gender()

# Generated at 2022-06-23 21:47:29.154724
# Unit test for method full_name of class Person
def test_Person_full_name():

    # Create an instance of class Person
    person = gen.Person()

    # Generate full name for man and woman
    assert person.full_name(Gender.MAN) in person._data['name']['man']
    assert person.full_name(Gender.WOMAN) in person._data['name']['woman']

    # Generate full name without gender
    genders = (Gender.MAN, Gender.WOMAN)
    assert person.full_name() in genders

    # Generate reversed full name
    assert person.full_name(reverse=True) == ' '.join(reversed(
        person.full_name().split()))


# Generated at 2022-06-23 21:47:37.233579
# Unit test for method occupation of class Person
def test_Person_occupation():
    '''
    Unit test for method occupation of class Person
    '''
    person = Person()

# Generated at 2022-06-23 21:47:40.608967
# Unit test for method sex of class Person
def test_Person_sex():
    # Test with not arguments
    assert isinstance(Person().sex(), str) == True, 'Should be string, got {}'.format(type(Person().sex()))

    # Test with iso5218 argument
    assert isinstance(Person().sex(iso5218=True), int) == True, 'Should be int, got {}'.format(type(Person().sex(iso5218=True)))

    # Test with symbol argument
    assert isinstance(Person().sex(symbol=True), str) == True, 'Should be string, got {}'.format(type(Person().sex(symbol=True)))


# Generated at 2022-06-23 21:47:46.823274
# Unit test for method last_name of class Person
def test_Person_last_name():
    # Объект класса Person
    p = Person(seed = 1)
    # Генерируем последнее имя в виде строки
    last_name = p.last_name()
    # Тест с помощью утверждения
    assert last_name == "Королёв", "Ошибка: метод last_name должен " \
                                   "возвращать значение типа " \
                

# Generated at 2022-06-23 21:47:49.357604
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    worldviews = p._data['worldview']
    assert p.worldview() in worldviews

# Generated at 2022-06-23 21:48:00.911226
# Unit test for method identifier of class Person
def test_Person_identifier():
    """
    Test method identifier using the following cases:
    1.  If mask is empty string or if it is None, identifier method
        should return an empty string.
    2.  If mask is a set of '#' characters that are greater than 1,
        identifier method should return a random identifier.
    3.  If mask is a set of '#' characters that are less than 1,
        identifier method should raise ValueError exception.
    """
    # Case 1
    identifier = Person().identifier('')
    assert identifier == ''

    identifier = Person().identifier(None)
    assert identifier == ''

    # Case 2
    identifier = Person().identifier('###')
    assert re.match(r'[0-9]{3}', identifier) is not None

    identifier = Person().identifier('##--##-##')

# Generated at 2022-06-23 21:48:03.631481
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person()
    assert p.blood_type() in BLOOD_GROUPS
    assert p.blood_type() != p.blood_type()


# Generated at 2022-06-23 21:48:07.857356
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    print('Test Person.blood_type()')
    p = Person()
    blood_type = set([p.blood_type() for i in range(1000)])

    assert len(blood_type) >= 6
    assert 'AB+' in blood_type
    assert '0+' in blood_type
    assert 'B-' in blood_type


# Generated at 2022-06-23 21:48:10.959012
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    result = p.identifier()
    fmt = p.random.custom_code(mask='##-##/##')
    assert result == fmt


# Generated at 2022-06-23 21:48:14.321852
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person(seed=42)
    assert person.avatar() == "https://api.adorable.io/avatars/256/1f8a809036a7243f84e2ef858f7a2ab0.png"

# Generated at 2022-06-23 21:48:17.778191
# Unit test for method worldview of class Person
def test_Person_worldview():
    r = random.RandomState(seed=234)
    p = Person(random=r)
    for _ in range(100):
        assert p.worldview() == 'Secularism'
    assert p.worldview() == 'Secularism'


# Generated at 2022-06-23 21:48:24.379852
# Unit test for method gender of class Person

# Generated at 2022-06-23 21:48:26.491767
# Unit test for method full_name of class Person
def test_Person_full_name():
    place = Person(seed=65)
    assert place.full_name() == 'Phillip K.'


# Generated at 2022-06-23 21:48:27.977580
# Unit test for method full_name of class Person
def test_Person_full_name():
    gender = Gender.male
    person = Person()
    full_name = person.full_name(gender)
    assert full_name is not None

# Generated at 2022-06-23 21:48:34.024364
# Unit test for method views_on of class Person
def test_Person_views_on():
    from datagenerator import Person
    from sys import version

    if version[0] == '2':
        from test_py2 import get_random_item, build_enums_dict

    else:
        from test_py3 import get_random_item, build_enums_dict

    provider = Person()
    views = provider.views_on()

    assert views in provider._data['views_on']



# Generated at 2022-06-23 21:48:36.792406
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    academic_degree = person.academic_degree()
    assert academic_degree in DEGREES


# Generated at 2022-06-23 21:48:39.594130
# Unit test for method last_name of class Person
def test_Person_last_name():
    person_generator = Person(seed=10)
    assert person_generator.last_name() == 'Холт'



# Generated at 2022-06-23 21:48:47.160746
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    # Test gender
    data = person.gender()
    assert data in GENDER_EN

    # Test gender (iso5218)
    for _ in range(100):
        data = person.gender(iso5218=True)
        num = int(data)
        assert num in [0, 1, 2, 9]

    # Test gender (symbol)
    for _ in range(100):
        data = person.gender(symbol=True)
        assert data in GENDER_SYMBOLS

# Generated at 2022-06-23 21:48:52.535415
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    # Test method gender by default arguments
    assert person.gender() in list(Gender)
    # Test method gender by argument ``iso5218``
    assert person.gender(iso5218=True) in [0, 1, 2, 9]
    symbol = person.gender(symbol=True)
    assert symbol in GENDER_SYMBOLS
    assert isinstance(symbol, str)

# Generated at 2022-06-23 21:48:59.525269
# Unit test for method telephone of class Person
def test_Person_telephone():
    for x in range(1000):
        telephone = Person().telephone(mask='(###) ###-##-##')
        assert re.match(r'\([0-9]{3}\) [0-9]{3}-[0-9]{2}-[0-9]{2}', telephone)
    print("Test \'telephone\' - OK")

if __name__ == '__main__':
    test_Person_telephone()

# Generated at 2022-06-23 21:49:01.909036
# Unit test for method gender of class Person
def test_Person_gender():
    a = Person().gender()
    assert a in ['male', 'female']


# Generated at 2022-06-23 21:49:03.864389
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    rv = Person.blood_type()
    assert rv in BLOOD_GROUPS


# Generated at 2022-06-23 21:49:06.510198
# Unit test for method work_experience of class Person
def test_Person_work_experience():
	person = Person()
	assert person.work_experience() == {'job': '', 'company': '', 'location': '', 'start_date': '', 'end_date': ''}

# Generated at 2022-06-23 21:49:08.748212
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = g.Person()

    assert issubclass(person.nationality, str)
    assert person.nationality in Nation.all()

    del g.Person

# Generated at 2022-06-23 21:49:13.253567
# Unit test for method gender of class Person
def test_Person_gender():
    """Test for method gender of class Person."""
    person = Person()

    assert person.gender() in GENDER_WORDS
    assert person.gender(iso5218=True) in [0, 1, 2]
    assert person.gender(symbol=True) in GENDER_SYMBOLS

# Generated at 2022-06-23 21:49:17.171142
# Unit test for method password of class Person
def test_Person_password():
    # Arrange
    seed = b'efb373f36d6c31f7'
    password_length = 8
    p = Person(seed=seed)

    # Act
    password = p.password(length=password_length)

    # Assert
    assert password == 'C7Xz8Q1u'

# Generated at 2022-06-23 21:49:23.546569
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Default
    p = Person(random.Random())
    result = p.telephone()
    assert (result)

    # With param
    p = Person(random.Random())
    result = p.telephone(mask='+7 (###) ###-##-##')
    assert (result)
test_Person_telephone()

# Generated at 2022-06-23 21:49:25.526689
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    occupation = person.occupation()
    assert occupation in OCCUPATIONS


# Generated at 2022-06-23 21:49:27.413097
# Unit test for method surname of class Person
def test_Person_surname():
    from datamock.datamock import Person
    person = Person()
    surname = person.surname()
    assert surname is not None

# Generated at 2022-06-23 21:49:29.560898
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Testing method views_on of class Person
    # with Person's object.
    string = "views_on"
    tester = Person()
    data = getattr(tester, string)()
    assert isinstance(data, str)


# Generated at 2022-06-23 21:49:36.380799
# Unit test for method title of class Person
def test_Person_title():
    """Test for method title of class Person"""
    p = Person(seed=0)

    expected = 'Mr.'
    actual = p.title(gender=Gender.male, title_type=TitleType.prefix)
    assert expected == actual

    expected = 'Ms.'
    actual = p.title(gender=Gender.female, title_type=TitleType.prefix)
    assert expected == actual

    expected = 'Dr.'
    actual = p.title(gender=Gender.other, title_type=TitleType.prefix)
    assert expected == actual

    expected = 'Mr. Phd.'
    actual = p.title(gender=Gender.male, title_type=TitleType.suffix)
    assert expected == actual

    expected = 'Ms. Phd.'

# Generated at 2022-06-23 21:49:38.791996
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person(seed=0)
    assert p.telephone() == '+7-(495)-414-00-00'



# Generated at 2022-06-23 21:49:41.021301
# Unit test for method gender of class Person
def test_Person_gender():
    # method gender of class Person
    assert Person.gender(Person) in ['F', 'M', 'NotSpecified']

# Generated at 2022-06-23 21:49:43.540418
# Unit test for method university of class Person
def test_Person_university():
    provider = Person()
    result = provider.university()
    assert result in UNIVERSITIES


# Generated at 2022-06-23 21:49:53.655782
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person()
    res = p.political_views()
    assert isinstance(res, str)

test_Person_political_views()
print(f'Каждый раз получаем другую строку: ', Person().political_views())

from pprint import pprint as pp

pp(Person().political_views())

pp(Person().political_views())

pp(Person().political_views())

from IPython.display import Image

Image('https://sun9-28.userapi.com/c857424/v857424926/1b8c85/QJg5x5Uh5Hg.jpg')


# Generated at 2022-06-23 21:49:55.991932
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    item = Person.blood_type()
    assert item in BLOOD_GROUPS, 'Item not in expected list'

# Generated at 2022-06-23 21:49:58.528918
# Unit test for method worldview of class Person
def test_Person_worldview():
    """Testing worldview of class Person."""
    worldview = Person.worldview(Person())
    assert isinstance(worldview, str)



# Generated at 2022-06-23 21:50:00.668842
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in open(Path('data', 'nationality.txt')).read().split('\n')

# Generated at 2022-06-23 21:50:07.163210
# Unit test for method telephone of class Person
def test_Person_telephone():
    # GIVEN
    person = Person()
    # WHEN
    result_first = person.telephone()
    result_second = person.telephone()
    # THEN
    assert len(result_first)>0
    assert len(result_second)>0
    assert result_first !=result_second
test_Person_telephone()

# Generated at 2022-06-23 21:50:10.389372
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person(seed=123456789)
    blood_group = person.blood_type()
    assert isinstance(blood_group, str)
    assert blood_group in BLOOD_GROUPS
    assert blood_group == 'AB+'


# Generated at 2022-06-23 21:50:13.168343
# Unit test for method university of class Person
def test_Person_university():    
    p = Person(None)
    generated_data = p.university()
    assert generated_data in p._data['university']


# Generated at 2022-06-23 21:50:24.654110
# Unit test for method title of class Person
def test_Person_title():
    for _ in range(100):
        assert Person().title(title_type=TitleType.PREFIX, gender=Gender.MALE) in (
            'Mr',
            'Prof',
            'Dr'
        )
        assert Person().title(title_type=TitleType.PREFIX, gender=Gender.FEMALE) in (
            'Mrs',
            'Ms',
            'Miss'
        )
        assert Person().title(title_type=TitleType.SUFFIX, gender=Gender.MALE) in (
            'Jr',
            'Sr',
            'I'
        )
        assert Person().title(title_type=TitleType.SUFFIX, gender=Gender.FEMALE) in (
            'Jr',
            'Sr',
            'I'
        )

# Generated at 2022-06-23 21:50:26.712752
# Unit test for method university of class Person
def test_Person_university():
    p = Person()
    assert p.university()

# Generated at 2022-06-23 21:50:27.894343
# Unit test for method name of class Person
def test_Person_name():
    name = Person().name()
    assert isinstance(name,str)
    assert len(name) >= 5

# Generated at 2022-06-23 21:50:38.781203
# Unit test for method nationality of class Person

# Generated at 2022-06-23 21:50:41.295014
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person(random=Random())
    assert isinstance(person.work_experience(), str)


# Generated at 2022-06-23 21:50:43.453898
# Unit test for method height of class Person
def test_Person_height():
    h = Person().height(1.5, 1.9)

    assert isinstance(h, str)
    assert float(h) >= 1.5 and float(h) <= 1.9

# Generated at 2022-06-23 21:50:46.589934
# Unit test for method last_name of class Person
def test_Person_last_name():
    rnd = Factory.create()
    P = Person(random=rnd)
    assert P.last_name() in P._data['surname']['both'], "last name failed"

# Generated at 2022-06-23 21:50:49.132452
# Unit test for method gender of class Person
def test_Person_gender():
    from random import Random
    from names import Gender

    rnd = Random(42)
    p = Person(random=rnd)
    assert p.gender(symbol=True) in Gender.symbols()
    assert p.gender(symbol=False) in Gender.titles()



# Generated at 2022-06-23 21:50:59.246853
# Unit test for method views_on of class Person
def test_Person_views_on():
    person_1 = Person()
    views_on_1 = person_1.views_on()
    assert isinstance(views_on_1, str)

    person_2 = Person(seed=1)
    views_on_2 = person_2.views_on()
    assert views_on_2 == "Positive"

    person_3 = Person(seed=2)
    views_on_3 = person_3.views_on()
    assert views_on_3 == "Skeptical"

    person_4 = Person(seed=4)
    views_on_4 = person_4.views_on()
    assert views_on_4 == "Negative"

    person_5 = Person(seed=5)
    views_on_5 = person_5.views_on()