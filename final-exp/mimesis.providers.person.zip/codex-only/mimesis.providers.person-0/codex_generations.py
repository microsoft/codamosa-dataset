

# Generated at 2022-06-23 21:40:58.266286
# Unit test for method password of class Person
def test_Person_password():
    p = Person(1)
    assert len(p.password()) == 8

if __name__ == '__main__':
    test_Person_password()
    p = Person(rnd=0)
    print(p.password(length=20))

# Generated at 2022-06-23 21:40:59.759856
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    val = p.title()
    assert(isinstance(val, str))


# Generated at 2022-06-23 21:41:04.536047
# Unit test for method age of class Person
def test_Person_age():
    """Unit test for method age of class Person."""
    instance = Person()

    for _ in range(100):
        age = instance.age()
        assert isinstance(age, int), (
            'Attribute age must be int. '
            'Found {!r}'.format(type(age)))

        assert (age < 130 and age >= 0), (
            'Attribute age must be in range 0-130. '
            'Found {!r}'.format(age))



# Generated at 2022-06-23 21:41:08.302951
# Unit test for method avatar of class Person
def test_Person_avatar():
    assert Person().avatar().startswith('https://api.adorable.io/avatars/')
    assert Person().avatar(0).startswith('https://api.adorable.io/avatars/0/')



# Generated at 2022-06-23 21:41:13.951845
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()

    assert p.sexual_orientation()
    assert p.sexual_orientation(symbol=True)
    assert p.sexual_orientation() in SEXUALITY_DEFINITIONS
    assert p.sexual_orientation(symbol=True) in SEXUALITY_SYMBOLS

# Generated at 2022-06-23 21:41:16.029151
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()

    assert isinstance(person.first_name(), str)


# Generated at 2022-06-23 21:41:27.185943
# Unit test for method telephone of class Person

# Generated at 2022-06-23 21:41:31.765141
# Unit test for method age of class Person
def test_Person_age():
    generator = Generator()

    for _ in range(100):
        age_1 = generator.person.age(minimum=18, maximum=30)
        assert 18 <= age_1 <= 30
        age_2 = generator.person.age(minimum=70, maximum=80)
        assert 70 <= age_2 <= 80



# Generated at 2022-06-23 21:41:37.589113
# Unit test for method identifier of class Person
def test_Person_identifier():
    mask_1 = '@@-@@/##'
    mask_2 = '##-##/##'
    mask_3 = 'ŁŁ-ŁŁ/##'

    str_1 = Person.identifier()

    str_2 = Person.identifier(mask=mask_1)
    assert all([c in ascii_letters for c in str_2.replace('-', '')])
    assert not re.search(r'[a-zA-Z]\d', str_2)
    assert all([c in digits for c in str_2.replace('/', '').replace('-', '')])

    str_3 = Person.identifier(mask=mask_2)
    assert all([c in digits for c in str_2.replace('/', '').replace('-', '')])

    str

# Generated at 2022-06-23 21:41:43.273174
# Unit test for method title of class Person
def test_Person_title():
    assert Person.title('gender') == 'gender'
    assert Person.title(title_type = 'title_type') == 'title_type'
    assert Person.title('gender', 'title_type') == 'title_type'
    assert Person.title(title_type = 'title_type', gender = 'gender') == 'title_type'
test_Person_title()

# Generated at 2022-06-23 21:41:45.717196
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person()
    name = p.first_name()
    assert isinstance(name, str)
    assert len(name) > 0

# Generated at 2022-06-23 21:41:47.880781
# Unit test for method full_name of class Person
def test_Person_full_name():
    for i in range(50):
        name = fake.full_name(reverse=True)
        assert isinstance(name, str)


# Generated at 2022-06-23 21:41:51.075739
# Unit test for method avatar of class Person
def test_Person_avatar():
    provider = Person()
    avatar = provider.avatar()
    assert avatar == 'https://api.adorable.io/avatars/256/{}.png'.format(
        provider.password(hashed=True))


# Generated at 2022-06-23 21:41:54.303633
# Unit test for method first_name of class Person
def test_Person_first_name():
    # Creating an object
    fake = Faker(locale='en')

    for i in range (1000):

        # Calling method
        result = fake.first_name()

        # Verifying that result is not empty
        assert len(result) != 0


# Generated at 2022-06-23 21:41:56.620882
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person()
    result = p.full_name()
    assert result is not None
    assert type(result) is str
    assert len(result) > 0
test_Person_full_name()


# Generated at 2022-06-23 21:41:59.118044
# Unit test for method last_name of class Person
def test_Person_last_name():
    with pytest.raises(NonEnumerableError):
        Person(seed=1).last_name(gender=2)
    assert Person(seed=1).last_name(gender=Gender.MALE) == "Krause"
    
    

# Generated at 2022-06-23 21:42:05.364032
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    num = p.telephone()
    num = p.telephone(mask='+999 (99) (9)9999 9999')
    assert re.fullmatch('\+[0-9]{1,4}[ -]\([0-9]{2}\)\([0-9]{1}\)[0-9]{4}[0-9]{4}', num)

    num = p.telephone(mask='999 (99) (9)9999 9999')
    assert re.fullmatch('[0-9]{3}[ -]\([0-9]{2}\)\([0-9]{1}\)[0-9]{4}[0-9]{4}', num)


# Generated at 2022-06-23 21:42:13.035530
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert Person().first_name() in NAMES
    assert Person().first_name(gender=Gender.female) in NAMES_FEMALE
    assert Person().first_name(gender=Gender.male) in NAMES_MALE

if __name__ == '__main__':
    def test_Person_first_name():
        assert Person().first_name() in NAMES
        assert Person().first_name(gender=Gender.female) in NAMES_FEMALE
        assert Person().first_name(gender=Gender.male) in NAMES_MALE

# Generated at 2022-06-23 21:42:19.426650
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Testing method telephone"""
    provider = Person()
    assert provider.seed == 42
    assert provider.telephone(mask='+7 (###) ###-##-##') == '+7 (533) 107-34-39'
    assert provider.telephone(mask='+7 (###) ###-##-##') == '+7 (808) 659-35-13'
    assert provider.telephone(mask='+7 (###) ###-##-##') == '+7 (553) 246-41-11'
    assert provider.telephone(mask='+7 (###) ###-##-##') == '+7 (858) 771-95-85'
    assert provider.telephone(mask='+7 (###) ###-##-##') == '+7 (639) 341-03-57'

# Generated at 2022-06-23 21:42:30.016501
# Unit test for method password of class Person
def test_Person_password():
    for seed in range(5):
        password_4 = Person(seed=seed).password(length=4, hashed=False)
        password_6 = Person(seed=seed).password(length=6, hashed=False)
        password_8 = Person(seed=seed).password(length=8, hashed=False)
        password_4_hashed = Person(seed=seed).password(length=4, hashed=True)
        password_6_hashed = Person(seed=seed).password(length=6, hashed=True)
        password_8_hashed = Person(seed=seed).password(length=8, hashed=True)

        assert password_4 == 'P%oY'
        assert password_6 == 'yL=7V^'
        assert password_8 == 'N^&04}7+'

# Generated at 2022-06-23 21:42:32.084777
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name() in LAST_NAMES


# Generated at 2022-06-23 21:42:34.233633
# Unit test for method language of class Person
def test_Person_language():
    person = Person(random.Random())
    assert isinstance(person.language(), str)


# Generated at 2022-06-23 21:42:42.549494
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    phone = person.telephone(mask='+7 ## ### ## ##')
    assert len(phone) == 13

if __name__ == '__main__':
    with Person() as p:
        print(p.full_name(gender=Gender.MALE))
        print(p.telephone())
        print(p.email())
        print(p.social_media_profile(site=SocialNetwork.FACEBOOK))
        print(p.social_media_profile(site=SocialNetwork.INSTAGRAM))
        print(p.social_media_profile(site=SocialNetwork.TWITTER))
        print(p.social_media_profile(site=SocialNetwork.VKONTAKTE))
        print(p.social_media_profile(site=SocialNetwork.OKRU))

# Generated at 2022-06-23 21:42:45.509618
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for _ in range(5):
        assert len(Person().blood_type()) == 3


# Generated at 2022-06-23 21:42:54.540495
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person(seed=1)
    assert p.first_name() == 'Curtis'
    assert p.first_name(Gender.MALE) == 'John'
    assert p.first_name(Gender.MALE) == 'David'
    assert p.first_name(Gender.MALE) == 'David'
    assert p.first_name(Gender.MALE) == 'James'
    assert p.first_name(Gender.FEMALE) == 'Laura'
    assert p.first_name(Gender.FEMALE) == 'Heather'
    assert p.first_name(Gender.FEMALE) == 'Elizabeth'
    assert p.first_name(Gender.FEMALE) == 'Elizabeth'
    assert p.first_name(Gender.FEMALE) == 'Elizabeth'
    assert p.first_

# Generated at 2022-06-23 21:43:00.458994
# Unit test for method first_name of class Person
def test_Person_first_name():
    from Hypothesis.tests.test_random import get_random_value
    from Hypothesis.enums import Gender
    random = get_random_value()
    person = Person(random)
    assert isinstance(person.first_name(Gender.FEMALE), str)
    assert isinstance(person.first_name(Gender.MALE), str)

# Generated at 2022-06-23 21:43:01.856169
# Unit test for method worldview of class Person
def test_Person_worldview():
    assert Person.worldview() != Person.worldview()

# Generated at 2022-06-23 21:43:03.489507
# Unit test for method sex of class Person
def test_Person_sex():
    provider = Person()
    sex = provider.sex()
    assert sex in GENDERS


# Generated at 2022-06-23 21:43:08.564645
# Unit test for method avatar of class Person
def test_Person_avatar():
    provider = Person(seed=1234)
    for _ in range(100):
        avatar = provider.avatar()
        assert avatar == 'https://api.adorable.io/avatars/256/7e86f958f1b8.png'

# Generated at 2022-06-23 21:43:10.906566
# Unit test for method language of class Person
def test_Person_language():
    pr = Person()
    assert pr.language() != None
    assert pr.random != None
    assert pr.seed != None


# Generated at 2022-06-23 21:43:11.969985
# Unit test for method political_views of class Person
def test_Person_political_views():
    print()


# Generated at 2022-06-23 21:43:15.012136
# Unit test for method sex of class Person
def test_Person_sex():
    import json
    with open('dictionary.json','r') as f:
        data = json.load(f)
    p = Person(data)
    assert p.sex() in data['gender']

# Generated at 2022-06-23 21:43:23.174415
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person.gender() in {
        'Male',
        'Female',
        'Other',
    }
    assert person.sex() in {
        'Male',
        'Female',
        'Other',
    }
    assert person.name(gender=Gender.male) in {
        'Alexander',
        'Andrey',
        'Dmitry',
    }
    assert person.name(gender=Gender.female) in {
        'Anna',
        'Olga',
        'Anastasia',
    }
    assert person.name(gender=Gender.other) in {
        'Emma',
        'Ella',
        'Sophia',
    }
    assert person.nationality() in {
        'Russian',
        'British',
        'German',
    }

# Generated at 2022-06-23 21:43:27.915525
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert type(Person.work_experience()) == int
    assert Person.work_experience(minimum=0, maximum=40) <= 40
    assert Person.work_experience(minimum=0, maximum=40) >= 0
    assert Person.work_experience(minimum=12, maximum=40) <= 40
    assert Person.work_experience(minimum=12, maximum=40) >= 12

# Generated at 2022-06-23 21:43:30.113421
# Unit test for method weight of class Person
def test_Person_weight():
    for _ in range(100):
        assert(0, Person.weight() <= 90)
        assert (1, Person.weight()) >= 38
    return 'Passed'


# Generated at 2022-06-23 21:43:36.286961
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit test for method nationality of class Person"""
    person = Person()
    
    assert isinstance(person.nationality(), str)
    
    # Test for default nationality (Russian)
    assert person.nationality() == "Russian"
    
    # Test that all nationalities are unique
    def test_all_nationalities_are_unique():
        nationalities = [person.nationality() for i in range(500)]
        return len(set(nationalities)) == len(nationalities)
    
    assert test_all_nationalities_are_unique() == True, \
    "All nationalities should be unique"
if __name__ == '__main__':
    test_Person_nationality()
 

# Generated at 2022-06-23 21:43:39.505017
# Unit test for method name of class Person
def test_Person_name():
    # (self)
    # Get a random name.

    # Example:
    person = Person()
    name = person.name()
    assert name in NAMES



# Generated at 2022-06-23 21:43:46.614042
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    from pydantic import ValidationError
    from faker import Faker

    faker = Faker(['en_US'])
    faker.add_provider(Person(locale='en_US'))

    AcademicDegree = faker.academic_degree()

    assert AcademicDegree in AcDegree

    with pytest.raises(ValidationError):
        AcademicDegree = faker.academic_degree('Pokachalka')

# Generated at 2022-06-23 21:43:54.293511
# Unit test for method password of class Person
def test_Person_password():
    random = Random()
    random.seed(None)

    provider = Person(rnd=random)

    password = provider.password()

    assert 8 == len(password)
    assert not re.fullmatch('^[A-Za-z0-9]*$', password)

    password = provider.password(length=12, hashed=True)
    assert 32 == len(password)

    if 'random' not in globals():
        del provider
        del random


# Generated at 2022-06-23 21:43:56.394875
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person('de_DE', None)
    res = p.occupation()
    assert res in p._data['occupation']

# Generated at 2022-06-23 21:44:00.016674
# Unit test for method height of class Person
def test_Person_height():
    """
    Test that the method height of class Person returns the proper output
    """
    person = Person()
    assert isinstance(person.height(), str)

# Generated at 2022-06-23 21:44:02.317572
# Unit test for method university of class Person
def test_Person_university():
    for _ in range(100):
        university = Person().university()
        assert university in data['university']

# Generated at 2022-06-23 21:44:06.405322
# Unit test for method email of class Person
def test_Person_email():
    _Person = PersonFactory()
    email_ = _Person.email()
    assert isinstance(email_, str)
    assert '@' in email_


# Generated at 2022-06-23 21:44:08.451366
# Unit test for method weight of class Person
def test_Person_weight():
    from faker import Faker
    obj = Faker()
    assert obj.weight()

# Generated at 2022-06-23 21:44:11.454154
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    for _ in range(1000):
        email = person.email()
        assert '@' in email
        assert email.split('@')[1] in EMAIL_DOMAINS

# Generated at 2022-06-23 21:44:13.293886
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    result = Person().academic_degree()
    assert result in ACADEMIC_DEGREES

# Generated at 2022-06-23 21:44:14.938541
# Unit test for method name of class Person
def test_Person_name():
    p = Person()
    assert type(p.name()) is str
    assert p.name() in p._data['name']

# Generated at 2022-06-23 21:44:19.718810
# Unit test for method political_views of class Person
def test_Person_political_views():
    from faker.generator import Generator
    from faker.factory import Factory
    from faker.providers.person.vi_VN import Provider as PersonProvider
    from faker.utils.loading import find_available_locales

    for locale in find_available_locales():
        f = Factory.create(locale)
        if isinstance(f.political_views(), str):
            pass
        else:
            print(locale)
test_Person_political_views()


# Generated at 2022-06-23 21:44:24.383241
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    as_dict = person.work_experience(as_dict=True)
    assert as_dict['company'] in COMPANIES

    as_tuple = person.work_experience()
    assert as_tuple[0] in COMPANIES

    as_tuple = person.work_experience(as_tuple=False)
    assert_deepequal(as_tuple, as_dict)

    person = Person(random=Random(seed=314))
    assert person.work_experience() == ('TriNom', 'Computer Network Architect')



# Generated at 2022-06-23 21:44:29.479799
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert is_all_equal(
        FakePerson().nationality(gender=Gender.MALE),
        FakePerson().nationality(gender=Gender.MALE),
        FakePerson().nationality(gender=Gender.MALE),
        FakePerson().nationality(gender=Gender.MALE),
    )
    assert is_all_equal(
        FakePerson().nationality(gender=Gender.FEMALE),
        FakePerson().nationality(gender=Gender.FEMALE),
        FakePerson().nationality(gender=Gender.FEMALE),
        FakePerson().nationality(gender=Gender.FEMALE),
    )

# Generated at 2022-06-23 21:44:30.620794
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    for _ in range(100):
        res = Person().academic_degree()
        assert res


# Generated at 2022-06-23 21:44:34.509949
# Unit test for method weight of class Person
def test_Person_weight():
    dp = PersonalDataProvider()
    result = dp.weight()
    if not isinstance(result, int):
        raise AssertionError("This method return not integer. "
                             "This is unexpected behaviour.")


# Generated at 2022-06-23 21:44:35.726480
# Unit test for method worldview of class Person
def test_Person_worldview():
    worldview = Person().worldview()
    assert worldview in _data['worldview']

# Generated at 2022-06-23 21:44:37.890885
# Unit test for method surname of class Person
def test_Person_surname():
    m = Person()
    sn = m.surname()
    assert type(sn) is str

# Generated at 2022-06-23 21:44:38.688829
# Unit test for method last_name of class Person
def test_Person_last_name():
    pass

# Generated at 2022-06-23 21:44:42.587687
# Unit test for method surname of class Person
def test_Person_surname():
    pr = Person()
    assert isinstance(pr.surname(Gender.FEMALE), str)
    print(pr.surname(Gender.FEMALE))
    print(pr.surname())
    print(pr.surname(gender=Gender.MALE))


# Generated at 2022-06-23 21:44:44.521257
# Unit test for method age of class Person
def test_Person_age():
    person = Person()
    assert person.age() >= 0


# Generated at 2022-06-23 21:44:46.604653
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person('en')
    assert person.blood_type() in person.blood_types

# Generated at 2022-06-23 21:44:48.188251
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for i in range(100):
        assert Person().blood_type() in BLOOD_GROUPS



# Generated at 2022-06-23 21:44:49.833244
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    views_on = person.views_on()
    assert views_on in person._data['views_on']


# Generated at 2022-06-23 21:45:01.550423
# Unit test for method surname of class Person
def test_Person_surname():
    import json
    import os
    os.chdir('/home/daniil/python/library/locales/ru_RU/data')
    data = json.load(open('person.json'))
    surnames = data['surnames']
    assert Person.surname(surnames) in surnames
    assert Person.surname(surnames, gender='male') in surnames['male']
    assert Person.surname(surnames, gender='female') in surnames['female']
    assert Person.surname(surnames, gender='male') not in surnames['female']
    assert Person.surname(surnames, gender='female') not in surnames['male']

# Generated at 2022-06-23 21:45:02.536880
# Unit test for method university of class Person
def test_Person_university():
    assert 'University of Hyderabad' in Person().university()

# Generated at 2022-06-23 21:45:04.611956
# Unit test for method occupation of class Person
def test_Person_occupation():
    """Unit test for method occupation of class Person."""
    for _ in range(100):
        assert isinstance(Person().occupation(), str)

# Generated at 2022-06-23 21:45:05.265068
# Unit test for method avatar of class Person
def test_Person_avatar():
    pass

# Generated at 2022-06-23 21:45:10.986613
# Unit test for method email of class Person
def test_Person_email():
    person = Person(random=Random())

    assert person.email() == person.email()

    assert person.email(domains=('mail.com',)) == person.email(domains=('mail.com',))

    assert person.email(unique=True) == person.email(unique=True)

    assert person.email(domains=('mail.com',), unique=True) == person.email(domains=('mail.com',), unique=True)

# Generated at 2022-06-23 21:45:12.696919
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname()
# Testing method name of class Person

# Generated at 2022-06-23 21:45:14.949650
# Unit test for method political_views of class Person
def test_Person_political_views():
    fake = Faker()
    assert len(fake.political_views()) > 0



# Generated at 2022-06-23 21:45:24.157569
# Unit test for method identifier of class Person
def test_Person_identifier():
    provider = Person()

    assert provider.identifier('##-##/##') == '07-97/04'
    assert provider.identifier('@@-@@/@@') == 'XD-XD/XD'
    assert provider.identifier(mask='##-##/##') == '07-97/04'
    assert provider.identifier(mask='@@-@@/@@') == 'XD-XD/XD'
    assert provider.identifier(mask='##-##-####') == '07-97-1674'
    assert provider.identifier(mask='@@-@@-####') == 'XD-XD-1674'

    assert re.match(r'\d{2}-\d{2}-\d{4}', provider.identifier('##-##-####'))

# Generated at 2022-06-23 21:45:30.976744
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    tester = Provider()
    result = tester.work_experience()
    assert isinstance(result, tuple)
    assert isinstance(result[0], datetime.date)
    assert isinstance(result[1], datetime.date)

    result_2 = tester.work_experience(experience=datetime.timedelta(days=20))
    assert result_2[1] - result_2[0] == datetime.timedelta(days=20)


# Generated at 2022-06-23 21:45:37.671639
# Unit test for method weight of class Person
def test_Person_weight():
    examples = (
        # minimum, maximum, expected
        (38, 90, 48),
        (45, 100, 52),
        (30, 60, 49),
        (1, 99, 50),
        (1800, 2000, 1845),
    )
    for example in examples:
        (minimum, maximum, expected) = example
        assert expected == Person().weight(minimum, maximum)


# Generated at 2022-06-23 21:45:47.775804
# Unit test for method username of class Person
def test_Person_username():
    p = Person(seed=0)

    assert p.username() == "e_2019"
    assert p.username() == "e.1959"
    assert p.username() == "e-1912"
    assert p.username() == "ee-1954"
    assert p.username() == "ee.1910"
    assert p.username() == "ee_1879"
    assert p.username() == "ec-1974"
    assert p.username() == "ec.1925"
    assert p.username() == "et_2005"
    assert p.username() == "ef-2062"

    assert p.username() == "e_1932"
    assert p.username() == "e.1973"
    assert p.username() == "e-2013"
    assert p.username() == "ee-1962"

# Generated at 2022-06-23 21:45:49.383499
# Unit test for method age of class Person
def test_Person_age():
    assert Person().age() >= 0

# Generated at 2022-06-23 21:46:00.238088
# Unit test for constructor of class Person
def test_Person():
    # Test generator
    # Case: _check_data() - correct data
    def check_data(key: str, data: list) -> None:
        provider = Person(data)
        assert provider._data[key] == data
    # Case: _check_data() - incorrect data (not list)
    def check_incorrect_data(data: list) -> None:
        with pytest.raises(ValueError):
            provider = Person(data)
    # Case: _check_data() - incorrect data (empty list)
    def check_empty_data(data: list) -> None:
        with pytest.raises(ValueError):
            provider = Person(data)

    # Prepare test data

# Generated at 2022-06-23 21:46:02.058133
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person(seed=17)
    v = p.views_on()
    assert v == "Positive"

# Generated at 2022-06-23 21:46:09.148630
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    # [TEST] Username len[6]
    @unittest.skip("This method is not ready yet")
    def test_username_len(self):
        self.assertEqual(len(p.username(template="llllll")), 6)

    # [TEST] Username len[8]
    @unittest.skip("This method is not ready yet")
    def test_username_len(self):
        self.assertEqual(len(p.username(template="lllllll-d")), 8)
 

# Generated at 2022-06-23 21:46:12.222402
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    provider = Provider()

    for _i in range(10):
        degree = provider.academic_degree()
        assert isinstance(degree, str)
        assert degree in ACADEMIC_DEGREES

# Generated at 2022-06-23 21:46:16.182504
# Unit test for method username of class Person
def test_Person_username():
    provider = Person()
    username = provider.username()
    assert len(username) >= 5
    assert username[0:1].islower()


# Generated at 2022-06-23 21:46:17.765129
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    
    # Sample object
    sample_person = Person()
    
    # Test method
    assert sample_person.work_experience() in WORK_EXPERIENCE
    
    

# Generated at 2022-06-23 21:46:27.826160
# Unit test for method username of class Person
def test_Person_username():
    """Test case: test_Person_username."""
    # Arrange.
    p = Person()
    first_template = 'U_d' # U_d
    second_template = 'l.d' # l.d

    # Act
    first_name = p.username(template=first_template)
    second_name = p.username(template=second_template)

    # Assert
    assert all(re.match(r'[Uld\.\-\_]*[Ul]+[Uld\.\-\_]*', first_name)!=None for first_name in first_name)
    assert all(re.match(r'[Uld\.\-\_]*[Ul]+[Uld\.\-\_]*', second_name)!=None for second_name in second_name)


# Generated at 2022-06-23 21:46:30.984880
# Unit test for method university of class Person
def test_Person_university():
    '''Test to check if function return value is in list of universities'''
    person = Person()
    assert person.university() in person._data['university']


# Generated at 2022-06-23 21:46:34.018658
# Unit test for method occupation of class Person
def test_Person_occupation():
    try:
        assert Person().occupation() in Person()._data['occupation']
    except AssertionError:
        print('test_Person_occupation() - FAILED')

# Generated at 2022-06-23 21:46:36.762543
# Unit test for method full_name of class Person
def test_Person_full_name():
    pr = Person()
    name = pr.full_name(reverse=True)
    assert isinstance(name, str)
    print(name)

test_Person_full_name()


# Generated at 2022-06-23 21:46:38.986109
# Unit test for method university of class Person
def test_Person_university():
    a = Person(seed=86088150273875)
    assert a.university() == 'Yale'



# Generated at 2022-06-23 21:46:41.685592
# Unit test for method title of class Person
def test_Person_title():
    app = Person().title()
    assert app, "Error: Testing method 'title'"

# Generated at 2022-06-23 21:46:43.277370
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    assert '1.' in p.height()



# Generated at 2022-06-23 21:46:45.301575
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    assert isinstance(p.sexual_orientation(), str)


# Generated at 2022-06-23 21:46:48.062067
# Unit test for method gender of class Person
def test_Person_gender():
    male = Gender.MALE.value
    female = Gender.FEMALE.value
    person = Person()
    assert person.gender() in (male, female)

# Generated at 2022-06-23 21:46:49.897613
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person(locale='en')
    assert isinstance(person.views_on(), str)

# Generated at 2022-06-23 21:46:57.472080
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Validate social_media_profile method of class Person
    # Create instance of class Person
    person = Person()
    # Validate social_media_profile method of class Person
    social_media_profile = person.social_media_profile()
    # Print "\n\t>>> social_media_profile = {0}".format(social_media_profile)
    ############
    # Validate social_media_profile method of class Person
    social_media_profile = person.social_media_profile('Facebook')
    # Print "\n\t>>> social_media_profile = {0}".format(social_media_profile)
    ############
    # Validate social_media_profile method of class Person
    social_media_profile = person.social_media_profile('Skype')
    # Print "\n\t>>> social_media_

# Generated at 2022-06-23 21:47:07.804055
# Unit test for method name of class Person
def test_Person_name():
    from dataclasses import dataclass
    @dataclass
    class Person:
        name: str
        surnames: str
        gender: str
        title_type: str
        full_name: str
        username: str
        password: str
        email: str
        social_media_profile: str
        gender: str
        sex: str
        height: str
        weight: int
        blood_type: str
        sexual_orientation: str
        occupation: str
        political_views: str
        worldview: str
        views_on: str
        nationality: str
        university: str
        academic_degree: str
        language: str
        telephone: str
        avatar: str
        identifier: str
    import random
    import hashlib
    seed = random.random()

# Generated at 2022-06-23 21:47:11.292896
# Unit test for method age of class Person
def test_Person_age():
    person1 = Person()
    assert person1.age() in range(13, 46 + 1)

    person2 = Person(random=2)
    assert person2.age() in range(13, 46 + 1)



# Generated at 2022-06-23 21:47:13.480622
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    result = person.university()
    correct = result in person._data['university']
    assert correct


# Generated at 2022-06-23 21:47:14.587784
# Unit test for method political_views of class Person
def test_Person_political_views():
    for _ in range(10):
        assert Person().political_views() in POLITICS



# Generated at 2022-06-23 21:47:23.138425
# Unit test for method sex of class Person
def test_Person_sex():
    """Test for method sex of class Person."""

    print('Testing method sex of class Person')

    random.seed(12345)
    person = Person(random.Random())

    # Test arguments type
    with pytest.raises(TypeError):
        person.sex(1)

    # Test return value of method sex with default is_symbol=False
    test_value = person.sex()
    assert test_value in ('Male', 'Female')

    # Test return value of method sex with is_symbol=True
    test_value = person.sex(symbol=True)
    assert test_value in ('♂', '♀')

# =======================
# Method password of class Person
# =======================


# Generated at 2022-06-23 21:47:25.955321
# Unit test for method views_on of class Person
def test_Person_views_on():
    for i in range(100):
        assert isinstance(person.views_on(), str), \
            'Method views_on() of class Person should return string.'

# Generated at 2022-06-23 21:47:30.024779
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    t1 = p.telephone()
    assert t1
    assert isinstance(t1, str)
    assert len(t1) >= 10

# Generated at 2022-06-23 21:47:40.429534
# Unit test for method surname of class Person
def test_Person_surname():
    """
    You can find lot of test branches at
        * https://github.com/joke2k/faker/blob/master/tests/test_person.py
        * https://github.com/s-nt/pyfaker/blob/master/tests/test_person.py
    """
    gender = Gender.MALE.value
    assert Person.surname(gender) in SURNAME_MALE
    assert Person.last_name(gender) in SURNAME_MALE

    gender = Gender.FEMALE.value
    assert Person.surname(gender) in SURNAME_FEMALE
    assert Person.last_name(gender) in SURNAME_FEMALE

    assert Person.surname(gender=None) in SURNAME_FEMALE + SURNAME_MALE

# Generated at 2022-06-23 21:47:43.549222
# Unit test for method occupation of class Person
def test_Person_occupation():
    from faker.providers.person.ru_RU import Provider
    from faker import Faker
    import pytest
    f = Faker()
    f.add_provider(Provider)
    for _ in range(10):
        job = f.occupation()
        assert isinstance(job, str)


# Generated at 2022-06-23 21:47:48.029306
# Unit test for method sex of class Person
def test_Person_sex(): 
    ls = []
    p = Person()
    for i in range(100):
        g = p.sex()
        assert g in ('Female', 'Male', 'Male', 'Male', 'Not known','Not applicable'), f"{g} is not in list:" \
                                                                                         f" ['Female', 'Male', 'Male', " \
                                                                                         f"'Male', 'Not known','Not applicable']"
        ls.append(g)
    return ls

# Generated at 2022-06-23 21:47:54.043565
# Unit test for method password of class Person
def test_Person_password():
    seed = 0
    data = Person(seed=seed)
    assert data.password(hashed=True) == \
        '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'


# Generated at 2022-06-23 21:47:56.559479
# Unit test for method username of class Person
def test_Person_username():
    # Assert is instance
    person = Person()
    assert isinstance(person.username(template='U_d'), str)

# Generated at 2022-06-23 21:47:58.145941
# Unit test for method language of class Person
def test_Person_language():

    person = Person()

    assert person.language() in LANGUAGES

# Generated at 2022-06-23 21:48:04.191271
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person("ru")
    assert isinstance(person.nationality(), str)
    # test gender argument
    gender = Gender.male
    assert isinstance(person.nationality(gender), str)
    gender = Gender.female
    assert isinstance(person.nationality(gender), str)
    # test unsupported gender argument
    with pytest.raises(NonEnumerableError):
        person.nationality("wrong")


# Generated at 2022-06-23 21:48:12.076344
# Unit test for method height of class Person
def test_Person_height():
    from pydantic import ValidationError

    p1 = Person()
    assert p1.height() != None

    p2 = Person()
    p2.height(minimum = 2.0, maximum = 2.3)  # NOT COVERED
    assert p2.height() != None

    try:
        p3 = Person()
        p3.height(minimum = 2.0, maximum = 1.4)
    except:
        assert True
    else:
        assert False

    try:
        p4 = Person()
        p4.height(minimum = 1.2, maximum = 1.2)
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:48:20.321361
# Unit test for method password of class Person
def test_Person_password():
    print('test_Person_password')
    
    #for _ in range(10):
    #    print(_)
    
    # Create object
    prsn = Person()
    
    # Test method
    pswrd = prsn.password()
    print(pswrd)
    print('-'*79)
    
    # Test method
    hash_pswrd = prsn.password(hashed=True)
    print(hash_pswrd)
    print('-'*79)
    
    # Check length of password
    assert len(pswrd) >= 8
    print(len(pswrd))
    print('-'*79)
    
    # Check length of hash
    assert len(hash_pswrd) == 32
    print(len(hash_pswrd))
    

# Generated at 2022-06-23 21:48:23.045569
# Unit test for method title of class Person
def test_Person_title():
    t = Person()
    title = t.title(gender = Gender.MALE)
    assert title in t._data['title']['male']['prefix'], 'Method title return incorrect result'
# Unit testing for method title of class Person

# Generated at 2022-06-23 21:48:34.365623
# Unit test for method first_name of class Person
def test_Person_first_name():
    provider = Person(seed=42)
    assert provider.first_name() == 'John'
    assert provider.first_name(Gender.MALE) == 'John'
    assert provider.first_name(Gender.FEMALE) == 'Amanda'
    provider_two = Person(seed=42)
    assert provider_two.first_name() == 'John'
    assert provider_two.first_name(Gender.MALE) == 'John'
    assert provider_two.first_name(Gender.FEMALE) == 'Amanda'
    assert provider_two.first_name() == provider.first_name()
    assert provider_two.first_name(Gender.MALE) == provider.first_name(
        Gender.MALE)
    assert provider_two.first_name(Gender.FEMALE) == provider.first_

# Generated at 2022-06-23 21:48:39.793360
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    """
    Test method academic_degree of class Person.
    """
    # Check academic degree
    person = Person()
    assert person.academic_degree() in ACADEMIC_DEGREES
    assert person.academic_degree() in person._data['academic_degree']

# Generated at 2022-06-23 21:48:43.275918
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    assert isinstance(p.last_name(), str)
    assert p.last_name() in SURNAMES
    
test_Person_last_name()
    

# Generated at 2022-06-23 21:48:46.070848
# Unit test for method gender of class Person
def test_Person_gender():
    print(Person().gender())
    print(Person().gender(symbol=True))
    print(Person().gender(iso5218=True))
test_Person_gender()


# Generated at 2022-06-23 21:48:53.406099
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    # Setup
    random.seed(90805)
    gender = 'female'
    
    
    # Exercise
    actual_result = Person(gender).sexual_orientation()
    
    # Verify
    expected_result = 'Heterosexuality'
    assert actual_result == expected_result

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Cleanup - none necessary




# Generated at 2022-06-23 21:48:58.121836
# Unit test for method title of class Person
def test_Person_title():
    import random
    from faker_ru_lite.enums import Gender

    for _ in range(100):
        for gender in Gender:
            person = Person(random)
            title = person.title(gender=gender)
            print(title)



# Generated at 2022-06-23 21:49:00.178607
# Unit test for method language of class Person
def test_Person_language():
    for i in range(1000):
        language = Person().language()
        assert language in LANGUAGES

# Generated at 2022-06-23 21:49:02.952457
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    assert isinstance(person.university(), str)


# Unit Test for method Political_Views of class Person

# Generated at 2022-06-23 21:49:04.283795
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert type(Person.political_views(Person())) == str

# Generated at 2022-06-23 21:49:07.206788
# Unit test for method telephone of class Person
def test_Person_telephone():
    test = Person()
    assert re.match(r'^(\+\d{1,3}[- ]?)?\d{10}$', test.telephone()) is not None


# Generated at 2022-06-23 21:49:09.398449
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Set
    name = 'Johann'
    surname = 'Wolfgang'

    # Assert
    assert name + ' ' + surname == Person().full_name()


# Generated at 2022-06-23 21:49:11.421015
# Unit test for method views_on of class Person
def test_Person_views_on():
    for i in range(100):
        person = PersonFactory()
        person.views_on()

# Generated at 2022-06-23 21:49:19.534800
# Unit test for method title of class Person
def test_Person_title():
    assert Person.title(Gender.MALE, TitleType.PREFIX) == 'Mr.'
    assert Person.title(TitleType.PREFIX) in ['Mr.', 'Mrs.']
    assert Person.title(TitleType.PREFIX) in ['Mr.', 'Mrs.']
    assert Person.title(Gender.MALE, TitleType.SUFFIX) == 'Jr.'
    assert Person.title(Gender.FEMALE, TitleType.SUFFIX) == 'Jr.'
    assert Person.title(TitleType.SUFFIX) in ['Jr.', 'Sr.']
    assert Person.title() == 'Jr.'
    assert Person.title(0, 0) == 'Mr.'
    assert Person.title(1, 0) == 'Mrs.'
    assert Person.title(0, 1) == 'Jr.'
    assert Person

# Generated at 2022-06-23 21:49:26.431306
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    min_height = 1.5
    max_height = 2
    assert float(p.height()) >= float(min_height)
    assert float(p.height()) <= float(max_height)
    assert p.height() is not None
    assert p.height(unit='m') is not None
    assert p.height(unit='cm') is not None
    assert p.height(unit='mm') is not None

# Generated at 2022-06-23 21:49:28.409858
# Unit test for method first_name of class Person
def test_Person_first_name():
    provider = Person(seed=19095)
    assert provider.first_name() == 'Marco'
    provider = Person(seed=19095)
    assert provider.name() == 'Marco'


# Generated at 2022-06-23 21:49:29.390789
# Unit test for method sex of class Person
def test_Person_sex():
    woman = Person().sex
    man = Person().sex
    assert woman != man

# Generated at 2022-06-23 21:49:31.806202
# Unit test for method title of class Person
def test_Person_title():
    assert (Person.title(Gender.MALE, TitleType.PREFIX) != Person.title(Gender.MALE, TitleType.SUFFIX))

# Generated at 2022-06-23 21:49:42.058514
# Unit test for method username of class Person
def test_Person_username():
    from databaker.framework import *

    from tempfile import TemporaryDirectory
    from pathlib import Path

    from databaker.constants import *

    with TemporaryDirectory(prefix='databaker-') as temp:
        output = Path(temp, 'output.xlsx')

        # Initialize.
        tab1 = 'T1'
        tab2 = 'T2'
        tab3 = 'T3'

        parameters = [
            Parameter('template'),
        ]


# Generated at 2022-06-23 21:49:44.418490
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(10):
        result = Person().email()
        assert isinstance(result, str)
        assert result.split('@')[-1] in EMAIL_DOMAINS
        print(result)
    print()


# Generated at 2022-06-23 21:49:54.464242
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    rnd = random.Random(0)
    validator = EnumValidator(enum=Gender)
    person = Person(rnd)
    # Act
    result_1 = person.surname(gender=Gender.MALE)
    result_2 = person.surname(gender=Gender.FEMALE)
    result_3 = person.surname(gender='male')
    result_4 = person.surname(gender='female')
    result_5 = person.surname(gender=validator.enum_get('male'))
    result_6 = person.surname(gender=validator.enum_get('female'))
    # Assert
    assert result_1 == 'Петров'

# Generated at 2022-06-23 21:49:56.418544
# Unit test for method occupation of class Person
def test_Person_occupation():
    obj = Person(locale='en')
    assert obj.occupation() in OCCUPATIONS



# Generated at 2022-06-23 21:50:01.431492
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    def _test_Person_blood_type(length, *args, **kwargs):
        result = Person(*args, **kwargs).blood_type()
        length2 = len(result)
        if not isinstance(result, str) or length2 != length:
            raise ValueError('Wrong result of method blood_type')

    return _test_Person_blood_type


# Generated at 2022-06-23 21:50:05.927902
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender(iso5218=True) in [0, 1, 2, 9]
    assert person.gender(symbol=True) in ['♂', '♀']
    assert person.gender() in ['Male', 'Female', 'Androgynous']

# Generated at 2022-06-23 21:50:08.769901
# Unit test for method password of class Person
def test_Person_password():
    """Unit test for method password of class Person"""
    p = Person()
    value = p.password()
    # Check result.
    assert len(value) == 8,\
        'Method password of class Person failed'

# Generated at 2022-06-23 21:50:11.098836
# Unit test for method university of class Person
def test_Person_university():
    person = Person(_random=None)
    universities = person._data['university']
    for i in range(100):
        assert person.university() in universities


# Generated at 2022-06-23 21:50:12.477041
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    from faker import Faker
    fake = Faker('ru_RU')
    res = fake.blood_type()
    assert isinstance(res,str)


# Generated at 2022-06-23 21:50:24.237493
# Unit test for method username of class Person
def test_Person_username():
    p = Person()

    username1 = p.username('UU-d')  # e.g. 'k.1872'
    username2 = p.username('Ul-d')  # e.g. 'a1891'
    username3 = p.username('U-l-d')  # e.g. 'ir-i1885'
    username4 = p.username('U_d')  # e.g. 'n.1896'
    username5 = p.username('U.d')  # e.g. 'y.1888'
    username6 = p.username('ld')  # e.g. 'j.1879'
    username7 = p.username('l-d')  # e.g. 'r1871'
    username8 = p.username('Ud')  # e.g. 'z

# Generated at 2022-06-23 21:50:26.404421
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert isinstance(person, Person) is True


# Generated at 2022-06-23 21:50:28.237934
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person('en')
    assert p.work_experience() == 'at least 5 years'

# Generated at 2022-06-23 21:50:31.859534
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    first_email = person.email()
    second_email = person.email()
    print(first_email, second_email)
    assert(person)
test_Person_email()

# Generated at 2022-06-23 21:50:36.347242
# Unit test for method email of class Person
def test_Person_email():
    # Seed
    seed = 1
    rnd = Random(seed)

    # Create provider
    provider = Person(rnd=rnd)

    # Call method
    email = provider.email()

    # Check result
    assert email == 'avoc.1930@example.com'

# Generated at 2022-06-23 21:50:38.499932
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    result = person.worldview()
    print(type(result))
    print(result)
    

# Generated at 2022-06-23 21:50:49.797428
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """
    Test method blood_type of class Person
    """
    person = Person(seed=123)
    assert person.blood_type() == "O+"
    person = Person(seed=1234)
    assert person.blood_type() == "O+"
    person = Person(seed=12345)
    assert person.blood_type() == "AB-"
    person = Person(seed=123456)
    assert person.blood_type() == "B+"
    person = Person(seed=1234567)
    assert person.blood_type() == "B-"
    person = Person(seed=12345678)
    assert person.blood_type() == "O+"
    person = Person(seed=123456789)
    assert person.blood_type() == "AB+"

# Generated at 2022-06-23 21:50:56.778803
# Unit test for method university of class Person
def test_Person_university():
   # Unit test for method university of class Person
    @pytest.fixture(scope='class')
    def p(request):
        request.cls.p = Person()

    request.cls.p = Person()

    @pytest.mark.usefixtures('p')
    class TestPersonUniveristy:

        def test_university(self):
            """Univeristy should be string"""
            assert isinstance(self.p.university(), str)

test_Person_university()
