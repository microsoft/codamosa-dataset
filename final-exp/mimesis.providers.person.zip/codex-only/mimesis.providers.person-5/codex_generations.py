

# Generated at 2022-06-23 21:41:04.596866
# Unit test for method occupation of class Person
def test_Person_occupation():
    from pydantic import BaseModel, ValidationError
    import typing
    import random

    class Person(BaseModel):
        name: str
        occupation: str

    p = Person(name=None, occupation=None)
    person_list = []
    for n in range(0, 1000):
        rand_value = random.randint(0, 2000)
        person_list.append({"name": "Person " + str(rand_value), "occupation": p.occupation()})

    print("------ Test 1 ------")
    print(person_list)

    # unit test for method 'name' and 'occupation' in class Person
    # The code is written according to the principle of polymorphism
    # В качестве аргумента в выз

# Generated at 2022-06-23 21:41:07.439697
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person(Random())
    avatar = person.avatar()

    assert 'https://api.adorable.io/avatars/256/' in avatar
    assert avatar[avatar.rfind('.'):] in ['.png', '.jpg']


# Generated at 2022-06-23 21:41:11.667854
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    name = person.name(Gender.MALE)
    assert name in person._data['name']['male']
    name = person.name(Gender.FEMALE)
    assert name in person._data['name']['female']


# Generated at 2022-06-23 21:41:17.384743
# Unit test for method password of class Person
def test_Person_password():
    p = Person(random=Random())
    assert isinstance(p.password(8,False),str)
    assert p.password(5,False) != p.password(5,False)
    assert len(p.password(5,False))==5
    assert len(p.password(10,False))==10
    assert len(p.password(1,False))==1

# Generated at 2022-06-23 21:41:19.876529
# Unit test for method views_on of class Person
def test_Person_views_on():

    person = Person('en')
    views = person.views_on()
    assert views in person._data['views_on']



# Generated at 2022-06-23 21:41:22.830277
# Unit test for constructor of class Person
def test_Person():
    random = Random()
    person = Person(random=random)
    assert isinstance(person.random, Random)
    assert isinstance(person.data, dict)
    assert isinstance(person.dictionaries, Dictionaries)


# Generated at 2022-06-23 21:41:25.546343
# Unit test for method age of class Person
def test_Person_age():
    assert Persona().age()

    current_year = datetime.datetime.now().year
    assert Persona().age(minimum=current_year - 59, maximum=current_year - 21) in range(21, 60)

    assert Persona().age(minimum=1900, maximum=1940) in range(18, 100)

# Generated at 2022-06-23 21:41:35.546853
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Create a provider for Person
    p = Person()
    # Check that Person set the gender, if Person receive parameter
    # ``gender = Gender.male`` and Person return fullname from male names
    assert p.full_name(gender=Gender.male).split(' ')[0] in MALE_NAMES
    # The same but with female names
    assert p.full_name(gender=Gender.female).split(' ')[0] in FEMALE_NAMES
    # Check that Person can return reversed fullname when Person receive
    # parameter ``reverse = True``
    fullname = p.full_name(reverse=True)
    assert fullname.split(' ')[::-1][0] in FEMALE_NAMES and \
           fullname.split(' ')[::-1][1] in SURNAMES
    # Check that gender is optional

# Generated at 2022-06-23 21:41:41.322097
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person(random=Random())
    for _ in range(100):
        assert len(provider.gender()) > 0
    for _ in range(100):
        assert len(provider.gender(symbol=True)) > 0
    for _ in range(100):
        assert len(str(provider.gender(iso5218=True))) == 1


# Generated at 2022-06-23 21:41:42.909141
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert Person.blood_type() in BLOOD_GROUPS


# Generated at 2022-06-23 21:41:47.299430
# Unit test for method title of class Person
def test_Person_title():
    assert Person().title() == 'Dr'
    assert Person().title(Gender.FEMALE) == 'Mrs'
    assert Person().title(TitleType.PREFIX) == 'Mr'
    assert Person().title(Gender.FEMALE, TitleType.POSTFIX) == 'PhD'



# Generated at 2022-06-23 21:41:49.259444
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert isinstance(person.email(), str)


# Generated at 2022-06-23 21:41:52.674988
# Unit test for method weight of class Person
def test_Person_weight():
    for i in range(0, 10):
        res = Person().weight(minimum = 38, maximum = 90)
        if res < 38:
            return False
        if res > 90:
            return False
    return True

test_Person_weight()

# Generated at 2022-06-23 21:41:54.767756
# Unit test for method university of class Person
def test_Person_university():
    people = []
    for i in range(1001):
        people.append(Person())
        
    assert len(set(people)) == 1000
test_Person_university()

# Generated at 2022-06-23 21:41:57.006400
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert Person().sexual_orientation() in SEXUAL_ORIENTATIONS
    assert Person().sexual_orientation(symbol=True) in SEXUALITY_SYMBOLS


# Generated at 2022-06-23 21:41:57.774276
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert type(Person().occupation()) == str

# Generated at 2022-06-23 21:41:59.424026
# Unit test for method sex of class Person
def test_Person_sex():
    # Test for coverage 100%
    assert Person().sex(symbol=True) != None
    assert Person().sex(iso5218=True) != None


# Generated at 2022-06-23 21:42:01.748783
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    assert isinstance(person.telephone(), str)
    assert len(person.telephone()) == 17
    
    

# Generated at 2022-06-23 21:42:06.867224
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    assert person.political_views() in (
        "Liberal",
        "Moderate",
        "Conservative",
        "Libertarian",
        "Green",
        "Monarchist",
        "Anarchist",
        "Communist",
        "Socialist",
        "Centrist",
        "Nationalist",
    )

# Generated at 2022-06-23 21:42:12.187239
# Unit test for method name of class Person
def test_Person_name():
    import random
    from random import seed
    
    for seed_ in range(1,1000):
        seed(seed_)
        p = Person(seed=seed_)
        try:
            assert p.name() == 'Sonia'
        except AssertionError:
            print ("Method name of class Person failed with seed", seed_)
            break

# Generated at 2022-06-23 21:42:13.042040
# Unit test for method language of class Person
def test_Person_language():
    language = Person().language()
    assert isinstance(language, str)

# Generated at 2022-06-23 21:42:15.189174
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person(seed=1337)
    assert person.avatar(size=128) == 'https://api.adorable.io/avatars/128/4b2c2e766a5cbf490d280acd07b93485.png'


# Generated at 2022-06-23 21:42:18.191628
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Base test
    for _ in range(100):
        p = Person()
        result = p.nationality()
        assert len(result) > 1
        assert isinstance(result, str)


# Unit tests for method last_name of class Person

# Generated at 2022-06-23 21:42:20.278510
# Unit test for method occupation of class Person
def test_Person_occupation():
    obj = Person()

    result = obj.occupation()
    assert type(result) is str

# Generated at 2022-06-23 21:42:26.825789
# Unit test for method worldview of class Person
def test_Person_worldview():
    import pytest
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import text
    import re

    @given(worldview = text())
    # Unit test for method worldview of class Person
    def test_Person_worldview(worldview):
        Fake = Faker(locale='en')
        worldview_regex = '^([A-Z][a-z]+(\s[A-Z][a-z]+)*)$'
        worldview_test = re.search(worldview_regex, Fake.worldview())
        worldview_test = worldview_test.group(0)
        worldview_test = worldview_test.replace(' ', '')
        worldview = worldview.replace(' ', '')
        assert Fake.worldview() != worldview
        assert worldview_test == worldview

    test_Person_

# Generated at 2022-06-23 21:42:28.772629
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    universities = person._data['university']
    assert person.university() in universities

# Generated at 2022-06-23 21:42:39.397754
# Unit test for method password of class Person
def test_Person_password():
    # Testing with a seeded provider
    seeded = Person(seed=42)
    assert seeded.password() == 'VpU6JN$7'  # length 8
    assert seeded.password(length=20) == 'VpU6JN$7D6k*mH5X5%8W'  # length 20
    assert seeded.password(hashed=True) == 'e688b0d9d7e9c8abfbd3c3d6fcdde7d0'

    # Testing with a dynamic provider
    assert Person().password().isalnum()  # length 8
    assert Person().password(length=20).isalnum()  # length 20
    assert Person().password(hashed=True).isalnum()
test_Person_password()


# Generated at 2022-06-23 21:42:43.498580
# Unit test for method gender of class Person
def test_Person_gender():
    for _ in range(10):
        # Check that result is always str class
        assert isinstance(Person().gender(),str)
        # Check that the result is in the correct range
        assert ((Person().gender(symbol=True) in GENDER_SYMBOLS) or (Person().gender(iso5218=True) in [0,1,2,9]))

# Generated at 2022-06-23 21:42:47.534591
# Unit test for method username of class Person
def test_Person_username():
    u_1_1 = Person().username()
    u_1_2 = Person().username()
    u_2_1 = Person().username('default')
    u_2_2 = Person().username('default')
    u_3_1 = Person().username('l.d')
    u_3_2 = Person().username('l.d')
    
    assert u_1_1 != u_1_2
    assert u_2_1 != u_2_2
    assert u_3_1 != u_3_2

# Generated at 2022-06-23 21:42:50.718133
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    for _ in range(50):
        assert person.sex() in person._data["gender"], "Not in person._data[\"gender\"]"

# Generated at 2022-06-23 21:42:52.579698
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    political_views = person.political_views()
    assert political_views in POLITICAL_VIEWS

# Generated at 2022-06-23 21:42:57.140908
# Unit test for method identifier of class Person
def test_Person_identifier():
    from faker_no.providers import Person
    from faker_no.providers.person import CustomCode

    p = Person(seed=1337)
    code = p.identifier(mask='##-##/##')
    assert code == '07-97/04'



# Generated at 2022-06-23 21:43:02.978908
# Unit test for method gender of class Person
def test_Person_gender():
    from random import seed
    from stringcase import snakecase
    from faker.generator import random
    from faker.providers.person.en_US import Provider as Person

    seed(1)
    p = Person(random)
    for enum in range(0,4):
        if not isinstance(p.gender(iso5218 = True), int):
            return False
        assert isinstance(p.gender(iso5218 = True), int)
    assert isinstance(p.gender(), str)
    assert isinstance(p.gender(), str)
    assert isinstance(p.gender(iso5218 = False), str)
    assert isinstance(p.gender(symbol = True), str)
    assert isinstance(p.gender(symbol = True), str)

# Generated at 2022-06-23 21:43:05.785958
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person.academic_degree(Person) == "Bachelor"

# Generated at 2022-06-23 21:43:15.303606
# Unit test for method occupation of class Person
def test_Person_occupation():
    obj = Person(seed=100)
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'
    assert obj.occupation() == 'Artist'

# Generated at 2022-06-23 21:43:18.382986
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    assert len(person.telephone()) == 14
    assert re.match(r'^\+7-\d{3}-\d{3}-\d{4}$', person.telephone())

# Generated at 2022-06-23 21:43:20.383881
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    s = p.worldview()
    assert s in p._data['worldview']



# Generated at 2022-06-23 21:43:21.536765
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    assert person.language() in LANGUAGES


# Generated at 2022-06-23 21:43:24.376586
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Unit test for method telephone of class Person"""
    person = PersonProvider()
    number = person.telephone()
    assert number != False



# Generated at 2022-06-23 21:43:26.816817
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    assert isinstance(p.worldview(), str)

# Test Person.worldview()
assert test_Person_worldview()

# Generated at 2022-06-23 21:43:29.151950
# Unit test for method username of class Person
def test_Person_username():
    r = Person().username()
    assert len(r) >= 6 and all(i.islower() or i in "0123456789-_." for i in r)


# Generated at 2022-06-23 21:43:33.324349
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert type(p.nationality()) == str
    assert type(p.nationality(Gender.FEMININE)) == str
    assert type(p.nationality(Gender.MASCULINE)) == str



# Generated at 2022-06-23 21:43:36.973673
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    """Unit test for method sexual_orientation of class Person."""
    p = Person()
    # Test if result is in list
    assert p.sexual_orientation() in SEXUAL_ORIENTATIONS
    # Test symbol
    assert p.sexual_orientation(symbol=True) in SEXUALITY_SYMBOLS
    # Test if result is string
    assert type(p.sexual_orientation()) == str

# Generated at 2022-06-23 21:43:39.298353
# Unit test for method occupation of class Person
def test_Person_occupation():
    # initialize
    person = Person()
    # test
    assert isinstance(person.occupation(), str)

# Generated at 2022-06-23 21:43:43.442519
# Unit test for method sex of class Person
def test_Person_sex():
    isinstance(Person().sex(), (str, int))
    isinstance(Person().sex(iso5218=True), int)
    isinstance(Person().sex(symbol=True), str)


# Generated at 2022-06-23 21:43:55.523740
# Unit test for method name of class Person
def test_Person_name():
    """Unit test for method name of class Person."""

    provider = Person(random.Random(2))

    assert provider.name(Gender.MALE) == 'Прокопий'
    assert provider.name(Gender.FEMALE) == 'Александрина'
    assert provider.name(Gender.UNKNOWN) == 'Александрина'
    assert provider.name(None) == 'Борис'

    assert provider.first_name(Gender.MALE) == 'Прокопий'
    assert provider.first_name(Gender.FEMALE) == 'Александрина'

# Generated at 2022-06-23 21:44:06.770671
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    from faker import Faker
    from datafactory.enums import SexualOrientation
    from datafactory.exceptions import NonEnumerableError

    fake = Faker()

    for _ in range(5):
        assert fake.sexual_orientation() in SexualOrientation

    for _ in range(5):
        assert isinstance(fake.sexual_orientation(), str)

    # Test enumerable by value
    for _ in range(5):
        assert fake.sexual_orientation(symbol=True) in SexualOrientation

    # Test enumerable by symbol
    for _ in range(5):
        assert fake.sexual_orientation(symbol=True) in SexualOrientation

    # Test raise NonEnumerableError

# Generated at 2022-06-23 21:44:08.863614
# Unit test for method occupation of class Person
def test_Person_occupation():
    from faker import Faker
    faker = Faker()
    print(faker.occupation())

# Generated at 2022-06-23 21:44:12.502194
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()

    phone = provider.telephone()
    assert re.match(r'[\+\(]\d*-\d*-\d*-\d*-\d*', phone)

    phone = provider.telephone(mask='###-###-####')
    assert re.match(r'\d*-\d*-\d*', phone)



# Generated at 2022-06-23 21:44:14.577526
# Unit test for method last_name of class Person
def test_Person_last_name():
    pr = Person()
    assert len(pr.last_name()) > 0


# Generated at 2022-06-23 21:44:17.589509
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Create instance of class Person
    obj = Person()
    # Call method full_name
    result = obj.full_name()
    # Check type of result
    assert isinstance(result, str)

# Generated at 2022-06-23 21:44:19.557926
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person()
    assert p.first_name() in FIRST_NAMES, 'It is not first name'


# Generated at 2022-06-23 21:44:22.217224
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    height = person.height()
    # height is 1.5 to 2.0, and 2 digit after point
    assert len(height) == 4
    assert float(height) >= 1.5
    assert float(height) <= 2.0


# Generated at 2022-06-23 21:44:23.787414
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = PersonFactory.create()
    assert person.nationality() == 'Russian', 'Method «nationality» failed'


# Generated at 2022-06-23 21:44:29.741993
# Unit test for method political_views of class Person
def test_Person_political_views():
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())
    print(Person().political_views())

# Generated at 2022-06-23 21:44:31.238832
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    assert person.worldview() in worldviews

# Generated at 2022-06-23 21:44:41.621257
# Unit test for constructor of class Person
def test_Person():
    provider1 = Person()
    assert isinstance(provider1.random, Random)
    assert provider1.locale == 'en'
    assert provider1.locale_data is not None
    assert provider1.seed is None

    provider2 = Person('en_US')
    assert provider2.locale == 'en_US'
    assert provider2.locale_data is not None
    assert provider2.seed is None

    provider3 = Person(random=Random(123))
    assert provider3.random is not None
    assert provider3.random.seed == 123
    assert provider3.seed == 123

    provider4 = Person(locale='uk')
    assert provider4.locale == 'uk'
    assert provider4.locale_data is None
    assert provider4.seed is None

# Unit tests for method "gender"

# Generated at 2022-06-23 21:44:43.248117
# Unit test for method title of class Person
def test_Person_title():
    from faker_seed.faker import Faker
    from faker_seed.faker import Faker



# Generated at 2022-06-23 21:44:45.532229
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    result = person.worldview()
    assert result in worldviews

# Generated at 2022-06-23 21:44:46.435075
# Unit test for method first_name of class Person
def test_Person_first_name():
  assert Person.first_name() is not None


# Generated at 2022-06-23 21:44:47.667067
# Unit test for method university of class Person
def test_Person_university():
    person = Person('en')
    university = person.university()
    assert bool(university)

# Generated at 2022-06-23 21:44:49.678439
# Unit test for method language of class Person
def test_Person_language():
    import doctest
    doctest.testmod(Person, verbose=True)


# Generated at 2022-06-23 21:44:56.395479
# Unit test for method password of class Person
def test_Person_password():
    # GIVEN a Person with a fixed seed
    person = Person(seed=1)
    # WHEN password() is called on person
    result = person.password()
    # THEN the result is "f<n_2(%iZ8"
    assert result == "f<n_2(%iZ8"

test_Person_password()

# Generated at 2022-06-23 21:44:59.142026
# Unit test for method username of class Person
def test_Person_username():
    # Create an instance of class Person
    person = Person()
    # Return a random username 
    assert isinstance(person.username(),str)

# Generated at 2022-06-23 21:45:03.069669
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    value = person.occupation()
    assert value == "Programmer" or value == "Professor" or value == "Psychiatrist" or value == "Psychologist" or value == "Public relations professional" or value == "Quality assurance specialist"

# Generated at 2022-06-23 21:45:06.713020
# Unit test for method weight of class Person
def test_Person_weight():
    provider = Person(random.Random(), 'ru_RU')
    w = provider.weight()
    assert type(w) == int
    assert w >= 38 and w <= 90
if __name__ == '__main__':
    test_Person_weight()
 

# Generated at 2022-06-23 21:45:07.817155
# Unit test for method worldview of class Person
def test_Person_worldview():
    assert Person().worldview() in WORLDVIEWS
test_Person_worldview()

# Generated at 2022-06-23 21:45:14.463042
# Unit test for method worldview of class Person
def test_Person_worldview():
    for i in range(10):
        assert Person().worldview() in ['Agnosticism', 'Atheism', 'Deism', 'Dualism', 'Empiricism', 'Idealism', 'Materialism', 'Naturalism', 'Nontheism', 'Pantheism', 'Phenomenalism', 'Positivism', 'Realism', 'Skepticism', 'Sufism', 'Taoism', 'Theism']


# Generated at 2022-06-23 21:45:16.742342
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Faker()
    phone = provider.telephone()
    assert len(phone) > 0, 'The phone number is not generated.'


# Generated at 2022-06-23 21:45:20.165807
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    print("Test for method blood_type ...")
    assert(isinstance(Person().blood_type(), str))
    assert(len(Person().blood_type())>0)
    print("ok")

# Generated at 2022-06-23 21:45:30.306646
# Unit test for method nationality of class Person
def test_Person_nationality():
    from random import Random
    from pyfaker.utils import SEED

    rnd = Random(SEED)
    p = Person(rnd)

# Generated at 2022-06-23 21:45:39.314460
# Unit test for method surname of class Person
def test_Person_surname():
    gender = Gender.MALE
    provider = Person(gender=gender)
    surnames = provider.surnames(gender=gender)
    assert surnames
    surnames = provider.surnames()
    assert surnames
    surnames = provider.surnames(gender=Gender.FEMALE)
    assert surnames
    surnames = provider.surnames(gender=Gender.UNDEFINED)
    assert surnames
    surnames = provider.surnames(gender=Gender.UNKNOWN)
    assert surnames

# Generated at 2022-06-23 21:45:45.877810
# Unit test for method title of class Person
def test_Person_title():
    assert Person.title(Gender.MALE, TitleType.PREFIX) in ('Mr.', 'Dr.')
    assert Person.title(Gender.FEMALE, TitleType.PREFIX) in ('Ms.', 'Dr.')

    assert Person.title(Gender.MALE, TitleType.SUFFIX) in ('Jr.', 'PhD')
    assert Person.title(Gender.FEMALE, TitleType.SUFFIX) in ('Jr.', 'PhD')


# Generated at 2022-06-23 21:45:54.022549
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from faker.providers.person.en_US_PersonProvider import Provider as PersonProvider
    from faker import Faker
    faker = Faker('en_US')
    faker.add_provider(PersonProvider)
    social_media_profile = faker.social_media_profile()
    assert(social_media_profile is not None)
    assert(faker.social_media_profile() != faker.social_media_profile())

# Generated at 2022-06-23 21:45:56.396542
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    for i in range(100):
        years = Person().work_experience()
        assert type(years) is int



# Generated at 2022-06-23 21:45:59.204380
# Unit test for method age of class Person
def test_Person_age():
    for _ in range(100):
        age = Person().age(minimum=5, maximum=10)
        assert 5 <= age <= 10, 'The age is not in the range 5-10'

# Generated at 2022-06-23 21:46:02.518201
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    orientations = person.sexual_orientation()
    locale = locale.setlocale(locale.LC_ALL, 'en_US.UTF8')
    assert orientations in locale


# Generated at 2022-06-23 21:46:03.886057
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    print(Person().work_experience())

# Generated at 2022-06-23 21:46:07.480419
# Unit test for method sex of class Person
def test_Person_sex():
    
    random.seed(2)
    gender = Gender.MALE
    result = Person().sex(gender=gender)
    print(result)
    assert result == 'Male'
    
    
    
test_Person_sex()

print('Test has passed successfully')


# Generated at 2022-06-23 21:46:19.928799
# Unit test for method first_name of class Person
def test_Person_first_name():
    print('Test method first_name of class Person')
    # Test generate name
    assert Person().first_name() in USERNAMES
    # Test generate name with gender
    assert Person().name(gender=Gender.MALE) in USERNAMES
    # Test generate name by male gender
    assert Person().first_name(gender=Gender.MALE) in USERNAMES
    # Test generate name by female gender
    assert Person().first_name(gender=Gender.FEMALE) in USERNAMES
    # Test generate name by alternative male gender
    assert Person().first_name(gender=Gender(1)) in USERNAMES
    # Test generate name by alternative female gender
    assert Person().first_name(gender=Gender(2)) in USERNAMES
    # Test generate name by not existing gender

# Generated at 2022-06-23 21:46:28.555490
# Unit test for method worldview of class Person
def test_Person_worldview():
    en = Person(lang='en')
    worldview = en.worldview()
    assert worldview in en._data['worldview']

test_Person_worldview()
assert Person(lang='en').worldview() in Person(lang='en')._data['worldview']

assert Person(lang='en').views_on() in Person(lang='en')._data['views_on']

assert Person(lang='en').nationality() in Person(lang='en')._data['nationality']

assert Person(lang='en').university() in Person(lang='en')._data['university']

assert Person(lang='en').academic_degree() in Person(lang='en')._data['academic_degree']

assert Person(lang='en').identifier()[0] == Person(lang='en').identifier()[0]



# Generated at 2022-06-23 21:46:32.983693
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person(seed=1234)
    assert person.avatar() == 'https://api.adorable.io/avatars/256/' \
                              'a31a3857d9548b0987ec3ca3c3159056.png'



# Generated at 2022-06-23 21:46:39.382183
# Unit test for method language of class Person
def test_Person_language():
    person_ru_language = Provider(lang='ru')
    person_ru_language.language() # Загребскохорватский
    person_ru_language.language() # Английский
    person_ru_language.language() # Украинский

    person_en_language = Provider(lang='en')
    person_en_language.language() # Chinese
    person_en_language.language() # Italian
    person_en_language.language() # Japanese

# Generated at 2022-06-23 21:46:42.079356
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for _ in range(100):
        assert Person().blood_type() in BLOOD_GROUPS


# Generated at 2022-06-23 21:46:52.415390
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person(seed=0)

    rt_date1 = datetime.date(2011, 9, 1)
    rt_date2 = datetime.date(2013, 11, 7)
    rt_date3 = datetime.date(2016, 9, 15)
    rt_date4 = datetime.date(2017, 2, 15)

    assert p.work_experience(rt_date1, rt_date2) == 1.47
    assert p.work_experience(rt_date2, rt_date3) == 3
    assert p.work_experience(rt_date3, rt_date4) == 0.39
    assert p.work_experience(years=1, months=2) == 1.2

# Generated at 2022-06-23 21:46:53.393925
# Unit test for method avatar of class Person
def test_Person_avatar():
    assert Person.avatar(256)


# Generated at 2022-06-23 21:46:59.248083
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    assert person.sex() in ['Female', 'Male']
    assert person.sex(iso5218=True) in [0, 1, 2, 9]
    assert person.sex(symbol=True) in list(GENDER_SYMBOLS)
    pass


# Generated at 2022-06-23 21:47:01.948654
# Unit test for method password of class Person
def test_Person_password():
    # Call the method under test and assert that the result is correct.
    assert Person.password() == 'k6dv2odff9#4h'

# Generated at 2022-06-23 21:47:06.973613
# Unit test for method gender of class Person
def test_Person_gender():
    for _ in range(100):
        gender = Person().gender()

        assert gender in Person.GENDERS

        gender = Person().gender(symbol=True)
        assert gender in Person.GENDER_SYMBOLS

        gender = Person().gender(iso5218=True)
        assert gender in [0, 1, 2, 9]


# Generated at 2022-06-23 21:47:10.600007
# Unit test for method university of class Person
def test_Person_university():
    arr = []
    for i in range(3):
        person = Person('en')
        person.random.seed(i)
        arr.append(person.university())
    assert arr == ['Heidelberg University', 'University of Oxford', 'University of Oxford']

# Generated at 2022-06-23 21:47:14.812305
# Unit test for method avatar of class Person
def test_Person_avatar():
    """Unit test for method avatar of class Person"""
    person = Person(seed=42)
    result = person.avatar()
    assert result == 'https://api.adorable.io/avatars/256/d41d8cd98f00b204e9800998ecf8427e.png'

# Generated at 2022-06-23 21:47:16.348283
# Unit test for method worldview of class Person
def test_Person_worldview():
  assert Person().worldview() in PERSON_WORLDVIEW

# Generated at 2022-06-23 21:47:19.867708
# Unit test for method username of class Person
def test_Person_username():
    provider = Person()
    for _ in range(100):
        username = provider.username(template='Ud')
        assert (
            re.fullmatch(
                '^[A-Z](\d{4})$',
                username
            )
        )


# Generated at 2022-06-23 21:47:26.869013
# Unit test for method username of class Person
def test_Person_username():
    ow = Person(seed=1)
    assert ow.username() == "r.t"
    assert ow.username(template="UUd") == "Rt1843"
    assert ow.username(template="Ud") == "H1950"
    assert ow.username(template="l.d") == "k.05"
    assert ow.username(template="l-d") == "m-91"
    assert ow.username(template="l_d") == "h_62"
    with pytest.raises(ValueError):
        ow.username(template="qwerty")
        ow.username(template="UU")

# Generated at 2022-06-23 21:47:28.387977
# Unit test for method height of class Person
def test_Person_height():
    assert 1.5 <= float(Person().height()) <= 2.0

# Generated at 2022-06-23 21:47:29.238111
# Unit test for method name of class Person
def test_Person_name():
  assert Person.name(None) == "Johann Wolfgang"

# Generated at 2022-06-23 21:47:39.770145
# Unit test for method password of class Person
def test_Person_password():
    from datetime import datetime
    from pprint import pprint as ppt
    from faker.utils.random import randint
    from faker.utils.text import slugify
    from faker.providers.address.ru_RU import Provider as RUProvider
    from faker.providers import BaseProvider
    from faker.providers.phone_number.en_US import Provider as PHProvider
    from faker.providers.person.de_DE import Provider as DEProvider
    from faker.providers.internet.en_US import Provider as InProvider
    import faker
    p = faker.Faker()
    p.seed_instance(0)
    p.add_provider(RUProvider)
    p.add_provider(PHProvider)
    p.add_provider(InProvider)
    p.add

# Generated at 2022-06-23 21:47:46.310787
# Unit test for method age of class Person
def test_Person_age():
    random.seed(0)
    assert Person.age() == 19
    assert Person.age() == 12
    assert Person.age() == 44
    assert Person.age() == 43
    assert Person.age() == 47
    assert Person.age() == 25
    assert Person.age() == 51
    assert Person.age() == 18
    assert Person.age() == 21
    assert Person.age() == 12
    assert Person.age() == 12
    assert Person.age() == 0
    assert Person.age() == 23
    assert Person.age() == 28
    assert Person.age() == 28
    assert Person.age() == 24
    assert Person.age() == 25
    assert Person.age() == 36
    assert Person.age() == 47
    assert Person.age() == 43
    assert Person.age() == 27

# Generated at 2022-06-23 21:47:48.038910
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    w = p.weight()
    assert isinstance(w, int)
    assert 38 <= w <= 90

# Generated at 2022-06-23 21:47:51.249348
# Unit test for method age of class Person
def test_Person_age():
    p = Person()
    if p.age() not in range(0, 120):
        raise AssertionError

# Generated at 2022-06-23 21:47:53.423852
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    faker = Faker()
    assert type(faker.blood_type()) is str


# Generated at 2022-06-23 21:47:59.893058
# Unit test for method username of class Person
def test_Person_username():
    from string import ascii_lowercase
    from random import seed, choice

    for i in range(500):
        seed(i)
        provider = Person(seed=i)
        username = provider.username()
        chars = ascii_lowercase + '0123456789'
        expected = ''.join([choice(chars) for _ in range(8)])
        assert username == expected
test_Person_username()


# Generated at 2022-06-23 21:48:02.241234
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']

test_Person_surname()

# Generated at 2022-06-23 21:48:11.344223
# Unit test for constructor of class Person
def test_Person():
    person = Person(seed=666)

    with pytest.raises(NonEnumerableError):
        person.gender(555)

    assert person.gender(Gender.UNKNOWN) == 'Male'

    with pytest.raises(NonEnumerableError):
        person.social_media_profile(555)

    assert person.social_media_profile(SocialNetwork.TWITTER) == \
        'https://twitter.com/vQdSX9'

    with pytest.raises(ValueError):
        person.email(unique=True)

    assert person.email() == 'wind_blow1993@yahoo.com'
    assert person.password(length=10) == 'F[#H"0R7Xg'


# Generated at 2022-06-23 21:48:12.302664
# Unit test for method avatar of class Person
def test_Person_avatar():
    print(Person().avatar())


# Generated at 2022-06-23 21:48:13.904104
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    gender = person.sex()
    assert gender in GENDER_OPTIONS



# Generated at 2022-06-23 21:48:20.998498
# Unit test for method avatar of class Person
def test_Person_avatar():
    test_avatar_url = 'https://api.adorable.io/avatars/256/'
    correct_avatar = ['7c9ee293d4a7f4c4ec4f7a06aec2ef80.png', '912b3c75b51d65e39e0cd76f837a7c52.png']

    test_avatar = Person().avatar()

    assert test_avatar.startswith(test_avatar_url)
    assert test_avatar.endswith(correct_avatar[0]) or test_avatar.endswith(correct_avatar[1])

    assert type(test_avatar) is str


# Generated at 2022-06-23 21:48:25.985366
# Unit test for method gender of class Person
def test_Person_gender():
    # Test with seeded provider
    p1 = Person(seed=42)

    assert p1.gender(iso5218=True) == 0
    assert p1.gender(symbol=True) == '♀'
    assert p1.gender() == 'Male'
    assert p1.gender() == 'Female'
    assert p1.gender() == 'Male'
    assert p1.gender() == 'Female'
    assert p1.gender() == 'Male'
    assert p1.gender() == 'Female'

# Generated at 2022-06-23 21:48:30.054675
# Unit test for method password of class Person
def test_Person_password():
    for _ in range(1000):
        # Test for parameter hashed
        assert len(Person(random=Random()).password(hashed=True)) == 32


# Generated at 2022-06-23 21:48:31.846102
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person()
    actual = provider.social_media_profile()
    assert actual == 'https://facebook.com/RaashidDobby'

# Generated at 2022-06-23 21:48:42.330386
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()

# Generated at 2022-06-23 21:48:44.189216
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    gen = Person()
    assert isinstance(gen.sexual_orientation(), str)

# Generated at 2022-06-23 21:48:46.633747
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert isinstance(Person.political_views(), str) and len(Person.political_views()) >= 3
test_Person_political_views()

# Generated at 2022-06-23 21:48:50.698551
# Unit test for method avatar of class Person
def test_Person_avatar():
    result = Person().avatar(size=256)
    assert re.fullmatch(
        r'(https://)(api.adorable.io/avatars/)(\d+)(/)([a-zA-Z0-9]+)(.png)', result) is not None

# Generated at 2022-06-23 21:48:54.016374
# Unit test for method first_name of class Person
def test_Person_first_name():
    i = 0
    while i < 1000 :
        test = Person()
        test.first_name()
        i += 1

# Generated at 2022-06-23 21:49:05.892263
# Unit test for method views_on of class Person
def test_Person_views_on():
    test_data = [
        'Agnostic',
        'Apatheism',
        'Atheism',
        'Deism',
        'Determinism',
        'Dualism',
        'Idealism',
        'Materialism',
        'Monism',
        'Moralism',
        'Naturalism',
        'Neutralism',
        'Nihilism',
        'Pantheism',
        'Pessimism',
        'Positive',
        'Realism',
        'Religious',
        'Skepticism',
        'Theism',
        'Tolerance',
        'Transcendentalism',
        'Uncertainty',
        'Unpredictability',
        'Fear of God',
        'Negative',
    ]
    assert Person.views_on() in test_data
    

# Generated at 2022-06-23 21:49:12.930975
# Unit test for method password of class Person
def test_Person_password():
    from unittest import TestCase
    from random import seed
    class _TestPersonPassword(TestCase):
        def test_1(self):
            seed(1)
            x = Person(seed=1).password()
            self.assertEqual(x, 'h3qZ"&pw')
            x = Person(seed=1).password(length=5)
            self.assertEqual(x, 'Y&%7V')
            x = Person(seed=1).password(length=5, hashed=True)
            self.assertEqual(x, 'd47882a5e7a5b53e5a7382d478d9e7b5')
    _TestPersonPassword().test_1()
 

# Generated at 2022-06-23 21:49:18.996201
# Unit test for method weight of class Person
def test_Person_weight():
    """Unit test for method weight of class Person."""
    person = Person(seed=42)

    actual = person.weight(minimum=1, maximum=1)
    assert actual == 1

    person = Person(seed=43)
    actual = person.weight(minimum=1, maximum=1)
    assert actual == 1

    person = Person(seed=44)
    actual = person.weight(minimum=1, maximum=1)
    assert actual == 1

    person = Person()
    actual = person.weight(minimum=1, maximum=2)
    assert actual in (1, 2)

# Generated at 2022-06-23 21:49:25.618317
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    for _ in range(100):
        assert len(p.telephone().split('-')) == 4
    for _ in range(100):
        assert len(p.telephone('###-##-##').split('-')) == 3
    for _ in range(100):
        assert len(p.telephone('###-###-##-##').split('-')) == 4


# Generated at 2022-06-23 21:49:27.658868
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person.academic_degree() in [
        'Bachelor',
        'Candidate',
        'PhD'
    ]

# Generated at 2022-06-23 21:49:30.092897
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person()

    for i in range(100):
        result = p.occupation()
        #print(result)

# Generated at 2022-06-23 21:49:35.618660
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email() in (
        'gjohann-wilhelm@yahoo.com',
        'krobert.balthasar@live.com',
        'tarcher.jeremias@gmail.com'
    )



# Generated at 2022-06-23 21:49:43.676563
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person(seed=1851, locale='en')
    assert person.blood_type() == '0-', "Case #0"

    person = Person(seed=5721, locale='en')
    assert person.blood_type() == 'B+', "Case #1"

    person = Person(seed=7364, locale='en')
    assert person.blood_type() == 'AB-', "Case #2"

    person = Person(seed=10756, locale='en')
    assert person.blood_type() == 'AB+', "Case #3"

    person = Person(seed=16495, locale='en')
    assert person.blood_type() == 'A-', "Case #4"

    person = Person(seed=19324, locale='en')

# Generated at 2022-06-23 21:49:45.374952
# Unit test for method views_on of class Person
def test_Person_views_on():
    value = get_random_item(
        ViewsOn,
        rnd=random.Random(
            seed=123456789
        )
    )
    assert value == 'hostile'

# Generated at 2022-06-23 21:49:48.438194
# Unit test for method email of class Person
def test_Person_email():
    person_provider = Person()

    email_address = person_provider.email()

    assert isinstance(email_address, str)
    assert len(email_address) != 0
    assert '@' in email_address

# Generated at 2022-06-23 21:49:53.537577
# Unit test for method name of class Person
def test_Person_name():
    p = Person()
    localization = 'ru_RU'
    result = p.name('ru_RU')
    assert result in NAME_RU_RU
    p.name('ru_RU') in NAME_RU_RU
    p.name('ru_RU') in dict(Gender)[0]
    assert p.name('ru_RU') in NAME_RU_RU


# Generated at 2022-06-23 21:49:57.302443
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person.work_experience() == "5-6 years"
    assert Person.work_experience() == "2-3 years"
    assert Person.work_experience() == "3-5 years"
    pass


# Generated at 2022-06-23 21:50:01.781903
# Unit test for method name of class Person
def test_Person_name():
    # Test 1
    person = Person()

    name = person.name(gender=Gender.male)
    assert type(name) == str
    assert name in MALE_NAMES

    # Test 2
    name = person.name(gender=Gender.female)
    assert type(name) == str
    assert name in FEMALE_NAMES

# Generated at 2022-06-23 21:50:02.677910
# Unit test for method weight of class Person
def test_Person_weight():
    assert Person.weight() > 0

# Generated at 2022-06-23 21:50:11.803045
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person('ru')
    person.seed(1)
    assert person.identifier("@@-@@/##") == "uf-fy/69"
    assert person.identifier("@@-@@/##") == "jy-ft/69"
    assert person.identifier("@@-@@/##") == "ta-lf/69"
    assert person.identifier("@@-@@/##") == "do-jv/69"
    assert person.identifier("@@-@@/##") == "sn-cd/69"
    assert person.identifier("@@-@@/##") == "dk-ct/69"
    assert person.identifier("@@-@@/##") == "ae-cu/69"
test_Person_identifier()


# Generated at 2022-06-23 21:50:16.686211
# Unit test for method name of class Person
def test_Person_name():
    fake = Faker()
    assert isinstance(fake.name(), str)
    assert isinstance(fake.first_name(), str)
    assert isinstance(fake.last_name(), str)
    assert isinstance(fake.full_name(), str)


# Generated at 2022-06-23 21:50:20.847032
# Unit test for method identifier of class Person
def test_Person_identifier():
    rv = Person().identifier('@@/##')
    assert len(rv) == 6
    assert re.match(r'\w\w/\d\d$', rv)


# Generated at 2022-06-23 21:50:23.311293
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    print()
    print(person.username())

if __name__ == '__main__':
    test_Person_username()


# Generated at 2022-06-23 21:50:28.089497
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    social_media_profile = person.social_media_profile(SocialNetwork.FACEBOOK)
    print(social_media_profile)
    assert social_media_profile.startswith('https://facebook.com')
    
test_Person_social_media_profile()


# Generated at 2022-06-23 21:50:31.040971
# Unit test for method gender of class Person
def test_Person_gender():
    seed(1)
    p = Person()
    result, expected = p.gender(), 'Male'
    assert result == expected

test_Person_gender()

# Generated at 2022-06-23 21:50:33.667558
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    # print(p.avatar())
    print(p.telephone('+7 (###) ###-##-##'))

# Generated at 2022-06-23 21:50:34.705850
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)

# Generated at 2022-06-23 21:50:37.381020
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    # Setup
    P = Person()
    # Exercise
    result = P.sexual_orientation()
    # Verify
    assert isinstance(result, str)
    

# Generated at 2022-06-23 21:50:41.098041
# Unit test for method university of class Person
def test_Person_university():
    mocker = Mocker()

    provider = mocker.mock()
    provider.random.choice.side_effect = (
        'Harvard University',
    )

    with mocker:
        person = Person(provider)
        assert person.university() == 'Harvard University'



# Generated at 2022-06-23 21:50:42.874629
# Unit test for method gender of class Person
def test_Person_gender():
    result = Person.gender()
    assert_in_result(result, ['Male', 'Female', 'Not specified'])

# Generated at 2022-06-23 21:50:44.857686
# Unit test for method worldview of class Person
def test_Person_worldview():
    _worldview = Person.worldview(Person())
    assert bool(_worldview)


# Generated at 2022-06-23 21:50:55.341896
# Unit test for constructor of class Person
def test_Person():
    faker = Person()

    assert isinstance(faker.name(Gender.MALE), str)
    assert isinstance(faker.surname(Gender.MALE), str)
    assert isinstance(faker.last_name(Gender.MALE), str)
    assert isinstance(faker.full_name(gender=Gender.MALE), str)
    assert isinstance(faker.username(), str)
    assert isinstance(faker.password(length=10), str)
    assert isinstance(faker.password(hashed=True), str)
    assert isinstance(faker.email(), str)
    assert isinstance(faker.social_media_profile(site=SocialNetwork.FACEBOOK), str)
    assert isinstance(faker.gender(), str)
    assert isinstance(faker.sex(), str)
