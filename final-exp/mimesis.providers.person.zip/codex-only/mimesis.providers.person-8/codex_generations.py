

# Generated at 2022-06-23 21:41:01.568510
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    for i in range(10):
        email = person.email()
        assert(re.match(r'[\w\d]+(\.|-|_)?[\w\d]+@[\w\d]+\.[\w\d]+', email))


# Generated at 2022-06-23 21:41:11.758966
# Unit test for method gender of class Person
def test_Person_gender():
    """Test method gender of class Person"""
    seed = 42
    rnd = Random(seed)
    person = Person(rnd)
    print(rnd)

    rnd.random()
    male = person.gender()
    print(rnd)

    rnd.random()
    male = person.gender(symbol=True)
    print(rnd)

    rnd.random()
    male = person.gender(iso5218=True)
    print(rnd)

    rnd.reset_state()
    print(rnd)

    rnd.random()
    male = person.gender()
    print(rnd)

    assert male == "Male"
    assert male == "♂"
    assert male == 1


# Generated at 2022-06-23 21:41:22.724418
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person(seed=1)

    assert provider.gender() != provider.gender()
    assert provider.gender() != provider.gender()
    assert provider.gender() != provider.gender()
    assert provider.gender() != provider.gender()
    assert provider.gender() != provider.gender()

    provider = Person(seed=1)

    assert provider.gender(iso5218=True) != provider.gender()
    assert provider.gender(iso5218=True) != provider.gender()
    assert provider.gender(iso5218=True) != provider.gender()

    assert provider.gender() != provider.gender()
    assert provider.gender() != provider.gender()
    assert provider.gender() != provider.gender()

    assert provider.gender(iso5218=True) != provider.gender()

# Generated at 2022-06-23 21:41:26.795627
# Unit test for method height of class Person
def test_Person_height():
    from random import Random
   
    random = Random()
    random.seed(0)
    
    p = Person(random=random)
    
    # Test normal
    h1 = p.height()
    h2 = p.height()
    h3 = p.height()
    h4 = p.height()

    assert h1 == '1.64'
    assert h2 == '1.95'
    assert h3 == '1.83'
    assert h4 == '1.96'


# Generated at 2022-06-23 21:41:28.839942
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    assert person.first_name(None, None) == 'Johann'

# Generated at 2022-06-23 21:41:37.215665
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Belarusian' 
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Russian' 
    p = Person()
    assert p.nationality() == 'Russian'

# Generated at 2022-06-23 21:41:39.632096
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    res = person.username()
    print(res)

# Generated at 2022-06-23 21:41:49.515467
# Unit test for method gender of class Person
def test_Person_gender():
    from faker import Faker
    from faker.generator import random
    from faker.providers.person.en import Provider
    from faker.providers.person.en_US import Provider as EnUsProvider
    from faker.providers.person.en_US import en_US_provider
    from faker.providers.person.en_US import en_US_provider_no_data
    from faker.utils import text, decorators
    from faker.providers.ssn.es import checksum, Provider as EsProvider
    from faker.providers.ssn.es import Provider as EsProvider
    from faker.providers.ssn.es import es_provider
    from faker.providers.ssn.es import es_ES_provider
    import pytest


# Generated at 2022-06-23 21:41:51.210775
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    result = Person.work_experience()
    assert result in WORK_EXPERIENCE



# Generated at 2022-06-23 21:41:53.480065
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=0)
    nationality = person.nationality()
    
    assert nationality == "Cambodian"
    assert type(nationality) == str

# Generated at 2022-06-23 21:41:56.274993
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    # Testing for avatar
    for i in range(5):
        assert isinstance(person.avatar(), str)
        assert 'https://api.adorable.io/avatars/256/' in person.avatar(), True


# Generated at 2022-06-23 21:41:59.684276
# Unit test for method email of class Person
def test_Person_email():
    print("Method email of class Person")
    person = Person()
    email = person.email()
    email_domain = email.split('@')[1]
    assert email_domain in EMAIL_DOMAINS
    assert email.count('@') == 1
    assert email.count('.') == 1
    assert len(email) > 6
    print("Method email of class Person")

# Generated at 2022-06-23 21:42:01.129351
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname()
    assert isinstance(Person.surname(), str)
    

# Generated at 2022-06-23 21:42:05.048834
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    assert isinstance(person.first_name(), str)
    assert isinstance(person.first_name(gender=Gender.MALE), str)
    assert isinstance(person.first_name(gender=Gender.FEMALE), str)

# Generated at 2022-06-23 21:42:08.028435
# Unit test for constructor of class Person
def test_Person():
    r = Faker('ru-RU')

    person = Person(r)
    assert person.random == r

    person = Person()
    assert person.random


# Generated at 2022-06-23 21:42:13.709035
# Unit test for constructor of class Person
def test_Person():
    # Create an instance of Person
    person = Person()

    assert isinstance(person, Person)
    assert isinstance(person.name(), str)
    assert isinstance(person.full_name(), str)
    assert isinstance(person.telephone(), str)
    assert isinstance(person.avatar(), str)
    assert isinstance(person.identifier(), str)
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-23 21:42:14.966949
# Unit test for method university of class Person
def test_Person_university(): 
    assert Person(random=Random()).university() in UNIVERSITIES  

# Generated at 2022-06-23 21:42:20.275075
# Unit test for method full_name of class Person
def test_Person_full_name():
    full_names_list = []
    for i in range(100):
        full_names_list.append(Person().full_name(Gender.MAN))
    assert all([name is not None and len(name)>0 for name in full_names_list]),\
    "Проверьте, что ваша функция работает правильно"
test_Person_full_name()

# Generated at 2022-06-23 21:42:27.236372
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert isinstance(p, Person)
    assert isinstance(p.random, Random)
    assert p.seed is None

    p = Person(random=42, seed=42)
    assert p.random.random() == 0.7311760305836546
    assert p.seed == 42

    p = Person(locale='uk_UA')
    assert p._locale == "uk_UA"
    assert isinstance(p._data, dict)



# Generated at 2022-06-23 21:42:30.408239
# Unit test for method language of class Person
def test_Person_language():
    p = Person('en')
    # test_Person_language1
    assert p.language() in ('Swedish', 'Danish', 'Finnish', 'Greek', 'Turkish')


# Generated at 2022-06-23 21:42:32.776858
# Unit test for method university of class Person
def test_Person_university():
    provider = Person()
    value = provider.university()
    assert isinstance(value, str)



# Generated at 2022-06-23 21:42:37.474913
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    from pydbgen import pydbgen
    myDB=pydbgen.pydb()
    sample_data = myDB.blood_type()
    assert type(sample_data) == str
    assert sample_data in BLOOD_GROUPS
test_Person_blood_type()

# Generated at 2022-06-23 21:42:42.798733
# Unit test for method last_name of class Person
def test_Person_last_name():
    """Test Person.last_name"""
    p = apg.Person()
    ln = p.last_name()
    assert ln
    assert isinstance(ln, str)
    # If the first letter is uppercase and the rest are lowercase
    assert ln[0].isupper()
    assert ln[1:].islower()
    # If there are spaces
    assert len(re.findall(' ', ln)) == 0

# Generated at 2022-06-23 21:42:45.804607
# Unit test for method surname of class Person
def test_Person_surname():
    # Setup
    person = Person()
    assert isinstance(person.surname(), str)



# Generated at 2022-06-23 21:42:54.698375
# Unit test for method surname of class Person
def test_Person_surname():
    global nicknames, surnames
    
    p = Person()
    assert isinstance(p, Person)
    
    # Validate whether nicknames is a list
    assert isinstance(nicknames, list)
    
    # Validate whether surnames is a dictionary
    assert isinstance(surnames, dict)
    
    # Test surname() of class Person
    assert p.surname(gender=Gender.MALE) in nicknames['male'] + surnames['male']
    
    assert p.surname(gender=Gender.FEMALE) in nicknames['female'] + surnames['female']
    
    # If a non-enum argument is given, an error should be raised
    try:
        p.surname(gender=123)
    except NonEnumerableError:
        pass

# Generated at 2022-06-23 21:43:00.523901
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert isinstance(p, Person)

    p = Person(seed=42)

# Generated at 2022-06-23 21:43:04.491996
# Unit test for method age of class Person
def test_Person_age():
    # Initialize a seed for the random number generator
    rnd = Random()
    # Initialize variable person
    person = Person(rnd)
    # Initialize variable age
    age = person.age(min=18, max=25)
    # Check if age is between 18 and 25
    assert age in range(18, 25)


# Generated at 2022-06-23 21:43:06.172108
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    assert len(provider.email()) > 0


# Generated at 2022-06-23 21:43:08.136986
# Unit test for method sex of class Person
def test_Person_sex():
    with Person.seed(10):
        p = Person().sex()
    assert p == 'Not known'


# Generated at 2022-06-23 21:43:17.054600
# Unit test for method first_name of class Person
def test_Person_first_name():
    # First name should be string
    assert isinstance(Person(random=Random(42)).first_name(), str)
    # First name should be "Иван"
    assert Person(random=Random(42)).first_name(Gender.MALE) == "Иван"
    # First name should be "Анна"
    assert Person(random=Random(42)).first_name(Gender.FEMALE) == "Анна"
    # First name should be "Алексей"
    assert Person(random=Random(42)).first_name(Gender.ANDROGYNE) == "Алексей"
    # First name should be "Жанна"

# Generated at 2022-06-23 21:43:19.090331
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider, Person)
    assert isinstance(provider.random, Random)


# Generated at 2022-06-23 21:43:24.469692
# Unit test for method identifier of class Person
def test_Person_identifier():
    P = Person()
    assert isinstance(P.identifier(), str)
    assert all(c in '0123456789-' for c in P.identifier())
    assert len(P.identifier()) == len('##-##/##')
    assert P.identifier('AA-00##')
    assert P.identifier('AA-00##/##')



# Generated at 2022-06-23 21:43:28.651901
# Unit test for method surname of class Person
def test_Person_surname():
    test_data = (
        (Gender.FEMALE, ()),
        (Gender.MALE, ()),
        (None, (None, Gender.FEMALE))
    )

    for gender, surnames in test_data:
        provider = Person(gender)
        assert provider.surname(gender) in surnames


# Generated at 2022-06-23 21:43:30.449900
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()

    if not p.sexual_orientation():
        raise Exception("Person sexual_orientation does not work...")



# Generated at 2022-06-23 21:43:37.720609
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    assert person.title(Gender.MALE, TitleType.PREFIX) in person._data['title']['MALE']['PREFIX']
    assert person.title(Gender.FEMALE, TitleType.SUFFIX) in person._data['title']['FEMALE']['SUFFIX']
if __name__ == '__main__':
    test_Person_title()

# Generated at 2022-06-23 21:43:41.818162
# Unit test for method worldview of class Person
def test_Person_worldview():
    gen = Person()
    try:
        worldview = gen.worldview()
    except Exception as e:
        worldview = None
        print(e, file=sys.stderr)
    print(worldview)
 

# Generated at 2022-06-23 21:43:45.282448
# Unit test for method identifier of class Person
def test_Person_identifier():
    print().ljust(90, '=')
    provider = Person()
    print(provider.identifier())
test_Person_identifier()


# Generated at 2022-06-23 21:43:49.271362
# Unit test for method worldview of class Person
def test_Person_worldview():
    provider = Person(
        help_information=True
    )
    worldview = provider.worldview()
    assert worldview in provider._data['worldview']
    
test_Person_worldview()


# Generated at 2022-06-23 21:43:57.921055
# Unit test for method surname of class Person
def test_Person_surname():
    data = [
            (None, 'Тест для данного человека'),
            (Gender.MALE, 'Тест для данного парня'),
            (Gender.FEMALE, 'Тест для данной девушки'),
        ]

    person = Person(no_sample=True)
    for (gender, expected) in data:
        assert person.surname(gender=gender) == expected

# Generated at 2022-06-23 21:44:00.052856
# Unit test for method age of class Person
def test_Person_age():
    person = Person()
    for i in range(10):
        age = person.age(minimum=0, maximum=100)
        assert type(age) == int
        assert age >= 0
        assert age <= 100

# Generated at 2022-06-23 21:44:05.808228
# Unit test for method password of class Person
def test_Person_password():
    """Test Method password."""
    person = Person(seed=1)
    assert person.password() == 'LyKj14U6'
    assert person.password() == ')6Dy!XV_'
    assert person.password() == 'P4W8ZGzH'
    assert person.password() == 'N8y=HNx5'
    assert person.password() == '%w~jTP3t'
    assert person.password() == 'vjxm@=J@'
    assert person.password() == '=+4(~g4N'
    assert person.password() == ')$E5*S+S'
    assert person.password() == 'h=m?bQ(8'
    assert person.password() == '$~JY9R(y'

# Generated at 2022-06-23 21:44:08.503089
# Unit test for method age of class Person
def test_Person_age():
    provider = Person()
    age = provider.age()
    assert isinstance(age, int)
    assert age > 0



# Generated at 2022-06-23 21:44:12.108700
# Unit test for method password of class Person
def test_Person_password():
    assert Person.password(8, True) == hashlib.md5('k6dv2odff9#4h'.encode()).hexdigest()
    assert Person.password(8, False) == 'k6dv2odff9#4h'

# Generated at 2022-06-23 21:44:21.580494
# Unit test for method title of class Person
def test_Person_title():
    # Random seed
    seed = random.random()

    # Objects initialization
    person = Person(seed=seed)

    # Number of iterations in sample
    iterations = 100

    # Substitute personal titles
    personal_titles = ('PhD', 'Mr', 'Mrs', 'Ms', 'Mx')

    # Tuples with personal titles and
    # title types for the sample
    personal_titles_with_title_types = (
        personal_titles,
        (TitleType.PREFIX, TitleType.SUFFIX),
    )

    # Tuples with personal titles, genders,
    # and title types for the sample

# Generated at 2022-06-23 21:44:22.806212
# Unit test for method name of class Person
def test_Person_name():
    Person = Person()
    output = Person.name()
    assert isinstance(output, str)

# Generated at 2022-06-23 21:44:24.683984
# Unit test for method name of class Person
def test_Person_name():
    assert Person.name('male') == 'Johann'
    assert Person.name('female') == 'Chloe'
    assert Person.name() in ('Johann', 'Chloe')

# Generated at 2022-06-23 21:44:26.675986
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    for _ in range(50):
        title = p.title(gender=None, title_type=None)
        assert isinstance(title, str)
        assert title



# Generated at 2022-06-23 21:44:27.675282
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert isinstance(person, Person)



# Generated at 2022-06-23 21:44:31.316085
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    res = person.surname(gender=Gender.MALE)
    assert res in MALE_SURNAMES

    res = person.surname(gender=Gender.FEMALE)
    assert res in FEMALE_SURNAMES

    res = person.surname(gender=Gender.UNKNOWN)
    assert res in UNKNOWN_SURNAMES

    res = person.surname(gender=Gender.NOTAPPLICABLE)
    assert res in NOTAPPLICABLE_SURNAMES


# Generated at 2022-06-23 21:44:41.709509
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person('en')
    identifier = person.identifier('##-##/##')
    assert isinstance(identifier, str)
    assert re.fullmatch(r'[0-9]{2}-[0-9]{2}/[0-9]{2}', identifier)
    assert len(identifier) == len('##-##/##')

    identifier = person.identifier('@###-##-##')
    assert isinstance(identifier, str)
    assert re.fullmatch(r'[a-z]{4}-[0-9]{2}-[0-9]{2}', identifier)

    identifier = person.identifier('@@##-##-##')
    assert isinstance(identifier, str)

# Generated at 2022-06-23 21:44:47.076201
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == p.email()
    assert p.email() == p.email()
    assert p.email() == p.email()
    assert p.email() == p.email()
    assert p.email() == p.email()
    assert p.email() == p.email()
    assert p.email() == p.email()



# Generated at 2022-06-23 21:44:52.685835
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    weight = person.weight()
    assert person.weight(minimum=38, maximum=90) == weight
    assert person.weight(min=38, max=90) == weight
    assert person.weight(38, 90) == weight
    assert person.weight(38, 90) == weight
    assert person.weight(38, 90) == weight


# Generated at 2022-06-23 21:44:56.004656
# Unit test for method weight of class Person
def test_Person_weight():
    person = get_person()
    assert type(person.weight()) is int, "Person weight() method is not working properly"

# Generated at 2022-06-23 21:44:58.803337
# Unit test for method name of class Person
def test_Person_name():
    """ Unit test for method name of class Person """
    person = Person()
    assert person.name() in PERSON_NAMES



# Generated at 2022-06-23 21:45:01.670289
# Unit test for method identifier of class Person
def test_Person_identifier():
    provider = Provider()
    assert re.match(r'\d{2}-\d{2}/\d{2}', provider.identifier())

# Generated at 2022-06-23 21:45:03.691502
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    # SUT
    provider = Person()

    # Exercise
    result = provider.academic_degree()

    # Verify
    assert result



# Generated at 2022-06-23 21:45:09.541929
# Unit test for method telephone of class Person
def test_Person_telephone():
    '''person = Person()
    for _ in range(1000):
        phone = person.telephone()
        assert re.fullmatch(
            r'\+[1-9]\d{1,2}\s\(\d{3}\)\s\d{3}\s\d{4}', phone)

    phone = person.telephone(mask='0(###)###-##-##')
    assert re.fullmatch(r'0\(\d{3}\)[-\.]?\d{3}\-\d{2}\-\d{2}', phone)

    phone = person.telephone(mask='###-###/##')
    assert re.fullmatch(r'\d{3}-\d{3}\/\d{2}', phone)'''


# Generated at 2022-06-23 21:45:15.893171
# Unit test for constructor of class Person
def test_Person():
    p = Person(seed=1)
    assert p.seed == 1
    # An alias for self.name() method.
    assert p.first_name() == 'Richard'
    # An alias for self.surname() method.
    assert p.last_name() == 'Kimmel'
    assert p.height() == '1.90'
    assert p.weight() == 71
    assert p.blood_type() == 'B+'
    assert p.sexual_orientation() == 'Asexuality'
    assert p.occupation() == 'Wiring mechanic'
    assert p.political_views() == 'Anarchism'
    assert p.worldview() == 'Agnosticism'
    assert p.views_on() == 'Negative'
    assert p.nationality() == 'Russian'
    assert p.un

# Generated at 2022-06-23 21:45:20.386478
# Unit test for method political_views of class Person
def test_Person_political_views():
    views = Person().political_views()
    assert views in (
        'Liberal',
        'Left-wing politics',
        'Center',
        'Right-wing politics',
        'Conservatism',
        'Centrism'
    )
test_Person_political_views()

# Generated at 2022-06-23 21:45:22.234152
# Unit test for method political_views of class Person
def test_Person_political_views():
    random = Random()
    res = random.political_views()
    assert isinstance(res, str)

# Generated at 2022-06-23 21:45:23.930657
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    output = person.university()
    assert output == "MIT"


# Generated at 2022-06-23 21:45:26.546778
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    h = person.height()
    assert type(h) == str
test_Person_height()

# Generated at 2022-06-23 21:45:29.892717
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    p.last_name() # not raise an exception
    p.last_name(Gender.MALE) # not raise an exception
    p.last_name(Gender.FEMALE) # not raise an exception

# Generated at 2022-06-23 21:45:36.739322
# Unit test for constructor of class Person
def test_Person():
    # The constructor without any parameter
    person = Person()
    assert isinstance(person, Person) == True

    # The constructor with parameter random
    uuid = str(uuid4())
    random = Random()
    random.seed(uuid)
    person = Person(random=random)
    assert person.seed == uuid
    assert isinstance(person, Person) == True

    # The constructor with parameter seed
    uuid = str(uuid4())
    person = Person(seed=uuid)
    assert person.seed == uuid
    assert isinstance(person, Person) == True

    # The constructor with parameter locale
    person = Person(locale='ru_RU')
    assert person.locale == 'ru_RU'
    assert isinstance(person, Person) == True

    # The constructor with parameter data
   

# Generated at 2022-06-23 21:45:39.376907
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    _test_Person(
        attribute='sexual_orientation',
        size=len(PERSON_DATA['sexuality'])
    )

# Generated at 2022-06-23 21:45:42.340985
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    assert person.views_on() \
        in person._data['views_on']


# Generated at 2022-06-23 21:45:53.492928
# Unit test for method username of class Person
def test_Person_username():
    p = Person(seed=5)
    assert p.username() == 'Ida_1870'
    assert p.username(template='UUU-dd') == 'Lan-07'
    assert p.username(template='Ud') == 'T33'
    assert p.username(template='U_ddd') == 'D_001'
    assert p.username(template='U_dd') == 'W_81'
    assert p.username(template='Udd') == 'H86'
    assert p.username(template='Uddd') == 'K109'
    assert p.username(template='U.dd') == 'R.32'
    assert p.username(template='l.dd') == 'e.15'
    assert p.username(template='U.d') == 'S.3'
    assert p.username

# Generated at 2022-06-23 21:45:55.943404
# Unit test for method surname of class Person
def test_Person_surname():
    per = Person()
    surname = per.surname()
    assert surname in per._data['surname']


# Generated at 2022-06-23 21:46:03.845185
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()

    assert isinstance(person.full_name(), str)
    assert len(re.findall(r'\w+', person.full_name())) == 2

    assert isinstance(person.full_name(reverse=True), str)
    assert len(re.findall(r'\w+', person.full_name(reverse=True))) == 2

    assert isinstance(person.full_name(gender=Gender.MALE), str)
    assert len(re.findall(r'\w+', person.full_name(gender=Gender.MALE))) == 2
    assert isinstance(person.full_name(gender=Gender.FEMALE), str)
    assert len(re.findall(r'\w+', person.full_name(gender=Gender.FEMALE))) == 2
# Unit

# Generated at 2022-06-23 21:46:07.438810
# Unit test for method age of class Person
def test_Person_age():
    print("Start test_Person_age")
    person = Person()
    age = person.age(minimum=3, maximum=7)
    assert isinstance(age, int)
    assert 4 <= age <= 6
    print("End test_Person_age")


# Generated at 2022-06-23 21:46:19.881923
# Unit test for method work_experience of class Person

# Generated at 2022-06-23 21:46:24.439581
# Unit test for method political_views of class Person
def test_Person_political_views():
    from pydantic import ValidationError

    political_view = Person().political_views()
    assert political_view in political_views_catalog

    try:
        political_view = Person().political_views('wrong_arg')
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-23 21:46:27.558455
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person('ru')
    person.academic_degree() # Actual value
    res = person.academic_degree() # Expected value
    assert res == res

# Generated at 2022-06-23 21:46:28.954100
# Unit test for constructor of class Person
def test_Person():
    # Create an instance of class Person
    person = Person()


# Generated at 2022-06-23 21:46:30.935252
# Unit test for method language of class Person
def test_Person_language():
    p = Person()
    print(p.telephone())
    return True

# Generated at 2022-06-23 21:46:32.495069
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() == 'Russian'
    

# Generated at 2022-06-23 21:46:33.680989
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert isinstance(p, Person)

# =============================================================================
# User's module.
# =============================================================================
# Testing user's module of Person.

# Generated at 2022-06-23 21:46:35.860088
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    res = person.sexual_orientation()
    assert res in _data['sexuality']

# Generated at 2022-06-23 21:46:42.136155
# Unit test for method political_views of class Person
def test_Person_political_views():
    from faker import Faker
    from .data_loader import DataLoader
    from .constants import DEFAULT_LOCALE

    # Prepare fake
    fake = Faker(DEFAULT_LOCALE, data_loader=DataLoader)
    for _i in range(10):
        # Generate sample
        sample = fake.political_views()
        assert isinstance(sample, str)
        assert len(sample) > 3


# Generated at 2022-06-23 21:46:49.472308
# Unit test for method age of class Person
def test_Person_age():
    for i in range(100):
        assert isinstance(Person().age(), int), \
            'isinstance(Person().age(), int)'

    for i in range(100):
        assert (Person().age() > 0), 'Person().age() > 0'

    assert Person().age(minimum=12, maximum=18) in range(12, 18), \
        'Person().age(minimum=12, maximum=18) in range(12, 18)'

    assert Person(seed=1).age() == 17, 'Person(seed=1).age() == 17'

# Generated at 2022-06-23 21:46:57.171563
# Unit test for method password of class Person
def test_Person_password():
    from faker import Faker #imports the Faker module
    fake = Faker() #creates a fake object
    pswd1 = fake.password() #creates a variable containing a password
    pswd2 = fake.password(length=9) #creates a variable containing a password with length 9
    pswd3 = fake.password(length=20, hashed=True) #creates a variable containing a password with length of 20 and is hashed
    assert len(pswd1) == 8 #asserts whether the length of the password is equal to 8
    assert len(pswd2) == 9 #asserts whether the length of the password is equal to 9
    assert len(pswd3) == 32 #asserts whether the length of the password is equal to 32
    assert isinstance(pswd3, str) == True #asserts whether the

# Generated at 2022-06-23 21:47:07.571604
# Unit test for method full_name of class Person
def test_Person_full_name():
    data = [
        ('парень', 'парень'), ('девушка', 'девушка'), 
        ('парень или девушка', 'парень')
    ]

    for phrase, expected in data:
        phrase_without_space = phrase.replace(' ', '').replace('или', '|')
        assert phrase_without_space.count('|') < 2

        provider = Person(locale='ru')
        gender = provider.gender(phrase_without_space)
        assert gender == expected

        name = provider.full_name(gender)
        assert isinstance(name, str)
        assert len(name) > 0

# Generated at 2022-06-23 21:47:11.327448
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Initialize generator
    person = Person(seed=4)
    # Get full name
    result = person.full_name()
    # Check result - it should be Johann Wolfgang
    assert result == 'Johann Wolfgang'
test_Person_full_name()

# Generated at 2022-06-23 21:47:13.028907
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    assert type(person.sexual_orientation()) == str


# Generated at 2022-06-23 21:47:23.057057
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert p.name(Gender.MALE) in MALE_NAMES
    assert p.name(Gender.FEMALE) in FEMALE_NAMES
    assert p.surname(Gender.MALE) in MALE_SURNAMES
    assert p.surname(Gender.FEMALE) in FEMALE_SURNAMES
    assert p.full_name(Gender.MALE) in [' '.join(x) for x in zip(MALE_NAMES, MALE_SURNAMES)]
    assert p.full_name(Gender.FEMALE) in [' '.join(x) for x in zip(FEMALE_NAMES, FEMALE_SURNAMES)]
    assert p.username()
    assert p.password()
    assert p.email()
    assert p.social_media_profile

# Generated at 2022-06-23 21:47:26.641763
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    profile = Person().social_media_profile(SocialNetwork.GOOGLE)
    assert(profile == 'https://plus.google.com/some_user')
    
test_Person_social_media_profile()

# Generated at 2022-06-23 21:47:30.508331
# Unit test for method password of class Person
def test_Person_password():
    x = Person().password()
    assert len(x) == 8
    assert type(x) is str
    assert x.isalnum() is True

test_Person_password()

 

# Generated at 2022-06-23 21:47:34.028968
# Unit test for method identifier of class Person
def test_Person_identifier():
    'Unit test for method identifier of class Person'
    mask = '##-##/##'
    person = Person()
    for _ in range(10):
        identifier = person.identifier(mask=mask)
        print('identifier =', identifier)
        assert re.fullmatch(r'\d{2}-\d{2}/\d{2}', identifier)
    return True


# Generated at 2022-06-23 21:47:35.199507
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = Person()
    result = provider.last_name()
    assert result == 'Prokhorov'


# Generated at 2022-06-23 21:47:43.675881
# Unit test for method last_name of class Person
def test_Person_last_name():
	p = Person(seed=0)
	assert p.last_name() == 'Шибанов'
	assert p.last_name(Gender.MALE) == 'Герасимов'
	assert p.last_name(Gender.FEMALE) == 'Кишина'
	assert p.last_name() == 'Исаков'
	assert p.last_name(Gender.MALE) == 'Кишин'
	assert p.last_name(Gender.FEMALE) == 'Волкова'
	assert p.last_name() == 'Копанин'
	assert p.last_name(Gender.MALE) == 'Панин'
	assert p

# Generated at 2022-06-23 21:47:48.973988
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person(random)
    assert p.political_views() in [
        "Left-wing politics",
        "Right-wing politics",
        "Not a political",
        "Centrism",
        "Moderate left-wing politics",
        "Moderate right-wing politics",
        "Anarchism",
        "American liberalism",
        "Communism",
        "Republicanism",
        "Conservative liberalism",
        "Social democracy",
        "Liberal democracy",
        "Religious politics",
        "Far-right politics",
        "Far-left politics"
    ]

# Generated at 2022-06-23 21:47:51.365723
# Unit test for method university of class Person
def test_Person_university():
    with pytest.raises(TypeError):
        gen = Person(random=None)


# Generated at 2022-06-23 21:47:58.354080
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    @given(years=st.integers(min_value=0, max_value=100))
    def _test_work_experience(years):
        provider = Person()
        experience = provider.work_experience(years)
        assert experience in ('{} лет'.format(years),
                             '{} год'.format(years),
                             '{} года'.format(years))
    _test_work_experience()



# Generated at 2022-06-23 21:48:00.806036
# Unit test for method weight of class Person
def test_Person_weight():
    person = PersonProvider(random=random.Random())
    value = person.weight()
    assert isinstance(value, int)

# Generated at 2022-06-23 21:48:01.521656
# Unit test for method email of class Person
def test_Person_email():
    pass

# Generated at 2022-06-23 21:48:03.003684
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    assert person.sex() == person.sex()


# Generated at 2022-06-23 21:48:14.210850
# Unit test for method political_views of class Person
def test_Person_political_views():
    political_views = Person.political_views
    for _ in range(50):
        assert political_views() in ['Centrism',
                                     'Liberalism',
                                     'Conservatism',
                                     'Nationalism',
                                     'Constitutionalism',
                                     'Socialism',
                                     'Communism',
                                     'Anarchism',
                                     'Environmentalism',
                                     'Pacifism',
                                     'Protestantism',
                                     'Catholicism',
                                     'Hinduism',
                                     'Islam',
                                     'Judaism',
                                     'Buddhism',
                                     'Atheism',
                                     'Satanism']
    return True


# Generated at 2022-06-23 21:48:21.269785
# Unit test for method title of class Person
def test_Person_title():
    p = Person(seed=123)
    assert p.title(gender=Gender.MAN, title_type=TitleType.PREFIX) == 'Mr.'
    assert p.title(gender=Gender.WOMAN, title_type=TitleType.PREFIX) == 'Mrs.'
    assert p.title(gender=Gender.MAN, title_type=TitleType.SUFFIX) == 'PhD.'
    assert p.title(gender=Gender.WOMAN, title_type=TitleType.SUFFIX) == 'PhD.'
    assert p.title(gender=Gender.MAN) == 'Mr.'
    assert p.title(gender=Gender.WOMAN) == 'Mrs.'
test_Person_title()

# Generated at 2022-06-23 21:48:22.789224
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person(random=Random())
    assert p.occupation() != 'None'



# Generated at 2022-06-23 21:48:24.442997
# Unit test for method identifier of class Person
def test_Person_identifier():
    fake = Faker()
    assert fake.identifier(mask='@-@/@@')
    assert fake.identifier()



# Generated at 2022-06-23 21:48:33.860247
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    v = Person(seed=None)
    assert v.blood_type() in ('A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-')
    assert v.blood_type() in v._data['blood_type']
    v = Person('5')
    assert v.blood_type() in ('A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-')
    assert v.blood_type() in v._data['blood_type']
    

# Generated at 2022-06-23 21:48:38.379065
# Unit test for method weight of class Person
def test_Person_weight():
    for i in [38.0,90.0]:
        assert Person().weight() >= i
    for i in [38,90]:
        assert Person().weight()//1 == i
print(test_Person_weight())


# Generated at 2022-06-23 21:48:49.429536
# Unit test for method height of class Person
def test_Person_height():
    from pyfakefs import fake_filesystem
    from pyfakefs import fake_filesystem_glob
    from pyfakefs import fake_filesystem_open
    from pyfakefs.fake_filesystem_shutil import fake_filesystem_shutil

    fs = fake_filesystem.FakeFilesystem(path_separator='/')
    fs.create_file('/tmp/person.json', contents='{"height": "1.80"}')

    f = fake_filesystem_glob.FakeGlobModule(fs)
    fsh = fake_filesystem_shutil.FakeShutilModule(fs)
    fopen = fake_filesystem_open.FakeOpener(fs)
    os = fake_os_module.FakeOsModule(fs)


# Generated at 2022-06-23 21:48:50.599259
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert isinstance(person, Person)



# Generated at 2022-06-23 21:48:57.264937
# Unit test for method age of class Person
def test_Person_age():
    from . import Origin, Locale
    from .enums import Generation

    #
    # 1. Test basic functionality.
    #
    english = Origin.factory(language=Locale.ENGLISH)
    assert english.age() > 0

    #
    # 2. Test that raising right exceptions.
    #
    with pytest.raises(NonEnumerableError):
        english.age(
            minimum='wrong_value',
            maximum='wrong_value'
        )

    #
    # 3. Test that method return correct value.
    #
    assert english.age(
        minimum=18,
        maximum=18
    ) == 18

    assert english.age(
        generation=Generation.MILLENIALS
    ) in [18, 19]


# Generated at 2022-06-23 21:49:02.441946
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    assert isinstance(p.gender(), str)
    assert isinstance(p.gender(iso5218=True), int)

    assert isinstance(p.gender(symbol=True), str)
    assert len(p.gender(symbol=True)) == 1



# Generated at 2022-06-23 21:49:09.327218
# Unit test for method surname of class Person
def test_Person_surname():
    field = 'name'
    enums = (None, Gender.male, Gender.female)
    for gender in enums:
        generatable = [
            {gender: ['Слава']},
            {Gender.male: ['Андрей'], Gender.female: ['Анна']},
            'Слава',
        ]
        for surnames in generatable:
            provider = Person(surnames=surnames)
            result = getattr(provider, field)
            assert result() in surnames

# Generated at 2022-06-23 21:49:15.182818
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    surname = person.surname(Gender.FEMALE)
    assert surname == "Абрамова"
    surname = person.surname(Gender.MALE)
    assert surname == "Алексеев"
    surname = person.surname()
    assert surname == "Алексеев"


# Generated at 2022-06-23 21:49:17.830127
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person()
    assert type(provider.sexual_orientation()) == str

# Generated at 2022-06-23 21:49:29.618254
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username('U-d') == 'R-87'
    assert Person().username('U.d') == 'N.96'
    assert Person().username('U_d') == 'B_57'
    assert Person().username('UU-d') == 'VV-53'
    assert Person().username('UU.d') == 'TT.90'
    assert Person().username('UU_d') == 'UU_42'
    assert Person().username('ld') == 's66'
    assert Person().username('l-d') == 'j-67'
    assert Person().username('Ud') == 'V86'
    assert Person().username('l.d') == 'h.43'
    assert Person().username('l_d') == 'm_56'
    assert Person().username('default') == 'd.67'
   

# Generated at 2022-06-23 21:49:37.410735
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()
    result = provider.telephone(mask='+7-(###)-###-##-##')
    assert re.match(r'\+7\-(\d){3}\-(\d){3}\-(\d){2}\-(\d){2}', result)
    


# Generated at 2022-06-23 21:49:39.636083
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()
    assert isinstance(worldview, str)
    assert worldview != ''
    
    

# Generated at 2022-06-23 21:49:42.249098
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person()
    assert p.sex() in ['Male', 'Female']


# Generated at 2022-06-23 21:49:43.393254
# Unit test for method surname of class Person
def test_Person_surname():
    got = Person().surname()
    assert(got is not None)

# Generated at 2022-06-23 21:49:46.975420
# Unit test for method email of class Person
def test_Person_email():
    n = (Person().email(domains=('example.com',), unique=True) for _ in range(100))
    assert len(set(n)) == 100


# Generated at 2022-06-23 21:49:48.574609
# Unit test for method age of class Person
def test_Person_age():
    assert Person.age(1950) == age(1950)


# Generated at 2022-06-23 21:49:50.608619
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person(seed=1)
    assert person.blood_type() == 'AB+'

# Generated at 2022-06-23 21:49:52.476145
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person().full_name()


# Generated at 2022-06-23 21:49:55.213385
# Unit test for method identifier of class Person
def test_Person_identifier():
    r = Person().identifier(mask='####/##')
    index = random.randint(0, len(r))
    assert is_number(r[index]) or r[index] == '/' or r[index] == '-'


# Generated at 2022-06-23 21:49:56.753485
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    it = Person()
    assert isinstance(it.sexual_orientation(), str)

# Generated at 2022-06-23 21:50:02.400440
# Unit test for method views_on of class Person
def test_Person_views_on():
    from fakegen import Generator
    from fakegen.types import Gender
    gen = Generator()
    g = gen.person()
    assert g.views_on() in ['Positive', 'Negative', 'Neutral']
    assert g.views_on(Gender.MALE) in ['Positive', 'Negative', 'Neutral']
    assert g.views_on(Gender.FEMALE) in ['Positive', 'Negative', 'Neutral']

# Generated at 2022-06-23 21:50:05.654680
# Unit test for method last_name of class Person
def test_Person_last_name():
    generator = Generator()
    person = Person(generator)

    assert len(person.last_name(gender=Gender.FEMALE)) > 2
    assert len(person.last_name(gender=Gender.MALE)) > 2

# Generated at 2022-06-23 21:50:10.582461
# Unit test for method full_name of class Person
def test_Person_full_name():
    provider = Person(random=Random())
    gender = Gender.MALE
    first_name, last_name = provider.full_name(gender=gender).split(' ')
    assert gender == provider.gender_for_name(first_name)
    assert gender == provider.gender_for_name(last_name)


# Generated at 2022-06-23 21:50:12.957636
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    w = person.weight()
    assert type(w) is int


# Generated at 2022-06-23 21:50:22.383254
# Unit test for constructor of class Person
def test_Person():

    # Check values
    person = Person()

    assert person.seed is None
    assert person.locale is None

    person = Person(seed=None, locale='en')

    assert person.seed is None
    assert person.locale == 'en'

    # Check errors
    with pytest.raises(TypeError):
        Person(seed=1, locale=1)

    with pytest.raises(ValueError):
        Person(seed='', locale='en')

    with pytest.raises(ValueError):
        Person(seed='1', locale='')


# Generated at 2022-06-23 21:50:22.970696
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert 1 == 1

# Generated at 2022-06-23 21:50:26.661637
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    for i in range(512):
        s = person.sexual_orientation()
        assert isinstance(s, str)
        assert s not in ('', None)


# Generated at 2022-06-23 21:50:28.539801
# Unit test for method language of class Person
def test_Person_language():
    person = Person(_random=FakeRandom(1))
    assert person.language() == 'Greek'

# Generated at 2022-06-23 21:50:31.041651
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person(seed=10)
    occupation = person.occupation()
    assert occupation == 'Dramaturgy'


# Generated at 2022-06-23 21:50:37.117652
# Unit test for method title of class Person
def test_Person_title():
    r = Person(seed=1).title(gender=Gender.FEMALE)
    assert r == 'M.B.A.'

    r = Person(seed=2).title(gender=Gender.FEMALE)
    assert r == 'M.D.'

    r = Person(seed=3).title(gender=Gender.FEMALE)
    assert r == 'Ph.D.'

    r = Person(seed=4).title(gender=Gender.FEMALE)
    assert r == 'D.C.'

    r = Person(seed=5).title(gender=Gender.FEMALE)
    assert r == 'R.N.'

    r = Person(seed=6).title(gender=Gender.FEMALE)
    assert r == 'J.D.'


# Generated at 2022-06-23 21:50:37.868367
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person



# Generated at 2022-06-23 21:50:41.174203
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    v_set = set()
    for _ in range(10):
        v = p.views_on()
        v_set.add(v)
    assert v_set == {'Negative', 'Neutral', 'Positive'}

# Generated at 2022-06-23 21:50:44.343672
# Unit test for method height of class Person
def test_Person_height():
    import random
    # Test when all of parameters are None
    result = Person(random).height()
    assert result != ""
    # Test when all of parameters are not None
    result = Person(random).height(1.5, 2.0)
    assert result == "1.50"
test_Person_height()

# Generated at 2022-06-23 21:50:49.572771
# Unit test for method telephone of class Person
def test_Person_telephone():
    for i in range(0, 10):
        num = Person().telephone()
        assert re.match('^([\+]?[0-9][-]?)?[(]?[0-9]{3}[)]?[-]?[0-9]{3}[-]?[0-9]{4}$', num)
    
test_Person_telephone()

# Generated at 2022-06-23 21:50:59.920376
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Генерация данных для заполнения формы входа на сайт
    random_person = Person()
    # Генерация имени пользователя
    username = random_person.full_name()
    # Проверка соответствия сгенерированного имени пользователя заданному регулярном