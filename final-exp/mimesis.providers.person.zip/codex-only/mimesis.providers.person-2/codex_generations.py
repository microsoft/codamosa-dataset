

# Generated at 2022-06-23 21:40:58.948784
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    res = p.views_on()
    assert res in p._data['views_on']
test_Person_views_on()

# Generated at 2022-06-23 21:41:10.424548
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    # Test data from class Gender
    assert person.title(gender=Gender.MALE,
                        title_type=TitleType.PREFIX) in person._data['title'][0][0]
    assert person.title(gender=Gender.MALE,
                        title_type=TitleType.SUFFIX) in person._data['title'][0][1]
    assert person.title(gender=Gender.FEMALE,
                        title_type=TitleType.PREFIX) in person._data['title'][1][0]
    assert person.title(gender=Gender.FEMALE,
                        title_type=TitleType.SUFFIX) in person._data['title'][1][1]
    # Test data from class TitleType

# Generated at 2022-06-23 21:41:12.233824
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    assert person.weight() >= 38 and person.weight() <= 90

# Generated at 2022-06-23 21:41:15.439352
# Unit test for method name of class Person
def test_Person_name():
    class_ = Person()
    for _ in range(100):
        assert isinstance(class_.name(), str)


# Generated at 2022-06-23 21:41:18.296776
# Unit test for method password of class Person
def test_Person_password():
    person = Person()
    result = person.password()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:41:22.784539
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert isinstance(p.data['name'], dict)
    assert isinstance(p.data['surname'], dict)
    assert isinstance(p.data['nationality'], dict)
    assert isinstance(p.data['surname'], dict)


# Generated at 2022-06-23 21:41:24.587753
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    gen = Person()
    assert type(gen.social_media_profile()) == str

if __name__ == '__main__':
    test_Person_social_media_profile()

# Generated at 2022-06-23 21:41:25.297105
# Unit test for method avatar of class Person
def test_Person_avatar():
    assert Person().avatar()

# Generated at 2022-06-23 21:41:28.163854
# Unit test for method worldview of class Person
def test_Person_worldview():
    From = random_from(Person)
    assert isinstance(From.worldview(), str)
    

# Generated at 2022-06-23 21:41:36.825181
# Unit test for method worldview of class Person
def test_Person_worldview():
    worldview=Person().worldview()

# Generated at 2022-06-23 21:41:41.135553
# Unit test for method avatar of class Person
def test_Person_avatar():
    provider = Person()
    avatar = provider.avatar()
    assert re.compile(r'https:\/\/api.adorable.io\/avatars\/\d+\/.+\.png') \
        .match(avatar) is not None


# Generated at 2022-06-23 21:41:50.542930
# Unit test for method password of class Person
def test_Person_password():
    person = Person()
    # correct size
    assert len(person.password(length = 6)) == 6
    # not only digits
    assert any(map(lambda c: c.isalpha(), person.password(length = 16)))
    # not only letters
    assert any(map(lambda c: c.isdigit(), person.password(length = 16)))
    # not only letters and digits
    assert any(map(lambda c: c not in ALPHANUMERIC, person.password(length = 16)))
    # MD5 hash
    assert len(person.password(length = 6, hashed = True)) == 32
    # default length
    assert len(person.password()) == 8
    # default length
    assert len(person.password(length = None)) == 8
    # ``length`` must be integer

# Generated at 2022-06-23 21:41:52.550455
# Unit test for method university of class Person
def test_Person_university():
    Person = Person(random=Random(42))

    assert Person.university() == "St. Petersburg Academic University"


# Generated at 2022-06-23 21:41:58.273664
# Unit test for method email of class Person
def test_Person_email():
    from faker import Faker
    fake = Faker()
    domains = (
        'gmail.com', 'example.com', 'example.co-op', 'example.com-with-dash',
        'example.com.with.dot', 'example.com.com', 'example.com.co.uk'
    )
    email = fake.email(domains=domains, unique=True)
    assert email == 'example.com-with-dash'
    email = fake.email(domains=domains, unique=True)
    assert email == 'example.com.co.uk'

# Generated at 2022-06-23 21:41:59.537649
# Unit test for method age of class Person
def test_Person_age():
    pass



# Generated at 2022-06-23 21:42:03.641762
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality1 = person.nationality()
    assert nationality1 in NATIONALITIES
    nationality2 = person.nationality(gender=Gender.MAN)
    assert nationality2 in NATIONALITIES_MAN
    nationality3 = person.nationality(gender=Gender.WOMAN)
    assert nationality3 in NATIONALITIES_WOMAN
    print(f'\n{nationality1}\n{nationality2}\n{nationality3}\n')


# Generated at 2022-06-23 21:42:11.763855
# Unit test for method email of class Person
def test_Person_email():
    assert Person.email('en_US') is not None

    # Test method with custom domains
    assert Person.email('en_US', domains=('example.com',))

    # Test «unique» parameter
    assert Person.email('en_US', unique=True)

    # Test «unique» parameter with seeded provider
    provider = Generator(seed=0)
    assert provider.person.email(unique=True) == 'mXl7G2ig@gmail.com'
    assert provider.person.email(unique=True) == 'KZvUo9Bb@hotmail.com'



# Generated at 2022-06-23 21:42:17.619111
# Unit test for method email of class Person
def test_Person_email():
    values = [
        # (seed, domains, unique, expected)
        (None, [], False, r'^\w+\.\d\d@(?:\w*\.)+(?:com|ru|net|org)$'),
        (None, ['@example.com'], False, r'^\w+\.\d\d@example\.com$'),
    ]

    for args, expected in values:
        assert bool(re.match(expected, Person().email(*args)))


# Generated at 2022-06-23 21:42:20.399117
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert type(surname) is str
test_Person_surname()

# Generated at 2022-06-23 21:42:23.320437
# Unit test for method password of class Person
def test_Person_password():
    # test length = 16
    for i in range(1, 50):
        password = Person().password(length = 16)
        assert len(password) == 16


# Generated at 2022-06-23 21:42:26.120325
# Unit test for method university of class Person
def test_Person_university():
    # Arrange
    person = Person()

    # Act
    result = person.university()

    # Assert
    assert result is not None

# Generated at 2022-06-23 21:42:32.237776
# Unit test for method name of class Person
def test_Person_name():
    # Arrange
    names = ['Alic', 'Bert', 'Cecil', 'Doris', 'Ethel', 'Fred', 'Gwen',
             'Hans', 'Iris', 'Jack', 'Kurt', 'Lisa', 'Mark', 'Nick', 'Omar']

    person = Person()

    # Act
    result = person.name()

    # Assert
    assert result in names


# Generated at 2022-06-23 21:42:35.663305
# Unit test for method views_on of class Person
def test_Person_views_on():
    rnd = MockRandom(42)
    p = Person(rnd)
    result = p.views_on()
    assert result == 'Neutral', 'Result is "%s"' % result


# Generated at 2022-06-23 21:42:38.239887
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    gen = Person()
    for _ in range(100):
        degree = gen.academic_degree()

        assert degree in ACADEMIC_DEGREES

# Generated at 2022-06-23 21:42:41.991102
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    x = Person()
    n = 10
    y = [x.academic_degree() for _ in range(n)]
    numb = [_ for _ in y if _]
    assert len(numb) == n
    assert len(list(set(y))) != 1


# Generated at 2022-06-23 21:42:43.151485
# Unit test for method full_name of class Person
def test_Person_full_name():
    Person().full_name()
    # Output: 'Johan Christian'

# Generated at 2022-06-23 21:42:44.222485
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person.political_views(Person()) == 'Liberal'

# Generated at 2022-06-23 21:42:51.985947
# Unit test for method avatar of class Person
def test_Person_avatar():
    random = Random(seed=DEBUG_SEED)
    person = Person(random=random)
    assert person.avatar() == 'https://api.adorable.io/avatars/256/87b6fe27d6f36da2d9cfc7b96a87f1a7.png'
    assert person.avatar(size=128) == 'https://api.adorable.io/avatars/128/87b6fe27d6f36da2d9cfc7b96a87f1a7.png'


# Generated at 2022-06-23 21:42:57.633965
# Unit test for constructor of class Person
def test_Person():
    provider = Person()

    # Test constructor with full data
    provider = Person(data='full')

    # Test constructor with reduced data
    provider = Person(data='reduced')

    # Test constructor with custom data
    provider = Person(data='custom')

    # Test __repr__
    assert repr(provider)

    # Test __str__
    assert str(provider)

# Generated at 2022-06-23 21:43:00.494572
# Unit test for method surname of class Person
def test_Person_surname():
    n = Person(seed=12)
    assert n.surname() == 'Сухов'


# Generated at 2022-06-23 21:43:02.073713
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    assert isinstance(person.occupation(), str)


if __name__ == '__main__':
    test_Person_occupation()

# Generated at 2022-06-23 21:43:13.422427
# Unit test for method avatar of class Person
def test_Person_avatar():
    avatar_counts = 1000
    avatar_lengths = []
    avatar_first_chars = set()
    avatar_last_chars = set()
    avatar_last_2_chars = set()
    avatar_last_3_chars = set()
    # avatar_text = []

    for i in range(avatar_counts):
        avatar = Person().avatar()
        avatar_lengths.append(len(avatar))
        avatar_first_chars.add(avatar[0])
        avatar_last_chars.add(avatar[-1])
        avatar_last_2_chars.add(avatar[-2:])
        avatar_last_3_chars.add(avatar[-3:])
        # avatar_text.append(avatar)


# Generated at 2022-06-23 21:43:21.739343
# Unit test for constructor of class Person
def test_Person():
    from faker.random import Random
    from faker.providers.base import BaseProvider

    class TestPerson(Person):
        def __init__(self, seed: uint, data: dict, random: Random):
            super().__init__(seed, data, random)

        def _get_names(self, gender: Gender, key: str) -> list:
            return ['']

        def _get_surnames(self, gender: Gender) -> list:
            return ['']

    seed = 12345
    data = {}
    random = Random()
    person = TestPerson(seed, data, random)

    assert issubclass(TestPerson, BaseProvider)
    assert isinstance(person, TestPerson)

# Unit tests for class Person

# Generated at 2022-06-23 21:43:24.604551
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert person.height(minimum=1.5, maximum=2.0) == '1.85'

# Generated at 2022-06-23 21:43:25.757165
# Unit test for method surname of class Person
def test_Person_surname():
    result = Person().last_name(Gender.MALE)
    assert len(result)

# Generated at 2022-06-23 21:43:28.142360
# Unit test for method first_name of class Person
def test_Person_first_name():
    from faker import Faker
    Faker.seed(0)
    assert Faker().person.first_name() == 'Алла'


# Generated at 2022-06-23 21:43:34.592571
# Unit test for method title of class Person
def test_Person_title():
    person = Person(random=Random())

    title = person.title(gender=Gender.MALE,
                         title_type=TitleType.PREFIX)
    assert title in PREFIXES["MALE"]

    title = person.title(gender=Gender.FEMALE,
                         title_type=TitleType.SUFFIX)
    assert title in SUFFIXES["FEMALE"]

    title = person.title(gender=Gender.MALE,
                         title_type=TitleType.SUFFIX)
    assert title in SUFFIXES["MALE"]

    title = person.title(gender=Gender.FEMALE,
                         title_type=TitleType.PREFIX)
    assert title in PREFIXES["FEMALE"]
    
    title = person.title(gender=Gender.FEMALE)
    assert title in PRE

# Generated at 2022-06-23 21:43:38.396357
# Unit test for method surname of class Person
def test_Person_surname():
    expected = DataTestGenerator(None, None, None)
    actual = Person()
    assert expected.surname() == actual.surname()

# Generated at 2022-06-23 21:43:48.598330
# Unit test for method email of class Person
def test_Person_email():
    assert Person()._data['email'].get('domains'
                                       ) == EMAIL_DOMAINS
    regexp = re.compile(r'^[A-Z0-9._%+-]+'
                        r'@[A-Z0-9.-]+\.[A-Z]{2,}$', re.I | re.U)

    assert regexp.match(
        Person().email()
    )

    assert regexp.match(
        Person().email(('test.com',))
    )

    assert Person().email((
        'test.com', 'example.com',
    )) in (
        'user@example.com', 'user@test.com',
    )

    assert Person().email(('@test.com',)) in (
        'user@test.com',
    )



# Generated at 2022-06-23 21:43:50.777346
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    assert p.last_name(Gender.male)



# Generated at 2022-06-23 21:44:00.432843
# Unit test for method occupation of class Person

# Generated at 2022-06-23 21:44:03.036769
# Unit test for method views_on of class Person
def test_Person_views_on():
    for i in range(100):
        view = Person().views_on()
        assert isinstance(view, str)


# Generated at 2022-06-23 21:44:14.678308
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    title_for_name_male_prefix = person.title(gender=Gender.male,
                                              title_type=TitleType.prefix)
    title_for_name_female_prefix = person.title(gender=Gender.female,
                                                title_type=TitleType.prefix)
    title_for_name_male_suffix = person.title(gender=Gender.male,
                                              title_type=TitleType.suffix)
    title_for_name_female_suffix = person.title(gender=Gender.female,
                                                title_type=TitleType.suffix)

    print(title_for_name_male_prefix)
    print(title_for_name_female_prefix)
    print(title_for_name_male_suffix)

# Generated at 2022-06-23 21:44:17.677430
# Unit test for method avatar of class Person
def test_Person_avatar():
    avatar = get_provider().avatar()
    assert avatar.startswith('https://api.adorable.io/avatars/')
    assert avatar.endswith('.png')



# Generated at 2022-06-23 21:44:22.970321
# Unit test for method last_name of class Person
def test_Person_last_name():
    # I create an instance of the faker factory
    faker = Faker("fr_FR")
    # I create an instance of Person
    person = Person(faker)
    # I test if person is an instance of Person
    assert isinstance(person, Person)
    # I test if last_name is a function
    assert isinstance(person.last_name, FunctionType)
    # I test if last_name return a str
    assert isinstance(person.last_name(), str)


# Generated at 2022-06-23 21:44:24.380910
# Unit test for method views_on of class Person
def test_Person_views_on():
    obj = Person()
    assert obj.views_on() in ('Negative', 'Positive')

# Generated at 2022-06-23 21:44:26.614989
# Unit test for method language of class Person
def test_Person_language():
    # AssertionError
    try:
        p=Person()
        p.language()
    except AssertionError as e:
        print(e)
        assert True
    
    
test_Person_language()


# Generated at 2022-06-23 21:44:27.861424
# Unit test for method title of class Person
def test_Person_title():
    for i in range(100):
        assert _Person().title() in TITLES


# Generated at 2022-06-23 21:44:30.427931
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)

# # Unit test for method full_name of class Person

# Generated at 2022-06-23 21:44:40.948574
# Unit test for method height of class Person
def test_Person_height():
    import pytest
    from pytest import approx
    from string import ascii_letters as al
    from string import digits as dg
    import random

    # Check if generated number is in range
    def is_in_range(number, minimum, maximum):
        assert number >= minimum and number <= maximum

    # Generates random key with the same length as value
    def random_key_generator(dictionary):
        return random.choice(list(dictionary.keys()))

    # Valid test cases

# Generated at 2022-06-23 21:44:43.923744
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person(seed=1)
    ln = p.last_name(gender='male')
    assert ln == 'Морозов'
    
test_Person_last_name()

# Generated at 2022-06-23 21:44:49.540825
# Unit test for method avatar of class Person
def test_Person_avatar():
    pr = Person()

    assert type(pr.avatar()) == str

    assert pr.avatar() == 'https://api.adorable.io/avatars/256/8b067736d0972d43f93949246444617d.png'

    assert pr.avatar(128) == 'https://api.adorable.io/avatars/128/8b067736d0972d43f93949246444617d.png'

# Generated at 2022-06-23 21:44:53.786150
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Setup
    person = Person()

    # Exercise
    result = person.blood_type()

    # Verify
    assert result in BLOOD_GROUPS, "Blood groups must contain a result"



# Generated at 2022-06-23 21:44:57.800954
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    #Check for method sexual_orientation of class Person for correct result
    for i in range(10):
        result = Person().sexual_orientation()
        assert result in SEXUALITY

# Generated at 2022-06-23 21:45:00.866608
# Unit test for method sex of class Person
def test_Person_sex():
    for _ in range(1000):
        generator = Generator()
        assert type(generator.sex()) == str


# Generated at 2022-06-23 21:45:10.385445
# Unit test for method title of class Person
def test_Person_title():

    title_data = {
        Gender.FEMALE: {
            TitleType.PREFIX: ['Miss'],
            TitleType.SUFFIX: ['PhD'],
        },
        Gender.MALE: {
            TitleType.PREFIX: ['Mr'],
            TitleType.SUFFIX: ['PhD'],
        },
        Gender.UNKNOWN: {
            TitleType.PREFIX: ['Unknown'],
            TitleType.SUFFIX: ['Unknown'],
        }
    }

    person = Person(title_data)

    # Female prefix
    assert person.title(gender=Gender.FEMALE, title_type=TitleType.PREFIX) == 'Miss'

    # Female suffix
    assert person.title(gender=Gender.FEMALE, title_type=TitleType.SUFFIX)

# Generated at 2022-06-23 21:45:16.065667
# Unit test for method password of class Person
def test_Person_password():
    provider = Person(random=RandomGenerator())
    password = provider.password()
    assert isinstance(password, str)
    assert len(password) == 8

    password = provider.password(length=10)
    assert isinstance(password, str)
    assert len(password) == 10

    assert isinstance(provider.password(hashed=True), str)

# Generated at 2022-06-23 21:45:21.235079
# Unit test for method telephone of class Person
def test_Person_telephone():
    identifier = "13-17/14"
    person = Person()
    result = person.telephone(identifier)
    assert result == '13-17/14', "Test failed"
    assert len(result) == len(identifier), "Test failed\n"
print('Test Person.telephone - Ok')

test_Person_telephone()
# End unit test


# Generated at 2022-06-23 21:45:23.069825
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person(seed=6)
    assert p.sex() == 'Male'

# Generated at 2022-06-23 21:45:24.427394
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    assert p.weight()

# Generated at 2022-06-23 21:45:29.383435
# Unit test for method height of class Person
def test_Person_height():
    print('Testing method height for class Person ... ', end='')
    p = Person()
    assert re.match('^[0-9]{1,2}\.[0-9]{1,2}$', p.height()) is not None
    print('Done')

if __name__ == '__main__':
    test_Person_height()

# Generated at 2022-06-23 21:45:31.415220
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    print(person.views_on())
    print(person.views_on(symbol=True))

# Generated at 2022-06-23 21:45:41.875727
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"
    assert Person().academic_degree() == "Bachelor"


# Generated at 2022-06-23 21:45:44.160175
# Unit test for method telephone of class Person
def test_Person_telephone():
    for _ in range(100):
        p = Person()
        assert isinstance(p.telephone(), str)


# Generated at 2022-06-23 21:45:49.436142
# Unit test for method sex of class Person
def test_Person_sex():
    # Arrange
    from faker import Factory
    provider = Factory.create('en').provider('faker.providers.person')

    # Act
    result = provider.sex()

    # Assert
    assert result in ('Male', 'Female')

# Generated at 2022-06-23 21:45:51.254078
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    assert person.first_name()


# Generated at 2022-06-23 21:45:55.395955
# Unit test for method university of class Person
def test_Person_university():
    # Arrange
    person = Person(seed=12345)

    # Act
    actual = person.university()

    # Assert
    assert actual == 'Northeastern University'

test_Person_university()



# Generated at 2022-06-23 21:45:57.524426
# Unit test for method avatar of class Person
def test_Person_avatar():
    result = Person().avatar()

    assert result
    assert isinstance(result, str)

    print('avatar', result)

# Generated at 2022-06-23 21:46:03.361039
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    print("\nTesting Person.sexual_orientation()")
    print("===============================")
    l = []

    p = Person()
    for i in range(10):
        l.append(p.sexual_orientation())
        # print("\t{}".format(l[-1]))

    assert len(set(l)) == 10
    # Unit test for method political_views of class Person


# Generated at 2022-06-23 21:46:05.528530
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    work_experience = Person.work_experience()
    assert isinstance(work_experience, str)


# Generated at 2022-06-23 21:46:06.705607
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    university = person.university()
    assert university in PERSON_DATA['university']

# Generated at 2022-06-23 21:46:08.260289
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    academic_degree = Person().academic_degree()

# Generated at 2022-06-23 21:46:10.670718
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person(random=Random())
    for _ in range(100):
        politicalviews = person.political_views()
        assert politicalviews in POLITICAL_VIEWS
        

# Generated at 2022-06-23 21:46:12.997166
# Unit test for method views_on of class Person
def test_Person_views_on():
    # check a function returns str
    assert type(Person(random=Random()).views_on()) == str

# Generated at 2022-06-23 21:46:18.826594
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    domains = ('example.com', 'gmail.com', 'yahoo.com', 'yandex.ru')
    email = person.email(domains)
    assert ('@' in email)
    assert (email.split('@')[1] in domains)

# Generated at 2022-06-23 21:46:28.519435
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    assert re.fullmatch(r'[+]\d{1,3}-\d{10}', p.telephone())
    assert re.fullmatch(r'[+]\d{1,3}-\d{10}', p.telephone(mask='+#-(###)-###-####'))
    assert re.fullmatch(r'[+]\d{1,3}\s\d{3}\s\d{3}\s\d{4}', p.telephone(mask='+# #### ### ####'))

    # Test set custom separator
    assert re.fullmatch(r'[+]\d{1,3}_\d{10}', p.telephone(mask='+#_(###)_###_####'))

    # Test set custom placeholder

# Generated at 2022-06-23 21:46:30.001448
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    person.language()
test_Person_language()

# Generated at 2022-06-23 21:46:32.296697
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person()
    assert p.political_views() in Person._data['political_views']


# Generated at 2022-06-23 21:46:34.874584
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """ Tests method blood_type of class Person"""
    person = Person()
    assert person.blood_type() in BLOOD_GROUPS, "Should be a blood type"


# Generated at 2022-06-23 21:46:40.211024
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    # to make sure that there is no letters in the result
    code = p.identifier(mask='########')
    def has_letters(s):
        return any(x.isalpha() for x in s)
    assert has_letters(code) == False
    # to make sure that there is no digits in the result
    code = p.identifier(mask='@@@@@@@')
    def has_digits(s):
        return any(x.isdigit() for x in s)
    assert has_digits(code) == False

# Generated at 2022-06-23 21:46:42.416220
# Unit test for method first_name of class Person
def test_Person_first_name():
    # length of first name must be more then 0
    assert len(Person.first_name()) > 0


# Generated at 2022-06-23 21:46:46.530197
# Unit test for method email of class Person
def test_Person_email():
    """Generate a random email and check if email contains
    ``default``, ``@`` and ``.``.
    """
    email = Person().email()
    assert 'default' not in email
    assert '@' in email
    assert '.' in email


# Generated at 2022-06-23 21:46:48.396546
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    
    assert Person().academic_degree() in ACADEMIC_DEGREES

# Generated at 2022-06-23 21:46:52.109415
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person().political_views() in POLITICAL_VIEWS
    assert Person().political_views() in ['Communism', 'Anarchism',
                                          'Liberalism', 'Conservatism',
                                          'Socialism', 'Radicalism','Centrism',]



# Generated at 2022-06-23 21:46:59.353153
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person(seed='avatar_test')
    size = 256
    p.avatar(size)
    hash_value = hashlib.md5(('avatar_test' + str(size)).encode()).hexdigest()
    assert p.avatar(size) == f'https://api.adorable.io/avatars/{size}/{hash_value}.png'
test_Person_avatar()



# Generated at 2022-06-23 21:47:09.460304
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person('en')
    assert isinstance(p.first_name(), str)
    assert isinstance(p.first_name(Gender.MALE), str)
    assert isinstance(p.first_name(Gender.FEMALE), str)

    names = {
        Gender.MALE: ('James', 'John', 'Robert', 'George'),
        Gender.FEMALE: ('Mary', 'Linda', 'Patricia', 'Nancy')
    }
    p = Person('en')
    for gender in (Gender.MALE, Gender.FEMALE):
        if gender:
            assert p.first_name(gender) in names[gender]
        else:
            assert p.first_name() in names[gender]

# Generated at 2022-06-23 21:47:11.756833
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = pydenticon.Person()
    social = person.social_media_profile(site=None)
    assert social == 'https://facebook.com/a0'



# Generated at 2022-06-23 21:47:18.188999
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    for i in range(10):
        result = person.work_experience(i)
        assert result == (
            'Current job:',
            'Job from 2013 to 2018',
            'Job in 2013',
            'Job in 2014',
            'Job in 2015',
            'Job in 2016',
            'Job in 2017',
            'Job in 2018',
            'Job in 2019',
            'Job in 2020',
        )[i]

# Generated at 2022-06-23 21:47:23.587123
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    assert re.match(r'[\d]{3}.[\d]{2}', p.height())
    

# Generated at 2022-06-23 21:47:26.807529
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    work_experience = person.work_experience()
    assert isinstance(work_experience, str)
    assert work_experience in person._data["work_experience"]


# Generated at 2022-06-23 21:47:32.235147
# Unit test for method sex of class Person
def test_Person_sex():
    """
    Unit test for method sex of class Person.
    """
    # Create instance of class Person
    p = Person()

    # Test method sex
    sex = p.sex()
    assert sex == p.sex()
    assert sex in [0, 1, 2, 9]

# Generated at 2022-06-23 21:47:35.671744
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person()
    profile_link = provider.social_media_profile()
    assert profile_link

    profile_link = provider.social_media_profile(SocialNetwork.facebook)
    assert profile_link


# Generated at 2022-06-23 21:47:39.440970
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    assert person.sex(symbol=True) in GENDER_SYMBOLS
    assert person.sex() in person._data['gender']
    assert person.sex(iso5218=True) in (0, 1, 2, 9)


# Generated at 2022-06-23 21:47:40.963519
# Unit test for method views_on of class Person
def test_Person_views_on():
    result = Person().views_on()
    assert result not in ('', None)

# Generated at 2022-06-23 21:47:42.943581
# Unit test for method political_views of class Person
def test_Person_political_views():
    # function to test politicial_views()
    for _ in range(10):
        print('political view -', Person().political_views())
        
test_Person_political_views()


# Generated at 2022-06-23 21:47:45.041896
# Unit test for method surname of class Person
def test_Person_surname():
    # Setup
    person = Person()
    # Exercise
    surname = person.surname()
    # Verify
    assert surname in person.surnames

# Generated at 2022-06-23 21:47:48.709547
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    from random import seed
    from .random_provider import SETTINGS
    from .random_provider import RandomProvider

    SETTINGS['seed'] = None
    seed_val = 1
    seed(seed_val)

    for _ in range(1000):
        provider = RandomProvider(seed_val)

        assert provider.blood_type() == 'A+'
    SETTINGS['seed'] = None



# Generated at 2022-06-23 21:47:52.052245
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Tests for method telephone() of class Person."""
    person = Person()
    telephone = person.telephone()

    assert len(telephone) > 5



# Generated at 2022-06-23 21:47:54.600314
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    assert person.work_experience() == '12 лет и 1 месяц'


# Generated at 2022-06-23 21:48:05.301535
# Unit test for method occupation of class Person
def test_Person_occupation():
    from FakeDataGenerator.random_enum import RandomEnum


    persons = []
    for i in range(0, 100):
      person = Person(random=RandomEnum(i))
      persons.append(person.occupation())
    print(sorted(persons))

# Generated at 2022-06-23 21:48:13.159285
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=None)
    assert p.nationality() in ['Russian', 'English', 'German', 'Hindi', 'Spanish', 'Dutch', 'Polish', 'Japanese', 'Chinese', 'Italian', 'Arabic', 'Portuguese', 'French', 'Persian', 'Turkish', 'Vietnamese', 'Ukrainian', 'Thai', 'Indonesian', 'Bengali', 'Taiwanese', 'Korean', 'Hungarian', 'Swedish']


# Generated at 2022-06-23 21:48:14.957967
# Unit test for method worldview of class Person
def test_Person_worldview():
    f = Person().worldview
    g = f()
    assert isinstance(g, str)



# Generated at 2022-06-23 21:48:16.508443
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(10):
        assert len(Person().nationality()) == 12

# Generated at 2022-06-23 21:48:20.455808
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    # GIVEN
    person_mock = Person(random=MockRandom())
    person_mock.academic_degree()
    # WHEN
    person_mock.academic_degree()
    # THEN
    person_mock.random.choice.assert_called_once_with(
        person_mock._data['academic_degree'])

# Generated at 2022-06-23 21:48:22.558960
# Unit test for method occupation of class Person
def test_Person_occupation():
    # This is a test for the method occupation of class Person, it is to be sure
    # that we can generate a job
    assert len(Person().occupation())



# Generated at 2022-06-23 21:48:23.977284
# Unit test for method age of class Person
def test_Person_age():
    person = Person(seed=0)
    assert person.age() == 23


# Generated at 2022-06-23 21:48:26.552914
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person()
    assert provider.social_media_profile()

    for site in SocialNetwork:
        assert provider.social_media_profile(site=site)

    for gender in Gender:
        assert provider.name(gender)
        assert provider.surname(gender)

# Generated at 2022-06-23 21:48:27.399377
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in {'Male', 'Female'}



# Generated at 2022-06-23 21:48:29.315349
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider, Person)



# Generated at 2022-06-23 21:48:34.216874
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person(random=Random())
    res1 = person.work_experience()
    res2 = person.work_experience()

    def check():
        assert is_integer(res1)
        assert is_integer(res2)

        assert res1 is not None
        assert res2 is not None

        assert res1 != res2

    check()


# Generated at 2022-06-23 21:48:36.227394
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person(LOCALE)
    assert isinstance(person.weight(), int)

# Generated at 2022-06-23 21:48:38.620540
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert type(Person().views_on()) is str

# Generated at 2022-06-23 21:48:42.488866
# Unit test for method height of class Person
def test_Person_height():
    for i in range(1000):
        result = Person.height(minimum=1.5, maximum=2.0)
        # ValueError: assert isinstance(val, float)
        assert isinstance(result, float)


# Generated at 2022-06-23 21:48:52.681302
# Unit test for method username of class Person
def test_Person_username():
    import random
    import string
    import regex
    import pytest
    from faker import Faker

    from faker.providers.person import Provider
    from faker.providers.person.en_US import Provider as PersonEnUSProvider

    provider = Provider(Faker())
    en_us_provider = PersonEnUSProvider(Faker())

    def random_string(min_chars=0, max_chars=8) -> str:
        length = random.randint(min_chars, max_chars)
        letters = string.ascii_letters
        return ''.join(random.choice(letters) for i in range(length))


# Generated at 2022-06-23 21:48:59.630107
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person(random=Random())

    for _ in range(100):
        sex_type = person.sex()
        assert sex_type in GENDER_TYPES

    sex_code = person.sex(iso5218=True)
    assert sex_code in [0, 1, 2, 9]

    sex_symbol = person.sex(symbol=True)
    assert sex_symbol in GENDER_SYMBOLS

# Generated at 2022-06-23 21:49:05.757051
# Unit test for method political_views of class Person
def test_Person_political_views():
    
    # Test with seed(0) and with seed(1)
    for i in range(2):
        provider_test = Person()
        
        assert provider_test.political_views() == 'Liberal'
        assert provider_test.political_views() == 'Conservative'
        assert provider_test.political_views() == 'Conservative'
        
        provider_test = Person(seed=i)
        

# Generated at 2022-06-23 21:49:10.312528
# Unit test for method worldview of class Person
def test_Person_worldview():
    rnd_1 = Random.get_instance()
    person_1 = Person(rnd=rnd_1)
    view_1 = person_1.worldview()

    rnd_2 = Random.get_instance()

    person_2 = Person(rnd=rnd_2)
    view_2 = person_2.worldview()

    assert view_1 == view_2

# Generated at 2022-06-23 21:49:14.358578
# Unit test for method username of class Person
def test_Person_username():
    # Create the object
    person = Person()
    # Generate the username
    username = person.username()
    # Check its type
    assert isinstance(username, str), \
        'The username should be a string'
    # Print the username
    print(username)



# Generated at 2022-06-23 21:49:21.964587
# Unit test for method age of class Person
def test_Person_age():
    for _ in range(100):
        min_age = random.randint(1, 100)
        max_age = random.randint(min_age, 100)
        assert Person(min_age, max_age).age() in range(min_age, max_age + 1)



# Generated at 2022-06-23 21:49:30.600942
# Unit test for method age of class Person
def test_Person_age():
    p = Person(seed=12345)
    assert p.age() == 25
    for i in range(10):
        assert 1 <= p.age(minimum=1) <= 120
        assert 1 <= p.age(maximum=120) <= 120
        assert 10 <= p.age(minimum=10) <= 30
        assert 10 <= p.age(maximum=30) <= 30
        assert 10 <= p.age(minimum=10, maximum=30) <= 30
        assert 0 <= p.age(minimum=0) <= 120
        assert 0 <= p.age(maximum=120) <= 120
        assert 0 <= p.age(minimum=0, maximum=120) <= 120

# Generated at 2022-06-23 21:49:37.896757
# Unit test for method gender of class Person
def test_Person_gender():
    rnd_0 = Faker.random.Random()
    rnd_0.seed(0)
    faker = Faker.Faker('en_US', rnd=rnd_0)
    gender = faker.gender(iso5218=False, symbol=False)
    assert gender == 'Male'



# Generated at 2022-06-23 21:49:39.557220
# Unit test for method email of class Person
def test_Person_email():
    person = Person(rnd=Random())
    print(person.email())


# Generated at 2022-06-23 21:49:45.156185
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    '''
    Test docstring of method academic_degree() of class Person.
    '''
    Lorem = Person(random)
    assert Lorem.academic_degree() in [
        'Bachelor', 'Master', 'PhD', 'Honorary PhD', 'Postgraduate', 'PhD',
        'Candidate of Science', 'Doctor of Science', 'Academician']

# Generated at 2022-06-23 21:49:50.381252
# Unit test for method last_name of class Person
def test_Person_last_name():
    n = 0
    while n < 10:
        n += 1
        s = Person().last_name()
        assert s is not None
        assert type(s) == str
        assert s.isalpha() == True
        assert len(s) > 0
print("Test passed.")


# Generated at 2022-06-23 21:49:58.056161
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person()
    result_1 = p.social_media_profile()
    result_2 = p.social_media_profile(SocialNetwork.FACEBOOK)
    assert result_1 != result_2
    result_3 = p.social_media_profile(SocialNetwork.VK)
    result_4 = p.social_media_profile(SocialNetwork.TWITTER)
    assert result_3 != result_4
    result_5 = p.social_media_profile(SocialNetwork.INSTAGRAM)
    result_6 = p.social_media_profile(SocialNetwork.GOOGLE)
    assert result_5 != result_6
    result_7 = p.social_media_profile(SocialNetwork.LINKEDIN)
    result_8 = p.social_media_profile(SocialNetwork.PINTEREST)
    assert result

# Generated at 2022-06-23 21:50:06.407129
# Unit test for method identifier of class Person
def test_Person_identifier():
    from random import seed
    from pydantic import ValidationError

    # Test cases for method identifier of class Person
    for i in range(4):
        # 1st Test case:
        assert Person().identifier(mask='##-##-##') == '49-97-63'

        # 2nd Test case:
        seed(1)
        assert Person().identifier(mask='##-##-##') == '28-91-87'

        # 3rd Test case:
        seed(2)
        assert Person().identifier(mask='##-##-##') == '94-78-29'

        # 4th Test case:
        seed(3)
        assert Person().identifier(mask='##-##-##') == '32-89-62'

        # 5th Test case:
        seed(4)

# Generated at 2022-06-23 21:50:17.262328
# Unit test for method last_name of class Person
def test_Person_last_name():
    # Case 1: get Russian last name with gender
    person = Person()
    result = person.last_name(gender=Gender.MALE)
    assert result in SURNAMES_RU_MALE
    result = person.last_name(gender=Gender.FEMALE)
    assert result in SURNAMES_RU_FEMALE
    # Case 2: get Russian last name without gender
    result = person.last_name()
    assert result in SURNAMES_RU
    # Case 3: get German last name with gender
    person = Person(lang='de')
    result = person.last_name(gender=Gender.MALE)
    assert result in SURNAMES_DE_MALE
    result = person.last_name(gender=Gender.FEMALE)
    assert result in SURNAMES_DE_FEAMALE


# Generated at 2022-06-23 21:50:26.557248
# Unit test for method username of class Person
def test_Person_username():
    provider = Person()

    for _ in range(100):
        assert re.match(r'\w{1,}[\.\-\_]\d{4}', provider.username('l.d')) is not None
        assert re.match(r'\w{1,}[\.\-\_]\d{4}', provider.username('U.d')) is not None
        assert re.match(r'\w{1,}[\.\-\_]\d{4}', provider.username('U_d')) is not None
        assert re.match(r'\w{1,}[\.\-\_]\d{4}', provider.username('default')) is not None

        provider.seed(0)
        assert provider.username() == 'pig.0365'



# Generated at 2022-06-23 21:50:37.522726
# Unit test for method identifier of class Person
def test_Person_identifier():
    provider = Person()
    test_str1 = provider.identifier()
    assert type(test_str1) is str
    test_str2 = provider.identifier('#-#/##')
    assert type(test_str2) is str
    test_str3 = provider.identifier('@-@/@@')
    assert type(test_str3) is str
    test_str4 = provider.identifier('##-##-##')
    assert type(test_str4) is str
    test_str5 = provider.identifier('##/##/##')
    assert type(test_str5) is str
    test_str6 = provider.identifier('####-##-##')
    assert type(test_str6) is str
# Unit tests for method blood_type of class Person

# Generated at 2022-06-23 21:50:44.027060
# Unit test for method password of class Person
def test_Person_password():
    pr = Provider(seed=1)
    assert pr.password() == 'lYyx5I5y'
    assert pr.password(5) == 'g7exZ'
    assert pr.password(8, hashed=True) == '6243649156a4e8be8b3fd3a4c4bdb049'
    assert pr.password(10) == 's+sVHLc152'



# Generated at 2022-06-23 21:50:51.572538
# Unit test for constructor of class Person
def test_Person():
    p = Person()

    assert isinstance(p, Generator)
    assert isinstance(p.random, Generator)
    assert isinstance(p.random, Random)
    assert isinstance(p.random, random.Random)

    p1 = Person()
    p2 = Person(seed=0)
    assert p1.name() == 'Mildred'
    assert p2.name() == 'Mildred'

    p3 = Person()
    p4 = Person(seed=42)
    assert p3.name() == 'Aubrey'
    assert p4.name() == 'Aubrey'


# Generated at 2022-06-23 21:50:52.261166
# Unit test for method worldview of class Person
def test_Person_worldview():
    pass

# Generated at 2022-06-23 21:50:53.295321
# Unit test for constructor of class Person
def test_Person():
    assert Person()


# Generated at 2022-06-23 21:51:00.106753
# Unit test for method email of class Person
def test_Person_email():
    # Test email with default arguments
    assert Person().email() == 'cassem15@gmail.com'
    # Test email with custom domains
    assert Person().email(domains=['example.com', 'example.org']) \
        in ['lindenmayer35@example.com', 'lindenmayer35@example.org']
    # Test email with unique argument
    assert Person(seed=1).email(unique=True) == 'lindenmayer35@t-online.de'
