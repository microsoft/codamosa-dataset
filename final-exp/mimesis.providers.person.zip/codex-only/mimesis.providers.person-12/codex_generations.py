

# Generated at 2022-06-23 21:40:59.452549
# Unit test for method age of class Person
def test_Person_age():
    assert Person.age(self, minimum = 18) <= 18
    assert Person.age(self, maximum = 50) <= 50


# Generated at 2022-06-23 21:41:01.381506
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in VIEWS_ON


# Generated at 2022-06-23 21:41:02.780740
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()

# Generated at 2022-06-23 21:41:14.758752
# Unit test for method username of class Person
def test_Person_username():
    test_values = [
        ('l.d', 'Akeel.1685'),
        ('ld', 'Akeel1685'),
        ('UU.d', 'Jonsee.2057'),
        ('UU-d', 'Ahmand-1291'),
        ('UU_d', 'Mears_1814'),
        ('U_d', 'Cess_1372'),
        ('U-d', 'Sasha-1209'),
        ('Ud', 'Sasha1209'),
        ('l.d', 'Akeel.1685'),
        ('l-d', 'Fadi-7344'),
        ('l_d', 'Mack_2538'),
        ('default', 'l.d'),
    ]

    for template, expected in test_values:
        result = Person(seed=1).username(template=template)

# Generated at 2022-06-23 21:41:17.141917
# Unit test for method name of class Person
def test_Person_name():
    """
    Name is generated.
    """
    person = Person()
    name = person.name(Gender.MALE)

    assert name, 'Name was not generated.'


# Generated at 2022-06-23 21:41:23.845695
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=22)

    assert(person.surname() == 'Попов')
    assert(person.surname(Gender.MALE) == 'Батурин')
    assert(person.surname(Gender.FEMALE) == 'Андрианова')
    assert(person.surname(Gender.ANDROGYNE) == 'Шмакова')


# Generated at 2022-06-23 21:41:26.567082
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert isinstance(person.height(), str)
    assert isinstance(person.height(0.0, 1.6), str)

# Generated at 2022-06-23 21:41:30.945873
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person(seed=76)
    result = person.sexual_orientation(symbol=True)
    assert result == '♑️'

    person = Person(seed=78)
    result = person.sexual_orientation()
    assert result == 'Asexuality'



# Generated at 2022-06-23 21:41:37.347266
# Unit test for method password of class Person
def test_Person_password():

    chars = ascii_letters + digits + punctuation
    assert len(chars) == LATIN_SYMBOLS_AMOUNT + DIGITS_AMOUNT + PUNCTUATION_AMOUNT

    password = Person.password(length = 10)
    assert len(password) == 10
    for ch in password:
        assert ch in chars

    password = Person.password(length = 10, hashed = True)
    assert len(password) == 32

# Generated at 2022-06-23 21:41:48.158886
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(random=Random('foretime10', 10))
    assert p.surname() == 'Маслов'
    assert p.surname(gender='male') == 'Петров'
    assert p.surname(gender='female') == 'Петрова'
    assert p.last_name() == 'Маслов'
    assert p.last_name(gender='male') == 'Петров'
    assert p.last_name(gender='female') == 'Петрова'
    assert p.surname(gender=Gender.male) == 'Петров'
    assert p.surname(gender=Gender.female) == 'Петрова'


# Generated at 2022-06-23 21:41:50.119986
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    # type: () -> None
    assert Person(seed=0).academic_degree() == 'Bachelor'


# Generated at 2022-06-23 21:41:55.622745
# Unit test for method political_views of class Person
def test_Person_political_views():
    from faker.utils.loading import get_full_class_name
    from faker.utils.enum import EnumFactory

    for _ in range(4):
        provider = LocalizedProvider(locale='ru_RU')
        assert get_full_class_name(provider.political_views()) == 'faker.providers.person.ru_RU.PoliticalViews'
        assert isinstance(provider.political_views(), EnumFactory)

# test_Person_political_views()

# Generated at 2022-06-23 21:41:57.547343
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider.random, Generator)

    assert provider.seed is None
    provider = Person(seed=1234)
    assert provider.seed == 1234

# Generated at 2022-06-23 21:42:01.558154
# Unit test for method political_views of class Person
def test_Person_political_views():
    random.seed(11)
    print('Test Person political_views:')
    for _ in range(10):
        print(Person().political_views())
    print('')


# Generated at 2022-06-23 21:42:05.107710
# Unit test for method email of class Person
def test_Person_email():
    pn = Person()
    n = pn.email()
    print(type(n), n)
Person.email(Person())

Person().email()

_provider = Person()
_provider.email()

# Generated at 2022-06-23 21:42:09.266129
# Unit test for method height of class Person
def test_Person_height():
    from pyutils.random.tests.test_provider_generator import Person
    p = Person(seed=0)
    min_, max_ = 1.5, 2.0
    assert p.height(min_, max_) == "1.60"


# Generated at 2022-06-23 21:42:17.144990
# Unit test for method name of class Person
def test_Person_name():
    p = Provider(locale='en')
    name = p.name()
    assert name.endswith(('Boy', 'Girl', 'Man', 'Woman'))
    
    p = Provider(locale='ru')
    name = p.name()
    assert name.endswith(('йцукенгшщзхъфывапролджэячсмитьбю',
                         'ка', 'чка', 'ша', 'баба', 'бабка', 'ица'))


# Generated at 2022-06-23 21:42:19.346333
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    assert person.blood_type() in BLOOD_GROUPS


# Generated at 2022-06-23 21:42:29.915749
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from fakegen.enums import SocialNetwork
    from random import Random
    # Initialize Faker
    faker = Person(Random(42))
    social_net_profiles = [
        "https://vk.com/some_user",
        "https://www.facebook.com/some_user",
        "https://twitter.com/some_user",
        "https://www.pinterest.com/some_user",
        "https://plus.google.com/some_user",
        "https://www.linkedin.com/some_user"
    ]
    # Generating a vk profile
    result = faker.social_media_profile(SocialNetwork.VK)
    assert result == social_net_profiles[0]
    # Generating a facebook profile

# Generated at 2022-06-23 21:42:32.727757
# Unit test for method first_name of class Person
def test_Person_first_name():
    from faker import Faker
    fake = Faker()
    assert not isinstance(fake.first_name(), int)

# Generated at 2022-06-23 21:42:34.924799
# Unit test for method weight of class Person
def test_Person_weight():
    for i in range(100):
        r = Person().weight()
        assert type(r) == int

# Generated at 2022-06-23 21:42:43.836685
# Unit test for method identifier of class Person
def test_Person_identifier():
    # expected_results
    r1_1 = '07-97/04'
    r1_2 = '@7-97/@4'
    r1_3 = '@7-97/04'
    r1_4 = '##-##/##'
    r1_5 = '@@-@@/@@'
    r1_6 = '##-@@/##'

    # Run tests
    assert Person().identifier(mask='##-##/##') == r1_1
    assert Person().identifier(mask='@7-97/@4') == r1_2
    assert Person().identifier(mask='@7-97/04') == r1_3
    assert Person().identifier(mask=r1_4) == r1_1

# Generated at 2022-06-23 21:42:46.940167
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    language = person.language()
    assert isinstance(language, str)
    assert len(language) > 0

# Generated at 2022-06-23 21:42:49.865751
# Unit test for method university of class Person
def test_Person_university():
    """Unit test for method university of class Person."""
    person = Person()
    assert person.university() in _UNIVERSITIES


# Generated at 2022-06-23 21:42:51.522939
# Unit test for method university of class Person
def test_Person_university():
    person = Person('en')
    assert person.university() == 'UMI'



# Generated at 2022-06-23 21:43:02.553752
# Unit test for method sex of class Person
def test_Person_sex():
    from faker import Faker
    from faker.providers.person.en_US import Provider as En
    from faker.providers.person.ru_RU import Provider as Ru
    from faker.providers.person.pl_PL import Provider as Pl
    from faker.utils import text
    import pytest

    locale_list = ['en_US', 'ru_RU', 'pl_PL']

    @pytest.mark.parametrize('locale', locale_list)
    def test_sex(locale):
        f = Faker(locale)
        f.add_provider(En)
        f.add_provider(Ru)
        f.add_provider(Pl)
        sex = f.sex(symbol=True)
        assert text.gender(sex, locale) == sex



# Generated at 2022-06-23 21:43:05.404515
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    number = p.telephone()
    assert bool(re.match(r'^\+\d{1,3}\-\(\d{3}\)\-\d{3}\-\d{4}$', number)) is True


# Generated at 2022-06-23 21:43:06.973579
# Unit test for method name of class Person
def test_Person_name():
    person = Person('en')
    person.name()

# Generated at 2022-06-23 21:43:11.425476
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person(random=Random())
    person.full_name(Gender.FEMALE, False)
    person.full_name(Gender.MALE, False)
    person.full_name(False)
    person.full_name(True)
    person.full_name()

# Generated at 2022-06-23 21:43:13.574193
# Unit test for method political_views of class Person
def test_Person_political_views():
    provider = Person()

    for _ in range(100):
        result = provider.political_views()
        assert result



# Generated at 2022-06-23 21:43:15.337878
# Unit test for method username of class Person
def test_Person_username():
    # Test case 1
    instance = Person()
    result = instance.username()
    assert result is not None


# Generated at 2022-06-23 21:43:17.517496
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    name = person.surname(Gender.FEMALE)
    assert name != ''


# Generated at 2022-06-23 21:43:19.317453
# Unit test for method first_name of class Person
def test_Person_first_name():
    """Test first_name method of class Person."""
    person = Igor()
    assert isinstance(person.first_name(), str)



# Generated at 2022-06-23 21:43:21.762396
# Unit test for method email of class Person
def test_Person_email():
    expected = 'sherlene_sawayn@example.net'
    actual = Person.email()
    assert actual == expected, "Actual is {}".format(actual)


# Generated at 2022-06-23 21:43:25.712883
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider, Person)
    assert isinstance(provider.random, Fake.Provider)
    assert isinstance(provider.random.seed, int)
    assert provider.seed is None


# Generated at 2022-06-23 21:43:34.628959
# Unit test for method title of class Person
def test_Person_title():
    _Person = Person()

    assert _Person.title(Gender.MALE, TitleType.PREFIX) == "Mr."
    assert _Person.title(Gender.MALE, TitleType.SUFFIX) == "Jr."
    assert _Person.title(Gender.FEMALE, TitleType.PREFIX) == "Mrs."
    assert _Person.title(Gender.FEMALE, TitleType.SUFFIX) == "II"

    assert _Person.title(TitleType.PREFIX) == "Ms."
    assert _Person.title(TitleType.SUFFIX) == "Jr."

    with pytest.raises(NonEnumerableError):
        _Person.title(1, TitleType.SUFFIX)

# Generated at 2022-06-23 21:43:39.359188
# Unit test for method username of class Person
def test_Person_username():
    # Arrange
    input_ = None
    expected = 'Ud'

    # Act
    actual = Person().username(template=input_)

    # Assert
    assert len(actual) == len(expected)



# Generated at 2022-06-23 21:43:41.346951
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person.provider().identifier() is not None



# Generated at 2022-06-23 21:43:45.229721
# Unit test for method language of class Person
def test_Person_language():
    def check_language(language):
        assert language in Person._data['language']

    seed(0)
    person = Person(seed=0)
    check_language(person.language())


# Generated at 2022-06-23 21:43:49.218120
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    degrees = [
        'Bachelor',
        'Candidate of Science',
        'Doctor of Science',
        'Post-graduate'
    ]
    for i in degrees:
        assert i in degrees


# Generated at 2022-06-23 21:43:59.405225
# Unit test for method sex of class Person
def test_Person_sex():
    """Test for method sex of class Person.
    test_Person_sex()
    """
    person = Person(seed=1)
    assert person.sex() is None
    assert person.sex(symbol=True) == '♂'
    assert person.sex(iso5218=True) == 0
    assert person.sex(symbol=True) == '♀'
    assert person.sex(iso5218=True) == 2
    assert person.sex(symbol=True) == '⚥'
    assert person.sex(iso5218=True) == 0
    assert person.sex(symbol=True) == '⚢'
    assert person.sex(iso5218=True) == 0
    assert person.sex(symbol=True) == '♀'

# Generated at 2022-06-23 21:44:02.167840
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person."""
    person = Person(seed=1244)
    assert person.seed == 1244
    person = Person()
    assert person.seed is None

# Generated at 2022-06-23 21:44:06.235011
# Unit test for method name of class Person
def test_Person_name():
    rnd = Random()
    rnd.seed(0)
    names = tuple(rnd.choice(PERSON_FIRST_NAMES) for _ in range(100))
    count = collections.Counter(names)
    assert len(names) == 100
    assert count['Jacqueline'] == 8



# Generated at 2022-06-23 21:44:11.455128
# Unit test for method gender of class Person
def test_Person_gender():
    gender_list = ['Male', 'Female', 'Androgynous', 'Transgender', 'Bigender',
    'Genderqueer', 'Genderfluid', 'Hermaphrodite', 'Intersex', 'Non-binary', 'Pangender']

    pn = Person()

    for i in range(100):
        assert pn.gender() in gender_list

# Generated at 2022-06-23 21:44:14.728620
# Unit test for method username of class Person
def test_Person_username():
    faker = Faker()
    g = faker.username(template='default')
    assert isinstance(g, str)
    f = faker.username(template='Ud')
    assert isinstance(f, str)
  # Unit test for method gender of class Person

# Generated at 2022-06-23 21:44:23.338852
# Unit test for method username of class Person
def test_Person_username():
    # Valid parameters, nominally
    provider = Person(seed=1234)
    assert provider.username(template='l_d') == 'a_569'
    assert provider.username(template='U.d') == 'C.80'
    assert provider.username(template='U-d') == 'S-65'
    assert provider.username(template='UU-d') == 'Py-72'
    assert provider.username(template='UU.d') == 'Ba.56'
    assert provider.username(template='UU_d') == 'Py_10'
    assert provider.username(template='ld') == 'f19'
    assert provider.username(template='l-d') == 'r-57'
    assert provider.username(template='Ud') == 'N43'

# Generated at 2022-06-23 21:44:24.989208
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    p = Person()
    assert p.academic_degree() in ('Bachelor', 'Master', 'Candidate of science',
                                   'PhD', 'Doctor')



# Generated at 2022-06-23 21:44:26.590879
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person('en')
    wk_experience = person.work_experience()
    assert type(wk_experience) == int


# Generated at 2022-06-23 21:44:28.408177
# Unit test for method password of class Person
def test_Person_password():
    # Arrange
    p = Person()
    length = 8

    # Act
    password = p.password(length)

    # Assert
    assert len(password) == length


# Generated at 2022-06-23 21:44:30.661709
# Unit test for method last_name of class Person
def test_Person_last_name():
    for i in range(100):
        person = Person(random.Random())
        assert isinstance(person.last_name(),str)


# Generated at 2022-06-23 21:44:33.837020
# Unit test for method password of class Person
def test_Person_password():
    from random import Random
    obj = Random(3)
    # obj = Person()
    for _ in range(100):
        print(obj.password(length=5))



# Generated at 2022-06-23 21:44:37.605912
# Unit test for method sex of class Person
def test_Person_sex():
    assert callable(Person.sex), \
        "Person class method \"sex\" is not callable"
    fake = Person()
    assert isinstance(fake.sex(), str), \
        "Person class method \"sex\" does not return a \"str\""


# Generated at 2022-06-23 21:44:46.403668
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    print('Testing function «test_Person_social_media_profile»...', end='')
    p = Person(seed=42)
    assert p.social_media_profile(site=SocialNetwork.FACEBOOK) == \
        'https://facebook.com/bwN6'
    assert p.social_media_profile(site=SocialNetwork.TWITTER) == \
        'https://twitter.com/mty2'
    assert p.social_media_profile(site=SocialNetwork.GOOGLE) == \
        'https://google.com/bwN6'
    assert p.social_media_profile(site=SocialNetwork.YOUTUBE) == \
        'https://youtube.com/bwN6'

# Generated at 2022-06-23 21:44:48.032312
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person(seed=1)
    assert p.blood_type() == 'O+'
    

# Generated at 2022-06-23 21:44:49.991298
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person("ru")
    person.academic_degree()
    # This code validates method academic_degree of class Person
    #assert False


# Generated at 2022-06-23 21:44:56.671903
# Unit test for method password of class Person
def test_Person_password():
    p = Person()
    p.seed(99)
    assert p.password(8, hashed=False) == '@sCtkMt$Z'
    assert p.password(8, hashed=True) == 'a14a1a1d0ee7c3e4f54a4cf2a0b13dc4'


# Generated at 2022-06-23 21:45:05.914636
# Unit test for method gender of class Person
def test_Person_gender():
    from random import choice
    from pytest import raises

    person = Person()

    _gender = person.gender()
    assert isinstance(_gender, str)
    assert _gender in person._data['gender']

    _gender = person.gender(iso5218=True)
    assert isinstance(_gender, int)
    assert 0 <= _gender <= 9

    _gender = person.gender(symbol=True)
    assert isinstance(_gender, str)
    assert len(_gender) == 1
    assert _gender in GENDER_SYMBOLS

    enums = (Gender.M, Gender.F)
    for _ in range(100):
        _gender = person.gender(choice(enums))
        assert isinstance(_gender, str)
        assert _gender in person._data['gender']


# Generated at 2022-06-23 21:45:13.951534
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    assert person.title(
        gender=Gender.MALE,
        title_type=TitleType.PREFIX
    ) in [
        'Dr', 'Mr', 'Prof', 'Rev', 'Hon', 'Pres', 'Prime Min'
    ]
    assert person.title(
        gender=Gender.MALE,
        title_type=TitleType.SUFFIX
    ) in [
        'I', 'II', 'III', 'Jr', 'Sr', 'Esq', 'PhD'
    ]

# Generated at 2022-06-23 21:45:19.743270
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = PersonProvider()
    result = provider.telephone()
    print(result)
    assert result is not None
    assert re.match(r'\+\d{1,3}\(\d{3}\)\d{3}-\d{2}-\d{2}', result)
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-23 21:45:22.989751
# Unit test for method age of class Person
def test_Person_age():
    # Arrange
    r = rnd.Random()
    r.seed()
    p = Person(r)

    rnd_age = p.age()

    assert rnd_age > 0 and rnd_age < 101  # Assert



# Generated at 2022-06-23 21:45:27.091462
# Unit test for method identifier of class Person
def test_Person_identifier():
    # Arrange
    person = Person()
    mask = '##-##/##'

    # Act
    result = person.identifier(mask)

    # Assert
    assert isinstance(result, str)
    assert len(result) == 9



# Generated at 2022-06-23 21:45:31.059454
# Unit test for method height of class Person
def test_Person_height():
    from random import Random
    
    random = Random()
    random.seed(0)
    person = Person(random)
    
    assert person.height() == '1.67'
    assert person.height(minimum=1, maximum=1.1) == '1.05'
    return

# Generated at 2022-06-23 21:45:36.860599
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        assert isinstance(Person().nationality(), str)
        assert isinstance(Person().nationality(Gender.FEMALE), str)
        assert isinstance(Person().nationality(Gender.MALE), str)
        assert isinstance(Person().nationality(Gender.OTHER), str)


# Generated at 2022-06-23 21:45:41.718992
# Unit test for method age of class Person
def test_Person_age():
    person = Person(random=Random())
    assert isinstance(person.age(), datetime.date)
    person = Person(random=Random(), year=None, month=None, day=None)
    assert isinstance(person.age(), datetime.date)



# Generated at 2022-06-23 21:45:45.407911
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    height = person.height()
    assert isinstance(height, str), "The height attribute is not a string"
    
    height = float(height) # Convert to integer
    assert isinstance(height, float), "The height attribute is not a float"

# Generated at 2022-06-23 21:45:47.092174
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    return person.occupation()


# Generated at 2022-06-23 21:45:48.813958
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    import pytest
    from pydantic.error_wrappers import ValidationError

    with pytest.raises(ValidationError):
        Person._validate_enum(None, Gender)

# Generated at 2022-06-23 21:45:59.933460
# Unit test for method age of class Person
def test_Person_age():
    person = Person(seed=0)
    # assert person.age(15, 21) == 20
    # assert person.age(40, 45) == 45
    assert person.age(18, 30) == 29
    assert person.age(21, 25) == 24
    assert person.age(15, 21) == 20
    assert person.age(40, 45) == 45
    assert person.age(17, 23) == 20
    assert person.age(15, 21) == 20
    assert person.age(15, 21) == 20
    assert person.age(17, 23) == 19
    assert person.age(15, 21) == 18
    assert person.age(15, 21) == 20
    assert person.age(15, 21) == 18
    assert person.age(15, 21) == 17
    assert person.age

# Generated at 2022-06-23 21:46:01.551473
# Unit test for method occupation of class Person
def test_Person_occupation():
    for x in range(10):
        print(Person().occupation())


# Generated at 2022-06-23 21:46:04.502706
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Check the method
    assert Person().telephone("+7-(###)-###-##-##") == "+7-(631)-140-85-33"


# Generated at 2022-06-23 21:46:05.891922
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert isinstance(Person.views_on(), str)

# Generated at 2022-06-23 21:46:07.609499
# Unit test for method university of class Person
def test_Person_university():
    assert Person().university() != Person().university()

test_Person_university()


# Generated at 2022-06-23 21:46:09.809781
# Unit test for method title of class Person
def test_Person_title():
    assert isinstance(Person().title(), str)
    assert isinstance(Person().title(Gender.FEMALE), str)

# Generated at 2022-06-23 21:46:16.230897
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Test method telephone of class Person."""
    person = Person()
    assert person.telephone() == '+92-(457)-813-6565'
    assert person.telephone(placeholder='X') == '+47-XXX-XXX-XXXX'
    assert person.telephone(mask='(###) #######') == '(837) 5668486'

# Generated at 2022-06-23 21:46:17.257709
# Unit test for method university of class Person
def test_Person_university():
    assert Person().university() != None
    assert Person().university() != []

# Generated at 2022-06-23 21:46:20.248234
# Unit test for method name of class Person
def test_Person_name():
    provider = get_provider(Locales.RU)
    name = provider.name()
    assert len(name) > 1
    assert name.isalpha()


# Generated at 2022-06-23 21:46:24.258484
# Unit test for method full_name of class Person
def test_Person_full_name():
    from faker import Faker
    fake = Faker()
    fake.seed(0)
    assert fake.person.full_name() == 'Isabel Scholten'

if __name__ == '__main__':
    test_Person_full_name()

# Generated at 2022-06-23 21:46:26.811757
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person('en')
    assert isinstance(person.weight(), int)
Person().weight()

# Generated at 2022-06-23 21:46:29.191777
# Unit test for method sex of class Person
def test_Person_sex():
    per = Person()
    sex = per.sex()
    assert isinstance(sex, str)
    assert sex in ['Male', 'Female']
sex = Person()
sex.sex()


# Generated at 2022-06-23 21:46:38.852524
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()

    phone = person.telephone()
    assert re.fullmatch(r'\+[\d]{1,3}\([\d]{3}\)-[\d]{3}-[\d]{2}-[\d]{2}', phone)

    phone = person.telephone(mask='+7-(###)-###-##-##')
    assert re.fullmatch(r'\+7\([\d]{3}\)-[\d]{3}-[\d]{2}-[\d]{2}', phone)

    phone = person.telephone(mask='+7-(###)-###-##-##', placeholder='*')

# Generated at 2022-06-23 21:46:40.844762
# Unit test for method university of class Person
def test_Person_university():
    with pytest.raises(AttributeError):
        Person(seed=1)

# Generated at 2022-06-23 21:46:45.619754
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    for i in range(10000):
        result = PersonalDataProvider.social_media_profile()
        assert result
        assert isinstance(result, str)
        assert len(result) >= 14
        assert is_web_url(result)
        assert result.startswith('http')

# Generated at 2022-06-23 21:46:49.520061
# Unit test for method password of class Person
def test_Person_password():
    provider = providers.Person()
    uid = get_unique_id()
    provider.seed(uid)
    password = provider.password(length = 10, hashed = True)
    assert password == '52e8ee7c4d0d4'


# Generated at 2022-06-23 21:46:57.196363
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()

# Generated at 2022-06-23 21:47:03.461612
# Unit test for method gender of class Person
def test_Person_gender():
    # Test 1. gender default parameters
    assert(isinstance(Person().gender(), str))
    
    # Test 2. gender parameter iso5218 = False
    assert(isinstance(Person().gender(iso5218=False), str))
    
    # Test 3. gender parameter iso5218 = True
    assert(isinstance(Person().gender(iso5218=True), int))
    
    # Test 4. gender parameter symbol = False
    assert(isinstance(Person().gender(symbol=False), str))
    
    # Test 5. gender parameter symbol = True
    assert(isinstance(Person().gender(symbol=True), str))
    
    # Test 6. gender parameters iso5218 & symbol
    assert(isinstance(Person().gender(iso5218=True, symbol=False), int))

# Generated at 2022-06-23 21:47:04.915083
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert isinstance(Person().last_name(), str)



# Generated at 2022-06-23 21:47:07.431502
# Unit test for method political_views of class Person
def test_Person_political_views():
    for i in range(100):
        person = Person()
        result = person.political_views()
        assert isinstance(result, str)


# Generated at 2022-06-23 21:47:11.665949
# Unit test for method views_on of class Person
def test_Person_views_on():
    """
    Test Person.views_on() method.

    method Person.views_on must return object from list

    list of objects:
        'Negative',
        'Neutral',
        'Positive'
    """
    person = Person()

    assert person.views_on() in ['Negative', 'Neutral', 'Positive']

# Generated at 2022-06-23 21:47:13.464538
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Test if views_on returns string
    r = Person()
    assert isinstance(r.views_on(), str)


# Generated at 2022-06-23 21:47:16.595997
# Unit test for method telephone of class Person
def test_Person_telephone():
    seed(123)
    p = Person(random=Random())
    result = p.telephone(mask='+#-#-#-##-##', placeholder='#')
    assert result == '+9-9-6-34-09', 'Unittest for method telephone of class Person has failed'

# Generated at 2022-06-23 21:47:25.894336
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    assert person.social_media_profile(site=SocialNetwork.FACEBOOK) is not None
    assert person.social_media_profile(site=SocialNetwork.TWITTER) is not None
    assert person.social_media_profile(site=SocialNetwork.INSTAGRAM) is not None
    assert person.social_media_profile(site=SocialNetwork.VK) is not None
    assert person.social_media_profile(site=SocialNetwork.OK) is not None
    assert person.social_media_profile(site=SocialNetwork.GOOGLE) is not None
    assert person.social_media_profile(site=SocialNetwork.GITHUB) is not None
    assert person.social_media_profile(site=SocialNetwork.STEAM) is not None

# Generated at 2022-06-23 21:47:29.199418
# Unit test for method age of class Person
def test_Person_age():
    age = Person().age()
    assert age >= 15
    assert age <= 90


# Generated at 2022-06-23 21:47:33.391914
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    minimum = 1.5
    maximum = 2.0
    test = person.height(minimum, maximum)

    if type(test) != str:
        raise Exception('Bad result: {}'.format(test))

    if test.count('.') != 1:
        raise Exception('Bad result: {}'.format(test))

    test = float(test)
    if test < minimum or test > maximum:
        raise Exception('Bad result: {}'.format(test))

# Generated at 2022-06-23 21:47:39.059548
# Unit test for method sex of class Person
def test_Person_sex():
    from pydbgen import pydbgen
    from pydbgen import Gender
    from pydbgen import SocialNetwork
    from pydbgen import TitleType
    from pydbgen import NonEnumerableError
    from pydbgen import Country
    from pydbgen import Religion
    from pydbgen import Currency
    from pydbgen import Continent
    from pydbgen import City
    from pydbgen import Language

    db = pydbgen.pydb()
    print(db)
    print(db.name(gender=Gender.MALE))
    print(db.name(gender=Gender.FEMALE))
    print(db.name(gender=None))
    print(db.surname(gender=Gender.MALE))

# Generated at 2022-06-23 21:47:39.969114
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    assert isinstance(person.name(), str)


# Generated at 2022-06-23 21:47:41.849494
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    email = p.email()
    assert '@' in email
    assert not email.endswith('@')

# Generated at 2022-06-23 21:47:42.887593
# Unit test for method sex of class Person
def test_Person_sex():
    assert type(Person().sex())  == str


# Generated at 2022-06-23 21:47:44.574477
# Unit test for method worldview of class Person
def test_Person_worldview():
    # create one object
    person = Person()
    # call method worldview of object person
    worldview = person.worldview()
    # check result
    assert worldview in worldviews

# Generated at 2022-06-23 21:47:46.783851
# Unit test for method height of class Person
def test_Person_height():
    with pytest.raises(TypeError):
        Person().height(1.5, 2.0)
    assert Person().height(1.5, 2.0) == '1.92'

# Generated at 2022-06-23 21:47:49.311130
# Unit test for method university of class Person
def test_Person_university():
    """
    Test that random university is not empty
    """
    p = Person()
    assert p.university()

# Generated at 2022-06-23 21:47:51.993483
# Unit test for method views_on of class Person
def test_Person_views_on():
    view = Person.views_on()
    assert view in ['Positive', 'Negative', 'Neutral', "Don't know"]

# Generated at 2022-06-23 21:47:54.099075
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    avatar = person.avatar()
    assert avatar



# Generated at 2022-06-23 21:47:58.353435
# Unit test for method university of class Person
def test_Person_university():
    person = Person({'university': ['РГПУ', 'РГПУ']})
    if person.university() == 'РГПУ':
        print('pass')
    else:
        print('fail')

# Generated at 2022-06-23 21:47:59.906407
# Unit test for method university of class Person
def test_Person_university():
    for _ in range(100):
        university = Person().university()
        assert university in UNIVERSITIES


# Generated at 2022-06-23 21:48:10.775505
# Unit test for method title of class Person
def test_Person_title():
    provider = Person()
    assert provider.title()
    assert provider.title(gender=Gender.MALE)
    assert provider.title(gender=Gender.FEMALE)
    assert provider.title(title_type=TitleType.PREFIX)
    assert provider.title(title_type=TitleType.SUFFIX)

    assert provider.title(gender=Gender.MALE, title_type=TitleType.PREFIX)
    assert provider.title(gender=Gender.MALE, title_type=TitleType.SUFFIX)
    assert provider.title(gender=Gender.FEMALE, title_type=TitleType.PREFIX)
    assert provider.title(gender=Gender.FEMALE, title_type=TitleType.SUFFIX)

# Generated at 2022-06-23 21:48:15.165367
# Unit test for method password of class Person
def test_Person_password():
    provider = Person()

    assert provider.password() != provider.password()

    provider.reset_seed()

    assert provider.password(hashed=True) == provider.password(hashed=True)

    assert provider.password(hashed=True) == '1ccc7c3874a5c8b5f6cc5c6a5a6c0e8e'

# Generated at 2022-06-23 21:48:19.282951
# Unit test for method political_views of class Person
def test_Person_political_views():
  from pathlib import Path
  from datetime import datetime
  from faker.providers import BaseProvider

  class MyProvider(BaseProvider):
      def foo(self):
          return 'bar'

  f = Factory.create(providers=[MyProvider])
  assert f.political_views() in ("Communism","Capitalism","Socialism","Nationalism")




# Generated at 2022-06-23 21:48:20.885021
# Unit test for method name of class Person
def test_Person_name():
    print("Testing Person.name")
    for i in range(1000):
        assert len(Person().name()) > 0


# Generated at 2022-06-23 21:48:22.072166
# Unit test for method email of class Person
def test_Person_email():
    pp = Person()
    assert '@' in pp.email()


# Generated at 2022-06-23 21:48:24.025480
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality()
    assert Person().nationality(Gender.MALE)
    assert Person().nationality(Gender.FEMALE)


# Generated at 2022-06-23 21:48:25.577034
# Unit test for method height of class Person
def test_Person_height():
  p = Person()
  h = p.height(1.5,2.0)
  assert h == '1.74'


# Generated at 2022-06-23 21:48:27.994890
# Unit test for method language of class Person
def test_Person_language():
    pass



# Generated at 2022-06-23 21:48:29.984600
# Unit test for method sex of class Person
def test_Person_sex():
    # Arrange
    seed = 12345
    person = Person(seed=seed)

    # Act
    result = person.sex()

    # Assert
    assert result == 'Female'

# Generated at 2022-06-23 21:48:31.253646
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()
    assert worldview in worldviews




# Generated at 2022-06-23 21:48:41.222968
# Unit test for method avatar of class Person
def test_Person_avatar():
    """
    :return: ``None``
    """
    male = Person(seed=0)
    assert (male.avatar() ==
            'https://api.adorable.io/avatars/256/a3f9d896c6dffa19a28c6d26e6b99c6f.png')
    assert male.avatar(size=128) == 'https://api.adorable.io/avatars/128/a3f9d896c6dffa19a28c6d26e6b99c6f.png'

    female = Person(seed=1)
    assert (female.avatar() ==
            'https://api.adorable.io/avatars/256/7ceb085ab1c7d5104c8f44aeb5b09bc5.png')
   

# Generated at 2022-06-23 21:48:43.477702
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    p = Person('en')
    assert p.academic_degree() == "Bachelor"


# Generated at 2022-06-23 21:48:45.858393
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    provider = Person()

    for _ in range(10):
        assert len(provider.academic_degree()) > 0



# Generated at 2022-06-23 21:48:52.410674
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    worldview_list = ['Pantheism', 'Monotheistic religion (Abrahamic)', 'Monotheistic religion (Abrahamic)',
    'Monotheistic religion (Abrahamic)', 'Monotheistic religion (Abrahamic)', 'Monotheistic religion (Abrahamic)',
    'Neopaganism', 'Neopaganism', 'Neopaganism', 'Neopaganism'] 
    assert p.worldview() in worldview_list
    
    

# Generated at 2022-06-23 21:48:54.428970
# Unit test for method university of class Person
def test_Person_university():
    uni = Person().university()
    assert isinstance(uni, str)



# Generated at 2022-06-23 21:48:56.452338
# Unit test for method political_views of class Person
def test_Person_political_views():
    """Test for political_views method"""
    person = Person()
    assert person.political_views()



# Generated at 2022-06-23 21:49:03.629595
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    assert 'A+' in BLOOD_GROUPS
    assert 'A-' in BLOOD_GROUPS
    assert 'AB+' in BLOOD_GROUPS
    assert 'AB-' in BLOOD_GROUPS
    assert 'O+' in BLOOD_GROUPS
    assert 'O-' in BLOOD_GROUPS
    assert person.blood_type() in BLOOD_GROUPS

# Generated at 2022-06-23 21:49:05.207350
# Unit test for method gender of class Person
def test_Person_gender():
    yandex = Person(gender=Gender.MALE)


# Generated at 2022-06-23 21:49:13.864342
# Unit test for method first_name of class Person
def test_Person_first_name():
    for _ in range(10):
        assert type(Person.first_name()) == str
        assert type(Person.first_name(gender=Gender.MALE)) == str
        assert type(Person.first_name(gender=Gender.FEMALE)) == str

        assert type(Person.first_name(seed=1234)) == str
        assert type(Person.first_name(gender=Gender.MALE, seed=1234)) == str
        assert type(Person.first_name(gender=Gender.FEMALE, seed=1234)) == str

# Generated at 2022-06-23 21:49:17.260906
# Unit test for method name of class Person
def test_Person_name():
    random_name = Person().name()
    assert isinstance(random_name, str)
    assert 0 < len(random_name) < 50

# Generated at 2022-06-23 21:49:18.731471
# Unit test for method password of class Person

# Generated at 2022-06-23 21:49:26.967004
# Unit test for method full_name of class Person
def test_Person_full_name():
    pr = Person(seed=42)
    # first example
    assert pr.full_name(False) == 'Савва Пономаренко'
    # second example
    assert pr.full_name(False) == 'Алина Загребельный'
    # third example
    assert pr.full_name(False) == 'Савва Овсяников'


# Generated at 2022-06-23 21:49:28.072386
# Unit test for constructor of class Person
def test_Person():
    with pytest.raises(TypeError):
        Person(seed=1, locale='ru')


# Generated at 2022-06-23 21:49:30.147438
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    assert isinstance(person.weight(38, 90), int)

# Generated at 2022-06-23 21:49:35.620411
# Unit test for method worldview of class Person
def test_Person_worldview():
    provider = Person()
    worldview = provider.worldview()
    assert worldview in ('atheism', 'pantheism', 'agnostic', 'christianity', 'islam', 'hinduism', 'judaism')

# Generated at 2022-06-23 21:49:37.540102
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    for _ in range(100):
        university = person.university()
        assert university in UNIVERSITIES


# Generated at 2022-06-23 21:49:39.478951
# Unit test for method views_on of class Person
def test_Person_views_on():
    views_on = Person().views_on()
    assert views_on in VIEWS_ON
    assert isinstance(views_on, str)

# Generated at 2022-06-23 21:49:41.552821
# Unit test for method views_on of class Person
def test_Person_views_on():
    job = Person()
    answer = job.views_on()
    assert(answer)



# Generated at 2022-06-23 21:49:43.393857
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name(Gender.FEMALE) in NAMES.get('last_name', {}).get(Gender.FEMALE, [])
    

# Generated at 2022-06-23 21:49:46.635517
# Unit test for method email of class Person
def test_Person_email():
    test_email = Person.email()
    assert re.match(r'\w{8,}@\w{2,}\.\w{3,}', test_email), \
        'Generated email is not in the expected format!'
    print('Generated email:', test_email)



# Generated at 2022-06-23 21:49:52.348196
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    assert(p.avatar(100) == 'https://api.adorable.io/avatars/100/d38a12bc265e6fb11353ae2e1b0baa95.png')
    assert(p.avatar(500) == 'https://api.adorable.io/avatars/500/d38a12bc265e6fb11353ae2e1b0baa95.png')


# Generated at 2022-06-23 21:49:59.106902
# Unit test for method full_name of class Person
def test_Person_full_name():
    full_name_list = []
    for i in range(5):
        gen = Person()
        full_name_list.append(gen.full_name())
    print(full_name_list)

test_Person_full_name()

full_name_list = []
for i in range(5):
    gen = Person()
    full_name_list.append(gen.full_name())
print(full_name_list)


# Generated at 2022-06-23 21:50:02.999813
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert (Person().work_experience() >= 0)
    assert (Person().work_experience() <= 30)


# Generated at 2022-06-23 21:50:07.603700
# Unit test for method name of class Person
def test_Person_name():
    from faker import Faker
    from pprint import pprint
    faker = Faker(['ru_RU'])
    result = faker.name()
    expected = True
    assert type(result) == str, "Result is not str %r" % result
    assert len(result) > 0, "Result is empty str %r" % result
    print(result)
    print(type(result))
    print(len(result))

# Generated at 2022-06-23 21:50:10.028351
# Unit test for method blood_type of class Person
def test_Person_blood_type():

    # Arrange
    # Act
    result = get_random_item(Person)

    # Assert
    assert_that(result.blood_type(), is_in(BLOOD_GROUPS))

# Generated at 2022-06-23 21:50:14.105069
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    avatar = person.avatar(size=100)
    assert avatar
    assert avatar.startswith('https://api.adorable.io/avatars/100/')
    assert avatar.endswith('.png')

# Generated at 2022-06-23 21:50:16.039400
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    assert person.views_on() in PERSON

# Generated at 2022-06-23 21:50:21.988545
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    for _ in range(50):
        result = p.email()
        assert type(result) is str
        assert len(result) > 1
        assert len(result.split('@')) == 2
        assert result.split('@')[1] in EMAIL_DOMAINS


# Generated at 2022-06-23 21:50:23.184192
# Unit test for method occupation of class Person
def test_Person_occupation():
    obj = Person()
    obj.occupation()
    

# Generated at 2022-06-23 21:50:26.862360
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person(seed=10)
    assert p.last_name(gender='male')=='Kelly'
    assert p.last_name(gender='female')=='Harris'

# Generated at 2022-06-23 21:50:36.192274
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    import pytest

    person = Person()

    # The number of arguments is correct
    with pytest.raises(TypeError):
        person.sexual_orientation(
            symbol=True,
            something=True)

    # All arguments are correct
    value = person.sexual_orientation(symbol=True)

    assert value in SEXUALITY_SYMBOLS

    # The type of the argument is wrong
    with pytest.raises(NonEnumerableError):
        person.sexual_orientation(symbol='symbol')

    # Argument is not passed
    value = person.sexual_orientation()
    assert value in person._data['sexuality']

# Generated at 2022-06-23 21:50:39.837868
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test method nationality of class Person."""
    p = Person()

    # About 20 attempts
    for i in range(20):
        nat = p.nationality()
        assert nat in p._data['nationality'], \
            "nationality {} not found in source data.".format(nat)


# Generated at 2022-06-23 21:50:42.119077
# Unit test for method university of class Person
def test_Person_university():
    p = Person()
    assert p.university() in UNIVERSITIES


# Generated at 2022-06-23 21:50:43.619761
# Unit test for constructor of class Person
def test_Person():
    p = Person()

    assert p is not None


# Generated at 2022-06-23 21:50:44.770114
# Unit test for method university of class Person
def test_Person_university():
    assert Person().university() == "MIT"
    

# Generated at 2022-06-23 21:50:46.634938
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(0,10):
        assert '@' in Person().email()

# Generated at 2022-06-23 21:50:50.255589
# Unit test for method political_views of class Person
def test_Person_political_views():
    political_views = Person().political_views()
    # Check the data type of method political_views()
    assert isinstance(political_views, str)
    # Check the length of method political_views()
    assert len(political_views) > 1

# Generated at 2022-06-23 21:50:53.294941
# Unit test for method email of class Person
def test_Person_email():
    '''
    Test that random email is valid
    '''
    lorem = Person()
    assert lorem.email()
    assert lorem.email()
    assert lorem.email()

# Generated at 2022-06-23 21:50:55.341837
# Unit test for method worldview of class Person
def test_Person_worldview():
    assert len(Person().worldview()) > 0

# Generated at 2022-06-23 21:51:02.566409
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person()
    assert re.match('https://www.facebook.com/\w+',
                    p.social_media_profile())
    assert re.match('https://www.facebook.com/\w+',
                    p.social_media_profile(
                        site=SocialNetwork.FACEBOOK))
    assert re.match('https://www.twitter.com/\w+',
                    p.social_media_profile(
                        site=SocialNetwork.TWITTER))
    assert re.match('https://www.reddit.com/user/\w+',
                    p.social_media_profile(
                        site=SocialNetwork.REDDIT))

