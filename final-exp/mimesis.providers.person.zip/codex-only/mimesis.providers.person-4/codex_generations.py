

# Generated at 2022-06-23 21:41:01.110727
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    # height must be unique
    assert(person.height() != person.height())

# Generated at 2022-06-23 21:41:04.597654
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person(random=Random())

    result = person.identifier()
    assert re.fullmatch(r'\d+-\d+/\d+', result), \
        'Pattern not found'


# Generated at 2022-06-23 21:41:16.374351
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    items = [Person().blood_type() for i in range(0,1000)]

# Generated at 2022-06-23 21:41:20.748224
# Unit test for method political_views of class Person
def test_Person_political_views():
    """Unit test for method political_views of class Person"""
    # Create an object
    person = faker.Person()
    # Try to get a random political views
    res = person.political_views()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:41:25.109846
# Unit test for method nationality of class Person
def test_Person_nationality():
    from . import Person
    p = Person()
    p.nationality()
p = Person()
print(p.nationality())

import random

print(random.choice(['aaa', 'bbb', 'ccc', 'ddd', 'eee']))


# Generated at 2022-06-23 21:41:27.550391
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p=Person()
    print(p.blood_type())

# Generated at 2022-06-23 21:41:32.369728
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person(seed=123)
    assert person.views_on() == 'Positive'

    lst = []
    for _ in range(250):
        lst.append(person.views_on())

    assert len(lst) == 250
    assert isinstance(lst, list)
    assert len(set(lst)) > 1



# Generated at 2022-06-23 21:41:34.257107
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person('en')
    assert person.academic_degree() in person._data.get('academic_degree')


# Generated at 2022-06-23 21:41:41.898019
# Unit test for method gender of class Person
def test_Person_gender():
    random = Random()
    person = Person(random)
    for _ in range(10):
        gender = person.gender()
        gender_symbol = person.gender(symbol=True)
        gender_iso5218 = person.gender(iso5218=True)
        assert gender in ('Male', 'Female', 'Other')
        assert gender_symbol in ('♀', '♂', '♾', '⚲')
        assert gender_iso5218 in (0, 1, 2, 9)

# Generated at 2022-06-23 21:41:47.204288
# Unit test for method gender of class Person
def test_Person_gender():
    seed(100)
    p = Person()
    gender = p.gender()
    assert isinstance(gender, str)
    assert len(gender) > 0
    assert isinstance(p.gender(iso5218=True), int)
    assert isinstance(p.gender(symbol=True), str)
    assert isinstance(p.sex(), str)


# Generated at 2022-06-23 21:41:50.248345
# Unit test for method identifier of class Person
def test_Person_identifier():
    testObject = Person()
    value = testObject.identifier(mask = '##-##/##')
    assert type(value) == type('str')



# Generated at 2022-06-23 21:41:57.707922
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    person.name()
    person.name(Gender.FEMALE)
    person.first_name()
    person.first_name(Gender.FEMALE)
    person.last_name()
    person.last_name(Gender.FEMALE)
    person.full_name()
    person.full_name(Gender.FEMALE)
    person.username()
    person.password()
    person.password(hashed=True)
    person.email()
    person.social_media_profile()
    person.social_media_profile(SocialNetwork.TWITTER)
    person.gender()
    person.blood_type()
    person.sexual_orientation()
    person.political_views()
    person.nationality()
    person.nationality(Gender.FEMALE)
    person

# Generated at 2022-06-23 21:41:58.995819
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person(seed=42)
    assert person.social_media_profile() == 'https://www.facebook.com/Celloid1873'



# Generated at 2022-06-23 21:42:02.661678
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    with pytest.raises(Exception) as e_info:
        p.weight("s", 90)
    assert str(e_info.value) == "RandomGenerator.randint(a, b) takes 2 positional arguments but 3 were given"
    assert p.weight(38, 90) >= 38
    assert p.weight(38, 90) <= 90
    return

# Generated at 2022-06-23 21:42:04.606750
# Unit test for method name of class Person
def test_Person_name():
    assert Person(seed=4321).name(Gender.female) == 'Ксения'

# Generated at 2022-06-23 21:42:13.082100
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    site = ['blogger', 'facebook', 'flickr', 'foursquare', 'github', 'google',
            'linkedin', 'livejournal', 'livejournal', 'livejournal', 'livejournal', 
            'instagram', 'skype', 'soundcloud', 'tumblr', 'twitter', 'vimeo',
            'vkontakte', 'wordpress', 'yandex']
    for i in range(5):
        social_network = site[i]
        assert Person.social_media_profile(site = social_network).split(".")[1] == social_network
test_Person_social_media_profile()


# Generated at 2022-06-23 21:42:15.258929
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()

    with pytest.raises(TypeError):
        person.avatar('test')

    avatar = person.avatar()

    assert avatar is not None
    assert isinstance(avatar, str)
    assert len(avatar) > 0



# Generated at 2022-06-23 21:42:17.954654
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Unit tests for method telephone of class Person."""
    print('In method telephone of class Person:')
    for i in range(10):
        print(Person().telephone())
    print('')


# Generated at 2022-06-23 21:42:22.729776
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person(random=Random())
    img = person.avatar(size=256)

    assert(img == 'https://api.adorable.io/avatars/256/10a5f5cc7f2e0c5a0e5e5d5abc5b5c5b.png')


# Generated at 2022-06-23 21:42:24.942045
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    assert len(p.avatar(1200)) > 0


# Generated at 2022-06-23 21:42:29.308062
# Unit test for method height of class Person
def test_Person_height():
    ''' Test height 1.5 < [[height]] < 2.0 '''
    p = PersonFactory()
    assert float(p.height()) > 1.5, "Height must be >= 1.5"
    assert float(p.height()) < 2.0, "Height must be < 2.0"


# Generated at 2022-06-23 21:42:31.782748
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    for _ in range(10):
        _ = person.views_on()

# Generated at 2022-06-23 21:42:34.340754
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    blood_type = person.blood_type()
    assert blood_type in BLOOD_GROUPS

# Generated at 2022-06-23 21:42:37.103779
# Unit test for method university of class Person
def test_Person_university():
    provider = Person(random=Random())
    assert isinstance(provider.university(),str) == True
    assert provider.university() in Data['university']


# Generated at 2022-06-23 21:42:38.574969
# Unit test for method first_name of class Person
def test_Person_first_name():
    for _ in range(20):
        assert Person().first_name() in _data['name']

# Generated at 2022-06-23 21:42:41.559734
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    for _ in range(10):
        degree = Person().academic_degree()
        assert isinstance(degree, str)
        assert len(degree) > 1
        assert degree in ACADEMIC_DEGREES
test_Person_academic_degree()

# Generated at 2022-06-23 21:42:47.090757
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()

# Generated at 2022-06-23 21:42:48.475622
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    assert p.avatar() is not None
    assert p.avatar(size=128) is not None


# Generated at 2022-06-23 21:42:51.826540
# Unit test for method height of class Person
def test_Person_height():
    """Test for method height of class Person."""
    person = Person()

    for i in range(100):
        height = float(person.height())
        assert 1.5 < height < 2.0



# Generated at 2022-06-23 21:43:02.892901
# Unit test for method username of class Person
def test_Person_username():
    p = Person()

    # Test with empty template
    username = p.username()
    assert re.match(r'\w+_\d+', username)

    # Test with incorrect template
    with pytest.raises(ValueError):
        p.username(template='')
    with pytest.raises(ValueError):
        p.username(template='A')
    with pytest.raises(ValueError):
        p.username(template='Ud')
    with pytest.raises(ValueError):
        p.username(template='lU')

    # Test with correct template
    username = p.username(template='UU')
    assert re.match(r'[A-Z]{2}', username)
    username = p.username(template='UU_d')

# Generated at 2022-06-23 21:43:06.648373
# Unit test for method worldview of class Person
def test_Person_worldview():
    faker = Person('it')
    assert 'Ateismo' in faker.worldview()
    
test_Person_worldview()

# Generated at 2022-06-23 21:43:14.389387
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    social_network = SocialNetwork.INSTAGRAM
    email = 'test@test.ru'
    password = Person(seed=1).password()
    lang = 'ru'

    bot = Bot(email, password, lang)
    profile = bot.person.social_media_profile(site=social_network)
    assert profile == 'https://instagram.com/gh4wf0n7'

    social_network = SocialNetwork.INSTAGRAM
    profile = bot.person.social_media_profile(site=social_network)
    assert profile == 'https://instagram.com/k6dv2odff9#4h'


# Generated at 2022-06-23 21:43:17.169021
# Unit test for method password of class Person
def test_Person_password():
    from string import ascii_letters
    from string import digits
    from string import punctuation
    from random import choice
    from random import randint
    assert Person().password('k6dv2odff9#4h')

# Generated at 2022-06-23 21:43:17.967391
# Unit test for method title of class Person
def test_Person_title():
    assert isinstance(Person().title(), str)


# Generated at 2022-06-23 21:43:19.165451
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert isinstance(Person().political_views(), str)

# Generated at 2022-06-23 21:43:21.532107
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert len(Person.work_experience()) == 0
    assert len(Person.work_experience(1)) == 1
    assert len(Person.work_experience(5)) == 5

# Generated at 2022-06-23 21:43:27.925672
# Unit test for method email of class Person
def test_Person_email():
    seed(1)
    assert Person(seed=1).email() == 'langdon.42@gmail.com'
    seed(1)
    assert Person(seed=1).email() == 'langdon.42@gmail.com'
    seed(1)
    assert Person(seed=1).email() == 'langdon.42@gmail.com'
    seed(1)
    assert Person(seed=1).email() == 'langdon.42@gmail.com'
    seed(1)
    assert Person(seed=1).email() == 'langdon.42@gmail.com'
    seed(1)
    assert Person(seed=1).email() == 'langdon.42@gmail.com'
    seed(1)
    assert Person(seed=1).email() == 'langdon.42@gmail.com'

# Generated at 2022-06-23 21:43:30.450796
# Unit test for method weight of class Person
def test_Person_weight():
  weight = Person().weight(38, 90)
  if (weight >= 38) and (weight <= 90):
    print("Test Person_weight: OK")
  else: print("Test Person_weight: ERROR")

# Generated at 2022-06-23 21:43:38.620119
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person()
    f = p.first_name(gender=Gender.MALE)
    assert f == 'Абрам'
    a = p.first_name(gender=Gender.FEMALE)
    assert a == 'Абрамида'
    b = p.first_name()
    assert b == 'Абрам' or b == 'Абрамида'
    
    

# Generated at 2022-06-23 21:43:40.828811
# Unit test for method password of class Person
def test_Person_password():
    provider = Person()
    password = provider.password()
    assert len(password) == 8

# Generated at 2022-06-23 21:43:44.359249
# Unit test for method full_name of class Person
def test_Person_full_name():
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.generator import Generator
    from faker.factory import Factory
    from faker.utils.random import FakerRandom
    
    faker = Factory.create()
    faker.seed_instance(0)
    faker.add_provider(PersonProvider)

    assert faker.name() == 'Dr. Dwight Fernández'
    

# Generated at 2022-06-23 21:43:51.324054
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person()
    # default
    assert p.sex() in ('Male', 'Female', 'Other')
    # iso5218
    assert p.sex(iso5218=True) in (0, 1, 2, 9)
    # symbol
    assert p.sex(symbol=True) in ('\u2642', '\u2640', '\u26b2')


# Generated at 2022-06-23 21:43:59.152393
# Unit test for method username of class Person
def test_Person_username():
    person = Person
    username = person.username(person)

    assert isinstance(username, str)
    assert len(username) >= 3
    assert len(username) <= 128
    
# test_Person_username();
person = Person()
person.username()

person.random.seed(1234)
print(person.username())

person.random.seed(1234)
print(person.username())

person = Person()
person.random.seed(1234)
print(person.username())

person = Person()
person.random.seed(1234)
print(person.username())

# Generated at 2022-06-23 21:44:08.802015
# Unit test for method username of class Person
def test_Person_username():
    # test for full match
    assert re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', 'U-d')
    # test for full match
    assert re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', 'UU_d')
    # test for full match
    assert re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', 'ld')
    # test for full match
    assert re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', 'l-d')
    # test for full match

# Generated at 2022-06-23 21:44:10.714884
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    for _ in range(100):
        obj = Person()
        assert obj.work_experience()



# Generated at 2022-06-23 21:44:13.366162
# Unit test for method name of class Person
def test_Person_name():
    p = Person()
    assert(len(p.name()) >= 3)
    assert(p.name()[0].isupper())


# Generated at 2022-06-23 21:44:16.536263
# Unit test for method email of class Person
def test_Person_email():
    random_seed(2)
    print(Person().email())

    random_seed(2)
    print(Person().email())

    random_seed(123)
    print(Person().email())

# Generated at 2022-06-23 21:44:18.956767
# Unit test for method username of class Person
def test_Person_username():
    random = Random()
    random.seed(0)
    person = Person(random)
    assert person.username() == 'Fenley.1976'



# Generated at 2022-06-23 21:44:22.610496
# Unit test for method password of class Person
def test_Person_password():
    pwd = Person().password()
    assert isinstance(pwd, str)
    assert len(pwd) == 8

    pwd = Person().password(length=4)
    assert isinstance(pwd, str)
    assert len(pwd) == 4

    pwd = Person().password(hashed=True)
    assert isinstance(pwd, str)
    assert len(pwd) == 32

# Generated at 2022-06-23 21:44:29.253246
# Unit test for method identifier of class Person
def test_Person_identifier():
    """Unit test for method identifier of class Person.
    """
    rnd = Random()

    # --- Mask = '##-##/##' ---
    person = Person(rnd)
    identifier = person.identifier(mask='##-##/##')
    assert len(identifier) == 9
    assert re.match(r'\d{2}-\d{2}/\d{2}', identifier)

    # --- Mask = '##-##-##' ---
    person = Person(rnd)
    identifier = person.identifier(mask='##-##-##')
    assert len(identifier) == 8
    assert re.match(r'\d{2}-\d{2}-\d{2}', identifier)

    # --- Mask = '########' ---
    person = Person(rnd)


# Generated at 2022-06-23 21:44:34.271881
# Unit test for method identifier of class Person
def test_Person_identifier():
    id = Person().identifier(mask='@-@/@')
    assert isinstance(id, str)

    p = re.compile('[a-z]{2}-[a-z]{2}/[a-z]{2}')
    res = p.fullmatch(id)
    assert res



# Generated at 2022-06-23 21:44:37.651256
# Unit test for method name of class Person
def test_Person_name():
    from dummy_data.core import Dummy
    from dummy_data.enumerations import Gender
    for _ in range(10):
        assert isinstance(Dummy.Person().name(Gender.MALE), str)

# Generated at 2022-06-23 21:44:46.165056
# Unit test for method email of class Person
def test_Person_email():
    data = [
        (
            [{'locale': 'en_US', 'male': ['Johann Wolfgang'], 'female': ['Johann Wolfgang']}],
            None,
            'Johann Wolfgang',
        ),
        (
            [{'locale': 'en_US', 'male': ['Johann Wolfgang'], 'female': ['Johann Wolfgang']}],
            'Johann Wolfgang',
            'Johann Wolfgang',
        ),
    ]

    for name in data:
        person = Person(names=name[0], rnd=rnd)
        assert person.name() == name[2]
# Define object rnd
rnd = Random()

# Create object Person
person = Person(rnd=rnd)


# Generated at 2022-06-23 21:44:48.421083
# Unit test for method weight of class Person
def test_Person_weight():
    values = set()
    for _ in range(100):
        values.add(Person().weight())
    assert min(values) >= 38
    assert max(values) <= 90

# Generated at 2022-06-23 21:44:50.843484
# Unit test for method occupation of class Person
def test_Person_occupation():
    for i in range(100):
        x = Person.occupation(person)
        assert isinstance(x, str) is True


# Generated at 2022-06-23 21:44:52.741878
# Unit test for constructor of class Person
def test_Person():
    fake = Person()
    assert isinstance(fake, Person)

# Generated at 2022-06-23 21:44:56.447284
# Unit test for method age of class Person
def test_Person_age():
    # Person
    assert Person.age(birthday='1995-08-12') == 23
    assert Person.age(birthday='2010-08-12') == 8



# Generated at 2022-06-23 21:45:04.089204
# Unit test for method username of class Person
def test_Person_username():
    
    # Create Person object and set random seed
    p = Person()
    p.seed(1)
    
    # Test 10 usernames
    username_list = []
    for i in range(10):
        username_list.append(p.username())
    
    # Set expected results
    expected_results = ['S_1822', 'S.1823', 'S-1824', 'SS-1825', 'SS.1826',
                        'SS_1827', 'k_1828', 'k.1829', 'k-1830', 'kk-1831']
    
    return username_list, expected_results


# Generated at 2022-06-23 21:45:05.574214
# Unit test for method email of class Person
def test_Person_email():
    ip = Person()
    ip.email()


# Generated at 2022-06-23 21:45:06.813940
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person(seed=0)
    assert person.sexual_orientation() == 'Bisexuality'

# Generated at 2022-06-23 21:45:10.221629
# Unit test for method password of class Person
def test_Person_password():

    # Arrange
    password = 'k6dv2odff9#4h'
    person = Person()

    # Act
    result = person.password()

    # Assert
    assert result == password

# Generated at 2022-06-23 21:45:16.210452
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    result = person.work_experience()

    assert(person.random.randrange(10) == result.range_of_experience.years)
    assert(person.random.randrange(10) == result.experience_in_current_area.years)
    assert(person.random.randrange(10) == result.experience_in_current_position.years)

# Generated at 2022-06-23 21:45:21.752833
# Unit test for constructor of class Person
def test_Person():
    # Test init of random provider
    person = Person()

    # Check default state of provider
    assert not person._initialized
    assert person.seed is None
    assert person._data == {}

    # Create random provider with explicit seed
    person = Person(seed=42)

    # Check explicit init of provider
    assert person._initialized
    assert person.seed == 42
    assert person._data == {}


# Generated at 2022-06-23 21:45:24.515822
# Unit test for method password of class Person
def test_Person_password():
    pytest.debug_func()
    person = Person()
    password = person.password()
    assert len(password) == 8
    assert re.match(r'\w+', password)

# Generated at 2022-06-23 21:45:27.990864
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person('ru')
    assert re.match(r'\d+\D+\d{4}', person.work_experience())
test_Person_work_experience()


# Generated at 2022-06-23 21:45:29.438790
# Unit test for method password of class Person
def test_Person_password():
    result = Person.password()
    assert type(result) == str
    assert len(result) == 8


# Generated at 2022-06-23 21:45:33.426039
# Unit test for method identifier of class Person
def test_Person_identifier():
    pn = Person()
    identifier = pn.identifier(mask='##*##/##')
    assert identifier.count('#') == 6
    assert identifier.count('*') == 1
    assert identifier.count('/') == 1
    assert re.match(r'^[0-9]*\*[0-9]*/[0-9]+$', identifier)

# Generated at 2022-06-23 21:45:38.360979
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Target
    provider = Person()

    # Action
    result = provider.social_media_profile(SocialNetwork.TWITTER)

    # Assert
    assert result.startswith('https://')
    assert result.endswith('.com/')

# Generated at 2022-06-23 21:45:45.877461
# Unit test for method university of class Person
def test_Person_university():
    import random
    from string import ascii_uppercase
    from efictopub.models.person import Person

    person = Person(seed=0)
    data = person._data['university']
    # print(data)
    sample_size = 1000
    n = len(data)
    values = [person.university() for _ in range(sample_size)]
    unique_values = set(values)
    print(len(unique_values), unique_values)
    assert len(values) == len(unique_values)



# Generated at 2022-06-23 21:45:57.698217
# Unit test for method gender of class Person
def test_Person_gender():
    from faker_ru.utils import Gender

    per = Person(seed=123456)

    for i in range(10):
        gender = per.gender(iso5218=True)
        assert gender in (1, 2, 0, 9)
        assert isinstance(gender, int)

    for i in range(10):
        gender_symbol = per.gender(symbol=True)
        assert gender_symbol in ('♂', '♀')

    gender_symbol = per.gender(symbol=True)
    assert gender_symbol == '♀'

    for i in range(5):
        gender = per.gender()
        assert gender in ('Male', 'Female')

    gender = per.gender()
    assert gender == 'Male'


# Generated at 2022-06-23 21:45:59.200399
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person().work_experience() in WORK_EXPERIENCES

# Generated at 2022-06-23 21:46:03.590611
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()

    r = p.views_on()
    assert r in ('Neutral', 'Positive', 'Negative')

    p = Person(seed=42)

    r = p.views_on()
    assert r == 'Neutral'

# Generated at 2022-06-23 21:46:09.688115
# Unit test for method username of class Person
def test_Person_username():
    # Smoke Tests
    assert Person().username()
    assert Person().username(template=None)
    assert Person().username(template='default')
    assert Person().username(template='ld')
    assert Person().username(template='U_d')
    assert Person().username(template='l-d')
    assert Person().username(template='U.d')
    assert Person().username(template='l_d')

    # Test exception
    with pytest.raises(ValueError):
        Person().username(template='Invalid')


# Generated at 2022-06-23 21:46:19.196740
# Unit test for method password of class Person
def test_Person_password():
    x = Person(seed=1)
    assert x.password(hashed=False) == 'k6dv2odff9#4h'
    assert x.password(hashed=False) == 'k6dv2odff9#4h'
    assert x.password(hashed=True) == '50481d95e2cc99bb9fdf2414b8c0dbb1'
    assert x.password(hashed=True) == '50481d95e2cc99bb9fdf2414b8c0dbb1'


# Generated at 2022-06-23 21:46:21.308626
# Unit test for method age of class Person
def test_Person_age():
    with Person() as p:
        assert type(p.age()) is int


# Generated at 2022-06-23 21:46:24.054687
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person."""
    person = Person()
    assert isinstance(person, Person)
    print('✔︎ constructor Person()')


# Generated at 2022-06-23 21:46:28.894071
# Unit test for method name of class Person
def test_Person_name():
    # Assert that all possible results for `Person.name` match the expected patterns
    for _ in range(10000):
        name = f.name()
        assert re.match('[A-Z][a-z]+', name), f'`name` failed with result `{name}`'
        assert len(name) > 1 and len(name) < 10, f'`name` failed with result `{name}`'


# Generated at 2022-06-23 21:46:31.288055
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person(seed=2)
    assert person.worldview() == 'Atheism'

# Generated at 2022-06-23 21:46:33.834594
# Unit test for method password of class Person
def test_Person_password():
    assert Person().password()
    assert Person().password(hashed=True)
    assert len(Person(seed=1).password()) == 8
    assert len(Person(seed=1).password(hashed=True)) == 32
    assert len(Person().password(length=40)) == 40

# Generated at 2022-06-23 21:46:36.361242
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()

    for _ in range(10):
        assert person.academic_degree() in ACADEMIC_DEGREES


# Generated at 2022-06-23 21:46:38.110848
# Unit test for method name of class Person
def test_Person_name():
    p = Person(random=Random())
    assert isinstance(p.name(), str)


# Generated at 2022-06-23 21:46:40.896264
# Unit test for method weight of class Person
def test_Person_weight():
    w = Person().weight()
    assert isinstance(w, int) and w>=38 and w<=90


# Generated at 2022-06-23 21:46:46.950749
# Unit test for method title of class Person
def test_Person_title():
    provider = Person()
    print(provider.title(Gender.male, TitleType.prefix))
    # => Dr
    print(provider.title(TitleType.prefix))
    # => Mrs
    print(provider.title(Gender.male, TitleType.suffix))
    # => Jr
    print(provider.title(TitleType.suffix))
    # => Sr


# Generated at 2022-06-23 21:46:53.774155
# Unit test for method worldview of class Person
def test_Person_worldview():
    result = Person().worldview()
    assert result in ["Deism", "Humanism", "Pantheism", "Positivism",
                     "Realism", "Rationalism", "Scientific materialism", "Agnosticism",
                     "Christianity", "Gnosticism", "Hinduism", "Islamism", "Judaism",
                     "Paganism", "Buddhism", "Shamanism", "Taoism", "Shintoism"], "Method worldview() of class Person does not work"

assert test_Person_worldview()


# Generated at 2022-06-23 21:47:05.710783
# Unit test for method identifier of class Person

# Generated at 2022-06-23 21:47:07.477355
# Unit test for method weight of class Person
def test_Person_weight():
    with pytest.raises(AssertionError):
        assert Person().weight(38, 38)

# Generated at 2022-06-23 21:47:10.026561
# Unit test for method age of class Person
def test_Person_age():
    provider = Faker.get_instance(locales=['en'])
    age = provider.age()
    assert isinstance(age, int)



# Generated at 2022-06-23 21:47:17.161879
# Unit test for method title of class Person
def test_Person_title():
    p = Person(locale='en')
    for i in range(1000):
        assert p.title(gender=Gender.Female, title_type=TitleType.Prefix) in p._data['title']['female']['prefix']
        assert p.title(gender=Gender.Female, title_type=TitleType.Suffix) in p._data['title']['female']['suffix']
        assert p.title(gender=Gender.Male, title_type=TitleType.Prefix) in p._data['title']['male']['prefix']
        assert p.title(gender=Gender.Male, title_type=TitleType.Suffix) in p._data['title']['male']['suffix']


# Generated at 2022-06-23 21:47:19.621000
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    # Test function Person.academic_degree()
    person = Person(language='en')
    degree = person.academic_degree()
    assert isinstance(degree, str)

# Generated at 2022-06-23 21:47:22.630754
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert len(Person().social_media_profile()) > 0


# Generated at 2022-06-23 21:47:24.423849
# Unit test for method first_name of class Person
def test_Person_first_name():
    l = Person.first_name()
    return isinstance(l, str)

# Generated at 2022-06-23 21:47:27.752371
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationalities = person._data['nationality']

    if isinstance(nationalities, dict):
        for _ in range(100):
            for gender in Gender:
                assert person.nationality(gender) in nationalities[gender]

    else:
        for _ in range(100):
            assert person.nationality() in nationalities


# Generated at 2022-06-23 21:47:30.324623
# Unit test for constructor of class Person
def test_Person():
    """
    Test for constructor of class Person.
    """
    person = Person()
    assert person is not None


# Generated at 2022-06-23 21:47:33.096790
# Unit test for method height of class Person
def test_Person_height():
    person = Person(locale='en')
    for _ in range(100):
        assert isinstance(person.height(), str)

# Generated at 2022-06-23 21:47:35.385741
# Unit test for method full_name of class Person
def test_Person_full_name():
    test_full_name = Person.full_name(None)
    assert(isinstance(test_full_name ,str))

# Generated at 2022-06-23 21:47:39.525216
# Unit test for method avatar of class Person
def test_Person_avatar():
    for size in (1, 32, 64, 128, 256):
        r = Person(random=Random())
        assert r.avatar(size=size) == f'https://api.adorable.io/avatars/{size}/{r.password(hashed=True)}.png'

# Generated at 2022-06-23 21:47:41.959855
# Unit test for method nationality of class Person
def test_Person_nationality():
    args = [
        ('usd', ['nationality'])
    ]

    for arg in args:
        assert get_random_value(Person, *arg) is not None



# Generated at 2022-06-23 21:47:43.926985
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person(seed=1410)
    assert person.gender() == 'Male'
    assert person.gender(symbol=True) == '♂'
    assert person.gender(iso5218=True) == 2

# Generated at 2022-06-23 21:47:45.918228
# Unit test for method height of class Person
def test_Person_height():
    height = Person.height(minimum=1.5,maximum=2)
    assert 1.5 < height<2

# Generated at 2022-06-23 21:47:53.763406
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    provider = Person()
    for _ in range(10):
        assert type(provider.work_experience(as_str=False)) == int
        assert re.match(r'\d+\s?(years?|months?|days?)',
                        provider.work_experience(as_str=True))

    provider.random.seed(0)
    assert provider.work_experience(as_str=False) == 14
    assert provider.work_experience(as_str=True) == '14 years'
    provider.random.seed()

# Generated at 2022-06-23 21:48:04.620380
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    py_rpg = Person(seed=12878)
    assert py_rpg.sexual_orientation() == 'Bisexuality'
    assert py_rpg.sexual_orientation() == 'Pansexuality'
    assert py_rpg.sexual_orientation() == 'Asexuality'
    assert py_rpg.sexual_orientation() == 'Bisexuality'
    assert py_rpg.sexual_orientation() == 'Bisexuality'
    assert py_rpg.sexual_orientation() == 'Bisexuality'
    assert py_rpg.sexual_orientation() == 'Bisexuality'
    assert py_rpg.sexual_orientation() == 'Homosexuality'
    assert py_rpg.sexual_orientation() == 'Asexuality'

# Generated at 2022-06-23 21:48:16.221087
# Unit test for method email of class Person
def test_Person_email():
    string = 'abcdefghijklmnopqrstuvwxyz'
    upper_string = string.upper()
    numbers = '0123456789'
    all_char = string + upper_string + numbers

    provider = Person()
    random_first_part_name = ''.join(random.choice(all_char) for i in range(10))
    random_second_part_name = ''.join(random.choice(all_char) for i in range(5))

    random_domain_list = ['@gmail.com', '@hotmail.com', '@yahoo.com', '@icloud.com', '@outlook.com']
    first_part_random_email = random_first_part_name + random_second_part_name

# Generated at 2022-06-23 21:48:19.604930
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Create personal instance
    person = Person()
    # Check that method returns not empty string
    assert person.work_experience() != '', 'No empty string'
    # Check that method returns string
    assert isinstance(person.work_experience(), str), 'Not str instance'

# Generated at 2022-06-23 21:48:20.564934
# Unit test for method weight of class Person
def test_Person_weight():
    pass


# Generated at 2022-06-23 21:48:21.419209
# Unit test for method name of class Person
def test_Person_name():
    assert Person().name() is not None


# Generated at 2022-06-23 21:48:33.860223
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():

    person = Person()
    print(person.sexual_orientation())
    # >>> random.choice(SEXUALITY_SYMBOLS)
    # "🌈"
    # >>> random.choice(SEXUALITY_SYMBOLS)
    # "🏳‍"
    # >>> random.choice(SEXUALITY_SYMBOLS)
    # "⚥"
    # >>> random.choice(SEXUALITY_SYMBOLS)
    # "🌈"
    # >>> random.choice(SEXUALITY_SYMBOLS)
    # "🏳‍"
    # >>> random.choice(SEXUALITY_SYMBOLS)
    # "⚥"
    # >>> random.choice(SEXUALITY_SYMBOLS)
    # "

# Generated at 2022-06-23 21:48:42.226320
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person(random=Random())
    assert p.blood_type()  == "O+"
    assert p.blood_type()  == "A+"
    assert p.blood_type()  == "AB+"
    assert p.blood_type()  == "A-"
    assert p.blood_type()  == "B+"
    assert p.blood_type()  == "O-"
    assert p.blood_type()  == "AB-"
    assert p.blood_type()  == "B-"


# Generated at 2022-06-23 21:48:48.474187
# Unit test for method telephone of class Person
def test_Person_telephone():

    # Using telephone() method with default arguments
    assert Person().telephone() == '+9-(967)-456-78-99'

    # Using telephone() method with mask argument
    assert Person().telephone(mask='##/##-####') == '12/34-5678'

    # Using telephone() method with placeholder argument
    assert Person().telephone(mask='#-#/##', placeholder='@') == '3-4/56'


# Generated at 2022-06-23 21:48:49.958830
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert type(person) is Person


# Generated at 2022-06-23 21:48:52.938623
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person(None)
    person_views_on = person.views_on()
    assert isinstance(person_views_on, str)
    assert person_views_on in PERSON_VIEWS_ON


# Generated at 2022-06-23 21:48:55.060437
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person(random=Random())
    assert isinstance(person.sexual_orientation(), str)


# Generated at 2022-06-23 21:49:00.230712
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email().split('@')[1] in EMAIL_DOMAINS

    emails = [
        Person().email()
        for _ in range(5000)
    ]

    for email in EMAIL_DOMAINS:
        assert '@' + email in emails

# Generated at 2022-06-23 21:49:02.183187
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    print(person.weight())


# Generated at 2022-06-23 21:49:04.104202
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    assert person.political_views() in POLITICAL_VIEWS

# Generated at 2022-06-23 21:49:06.725240
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    from faker.providers.person.en_US.person import Provider

    provider = Provider(None)
    print(provider.sexual_orientation())


# Generated at 2022-06-23 21:49:10.508216
# Unit test for method height of class Person
def test_Person_height():
    provider = Faker()
    assert type(provider.height()) is str
    assert type(provider.height(minimum=0.3)) is str
    assert provider.height(minimum=1, maximum=1) is not None
    assert 0.3 <= float(provider.height(minimum=0.3, maximum=1)) <= 1


# Generated at 2022-06-23 21:49:16.826685
# Unit test for method worldview of class Person
def test_Person_worldview():
    assert Person().worldview() in ['Hedonism', 'Pantheism', 'Humanism', 'Egoism', 'Rationalism', 'Materialism', 'Buddhism', 'Fatalism', 'Anarchism', 'Atheism', 'Pessimism', 'Nihilism', 'Naturism', 'Stoa', 'Agnosticism', 'Confucianism', 'Taoism', 'Paganism', 'Tolstoyism', 'Christianity', 'Judaism', 'Islam']


# Generated at 2022-06-23 21:49:22.475592
# Unit test for method name of class Person
def test_Person_name():
    from faker import Faker
    from faker.providers.person.en_US import Provider
    fake = Faker()
    fake.add_provider(Provider)
    for value in range(1,10):
        print(fake.name())


# Generated at 2022-06-23 21:49:26.018832
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname(Gender.Female) in person._data['surname']
    assert person.surname(Gender.Female) in person._data['surname'][Gender.Female]


# Generated at 2022-06-23 21:49:29.016307
# Unit test for method avatar of class Person
def test_Person_avatar():
    # Initialization of Faker class
    faker = Faker()

    # Get random avatar
    avatar = faker.Person.avatar()

    # Check avatar
    assert avatar

# Generated at 2022-06-23 21:49:36.097420
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    words = Person.academic_degree()
    assert isinstance(words, str)

# Generated at 2022-06-23 21:49:39.715524
# Unit test for method identifier of class Person
def test_Person_identifier():
    rnd = random.Random()
    rnd.seed(12345)
    #
    provider = Person(rnd=rnd)
    assert provider.identifier('##-##/##') == '07-97/04', 'Invalid identifier'



# Generated at 2022-06-23 21:49:47.988854
# Unit test for method age of class Person
def test_Person_age():
    p = Person()

    # Should be less than or exactly 100
    for _ in range(100):
        age = p.age(maximum=100)
        assert age <= 100

    # Should be greater than or exactly 18
    for _ in range(100):
        age = p.age(minimum=18)
        assert age >= 18

    # Should be between 18 and 100
    for _ in range(100):
        age = p.age(minimum=18, maximum=100)
        assert age >= 18 and age <= 100

# Generated at 2022-06-23 21:49:52.422014
# Unit test for method language of class Person
def test_Person_language():
    name = Person().language()
    try:
        f = open('languages.txt','r')
    except FileNotFoundError:
        print("File not found")
    except:
        print("An error occurred")
    content = f.read()
    assert name in content
    f.close()
    return

# Generated at 2022-06-23 21:49:54.014204
# Unit test for method avatar of class Person
def test_Person_avatar():
    av = Person.avatar()
    print(av)

# Generated at 2022-06-23 21:49:56.847927
# Unit test for method language of class Person
def test_Person_language():
    for _ in range(100):
        _ = instance.language()
        assert(isinstance(_, str))
test_Person_language()




# Generated at 2022-06-23 21:49:58.773973
# Unit test for method name of class Person
def test_Person_name():
    with Person.seed_instance(12345):
        name = Person().name()
    assert name == 'Oleg'

# Generated at 2022-06-23 21:50:00.533779
# Unit test for method language of class Person
def test_Person_language():
    p = Person()
    assert p.language() in p._data["language"]

# Generated at 2022-06-23 21:50:04.381001
# Unit test for method telephone of class Person
def test_Person_telephone():
    random.seed(0)
    actual = Person().telephone()
    expected = '+3-(860)-433-87-64'
    assert actual == expected

# Generated at 2022-06-23 21:50:08.206635
# Unit test for method avatar of class Person
def test_Person_avatar():
    """Unit test for method avatar of class Person."""
    from pydora.collections import Person
    seed = 1
    print('Person.avatar(seed={})'.format(seed))

    for _ in range(3):
        per = Person(seed=seed)
        a = per.avatar()
        print(a)



# Generated at 2022-06-23 21:50:11.635629
# Unit test for method weight of class Person
def test_Person_weight():
    p = Provider()
    p.seed(0)
    for i in range(1,10):
        weight = p.weight()
        print(weight)
        assert weight >= 38
        assert weight <= 90


# Generated at 2022-06-23 21:50:18.946025
# Unit test for method full_name of class Person
def test_Person_full_name():
    """Unit test for method full_name of class Person."""
    person = Person()
    full_name = person.full_name()
    assert full_name is not None
    assert isinstance(full_name, str)
    assert len(full_name) > 0
    assert full_name.split()[0] in first_names
    assert full_name.split()[1] in last_names


# Generated at 2022-06-23 21:50:22.265425
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    tester = Assert()
    special = Person()
    result = special.blood_type()
    tester.assert_not_equals(result, Boolean(), '', 3, False)

# Generated at 2022-06-23 21:50:26.138423
# Unit test for method political_views of class Person
def test_Person_political_views():
    counter = 0
    for _ in range(100):
        if Person().political_views() == 'Сommunist':
            counter += 1
    assert counter == 0
    
test_Person_political_views()

# Generated at 2022-06-23 21:50:28.823791
# Unit test for method height of class Person
def test_Person_height():
    provider = Person(locale='ru')
    for _ in range(100):
        assert 1.5 <= float(provider.height()) <= 2.0


# Generated at 2022-06-23 21:50:33.248906
# Unit test for constructor of class Person
def test_Person():
    pr = Person()
    assert pr.random is not None, 'Random state is not initialized'
    assert pr.seed is None

    pr = Person(seed=777)
    assert pr.random is not None, 'Random state is not initialized'
    assert pr.seed == 777



# Generated at 2022-06-23 21:50:36.039808
# Unit test for method sex of class Person
def test_Person_sex():
    for _ in range(100):
        sex = Person.sex()
        result = sex
        assert result in ('Male', 'Female')

test_Person_sex()



# Generated at 2022-06-23 21:50:42.196319
# Unit test for method title of class Person
def test_Person_title():
    from faker.providers.person.en_US import Provider as Person
    p = Person.title(gender="female", title_type="prefix")
    assert p == 'Mrs.'

    p = Person.title(gender="male", title_type="suffix")
    assert p == "Jr."

    p = Person.title(gender="female", title_type="suffix")
    assert p == "II"

    p = Person.title(gender="male", title_type="prefix")
    assert p == "Mr."


# Generated at 2022-06-23 21:50:44.622401
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = Person()
    assert isinstance(provider.last_name(), str)
    assert provider.last_name()

# Generated at 2022-06-23 21:50:46.491127
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person()

    assert type(p.first_name()) is str


# Generated at 2022-06-23 21:50:48.651511
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = Person()
    last_name = provider.last_name()

    assert last_name in SURNAMES

# Generated at 2022-06-23 21:50:52.356784
# Unit test for method title of class Person
def test_Person_title():
    # Given
    person=Person()

    # When

    # Then
    assert type(person.title(title_type=TitleType.PREFIX)) == str
    assert type(person.title(title_type=TitleType.SUFFIX)) == str


# Generated at 2022-06-23 21:50:53.436408
# Unit test for method name of class Person
def test_Person_name():
    assert Person.name('female') != None

# Generated at 2022-06-23 21:50:56.907756
# Unit test for method avatar of class Person
def test_Person_avatar():
    res = Person().avatar()
    assert re.findall('(\w+[-]\w+[-]\w+[-]\w+[-]\w+){1}', res)


# Generated at 2022-06-23 21:51:00.690800
# Unit test for method first_name of class Person
def test_Person_first_name():
    for _ in range(100):
        gender = get_random_item(Gender, rnd=random)
        first_name = Person.first_name(gender, random)
        assert isinstance(first_name, str)
        assert first_name
        assert first_name in NAMES[gender]
