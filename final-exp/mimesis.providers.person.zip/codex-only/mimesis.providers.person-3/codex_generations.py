

# Generated at 2022-06-23 21:40:58.166676
# Unit test for method sex of class Person
def test_Person_sex():
    r = Member()
    assert isinstance(r.sex(), str)


# Generated at 2022-06-23 21:40:59.735160
# Unit test for method university of class Person
def test_Person_university():
    provider = Person()
    assert provider.university() == 'NDEU'



# Generated at 2022-06-23 21:41:07.338108
# Unit test for method title of class Person
def test_Person_title():
    assert Person().title() in _data.title['male']['prefix'] + _data.title['female']['prefix']
    assert Person().title(gender='male') in _data.title['male']['prefix']
    assert Person().title(gender='female') in _data.title['female']['prefix']
    assert Person().title(title_type='prefix') in _data.title['male']['prefix'] + _data.title['female']['prefix']
    assert Person().title(gender='male', title_type='prefix') in _data.title['male']['prefix'] 
    assert Person().title(gender='female', title_type='prefix') in _data.title['female']['prefix']
    assert Person().title(title_type='suffix') in _data.title['male']['suffix']

# Generated at 2022-06-23 21:41:10.820708
# Unit test for method full_name of class Person
def test_Person_full_name(): #unit test for method full_name of class Person
    person = PersonProvider(random = Random()) #initialize class PersonProvider
    person.full_name() #call method full_name of class PersonProvider


# Generated at 2022-06-23 21:41:12.233466
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert(Person().nationality() in NATIONALITIES)


# Generated at 2022-06-23 21:41:21.385812
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Initialize random bytes generator with seed
    random_bytes_generator = RandomBytesGenerator(seed=622)

    # Initialize random generator
    rnd = RandomGenerator(random_bytes_generator=random_bytes_generator)

    person = Person(random_generator=rnd)
    name = person.full_name()
    assert name == 'Николай Антонов'

    person = Person(random_generator=rnd)
    name = person.full_name()
    assert name == 'Николай Антонов'

# Generated at 2022-06-23 21:41:25.695131
# Unit test for method nationality of class Person
def test_Person_nationality():
    # test_Person_nationality return random nation
    p = Person(seed=654321)
    nationalities = set()
    for i in range(100):
        nationalities.add(p.nationality())
    assert(len(nationalities) == 100)



# Generated at 2022-06-23 21:41:30.503310
# Unit test for method last_name of class Person
def test_Person_last_name():
    """
    Unit test for method last_name of class Person
    """
    from faker import Faker
    fk = Faker()
    first_name = fk.name()
    assert type(first_name) == str
    print ("Test last_name - OK")
    

# Generated at 2022-06-23 21:41:31.814129
# Unit test for method sex of class Person
def test_Person_sex():
    """Person().sex"""
    assert Person().sex() in GENDER_SYMBOLS

# Generated at 2022-06-23 21:41:34.521277
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    faker = Faker('ru_RU')
    profile = faker.social_media_profile()
    print(profile)
    

# Generated at 2022-06-23 21:41:36.975363
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    assert provider.surname() != provider.surname()



# Generated at 2022-06-23 21:41:45.611750
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    @patch('faker_ru.Provider.random')
    def test(self, random):
        random.choice.return_value = 'Bisexuality'
        assert self.sexual_orientation() == 'Bisexuality'
        random.choice.assert_called_once_with(self._data['sexuality'])
        random.choice.return_value = 'Pansexuality'
        assert self.sexual_orientation() == 'Pansexuality'
        random.choice.assert_called_with(self._data['sexuality'])
        assert random.choice.call_count == 2



# Generated at 2022-06-23 21:41:49.003021
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    from faker import Faker
    from faker.generator import random
    from faker.providers.person.it_IT import Provider

    fake = Faker()
    fake.add_provider(Provider)
    assert type(fake.sexual_orientation()) == str

# Generated at 2022-06-23 21:41:50.676419
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person('Data/person.json')
    assert person.social_media_profile()
import pytest


# Generated at 2022-06-23 21:41:58.117592
# Unit test for constructor of class Person
def test_Person():
    person = Person(seed=42)

    assert person.name(gender=Gender.Male) == 'Oleg'
    assert person.name(gender=Gender.Female) == 'Anna'
    assert person.name(gender=Gender.Androgyne) == 'Kostya'
    assert person.nationality(gender=Gender.Male) == 'Russian'
    assert person.nationality(gender=Gender.Female) == 'Armenian'
    assert person.nationalities == ['Russian', 'Armenian']
    assert person.telephone() == '+7-(963)-409-11-22'
    assert person.telephone(mask='# (###) ### ## ##') == '7 (963) 409 11 22'

# Generated at 2022-06-23 21:41:59.920301
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert type(Person().nationality()) == str

# Generated at 2022-06-23 21:42:02.196368
# Unit test for method username of class Person
def test_Person_username():
    provider = Person(random=FakeRandom(22))
    assert provider.username() == 'Eunice_1871'


# Generated at 2022-06-23 21:42:04.964577
# Unit test for method occupation of class Person
def test_Person_occupation():
    result = Person.occupation()
    print('occupation = ', result)
    assert isinstance(result, str)

test_Person_occupation()


# Generated at 2022-06-23 21:42:07.929842
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    name = person.surname()
    
    assert name is not None
    assert name != ''
    assert isinstance(name, str)

# Generated at 2022-06-23 21:42:10.240001
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert isinstance(Person.political_views(), str)
    assert len(Person.political_views()) >= 1


# Generated at 2022-06-23 21:42:15.320797
# Unit test for method sex of class Person
def test_Person_sex():
    from faker import Faker
    from faker.utils import text
    from faker.config import AVAILABLE_LOCALES as locales
    from faker.providers.person.en_US import Provider as EnProvider
    from faker.providers.person.ru_RU import Provider as RuProvider

    # Create seed manually
    seed = text.get_seed(EnProvider)
    fake = Faker('ru_RU', seed=seed)
    ru = RuProvider(fake)
    ru_sex = ru.sex()
    ru_sex_symbol = ru.sex(symbol=True)
    
    # Create seed manually
    seed = text.get_seed(RuProvider)
    fake = Faker('en_US', seed=seed)
    en = EnProvider(fake)

# Generated at 2022-06-23 21:42:19.363505
# Unit test for method telephone of class Person
def test_Person_telephone():    
    p = faker.Faker()
    # make sure that the phone number is in the correct format
    assert re.match(r'^\+\d{1,3}\-\(\d{3}\)\-\d{3}\-\d{2}\-\d{2}$', p.telephone('+7-(###)-###-##-##'))


# Generated at 2022-06-23 21:42:22.602796
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Init provider
    provider = Person(random=Random())

    # Get result
    result = provider.telephone()

    # Check result
    assert re.fullmatch(r'[\+]?[\d-]*', result) is not None

# Generated at 2022-06-23 21:42:29.647090
# Unit test for method identifier of class Person
def test_Person_identifier():
    for i in range(10):
        obj = Person()
        assert( len(obj.identifier()) == len('##-##/##') )
        assert( obj.identifier('@') == '@' )
        assert( obj.identifier('##') == '##' )
        assert( obj.identifier('@@') == '@@' )
        assert( obj.identifier('##@@') == '##@@' )
        assert( obj.identifier('@@##') == '@@##' )

# Generated at 2022-06-23 21:42:32.084817
# Unit test for method worldview of class Person
def test_Person_worldview():
    pr = Person('ru')
    assert pr.worldview() in pr._data['worldview']


# Generated at 2022-06-23 21:42:34.233808
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    print(person.university())
test_Person_university()


# Generated at 2022-06-23 21:42:37.383039
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person(random = random)
    Person_weight = person.weight(minimum = 0, maximum = 800)
    assert(Person_weight >= 0 and Person_weight <= 800)


# Generated at 2022-06-23 21:42:41.483393
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person(seed=1234)
    assert provider.sexual_orientation() == "Asexuality"
    assert provider.sexual_orientation(symbol=True) == "⚢"
    for _ in range(100):
        assert provider.sexual_orientation() == provider.sexual_orientation()


# Generated at 2022-06-23 21:42:45.215576
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    p.random.seed(1)
    assert p.last_name() == 'Cespedes'
    p.random.seed(1)
    assert p.last_name() == p.last_name()
    p.random.seed(2)
    assert p.last_name() != p.last_name()
    assert isinstance(p.last_name(), str)

# Generated at 2022-06-23 21:42:52.159192
# Unit test for constructor of class Person
def test_Person():
    from faker import Faker
    from faker_play.toys import Toy

    fake = Faker()
    toy = Toy(Person)

    fake_person = Person(fake, 'ru_RU')
    assert fake_person.random == fake.random

    fake_person = fake.person
    assert fake_person.random == fake.random

    fake_person = Person.default_provider()
    assert isinstance(fake_person.random, Generator)

    fake_person = Person(None, 'ru_RU')
    assert isinstance(fake_person.random, Generator)

    fake_person = Person(fake, 'ru_RU')
    assert fake_person.locale == 'ru_RU'

    assert isinstance(toy.entity, Person)
    assert toy.entity.locale == 'en'



# Generated at 2022-06-23 21:42:56.285705
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    """Unit test for method sexual_orientation of class Person"""
    # Arrange

    # Act
    sexual_orientation = provider.sexual_orientation()

    # Assert
    assert sexual_orientation in SEXUAL_ORIENTATIONS

# Generated at 2022-06-23 21:43:00.677573
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert Person().sexual_orientation() in (
        r'Androphilia',
        r'Gynephilia',
        r'Gynophilia',
        r'Androphilia',
        r'Gynephilia',
        r'Gynophilia',
    )

# Generated at 2022-06-23 21:43:05.897823
# Unit test for method avatar of class Person
def test_Person_avatar():
    from faker.providers.person.en_US import Provider
    gen = Provider(None)
    for _ in range(100):
        res = gen.avatar()
        assert re.match(r'[^@]+@[^@]+\.[^@]+', res), res
    assert gen.avatar(500).endswith('500.png')


# Generated at 2022-06-23 21:43:07.444849
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in VIEWS_ON


# Generated at 2022-06-23 21:43:08.617926
# Unit test for method password of class Person
def test_Person_password():
    Person().password()


# Generated at 2022-06-23 21:43:10.211312
# Unit test for method views_on of class Person
def test_Person_views_on():
    v = Person().views_on()
    assert v in VIEWS_ON_VALUES

# Generated at 2022-06-23 21:43:11.968467
# Unit test for method height of class Person
def test_Person_height():
    height = Person(rnd=Random()).height()
    print(height)
    assert height



# Generated at 2022-06-23 21:43:13.575037
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    for site in SocialNetwork:
        profile = Person().social_media_profile(site=site)
        print(profile)

# Generated at 2022-06-23 21:43:15.998219
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person.views_on() in ['Neutral',
                                 'Positive',
                                 'Negative']
    
    

# Generated at 2022-06-23 21:43:18.190851
# Unit test for method password of class Person
def test_Person_password():
    faker = Person('ru')
    password = faker.password()
    assert isinstance(password, str)



# Generated at 2022-06-23 21:43:19.483590
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert Person().blood_type() in BLOOD_GROUPS


# Generated at 2022-06-23 21:43:22.627212
# Unit test for method surname of class Person
def test_Person_surname():
    # Create the object of class Person with default parameters
    person = Person()

    # Try to get random surname for second time
    surname1 = person.surname()
    surname2 = person.surname()

    # Check if surnames are not equal
    assert surname1 != surname2
    

# Generated at 2022-06-23 21:43:27.033704
# Unit test for method sex of class Person
def test_Person_sex():
    provider = Providers()
    person = Person(provider)
    result_1 = person.sex()
    assert result_1 in ('Male', 'Female', 'Not applicable', 'Not known')
    result_2 = person.sex(symbol=True)
    assert result_2 in ('♂', '♀', '⚧', '⚥')
    result_3 = person.sex(iso5218=True)
    assert result_3 in (0, 1, 2, 9)
test_Person_sex()

# Generated at 2022-06-23 21:43:32.176720
# Unit test for method telephone of class Person
def test_Person_telephone():
    def _assert_ok(n, m):
        if len(n) != len([i for i in m if i != '#']):
            raise ValueError('Number is not equal to mask.')

    # Create object of class Person
    p = Person()

    # Test calling the method telephone use default parameters
    n = p.telephone()
    _assert_ok(n, '#-###')

    # Test calling the method telephone use custom mask
    n = p.telephone(mask='###-####', placeholder='#')
    _assert_ok(n, '###-####')

# Generated at 2022-06-23 21:43:36.122409
# Unit test for method password of class Person
def test_Person_password():
    p = Person()
    # The following test must pass
    assert p.password(length=8, hashed=False) == 'k6dv2odff9#4h'



# Generated at 2022-06-23 21:43:46.613973
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    data = [
        (SocialNetwork.FACEBOOK, r'{}'),
        (SocialNetwork.GOOGLE, r'{}'),
        (SocialNetwork.LINKEDIN, r'{}'),
        (SocialNetwork.TWITTER, r'{}'),
        (SocialNetwork.VKONTAKTE, r'{}'),
        (SocialNetwork.OK_RU, r'{}'),
    ]
    for site, template in data:
        provider = Person(random=Random()).social_media_profile(site)
        assert re.fullmatch(template.format('[\w]{3,}'), provider) is not None
        assert provider.startswith('https://')


# Generated at 2022-06-23 21:43:48.638390
# Unit test for method gender of class Person
def test_Person_gender():
    assert len(Person().gender()) >= 2


# Generated at 2022-06-23 21:43:49.906305
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person(seed=3)
    assert p.identifier(mask='##-##/##') == '07-97/04'



# Generated at 2022-06-23 21:43:59.860572
# Unit test for method language of class Person
def test_Person_language():
    from faker import Faker
    from faker.providers.person import Provider
    import faker.providers.person.en_US
    import faker.providers.person.en_CA
    import faker.providers.person.en_GB
    import faker.providers.person.en_AU
    import faker.providers.person.es_ES
    import faker.providers.person.zh_TW
    import faker.providers.person.zh_CN
    import faker.providers.person.ja_JP
    import faker.providers.person.ja
    import faker.providers.person.ru
    import faker.providers.person.pt_BR
    import faker.providers.person.it_IT
    import faker.providers.person.fr_FR
   

# Generated at 2022-06-23 21:44:02.899127
# Unit test for method full_name of class Person
def test_Person_full_name():
    """
    #TODO: Need a validation
    """
    p = Person()
    p.seed(0)
    assert p.full_name() == 'Theresa Hicks'


# Generated at 2022-06-23 21:44:05.459418
# Unit test for method university of class Person
def test_Person_university():
    person_provider = Person()
    universities = person_provider._data['university']
    assert person_provider.university() in universities


# Generated at 2022-06-23 21:44:13.233523
# Unit test for method surname of class Person
def test_Person_surname():
    # Check that data is lowercase
    assert all([w.islower() for w in Person.surname(gender=Gender.male)])
    assert all([w.islower() for w in Person.surname(gender=Gender.female)])
    assert all([s.islower() for s in Person.surname(gender=Gender.not_known)])
    # Check that random choice returns different names
    male_surnames = set()
    female_surnames = set()
    for _ in range(100):
        male_surnames.add(Person.surname(gender=Gender.male))
        female_surnames.add(Person.surname(gender=Gender.female))
    assert len(male_surnames) > 10
    assert len(female_surnames) > 10
#

# Generated at 2022-06-23 21:44:22.323739
# Unit test for method occupation of class Person

# Generated at 2022-06-23 21:44:24.309011
# Unit test for method password of class Person
def test_Person_password():
    assert Person().password(length=10, hashed=True) == '1ac2f07bfb5966e9cc29a9b5a7026877'

# Generated at 2022-06-23 21:44:26.293775
# Unit test for method telephone of class Person
def test_Person_telephone():
    for _ in range(1000):
        tel = Person().telephone()
        print(tel)
        # print('Length of phone number:', len(tel))
test_Person_telephone()


# Generated at 2022-06-23 21:44:29.630070
# Unit test for method avatar of class Person
def test_Person_avatar():
    avatar = Person().avatar()
    assert avatar.startswith('https://api.adorable.io/avatars/')
    assert avatar.endswith('.png')
    size = 256
    avatar = Person().avatar(size)
    assert avatar.startswith('https://api.adorable.io/avatars/{}'.format(size))
    assert avatar.endswith('.png')

# Generated at 2022-06-23 21:44:33.877137
# Unit test for method first_name of class Person
def test_Person_first_name():
    r = Person()
    assert r.first_name() in r._data['name']['first_name'][Gender.Male]
    assert r.first_name(gender=Gender.Female) in r._data['name']['first_name'][Gender.Female]

# Generated at 2022-06-23 21:44:37.652739
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    gen = Generator()
    orientations = ['Heterosexuality', 'Bisexuality', 'Homosexuality',
                    'Asexuality', 'Pansexuality', 'Polysexuality']
    assert gen.person().sexual_orientation() in orientations


# Generated at 2022-06-23 21:44:47.831319
# Unit test for method identifier of class Person
def test_Person_identifier():
    provider = Person()
    assert re.match(r"\d{2}-\d{2}/\d{2}", provider.identifier("##-##/##"))
    assert provider.identifier("@@-@@/@@")


    """
    Generate a random enum object.

    :param enum_obj: Enum object.
    :param rnd: Random object.
    :return: A random enum member.
    :raises TypeError: if enum_obj is not an Enum.
    """
    if not isinstance(enum_obj, Enum):
        raise TypeError("enum_obj must be an Enum")

    if rnd is None:
        rnd = random
    return enum_obj(rnd.randint(1, len(enum_obj))).name



# Generated at 2022-06-23 21:44:49.321684
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name() == Person().surname()

# Generated at 2022-06-23 21:45:01.751623
# Unit test for method university of class Person
def test_Person_university():
    person = Person(1)

# Generated at 2022-06-23 21:45:03.779448
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    f_name = person.first_name()
    assert isinstance(f_name, str)

# Generated at 2022-06-23 21:45:09.805697
# Unit test for method first_name of class Person
def test_Person_first_name():
    def __test(gender, ans):
        names = get_names(gender)
        assert ans in names
        assert Person.first_name(gender) in names

    __test('male', 'Петр')
    __test('female', 'Ульяна')
    __test(Gender.MALE, 'Петр')
    __test(Gender.FEMALE, 'Ульяна')

# Test for method surname

# Generated at 2022-06-23 21:45:11.285267
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person(seed=0)
    assert person.first_name() == 'Cecil'


# Generated at 2022-06-23 21:45:15.471094
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    s = person.social_media_profile()
    print(s)

# Testing method social_media_profile
if __name__ == "__main__":
    test_Person_social_media_profile()


# Generated at 2022-06-23 21:45:24.458162
# Unit test for method weight of class Person
def test_Person_weight():
    years = [20, 50]
    gens = [Gender.MALE, Gender.FEMALE]
    assert Person.weight(20) in range(20, 50)
    assert Person.weight(50) in range(20, 50)
    assert Person.weight(gens[0]) in range(20, 50)
    assert Person.weight(gens[1]) in range(20, 50)
    assert Person.weight(years[0], gens[0]) in range(20, 50)
    assert Person.weight(years[1], gens[1]) in range(20, 50)
    assert Person.weight(*years, *gens) in range(20, 50)
    assert Person.weight(50, 50, 50, 50) in range(50, 90)

# Generated at 2022-06-23 21:45:26.129871
# Unit test for method worldview of class Person
def test_Person_worldview():
    # Create object of class Person
    person = Person()
    # Call the method worldview
    worldview = person.worldview()
    # Check the type of the variable worldview
    assert isinstance(worldview, str), "worldview is not a instance of str"

# Generated at 2022-06-23 21:45:32.937764
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():

    from collection.enum.social_network import SocialNetwork
    from collection.enum.gender import Gender

    p = Person()

    for i in range(100):

        profile = p.social_media_profile()

        if 'facebook' in profile:
            assert profile.startswith('https://facebook.com/')

        if 'twitter' in profile:
            assert profile.startswith('https://twitter.com/')

        if 'instagram' in profile:
            assert profile.startswith('https://instagram.com/')

        if 'linkedin' in profile:
            assert profile.startswith('https://linkedin.com/in/')

        if 'pinterest' in profile:
            assert profile.startswith('https://pinterest.com/')


# Generated at 2022-06-23 21:45:35.993547
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    email = p.email()
    assert re.match(r'^.+@.+$', email)



# Generated at 2022-06-23 21:45:46.731386
# Unit test for method email of class Person
def test_Person_email():
    from frandom.text import LoremIpsum
    from frandom.numbers import RandomInt
    from frandom.adapters import RangeAdapter
    from frandom.adapters import RandomItemAdapter

    rnd = RandomInt

    result = rnd(min=5, max=5).run()
    assert result == 5

    result = RangeAdapter(rnd, min=5, max=10).run()
    assert result in range(5, 10)
    
    result = RandomItemAdapter(rnd, items=(1, 2, 3, 4)).run()
    assert result in (1, 2, 3, 4)

    result = LoremIpsum(words_count=1).run()
    assert result == 'Lorem'


# Generated at 2022-06-23 21:45:51.199612
# Unit test for constructor of class Person
def test_Person():
    p = Person(lang='ru', region='RU')
    assert isinstance(p, Person)
    assert p.lang == 'ru'
    assert p.region == 'RU'



# Generated at 2022-06-23 21:45:56.973965
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    for i in range(100):
        assert PersonProvider().sexual_orientation() in (
            "Lesbianism",
            "Bisexuality",
            "Heterosexuality",
            "Homosexuality",
            "Asexuality",
            "Pansexuality",
            "Polysexuality",
            "Androgyny",
            "Polyamory",
        )



# Generated at 2022-06-23 21:46:00.784000
# Unit test for method political_views of class Person
def test_Person_political_views():
    Person._data['political_views'] = ('Yes', 'No', 'Maybe')

    for _ in range(1000):
        test = str(Person().political_views())
        assert test == 'Yes' or test == 'No' or test == 'Maybe'

# Generated at 2022-06-23 21:46:10.055410
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    class_name = 'Person'
    method_name = 'work_experience'
    class_obj = Person()
    assert hasattr(class_obj, method_name),\
        "Method {} not found in class {}".format(method_name, class_name)
    work_experience = class_obj.work_experience()
    assert type(work_experience) == str,\
        "Method {} in class {} returns not a str type".format(method_name, class_name)
    assert len(work_experience) > 0,\
        "Method {} in class {} not return anything".format(method_name, class_name)
    assert work_experience in WORK_EXPERIENCE.values(),\
        "Method {} in class {} returns wrong value".format(method_name, class_name)

# Generated at 2022-06-23 21:46:10.681331
# Unit test for method height of class Person
def test_Person_height():
    pass

# Generated at 2022-06-23 21:46:12.998359
# Unit test for method views_on of class Person
def test_Person_views_on():
    """Test method views_on."""
    assert isinstance(Person().views_on(), str)

# Generated at 2022-06-23 21:46:15.090760
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    generator = Person()
    assert isinstance(generator.blood_type(), str)

# Generated at 2022-06-23 21:46:17.716402
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert isinstance(Person().last_name(), str)

# Generated at 2022-06-23 21:46:21.156410
# Unit test for method sex of class Person
def test_Person_sex():

    # Initialization of provider
    provider = Provider()

    # Generating the sex
    sex = provider.sex()

    # Checking by assert
    assert(sex in provider.data('gender'))


# Generated at 2022-06-23 21:46:23.004331
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()[-13:] == '@gmail.com'

# Generated at 2022-06-23 21:46:26.268373
# Unit test for method occupation of class Person
def test_Person_occupation():
    for num in range(100):
        job = Person.occupation()
        assert (job in JOBS), str(job) + " not in JOBS"


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 21:46:32.474109
# Unit test for method weight of class Person
def test_Person_weight():
    from random import Random
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis import assume, settings

    @given(integers(min_value=38, max_value=90))
    @settings(max_examples=100)
    def test_weight(randomseed, max_value, min_value):
        assume(max_value >= 38)
        assume(min_value <= 90)
        rnd = Random()
        rnd.seed(randomseed)
        provider = Person(random=rnd)
        result = provider.weight(minimum=min_value, maximum=max_value)
        assert min_value <= result <= max_value

    test_weight()

# Generated at 2022-06-23 21:46:39.065737
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Default
    assert Person().telephone()

    # With country code
    assert Person().telephone(mask='+7##########')

    # Custom mask
    assert Person().telephone(mask='#######')

    # Custom placeholder
    assert Person().telephone(mask='########', placeholder='#')
    assert Person().telephone(mask='+++++', placeholder='+')

    # No digits in mask
    assert not Person().telephone(mask='-')

    # Custom mask but no digits in source data
    assert not Person().telephone(mask='+7-(###)-###-####')



# Generated at 2022-06-23 21:46:48.879913
# Unit test for method weight of class Person
def test_Person_weight():
    import pytest
    from fake_useragent import FakeUserAgent
    from pprint import pprint

    ua = FakeUserAgent()
    headers = {'User-Agent': ua.random}

    print(headers)
    print(ua.random)
    print(ua.chrome)
    print(ua.firefox)
    print(ua.opera)
    print(ua.internetexplorer)
    print(ua.random)
    print(ua.random)
    print(ua.random)

    assert 1 == 1

if __name__ == '__main__':
    test_Person_weight()
 
# You should not edit this code

# Generated at 2022-06-23 21:46:51.836969
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Test Person().telephone() method"""
    pr = Person(seed=1947)

    assert pr.telephone() == '+7-(987)-618-58-13'


# Generated at 2022-06-23 21:46:55.843540
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    assert p.sexual_orientation() in ['Bisexuality', 'Exhibitionism', 'Heterosexuality', 'Homosexuality', 'Transgenderism']


# Generated at 2022-06-23 21:46:59.617557
# Unit test for method nationality of class Person
def test_Person_nationality():
        p = Person()
        a = p.nationality()
        check = a in p._data['nationality']
        if not check:
            print('Error in method nationality in class Person')
        assert check
        

# Generated at 2022-06-23 21:47:02.279171
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert email
    print('Randoom email: {}'.format(email))

# Generated at 2022-06-23 21:47:04.634391
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert isinstance(person.email(), str) is True
"test_Person_email function passed"

# Generated at 2022-06-23 21:47:07.524308
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    assert person.full_name()
    assert person.full_name(Gender.MALE)
    assert person.full_name(Gender.FEMALE)


# Generated at 2022-06-23 21:47:12.063789
# Unit test for method password of class Person
def test_Person_password():
    # Test 1
    rng = Faker.create('ru_RU')
    result = rng.random.password()
    assert len(result) == 8
    assert any(c in ascii_letters for c in result)
    assert any(c in digits for c in result)
    assert any(c in punctuation for c in result)

# Generated at 2022-06-23 21:47:13.576509
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert Person(Language.RU, 'en_US').blood_type() in BLOOD_GROUPS

# Generated at 2022-06-23 21:47:16.167053
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    person = Person()

    # Act
    result = person.nationality()

    # Assert
    assert result in PERSON_NATIONALITIES

# Generated at 2022-06-23 21:47:17.533106
# Unit test for method password of class Person
def test_Person_password():
    obj = Person()
    assert type(obj.password()) is str

# Generated at 2022-06-23 21:47:21.591520
# Unit test for method password of class Person
def test_Person_password():
    test_Person_password.count += 1
    person = Person()
    assert person.password(length=20) == person.password(length=20)
    
test_Person_password.count = 0
print(f"{test_Person_password.__name__} - {test_Person_password.count}")


# Generated at 2022-06-23 21:47:24.423801
# Unit test for method nationality of class Person
def test_Person_nationality():
    cases = [
        (None, 'Russian'),
    ]
    for gender, expected in cases:
        actual = Person.nationality(gender)
        assert actual == expected

# Generated at 2022-06-23 21:47:30.241668
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person()
    print(provider.social_media_profile(SocialNetwork.twitter))
    # https://twitter.com/xm1e0dgwv
    # https://twitter.com/k.mclaughlin
    # https://twitter.com/ksmith
    # https://twitter.com/4h4jD9ieE
    # https://twitter.com/g.page
    # https://twitter.com/boothj
    # https://twitter.com/green



# Generated at 2022-06-23 21:47:31.678070
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p.work_experience()

# Generated at 2022-06-23 21:47:38.428782
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(100):
        seed = random.randint(0, 999999999)
        person = Person(seed=seed)
        email_address = person.email(unique=False)
        assert len(email_address) > 6
        assert email_address.count('@') == 1
        assert email_address.count('.') == 1
        assert email_address[-4] == '.'
        assert email_address[:email_address.index('@')].count('.') == 0


# Generated at 2022-06-23 21:47:45.188908
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    name = person.name()
    assert isinstance(name, str)
    assert len(name) > 2

    for i in range(50):
        name = person.name(gender=Gender.MALE)
        assert isinstance(name, str)
        assert len(name) > 2
        assert name[0] in 'АВЕЁКМНОРСТУХ'

        name = person.name(gender=Gender.FEMALE)
        assert isinstance(name, str)
        assert len(name) > 2
        assert name[0] in 'АВЕЁКМНОРСТУХ'


# Generated at 2022-06-23 21:47:46.784070
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    sex = person.sex()

    assert isinstance(sex, str)
    assert sex in u.PERSON_DATA['gender']

# Generated at 2022-06-23 21:47:50.400885
# Unit test for method sex of class Person
def test_Person_sex():
    firm = Faker()
    fake = firm.person()

    assert fake.sex() in GENDER_SYMBOLS
    assert fake.sex() in SEXUALITY_SYMBOLS


# Generated at 2022-06-23 21:47:53.931924
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert (Person().sexual_orientation() in SEXUALITY)
    assert (Person().sexual_orientation(symbol=True) in SEXUALITY_SYMBOLS)

# Generated at 2022-06-23 21:47:57.323746
# Unit test for method avatar of class Person
def test_Person_avatar():
    def test_avatar_size():
        p = Person(random=Random())
        size = 256
        assert len(p.avatar(size=size)) == 96

    test_avatar_size()

# Generated at 2022-06-23 21:48:03.103503
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert(Person().political_views() in ('Liberal', 'Socialism', 'Communism',
                                          'Centrism', 'Conservatism', 'Monarchism',
                                          'Anarchism', 'Fascism', 'Left-wing',
                                          'Right-wing'))
    assert(len(set(Person().political_views() for i in range(100))) > 1)



# Generated at 2022-06-23 21:48:05.906929
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    height = person.height()
    assert isinstance(height, str), "Incorrect type."
    assert len(height) == 4, "Incorrect output."



# Generated at 2022-06-23 21:48:12.526295
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person(random)
    assert isinstance(p.weight(), int)
    assert isinstance(p.weight(maximum=100), int)
    assert 1<=p.weight(maximum=100)<=100
    assert isinstance(p.weight(minimum=10, maximum=100), int)
    assert 10<=p.weight(minimum=10, maximum=100)<=100


# Generated at 2022-06-23 21:48:14.544272
# Unit test for method telephone of class Person
def test_Person_telephone():
    assert Person().telephone()[0] == '+'
    assert Person().telephone()[1].isdigit()

# Generated at 2022-06-23 21:48:16.703788
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    result = person.views_on()
    assert isinstance(result, str)
    assert result in PERSON_DATA['views_on']
    
    

# Generated at 2022-06-23 21:48:18.849064
# Unit test for method weight of class Person
def test_Person_weight():
    print(Person().weight())
    print(Person().weight(minimum=20))
    print(Person().weight(minimum=20, maximum=70))  

# Generated at 2022-06-23 21:48:22.736238
# Unit test for method age of class Person
def test_Person_age():
    for _ in range(1000):
        min_age = random.randint(0, 100)
        max_age = random.randint(1, 101)
        age = Person().age(min_age, max_age)
        assert isinstance(age, int)
        assert min_age <= age <= max_age

# Generated at 2022-06-23 21:48:24.108314
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()

    assert p.last_name() in p._data['surname']



# Generated at 2022-06-23 21:48:25.593362
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person()
    assert person.identifier().isdigit()


# Generated at 2022-06-23 21:48:29.528006
# Unit test for method weight of class Person
def test_Person_weight():
    obj = Person(random=Random(47))
    assert obj.weight(minimum=38, maximum=90) == 42

# Generated at 2022-06-23 21:48:32.384811
# Unit test for method political_views of class Person
def test_Person_political_views():
    obj = Person()
    result = obj.political_views()
    assert isinstance(result, str)
    assert len(result) >= 1


# Generated at 2022-06-23 21:48:36.592095
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    from faker_wisdom import Wisdom
    from faker_wisdom.enums import Gender

    faker = Faker("en_US")
    faker.add_provider(Wisdom(faker))
    result = faker.surname(gender=Gender.FEMALE)
    assert result in WisdomProvider._data['surname'][Gender.FEMALE]
    print(result)

# Generated at 2022-06-23 21:48:38.670397
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    assert isinstance(person.sex(), str)


# Generated at 2022-06-23 21:48:39.745066
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in GENDERS

# Generated at 2022-06-23 21:48:42.806435
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    """Unit test for method academic_degree of class Person."""
    person = Person(seed=0)

    assert person.academic_degree() == u'PhD'


# Generated at 2022-06-23 21:48:44.441436
# Unit test for method name of class Person
def test_Person_name():
    for gender in Gender:
        for n in range(10):
            name = Person.name(gender=gender)
            assert isinstance(name, str)
            assert gender.value in name


# Generated at 2022-06-23 21:48:50.002010
# Unit test for method age of class Person
def test_Person_age():
    # We check if age returns a number
    assert isinstance(Person().age(16, 33), int) 
    # We check the minimum age
    assert Person().age(16, 16) == 16
    # We check the maximum age
    assert Person().age(100, 100) == 100

# Generated at 2022-06-23 21:48:51.016266
# Unit test for method age of class Person
def test_Person_age():
    print(Person.age())


# Generated at 2022-06-23 21:48:59.046630
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert 'U6OwdL' == Person().full_name(None, False)
    assert 'o5ypQ6 SL1D' == Person().full_name(None, True)
    assert 'W5bY3q' == Person().full_name(Gender.MALE, False)
    assert 'm5bvzD f5WYk' == Person().full_name(Gender.FEMALE, True)

# Generated at 2022-06-23 21:49:05.980843
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():

    from fake_data.locales.ru_ru import RUProvider
    from fake_data.enums import Gender
    from fake_data.main import FakeData
    from fake_data.person import Person

    provider = RUProvider()
    fake_data = FakeData(provider)
    person = Person(fake_data)
    assert person.academic_degree() in provider.data['academic_degree']

test_Person_academic_degree()


# Generated at 2022-06-23 21:49:10.656484
# Unit test for method password of class Person
def test_Person_password():
    p = Person(seed=42)
    assert p.password(3, False) == '*#K'
    assert p.password(2, True) == '95a6179b99d7dcf8d9a6c9bac95c86fd'


# Generated at 2022-06-23 21:49:17.333781
# Unit test for method identifier of class Person
def test_Person_identifier():
    provider = Person()
    assert provider.identifier()
    assert provider.identifier('#')
    assert provider.identifier('@')
    assert provider.identifier('##-##/##')
    assert provider.identifier('##-##/@@')
    assert provider.identifier('##-##/##', placeholder='@')
    assert provider.identifier('##-##/@@', placeholder='@')
    assert re.match(r'^\d{2}-\d{2}/\d{2}$', provider.identifier())
    assert re.match(r'^\d{2,3}$', provider.identifier(mask='#'))
    assert re.match(r'^([a-zA-Z]+)$', provider.identifier(mask='@'))

# Generated at 2022-06-23 21:49:29.251564
# Unit test for method name of class Person
def test_Person_name():
    assert Person.name(lang='ru') == 'Хелале'
    assert Person.name(lang='en') == 'Sarita'
    
    assert Person.name(lang='ru', gender=Gender.MALE) == 'Никита'
    assert Person.name(lang='ru', gender=Gender.FEMALE) == 'Елена'
    
    assert Person.name(lang='en', gender=Gender.MALE) == 'Jarvis'    
    assert Person.name(lang='en', gender=Gender.FEMALE) == 'Shine'
    
    assert Person.name(lang='ru', reverse=True) == 'Захар'
    assert Person.name(lang='en', reverse=True) == 'Clarissa'
    

# Generated at 2022-06-23 21:49:32.592696
# Unit test for method avatar of class Person
def test_Person_avatar():
    """Test method Person.avatar()."""
    person = Person()
    avatar = person.avatar()
    assert avatar.startswith('https://api.adorable.io/avatars/256/')
    assert avatar.endswith('.png')

# Generated at 2022-06-23 21:49:34.622333
# Unit test for method occupation of class Person
def test_Person_occupation():
    a = Person()
    assert a.occupation() in Person._data.get('occupation')

# Generated at 2022-06-23 21:49:40.060919
# Unit test for method title of class Person
def test_Person_title():
    tester = Person()

    def title(gender: Optional[Gender],
              title_type: Optional[TitleType]) -> str:
        return tester.title(gender=Gender.male,
                            title_type=TitleType.prefix)
    tester.run_test(title, Gender, TitleType, arg_name='gender')

# Generated at 2022-06-23 21:49:42.989142
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = Person()
    assert 1
    assert type(provider.last_name()) == str
    assert provider.last_name() != None

# Generated at 2022-06-23 21:49:44.390809
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() != p.email()



# Generated at 2022-06-23 21:49:46.955103
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in SURNAMES


# Generated at 2022-06-23 21:49:48.824391
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person().political_views() in Person()._data['political_views']
import random
from random import randint

# Generated at 2022-06-23 21:49:51.174783
# Unit test for method weight of class Person
def test_Person_weight():
    for _ in range(100):
        assert(1 <= Person().weight(minimum=1, maximum=100) <= 100)

# Generated at 2022-06-23 21:49:55.606121
# Unit test for method surname of class Person
def test_Person_surname():
    from pydbgen import pydbgen
    get_name = pydbgen.pydb()
    db = get_name.get_person()
    for i in range(5):
        assert isinstance(db.surname(), str)

# Generated at 2022-06-23 21:49:57.347156
# Unit test for method age of class Person
def test_Person_age():
    x = Person() #create an instance
    assert -1 < x.age() < 140


# Generated at 2022-06-23 21:50:08.608600
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    try:
        # Make instance of class Person
        person = Person(seed=42)

        result = person.social_media_profile(site="Facebook")
        assert result == 'https://facebook.com/kV7RxP'
    except AssertionError as error:
        print("Test \"test_Person_social_media_profile\" FAILED")
        print("\tExpected result: 'https://facebook.com/kV7RxP'")
        print("\tObtained result:", result)
        print("\tError:", error)
    else:
        print("Test \"test_Person_social_media_profile\" PASSED")
# Run unit test
test_Person_social_media_profile()


# Generated at 2022-06-23 21:50:10.497216
# Unit test for method sex of class Person
def test_Person_sex():
    d = Locale({})
    p = Person(d)
    print(type(p.sex()))


# Generated at 2022-06-23 21:50:23.079388
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    # Максимальное значение можно задать
    assert p.weight(maximum = 50) <= 50
    # Минимальное значение можно задать
    assert p.weight(minimum = 1) >= 1
    # Можно задать диапазон значений
    assert p.weight(minimum = 1, maximum = 10) >= 1
    assert p.weight(minimum = 1, maximum = 10) <= 10
    # Если минимум б

# Generated at 2022-06-23 21:50:32.094377
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    from random import seed
    from unittest import TestCase

    from faker.generator import Generator
    from faker.providers.person.en_US import Provider as PersonProvider

    class TestPersonUS(TestCase):
        def setUp(self):
            self.factory = Generator
            self.ratio = 1.0

        def test_sexual_orientation(self):
            for _ in range(100):
                obj = self.factory.create(self.factory.create_format('en_US'))
                assert obj.eyecolor() in PERSON_EYES


# Generated at 2022-06-23 21:50:36.141816
# Unit test for method gender of class Person
def test_Person_gender():
    """Unit test for method Person.gender.

    :return: None
    """
    random.seed(0)
    gender = Person(seed=0).gender()
    # Check the result of method gender
    assert gender == 'Male'
    return gender



# Generated at 2022-06-23 21:50:40.717972
# Unit test for method password of class Person
def test_Person_password():
    rnd = Random()
    rnd.seed(0)
    person = Person(rnd)
    assert person.password(8, False) == 'k6dv2odff9#4h'
    assert person.password(8, True) == 'a0b6d7c6d9225236a8b6f03fc3e08c9e'


# Generated at 2022-06-23 21:50:45.243919
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    assert person.avatar() == 'https://api.adorable.io/avatars/256/7355a1028d2e7e0d6f9ed72ca99cbfb7.png'

# Generated at 2022-06-23 21:50:55.703401
# Unit test for method political_views of class Person
def test_Person_political_views():
    political_views = [
        Person.political_views()
        for _ in range(1000)
    ]
    assert political_views

    assert 'Communism' in political_views
    assert 'Socialism' in political_views
    assert 'Liberalism' in political_views
    assert 'Anarchism' in political_views
    assert 'Fascism' in political_views
    assert 'Nazism' in political_views
    assert 'Conservatism' in political_views
    assert 'Agrarianism' in political_views
    assert 'Capitalism' in political_views
    assert 'Republicanism' in political_views
    assert 'Anarchism' in political_views
    assert 'Totalitarianism' in political_views
    assert 'Statism' in political_views
    assert 'Monarchism' in political_views

# Generated at 2022-06-23 21:50:59.128806
# Unit test for method political_views of class Person
def test_Person_political_views():
    """
    Will create a instance of class Person
    and check that values in the political_views
    are not empty
    """
    provider = Person.create_class()

    for value in provider.political_views():
        assert len(value) > 0
