

# Generated at 2022-06-23 21:41:04.146187
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    import pytest
    from faker import Faker
    f = Faker()
    f.seed(0)
    expected = 'https://www.facebook.com/johnsontheodore'
    actual = f.social_media_profile(SocialNetwork.FACEBOOK)
    assert actual == expected
    assert f.social_media_profile() in SOCIAL_NETWORKS.values()
    assert f.social_media_profile(SocialNetwork.VKONTAKTE) == 'https://vk.com/abigailgracia'
    with pytest.raises(ValueError):
        f.social_media_profile(SocialNetwork.TWITTER)

# Generated at 2022-06-23 21:41:05.605898
# Unit test for method first_name of class Person
def test_Person_first_name():
    import random
    person = Person(random)
    person.first_name()


# Generated at 2022-06-23 21:41:08.203577
# Unit test for method height of class Person
def test_Person_height():
    p = Provider(localization=Localization.RU)
    result = p.height()
    assert isinstance(result, str)
    assert len(result) == 4

# Generated at 2022-06-23 21:41:10.869675
# Unit test for method language of class Person
def test_Person_language():
    d = Person.language()
    print(d)
    assert d in Person._data["language"]

test_Person_language()


# Generated at 2022-06-23 21:41:15.285360
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname(Gender.MALE) in SURNAME_MALE
    assert Person().surname(Gender.FEMALE) in SURNAME_FEMALE
    assert Person().surname() in SURNAME_MALE


# Generated at 2022-06-23 21:41:21.789380
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person(seed=1)
    worldview = person.worldview()
    assert(worldview == 'Pantheism')

    person = Person(seed=2)
    worldview = person.worldview()
    assert(worldview == 'Agnosticism')

    person = Person(seed=3)
    worldview = person.worldview()
    assert(worldview == 'Spiritualism')


# Generated at 2022-06-23 21:41:25.381605
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person(seed=0x1234, locale='ru')
    # person.academic_degree()
    assert person.academic_degree() == "Магистр"

# Generated at 2022-06-23 21:41:29.724575
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    person = Person()

    # Act
    actual_output = person.nationality()

    # Assert
    assert isinstance(actual_output, str)
    assert actual_output != ''


# Generated at 2022-06-23 21:41:32.453852
# Unit test for method first_name of class Person
def test_Person_first_name():
    genders = [x.name for x in Gender]
    assert isinstance(Person().first_name(), str)
    assert Person().first_name().split()[-1] in genders

# Generated at 2022-06-23 21:41:39.796450
# Unit test for method avatar of class Person
def test_Person_avatar():
    from faker_test.test_case import MyTestCase
    from faker import Faker
    faker = Faker()

    for _ in range(100):
        url = faker.avatar()
        assert url.startswith('https://api.adorable.io/avatars/')

    for _ in range(100):
        url = faker.avatar(32)
        assert url.startswith('https://api.adorable.io/avatars/32/')
        assert url.endswith('.png')

    for _ in range(100):
        url = faker.avatar(94)
        assert url.startswith('https://api.adorable.io/avatars/94/')
        assert url.endswith('.png')


# Generated at 2022-06-23 21:41:41.606406
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test for method nationality
    for i in range(100):
        nationality = Person().nationality()
        assert isinstance(nationality, str)
        assert nationality in NATIONALITIES


# Generated at 2022-06-23 21:41:43.985970
# Unit test for method nationality of class Person
def test_Person_nationality():
    obj = Person()
    expected = 'Russian'
    result = obj.nationality()
    
    assert result == expected

# Generated at 2022-06-23 21:41:46.832801
# Unit test for method nationality of class Person
def test_Person_nationality():
    random = Random()
    person = Person(random=random)
    for _ in range(100):
        assert type(person.nationality()) is str
        

# Generated at 2022-06-23 21:41:51.716857
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Пример создания экземпляра класса Person
    person = Person()
    # Генерируем случайное количество опыта работы
    print(person.work_experience())


# Generated at 2022-06-23 21:41:53.446785
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    blood_type = person.blood_type()
    assert blood_type in BLOOD_GROUPS



# Generated at 2022-06-23 21:41:55.248413
# Unit test for method university of class Person
def test_Person_university():
    for i in range(0, 100):
        res = Person.university()
        assert isinstance(res, str)
        

# Generated at 2022-06-23 21:41:57.929371
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    result = person.university()

# Generated at 2022-06-23 21:42:01.558440
# Unit test for method sex of class Person
def test_Person_sex():
    """Test method Person.sex()"""
    assert Person().sex(symbol=True) in GENDER_SYMBOLS
    assert Person().sex() in Person()._data['gender']


# Generated at 2022-06-23 21:42:04.351046
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    telephone = person.telephone(mask='+7 (###) ### ## ##')
    assert len(telephone) == 15
    assert telephone[:4] == '+7 ('
    assert telephone[4] == ' '
    assert telephone[8] == ' '
    assert telephone[12] == ' '


# Generated at 2022-06-23 21:42:05.254820
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in VIEWS_ON


# Generated at 2022-06-23 21:42:07.582414
# Unit test for method surname of class Person
def test_Person_surname():
    with pytest.raises(NonEnumerableError):
        Person(random).surname(Gender.MALE.name)


# Generated at 2022-06-23 21:42:08.564699
# Unit test for method age of class Person
def test_Person_age():
    pr = Person()
    result = pr.age(minimum=15, maximum=25)
    assert 0 < result < 25


# Generated at 2022-06-23 21:42:17.916493
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    political_views = person.political_views()

    assert_that(political_views).is_in(["Liberal", "Conservatism", "Communism", "Socialism", "Autocracy", "Fascism", "Anarchism", "Ecologism", "Pacifism", "Atheism", "Theism", "Agnosticism", "Paganism", "Afrocentrism", "Altruism", "Misanthropism", "Nihilism", "Antimilitarism", "Capitalism", "Nationalism", "Neutral", "Neoconservatism", "Neoliberalism", "Neolibertarianism", "Neolocalism", "Neopacifism", "Neopaganism", "Neoprimitivism", "Neopsychology", "Neosocialism"])


# Generated at 2022-06-23 21:42:20.310933
# Unit test for method worldview of class Person
def test_Person_worldview():
    # Check that a random worldview is returned
    p = Person(random)
    beliefs = p.worldview()
    assert beliefs in worldviews



# Generated at 2022-06-23 21:42:31.104464
# Unit test for method worldview of class Person
def test_Person_worldview():
    wv = set()
    for _ in range(100):
        wv.add(Person.create().worldview())
    assert wv == {
        'Agnosticism', 'Atheism', 'Buddhism', 'Confucianism', 'Deconstructionism',
        'Deism', 'Empiricism', 'Existentialism', 'Fideism', 'Humanism', 'Idealism',
        'Judaism', 'Linguistic', 'Logical positivism', 'Materialism', 'Mysticism',
        'Pantheism', 'Phenomenology', 'Platonism', 'Rationalism', 'Scholasticism',
        'Stoicism', 'Transcendentalism', 'Tritheism', 'Vedism', 'Vitalism', 'Zoroastrianism',
    }


# Generated at 2022-06-23 21:42:35.239273
# Unit test for method views_on of class Person
def test_Person_views_on():
    global _Person__Person__views_on
    assert _Person__Person__views_on is not None
    assert type(_Person__Person__views_on) is list
    assert len(_Person__Person__views_on) > 0


# Generated at 2022-06-23 21:42:44.032767
# Unit test for method gender of class Person
def test_Person_gender():
    from hypothesis import given
    from hypothesis.strategies import sampled_from, integers
    
    p = Person()
    
    @given(sampled_from(Person.SEX))
    def test_Person_gender_1(gender):
        assert p.sex(gender).lower() == gender.name.lower()
        
    @given(integers(min_value=0, max_value=1))
    def test_Person_gender_2(code):
        assert p.sex(code).lower() == p.GENDER_ISO5218[code]
        
    @given(integers(min_value=0, max_value=1))
    def test_Person_gender_3(code):
        assert p.sex(code, symbol=True) == p.GENDER_SYMBOLS[code]
        return

# Generated at 2022-06-23 21:42:45.304739
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    telephone = person.telephone()
    assert isinstance(telephone, str)

# Generated at 2022-06-23 21:42:54.432026
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person().work_experience('Programmer', date(1990, 1, 1)) == '1990'
    assert Person().work_experience('Programmer', date(1990, 1, 1), date(2020, 1, 1)) == '30'
    assert Person().work_experience('Programmer', date(2020, 1, 1)) == '2020'
    assert Person().work_experience('Programmer', date(2020, 1, 1), date(2020, 1, 1)) == '2020'
    assert Person().work_experience('Programmer', date(1989, 1, 1), date(2020, 1, 1)) == '31'
    assert Person().work_experience('Programmer', date(1990, 1, 1), date(2021, 1, 1)) == '31'

# Generated at 2022-06-23 21:42:58.143359
# Unit test for method email of class Person
def test_Person_email():
    r_seed = 1017
    person = Person(r_seed)
    correct = 'sbormann943@gmail.com'
    test_email = person.email()
    assert_equal(correct, test_email)



# Generated at 2022-06-23 21:43:06.782512
# Unit test for constructor of class Person
def test_Person():
    from datetime import datetime, timezone
    from fake_ocean import Seed, Fake

    # Create a fake number generator with a fixed seed
    seed = Seed(fixed=123)
    fake = Fake(seed)

    # Create an instance of Person
    person = Person(random=fake)

    assert person.name() == 'Corina'
    assert person.surname() == 'Beyer'
    assert person.name(Gender.FEMALE) == 'Corina'
    assert person.surname(Gender.FEMALE) == 'Beyer'

    assert person.birthdate() == datetime(1972, 11, 11, tzinfo=timezone.utc)

# Generated at 2022-06-23 21:43:15.983944
# Unit test for method title of class Person
def test_Person_title():
    assert Person().title(title_type=TitleType.PREFIX) in ('Miss', 'Dr.',
                                                           'Prof.', 'Mr.',
                                                           'Mrs.', 'Ms.')
    assert Person().title(title_type=TitleType.SUFFIX) in ('I', 'II', 'III',
                                                           'Jr.', 'Sr.', 'IV',
                                                           'V', 'VI', 'VII')
    assert Person().title(gender=Gender.MALE, title_type=TitleType.PREFIX) in (
        'Mr.', 'Mr.', 'Prof.', 'Dr.')

# Generated at 2022-06-23 21:43:23.115421
# Unit test for method email of class Person
def test_Person_email():
    # Seed generating random to get the same result every time
    # More info on https://pypi.org/project/Faker/#fakerseed-alias-randomseed
    faker.Faker.seed(0)

    # Create a fake object by passing a dictionary
    fake = faker.Faker({'email': 'fake@example.com'})

    # Create another fake object by passing a JSON string of the dictionary
    fake = faker.Faker('{"email": "fake@example.com"}')
 
    # Create another fake object by passing an JSON file
    with open('myjsonfile.json', 'r', encoding='utf-8') as f:
        fake = faker.Faker(f)


# Generated at 2022-06-23 21:43:24.580692
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    assert p.weight(38, 90) <= 90 and p.weight(38, 90) >= 38

# Generated at 2022-06-23 21:43:27.614953
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    result = provider.email()
    assert '@' in result
    assert '.' in result
    assert len(result.split("@")) == 2
    assert len(result.split(".")) == 2
    assert len(result) > 7

print("Email: ",test_Person_email())


# Generated at 2022-06-23 21:43:30.976066
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person.create().gender() in ['Male', 'Female']
    assert Person.create().gender(symbol=True) in [chr(127903), chr(127904)]
    assert Person.create().gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-23 21:43:34.648832
# Unit test for method first_name of class Person
def test_Person_first_name():
    provider = Generator()
    person = Person(provider)
    # Correct result
    assert isinstance(person.first_name(Gender.MALE), str)
    # Incorrect result
    assert person.first_name(12) is None
    assert person.first_name(Gender.MALE, 'string') is None
    assert person.first_name() is None

test_Person_first_name()

# Generated at 2022-06-23 21:43:41.441253
# Unit test for method password of class Person
def test_Person_password():
    obj = Person()
    obj.seed(0)
    assert obj.password(length=5, hashed=False) == '8J#gR'
    assert obj.password(length=5, hashed=True) == 'ea1e50f3a3d75f3c9f61bff7f2daf4d4'



# Generated at 2022-06-23 21:43:49.320576
# Unit test for method name of class Person
def test_Person_name():
    names = Person().name()
    assert names in (
        'Galina',
        'Ирина',
        '静',
        '가지란',
        'นันทนา',
        'ᑎᓐᓂᐊ',
        'آلبرت',
        'بير',
        'הדוגמה',
        'ប្អូន',
        'สระอยุธยา',
        'კახა',
    )

# Generated at 2022-06-23 21:43:52.659668
# Unit test for method height of class Person
def test_Person_height():
    p = Person('fake')
    assert p.height()
    # assert type(p.height()) == str
    # assert re.match(r'^[1-9]', p.height())


# Generated at 2022-06-23 21:43:54.650304
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    from faker import Faker
    fake = Faker()
    res = fake.academic_degree()
    assert isinstance(res, str)
    assert len(res.strip()) > 0


# Generated at 2022-06-23 21:43:58.375973
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    value = person.political_views()

    assert value is not None
    assert isinstance(value, str)
    assert value in political_views


# Generated at 2022-06-23 21:44:04.360499
# Unit test for method email of class Person
def test_Person_email():
    from fake.providers import Person
    from fake.constants import EMAIL_DOMAINS
    provider = Person()
    email = provider.email(domains=EMAIL_DOMAINS, unique=True)
    assert '@' in email
    assert '.' in email
    assert ' ' not in email
    assert '_' not in email
    assert email.endswith(tuple(EMAIL_DOMAINS))


# Generated at 2022-06-23 21:44:12.501809
# Unit test for method telephone of class Person
def test_Person_telephone():
    from random import seed
    from unittest import TestCase
    from faker import Faker

    f = Faker()
    for _ in range(100):
        with TestCase.subTest(i=_):
            s = seed(0)
            result = f.telephone()
            expected = '+1-(827)-821-7574'
            assert result == expected

            s = seed(1)
            result = f.telephone()
            expected = '+1-(053)-239-1787'
            assert result == expected

            s = seed(2)
            result = f.telephone()
            expected = '+1-(744)-210-4235'
            assert result == expected

            s = seed(3)
            result = f.telephone()

# Generated at 2022-06-23 21:44:15.002787
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person
    """
    person = Person()
    assert isinstance(person, Person)


# Generated at 2022-06-23 21:44:17.580692
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    for _ in range(10):
        assert provider.nationality() != provider.nationality(Gender.MALE)
        assert provider.nationality() != provider.nationality(Gender.FEMALE)



# Generated at 2022-06-23 21:44:19.208129
# Unit test for method views_on of class Person
def test_Person_views_on():
    fake = Faker()
    result = fake.views_on()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:44:21.961222
# Unit test for method email of class Person
def test_Person_email():
    # Unit test for method email of class Person
    person = Person()
    email = person.email()
    for i in email:
        assert (i in EMAIL_DOMAINS), "Method Person.email does not work correctly"


# Generated at 2022-06-23 21:44:24.805035
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(rnd=False)
    assert person.surname(Gender.MALE) is 'Иванов'
    assert person.surname(Gender.FEMALE) is 'Петрова'


# Generated at 2022-06-23 21:44:26.176512
# Unit test for constructor of class Person
def test_Person():
    provider = Person(seed=0)
    assert provider.seed == 0
    assert isinstance(provider.random, Random)



# Generated at 2022-06-23 21:44:26.923072
# Unit test for method email of class Person
def test_Person_email():
    assert isinstance(Person().email(), str)

# Generated at 2022-06-23 21:44:29.476768
# Unit test for method language of class Person
def test_Person_language():
    print("\nUnit test for method language of class Person")
    data = Person().language()
    print(data)
    
    

# Generated at 2022-06-23 21:44:34.509868
# Unit test for method title of class Person
def test_Person_title():
    # Check method title of class Person
    # with right params
    person = Person('el', 'el')
    assert(person.title() == 'Δρ.')
    # Check method title of class Person
    # with wrong params
    person = Person('en', 'en')
    assert(person.title() == 'Mr.')
    


# Generated at 2022-06-23 21:44:41.752998
# Unit test for method political_views of class Person
def test_Person_political_views():
    from pprint import pprint

    i = Person.political_views
    d = set(i() for j in range(100))
    pprint(d)

    l = [i() for j in range(100)]
    pprint(l)
    
    assert len(d) >= 1, "You need to find more than one political views"
    assert len(d) < 100, "You need to find less than one hundred political views"
    assert len(l) ==100, "You need to find one hundred political views"
    
test_Person_political_views()


# Generated at 2022-06-23 21:44:44.261416
# Unit test for method password of class Person
def test_Person_password():
    provider = Person()
    password = provider.password()
    assert type(password) is str, "Must be string"
    return True


# Generated at 2022-06-23 21:44:47.709661
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    person.random.seed(2)
    result = person.worldview()
    assert result is not None
    assert len(result) >= 1
    assert isinstance(result, str)


# Generated at 2022-06-23 21:44:51.268637
# Unit test for method worldview of class Person
def test_Person_worldview():
    res = Person.worldview()
    assert res in WORLDVIEW
    
    p = Person()
    res = p.worldview()
    assert res in WORLDVIEW

test_Person_worldview()

# Generated at 2022-06-23 21:44:58.398653
# Unit test for method title of class Person
def test_Person_title():
    # Arrange
    generator = randomgen.RandomGenerator(random_generator_source='')
    generator.titles = lambda gender, title_type: ('Dr.', 'Major')

    provider = Person(generator)

    # Act
    actual_result = provider.title()

    # Assert
    assert actual_result in ('Dr.', 'Major')



# Generated at 2022-06-23 21:44:59.758693
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person()
    assert type(provider.gender()) == str


# Generated at 2022-06-23 21:45:03.697977
# Unit test for method nationality of class Person
def test_Person_nationality():

    person = Person()

    for i in range(10):
        result = person.nationality()
        if not isinstance(result, str):
            raise AssertionError("The function nationality must return a string")

test_Person_nationality()

# Generated at 2022-06-23 21:45:06.980986
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """
    Test of method blood_type of class Person.
    """
    blood_type = Person().blood_type()
    assert blood_type in BLOOD_GROUPS
test_Person_blood_type()

# Generated at 2022-06-23 21:45:10.113193
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    random = Random()
    person = Person(random)
    academic_degree = person.academic_degree()
    assert type(academic_degree) == str



# Generated at 2022-06-23 21:45:21.031311
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()

    # Name with gender
    assert person.first_name(gender='male')
    assert person.first_name(gender='female')

    # Name with gender (enum)
    assert person.first_name(gender=Gender.MALE)
    assert person.first_name(gender=Gender.FEMALE)

    # Name with title
    assert person.first_name(title_type='prefix')
    assert person.first_name(title_type='suffix')
    assert person.first_name(title_type='both')

    # Name with title (enum)
    assert person.first_name(title_type=TitleType.PREFIX)
    assert person.first_name(title_type=TitleType.SUFFIX)
    assert person.first_name(title_type=TitleType.BOTH)

# Generated at 2022-06-23 21:45:31.232365
# Unit test for method political_views of class Person

# Generated at 2022-06-23 21:45:43.700394
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Initialization of the Faker class
    fake = Faker()
    # Unit test for method work_experience of class Person
    # ===============================
    # Work experience of the person:
    # ===============================
      # Check that the method returns a string value
    assert isinstance(fake.Person().work_experience, str)
    # Check that the method returns a string value in the Eastern Arabic numerals script
    assert isinstance(fake.Person().work_experience, str) and all([ord(x) in range(48, 58) for x in fake.Person().work_experience])
    # Check that the method returns a string value in the Latin alphabet

# Generated at 2022-06-23 21:45:46.139029
# Unit test for method avatar of class Person
def test_Person_avatar():
    for i in range(20):
        assert Person().avatar(256) == Person().avatar(256)

# Generated at 2022-06-23 21:45:49.873928
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit test for method nationality of class Person"""
    pair = tuple(Person().nationality() for _ in range(2))
    assert pair[0] != pair[1]



# Generated at 2022-06-23 21:45:52.646970
# Unit test for method avatar of class Person
def test_Person_avatar():
    """Unit test for method avatar of class Person."""
    pr = Person()
    link = pr.avatar()
    assert isinstance(link, str)
    pattern = r'https:\/\/api\.adorable\.io\/avatars\/\d+\/[a-z0-9]{32}\.png'
    assert re.fullmatch(pattern, link)



# Generated at 2022-06-23 21:46:01.945296
# Unit test for method password of class Person
def test_Person_password():
    # Unicode
    natasha = Person(seed=None)
    assert natasha.password() == 'K¥¦₲ℌÆĹ'
    # Length
    ruslan = Person(seed=None)
    assert len(ruslan.password(length=5)) == 5
    # Hashed
    max = Person(seed=None)
    assert max.password(hashed=True) == 'efdd9dbf8eea0d7906d36e001babf4cf'
    # Mocked random
    random = Random()
    random.randint = Mock(return_value=1)  # Ensure we get an expected password.
    person = Person(seed=None)
    assert person.password(random=random) == 'jK^x2lDsuZ#4'

#

# Generated at 2022-06-23 21:46:04.420722
# Unit test for method sex of class Person
def test_Person_sex():
    from faker_ru import Person
    p = Person(localization='ru_RU')
    for i in range(0, 10):
        assert p.sex() in ['Мужской', 'Женский']


# Generated at 2022-06-23 21:46:06.528767
# Unit test for constructor of class Person
def test_Person():
    # Init
    p = Person('en')
    # Check
    assert isinstance(p, Person), 'Invalid constructor'

# Generated at 2022-06-23 21:46:08.580930
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    for i in range(100):
        assert person.sex() in SEXES



# Generated at 2022-06-23 21:46:10.222572
# Unit test for method first_name of class Person
def test_Person_first_name():
    o = Person()
    result = o.first_name()
    assert result in o.names



# Generated at 2022-06-23 21:46:12.164459
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person()
    r = p.political_views()
    assert isinstance(r,str)

# Generated at 2022-06-23 21:46:17.825250
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    generator = Generator()
    person = Person(Random(), generator)
    result = person.work_experience()

    assert result["company"]

    assert result["position"]

    assert result["start_date"]

    assert result["end_date"]

    assert result["description"]

# Generated at 2022-06-23 21:46:27.865258
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    sample_input = [0, 1, 2, 3, 4]
    def test_BLOOD_GROUPS(lst, n):
        '''
        The blood_type method of the class Person
        takes 0 argument and returns a random choice 
        from the list BLOOD_GROUPS.
        '''
        assert lst[n] in BLOOD_GROUPS
        return n
    def test_Person_blood_type(n):
        '''
        The blood_type method of the class Person
        takes 0 argument and returns a random choice 
        from the list BLOOD_GROUPS.
        '''
        person = Person()
        return test_BLOOD_GROUPS(BLOOD_GROUPS, 
                                 person.blood_type())
    for i in sample_input:
        assert test_Person

# Generated at 2022-06-23 21:46:30.231716
# Unit test for method name of class Person
def test_Person_name():
    p = Person(seed=12345678)
    assert p.name() == 'Мария'

# Generated at 2022-06-23 21:46:36.062183
# Unit test for method name of class Person
def test_Person_name():
    data = [
        {
            'value': None,
            'name': 'Katarina',
            'output': None
        },
        {
            'value': Gender.FEMALE,
            'name': 'Katarina',
            'output': 'Female'
        },
        {
            'value': 1,
            'name': 'Katarina',
            'output': None,
            'raises': NonEnumerableError(Gender)
        },
        {
            'value': 'Other',
            'name': 'Katarina',
            'output': None,
            'raises': NonEnumerableError(Gender)
        }
    ]


# Generated at 2022-06-23 21:46:38.858011
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person()
    assert provider.sexual_orientation() in SEXUAL_ORIENTATION
    assert provider.sexual_orientation(symbol=True) in SEXUALITY_SYMBOLS

# Generated at 2022-06-23 21:46:40.844509
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    assert person.political_views() in political_views

# Generated at 2022-06-23 21:46:43.938771
# Unit test for method political_views of class Person
def test_Person_political_views():
    """Unit test for method political_views of class Person"""

    pol_views = IPerson.political_views(None)

    assert isinstance(pol_views, str)


# Generated at 2022-06-23 21:46:45.041439
# Unit test for method first_name of class Person
def test_Person_first_name():
    pass


# Generated at 2022-06-23 21:46:49.376829
# Unit test for method title of class Person
def test_Person_title():
    with pytest.raises(NonEnumerableError):
        assert Person().title(gender='NOT_DEFINED')

    with pytest.raises(NonEnumerableError):
        assert Person().title(title_type='NOT_SUPPORTED')

    assert isinstance(Person().title(), str)


# Generated at 2022-06-23 21:46:50.809216
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    inst = Person()
    assert len(inst.work_experience())



# Generated at 2022-06-23 21:46:53.455105
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality is not None
    assert isinstance(nationality, str)
    print(f'\n national: {nationality}')

# Generated at 2022-06-23 21:47:04.634613
# Unit test for method surname of class Person
def test_Person_surname():
    # Base case
    assert Person('en').surname() in USERNAME_SURNAMES
    # Case with gender male
    assert Person('en').surname(Gender.MALE) in USERNAME_SURNAMES
    # Case with gender female
    assert Person('en').surname(Gender.FEMALE) in USERNAME_SURNAMES
    # Case with gender not specified
    assert Person('en').surname() in USERNAME_SURNAMES
    # Case check if an error is triggered
    with pytest.raises(NonEnumerableError):
        Person('en').surname(None)
    # Case compare with value
    assert Person("en").surname(Gender.FEMALE) == 'Jones'

# Generated at 2022-06-23 21:47:07.975308
# Unit test for method first_name of class Person
def test_Person_first_name():
    rnd = Random()
    person = Person(random=rnd)

    f_name = person.first_name()

    assert f_name is not None, "Value first_name is not set"
    assert f_name != "", "Value first_name is an empty string"


# Generated at 2022-06-23 21:47:10.166387
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    assert type(person.social_media_profile('facebook')) is str


# Generated at 2022-06-23 21:47:12.718429
# Unit test for method password of class Person
def test_Person_password():
    faker = Faker()
    password = faker.password(length=10, hashed=False)
    assert isinstance(password, str)
    assert len(str) == 10


# Generated at 2022-06-23 21:47:14.953566
# Unit test for method views_on of class Person
def test_Person_views_on():
    for _ in range(10):
        assert 'views_on' in Person().views_on()


# Generated at 2022-06-23 21:47:21.077236
# Unit test for method weight of class Person
def test_Person_weight():
    provider = Faker(['en_US'])
    for _ in range(10):
        # min <= x <= max
        assert 38 <= provider.weight(minimum=38, maximum=90) <= 90
        # min <= x <= default_max
        assert 38 <= provider.weight(minimum=38) <= 90
        # default_min <= x <= max
        assert 38 <= provider.weight(maximum=90) <= 90
        # default_min <= x <= default_max
        assert 38 <= provider.weight() <= 90


# Generated at 2022-06-23 21:47:23.500920
# Unit test for method password of class Person
def test_Person_password():
    p = Person()
    assert type(p.password()) == str
    assert type(p.password(hashed=True)) == str


# Generated at 2022-06-23 21:47:26.382720
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person("person")
    assert p.occupation() == "программер"

test_Person_occupation() 


# Generated at 2022-06-23 21:47:31.249524
# Unit test for constructor of class Person
def test_Person():
    # Call the constructor without any arguments
    p = Person()
    # Check that the object has the correct constructor data
    assert p.__class__.__name__ == 'Person'
    # Check that there is no seed
    assert p.get_seed() is None

# Generated at 2022-06-23 21:47:33.617328
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    nat = p.nationality(Gender.female)
    assert nat in NATIONALITIES["female"]


# Generated at 2022-06-23 21:47:36.639863
# Unit test for method name of class Person
def test_Person_name():
    for i in range(10000):
        n = Person().name()
        assert isinstance(n, str)
        assert len(n) >= 5
        assert n[0].isupper()


# Generated at 2022-06-23 21:47:41.232114
# Unit test for method language of class Person
def test_Person_language():
    my_Person = Person()
    my_var = my_Person.language()
    assert my_var in LANGUAGES, f"Значение {my_var} не входит в диапазон допустимых"

# Generated at 2022-06-23 21:47:42.225799
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    person.political_views()


# Generated at 2022-06-23 21:47:43.963188
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person()
    bg = p.blood_type()
    assert bg in BLOOD_GROUPS, 'Not real blood type'

# Test all methods of class Person

# Generated at 2022-06-23 21:47:49.543607
# Unit test for method worldview of class Person
def test_Person_worldview():
    print('Test worldview..')
    
    def get_worldviews(n: int=10) -> List[str]:
        worldviews = []
        for _ in range(n):
            worldviews.append(Person().worldview())
        return worldviews
    
    worldviews = get_worldviews()
    worldviews_set = set(worldviews)
    
    print(worldviews)
    
    # Check that created worldviews are unique
    assert worldviews_set == set(worldviews), \
           'Created worldviews are not unique'
    
    print('Done.\n')
test_Person_worldview()


# Generated at 2022-06-23 21:48:01.105632
# Unit test for method telephone of class Person
def test_Person_telephone():
    assert Person.telephone() in ['+7-963-409-11-22', '+7-952-118-11-94',
                                  '+7-936-808-24-57', '+7-965-868-87-24',
                                  '+7-967-735-97-23', '+7-909-588-72-94',
                                  '+7-926-426-67-74']
    assert Person.telephone() == Person.telephone()

# Generated at 2022-06-23 21:48:04.195399
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Arrange
    person = Person()
    expected = person.views_on()

    # Action
    actual = person.views_on()

    # Assert
    assert actual == expected
    

# Generated at 2022-06-23 21:48:08.443665
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    result = person.avatar()
    assert re.match(r"^https://api.adorable.io/avatars/.+$", result)


# Generated at 2022-06-23 21:48:10.499984
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert Person('en').sexual_orientation() in PERSON_DATA['en']['sexuality']


# Generated at 2022-06-23 21:48:19.358475
# Unit test for method password of class Person
def test_Person_password():
    """Unit test for method password of class Person"""

    person = Person()

    password = person.password()
    assert len(password) == 8 
    regex(r'[A-Za-z]', password)
    regex(r'[0-9]', password)
    regex(r'\W', password)
    password = person.password(hashed=True)
    assert len(password) == 32

    for i in range(20):
        password = person.password(length=i)
        print(password)
        assert len(password) == i

    for i in [3, 4, 10, 30, 32, 64]:
        password = person.password(hashed=True, length=i)
        assert len(password) == i
        print(password)



# Generated at 2022-06-23 21:48:20.575500
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person()
    #print(p.blood_type())


# Generated at 2022-06-23 21:48:32.960536
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person().identifier() == '07-97/04'
    assert Person().identifier() == '96-70/03'
    assert Person().identifier() == '75-63/78'
    assert Person().identifier() == '38-55/84'
    assert Person().identifier() == '19-44/66'
    assert Person().identifier() == '07-07/96'
    assert Person().identifier() == '41-50/07'
    assert Person().identifier() == '01-83/01'
    assert Person().identifier() == '97-54/95'
    assert Person().identifier() == '99-91/22'
    assert Person().identifier() == '20-33/06'
    assert Person().identifier() == '70-94/06'
    assert Person().identifier()

# Generated at 2022-06-23 21:48:37.755013
# Unit test for method sex of class Person
def test_Person_sex():
    # initialization
    entities = [
        Person()
    ]

    # Проверка на наличие метода
    for entity in entities:
        assert callable(getattr(entity, "sex", None))

    # Проверка работы метода
    for entity in entities:
        result = entity.sex()
        check_result(result, *GENDER_VALUES)

# Generated at 2022-06-23 21:48:40.036509
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """Unit test for method blood_type of class Person."""
    person = Person()

    assert isinstance(person.blood_type(), str)

# Generated at 2022-06-23 21:48:42.697920
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    for _ in range(100):
        assert Person(random.Random()).work_experience().endswith(" years")

# Generated at 2022-06-23 21:48:44.142587
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert type(Person().blood_type()) == str
    
    

# Generated at 2022-06-23 21:48:45.620318
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name() in LAST_NAMES



# Generated at 2022-06-23 21:48:49.376567
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person()
    e = p.work_experience(experience_type=ExperienceType.years,
                          time_diff=timedelta(days=90))
    assert isinstance(e, str)

# Generated at 2022-06-23 21:48:51.492571
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person(random=Random())
    assert isinstance(p.blood_type(), str)
test_Person_blood_type()

# Generated at 2022-06-23 21:48:55.588227
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    validator = lambda x: x in BLOOD_GROUPS
    values = [Person().blood_type() for _ in range(1000)]
    assert all(map(validator, values))


# Generated at 2022-06-23 21:48:59.910383
# Unit test for method username of class Person
def test_Person_username():
    
    # Create object for tests
    target = Person()
    # Show all results
    for _ in range(10):
        print(target.username())
test_Person_username()

print("\n\n")


# Generated at 2022-06-23 21:49:04.405311
# Unit test for method sex of class Person
def test_Person_sex():
    # Testing Person.sex
    person = Person()
    assert person.sex() in GENDER_SYMBOLS
    assert person.sex(symbol=False) in person._data['gender']
    assert 0 <= person.sex(iso5218=True) <= 9


# Generated at 2022-06-23 21:49:05.846488
# Unit test for method weight of class Person
def test_Person_weight():
    assert Person(seed=1).weight(38, 90) == 61

# Generated at 2022-06-23 21:49:07.825333
# Unit test for method email of class Person
def test_Person_email():
    obj = Person(seed=23894)
    assert obj.email(unique=False) == "v21@yahoo.com"


# Generated at 2022-06-23 21:49:10.035515
# Unit test for method university of class Person
def test_Person_university():
    with Person() as p:
        resp = p.university()
        assert resp in PERSON_DATA['university']
        print(resp)


# Generated at 2022-06-23 21:49:11.700898
# Unit test for method occupation of class Person
def test_Person_occupation():
    Occupation = Person().occupation()
    assert Occupation is not None

# Generated at 2022-06-23 21:49:17.572222
# Unit test for method password of class Person
def test_Person_password():
    person = Person(rnd=Random(seed=const.SEED_FOR_CORRECTNESS_TEST))

    # test with default parameters
    assert person.password() == 'a2$6,@.-k'

    # test with custom length
    assert len(person.password(length=12)) == 12

    # test with hashed
    assert person.password(hashed=True) == 'b1bc5118adf5cbd9b344d8fee01e0b39'

# Generated at 2022-06-23 21:49:26.340315
# Unit test for method views_on of class Person
def test_Person_views_on():

    from faker import Faker
    from faker.providers.person.en import Provider

    fake = Faker(['en_US', 'en_UK'])
    fake.add_provider(Provider)

    for country in fake.available_locales:
        fake = Faker(country)
        fake.add_provider(Provider)
        views_on = fake.views_on()

        assert isinstance(views_on, str)

        assert views_on in fake.get_provider('person')._data['views_on']

# Generated at 2022-06-23 21:49:28.405046
# Unit test for method weight of class Person
def test_Person_weight():
    print('Test for method weight of class Person')
    for _ in range(10):
        person = Person()
        print(person.weight())
    print('Test of method weight passed')

test_Person_weight()


# Generated at 2022-06-23 21:49:32.627298
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    from pyfaker.utils.compat import mock

    with mock.patch('random.choice') as mock_choice:
        f = Person()
        r = f.blood_type()
        mock_choice.assert_called_once_with(BLOOD_GROUPS)
        assert r == mock_choice.return_value


# Generated at 2022-06-23 21:49:35.725425
# Unit test for method email of class Person
def test_Person_email():
    person = Person()

    for _ in range(100):
        assert person.email(), 'Expected string'
        assert '@' in person.email()

# Generated at 2022-06-23 21:49:41.151404
# Unit test for method username of class Person
def test_Person_username():
    from pyfaker import Faker

    f = Faker()
    assert f('person.username') == f.username()

    assert f('person.username', template='U_d').isupper()
    assert f('person.username', template='ld').islower()

    with pytest.raises(ValueError):
        f(method='person.username', template='ldd')



# Generated at 2022-06-23 21:49:45.045509
# Unit test for method weight of class Person
def test_Person_weight():
    random_person = Person(None, None, None)
    random_weight = random_person.weight()
    print(random_weight)
    assert (random_weight >= 38 and random_weight <= 90)
test_Person_weight()


# Generated at 2022-06-23 21:49:47.609557
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    surname = p.surname(Gender.MALE)
    assert surname

# Generated at 2022-06-23 21:49:51.620773
# Unit test for method sex of class Person
def test_Person_sex():
  random.seed('slavag')
  pe = Person()
  assert pe.sex() == 'Male'
  assert pe.sex(symbol=True) == ''
  assert pe.sex(iso5218=True) == 0
test_Person_sex()


# Generated at 2022-06-23 21:49:52.947424
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    avatar = person.avatar()
    assert avatar

# Generated at 2022-06-23 21:49:56.607792
# Unit test for method password of class Person
def test_Person_password():
    assert Person.password() != '12345678'
    assert Person.password() != '87654321'
    assert Person.password() != 'abcdefgh'
    assert Person.password() != 'hgfedcba'

# Generated at 2022-06-23 21:49:58.848105
# Unit test for method full_name of class Person
def test_Person_full_name():
    """Test Person.full_name()"""
    person = Person(seed=1)
    assert person.full_name() == "Emanuel Zemorých"


# Generated at 2022-06-23 21:50:00.983579
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person.get_instance()
    views_on = person.views_on()
    assert isinstance(views_on, str)


# Generated at 2022-06-23 21:50:05.010410
# Unit test for method university of class Person
def test_Person_university():
    languages = [
        'Russian',
        'Irish',
        'German',
        'Spanish',
        'English',
        'Italian',
        'French',
        'Welsh',
        'Chinese',
    ]

    person = Person()
    for i in range(10):
        lang = person.language()
        assert lang in languages


# Generated at 2022-06-23 21:50:06.081822
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    surname = person.last_name()
    assert surname in SURNAMES_ALL


# Generated at 2022-06-23 21:50:11.789162
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person(locale='ru_RU')
    worldviews = ('Agnosticism', 'Atheism', 'Deism', 'Pantheism', 'Polytheism')
    for _ in range(100):
        worldview = person.worldview()
        assert worldview in worldviews
        assert isinstance(worldview, str)
    print('Person.worldview() is ok')

if __name__ == '__main__':
    test_Person_worldview()

# Generated at 2022-06-23 21:50:23.763471
# Unit test for method height of class Person
def test_Person_height():
    faker = Person()
    name = faker.name(Gender.MALE)
    surname = faker.surname(Gender.MALE)

    def _test_height(height: int):
        assert isinstance(height, float)
        assert 0 < height < 3
        return True
    h = faker.height()
    assert _test_height(h)
    # test for maximum and minimum values
    for i in range(100):
        h = faker.height(minimum=1.2, maximum=1.5)
        assert _test_height(h)

    #test for the ValueError exception
    with pytest.raises(ValueError) as e:
        faker.height(1.2, 1.1)
    assert 'The minimum value must be less than the maximum value' in str(e.value)

# Generated at 2022-06-23 21:50:26.254504
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    result = p.last_name()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:50:37.192769
# Unit test for constructor of class Person
def test_Person():
    provider = Person(seed=1)
    assert provider.seed == 1
    assert provider.__class__.__name__ == 'Person'
    assert provider.__doc__ == 'Data Provider for personal data.'
    assert provider.random == Random()
    assert provider._data['name']['male'] == MALE_NAMES
    assert provider._data['name']['female'] == FEMALE_NAMES
    assert provider._data['surname']['male'] == MALE_SURNAMES
    assert provider._data['surname']['female'] == FEMALE_SURNAMES
    assert provider._data['gender'] == GENDERS
    assert provider._data['occupation'] == OCCUPATIONS
    assert provider._data['nationality'] == NATIONALITIES
    assert provider._data['university'] == UNIVERSITIES
   

# Generated at 2022-06-23 21:50:38.175227
# Unit test for method name of class Person
def test_Person_name():
    assert len(Person().name())!=0


# Generated at 2022-06-23 21:50:39.885450
# Unit test for method university of class Person
def test_Person_university():
    gen = Person('en')
    assert isinstance(gen.university(), str)

# Generated at 2022-06-23 21:50:43.871064
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # generate a random blood type
    blood_type = random_person().blood_type()

    # check that the random blood type is a string
    assert isinstance(blood_type, str)
    
    

# Generated at 2022-06-23 21:50:45.389180
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in PERSON_VIEWS_ON


# Generated at 2022-06-23 21:50:47.610738
# Unit test for method occupation of class Person
def test_Person_occupation():
    for i in range(100):
        occupation = Person().occupation()
        assert occupation in OCCUPATIONS



# Generated at 2022-06-23 21:50:49.392448
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person('ru')
    result = person.nationality()
    assert result in NATIONALITIES


# Generated at 2022-06-23 21:50:52.350143
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()

    assert all(
        item in BLOOD_GROUPS
        for item in [person.blood_type() for _ in range(1000)]
    )


# Generated at 2022-06-23 21:50:56.652247
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert isinstance(person, Person) is True
    assert isinstance(person, BaseProvider) is True
    assert isinstance(person, Generator) is True


if __name__ == '__main__':
    import doctest
    doctest.testmod()