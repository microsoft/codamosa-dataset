

# Generated at 2022-06-23 21:41:02.287142
# Unit test for method age of class Person
def test_Person_age():
    # Get instance of class Person
    person = Person(random=random)
    # Get year of birth
    year = person.birth_date(minimum=15, maximum=99,
                             minimum_tzd=None, maximum_tzd=None).split('-')[0]
    # Check is birth date one-two digit
    assert 15 <= len(year) <= 2
    # Get age
    age = person.age(minimum=15, maximum=99)
    # Check is age same as year of birth
    assert age == int(year)



# Generated at 2022-06-23 21:41:04.054500
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    g = Generator()
    data = g.blood_type()
    assert isinstance(data,str)

# Generated at 2022-06-23 21:41:14.969847
# Unit test for method language of class Person
def test_Person_language():
    fatal_error = False
    # Create object of class Person
    faker = Person(random_seed=2)
    for i in range(1, 100):
        # Generate random language
        language = faker.language()
        if not isinstance(language, str):
            fatal_error = True
        if len(language) < 1:
            fatal_error = True
    if fatal_error:
        print("\033[93m" + "Method language of class Person has fatal errors!" + "\033[0m")
        return 1
    else:
        print("\033[92m" + "Method language of class Person has passed the test!" + "\033[0m")
        return 0

# Generated at 2022-06-23 21:41:17.487148
# Unit test for method occupation of class Person
def test_Person_occupation():
    from datagenpy.providers import Person
    p = Person()
    print(p.occupation())

# Generated at 2022-06-23 21:41:20.344512
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person."""
    person = Person('en')
    assert isinstance(person, Person)
    assert person.locale == 'en'

# Generated at 2022-06-23 21:41:24.024998
# Unit test for method telephone of class Person
def test_Person_telephone():
    def wrap_test_method():
        p = Person()
        t = p.telephone(mask='+7-(###)-###-####', placeholder='#')
        return t

    assert_length(wrap_test_method(), 14)

# Generated at 2022-06-23 21:41:27.040507
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    for _ in range(100):
        p = Person()
        assert isinstance(p.work_experience(), str)
        assert isinstance(p.work_experience(True), int)


# Generated at 2022-06-23 21:41:30.226827
# Unit test for method height of class Person
def test_Person_height():
    t = Person()
    assert isinstance(t.height(), basestring)
    assert isinstance(t.height(minimum=0.2, maximum=2.2), basestring)



# Generated at 2022-06-23 21:41:31.521657
# Unit test for method sex of class Person
def test_Person_sex():
    for _ in range(10):
        assert isinstance(Person.sex(), str)

# Generated at 2022-06-23 21:41:33.023071
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    actual_first_name = person.first_name()
    assert isinstance(actual_first_name, str)



# Generated at 2022-06-23 21:41:37.116568
# Unit test for method university of class Person
def test_Person_university():
    mock_data = {'university': ['Tver State University', 'Tver Technical University']}
    fake = Person(mock_data)
    assert fake.university() in mock_data['university']

# Generated at 2022-06-23 21:41:47.996958
# Unit test for method title of class Person
def test_Person_title():
    titles = {
        TitleType.PREFIX: ('Prof.', 'Dr.', 'Mr.', 'Mrs.', 'Ms.'),
        TitleType.SUFFIX: ('Jr.', 'Sr.', 'PhD.'),
    }


# Generated at 2022-06-23 21:41:55.556866
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person(seed=1234)
    
    assert person.full_name() == "Bart Simpson"
    assert person.full_name(reverse=True) == "Simpson Bart"
    assert person.full_name(gender=Gender.MALE) == "Lenny Leonard"
    assert person.full_name(gender=Gender.MALE, reverse=True) == "Leonard Lenny"
    assert person.full_name(gender=Gender.FEMALE) == "Lisa Simpson"
    assert person.full_name(gender=Gender.FEMALE, reverse=True) == "Simpson Lisa"
    
    random.seed(1234)

# Generated at 2022-06-23 21:41:58.921653
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person().work_experience() == 0
    assert Person(seed=1).work_experience() == 0.0
    assert Person(seed=2).work_experience() == 5.0
    assert Person(seed=3).work_experience() == 9.0
    assert Person(seed=4).work_experience() == 50.0


# Generated at 2022-06-23 21:42:05.385392
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person(seed=2)
    assert p.full_name() == 'Jörg Hämmerle'
    assert p.full_name(Gender.FEMALE) == 'Elzbieta Miklaszewska'
    assert p.full_name(Gender.MALE, reverse=True) == 'Thomas Nothnagel'
    assert p.full_name(gender=Gender.FEMALE, reverse=True) == 'Ingrid Schneider'


# Generated at 2022-06-23 21:42:09.978744
# Unit test for method email of class Person
def test_Person_email():
    assert 'ДДДДД' == Person.email()
    assert 'ДДДД' == Person.email()
    assert 'ДДД' == Person.email()
    assert 'ДД' == Person.email()
    assert 'Д' == Person.email()
    assert 'ДДДДД' == Person.email()
    assert 'ДДДДД' == Person.email()
    assert 'ДДДДД' == Person.email()
    assert 'ДДДДД' == Person.email()

# Generated at 2022-06-23 21:42:11.593755
# Unit test for method avatar of class Person
def test_Person_avatar():

    provider = Person()

    default_avatar = provider.avatar(size=256)

    assert isinstance(default_avatar, str)
    assert 'https://api.adorable.io/avatars' in default_avatar



# Generated at 2022-06-23 21:42:16.744897
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    data = []
    data += [Person().social_media_profile(site=None) for _ in range(500)]
    data += [Person().social_media_profile(site=SocialNetwork.facebook) for _ in range(500)]
    data += [Person().social_media_profile(site=SocialNetwork.instagram) for _ in range(500)]
    #data += [Person().social_media_profile(site=SocialNetwork.twitter) for _ in range(500)]
    #data += [Person().social_media_profile(site=SocialNetwork.vk) for _ in range(500)]
    #data += [Person().social_media_profile(site=SocialNetwork.twitch) for _ in range(500)]
    #data += [Person().social_media_profile(site=SocialNetwork.youtube) for _ in range(500)]
    #

# Generated at 2022-06-23 21:42:23.041608
# Unit test for method first_name of class Person
def test_Person_first_name():
    from faker import Faker
    from faker_sexmachine.classes import Gender, TitleType

    fake = Faker('ru_RU')
    male_fullname = 'Игорь Павлович'
    female_fullname = 'Любовь Максимовна'

    # By gender
    assert fake.first_name(gender=Gender.MALE) == 'Игорь'
    assert fake.first_name(gender=Gender.FEMALE) == 'Любовь'

    # Male by gender key
    assert fake.first_name(gender='m') == 'Игорь'

    # Female by gender key
    assert fake.first_name(gender='f')

# Generated at 2022-06-23 21:42:24.094112
# Unit test for method age of class Person
def test_Person_age():
    for i in range(100):
        assert Person().age(minimum=16, maximum=99)



# Generated at 2022-06-23 21:42:32.971923
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person(seed=1)
    test_list = [
        person.social_media_profile(Facebook),
        person.social_media_profile(Twitter),
        person.social_media_profile(Instagram),
        person.social_media_profile(YouTube),
    ]
    expected_list = [
        'https://facebook.com/szozmny',
        'https://twitter.com/m8slid',
        'https://instagram.com/zmp8n',
        'https://youtube.com/4lm8ckovi',
    ]
    assert test_list == expected_list


# Generated at 2022-06-23 21:42:35.610274
# Unit test for method university of class Person
def test_Person_university():
    person = Person(random.Random())
    result = person.university()
    assert type(result) == str
    assert result != ''


# Generated at 2022-06-23 21:42:39.609429
# Unit test for method gender of class Person
def test_Person_gender():
    """This method tests the Person class method 'gender' and
    checks whether it returns the correct type for the return value"""
    p = faker.faker.Person()
    r = p.gender()
    assert type(r) == str
    assert r in p._data['gender']


# Generated at 2022-06-23 21:42:42.168902
# Unit test for method password of class Person
def test_Person_password():
    """Unit test for method password of class Person.
    
    Test if method return a password.
    """
    assert isinstance(Person().password(), str)


# Generated at 2022-06-23 21:42:46.643763
# Unit test for method telephone of class Person
def test_Person_telephone():
    """
    Unit test for method telephone of class Person.
    """
    # Test for method telephone
    assert Person().telephone()
    assert Person().telephone(mask='7-(###)-###-##-##')


# Generated at 2022-06-23 21:42:48.520032
# Unit test for method occupation of class Person
def test_Person_occupation():
    pr = Person()
    assert pr.occupation() in pr._data['occupation']



# Generated at 2022-06-23 21:42:52.763266
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert Person.first_name({'male': ('Алексей',)}) == 'Алексей'
    assert Person.first_name(['Алексей']) == 'Алексей'

# Generated at 2022-06-23 21:42:56.134891
# Unit test for method avatar of class Person
def test_Person_avatar():
    sample = Person.avatar()
    assert isinstance(sample, str)
    assert len(sample) > 16
    assert 'api.adorable.io' in sample



# Generated at 2022-06-23 21:42:59.021409
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert isinstance(Person().first_name(), str)
    assert isinstance(Person().first_name('male'), str)
    assert isinstance(Person().first_name(Gender.MALE), str)

# Generated at 2022-06-23 21:43:07.254002
# Unit test for method title of class Person
def test_Person_title():
    # case 1: input = (None, None)
    # output = non of ['Prof.', 'Dr.', 'Dr', 'Prof.']
    out1 = Person().title()
#     assert out1 not in ['Prof.', 'Dr.', 'Dr', 'Prof.']
    # case 2: input = (Gender.MALE, TitleType.PREFIX)
    # output = any of ['Prof.', 'Dr.', 'Dr']
    out2 = Person().title(Gender.MALE, TitleType.PREFIX)
    assert out2 in ['Prof.', 'Dr.', 'Dr']
    # case 3: input = (None, TitleType.SUFFIX)
    # output = any of ['PhD', 'MBA', 'Jr.']
    out3 = Person().title(None, TitleType.SUFFIX)


# Generated at 2022-06-23 21:43:11.333688
# Unit test for method university of class Person
def test_Person_university():
    from yomiko.enums import Sex, Gender
    p = Person(seed=0)
    assert p.university() == 'MIT'
    assert isinstance(p.university(), str)
    assert p.university() in p.all_universities()

# Generated at 2022-06-23 21:43:16.708756
# Unit test for method password of class Person
def test_Person_password():
    somelist = []
    for _ in range(0,100):
        p = Person()
        x = p.password(length=7, hashed=True)
        if x not in somelist: somelist.append(x)
    if len(somelist) == 100:
        print("\nTest: PASS")
    assert len(somelist) == 100
test_Person_password()


# Generated at 2022-06-23 21:43:18.191152
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert Person.blood_type() in BLOOD_GROUPS

# Generated at 2022-06-23 21:43:19.714474
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person.providers['views_on']() == 'Positive' or 'Negative'

# Generated at 2022-06-23 21:43:21.720226
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    r = PersonFactory().sexual_orientation()
    for _ in range(99):
        assert r == PersonFactory().sexual_orientation()



# Generated at 2022-06-23 21:43:31.164140
# Unit test for method full_name of class Person

# Generated at 2022-06-23 21:43:34.268213
# Unit test for method gender of class Person
def test_Person_gender():
    actual = Person().gender()
    expected = random.choice(['Male', 'Female'])
    assert actual == expected


# Generated at 2022-06-23 21:43:36.028542
# Unit test for method telephone of class Person
def test_Person_telephone():
    assert Person().telephone()



# Generated at 2022-06-23 21:43:39.245165
# Unit test for method name of class Person
def test_Person_name():
    '''
    Should return different values to test whether the method works properly
    '''
    p = Person()
    assert p.name() != p.name()

# Generated at 2022-06-23 21:43:40.988647
# Unit test for method language of class Person
def test_Person_language():
    verbs = Person.language()
    assert verbs in Person.languages



# Generated at 2022-06-23 21:43:43.923183
# Unit test for method nationality of class Person
def test_Person_nationality():
    from fake2db import Person
    from pprint import pprint
    from enum import Enum
    
    class Gender(Enum):
        MALE = 0
        FEMALE = 1
    
    p = Person()
    pprint(p.nationality(Gender.MALE))
    
    
test_Person_nationality()


# Generated at 2022-06-23 21:43:46.355072
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person()
    assert p.political_views() in p._data["political_views"]

# Generated at 2022-06-23 21:43:48.300027
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    Person().work_experience()
Person().work_experience()
 

# Generated at 2022-06-23 21:43:54.651014
# Unit test for method email of class Person
def test_Person_email():
    person = Person()

    units = [
        person.email(),
        person.email(domains=('foo.com', 'bar.com')),
        person.email(domains=['baz.com']),
    ]

    for unit in units:
        assert isinstance(unit, str)
        assert '@' in unit
        assert '.' in unit
        assert len(unit) < 255


# Generated at 2022-06-23 21:43:56.722564
# Unit test for method weight of class Person
def test_Person_weight():
    for _ in range(100):
        assert Person().weight()>=38
        assert Person().weight()<=90
        

# Generated at 2022-06-23 21:43:59.613285
# Unit test for method age of class Person
def test_Person_age():
    assert(Person().age() <= 121)
    assert(Person().age()>=0)
    
test_Person_age()


# Generated at 2022-06-23 21:44:06.463745
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(100):
        worldview = Person().worldview()
        assert worldview in ('Atheism',
                             'Buddhism',
                             'Catholicism',
                             'Confucianism',
                             'Hinduism',
                             'Islam',
                             'Judaism',
                             'Lutheranism',
                             'Methodism',
                             'Pantheism',
                             'Protestantism',
                             'Shintoism',
                             'Zoroastrianism')



# Generated at 2022-06-23 21:44:07.505163
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person.last_name()


# Generated at 2022-06-23 21:44:17.845717
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person."""
    person = Person(seed=42)
    assert person.name() == "Фёдор"
    assert person.surname() == "Семёнов"
    assert person.full_name(Gender.MALE) == "Фёдор Семёнов"
    assert person.name(Gender.MALE) == 'Фёдор'
    assert person.surname(Gender.MALE) == 'Семёнов'
    assert person.full_name(Gender.FEMALE) == "Мария Тимофеева"
    assert person.name(Gender.FEMALE) == 'Мария'
   

# Generated at 2022-06-23 21:44:22.831149
# Unit test for method name of class Person
def test_Person_name():
    assert Person('ru').name(gender=Gender.MALE) != None
    assert Person('ru').name(gender=Gender.FEMALE) != None
    assert Person().name(gender=Gender.MALE) != None
    assert Person().name(gender=Gender.FEMALE) != None
    assert isinstance(Person('ru').name(gender=Gender.MALE), str)
    assert isinstance(Person('ru').name(gender=Gender.FEMALE), str)

# Generated at 2022-06-23 21:44:24.804744
# Unit test for method university of class Person
def test_Person_university():
    #Arrange
    #Act
    result = Person().university()
    #Assert 
    assert type(result) is str, "The result should be a string"

# Generated at 2022-06-23 21:44:26.545724
# Unit test for constructor of class Person
def test_Person():
    p = Person()

    assert hasattr(p, 'random')
    assert hasattr(p, 'seed')
    assert hasattr(p, '_data')

# Unit tests

# Generated at 2022-06-23 21:44:31.001182
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    random.seed(0)
    assert Person().academic_degree() == 'Bachelor', 'Random academic_degree'

    with pytest.raises(NotImplementedError):
        Person(locale='es_MX').academic_degree()

# Generated at 2022-06-23 21:44:33.313066
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()
    print(worldview)
    

# Generated at 2022-06-23 21:44:37.825126
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person(seed=12345)
    assert p.first_name(gender=Gender.MALE) == 'Johann'
    assert p.first_name(gender=Gender.FEMALE) == 'Maria'
    assert p.first_name(gender=Gender.UNKNOWN) == 'Johann'


# Generated at 2022-06-23 21:44:45.171704
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Test with empty seed
    rnd1 = Random()
    provider1 = Person(rnd1)
    views1 = provider1.views_on()
    assert (type(views1) == str)
    assert (views1 in ['Positive', 'Negative', 'Neutral'])
    # Test with random seed
    rnd2 = Random()
    random_seed = rnd2.randint(0, 999999999)
    rnd2.seed(random_seed)
    provider2 = Person(rnd2)
    views2 = provider2.views_on()
    assert (views2 == views1)

# Generated at 2022-06-23 21:44:48.420773
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    gender = Gender.female
    title_type = TitleType.postfix
    assert person.title(gender, title_type) in ['Jr.', 'Sr.', 'II', 'III', 'IV']


# Generated at 2022-06-23 21:44:55.116765
# Unit test for method worldview of class Person
def test_Person_worldview():
    @st.composite
    def worldviews(draw):
        worldviews = Person()._data['worldview']
        return draw(st.sampled_from(worldviews))
    
    @given(worldview=worldviews())
    def test_one_worldview(worldview):
        assert worldview in Person()._data['worldview']
        
    test_one_worldview()
    
    

# Generated at 2022-06-23 21:45:04.899755
# Unit test for method sex of class Person
def test_Person_sex():
    """Unit test for method sex of class Person."""
    person = Person(seed=1234)
    words = set()
    for _ in range(100):
        words.add(person.sex())
    assert words == {'Male', 'Female', 'Not known'}

    person = Person(seed=1234, locales=('en_US',))
    words = set()
    for _ in range(100):
        words.add(person.sex())
    assert words == {'Male', 'Female', 'Not known'}

    person = Person(seed=1234, locales=('en_UK',))
    words = set()
    for _ in range(100):
        words.add(person.sex())
    assert words == {'Male', 'Female', 'Not known'}


# Generated at 2022-06-23 21:45:10.457196
# Unit test for method title of class Person
def test_Person_title():
    person = Person(Random())
    gender = Gender.male
    title_type = TitleType.prefix
    gender_key = person._validate_enum(gender, Gender)
    title_key = person._validate_enum(title_type, TitleType)
    titles = person._data['title'][gender_key][title_key]
    result = person.title(gender, title_type)
    assert (result in titles)

# Generated at 2022-06-23 21:45:13.323075
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Arrange
    person = Person()

    # Act
    actual = person.work_experience(0)

    # Assert
    assert actual >= 0



# Generated at 2022-06-23 21:45:23.297743
# Unit test for method identifier of class Person
def test_Person_identifier():
    m = Mask()
    assert m.identifier()
    assert m.custom_code('##-##/##')
    assert m.custom_code('##-##/##', '#')
    assert m.custom_code('@@-@@/@@', '@')
    assert m.custom_code('##-##/##', '#')
    assert isinstance(m.identifier(), str)
    assert isinstance(m.custom_code('##-##/##'), str)
    assert isinstance(m.custom_code('##-##/##', '#'), str)
    assert isinstance(m.custom_code('@@-@@/@@', '@'), str)
    assert isinstance(m.custom_code('##-##/##', '#'), str)

# Generated at 2022-06-23 21:45:25.208453
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Test Person.blood_type()
    person = Person()
    assert person.blood_type() in BLOOD_GROUPS


# Generated at 2022-06-23 21:45:31.259633
# Unit test for method title of class Person
def test_Person_title():
    # Testing method title from class Person
    from faker import Faker
    from faker.providers.person.en_US import Provider

    fake = Faker(locale='en_US')
    fake.add_provider(Provider)

    for _ in range(10):
        # Testing gender, title_type
        assert type(fake.title(gender=Gender.MALE,
                               title_type=TitleType.PREFIX)) is str



# Generated at 2022-06-23 21:45:35.249927
# Unit test for method password of class Person
def test_Person_password():
    person = Person(random=Random())
    password = person.password(hashed=True)
    assert hashlib.md5(password.encode()).hexdigest() == password
test_Person_password()

# Generated at 2022-06-23 21:45:37.841719
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    res = Person.blood_type()
    assert res in BLOOD_GROUPS
    assert res == Person.blood_type()

# Generated at 2022-06-23 21:45:40.831385
# Unit test for method age of class Person
def test_Person_age():
    data = [0, 18, 18, 19, 20]
    assert Person(random).age(random.choice(data)) in data


# Generated at 2022-06-23 21:45:49.101534
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person(seed=662774)
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()
    assert 'Male' == person.sex()


# Generated at 2022-06-23 21:45:49.838603
# Unit test for method university of class Person
def test_Person_university():
    assert isinstance(Person.university(), str)

# Generated at 2022-06-23 21:45:53.179581
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    academic_degree = Person.academic_degree()
    assert isinstance(academic_degree, str)
    assert academic_degree in ACADEMIC_DEGREES


# Generated at 2022-06-23 21:45:58.983434
# Unit test for method political_views of class Person
def test_Person_political_views():
    '''
    Test that Person().political_views() returns a political view
    as a string from the list of political views from the file 'political_views.json'.
    '''
    person = Person()
    political_view = person.political_views()
    
    assert type(political_view) is str
    assert political_view in json.load(open('file.json'))
test_Person_political_views()
        

# Generated at 2022-06-23 21:46:04.388748
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    with pytest.raises(TypeError) as excinfo:
        Person.work_experience('UAE')
    assert str(excinfo.value) == 'Company must be a string, not <class \'str\'>'
    with pytest.raises(TypeError) as excinfo:
        Person.work_experience(8)
    assert str(excinfo.value) == 'Company must be a string, not <class \'int\'>'
    assert Person.work_experience('UAE', 'Pep') == {'Company': 'UAE', 'Position': 'Pep'}
    



# Generated at 2022-06-23 21:46:06.854288
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    last_name = p.last_name()
    assert isinstance(last_name, str)
    assert 0 < len(last_name) < 50

# Generated at 2022-06-23 21:46:09.321192
# Unit test for method weight of class Person
def test_Person_weight():
    weight = Person.weight(minimum=60, maximum=80)
    assert weight <= 80
    assert weight >= 60


# Generated at 2022-06-23 21:46:11.067939
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    age = 19
    assert Person.work_experience(age) == 0


# Generated at 2022-06-23 21:46:13.300134
# Unit test for method gender of class Person
def test_Person_gender():
    for _ in range(1000):
        assert Person().gender() in ('Male', 'Female')



# Generated at 2022-06-23 21:46:16.176776
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    instance = Person()
    assert isinstance(instance.academic_degree(),str)

# Generated at 2022-06-23 21:46:18.096697
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    print(person.last_name())
    

# Generated at 2022-06-23 21:46:20.020461
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    worldview = p.worldview()
    assert worldview in p._data['worldview']

# Generated at 2022-06-23 21:46:21.620229
# Unit test for method worldview of class Person
def test_Person_worldview():
    assert Person().worldview() == 'Pantheism'


# Generated at 2022-06-23 21:46:30.196930
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Создаём экземпляр класса Person с семями для повторяемости
    generator = Person(seed=1)
    # Получаем текст со сгенерированным опытом работы
    work_experience = generator.work_experience()
    # Сравниваем полученный результат с ожидаемым

# Generated at 2022-06-23 21:46:36.030516
# Unit test for method identifier of class Person
def test_Person_identifier():
    # Identifier
    from faker.providers.person import Provider
    from faker.providers.person.en import Provider as EnProvider
    from faker.providers.person.en_GB import Provider as EnGbProvider

    for cls in [Provider, EnProvider, EnGbProvider]:
        p = cls(seed=0)
        assert p.identifier(mask='@@-@@/@@') == 'KH-IW/DY'
        assert p.identifier(mask='##-##/##') == '07-97/04'
        assert p.identifier(mask='##-##/##', placeholder='#') == '07-97/04'

# Generated at 2022-06-23 21:46:47.101143
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Provider().nationality() in NATIONALITIES
    assert Provider().nationality(gender='male') in NATIONALITIES
    assert Provider().nationality(gender='female') in NATIONALITIES
    assert Provider().nationality(gender='not known') in NATIONALITIES
    assert Provider().nationality(gender=0) in NATIONALITIES
    assert Provider().nationality(gender=1) in NATIONALITIES
    assert Provider().nationality(gender=2) in NATIONALITIES
    assert Provider().nationality(gender=9) in NATIONALITIES
    assert Provider().nationality(gender=Gender.MALE) in NATIONALITIES
    assert Provider().nationality(gender=Gender.FEMALE) in NATIONALITIES
    assert Provider().nationality(gender=Gender.NOT_KNOWN) in NATIONALITIES

# Generated at 2022-06-23 21:46:48.069084
# Unit test for method university of class Person
def test_Person_university():
    assert Person().university() in Person.university

# Generated at 2022-06-23 21:46:50.975041
# Unit test for method university of class Person
def test_Person_university():
    """
    Unit test for method university of class Person
    """
    p1=Person()
    assert(p1.university() in p1._data['university'])


# Generated at 2022-06-23 21:46:52.225742
# Unit test for method language of class Person
def test_Person_language():
    p = Person()
    assert isinstance(p.language(), str)

# Generated at 2022-06-23 21:46:58.145090
# Unit test for method first_name of class Person
def test_Person_first_name():
    from faker import Faker
    fake = Faker(locale='ru_RU')
    assert isinstance(fake.first_name(), str)
    assert isinstance(fake.first_name(gender=Gender.MALE), str)
    assert isinstance(fake.first_name(gender=Gender.FEMALE), str)

# Generated at 2022-06-23 21:47:01.007337
# Unit test for method surname of class Person
def test_Person_surname():
    r = Person()

    assert isinstance(r.surname(), str)
    assert r.surname() in r._data['surname']


# Generated at 2022-06-23 21:47:10.861575
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from random import Random
    from faker import Faker
    from faker.config import DEFAULT_LOCALE
    person = Faker(locale=DEFAULT_LOCALE, generator=Random())
    # Test the random social network
    social_media_profile = person.social_media_profile()
    assert type(social_media_profile) == str
    assert social_media_profile.lower().startswith('http')
    assert social_media_profile[0:8] + social_media_profile[12:15] in SOCIAL_NETWORKS.values()
    # Test the specific social network
    valid_networks = list(SOCIAL_NETWORKS.keys())
    for network in valid_networks:
        if network == 'LinkedIn':
            social_media_profile = person.social_media_profile(network)
           

# Generated at 2022-06-23 21:47:13.333838
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """Unit test for method blood_type of class Person."""
    provider = Person()
    assert provider.blood_type() in BLOOD_GROUPS

# Generated at 2022-06-23 21:47:15.500138
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    assert person.occupation().startswith('A')

# Generated at 2022-06-23 21:47:17.296549
# Unit test for method title of class Person
def test_Person_title():
    for i in range(1):
        assert len(Person().title()) in range(2, 25)


# Generated at 2022-06-23 21:47:26.393495
# Unit test for method email of class Person
def test_Person_email():
    from hypothesis import given, assume, settings
    import hypothesis.strategies as st
    from string import ascii_letters


    @settings(max_examples=500, deadline=None)
    @given(
        domains=st.lists(
            elements=st.text(min_size=1, max_size=20,
                             alphabet=ascii_letters),
            min_size=1, max_size=10),
        unique=st.booleans(),
    )
    def test(domains, unique):
        p = Person(domains=domains, unique=unique)
        assume(isinstance(domains, list))
        assume(isinstance(unique, bool))
        assume(len(domains) >= 1)
        assert isinstance(p.email(), str)

# Generated at 2022-06-23 21:47:28.208732
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert Person().sexual_orientation() in SEXUALITY



# Generated at 2022-06-23 21:47:35.159953
# Unit test for method email of class Person
def test_Person_email():
    """Test for random method Person.email()
    """
    # test 1
    def test_Person_email_true_1():
        """Test for random method Person.email()
        """
        # check for True
        person = Person()
        email = person.email()
        assert bool(email) == True
    # test 2
    def test_Person_email_true_2():
        """Test for random method Person.email()
        """
        # check for True
        person = Person()
        unique = True
        email = person.email(unique=unique)
        assert bool(email) == True
    # test 3
    def test_Person_email_true_3():
        """Test for random method Person.email()
        """
        # check for True
        person = Person()

# Generated at 2022-06-23 21:47:43.645610
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username(template='U_d') == 'M_67'
    assert Person().username(template='U.d') == 'S.63'
    assert Person().username(template='U-d') == 'P-57'
    assert Person().username(template='UU-d') == 'MU-66'
    assert Person().username(template='UU.d') == 'GI.82'
    assert Person().username(template='UU_d') == 'IS_89'
    assert Person().username(template='ld') == 'r37'
    assert Person().username(template='l-d') == 'r-81'
    assert Person().username(template='Ud') == 'R74'
    assert Person().username(template='l.d') == 'p.91'

# Generated at 2022-06-23 21:47:50.211527
# Unit test for method email of class Person
def test_Person_email():
    # Case 1: «unique» is False
    person = Person(random=7)
    for _ in range(100):
        assert '@' in person.email()
    # Case 2: «unique» is True
    person = Person(random=7)
    for _ in range(100):
        assert len(person.email(unique=True)) == 9 + 1 + len(EMAIL_DOMAINS[0])
    # Case 3: «domains» is not None
    person = Person(random=7)
    for _ in range(100):
        email = person.email(domains=('jazz.ru', 'google.com', 'yandex.ru'))
        assert email.rsplit('@', 1)[-1] in ('jazz.ru', 'google.com', 'yandex.ru')
    #

# Generated at 2022-06-23 21:47:52.393131
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    a = person.language()
    print(a)

# Generated at 2022-06-23 21:47:54.491311
# Unit test for method last_name of class Person
def test_Person_last_name():
    tester = Person()
    answer = tester.last_name()
    assert answer is not None

# Generated at 2022-06-23 21:47:56.080515
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert len(Person().views_on()) > 0, "Failed!"


# Generated at 2022-06-23 21:48:03.204527
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    global work_experience
    global years
    global months
    global days
    global random
    global Person

    random = Random()
    Person = Person(random)

    years = (1,10)
    months = (1,12)
    days = (1,30)
    work_experience = Person.work_experience(years,months,days)
    print(work_experience)
    assert work_experience is not None

test_Person_work_experience()

# Generated at 2022-06-23 21:48:05.674472
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person()
    result = provider.social_media_profile(SocialNetwork.VK)
    assert result == 'https://vk.com/some_user'


# Generated at 2022-06-23 21:48:11.221544
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()

    # Act
    surname_1 = person.surname()
    surname_2 = person.surname()
    surname_3 = person.surname()

    # Assert
    assert surname_1 != surname_2 != surname_3

# Generated at 2022-06-23 21:48:20.218395
# Unit test for method sex of class Person
def test_Person_sex():
    faker = Faker()
    
    sex = faker.sex(symbol=True)
    
    try:
        unicode_literals.encode('ascii', 'backslashreplace')
    except NameError:
        pass
    else:
        assert isinstance(sex, str)
        
    try:
        eval('u""')
    except SyntaxError:
        pass
    else:
        assert isinstance(sex, str)
    
    assert isinstance(sex, str)
    
    try:
        eval("u''")
    except SyntaxError:
        pass
    else:
        assert isinstance(sex, str)
    
    assert isinstance(sex, str)
    
    assert sex != 'Male'
    
    assert sex != 'Female'
    

# Generated at 2022-06-23 21:48:22.939788
# Unit test for method nationality of class Person
def test_Person_nationality():
    
    #Test that nationality is a string and is equal to 'Brazillian'
    
    nationality = Person().nationality(Gender.MALE)
    assert isinstance(nationality, str)
    assert nationality == 'Brazillian'


# Generated at 2022-06-23 21:48:25.916471
# Unit test for method avatar of class Person
def test_Person_avatar():
    # Test arguments
    size = 256

    # Test function
    person = Person(random=Random(seed=10))
    avatar = person.avatar(size=size)
    assert avatar == 'https://api.adorable.io/avatars/256/df0d0b4a4b4ff7b4a0b30e7c0bd22d9d.png'



# Generated at 2022-06-23 21:48:33.942523
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    random = random_gen()
    p = Person(random)
    lst = []
    for _ in range(1000000):
        lst.append(p.sexual_orientation())
    assert 'Serodiscordant' in lst
    assert 'Dyadic' in lst
    assert 'Androphilia' in lst
    assert 'Asexual' in lst
    assert 'Aromantic' in lst
    assert 'Pansexual' in lst
    assert 'Heterosexual' in lst

# Generated at 2022-06-23 21:48:35.553915
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    print(person.academic_degree())

# Generated at 2022-06-23 21:48:39.135045
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    assert person.name(Gender.FEMALE).isalpha()
    assert person.name(Gender.MALE).isalpha()
    

# Generated at 2022-06-23 21:48:42.118534
# Unit test for method gender of class Person
def test_Person_gender():
    genders = [Person().gender() for _ in range(100)]
    assert set(genders) == {'Male', 'Female', 'Androgyne'}



# Generated at 2022-06-23 21:48:50.005141
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person(seed=89)
    # person is an object of class Person.
    assert type(person) == Person
    # value of gender is None.
    # The gender will be chosen randomly.
    assert person.first_name(gender=None) == 'Alexander'
    assert person.first_name(gender=None) == 'Alexander'
    assert person.first_name(gender=None) == 'Sergey'
    assert person.first_name(gender=None) == 'Sergey'
    assert person.first_name(gender=None) == 'Victor'

# Generated at 2022-06-23 21:48:51.162088
# Unit test for method university of class Person
def test_Person_university():
    p = Person()
    assert isinstance(p.university(), str)


# Generated at 2022-06-23 21:49:04.205846
# Unit test for method political_views of class Person
def test_Person_political_views():
    import pytest
    # Create an instance of Person class
    person = Person(random=Random())
    # Generate a random political views
    result = person.political_views()
    # Check
    assert result in ['Conservative', 'Liberal', 'Moderate', 'Libertarian',
                      'Green', 'Socialist', 'Centrist', 'Anarchist',
                      'Communist', 'Fascist', 'Progressive', 'Monarchist',
                      'Tory', 'Tory', 'Tory', 'Tory', 'Tory', 'Tory',
                      'Tory', 'Tory', 'Tory', 'Tory', 'Tory', 'Tory',
                      'Tory', 'Tory', 'Tory', 'Tory', 'Tory', 'Tory',
                      'Tory', 'Tory', 'Tory']


# Unit test

# Generated at 2022-06-23 21:49:11.630442
# Unit test for method password of class Person
def test_Person_password():
    password_patterns = [
        r'^[\w\d\s~`!@#$%^&*()-_=+\[\]{};:"<>,./?\\|]{8}$',
        r'^[\w\d\s~`!@#$%^&*()-_=+\[\]{};:"<>,./?\\|]{16}$',
        r'^[\w\d\s~`!@#$%^&*()-_=+\[\]{};:"<>,./?\\|]{64}$'
    ]
    for patern in password_patterns:
        assert re.match(patern, Person().password())

# Generated at 2022-06-23 21:49:13.909087
# Unit test for method political_views of class Person
def test_Person_political_views():
    provider = Person(seed=1996)
    result = provider.political_views()
    assert result == 'Communism', 'incorrect'

# Generated at 2022-06-23 21:49:17.430483
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person(seed=1)

    assert person.weight() == 60
    assert person.weight() == 89
    assert person.weight() == 89
    assert person.weight(minimum=140, maximum=150) == 142
    assert person.weight(minimum=10, maximum=200) == 47

# Generated at 2022-06-23 21:49:20.062604
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    assert isinstance(person.political_views(), str)

# Generated at 2022-06-23 21:49:25.041917
# Unit test for method password of class Person
def test_Person_password():
    user = Person()
    password = 'f1F6D?asdf'
    assert user.password(hashe=True) != user.password()
    assert user.password(hashe=True) == user.password(password, True)
    assert user.password(hashe=True) != user.password(password)

# Generated at 2022-06-23 21:49:31.610054
# Unit test for method username of class Person
def test_Person_username():
    "Person.username() test"

    # Test without passing any value
    result = fake.username()
    assert result is not None, "The result should be a string"

    # Test with passing a custom template
    result = fake.username(template="UU_d")
    assert result is not None, "The result should be a string"
    assert result.startswith('U'), "The result should start with \"U\""
    assert result.endswith('_d'), "The result should end with \"_d\""
    assert "_" in result, "The result should contain \"_\""
    assert result[0].isupper(), "The result should contain uppercase"

    # Test with passing an unsupported template

# Generated at 2022-06-23 21:49:42.054052
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Initialize Faker generator
    fake = Faker()
    # Get a random social network
    social_network = get_random_item(SocialNetwork, rnd=fake.random)
    # Get a random username
    username = fake.username()
    # Generate a profile for social network
    profile = fake.social_media_profile(site=social_network)
    # Get a random social network URL
    social_network_url = get_random_item_by_attr(SocialNetwork, 'url', rnd=fake.random)
    # Get a random social network name
    social_network_name = get_random_item_by_attr(SocialNetwork, 'name', rnd=fake.random)
    # Format expected value of URL
    expected_url = social_network_url.format(username)
    # Format expected value of URL

# Generated at 2022-06-23 21:49:43.684500
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert provider.seed is None
    assert isinstance(provider.random, Random)
    assert provider._data


# Generated at 2022-06-23 21:49:47.590437
# Unit test for method password of class Person
def test_Person_password():
    print("Test Person.password() ...")
    p = Person()
    p.set_locale("ru-RU")
    password = p.password(length=12, hashed=False)
    print(password)
    assert isinstance(password, str)
    assert len(password) == 12
    assert isinstance(p.password(length=12, hashed=True), str)


# Generated at 2022-06-23 21:49:56.697496
# Unit test for method sex of class Person
def test_Person_sex():
    import unittest
    from pprint import pprint
    from faker.utils import TEST_MODE
    from faker.config import AVAILABLE_LOCALES as LOCALES

    class TestPerson(unittest.TestCase):
        """Test class Person."""

        @classmethod
        def setUpClass(cls):
            cls.tester = Person('en')

        def test_sex(self):
            for _ in range(100):
                result = self.tester.sex()
                self.assertIn(result, self._data())

        def test_sex__symbol(self):
            for _ in range(100):
                result = self.tester.sex(symbol=True)
                self.assertIn(result, self._data(True))


# Generated at 2022-06-23 21:49:59.896505
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    
    # Testing method occupation
    occ = person.occupation()
    assert occ in OCCUPATIONS, "Error in method occupation: %s" % occ

# Generated at 2022-06-23 21:50:07.470976
# Unit test for method occupation of class Person

# Generated at 2022-06-23 21:50:19.556652
# Unit test for method worldview of class Person
def test_Person_worldview():
    faker = Faker()
    worldview1 = ['Agnosticism', 'Atheism', 'Buddhism', 'Deism',
                  'Judaism', 'Panentheism', 'Pantheism', 'Pastafarianism',
                  'Shinto', 'Taoism', 'Secular Humanism', 'Theism',
                  'Unitarian Universalism', 'Zoroastrianism', 'Humanism',
                  'God', 'Nature', 'Nihilism']

# Generated at 2022-06-23 21:50:22.678830
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    s = Person(seed=7)
    assert s.work_experience(minimum_experience=2, maximum_experience=3) == '3 месяцев <br>'

# Generated at 2022-06-23 21:50:26.713360
# Unit test for constructor of class Person
def test_Person():
    from random import Random
    _ = Person(Random(seed=1))
    _ = Person(Random(seed=2))

if __name__ == '__main__':
    p = Person()
    print(p.email())

# Generated at 2022-06-23 21:50:32.300092
# Unit test for method weight of class Person
def test_Person_weight():
    # Test Person.weight method with full parametrs
    assert Person().weight(minimum=0, maximum=10) <= 10
    assert Person().weight(minimum=0, maximum=10) >= 0

    assert Person().weight(minimum=0, maximum=0) == 0

    # Test Person.weight method with default parametrs
    assert Person().weight() <= 90
    assert Person().weight() >= 38

# Generated at 2022-06-23 21:50:41.950729
# Unit test for method first_name of class Person
def test_Person_first_name():
    provider = Person()

    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    assert provider.first_name() != provider.first_name()
    # Checking that names are the same for the specified gender

# Generated at 2022-06-23 21:50:49.013908
# Unit test for method worldview of class Person
def test_Person_worldview():
    obj = Person()
    worldview = obj.worldview()
    assert worldview in ['Pantheism',
                         'Agnosticism',
                         'Deism',
                         'Theism',
                         'Spiritualism',
                         'Positivism',
                         'Materialism',
                         'Idealism',
                         'Pluralism',
                         'Apatheism',
                         'Atheism',
                         'Cynicism',
                         'Idealism',
                         'Nihilism',
                         'Fatalism',
                         'Naturism']


# Generated at 2022-06-23 21:50:50.748429
# Unit test for method worldview of class Person
def test_Person_worldview():
    worldview = Person.worldview()
    assert worldview in PERSON_WORLDVIEW


# Generated at 2022-06-23 21:50:53.006629
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person(seed=0)
    assert person.academic_degree() == 'Bachelor', 'Method academic_degree failed.'

# Generated at 2022-06-23 21:50:56.513809
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert len(Person().nationality()) > 0
    assert (Person().nationality('Українська').lower() == 'українська')
