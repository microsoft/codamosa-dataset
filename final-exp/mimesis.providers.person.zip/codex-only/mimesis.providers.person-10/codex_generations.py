

# Generated at 2022-06-23 21:41:02.041075
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = PersonProvider()

    # test default value
    result = str(provider.telephone())
    assert isinstance(result, str)
    assert len(result) == 12

    # test with custom mask
    result = str(provider.telephone(mask='##-##-##-##'))
    assert isinstance(result, str)
    assert len(result) == 11

    # test with mask and placeholder
    result = str(provider.telephone(mask='@@-@@-@@/@@', placeholder='@'))
    assert isinstance(result, str)
    assert len(result) == 11

# Generated at 2022-06-23 21:41:05.553417
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    provider = Faker.get_provider('ru')
    for i in range(10):
        assert provider.nationality() in RU_NATIONALITY

# Generated at 2022-06-23 21:41:09.175160
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person(seed=1)
    person.random.choice = lambda x: x[3]
    result = person.last_name()
    assert result == "Морозова"


# Generated at 2022-06-23 21:41:12.724062
# Unit test for method avatar of class Person
def test_Person_avatar():
    avatar = Person().avatar()
    assert re.match('https://api.adorable.io/avatars/[0-9]*/[0-9a-f]*\.png',
                    avatar) is not None

# Generated at 2022-06-23 21:41:15.450026
# Unit test for method sex of class Person
def test_Person_sex():
    provider = faker.Factory.create()
    assert provider.sex() in SEXES

# Generated at 2022-06-23 21:41:18.715827
# Unit test for method username of class Person
def test_Person_username():
    pr = Person()
    result = pr.username()
    assert result != ''
    assert type(result) == str

# Generated at 2022-06-23 21:41:20.748890
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    avatar = person.avatar()
    # print(avatar)


# Generated at 2022-06-23 21:41:24.882496
# Unit test for method views_on of class Person
def test_Person_views_on():
    for i in range(0,10):
        view = Person.views_on()
        if (view == "Negative") or (view == "Neutral") or (view == "Positive") or (view == "Undecided") or (view == "I don't care"):
            continue
        else:
            return False
    return True
print(test_Person_views_on())

import unittest

# Generated at 2022-06-23 21:41:26.882155
# Unit test for method worldview of class Person
def test_Person_worldview():
    from faker import Faker
    fake = Faker()
    worldview = fake.worldview()
    assert worldview in Person.WORLDVIEW


# Generated at 2022-06-23 21:41:28.569282
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert isinstance(Person.sexual_orientation(), str)

# Generated at 2022-06-23 21:41:29.958694
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person()
    assert p.occupation() == 'Manager'

# Generated at 2022-06-23 21:41:32.044755
# Unit test for method username of class Person
def test_Person_username():
    exp = 'l.d'
    act = Person().username()

    assert re.fullmatch(exp, act) is not None, \
        'Error in Person.username() method'


# Generated at 2022-06-23 21:41:37.196770
# Unit test for method gender of class Person
def test_Person_gender():
    """Test method gender of class Person"""

    test_values = [Gender.FEMALE, Gender.MALE, None, 'female', 'male', 'xxx']
    check_values = [Gender.FEMALE, Gender.MALE]
    with pytest.raises(NonEnumerableError):
        check_values.append(from_string(Gender, test_values[5]))

    person = Person('en')
    for value in test_values:
        with pytest.raises(NonEnumerableError):
            person.gender(value)

    person.gender('female')

    person.gender(Gender.MALE)
    person.gender(Gender.FEMALE)
    person.gender()

# Generated at 2022-06-23 21:41:40.740277
# Unit test for method language of class Person
def test_Person_language():
    fake = Faker()
    assert fake.language() in fake._data['language']
    assert isinstance(fake.language(), str)
    assert fake.language() is not ''


# Generated at 2022-06-23 21:41:48.588995
# Unit test for method surname of class Person
def test_Person_surname():
  assert len(Person.surname('RU', 'male')) > 1
  assert len(Person.surname('RU', 'female')) > 1
  assert len(Person.surname('RU')) > 1
  assert len(Person.surname()) > 1
  assert len(Person.last_name('RU', 'male')) > 1
  assert len(Person.last_name('RU', 'female')) > 1
  assert len(Person.last_name('RU')) > 1
  assert len(Person.last_name()) > 1

# Generated at 2022-06-23 21:41:50.202172
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    obj = Person()
    assert isinstance(obj.sexual_orientation(), str)


# Generated at 2022-06-23 21:41:52.842441
# Unit test for method title of class Person
def test_Person_title():
    # Arrange
    person = Person()

    # Act
    title = person.title()

    # Assert
    assert title is not None
    assert title != ' '
    assert title != ''
    assert isinstance(title, str)


# Generated at 2022-06-23 21:41:54.941102
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationality = Person().nationality()
    assert nationality.isalpha()
    assert len(nationality)>=3
test_Person_nationality()

# Generated at 2022-06-23 21:41:58.373990
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    """Test social_media_profile method of class Person."""
    for provider in PROVIDERS:
        for site in SocialNetwork:
            assert provider.social_media_profile(site) != \
                   provider.social_media_profile(site)
        print('{0}.social_media_profile() - ok'.format(provider.__class__.__name__))

# Generated at 2022-06-23 21:42:00.899604
# Unit test for method title of class Person
def test_Person_title():
    assert Person.title(gender = Gender.MALE, title_type = TitleType.PREFIX) == "Mr."

# Generated at 2022-06-23 21:42:02.334240
# Unit test for method height of class Person
def test_Person_height():
    height = Person.height(0, 0)
    assert height is not None

# Generated at 2022-06-23 21:42:03.911066
# Unit test for constructor of class Person
def test_Person():
    try:
        Person()
    except Exception as e:
        assert False, \
            'An error occurred creating an instance of Person: {}'.format(e)


# Generated at 2022-06-23 21:42:14.232802
# Unit test for method username of class Person
def test_Person_username():
    pl = Person()

    assert(pl.username(template='UU-d') == 'Jon1863')
    assert(pl.username(template='UU_d') == 'Jon_1863')
    assert(pl.username(template='UU.d') == 'Jon.1863')
    assert(pl.username(template='U_d') == 'J1863')
    assert(pl.username(template='U.d') == 'J.1863')
    assert(pl.username(template='U-d') == 'J-1863')
    assert(pl.username(template='ld') == 'j1863')
    assert(pl.username(template='l_d') == 'j_1863')
    assert(pl.username(template='l.d') == 'j.1863')

# Generated at 2022-06-23 21:42:18.483485
# Unit test for method full_name of class Person
def test_Person_full_name():
    # check correctness with different genders
    assert Person.full_name('man') in ('Arnold Schwarzenegger', 'Michael Jordan',
                                       'Dmitriy Sotnikov', 'Barack Obama')
    assert Person.full_name('woman') in ('Taylor Swift', 'Adele',
                                         'Sophia Loren', 'Bianca Andreescu')


# Generated at 2022-06-23 21:42:21.375360
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()

    for _ in range(100):
        assert person.blood_type() in BLOOD_GROUPS

# Generated at 2022-06-23 21:42:24.896024
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert re.fullmatch('\w+@\S+\.\S{2,4}', p.email()) is not None, \
        'Method Person.email() does not work'

# Generated at 2022-06-23 21:42:29.263810
# Unit test for method occupation of class Person
def test_Person_occupation():
    test_cases = [
        {
            'method': 'occupation'
        }
    ]
    provider = Person()
    for test_case in test_cases:
        method = getattr(provider, test_case['method'])
        result = method()
        assert result is not None

# Generated at 2022-06-23 21:42:36.140040
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    from collections import Counter
    from pprint import pprint

    def get_sex():
        return get_random_item(Sex, rnd=self.random)

    def get_blood_type():
        return p.blood_type()

    iterations = 10000
    results = Counter()
    p = Person()

    for _ in range(iterations):
        results[get_blood_type()] += 1

    pprint(results)

# Generated at 2022-06-23 21:42:44.556065
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Unit test for method telephone of class Person"""
    from .providers import BaseProvider
    from .enums import Gender, TitleType

    provider = Person(BaseProvider())

    assert provider.age() in range(18, 101)
    assert provider.name(Gender.MALE) in provider._data['name']['male']
    assert provider.name(Gender.FEMALE) in provider._data['name']['female']
    assert provider.surname(Gender.MALE) in provider._data['surname']['male']
    assert provider.surname(Gender.FEMALE) in provider._data['surname']['female']
    assert provider.last_name(Gender.MALE) in provider._data['surname']['male']

# Generated at 2022-06-23 21:42:47.813110
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)
    assert hasattr(p, 'nationality')
    assert callable(getattr(p, 'nationality'))


# Generated at 2022-06-23 21:42:50.228894
# Unit test for method height of class Person
def test_Person_height():
    human = Person()
    assert 1.0 <= float(human.height()) <= 2.1

# Generated at 2022-06-23 21:43:01.148311
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from datetime import datetime
    from pyfaker.exceptions import SeedRequiredError
    from pyfaker import enums
    from pyfaker.utils import random_time_expr

    random_time = random_time_expr(time_format='%Y.%m.%d')
    rnd = random.Random(42)

    person = Person(rnd=rnd, seed=42)
    assert person.work_experience(start_date=random_time) == (
        datetime(2018, 8, 17), datetime(2019, 2, 12))

    person = Person(seed=42)
    assert person.work_experience(start_date=random_time) == (
        datetime(2018, 8, 17), datetime(2019, 2, 12))

    person = Person(rnd=rnd)
   

# Generated at 2022-06-23 21:43:05.077220
# Unit test for method height of class Person
def test_Person_height():

    person = Person()

    for i in range(100):
        height = person.height()
        assert isinstance(height, str)
        assert re.match(r'\d{1,3}\.\d+$', height)



# Generated at 2022-06-23 21:43:14.799144
# Unit test for method username of class Person
def test_Person_username():
    cls = Person
    obj = Person()
    obj.seed(0)
    assert obj.username() == 'Ivory.14'
    assert obj.username(template='Ud') == 'Pepper3308'
    assert obj.username(template='l.d') == 'w.0'
    assert obj.username(template='U_d') == 'Alexandra9361'
    assert obj.username(template='l_d') == 'g_1925'
    assert obj.username(template='ld') == 'p0'
    assert obj.username(template='U.d') == 'Minnie1572'
    assert obj.username(template='l.d') == 'f.0'
    assert obj.username(template='U-d') == 'Zoe-927'

# Generated at 2022-06-23 21:43:16.888371
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    test_data = person.sexual_orientation()
    assert test_data in SEXUAL_ORIENTATIONS

# Generated at 2022-06-23 21:43:18.973206
# Unit test for method gender of class Person
def test_Person_gender():
    from faker import Faker

    fake = Faker('en')

    assert fake.gender() in fake._data['gender']

# Generated at 2022-06-23 21:43:20.485883
# Unit test for method full_name of class Person
def test_Person_full_name():
    provider = Person()
    result = provider.full_name()
    assert isinstance(result, str) and result

# Generated at 2022-06-23 21:43:26.197000
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person(random=Random())
    assert p.gender(iso5218=False) == 'Male'
    assert p.gender(symbol=False) == 'Male'
    assert p.gender(iso5218=True) in [0, 1, 2, 9]
    assert p.gender(symbol=True) in ['♂', '♀', '⚧']


# Generated at 2022-06-23 21:43:28.954160
# Unit test for method title of class Person
def test_Person_title():
    for x in range(10):
        assert Person.title() in ['Dr.', 'Mr.', 'Mrs.', 'Mx.', 'Prof.', 'Ms.', 'Jr.', 'Sr.', 'Miss', 'Hon.']

# Generated at 2022-06-23 21:43:33.469263
# Unit test for method avatar of class Person
def test_Person_avatar():
    test_counter = 0
    for _ in range(1000):
        url = Person().avatar()
        r = requests.get(url)
        if r.status_code == requests.codes.ok:
            test_counter += 1
    assert test_counter > 300



# Generated at 2022-06-23 21:43:34.584755
# Unit test for constructor of class Person
def test_Person():
    Person
    assert True


# Generated at 2022-06-23 21:43:46.870615
# Unit test for method username of class Person
def test_Person_username():
    p = Person(seed=123, locale='en_US')

    assert p.username(template='d') == '18'
    assert p.username(template='l') == 'w'
    assert p.username(template='Ud') == 'O18'
    assert p.username(template='UUd') == 'Ie18'
    assert p.username(template='ld') == 'wi18'
    assert p.username(template='U-d') == 'O-18'
    assert p.username(template='U.d') == 'O.18'
    assert p.username(template='U_d') == 'O_18'
    assert p.username(template='UU-d') == 'Ie-18'
    assert p.username(template='UU.d') == 'Ie.18'
    assert p.username

# Generated at 2022-06-23 21:43:51.275588
# Unit test for method name of class Person
def test_Person_name():
    get_name = Person()
    try:
        assert(str(type(get_name.name())) == "<class 'str'>")
    except AssertionError:
        print("name is not type of str")

# Generated at 2022-06-23 21:43:54.093056
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    print(p.telephone())
    # 8-(911)-368-13-45


# Generated at 2022-06-23 21:43:55.512254
# Unit test for method height of class Person
def test_Person_height():
    obj = Person().height()
    assert obj is not None


# Generated at 2022-06-23 21:44:00.256983
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    gender = person.random.choice([Gender.MALE, Gender.FEMALE])
    surname = person.surname(gender)

    print(surname)
    print(person.__doc__)


# Generated at 2022-06-23 21:44:04.034015
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert isinstance(Person().blood_type(), str)
    assert Person().blood_type().upper() in ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")
    
    

# Generated at 2022-06-23 21:44:15.356160
# Unit test for method email of class Person
def test_Person_email():
    r = Person()
    assert re.match(r'^[a-z0-9]*@[a-z.]*$', r.email())
    r = Person()
    assert re.match(r'^[a-z0-9]*@[a-z.]*$', r.email())
    r = Person()
    assert re.match(r'^[a-z0-9]*@[a-z.]*$', r.email())
    r = Person()
    assert re.match(r'^[a-z0-9]*@[a-z.]*$', r.email())
    r = Person()
    assert re.match(r'^[a-z0-9]*@[a-z.]*$', r.email())
    r = Person()
    assert re

# Generated at 2022-06-23 21:44:16.496567
# Unit test for method height of class Person
def test_Person_height():
    Person = Person()
    Person.height()


# Generated at 2022-06-23 21:44:19.819136
# Unit test for constructor of class Person
def test_Person():
    # Instantiate the class
    person = Person()

    # Check instance
    assert isinstance(person, Person) == True
    assert person.__doc__ == 'Fake data generator for personal information.'
    assert isinstance(person.random, random.Random) == True
    assert hasattr(person, 'seed') == True


# Generated at 2022-06-23 21:44:21.013366
# Unit test for method university of class Person
def test_Person_university():
    get_random_university = Person().university
    university = 'Hunan University'
    assert get_random_university() in university


# Generated at 2022-06-23 21:44:27.113835
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person().identifier() == '79-09/91'
    assert Person().identifier(mask='@A-@A/@A') == 'sO-kZ/xO'
    assert Person().identifier(mask='@AA-@AA/@AA') == 'aZb-wDg/fMv'
    assert Person().identifier(mask='@AAA-@AAA/@AAA') == 'iHjR-rFxU/rPkY'

    # The number of digits must be at least 1.
    with pytest.raises(ValueError):
        Person().identifier(mask='@@@-@@@/@@@')

    # The number of characters must be at least 1.
    with pytest.raises(ValueError):
        Person().identifier(mask='###-###/###')

   

# Generated at 2022-06-23 21:44:29.023714
# Unit test for method height of class Person
def test_Person_height():
    provider = Person()
    result = provider.height(0.2, 2)
    assert isfloat(result)
    result = float(result)
    assert result >= 0.2
    assert result <= 2

# Generated at 2022-06-23 21:44:35.160321
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    p.seed(1234)
    for i in range(0, 10):
        result = p.weight(minimum=38, maximum=90)
        assert result in range(38, 90 + 1)
        assert len(str(result)) == 2

    p.seed(1234)
    for i in range(0, 10):
        assert p.weight(minimum=38, maximum=90) == 51


# Generated at 2022-06-23 21:44:38.678150
# Unit test for method occupation of class Person
def test_Person_occupation():
    # The test that checks the method of getting a random job
    person = Person()
    occupation = person.occupation()
    assert occupation in person._data['occupation']
    print('OK!')


test_Person_occupation()

# Generated at 2022-06-23 21:44:43.845381
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():

    # Unit test for method sexual_orientation of class Person with param symbol
    res = [Person().sexual_orientation(symbol=True) for i in range(100)]
    assert len(set(res)) > 1

    # Unit test for method sexual_orientation of class Person without param symbol
    res = [Person().sexual_orientation() for i in range(100)]
    assert len(set(res)) > 1



# Generated at 2022-06-23 21:44:46.939133
# Unit test for method name of class Person
def test_Person_name():
    '''
    Test method Person.name
    '''
    male = Person.name(Gender.MALE)
    assert isinstance(male, str) and len(male)

    female = Person.name(Gender.FEMALE)
    assert isinstance(female, str) and len(female)


# Generated at 2022-06-23 21:44:48.184935
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    occupation = person.occupation()
    assert isinstance(occupation, str)



# Generated at 2022-06-23 21:44:50.953605
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    r = Person(seed=1)
    for _ in range(10):
        assert r.social_media_profile(site='Google') == r.social_media_profile()



# Generated at 2022-06-23 21:44:54.573935
# Unit test for method full_name of class Person
def test_Person_full_name():
    """Test method full_name of class Person"""
    person = Person(seed=1)
    assert person.full_name() == 'Ray Parker'


# Generated at 2022-06-23 21:44:57.180757
# Unit test for method age of class Person
def test_Person_age():
    provider = Person()
    
    assert provider.age() in range(98)

# Generated at 2022-06-23 21:45:04.020948
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    PLACEHOLDER = '____'

    person = Person()
    wp = person.work_experience()
    assert wp.count(PLACEHOLDER) == 1, \
        'Unexpected work experience:: {}'.format(wp)

    # Check for groups
    for group in PERSON_GROUPS:
        person = Person(group=group)
        wp = person.work_experience()
        assert wp.count(PLACEHOLDER) == 1, \
            'Unexpected work experience:: {}'.format(wp)



# Generated at 2022-06-23 21:45:08.046097
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Provider(locale='ru')
    nationality = provider.nationality(gender=Gender.MALE)
    assert nationality in RU_NATIONALITIES['male']

    nationality = provider.nationality(gender=Gender.FEMALE)
    assert nationality in RU_NATIONALITIES['female']


# Generated at 2022-06-23 21:45:09.957310
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person.last_name(Person()) == 'Lamper'



# Generated at 2022-06-23 21:45:12.696941
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    social_media_profile = Person().social_media_profile()
    assert social_media_profile
test_Person_social_media_profile()


# Generated at 2022-06-23 21:45:14.158261
# Unit test for method telephone of class Person
def test_Person_telephone():
    value = Person().telephone()
    assert isinstance(value, str)
    assert len(value) >= 5
    

# Generated at 2022-06-23 21:45:16.064490
# Unit test for method title of class Person
def test_Person_title():
    print(Person().title(title_type=TitleType.prefix.value,gender=Gender.female.value))

# Generated at 2022-06-23 21:45:20.199001
# Unit test for method sex of class Person
def test_Person_sex():
    provider = Person(locale='ru')
    result = provider.sex()
    assert result in ['Мужской', 'Женский', 'Трансгендерный']

# Generated at 2022-06-23 21:45:23.118398
# Unit test for method height of class Person
def test_Person_height():
    for i in range(100):
        assert Person().height(1.5, 2.0) <= 2.0
        assert Person().height(1.5, 2.0) >= 1.5
        

# Generated at 2022-06-23 21:45:24.427408
# Unit test for method language of class Person
def test_Person_language():
    provider = Person()
    language = provider.language()

    assert isinstance(language, str)

# Generated at 2022-06-23 21:45:31.691745
# Unit test for method surname of class Person
def test_Person_surname():
    
    # Test Person.surname()
    person = Person(random.Random(7))
    assert person.surname() == 'Gordon'
    
    # Test Person.surname(gender)
    person = Person(random.Random(7))
    assert person.surname(gender=Gender.Male) == 'Gordon'
    assert person.surname(gender=Gender.Female) == 'Gordon'
    
    # Test Person.surname(gender) for male and female surnames
    person = Person(random.Random(7))

# Generated at 2022-06-23 21:45:35.367170
# Unit test for method views_on of class Person
def test_Person_views_on():
    provider = Person()
    test = provider.views_on()
    assert test in [
        'Negative', 'Positive', 'Neutral'
    ]

# Generated at 2022-06-23 21:45:46.336729
# Unit test for method title of class Person
def test_Person_title():
    # для проверки нашего кода, мы применим doctest - модуль для тестирования примеров в docstring
    import doctest
    # загрузим тесты
    doctest.testmod(verbose=1)  

test_Person_title()

# Задача: сделать модуль с тестами для методов Person
# Используйте д

# Generated at 2022-06-23 21:45:49.649965
# Unit test for method password of class Person
def test_Person_password():
    if Person.password() != "8w$$&%$#d2@":
        raise AssertionError()

# Generated at 2022-06-23 21:45:53.544533
# Unit test for method age of class Person
def test_Person_age():
    # Arrange
    p = Person(seed=1)

    # Act
    result = p.age()

    # Assert
    assert result == 19

age = Person(seed=1).age()


# Generated at 2022-06-23 21:45:55.994724
# Unit test for method name of class Person
def test_Person_name():
    try:
        pass
    except Exception:
        pass
    else:
        print('Method Person.name is OK')


# Generated at 2022-06-23 21:45:58.808984
# Unit test for method sex of class Person
def test_Person_sex():
    tester = Provider()
    answer = "Male"
    sex = tester.sex()
    assert sex == answer, f"Method sex() of class Person, sex = {sex}"



# Generated at 2022-06-23 21:46:03.813747
# Unit test for method name of class Person
def test_Person_name():
    p = Person()
    assert type(p.name()) == str
    assert len(p.name()) > 2
    assert type(p.name(Gender.MALE)) == str
    assert len(p.name(Gender.MALE)) > 2
    assert type(p.name(Gender.FEMALE)) == str
    assert len(p.name(Gender.FEMALE)) > 2
    assert type(p.name(Gender.NEUTRAL)) == str
    assert len(p.name(Gender.NEUTRAL)) > 2

# Generated at 2022-06-23 21:46:04.859800
# Unit test for method weight of class Person
def test_Person_weight():
  person = Person()
  assert person.weight() >= 38
  assert person.weight() <= 90
  

# Generated at 2022-06-23 21:46:07.987094
# Unit test for method title of class Person
def test_Person_title():
    assert Person.instance().title() != None
    assert Person.instance().title( gender = Gender.FEMALE ) != None
    assert Person.instance().title( title_type = TitleType.SUFFIX ) != None

# Generated at 2022-06-23 21:46:10.213067
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert isinstance(p, Person)


# Unit tests for method 'first_name' of class Person

# Generated at 2022-06-23 21:46:14.110956
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person()
    assert isinstance(p.occupation(), str)
test_Person_occupation()
test_Person_occupation()
test_Person_occupation()
test_Person_occupation()
test_Person_occupation()

# Generated at 2022-06-23 21:46:17.341553
# Unit test for method height of class Person
def test_Person_height():
    assert(Person().height() == Person().height())
    assert(isinstance(Person().height(), str))

# Generated at 2022-06-23 21:46:25.875449
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from datetime import datetime
    locale = 'en'
    person = Person(locale=locale)

    company_name = person.company()
    position = person.position()
    start_date = datetime.strftime(
        datetime.today() - timedelta(days=person.random.randint(1, 370)),
        '%b %Y'
    )
    work_experience = person.work_experience(
        **dict(company=company_name, position=position))
    assert start_date in work_experience
    assert company_name in work_experience
    assert position in work_experience

# Generated at 2022-06-23 21:46:31.488196
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    from faker.providers.person import Provider as Person

    rnd = random.Random(0)
    p = Person(random=rnd)

    assert p.sexual_orientation() == 'Heterosexuality'
    assert p.sexual_orientation(symbol=True) == '♀ ♂'
    assert p.sex(iso5218=True) == 1

# Generated at 2022-06-23 21:46:38.464482
# Unit test for method gender of class Person
def test_Person_gender():
    r = Random()
    r.seed(2)
    p = Person(seed = 2)

    assert isinstance(p.gender(), str)
    assert p.gender() == "Male"

    assert isinstance(p.gender(True), int)
    assert p.gender(True) == 1

    assert isinstance(p.gender(False, True), str)
    assert p.gender(False, True) == '♂'

    assert p.sex() == "Male"
    assert p.sex(True) == 1
    assert p.sex(False, True) == '♂'


# Generated at 2022-06-23 21:46:41.523429
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    person_occupation = person.occupation()

    assert person_occupation in OCCUPATION_LIST


# Generated at 2022-06-23 21:46:45.250275
# Unit test for method avatar of class Person
def test_Person_avatar():
    from collections import Counter

    c = Counter()

    for _ in range(1000):
        c[Person().avatar()] += 1

    assert c[next(iter(c))] < 10
# Testing method Person.nationality

# Generated at 2022-06-23 21:46:47.591160
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    for _ in range(100):
        assert isinstance(p.views_on(), str)



# Generated at 2022-06-23 21:46:52.736380
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    worldview = p.worldview()
    assert worldview in ('Monotheism', 'Polytheism', 'Agnosticism', 'Atheism', 'Deism', 'Pantheism', 'Humanism', 'Natural religion', 'Nihilism', 'Fatalism', 'Existentialism', 'Transcendentalism', 'Materialism', 'Spiritualism', 'Postmodernism', 'Other')


# Generated at 2022-06-23 21:47:04.681297
# Unit test for method weight of class Person
def test_Person_weight():
    from random import seed
    from pfaker.providers import Provider
    provider = Provider(seed=23)
    # Test with the minimum value
    assert int(provider.weight(minimum=0)) == 38
    # Test with the maximum value
    assert int(provider.weight(maximum=100)) == 90
    # Test with the default values
    assert int(provider.weight()) == 60
    # Test with the custom values
    weights = list(range(100, 110))
    for weight in weights:
        # Test with a seed
        assert int(provider.weight(minimum=100, maximum=110)) == weight
    # Test with values out of range
    with pytest.raises(ValueError) as exception_info:
        assert int(provider.weight(minimum=100, maximum=99))
    assert 'Invalid arguments'

# Generated at 2022-06-23 21:47:06.568425
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    result = person.views_on()

    assert type(result) == str
    assert len(result) > 0


# Generated at 2022-06-23 21:47:11.228890
# Unit test for method password of class Person
def test_Person_password():
    """
    Unit test for method password of class Person.
    """
    # Set up
    rnd = FakeRandom()
    fake = Faker(rnd)
    person = Person(fake)

    # Exercise
    actual = person.password()

    # Verify
    assert actual == "k6dv2odff9#4h"

    # Clean up - none necessary


# Generated at 2022-06-23 21:47:12.834279
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    result = person.university()
    assert result in PERSON_DATA.university



# Generated at 2022-06-23 21:47:16.678394
# Unit test for method surname of class Person
def test_Person_surname():
    print('\nTest surname: ')
    p = Person()
    print('\nGender: ')
    print(p.gender())
    print('\nSurname: ')
    print(p.surname())


# Generated at 2022-06-23 21:47:18.461403
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-23 21:47:27.002101
# Unit test for method title of class Person
def test_Person_title():
    provider = Person()

    assert provider.title(Gender.FEMALE) == 'Mrs.'

    assert provider.title(Gender.MALE) == 'Mr.'

    assert provider.title(Gender.FEMALE, TitleType.PREFIX) == 'Ms.'

    assert provider.title(Gender.MALE, TitleType.PREFIX) == 'Mr.'
# Unit tests for methods name, first_name of class Person

# Generated at 2022-06-23 21:47:29.562714
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person.full_name() != None
    assert isinstance(Person.full_name(), str) is True

# Generated at 2022-06-23 21:47:32.709301
# Unit test for method occupation of class Person
def test_Person_occupation():
    provider = Person()
    value = provider.occupation()
    assert value is not None
    assert value in provider.occupation.__doc__


# Generated at 2022-06-23 21:47:42.066271
# Unit test for method username of class Person
def test_Person_username():
    # num tests: 5
    # input:
    #   ['-', 'l', 'l', 'd', 'l']
    # output:
    #   -brb1923
    #   no4999
    #   nz4860
    #   nz9701
    #   nz2501
    random = Random()
    person = Person(random)
    template = '-l'
    expected = '-brb1923'
    actual = person.username(template)
    assert actual == expected
    template = 'l'
    expected = 'no4999'
    actual = person.username(template)
    assert actual == expected
    template = 'l'
    expected = 'nz4860'
    actual = person.username(template)
    assert actual == expected
    template = 'ld'

# Generated at 2022-06-23 21:47:44.058830
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert Person.social_media_profile(Site) == None
    assert Person.social_media_profile(Site, None) == None
    assert Person.social_media_profile(Site, None) == None
    

# Generated at 2022-06-23 21:47:48.842754
# Unit test for method age of class Person
def test_Person_age():
    p1 = Person()
    assert p1.age(5,8) >= 5
    assert p1.age(5,8) <= 8
    assert p1.age(5,8,include_max=True) >= 5
    assert p1.age(5,8,include_max=True) <= 8
    assert p1.age(5,8,include_max=False) >= 5
    assert p1.age(5,8,include_max=False) < 8
test_Person_age()

# Generated at 2022-06-23 21:47:52.219686
# Unit test for method political_views of class Person
def test_Person_political_views():
    provider = Person()
    political_view = provider.political_views()
    assert type(political_view) == str, 'The method political_views() must return a string.'


# Generated at 2022-06-23 21:47:54.322417
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()

    res = person.academic_degree()

    assert isinstance(res, str)

# Generated at 2022-06-23 21:48:05.082527
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    
    # WORK_EXPERIENCE = ('WORK_EXPERIENCE_STUDENT',
    #                    'WORK_EXPERIENCE_ONE_TWO',
    #                    'WORK_EXPERIENCE_THREE_FOUR',
    #                    'WORK_EXPERIENCE_FIVE_SIX',
    #                    'WORK_EXPERIENCE_SEVEN_EIGHT',
    #                    'WORK_EXPERIENCE_NINE_TEN',
    #                    'WORK_EXPERIENCE_ELEVEN_FIFTEEN',
    #                    'WORK_EXPERIENCE_SIXTEEN_TWENTY',
    #                    'WORK_EXPERIENCE_TWENTY_ONE_TWENTY_NINE',
    #                    'WORK_EXPERIENCE_THIRTY_PLUS')
    pass



# Generated at 2022-06-23 21:48:06.349656
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert Faker().first_name()


# Generated at 2022-06-23 21:48:14.210101
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    assert (p.title() in [
        'Dr', 'Mr', 'Miss', 'Mrs', 'Ms', 'Sir', 'Prof', 'Fr', 'Jr', 'Sr',
        'Drs', 'Mlle', 'Mme', 'Lord', 'Lady', 'Drn', 'Drng', 'Drgn', 'Drgja',
        'Czł', 'Człow', 'Członk', 'Czh', 'Czci'
    ])


# Generated at 2022-06-23 21:48:16.071015
# Unit test for method language of class Person
def test_Person_language():
    seed(1)
    p = Person()
    result = p.language()
    assert result == 'Russian', 'Result is not valid'

# Generated at 2022-06-23 21:48:23.943718
# Unit test for method username of class Person
def test_Person_username():
    faker = Person(locale='en')
    assert faker.username() == 'F.66'
    assert faker.username(template='UUU_d') == 'GiM14'
    assert faker.username(template='UU_d') == 'Ni8'
    assert faker.username(template='U_d') == 'He_88'
    assert faker.username(template='U.d') == 'Dd.53'
    assert faker.username(template='U-d') == 'Rt-25'
    assert faker.username(template='UU-d') == 'Wi-77'
    assert faker.username(template='UU.d') == 'Sp.08'
    assert faker.username(template='ld') == 'ha60'

# Generated at 2022-06-23 21:48:24.971917
# Unit test for method university of class Person
def test_Person_university():
    provider = Person()

    assert provider.university()

# Generated at 2022-06-23 21:48:29.251561
# Unit test for method telephone of class Person
def test_Person_telephone():
    count = 100

    person = Person(random=Random())

    masks = ('+7-(###)-###-##-##',
             '##-##-##-##',
             '+(##)-###-##-##-#-##',
             '(###)-(###)-(##)-(##)')

    for mask in masks:
        for _ in range(count):
            number = person.telephone(mask)
            assert re.fullmatch(re.sub('#', '\d', mask), number)


# Generated at 2022-06-23 21:48:29.924132
# Unit test for method weight of class Person
def test_Person_weight():
    pass

# Generated at 2022-06-23 21:48:31.982912
# Unit test for method age of class Person
def test_Person_age():
    """Testing method age() of class Person."""

    person = Person()
    age = person.age()

    assert isinstance(age, int)
    assert 0 <= age <= 120

# Generated at 2022-06-23 21:48:33.256825
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    height = person.height()
    assert isinstance(height, str)


# Generated at 2022-06-23 21:48:35.381789
# Unit test for method surname of class Person
def test_Person_surname():
    fr = tr.get('surname', 'es_ES')
    assert fr == 'Apellido'


# Generated at 2022-06-23 21:48:38.094418
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    phone = person.telephone()
    assert isinstance(phone, str)


# Generated at 2022-06-23 21:48:39.989511
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    assert isinstance(person.academic_degree(), str)


# Generated at 2022-06-23 21:48:50.935149
# Unit test for method identifier of class Person
def test_Person_identifier():
    G = Person()

    assert G.identifier() in {'0a-b9/0a', '0z-a3/0d'}
    assert G.identifier(mask='##-##/##') in {'43-94/31', '37-42/04'}
    assert G.identifier(mask='##@-##@/##') in {'4f-ff/e4', 'f7-13/8a'}
    assert G.identifier(mask='##@-##@/##@') in {'3q-28/v8', '2q-78/e5'}
    assert G.identifier(mask='@#@#@#@#@#@#') in {'f6g5k6a1l6m5', 'l9a8z8r6r5m5'}

# Generated at 2022-06-23 21:49:04.011440
# Unit test for method gender of class Person
def test_Person_gender():
    from random import seed
    from vlademir.providers.person import Person
    from enum import Enum

    class Gender(Enum):
        MALE = 'male'
        FEMALE = 'female'

    seed(555)

    # Test with specific gender
    assert Person().gender() in ('Male', 'Female')
    assert Person().gender(symbol=True) in ('♂', '♀')
    assert Person().gender(iso5218=True) in (0, 1, 2, 9)

    assert Person().gender(gender=Gender.MALE) == 'Male'
    assert Person().gender(gender=Gender.MALE, symbol=True) == '♂'
    assert Person().gender(gender=Gender.MALE, iso5218=True) == 1


# Generated at 2022-06-23 21:49:08.028776
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    for gender in [None, Gender.Male, Gender.Female, Gender.NotSet]:
        for title_type in [None, TitleType.Prefix, TitleType.Suffix]:
            title = person.title(gender, title_type)
            assert type(title) is str

# Generated at 2022-06-23 21:49:10.729336
# Unit test for method sex of class Person
def test_Person_sex():
    # Arrange
    from faker.providers.person.en_CA import Provider
    provider = Provider
    sex = provider.sex()
    # Act
    # Assert
    assert sex in provider._data['gender']


# Generated at 2022-06-23 21:49:13.244302
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    print ('Execute unit test for method blood_type of class Person')
    random = Random()
    person = Person(random)
    print ('The blood type is: ', person.blood_type())
    print ('Unit Test for method blood_type is OK')


# Generated at 2022-06-23 21:49:14.311190
# Unit test for method age of class Person
def test_Person_age():
    provider = Person()

    assert provider.age() >= 0

# Generated at 2022-06-23 21:49:16.388109
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    name = Person()
    assert name.sexual_orientation() in SexualOrientation.names()
    assert name.sexual_orientation(True) in SEXUALITY_SYMBOLS

# Generated at 2022-06-23 21:49:26.565959
# Unit test for method age of class Person
def test_Person_age():
    from faker import Faker
    from faker_mimesis.utils import DEFAULT_DATA_PATH
    fake = Faker(_data_path=DEFAULT_DATA_PATH)

    # Parameter min
    age = fake.person.age(min=32)
    assert isinstance(age, int) and 32 <= age < 100

    # Parameter max
    age = fake.person.age(max=32)
    assert isinstance(age, int) and 0 <= age < 32

    # Both parameters
    age = fake.person.age(min=32, max=33)
    assert isinstance(age, int) and 32 <= age < 33

# Generated at 2022-06-23 21:49:28.844746
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person is not None

### CUSTOM FUNCTIONS ###

# Returns a random birthday from today

# Generated at 2022-06-23 21:49:31.957013
# Unit test for method title of class Person
def test_Person_title():
    # Given
    title_types = [TitleType.PREFIX, TitleType.SUFFIX, None]
    for title_type in title_types:
        assert Person(seed=0).title(title_type=title_type) == 'Dr.'

# Generated at 2022-06-23 21:49:33.441732
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert type(Person().blood_type()) is str


# Generated at 2022-06-23 21:49:37.044566
# Unit test for method weight of class Person
def test_Person_weight():
    provider = Person(seed=0)
    expected = 66
    actual = provider.weight()
    assert expected == actual

# Generated at 2022-06-23 21:49:40.387496
# Unit test for method email of class Person
def test_Person_email():
    import pytest

    with pytest.raises(ValueError) as exc:
        provider = Person(random_state=None, seed=100)
        provider.email(unique=True)
    assert 'n use «unique» parameter with a seeded provider' in str(exc.value)

# Generated at 2022-06-23 21:49:43.744554
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person()
    social_network = p.social_media_profile(site='facebook')
    assert "http://facebook.com/" in social_network


# Generated at 2022-06-23 21:49:47.045318
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert get_random_item(BLOOD_GROUPS) in [
        u.blood_type() for u in [Person() for _ in range(100)]
    ]


# Generated at 2022-06-23 21:49:56.343055
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    # This code for test need for methods email and username
    # -----------------------------------------------------
    # Set seed for testing
    person.random.seed(0)

    # Check method email
    assert person.email() == "celica98@aol.com"
    assert person.email(domains=['ya.ru', 'gmail.com']) == "gulliver34@gmail.com"
    assert person.email(unique=True) == "gulliver34@aol.com"

    # Check method username
    assert person.username(template='Ud') == "Cleve1950"
    assert person.username(template='UUd') == "Claw1918"
    assert person.username(template='ld') == "gavin1704"

# Generated at 2022-06-23 21:49:57.878382
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    assert p.username() != ''


# Generated at 2022-06-23 21:50:02.001000
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Arrange
    person = Person(seed=5)

    # Act
    result = person.work_experience()

    # Assert
    assert result == 2



# Generated at 2022-06-23 21:50:09.630544
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person()
    s = p.social_media_profile()
    assert isinstance(s, str)
from typing import Any, Dict, Optional, Union
from enum import Enum

from faker.utils.datasets import Dataset
from faker.generators.decorators import slugify
from faker.providers.bank.en_US.provider import Provider as EnUsBank
from faker.utils import slugify_unicode
from faker.utils.distribution import choices_distribution

from faker.providers.lorem.la.provider import Provider as LoremLaProvider

from faker.providers.date_time.en_US.provider import Provider as DateTimeEnUsProvider
from faker.providers.date_time.ja_JP.provider import Provider as DateTimeJaJpProvider

# Generated at 2022-06-23 21:50:13.490946
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    blood_type = person.blood_type()
    assert isinstance(blood_type, str)
    assert blood_type in BLOOD_GROUPS
    
test_Person_blood_type()

# Generated at 2022-06-23 21:50:24.814980
# Unit test for method university of class Person
def test_Person_university():
    """Test for method university."""
    person = Person(seed=0)
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'TogliattiradioTechnicalUniversity'
    assert person.university() == 'MoscowInstituteofElectronicsandMathematics'

# Generated at 2022-06-23 21:50:28.286846
# Unit test for method telephone of class Person
def test_Person_telephone():
    # <-setUp]
    
    # <-body
    person = Person()
    actual = person.telephone()
    assert actual
    # body->
    # <-cleanUp]

# Generated at 2022-06-23 21:50:31.199708
# Unit test for method last_name of class Person
def test_Person_last_name():
    prv = Person()
    for _ in range(10):
        print(prv.last_name())
test_Person_last_name()


# Generated at 2022-06-23 21:50:32.452130
# Unit test for method views_on of class Person
def test_Person_views_on():
    r = randomdata()
    assert r.Person.views_on() in ('Positive', 'Negative')


# Generated at 2022-06-23 21:50:34.075502
# Unit test for method telephone of class Person
def test_Person_telephone():
    assert len(Person().telephone()) > 0

# Generated at 2022-06-23 21:50:38.636843
# Unit test for method email of class Person
def test_Person_email():
    email = Person().email()
    assert isinstance(email, str)
    assert re.match(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)", email) is not None


# Generated at 2022-06-23 21:50:42.481871
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    for _ in range(100):
        work_experience = Person.work_experience(Person)
        assert isinstance(work_experience, str)

# Generated at 2022-06-23 21:50:52.488963
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person.
    """
    p1 = Person(seed=1)
    p2 = Person(seed=1)

    assert p1.email() == p2.email()
    assert p1.identifier() == p2.identifier()
    assert p1.username() == p2.username()
    assert p1.telephone() == p2.telephone()
    assert p1.name() == p2.name()
    assert p1.first_name() == p2.first_name()
    assert p1.full_name() == p2.full_name()
    assert p1.last_name() == p2.last_name()
    assert p1.surname() == p2.surname()
    assert p1.avatar() == p2.avatar()
   