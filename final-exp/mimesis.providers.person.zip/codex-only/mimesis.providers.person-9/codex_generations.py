

# Generated at 2022-06-23 21:40:59.784185
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    result = p.avatar()
    assert type(result) is str
    assert isinstance(result, str)
    assert result
    assert result != ''
    assert len(result) > 0

# Generated at 2022-06-23 21:41:02.517364
# Unit test for method weight of class Person
def test_Person_weight():
    """
    Test for Person.weight method
    """
    assert Person().weight(minimum = 1, maximum = 5) >= 1 and Person().weight(minimum = 1, maximum = 5) <= 5

# Generated at 2022-06-23 21:41:04.887289
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    res = p.avatar()
    assert isinstance(res, str)
    print(res)


# Generated at 2022-06-23 21:41:12.330169
# Unit test for method political_views of class Person
def test_Person_political_views():
    res = []

# Generated at 2022-06-23 21:41:16.247549
# Unit test for method email of class Person
def test_Person_email():
    for i in range(50):
        person = Person('ru')
        assert re.match('\w+?@\w+?.\w{2,3}', person.email()) is not None


# Generated at 2022-06-23 21:41:17.502465
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()

# Generated at 2022-06-23 21:41:19.571484
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()

    assert person.blood_type() != person.blood_type()

# Generated at 2022-06-23 21:41:22.741458
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    g = p.sexual_orientation(symbol=True)
    assert g in SEXUALITY_SYMBOLS, "Person.sexual_orientation() failed"

# Generated at 2022-06-23 21:41:24.984762
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person.last_name.__doc__ == Person.surname.__doc__


# Generated at 2022-06-23 21:41:29.259750
# Unit test for method university of class Person
def test_Person_university():
    from faker import Faker
    faker = Faker()
    university = faker.university()
    print(university)
    assert university != None
    assert type(university) == str

# Generated at 2022-06-23 21:41:32.370976
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality(Gender.MALE) in p._data['nationality']['male']
    assert p.nationality(Gender.FEMALE) in p._data['nationality']['female']


# Generated at 2022-06-23 21:41:33.342878
# Unit test for method telephone of class Person
def test_Person_telephone():
    pass


# Generated at 2022-06-23 21:41:35.391247
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    assert person.name() in NAMES


# Generated at 2022-06-23 21:41:37.117136
# Unit test for method email of class Person
def test_Person_email():
    pr = Person.email()
    assert len(pr) <= 254

# Generated at 2022-06-23 21:41:38.342016
# Unit test for method username of class Person
def test_Person_username():
    faker = Person()
    for _ in range(100):
        assert isinstance(faker.username(), str)



# Generated at 2022-06-23 21:41:40.058045
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person().full_name() == 'Johann Wolfgang'


# Generated at 2022-06-23 21:41:42.755631
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person('en')
    gender = {"male": "Male", "female": "Female"}
    assert person.sex(symbol = True) == random.choice(gender)


# Generated at 2022-06-23 21:41:47.522789
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    occupation = person.occupation()
    assert occupation in person._data['occupation']
import random
import string
import hashlib

from enum import Enum, unique, IntEnum
from string import ascii_letters, digits, punctuation

from faker_ru.providers.base import BaseProvider



# Generated at 2022-06-23 21:41:49.854690
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    degree = Person().academic_degree()
    assert degree in ACADEMIC_DEGREES
    # It is impossible to determine the length of the result,
    # because some values can be abbreviations.
    assert len(degree) >= 3


# Generated at 2022-06-23 21:41:50.457025
# Unit test for method username of class Person
def test_Person_username():
    print(Person.username(Person()))

# Generated at 2022-06-23 21:41:51.991768
# Unit test for method views_on of class Person
def test_Person_views_on():
    global views_on
    Person().views_on()
    assert views_on == 'Negative'

# Generated at 2022-06-23 21:41:58.153146
# Unit test for method last_name of class Person
def test_Person_last_name():
    from fake2db.constants import MALE, FEMALE
    from faker import Faker
    from .test import random_gender, random_surname

    for _ in range(50):
        f = Faker(['en'])
        gender = random_gender()
        surname = f.last_name(gender)
        assert surname in random_surname(gender)

    f = Faker(['en'])
    for _ in range(50):
        surname = f.last_name()
        assert surname in random_surname(MALE) or \
               surname in random_surname(FEMALE)
test_Person_last_name()


# Generated at 2022-06-23 21:42:03.536630
# Unit test for method surname of class Person
def test_Person_surname():
    from hypothesis import given
    from hypothesis.strategies import text, sampled_from
    from unittest import TestCase
    from faker.providers.misc import Person
    
    all_surnames = Person.SURNAME_LIST 
    surname_dicts = [Person.SURNAME_MALE, Person.SURNAME_FEMALE]

    def check_surname_value(surname):
        assert surname in all_surnames

    @given(surname=text(min_size=1))
    def test_dicts(surname):
        for surname_dict in surname_dicts:
            surname_dict['surname'] = surname

    test_dicts()


# Generated at 2022-06-23 21:42:09.737946
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Test Positive
    # Test 1
    for _ in range(5):
        assert Person().telephone() is not None
        assert re.match(r'\+7-\(\d{3}\)-\d{3}-\d{4}', Person().telephone()) is not None
    # Test Negative
    # Test 1
    with pytest.raises(ValueError):
        Person().telephone(mask='')


# Generated at 2022-06-23 21:42:18.778279
# Unit test for method gender of class Person
def test_Person_gender():
    print("test")
    # Test on seed 0
    provider0 = Person()
    test_words0 = provider0.gender()
    assert test_words0 == "Male"
    # Test on seed 1
    provider1 = Person(1)
    test_words1 = provider1.gender()
    assert test_words1 == "Female"
    # Test on seed 2
    provider2 = Person(2)
    test_words2 = provider2.gender()
    assert test_words2 == "Male"
    # Test on seed 3
    provider3 = Person(3)
    test_words3 = provider3.gender()
    assert test_words3 == "Female"
    # Test on seed 4
    provider4 = Person(4)
    test_words4 = provider4.gender()
    assert test_words4 == "Male"


# Generated at 2022-06-23 21:42:20.177304
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert Person.occupation() == 'Administrative assistant'


# Generated at 2022-06-23 21:42:21.161917
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # TODO: Implement test

    pass

# Generated at 2022-06-23 21:42:32.495604
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    rnd_str = RandomStr()
    rnd_str.seed(1)
    prs = Person(rnd_str)
    assert prs.sexual_orientation() == "Heterosexuality"
    rnd_str.seed(2)
    assert prs.sexual_orientation() == "Bisexuality"
    rnd_str.seed(3)
    assert prs.sexual_orientation() == "Asexuality"
    rnd_str.seed(4)
    assert prs.sexual_orientation() == "Pansexuality"
    rnd_str.seed(5)
    assert prs.sexual_orientation() == "Queer"
    rnd_str.seed(6)
    assert prs.sexual_orientation() == "Trisexuality"

# Generated at 2022-06-23 21:42:37.571892
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    k = Person('en')
    r2 = k.social_media_profile(SocialNetwork.facebook)
    assert r2 == 'https://facebook.com/some_user'
    r3 = k.social_media_profile(SocialNetwork.instagram)
    assert r3 == 'https://instagram.com/some_user'




# Generated at 2022-06-23 21:42:40.375714
# Unit test for method age of class Person
def test_Person_age():
    person = Person(random=Random(Random.MersenneTwister(4)))
    assert person.age(16, 68) == 36

# Generated at 2022-06-23 21:42:42.569971
# Unit test for method password of class Person
def test_Person_password():
    for i in range(100):
        P = Provider()
        assert len(P.password()) == 8
        assert len(P.password(length=12)) == 12


# Generated at 2022-06-23 21:42:50.846443
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()

    views = p.views_on()
    assert views in [
        'Negative',
        'Neutral',
        'Positive',
    ]

    views = p.views_on()
    assert views in [
        'Negative',
        'Neutral',
        'Positive',
    ]

    views = p.views_on()
    assert views in [
        'Negative',
        'Neutral',
        'Positive',
    ]


# Generated at 2022-06-23 21:42:53.876359
# Unit test for method height of class Person
def test_Person_height():
    provider = Person()
    def test_height_1():
        assert round(float(provider.height()), 2) >= 1.5
        assert round(float(provider.height()), 2) <= 2.0


# Generated at 2022-06-23 21:43:01.415349
# Unit test for method gender of class Person
def test_Person_gender():
    """ Unit test for method self.gender(). """
    # Test 1
    provider = Person(random=Random())
    result = provider.gender(iso5218=True)
    assert result in (0, 1, 2, 9)

    # Test 2
    result = provider.gender(symbol=True)
    assert result in GENDER_SYMBOLS

    # Test 3
    result = provider.gender()
    assert result in ('Male', 'Female')

# Generated at 2022-06-23 21:43:02.724935
# Unit test for method email of class Person
def test_Person_email():
    person = Person("en")
    print(person.email())


# Generated at 2022-06-23 21:43:05.731044
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert Person().occupation() in Person._data['occupation']

# Generated at 2022-06-23 21:43:13.458951
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    p.random.seed(4462)

    assert p.nationality() == 'Lithuanian'
    assert p.nationality() == 'Palestinian'
    assert p.nationality() == 'Armenian'
    assert p.nationality() == 'Japanese'
    assert p.nationality() == 'Belarusian'
    assert p.nationality() == 'Belarusian'
    assert p.nationality() == 'American'
    assert p.nationality() == 'Russian'
    assert p.nationality() == 'Russian'
    assert p.nationality() == 'Russian'

# Generated at 2022-06-23 21:43:14.222148
# Unit test for method sex of class Person
def test_Person_sex():
    pass

# Generated at 2022-06-23 21:43:22.793010
# Unit test for method identifier of class Person
def test_Person_identifier():
    import random
    random.seed('3b642874-c1b8-4cf3-b3e2-2c544d86b890')
    p = Person(random)
    assert p.identifier(mask='##-##/##') == '07-97/04'
    assert p.identifier(mask='##-##/##') == '07-97/04'
    assert p.identifier(mask='##-##/##') == '07-97/04'
    assert p.identifier(mask='##-##/##') == '07-97/04'
    assert p.identifier(mask='##-##/##') == '07-97/04'
    assert p.identifier(mask='##-##/##') == '07-97/04'

# Generated at 2022-06-23 21:43:30.846067
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    import datetime
    # I do not know what is this test names.
    # Just take it from the original library.
    test_cases = (
        ('Программист', 'Программист'),
        ('Директор', 'Директор'),
        ('Инженер', 'Инженер'),
    )

    for case in test_cases:
        occupation, result = case
        assert Person(random=FakeRandom.new()).work_experience(
            occupation=occupation) == result

test_Person_work_experience()


# Generated at 2022-06-23 21:43:33.077073
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person().worldview()
    assert isinstance(p, str)

# Generated at 2022-06-23 21:43:38.453432
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()                                            # create object of class
    assert person.full_name() in {'Mary Brown', 'Janet Jones'}  # test if the value returned is a string
    assert type(person.full_name()) is str                      # test if the value returned is a string

# Generated at 2022-06-23 21:43:40.681718
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)

# Generated at 2022-06-23 21:43:43.148588
# Unit test for method name of class Person
def test_Person_name():
    from faker import Faker
    f = Faker()
    # Test for method name of class Person
    for i in range(100):
        assert isinstance(f.name(), str), 'f.name() should be a list'


# Generated at 2022-06-23 21:43:46.454955
# Unit test for method username of class Person
def test_Person_username():
    # prepare local variables
    lfaker = lfaker.Person()
    lfaker_instance = lfaker.username()

    # compare results
    assert lfaker_instance == lfaker_instance

# Generated at 2022-06-23 21:43:50.029330
# Unit test for method title of class Person
def test_Person_title():
    person = Person(seed=42)
    actual = person.title()

    assert actual == 'Dr.'
# Unit tests for method last_name of class Person

# Generated at 2022-06-23 21:43:52.163102
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    for i in range(0, 100):
        person.username()


# Generated at 2022-06-23 21:43:58.695567
# Unit test for method age of class Person
def test_Person_age():
    '''
    Test method age
    '''
    rnd = Random()
    person = Person(rnd=rnd)
    rnd.seed(67)
    assert(person.age()==68)
    assert(person.age()==68)
    assert(person.age()==68)
    rnd.seed(98)
    assert(person.age()==99)
    assert(person.age()==99)
    assert(person.age()==99)

# Generated at 2022-06-23 21:44:08.500817
# Unit test for method password of class Person
def test_Person_password():
    print("\n")
    
    # initialize class
    person = Person(random = None)
    
    # examine method
    print("unit test: method password of class Person")
    print("method password of class Person: {}".format(person.password()))
    print("method password of class Person: {}".format(person.password()))
    print("method password of class Person: {}".format(person.password()))
    print("method password of class Person: {}".format(person.password()))
    print("method password of class Person: {}".format(person.password()))
    print("method password of class Person: {}".format(person.password()))
    print("method password of class Person: {}".format(person.password()))
    print("method password of class Person: {}".format(person.password()))

# Generated at 2022-06-23 21:44:18.624663
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()
    assert provider.telephone().startswith('+')
    assert provider.telephone().count('(') == 1
    assert provider.telephone().count(')') == 1
    assert provider.telephone().count('-') == 3
    assert provider.telephone().count('#') == 0
    assert provider.telephone('#' * 10).count('#') == 10
    assert provider.telephone('###-###-###').count('-') == 2
    assert provider.telephone('###-###-###').count('#') == 9
    assert provider.telephone('###.###.###').count('.') == 2
    assert provider.telephone('###.###.###').count('#') == 9
    assert provider.telephone('###/###/###').count('/') == 2

# Generated at 2022-06-23 21:44:19.520592
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert(Person().sexual_orientation() in Person()._data['sexuality'])


# Generated at 2022-06-23 21:44:22.219874
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    total_time = 0
    person = Person(seed=0)
    for _ in range(20):
        total_time += person.work_experience()

    assert int(total_time / 20) == 2  # avg


# Generated at 2022-06-23 21:44:24.238842
# Unit test for method surname of class Person
def test_Person_surname():
    pers = Person()
    surname = pers.surname (Gender.Male)
    assert surname in DATA['surname']['male']


# Generated at 2022-06-23 21:44:25.978952
# Unit test for method email of class Person
def test_Person_email():
    answer = '<class ' + '\'faker.providers.person.Person\'' + '>'
    actual = str(Person)
    assert answer == actual


# Generated at 2022-06-23 21:44:37.651250
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Provider(name='en')
    p.random.seed(1)
    result = p.social_media_profile()
    assert result == 'https://instagram.com/some_user'
import pytest # import pytest

# Generated at 2022-06-23 21:44:39.073983
# Unit test for method university of class Person
def test_Person_university():
    p = Person()
    assert isinstance(p.university(), str)

# Generated at 2022-06-23 21:44:40.807683
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person(['ru']) # Here indian is an example of one country
    assert person.last_name() != ''

# Generated at 2022-06-23 21:44:43.806728
# Unit test for method work_experience of class Person
def test_Person_work_experience(): 
    work_experience = Person(random=None).work_experience(from_year=2017)
    assert(work_experience == '1 year')
    assert(isinstance(work_experience, str) == True)


# Generated at 2022-06-23 21:44:46.652555
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Arrange
    person = Person()

    # Act
    result = person.social_media_profile()

    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-23 21:44:48.846942
# Unit test for method weight of class Person
def test_Person_weight():
    # Arrange
    person = Person()
    # Action
    result = person.weight(1)
    # Assert
    assert 1 <= result <= 90


# Generated at 2022-06-23 21:44:58.285958
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    data = [
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
    ]
    check_values_equality(Person, 'academic_degree', data)



# Generated at 2022-06-23 21:45:00.989951
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert len(Person().occupation()) in range(10, 17)
    
    # Unit test for method university of class Person

# Generated at 2022-06-23 21:45:04.836382
# Unit test for method identifier of class Person
def test_Person_identifier():
    identifier_1 = Person().identifier('##-##/##')
    assert re.search(r'\d{2}-\d{2}/\d{2}', identifier_1)

    identifier_2 = Person().identifier('##-##/##')
    assert identifier_1 != identifier_2

# Generated at 2022-06-23 21:45:11.586758
# Unit test for method occupation of class Person
def test_Person_occupation():
    import re
    p = Person()
    o = p.occupation()
    assert isinstance(o, str)
    assert re.match(r'^\w+$', o)
 
    p = Person()
    o = p.occupation()
    assert isinstance(o, str)
    assert re.match(r'^\w+$', o)
    
    p = Person()
    o = p.occupation()
    assert isinstance(o, str)
    assert re.match(r'^\w+$', o)


# Generated at 2022-06-23 21:45:15.828672
# Unit test for method surname of class Person
def test_Person_surname():
    import random
    person = Person(random)
    person.surname()
    person.surname(gender=1)
    person.surname(gender=2)
    person.surname(gender=3)

# Generated at 2022-06-23 21:45:18.012150
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person(Random())
    assert p.views_on() in VIEWS_ON

# Generated at 2022-06-23 21:45:24.128321
# Unit test for method title of class Person
def test_Person_title():
    person = Person(locale='en')
    assert person.title() in ('Mr.', 'Mrs.')
    assert person.title(title_type=TitleType.PREFIX) in ('Mr.', 'Mrs.')
    assert person.title(title_type=TitleType.SUFFIX) in ('PhD', 'M.D.', 'Esq.')
    assert person.title(gender=Gender.MALE) == 'Mr.'
    assert person.title(gender=Gender.FEMALE) == 'Mrs.'
test_Person_title()


# Generated at 2022-06-23 21:45:27.143366
# Unit test for method last_name of class Person
def test_Person_last_name():
    person_generator = Person()
    last_name = person_generator.last_name()
    assert isinstance(last_name,str)


# Generated at 2022-06-23 21:45:32.923398
# Unit test for method gender of class Person
def test_Person_gender():
    # arg1 == None and arg2 == None
    result1 = Person().gender()
    assert result1 in ['Male', 'Female', 'Asexuality']
    # arg1 == True and arg2 == None
    result2 = Person().gender(iso5218=True)
    assert result2 in [1, 2]
    # arg1 == None and arg2 == True
    result3 = Person().gender(symbol=True)
    assert result3 in ['♀', '♂']



# Generated at 2022-06-23 21:45:44.947509
# Unit test for method last_name of class Person
def test_Person_last_name():

    import os
    import sys
    sys.path.append(".")

    from . import person
    from . import person_ru

    # Инициализация объекта
    person = person.Person('en')

    # Генерация случайного фамилии
    last_name = person.last_name()

    # Вывод информации
    print(last_name)

    # Инициализация объекта (RU)
    person_ru = person_ru.Person('ru')

    #

# Generated at 2022-06-23 21:45:54.664654
# Unit test for method full_name of class Person
def test_Person_full_name():
    test_cases_Person_full_name = {"1": {'gender': 'male', 'reverse': False},
                                   "2": {'gender': 'male', 'reverse': True},
                                   "3": {'gender': 'female', 'reverse': False},
                                   "4": {'gender': 'female', 'reverse': True}}

    for test_case_name, test_case_data in test_cases_Person_full_name.items():
        assert type(Person().full_name(test_case_data['gender'], test_case_data['reverse'])) == str

# Generated at 2022-06-23 21:46:04.598346
# Unit test for method worldview of class Person

# Generated at 2022-06-23 21:46:10.513767
# Unit test for method nationality of class Person
def test_Person_nationality():
    from . import Common
    # Создадим экземпляр класса объекта Common
    obj = Common()
    # Сгенерируем случайную национальность
    assert obj.nationality() in obj.nationalitys
    # Очистим память
    del obj

# Generated at 2022-06-23 21:46:19.246695
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()

    for _ in range(100):
        assert p.worldview() in(
            'Agnosticism', 'Atheism', 'Deism', 'Pantheism',
            'Theism', 'Satanism', 'Buddhism', 'Christianity',
            'Islam', 'Judaism', 'Confucianism', 'Hinduism',
            'Shinto', 'Taoism', 'Wicca', 'Pastafarianism'
        )
test_Person_worldview()

# Generated at 2022-06-23 21:46:27.288060
# Unit test for method first_name of class Person
def test_Person_first_name():
    from random import Random
    from collections import OrderedDict
    from enum import Enum

    class Gender(Enum):
        Male = 'male'
        Female = 'female'

    class PersonProvider(Person):
        def __init__(self, data: dict = None, random: Random = None):
            Person.__init__(self, data, random)

            self.data.update(OrderedDict({
                'male': ['Капустан'],
                'female': ['Капустан'],
            }))

    p = PersonProvider()

    # Unique name
    assert p.first_name() == 'Капустан'

# Generated at 2022-06-23 21:46:33.170957
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person().identifier('##-##/##') == '07-97/04'

    # Get the first IPv4 address.
    m = re.search(r'(?:\d+\.){3}\d+', Person().identifier(
        '###.###.###.###'), re.I | re.M)
    assert m.group() == '172.217.168.174'

# Generated at 2022-06-23 21:46:40.333025
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    print("social_media_profile")
    # Set up test data and expected results
    obj = Person()
    obj.random.set_seed(0)
    assert obj.social_media_profile() == 'https://facebook.com/H30'
    assert obj.social_media_profile() == 'https://twitter.com/U6N'
    assert obj.social_media_profile() == 'https://reddit.com/K27'
    assert obj.social_media_profile() == 'https://instagram.com/T53'
    assert obj.social_media_profile() == 'https://vk.com/I22'
    assert obj.social_media_profile() == 'https://facebook.com/K26'


# Generated at 2022-06-23 21:46:43.005837
# Unit test for method first_name of class Person
def test_Person_first_name():
    """Unit test for method first_name of class Person."""
    assert type(Person().first_name()) == str



# Generated at 2022-06-23 21:46:53.123339
# Unit test for constructor of class Person

# Generated at 2022-06-23 21:47:01.007499
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    assert p.title()
    assert p.title(gender=Gender.MALE)
    assert p.title(gender=Gender.FEMALE)
    assert p.title(gender=Gender.UNKNOWN)
    assert p.title(title_type=TitleType.PREFIX)
    assert p.title(title_type=TitleType.SUFFIX)
    assert p.title(title_type=TitleType.BOTH)


# Generated at 2022-06-23 21:47:02.496992
# Unit test for method weight of class Person
def test_Person_weight(): 
    p = Person.create_male() 
    assert(p.weight() > 38 and p.weight() < 90)

# Generated at 2022-06-23 21:47:05.256879
# Unit test for method height of class Person
def test_Person_height():
    for i in range(100):
        obj = Person(random=Random())
        assert(obj.height() >= 1.5 and obj.height() <= 2)


# Generated at 2022-06-23 21:47:06.517201
# Unit test for method university of class Person
def test_Person_university():
    p = Person()

    universities = p.university()
    assert universities in UNIVERSITIES


# Generated at 2022-06-23 21:47:11.826474
# Unit test for method university of class Person
def test_Person_university():
  p = Person()
  assert p.university() in ['Cornell University',
                            'Harvard University',
                            'Princeton University',
                            "Stanford University",
                            'Massachusetts Institute of Technology',
                            'University of Chicago',
                            'Yale University',
                            'University of Pennsylvania',
                            'Columbia University',
                            'Duke University']
    
    
    
    
 

# Generated at 2022-06-23 21:47:21.668018
# Unit test for method name of class Person
def test_Person_name():
    assert Person.name(Gender.MALE) in PERSON_NAMES[Gender.MALE]
    assert Person.name(Gender.FEMALE) in PERSON_NAMES[Gender.FEMALE]
    assert Person.name(Gender.MALE) in PERSON_NAMES[Gender.MALE]
    assert Person.name(Gender.FEMALE) in PERSON_NAMES[Gender.FEMALE]
    assert Person.name() in PERSON_NAMES[Gender.MALE]
    assert Person.name() in PERSON_NAMES[Gender.FEMALE]
    assert Person.name().lower() in PERSON_NAMES[Gender.MALE]
    assert Person.name().lower() in PERSON_NAMES[Gender.FEMALE]
    assert Person.name(Gender.MALE).capitalize() in PERSON_NAMES[Gender.MALE]

# Generated at 2022-06-23 21:47:27.680463
# Unit test for method email of class Person
def test_Person_email():
    # Removed for brevity
    def test_with_custom_domains(self):
        """Test ``email`` method with custom domains."""
        custom_domains = ('mydomain.com', 'my_domain.com', 'my-domain.com')
        fake = Person('en_US')
        email = fake.email(domains=custom_domains)
        self.assertTrue(any(email.endswith(domain) for domain in custom_domains))

# Generated at 2022-06-23 21:47:39.015052
# Unit test for method occupation of class Person
def test_Person_occupation():
    # Seed the random number generator
    random.seed(0)

    # Create and populate a list with 100 Person instances
    person_list = [Person() for _ in range(100)]

    # Create and populate a list with all the Person instances' occupations
    person_occupations = [person.occupation() for person in person_list]

    # Create and populate a set with all the Person instances' occupations
    person_occupations_set = set(person_occupations)

    # The above list should have 100 elements and the set should have fewer
    assert len(person_occupations) == 100
    assert len(person_occupations_set) != 100

    # Print the two lists - uncomment the below lines to see the output
    # print()
    # print(person_occupations)
    # print()
    # print(person_occupations_set

# Generated at 2022-06-23 21:47:41.013924
# Unit test for method weight of class Person
def test_Person_weight():
    # Arrange
    pr = Person()

    # Act
    weight = pr.weight()

    # Assert
    assert(weight > 0 and weight <100)

# Generated at 2022-06-23 21:47:42.258499
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person(random=Random())
    assert person.work_experience() == 'No experience'

# Generated at 2022-06-23 21:47:49.197781
# Unit test for method title of class Person
def test_Person_title():
    """ Unit test for method title of class Person. """
    tester = Person()
    obj = tester.title(gender=Gender.MALE, title_type=TitleType.PREFIX)
    assert "Dr." in obj
    obj = tester.title(gender=Gender.MALE, title_type=TitleType.SUFFIX)
    assert "I" in obj
    obj = tester.title(gender=Gender.MALE)
    assert "Dr." or "I" in obj
    obj = tester.title(title_type=TitleType.PREFIX)
    assert "Dr." in obj
    obj = tester.title(title_type=TitleType.SUFFIX)
    assert "I" in obj
    obj = tester.title()
    assert "Dr." or "I" in obj
    
test_

# Generated at 2022-06-23 21:47:51.027523
# Unit test for method email of class Person
def test_Person_email():
    try:
        Person().email(unique=True)
    except ValueError:
        pass

# Generated at 2022-06-23 21:48:02.349063
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(1000):
        worldview = Person().worldview()

# Generated at 2022-06-23 21:48:05.276172
# Unit test for method username of class Person
def test_Person_username():
    username = Person().username('Ud')
    assert type(username) == str and len(username) > 0



# Generated at 2022-06-23 21:48:14.566797
# Unit test for method email of class Person
def test_Person_email():
    p = PersonProvider()
    assert p.email() in ['bluecarrot@yandex.ru', 'bigapple@list.ru',
                         'bigapple@tut.by', 'bigapple@yahoo.com',
                         'bigapple@yandex.ru', 'bigapple12@yandex.ru',
                         'bigapple12b@yandex.ru', 'bigapple12b@list.ru',
                         'bigapple12b@tut.by', 'bigapple12b@mail.ru',
                         'bigapple12b@yahoo.com']
# Unit testing for method password of class Person

# Generated at 2022-06-23 21:48:15.807142
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email() == 'celerykeith@yahoo.com'

# Generated at 2022-06-23 21:48:17.041648
# Unit test for method email of class Person
def test_Person_email():
    assert Person.email() == 'freddiewilk@gmail.com'



# Generated at 2022-06-23 21:48:18.592353
# Unit test for method surname of class Person
def test_Person_surname():
    faker = Faker('en')
    surname = faker.last_name()
    assert(isinstance(surname, str))
    assert(len(surname) > 0)


# Generated at 2022-06-23 21:48:22.593277
# Unit test for method email of class Person
def test_Person_email():
    """if email is unique and the provider was seeded.

    The valueError
    """
    unique = True

    # seed = 1
    # provider = Person(seed=seed)
    # email = provider.email(unique=unique)
    provider = Person()
    email = provider.email(unique=unique)
test_Person_email()


# Generated at 2022-06-23 21:48:29.913456
# Unit test for method age of class Person
def test_Person_age():
    assert Person().age() <= 100
    assert Person().age(min_age=50, max_age=100) <= 100
    assert Person().age(max_age=100) < 100
    assert Person().age(min_age=50) >= 50
    assert Person().age(max_age=100, min_age=50) < 100
    assert Person().age(max_age=100, min_age=50) >= 50


# Generated at 2022-06-23 21:48:30.562731
# Unit test for method email of class Person
def test_Person_email():
    return Person().email()

# Generated at 2022-06-23 21:48:32.119588
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    blood_type = Person.blood_type(Person)
    assert blood_type in BLOOD_GROUPS


# Generated at 2022-06-23 21:48:34.954005
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person()
    # test for randomness
    count = p.random.randint(0, 5)
    for i in range (0, count):
        assert p.occupation() != p.occupation()


# Generated at 2022-06-23 21:48:38.425292
# Unit test for method weight of class Person
def test_Person_weight():
    print('Test Person.weight()')
    person = Person()
    
    for _ in range(10):
        print(person.weight())


# Generated at 2022-06-23 21:48:48.082660
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person()
    assert provider.gender(symbol=False) == 'мужской'
    assert provider.gender(symbol=True) == '♂'
    assert provider.gender(iso5218=False) == 'мужской'
    assert provider.gender(iso5218=True) == 0
    assert provider.gender(iso5218=True) == 1
    assert provider.gender(iso5218=True) == 2
    assert provider.gender(iso5218=True) == 9
    assert provider.gender(symbol=False) == 'мужской'
    assert provider.gender(symbol=True) == '♂'


# Generated at 2022-06-23 21:48:50.892323
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    langs = person.language()

    assert isinstance(person, Person)
    assert isinstance(langs, str)

# Generated at 2022-06-23 21:48:52.493369
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    assert len(person.first_name()) >= 3



# Generated at 2022-06-23 21:48:57.028404
# Unit test for method worldview of class Person
def test_Person_worldview():
    world_view = None
    for j in range(10):
        world_view = p.worldview()
        assert world_view in WORLD_VIEWS
        print(world_view, end = '\n')

test_Person_worldview()


# Generated at 2022-06-23 21:49:08.029959
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person()
    assert type(p.blood_type()) is str

'''
    Test for method blood_type of class Person
Results: 
            blood_type
            A+           378
            AB+          367
            B+           344
            O+           351
            A-           482
            AB-          476
            B-           456
            O-           469
'''
if __name__ == "__main__":
    p = Person()
    a = ['A+','AB+','B+','O+','A-','AB-','B-','O-']
    b = {}
    for i in a:
        b[i] = 0
    print("\n    Test for method blood_type of class Person")
    for _ in range(10**4):
        t = p.blood_

# Generated at 2022-06-23 21:49:09.207303
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person(random=Random())
    result = p.weight()
    assert type(result) == int
    assert result >= 38
    assert result <= 90


# Generated at 2022-06-23 21:49:18.357090
# Unit test for method occupation of class Person
def test_Person_occupation():
    from faker.providers.person.en import Provider

    prov = Provider

    # Test format
    # ------------
    # Assert 9 tests for format:
    # 2 checks for the length of list (how many values)
    # 7 checks for the type of values

    occupation_list = prov.occupation()

    assert len(occupation_list) == 9
    assert isinstance(occupation_list, tuple)
    assert isinstance(occupation_list[0], str)
    assert isinstance(occupation_list[1], str)
    assert isinstance(occupation_list[2], str)
    assert isinstance(occupation_list[3], str)
    assert isinstance(occupation_list[4], str)
    assert isinstance(occupation_list[5], str)

# Generated at 2022-06-23 21:49:20.552587
# Unit test for method university of class Person
def test_Person_university():
    assert Person().university() == 'MIT'


# Generated at 2022-06-23 21:49:31.230794
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    seed = 42
    p = Person(seed=seed)
    
    
    data = [p.sexual_orientation for _ in range(1000)]
    
    
    

# Generated at 2022-06-23 21:49:42.025122
# Unit test for constructor of class Person
def test_Person():
    p = Person()

    assert callable(p.name)
    assert callable(p.full_name)
    assert callable(p.surname)
    assert callable(p.last_name)
    assert callable(p.title)
    assert callable(p.username)
    assert callable(p.password)
    assert callable(p.email)
    assert callable(p.gender)
    assert callable(p.sex)
    assert callable(p.height)
    assert callable(p.weight)
    assert callable(p.identifier)
    assert callable(p.blood_type)
    assert callable(p.sexual_orientation)
    assert callable(p.occupation)
    assert callable(p.political_views)

# Generated at 2022-06-23 21:49:44.208428
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person(locale='en')
    result = person.political_views()
    assert result in POLITICAL_VIEWS



# Generated at 2022-06-23 21:49:47.516912
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    fake = Faker(locale='en')
    assert fake.nationality() in fake._data['nationality']


# Generated at 2022-06-23 21:49:49.568985
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Start with a lowercase letter.
    assert Person.work_experience(Person())



# Generated at 2022-06-23 21:49:53.243295
# Unit test for method name of class Person
def test_Person_name():
    res = Faker(locale='ru_RU').person.name(Gender.MALE)
    assert res is not None


# Generated at 2022-06-23 21:50:00.893330
# Unit test for method email of class Person
def test_Person_email():
    # Random Person object
    person = Person()
    # Random email (str)
    person.email()
    # Another random email (str)
    person.email()
    # Returns true if email address is email
    is_email = lambda x: bool(re.match(r"^.+@(\[?)[a-zA-Z0-9-.]+.([a-zA-Z]{2,3}|[0-9]{1,3})(]?)$", x))
    # Assertion
    assert is_email(person.email())


# Generated at 2022-06-23 21:50:03.316747
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    assert isinstance(person.language(), str)

# Generated at 2022-06-23 21:50:05.104383
# Unit test for method weight of class Person
def test_Person_weight():
    for i in range(100):
        value = Person().weight()
        assert isinstance(value, int)


# Generated at 2022-06-23 21:50:07.361961
# Unit test for method username of class Person
def test_Person_username():
    """Test the method Person of class Person"""
    person = Person()
    assert person.username()
    assert person.username(template = 'U-d')

# Generated at 2022-06-23 21:50:11.847879
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    assert isinstance(p.telephone(), str)
    pattern = re.compile('^\+[0-9]*-[0-9]*-[0-9]*-[0-9]*-[0-9]*$')
    assert pattern.match(p.telephone()) != None


# Generated at 2022-06-23 21:50:15.343143
# Unit test for method gender of class Person
def test_Person_gender():
    for politeness in ['Male', 'Female', 'Not known', 'Male and Female', 'Not Applicable']:
        assert politeness in Person().gender(), \
            'Method Person().gender() has a bug'

# Generated at 2022-06-23 21:50:23.126230
# Unit test for method age of class Person
def test_Person_age():
    class TestMembers:
        data = None
        seed = None
        random = None
        person = None

    test = TestMembers()
    test.data = 'faker.providers.person.ru_RU'
    test.seed = 20
    test.random = Generator(test.data, test.seed)
    test.person = Person(test.random)
    assert test.person.age(minimum=18, maximum=99) == 64


# Generated at 2022-06-23 21:50:31.108636
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with gender is not specified
    actual = Person.nationality()
    expected = Person.random.choice(Person._data['nationality'])
    assert actual == expected, "{}, expected: {}".format(actual, expected)

    # Test with gender is specified
    for gender in Gender:
        actual = Person.nationality(gender)
        expected = Person.random.choice(Person._data['nationality'][gender])
        assert actual == expected, "{}, expected: {}".format(actual, expected)
        
test_Person_nationality()


# Generated at 2022-06-23 21:50:33.367454
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    res = person.height()
    exp = 1.76
    assert res == exp

# Generated at 2022-06-23 21:50:36.501237
# Unit test for method first_name of class Person
def test_Person_first_name():
    from datamaker.tests.datamaker.person import PersonTest
    assert Person.first_name(PersonTest(seed=0)) == 'Вячеслав'

# Generated at 2022-06-23 21:50:38.323837
# Unit test for method occupation of class Person
def test_Person_occupation():
    person_gen = Person()
    occupation = person_gen.occupation()
    assert(occupation in person_gen._data['occupation'])



# Generated at 2022-06-23 21:50:46.953117
# Unit test for method worldview of class Person
def test_Person_worldview():
    worldviews = []
    for i in range(100):
        worldview = Person().worldview()
        worldviews.append(worldview)
    
    assert any(worldview in worldviews for worldview in Person._data['worldview'])

test_Person_worldview()
# Worldview
worldviews = []
for i in range(1000):
    worldview = Person().worldview()
    worldviews.append(worldview)

i = 1
for worldview in worldviews:
    i+=1
    print(f'{i}. {worldview}')

# Generated at 2022-06-23 21:50:48.741766
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    h = p.height(minimum=100)
    assert h >= 100


# Generated at 2022-06-23 21:50:49.404314
# Unit test for method nationality of class Person
def test_Person_nationality():
    pass

# Generated at 2022-06-23 21:50:51.418902
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()

    assert person.views_on() in [
        'Negative', 'Positive', 'Indifferent', 'Definitely negative',
        'Definitely positive', 'Tolerant', 'Uncertain', 'Vague']

# Generated at 2022-06-23 21:50:52.874670
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider, Person)


# Generated at 2022-06-23 21:50:55.294958
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person()
    assert validator.validate(provider.gender(), 'gender')

# Generated at 2022-06-23 21:50:56.650678
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = Person()
    assert provider.last_name()
