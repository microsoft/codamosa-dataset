

# Generated at 2022-06-23 21:40:57.725219
# Unit test for method telephone of class Person
def test_Person_telephone():
    n = PersonFactory()
    assert n.telephone()
    assert n.telephone(mask='(###)###-##-##', placeholder='#')

# Generated at 2022-06-23 21:40:59.596150
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Provider()
    assert isinstance(provider.surname(), str)

# Generated at 2022-06-23 21:41:02.690527
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for _ in range(100):
        bt = Person.blood_type()
        assert isinstance(bt, str)
        assert bt in BLOOD_GROUPS

# Generated at 2022-06-23 21:41:04.419446
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person.random.seed is None

    person = Person(seed=123)
    assert person.random.seed == 123



# Generated at 2022-06-23 21:41:16.206399
# Unit test for method name of class Person

# Generated at 2022-06-23 21:41:17.730541
# Unit test for method identifier of class Person
def test_Person_identifier():
    pass


# Generated at 2022-06-23 21:41:26.122724
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person(random=Random())

    arrange = (
        (
            'provider.sexual_orientation()',
            lambda: provider.sexual_orientation()
        ),
        (
            'provider.sexual_orientation(symbol=True)',
            lambda: provider.sexual_orientation(symbol=True)
        ),
    )

    for (code, method) in arrange:
        result = method()

        if code.find('symbol') != -1:
            assert result in SEXUALITY_SYMBOLS
        else:
            assert result in provider._data['sexuality']

# Generated at 2022-06-23 21:41:28.320944
# Unit test for method political_views of class Person
def test_Person_political_views():
    result = Person.political_views()
    assert result in POLITICAL_VIEWS


# Generated at 2022-06-23 21:41:34.978229
# Unit test for method first_name of class Person
def test_Person_first_name():
    t = Person()
    person = t.first_name(Gender.MALE)

# Generated at 2022-06-23 21:41:37.878736
# Unit test for method full_name of class Person
def test_Person_full_name():
    rnd = random.Random()
    p = Person(rnd)
    name = p.full_name()
    assert len(name) > 0


# Generated at 2022-06-23 21:41:39.774908
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert isinstance(person.height(),str)

# Generated at 2022-06-23 21:41:42.495412
# Unit test for method worldview of class Person
def test_Person_worldview():
    """Test method worldview of class Person"""

    generator = Person()
    worldview: str = generator.worldview()
    assert type(worldview) is str


# Generated at 2022-06-23 21:41:46.923411
# Unit test for method last_name of class Person
def test_Person_last_name():
    r = Random(0xB000000000000000)
    p = Person(r)
    assert isinstance(p, Person)
    assert p.last_name() == 'Президента'
test_Person_last_name()
print('Ok')


# Generated at 2022-06-23 21:41:48.240725
# Unit test for method height of class Person
def test_Person_height():
    assert type(Person().height()) == str


# Generated at 2022-06-23 21:41:56.620325
# Unit test for method title of class Person
def test_Person_title():
    assert Person().title(gender=Gender.male, title_type=TitleType.prefix) in 'Mr.'
    assert Person().title(gender=Gender.female, title_type=TitleType.prefix) in 'Mrs.'
    assert Person().title(gender=Gender.male, title_type=TitleType.suffix) in 'Esq.'
    assert Person().title(gender=Gender.female, title_type=TitleType.suffix) in 'MD'
    assert Person().title(gender=Gender.male, title_type=TitleType.middle) in 'F'
    assert Person().title(gender=Gender.female, title_type=TitleType.middle) in 'Van'
    assert Person().title(gender=Gender.male, title_type=TitleType.both) in 'Jr.'

# Generated at 2022-06-23 21:41:57.221974
# Unit test for method height of class Person
def test_Person_height():
    assert Person.height()

# Generated at 2022-06-23 21:42:00.636692
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    assert person.sexual_orientation() in PERSON_SEXUAL_ORIENTATIONS


# Generated at 2022-06-23 21:42:02.102649
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    p.avatar()



# Generated at 2022-06-23 21:42:06.030046
# Unit test for method avatar of class Person
def test_Person_avatar():
    expected = 'https://api.adorable.io/avatars/256/78de6c55bf6bb0c7e8c6d75e7f3b3187.png'
    actual = Person.avatar(size=256)
    assert expected == actual

# Generated at 2022-06-23 21:42:07.521173
# Unit test for method password of class Person
def test_Person_password():
    people = Person()
    print(people.password(12,True))


# Generated at 2022-06-23 21:42:09.636905
# Unit test for method avatar of class Person
def test_Person_avatar():
    provider = Person()
    random_avatar = provider.avatar()
    assert re.match(r'^https://api\.adorable\.io/avatars/[0-9]+/[0-9a-f]+.png$', random_avatar)


# Generated at 2022-06-23 21:42:11.904294
# Unit test for method email of class Person
def test_Person_email():
    a = Person()
    em = a.email()
    print(em)
    assert em is not None
    return True

# Generated at 2022-06-23 21:42:17.199369
# Unit test for method surname of class Person
def test_Person_surname():
    import itertools
    import pytest
    @pytest.mark.parametrize("gender", list(itertools.chain(*[
        (Gender.MALE, Gender.FEMALE)
    ])))
    def test_Person_surname(gender, faker):
        result = faker.surname(gender=gender)
        if gender == Gender.MALE:
            assert any([prefix in result for prefix in SURNAME_PREFIX_MALE]), \
                "found result: {}".format(result)
        elif gender == Gender.FEMALE:
            assert any([prefix in result for prefix in SURNAME_PREFIX_FEMALE]), \
                "found result: {}".format(result)
        else:
            assert False, "invalid gender: {}".format(gender)


# Unit test

# Generated at 2022-06-23 21:42:21.058893
# Unit test for method gender of class Person
def test_Person_gender():
    """Unit test for method gender of class Person."""
    for _ in range(100):
        my_person = Person()
        my_person.gender()
        my_person.gender(iso5218=True)
        my_person.gender(symbol=True)

        my_person.sex()
        my_person.sex(iso5218=True)
        my_person.sex(symbol=True)


# Generated at 2022-06-23 21:42:24.164691
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person('en')
    a = p.worldview()
    print(a)
    assert a is not None, "ERROR: method worldview return None"


# Generated at 2022-06-23 21:42:31.834635
# Unit test for method username of class Person
def test_Person_username():
    pr = Person()
    # Get the email address
    print (pr.username(template='U_d'))
    # Get the email address
    print (pr.username(template='Ud'))
    # Get the email address
    print (pr.username(template='ld'))
    # Get the email address
    print (pr.username(template='UU_d'))
    # Get the email address
    print (pr.username(template='Ul'))
if __name__ == '__main__':
    test_Person_username()


# Generated at 2022-06-23 21:42:33.467537
# Unit test for method university of class Person
def test_Person_university():
    provider = Person()
    assert provider.university() in UNIVERSITIES

# Generated at 2022-06-23 21:42:42.952262
# Unit test for method surname of class Person
def test_Person_surname():
    from pprint import pprint
    p = Person()
    p.set_random_seed(0)
    v = p.surname()
    assert v == "Herrmann"

    p.set_random_seed(1)
    v = p.surname()
    assert v == "Freytag"

    p.set_random_seed(2)
    v = p.surname()
    assert v == "Neumann"

    p.set_random_seed(3)
    v = p.surname()
    assert v == "Muller"

    p.set_random_seed(4)
    v = p.surname()
    assert v == "Schmidt"

    p.set_random_seed(5)
    v = p.surname()

# Generated at 2022-06-23 21:42:45.609653
# Unit test for method worldview of class Person
def test_Person_worldview():
    provider = Person()
    assert provider.worldview() in worldviews


# Generated at 2022-06-23 21:42:47.047924
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert Person().first_name() == 'John'


# Generated at 2022-06-23 21:42:49.483367
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    assert isinstance(person.occupation(), str)



# Generated at 2022-06-23 21:43:00.877052
# Unit test for method name of class Person
def test_Person_name():
    # Init a Faker class and then init method
    # name of this class with param female.
    fake = Faker()
    result = fake.name(Gender.FEMALE)
    
    # The result must be a type string.
    assert isinstance(result, str)
    
    # Init a Faker class and then init method
    # name of this class with param male.
    fake = Faker()
    result = fake.name(Gender.MALE)
    
    # The result must be a type string.
    assert isinstance(result, str)
    
    # Init a Faker class and then init method
    # name of this class without param.
    fake = Faker()
    result = fake.name()
    
    # The result must be a type string.
    assert isinstance(result, str)
    


# Generated at 2022-06-23 21:43:11.736793
# Unit test for method surname of class Person
def test_Person_surname():
    # Surnames separated by gender.
    surnames = {
        Gender.MALE: ('Smith', 'Johnson', 'Williams', 'Jones', 'Brown'),
        Gender.FEMALE: ('Johnson', 'Williams', 'Jones', 'Brown'),
    }

    person = Person(
        gender=None,
        seed=None,
        surnames=surnames,
        random=random,
    )

    for _ in range(20):
        assert person.surname(gender=Gender.MALE) in surnames[Gender.MALE]
        assert person.surname(gender=Gender.FEMALE) in surnames[Gender.FEMALE]

    # Surnames separated by gender (mixed).

# Generated at 2022-06-23 21:43:20.868798
# Unit test for method language of class Person
def test_Person_language():
  Faker.seed(0)
  faker = Faker()

##  data_msgs_locale_en_US_Person_language = '''
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese
##      Chinese


# Generated at 2022-06-23 21:43:26.197816
# Unit test for method name of class Person
def test_Person_name():
    tester = Faker("ru_RU")
    #ru_RU
    assert tester.name(gender=None) != None
    assert tester.name(gender=Gender.MALE) != None
    assert tester.name(gender=Gender.FEMALE) == None
    assert tester.name(gender=Gender.FEMALE) != None

# Generated at 2022-06-23 21:43:28.901523
# Unit test for method language of class Person
def test_Person_language():
    code = [
        'language()',
    ]
    obj = Person()
    eval(code[0])
    expected = ['language']
    assert len(language) == len(expected)

# Generated at 2022-06-23 21:43:34.082649
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert Person.social_media_profile(Person()) == 'https://facebook.com/foretime10'
    assert Person.social_media_profile(Person()) != 'https://facebook.com/foretime10'
    assert Person.social_media_profile(Person()) == 'https://facebook.com/foretime10'
    assert Person.social_media_profile(Person()) == 'https://facebook.com/foretime10'
    assert Person.social_media_profile(Person()) == 'https://facebook.com/foretime10'
    assert Person.social_media_profile(Person()) == 'https://facebook.com/foretime10'

# Generated at 2022-06-23 21:43:46.464440
# Unit test for method telephone of class Person
def test_Person_telephone():
    with pytest.raises(TypeError) as exc:
        assert Person().telephone(mask=1)
    assert str(exc.value) == 'mask must be str.'

    with pytest.raises(TypeError) as exc:
        assert Person().telephone(placeholder=1)
    assert str(exc.value) == 'placeholder must be str.'

    with pytest.raises(ValueError) as exc:
        assert Person().telephone(mask='maskWithoutAnyPlaceholders')
    assert str(exc.value) == 'You must provide at least one of the ' \
                   'following placeholders: (#, @, $, &).'

    assert Person().telephone(mask='#' * 10)
    assert Person().telephone(mask='#' * 12)

# Generated at 2022-06-23 21:43:52.264884
# Unit test for method gender of class Person
def test_Person_gender():
    # Test with default arguments
    assert Person().gender() in GENDER

    # Test with iso5218 argument
    assert Person().gender(iso5218=True) in range(0, 10)

    # Test with symbol argument
    assert Person().gender(symbol=True) in GENDER_SYMBOLS


# Generated at 2022-06-23 21:43:57.523792
# Unit test for method password of class Person
def test_Person_password():
    create_provider(Person).password(hashed=True) == 'b9f49025d367afc32d82ceb73e6ba06c'
    create_provider(Person).password(length=9, hashed=True) == '2b2ff46c2d49e8f8e14f6bd0ad79a9b9'



# Generated at 2022-06-23 21:44:07.981384
# Unit test for method age of class Person
def test_Person_age():
    person = Person()

    one = person.age()
    two = person.age(1)
    three = person.age(18)
    four = person.age(65)

    assert isinstance(one, int), "Method age should return an int"
    assert isinstance(two, int), "Method age should return an int"
    assert isinstance(three, int), "Method age should return an int"
    assert isinstance(four, int), "Method age should return an int"

    assert 0 <= one <= 120, "Method age should return a random age"
    assert 0 <= one <= 120, "Method age should return a random age"
    assert 18 <= one <= 120, "Method age should return a random age in interval"
    assert 65 <= one <= 120, "Method age should return a random age in interval"


# Generated at 2022-06-23 21:44:18.101683
# Unit test for method first_name of class Person
def test_Person_first_name():
    """Unit test for method first_name of class Person"""
    from pydantic import BaseModel
    from app.core.config import FEMALE_FIRST_NAMES
    from app.core.config import MALE_FIRST_NAMES

    class TestPerson(BaseModel):
        """Test class for method first_name of class Person"""
        first_name: str
        names: dict
        gender: dict

    # Test first_name
    person = TestPerson(
        first_name=get_random_item(str, length=50),
        names={'male': MALE_FIRST_NAMES, 'female': FEMALE_FIRST_NAMES},
        gender={'male': 'male', 'female': 'female'}
    )

    string_value = person.first_name

# Generated at 2022-06-23 21:44:19.715329
# Unit test for method university of class Person
def test_Person_university():
    gen = Person()
    result = gen.university()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:44:22.307172
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person(random=Random())
    assert type(person.gender()) == str
    assert type(person.gender(symbol=True)) == str
    assert type(person.gender(iso5218=True)) == int
    
test_Person_gender()
print('✓')

# Unit tests for method sex of class Person

# Generated at 2022-06-23 21:44:24.122496
# Unit test for method political_views of class Person
def test_Person_political_views():
    # Setup
    person = Person()

    # Exercise
    result = person.political_views()

    # Verify
    assert type(result) is str


# Generated at 2022-06-23 21:44:26.582648
# Unit test for method views_on of class Person
def test_Person_views_on():
    try:
        p = Person()
        views_on = p.views_on()
        assert isinstance(views_on, str)
    except NonEnumerableError:
        assert False, 'The method Person.views_on raises NonEnumerableError.'

# Generated at 2022-06-23 21:44:32.687239
# Unit test for method worldview of class Person
def test_Person_worldview():
    print("Test worldview")

# Generated at 2022-06-23 21:44:35.294805
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person(random=Random())
    result = person.first_name()
    _check_parm(result, 'Person.first_name()')

# Generated at 2022-06-23 21:44:37.204700
# Unit test for method political_views of class Person
def test_Person_political_views():
    data = Person().political_views()
    assert isinstance(data, str)

# Generated at 2022-06-23 21:44:46.097246
# Unit test for method language of class Person
def test_Person_language():
    _ = Person('en_US')
    languages = _.language()

# Generated at 2022-06-23 21:44:47.287053
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    assert p.views_on() != 'Negative'

# Generated at 2022-06-23 21:44:48.809659
# Unit test for method university of class Person
def test_Person_university():
    guess = Person().university()
    assert isinstance(guess, str)



# Generated at 2022-06-23 21:45:01.261958
# Unit test for method name of class Person
def test_Person_name():
    person = Person(seed=1234)

    assert person.name(Gender.MALE) == 'Johann'
    assert person.name(Gender.FEMALE) == 'Kiara'
    assert person.name() == 'Kiara'
    assert person.name() == 'Liz'

    person = Person(seed='1234')

    assert person.name(Gender.MALE) == 'Johann'
    assert person.name(Gender.FEMALE) == 'Kiara'
    assert person.name() == 'Kiara'
    assert person.name() == 'Liz'

    person.random.seed(1234)
    assert person.name(Gender.FEMALE) == 'Kiara'
    assert person.name() == 'Kiara'

# Generated at 2022-06-23 21:45:05.574496
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    SocialNetwork.add_item('k')
    Person.data['social_media']['k'] = 'k.com/{0}'
    providers = [Person() for _ in range(10)]
    for provider in providers:
        result = provider.social_media_profile('k')
        assert 'k.com' in result



# Generated at 2022-06-23 21:45:07.642829
# Unit test for method name of class Person
def test_Person_name():
    p = Person(seed=12)
    result = p.name(Gender.MALE)
    assert result == 'Davian'

# Generated at 2022-06-23 21:45:09.959202
# Unit test for method name of class Person
def test_Person_name():
    p = Person()
    for _ in range(100):
        assert p.name() in NAME

# Generated at 2022-06-23 21:45:12.182139
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person()
    f_name = p.full_name(gender = Gender.male)
    assert (f_name == 'Юрий Алексеев')

# Generated at 2022-06-23 21:45:15.111758
# Unit test for method gender of class Person
def test_Person_gender():
    generator = Generator()
    person = Person(generator)
    assert isinstance(person.gender(), str)
    

# Generated at 2022-06-23 21:45:24.267923
# Unit test for method password of class Person

# Generated at 2022-06-23 21:45:33.581631
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    assert person.weight()


if __name__ == '__main__':
    person = Person()

    print(person.name(Gender.MALE))
    print(person.sex(iso5218=True))
    print(person.height())
    print(person.weight())
    print(person.blood_type())
    print(person.sexual_orientation())
    print(person.occupation())
    print(person.political_views())
    print(person.worldview())
    print(person.views_on())
    print(person.nationality())
    print(person.university())
    print(person.academic_degree())
    print(person.language())
    print(person.telephone())
    print(person.identifier('##-##/##'))

# Generated at 2022-06-23 21:45:38.533684
# Unit test for method first_name of class Person
def test_Person_first_name():
    f = Person.first_name
    # test function with wrong arguments
    try:
        f('male')
    except TypeError:
        pass
    else:
        raise Exception("Error")
    # test standard usage
    assert isinstance(f(), str)


# Generated at 2022-06-23 21:45:43.173188
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert 'Chief executive officer' in Person().work_experience
    assert 'Position' in str(Person().work_experience)
    assert 'Company' in str(Person().work_experience)
    assert type(Person().work_experience) == dict

# Generated at 2022-06-23 21:45:46.762603
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=0)
    surname1 = person.surname()
    surname2 = person.surname()
    surname3 = person.surname()
    assert surname1 == 'Иванов'
    assert surname2 == 'Иванов'
    assert surname3 == 'Петров'
    # Test aliases
    surname4 = person.last_name()
    assert surname4 == surname3

# Generated at 2022-06-23 21:45:50.818394
# Unit test for method political_views of class Person
def test_Person_political_views():
    for _ in range(100):
        item = Person.political_views()
        assert isinstance(item, str)
        assert item in POLITICAL_VIEWS

# Generated at 2022-06-23 21:45:57.431057
# Unit test for method last_name of class Person
def test_Person_last_name():
    def test_Person_last_name_spanish(lang):
        p = Person(lang=lang)
        one_factor = p.last_name(gender=Gender.MALE)
        another_factor = p.last_name(gender=Gender.MALE)
        assert one_factor != another_factor
    
    for lang in ('es', 'en', 'fr'):
        yield test_Person_last_name_spanish, lang

# Generated at 2022-06-23 21:46:03.601617
# Unit test for method username of class Person
def test_Person_username():
    mock = MD5Mock()
    provider = Faker('en_US')
    provider.random.seed(0)

    assert provider.username(template='UUd') == 'AA1688'
    assert provider.username(template='UUU6d') == 'AAA1776'
    assert provider.username(template='Ud') == 'R890'
    assert provider.username() == 'e.1862'

    provider.random.seed(None)
    provider.random.randstr = mock
    assert provider.username(unique=True) == 'sdfsdf37'
    assert mock.call_count == 1



# Generated at 2022-06-23 21:46:05.378522
# Unit test for method political_views of class Person
def test_Person_political_views():
    """ Unit test for method political_views of class Person. """
    person = Person()
    political_views = person.political_views()
    assert political_views in PERSON_POLITICAL_VIEWS


# Generated at 2022-06-23 21:46:06.549283
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    gender = p.gender()
    assert gender in ('Male', 'Female')


# Generated at 2022-06-23 21:46:08.232261
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    assert isinstance(person.political_views(), str)


# Generated at 2022-06-23 21:46:11.931245
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    assert isinstance(p.last_name(), str)
    assert isinstance(p.last_name(gender=Gender.MALE), str)
    assert isinstance(p.last_name(gender=Gender.FEMALE), str)


# Generated at 2022-06-23 21:46:24.439250
# Unit test for method username of class Person
def test_Person_username():
    print("\n===== TEST METHOD 'username' =====")
    provider = Person()
    print("default template:", provider.username(None)) # U-d
    print("your template:", provider.username('ld'))
    print("U_d template:", provider.username('U_d'))
    print("U.d template:", provider.username('U.d'))
    print("U-d template:", provider.username('U-d'))
    print("ld template:", provider.username('ld'))
    print("l-d template:", provider.username('l-d'))
    print("l.d template:", provider.username('l.d'))
    print("l_d template:", provider.username('l_d'))

# Generated at 2022-06-23 21:46:35.514078
# Unit test for method political_views of class Person
def test_Person_political_views():
    from faker import Faker 
    from faker.providers.person.en import Provider
    from faker.providers.person.ru_RU import Provider
    from faker.providers.person.de_DE import Provider
    from faker.providers.person.es_ES import Provider
    from faker.providers.person.it_IT import Provider
    from faker.providers.person.ja_JP import Provider
    from faker.providers.person.fr_FR import Provider
    from faker.providers.person.zh_CN import Provider
    from faker.providers.person.ru_RU import Provider

    fake = Faker()

    assert isinstance(fake.political_views(), (str, list)) == True 
    assert isinstance(fake.political_views(), (str, list)) == True 

# Generated at 2022-06-23 21:46:37.070363
# Unit test for method first_name of class Person
def test_Person_first_name():
    for i in range(1,10):
        assert len(Person().name())==i


# Generated at 2022-06-23 21:46:38.952380
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test default case
    person = Person()
    assert person.nationality() in NATIONALITIES

# Generated at 2022-06-23 21:46:40.947353
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person
    assert p.avatar(p) != None

# Generated at 2022-06-23 21:46:51.700039
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person(seed=1)
    assert p.social_media_profile(site=SocialNetwork.Facebook) == 'https://facebook.com/kxy'
    assert p.social_media_profile(site=SocialNetwork.Twitter) == 'https://twitter.com/4b'
    assert p.social_media_profile(site=SocialNetwork.Instagram) == 'https://instagram.com/l_'
    assert p.social_media_profile(site=SocialNetwork.Linkedin) == 'https://linkedin.com/po'
    assert p.social_media_profile(site=SocialNetwork.GooglePlus) == 'https://googleplus.com/wp'
    assert p.social_media_profile(site=SocialNetwork.YouTube) == 'https://youtube.com/yt'

# Generated at 2022-06-23 21:46:53.523515
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    university = person.university()
    assert university in PERSON_DATA['university']


# Generated at 2022-06-23 21:46:59.405708
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person('en')
    assert person.gender() in GENDERS
    assert person.sex() in GENDERS
    assert person.gender(iso5218=True) in [0, 1, 2, 9]
    assert person.gender(symbol=True) in GENDER_SYMBOLS


# Generated at 2022-06-23 21:47:00.911195
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person().full_name() != Person().full_name()

# Generated at 2022-06-23 21:47:04.114261
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    '''
    Testing BLOOD_GROUPS
    '''
    BLOOD_TYPE = Person().blood_type()
    assert BLOOD_TYPE in BLOOD_GROUPS


# Generated at 2022-06-23 21:47:13.491549
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    """Unit-test for method social_media_profile.
    
    Arguments:
        Person {[type]} -- [description]
    """
    person = Person('en') # 'en' - is a language code
    
    # Prints profile on Facebook
    print('Facebook:', person.social_media_profile(SocialNetwork.FACEBOOK))
    
    # Prints profile on Twitter
    print('Twitter:', person.social_media_profile(SocialNetwork.TWITTER))
    
    # Prints profile on Google+
    print('Google:', person.social_media_profile(SocialNetwork.GOOGLE))
    
    # Prints profile on Youtube
    print('Youtube:', person.social_media_profile(SocialNetwork.YOUTUBE))
    
    # Prints profile on Vimeo

# Generated at 2022-06-23 21:47:16.482391
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    assert p.worldview() in [item for item in p._data['worldview']]
test_Person_worldview()

# Generated at 2022-06-23 21:47:22.524110
# Unit test for method identifier of class Person
def test_Person_identifier():
    rng = Random()
    p = Person(rng)
    mask = '##-##/##'
    mask = '@@-@@/@@'
    mask = '##-##-##-##'
    id = p.identifier(mask)
    assert(len(id)==len(mask))
    assert('-' in id)
    id = p.identifier(mask)
    assert(len(id)==len(mask))
    assert('/' in id)
    id = p.identifier(mask)
    assert(len(id)==len(mask))
    assert('-' in id)
    id = p.identifier(mask)
    assert(len(id)==len(mask))
    mask = '@@-@@-@@-@@'
    id = p.identifier(mask)

# Generated at 2022-06-23 21:47:26.556650
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    """Unit test for method work_experience of class Person"""
    # Test if it is tuple and has len
    assert(isinstance(Person.work_experience(), tuple)) and \
        (len(Person.work_experience()) == 2)


# Generated at 2022-06-23 21:47:33.859455
# Unit test for method social_media_profile of class Person

# Generated at 2022-06-23 21:47:42.856754
# Unit test for method sex of class Person
def test_Person_sex():
    """Unit test for method sex of class Person."""
    random_person = Person()
    # https://docs.python.org/3/library/unittest.html
    # https://docs.python.org/3/library/unittest.html#assert-methods
    # https://pypi.org/project/assertpy/
    # https://pypi.org/project/assertpy/ == assertpy
    # https://assertpy.readthedocs.io/en/latest/
    # https://assertpy.readthedocs.io/en/latest/#
    # https://github.com/Activiti/Activiti == Activiti
    # https://github.com/Activiti/Activiti/tree/master/activiti-cloud-examples
    # https://github.com/Activiti/Activiti == Activ

# Generated at 2022-06-23 21:47:44.772784
# Unit test for method sex of class Person
def test_Person_sex():
    gen = Person()
    names = [gen.sex() for _ in range(100)]
    name = names[0]

    assert type(name) == str
    assert name in gen._data['gender']

# Generated at 2022-06-23 21:47:46.285044
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    n = person.first_name()
    assert len(n) > 0, 'Name is empty'
    print(n)

# Generated at 2022-06-23 21:47:49.133067
# Unit test for method occupation of class Person
def test_Person_occupation():
    result = ""
    count = 0
    while count < 1:
        instance = Person(seed=count)
        result = instance.occupation()
        count += 1
    assert result != ""
    

# Generated at 2022-06-23 21:47:56.505769
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person('zh')
    assert person.nationality() in PERSON.NATIONALITY
    assert person.nationality(gender=Person.GENDER.M) in PERSON.NATIONALITY.M
    assert person.nationality(gender=Person.GENDER.F) in PERSON.NATIONALITY.F
    assert person.nationality(gender='M') in PERSON.NATIONALITY.M
    assert person.nationality(gender='F') in PERSON.NATIONALITY.F

# Generated at 2022-06-23 21:47:58.971187
# Unit test for method weight of class Person
def test_Person_weight():
    for _ in range(300):
        result = Person().weight(minimum=10, maximum=20)
        assert result >= 10 and result <= 20

# Generated at 2022-06-23 21:48:05.591369
# Unit test for method avatar of class Person
def test_Person_avatar():
    m = Person(seed=10)
    c = 'https://api.adorable.io/avatars/256/12d0517c41a96371672e19c5dcd6a29b.png'
    assert m.avatar() == c
    c = 'https://api.adorable.io/avatars/100/12d0517c41a96371672e19c5dcd6a29b.png'
    assert m.avatar(size=100) == c



# Generated at 2022-06-23 21:48:09.080802
# Unit test for method height of class Person
def test_Person_height():
    height = Person().height()
    assert len(height) == 4
    assert height.count('.') == 1


# Generated at 2022-06-23 21:48:10.968316
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in ['Negative', 'Neutral', 'Positive']

# Generated at 2022-06-23 21:48:18.830697
# Unit test for method height of class Person
def test_Person_height():
    # Init Faker class
    faker = Faker()
    # Call method 'height'
    result = faker.Person.height()
    # Check the type of result
    if not isinstance(result, float):
        print("ERROR! Method 'height' of class 'Person' must return float")
        exit(1)
    # Check the range of returned value
    if result < 1.5 or result > 2.0:
        print("ERROR! Method 'height' of class 'Person' must return float in range [1.5, 2.0]")
        exit(1)
    # Show result
    print("Method 'height' of class 'Person' has been successfully tested.")

# Generated at 2022-06-23 21:48:26.155487
# Unit test for method views_on of class Person
def test_Person_views_on():
    from pprint import pprint
    from hypothesis import given, assume, settings

    # Init function
    _func = p.views_on

    # MUST_BE_EQUAL_TO_CONSTANT
    @settings(max_examples=100,
              deadline=None)
    @given(st.integers(min_value=1, max_value=100))
    def test_views_on(n: int):
        global this_provider
        assume(n >= 1)
        assume(n <= 100)
        must_be = [
            'Positive',
            'Negative',
            'Neutral'
        ]
        for i in range(n):
            res = _func(this_provider)
            pprint(res)
            assert res in must_be

    test_views_on()

#

# Generated at 2022-06-23 21:48:28.832808
# Unit test for method telephone of class Person
def test_Person_telephone():
    return '+7-(963)-409-11-22'



# Generated at 2022-06-23 21:48:30.452186
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider, Person)

# Generated at 2022-06-23 21:48:38.122512
# Unit test for method email of class Person
def test_Person_email():
    from string import ascii_letters

    p = Person()
    assert p.email()
    assert '@' in p.email()
    assert p.email().split('@')[1] in EMAIL_DOMAINS
    assert '{}@{}'.format(p.email().split('@')[0], p.email().split('@')[1]) == p.email()

    assert p.email(domains=['@mail.ru', '@yandex.ru'])
    assert '1@2' == p.email('1@2')
    assert p.email(unique=True)
    assert '.' in p.email(unique=True)

    assert '_' in p.email(unique=True, domains=['@mail.ru', '@yandex.ru'])

# Generated at 2022-06-23 21:48:43.224217
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person('test')
    assert person.identifier('##-##/##') == '07-97/04'
    assert person.identifier('@##/##/##') == 'J52/75/72'
    assert person.identifier('###/@##/##') == '942/W18/40'


# Generated at 2022-06-23 21:48:45.052518
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person(None)
    for i in range(100):
        print(p.occupation())


# Generated at 2022-06-23 21:48:50.428472
# Unit test for method gender of class Person
def test_Person_gender():
    from nose.tools import assert_is_instance, assert_equal
    from faker.providers.person.en import Provider as PersonEnProvider

    en_provider = PersonEnProvider.seed_instance(0)
    assert_is_instance(en_provider.gender(), str)
    assert_equal(en_provider.gender(), 'Male')

# Generated at 2022-06-23 21:48:57.158600
# Unit test for constructor of class Person
def test_Person():
    from pprint import pprint

    provider = Person()


# Generated at 2022-06-23 21:49:01.030059
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(True)
    assert person.surname() != None
    assert type(person.surname()) == str
    print("test_Person_surname() passed successfully")

# Generated at 2022-06-23 21:49:06.986522
# Unit test for method password of class Person
def test_Person_password():
    p = Person()
    password = p.password()
    assert type(password) == str
    assert len(password) == 8
    assert not re.match("^[a-z]+$", password) and not re.match("^[A-Z]+$", password) and not re.match("^[0-9]+$", password)
    assert re.match("^[a-zA-Z0-9]+$", password)

# Generated at 2022-06-23 21:49:10.385023
# Unit test for method views_on of class Person
def test_Person_views_on():
    from pydgutils.random import Random
    from pydgutils.random.providers import Person

    r = Random()
    v = r.person.views_on()
    assert isinstance(v, str)

# Generated at 2022-06-23 21:49:15.750953
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Arrange
    person = Person()
    mask = '+99-(##)-###-##-##'

    # Act
    result = person.telephone(mask=mask)

    # Assert
    assert re.fullmatch(r'\+\d{2}\-\(\d{2}\)\-\d{3}\-\d{2}\-\d{2}', result)

# Generated at 2022-06-23 21:49:18.172054
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    assert person.social_media_profile()

# Generated at 2022-06-23 21:49:24.178553
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    # should return a string
    assert isinstance(person.political_views(), str)
    # should return a random view
    assert person.political_views() in person._data['political_views']
    # should return a random view
    assert person.political_views() in person._data['political_views']

# Generated at 2022-06-23 21:49:30.093441
# Unit test for method avatar of class Person
def test_Person_avatar():
    """
    Test method avatar of class Person.
        
    """
    faker = Factory.create()
    for _ in range(10):
        avatar = faker.person.avatar(300)
        assert isinstance(avatar, str)
        assert avatar.find('api.adorable.io/avatars') > -1
        assert avatar.find('.png') > -1
        
test_Person_avatar()


# Generated at 2022-06-23 21:49:33.162160
# Unit test for method height of class Person
def test_Person_height():
    provider = Person()

    assert provider.height() is not None


# Generated at 2022-06-23 21:49:38.117704
# Unit test for method weight of class Person
def test_Person_weight():
    n = 10
    print('\nPerson weight:')
    p = Person()
    for i in range(n):
        weight = p.weight()
        print(weight, end=' ')
        assert type(weight) == int


# Generated at 2022-06-23 21:49:39.836134
# Unit test for method university of class Person
def test_Person_university():
    print("testing Person(university)")

    p = Person()
    p.university()


# Generated at 2022-06-23 21:49:43.171044
# Unit test for method name of class Person
def test_Person_name():
    name = random_person.name(gender=Gender.FEMALE)
    print(name)
    assert not name is None
    assert isinstance(name, str)


# Generated at 2022-06-23 21:49:50.334996
# Unit test for method username of class Person
def test_Person_username():
    with pytest.raises(ValueError):
        provider = Person(locales=['ru_RU'])
        provider.username('wrong-template')

    with pytest.raises(ValueError):
        provider = Person(locales=['ru_RU'])
        provider.username(template='U-d')

    provider = Person(locales=['ru_RU'])
    username = provider.username()

    assert username is not None



# Generated at 2022-06-23 21:50:01.824706
# Unit test for method username of class Person
def test_Person_username():
    from pfaker.providers import Person

    # Test that generated user name is in username list
    rnd_user_name = Person().username()
    assert (rnd_user_name in USERNAMES)

    # Test that generated user name is in username list
    rnd_user_name = Person(template=None).username()
    assert (rnd_user_name in USERNAMES)

    # Test that generated user name is in username list
    rnd_user_name = Person(template='ld').username()
    assert (rnd_user_name in USERNAMES)

    # Test that generated user name is in username list
    rnd_user_name = Person(template='U-d').username()
    assert (rnd_user_name in USERNAMES)

    # Test that generated user name is in username list
    r

# Generated at 2022-06-23 21:50:11.647169
# Unit test for method last_name of class Person

# Generated at 2022-06-23 21:50:19.556891
# Unit test for method political_views of class Person
def test_Person_political_views():

    # Generate a list of random political views
    political_views_list = [Person().political_views() for _ in range(5)]

    # Assert that the method political_views returns a list of strings
    assert isinstance(political_views_list, list)
    assert all([isinstance(views, str)
                for views in political_views_list])
test_Person_political_views()

print('Success!')


# Generated at 2022-06-23 21:50:30.557087
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person_provider = Person(random.Random())
    # Assert sexual_orientation
    assert person_provider.sexual_orientation() in (
        "Andromimetophilia",
        "Androphilia",
        "Autosexuality",
        "Bisexuality",
        "Flashing",
        "Gynecomimetophilia",
        "Heterosexuality",
        "Homosexuality",
        "Lesbophilia",
        "Pedophilia",
        "Teleiophilia",
        "Transgender",
        "Transsexuality",
    )

    # Assert sexual_orientation with symbol

# Generated at 2022-06-23 21:50:33.193484
# Unit test for method language of class Person
def test_Person_language():
    data = load_data(__name__)
    p = Person(data)
    assert p.language() in data['language']

# Generated at 2022-06-23 21:50:35.584954
# Unit test for method username of class Person
def test_Person_username():
    person = Person(Random(), seed=50, locale='en')
    assert person.username() == 'l.d'

# Generated at 2022-06-23 21:50:39.311553
# Unit test for method first_name of class Person
def test_Person_first_name():
    print('\nStart unit test. Method first_name of class Person:\n')
    person = Person()
    print(person.first_name())
    print(person.first_name(Gender.male))
    print(person.first_name(Gender.female))


# Generated at 2022-06-23 21:50:43.619912
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    political_views = person.political_views()
    assert isinstance(political_views, str)
    assert political_views in PERSON_POLITICAL_VIEWS
    
    return None


# Generated at 2022-06-23 21:50:45.193848
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name() == Person().surname()


# Generated at 2022-06-23 21:50:47.794008
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    weight = person.weight()
    assert isinstance(weight, int)
    assert weight >= 38 and weight <= 90
test_Person_weight()

# Generated at 2022-06-23 21:50:58.073976
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    occupation = person.occupation()