

# Generated at 2022-06-17 22:55:35.421925
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:55:46.863613
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(domains=('@example.com',)) == 'foretime10@example.com'
    assert person.email(domains=('@example.com',)) != 'foretime10@example.com'
    assert person.email(unique=True, domains=('@example.com',)) == 'foretime10@example.com'

# Generated at 2022-06-17 22:55:49.127014
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:55:51.474902
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:55:55.253472
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:55:59.231465
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert len(surname) > 0

# Generated at 2022-06-17 22:56:01.994254
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:56:04.967336
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert len(surname) > 0


# Generated at 2022-06-17 22:56:07.204614
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:09.717796
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:56:22.646529
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
    assert person.nationality(Gender.MALE) in person._data['nationality']['male']
    assert person.nationality(Gender.FEMALE) in person._data['nationality']['female']


# Generated at 2022-06-17 22:56:27.659407
# Unit test for method gender of class Person
def test_Person_gender():
    # Test for method gender of class Person
    person = Person()
    assert person.gender() in GENDER_TITLES
    assert person.gender(iso5218=True) in [0, 1, 2, 9]
    assert person.gender(symbol=True) in GENDER_SYMBOLS


# Generated at 2022-06-17 22:56:29.579736
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:56:32.139433
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in GENDER_TITLES
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-17 22:56:33.373219
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:34.385138
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:38.637250
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for method surname of class Person
    # Arrange
    person = Person()
    # Act
    surname = person.surname()
    # Assert
    assert surname in person._data['surname']

# Generated at 2022-06-17 22:56:41.086052
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    surname = person.surname()
    # Assert
    assert isinstance(surname, str)


# Generated at 2022-06-17 22:56:47.027486
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDER_TITLES
    assert person.gender(symbol=True) in GENDER_SYMBOLS
    assert person.gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-17 22:56:57.064829
# Unit test for method username of class Person
def test_Person_username():
    """Test method username of class Person."""
    person = Person()
    assert person.username()
    assert person.username(template='Ud')
    assert person.username(template='ld')
    assert person.username(template='U_d')
    assert person.username(template='U.d')
    assert person.username(template='U-d')
    assert person.username(template='UU-d')
    assert person.username(template='UU.d')
    assert person.username(template='UU_d')
    assert person.username(template='l-d')
    assert person.username(template='l.d')
    assert person.username(template='l_d')
    assert person.username(template='default')
    assert person.username(template='U')
    assert person.username(template='l')

# Generated at 2022-06-17 22:57:03.465406
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:04.764866
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:06.384884
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:08.037774
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:57:18.370266
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)

# Generated at 2022-06-17 22:57:28.970180
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert email.count('@') == 1
    assert email.count('.') == 1
    assert email.count('_') == 0
    assert email.count('-') == 0
    assert email.count('+') == 0
    assert email.count(' ') == 0
    assert email.count('\n') == 0
    assert email.count('\t') == 0
    assert email.count('\r') == 0
    assert email.count('\v') == 0
    assert email.count('\f') == 0
    assert email.count('\b') == 0
    assert email.count('\a') == 0
    assert email.count('\0') == 0
    assert email.count('\x0b') == 0

# Generated at 2022-06-17 22:57:31.913088
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:57:34.419832
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']

# Generated at 2022-06-17 22:57:36.396320
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:38.672075
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:58:04.568697
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:06.426775
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:07.901432
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:08.989770
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:58:10.610980
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert isinstance(person.email(), str)
    assert '@' in person.email()


# Generated at 2022-06-17 22:58:20.133654
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_AVAILABLE), str)
#

# Generated at 2022-06-17 22:58:31.139386
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(domains=['example.com']) == 'foretime10@example.com'
    assert person.email(domains=['example.com'], unique=True) == 'foretime10@example.com'
    assert person.email(domains=['example.com'], unique=True) != 'foretime10@example.com'
    assert person.email(domains=['@example.com']) == 'foretime10@example.com'

# Generated at 2022-06-17 22:58:33.345631
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:58:34.989568
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:58:36.588841
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:44.560001
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:58:46.575600
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:56.919108
# Unit test for method surname of class Person
def test_Person_surname():
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.person.en_US import SURNAMES
    from faker.providers.person.en_US import GENDER_SYMBOLS
    from faker.providers.person.en_US import Gender
    from faker.providers.person.en_US import TitleType
    from faker.providers.person.en_US import Title
    from faker.providers.person.en_US import SocialNetwork
    from faker.providers.person.en_US import BLOOD_GROUPS
    from faker.providers.person.en_US import SEXUALITY_SYMBOLS
    from faker.providers.person.en_US import CALLING_CODES

# Generated at 2022-06-17 22:59:06.847782
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.male), str)
    assert isinstance(person.surname(gender=Gender.female), str)
    assert isinstance(person.surname(gender=Gender.not_known), str)
    assert isinstance(person.surname(gender=Gender.not_applicable), str)
    assert isinstance(person.surname(gender=Gender.other), str)


# Generated at 2022-06-17 22:59:10.403378
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:59:12.227854
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 22:59:15.470583
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:59:24.321435
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
    assert person.nationality(Gender.MALE) in person._data['nationality']['male']
    assert person.nationality(Gender.FEMALE) in person._data['nationality']['female']
    assert person.nationality(Gender.NOT_APPLICABLE) in person._data['nationality']['not_applicable']
    assert person.nationality(Gender.NOT_KNOWN) in person._data['nationality']['not_known']
    assert person.nationality(Gender.NOT_SPECIFIED) in person._data['nationality']['not_specified']
    assert person.nationality(Gender.PREFER_NOT_TO_SAY) in person._data['nationality']['prefer_not_to_say']

# Generated at 2022-06-17 22:59:27.176587
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:59:28.847859
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:59:36.882948
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:59:46.466425
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:59:55.099891
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 23:00:02.925915
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()
    assert person.email(unique=True)
    assert person.email(domains=('example.com',))
    assert person.email(domains=('@example.com',))
    assert person.email(domains=('@example.com', '@example.org'))
    assert person.email(domains=('example.com', 'example.org'))
    assert person.email(domains=('@example.com', '@example.org'))
    assert person.email(domains=('example.com', '@example.org'))
    assert person.email(domains=('@example.com', 'example.org'))
    assert person.email(domains=('example.com', 'example.org'))

# Generated at 2022-06-17 23:00:09.784245
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)
    assert isinstance(p.nationality(gender=Gender.MALE), str)
    assert isinstance(p.nationality(gender=Gender.FEMALE), str)
    assert isinstance(p.nationality(gender=Gender.UNKNOWN), str)
    assert isinstance(p.nationality(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(p.nationality(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 23:00:12.686558
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:14.103789
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 23:00:15.282620
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:00:26.115672
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)

# Generated at 2022-06-17 23:00:33.388375
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']


# Generated at 2022-06-17 23:00:46.903800
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 23:00:52.323152
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']

# Generated at 2022-06-17 23:00:53.719035
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:01:00.708480
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(Gender.MALE), str)
    assert isinstance(person.surname(Gender.FEMALE), str)
    assert isinstance(person.surname(Gender.UNKNOWN), str)
    assert isinstance(person.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(Gender.NOT_SPECIFIED), str)


# Generated at 2022-06-17 23:01:04.079894
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:01:06.416588
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 23:01:08.529599
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 23:01:09.633601
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:01:11.305656
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']

# Generated at 2022-06-17 23:01:14.899582
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:01:39.681990
# Unit test for method email of class Person
def test_Person_email():
    from faker import Faker
    fake = Faker()
    fake.seed(0)
    assert fake.email() == 'johann.wolfgang@hotmail.com'
    assert fake.email(unique=True) == 'johann.wolfgang@hotmail.com'
    assert fake.email(unique=True) == 'johann.wolfgang.1@hotmail.com'
    assert fake.email(unique=True) == 'johann.wolfgang.2@hotmail.com'
    assert fake.email(unique=True) == 'johann.wolfgang.3@hotmail.com'
    assert fake.email(unique=True) == 'johann.wolfgang.4@hotmail.com'

# Generated at 2022-06-17 23:01:42.885253
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert len(surname) > 0


# Generated at 2022-06-17 23:01:44.707208
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    assert result in person._data['nationality']


# Generated at 2022-06-17 23:01:47.136366
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in SURNAMES

# Generated at 2022-06-17 23:01:48.415387
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 23:01:53.644013
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 23:01:55.646626
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:02:02.701522
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 23:02:04.036904
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:02:05.402212
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:02:50.694356
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname() == 'Смирнов'
    assert person.surname(gender=Gender.MALE) == 'Смирнов'
    assert person.surname(gender=Gender.FEMALE) == 'Иванова'


# Generated at 2022-06-17 23:02:53.193652
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']

# Generated at 2022-06-17 23:02:58.421533
# Unit test for method username of class Person
def test_Person_username():
    # Test with default template
    assert Person().username() == 'l.d'
    # Test with custom template
    assert Person().username(template='UU_d') == 'UU_d'
    # Test with custom template
    assert Person().username(template='UU_d') == 'UU_d'
    # Test with custom template
    assert Person().username(template='UU_d') == 'UU_d'
    # Test with custom template
    assert Person().username(template='UU_d') == 'UU_d'
    # Test with custom template
    assert Person().username(template='UU_d') == 'UU_d'
    # Test with custom template
    assert Person().username(template='UU_d') == 'UU_d'
    # Test with custom template

# Generated at 2022-06-17 23:02:59.932899
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:03:02.180675
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:03:03.425885
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email() == 'foretime10@live.com'

# Generated at 2022-06-17 23:03:04.461044
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:03:08.057543
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:03:10.444187
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()
    assert person.email(unique=True)
    assert person.email(domains=('example.com',))
    assert person.email(unique=True, domains=('example.com',))


# Generated at 2022-06-17 23:03:12.369961
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 23:04:48.518173
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 23:04:49.792570
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 23:04:51.992730
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:05:02.077293
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 23:05:09.088190
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)

# Generated at 2022-06-17 23:05:11.614143
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 23:05:12.810464
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:05:13.949775
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)


# Generated at 2022-06-17 23:05:16.979412
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:05:21.660259
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)