

# Generated at 2022-06-17 22:55:50.450554
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:55:57.384722
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:56:00.158375
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:02.928140
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:56:14.871675
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.PREFER_NOT_TO_SAY), str)
    assert isinstance(p.surname(Gender.UNSPECIFIED), str)

# Generated at 2022-06-17 22:56:16.500854
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:18.873534
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:21.810980
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:23.549414
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:25.835515
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 22:56:40.059011
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:44.200297
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:46.421046
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:56:48.911769
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in SURNAMES


# Generated at 2022-06-17 22:56:58.820912
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 22:57:10.477229
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.NOT_KNOWN) in person._data['surname']['not_known']


# Generated at 2022-06-17 22:57:13.703683
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:15.873318
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:25.131361
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 22:57:26.969472
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:58:10.253990
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in SURNAMES


# Generated at 2022-06-17 22:58:19.976383
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.providers.person.en import Provider as PersonProvider
    from faker.providers.person.ru import Provider as PersonProviderRu
    from faker.providers.person.uk import Provider as PersonProviderUk
    from faker.providers.person.de import Provider as PersonProviderDe
    from faker.providers.person.es import Provider as PersonProviderEs
    from faker.providers.person.fr import Provider as PersonProviderFr
    from faker.providers.person.it import Provider as PersonProviderIt
    from faker.providers.person.ja import Provider as PersonProviderJa
    from faker.providers.person.ko import Provider as PersonProviderKo
    from faker.providers.person.zh_CN import Provider as PersonProviderZhCN

# Generated at 2022-06-17 22:58:24.991842
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname(Gender.MALE) in p._data['surname']['male']
    assert p.surname(Gender.FEMALE) in p._data['surname']['female']
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:58:26.773289
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:58:28.478905
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']
