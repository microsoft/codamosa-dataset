

# Generated at 2022-06-17 22:56:03.400770
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:05.458523
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']

# Generated at 2022-06-17 22:56:07.338493
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES


# Generated at 2022-06-17 22:56:09.823279
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:16.917683
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.male), str)
    assert isinstance(person.surname(gender=Gender.female), str)
    assert isinstance(person.surname(gender=Gender.not_known), str)
    assert isinstance(person.surname(gender=Gender.not_applicable), str)
    assert isinstance(person.surname(gender=Gender.other), str)

# Generated at 2022-06-17 22:56:19.032154
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:56:21.899897
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:31.647916
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email()

# Generated at 2022-06-17 22:56:32.872985
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:34.583895
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    result = person.surname()
    # Assert
    assert isinstance(result, str)

# Generated at 2022-06-17 22:56:57.831758
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:57:00.238512
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:03.740725
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:06.292965
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)



# Generated at 2022-06-17 22:57:08.623353
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:11.382806
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:57:23.208952
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.OTHER) in person._data['surname']['other']

# Generated at 2022-06-17 22:57:25.287013
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:28.708770
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)


# Generated at 2022-06-17 22:57:41.112028
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default value
    assert Person().surname() in SURNAMES
    # Test with gender
    assert Person().surname(Gender.MALE) in SURNAMES_MALE
    assert Person().surname(Gender.FEMALE) in SURNAMES_FEMALE
    # Test with incorrect value
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.UNKNOWN)
    # Test with incorrect type
    with pytest.raises(NonEnumerableError):
        Person().surname(None)
    with pytest.raises(NonEnumerableError):
        Person().surname(1)
    with pytest.raises(NonEnumerableError):
        Person().surname('male')
    with pytest.raises(NonEnumerableError):
        Person