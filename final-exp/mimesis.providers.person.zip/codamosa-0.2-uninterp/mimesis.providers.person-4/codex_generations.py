

# Generated at 2022-06-17 22:55:35.904673
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person."""
    person = Person()
    surname = person.surname()
    assert surname in SURNAMES


# Generated at 2022-06-17 22:55:37.233528
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:55:39.090746
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:55:50.730689
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']
    assert p.surname(gender=Gender.MALE) in p._data['surname']['male']
    assert p.surname(gender=Gender.FEMALE) in p._data['surname']['female']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender=Gender.NOT_APPLICABLE) in p._data['surname']['not_applicable']
    assert p.surname(gender=Gender.OTHER) in p._data['surname']['other']


# Generated at 2022-06-17 22:55:52.394867
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:56:06.035627
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default parameters
    assert Person().surname() in SURNAMES
    # Test with gender
    assert Person().surname(Gender.MALE) in SURNAMES_MALE
    assert Person().surname(Gender.FEMALE) in SURNAMES_FEMALE
    # Test with gender in incorrect format
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.NOT_KNOWN)
    # Test with surnames in incorrect format
    with pytest.raises(TypeError):
        Person(surnames=['Smith']).surname()
    # Test with surnames in correct format
    surnames = {
        Gender.MALE: ['Smith'],
        Gender.FEMALE: ['Smith'],
    }

# Generated at 2022-06-17 22:56:08.435795
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:10.828153
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:12.982832
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:56:21.103216
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert isinstance(person.email(), str)
    assert isinstance(person.email(unique=True), str)
    assert isinstance(person.email(domains=('gmail.com',)), str)
    assert isinstance(person.email(domains=('@gmail.com',)), str)
    assert isinstance(person.email(domains=('@gmail.com', '@mail.ru')), str)
    assert isinstance(person.email(domains=('gmail.com', 'mail.ru')), str)
    assert isinstance(person.email(domains=('@gmail.com', '@mail.ru')), str)
    assert isinstance(person.email(domains=('@gmail.com', '@mail.ru')), str)

# Generated at 2022-06-17 22:56:32.367828
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:56:33.459727
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:56:34.447039
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-17 22:56:38.947988
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert isinstance(person.nationality(gender=Gender.MALE), str)
    assert isinstance(person.nationality(gender=Gender.FEMALE), str)
    assert isinstance(person.nationality(gender=Gender.UNKNOWN), str)
    assert isinstance(person.nationality(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.nationality(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:56:42.366370
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert email.count('@') == 1
    assert email.count('.') == 1
    assert email.split('@')[1] in EMAIL_DOMAINS


# Generated at 2022-06-17 22:56:51.691377
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default value
    assert Person().surname() in Person()._data['surname']
    # Test with gender
    assert Person().surname(gender=Gender.MALE) in Person()._data['surname']['male']
    assert Person().surname(gender=Gender.FEMALE) in Person()._data['surname']['female']
    # Test with incorrect value
    with pytest.raises(NonEnumerableError):
        Person().surname(gender='male')


# Generated at 2022-06-17 22:56:58.618762
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default parameters
    assert Person().surname() in Person()._data['surname']
    # Test with gender
    assert Person().surname(gender=Gender.MALE) in Person()._data['surname']['male']
    assert Person().surname(gender=Gender.FEMALE) in Person()._data['surname']['female']
    # Test with incorrect gender
    try:
        Person().surname(gender='male')
    except NonEnumerableError:
        pass
    else:
        assert False

# Generated at 2022-06-17 22:57:01.749109
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:57:04.574167
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:57:08.778890
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname(Gender.MALE) in person._data['surname']['male']
    assert person.surname(Gender.FEMALE) in person._data['surname']['female']
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:22.817502
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:25.946334
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:57:31.252799
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default parameters
    person = Person()
    surname = person.surname()
    assert surname in SURNAMES
    # Test with gender
    surname = person.surname(gender=Gender.MALE)
    assert surname in SURNAMES_MALE
    surname = person.surname(gender=Gender.FEMALE)
    assert surname in SURNAMES_FEMALE
    # Test with incorrect gender
    with pytest.raises(NonEnumerableError):
        person.surname(gender='male')

# Generated at 2022-06-17 22:57:33.230999
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:35.271631
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:36.794494
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:38.672685
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)


# Generated at 2022-06-17 22:57:42.601524
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert re.match(r'^[\w\d]+@[\w\d]+\.[\w\d]+$', email)

# Generated at 2022-06-17 22:58:04.569380
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'foretime10@live.com'
    assert p.email(unique=True) == 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'
    assert p.email(domains=('example.com',)) == 'foretime10@example.com'
    assert p.email(domains=('@example.com',)) == 'foretime10@example.com'
    assert p.email(domains=('example.com', '@example.com')) == 'foretime10@example.com'
    assert p.email(domains=('example.com', '@example.com')) == 'foretime10@example.com'

# Generated at 2022-06-17 22:58:06.841197
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert len(person.surname()) > 0

# Generated at 2022-06-17 22:58:35.707045
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:58:37.303386
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:58:39.248722
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:40.921142
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:49.358427
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:59:00.712814
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 22:59:06.399196
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'foretime10@live.com'
    assert p.email(unique=True) == 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'
    assert p.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 22:59:09.615873
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:59:11.876376
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:59:15.155997
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
