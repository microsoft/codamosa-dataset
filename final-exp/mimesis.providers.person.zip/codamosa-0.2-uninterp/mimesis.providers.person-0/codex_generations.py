

# Generated at 2022-06-17 22:55:57.542586
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    assert p.gender() in GENDER_TITLES
    assert p.gender(symbol=True) in GENDER_SYMBOLS
    assert p.gender(iso5218=True) in [0, 1, 2, 9]
    assert p.sex() in GENDER_TITLES
    assert p.sex(symbol=True) in GENDER_SYMBOLS
    assert p.sex(iso5218=True) in [0, 1, 2, 9]

# Generated at 2022-06-17 22:56:01.034989
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDER_TITLES
    assert person.gender(iso5218=True) in [0, 1, 2, 9]
    assert person.gender(symbol=True) in GENDER_SYMBOLS


# Generated at 2022-06-17 22:56:07.643482
# Unit test for method gender of class Person
def test_Person_gender():
    # Test for method gender of class Person
    # with default parameters
    person = Person()
    assert person.gender() in GENDER_TYPES
    # with parameter iso5218=True
    assert person.gender(iso5218=True) in [0, 1, 2, 9]
    # with parameter symbol=True
    assert person.gender(symbol=True) in GENDER_SYMBOLS


# Generated at 2022-06-17 22:56:10.060365
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:12.464340
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:13.431169
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-17 22:56:14.631342
# Unit test for method gender of class Person
def test_Person_gender():
    gender = Person().gender()
    assert gender in GENDER_SYMBOLS


# Generated at 2022-06-17 22:56:16.293557
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDER_SYMBOLS


# Generated at 2022-06-17 22:56:17.838265
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:56:21.209635
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:47.723461
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    result = person.surname()
    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-17 22:56:49.987023
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:51.335333
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:53.247852
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:55.993676
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:08.863741
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']
    assert person.surname(Gender.MALE) in person._data['surname']['male']
    assert person.surname(Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(Gender.NOT_KNOWN) in person._data['surname']['not_known']


# Generated at 2022-06-17 22:57:10.886111
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:22.066300
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    assert person.full_name() == 'Александр Сергеев'
    assert person.full_name(Gender.MALE) == 'Александр Сергеев'
    assert person.full_name(Gender.FEMALE) == 'Анна Сергеева'
    assert person.full_name(Gender.MALE, reverse=True) == 'Сергеев Александр'
    assert person.full_name(Gender.FEMALE, reverse=True) == 'Сергеева Анна'


# Generated at 2022-06-17 22:57:31.678288
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.PREFER_NOT_TO_SAY), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 22:57:33.720509
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:58:12.025095
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
