

# Generated at 2022-06-17 22:55:40.327457
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:55:52.732520
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
   

# Generated at 2022-06-17 22:56:02.929505
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=42)
    assert person.surname() == 'Сергеев'
    assert person.surname(gender=Gender.MALE) == 'Сергеев'
    assert person.surname(gender=Gender.FEMALE) == 'Сергеева'
    assert person.surname(gender=Gender.UNKNOWN) == 'Сергеев'


# Generated at 2022-06-17 22:56:04.598477
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:06.701753
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:17.604372
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 22:56:25.586561
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']


# Generated at 2022-06-17 22:56:27.441879
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:32.731336
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:56:34.989781
# Unit test for method username of class Person
def test_Person_username():
    provider = Person()
    for _ in range(100):
        username = provider.username()
        assert len(username) >= 2
        assert username[0].islower()
        assert username[-1].isdigit()


# Generated at 2022-06-17 22:56:51.064457
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(Gender.MALE), str)
    assert isinstance(person.surname(Gender.FEMALE), str)
    assert isinstance(person.surname(Gender.UNKNOWN), str)
    assert isinstance(person.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(Gender.OTHER), str)
    assert isinstance(person.surname(Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 22:56:52.859714
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:55.617434
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:58.852897
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:01.989646
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 22:57:04.689385
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:06.341030
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:07.944122
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 22:57:10.082038
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:11.522882
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES

# Generated at 2022-06-17 22:57:25.487442
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:27.618353
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:57:40.573771
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    assert person.username()
    assert person.username(template='U_d')
    assert person.username(template='U.d')
    assert person.username(template='U-d')
    assert person.username(template='UU-d')
    assert person.username(template='UU.d')
    assert person.username(template='UU_d')
    assert person.username(template='ld')
    assert person.username(template='l-d')
    assert person.username(template='Ud')
    assert person.username(template='l.d')
    assert person.username(template='l_d')
    assert person.username(template='default')
    assert person.username(template='U')
    assert person.username(template='l')
    assert person.username(template='d')

# Generated at 2022-06-17 22:57:42.480766
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=1)
    assert person.nationality() == 'Russian'


# Generated at 2022-06-17 22:57:44.354953
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:57:46.638022
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert isinstance(person.nationality(gender=Gender.MALE), str)
    assert isinstance(person.nationality(gender=Gender.FEMALE), str)

# Generated at 2022-06-17 22:57:48.210613
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:04.568662
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:09.489143
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email()

# Generated at 2022-06-17 22:58:11.837646
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:42.263321
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:58:45.945486
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:47.597972
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:58:59.179442
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_AVAILABLE), str)
   

# Generated at 2022-06-17 22:59:02.361748
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:59:05.253699
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(100):
        assert isinstance(Person().surname(), str)


# Generated at 2022-06-17 22:59:09.026449
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()
    assert person.email(unique=True)
    assert person.email(domains=('example.com',))
    assert person.email(unique=True, domains=('example.com',))
    assert person.email(unique=True, domains=('example.com', 'example.org'))


# Generated at 2022-06-17 22:59:11.098506
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:14.251763
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:59:15.754727
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()

# Generated at 2022-06-17 23:00:03.492330
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:00:04.954474
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:14.134187
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.male), str)
    assert isinstance(person.surname(gender=Gender.female), str)
    assert isinstance(person.surname(gender=Gender.not_known), str)
    assert isinstance(person.surname(gender=Gender.not_applicable), str)
    assert isinstance(person.surname(gender=Gender.not_specified), str)
    assert isinstance(person.surname(gender=Gender.other), str)


# Generated at 2022-06-17 23:00:16.806815
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:00:18.795498
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:20.393308
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:23.978899
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)


# Generated at 2022-06-17 23:00:25.139077
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email() == 'foretime10@live.com'


# Generated at 2022-06-17 23:00:26.470456
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:29.206336
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
