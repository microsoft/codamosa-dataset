

# Generated at 2022-06-17 22:55:46.060790
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email() == 'foretime10@live.com'
    assert p.email()

# Generated at 2022-06-17 22:55:57.503806
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'foretime10@live.com'
    assert p.email(domains=('example.com',)) == 'foretime10@example.com'
    assert p.email(unique=True) == 'foretime10@live.com'
    assert p.email(unique=True, domains=('example.com',)) == 'foretime10@example.com'
    assert p.email(unique=True, domains=('example.com',)) != 'foretime10@live.com'
    assert p.email(unique=True, domains=('example.com',)) != 'foretime11@example.com'
    assert p.email(unique=True, domains=('example.com',)) != 'foretime11@live.com'

# Generated at 2022-06-17 22:56:08.226539
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)
    assert isinstance(person.surname(gender=Gender.UNSPECIFIED), str)


# Generated at 2022-06-17 22:56:11.203289
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:56:13.309955
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:21.272407
# Unit test for method username of class Person
def test_Person_username():
    # Test with default template
    provider = Person()
    username = provider.username()
    assert username
    assert re.fullmatch(r'[a-z]{1,2}[\.\-\_]?\d{4}', username)

    # Test with custom template
    provider = Person()
    username = provider.username(template='U_d')
    assert username
    assert re.fullmatch(r'[A-Z]{1,2}[\.\-\_]\d{4}', username)

    # Test with custom template
    provider = Person()
    username = provider.username(template='Ud')
    assert username
    assert re.fullmatch(r'[A-Z]{1,2}\d{4}', username)

    # Test with custom template
    provider = Person()
    username = provider

# Generated at 2022-06-17 22:56:22.979330
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:25.682954
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:27.490486
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    assert provider.surname() in provider._data['surname']


# Generated at 2022-06-17 22:56:29.083969
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:45.044975
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']

# Generated at 2022-06-17 22:56:48.038227
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:56:58.368346
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(Gender.MALE), str)
    assert isinstance(person.surname(Gender.FEMALE), str)
    assert isinstance(person.surname(Gender.UNKNOWN), str)
    assert isinstance(person.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(Gender.OTHER), str)
    assert isinstance(person.surname(Gender.NOT_DECLARED), str)
    assert isinstance(person.surname(Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:57:03.264916
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:04.596192
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:06.258743
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:11.296250
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)


# Generated at 2022-06-17 22:57:16.445247
# Unit test for method email of class Person
def test_Person_email():
    # Arrange
    person = Person()
    # Act
    result = person.email()
    # Assert
    assert isinstance(result, str)
    assert '@' in result
    assert '.' in result

# Generated at 2022-06-17 22:57:20.241080
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for method surname of class Person
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:22.572245
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:36.500274
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:57:38.069429
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:48.842259
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    assert p.username()
    assert p.username(template='U_d')
    assert p.username(template='U.d')
    assert p.username(template='U-d')
    assert p.username(template='UU-d')
    assert p.username(template='UU.d')
    assert p.username(template='UU_d')
    assert p.username(template='ld')
    assert p.username(template='l-d')
    assert p.username(template='Ud')
    assert p.username(template='l.d')
    assert p.username(template='l_d')
    assert p.username(template='default')
    assert p.username(template='U_d')
    assert p.username(template='U.d')

# Generated at 2022-06-17 22:58:04.568606
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:58:07.446402
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:58:08.779705
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:13.601055
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:58:21.961386
# Unit test for method username of class Person
def test_Person_username():
    provider = Person()
    assert provider.username()
    assert provider.username(template='U_d')
    assert provider.username(template='U.d')
    assert provider.username(template='U-d')
    assert provider.username(template='UU-d')
    assert provider.username(template='UU.d')
    assert provider.username(template='UU_d')
    assert provider.username(template='ld')
    assert provider.username(template='l-d')
    assert provider.username(template='Ud')
    assert provider.username(template='l.d')
    assert provider.username(template='l_d')
    assert provider.username(template='default')
    assert provider.username(template='U_d')
    assert provider.username(template='U.d')

# Generated at 2022-06-17 22:58:24.053738
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:26.383484
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:59:06.389238
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(Gender.MALE), str)
    assert isinstance(person.surname(Gender.FEMALE), str)
    assert isinstance(person.surname(Gender.UNKNOWN), str)
    assert isinstance(person.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(Gender.OTHER), str)
    assert isinstance(person.surname(Gender.PREFER_NOT_TO_SAY), str)

# Generated at 2022-06-17 22:59:08.007930
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:19.970490
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime11@live.com'
    assert person.email(unique=True) == 'foretime12@live.com'
    assert person.email(unique=True) == 'foretime13@live.com'
    assert person.email(unique=True) == 'foretime14@live.com'
    assert person.email(unique=True) == 'foretime15@live.com'
    assert person.email(unique=True) == 'foretime16@live.com'
    assert person.email(unique=True) == 'foretime17@live.com'

# Generated at 2022-06-17 22:59:27.359192
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime11@live.com'
    assert person.email(unique=True) == 'foretime12@live.com'
    assert person.email(unique=True) == 'foretime13@live.com'
    assert person.email(unique=True) == 'foretime14@live.com'
    assert person.email(unique=True) == 'foretime15@live.com'
    assert person.email(unique=True) == 'foretime16@live.com'
    assert person.email(unique=True) == 'foretime17@live.com'

# Generated at 2022-06-17 22:59:29.958736
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:31.281251
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:59:33.356681
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:59:38.790219
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)


# Generated at 2022-06-17 22:59:55.103998
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'
    assert Person().email() == 'foretime10@live.com'

# Generated at 2022-06-17 22:59:56.887369
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    surname = person.surname()
    # Assert
    assert surname in person._data['surname']


# Generated at 2022-06-17 23:00:53.595621
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:00:55.175579
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:00:57.361465
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 23:01:07.375266
# Unit test for method surname of class Person

# Generated at 2022-06-17 23:01:17.841247
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']
    assert p.surname(gender=Gender.MALE) in p._data['surname']['male']
    assert p.surname(gender=Gender.FEMALE) in p._data['surname']['female']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']


# Generated at 2022-06-17 23:01:19.139608
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:01:20.284454
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:01:30.670484
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.UNSPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 23:01:38.381254
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 23:01:39.972786
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
