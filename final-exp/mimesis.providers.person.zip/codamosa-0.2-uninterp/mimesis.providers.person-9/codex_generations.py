

# Generated at 2022-06-17 22:55:47.268330
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert len(surname) > 0


# Generated at 2022-06-17 22:55:58.511070
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)
    assert isinstance(p.surname(Gender.NOT_AVAILABLE), str)

# Generated at 2022-06-17 22:56:01.916177
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:56:12.244613
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person()
    assert p.full_name()
    assert p.full_name(Gender.MALE)
    assert p.full_name(Gender.FEMALE)
    assert p.full_name(Gender.NOT_APPLICABLE)
    assert p.full_name(Gender.NOT_KNOWN)
    assert p.full_name(Gender.MALE, reverse=True)
    assert p.full_name(Gender.FEMALE, reverse=True)
    assert p.full_name(Gender.NOT_APPLICABLE, reverse=True)
    assert p.full_name(Gender.NOT_KNOWN, reverse=True)


# Generated at 2022-06-17 22:56:13.460658
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:56:15.520041
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:21.544109
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)


# Generated at 2022-06-17 22:56:23.998516
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test for method nationality of class Person
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:56:26.706031
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:33.730246
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)


# Generated at 2022-06-17 22:56:53.972047
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    assert person.username()
    assert person.username(template='U_d')
    assert person.username(template='U.d')
    assert person.username(template='U-d')
    assert person.username(template='UU-d')
    assert person.username(template='UU.d')
    assert person.username(template='UU_d')
    assert person.username(template='ld')
    assert person.username(template='l-d')
    assert person.username(template='Ud')
    assert person.username(template='l.d')
    assert person.username(template='l_d')
    assert person.username(template='default')
    assert person.username(template='U')
    assert person.username(template='l')
    assert person.username(template='d')

# Generated at 2022-06-17 22:56:56.215775
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:59.493469
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:57:02.556636
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:57:10.181581
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()
    assert person.email(unique=True)
    assert person.email(domains=('example.com',))
    assert person.email(domains=('@example.com',))
    assert person.email(domains=('@example.com', '@example.org'))
    assert person.email(domains=('example.com', 'example.org'))
    assert person.email(unique=True, domains=('example.com',))
    assert person.email(unique=True, domains=('@example.com',))
    assert person.email(unique=True, domains=('@example.com', '@example.org'))
    assert person.email(unique=True, domains=('example.com', 'example.org'))

# Generated at 2022-06-17 22:57:14.328417
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert '@' in email
    assert '.' in email

# Generated at 2022-06-17 22:57:16.340734
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:17.906477
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:21.996233
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']

# Generated at 2022-06-17 22:57:25.234680
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:57:32.279812
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:36.501253
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)

# Generated at 2022-06-17 22:57:42.481677
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)


# Generated at 2022-06-17 22:57:43.814762
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:45.789678
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:46.901444
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:02.246141
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)

# Generated at 2022-06-17 22:58:12.822472
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:58:16.123343
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:58:17.243251
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:58:34.549651
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)


# Generated at 2022-06-17 22:58:36.222000
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:58:42.868497
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:58:46.101417
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    surname = person.surname()
    # Assert
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:58:47.677044
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:58:50.096756
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:56.014926
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default value
    assert Person().surname() in SURNAMES

    # Test with gender
    assert Person().surname(Gender.MALE) in SURNAMES_MALE
    assert Person().surname(Gender.FEMALE) in SURNAMES_FEMALE

    # Test with incorrect value
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.NON_BINARY)


# Generated at 2022-06-17 22:58:59.365638
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    fake = Faker()
    assert fake.nationality() in fake._data['nationality']


# Generated at 2022-06-17 22:59:02.526767
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:05.341288
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:59:27.661273
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:59:29.958572
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in SURNAMES

# Generated at 2022-06-17 22:59:31.107986
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:59:32.862371
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:59:35.313501
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:59:39.710086
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)

# Generated at 2022-06-17 22:59:41.122627
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:55.103574
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)

# Generated at 2022-06-17 22:59:56.013898
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 22:59:58.654279
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:24.131143
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:00:25.288954
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 23:00:28.772036
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 23:00:30.391365
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 23:00:32.443551
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:00:33.921121
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:00:43.153608
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 23:00:47.119759
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:48.257816
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality(Person()) == 'Russian'

# Generated at 2022-06-17 23:00:50.425919
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    result = person.surname()
    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-17 23:01:35.875285
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 23:01:39.210613
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:01:43.674234
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with default parameters
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']

    # Test with gender
    gender = Gender.MALE
    nationality = person.nationality(gender)
    assert nationality in person._data['nationality'][gender]

# Generated at 2022-06-17 23:01:45.039853
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:01:51.796509
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) == 'foretime10@example.com'

# Generated at 2022-06-17 23:02:00.767120
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) != 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) != 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) != 'foretime10@example.com'

# Generated at 2022-06-17 23:02:03.207504
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 23:02:08.941860
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with default value
    assert Person().nationality() in NATIONALITIES
    # Test with gender
    assert Person().nationality(Gender.MALE) in NATIONALITIES
    assert Person().nationality(Gender.FEMALE) in NATIONALITIES
    # Test with incorrect value
    with pytest.raises(NonEnumerableError):
        Person().nationality(Gender.OTHER)
    # Test with incorrect type
    with pytest.raises(NonEnumerableError):
        Person().nationality(1)

# Generated at 2022-06-17 23:02:10.034396
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITIES

# Generated at 2022-06-17 23:02:12.422676
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:02:59.418959
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:03:01.555824
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:03:03.033761
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:03:04.733149
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname != ''


# Generated at 2022-06-17 23:03:07.962286
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:03:08.748718
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:03:10.020203
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:03:12.713086
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert re.match(r'[\w\.-]+@[\w\.-]+', email)


# Generated at 2022-06-17 23:03:13.973647
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:03:15.120991
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:04:52.448125
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:05:02.466914
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_DECLARED), str)
   

# Generated at 2022-06-17 23:05:04.443086
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:05:13.402285
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.ANDROGYNE), str)
    assert isinstance(person.surname(gender=Gender.INTERSEX), str)
    assert isinstance(person.surname(gender=Gender.NEUTER), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)

# Unit

# Generated at 2022-06-17 23:05:15.394682
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:05:17.798503
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:05:20.091335
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:05:21.318192
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:05:22.186034
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:05:27.690900
# Unit test for method username of class Person
def test_Person_username():
    # Test for method username of class Person
    # Arrange
    person = Person()
    # Act
    result = person.username()
    # Assert
    assert isinstance(result, str)
    assert len(result) > 0