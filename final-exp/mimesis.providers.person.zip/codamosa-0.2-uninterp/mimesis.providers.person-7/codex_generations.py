

# Generated at 2022-06-17 22:55:38.377846
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDER_TITLES
    assert person.gender(symbol=True) in GENDER_SYMBOLS
    assert person.gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-17 22:55:45.448528
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    assert person.full_name()
    assert person.full_name(gender=Gender.MALE)
    assert person.full_name(gender=Gender.FEMALE)
    assert person.full_name(reverse=True)
    assert person.full_name(gender=Gender.MALE, reverse=True)
    assert person.full_name(gender=Gender.FEMALE, reverse=True)


# Generated at 2022-06-17 22:55:50.501209
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)


# Generated at 2022-06-17 22:56:00.656097
# Unit test for method email of class Person
def test_Person_email():
    # Test with default domains
    assert Person().email()
    assert Person().email().endswith(tuple(EMAIL_DOMAINS))

    # Test with custom domains
    domains = ('example.com', 'example.net', 'example.org')
    assert Person().email(domains=domains).endswith(domains)

    # Test with unique emails
    assert Person().email(unique=True)
    assert Person().email(unique=True) != Person().email(unique=True)

    # Test with seeded provider
    provider = Person(seed=1)
    assert provider.email() == provider.email()
    assert provider.email(unique=True) == provider.email(unique=True)

    # Test with seeded provider and custom domains
    provider = Person(seed=1)

# Generated at 2022-06-17 22:56:05.120971
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(100):
        email = Person().email()
        assert re.match(r'^[a-zA-Z0-9_]+@[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$', email) is not None


# Generated at 2022-06-17 22:56:08.384408
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert '@' in email
    assert len(email) > 5


# Generated at 2022-06-17 22:56:10.827757
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:16.368534
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_AVAILABLE), str)
   

# Generated at 2022-06-17 22:56:23.219836
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']

# Generated at 2022-06-17 22:56:26.707625
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:56:39.112713
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default parameters
    assert Person().surname() in SURNAMES
    # Test with gender
    assert Person().surname(Gender.MALE) in SURNAMES_MALE
    assert Person().surname(Gender.FEMALE) in SURNAMES_FEMALE
    # Test with incorrect gender
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.UNKNOWN)
    # Test with incorrect gender
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.NOT_APPLICABLE)
    # Test with incorrect gender
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.NOT_KNOWN)
    # Test with incorrect gender
    with pytest.raises(NonEnumerableError):
        Person

# Generated at 2022-06-17 22:56:40.923357
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:44.402281
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:53.852839
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 22:57:07.862234
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(gender=Gender.MALE), str)
    assert isinstance(p.surname(gender=Gender.FEMALE), str)
    assert isinstance(p.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(p.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:57:09.918652
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:57:21.451074
# Unit test for method username of class Person
def test_Person_username():
    # Test with default template
    assert Person().username()
    # Test with custom template
    assert Person().username(template='Ud')
    assert Person().username(template='U_d')
    assert Person().username(template='U-d')
    assert Person().username(template='UU-d')
    assert Person().username(template='UU.d')
    assert Person().username(template='UU_d')
    assert Person().username(template='ld')
    assert Person().username(template='l-d')
    assert Person().username(template='l.d')
    assert Person().username(template='l_d')
    # Test with incorrect template
    with pytest.raises(ValueError):
        Person().username(template='U')
    with pytest.raises(ValueError):
        Person().username(template='l')


# Generated at 2022-06-17 22:57:25.437039
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:57:26.676205
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:28.078054
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:04.568627
# Unit test for method username of class Person
def test_Person_username():
    # Arrange
    person = Person()
    # Act
    result = person.username()
    # Assert
    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-17 22:58:06.078356
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:58:07.513721
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:08.886752
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:58:11.456332
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:58:21.034607
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(gender=Gender.MALE), str)
    assert isinstance(p.surname(gender=Gender.FEMALE), str)
    assert isinstance(p.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(gender=Gender.OTHER), str)
    assert isinstance(p.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(p.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:58:30.921226
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
    assert person.nationality(gender=Gender.MALE) in person._data['nationality']['male']
    assert person.nationality(gender=Gender.FEMALE) in person._data['nationality']['female']
    assert person.nationality(gender=Gender.UNKNOWN) in person._data['nationality']['unknown']
    assert person.nationality(gender=Gender.NOT_APPLICABLE) in person._data['nationality']['not_applicable']
    assert person.nationality(gender=Gender.NOT_KNOWN) in person._data['nationality']['not_known']


# Generated at 2022-06-17 22:58:33.818449
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:58:35.494317
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:58:43.282452
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:58:50.352415
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:59:00.710808
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)


# Generated at 2022-06-17 22:59:10.232403
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:59:11.567516
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:59:21.092059
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(gender=Gender.male), str)
    assert isinstance(p.surname(gender=Gender.female), str)
    assert isinstance(p.surname(gender=Gender.not_applicable), str)
    assert isinstance(p.surname(gender=Gender.not_known), str)
    assert isinstance(p.surname(gender=Gender.other), str)
    assert isinstance(p.surname(gender=Gender.unknown), str)
    assert isinstance(p.surname(gender=Gender.unspecified), str)

# Generated at 2022-06-17 22:59:26.368338
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(gender=Gender.MALE), str)
    assert isinstance(p.surname(gender=Gender.FEMALE), str)
    assert isinstance(p.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_SPECIFIED), str)


# Generated at 2022-06-17 22:59:28.500471
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    surname = person.surname()
    # Assert
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:59:31.424776
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:59:40.965807
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)
    assert isinstance(p.surname(Gender.NOT_AVAILABLE), str)

# Generated at 2022-06-17 22:59:55.103266
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)

# Generated at 2022-06-17 23:00:09.550016
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:00:13.980844
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert isinstance(person.nationality(gender=Gender.MALE), str)
    assert isinstance(person.nationality(gender=Gender.FEMALE), str)


# Generated at 2022-06-17 23:00:14.985698
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:25.481100
# Unit test for method username of class Person
def test_Person_username():
    # Test with default template
    assert Person().username() == 'l.d'
    # Test with custom template
    assert Person().username(template='Ud') == 'Ud'
    # Test with custom template
    assert Person().username(template='U_d') == 'U_d'
    # Test with custom template
    assert Person().username(template='U-d') == 'U-d'
    # Test with custom template
    assert Person().username(template='UU-d') == 'UU-d'
    # Test with custom template
    assert Person().username(template='UU.d') == 'UU.d'
    # Test with custom template
    assert Person().username(template='UU_d') == 'UU_d'
    # Test with custom template
    assert Person().username(template='ld') == 'ld'
    # Test

# Generated at 2022-06-17 23:00:30.059206
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    surname = person.surname()
    # Assert
    assert surname in person._data['surname']


# Generated at 2022-06-17 23:00:32.202378
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:00:33.713883
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:00:35.486699
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:00:38.160900
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:45.770761
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'

# Generated at 2022-06-17 23:01:22.539168
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default gender
    assert Person().surname() in SURNAMES
    # Test with gender
    assert Person().surname(Gender.MALE) in SURNAMES_MALE
    assert Person().surname(Gender.FEMALE) in SURNAMES_FEMALE
    # Test with incorrect gender
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.UNKNOWN)
    # Test with incorrect type
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.UNKNOWN.value)
    # Test with incorrect type
    with pytest.raises(NonEnumerableError):
        Person().surname(Gender.UNKNOWN.name)
    # Test with incorrect type
    with pytest.raises(NonEnumerableError):
        Person

# Generated at 2022-06-17 23:01:34.196445
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    assert p.username()
    assert p.username(template='U_d')
    assert p.username(template='U.d')
    assert p.username(template='U-d')
    assert p.username(template='UU-d')
    assert p.username(template='UU.d')
    assert p.username(template='UU_d')
    assert p.username(template='ld')
    assert p.username(template='l-d')
    assert p.username(template='Ud')
    assert p.username(template='l.d')
    assert p.username(template='l_d')
    assert p.username(template='default')
    assert p.username(template='U')
    assert p.username(template='l')
    assert p.username(template='d')

# Generated at 2022-06-17 23:01:39.713764
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.PREFER_NOT_TO_SAY), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 23:01:41.909867
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:01:49.909873
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(gender=Gender.MALE), str)
    assert isinstance(p.surname(gender=Gender.FEMALE), str)
    assert isinstance(p.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(gender=Gender.OTHER), str)
    assert isinstance(p.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(p.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 23:01:52.741360
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:01:54.111771
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:01:57.341998
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:01:59.175636
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 23:02:00.386906
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 23:02:36.940011
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 23:02:37.893715
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 23:02:39.858350
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:02:41.040003
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:02:43.138657
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:02:44.657862
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:02:46.274175
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:02:47.796598
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:02:49.083551
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 23:02:59.055626
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)

# Generated at 2022-06-17 23:03:54.630033
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:03:56.029953
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:03:57.958059
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:04:03.119893
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert email.count('@') == 1
    assert email.count('.') == 1
    assert len(email) > 5
    assert len(email) < 50
    assert email.startswith('@') is False
    assert email.endswith('@') is False
    assert email.startswith('.') is False
    assert email.endswith('.') is False
    assert email.startswith('_') is False
    assert email.endswith('_') is False
    assert email.startswith('-') is False
    assert email.endswith('-') is False
    assert email.startswith('+') is False
    assert email.endswith('+') is False
    assert email.start

# Generated at 2022-06-17 23:04:04.348188
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:04:05.154415
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES


# Generated at 2022-06-17 23:04:14.749083
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.ANDROGYNOUS) in person._data['surname']['androgynous']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person

# Generated at 2022-06-17 23:04:22.400319
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person."""
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.OTHER) in person._data['surname']['other']

# Generated at 2022-06-17 23:04:23.414249
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 23:04:30.306771
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.PREFER_NOT_TO_SAY), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)