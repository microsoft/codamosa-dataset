

# Generated at 2022-06-17 22:55:47.064060
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert len(email) > 0
    assert '@' in email
    assert '.' in email

# Generated at 2022-06-17 22:55:48.553680
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:55:51.156983
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:55:54.532981
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:55:57.260827
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:56:00.616794
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:56:03.362120
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:15.230443
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:56:16.757940
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:18.784076
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:56:29.538262
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:56:31.283076
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:56:32.616425
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    assert result in person._data['nationality']


# Generated at 2022-06-17 22:56:37.807425
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
   

# Generated at 2022-06-17 22:56:39.498554
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:45.995362
# Unit test for method username of class Person
def test_Person_username():
    # Test with default template
    assert Person().username() == 'm.1867'
    # Test with custom template
    assert Person().username(template='Ud') == 'D1867'
    # Test with custom template
    assert Person().username(template='U-d') == 'D-1867'
    # Test with custom template
    assert Person().username(template='U_d') == 'D_1867'
    # Test with custom template
    assert Person().username(template='UU-d') == 'DD-1867'
    # Test with custom template
    assert Person().username(template='UU.d') == 'DD.1867'
    # Test with custom template
    assert Person().username(template='UU_d') == 'DD_1867'
    # Test with custom template

# Generated at 2022-06-17 22:56:56.519293
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p.email() == 'johannwolfgang@gmail.com'
    assert p

# Generated at 2022-06-17 22:57:05.238051
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with default value
    assert Person().nationality() in NATIONALITIES
    # Test with gender
    assert Person().nationality(Gender.MALE) in NATIONALITIES
    assert Person().nationality(Gender.FEMALE) in NATIONALITIES
    # Test with incorrect value
    with pytest.raises(NonEnumerableError):
        Person().nationality(Gender.UNKNOWN)

# Generated at 2022-06-17 22:57:06.857028
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:57:18.862266
# Unit test for method username of class Person
def test_Person_username():
    """Test method username of class Person."""
    from faker import Faker
    from faker.providers.person.en_US import Provider as PersonProvider

    faker = Faker()
    faker.add_provider(PersonProvider)

    for _ in range(100):
        username = faker.username()
        assert isinstance(username, str)
        assert len(username) >= 4
        assert len(username) <= 15
        assert re.fullmatch(r'[a-zA-Z0-9\._-]+', username)

    for _ in range(100):
        username = faker.username(template='U_d')
        assert isinstance(username, str)
        assert len(username) >= 4
        assert len(username) <= 15

# Generated at 2022-06-17 22:57:37.144877
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:57:40.738764
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:42.639800
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:44.489523
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:45.375269
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:58:04.569713
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)


# Generated at 2022-06-17 22:58:06.499753
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']

# Generated at 2022-06-17 22:58:07.957918
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:58:09.289509
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:19.791879
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email()

# Generated at 2022-06-17 22:59:04.198269
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:59:05.261513
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:59:06.166199
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 22:59:07.211348
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:59:16.103189
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:59:19.969894
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)


# Generated at 2022-06-17 22:59:21.626715
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:59:27.067755
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:38.056489
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(gender=Gender.MALE), str)
    assert isinstance(p.surname(gender=Gender.FEMALE), str)
    assert isinstance(p.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(gender=Gender.OTHER), str)
    assert isinstance(p.surname(gender=Gender.NOT_SPECIFIED), str)


# Generated at 2022-06-17 22:59:44.036581
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname() == 'Смирнов'
    assert person.surname(gender=Gender.MALE) == 'Смирнов'
    assert person.surname(gender=Gender.FEMALE) == 'Иванова'
    assert person.surname(gender=Gender.UNKNOWN) == 'Смирнов'
    assert person.surname(gender=Gender.NOT_APPLICABLE) == 'Смирнов'
    assert person.surname(gender=Gender.NOT_KNOWN) == 'Смирнов'
