

# Generated at 2022-06-17 22:55:41.159449
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:55:42.141586
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:55:45.709664
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:55:46.438941
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:55:57.504385
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.NOT_KNOWN) in person._data['surname']['not_known']


# Generated at 2022-06-17 22:55:59.240113
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:56:02.923143
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDER_TITLES
    assert person.gender(symbol=True) in GENDER_SYMBOLS
    assert person.gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-17 22:56:05.021333
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:56:06.701673
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:10.159482
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:56:26.453513
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:56:28.122204
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:56:30.025415
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for method surname of class Person
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:56:31.422144
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:32.706148
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:56:33.906498
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:56:43.857634
# Unit test for method username of class Person
def test_Person_username():
    # Test with default template
    assert Person().username()
    # Test with custom template
    assert Person().username(template='U_d')
    # Test with custom template
    assert Person().username(template='U.d')
    # Test with custom template
    assert Person().username(template='U-d')
    # Test with custom template
    assert Person().username(template='UU-d')
    # Test with custom template
    assert Person().username(template='UU.d')
    # Test with custom template
    assert Person().username(template='UU_d')
    # Test with custom template
    assert Person().username(template='ld')
    # Test with custom template
    assert Person().username(template='l-d')
    # Test with custom template
    assert Person().username(template='Ud')
    # Test with custom template
   

# Generated at 2022-06-17 22:56:45.897015
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 22:56:56.443704
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)

# Generated at 2022-06-17 22:56:59.817383
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:07.062641
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:09.332525
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:57:13.412613
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:57:15.512672
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:57:17.573153
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:21.546135
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:24.722550
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:26.612831
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:28.000176
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:31.354345
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:44.619089
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:57:45.828158
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:47.467118
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:58:04.568641
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    fake = Faker()
    assert fake.surname()


# Generated at 2022-06-17 22:58:06.827979
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITIES


# Generated at 2022-06-17 22:58:08.283110
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:09.957913
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:58:12.211465
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for method surname of class Person
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:21.569433
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default value of gender
    surname = Person().surname()
    assert isinstance(surname, str)
    assert len(surname) > 0
    # Test with gender = Gender.MALE
    surname = Person().surname(gender=Gender.MALE)
    assert isinstance(surname, str)
    assert len(surname) > 0
    # Test with gender = Gender.FEMALE
    surname = Person().surname(gender=Gender.FEMALE)
    assert isinstance(surname, str)
    assert len(surname) > 0
    # Test with incorrect value of gender
    with pytest.raises(NonEnumerableError):
        Person().surname(gender='male')

# Generated at 2022-06-17 22:58:33.169136
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.NOT_KNOWN) in person._data['surname']['not_known']