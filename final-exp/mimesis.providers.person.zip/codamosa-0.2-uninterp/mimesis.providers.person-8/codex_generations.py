

# Generated at 2022-06-17 22:55:46.157906
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:55:57.580139
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 22:55:59.681705
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(random=Random())
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:56:01.768423
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:56:09.872105
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    assert p.gender() in ('Male', 'Female')
    assert p.gender(iso5218=True) in (0, 1, 2, 9)
    assert p.gender(symbol=True) in ('♂', '♀')
    assert p.sex() in ('Male', 'Female')
    assert p.sex(iso5218=True) in (0, 1, 2, 9)
    assert p.sex(symbol=True) in ('♂', '♀')


# Generated at 2022-06-17 22:56:16.293875
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)


# Generated at 2022-06-17 22:56:19.050563
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:21.899795
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:56:23.178885
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES

# Generated at 2022-06-17 22:56:32.591405
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in GENDER_TITLES
    assert Person().gender(iso5218=True) in [0, 1, 2, 9]
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(symbol=True) in GENDER

# Generated at 2022-06-17 22:56:50.899105
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname() == 'Иванов'
    assert person.surname(gender=Gender.MALE) == 'Иванов'
    assert person.surname(gender=Gender.FEMALE) == 'Иванова'
    assert person.surname(gender=Gender.UNKNOWN) == 'Иванов'


# Generated at 2022-06-17 22:56:52.715224
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:55.396960
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    gender = person.gender()
    assert gender in person._data['gender']


# Generated at 2022-06-17 22:57:01.423880
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in GENDER_TITLES
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-17 22:57:04.414924
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:06.053395
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:09.339491
# Unit test for method username of class Person
def test_Person_username():
    # Arrange
    person = Person()

    # Act
    username = person.username()

    # Assert
    assert username is not None
    assert isinstance(username, str)
    assert len(username) > 0

# Generated at 2022-06-17 22:57:10.598417
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:57:15.520326
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.NOT_DECLARED), str)

# Generated at 2022-06-17 22:57:17.641875
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:57:32.823720
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:34.965042
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:57:36.897497
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:38.757815
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:57:41.390780
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:45.916326
# Unit test for method email of class Person
def test_Person_email():
    # Arrange
    person = Person()
    # Act
    result = person.email()
    # Assert
    assert result is not None
    assert isinstance(result, str)
    assert len(result) > 0
    assert '@' in result


# Generated at 2022-06-17 22:57:47.865219
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    fake = Faker()
    assert fake.nationality() in fake._data['nationality']

# Generated at 2022-06-17 22:58:04.568991
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(Gender.MALE), str)
    assert isinstance(p.surname(Gender.FEMALE), str)
    assert isinstance(p.surname(Gender.UNKNOWN), str)
    assert isinstance(p.surname(Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(Gender.NOT_KNOWN), str)
    assert isinstance(p.surname(Gender.OTHER), str)
    assert isinstance(p.surname(Gender.PREFERS_NOT_TO_SAY), str)
    assert isinstance(p.surname(Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 22:58:07.175868
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:13.626715
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.NOT_KNOWN) in person._data['surname']['not_known']


# Generated at 2022-06-17 22:58:26.773786
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:28.492337
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:58:31.017403
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:58:33.184007
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']

# Generated at 2022-06-17 22:58:34.863274
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:36.506523
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:40.500966
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']
    assert p.surname(Gender.MALE) in p._data['surname']['male']
    assert p.surname(Gender.FEMALE) in p._data['surname']['female']


# Generated at 2022-06-17 22:58:47.902015
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES
    assert Person().surname(gender=Gender.MALE) in SURNAMES_MALE
    assert Person().surname(gender=Gender.FEMALE) in SURNAMES_FEMALE
    assert Person().surname(gender=Gender.UNKNOWN) in SURNAMES
    assert Person().surname(gender=Gender.NOT_APPLICABLE) in SURNAMES
    assert Person().surname(gender=Gender.OTHER) in SURNAMES
    assert Person().surname(gender=Gender.NOT_KNOWN) in SURNAMES

# Generated at 2022-06-17 22:58:50.106878
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 22:58:55.015203
# Unit test for method email of class Person
def test_Person_email():
    # Arrange
    person = Person()
    # Act
    result = person.email()
    # Assert
    assert result is not None
    assert isinstance(result, str)
    assert result.count('@') == 1
    assert result.count('.') == 1
    assert result.split('@')[1] in EMAIL_DOMAINS