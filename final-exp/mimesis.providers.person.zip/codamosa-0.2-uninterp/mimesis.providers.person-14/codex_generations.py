

# Generated at 2022-06-17 22:55:38.959190
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:55:40.577712
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:55:47.165720
# Unit test for method gender of class Person
def test_Person_gender():
    # Test with default parameters
    assert Person().gender() in GENDER_TITLES

    # Test with symbol=True
    assert Person().gender(symbol=True) in GENDER_SYMBOLS

    # Test with iso5218=True
    assert Person().gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-17 22:55:49.972905
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:55:57.616373
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)


# Generated at 2022-06-17 22:56:00.042800
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:56:01.768520
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:56:03.738920
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:05.807712
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:08.226458
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:17.779694
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']

# Generated at 2022-06-17 22:56:19.251993
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:25.141199
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
    assert person.nationality(Gender.MALE) in person._data['nationality'][Gender.MALE]
    assert person.nationality(Gender.FEMALE) in person._data['nationality'][Gender.FEMALE]
    assert person.nationality(Gender.UNKNOWN) in person._data['nationality'][Gender.UNKNOWN]
    assert person.nationality(Gender.NOT_APPLICABLE) in person._data['nationality'][Gender.NOT_APPLICABLE]
    assert person.nationality(Gender.NOT_KNOWN) in person._data['nationality'][Gender.NOT_KNOWN]
    assert person.nationality(Gender.NOT_SPECIFIED) in person._data['nationality'][Gender.NOT_SPECIFIED]
   

# Generated at 2022-06-17 22:56:27.026411
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 22:56:28.662063
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    assert provider.surname() in provider._data['surname']


# Generated at 2022-06-17 22:56:30.219729
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:31.617833
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:32.646490
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:39.111371
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']
    assert p.surname(gender=Gender.MALE) in p._data['surname']['male']
    assert p.surname(gender=Gender.FEMALE) in p._data['surname']['female']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender='male') in p._data['surname']['male']
    assert p.surname(gender='female') in p._data['surname']['female']
    assert p.surname(gender='unknown') in p._data['surname']['unknown']

# Generated at 2022-06-17 22:56:51.416969
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert type(email) == str
    assert email.count('@') == 1
    assert email.count('.') == 1
    assert email.count(' ') == 0
    assert email.count('\n') == 0
    assert email.count('\t') == 0
    assert email.count('\r') == 0
    assert email.count('\v') == 0
    assert email.count('\f') == 0
    assert email.count('\b') == 0
    assert email.count('\a') == 0
    assert email.count('\0') == 0
    assert email.count('\x0b') == 0
    assert email.count('\x0c') == 0
    assert email.count('\x1c') == 0
    assert email.count

# Generated at 2022-06-17 22:57:04.887570
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:57:06.123443
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 22:57:07.401113
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 22:57:19.056662
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.NOT_KNOWN) in person._data['surname']['not_known']


# Generated at 2022-06-17 22:57:21.048911
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:57:29.816242
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)
    assert isinstance(p.surname(gender=Gender.MALE), str)
    assert isinstance(p.surname(gender=Gender.FEMALE), str)
    assert isinstance(p.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(p.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(p.surname(gender=Gender.OTHER), str)
    assert isinstance(p.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:57:31.510861
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES

# Generated at 2022-06-17 22:57:33.502389
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'

# Generated at 2022-06-17 22:57:35.118533
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() != ''


# Generated at 2022-06-17 22:57:37.981361
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 22:58:25.919755
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:58:36.590072
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with default parameters
    assert Person().nationality() in NATIONALITIES
    # Test with gender
    assert Person().nationality(Gender.MALE) in NATIONALITIES
    assert Person().nationality(Gender.FEMALE) in NATIONALITIES
    # Test with invalid gender
    with pytest.raises(NonEnumerableError):
        Person().nationality(Gender.NON_BINARY)
    # Test with invalid type of gender
    with pytest.raises(NonEnumerableError):
        Person().nationality(Gender.MALE.value)
    # Test with invalid type of gender
    with pytest.raises(NonEnumerableError):
        Person().nationality(Gender.MALE.name)
    # Test with invalid type of gender
    with pytest.raises(NonEnumerableError):
        Person().nationality

# Generated at 2022-06-17 22:58:38.581279
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 22:58:44.779464
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)


# Generated at 2022-06-17 22:58:55.386393
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(seed=1)
    assert p.surname() == 'Иванов'
    assert p.surname(gender=Gender.MALE) == 'Иванов'
    assert p.surname(gender=Gender.FEMALE) == 'Иванова'
    assert p.surname(gender=Gender.UNKNOWN) == 'Иванов'
    assert p.surname(gender=Gender.NOT_APPLICABLE) == 'Иванов'
    assert p.surname(gender=Gender.NOT_KNOWN) == 'Иванов'
    assert p.surname(gender=Gender.NOT_SPECIFIED) == 'Иванов'
    assert p.surn

# Generated at 2022-06-17 22:58:57.455859
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 22:59:01.080699
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:59:05.253310
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:59:06.896767
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:59:10.402770
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:00:15.253075
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)

# Generated at 2022-06-17 23:00:22.696751
# Unit test for method surname of class Person
def test_Person_surname():
    # Test with default value
    assert Person().surname() in SURNAMES
    # Test with value
    assert Person().surname(Gender.MALE) in SURNAMES_MALE
    assert Person().surname(Gender.FEMALE) in SURNAMES_FEMALE
    # Test with incorrect value
    with pytest.raises(NonEnumerableError):
        Person().surname('male')


# Generated at 2022-06-17 23:00:23.696536
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:24.663703
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:00:27.569801
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 23:00:29.724049
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']

# Generated at 2022-06-17 23:00:31.862240
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:33.463029
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:00:34.926959
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:36.953025
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)

# Generated at 2022-06-17 23:01:06.416582
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:01:08.506573
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 23:01:09.978532
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:01:11.507996
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:01:14.484155
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-17 23:01:15.985459
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:01:18.064130
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:01:19.355041
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=1)
    assert person.nationality() == 'Russian'


# Generated at 2022-06-17 23:01:20.286244
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:01:21.615751
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)


# Generated at 2022-06-17 23:02:28.751346
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)

# Generated at 2022-06-17 23:02:30.803534
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:02:31.913995
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES


# Generated at 2022-06-17 23:02:33.213471
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:02:35.739126
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:02:42.411395
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.NOT_APPLICABLE) in person._data['surname']['not_applicable']
    assert person.surname(gender=Gender.NOT_KNOWN) in person._data['surname']['not_known']


# Generated at 2022-06-17 23:02:50.757886
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime11@live.com'
    assert person.email(unique=True) == 'foretime12@live.com'
    assert person.email(unique=True) == 'foretime13@live.com'
    assert person.email(unique=True) == 'foretime14@live.com'
    assert person.email(unique=True) == 'foretime15@live.com'
    assert person.email(unique=True) == 'foretime16@live.com'
    assert person.email(unique=True) == 'foretime17@live.com'

# Generated at 2022-06-17 23:02:53.226214
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 23:02:54.698862
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert email == 'foretime10@live.com'

# Generated at 2022-06-17 23:03:04.285067
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 23:04:06.488437
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)

# Generated at 2022-06-17 23:04:14.749081
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 23:04:16.254470
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:04:17.598379
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:04:23.058584
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=42)
    assert person.surname() == 'Кузнецов'
    assert person.surname(gender=Gender.MALE) == 'Кузнецов'
    assert person.surname(gender=Gender.FEMALE) == 'Кузнецова'
    assert person.surname(gender=Gender.UNKNOWN) == 'Кузнецов'

# Generated at 2022-06-17 23:04:30.169424
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    assert person.username() == 'j.1870'
    assert person.username(template='U_d') == 'J_1870'
    assert person.username(template='Ud') == 'J1870'
    assert person.username(template='ld') == 'j1870'
    assert person.username(template='l-d') == 'j-1870'
    assert person.username(template='l.d') == 'j.1870'
    assert person.username(template='l_d') == 'j_1870'
    assert person.username(template='UU-d') == 'JJ-1870'
    assert person.username(template='UU.d') == 'JJ.1870'
    assert person.username(template='UU_d') == 'JJ_1870'

# Generated at 2022-06-17 23:04:31.096474
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:04:32.907292
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert email.count('@') == 1
    assert email.count('.') == 1
    assert email.split('@')[1] in EMAIL_DOMAINS


# Generated at 2022-06-17 23:04:36.883760
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 23:04:37.907588
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']