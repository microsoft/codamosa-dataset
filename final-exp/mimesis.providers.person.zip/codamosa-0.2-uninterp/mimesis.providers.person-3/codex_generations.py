

# Generated at 2022-06-17 22:55:38.084049
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:55:45.377876
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email()

# Generated at 2022-06-17 22:55:46.864290
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES


# Generated at 2022-06-17 22:55:50.453805
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)
    assert nationality in person._data['nationality']

# Generated at 2022-06-17 22:55:58.688274
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)


# Generated at 2022-06-17 22:56:00.209612
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:01.893980
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:05.932283
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert '@' in email
    assert '.' in email
    assert len(email.split('@')) == 2
    assert len(email.split('@')[1].split('.')) == 2


# Generated at 2022-06-17 22:56:08.330956
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:11.308252
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:18.606102
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:56:21.516699
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']

# Generated at 2022-06-17 22:56:23.140505
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:56:25.885198
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 22:56:27.659564
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 22:56:28.472807
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:56:30.025607
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:56:31.422176
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:56:38.157921
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNDEFINED), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.NOT_DISCLOSED), str)
   

# Generated at 2022-06-17 22:56:39.497235
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAME


# Generated at 2022-06-17 22:56:47.407710
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'foretime10@live.com'


# Generated at 2022-06-17 22:56:51.454461
# Unit test for method username of class Person
def test_Person_username():
    # Test for method username of class Person
    # Arrange
    person = Person()
    # Act
    result = person.username()
    # Assert
    assert result is not None
    assert isinstance(result, str)


# Generated at 2022-06-17 22:57:00.096194
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email() == 'foretime10@live.com'
    assert person.email()

# Generated at 2022-06-17 22:57:03.585123
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:57:04.852044
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:06.137270
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:08.193402
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:18.579503
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)


# Generated at 2022-06-17 22:57:20.834530
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    full_name = person.full_name()
    assert isinstance(full_name, str)
    assert len(full_name) > 0

# Generated at 2022-06-17 22:57:22.242428
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 22:57:31.907311
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:57:33.502458
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:57:35.528034
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:37.484867
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:39.936297
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:57:40.761574
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:57:42.714357
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:58:04.568901
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']
    assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']['female']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']
    assert person.surname(gender=Gender.UNKNOWN) in person._data['surname']['unknown']


# Generated at 2022-06-17 22:58:05.388536
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES

# Generated at 2022-06-17 22:58:07.513897
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-17 22:58:22.333504
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']
    assert p.surname(gender=Gender.MALE) in p._data['surname']['male']
    assert p.surname(gender=Gender.FEMALE) in p._data['surname']['female']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']
    assert p.surname(gender=Gender.UNKNOWN) in p._data['surname']['unknown']


# Generated at 2022-06-17 22:58:24.992347
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    assert provider.surname() in provider._data['surname']


# Generated at 2022-06-17 22:58:26.015830
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:58:36.669349
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.PREFER_NOT_TO_SAY), str)

# Generated at 2022-06-17 22:58:38.681071
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 22:58:40.762561
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:43.050967
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:58:45.290910
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:58:46.736487
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 22:58:51.691168
# Unit test for method username of class Person
def test_Person_username():
    # Test for method username of class Person
    # Arrange
    person = Person()
    # Act
    username = person.username()
    # Assert
    assert isinstance(username, str)
    assert len(username) > 0
    assert username[0].isalpha()
    assert username[-1].isdigit()

# Generated at 2022-06-17 22:59:04.218444
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']


# Generated at 2022-06-17 22:59:05.874403
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:07.780920
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-17 22:59:11.096191
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-17 22:59:15.194009
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']

# Generated at 2022-06-17 22:59:16.478015
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:59:17.763008
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:59:19.969249
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 22:59:21.215834
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 22:59:28.542160
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'
    assert p.email(unique=True) == 'johndoe@gmail.com'

# Generated at 2022-06-17 22:59:59.213855
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:00:05.358278
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert isinstance(person.nationality(gender=Gender.MALE), str)
    assert isinstance(person.nationality(gender=Gender.FEMALE), str)
    assert isinstance(person.nationality(gender=Gender.UNKNOWN), str)
    assert isinstance(person.nationality(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.nationality(gender=Gender.NOT_KNOWN), str)
    assert isinstance(person.nationality(gender=Gender.NOT_SPECIFIED), str)


# Generated at 2022-06-17 23:00:14.162346
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)
    assert isinstance(person.surname(gender=Gender.NOT_APPLICABLE), str)
    assert isinstance(person.surname(gender=Gender.OTHER), str)
    assert isinstance(person.surname(gender=Gender.NOT_SPECIFIED), str)

# Generated at 2022-06-17 23:00:15.121339
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:00:18.305855
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-17 23:00:19.965276
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:00:21.948940
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-17 23:00:24.131389
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for method surname of class Person
    # Create an instance of class Person
    person = Person()
    # Check that the method surname return a string
    assert isinstance(person.surname(), str)

# Generated at 2022-06-17 23:00:25.603369
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:00:36.524641
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'
    assert person.email(unique=True) != 'foretime10@live.com'
    assert person.email(unique=True, domains=('example.com',)) == 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) != 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) != 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',)) != 'foretime10@example.com'
    assert person.email(unique=True, domains=('example.com',))

# Generated at 2022-06-17 23:01:17.808691
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:01:25.487722
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()
    assert person.email(unique=True)
    assert person.email(unique=True, domains=('example.com',))
    assert person.email(domains=('example.com',))
    assert person.email(domains=('@example.com',))
    assert person.email(domains=('example.com', 'example.org'))
    assert person.email(domains=('@example.com', '@example.org'))
    assert person.email(domains=('example.com', '@example.org'))
    assert person.email(domains=('@example.com', 'example.org'))


# Generated at 2022-06-17 23:01:27.642616
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAME


# Generated at 2022-06-17 23:01:37.157710
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    assert person.username()
    assert person.username(template='U_d')
    assert person.username(template='U.d')
    assert person.username(template='U-d')
    assert person.username(template='UU-d')
    assert person.username(template='UU.d')
    assert person.username(template='UU_d')
    assert person.username(template='ld')
    assert person.username(template='l-d')
    assert person.username(template='Ud')
    assert person.username(template='l.d')
    assert person.username(template='l_d')
    assert person.username(template='default')
    assert person.username(template='U')
    assert person.username(template='l')
    assert person.username(template='d')

# Generated at 2022-06-17 23:01:39.822947
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert len(surname) > 0

# Generated at 2022-06-17 23:01:41.624938
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-17 23:01:43.493473
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-17 23:01:44.914924
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']

# Generated at 2022-06-17 23:01:47.662809
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person()
    # Act
    surname = person.surname()
    # Assert
    assert surname in person._data['surname']


# Generated at 2022-06-17 23:01:48.998319
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in SURNAMES


# Generated at 2022-06-17 23:03:10.410161
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert len(surname) > 0

# Generated at 2022-06-17 23:03:12.336619
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-17 23:03:18.125623
# Unit test for method username of class Person
def test_Person_username():
    from fake_ocean.providers import Person
    from fake_ocean.constants import Gender
    from fake_ocean.constants import TitleType
    from fake_ocean.constants import SocialNetwork
    from fake_ocean.constants import USERNAMES
    from fake_ocean.constants import EMAIL_DOMAINS
    from fake_ocean.constants import SOCIAL_NETWORKS
    from fake_ocean.constants import BLOOD_GROUPS
    from fake_ocean.constants import SEXUALITY_SYMBOLS
    from fake_ocean.constants import GENDER_SYMBOLS
    from fake_ocean.constants import CALLING_CODES
    from fake_ocean.constants import Gender
    from fake_ocean.constants import TitleType

# Generated at 2022-06-17 23:03:19.232810
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surname']

# Generated at 2022-06-17 23:03:29.007442
# Unit test for method email of class Person
def test_Person_email():
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.internet.en_US import Provider as InternetProvider
    from faker.providers.internet.en_US import EMAIL_DOMAINS
    from faker.providers.internet.en_US import USERNAMES
    from faker.providers.internet.en_US import TLD_NAMES
    from faker.providers.internet.en_US import FREE_EMAIL_DOMAINS
    from faker.providers.internet.en_US import SAFE_EMAIL_TLD
    from faker.providers.internet.en_US import USER_AGENTS
    from faker.providers.internet.en_US import FIREFOX_USER_AGENTS

# Generated at 2022-06-17 23:03:31.520808
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:03:32.938295
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-17 23:03:37.448244
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert isinstance(person.surname(gender=Gender.UNKNOWN), str)


# Generated at 2022-06-17 23:03:39.118024
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-17 23:03:40.465063
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']