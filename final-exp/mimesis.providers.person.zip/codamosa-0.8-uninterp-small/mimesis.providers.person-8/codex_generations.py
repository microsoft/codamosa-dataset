

# Generated at 2022-06-25 21:06:24.163396
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    nationality_1 = person_0.nationality(gender="Male")
    nationality_2 = person_0.nationality(gender="Female")


# Generated at 2022-06-25 21:06:32.498124
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    int_0 = person_0.age()
    gender_0 = person_0.gender()
    nationality_0 = person_0.nationality(gender=gender_0)
    assert_type_0 = isinstance(nationality_0, type(str))
    assert assert_type_0


# Generated at 2022-06-25 21:06:36.584791
# Unit test for method surname of class Person
def test_Person_surname():
    print('Testing Person class, surname method')
    person_0 = Person()
    person_0.gender(iso5218=True)
    list_0 = []
    str_0 = person_0.surname()
    list_0.append(str_0)
    print(list_0)

# Generated at 2022-06-25 21:06:40.524788
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality(Gender.MALE)
    str_1 = person_0.nationality(Gender.MALE)
    str_2 = person_0.nationality(Gender.MALE)


# Generated at 2022-06-25 21:06:52.372153
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Method test_Person_surname of Person is tested
    """
    string_1 = ''
    string_2 = ''
    enum_0 = Gender.UNKNOWN
    enum_1 = Gender.FEMALE
    enum_2 = Gender.MALE
    person_0 = Person()
    string_0 = person_0.surname()
    int_0 = len(string_0)
    print("len(string_0)")
    print(len(string_0))
    print("person_0")
    print(person_0)
    print("string_0")
    print(string_0)
    string_1 = person_0.surname(enum_2)
    int_1 = len(string_1)
    print("len(string_1)")

# Generated at 2022-06-25 21:06:56.784523
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    str_1 = person_0.surname(gender=Gender.MALE)
    str_2 = person_0.surname(gender=Gender.FEMALE)


# Generated at 2022-06-25 21:06:59.276738
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:07:10.360383
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationalities = person._data['nationality']

    # Test multiple arguments
    for gender in (Gender.FEMALE, Gender.MALE):
        for _ in range(100):
            assert person.nationality(gender=gender) in nationalities

    # Test an empty argument
    for _ in range(100):
        assert person.nationality() in nationalities

    # Test a wrong argument
    try:
        person.nationality(gender='female')
    except NonEnumerableError:
        pass

    # Test an instance argument
    for _ in range(100):
        assert person.nationality(gender=Gender.FEMALE) in nationalities
        assert person.nationality(gender=Gender.MALE) in nationalities

    # Test several arguments

# Generated at 2022-06-25 21:07:19.320686
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_2 = person_0.nationality()
    assert str_2 == "Portuguese" or str_2 == "American" or str_2 == "Chilean" or str_2 == "Ethiopian" or str_2 == "New Zealander" or str_2 == "Australian" or str_2 == "Norwegian" or str_2 == "Guatemalan" or str_2 == "Seychellois" or str_2 == "French" or str_2 == "Ivorian" or str_2 == "Romanian" or str_2 == "Swedish" or str_2 == "Colombian" or str_2 == "French" or str_2 == "Somalian" or str_2 == "Dutch" or str_2 == "Albanian" or str_2 == "British"

# Generated at 2022-06-25 21:07:21.757480
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname(Gender.FEMALE)
    assert type(str_0) is str


# Generated at 2022-06-25 21:07:30.625771
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(Gender.Male), str)


# Generated at 2022-06-25 21:07:35.445836
# Unit test for method nationality of class Person
def test_Person_nationality():
    # create object of class Person
    person = Person()

    # check if the returned nationality is of type string
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-25 21:07:38.683802
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert(Person().nationality() in _data['nationality'])
    assert(Person().nationality(gender='male') in _data['nationality'])
    assert(Person().nationality(gender='female') in _data['nationality'])


# Generated at 2022-06-25 21:07:43.169763
# Unit test for method surname of class Person
def test_Person_surname():
    # Run test 10 times
    for i in range(10):
        person_0 = Person()

        person_surname = person_0.surname()
        person_surname = person_surname.title()

        person_surname_in_surnames = person_surname in SURNAME_SAMPLES
        assert person_surname_in_surnames == True, 'Invalid value!'


# Generated at 2022-06-25 21:07:47.703355
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    try:
        nationality = person_0.nationality()
        assert isinstance(nationality, str), 'nationality is not a string'
    except AttributeError as e:
        print(e)
        assert False, "person_0.nationality() should not raise exception"
    print(f'Test Case 0 Passed (nationality)')


# Generated at 2022-06-25 21:07:49.434122
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    print(surname)


# Generated at 2022-06-25 21:08:00.344334
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0_nationality = person_0.nationality()
    person_1 = Person()
    person_1_nationality = person_1.nationality()
    person_2 = Person()
    person_2_nationality = person_2.nationality()
    person_3 = Person()
    person_3_nationality = person_3.nationality()
    person_4 = Person()
    person_4_nationality = person_4.nationality()
    person_5 = Person()
    person_5_nationality = person_5.nationality()
    person_6 = Person()
    person_6_nationality = person_6.nationality()
    person_7 = Person()
    person_7_nationality = person_7.nationality()
    person_8 = Person()

# Generated at 2022-06-25 21:08:02.452268
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-25 21:08:06.005743
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    print(person.surname())
    assert person.surname() == 'Иванов'
    assert person.surname(Gender.FEMALE) == 'Иванова'


# Generated at 2022-06-25 21:08:12.151611
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test Case #1: Nationality for gender None
    person_1 = Person(gender=None)
    nationality_1 = person_1.nationality()
    assert nationality_1 in (
        'American', 'German', 'Russian', 'French', 'British', 'Chinese'
    )

    # Test Case #2: Nationality for Male
    person_2 = Person(gender=Gender.male)
    nationality_2 = person_2.nationality(Gender.male)
    assert nationality_2 in (
        'American', 'German', 'Russian', 'French', 'British', 'Chinese'
    )

    # Test Case #3: Nationality for Female
    person_3 = Person(gender=Gender.female)
    nationality_3 = person_3.nationality(Gender.female)

# Generated at 2022-06-25 21:08:31.891702
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    name_0 = None
    name_1 = person_0.surname(name_0)
    assert name_1 == "Day"
    name_2 = person_0.surname(name_1)
    assert name_2 == "Horton"
    name_3 = person_0.surname(name_2)
    assert name_3 == "Shepherd"
    name_4 = person_0.surname(name_3)
    assert name_4 == "Wolfe"
    name_5 = person_0.surname(name_4)
    assert name_5 == "Cole"
    name_6 = person_0.surname(name_5)
    assert name_6 == "Rosa"
    name_7 = person_0.surn

# Generated at 2022-06-25 21:08:33.445548
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert type(person_0.nationality()) == str


# Generated at 2022-06-25 21:08:36.394915
# Unit test for method surname of class Person
def test_Person_surname():
    # Set seed 
    np.random.seed(100)
    person_0 = Person()
    surname = person_0.surname()
    assert(surname == 'Reed')


# Generated at 2022-06-25 21:08:40.959237
# Unit test for method nationality of class Person
def test_Person_nationality():
    is_failed = False
    for _ in range(1):
        p0 = Person()
        n0 = p0.nationality()
        if n0 not in NATIONALITIES:
            is_failed = True
    print("Test for method 'nationality' of class 'Person' is failed: " + str(is_failed))


# Generated at 2022-06-25 21:08:43.310727
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    username = person.username()
    assert re.match(r'[^\W_]+_+[0-9]+', username) is not None


# Generated at 2022-06-25 21:08:47.769311
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0_nationality = person_0.nationality
    print("Testing Person.nationality() ...")
    # Test that method nationality of class Person is OK
    try:
        assert isinstance(person_0_nationality(), str)
    except:
        print("--> [ERROR] method nationality of class Person is NOT OK")
    else:
        print("--> method nationality of class Person is OK")

# Generated at 2022-06-25 21:08:49.734102
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert(p.surname() in SURNAME_LIST)


# Generated at 2022-06-25 21:08:59.146627
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

# Generated at 2022-06-25 21:09:01.432165
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    for _ in range(10):
        surname = person.surname()
        assert surname in SURNAMES


# Generated at 2022-06-25 21:09:02.753771
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    person.email()
    #pass


# Generated at 2022-06-25 21:09:18.857900
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    print("email = " + person.email())
    print("email = " + person.email())
    print("email = " + person.email())
    print("email = " + person.email())


# Generated at 2022-06-25 21:09:26.815851
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert person_1.nationality() in person_1._data['nationality']
    assert person_1.nationality(Gender.FEMALE) in person_1._data['nationality']['female']
    assert person_1.nationality(Gender.MALE) in person_1._data['nationality']['male']
    assert person_1.nationality(Gender.UNKNOWN) in person_1._data['nationality']['unknown']


# Generated at 2022-06-25 21:09:28.646808
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()
    person_0.username(template='U.d')
    

# Generated at 2022-06-25 21:09:38.399185
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person(first_names={Gender.MALE: ['Vasya'], Gender.FEMALE: ['Olya']},
                      surnames={Gender.MALE: ['Petrov'], Gender.FEMALE: ['Ivanova']},
                      nationality={Gender.MALE: ['German'], Gender.FEMALE: ['Spanish']})
    for i in range(100):
        assert person_1.nationality(Gender.MALE).lower() == 'german'
        assert person_1.nationality(Gender.FEMALE).lower() == 'spanish'
    for i in range(100):
        assert person_0.nationality(Gender.MALE).lower() != 'spanish'

# Generated at 2022-06-25 21:09:39.442556
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

# Test case with parameters

# Generated at 2022-06-25 21:09:40.574842
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert type(person_0.surname()) is str


# Generated at 2022-06-25 21:09:43.987915
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality = person_0.nationality()
    assert nationality
    assert isinstance(nationality, str)


# Generated at 2022-06-25 21:09:45.311957
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in NATIONALITY


# Generated at 2022-06-25 21:09:48.822527
# Unit test for method surname of class Person
def test_Person_surname():
    """test_Person_surname"""

    gender = Gender.FEMALE
    surname_0 = Person().surname(gender)
    assert len(surname_0) > 0


# Generated at 2022-06-25 21:09:51.324645
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()


# Generated at 2022-06-25 21:10:08.025895
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    
    assert isinstance(p.surname(Gender.MALE), str), 'Value was not a string'
    assert isinstance(p.surname(Gender.FEMALE), str), 'Value was not a string'


# Generated at 2022-06-25 21:10:11.265668
# Unit test for method nationality of class Person
def test_Person_nationality():
    print('Start test for method nationality of class Person')
    person_0 = Person()
    nationality_0 = person_0.nationality()
    assert isinstance(nationality_0, str)
    assert nationality_0 in person_0._data['nationality']
    print('Passed test for method nationality of class Person')


# Generated at 2022-06-25 21:10:14.261510
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    # Checks if the name returned is string
    assert type(person_1.surname()) == str


# Generated at 2022-06-25 21:10:16.406317
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert(isinstance(person.surname(), str))


# Generated at 2022-06-25 21:10:19.946577
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person(random=0)
    assert person_0.surname() == 'Doe'
    assert person_0.surname() == 'Иванов'


# Generated at 2022-06-25 21:10:21.460156
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    print(person.nationality())

test_Person_nationality()


# Generated at 2022-06-25 21:10:33.273456
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    #====================
    # Test method surname
    #====================
    surname_0 = person_0.surname()

# Generated at 2022-06-25 21:10:34.604417
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    print(person_0)
    print(type(person_0))


# Generated at 2022-06-25 21:10:36.612016
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    print(f"{email}")

if __name__ == "__main__":
    test_Person_email()

# Generated at 2022-06-25 21:10:48.873492
# Unit test for method surname of class Person
def test_Person_surname():
    data = []
    person_0 = Person(seed=0)
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())
    data.append(person_0.surname())


# Generated at 2022-06-25 21:11:10.373169
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for seed
    person_0 = Person(seed=1)
    assert person_0.surname() == 'Поляков'

    # Test for gender
    person_0 = Person(seed=2)
    assert person_0.surname(Gender.MALE) == 'Семенов'
    assert person_0.surname(Gender.FEMALE) == 'Михайлова'

    person_1 = Person(seed=1)
    assert person_1.surname() == 'Поляков'
    assert person_1.surname(Gender.MALE) == 'Поляков'

# Generated at 2022-06-25 21:11:15.611241
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Testing the method nationality on different values of parameters gender
    from enum import Enum
    from unittest import TestCase
    print()
    TestCase.assertIsInstance(person_0.nationality(gender=Gender.MALE), str,
                              'person_0.nationality() must return a str object')
    TestCase.assertIsInstance(person_0.nationality(gender=Gender.FEMALE), 
                              str,
                              'person_0.nationality() must return a str object')


# Generated at 2022-06-25 21:11:17.519433
# Unit test for method nationality of class Person
def test_Person_nationality():

    person = Person()
    assert isinstance(person.nationality(), str)



# Generated at 2022-06-25 21:11:21.404049
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.seed(0)
    assert person_0.surname() == 'Micheals'
    

# Generated at 2022-06-25 21:11:30.657902
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surnames = person_0.surname(Gender.MALE)
    surnames = person_0.surname(Gender.MALE)
    surnames = person_0.surname(Gender.MALE)
    surnames = person_0.surname(Gender.MALE)
    surnames = person_0.surname(Gender.MALE)
    surnames = person_0.surname(Gender.MALE)

    surnames = person_0.surname(Gender.FEMALE)
    surnames = person_0.surname(Gender.FEMALE)
    surnames = person_0.surname(Gender.FEMALE)
    surnames = person_0.surname(Gender.FEMALE)
    surnames = person_0

# Generated at 2022-06-25 21:11:32.638731
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    list = person.nationality(Gender.FEMALE)
    assert list == 'Russian', "The test has failed because the method \
        nationality the class Person returned not Russian"


# Generated at 2022-06-25 21:11:37.452790
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    e_mail_0 = p.email()

    assert '@' in e_mail_0

    # Examples
    print(p.email())
    print(p.email(unique=True))


# Generated at 2022-06-25 21:11:39.861152
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    assert nationality_0 in NATIONALITIES


# Generated at 2022-06-25 21:11:40.960600
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    res = person_1.surname()
    assert isinstance(res, str)


# Generated at 2022-06-25 21:11:42.582857
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print("TEST -> person_0.nationality() = " + person_0.nationality())


# Generated at 2022-06-25 21:12:09.019261
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    value_of_given_name_0 = person_0.surname()
    print(value_of_given_name_0)
    assert isinstance(value_of_given_name_0, str)


# Generated at 2022-06-25 21:12:11.453097
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    # Test with default parameters
    person_0.nationality()
    

# Generated at 2022-06-25 21:12:16.437267
# Unit test for method nationality of class Person
def test_Person_nationality():
    # test_Person_nationality_0
    person_0 = Person()
    nationality_0 = person_0.nationality()
    assert nationality_0 == 'Honduran', 'nationality_0 is not "Honduran"'
    # test_Person_nationality_1
    person_1 = Person()
    nationality_1 = person_1.nationality(gender=Gender.FEMALE)
    assert nationality_1 == 'French', 'nationality_1 is not "French"'
    # test_Person_nationality_2
    person_2 = Person()
    nationality_2 = person_2.nationality(gender=Gender.MALE)
    assert nationality_2 == 'French', 'nationality_2 is not "French"'
    
    

# Generated at 2022-06-25 21:12:19.529003
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert isinstance(person_0.email(), str)


# Generated at 2022-06-25 21:12:21.657310
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in PERSON_NATIONALITIES


# Generated at 2022-06-25 21:12:27.708212
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0_1 = person_0.nationality()
    person_0_2 = person_0.nationality()
    assert person_0_1 in list(NATIONALITIES)
    assert person_0_2 in list(NATIONALITIES)
    assert person_0_1 != person_0_2


# Generated at 2022-06-25 21:12:32.315615
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    print('Nationality:', nationality_0)


# Generated at 2022-06-25 21:12:34.884994
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()

    person_1 = Person(seed=42)
    surname_1 = person_1.surname()

    check_values(locals())


# Generated at 2022-06-25 21:12:45.403706
# Unit test for method nationality of class Person

# Generated at 2022-06-25 21:12:58.141391
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Create an Person object
    person_0 = Person()

    # Store the nationalities of male
    nationalities_male = person_0.nationality(gender=Gender.MALE)
    # Store the nationalities of female
    nationalities_female = person_0.nationality(gender=Gender.FEMALE)

    # Check the nationalities of male
    assert nationalities_male in GENDER_MAP[Gender.MALE]
    assert nationalities_male not in GENDER_MAP[Gender.FEMALE]

    # Check the nationalities of female
    assert nationalities_female in GENDER_MAP[Gender.FEMALE]
    assert nationalities_female not in GENDER_MAP[Gender.MALE]


# Generated at 2022-06-25 21:13:56.621369
# Unit test for method nationality of class Person
def test_Person_nationality():
    k = {}
    for _ in range(100):
        person_1 = Person(gender = Gender.MALE)
        nationality_1 = person_1.nationality()
        k[nationality_1] = k.get(nationality_1, 0) + 1
    for _ in range(100):
        person_1 = Person(gender = Gender.FEMALE)
        nationality_1 = person_1.nationality()
        k[nationality_1] = k.get(nationality_1, 0) + 1
    print(k)

if __name__ == '__main__':
    person_0 = Person()

    k = {}
    for _ in range(100):
        person_1 = Person(gender = Gender.MALE)
        nationality_1 = person_1.nationality()

# Generated at 2022-06-25 21:14:04.971802
# Unit test for method username of class Person
def test_Person_username():

    person = Person()

    assert person.username(template=None) == person.username()

    for _ in range(10000):
        person.username(template='Ud')
        person.username(template='ld')
        person.username(template='U_d')
        person.username(template='U-d')
        person.username(template='U.d')
        person.username(template='UU-d')
        person.username(template='UU.d')
        person.username(template='UU_d')
        person.username(template='l-d')
        person.username(template='l.d')
        person.username(template='l_d')

    try:
        person.username(template='UU')
        raise AssertionError()
    except ValueError:
        pass


# Generated at 2022-06-25 21:14:15.942716
# Unit test for method nationality of class Person
def test_Person_nationality():
    n = 0
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_7 = Person()
    person_8 = Person()
    person_9 = Person()

    de_nationality_list = ['Deutsche', 'Österreichischen',
                           'Deutscher', 'Deutsch', 'Österreich',
                           'Deutsche', 'Deutscher', 'Deutsche']
    rus_nationality_list = ['Russisch', 'Russischen', 'Russen',
                            'Russische', 'Russischer', 'Russisch',
                            'Russischen', 'Russen']


# Generated at 2022-06-25 21:14:21.784765
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    result_1 = person_1.surname()
    assert result_1 in ['Иванов', 'Петров', 'Сидоров', 'Козлов']


# Generated at 2022-06-25 21:14:23.208116
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert type(person_0.nationality()) == str


# Generated at 2022-06-25 21:14:28.560240
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()
    assert surname_0 in SURNAMES, \
        'Method surname() of class Person return incorrect value.'


# Generated at 2022-06-25 21:14:31.296176
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()

    assert(type(person_0.email()) == str)


# Generated at 2022-06-25 21:14:37.946771
# Unit test for method surname of class Person
def test_Person_surname():
    # variable person of type Person
    person = Person()

    # iterate until condition is true
    while True:
        try:
            # Condition where random.choice(GENDER_SYMBOLS) == '♂'
            if random.choice(GENDER_SYMBOLS) == '♂':

                assert person.surname(Gender.MALE) == 'Марченко'
                break
            else:
                # Condition where random.choice(GENDER_SYMBOLS) == '♀'
                assert person.surname(Gender.FEMALE) == 'Вишнівська'
                break
        except:
            print("Assertion failed")
            break


# Generated at 2022-06-25 21:14:41.461372
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    for _ in range(0, 1000):
        print(person_0.nationality())


# Generated at 2022-06-25 21:14:47.836498
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    for i in range(0,10):
        nation = person_0.nationality()