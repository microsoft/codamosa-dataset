

# Generated at 2022-06-25 21:06:36.452256
# Unit test for method nationality of class Person
def test_Person_nationality():
    bool_0 = True
    test_case_name = 'test_case_0'
    person_0 = Person()
    str_0 = person_0.gender(bool_0)
    str_1 = person_0.nationality(str_0)
    print(str_1)

if __name__ == '__main__':
    # Set up logging.
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(levelname)s: %(asctime)s: %(name)s: %(message)s')

    test_Person_nationality()

# Generated at 2022-06-25 21:06:40.924119
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname('male')
    assert str_0 == 'Müller'
    str_1 = person_0.surname('female')
    assert str_1 == 'Herrmann'
    str_2 = person_0.surname()


# Generated at 2022-06-25 21:06:44.105740
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    gender = Gender(); gender = Gender.MALE
    str_0 = person_0.surname(gender)


# Generated at 2022-06-25 21:06:49.634893
# Unit test for method surname of class Person
def test_Person_surname():
    array_2 = Person._data['surname']['male']
    str_3 = array_2[-1]
    person_0 = Person()
    str_1 = person_0.surname(Gender.male)
    if str_1 == str_3:
        bool_0 = True
    else:
        bool_0 = False
    assert bool_0 == True

# Generated at 2022-06-25 21:06:54.545148
# Unit test for method surname of class Person
def test_Person_surname():
    from random import Random
    from enum import Enum, auto
    person = Person(seed=Random(None))
    gender = Enum('Gender', 'MALE FEMALE')
    assert isinstance(person.surname(gender.MALE), str)

# Generated at 2022-06-25 21:06:59.320573
# Unit test for method nationality of class Person
def test_Person_nationality():
    bool_0 = True
    person_0 = Person()
    str_0 = person_0.nationality()
    assert str_0.startswith("Nam")
    assert str_0.endswith("n")
    assert str_0 == "Namibian"


# Generated at 2022-06-25 21:07:02.817804
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    if not isinstance(person_1.nationality(), str):
        raise AssertionError('Expected str, got %s' % type(person_1.nationality()))


# Generated at 2022-06-25 21:07:05.516994
# Unit test for method surname of class Person
def test_Person_surname():
    
    # Declare class Person
    person_0 = Person()
   
    # Assertion
    assert person_0.surname().lstrip() == 'Иванов'


# Generated at 2022-06-25 21:07:10.231543
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname()
    assert person_0.surname()
    assert person_0.surname()
    assert person_0.surname()
    assert person_0.surname()


# Generated at 2022-06-25 21:07:13.964201
# Unit test for method surname of class Person
def test_Person_surname():
    try:
        person = Person()
        surname = person.surname()
        assert isinstance(surname, str)
    except Exception as e:
        print("Function surname of class Person has error. " + str(e))
        assert False


# Generated at 2022-06-25 21:07:30.978796
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    person_1._data['nationality'] = {
        Gender.MALE: ['Русский'],
        Gender.FEMALE: ['Русская']
    }

    assert person_1.nationality() == 'Русский'
    assert person_1.nationality(gender=Gender.FEMALE) == 'Русская'

if __name__ == '__main__':
    test_case_0()
    test_Person_nationality()
    print('All tests OK!')

# Generated at 2022-06-25 21:07:39.760249
# Unit test for method surname of class Person
def test_Person_surname():
    # Tests with each gender as an input parameter
    """
    person_0 = Person()
    result_0 = person_0.surname(Gender.MALE)
    print(result_0)
    result_1 = person_0.surname(Gender.FEMALE)
    print(result_1)
    """

    # Tests with None as an input parameter
    """
    person_2 = Person()
    result_2 = person_2.surname(None)
    print(result_2)
    """
    
    
    
    



# Generated at 2022-06-25 21:07:46.035347
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person(seed=0)
    person_4 = Person(seed=0)
    person_5 = Person(seed=0)

# Generated at 2022-06-25 21:07:47.795777
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'talia.surin@msn.com'


# Generated at 2022-06-25 21:07:50.092769
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = person_0._data['nationality']
    nationality = person_0.nationality()
    assert nationality in nationalities


# Generated at 2022-06-25 21:07:52.585427
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(20):
        print(Person().nationality())

# Generated at 2022-06-25 21:07:54.098479
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITY


# Generated at 2022-06-25 21:07:58.545319
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person(seed=1)
    person_0.gender(Gender.MALE)
    person_0.surname(Gender.MALE)
    person_1.gender(Gender.FEMALE)
    person_1.surname(Gender.FEMALE)


# Generated at 2022-06-25 21:08:08.152659
# Unit test for method nationality of class Person
def test_Person_nationality():
    ins_Person = Person()
    nationality = ins_Person.nationality()

# Generated at 2022-06-25 21:08:14.527223
# Unit test for method username of class Person
def test_Person_username():
    person_1 = Person()
    # Test function with default arguments
    result_1 = person_1.username()
    assert type(result_1) == str
    result_2 = person_1.username(template = 'dldddld')
    assert type(result_2) == str
    result_3 = person_1.username(template = 'U_d')
    assert type(result_3) == str
    result_4 = person_1.username(template = 'UU.d')
    assert type(result_4) == str
    result_5 = person_1.username(template = 'UU-d')
    assert type(result_5) == str
    result_6 = person_1.username(template = 'U-d')
    assert type(result_6) == str

# Generated at 2022-06-25 21:08:27.420096
# Unit test for method email of class Person
def test_Person_email():
    # Arrange
    expected = 'foretime10@live.com'
    person = Person()

    # Act
    actual = person.email()

    # Assert
    assert actual, expected


# Generated at 2022-06-25 21:08:32.194232
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    print('\nGender data:')
    print(person.gender())
    print(person.gender(symbol='unicode'))
    print(person.gender(iso5218=True))
    print('\nnationality data:')
    print(person.nationality())
    print(person.nationality(Gender.man))
    print(person.nationality(Gender.woman))
    print(person.nationality(Gender.not_known))
    print(person.nationality(Gender.not_applicable))


# Generated at 2022-06-25 21:08:35.077008
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    nationalities = person._data['nationality']
    print(nationality)
    assert nationality in nationalities
    print("Test case 0 passed")
    assert True == True
    print('Test case 1 passed')


# Generated at 2022-06-25 21:08:37.525509
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    result = person_0.surname()
    assert result in SURNAMES


# Generated at 2022-06-25 21:08:44.556618
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in ['Russian', 'Slovenian', 'Hungarian', 'Danish', 'Icelandic',
                           'German', 'Serbian', 'Malagasy', 'Georgian', 'Armenian',
                           'Greek', 'Croatian', 'Portuguese', 'Macedonian', 'Kazakh',
                           'Polish', 'Estonian', 'Finnish', 'Kyrgyz', 'Norwegian',
                           'Slovak', 'Belarusian', 'Vietnamese', 'Azerbaijani',
                           'Bosnian', 'Romanian', 'Latvian']


# Generated at 2022-06-25 21:08:46.655592
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname() in ['Mcdonald', 'Gilliam', 'Peters', 'Peterson']


# Generated at 2022-06-25 21:08:49.572170
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname(Gender.male) == person_0.surname(Gender.female) == \
            person_0.surname()


# Generated at 2022-06-25 21:08:56.535685
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    person_2 = Person()

    person_1_nationality = person_1.nationality()
    person_2_nationality = person_2.nationality()

    person_1_nationality = str(person_1_nationality)
    person_2_nationality = str(person_2_nationality)

    assert isinstance(person_1_nationality, str)
    assert isinstance(person_2_nationality, str)
    assert person_1_nationality != person_2_nationality



# Generated at 2022-06-25 21:08:57.913546
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert(isinstance(person_0.email(), str))


# Generated at 2022-06-25 21:09:00.016770
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    surname = person.surname()

    assert isinstance(surname, str) == True


# Generated at 2022-06-25 21:09:11.548832
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    # Expected: 'Russian'
    assert person_0.nationality() in ['Russian', 'Russian']


# Generated at 2022-06-25 21:09:20.613095
# Unit test for method surname of class Person
def test_Person_surname():

    person_0 = Person(seed=0)

    print("\n- Testing surname method of class Person")

    surname_0 = person_0.surname()
    surname_1 = person_0.surname()
    surname_2 = person_0.surname()
    surname_3 = person_0.surname()
    surname_4 = person_0.surname()
    surname_5 = person_0.surname()
    surname_6 = person_0.surname()
    surname_7 = person_0.surname()
    surname_8 = person_0.surname()
    surname_9 = person_0.surname()
    surname_10 = person_0.surname()
    surname_11 = person_0.surname()

# Generated at 2022-06-25 21:09:23.559142
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    assert isinstance(person_0.surname(), str)


# Generated at 2022-06-25 21:09:33.226823
# Unit test for method surname of class Person
def test_Person_surname():
    # Check method with default parameters (Random)
    person_0 = Person()
    person_0.surname()
    assert type(person_0.surname()) == str, "Must be <str>."

    # Check method with seeded provider
    person_1 = Person(seed=7)
    assert person_1.surname() == 'Delacruz', "Must be <Delacruz>."
    assert person_1.surname() == 'Delacruz', "Must be <Delacruz>."
    assert person_1.surname() == 'Delacruz', "Must be <Delacruz>."

    # Check method with gender
    person_2 = Person(seed=7)

# Generated at 2022-06-25 21:09:35.121166
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:09:37.143290
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    if type(person_0.surname()) == str:
        assert True
    else:
        assert False

# Generated at 2022-06-25 21:09:43.660528
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    res_0 = string_test_utils.test_type(string_test_utils.TYPE_STR, person_0.surname())
    assert res_0
    res_1 = string_test_utils.test_type(string_test_utils.TYPE_STR, person_0.surname(gender=Gender.male))
    assert res_1
    res_2 = string_test_utils.test_type(string_test_utils.TYPE_STR, person_0.surname(gender=Gender.female))
    assert res_2
    Person.data = f.load_data('en')
    res_3 = string_test_utils.test_type(string_test_utils.TYPE_STR, person_0.surname())
    assert res_3

# Generated at 2022-06-25 21:09:45.324848
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(), str), "Test for nationality failed"


# Generated at 2022-06-25 21:09:46.495030
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0_surname = person_0.surname()
    assert person_0_surname in USERNAMES


# Generated at 2022-06-25 21:09:48.914253
# Unit test for method surname of class Person
def test_Person_surname():

    person_0 = Person()

    surname = person_0.surname()
    assert isinstance(surname, str)
    assert surname in SURNAME_WORDS_RUSSIAN


# Generated at 2022-06-25 21:10:15.313075
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    # support function
    def f(gender: Optional[Gender] = None) -> str:
        return p.surname(gender)

    if f() in SURNAMES:
        pass
    else:
        raise AssertionError('Invalid surname %s' % f())

    if f(Gender.MALE) in SURNAMES['Male']:
        pass
    else:
        raise AssertionError('Invalid surname %s' % f(Gender.MALE))

    if f(Gender.FEMALE) in SURNAMES['Female']:
        pass
    else:
        raise AssertionError('Invalid surname %s' % f(Gender.FEMALE))


# Generated at 2022-06-25 21:10:17.213123
# Unit test for method email of class Person
def test_Person_email():
    person_1 = Person()
    email_0 = person_1.email()
    assert re.match(r'^(.*)@(.*)$', email_0)


# Generated at 2022-06-25 21:10:19.141294
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    person_0.surname(gender = Gender.MALE)


# Generated at 2022-06-25 21:10:24.405389
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0_0 = person_0.surname()
    surname_0_1 = person_0.surname()
    surname_0_2 = person_0.surname()

    assert surname_0_0 != surname_0_1
    assert surname_0_1 != surname_0_2
    assert surname_0_2 != surname_0_0


# Generated at 2022-06-25 21:10:29.159523
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality = person_0.nationality()

    nationality_len = len(nationality)

    assert(nationality_len == len(nationality))


# Generated at 2022-06-25 21:10:31.789384
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    person_1.seed(12345)
    assert(person_1.nationality() == "Ukrainian")


# Generated at 2022-06-25 21:10:32.648325
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    person_1.nationality()


# Generated at 2022-06-25 21:10:38.819102
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person(seed=0)
    person_2 = Person(seed=0)
    person_3 = Person(seed=0)
    new_surnames = ('Surname{}'.format(i) for i in range(3))
    person_0.add_custom_dataset('surnames', new_surnames)
    assert person_0.surname() == 'Surname0'
    assert person_1.surname() == 'Сабанов'

# Generated at 2022-06-25 21:10:41.776642
# Unit test for method username of class Person
def test_Person_username():
    person_1 = Person()
    print(person_1.username())


# Generated at 2022-06-25 21:10:44.099542
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()
    """
    print(surname_0)
    """


# Generated at 2022-06-25 21:11:10.998017
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()
    assert isinstance(surname_0,str)


# Generated at 2022-06-25 21:11:12.204602
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    person.nationality()


# Generated at 2022-06-25 21:11:16.345444
# Unit test for method nationality of class Person
def test_Person_nationality():
    thresh = 10
    person_generator = Person()
    for i in range(thresh):
        nationality_0 = person_generator.nationality()
        assert isinstance(nationality_0, str)
        print("The nationality is:", nationality_0)


# Generated at 2022-06-25 21:11:21.546251
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()

    person_1.nationality()
    person_2.nationality()
    person_3.nationality('male')

    assert True, "test_Person_nationality"


# Generated at 2022-06-25 21:11:24.473933
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()
    assert isinstance(surname_0, str)


# Generated at 2022-06-25 21:11:30.513839
# Unit test for method surname of class Person
def test_Person_surname():
    rnd = Random()
    person_1 = Person(random=rnd, seed=1)
    names = set()
    for i in range(1000):
        names.add(person_1.surname('male'))
    assert len(names) == 1000

    rnd = Random()
    person_2 = Person(random=rnd, seed=2)
    names = set()
    for i in range(1000):
        names.add(person_2.surname('female'))
    assert len(names) == 1000


# Generated at 2022-06-25 21:11:31.760757
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print(person_0.nationality())


# Generated at 2022-06-25 21:11:39.184256
# Unit test for method nationality of class Person
def test_Person_nationality():
    given_gender_male = Gender.MALE
    given_gender_female = Gender.FEMALE
    given_nationality_male = Nationality.ALBANIAN
    given_nationality_female = Nationality.AFGHAN
    person = Person()
    assert person.nationality(given_gender_male) == \
        given_nationality_male.value
    assert person.nationality(given_gender_female) == \
        given_nationality_female.value


# Generated at 2022-06-25 21:11:40.052147
# Unit test for method surname of class Person
def test_Person_surname():
    pass


# Generated at 2022-06-25 21:11:42.848137
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    # print("print surname: ")
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
