

# Generated at 2022-06-25 21:06:39.389762
# Unit test for method email of class Person
def test_Person_email():
    rnd_seed = random.randint(1, 9999)
    with mock.patch('random.seed', lambda *args: rnd_seed):
        list_0 = []
        person_0 = Person(*list_0)
        print(person_0.email(unique=True))
        assert 'unique' not in str(person_0.email.__code__)
        list_0 = ['f2b1545c-7783-4a0e-b938-07e6b23d2a3f']
        person_0 = Person(*list_0)
        with pytest.raises(ValueError):
            person_0.email(unique=True)
        # assert 'unique' not in str(person_0.email.__code__)


# Generated at 2022-06-25 21:06:49.948976
# Unit test for method surname of class Person
def test_Person_surname():
    print('----------------test_Person_surname()----------------')

    person_0 = Person()
    print('person_0.surname is:', person_0.surname())
    print('person_0.surname is:', person_0.surname(Gender.male))
    print('person_0.surname is:', person_0.surname(Gender.female))

    print()

    person_1 = Person(surnames={Gender.male : ['smth_0'], Gender.female : ['smth_1']})
    print('person_1.surname is:', person_1.surname())
    print('person_1.surname is:', person_1.surname(Gender.male))

# Generated at 2022-06-25 21:07:02.645755
# Unit test for method nationality of class Person

# Generated at 2022-06-25 21:07:05.685073
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname(gender=Gender.female)
    surname_female = person.surname(gender=Gender.female)
    surname_male = person.surname(gender=Gender.male)


# Generated at 2022-06-25 21:07:13.982882
# Unit test for method nationality of class Person
def test_Person_nationality():
    list_0 = []
    person_0 = Person(*list_0)
    str_0 = person_0.nationality(Gender.FEMALE)
    str_1 = person_0.nationality(Gender.MALE)
    str_2 = person_0.nationality(Gender.OTHER)
    str_3 = person_0.nationality()
    str_4 = person_0.nationality(Gender.ANY)
    print(str_0)
    print(str_1)
    print(str_2)
    print(str_3)
    print(str_4)


# Generated at 2022-06-25 21:07:22.799432
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Valid value
    person_0 = Person('en', 'ru')
    ru_vector = person_0._data["nationality"][Gender.Male]
    person_1 = Person('ru', 'en')
    en_vector = person_1._data["nationality"][Gender.Male]
    male_ru = person_0.nationality(Gender.Male)
    male_en = person_0.nationality(Gender.Male)
    assert (male_ru in ru_vector and male_en in en_vector)
    female_ru = person_0.nationality(Gender.Female)
    female_en = person_0.nationality(Gender.Female)
    ru_vector = person_0._data["nationality"][Gender.Female]
    en_vector = person_1._data["nationality"][Gender.Female]


# Generated at 2022-06-25 21:07:30.298689
# Unit test for method surname of class Person
def test_Person_surname():
    test_Person_surname_sex_0 = Person.Gender.FEMALE
    test_Person_surname_sex_1 = Person.Gender.MALE
    test_Person_surname_sex_2 = None

    assert Person.surname(test_Person_surname_sex_0) in Person._data['surname'].keys()

    assert Person.surname(test_Person_surname_sex_1) in Person._data['surname'].keys()

    assert Person.surname(test_Person_surname_sex_2) in Person._data['surname'].keys()


# Generated at 2022-06-25 21:07:36.305725
# Unit test for method nationality of class Person
def test_Person_nationality():
    # (self, gender: Optional[Gender] = None) -> str:
    list_0 = []
    person_0 = Person(*list_0)

    assert(type(person_0.nationality()) == str)


# Generated at 2022-06-25 21:07:38.207002
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert len(Person.nationality()) == len(Person.country())
    assert Person.nationality() == Person.nationality()


# Generated at 2022-06-25 21:07:44.413169
# Unit test for method email of class Person
def test_Person_email():
    print('Testing Person.email')

    from random import Random
    from faker.providers.person.en_US import Provider as PersonProvider

    person = PersonProvider(Random())
    print(person.email()) # -> 'bmckinney@mitchell.com'
    print(person.email(unique=True)) # -> 'cshantel@brown.com'
    print(person.email(domains=[
        'gmail.com',
        'yahoo.fr',
        'hotmail.com'])) # -> 'ulegar@yahoo.fr'



if __name__ == '__main__':
    # test_case_0()
    test_Person_email()

# Generated at 2022-06-25 21:07:58.747458
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert isinstance(person_1.nationality(),str)


# Generated at 2022-06-25 21:08:03.068320
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person(seed = "123456")
    person_1 = Person()

    assert person_0.surname() == 'Seddon'
    assert person_0.surname() == 'Seddon'
    assert person_1.surname() == 'Tilghman'


# Generated at 2022-06-25 21:08:04.786468
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    value = p.nationality()
    assert isinstance(value, str)


# Generated at 2022-06-25 21:08:06.138604
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:08:07.135699
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert person_0.email() != None


# Generated at 2022-06-25 21:08:08.388358
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = "Петров"
    assert person.surname(gender='male') == surname


# Generated at 2022-06-25 21:08:14.664581
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    for nationality1 in person.nationality():
        assert type(nationality1) == type('Russian')
        assert nationality1 in NATIONALITIES
        assert len(nationality1) in range(3,32)
        person_1 = Person()
        person_2 = Person()
        person_3 = Person()
        person_4 = Person()
        person_5 = Person()
        person_6 = Person()
        person_7 = Person()
        person_8 = Person()
        person_9 = Person()
        person_list = [person_1, person_2, person_3, person_4, person_5, person_6, person_7, person_8, person_9]
        for person_i in person_list:
            assert person_i.nationality() in NATIONALITIES
            nationality2

# Generated at 2022-06-25 21:08:17.093109
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.seed(1111)
    expected_output = 'Watson'
    actual_output = person_0.surname()
    assert actual_output == expected_output

# Generated at 2022-06-25 21:08:19.446922
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert type(person_0.surname()) == str, \
        "Class Person.surname() should return str type."


# Generated at 2022-06-25 21:08:21.176250
# Unit test for method nationality of class Person
def test_Person_nationality():
    p_obj = Person()
    nationality = p_obj.nationality()
    assert isinstance(nationality, str)


# Generated at 2022-06-25 21:08:35.763694
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(), str)


# Generated at 2022-06-25 21:08:44.641932
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person(random=Random())
    str_0 = person_0.surname()

# Generated at 2022-06-25 21:08:46.766064
# Unit test for method nationality of class Person
def test_Person_nationality():
    person1 = Person()
    person2 = Person()

    #test the method nationality for default case
    assert person1.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:08:49.054376
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Call method nationality() and print result
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:08:51.916314
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    # Должен возвращать строку
    assert isinstance(person_0.surname(), (str))


# Generated at 2022-06-25 21:08:53.164459
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert set(Person().nationality() == None)


# Generated at 2022-06-25 21:08:58.705134
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_gen = Person()
    nationalities=person_gen.nationality()
    print(nationalities)
    assert nationalities in ['Arabia', 'Armenia', 'Bulgaria', 'Georgia', 'Kazakhstan', 'Kyrgyzstan', 'Pakistan', 'Russia', 'Tajikistan', 'Turkmenistan', 'Ukraine', 'Uzbekistan']



# Generated at 2022-06-25 21:09:01.588752
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=0)
    print(person.surname())

if __name__ == '__main__':
    person = Person()
    print(person.surname())

# Generated at 2022-06-25 21:09:07.063305
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in person_0._data['nationality']
    assert person_0.nationality(Gender.FEMALE) in person_0._data['nationality']['female']
    assert person_0.nationality(Gender.MALE) in person_0._data['nationality']['male']
    with pytest.raises(NonEnumerableError):
        assert person_0.nationality('some_string')


# Generated at 2022-06-25 21:09:13.814634
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(), str)
    assert type(person_0.nationality()) == str
    assert isinstance(person_0.nationality(Gender.MALE), str)
    assert type(person_0.nationality(Gender.MALE)) == str
    assert isinstance(person_0.nationality(Gender.FEMALE), str)
    assert type(person_0.nationality(Gender.FEMALE)) == str
    assert isinstance(person_0.nationality(Gender.NOT_SPECIFIED), str)
    assert type(person_0.nationality(Gender.NOT_SPECIFIED)) == str


# Generated at 2022-06-25 21:09:44.485938
# Unit test for method nationality of class Person
def test_Person_nationality():
    local_person_0 = Person()
    local_person_1 = Person()
    rnd_gender_0 = Gender(random.randint(0, 2))
    rnd_gender_1 = Gender(random.randint(0, 2))
    assert(len(local_person_0.nationality(rnd_gender_0)) >= 2)
    assert(len(local_person_1.nationality(rnd_gender_1)) >= 2)


# Generated at 2022-06-25 21:09:47.148159
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    assert person_1.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:09:49.096146
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    for i in range(10):
        surname = person_0.surname()
        assert len(surname) > 0


# Generated at 2022-06-25 21:09:58.318159
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()

    # Act
    surname_0 = person_0.surname()
    surname_1 = person_1.surname()
    surname_2 = person_2.surname()
    surname_3 = person_3.surname()
    surname_4 = person_4.surname()
    surname_5 = person_5.surname()
    surname_6 = person_6.surname()

    # Assert
    assert isinstance(surname_0, str)
    assert isinstance(surname_1, str)

# Generated at 2022-06-25 21:09:59.357062
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    person_1.surname()


# Generated at 2022-06-25 21:10:08.829004
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

    assert type(person_0.nationality()) == str
    assert type(person_0.nationality(gender=Gender.female)) == str

    try:
        person_0.nationality(gender="Male")
    except NonEnumerableError:
        pass
    else:
        raise AssertionError("NonEnumerableError is not raised")

    try:
        person_0.nationality(gender=3)
    except NonEnumerableError:
        pass
    else:
        raise AssertionError("NonEnumerableError is not raised")



# Generated at 2022-06-25 21:10:11.659265
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    person_2 = Person()

    if person_1.surname() != 'Anderson':
        print(person_1.surname())
    if person_2.surname() != 'Anderson':
        print(person_2.surname())



# Generated at 2022-06-25 21:10:19.307812
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(seed=0)
    print("\nTest case 0 (seed=0)")
    print("================================================================")
    print("Nationality: ", person_0.nationality(), "\n")
    nationalities = set([person_0.nationality() for _ in range(100)])

    person_1 = Person(seed=1)
    print("\nTest case 1 (seed=1)")
    print("================================================================")
    print("Nationality: ", person_1.nationality(), "\n")
    nationalities_1 = set([person_1.nationality() for _ in range(100)])

    assert nationalities == nationalities_1

if __name__ == '__main__':
    test_Person_nationality()

# Generated at 2022-06-25 21:10:24.891671
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test for nationality for gender not None
    person_1 = Person()
    nationalities = person_1._data['nationality']
    # Checking the nationality for genders: male, female, not known
    for gender in Gender:
        # Validation if key male or female exists
        if gender not in nationalities:
            continue
        nationality = person_1.nationality(gender)
        assert nationality in nationalities[gender]
    return True


# Generated at 2022-06-25 21:10:29.078976
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    a = person.surname(Gender.Male)
    assert isinstance(a, str)


# Generated at 2022-06-25 21:11:29.511785
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    method_result_0 = person_0.nationality()

# Generated at 2022-06-25 21:11:30.713373
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(10):
        assert type(Person().nationality()) == str


# Generated at 2022-06-25 21:11:31.948104
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality = person_0.nationality()
    print(nationality)



# Generated at 2022-06-25 21:11:33.936637
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()

    # Check a string is returned
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-25 21:11:41.270312
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nat_0 = person_0.nationality()
    nat_1 = person_0.nationality(Gender.FEMALE)
    nat_2 = person_0.nationality(Gender.MALE)
    assert isinstance(nat_0, str), 'nat_0 is not a string'
    assert isinstance(nat_1, str), 'nat_1 is not a string'
    assert isinstance(nat_2, str), 'nat_2 is not a string'


# Generated at 2022-06-25 21:11:43.874602
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-25 21:11:45.022704
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print(person_0.nationality())


# Generated at 2022-06-25 21:11:47.958625
# Unit test for method nationality of class Person
def test_Person_nationality():
    cases = [{'nationality': 'French', 'gender': 'MALE'},
             {'nationality': 'French', 'gender': 'FEMALE'},
             {'nationality': 'French'}]

    for case in cases:
        person = Person()
        person.nationality(case['nationality'], case['gender'])



# Generated at 2022-06-25 21:11:49.070952
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in NATIONALITY_LIST


# Generated at 2022-06-25 21:11:57.781591
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
