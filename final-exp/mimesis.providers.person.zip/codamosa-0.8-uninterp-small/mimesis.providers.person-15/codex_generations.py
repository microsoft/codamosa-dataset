

# Generated at 2022-06-25 21:06:24.195818
# Unit test for method email of class Person
def test_Person_email():
    rng = random.Random()
    rng.seed(1)
    person_0 = Person(rng)
    assert person_0.email(['mail.com'], unique=False) == 'henderson69@mail.com'


# Generated at 2022-06-25 21:06:29.723761
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname(gender=Gender.M)
    assert type(str_0) == str
    assert len(str_0) > 0


# Generated at 2022-06-25 21:06:33.258088
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()
    assert str_0 == 'Singaporean'


# Generated at 2022-06-25 21:06:35.097901
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()


# Generated at 2022-06-25 21:06:44.106840
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    # Pick any random email.
    email = person.email()
    print(email)
    # Pick any random email from a list of custom domains.
    email = person.email(domains=['gmail.com'])
    print(email)

    # The email is not unique.
    person = Person()
    email = person.email()
    print(email)
    email = person.email()
    print(email)

    # The email is unique.
    person = Person()
    email = person.email(unique=True)
    print(email)
    email = person.email(unique=True)
    print(email)



# Generated at 2022-06-25 21:06:45.248642
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()


# Generated at 2022-06-25 21:06:47.403940
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    sn = person.surname()
    assert isinstance(sn, str)


# Generated at 2022-06-25 21:06:59.652274
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person('{surname}')
    str_0 = person_0.surname()
    str_1 = person_0.name()
    str_2 = person_0.last_name()
    str_3 = person_0.title()
    str_4 = person_0.full_name()
    str_5 = person_0.username(template='UU-d')
    str_6 = person_0.password()
    str_7 = person_0.email()
    str_8 = person_0.social_media_profile()
    str_9 = person_0.gender()
    str_10 = person_0.height()
    str_11 = person_0.weight()
    str_12 = person_0.blood_type()
    str_13 = person_0.sexual_

# Generated at 2022-06-25 21:07:02.515159
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:07:05.226473
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    str_0 = person_0.email()
    assert str_0 == 'wilson.austin@aol.co.uk'



# Generated at 2022-06-25 21:07:14.644167
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == Person().email()
    assert person.email(unique=True) != Person().email(unique=True)
    assert person.email(unique=True) == person.email(unique=True)


# Generated at 2022-06-25 21:07:16.670506
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname = person_0.surname()
    assert isinstance(surname, str)

# Generated at 2022-06-25 21:07:19.002628
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-25 21:07:27.983077
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.random.seed(0)
    test_0 = person_0.nationality()
    assert test_0 == 'Honduran'
    test_1 = person_0.nationality(Gender.FEMALE)
    assert test_1 == 'Honduran'
    person_0.random.seed(1)
    test_2 = person_0.nationality()
    assert test_2 == 'American'
    test_3 = person_0.nationality(Gender.FEMALE)
    assert test_3 == 'American'
    person_0.random.seed(2)
    test_4 = person_0.nationality()
    assert test_4 == 'Belgian'
    test_5 = person_0.nationality(Gender.FEMALE)
    assert test_

# Generated at 2022-06-25 21:07:31.806385
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    print("nationality_0 is " + str(nationality_0))
    nationality_1 = person_0.nationality(Gender.Female)
    print("nationality_1 is " + str(nationality_1))


# Generated at 2022-06-25 21:07:35.920705
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    email_0 = provider.email()


# Generated at 2022-06-25 21:07:38.167091
# Unit test for method email of class Person
def test_Person_email():
    for i in range(10): 
        person_0 = Person()
        assert person_0.email() == person_1.email()
    

# Generated at 2022-06-25 21:07:45.160631
# Unit test for method surname of class Person
def test_Person_surname():
    # Создание экземпляра класса Person
    person_0 = Person()
    # Генирация значений, которые не являются объектами класса Gender

# Generated at 2022-06-25 21:07:46.489156
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    person.nationality()


# Generated at 2022-06-25 21:07:57.414259
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()
    ans = 'BuckDecker1849'
    assert person_0.username('l_d') == ans
    ans = 'BuckDecker1849'
    assert person_0.username('l_d') == ans
    ans = 'BuckDecker1849'
    assert person_0.username('l_d') == ans
    ans = 'BuckDecker1849'
    assert person_0.username('l_d') == ans
    ans = 'BuckDecker1849'
    assert person_0.username('l_d') == ans
    ans = 'BuckDecker1849'
    assert person_0.username('l_d') == ans
    ans = 'BuckDecker1849'
    assert person_0.username('l_d') == ans
    ans

# Generated at 2022-06-25 21:08:19.649158
# Unit test for method surname of class Person
def test_Person_surname():
    male_first_name_list = []
    male_last_name_list = []
    female_first_name_list = []
    female_last_name_list = []

    for test_iter in range(100):
        person_test = Person()

        male_first_name_list.append(person_test.name(Gender.MALE))
        female_first_name_list.append(person_test.name(Gender.FEMALE))
        male_last_name_list.append(person_test.surname(Gender.MALE))
        female_last_name_list.append(person_test.surname(Gender.FEMALE))

    assert len(male_first_name_list) == len(female_first_name_list)
    assert len(male_first_name_list) == len

# Generated at 2022-06-25 21:08:20.463911
# Unit test for method surname of class Person
def test_Person_surname():
    print(Person().surname())


# Generated at 2022-06-25 21:08:28.363897
# Unit test for method surname of class Person
def test_Person_surname():
    import random
    from collections import Counter, defaultdict
    person_0 = Person()

    surnames_0 = list()
    surnames_1 = list()
    counts = Counter()

    for i in range(10**5):
        surname_0 = person_0.surname(Gender.MALE)
        surnames_0.append(surname_0)

    counts_0 = Counter(surnames_0)

    for i in range(10**5):
        surname_1 = person_0.surname(Gender.FEMALE)
        surnames_1.append(surname_1)

    counts_1 = Counter(surnames_1)

    for x in counts_0.keys():
        counts[x] += counts_0[x]


# Generated at 2022-06-25 21:08:30.058572
# Unit test for method email of class Person
def test_Person_email():
    # Create an instance of Person
    person = Person()
    assert isinstance(person.email(), str)
    assert person.email().startswith('@')


# Generated at 2022-06-25 21:08:32.478612
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    rnd = person_0.surname()
    print('surname =', rnd)
    assert type(rnd) is str
    assert len(rnd) > 0


# Generated at 2022-06-25 21:08:40.883622
# Unit test for method email of class Person
def test_Person_email():
    person_1 = Person()
    greek = ''.join(chr(code) for code in range(913, 976))
    cyrillic = ''.join(chr(code) for code in range(1040, 1072))
    korean = ''.join(chr(code) for code in range(44032, 55203))
    domains = tuple(
        ['abcdefg', 'домен', '∂øмåîñ', greek, cyrillic, korean])

    # # Test that when person_1.email() returns a string
    def test_case_1():
        assert isinstance(person_1.email(), str)

    # # Test that when person_1.email(domains) returns a string

# Generated at 2022-06-25 21:08:42.576163
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print(person_0.nationality())


# Generated at 2022-06-25 21:08:44.284971
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert(isinstance(nationality, str))
    assert(nationality != '')


# Generated at 2022-06-25 21:08:45.753284
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert type(person_0.surname()) is str


# Generated at 2022-06-25 21:08:49.533586
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    assert person_1.surname(Gender.male) == 'Сергеев'

    person_2 = Person(seed=4)
    assert person_2.surname(Gender.male) == 'Самойлов'


# Generated at 2022-06-25 21:09:09.116683
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person()

    person_0.surname(Gender.FEMALE)
    person_1.surname()


if __name__ == '__main__':

    test_case_0()
    test_Person_surname()
    print('Test is completed.')

# Generated at 2022-06-25 21:09:11.366058
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(gender=Gender.MAN), str)


# Generated at 2022-06-25 21:09:13.932524
# Unit test for method surname of class Person
def test_Person_surname():
    # Run test
    person_0 = Person()

    assert (not(person_0.surname() is None)) \
           and not(len(person_0.surname()) == 0)


# Generated at 2022-06-25 21:09:19.651024
# Unit test for method username of class Person
def test_Person_username():
    m_0 = Person()
    username_0 = m_0.username()
    print('username_0 =', username_0)
    assert (re.fullmatch(r'[a-z]{5}\d{4}', username_0) is not None or
            re.fullmatch(r'[a-z]{5}\d{4}', username_0) is not None)


# Generated at 2022-06-25 21:09:31.415891
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()

    arg_0 = Gender.FEMALE
    arg_1 = None
    arg_2 = Gender.MALE
    arg_3 = Gender.MALE
    arg_4 = Gender.FEMALE
    arg_5 = Gender.MALE
    arg_6 = None

    assert person_0.nationality(arg_0) is not None
    assert person_1.nationality(arg_1) is not None
    assert person_2.nationality(arg_2) is not None
    assert person_3.nationality(arg_3) is not None

# Generated at 2022-06-25 21:09:33.156506
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    person.seed(0)
    person.email()


# Generated at 2022-06-25 21:09:37.365086
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()
    person_1 = Person()

    u_0 = person_0.username(template='l_d')
    u_1 = person_1.username(template='l_d')

    assert len(u_0) == len(u_1)
    assert len(u_0) == 4


# Generated at 2022-06-25 21:09:39.023774
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert person_0.email().find(".com") != -1


# Generated at 2022-06-25 21:09:42.369823
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname(gender=Gender.MALE) in person_0._data['surnames']['male']
    assert person_0.surname(gender=Gender.FEMALE) in person_0._data['surnames']['female']
    assert person_0.surname(gender=Gender.UNDEFINED) in person_0._data['surnames']['undefined']


# Generated at 2022-06-25 21:09:44.206454
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname() in person_0._data['surname']


# Generated at 2022-06-25 21:10:15.500448
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert type(surname) is str


# Generated at 2022-06-25 21:10:17.371108
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    output_1 = person_1.nationality(gender=None)
    assert_equal(isinstance(output_1, str), True)


# Generated at 2022-06-25 21:10:21.249919
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    if person_0.surname(Gender.MALE) != "Иванов":
        raise AssertionError
    if person_0.surname(Gender.FEMALE) != "Иванова":
        raise AssertionError


# Generated at 2022-06-25 21:10:30.463416
# Unit test for method nationality of class Person
def test_Person_nationality():

    person_0 = Person(seed=123)
    for _ in range(0):
        person_0.nationality()

    person_0 = Person(seed=123)
    nationality_0 = person_0.nationality()
    assert nationality_0 == "Lithuanian"

    person_0 = Person(seed=123)
    nationality_0 = person_0.nationality()
    assert nationality_0 == "Lithuanian"

if __name__ == '__main__':
    test_case_0()
    test_Person_nationality()
    print('Done')

# Generated at 2022-06-25 21:10:37.899667
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_7 = Person()
    person_8 = Person()
    person_9 = Person()
    person_10 = Person()
    person_11 = Person()
    person_12 = Person()
    person_13 = Person()
    person_14 = Person()

# Generated at 2022-06-25 21:10:44.065722
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    genders = [Gender.male, Gender.female, Gender.unknown]
    for gender in genders:
        for i in range(10):
            nationality = person.nationality(gender)
            assert isinstance(nationality, str)
            assert len(nationality) > 0
    return 0


# Generated at 2022-06-25 21:10:48.770010
# Unit test for method email of class Person
def test_Person_email():
    from random import seed
    from faker import Faker
    from faker.providers.person.en_US import Provider
    fake = Faker('en_US')
    fake.seed(0)
    person_Gen = Person(fake)

    email_0 = person_Gen.email()

    assert email_0 == 'gabrielle.green@hotmail.com'



# Generated at 2022-06-25 21:10:50.921020
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    output_0 = person_0.surname(Gender.MALE)
    # Assertion, check if the surname of person 0 is not empty
    assert output_0 != ""


# Generated at 2022-06-25 21:10:53.705316
# Unit test for method surname of class Person
def test_Person_surname():
    n = 10
    for i in range(n):
        person = Person()
        surname = person.surname()
        assert isinstance(surname, str), "Incorrect type of surname"


# Generated at 2022-06-25 21:10:55.303061
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test Person.nationality method.

    Test if method nationality of class Person has no errors.
    """
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-25 21:12:11.695603
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname(Gender.MALE)
    person_0.surname(Gender.FEMALE)

    person_1 = Person().surname()
    print(person_1)


# Generated at 2022-06-25 21:12:16.968817
# Unit test for method surname of class Person

# Generated at 2022-06-25 21:12:25.969862
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(10):
        person_1 = Person()
        person_1.random.seed(43)
        assert person_1.surname() == 'Конюшков'
        assert person_1.surname() == 'Конюшков'
        assert person_1.surname() == 'Конюшков'
        assert person_1.surname() == 'Конюшков'
        assert person_1.surname() == 'Конюшков'

        person_1.random.seed(43)
        assert person_1.surname(gender=Gender.MALE) == 'Конюшков'
       

# Generated at 2022-06-25 21:12:36.808702
# Unit test for method surname of class Person
def test_Person_surname():

    # Test data
    test_data = [None, Gender.male, Gender.female]

    # Expect results

# Generated at 2022-06-25 21:12:40.159822
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert(isinstance(person_0.nationality(), str))


# Generated at 2022-06-25 21:12:43.819593
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    for i in range(50000):
        try:
            assert type(person_0.surname()) == str
        except AssertionError:
            print("AssertionError:", person_0.surname())


# Generated at 2022-06-25 21:12:46.866238
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-25 21:13:00.775323
# Unit test for method surname of class Person
def test_Person_surname():
    # Creating object
    person_0 = Person(random=Random(seed=0))

    # Test method - 0
    try:
        expected_0 = 'Тимофеев'
        actual_0 = person_0.surname()
        assert actual_0 == expected_0
    except AssertionError as e:
        print('Test method 0 - FAILED')
        print('Expected: "{}"'.format(expected_0))
        print('Actual: "{}"'.format(actual_0))
        raise e
    else:
        print('Test method 0 - PASSED')
    # Test method - 1

# Generated at 2022-06-25 21:13:04.090226
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    try:
        nationality_0 = person_0.nationality()
    except NonEnumerableError:
        pass
    nationality_1 = person_0.nationality(Gender.MALE)
    nationality_2 = person_0.nationality(Gender.FEMALE)


# Generated at 2022-06-25 21:13:07.647372
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()


# Generated at 2022-06-25 21:14:18.502413
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    result = person.surname()
    assert isinstance(result, str)


# Generated at 2022-06-25 21:14:22.439247
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationalities = person_0._data['nationality']
    assert person_0.nationality() in nationalities


# Generated at 2022-06-25 21:14:25.023927
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    test_case_0(person_0.surname())


# Generated at 2022-06-25 21:14:29.245999
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(gender=Gender.MALE), str)


# Generated at 2022-06-25 21:14:35.329007
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    nationality = person_1.nationality()
    assert nationality in _data['nationality']
    nationality_male = person_1.nationality(gender=Gender.male)
    assert nationality_male in _data['nationality'][Gender.male]
    nationality_female = person_1.nationality(gender=Gender.female)
    assert nationality_female in _data['nationality'][Gender.female]


# Generated at 2022-06-25 21:14:44.907261
# Unit test for method nationality of class Person
def test_Person_nationality():
    seed = 8
    random.seed(seed)
    expected_1 = 'American'
    expected_2 = 'Russian'
    person_1 = Person(seed=seed)
    person_2 = Person(seed=seed)
    assert person_1.nationality() == expected_1
    assert person_1.nationality(Gender.Male) == expected_2
    assert person_1.nationality(Gender.Female) == expected_1
    assert person_2.nationality() == expected_1
    assert person_2.nationality(Gender.Male) == expected_2
    assert person_2.nationality(Gender.Female) == expected_1


# Generated at 2022-06-25 21:14:54.349420
# Unit test for method surname of class Person
def test_Person_surname():
    names = ['Smith', 'Miller', 'Heinz', 'Lindquist', 'Ford', 'Johnson', 'Williams', 'Brown', 'Jones']
    regexp = r'^%s$' % '|'.join(names)
    person = Person()
    assert re.match(regexp, person.surname())
    person = Person(seed=123)
    assert re.match(regexp, person.surname())
    assert re.match(regexp, person.surname())
    person = Person(seed=123)
    assert re.match(regexp, person.surname())
    assert re.match(regexp, person.surname())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:14:56.871260
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)


# Generated at 2022-06-25 21:15:02.599191
# Unit test for method surname of class Person
def test_Person_surname():
    """Test surname method of Person class."""
    from datagenerator.generators.person import Person

    # Testing surname method
    person_0 = Person()
    person_0.surname()


# Generated at 2022-06-25 21:15:08.949185
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(seed=1)
    person_0.nationality()
    assert person_0.nationality() == 'Русский'

