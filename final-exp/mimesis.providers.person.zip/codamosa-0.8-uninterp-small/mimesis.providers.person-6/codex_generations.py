

# Generated at 2022-06-25 21:06:24.090781
# Unit test for method gender of class Person
def test_Person_gender():
    # Init person object
    person_0 = Person()
    # Call method gender
    var_0 = person_0.gender()
    # Assert that actual result equal expected result
    assert var_0 == "Мужской"


# Generated at 2022-06-25 21:06:28.072085
# Unit test for method surname of class Person
def test_Person_surname():

    person_1 = Person()
    var_1 = person_1.surname()


# Generated at 2022-06-25 21:06:32.068789
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    var_0 = person_0.surname()
    assert var_0 in person_0._data['surname']


# Generated at 2022-06-25 21:06:36.364710
# Unit test for method gender of class Person
def test_Person_gender():
    var_0 = Person()
    var_1 = var_0.gender()
    if var_1 == 'Male':
        print('Unit test for method gender of class Person is PASSED.')
    else:
        print('Unit test for method gender of class Person is FAILED.')


# Generated at 2022-06-25 21:06:41.559850
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    # Test case: person_0.email()
    person_0.email()
    person_0.email()
    person_0.email()
    person_0.email()
    person_0.email()
    person_0.email()
    person_0.email()
    person_0.email()


# Generated at 2022-06-25 21:06:45.894445
# Unit test for method email of class Person
def test_Person_email():
    import random

    person_0 = Person(random_state=random.Random())
    var_0 = person_0.email()
    assert type(var_0) == str
    assert var_0 == 'maricelamarcuse@hotmail.com'


# Generated at 2022-06-25 21:06:58.216360
# Unit test for method gender of class Person
def test_Person_gender():
    # Test case #0
    person_0 = Person()
    var_0 = person_0.gender()
    assert(isinstance(var_0, str))
    # Test case #1
    person_1 = Person()
    var_1 = person_1.gender()
    assert(isinstance(var_1, str))
    # Test case #2
    person_2 = Person()
    var_2 = person_2.gender()
    assert(isinstance(var_2, str))
    # Test case #3
    person_3 = Person()
    var_3 = person_3.gender()
    assert(isinstance(var_3, str))
    # Test case #4
    person_4 = Person()
    var_4 = person_4.gender()
    assert(isinstance(var_4, str))

# Generated at 2022-06-25 21:07:01.029263
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_1 = Person()

    assert person_1.email() != person_0.email()


# Generated at 2022-06-25 21:07:02.381367
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:07:12.651018
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    var_0 = person_0.surname()
    var_1 = person_0.surname()
    var_2 = person_0.surname()
    var_3 = person_0.surname()
    var_4 = person_0.surname()
    var_5 = person_0.surname()
    var_6 = person_0.surname()
    var_7 = person_0.surname()
    var_8 = person_0.surname()
    var_9 = person_0.surname()
    var_10 = person_0.surname()
    var_11 = person_0.surname()
    var_12 = person_0.surname()

# Generated at 2022-06-25 21:07:23.812082
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()
    person_0.surname(gender = Gender.FEMALE)


# Generated at 2022-06-25 21:07:26.214009
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(0, 10):
        person = Person()
        nationality = person.nationality()
        assert isinstance(nationality, str)


# Generated at 2022-06-25 21:07:27.982539
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:07:29.259147
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() == 'German'


# Generated at 2022-06-25 21:07:31.763908
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_0.email()
    person_0.email()
    person_0.email()

test_Person_email()


# Generated at 2022-06-25 21:07:37.229310
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(0, 100):
        person_0 = Person()
        if person_0.nationality() in NATIONALITY:
            pass
        else:
            print("Failed")
            exit(1)


# Generated at 2022-06-25 21:07:41.371168
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    assert "Сомали" == person_1.nationality()
    assert "Сомали" == person_1.nationality(gender=Gender.Male)
    assert "Сомали" == person_1.nationality(gender=Gender.Female)


# Generated at 2022-06-25 21:07:50.577461
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

# Generated at 2022-06-25 21:07:56.520523
# Unit test for method surname of class Person
def test_Person_surname():
    """Test method surname of class Person."""
    person_0 = Person()
    assert person_0.surname() in SURNAMES
    assert person_0.surname(gender=Gender.MALE) in SURNAMES_MALE
    assert person_0.surname(gender=Gender.FEMALE) in SURNAMES_FEMALE


# Generated at 2022-06-25 21:07:58.792886
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in person_0._data['nationality']


# Generated at 2022-06-25 21:08:06.987981
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(0, len(COUNTRIES)):
        person_0 = Person()
        person_0.nationality() == COUNTRIES[i]


# Generated at 2022-06-25 21:08:13.559302
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    # Surname for male gender
    print(person_1.surname(gender=Gender.MALE))
    # Surname for female gender
    print(person_1.surname(gender=Gender.FEMALE))
    # Surname for unspecified gender
    print(person_1.surname())
    # Last name for male gender
    print(person_1.last_name(gender=Gender.MALE))
    # Last name for female gender
    print(person_1.last_name(gender=Gender.FEMALE))
    # Last name for unspecified gender
    print(person_1.last_name())


# Generated at 2022-06-25 21:08:15.229896
# Unit test for method nationality of class Person
def test_Person_nationality():
   for i in range(0, 100):
       person = Person()
       assert type(person.nationality()) is str


# Generated at 2022-06-25 21:08:17.054071
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    res_0 = person_0.nationality()
    print(res_0)


# Generated at 2022-06-25 21:08:18.700692
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    assert isinstance(person_0.nationality(), str)
    assert isinstance(person_1.nationality(), str)
    assert person_0.nationality() != person_1.nationality()


# Generated at 2022-06-25 21:08:25.740058
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_7 = Person()
    person_8 = Person()

    assert(person_1.surname() != person_2.surname())
    assert(person_3.surname() != person_4.surname())
    assert(person_5.surname() != person_6.surname())
    assert(person_7.surname(Gender.MALE) != None)
    assert(person_8.surname(Gender.FEMALE) != None)


# Generated at 2022-06-25 21:08:27.730176
# Unit test for method username of class Person
def test_Person_username():
    # Case 0
    person_0 = Person()
    result_0 = person_0.username()
    assert isinstance(result_0, str)


# Generated at 2022-06-25 21:08:34.025239
# Unit test for method surname of class Person
def test_Person_surname():
    names = ['Djokovic', 'Zverev', 'Dimitrov', 'Ferrer', 'Gasquet',
             'Monfils', 'Simon', 'Tsonga', 'Raonic', 'Cilic', 'Gulbis',
             'Bautista Agut', 'Fognini', 'Pouille', 'Kohlschreiber', 'Murray',
             'Almagro', 'Goffin', 'Struff', 'Karlovic', 'Isner', 'Ferrer',
             'Haase', 'Nishikori', 'Carreno Busta', 'Querrey', 'Thiem',
             'Kyrgios', 'Shapovalov']
    p = Person()
    for _ in range(1000):
        name = p.surname()
        assert name in names


# Generated at 2022-06-25 21:08:37.971914
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(Seed.deterministic)
    assert person_0.nationality() == 'Russian'
    assert person_0.nationality(gender = Gender.Male) == 'Russian'
    assert person_0.nationality(gender = Gender.Female) == 'Russian'
    

# Generated at 2022-06-25 21:08:42.939898
# Unit test for method email of class Person
def test_Person_email():

    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    
    print(person_1.email())
    print(person_1.email(unique=True))
    print(person_2.email(unique=True))
    print(person_3.email(unique=True))
    # print(person_1.email(unique==True))
    # print(person_1.unique())


# Generated at 2022-06-25 21:08:59.795970
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test case 0
    person_0 = Person()
    assert isinstance(person_0.nationality(), str)


# Generated at 2022-06-25 21:09:08.720538
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    # Return random value from 'test_data/test_nationality.json'
    # For 'test_data/test_nationality.json'
    # [ 'Albanian', 'Bosnian', 'Brazilian', 'Croatian', 'Cuban', 'Czech',
    #   'Danish', 'Dutch', 'English', 'Estonian', 'Finnish', 'French',
    #   'German', 'Hungarian', 'Icelandic', 'Irish', 'Italian', 'Latvian',
    #   'Lithuanian', 'Maltese', 'Norwegian', 'Portuguese', 'Romanian',
    #   'Russian', 'Serbian', 'Slovakian', 'Slovenian', 'Spanish',
    #   'Swedish', 'Turkish', 'Ukrainian' ]

# Generated at 2022-06-25 21:09:11.653881
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    gender = Gender.MALE
    people = person.surname(gender)
    print(people)
    assert isinstance(people, str)


# Generated at 2022-06-25 21:09:17.612374
# Unit test for method surname of class Person
def test_Person_surname():
    import random
    person_0 = Person(random)
    gender = None
    assert person_0.surname(gender) in ['Abbott', 'Cervantes', 'Hawking', 'Borges', 'Bradbury', 'Plath', 'Alcott', 'Woolf', 'Lee', 'Atwood', 'Akutagawa']


# Generated at 2022-06-25 21:09:22.288447
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert(isinstance(person.surname(), str) == True)
    assert(isinstance(person.surname(Gender.Male), str) == True)
    assert(isinstance(person.surname(Gender.Female), str) == True)


# Generated at 2022-06-25 21:09:25.658787
# Unit test for method username of class Person
def test_Person_username():
    # KeyError: 'username'
    person_0 = Person()
    result = person_0.username()
    assert type(result) is str


# Generated at 2022-06-25 21:09:35.355076
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    # Test 1
    nationality_0 = person_0.nationality()
    assert isinstance(nationality_0, str)
    # Test 2
    nationality_0 = person_0.nationality(Gender.MALE)
    nationality_0 = person_0.nationality(Gender.FEMALE)
    nationality_0 = person_0.nationality(Gender.FEMALE)
    nationality_0 = person_0.nationality(Gender.FEMALE)
    nationality_0 = person_0.nationality(Gender.MALE)
    nationality_0 = person_0.nationality(Gender.MALE)
    nationality_0 = person_0.nationality(Gender.FEMALE)
    nationality_0 = person_0.nationality(Gender.FEMALE)
    nationality_0 = person

# Generated at 2022-06-25 21:09:37.335099
# Unit test for method surname of class Person
def test_Person_surname():
    # Create an instance of class Person
    person_0 = Person()
    # Get surname for the person
    surname = person_0.surname()



# Generated at 2022-06-25 21:09:40.502659
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(seed=42)
    expected_result_0 = "English"
    person_0_class_method_result = person_0.nationality(gender=Gender.MALE)
    assert person_0_class_method_result == expected_result_0


# Generated at 2022-06-25 21:09:47.107504
# Unit test for method surname of class Person
def test_Person_surname():
    # Test case 0
    person_0 = Person()
    surname = person_0.surname()
    if not (type(surname) == type('') and surname):
        print('Test for method surname of class Person FAILED.')
        print('Unexpected type or value')
        return
    print('Test for method surname of class Person PASSED.')


# Generated at 2022-06-25 21:10:03.213597
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    print(person_0.surname())


# Generated at 2022-06-25 21:10:13.736105
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.seed(0)
    assert person_0.surname() == "Nikolaev"
    assert person_0.surname() == "Ivanov"
    assert person_0.surname() == "Kuzmin"
    assert person_0.surname() == "Tishchenko"
    assert person_0.surname() == "Smirnov"
    assert person_0.surname() == "Degtyarev"
    assert person_0.surname() == "Zhukov"
    assert person_0.surname() == "Grishin"
    assert person_0.surname() == "Pavlov"
    assert person_0.surname() == "Kupriyanov"

# Generated at 2022-06-25 21:10:15.720530
# Unit test for method nationality of class Person
def test_Person_nationality():
    Person_nationality = Person().nationality()
    expected_results = ('Russian', 'English', 'Kazakh', 'French', 'German', 'Italian', 'Japanese', 'Chinese')

    assert Person_nationality in expected_results


# Generated at 2022-06-25 21:10:21.554223
# Unit test for method surname of class Person
def test_Person_surname():
    from text_unidecode import unidecode
    person_0 = Person()
    person_0.seed(123)
    surname_0 = person_0.surname()
    assert surname_0 == 'Петров'
    person_0.seed(123)
    surname_1 = person_0.surname('male')
    assert surname_1 == 'Петров'
    person_0.seed(123)
    surname_2 = person_0.surname(Person.Gender.Male)
    assert surname_2 == 'Петров'
    person_0.seed(123)
    surname_3 = person_0.surname(title_type=Person.TitleType.Suffix)

# Generated at 2022-06-25 21:10:24.265671
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

    nationality_0 = person_0.nationality()

    assert nationality_0 in NATIONALITIES


# Generated at 2022-06-25 21:10:34.412363
# Unit test for method nationality of class Person
def test_Person_nationality():
    Person._data['nationality']=('Слон','Лев','Лошадь','Волк','Заяц','Бородач','Тигр','Собака')
    person_1 = Person()
    assert 17<=person_1.nationality().count(' ')<=25
    assert person_1.nationality() not in ('Слон','Лев','Лошадь','Волк','Заяц','Бородач','Тигр','Собака')

#Unit test for method full_name of class Person

# Generated at 2022-06-25 21:10:35.806890
# Unit test for method surname of class Person
def test_Person_surname():
    """Test method surname."""
    person_0 = Person()
    assert isinstance(person_0.surname(), str)


# Generated at 2022-06-25 21:10:37.121708
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)


# Generated at 2022-06-25 21:10:48.770652
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    person_0 = Person()

    # Act
    nationality_0 = person_0.nationality()

    # Assert

# Generated at 2022-06-25 21:10:50.010621
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert(isinstance(person.nationality(), str))


# Generated at 2022-06-25 21:11:09.736519
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality = person_0.nationality()
    print('The nationality is:', nationality)


# Generated at 2022-06-25 21:11:15.795049
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    # Test result

# Generated at 2022-06-25 21:11:18.353604
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert person_0.email() == 'r.ybarra@gmail.com', \
        "Failed test_Person_email"


# Generated at 2022-06-25 21:11:25.476108
# Unit test for method email of class Person
def test_Person_email():
    cases_0 = [('abd@gmail.com', 'abd', 'gmail.com', None)]
    person_0 = Person()
    for case_0 in cases_0:
        emial_0 = person_0.email(case_0[1], case_0[2], case_0[3])
        assert(emial_0 == case_0[0])

if __name__ == '__main__':
    test_Person_email()

# Generated at 2022-06-25 21:11:30.131638
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert isinstance(person_1.nationality(Gender.Male), str)
    assert isinstance(person_1.nationality(Gender.Female), str)
    # Test for error-handling
    try:
        person_1.nationality(Gender.Both)
        assert False
    except NonEnumerableError:
        assert True


# Generated at 2022-06-25 21:11:40.158281
# Unit test for method nationality of class Person

# Generated at 2022-06-25 21:11:41.195604
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    person.Nationality()


# Generated at 2022-06-25 21:11:43.106560
# Unit test for method nationality of class Person
def test_Person_nationality():
    gender = Gender.MALE
    p = Person()
    p.nationality(gender)


# Generated at 2022-06-25 21:11:44.604501
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(50):
        nationality_0 = Person().nationality()
        assert nationality_0 in NATIONALITIES


# Generated at 2022-06-25 21:11:45.507850
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    p.nationality()


# Generated at 2022-06-25 21:12:16.770643
# Unit test for method username of class Person
def test_Person_username():
    from textwrap import dedent

    Person = get_class(MODULE_PATH, 'Person')

    person = Person()

    for _ in range(20):
        username = person.username()
        msg = "username={!r}".format(username)
        assert isinstance(username, str), msg

        num_l = len(re.findall(r'[a-z]', username))
        msg = "re.findall(r'[a-z]', {!r})={!r}".format(username, num_l)
        assert num_l > 0, msg

        num_U = len(re.findall(r'[A-Z]', username))
        msg = "re.findall(r'[A-Z]', {!r})={!r}".format(username, num_U)


# Generated at 2022-06-25 21:12:19.830047
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    str1 = p.nationality()
    assert type(str1) == str


# Generated at 2022-06-25 21:12:23.013563
# Unit test for method username of class Person
def test_Person_username():
    """Test case: username.

    Get the username.
    """
    person_0 = Person()
    username_0 = person_0.username()
    assert len(username_0) != 0
    all(c.isascii() for c in username_0)


# Generated at 2022-06-25 21:12:30.561802
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    try:
        person.surname('male')
    except NonEnumerableError:
        assert True
    assert person._validate_enum('male', Gender) == Gender.MALE
    assert person.surname(Gender.MALE) in person._data['surname']['male']
    assert person._validate_enum('both', Gender) == Gender.BOTH
    assert person.surname(Gender.BOTH) in person._data['surname']['both']
    assert person.surname() in (person._data['surname']['male'] + person._data['surname']['female'])
    person_0 = Person()

# Generated at 2022-06-25 21:12:34.167215
# Unit test for method email of class Person
def test_Person_email():
    Person_ = Person()

    EMAIL = 'xhong@example.com'

    # Test for method email of class Person
    assert (Person_.email() not in EMAIL)
    

# Generated at 2022-06-25 21:12:43.491574
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    print('\nCase 0:')
    print(person_0.email())
    print('\nCase 1:')
    print(person_0.email(['gmail.com']))
    domains = ['a.b', 'c.d', 'e.f']
    print('\nCase 2:')
    print(person_0.email(domains))
    print('\nCase 3:')
    print(person_0.email(unique=True))



# Generated at 2022-06-25 21:12:46.413053
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

    assert(person_0.nationality() in person_data['nationality'])


# Generated at 2022-06-25 21:12:49.542224
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    print("Nationality: ", nationality_0)
    

# Generated at 2022-06-25 21:13:02.377482
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname(Gender.MALE) in ['Иванов', 'Сидоров', 'Петров']
    assert person_0.surname(Gender.FEMALE) in ['Иванова', 'Сидорова', 'Петрова']
    assert person_0.surname() in ['Иванов', 'Иванова', 'Сидоров', 'Сидорова', 'Петров', 'Петрова']


# Generated at 2022-06-25 21:13:14.869422
# Unit test for method surname of class Person
def test_Person_surname():
    # Randomly chooses first name from data file
    person_0 = Person()
    print("Randomly chooses first name from data file : ", person_0.surname())
    print("Randomly chooses first name from data file : ", person_0.surname())

    # Randomly chooses first name from data file
    person_1 = Person()
    print("Randomly chooses first name from data file : ", person_1.surname())
    print("Randomly chooses first name from data file : ", person_1.surname())

    # Randomly chooses first name from data file
    person_2 = Person()
    print("Randomly chooses first name from data file : ", person_2.surname())
    print("Randomly chooses first name from data file : ", person_2.surname())

    # Randomly chooses first name from data file

# Generated at 2022-06-25 21:13:44.810846
# Unit test for method nationality of class Person
def test_Person_nationality():
    # TODO: Please write test cases for nationality().
    # TODO: Пожалуйста, напишите тесты для nationality().
    pass


# Generated at 2022-06-25 21:13:47.806478
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert isinstance(person_0.email(unique=True), str)


# Generated at 2022-06-25 21:13:52.870453
# Unit test for method surname of class Person
def test_Person_surname():
    # Create instance of class and get name
    person = Person()
    surname = person.surname()

    # Check description
    description = 'Return random surname'
    assert description == person.surname.__doc__, '\n' + description


# Generated at 2022-06-25 21:14:03.523846
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.seed(0)
    assert person_0.surname(Gender.MALE) == 'Горячев'
    assert person_0.surname(Gender.FEMALE) == 'Кучинская'
    assert person_0.last_name(Gender.MALE) == 'Горячев'
    assert person_0.last_name(Gender.FEMALE) == 'Кучинская'


# Generated at 2022-06-25 21:14:10.871412
# Unit test for method email of class Person
def test_Person_email():
    # Creates a variable person and assigns to it a new instance of Person
    person = Person()
    person.email()


# Generated at 2022-06-25 21:14:13.905392
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)
    print('\n', nationality)
    print('Test for the method nationality of Class Person - passed successfully.')


# Generated at 2022-06-25 21:14:16.690728
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    assert nationality_0 in NATIONALITIES


# Generated at 2022-06-25 21:14:20.841573
# Unit test for method surname of class Person
def test_Person_surname():
    person_obj = Person()
    surname_0 = person_obj.surname(Gender.MALE)
    assert surname_0 in PERSON_SURNAMES['male']


# Generated at 2022-06-25 21:14:24.176924
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person(seed=1)

    assert person_1.nationality() == "Russian"
    assert person_1.nationality(Gender.MALE) == "British"
    assert person_1.nationality(Gender.FEMALE) == "Taiwanese"


# Generated at 2022-06-25 21:14:30.177089
# Unit test for method email of class Person
def test_Person_email():
    # Create person
    person = Person()

    # Create email
    email = person.email()

    # Check that email is correct
    # Check email operation
    # assert email == person.email()
    assert len(email) > 5


# Generated at 2022-06-25 21:15:00.392025
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()
    person_0.surname(gender=Gender.FEMALE)
    person_0.surname(gender='female')


# Generated at 2022-06-25 21:15:03.202921
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()
    assert type(surname_0) is str
    assert isinstance(surname_0, str)


# Generated at 2022-06-25 21:15:08.495060
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality = person_0.nationality()
    assert nationality in person_0._data['nationality']


# Generated at 2022-06-25 21:15:14.163919
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Person.nationality() should return a string"""
    person_0 = Person()
    assert type(person_0.nationality()) == str

# Test case for class Person



# Generated at 2022-06-25 21:15:17.503146
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    surname_0 = person_0.surname()
    assert type(surname_0) == str



# Generated at 2022-06-25 21:15:23.525556
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    name = person_0.surname()
    assert type(name) == str
    assert len(name) > 0


# Generated at 2022-06-25 21:15:25.026048
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert (person_1.nationality() in ['Russian', 'English', 'French', 'German', 'Spanish'])


# Generated at 2022-06-25 21:15:29.280049
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in PERSON_NATIONALITY_LIST


# Generated at 2022-06-25 21:15:35.901492
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    surname = person.surname()
    assert surname in SURNAME

    surname = person.surname(gender=Gender.MALE)
    assert surname in SURNAME_MALE

    surname = person.surname(gender=Gender.FEMALE)
    assert surname in SURNAME_FEMALE

    surname = person.surname(gender=Gender.Androgynous)
    assert surname in SURNAME_ANDROGYNOUS


# Generated at 2022-06-25 21:15:39.746271
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    res_0 = person_0.nationality()
    assert res_0 in NATIONALITIES_NAMES
