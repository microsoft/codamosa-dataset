

# Generated at 2022-06-25 21:07:01.352159
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname(Gender.MALE)
    assert len(surname) > 0


# Generated at 2022-06-25 21:07:03.038018
# Unit test for method surname of class Person
def test_Person_surname():
    person_obj = Person()
    person_obj.surname(Gender.MALE)


# Generated at 2022-06-25 21:07:05.056208
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    for x in range(10):
        nationality = person.nationality()
        assert type(nationality) is str


# Generated at 2022-06-25 21:07:07.164011
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surnames = person.surname()

    # Assert field
    assert surnames


# Generated at 2022-06-25 21:07:10.996083
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    gender = Gender.MALE
    surname = person.surname(gender=gender)
    assert surname in person._data['surname']['male']


# Generated at 2022-06-25 21:07:19.943867
# Unit test for method surname of class Person
def test_Person_surname():
    # Case 1
    person_1 = Person()
    str_1 = person_1.surname()
    str_2 = person_1.surname(Gender.FEMALE)
    str_3 = person_1.surname(Gender.MALE)
    str_4 = person_1.last_name()
    str_5 = person_1.last_name(Gender.FEMALE)
    str_6 = person_1.last_name(Gender.MALE)
    # Case 2
    person_2 = Person()
    str_7 = person_2.surname()
    str_8 = person_2.surname(Gender.FEMALE)
    str_9 = person_2.surname(Gender.MALE)
    str_10 = person_2.last_name()


# Generated at 2022-06-25 21:07:21.306287
# Unit test for method surname of class Person
def test_Person_surname():
    person_test = Person()
    person_test.surname()


# Generated at 2022-06-25 21:07:26.502056
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()
    str_1 = person_0.nationality()
    str_2 = person_0.nationality()
    str_3 = person_0.nationality()
    str_4 = person_0.nationality()
    str_5 = person_0.nationality()
    assert str_0 != str_2 != str_4
    assert str_1 != str_3 != str_5


# Generated at 2022-06-25 21:07:27.983012
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.last_name()

# Generated at 2022-06-25 21:07:30.171155
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:07:40.946360
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    gender = Gender.FEMALE
    person.nationality(gender)


# Generated at 2022-06-25 21:07:42.783544
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    n = person_0.nationality()
    print(n)



# Generated at 2022-06-25 21:07:44.148863
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    print(person.surname())


# Generated at 2022-06-25 21:07:46.488248
# Unit test for method nationality of class Person
def test_Person_nationality():
    try:
        person_0 = Person()
        person_0.nationality()
    except Exception as e:
        pytest.fail("Unexpected exception occurred: " + str(e))

# Generated at 2022-06-25 21:07:49.960963
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0_nationality = person_0.nationality()
    assert type(person_0_nationality) == str, "Err: person_0_nationality is not of type str"


# Generated at 2022-06-25 21:07:52.444815
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert type(p.nationality()) is str


# Generated at 2022-06-25 21:07:55.059943
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()
    assert surname_0 ==  "O'Connor"


# Generated at 2022-06-25 21:07:57.569525
# Unit test for method nationality of class Person
def test_Person_nationality():
    unitTest = Person()
    for i in range(0, 500):
        nationality = unitTest.nationality()
        assert isinstance(nationality, str)


# Generated at 2022-06-25 21:08:07.357846
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

# Generated at 2022-06-25 21:08:10.969218
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname()
    assert person_0.surname('male')
    assert person_0.surname('female')
    assert person_0.surname(Person.Gender.male)
    assert person_0.surname(Person.Gender.female)


# Generated at 2022-06-25 21:08:25.280371
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    def test_case_0():
        surname_0 = person.surname(Gender.MALE)
        return surname_0
    def test_case_1():
        surname_1 = person.surname(Gender.FEMALE)
        return surname_1
    def test_case_2():
        surname_2 = person.surname(Gender.ANDROGYNOUS)
        return surname_2
    def test_case_3():
        surname_3 = person.surname()
        return surname_3
    def test_case_4():
        surname_4 = person.surname(Gender(person.random.randint(0, 2)))
        return surname_4

    print(test_case_0())
    print(test_case_1())

# Generated at 2022-06-25 21:08:25.993545
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()


# Generated at 2022-06-25 21:08:32.955587
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(locale='en')

# Generated at 2022-06-25 21:08:34.823549
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print('test_Person_nationality')
    n = person_0.nationality()
    assert n is not None


# Generated at 2022-06-25 21:08:36.469508
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    data_1 = person_1.nationality()
    assert data_1 in person_1.nationality


# Generated at 2022-06-25 21:08:43.385194
# Unit test for method surname of class Person
def test_Person_surname():
    import re
    person_0 = Person()

    # Test for method surname with no arguments 
    for _ in range(1000):
        surname_0 = person_0.surname()
        print(' «{}» '.format(surname_0), end='')

    print('\n\n')

    # Test for method surname with 1 argument 
    for _ in range(1000):
        surname_0 = person_0.surname(Gender.FEMALE)
        print(' «{}» '.format(surname_0), end='')


# Generated at 2022-06-25 21:08:45.448640
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0_result = person_0.nationality()
    assert person_0_result in NATIONALITY_LIST


# Generated at 2022-06-25 21:08:48.149962
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    for i in range(10):
        nation = person.nationality()
        assert isinstance(nation, str) and len(nation) > 0, 'Nationality must be a string and not empty.'


# Generated at 2022-06-25 21:08:50.954542
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    assert (person_0.surname() == person_0.surname())
    assert (person_0.surname() != person_0.surname())


# Generated at 2022-06-25 21:08:53.164172
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        person = Person()
        nationality = person.nationality()
        assert nationality in NATIONALITIES.keys()


# Generated at 2022-06-25 21:09:14.847551
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    nationalities_0 = ['Russian', 'English', 'German', 'French', 'Swahili', 'Mandarin', 'Japanese', 'Russian', 'English', 'German', 'French', 'Swahili']
    nationalities_1 = ['Russian', 'English', 'German', 'French', 'Swahili', 'Mandarin', 'Japanese', 'Russian', 'English', 'German', 'French', 'Swahili']
    nationalities_2 = ['Russian', 'English', 'German', 'French', 'Swahili', 'Mandarin', 'Japanese', 'Russian', 'English', 'German', 'French', 'Swahili']
    nationalities_3 = ['Russian', 'English', 'German', 'French', 'Swahili', 'Mandarin', 'Japanese', 'Russian', 'English', 'German', 'French', 'Swahili']

# Generated at 2022-06-25 21:09:16.817787
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    name = person.surname()
    assert (name in SURNAMES)


# Generated at 2022-06-25 21:09:18.481451
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert(person_0.surname() in PERSON_DATA['surname'])


# Generated at 2022-06-25 21:09:19.745015
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert isinstance(person_1.nationality(), str)


# Generated at 2022-06-25 21:09:23.481694
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    print(person_0.surname('female'))


# Generated at 2022-06-25 21:09:33.156263
# Unit test for method nationality of class Person
def test_Person_nationality():
    from random import Random

    rnd = Random()
    person_0 = Person(random=rnd)

    # Case 0
    rnd.seed(0)
    assert person_0.nationality() == 'Русский'
    assert person_0.nationality() == 'Украинский'
    assert person_0.nationality() == 'Английский'
    assert person_0.nationality() == 'Идиш'
    assert person_0.nationality() == 'Сербохорватский'
    assert person_0.nationality() == 'Белорусский'
    assert person_0.nationality

# Generated at 2022-06-25 21:09:39.961762
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    # Tests of isinstance
    assert isinstance(person_0.surname(), str)
    assert isinstance(person_0.surname(gender=Gender.FEMALE), str)
    assert isinstance(person_0.surname(gender=Gender.MALE), str)
    # Tests of length
    assert 1 <= len(person_0.surname()) <= 50
    assert 1 <= len(person_0.surname(gender=Gender.FEMALE)) <= 50
    assert 1 <= len(person_0.surname(gender=Gender.MALE)) <= 50


# Generated at 2022-06-25 21:09:43.687832
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    
    for i in range(10):
        print(person_0.nationality())


# Generated at 2022-06-25 21:09:45.046829
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()
    username_0 = person_0.username()


# Generated at 2022-06-25 21:09:48.884350
# Unit test for method email of class Person
def test_Person_email():
    person_1 = Person()
    assert person_1.email() == 'bqtpq1252@hotmail.com'
    assert person_1.email() == 'nnycghvg@hotmail.com'


# Generated at 2022-06-25 21:10:15.094350
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality(Gender.MALE)
    assert isinstance(nationality, str)



# Generated at 2022-06-25 21:10:24.373260
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    # Test integer
    result = person_0.email(domains=5)
    assert type(result) is str

    # Test float
    result = person_0.email(domains=5.5)
    assert type(result) is str

    # Test string
    result = person_0.email(domains='test')
    assert type(result) is str

    # Test None
    result = person_0.email(domains=None)
    assert type(result) is str

    # Test list
    result = person_0.email(domains=['test'])
    assert type(result) is str

    # Test tuple
    result = person_0.email(domains=('test',))
    assert type(result) is str

    # Test dict
    result = person_0

# Generated at 2022-06-25 21:10:27.929330
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(), str)


# Generated at 2022-06-25 21:10:29.878586
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    result = person_0.surname()
    assert type(result) == str


# Generated at 2022-06-25 21:10:31.572118
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    print(provider.email())


# Generated at 2022-06-25 21:10:33.416231
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=1)
    for _ in range(10):
        print(p.nationality())



# Generated at 2022-06-25 21:10:34.216421
# Unit test for method nationality of class Person
def test_Person_nationality():
    pass


# Generated at 2022-06-25 21:10:36.007075
# Unit test for method nationality of class Person
def test_Person_nationality():

    person_0 = Person()
    person_0.random.seed(1686)
    result = person_0.nationality()
    assert result == 'Bosnian'


# Generated at 2022-06-25 21:10:45.895070
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Code for testing without gender
    person_0 = Person()

    nationalities = person_0.nationality()
    assert (nationalities in NATIONALITIES)

    # Code for testing for gender with enum object
    person_1 = Person()
    gender = Gender.MALE

    nationality = person_1.nationality(gender=gender)
    assert (nationality in NATIONALITIES_MALE)

    # Code for testing for gender with string object
    person_2 = Person()
    gender = 'male'

    nationality = person_1.nationality(gender=gender)
    assert (nationality in NATIONALITIES_MALE)

    # Code for testing for gender with int object
    person_3 = Person()
    gender = 0

    nationality = person_1.nationality(gender=gender)

# Generated at 2022-06-25 21:10:50.022626
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)


# Generated at 2022-06-25 21:11:19.034227
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(gender = Gender.FEMALE), str)


# Generated at 2022-06-25 21:11:25.369265
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    # Test default surname
    assert person_1.surname() in SURNAMES
    # Test gender
    assert (person_1.surname(Gender.Male) in PERSON_NAMES['male'])
    assert (person_1.surname(Gender.Female) in PERSON_NAMES['female'])


# Generated at 2022-06-25 21:11:27.557608
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    temp = person_0.email()
    assert len(temp) > 0


# Generated at 2022-06-25 21:11:36.848799
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.random.seed(1)
    ans = person_0.nationality()
    assert ans == 'Albanian'
    ans = person_0.nationality()
    assert ans == 'Bulgarian'
    ans = person_0.nationality()
    assert ans == 'Cypriot'
    ans = person_0.nationality()
    assert ans == 'Portuguese'
    ans = person_0.nationality()
    assert ans == 'Swedish'
    ans = person_0.nationality()
    assert ans == 'Belgian'
    ans = person_0.nationality()
    assert ans == 'German'
    ans = person_0.nationality()
    assert ans == 'Turkish'
    ans = person_0.nationality()

# Generated at 2022-06-25 21:11:39.860663
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    nationality_1 = person_1.nationality()
    if type(nationality_1) == str:
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-25 21:11:41.195608
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert_that(isinstance(person_0.nationality(), str))


# Generated at 2022-06-25 21:11:47.042053
# Unit test for method surname of class Person
def test_Person_surname():
    # Number of tests to perform
    nb_tests = 100
    p = Person()
    for i in range(nb_tests):
        # Test any random gender
        gender = get_random_item(Gender, rnd=p.random)
        surname = p.surname(gender=gender)
        assert isinstance(surname, str)
        assert len(surname) != 0


# Generated at 2022-06-25 21:11:51.480072
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Creating an object "Person"
    pm = Person()
    # Getting nationality of one person
    nationality = pm.nationality()
    # Creating a list of nationalities
    list_of_nationalities = []
    list_of_nationalities.append(nationality)
    # Adding nationality of a person to list of nationalities
    for _ in range(9):
        nationality = pm.nationality()
        list_of_nationalities.append(nationality)
    # Printing list of nationalities
    print("List of nationalities:")
    for i in range(0,10):
        print(list_of_nationalities[i])


# Generated at 2022-06-25 21:11:54.121452
# Unit test for method surname of class Person
def test_Person_surname():
    # Create a random number generator using the seed 0
    rnd = Random(0)
    
    # Calculate the value of subject
    subject = Person(rnd).surname()

    # Check that subject equals the value expected
    assert subject == 'Иванов', 'Wrong value: {}'.format(subject)


# Generated at 2022-06-25 21:11:55.430815
# Unit test for method nationality of class Person
def test_Person_nationality():

    person_0 = Person()
    nationality_0 = person_0.nationality()

    assert nationality_0 in NATIONALITIES


# Generated at 2022-06-25 21:12:51.838212
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    username = person.username()
    assert isinstance(username, str)
    assert username[0].isupper()
    assert len(username) >= 3


# Generated at 2022-06-25 21:13:03.572374
# Unit test for method email of class Person
def test_Person_email():
    test_email_0, test_email_1, test_email_2, test_email_3, test_email_4 = None, None, None, None, None

    # Call method email of class Person
    test_email_0 = Person().email()

    # Call method email of class Person
    test_email_1 = Person().email(domains=['gmail.com', 'mail.ru'])

    # Call method email of class Person
    test_email_2 = Person().email(unique=True)

    # Call method email of class Person
    test_email_3 = Person().email(unique=False)

    # Call method email of class Person
    test_email_4 = Person().email(unique=False, domains=['gmail.com', 'mail.ru'])


# Generated at 2022-06-25 21:13:09.361613
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    result_returned = person_0.email()
    if '@' not in result_returned:
        raise ValueError("Output displayed is not a valid email address")


# Generated at 2022-06-25 21:13:13.048820
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()

    nationalities = person._data['nationality']

    nationality = person.nationality()

    assert nationality in nationalities, 'Not correct nationality'


# Generated at 2022-06-25 21:13:24.271589
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(42)
    nationality_0 = person_0.nationality()
    assert nationality_0 == "Belarusian"

    person_1 = Person(0)
    nationality_1 = person_1.nationality()
    assert nationality_1 == "Korean"

    person_2 = Person()
    nationality_2 = person_2.nationality()
    assert nationality_2 == 'Singaporean'

    person_3 = Person()
    nationality_3 = person_3.nationality()
    assert nationality_3 == 'Icelandic'

    person_4 = Person()
    nationality_4 = person_4.nationality()
    assert nationality_4 == 'Israeli'


# Generated at 2022-06-25 21:13:28.547920
# Unit test for method surname of class Person
def test_Person_surname():
    with pytest.raises(TypeError):
        person = Person(None)
        person.surname()


# Generated at 2022-06-25 21:13:30.338216
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    person.nationality()


# Generated at 2022-06-25 21:13:42.187694
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    gender_0 = Gender.Female
    person_0.surname(gender_0)
    # Test exception
    # Exception raised: NonEnumerableError Class: NonEnumerableError
    # Method: _validate_enum File: random_data_generator.py Message: TitleType
    title_type_0 = TitleType.Affix
    gender_1 = Gender.Female
    person_0.title(gender_1, title_type_0)
    # Test exception
    # Exception raised: NonEnumerableError Class: NonEnumerableError
    # Method: _validate_enum File: random_data_generator.py Message: Gender
    person_0.name(0)


# Generated at 2022-06-25 21:13:44.546569
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test case #0
    person_0 = Person()
    assert person_0.nationality() in NATIONALITY


# Generated at 2022-06-25 21:13:49.368620
# Unit test for method surname of class Person
def test_Person_surname():

    def test_surname_0():
        person_surname = Person().surname()
        assert type(person_surname) == str

    test_surname_0()


# Generated at 2022-06-25 21:15:27.932604
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITIES


# Generated at 2022-06-25 21:15:34.549500
# Unit test for method username of class Person
def test_Person_username():
    rnd_test = random.Random()
    rnd_test.seed(1)

    person_0 = Person(rnd_test)

    expected_result = 'a.41'
    result = person_0.username(template='l.d')

    assert result == expected_result
    


# Generated at 2022-06-25 21:15:38.944572
# Unit test for method surname of class Person
def test_Person_surname():
    # Test 1
    person_1 = Person()
    result = person_1.surname()
    assert isinstance(result, str)
    
    

# Generated at 2022-06-25 21:15:41.361258
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surnames = person.surname()
    assert surnames is not None


# Generated at 2022-06-25 21:15:44.728015
# Unit test for method nationality of class Person
def test_Person_nationality():
    person0 = Person(random = Random(seed = 1))
    nationalities = person0.nationality()
    assert(nationalities == 'Portuguese') 


# Generated at 2022-06-25 21:15:48.849210
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-25 21:15:56.302006
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)
    assert isinstance(person_0.surname(Gender.MALE), str)
    assert isinstance(person_0.surname(Gender.FEMALE), str)


# Generated at 2022-06-25 21:15:57.654297
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert type(person_0.surname()) == str


# Generated at 2022-06-25 21:16:08.936012
# Unit test for method nationality of class Person
def test_Person_nationality():
    # array of the method's results
    arr = []
    # create class object
    person_0 = Person()
    # call method by loop
    for i in range(5):
        # store method's result
        result = person_0.nationality()
        # if result not in array of results
        if not result in arr:
            # add result to array
            arr.append(result)
        else:
            # return False and text message
            return False, "Some nationalities repeat"
    # if all of the results are unique
    # return True and text message
    return True, "The method return unique nationalities"
