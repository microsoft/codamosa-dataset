

# Generated at 2022-06-25 21:06:37.460153
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in person_0._data['nationality']
    assert person_0.nationality(gender=Gender.MALE) in person_0._data['nationality']['m']
    assert person_0.nationality(gender=Gender.FEMALE) in person_0._data['nationality']['f']


# Generated at 2022-06-25 21:06:39.480401
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert isinstance(person_1.nationality(), str)


# Generated at 2022-06-25 21:06:41.646051
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surnames = person_0.surname()
    assert len(surnames) > 0


# Generated at 2022-06-25 21:06:44.702025
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    try:
        person_0.surname()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 21:06:50.212196
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    unique = False
    domains = ('ya.ru', 'yandex.ru', 'yandex.ua', 'yandex.by', 'yandex.kz', 'yandex.com')
    email_0 = person_0.email(domains, unique)

    assert email_0 == 'rofert.1990@yandex.com'


# Generated at 2022-06-25 21:06:53.842299
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert callable(person.nationality) == True
    assert type(person.nationality()) == str


# Generated at 2022-06-25 21:07:04.744727
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_7 = Person()
    person_8 = Person()
    person_9 = Person()
    person_10 = Person()
    person_11 = Person()
    person_12 = Person()
    person_13 = Person()
    person_14 = Person()
    person_15 = Person()
    person_16 = Person()
    person_17 = Person()
    person_18 = Person()
    person_19 = Person()
    person_20 = Person()
    person_21 = Person()
    person_22 = Person()
    person_23 = Person()
    person_24 = Person()

# Generated at 2022-06-25 21:07:07.205833
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person(seed=0)
    assert person_0.email() == "eubanks.cristina@pm.me"


# Generated at 2022-06-25 21:07:10.004983
# Unit test for method surname of class Person
def test_Person_surname():
    new_gen = Person()
    assert isinstance(new_gen.surname(), str)


# Generated at 2022-06-25 21:07:12.349203
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    if person.surname() in person._data['surname']:
        print('Pass')
    else:
        print('Fail')


# Generated at 2022-06-25 21:07:31.106516
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    assert(type(person_1.surname()) == str)


# Generated at 2022-06-25 21:07:42.115229
# Unit test for method surname of class Person
def test_Person_surname():
    # test the method when both of the parameters are None
    person_0 = Person()
    surname_0 = person_0.surname()
    assert type(surname_0) is str
    assert len(surname_0) is not 0

    # test the method when the gender parameter is None
    person_1 = Person()
    surnames = person_1._data['surname']
    keys = set(surnames.keys())
    expected_result = set(('male', 'female', 'neutral'))
    assert keys == expected_result
    surname_1 = person_1.surname(gender=Gender.MALE)
    assert type(surname_1) is str
    assert len(surname_1) is not 0

    # test the method when the surname parameter is None
    person_2

# Generated at 2022-06-25 21:07:48.087149
# Unit test for method surname of class Person
def test_Person_surname():
    from termcolor import colored
    test_set_0 = {
        "gender" : Gender.MALE,
        "expected" : "Lee"
    }
    person_0 = Person()
    actual = person_0.surname(test_set_0["gender"])
    passed = actual == test_set_0["expected"]
    if not passed:
        print(colored("Failed!", "red"))
    else:
        print(colored("Passed!", "green"))


# Generated at 2022-06-25 21:07:49.604212
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()


# Generated at 2022-06-25 21:07:54.053293
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    print('')
    print('test_Person_surname')
    surname = person_0.surname()
    print('surname = {}'.format(surname))


# Generated at 2022-06-25 21:07:59.661334
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Create an instance of class Person
    person = Person()

    # Generate 1 random nationality.
    nationality = person.nationality()
    assert isinstance(nationality, str)

    # Generate 100 random nationalities.
    nationality = person.nationality()
    assert isinstance(nationality, str)

    # Generate 10000 random nationalities.
    nationality = person.nationality()
    assert isinstance(nationality, str)


# Generated at 2022-06-25 21:08:02.878623
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person(random=Random())
    assert person_0.surname() in SURNAMES
    assert person_0.random.choice(SURNAMES) in SURNAMES


# Generated at 2022-06-25 21:08:04.966888
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    for _ in range(100):
        person_0.surname()


# Generated at 2022-06-25 21:08:06.987608
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surnames = person_0.surname()
    assert surnames in PERSON_SURNAME


# Generated at 2022-06-25 21:08:13.341104
# Unit test for method nationality of class Person
def test_Person_nationality():
    from random import seed
    from faker import Faker
    from faker_nano.person import Gender, Nationality
    from faker_nano.utils import get_random_item
    seed(0)
    fake = Faker()
    fake_ = Faker(person=None)
    fake_ = Faker(person=Person())
    fake_ = Faker(fake=fake)
    fake_ = Faker(seed=0)
    fake_ = Faker(person=Person(), fake=fake)
    fake_ = Faker(person=Person(), seed=0)
    fake_ = Faker(fake=fake, seed=0)
    fake_ = Faker(person=Person(), fake=fake, seed=0)
    fake_ = Faker(locales=['test'])

# Generated at 2022-06-25 21:08:56.062016
# Unit test for method surname of class Person
def test_Person_surname():
    gen = Person(seed=270145)
    assert gen.surname(gender=Gender.MAN) == "Зайцев"
    gen = Person(seed=270145)
    assert gen.surname(gender=Gender.WOMAN) == "Улитина"
    assert gen.surname() == "Улитина"
    gen = Person(seed=270145)
    assert gen.surname(gender=Gender.NOT_APPLICABLE) == "Баранов"
    assert gen.surname() == "Баранов"
    assert gen.surname(gender=None) == "Баранов"
    gen = Person(seed=270145)

# Generated at 2022-06-25 21:09:04.393790
# Unit test for method email of class Person
def test_Person_email():
    from random import Random
    from faker import Faker
    from faker.providers.person.it_IT import Provider as PersonProvider
    from string import ascii_letters, digits, punctuation

    fake = Faker(version='2.0.0', providers=[PersonProvider], random=Random())
    fake.add_provider(PersonProvider)

    domains = [
        'abc.com',
        'acme.inc',
        'acs.inc',
        'acu.edu',
        'acu.ac.uk',
        'acu.edu.au',
        'acu.edu.ng'
    ]

    flag_0 = True

    for _ in range(100):
        _email = fake.email(domains=domains)

        _name, _domain = _email.split('@')
       

# Generated at 2022-06-25 21:09:05.760773
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(), str)


# Generated at 2022-06-25 21:09:09.311468
# Unit test for method nationality of class Person
def test_Person_nationality():

    # Instantiate class
    person_0 = Person()

    # Perform test
    nationalities_0 = [
        person_0.nationality() for _ in range(1000)
    ]

    # Assertion
    assert all([
        nationality in nationalities
        for nationality in nationalities_0
    ])


# Generated at 2022-06-25 21:09:19.333572
# Unit test for method nationality of class Person
def test_Person_nationality():
    # test0
    # Default
    person = Person()
    nationality = person.nationality()
    assert(isinstance(nationality, str))

    # test1
    # Russian
    person = Person()
    nationality = person.nationality(Gender.Male)
    assert(isinstance(nationality, str))
    assert(nationality == 'Russian')

    # test2
    # Russian
    person = Person()
    nationality = person.nationality(Gender.Female)
    assert(isinstance(nationality, str))
    assert(nationality == 'Russian')

    # test3
    # Russian
    person = Person()
    nationality = person.nationality(Gender.Androgynous)
    assert(isinstance(nationality, str))
    assert(nationality == 'Russian')

    # test4
    # Russian
   

# Generated at 2022-06-25 21:09:24.011351
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_0_ = person_0.email()
    print("person_0_ = ", person_0_)
    assert isinstance(person_0_, str)


# Generated at 2022-06-25 21:09:26.465428
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    data_0 = person_0.surname()
    print(data_0) # Martin


# Generated at 2022-06-25 21:09:28.652753
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    try:
        provider.nationality(gender='Male')
    except NonEnumerableError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 21:09:38.398890
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() == "Korean"
    assert person_0.nationality() == "Russian"
    assert person_0.nationality() == "Russian"
    assert person_0.nationality() == "Irish"
    assert person_0.nationality() == "Dutch"
    assert person_0.nationality() == "Russian"
    assert person_0.nationality() == "Croatian"
    assert person_0.nationality() == "Filipino"
    assert person_0.nationality() == "Hungarian"
    assert person_0.nationality() == "Chinese"
    assert person_0.nationality() == "Thai"
    assert person_0.nationality() == "Chinese"
    assert person_0.nationality() == "Croatian"


# Generated at 2022-06-25 21:09:40.179779
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    try:
        person_0.email()
    except Exception:
        assert False
