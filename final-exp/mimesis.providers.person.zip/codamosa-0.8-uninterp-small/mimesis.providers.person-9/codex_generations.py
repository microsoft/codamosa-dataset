

# Generated at 2022-06-25 21:06:29.068769
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() == "Georgian"


# Generated at 2022-06-25 21:06:30.936769
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert(isinstance(person_0.nationality(), str))


# Generated at 2022-06-25 21:06:34.342668
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality = person_0.nationality()
    assert nationality in person_0._data['nationality']


# Generated at 2022-06-25 21:06:36.864840
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationality_0 = Person().nationality()
    # Nationality should be in list names
    assert bool(nationality_0 in NAMES) == True


# Generated at 2022-06-25 21:06:39.745080
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationalities = person_0.nationality()
    print("nationality = " + str(nationalities))
    return 0


# Generated at 2022-06-25 21:06:41.067526
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:06:44.249946
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    print('>>>')
    print('nationality: ', nationality_0)


# Generated at 2022-06-25 21:06:48.558695
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality(Gender.UNKNOWN) in person_0._data['nationality']
    assert person_0.nationality(Gender.MALE) in person_0._data['nationality']['male']
    assert person_0.nationality(Gender.FEMALE) in person_0._data['nationality']['female']


# Generated at 2022-06-25 21:06:49.899568
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    print(person.nationality())


# Generated at 2022-06-25 21:06:58.262985
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_1.surname()
    person_2.surname()
    person_3.surname()
    person_4.surname()
    person_5.surname()
    person_6.surname()


# Generated at 2022-06-25 21:07:10.575608
# Unit test for method nationality of class Person
def test_Person_nationality():

    person = Person()
    nationality = person.nationality()
    assert nationality in NATIONALITIES

    person = Person(native=True)
    nationality = person.nationality()
    assert nationality in NATIONALITIES_NATIVE


# Generated at 2022-06-25 21:07:17.519340
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    char_0 = p.surname()
    char_1 = p.surname(gender=Gender.MALE)
    char_2 = p.surname(gender=Gender.FEMALE)
    char_3 = p.surname(gender=Gender.UNISEX)
    print('[INFO] char_0: {0}\n[INFO] char_1: {1}\n[INFO] char_2: {2}\n[INFO] char_3: {3}\n'.format(char_0, char_1, char_2, char_3))


# Generated at 2022-06-25 21:07:19.117715
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-25 21:07:22.154608
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    try:
        surname_0 = person_0.surname()
    except Exception as e:
        print('{}: {}'.format(type(e).__name__, str(e)))


# Generated at 2022-06-25 21:07:24.716874
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    surname_0 = person_1.surname(gender=Gender.male)
    surname_1 = person_1.surname(gender=Gender.female)
    

# Generated at 2022-06-25 21:07:26.338850
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality(Gender.MALE), isinstance(str)


# Generated at 2022-06-25 21:07:28.519162
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_result = person_0.surname()
    assert surname_result in Person.load_names('ru', 'surnames')


# Generated at 2022-06-25 21:07:36.560385
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0_nationality = person_0.nationality()
    print(f'person_0_nationality = {person_0_nationality}')
    person_1 = Person()
    person_1_nationality = person_1.nationality()
    print(f'person_1_nationality = {person_1_nationality}')
    assert person_1_nationality != person_0_nationality


# Generated at 2022-06-25 21:07:40.082045
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test for get nationality for male
    person_0 = Person()
    assert person_0.nationality(Gender.MALE)=="russian"
    # Test for get nationality for female
    assert person_0.nationality(Gender.FEMALE)=="russian"


# Generated at 2022-06-25 21:07:41.628450
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in ENGLISH_NAMES


# Generated at 2022-06-25 21:08:02.544231
# Unit test for method nationality of class Person
def test_Person_nationality():
    for index in range(10):
        person_0 = Person()
        nationality_0 = person_0.nationality()
        assert type(nationality_0) == str
        assert len(nationality_0) > 0


# Generated at 2022-06-25 21:08:08.385563
# Unit test for method nationality of class Person
def test_Person_nationality():
    countries = ['Russian', 'Ukrainian', 'Latvian', 'Lithuanian', 'Estonian', 'Belarusian']
    for i in range(50):
        p0 = Person()
        national = p0.nationality()
        if False == (national in countries):
            print("Fail : Person.nationality() -> [actual: %s]\n" % national)
        else:
            print("Pass : Person.nationality() -> [actual: %s]\n" % national)


# Generated at 2022-06-25 21:08:12.277687
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    val_0 = person_0.nationality()
    print(val_0)
    val_1 = person_0.nationality(gender=Gender.MALE)
    print(val_1)
    val_2 = person_0.nationality(gender=Gender.FEMALE)
    print(val_2)


# Generated at 2022-06-25 21:08:14.200918
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(0,1000):
        surname = Person().surname()
        assert(surname)
        assert(isinstance(surname, str))


# Generated at 2022-06-25 21:08:16.272732
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality(gender=Gender.male)
    person_0.nationality(gender=Gender.female)


# Generated at 2022-06-25 21:08:19.483742
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality(Gender.MALE)
    nationality_1 = person_0.nationality()
    nationality_2 = person_0.nationality(Gender.FEMALE)
    pass


# Generated at 2022-06-25 21:08:21.435725
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    username = person.username(template='ld')
    assert isinstance(username, str)


# Generated at 2022-06-25 21:08:23.616214
# Unit test for method surname of class Person
def test_Person_surname():
    # Create an instance of class Person
    person_0 = Person()
    for _ in range(1000):
        person_0.surname()


# Generated at 2022-06-25 21:08:25.278931
# Unit test for method surname of class Person
def test_Person_surname():

    person_0 = Person()
    res = person_0.surname()
    assert(type(res) == str)


# Generated at 2022-06-25 21:08:26.963502
# Unit test for method nationality of class Person
def test_Person_nationality():
    rnd = Random()
    person_0 = Person(rnd)
    assert isinstance(person_0.nationality(), str)
