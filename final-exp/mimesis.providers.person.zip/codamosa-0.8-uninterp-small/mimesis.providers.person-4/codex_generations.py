

# Generated at 2022-06-25 21:06:27.913188
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname(Gender.male)


# Generated at 2022-06-25 21:06:29.860160
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_0.email()


# Generated at 2022-06-25 21:06:39.744908
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test 1
    person_1 = Person()
    nationality_1 = person_1.nationality(Gender.FEMALE)
    assert nationality_1 in ('українка', 'білоруска', 'білорус')

    # Test 2
    gender_2 = Gender.FEMALE
    person_2 = Person()
    nationality_2 = person_2.nationality(gender_2)
    assert nationality_2 in ('українка', 'білоруска', 'білорус')


# Generated at 2022-06-25 21:06:43.960991
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_0.seed(12345678)
    expected_value = 'gjjkwzc@facebook.com'
    actual_value = person_0.email()
    assert(actual_value == expected_value)


# Generated at 2022-06-25 21:06:46.254951
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    print(person_0.surname())
    print(person_0.last_name())


# Generated at 2022-06-25 21:06:49.766096
# Unit test for method surname of class Person
def test_Person_surname():
    rnd = Random()
    Person.random = rnd
    gender = Gender.MALE
    surname = Person.surname(gender=gender)
    assert surname in Person_Data['surname'][gender], "Not found"


# Generated at 2022-06-25 21:06:54.695605
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    person04 = Person(seed=123)

    assert person.surname() == 'Иванов'
    assert person04.surname() == 'Иванова'


# Generated at 2022-06-25 21:06:59.499239
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname(None) in SURNAME_LAST_NAMES
    assert person_0.surname(Gender.male) in SURNAME_MEN
    assert person_0.surname(Gender.female) in SURNAME_WOMEN



# Generated at 2022-06-25 21:07:01.164899
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()


# Generated at 2022-06-25 21:07:04.267179
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    # Test if method surname returns a string
    if not isinstance(person_0.surname(), str):
        raise TypeError("Method surname of class Person does not return a string")


# Generated at 2022-06-25 21:07:25.090235
# Unit test for method surname of class Person
def test_Person_surname():
    test_cases = [
        {'gender': None, 'surnames': None},
        {'gender': 'MALE', 'surnames': None},
        {'gender': 'FEMALE', 'surnames': None},
    ]

    for case in test_cases:
        person_1 = Person()
        surname_1 = person_1.surname(**case)
        surname_2 = person_1.surname(**case)
        surname_3 = person_1.surname(**case)
        assert_not_equal(surname_1, surname_2)
        assert_not_equal(surname_2, surname_3)

    surnames_male = ('Garcia', 'Martinez', 'Gonzalez', 'Lopez')

# Generated at 2022-06-25 21:07:31.514566
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()

    nationalities = ["Irish", "Macedonian", "Tajik", "Afghan", "Armenian"]
    assert person_0.nationality() in nationalities
    assert person_1.nationality() in nationalities
    assert person_2.nationality() in nationalities
    assert person_3.nationality() in nationalities
    assert person_4.nationality() in nationalities



# Generated at 2022-06-25 21:07:42.470416
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.random.seed(0)
    assert person_0.surname() == 'Батурин'
    assert person_0.surname() == 'Держаков'
    assert person_0.surname() == 'Азарова'
    assert person_0.surname() == 'Сахнова'
    assert person_0.surname() == 'Захаров'
    assert person_0.surname() == 'Сагайдачник'
    assert person_0.surname() == 'Кузьменко'
    assert person_0.surname()

# Generated at 2022-06-25 21:07:44.148799
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert str == type(person_0.surname())


# Generated at 2022-06-25 21:07:45.473758
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in PERSON_NATIONALITY


# Generated at 2022-06-25 21:07:54.881352
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test for method nationality of class Person
    person_1 = Person()
    person_2 = Person(data_provider='es')
    person_3 = Person(gender=Gender.FEMALE)
    person_4 = Person(gender=Gender.FEMALE, data_provider='es')
    nationality_0 = person_1.nationality()
    nationality_1 = person_2.nationality()
    nationality_2 = person_3.nationality()
    nationality_3 = person_4.nationality()
    print(nationality_0)
    print(nationality_1)
    print(nationality_2)
    print(nationality_3)


# Generated at 2022-06-25 21:07:58.597483
# Unit test for method email of class Person
def test_Person_email():
    # тестовый случай для метода email класса Person
    person = Person()
    assert person.email() == 'punchy@yahoo.com'


# Generated at 2022-06-25 21:08:03.343483
# Unit test for method username of class Person
def test_Person_username():
    person_1 = Person()
    assert isinstance(person_1.username(), str), 'The method returns not a str'

if __name__ == '__main__':
    test_case_0()
    test_Person_username()
    print('All tests are successful')

# Test case using unittest
import unittest


# Generated at 2022-06-25 21:08:04.657510
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    person.surname()
    person.surname(gender=Gender.female)
    person.surname(gender=Gender.male)


# Generated at 2022-06-25 21:08:07.357332
# Unit test for method nationality of class Person
def test_Person_nationality():
    rnd_val = random.choice([None,'0'])
    random_Person = Person()
    assert random_Person.nationality(gender=rnd_val) in NATIONALITIES



# Generated at 2022-06-25 21:08:27.800729
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-25 21:08:33.308522
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Case 0
    person_0 = Person('en_US')
    actual_result_0 = person_0.nationality()

# Generated at 2022-06-25 21:08:34.642764
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-25 21:08:36.066701
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print(person_0.nationality())
# %%


# Generated at 2022-06-25 21:08:38.007726
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person
    person_0.nationality()


# Generated at 2022-06-25 21:08:39.059453
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality is not None


# Generated at 2022-06-25 21:08:45.546680
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_dict = {
        Gender.MALE: 'Russian',
        Gender.FEMALE: 'Russian'
    }
    person_0 = Person()
    person_1 = Person(nationality=person_dict)
    for i in range(100):
        assert person_0.nationality(Gender.MALE) == 'Russian'
        assert person_1.nationality(Gender.MALE) == 'Russian'
        assert person_0.nationality(Gender.FEMALE) == 'Russian'
        assert person_1.nationality(Gender.FEMALE) == 'Russian'



# Generated at 2022-06-25 21:08:48.039967
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    for i in range(1):
        surname_0 = person_0.surname()
        assert(isinstance(surname_0,str))


# Generated at 2022-06-25 21:08:51.916553
# Unit test for method nationality of class Person
def test_Person_nationality():
    print("----------- test case for method nationality of class Person ----------")
    person_0 = Person()
    print(person_0.nationality())
    print(person_0.nationality(gender = Gender.MALE))
    print(person_0.nationality(gender = Gender.FEMALE))


# Generated at 2022-06-25 21:08:55.399872
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()

    assert isinstance(nationality, str)
    assert re.fullmatch(r'[A-Z][a-z]+', nationality)


# Generated at 2022-06-25 21:09:49.183076
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    test_result_0 = person_0.surname()
    test_result_1 = person_0.surname(
        gender=Gender.MALE)
    test_result_2 = person_0.surname(
        gender=Gender.FEMALE)


# Generated at 2022-06-25 21:09:57.709581
# Unit test for method surname of class Person
def test_Person_surname():
    # test 1: general case
    person_0 = Person()
    gender_0 = Gender.MALE
    surname_0 = person_0.surname(gender_0)
    assert(isinstance(surname_0, str))

    # test 2: general case
    person_0 = Person()
    gender_0 = Gender.FEMALE
    surname_0 = person_0.surname(gender_0)
    assert(isinstance(surname_0, str))

    # test 3: general case
    person_0 = Person()
    surname_0 = person_0.surname()
    assert(isinstance(surname_0, str))


# Generated at 2022-06-25 21:10:00.007898
# Unit test for method nationality of class Person
def test_Person_nationality():
    # person_0 = Person()
    person_0 = Person()
    person_0.nationality(None)
    person_0.nationality(Gender.MALE)
    person_0.nationality(Gender.FEMALE)


# Generated at 2022-06-25 21:10:04.668462
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    surnames_1 = person_1.surname()
    assert surnames_1 != surnames_1.upper()
    assert surnames_1 != surnames_1.capitalize()


# Generated at 2022-06-25 21:10:09.488890
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname(Gender.male)
    person_0.surname(Gender.female)
    person_0.surname(Gender.other)
    person_0.surname()


# Generated at 2022-06-25 21:10:11.022021
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(), str)

# Test for method gender of class Person

# Generated at 2022-06-25 21:10:13.932889
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    # check input must be optional
    assert person_0.surname() is not None


# Generated at 2022-06-25 21:10:17.711831
# Unit test for method surname of class Person
def test_Person_surname():
    _data = load_data('person')
    surnames = _data['surnames']
    surnames = [surname for _, surname in surnames.items()]
    surnames = set(itertools.chain(*surnames))

    provider = Person()

    for i in range(10):
        surname = provider.surname()
        assert surname in surnames


# Generated at 2022-06-25 21:10:28.654871
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.seed(0)

    # Test 1
    assert person_0.surname() == 'White'

    # Test 2
    assert person_0.surname() == 'Stone'

    # Test 3
    person_0.seed(0)
    assert person_0.surname() == 'White'

    # Test 4
    person_0.seed(0)
    person_0.random.random()
    assert person_0.surname() == 'Stone'

    # Test 5
    assert person_0.surname(Gender.MALE) == 'Stone'

    # Test 6
    assert person_0.surname(Gender.FEMALE) == 'White'


# Generated at 2022-06-25 21:10:29.843163
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-25 21:11:15.611185
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert (isinstance(person.nationality(), str) == True)


# Generated at 2022-06-25 21:11:27.326950
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.random._seed(1)
    assert person_0.surname(Person.Gender.Male) == 'Bruhn'
    assert person_0.surname(Person.Gender.Female) == 'Schulze'
    assert person_0.surname(Person.Gender.Female) == 'Dittmann'
    assert person_0.surname(Person.Gender.Male) == 'Wolff'
    assert person_0.surname(Person.Gender.Male) == 'Ochs'
    assert person_0.surname(Person.Gender.Female) == 'Bruhn'
    assert person_0.surname(Person.Gender.Female) == 'Schulze'

# Generated at 2022-06-25 21:11:30.042904
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)
    assert len(person_0.surname()) >= 2
    assert person_0.surname().isalpha()


# Generated at 2022-06-25 21:11:39.785443
# Unit test for method nationality of class Person
def test_Person_nationality():

    # birth_date: Optional[str] = None,
    #     age: Optional[int] = None,
    #     gender: Optional[Gender] = None,
    #     country: Optional[str] = None,
    #     region: Optional[str] = None,
    #     city: Optional[str] = None,
    #     street_name: bool = False,
    #     street_address: bool = False,
    #     latitude: Optional[float] = None,
    #     longitude: Optional[float] = None,
    #     seed: Optional[int] = None,
    #     random: Optional[Random] = None) -> None:
    person_0 = Person()
    assert isinstance(person_0.nationality(), str) == True



# Generated at 2022-06-25 21:11:40.874502
# Unit test for method surname of class Person
def test_Person_surname():
    surname_0 = Person().surname()



# Generated at 2022-06-25 21:11:47.071199
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Generate 10 nationalities with default gender
    # and each element must be in list with nationalities
    for _ in range(10):
        assert person_0._data['nationality'][Generate.random.choice(list(Gender)).value].count(person_0.nationality()) >= 1
        # Generate 10 nationalities with unknown gender
        # and each element must be in list with nationalities
        assert person_0._data['nationality'][Generate.random.choice(list(Gender)).value].count(person_0.nationality(Gender.UNKNOWN)) >= 1
        # Generate 10 nationalities with male gender
        # and each element must be in list with nationalities
        assert person_0._data['nationality'][Generate.random.choice(list(Gender)).value].count(person_0.nationality(Gender.MALE))

# Generated at 2022-06-25 21:11:48.484969
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname(Gender.MALE)
    return surname_0


# Generated at 2022-06-25 21:11:49.769151
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    res_0 = person_0.surname()
    assert res_0


# Generated at 2022-06-25 21:11:52.938388
# Unit test for method surname of class Person
def test_Person_surname():
    print(">> Testing method surname of class Person")
    person_0 = Person()
    # testing the class method surname
    assert(type(person_0.surname()) == str)
    # testing the class method surname with gender
    assert(type(person_0.surname(gender=Gender.MALE)) == str)
    assert(type(person_0.surname(gender=Gender.FEMALE)) == str)


# Generated at 2022-06-25 21:11:55.587390
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for default parameters
    assert type(Person().surname()) == str
    # Test for specifying parameters
    assert Person().surname(Gender.MALE) == Person().surname(Gender.MALE)
    assert Person().surname(Gender.FEMALE) == Person().surname(Gender.FEMALE)


# Generated at 2022-06-25 21:12:40.470462
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    gender_0 = Gender.MALE
    with pytest.raises(NonEnumerableError):
        person_0.nationality(gender_0)


# Generated at 2022-06-25 21:12:43.520668
# Unit test for method email of class Person
def test_Person_email():
  email_result = Person().email()
  assert email_result.__contains__('@')
  assert email_result.split('@')[1].__contains__('.')


# Generated at 2022-06-25 21:12:49.796108
# Unit test for method nationality of class Person
def test_Person_nationality():
    rnd = Random()

    rnd.seed(123456789) #To generate a repeatable sequence

    person_0 = Person(random=rnd)
    
    assert person_0.nationality() == 'Bulgarian'
    assert person_0.nationality() == 'Macedonian'


# Generated at 2022-06-25 21:13:02.982962
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Make person object
    person_0 = Person()

    # Make empty set of Russian people
    set_of_russian = set()
    # Make empty set of Ukrainian people
    set_of_ukrainian = set()

    # Get nationalities
    for i in range(1000):
        nationality = person_0.nationality()
        # Check if nationality is Russian
        if nationality == "Russian":
            set_of_russian.add(nationality)
        # Check if nationality is Ukrainian
        if nationality == "Ukrainian":
            set_of_ukrainian.add(nationality)

    # Check if in set_of_russian only Russian is present
    assert len(set_of_russian) == 1
    assert "Russian" in set_of_russian

    # Check if in set_of_ukrainian

# Generated at 2022-06-25 21:13:06.852651
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert type(person_0.nationality()) == str


# Generated at 2022-06-25 21:13:14.681678
# Unit test for method surname of class Person
def test_Person_surname():
    gender = Gender.FEMALE
    person = Person()
    # Test 1
    result_1 = person.surname(gender)
    assert type(result_1) is str
    # Test 2
    result_2 = person.surname(gender)
    assert type(result_2) is str
    # Test 3
    result_3 = person.surname(gender)
    assert type(result_3) is str
    # Test 4
    result_4 = person.surname(gender)
    assert type(result_4) is str


# Generated at 2022-06-25 21:13:25.031847
# Unit test for method surname of class Person
def test_Person_surname():
    # Case 1
    person_0 = Person()
    assert person_0.surname(Gender.MALE) in person_0._data['surname']['male']

    # Case 2
    person_1 = Person()
    assert isinstance(person_1.surname(Gender.FEMALE), str)

    # Case 3
    person_2 = Person()
    surnames_male_n_female = dict(male=['Smith', 'Johnson', 'Williams'],
                                  female=['Smith', 'Johnson', 'Williams'])
    assert person_2.surname(surnames_male_n_female) in ['Smith', 'Johnson', 'Williams']


# Generated at 2022-06-25 21:13:26.111400
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    result = person.email()
    assert type(result) == str


# Generated at 2022-06-25 21:13:29.052523
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person(seed=12345)
    person_3 = Person(seed=12345)
    assert person_0.surname() != person_1.surname()
    assert person_2.surname() == person_3.surname()
    assert len(person_0.surname()) > 0


# Generated at 2022-06-25 21:13:31.846921
# Unit test for method nationality of class Person
def test_Person_nationality():
    res_0 = check_nationalities(Person.nationality)
    res_1 = check_nationalities(Person().nationality)


# Generated at 2022-06-25 21:14:52.517963
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname(gender=Gender.MALE) == 'Зуев'
    assert person.surname(gender=Gender.FEMALE) == 'Андреева'

    # Test exception.
    with pytest.raises(NonEnumerableError):
        person.surname(gender=None)


# Generated at 2022-06-25 21:14:59.458143
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    person_1_nationality_1 = person_1.nationality()

if __name__ == "__main__":
    print("Testing")

    test_case_0()
    test_Person_nationality()

# Generated at 2022-06-25 21:15:02.415705
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname = person_0.surname()
    # Test that surname was generated correctly
    assert surname in NAMES



# Generated at 2022-06-25 21:15:08.754513
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    list_0 = EMAIL_DOMAINS
    str_0 = person_0.email(list_0)
    assert type(str_0) is str
