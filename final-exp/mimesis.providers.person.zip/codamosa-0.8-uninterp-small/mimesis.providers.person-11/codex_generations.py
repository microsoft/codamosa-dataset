

# Generated at 2022-06-25 21:06:40.420031
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    # Alias for the method last_name()
    assert isinstance(person_0.surname(), str) == True
    assert isinstance(person_0.last_name(), str) == True

    assert person_0._data['surname_male'] == person_0._data['last_name_male']
    assert person_0._data['surname_female'] == person_0._data['last_name_female']
    assert person_0.surname(Gender.MALE) == person_0.last_name(Gender.MALE)
    assert person_0.surname(Gender.FEMALE) == person_0.last_name(Gender.FEMALE)


# Generated at 2022-06-25 21:06:41.076641
# Unit test for method email of class Person
def test_Person_email():
    pass


# Generated at 2022-06-25 21:06:43.474231
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    data = person.gender()
    assert isinstance(data, str)


# Generated at 2022-06-25 21:06:48.065433
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(locale="en")
    assert person_0.nationality() not in person_0._data['nationality']
    assert person_0.nationality(gender=Gender.MALE) not in person_0._data['nationality'][Gender.MALE]
    assert person_0.nationality(gender=Gender.FEMALE) not in person_0._data['nationality'][Gender.FEMALE]


# Generated at 2022-06-25 21:06:55.211962
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()
    uname_0 = person_0.username()
    uname_1 = person_0.username(template='Ud')
    uname_2 = person_0.username(template='l.d')
    uname_3 = person_0.username(template='l-d')

    return uname_0, uname_1, uname_2, uname_3


# Generated at 2022-06-25 21:06:57.184969
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDERS


# Generated at 2022-06-25 21:07:03.438267
# Unit test for method surname of class Person
def test_Person_surname():
    from enum import Enum
    from fakeator import BaseEnum, Choice, EnumType

    class App(BaseEnum):

        """App's enum."""

        test = Choice('test')
        test1 = Choice('test1')

    class Persion(Person):
        app: EnumType[App] = App

    person_1 = Persion(app=App.test)

    person_1.surname()


# Generated at 2022-06-25 21:07:05.099311
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() == 'Волков'


# Generated at 2022-06-25 21:07:09.829864
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    person_2 = Person(language='ru')

    # Check default language
    assert person_1.surname() in SURNAME_EN
    # Check selected language
    assert person_2.surname() in SURNAME_RU


# Generated at 2022-06-25 21:07:13.964183
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    # Possible values of gender
    gender = ['male', 'female', 'male', 'female']

    person_surname = person.surname(gender[random.randint(0, 3)])

    assert(len(person_surname) > 0)


# Generated at 2022-06-25 21:07:44.272116
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert person_1.nationality() in PERSON_NATIONALITY


# Generated at 2022-06-25 21:07:53.595202
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test case 0: 1 execution
    person_0 = Person()
    person_0_nationality = person_0.nationality()
    # Test case 1: 10 executions
    person_1 = Person()
    for _ in range(10):
        person_1_nationality = person_1.nationality()
    # Test case 2: 100 executions
    person_2 = Person()
    for _ in range(100):
        person_2_nationality = person_2.nationality()
    # Test case 3: 1000 executions
    person_3 = Person()
    for _ in range(1000):
        person_3_nationality = person_3.nationality()


# Generated at 2022-06-25 21:07:57.207666
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    print("First Person: ")
    print(person_0.surname())
    print(person_0.surname(Gender.MALE))
    print(person_0.surname(Gender.FEMALE))


# Generated at 2022-06-25 21:07:58.845341
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDER_SYMBOLS
    assert person.gender(symbol=False) in ["male", "female"]
    assert person.gender(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-25 21:08:03.544528
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert(person_1.nationality() in PERSON_NATIONALITIES_KEY_0)
    assert(person_1.nationality('Male') in PERSON_NATIONALITIES_KEY_1)
    assert(person_1.nationality('Female') in PERSON_NATIONALITIES_KEY_2)


# Generated at 2022-06-25 21:08:04.872664
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:08:13.000533
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert person_0.email() == 'dwight-yu@hotmail.com'
    assert person_0.email() == 'pope_55@outlook.com'
    assert person_0.email() == 'fok-mcdonald@yahoo.com'
    assert person_0.email() == 'narcisa1886@outlook.com'
    assert person_0.email() == 'stacy-barnes@yahoo.com'
    assert person_0.email() == 'alie-hansen@gmail.com'
    assert person_0.email() == 'sheryl18@gmail.com'
    assert person_0.email() == 'johanna_33@gmail.com'
    assert person_0.email() == 'jeramy.gould@hotmail.com'

# Generated at 2022-06-25 21:08:14.859613
# Unit test for method gender of class Person
def test_Person_gender():
    person_0 = Person()
    gender_0 = person_0.gender()
    assert gender_0 in {'Male', 'Female'}


# Generated at 2022-06-25 21:08:17.557366
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    names_0 = [person_0.surname() for _ in range(10)]
    assert all(len(name) == len(names_0[0]) for name in names_0)


# Generated at 2022-06-25 21:08:20.257951
# Unit test for method nationality of class Person
def test_Person_nationality():
    person0 = Person()
    
    i = 0
    while i < 10:
        assert type(person0.nationality()) is str, "Test case failed: method nationality() not returned a string"
        i += 1



# Generated at 2022-06-25 21:08:35.937159
# Unit test for method surname of class Person
def test_Person_surname():
    # Assert type(Person().surname()) == str
    assert(isinstance(Person().surname(), str))


# Generated at 2022-06-25 21:08:38.737074
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname() in person_0._data['surname']


# Generated at 2022-06-25 21:08:40.813950
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    for _ in range(10):
        print(person_0.surname())


# Generated at 2022-06-25 21:08:49.337782
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    nationality_0 = person_1.nationality(gender=Gender.MALE) # Serbian
    nationality_1 = person_1.nationality(gender=Gender.MALE) # Russian
    nationality_2 = person_1.nationality(gender=Gender.FEMALE) # Russian
    nationality_3 = person_1.nationality(gender=Gender.FEMALE) # Czech

    print("nationality_0 = {}".format(nationality_0))
    print("nationality_1 = {}".format(nationality_1))
    print("nationality_2 = {}".format(nationality_2))
    print("nationality_3 = {}".format(nationality_3))

    assert nationality_0 == "Serbian"
    assert nationality_1 == "Russian"

# Generated at 2022-06-25 21:08:52.561187
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality("female") in person_0._data['nationality']['female']
    assert person_0.nationality("male") in person_0._data['nationality']['male']



# Generated at 2022-06-25 21:08:55.097883
# Unit test for method nationality of class Person
def test_Person_nationality():

    person_0 = Person()
    assert isinstance(person_0.nationality(), str)


# Generated at 2022-06-25 21:08:57.434402
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    print(person_1.nationality())
    print(person_1.nationality())
    print(person_1.nationality())


# Generated at 2022-06-25 21:09:04.274797
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person(seed=0)
    surnames_0 = person_0.surname()
    assert surnames_0 == 'Смирнов'
    surnames_1 = person_0.surname(gender=Gender.FEMALE)
    assert surnames_1 == 'Кузнецова'

    Person_surname = Person(seed=0)
    surnames_3 = Person_surname.surname(gender=Gender.FEMALE)
    assert surnames_3 == 'Кузнецова'


# Generated at 2022-06-25 21:09:11.085167
# Unit test for method surname of class Person
def test_Person_surname():
    print("   - test_Person_surname()")

    # Initialize class Person
    person_0 = Person()

    # Check for the default case , when no gender is provided
    if person_0.surname(None) != "":
        print("Error!")
 
    # Check for the case when male is provided as gender
    if person_0.surname(Gender.MALE) == "":
        print("Error!")
 
    # Check for the case when female is provided as gender
    if person_0.surname(Gender.FEMALE) == "":
        print("Error!")

    return True


# Generated at 2022-06-25 21:09:18.116695
# Unit test for method gender of class Person
def test_Person_gender():
    from random import seed
    from random import random
    from faker.utils.random_enum import random_enum
    from faker.enums import Gender
    seed(0)
    gender = random_enum(Gender)
    person = Person(gender=gender)
    person.gender(symbol=False)
    person.gender(symbol=True)
    person.gender(iso5218=False)
    person.gender(iso5218=True)
