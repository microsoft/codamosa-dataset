

# Generated at 2022-06-25 21:06:27.376552
# Unit test for method email of class Person
def test_Person_email():

    person = Person()
    assert person.email()


# Generated at 2022-06-25 21:06:32.742483
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    print('Test 1:\n\tOutput = {}\n\tExpected = Not empty string...'.format(str_0))


# Generated at 2022-06-25 21:06:40.010313
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Generate a random nationality.

        :param gender: Gender.
        :return: Nationality.

        :Example:
            Russian
        """
    person = Person()
    nationalities = person._data['nationality']
    key = person._validate_enum(None, Gender)
    nationalities = nationalities[key]
    if isinstance(nationalities, dict):
        nationalities = [
            i for i in nationalities[key]
        ]
    nationality = person.nationality()

    if nationality not in nationalities:
        raise ValueError('Method Person.nationality() is wrong')


# Generated at 2022-06-25 21:06:42.493756
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:06:44.526800
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)


# Generated at 2022-06-25 21:06:47.968687
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality(gender=Gender.FEMALE)
    if not isinstance(nationality, str):
        raise AssertionError('Method nationality of class Person'
                             ' returns not a string')

# Generated at 2022-06-25 21:06:51.696777
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    assert_is_instance(str_0, str)


# Generated at 2022-06-25 21:06:54.353575
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()
    print(str_0)


# Generated at 2022-06-25 21:06:55.524302
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    country = person.nationality()
    assert(country in PERSON_DATA['nationality'])


# Generated at 2022-06-25 21:06:58.071733
# Unit test for method email of class Person
def test_Person_email():
    person_1 = Person()
    str_0 = person_1.email()


# Generated at 2022-06-25 21:07:11.039434
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:07:13.964195
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert isinstance(person_1.nationality(), str)
    assert isinstance(person_1.nationality(gender=Gender(2)), str)
    

# Generated at 2022-06-25 21:07:16.222922
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in PERSON_NATIONALITIES # Check if all values of the generated list is in the original list of nationalities



# Generated at 2022-06-25 21:07:18.296337
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    case_0 = person_0.surname()
    print(case_0)


# Generated at 2022-06-25 21:07:26.909039
# Unit test for method nationality of class Person
def test_Person_nationality():
    rnd = get_random_instance()

    data = {'male': ['British', 'Polish',
                  'German', 'Dutch',
                  'Spanish', 'Danish',
                  'Greek', 'Russian',
                  'Irish', 'Hungarian'],
            'female': ['British', 'Polish',
                       'German', 'Dutch',
                       'Spanish', 'Danish',
                       'Greek', 'Russian',
                       'Irish', 'Hungarian']}

    person = Person(random=rnd, nationality=data)

    res_male = person.nationality(Gender.MALE)
    res_female = person.nationality(Gender.FEMALE)

    assert res_male in person._data['nationality'][Gender.MALE]
    assert res_female in person._data['nationality'][Gender.FEMALE]

#

# Generated at 2022-06-25 21:07:28.148109
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()


# Generated at 2022-06-25 21:07:31.268154
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Set global seed for generating random numbers
    seed(10)
    # Define an instance of class  Person
    person_0 = Person()
    nationality = person_0.nationality()
    assert nationality == 'Russian'


# Generated at 2022-06-25 21:07:39.719577
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person(seed=23451)
    email_0 = person_0.email()
    assert email_0 == 'k-96/20@trompetenforum.eu'
    email_1 = person_0.email(unique=True)
    assert email_1 == 'k-96/20_2@trompetenforum.eu'
    email_2 = person_0.email(unique=True)
    assert email_2 == 'k-96/20_3@trompetenforum.eu'


# Generated at 2022-06-25 21:07:42.435142
# Unit test for method email of class Person
def test_Person_email():
    person_1 = Person()
    for i in range(0, 100):
        email_1 = person_1.email()
        assert(email_1.count('@') == 1 and email_1.count('.') == 1)


# Generated at 2022-06-25 21:07:44.064455
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_nationality = Person.nationality(Person)
    assert person_nationality == Person.nationality


# Generated at 2022-06-25 21:07:57.205788
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname(None)


# Generated at 2022-06-25 21:07:59.840941
# Unit test for method surname of class Person
def test_Person_surname():
    result_0 = Person().surname()
    # Check that result_0 is a str
    assert isinstance(result_0, str)


# Generated at 2022-06-25 21:08:04.177877
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    try:
        person.nationality()
        #person.nationality(Gender.Male)
        #person.nationality(Gender.Female)
    except NonEnumerableError as err:
        print(err.message)
    else:
        print("Passed")


# Generated at 2022-06-25 21:08:08.499497
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_1 = Person(seed=1)
    emails_0 = []
    for i in range(10):
        emails_0.append(person_0.email())

    emails_1 = []
    for i in range(10):
        emails_1.append(person_1.email())

    assert emails_0 != emails_1



# Generated at 2022-06-25 21:08:14.750033
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality = person_0.nationality()
    assert nationality in person_0._data['nationality']
    assert type(nationality) is str

    nationalities_female = person_0._data['nationality']['female']
    female_nationality = person_0.nationality(gender=Gender.female)
    assert female_nationality in nationalities_female
    assert type(female_nationality) is str

    nationalities_male = person_0._data['nationality']['male']
    male_nationality = person_0.nationality(gender=Gender.male)
    assert male_nationality in nationalities_male
    assert type(male_nationality) is str

    nationalities_unknown = person_0._data['nationality']['not_known']

# Generated at 2022-06-25 21:08:16.273363
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    print(person_1.surname())


# Generated at 2022-06-25 21:08:18.329133
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    result = person_0.nationality()
    print("Person.nationality():", result)


# Generated at 2022-06-25 21:08:22.074747
# Unit test for method surname of class Person
def test_Person_surname():
    surname_list = [Person().surname() for _ in range(1000)]

    # Test if surname is a string
    assert all(isinstance(surname, str) for surname in surname_list)

    # Test if surname is not empty
    assert all(len(surname) > 0 for surname in surname_list)


# Generated at 2022-06-25 21:08:25.206585
# Unit test for method nationality of class Person
def test_Person_nationality():
    # tests
    assert_equal(Person().nationality('M'), 'Русский')
    assert_equal(Person().nationality('F'), 'Русская')


# Generated at 2022-06-25 21:08:29.705850
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    print(person_1.surname())
