

# Generated at 2022-06-25 21:06:38.704677
# Unit test for method email of class Person
def test_Person_email():
    def test_Person_email_0():
        person_0 = Person()
        assert person_0.email() == "theodore.heathcote@gmail.com"
        assert person_0.email() == "evie_davis@hotmail.com"
        assert person_0.email() == "bobby_goodman@hotmail.com"

    def test_Person_email_1():
        person_1 = Person(seed=3)
        assert person_1.email() == "michael.buchanan@yahoo.com"
        assert person_1.email() == "joseph.mills@gmail.com"
        assert person_1.email() == "jesse.bell@live.com"
        assert person_1.email() == "liam_holt@live.com"

# Generated at 2022-06-25 21:06:41.152140
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname(gender=Gender.MALE)
    assert type(surname_0) == str


# Generated at 2022-06-25 21:06:42.514071
# Unit test for method surname of class Person
def test_Person_surname():
    random.seed(0)
    person = Person()
    assert(person.surname() == "Топоркова")


# Generated at 2022-06-25 21:06:46.662026
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(1000):
        rnd = Random()
        person_0 = Person(random=rnd)
        x = person_0.surname(gender=Gender.FEMALE)
        y = person_0.surname(gender=Gender.FEMALE)
        if x == y:
            print("Error: test_Person_surname: test case #", i, "failed")


# Generated at 2022-06-25 21:06:49.088546
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker_e164.__main__ import Person
    a = Person()
    assert type(a.nationality()) == str


# Generated at 2022-06-25 21:06:54.354124
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality
    print(nationality_0)
    nationality_1 = person_0.nationality
    print(nationality_1)
    assert nationality_0 != nationality_1


# Generated at 2022-06-25 21:06:56.469992
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert(isinstance(person_0.nationality(),str))


# Generated at 2022-06-25 21:06:58.683200
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname()


# Generated at 2022-06-25 21:07:09.787625
# Unit test for method nationality of class Person
def test_Person_nationality():

    # Case 0
    person_0 = Person(seed=573679531)
    assert person_0.nationality(gender=Gender.MALE) == "Danish"

    # Case 1
    person_1 = Person(seed=23587179)
    assert person_1.nationality(gender=Gender.FEMALE) == "French"

    # Case 2
    person_2 = Person(seed=884580811)
    assert person_2.nationality(gender=Gender.MALE) == "Latvian"

    # Case 3
    person_3 = Person(seed=4854743)
    assert person_3.nationality(gender=Gender.MALE) == "Romanian"

    # Case 4
    person_4 = Person(seed=110490935)

# Generated at 2022-06-25 21:07:11.432511
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    email_0 = person_0.email()


# Generated at 2022-06-25 21:07:22.498678
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person(seed=123)
    surname = person_0.surname()
    assert surname == 'Вольский'


# Generated at 2022-06-25 21:07:25.127086
# Unit test for method nationality of class Person
def test_Person_nationality():
    # test 0
    person_0 = Person()

    assert isinstance(person_0, Person)
    assert person_0.nationality() in NATIONALITIES_WITH_GENDER


# Generated at 2022-06-25 21:07:27.074370
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person(seed=0)
    assert person_0.surname() == 'Peterson'


# Generated at 2022-06-25 21:07:38.407687
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert 'Luz' == person_0.surname()
    assert 'Kessler' == person_0.surname(title_type = 'suffix', gender = 'male')
    assert 'Turner' == person_0.surname(title_type = 'suffix', gender = 'female')
    assert 'Farmer' == person_0.surname(title_type = 'prefix', gender = 'female')
    assert 'Krebs' == person_0.surname(title_type = 'prefix', gender = 'male')
    assert 'Roush' == person_0.surname(title_type = None, gender = 'male')
    assert 'Dominguez' == person_0.surname(title_type = None, gender = 'female')

# Unit test

# Generated at 2022-06-25 21:07:42.719528
# Unit test for method nationality of class Person
def test_Person_nationality():
    """
    If this test passes, we can be sure that:
      - method nationality of class Person 
        is working correctly
    """
    person_0 = Person()
    nationality = person_0.nationality()
    if type(nationality) == str:
        print('Method nationality of class Person is correct')
    else:
        print('Method nationality of class Person is not correct')



# Generated at 2022-06-25 21:07:45.080360
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)
    assert len(person_0.surname()) > 0


# Generated at 2022-06-25 21:07:47.226353
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() != ''
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-25 21:07:49.803817
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    print("Test 1. Start")
    print(person_1.surname())
    print("Test 1. End\n")


# Generated at 2022-06-25 21:08:00.716426
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in [
        'Russian', 'Ukrainian', 'Belorussian', 'Kazakh', 'Moldovan', 'Tadzhik',
        'Armenian', 'Uzbek', 'Kirghiz', 'Azerbaijani', 'Georgian', 'Turkmen',
        'Dagestan', 'Chechen', 'Ingush', 'Kabardin-Balkar', 'Chechen',
        'Karachai-Cherkess', 'Jewish', 'Tatar', 'Mordvinian', 'Bashkir',
        'Chuvash', 'Yakut']

    person_1 = Person(gender=Gender.FEMALE)

# Generated at 2022-06-25 21:08:10.906641
# Unit test for method surname of class Person
def test_Person_surname():

    # Create an object of class Person.
    person_0 = Person()

    # Check default value for attribute gender.
    # This attribute is necessary for get a random surname.
    assert person_0.gender is None

    # Check default value for attribute surnames.
    assert person_0.surnames is None

    # Create a random element of enumeration Gender.
    gender_0 = get_random_item(Gender, rnd=person_0.random)

    # Get a random surname.
    surname_0 = person_0.surname(gender_0)

    # Check if one of possible values for this surname.
    assert (surname_0 in SURNAMES[gender_0]) or (surname_0 in SURNAMES['both'])

    # Check the correct names for each gender.

# Generated at 2022-06-25 21:08:26.015063
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert isinstance(person_0.nationality(), str)


# Generated at 2022-06-25 21:08:29.799245
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    result_0 = person_0.surname(Gender.FEMALE)


# Generated at 2022-06-25 21:08:32.772856
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_0.email(unique=True)
    person_0.email(unique=False)
    person_0.email(unique=True, domains=['mydomain.com'])
    person_0.email(unique=False, domains=['mydomain.com'])

# Generated at 2022-06-25 21:08:34.680680
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in NATIONALITIES
    assert person_0.nationality() in person_0._data['nationality']


# Generated at 2022-06-25 21:08:42.357952
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(100):
        person_1 = Person(seed=i)
        SURNAMES_RU_GENDER_MALE_data = person_1._data['surname']['ru-RU']['male']
        assert person_1.surname('male') in SURNAMES_RU_GENDER_MALE_data

        SURNAMES_RU_GENDER_FEMALE_data = person_1._data['surname']['ru-RU']['female']
        assert person_1.surname('female') in SURNAMES_RU_GENDER_FEMALE_data


# Generated at 2022-06-25 21:08:50.787039
# Unit test for method username of class Person
def test_Person_username():
    def username_check(sample_size, template):
        assert sample_size > 0

        samples = {Person(seed=seed).username(template=template)
                   for seed in range(sample_size)}

        assert len(samples) == sample_size

    # All templates shoud return a string
    sample_size = 10
    for template in ('Ud', 'ld', 'UUd', 'ldd', 'Uddd', 'UUddd',
                     'U_d', 'U.d', 'U-d', 'UU-d', 'UU.d', 'UU_d',
                     'UUddd-dddd'):
        samples = {Person(seed=seed).username(template=template)
                   for seed in range(sample_size)}
        assert all(isinstance(sample, str) for sample in samples)

    # Tem

# Generated at 2022-06-25 21:08:52.311260
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in PERSON_NATIONALITY


# Generated at 2022-06-25 21:09:02.176826
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_gen_0 = Person()

# Generated at 2022-06-25 21:09:03.827956
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert type(surname)==str


# Generated at 2022-06-25 21:09:06.624469
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    results = []
    for _ in range(0, 100):
        results.append(person_0.surname())
    assert len(set(results)) == len(results)


# Generated at 2022-06-25 21:09:34.968871
# Unit test for method nationality of class Person
def test_Person_nationality():
    people = []
    for i in range(0, 10):
        people.append(Person())

    for person in people:
        info = person.nationality()
        print(info)

# test_case_0()
# test_Person_nationality()

# Generated at 2022-06-25 21:09:36.699958
# Unit test for method surname of class Person
def test_Person_surname():
    # create instance Person
    person = Person()
    assert isinstance(person.surname(), basestring) == True


# Generated at 2022-06-25 21:09:38.626537
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    result = person.email()
    assert result
    assert len(result.split('@')) == 2


# Generated at 2022-06-25 21:09:40.396590
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person(seed=123)
    nationality_1 = person_1.nationality()
    assert nationality_1 == 'Russian'


# Generated at 2022-06-25 21:09:44.318338
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for correctness of the surname
    person_0 = Person()
    for i in range(100):
        surname = person_0.surname()
        assert len(surname) > 0


# Generated at 2022-06-25 21:09:47.296996
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(30):
        p = Person()
        assert p.surname() != p.surname()


# Generated at 2022-06-25 21:09:48.686393
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert isinstance(person_1.nationality(), str)



# Generated at 2022-06-25 21:09:57.911952
# Unit test for method email of class Person
def test_Person_email():

    name_0 = Person.name()
    assert name_0 == 'name'
    assert Person.name() == 'name'

    full_name_0 = Person.full_name()
    assert full_name_0 == 'full_name'

    surname_0 = Person.surname()
    assert surname_0 == 'surname'

    last_name_0 = Person.last_name()
    assert last_name_0 == 'last_name'

    title_0 = Person.title()
    assert title_0 == 'title'

    username_0 = Person.username()
    assert username_0 == 'username'

    password_0 = Person.password()
    assert password_0 == 'password'

    email_0 = Person.email()
    assert email_0 == 'email'

    social_media_profile_0

# Generated at 2022-06-25 21:09:59.527590
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    # Check that the call does not lead to an exception
    nationality_0 = person_0.nationality()


# Generated at 2022-06-25 21:10:02.708771
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_str_0 = person_0.surname(None)


# Generated at 2022-06-25 21:10:32.723927
# Unit test for method nationality of class Person
def test_Person_nationality():
    from random import randint
    from faker.providers.person.en_US import Provider
    for i in range(100):
        # Generate a random gender
        gender = Gender(randint(1, 2))

        # Get the nationality of the person according to his gender
        nationality = Person().nationality(gender)

        # Check if the nationality exists in the provider
        assert nationality in Provider.nationality[gender.name]


# Generated at 2022-06-25 21:10:37.315387
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Local variables
    person = Person()
    results = []
    # Check count of results
    for _ in range(1000):
        result = person.nationality()
        results.append(result)
    unique = set(results)
    print(f"Count of unique elements in 1000 runs: {len(unique)}")
    # Generate 10 random elements form results
    print(f"Random 10 elements: {random.sample(results, 10)}")
    # Get random element
    print(f"Random element: {random.choice(results)}")


# Generated at 2022-06-25 21:10:41.976016
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surnames_0 = person_0.surname()
    # A surname should be string instance
    assert isinstance(surnames_0, str)


# Generated at 2022-06-25 21:10:48.919421
# Unit test for method surname of class Person
def test_Person_surname():
    import os
    import sys
    import unittest
    # Importing the class to be tested
    from fake2db.providers import Person
    # Importing the metadata from the application
    from tests.providers.meta import Person_meta

    # Defining the class for testing
    class PersonTestCase(unittest.TestCase):
        # Defining class attributes
        attr_name = ''
        provider = None

        # Defining setup method
        def setUp(self):
            # Instantiating the object
            self.provider = Person()
            # Assigning the attribute name
            self.attr_name = 'surname'

        # Defining teardown method
        def tearDown(self):
            # Deleting the object
            del self.provider

        # Defining test methods

# Generated at 2022-06-25 21:10:56.292414
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()

    test_cases_0 = (
        ('Иванов',),
        ('Сидоров',),
        ('Хьюстон',),
        ('Кузнецов',),
        ('Рудольфов',),
        ('Сергеев',),
        ('Архипов',),
        ('Фролов',),
        ('Бабенко',),
        ('Федотов',)
    )

    for surname in test_cases_0:
        assert person_0.surname() == surname


# Generated at 2022-06-25 21:11:01.062136
# Unit test for method username of class Person
def test_Person_username():
    from random import Random
    from hashlib import md5
    from datetime import datetime

    rnd = Random(0)

    for seed in range(100):
        rnd = Random(seed)
        Person_0 = Person(seed=seed)
        Person_1 = Person()

        for _ in range(100):
            # A random template.
            template = ''.join(rnd.choice('.-_Uld') for _ in range(rnd.randint(1,10)))

            # Generate a random username.
            username_0 = Person_0.username(template=template)
            username_1 = Person_1.username(template=template)

            # Check that generated usernames are the same.
            assert username_0 == username_1
            assert type(username_0) == type(username_1)



# Generated at 2022-06-25 21:11:04.320070
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    # Test the return is string
    assert (type(person_1.nationality()) == str)


# Generated at 2022-06-25 21:11:10.373358
# Unit test for method nationality of class Person
def test_Person_nationality():
    method = 'nationality'
    name = 'Мария'
    surname = 'Петрова'
    nationality = 'Германия'
    person = Person()

    person.name = name
    person.surname = surname
    person.nationality = nationality
    person_nationality = person.nationality
    assert person_nationality in ['Германия']


# Generated at 2022-06-25 21:11:16.169078
# Unit test for method email of class Person
def test_Person_email():
    person_1 = Person()
    email_1 = person_1.email()
    print(email_1)
    email_2 = person_1.email()
    print(email_2)
    email_3 = person_1.email(unique=True)
    print(email_3)
    email_4 = person_1.email(unique=True)
    print(email_4)
    email_5 = person_1.email(unique=True)
    print(email_5)
    email_6 = person_1.email(unique=True)
    print(email_6)
    email_7 = person_1.email(unique=True)
    print(email_7)
    email_8 = person_1.email(unique=True)
    print(email_8)
    email_9 = person_

# Generated at 2022-06-25 21:11:27.792998
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0_result = person_0.nationality()

# Generated at 2022-06-25 21:12:40.664999
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    expected_0=None
    actual_0 = person_0.surname(None)
    assert actual_0 == expected_0


# Generated at 2022-06-25 21:12:43.066132
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert(surname in person._data['surname'])


# Generated at 2022-06-25 21:12:48.160715
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

    # Test nationality method of class Person
    person_0_nationality_0 = person_0.nationality()
    assert isinstance(person_0_nationality_0, str)
    assert person_0_nationality_0 in COUNTRIES

    # Test nationality method of class Person
    person_0_nationality_1 = person_0.nationality(gender = Gender.MALE)
    assert isinstance(person_0_nationality_1, str)
    assert person_0_nationality_1 in COUNTRIES

    # Test nationality method of class Person
    person_0_nationality_2 = person_0.nationality(gender = Gender.FEMALE)
    assert isinstance(person_0_nationality_2, str)
    assert person_0_nationality_2 in COUNTRIES

# Generated at 2022-06-25 21:12:50.500517
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=0)
    assert p.nationality() == 'Russian'


# Generated at 2022-06-25 21:12:53.193123
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    assert nationality_0 in NATIONALITIES


# Generated at 2022-06-25 21:12:55.941821
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in all_surnames


# Generated at 2022-06-25 21:12:57.881034
# Unit test for method nationality of class Person
def test_Person_nationality():
    code = "Russian"
    assert Person().nationality() == code


# Generated at 2022-06-25 21:13:01.755189
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    expected_result = 'Russian'
    actual_result = person_0.nationality()
    assert actual_result == expected_result


# Generated at 2022-06-25 21:13:07.450632
# Unit test for method nationality of class Person
def test_Person_nationality():
    np.random.seed(0)
    person = Person()
    nationality = person.nationality()
    expected_value = "French"
    assert nationality == expected_value, 'Test failed'


# Generated at 2022-06-25 21:13:15.235823
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Testing the method nationality of class Person
    test_data = ["Russian", "American", "Russian", "French", "Russian", "German", "Russian", "Chinese", "Russian", "Latvian", "Russian", "Indian", "Russian", "Italian", "Russian", "Greek", "Russian", "Japanese", "Russian", "Spanish"]
    person_obj = Person()
    person_obj.seed(10)
    nationality_list = []
    for i in range(0, 20):
        data_case_0 = person_obj.nationality()
        nationality_list.append(data_case_0)
    assert nationality_list == test_data


# Generated at 2022-06-25 21:15:01.638046
# Unit test for method surname of class Person
def test_Person_surname():
    Person_1 = Person()
    surname = Person_1.surname()
    # print(surname)
    return


# Generated at 2022-06-25 21:15:07.240937
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()

    person_0_surname = person_0.surname()
    person_1_surname = person_1.surname()
    person_2_surname = person_2.surname()
    person_3_surname = person_2.surname()

    assert person_0_surname != person_1_surname
    assert person_1_surname != person_2_surname
    assert person_2_surname != person_3_surname


# Generated at 2022-06-25 21:15:09.877975
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    result = person_0.nationality()
    assert result


# Generated at 2022-06-25 21:15:15.530512
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    national_0 = person_0.nationality()
    assert type(national_0) == str
    national_1 = person_0.nationality(gender=Gender.FEMALE)
    assert type(national_1) == str
    national_2 = person_0.nationality(gender=Gender.MALE)
    assert type(national_2) == str


# Generated at 2022-06-25 21:15:23.681201
# Unit test for method nationality of class Person
def test_Person_nationality():
    g1 = Gender.MALE
    g2 = Gender.FEMALE

    person = Person()

    assert type(person.nationality()) == str
    assert type(person.nationality(gender=g1)) == str
    assert type(person.nationality(gender=g2)) == str


# Generated at 2022-06-25 21:15:36.249981
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Variables
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_7 = Person()
    person_8 = Person()
    person_9 = Person()
    person_10 = Person()
    person_11 = Person()
    person_12 = Person()
    person_13 = Person()
    person_14 = Person()
    person_15 = Person()
    person_16 = Person()
    person_17 = Person()
    person_18 = Person()
    person_19 = Person()
    person_20 = Person()
    person_21 = Person()
    person_22 = Person()
    person_23 = Person()
    person

# Generated at 2022-06-25 21:15:46.772727
# Unit test for method surname of class Person
def test_Person_surname():
    def _test(surname, gender, surnames):
        rng = get_random_instance()

        person = Person(surnames=surnames, rnd=rng)

        assert person.surname(gender) == surname


# Generated at 2022-06-25 21:15:49.374153
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    assert isinstance(person_1.surname(), str)


# Generated at 2022-06-25 21:15:53.055667
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)



# Generated at 2022-06-25 21:15:57.573959
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname() # Call method self.surname() without arguments.
    person_0.surname(gender=Gender.FEMALE) # Call method self.surname() with arguments.
