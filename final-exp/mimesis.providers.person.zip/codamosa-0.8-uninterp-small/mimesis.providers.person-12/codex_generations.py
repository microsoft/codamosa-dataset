

# Generated at 2022-06-25 21:06:30.478915
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    x = person_1.surname(Gender.Male) 
    assert isinstance(x, str)
    
    y = person_1.surname(Gender.Female) 
    assert isinstance(x, str)


# Generated at 2022-06-25 21:06:33.931383
# Unit test for method surname of class Person
def test_Person_surname():
    surname = Person().surname()
    assert isinstance(surname, str)
    assert len(surname) >= 3


# Generated at 2022-06-25 21:06:44.529176
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person(seed=1, locale='en')
    expected_surname = ['Smith', 'Johnson', 'Williams', 'Jones', 'Brown',
                        'Davis', 'Miller', 'Wilson', 'Moore', 'Taylor',
                        'Anderson', 'Thomas', 'Jackson', 'White', 'Harris',
                        'Martin', 'Thompson', 'Garcia', 'Martinez', 'Robinson']
    assert person_1.surname() in expected_surname

    person_2 = Person(seed=1, locale='ru')

# Generated at 2022-06-25 21:06:50.921177
# Unit test for method surname of class Person
def test_Person_surname():
    names = ('John', 'Johann', 'Juan', 'Nguyen', 'Jean-luc', 'Angel', 'Dante')
    surnames = ('Arnold', 'Demorol', 'Slater', 'Schwarzenegger', 'Rambo', 'Stallone', 'Willis')
    person_0 = Person()
    surname_0 = person_0.surname()
    name_0 = person_0.name()
    full_name_0 = person_0.full_name(reverse=True)

    surnames = ('Иванов', 'Сидоров', 'Петров', 'Кротов', 'Собаков')

# Generated at 2022-06-25 21:06:54.354278
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    nationalities = person._data['nationality']
    assert nationality in nationalities, "person.nationality() is invalid"

# Generated at 2022-06-25 21:06:56.469453
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in NATIONALITIES


# Generated at 2022-06-25 21:06:58.682372
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    name = person.nationality()
    print(name)


# Generated at 2022-06-25 21:07:09.787286
# Unit test for method nationality of class Person

# Generated at 2022-06-25 21:07:16.673158
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()

    # Make instances be independent from each other
    person_1.set_seed(10)
    person_2.set_seed(20)
    person_3.set_seed(30)

    assert person_0.nationality() == person_1.nationality()
    assert person_0.nationality() == 'Jamaican'
    assert person_2.nationality() == 'Latvian'
    assert person_3.nationality() == 'Cambodian'


# Generated at 2022-06-25 21:07:19.117064
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname = person_0.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-25 21:07:27.982545
# Unit test for method surname of class Person
def test_Person_surname():
    # Case 0
    person_0 = Person()
    assert person_0.surname() in _data['surname']


# Generated at 2022-06-25 21:07:31.147750
# Unit test for method surname of class Person
def test_Person_surname():
    list_Person_surname = [Person().surname(gender='female') for _ in range(10)]
    assert all(isinstance(name, str) for name in list_Person_surname)


# Generated at 2022-06-25 21:07:36.647327
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    while(True):
        nationality_0 = person_0.nationality()
        if(nationality_0 is not None):
            return True
        else:
            return False


# Generated at 2022-06-25 21:07:41.371163
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person(seed=1)

    test_surname_0 = person_0.surname()
    test_surname_1 = person_1.surname()

    assert test_surname_0 == 'Назарин'
    assert test_surname_1 == 'Берг'


# Generated at 2022-06-25 21:07:45.945788
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

    # Test case 1
    nationalities = person_0.nationality()

    # Test case 2
    nationalities = person_0.nationality(gender=person_0.gender())

    # Test case 3
    nationalities = person_0.nationality(gender="male")

    # Test case 4
    nationalities = person_0.nationality(gender="female")


# Generated at 2022-06-25 21:07:52.631514
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email(['example.com']) == '0ea957bb@example.com'
    assert person.email(['example.com'], unique=True) == '91ed0b9e@example.com'
    assert person.email() == '13d2a1c3@hotmail.com'
    assert person.email() == 'pilot1@mail.ru'


# Generated at 2022-06-25 21:07:54.515538
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert person_1.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:07:56.975868
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nation_0 = person_0.nationality()
    nation_1 = person_0.nationality(gender=Gender.MALE)


# Generated at 2022-06-25 21:07:59.661018
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Setup test
    person = Person()
    res = person.nationality()

    # Check condition
    assert isinstance(res, str)


# Generated at 2022-06-25 21:08:01.262902
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    print(person.surname(Gender.Male))


# Generated at 2022-06-25 21:08:08.423184
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print(person_0.nationality())


# Generated at 2022-06-25 21:08:11.067981
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert (person_0.surname() == 'Johnson')
    assert (person_0.surname() == 'Johnson')
    assert (person_0.surname() == 'Johnson')


# Generated at 2022-06-25 21:08:18.399241
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test 1
    person_1 = Person()
    assert person_1.nationality() in PERSON_DATA['nationality']

    # Test 2
    gender_2 = Gender.MALE
    person_2 = Person(gender=gender_2)
    nationality_male = PERSON_DATA['nationality'][Gender.MALE.value]
    assert person_2.nationality(gender=gender_2) in nationality_male

    # Test 3
    gender_3 = Gender.FEMALE
    person_3 = Person(gender=gender_3)
    nationality_female = PERSON_DATA['nationality'][Gender.FEMALE.value]
    assert person_3.nationality(gender=gender_3) in nationality_female


# Generated at 2022-06-25 21:08:19.858528
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert '@' in person_0.email()


# Generated at 2022-06-25 21:08:21.828197
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert type(surname) is str


# Generated at 2022-06-25 21:08:26.852863
# Unit test for method email of class Person
def test_Person_email():
    test_cases = [
        # test_case_0
        ('', None, None),
        ('', [], None),
        ('', [''], None),
    ]

    person_0 = Person()
    person_0.seed(42)
    for test_case in test_cases:
        params = list(test_case[1:])
        if params[0] is None:
            params.pop(0)
        res = person_0.email(*params)
        print(res)


# Generated at 2022-06-25 21:08:28.202743
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:08:31.523751
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person()
    surnames_result_0 = person_0.surname()
    surnames_result_1 = person_1.surname()
    assert surnames_result_0 in person_0._data['surname']
    assert surnames_result_1 in person_1._data['surname']
    assert surnames_result_0 != surnames_result_1

# Generated at 2022-06-25 21:08:33.940055
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str), 'Incorrect type'
    print('Surname is %s ' % person_0.surname())


# Generated at 2022-06-25 21:08:35.118880
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:08:51.679900
# Unit test for method nationality of class Person
def test_Person_nationality():
    # print("===================Start test_Person_nationality()==================")
    person = Person()
    male = person.nationality(male)
    # print("Male nationality: %s"%(male))
    female = person.nationality(female)
    # print("Female nationality: %s"%(female))
    # print("===================End test_Person_nationality()==================")


# Generated at 2022-06-25 21:08:57.777683
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()

    # Test 1
    assert person_1.surname(gender=Gender.MALE).casefold() in [i.casefold() for i in person_1._data["surnames"]["male"]]

    # Test 2
    assert person_1.surname(gender=Gender.FEMALE).casefold() in [i.casefold() for i in person_1._data["surnames"]["female"]]



# Generated at 2022-06-25 21:08:59.907597
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    for _ in range(10**2):
        assert isinstance(person_1.nationality(), str)


# Generated at 2022-06-25 21:09:01.666457
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    result = person.surname()
    assert type(result) == str


# Generated at 2022-06-25 21:09:03.661389
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)
    assert person_0.surname()


# Generated at 2022-06-25 21:09:07.946766
# Unit test for method nationality of class Person
def test_Person_nationality():
    x = Person()
    f_nationalities = x.nationality(gender=Gender.FEMALE)
    m_nationalities = x.nationality(gender=Gender.MALE)
    nationalities = x.nationality()
    assert type(f_nationalities) is str
    assert type(m_nationalities) is str
    assert type(nationalities) is str


# Generated at 2022-06-25 21:09:11.475614
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(100):
        person = Person()
        assert person.surname() in SURNAME_MALE + SURNAME_FEMALE


# Generated at 2022-06-25 21:09:17.715435
# Unit test for method surname of class Person
def test_Person_surname():
    # Default case.
    person_0 = Person()
    surname_0 = person_0.surname()
    print('Surname: ', surname_0)

    # Gender case.
    person_1 = Person()
    surname_1 = person_1.surname(gender=Gender.female)
    print(surname_1)


# Generated at 2022-06-25 21:09:23.403261
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()

    person_1 = Person()

    person_1_email = person_1.email(unique=True)

    assert len(person_1_email) > 0
    assert person_1_email in person_1_email
    assert person_0.email(unique=True) in person_1_email


# Generated at 2022-06-25 21:09:26.465187
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test 0
    person_0 = Person()
    # print(person_0.nationality())
    # Test 1
    person_1 = Person()
    # print(person_1.nationality())


# Generated at 2022-06-25 21:09:56.014312
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    # Random pick a surname from the list
    assert person.surname() in person._data['surname']
    # Test if female and male gets different values
    assert person.surname(Gender.Male) != person.surname(Gender.Female)


# Generated at 2022-06-25 21:10:00.156140
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()

    # Testing username when template is not None
    for template in ('U_d', 'U.d', 'U-d', 'UU-d', 'UU.d', 'UU_d',
                     'ld', 'l-d', 'Ud', 'l.d', 'l_d', 'default'):
        username = person_0.username(template=template)
        assert isinstance(username, str)

    # Testing username when template is None
    username = person_0.username()
    assert isinstance(username, str)


# Generated at 2022-06-25 21:10:04.150901
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(nationality=('Russian', 'American'))
    assert person_0.nationality() in ('Russian', 'American')


# Generated at 2022-06-25 21:10:07.101981
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    print(person_0.surname())


# Generated at 2022-06-25 21:10:08.417053
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality()


# Generated at 2022-06-25 21:10:10.832566
# Unit test for method surname of class Person
def test_Person_surname():
    rnd = Random()
    person = Person(rnd)

    last_name = person.surname()
    assert isinstance(last_name, str)
    assert len(last_name) > 0


# Generated at 2022-06-25 21:10:18.993552
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()
    username_0 = person_0.username(template='UU-d')
    username_1 = person_0.username(template='UUd')
    username_2 = person_0.username(template='UU.d')
    username_3 = person_0.username(template='UU_d')
    username_4 = person_0.username(template='l-d')
    username_5 = person_0.username(template='l.d')
    username_6 = person_0.username(template='l_d')
    username_7 = person_0.username(template='l')
    username_8 = person_0.username(template='U_d')
    username_9 = person_0.username(template='U.d')

# Generated at 2022-06-25 21:10:28.741340
# Unit test for method surname of class Person
def test_Person_surname():

    person_0 = Person()

    # Surname
    print("Surname:", person_0.surname())

    # Male surname
    print("Male surname:", person_0.surname(gender=Gender.MALE))

    # Female surname
    print("Female surname:", person_0.surname(gender=Gender.FEMALE))

    # Mixed surname
    surnames = {Gender.FEMALE: ['Smith'], Gender.MALE: ['Doe']}
    print("Mixed surname:", person_0.surname(surnames=surnames))
    return


# Generated at 2022-06-25 21:10:34.636638
# Unit test for method nationality of class Person
def test_Person_nationality():
    rnd = Random()
    # Set seed
    rnd.seed(0)
    person = Person(rnd)
    # Testing parameters
    gender = Gender.male
    sample = ['American', 'Russian', 'English', 'Norwegian',
        'Principality Of Korea', 'Bavarian', 'Putian']

    # Iterate 1000 times and check the result
    for _ in range(1000):
        nationality_0 = person.nationality(gender)
        if nationality_0 not in sample:
            return False

    return True


# Generated at 2022-06-25 21:10:36.195795
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()

    assert(surname in PERSON_SURNAMES)


# Generated at 2022-06-25 21:11:15.184551
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    try:
        surname_0 = person_0.surname(gender="male")
        print("Name (Male):", surname_0)
        surname_0 = person_0.surname(gender=Gender.MALE)
        print("Name (Male):", surname_0)
        surname_0 = person_0.surname(gender="female")
        print("Name (Female):", surname_0)
        surname_1 = person_0.surname()
        print("Name:", surname_1)
        surname_0 = person_0.surname(gender=Gender.FEMALE)
        print("Name (Female):", surname_0)
    except NonEnumerableError as e_0:
        print("An exception was raised:", type(e_0))

# Generated at 2022-06-25 21:11:26.874966
# Unit test for method nationality of class Person

# Generated at 2022-06-25 21:11:36.148121
# Unit test for method email of class Person
def test_Person_email():
    R = Fake().random
    # Using random seed
    R.seed(0)

    person_0 = Person(random = R)
    assert person_0.email() == 'joshua14@mail.com'
    assert person_0.email() == 'joshua14@mail.com'

    assert person_0.email() == 'joshua14@mail.com'
    assert person_0.email() == 'joshua14@mail.com'

    assert person_0.email() == 'joshua14@mail.com'
    assert person_0.email() == 'joshua14@mail.com'

    assert person_0.email() == 'joshua14@mail.com'
    assert person_0.email() == 'joshua14@mail.com'


# Generated at 2022-06-25 21:11:40.441167
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()

    # Testing the method nationality

    t_0 = person_0.nationality()
    t_1 = person_1.nationality()
    assert (isinstance(t_0, str))
    assert (isinstance(t_1, str))


# Generated at 2022-06-25 21:11:46.724240
# Unit test for method username of class Person
def test_Person_username():
    from collections import Counter

    p = Person()
    TEMPLATE_COUNT = 50


# Generated at 2022-06-25 21:11:47.571590
# Unit test for method nationality of class Person
def test_Person_nationality():
        person_0 = Person()
        person_0.nationality() == "Russian"

# Generated at 2022-06-25 21:11:48.835762
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    assert person_1.surname() in person_1._data['surname']


# Generated at 2022-06-25 21:11:50.314828
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    actual_1 = person_1.nationality()
    expected_1 = 'German'
    assert actual_1 == expected_1


# Generated at 2022-06-25 21:11:53.991216
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person() # Random provider
    person_1 = Person() # Seeded provider

    person_0.seed = 0x01234567890ABCDEF
    person_1.seed = 0x01234567890ABCDEF

    # Result from non-seeded
    result_0 = person_0.surname()
    # Result from seeded
    result_1 = person_1.surname()

    # Check results
    assert result_0 == result_1


# Generated at 2022-06-25 21:11:55.304276
# Unit test for method surname of class Person
def test_Person_surname():
    import random
    random.seed(0)
    person = Person(random)
    assert person.surname() == 'Moore'


# Generated at 2022-06-25 21:12:22.407192
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    r = p.surname(Gender.MALE)
    assert isinstance(r, str)


# Generated at 2022-06-25 21:12:25.915585
# Unit test for method surname of class Person
def test_Person_surname():
    persons = Person()
    surname = persons.surname()
    assert surname in SURNAME


# Generated at 2022-06-25 21:12:32.175062
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    result_1 = person_1.surname()
    assert type(result_1) == str


# Generated at 2022-06-25 21:12:35.420761
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Create instance of Person class
    person = Person()

    # Generates random nationality
    nationality = person.nationality()

    # Assert nationality is string
    assert type(nationality) == str, 'The function "nationality" does not return string'

    # Assert nationality is not empty
    assert len(nationality) > 0


# Generated at 2022-06-25 21:12:41.705432
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    actual_result = person_0.surname()
    expected_result = 'surname'
    assert actual_result == expected_result, 'Actual result is "{}" but expected result is "{}"'.format(actual_result, expected_result)


# Generated at 2022-06-25 21:12:44.108283
# Unit test for method surname of class Person
def test_Person_surname():
    # Create an instance of class Person
    person_0 = Person()
    # Get a random last name
    last_name = person_0.surname()

    assert last_name


# Generated at 2022-06-25 21:12:47.034700
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in person_0._data['nationality']


# Generated at 2022-06-25 21:12:50.693166
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    # Test method surname of class Person
    result = person_0.surname()
    assert isinstance(person_0, Person)


# Generated at 2022-06-25 21:12:52.116605
# Unit test for method surname of class Person
def test_Person_surname():
    pass


# Generated at 2022-06-25 21:12:55.551543
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0 is not None
    assert isinstance(person_0, Person)
    assert person_0.surname is not None


# Generated at 2022-06-25 21:13:23.249731
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    # Run the test 1000 times
    for i in range(1000):
        assert person.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:13:28.981432
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Method for testing surname method of class Person
    """
    person_1 = Person(seed=1)
    print(person_1.surname())


# Generated at 2022-06-25 21:13:31.278544
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    print(person_0.surname())


# Generated at 2022-06-25 21:13:44.413689
# Unit test for method nationality of class Person
def test_Person_nationality():
    newPerson = Person()
    nationalities_list = ['Белорусский','Русский','Белорусский','Белорусский','Русский','Белорусский','Русский','Белорусский','Русский','Русский']
    for j in range(10):
        nationality = newPerson.nationality()
        assert nationality in nationalities_list, 'Method nationality of class Person returned a non-existent nationality.'
        print(nationality)

test_Person_nationality()

# Generated at 2022-06-25 21:13:53.015389
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    # Check type of attribute nationalities
    assert isinstance(person_0.nationalities, tuple), "Wrong type of attribute nationalities"
    # Check type of attribute random
    assert isinstance(person_0.random, Random), "Wrong type of attribute random"
    nationalities = person_0.nationalities
    for nationality in nationalities:
        assert isinstance(nationality, str), "Wrong type of nationality"


# Generated at 2022-06-25 21:13:56.651686
# Unit test for method username of class Person
def test_Person_username():
    person_0 = Person()
    person_0.username()


# Generated at 2022-06-25 21:14:07.186762
# Unit test for method surname of class Person
def test_Person_surname():
    # initiate class
    person_1 = Person()

    # check that method surname return correct type
    assert isinstance(person_1.surname(), str)

    # check that method surname return at least one character
    assert len(person_1.surname()) > 0

    # the seed of random
    seed = random.randint(1,200)

    # case with seed
    # initiate class
    person_1_rand_1 = Person(random.Random(seed))
    # get result
    res_1 = person_1_rand_1.surname()
    # initiate class
    person_1_rand_2 = Person(random.Random(seed))
    # get result 
    res_2 = person_1_rand_2.surname()
    # check that both results are identical
    assert res_1

# Generated at 2022-06-25 21:14:12.512790
# Unit test for method surname of class Person
def test_Person_surname():
    gen = Person()
    assert gen.surname(gender=Gender.MALE) in "surname"
    assert gen.surname(gender=Gender.FEMALE) in "surname"


# Generated at 2022-06-25 21:14:13.678246
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)


# Generated at 2022-06-25 21:14:24.666475
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert not isinstance(person_0, RandomDataProvider)
    assert isinstance(person_0, RandomDataProvider)
    assert isinstance(person_0, Person)
    assert not isinstance(person_0.nationality(), list)
    assert len(person_0.nationality()) > 0
    assert not isinstance(person_0.nationality(), tuple)
    assert not isinstance(person_0.nationality(), int)
    assert not isinstance(person_0.nationality(), None)
    assert isinstance(person_0.nationality(), str)
    nationality = person_0.nationality()
    assert len(nationality) > 0
    nationality = person_0.nationality(gender=Gender.FEMALE)
    assert len(nationality) > 0

# Generated at 2022-06-25 21:15:14.878474
# Unit test for method surname of class Person
def test_Person_surname():
    generate_surname_0 = Person().surname(gender=Gender.FEMALE)
    generate_surname_1 = Person().surname(gender=Gender.MALE)
    generate_surname_2 = Person().surname()


# Generated at 2022-06-25 21:15:16.777025
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()


# Generated at 2022-06-25 21:15:25.448608
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(100):
        p = Person()
        assert len(p.surname()) > 0
        assert len(p.surname(Gender.MALE)) > 0
        assert len(p.surname(Gender.FEMALE)) > 0
        assert isinstance(p.surname(), str)
        assert isinstance(p.surname(Gender.MALE), str)
        assert isinstance(p.surname(Gender.FEMALE), str)


# Generated at 2022-06-25 21:15:30.271364
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(1000):
        person_0 = Person()
        r = person_0.nationality()
        assert r in NATIONALITY


# Generated at 2022-06-25 21:15:35.094152
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in SURNAME
    assert person.surname(gender=Gender.male) in MALE_SURNAME
    assert person.surname(gender=Gender.female) in FEMALE_SURNAME


# Generated at 2022-06-25 21:15:45.936313
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()

    print(person_0.nationality())
    print(person_1.nationality())
    print(person_2.nationality())
    print(person_3.nationality())
    print(person_4.nationality())
    print(person_5.nationality())
    print(person_6.nationality())

if __name__ == '__main__':
    test_case_0()
    print('\n')
    test_Person_nationality()

# Generated at 2022-06-25 21:15:50.374015
# Unit test for method email of class Person
def test_Person_email():
  person_0 = Person()
  rv = person_0.email()
  assert rv is not None

if __name__ == '__main__':
  test_Person_email()

# Generated at 2022-06-25 21:15:54.903147
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in person_0._data['nationality']


# Generated at 2022-06-25 21:15:57.074516
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname()



# Generated at 2022-06-25 21:16:03.045034
# Unit test for method surname of class Person
def test_Person_surname():
    # Setup
    person_0 = Person()

    # Test
    surname_0 = person_0.surname()
    assert surname_0 in ARRAY_0

    # Teardown
    del person_0

