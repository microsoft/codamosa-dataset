

# Generated at 2022-06-25 21:06:34.157050
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Test 0
    person_0 = Person(seed=17)
    str_0 = person_0.full_name()
    assert str_0 == 'Лана Сергей'

if __name__ == '__main__':
    test_case_0()
    test_Person_full_name()

# Generated at 2022-06-25 21:06:36.364570
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-25 21:06:42.546612
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.random.seed(0)
    str_0 = person_0.nationality()
    return str_0

if __name__ == "__main__":
    for i in range(10):
        str_1 = test_Person_nationality()
        print(str_1)
    for i in range(10):
        str_1 = test_Person_nationality()
        print(str_1)

# Generated at 2022-06-25 21:06:44.927889
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_5 = Person()
    str_5 = person_5.nationality()
    assert(str_5 != "")


# Generated at 2022-06-25 21:06:46.833463
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()


# Generated at 2022-06-25 21:06:49.276462
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()
    str_0 = person_0.nationality()



# Generated at 2022-06-25 21:06:52.216544
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    pass


# Generated at 2022-06-25 21:06:54.400497
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname(gender='Male')


# Generated at 2022-06-25 21:06:55.369635
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()


# Generated at 2022-06-25 21:06:59.055402
# Unit test for method email of class Person
def test_Person_email():
    person = Person(random = Random())

    l = set()
    for i in range(1000):
        l.add(person.email())

    assert len(l) == 1000


# Generated at 2022-06-25 21:07:26.785336
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality
    assert isinstance(nationality, str)
    assert len(nationality)>0


# Generated at 2022-06-25 21:07:29.019611
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()
    person_0.surname(gender=Gender.MALE)


# Generated at 2022-06-25 21:07:30.540498
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    person.gender()


# Generated at 2022-06-25 21:07:39.013599
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()

    # Test with invalid gender
    try:
        person.nationality(gender = "")
        assert False
    except NonEnumerableError as e:
        assert True
        print("Test case 0 passed.")
    except:
        assert False
        print("Test case 0 failed.")

    # Test with correct gender
    try:
        nationality = person.nationality(gender = Gender.MALE)
        assert nationality
        print("Test case 1 passed.")
    except Exception as e:
        print("Test case 1 failed.")


# Generated at 2022-06-25 21:07:41.552914
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    result_0 = person_0.surname(Gender.FEMALE)
    assert type(result_0) == str and len(result_0) > 0


# Generated at 2022-06-25 21:07:43.723862
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.providers.person.it_IT import Provider as Person
    person_0 = Person()
    nationality = person_0.nationality()


# Generated at 2022-06-25 21:07:46.780175
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test case 0:
    # Create an object of class Person
    person_0 = Person()
    # Test if the method nationality of class return a string
    assert person_0.nationality() == person_0.nationality()


# Generated at 2022-06-25 21:07:57.719551
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()

    person_0_gender = Gender.MALE
    person_1_gender = Gender.FEMALE
    person_2_gender = None

    person_0_surname_1 = person_0.surname(person_0_gender)
    person_0_surname_2 = person_0.surname(person_0_gender)
    person_0_surname_3 = person_0.surname(person_0_gender)

    person_1_surname_1 = person_1.surname(person_1_gender)
    person_1_surname_2 = person_1.surname(person_1_gender)

# Generated at 2022-06-25 21:08:03.297242
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    seed(1)
    rnd_0 = Random()
    rnd_0.seed(1)
    person_1 = Person(provider=rnd_0)
    assert person_0.nationality() == 'Korean'
    assert person_1.nationality() == person_0.nationality()
    assert person_1.nationality() != 'Korean'


# Generated at 2022-06-25 21:08:04.279060
# Unit test for method full_name of class Person
def test_Person_full_name():
    person_0 = Person()
    fullname = person_0.full_name()
    assert fullname


# Generated at 2022-06-25 21:08:22.918217
# Unit test for method surname of class Person
def test_Person_surname():
    pass


# Generated at 2022-06-25 21:08:24.329302
# Unit test for method gender of class Person
def test_Person_gender():
    person_0 = Person()
    assert isinstance(person_0.gender(), str)


# Generated at 2022-06-25 21:08:28.269123
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = str()
    data = dict()

    for i in range(10000): # change number here
        nationality_i = person.nationality()
        if nationality_i not in data:
            data[nationality_i] = 1
        else:
            data[nationality_i] += 1

    print(f'Test result:\n{data}\n\n')


# Generated at 2022-06-25 21:08:33.424722
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Randomize with a unique seed
    rnd = random.Random(5)
    person_1 = Person(rnd)
    # nationalities = person_1._data['nationality']
    # print(person_1.nationality())
    # print(person_1.nationality())
    # print(person_1.nationality())
    # print(person_1.nationality())
    # print(person_1.nationality())
    # print(person_1.nationality())
    for i in range(10):
        # print(person_1.nationality())
        pass


# Generated at 2022-06-25 21:08:35.078609
# Unit test for method surname of class Person
def test_Person_surname():
	person_0 = Person()
	# Test 0
	result = person_0.surname()
	assert result is not None


# Generated at 2022-06-25 21:08:36.164447
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    person.surname()


# Generated at 2022-06-25 21:08:38.399321
# Unit test for method gender of class Person
def test_Person_gender():
    person_0 = Person()
    assert person_0.gender() in ['Male', 'Female']


# Generated at 2022-06-25 21:08:41.869973
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0_result = person_0.surname()
    print("Method name Person.surname()", person_0_result)
    return person_0_result

test_Person_surname()

# Generated at 2022-06-25 21:08:50.276047
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname()

# Generated at 2022-06-25 21:08:56.313975
# Unit test for method nationality of class Person
def test_Person_nationality():
    with pytest.raises(NonEnumerableError):
        person_0 = Person()
        person_0.nationality()

    with pytest.raises(NonEnumerableError):
        person_0 = Person()
        person_0.nationality(Gender.MALE)

    with pytest.raises(NonEnumerableError):
        person_0 = Person()
        person_0.nationality(Gender.FEMALE)


# Generated at 2022-06-25 21:09:11.121783
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname()


# Generated at 2022-06-25 21:09:12.854474
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(0,len(SURNAMES)):
        assert(SURNAMES[i] == Person().surname())


# Generated at 2022-06-25 21:09:19.545191
# Unit test for method gender of class Person
def test_Person_gender():
    person_0 = Person()
    print('gender: ', person_0.gender())
    print('gender: ', person_0.gender(symbol=True))
    print('gender: ', person_0.gender(iso5218=True))
    print('sex: ', person_0.sex())
    print('sex: ', person_0.sex(symbol=True))
    print('sex: ', person_0.sex(iso5218=True))


# Generated at 2022-06-25 21:09:23.973785
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    
    for _ in range(100):
        assert person_0.surname() in person_0._data['surnames']


# Generated at 2022-06-25 21:09:32.199905
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    age = person.age()
    gender = person.gender();
    nationality = person.nationality(gender)

    list1 = ['Русский', 'Не имеет значения']
    list2 = ['Английский', 'Азербайджанский']

    if (age <= 17):
        assert nationality in list1
    else:
        assert nationality in list2


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 21:09:33.881133
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality(Gender.FEMALE)


# Generated at 2022-06-25 21:09:36.035069
# Unit test for method gender of class Person
def test_Person_gender():
    person_0 = Person()
    assert person_0.gender() in GENDERS


# Generated at 2022-06-25 21:09:37.396051
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname is not None


# Generated at 2022-06-25 21:09:48.015282
# Unit test for method gender of class Person
def test_Person_gender():
    # Set up
    gender_symbols = GENDER_SYMBOLS
    gender_symbols.sort()
    person_0 = Person()
    gender_set = set({})
    for i in range(10000):
        sample = person_0.gender()
        assert sample in GENDERS
        gender_set.add(sample)
    for i in range(10000):
        # There are only 4 types of unicode gender symbols
        sample = person_0.gender(symbol = True)
        assert sample in gender_symbols
        # There are only 4 types of ISO 5218 gender symbols
        sample = person_0.gender(iso5218 = True)
        assert sample in (1,2,9)
    assert len(gender_set) == 4


# Generated at 2022-06-25 21:09:51.618737
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    attr_value = person_1.random.choice(FIRST_NAMES_MALE)
    assert person_1.surname() == attr_value

# Generated at 2022-06-25 21:10:04.823717
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert person_1.nationality() in PERSON_NATIONALITIES


# Generated at 2022-06-25 21:10:10.957995
# Unit test for method gender of class Person
def test_Person_gender():
    person_1 = Person()
    value_1 = "Female"
    value_1_1 = person_1.gender(symbol=False)
    value_2 = "\U0001F469"
    value_2_1 = person_1.gender(symbol=True)
    if value_1==value_1_1:
        pass
    if value_2 == value_2_1:
        pass


# Generated at 2022-06-25 21:10:15.277123
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname() in SURNAMES
    assert person_0.surname(Gender.MALE) in SURNAMES_MALE
    assert person_0.surname(Gender.FEMALE) in SURNAMES_FEMALE


# Generated at 2022-06-25 21:10:19.542254
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Case 0
    person_0 = Person()
    nationality_0 = person_0.nationality()
    nationalities_0 = person_0._data['nationality']

    assert nationality_0 in nationalities_0
    
    # Case 1
    person_1 = Person()
    nationality_1 = person_1.nationality(Gender.MALE)
    nationalities_1 = person_1._data['nationality']['male']

    assert nationality_1 in nationalities_1


# Generated at 2022-06-25 21:10:30.789518
# Unit test for method gender of class Person
def test_Person_gender():
    #
    #  test_case_0
    #
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()
    person_0 = Person()


# Generated at 2022-06-25 21:10:33.981893
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality()
    assert nationality_0 in ('English', 'French', 'Polish', 'Portuguese', 'Romanian', 'Thai', 'Vietnamese')


# Generated at 2022-06-25 21:10:35.018839
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:10:37.148685
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    result = "Indonesian"
    person_0.set_nationality(result)
    print(person_0.get_nationality())
    assert(result == person_0.get_nationality())


# Generated at 2022-06-25 21:10:39.607071
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    assert isinstance(person_1.surname(), str)


# Generated at 2022-06-25 21:10:42.612047
# Unit test for method surname of class Person
def test_Person_surname():

    print(Person.surname.__doc__)

    person = Person()
    print(person.surname())


# Generated at 2022-06-25 21:11:13.069551
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality(Gender.FEMALE) == 'Polish'


# Generated at 2022-06-25 21:11:16.696494
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()
    person_0.nationality(Gender.female)
    person_0.nationality(Gender.male)


# Generated at 2022-06-25 21:11:18.563020
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert person_1.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:11:26.927209
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person(name=None, gender=Gender.MALE)
    person_2 = Person(name=None, gender=Gender.FEMALE)
    male_nationalities = person_1._data['nationality']['male']
    female_nationalities = person_2._data['nationality']['female']
    res_1 = person_1.nationality()
    res_2 = person_2.nationality()
    assert res_1 in male_nationalities
    assert res_2 in female_nationalities

# Generated at 2022-06-25 21:11:28.430633
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    print(person_1.surname())


# Generated at 2022-06-25 21:11:30.072338
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()

    # test your code
    assert str in [type(person_1.nationality())]


# Generated at 2022-06-25 21:11:30.815067
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:11:32.547188
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(random=Random())
    assert (type(person_0.nationality()), type(str())) == (type, type)


# Generated at 2022-06-25 21:11:35.332673
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in NATIONALITIES


# Generated at 2022-06-25 21:11:37.415031
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    print('A random surname:', person.surname())
