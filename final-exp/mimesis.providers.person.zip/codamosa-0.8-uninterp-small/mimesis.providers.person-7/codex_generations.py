

# Generated at 2022-06-25 21:06:23.788067
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    # Test 1
    assert person.gender() in "MaleFemale"


# Generated at 2022-06-25 21:06:29.624833
# Unit test for method surname of class Person
def test_Person_surname():
    # Creating object of class Person
    person = Person()
    for _ in range(10):
        # Testing method surname oclass Person
        assert isinstance(person.surname(), str)


# Generated at 2022-06-25 21:06:31.262335
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender() in GENDER


# Generated at 2022-06-25 21:06:35.899969
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    x = person.gender()
    y = person.gender()
    assert(isinstance(x,str)==True)
    assert(isinstance(y,str)==True)
    assert(x!=y)


# Generated at 2022-06-25 21:06:42.823384
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Check that full_name returns a non-empty string
    person_0 = Person()
    assert type(person_0.full_name()) is str
    assert person_0.full_name() != ''

    # Check that full_name generates a correct full name
    person_1 = Person()
    full_name_1 = person_1.full_name().split(' ')
    assert full_name_1[0] in person_1._data['name']['male']


# Generated at 2022-06-25 21:06:47.627056
# Unit test for method email of class Person
def test_Person_email():
    # Call function email of class Person
    person_0 = Person()
    email_output = person_0.email()

    # Check the email_output
    print(email_output)
    assert isinstance(email_output, str)
    assert len(email_output) >= 8
    assert email_output.count('@') == 1


# Generated at 2022-06-25 21:06:51.850934
# Unit test for method surname of class Person
def test_Person_surname():
    #pre-define test parameters
    gender = None
    #execute the function being tested
    result = Person.surname(gender)
    #assert the result we got with expected value
    assert result


# Generated at 2022-06-25 21:06:56.240667
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    ans = [person_0.nationality(), person_0.nationality(), person_0.nationality()]
    assert type(ans) == list
    for i in ans:
        assert type(i) == str


# Generated at 2022-06-25 21:06:58.496335
# Unit test for method surname of class Person
def test_Person_surname():
    surname_0 = Person().surname()
    assert_instance(surname_0, str)


# Generated at 2022-06-25 21:07:01.663558
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname = person_0.surname()
    assert type(surname) == str
    assert surname in SURNAME


# Generated at 2022-06-25 21:07:10.869090
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() != ""


# Generated at 2022-06-25 21:07:18.509690
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person(seed=1)

    nationalities = ['Russian', 'Kazakh', 'Uzbek', 'Tajik', 'Azerbaijani', 'Armenian', 'Turkmen']

    results_0 = []
    results_1 = []

    for i in range(100):
        nat_0 = person_0.nationality()
        nat_1 = person_1.nationality()

        results_0.append(nat_0)
        results_1.append(nat_1)

        assert nat_0 in nationalities
        assert nat_1 in nationalities

    assert results_0 != results_1


# Generated at 2022-06-25 21:07:20.714721
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    assert type(person_0.email()) == str


# Generated at 2022-06-25 21:07:23.195748
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    result = person.gender(iso5218=True)
    # Check that it is in the range of codes
    assert result in range(10)


# Generated at 2022-06-25 21:07:24.560575
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname()


# Generated at 2022-06-25 21:07:27.111501
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(REPETITIONS):
        person_0 = Person()
        nationality_0 = person_0.nationality()
        assert(isinstance(nationality_0, str))


# Generated at 2022-06-25 21:07:29.019602
# Unit test for method gender of class Person
def test_Person_gender():
    person_1 = Person()
    assert person_1.gender() in GENDERS
    assert person_1.sex() in GENDERS


# Generated at 2022-06-25 21:07:37.067188
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Set the random seed
    prng = random.Random(4)
    person = Person(prng)
    assert(person.nationality() == 'Russians')
    
    # Set the random seed
    prng = random.Random(4)
    person = Person(prng)
    assert(person.nationality(gender = Gender.FEMALE) == 'Russian')

test_case_0()
test_Person_nationality()

 

# Generated at 2022-06-25 21:07:44.518400
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_7 = Person()
    person_8 = Person()
    person_9 = Person()
    person_10 = Person()
    person_11 = Person()
    person_12 = Person()

    assert person_1.nationality() in NATIONALITY
    assert person_2.nationality() in NATIONALITY
    assert person_3.nationality() in NATIONALITY
    assert person_4.nationality() in NATIONALITY
    assert person_5.nationality() in NATIONALITY
    assert person_6.nationality() in NATIONALITY
    assert person_7.nationality() in NATIONALITY
    assert person_8

# Generated at 2022-06-25 21:07:45.818987
# Unit test for method gender of class Person
def test_Person_gender():
    person_0 = Person()
    person_0.gender()


# Generated at 2022-06-25 21:08:03.507278
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

    for i in range(10):
        print(person_0.nationality())


# Generated at 2022-06-25 21:08:05.181946
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    print(person.nationality(Gender.MALE))
    print(person.nationality(Gender.FEMALE))


# Generated at 2022-06-25 21:08:06.860344
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    print("surname: ", person_1.surname())


# Generated at 2022-06-25 21:08:08.104507
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str) == True, 'Invalid return type'


# Generated at 2022-06-25 21:08:14.478126
# Unit test for method surname of class Person
def test_Person_surname():

    person_0 = Person(random=Random(seed=0))
    person_1 = Person(random=Random(seed=1))
    
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0.surname() == "Fischer"
    assert person_0

# Generated at 2022-06-25 21:08:16.616818
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    result_0 = person_0.surname()
    expected_0 = "Smith"
    assert result_0 == expected_0


# Generated at 2022-06-25 21:08:19.648194
# Unit test for method gender of class Person
def test_Person_gender():

    person_0 = Person()
    person_0.gender(iso5218=True)
    person_0.gender(symbol=True)
    person_0.gender()


# Generated at 2022-06-25 21:08:23.828311
# Unit test for method nationality of class Person
def test_Person_nationality():
    rand_person = Person()
    r_nation = rand_person.nationality()
    if r_nation in NATIONALITIES:
        print("\nSUCCESS: The r_nation =", r_nation, "is in NATIONALITIES")
    else:
        print("\nFAILED: The r_nation =", r_nation, "is not in NATIONALITIES")

# Generated at 2022-06-25 21:08:30.327463
# Unit test for method gender of class Person
def test_Person_gender():
    expected = ['Male', 'Female']
    person = Person()
    gender = person.gender()
    if gender not in expected:
        raise AssertionError("Result is not in expected: {}".format(gender))


# Generated at 2022-06-25 21:08:33.012814
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person(random=Random())

    res = person_0.nationality()
    assert res is not None
    assert(isinstance(res, str))
    print("\nNationality returned from method nationality of \
Person class is " + res)


# Generated at 2022-06-25 21:09:06.085233
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    person.gender = 'man'
    person.nationality = 'Russian'
    assert person.nationality() == 'Russian'


# Generated at 2022-06-25 21:09:08.720637
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-25 21:09:11.084501
# Unit test for method nationality of class Person
def test_Person_nationality():
    tester = Person()
    assert(type(tester.nationality()) == str)


# Generated at 2022-06-25 21:09:16.062611
# Unit test for method surname of class Person
def test_Person_surname():
    person_1 = Person()
    assert isinstance(person_1.surname(), str)
    assert isinstance(person_1.surname(Gender.male), str)
    assert isinstance(person_1.surname(Gender.female), str)
    assert isinstance(person_1.surname(None), str)


# Generated at 2022-06-25 21:09:27.516140
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()
    person_3 = Person()
    person_4 = Person()
    person_5 = Person()
    person_6 = Person()
    person_7 = Person()
    person_8 = Person()
    person_9 = Person()
    person_10 = Person()
    person_11 = Person()
    person_12 = Person()
    person_13 = Person()
    person_14 = Person()
    person_15 = Person()
    person_16 = Person()
    person_17 = Person()
    person_18 = Person()
    person_19 = Person()
    person_20 = Person()
    person_21 = Person()
    person_22 = Person()
    person_23 = Person()
    person_24 = Person()

# Generated at 2022-06-25 21:09:35.550862
# Unit test for method surname of class Person
def test_Person_surname():
    # Verify that a type error is thrown when no gender is given
    with pytest.raises(NonEnumerableError):
        person_0 = Person()
        person_0.surname()

    # Verify that a type error is thrown when invalid gender is given
    with pytest.raises(IndexError):
        person_0 = Person()
        person_0.surname(Gender(3))

    # Verify that a random gender is given when gender.NOT_KNOWN is given
    person_0 = Person()
    assert person_0.surname(Gender(0)) in person_0._data['surname'][0]


# Generated at 2022-06-25 21:09:37.241353
# Unit test for method surname of class Person
def test_Person_surname():
    surname_0 = Person().surname(gender=Gender.M)
    assert isinstance(surname_0, str)


# Generated at 2022-06-25 21:09:40.625075
# Unit test for method username of class Person
def test_Person_username():
    # 1 - Arrange
    person_0 = Person()

    # 2 - Act
    username_0 = person_0.username()
    username_1 = person_0.username()

    # 3 - Assert
    assert username_0 != username_1

if __name__ == '__main__':
    test_Person_username()

# Generated at 2022-06-25 21:09:44.818206
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_0.faker.seed(0)
    email_0 = person_0.email(unique=True)
    assert email_0 == 'd_walker_michael_1909'


# Generated at 2022-06-25 21:09:52.015565
# Unit test for method surname of class Person
def test_Person_surname():
    person_a = Person()
    person_b = Person()
    person_c = Person()
    assert person_a.surname(gender=Gender.MALE.value) != person_b.surname(gender=Gender.MALE.value), "Values are the same"
    assert person_b.surname(gender=Gender.FEMALE.value) != person_c.surname(gender=Gender.FEMALE.value), "Values are the same"

# Generated at 2022-06-25 21:10:29.664018
# Unit test for method nationality of class Person
def test_Person_nationality():
    def is_inside(lst, el):
        return el in lst

    # Test Person.nationality()
    person_0 = Person()
    person_1 = Person(nationality = ['Jamaican'])
    person_2 = Person(nationality = {Gender.FEMALE: ['Jamaican']})

# Generated at 2022-06-25 21:10:34.379923
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    person_2 = Person()

    # Test that the attribute nationality of class Person is working properly
    assert person_0.nationality() != person_1.nationality()
    assert person_0.nationality() != person_2.nationality()
    assert person_1.nationality() != person_2.nationality()


# Generated at 2022-06-25 21:10:35.938222
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    assert result != ''
    assert isinstance(result, str)


# Generated at 2022-06-25 21:10:43.954399
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Case 0
    person_0 = Person()
    russian_nationality = 'Russian'
    nationality = person_0.nationality()
    assert nationality == russian_nationality

    # Case 1
    russian_male = person_0.name(Gender.male) + ' ' + person_0.surname(Gender.male)
    russian_female = person_0.name(Gender.female) + ' ' + person_0.surname(Gender.female)

    assert nationality == russian_nationality, "Case 1 test failed!"


# Generated at 2022-06-25 21:10:45.499233
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname = person_0.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-25 21:10:51.720060
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()

# Generated at 2022-06-25 21:10:54.201399
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Create an instance of Person class
    person_0 = Person()
    assert(isinstance(person_0, Person))
    # Check if the nationality is in the dataset
    assert(person_0.nationality() in person_0._data['nationality'])


# Generated at 2022-06-25 21:10:56.962999
# Unit test for method surname of class Person
def test_Person_surname():
    surname_exp = Person().surname()
    assert isinstance(surname_exp, str) == True, f"Expected type is str, got {type(surname_exp)}"


# Generated at 2022-06-25 21:11:04.320127
# Unit test for method email of class Person
def test_Person_email():
    person_1 = Person()

    email_1 = person_1.email(unique=False)
    assert type(email_1) is str
    print(email_1)

    email_2 = person_1.email(unique=True)
    assert type(email_2) is str
    print(email_2)


# Generated at 2022-06-25 21:11:12.051638
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    email_0 = person_0.email()
    assert isinstance(email_0, str)
    assert email_0.count('@') == 1
    if(person_0.random.choice(EMAIL_DOMAINS) not in email_0):
        raise AssertionError("Fails to return expected")

    person_5 = Person(seed=5)
    email_5 = person_5.email()
    assert isinstance(email_5, str)
    assert email_5.count('@') == 1
    if('@gm' not in email_5):
        raise AssertionError("Fails to return expected")


# Generated at 2022-06-25 21:11:38.095535
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    person_0.surname('M')


# Generated at 2022-06-25 21:11:40.264415
# Unit test for method surname of class Person
def test_Person_surname():
    name = Person().surname()
    assert name.upper() == name


# Generated at 2022-06-25 21:11:41.980799
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname is Person.last_name
    assert len(Person().surname()) > 0


# Generated at 2022-06-25 21:11:51.047406
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    #Test_Case_1
    assert type(person_0.surname()) == str, "person_0.surname() returns non-string"
    print("Test Case 1 of Person.surname() PASSED")

    #Test_Case_2
    assert person_0.surname()[0].islower(), "person_0.surname() returns name which doesn't start with a lowercase letter"
    print("Test Case 2 of Person.surname() PASSED")

    #Test_Case_3
    for i in range(10):
        assert person_0.surname() in person_0._data["surname"], "person_0.surname() returns name which isn't in _data[\"surname\"]"

# Generated at 2022-06-25 21:11:54.173771
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    surname_0 = person_0.surname(Gender.MALE)
    surname_1 = person_0.surname(Gender.FEMALE)
    if surname_0 in USERNAMES and surname_1 in USERNAMES:
        print('Test case 0: empty args -> success')
    else:
        print('Test case 0: empty args -> failed')


# Generated at 2022-06-25 21:11:55.277631
# Unit test for method surname of class Person
def test_Person_surname():
    test_person = Person()
    assert isinstance(test_person.surname(), str)


# Generated at 2022-06-25 21:12:00.997607
# Unit test for method surname of class Person
def test_Person_surname():
    # AssertionError: ValueError not raised for wrong type
    with pytest.raises(AssertionError):
        person_0 = Person()

        person_0.surname(type)

    # AssertionError: ValueError not raised for wrong value
    with pytest.raises(AssertionError):
        person_0 = Person()

        person_0.surname(Gender["not_valid"])

    # AssertionError: ValueError not raised for wrong value
    with pytest.raises(AssertionError):
        person_0 = Person()

        person_0.surname(TitleType["not_valid"])

    # AssertionError: ValueError not raised for wrong value
    with pytest.raises(AssertionError):
        person_0 = Person()

        person_0

# Generated at 2022-06-25 21:12:03.884522
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert type(person_0.surname()) == str
    assert len(person_0.surname()) > 0


# Generated at 2022-06-25 21:12:08.099377
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Create new instance of class Person
    person_0 = Person()

    # Check if the nationalities are strings
    counter = 0
    while counter < len(person_0._data['nationality']):
        # Assert the condition
        assert isinstance(person_0.nationality(), str)
        # Increment the counter
        counter += 1

    # Check if the nationalities are separated by gender
    counter = 0
    while counter < len(person_0._data['nationality']['male']):
        # Assert the condition
        assert isinstance(person_0.nationality(Gender(1)), str)
        # Increment the counter
        counter += 1

    counter = 0

# Generated at 2022-06-25 21:12:10.465458
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert type(nationality) == str


# Generated at 2022-06-25 21:12:40.454103
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    nationalities = person_1._data['nationality']
    assert person_1.nationality() in nationalities


# Generated at 2022-06-25 21:12:41.646637
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert len(surname)>0


# Generated at 2022-06-25 21:12:47.528669
# Unit test for method surname of class Person
def test_Person_surname():
    # Test case #0
    person_0 = Person(seed=12743)
    person_0_surname = person_0.surname()
    assert person_0_surname == 'Данилин'
    person_0_surname = person_0.surname(Gender.FEMALE)
    assert person_0_surname == 'Авдейко'
    person_0_surname = person_0.surname(Gender(0))
    assert person_0_surname == 'Лопатина'
    person_0_surname = person_0.surname(gender=None)
    assert person_0_surname == 'Кретинец'
    assert person_0

# Generated at 2022-06-25 21:12:52.059706
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert hasattr(person_1, "nationality"), "No nationalities"
    assert callable(getattr(person_1, "nationality")), "The method is not callable"


# Generated at 2022-06-25 21:12:54.094328
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert type(person_0.surname()) is str


# Generated at 2022-06-25 21:12:55.321191
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    assert isinstance(person_1.nationality(), str), 'Wrong type.'


# Generated at 2022-06-25 21:12:56.107716
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality()


# Generated at 2022-06-25 21:13:00.768091
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    # Initialize
    person_0._data = {}
    person_0._data['name'] = {}
    person_0._data['name'][0] = {}
    person_0._data['name'][0][0] = {}
    person_0._data['name'][0][0][0] = ["A", "B", "C"]
    person_0._data['name'][0][0][1] = ["D", "E", "F"]
    person_0._data['name'][0][0][2] = ["G", "H", "I"]
    person_0._data['name'][1] = {}
    person_0._data['name'][1][0] = {}

# Generated at 2022-06-25 21:13:02.808094
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert person_0.surname()



# Generated at 2022-06-25 21:13:08.587676
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in ['Russian', 'American', 'Chinese', 'French', 'Brazilian']

# Unit test of method sex of class Person

# Generated at 2022-06-25 21:14:02.311266
# Unit test for method email of class Person
def test_Person_email():
    person = Person(random=Random(42))
    person.email()

# Test for method title of class Person

# Generated at 2022-06-25 21:14:03.891050
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    for _ in range(100):
        assert isinstance(person_0.nationality(), str)
