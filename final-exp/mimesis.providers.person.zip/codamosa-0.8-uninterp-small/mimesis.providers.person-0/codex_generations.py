

# Generated at 2022-06-25 21:06:34.025962
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname(gender=None)
    #print(str_0)


# Generated at 2022-06-25 21:06:41.464107
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    str_0 = person_0.nationality()
    str_1 = person_0.nationality()
    str_2 = person_0.nationality()
    str_3 = person_0.nationality()
    str_4 = person_0.nationality()
    str_5 = person_0.nationality()
    str_6 = person_0.nationality()
    str_7 = person_0.nationality()
    str_8 = person_0.nationality()
    str_9 = person_0.nationality()


# Generated at 2022-06-25 21:06:44.569761
# Unit test for method nationality of class Person
def test_Person_nationality():
    rnd_person = Person()
    str_0 = rnd_person.nationality()
    assert (type(str_0) == str)


# Generated at 2022-06-25 21:06:46.769885
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_1 = Person()
    str_0 = person_1.nationality()


# Generated at 2022-06-25 21:06:49.899655
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname(gender=Gender.MALE)
    assert str_0 in SURNAME, "surname is not in SURNAME"


# Generated at 2022-06-25 21:06:57.706631
# Unit test for method surname of class Person
def test_Person_surname():
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())
    print(Person().surname())


# Generated at 2022-06-25 21:06:59.188329
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert isinstance(Person().nationality(), str)



# Generated at 2022-06-25 21:07:01.979000
# Unit test for method surname of class Person
def test_Person_surname():
    # Init variables for test
    person_0 = Person()
    str_0 = person_0.surname()


# Generated at 2022-06-25 21:07:04.701811
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    str_0 = person_0.surname()
    assert isinstance(str_0, str)
    assert len(str_0) > 1


# Generated at 2022-06-25 21:07:07.878283
# Unit test for method email of class Person
def test_Person_email():
    random.seed(0)
    person_0 = Person()
    email_0 = person_0.email()
    assert email_0 == 'Dolores2017@gmail.com'

# Test method password of class Person in <module> for default parameters

# Generated at 2022-06-25 21:07:28.148557
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test index 0
    person_0 = Person()

    # Test index 1
    person_1 = Person()

    # Test index 2
    person_2 = Person()

    # Test index 3
    person_3 = Person()

    # Test index 4
    person_4 = Person()

    # Test index 5
    person_5 = Person()

    # Test index 6
    person_6 = Person()

    # Test index 7
    person_7 = Person()

    # Test index 8
    person_8 = Person()

    # Test index 9
    person_9 = Person()


# Generated at 2022-06-25 21:07:30.624013
# Unit test for method surname of class Person
def test_Person_surname():
    print('Test Person.surname')
    person_0 = Person()
    print('method surname returns: ' + person_0.surname())


# Generated at 2022-06-25 21:07:31.899018
# Unit test for method email of class Person
def test_Person_email():
    person_0 = Person()
    person_0.email()


# Generated at 2022-06-25 21:07:42.596916
# Unit test for method username of class Person
def test_Person_username():
    #Test 0
    person_0 = Person()
    template_0 = '#'
    actual_result_0 = person_0.username(template_0)
    expected_result_0 = 'd'

    assert actual_result_0 == expected_result_0
    print("PASSED: Person.username test case 0")
    #Test 1
    person_1 = Person()
    template_1 = '##'
    actual_result_1 = person_1.username(template_1)
    expected_result_1 = 'dd'

    assert actual_result_1 == expected_result_1
    print("PASSED: Person.username test case 1")
    #Test 2
    person_2 = Person()
    template_2 = '###'
    actual_result_2 = person_2.username(template_2)
   

# Generated at 2022-06-25 21:07:44.954701
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert re.match(r'^.+@[^\.].*\.[a-z]{2,}$', person.email())


# Generated at 2022-06-25 21:07:47.439144
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    nationality = p.nationality()
    assert (nationality != None)
    assert (type(nationality) == str)


# Generated at 2022-06-25 21:07:50.046995
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    person.nationality('male')
    assert person.nationality('male') in PERSON_DATASET['nationality']['male']


# Generated at 2022-06-25 21:07:52.540918
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()


# Generated at 2022-06-25 21:07:55.199803
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    assert person_0.nationality() in ['Russian', 'American', 'British', 'German', 'Mexican']


# Generated at 2022-06-25 21:07:58.120507
# Unit test for method surname of class Person
def test_Person_surname():
    seed(0)
    person_0 = Person()
    assert person_0.surname(gender=Gender.FEMALE) == 'Грибова'


# Generated at 2022-06-25 21:08:28.136368
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    nationality_0 = person_0.nationality(Gender.Male)
    nationality_1 = person_0.nationality(Gender.Female)
    # print(nationality_0)
    # print(nationality_1)
    # nationality_2 = person_0.nationality()
    # nationality_3 = person_0.nationality()
    # print(nationality_2)
    # print(nationality_3)


# Generated at 2022-06-25 21:08:29.705845
# Unit test for method surname of class Person
def test_Person_surname():
    person_0 = Person()
    assert isinstance(person_0.surname(), str)


# Generated at 2022-06-25 21:08:32.154347
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    print("\nThis is test for method nationality of class Person:\n")
    print("Random nationality is: " + person_0.nationality())

#Unit tests for method name of class Person

# Generated at 2022-06-25 21:08:40.450713
# Unit test for method email of class Person
def test_Person_email():
    seed_ = 77939
    rnd = random.Random(seed_)
    person_1 = Person(seed=seed_)
    email_1 = person_1.email()
    assert email_1 == 'r.l@aol.co.uk'
    email_2 = person_1.email()
    assert email_2 == 'r.r@gmail.com'
    email_3 = person_1.email()
    assert email_3 == 'h.j@aol.co.uk'
    email_4 = person_1.email()
    assert email_4 == 'e.d@yahoo.com'
    email_5 = person_1.email()
    assert email_5 == 'c.l@yahoo.com'
    email_6 = person_1.email()

# Generated at 2022-06-25 21:08:42.939948
# Unit test for method nationality of class Person
def test_Person_nationality():
    code = '''
    person_0 = Person()
    '''

    result = timeit.timeit(code, number=1000, globals=globals())
    assert result < 1

# Generated at 2022-06-25 21:08:44.079131
# Unit test for method nationality of class Person
def test_Person_nationality():
    _ = Person()
    assert _.nationality()


# Generated at 2022-06-25 21:08:45.241469
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    person.surname() # it should not throw any error

# Generated at 2022-06-25 21:08:46.728294
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert not person.email() == person.email()


# Generated at 2022-06-25 21:08:51.994584
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_1 = Person()
    bol_0 = (person_0 == person_1)
    assert(bol_0)
    person_0 = Person(seed=random.uniform(0, 1))
    person_1 = Person(seed=random.uniform(0, 1))
    bol_0 = (person_0 == person_1)
    assert(bol_0)


# Generated at 2022-06-25 21:08:54.338119
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_0 = Person()
    person_0.nationality()
