

# Generated at 2022-06-12 02:21:46.247468
# Unit test for method email of class Person
def test_Person_email():
    i = 0
    while i < 100:
        provider = Person()
        assert re.match(r"^[a-zA-Z0-9_]+@[a-zA-Z0-9]+\.com$", provider.email())
        i += 1
 
test_Person_email()

# Generated at 2022-06-12 02:21:51.012668
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    data = []
    for _ in range(100):
        data.append(p.nationality())
    assert len(list(set(data))) > 1
    assert 'Россия' in list(set(data))


# Generated at 2022-06-12 02:21:53.085923
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() == 'Иванов'


# Generated at 2022-06-12 02:21:55.046792
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person()    
    assert len(p.full_name()) > 1


# Generated at 2022-06-12 02:22:01.388672
# Unit test for method nationality of class Person
def test_Person_nationality():
    persons = [
        Person(random=Random(1)),
        Person(random=Random(2)),
        Person(random=Random(3)),
        Person(random=Random(4)),
        Person(random=Random(5)),
        Person(random=Random(6)),
        Person(random=Random(7)),
        Person(random=Random(8)),
        Person(random=Random(9)),
        Person(random=Random(10)),
    ]
    assert_all(persons, 'nationality', 'Russian')



# Generated at 2022-06-12 02:22:03.311528
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    print(p.nationality())

test_Person_nationality()


# Generated at 2022-06-12 02:22:08.479256
# Unit test for method surname of class Person
def test_Person_surname():
    
    # Generate random person
    tester = Person()

    # Generate 100 surnames
    surnames = [tester.surname() for _ in range(100)]

    # Check all surnames have a length
    assert all([len(x) > 0 for x in surnames])

# Generated at 2022-06-12 02:22:11.332749
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname
    assert isinstance(surname, str)

# Generated at 2022-06-12 02:22:13.737997
# Unit test for method nationality of class Person
def test_Person_nationality():
    d = Person(seed=1)
    gen = d.nationality()
    assert gen == 'Russian'
    


# Generated at 2022-06-12 02:22:21.776266
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with default data
    from faker.providers import person
    from . import utils

    faker = utils.Fake()
    faker.add_provider(person)

    nationalities = faker.nationality()
    assert nationalities != None

    # Test with custom data
    faker.seed(1)
    faker.add_provider(person, {'nationality': ('Bulgarian', 'Russian')})

    nationalities = faker.nationality()
    assert nationalities != None


# Generated at 2022-06-12 02:22:31.242180
# Unit test for method nationality of class Person
def test_Person_nationality():
    # prepare the test
    person = Person(rnd=MT19937(seed=123456789))

    # test
    result = person.nationality(Gender.MALE)

    # verify
    assert result == 'Russian'


# Generated at 2022-06-12 02:22:38.621439
# Unit test for method full_name of class Person
def test_Person_full_name():
    """
    Test function for method full_name of class Person.
    """
    from random import randint
    from fake_data_generator.enum import Gender

    gender = Gender.male
    names = ('Сергей', 'Александр', 'Алексей', 'Иван', 'Максим', 'Дмитрий',
             'Альберт', 'Роман', 'Михаил', 'Василий')
    surname = 'Петров'

    # first name and last name
    for i in range(10):
        p = Person()

# Generated at 2022-06-12 02:22:43.450871
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    person = Person()
    results = []

    # Act
    for _ in range(0, 1000):
        results.append(person.nationality())

    # Assert
    assert str in map(type, results)

# Generated at 2022-06-12 02:22:45.718578
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']



# Generated at 2022-06-12 02:22:53.676662
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Seed 1
    test_nationality_1 = Person('test_nationality_1').nationality()
    control_nationality_1 = 'Russian'
    assert test_nationality_1 == control_nationality_1

    # Seed 2
    test_nationality_2 = Person('test_nationality_2').nationality()
    control_nationality_2 = 'Estonian'
    assert test_nationality_2 == control_nationality_2

    # Seed 3
    test_nationality_3 = Person('test_nationality_3').nationality()
    control_nationality_3 = 'Spanish'
    assert test_nationality_3 == control_nationality_3

# Validation test for method nationality of class Person

# Generated at 2022-06-12 02:22:57.050112
# Unit test for method surname of class Person
def test_Person_surname():
    generator = Person(seed=1)
    mask = '###-##/##'
    assert generator.identifier(mask) == '08-69/93'

# Generated at 2022-06-12 02:23:00.266995
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pydbgen import pydbgen
    mydb = pydbgen.pydb()
    data = mydb.nationality()
    assert len(data) > 0
    assert data in [data]


# Generated at 2022-06-12 02:23:05.849430
# Unit test for method email of class Person
def test_Person_email():
    from faker_ru.providers.person import Person
    
    provider = Person()
    
    assert isinstance(provider.email(), str)
    assert '@' in provider.email()
    assert isinstance(provider.email(unique=True), str)
    
    

# Generated at 2022-06-12 02:23:09.295606
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    f = Faker(locale='en')
    name = f.surname()
    assert isinstance(name, str)


# Generated at 2022-06-12 02:23:16.660043
# Unit test for method nationality of class Person
def test_Person_nationality():
    from fake_useragent import FakeUserAgent
    from fake_useragent.errors import FakeUserAgentError
    ua = FakeUserAgent()
    try:
        user_agent = ua.random
        # print(user_agent)
    except FakeUserAgentError:
        print('Cannot generate user-agent')
        raise

    # print(user_agent)
    p = Person(locale='en', user_agent=user_agent)
    nationality = p.nationality()
    # print(nationality)
    assert len(nationality) > 0



# Generated at 2022-06-12 02:23:27.641463
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    person = Person(random.Random())
    expected = 'Russian'
    # Act
    actual = person.nationality()
    # Assert
    assert (expected == actual)

# Generated at 2022-06-12 02:23:28.858849
# Unit test for method full_name of class Person
def test_Person_full_name():
    print(Person().full_name())



# Generated at 2022-06-12 02:23:32.232466
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(10):
        nationality = Person().nationality('male')
        assert type(nationality) is str
        assert nationality == 'Russian'
test_Person_nationality()


# Generated at 2022-06-12 02:23:36.386859
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Unit test for method surname of class Person
    """
    # Initialize the class
    person = Person(seed=123456789)
    # Get the first name
    surname = person.surname()
    # Check the outcome
    assert surname == 'Hauser', 'Wrong surname'

# Generated at 2022-06-12 02:23:40.748026
# Unit test for method email of class Person
def test_Person_email():
    # Check the generation of random emails
    # with a list of custom domains.

    person = Person()
    result = person.email(domains=('example.com', 'example.net'))
    assert '@example.com' in result or '@example.net' in result

# Generated at 2022-06-12 02:23:51.919742
# Unit test for method nationality of class Person
def test_Person_nationality():
    print('Testing function nationality...', end='')
    # Test with default gender
    person1 = Person()
    nationalities1 = [person1.nationality() for i in range(100)]
    nationalities1.sort()
    assert(nationalities1[-1] == 'Ukrainian')
    assert(nationalities1[0] == 'Albanian')
    # Test with male gender
    person2 = Person()
    nationalities2 = [person2.nationality(gender=Gender.MALE) for i in range(100)]
    # Test with female gender
    person3 = Person()
    nationalities3 = [person3.nationality(Gender.FEMALE) for i in range(100)]
    # Test with constant seed
    person4 = Person(seed=42)

# Generated at 2022-06-12 02:24:01.579755
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() == "Swiss"
    assert Person().nationality() == "Zimbabwean"
    assert Person().nationality() == "Korean"
    assert Person().nationality() == "Spanish"
    assert Person().nationality() == "Russian"
    assert Person().nationality() == "Mongolian"
    assert Person().nationality() == "French"
    assert Person().nationality() == "Finnish"
    assert Person().nationality() == "South Korean"
    assert Person().nationality() == "Egyptian"
    assert Person().nationality() == "Taiwanese"
    assert Person().nationality() == "British"
    assert Person().nationality() == "Australian"
    assert Person().nationality() == "Vietnamese"
    assert Person().nationality() == "Mexican"
    assert Person

# Generated at 2022-06-12 02:24:08.497768
# Unit test for method surname of class Person
def test_Person_surname():
    # create mocker
    mocker = Mocker()

    # create instance of class Person
    random = mocker.mock()
    data = mocker.mock()
    obj = Person(random, data)

    # mock next method
    random.choice((None, None))
    mocker.result(None)

    # -----------------
    # Test: #1
    # -----------------
    surnames = [None, None]

    # replay
    mocker.replay()

    # test
    assert obj.surname(surnames) is None

    # -----------------
    # Test: #2
    # -----------------
    surnames = {Gender.Male: None, Gender.Female: None}

    # replay
    mocker.replay()

    # test

# Generated at 2022-06-12 02:24:15.728722
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person().full_name() in ('Aaron Cordova', 'Ada Douglas', 'Alan Nguyen',
                                    'Alexander Jones', 'Alexander Long', 'Alexander Mason',
                                    'Alexander Perez', 'Amanda Duncan', 'Amanda Green',
                                    'Amanda Hall', 'Amanda James', 'Amanda King', 'Amanda Lewis',
                                    'Amanda Martin', 'Amanda Moore', 'Amanda Murphy', 'Amanda Spencer',
                                    'Amanda Thompson')



# Generated at 2022-06-12 02:24:19.406651
# Unit test for method surname of class Person
def test_Person_surname():
    person = data.Person()
    assert isinstance(person.surname(), str)
    assert len(person.surname()) >= 2


# Generated at 2022-06-12 02:24:39.924355
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    nationality = p.nationality()
    assert nationality
    assert isinstance(nationality, str)
    assert len(nationality) > 1
    assert len(nationality) < 30
    
    

# Generated at 2022-06-12 02:24:47.462328
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname("female") in p._data['surname']["female"]
    assert p.surname("male") in p._data['surname']["male"]
    assert p.surname("any") in p._data['surname']["female"] or p.surname("any") in p._data['surname']["male"]
    


# Generated at 2022-06-12 02:24:48.775099
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    print(person.nationality())


# Generated at 2022-06-12 02:24:50.818928
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    method = person.nationality
    method()

# Generated at 2022-06-12 02:25:02.750877
# Unit test for method nationality of class Person
def test_Person_nationality():
    from fake2db.providers import Person
    person = Person(random=Random())
    assert person.nationality() in person._data['nationality']
    assert person.nationality() in person._data['nationality'][Gender.MALE]
    assert person.nationality() in person._data['nationality'][Gender.FEMALE]
    assert person.nationality(gender=Gender.MALE) in person._data['nationality'][Gender.MALE]
    assert person.nationality(gender=Gender.FEMALE) in person._data['nationality'][Gender.FEMALE]
    assert person.nationality(gender='female') in person._data['nationality'][Gender.FEMALE]
    assert person.nationality(gender='male') in person._data['nationality'][Gender.MALE]
# Example of usage

# Generated at 2022-06-12 02:25:04.985058
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(10):
        p = Person()
        assert isinstance(p.nationality(), str)



# Generated at 2022-06-12 02:25:10.233830
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname('male')
    assert hasattr(person, 'surname')
    assert isinstance(surname, str)
    assert surname in ["carter", "allen", "mitchell", "james"]

# Generated at 2022-06-12 02:25:12.911059
# Unit test for method email of class Person
def test_Person_email():
    from random import Random
    rnd = Random(1)
    p = Person(rnd=rnd)
    assert (p.email() == 'noguchi_1961@gmail.com')

# Generated at 2022-06-12 02:25:14.331189
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Check if the method return is string
    assert True == isinstance(Person().nationality(), str)



# Generated at 2022-06-12 02:25:19.216323
# Unit test for method username of class Person
def test_Person_username():
    provider = Person()
    username = provider.username()
    assert username == 'l.d', providers_errors_msg.format(
        provider='username',
        value=username,
        expected='l.d'
    )
    username = provider.username(template='U_d')
    assert username == 'U_d', providers_errors_msg.format(
        provider='username',
        value=username,
        expected='U_d'
    )
    username = provider.username(template='l.d')
    assert username == 'l.d', providers_errors_msg.format(
        provider='username',
        value=username,
        expected='l.d'
    )
    username = provider.username(template='U')

# Generated at 2022-06-12 02:28:25.031943
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)



# Generated at 2022-06-12 02:28:26.714444
# Unit test for method email of class Person
def test_Person_email():
    pass


# Generated at 2022-06-12 02:28:29.157214
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    provider = Person()

    # Act
    actual_value = provider.nationality()

    # Assert
    assert actual_value in ['Russian', 'Belarussian', 'Ukrainian']

# Generated at 2022-06-12 02:28:37.644572
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Case 1: get a random nationality
    name = zufall.Person.nationality()
    assert isinstance(name, str)

    # Case 2: get a random nationality with gender
    name = zufall.Person.nationality(gender=zufall.Gender.Male)
    assert isinstance(name, str)

    # Case 3: get a random nationality by male
    name = zufall.Person.nationality(gender=1)
    assert isinstance(name, str)

    # Case 4: get a random nationality with incorrect gender
    with pytest.raises(zufall.NonEnumerableError):
        zufall.Person.nationality(gender=None)

    # Case 5: get a random nationality by incorrect gender

# Generated at 2022-06-12 02:28:39.384776
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nat = person.nationality()
    print(nat)
    #assert isinstance(nat, str)

# Generated at 2022-06-12 02:28:41.291830
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality( ) in NATIONALITIES


# Generated at 2022-06-12 02:28:49.284150
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), type("string"))
    assert isinstance(p.surname(Gender.male), type("string"))
    assert isinstance(p.surname(Gender.female), type("string"))
    assert isinstance(p.surname("male"), type("string"))
    assert isinstance(p.surname("female"), type("string"))
    assert isinstance(p.surname(1), type("string"))
    assert isinstance(p.surname(2), type("string"))
    assert isinstance(p.surname("1"), type("string"))
    assert isinstance(p.surname("2"), type("string"))

# Generated at 2022-06-12 02:28:56.388648
# Unit test for method surname of class Person
def test_Person_surname():
    # Default behavior
    surname = Person().surname()
    assert isinstance(surname, str) and len(surname) > 0
    assert surname in SURNAMES

    # Surnames separated by gender.
    man = Person(gender=Gender.MAN)
    woman = Person(gender=Gender.WOMAN)
    assert man.surname() in MALE_SURNAMES
    assert woman.surname() in FEMALE_SURNAMES


# Generated at 2022-06-12 02:28:58.381903
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(random=Random())
    for _ in range(100):
        expected = isinstance(person.surname(), str)
        assert expected

# Generated at 2022-06-12 02:29:02.231753
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email().count('@') == 1
    assert p.email().count('.') == 1
    assert p.email(domains='example.com').endswith('@example.com')
