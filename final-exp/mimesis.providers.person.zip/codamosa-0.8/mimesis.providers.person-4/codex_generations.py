

# Generated at 2022-06-12 02:21:51.275670
# Unit test for method surname of class Person
def test_Person_surname():
    test_cases = [
        ('Roger', None),
        ('Moriarty', Gender.male),
        ('Baker', Gender.female),
        ('Caldwell', Gender.indeterminate),
        ('Johnston', Gender.intersex),
        ('Doe', Gender.not_applicable),
        ('King', Gender.other)
    ]
    for i in range(10):
        # Arrange
        rnd = Random()
        name = Person(rnd=rnd)
        # Act
        results = [name.surname(gender=gender) for gender in Gender]
        # Assert
        for result, expected in zip(results, test_cases):
            assert result == expected[0]
        


# Generated at 2022-06-12 02:21:56.268353
# Unit test for method email of class Person
def test_Person_email():
    iperson = Person()
    res = iperson.email()
    assert isinstance(res, str)
    assert len(res.split('@')) == 2
    assert len(res.split('@')[0]) > 0
    assert len(res.split('@')[1]) > 0
    
    

# Generated at 2022-06-12 02:21:57.524134
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == p.email()

# Generated at 2022-06-12 02:21:59.931233
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationalities = person._data['nationality']
    user_nationality = person.nationality()
    assert user_nationality in nationalities

# Generated at 2022-06-12 02:22:01.080544
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    person.surname()

# Generated at 2022-06-12 02:22:02.973237
# Unit test for method surname of class Person
def test_Person_surname():
    Person = Person()
    x = Person.surname()
    assert isinstance(x, str)

# Generated at 2022-06-12 02:22:06.135042
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(get_random_seed())
    surname = person.surname()
    assert surname in SURNAMES
    assert isinstance(surname, str)


# Generated at 2022-06-12 02:22:09.575356
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() == 'Greek'
    assert Person().nationality(Gender.FEMALE) == 'Brazilian'
    assert Person().nationality(Gender.MALE) == 'Ukrainian'


# Generated at 2022-06-12 02:22:11.585748
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(), str)



# Generated at 2022-06-12 02:22:13.590478
# Unit test for method surname of class Person
def test_Person_surname():
    name = Person(seed=0).surname()
    print(name)
    assert name == 'Кохан'
    print('Pass')

# Generated at 2022-06-12 02:22:21.366782
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname()
    assert Person().last_name()
    assert Person().surname(Gender.MALE)
    assert Person().surname(Gender.FEMALE)


# Generated at 2022-06-12 02:22:24.115594
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    print(surname)
    assert isinstance(surname, str)



# Generated at 2022-06-12 02:22:26.017158
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality() == Person.nationality()

# Generated at 2022-06-12 02:22:30.118802
# Unit test for method nationality of class Person
def test_Person_nationality():
    doc = """Unit test for method nationality of class Person."""
    # Unit test for method nationality
    r = random.Random()
    p = Person(random=r)
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-12 02:22:32.218590
# Unit test for method nationality of class Person
def test_Person_nationality():
    serial = 0
    for nationality in Person.nationality:
        serial += 1
        print(serial,nationality)
    return

# Generated at 2022-06-12 02:22:42.913692
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:22:45.954144
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Nationality Немецкий
    assert Person().nationality() in ('Немецкий', 'German')

# Generated at 2022-06-12 02:22:48.998372
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    
    assert type(p.surname()) == str
    assert type(p.surname(Gender.MALE)) == str
    assert type(p.surname(Gender.FEMALE)) == str

# Generated at 2022-06-12 02:22:51.703691
# Unit test for method nationality of class Person
def test_Person_nationality():
    np = Provider()
    for _ in range(10):
        nationality = np.nationality(gender=Gender.male)
        print(nationality)


# Generated at 2022-06-12 02:22:56.008136
# Unit test for method nationality of class Person
def test_Person_nationality():
    # When
    p = Person()
    actual = p.nationality()
    print(actual)

    # Then
    expected = "Russian"
    assert actual == expected

test_Person_nationality()


# Generated at 2022-06-12 02:23:13.072177
# Unit test for method username of class Person
def test_Person_username():
    def test_template(template: Optional[str]) -> bool:
        if template is None:
            return True

        return bool(re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', template))

    symbol_placeholders = [None, '#', 'U', 'l', 'd', '_', '.', '-']
    templates = [None] + ['U_d', 'U.d', 'U-d', 'UU-d', 'UU.d', 'UU_d',
                          'ld', 'l-d', 'Ud', 'l.d', 'l_d']


# Generated at 2022-06-12 02:23:15.201433
# Unit test for method nationality of class Person
def test_Person_nationality():
    faker = Person()

    value = faker.nationality()
    assert value in faker._data['nationality']
test_Person_nationality()

# Generated at 2022-06-12 02:23:25.361378
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    for i in range(10):
        surname = person.surname(gender='female')
        print(surname)
    print()

    surnames = ['Петров', 'Иванов', 'Сидоров']
    for i in range(10):
        surname = person.surname(surnames)
        print(surname)
    print()

    surnames = {'male': ['Петров', 'Иванов'],
                'female': ['Петрова', 'Иванова']}
    for i in range(10):
        surname = person.surname(surnames)
        print(surname)
    print()

   

# Generated at 2022-06-12 02:23:29.624852
# Unit test for method nationality of class Person
def test_Person_nationality():
    @given(person(nationality=nationality('Russia')))
    def test_nationality(person):
        assert person.nationality == 'Russia'

    test_nationality()

# Generated at 2022-06-12 02:23:32.761837
# Unit test for method nationality of class Person
def test_Person_nationality():
    print("test_Person_nationality")

    rnd = Random()
    p = Person(rnd)
    print(p.nationality())
    
#test_Person_nationality()

# Generated at 2022-06-12 02:23:34.913378
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email('yahoo.com', unique=False) == 'foretime10@yahoo.com'

# Generated at 2022-06-12 02:23:39.235265
# Unit test for method email of class Person
def test_Person_email():
    from datetime import datetime

    from faker import Faker
    from faker_e164.providers.person import Provider as PersonProvider

    fake = Faker()
    fake.add_provider(PersonProvider)

    email = fake.email()
    assert isinstance(email, str)
    assert email.count('.') == 1
    assert email.count('@') == 1


# Generated at 2022-06-12 02:23:43.685012
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surnames = person._data['surname']
    surnames_list = []
    for k in surnames.keys():
        surnames_list += surnames[k]
    
    assert person.surname() in surnames_list


# Generated at 2022-06-12 02:23:45.867394
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(de_DE)
    assert isinstance(person.surname(), str)


# Generated at 2022-06-12 02:23:48.370788
# Unit test for method surname of class Person
def test_Person_surname():
   try:
      person = Person(random = Random())
      result = person.surname(gender = Gender.Male)
   except Exception as e:
      print(e)

# Generated at 2022-06-12 02:23:56.778733
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-12 02:23:59.510030
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test doc."""
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']
    assert isinstance(nationality, str)



# Generated at 2022-06-12 02:24:07.241323
# Unit test for method username of class Person
def test_Person_username():
    p = Person(random=Random())
    assert p.username(template='ld') == '1.1970'
    assert p.username(template='l-d') == '1-1970'
    assert p.username(template='l_d') == '1_1970'
    assert p.username(template='lld') == '111970'
    assert p.username(template='ll-d') == '11-1970'
    assert p.username(template='Ud') == 'E1970'
    assert p.username(template='U_d') == 'E_1970'
    assert p.username(template='U.d') == 'E.1970'
    assert p.username(template='Ul.d') == 'Eo.1970'
    assert p.username(template='Ul-d') == 'Eo-1970'
    assert p

# Generated at 2022-06-12 02:24:17.160518
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:24:25.452044
# Unit test for method nationality of class Person
def test_Person_nationality():
    person1 = Person(seed=42)
    assert person1.nationality() == 'Armenian'
    assert person1.nationality() == 'Armenian'
    assert person1.nationality() == 'Armenian'
    assert person1.nationality(gender=Gender.MALE) == 'Armenian'
    assert person1.nationality(gender=Gender.FEMALE) == 'Armenian'
    assert person1.nationality(gender=Gender.FEMALE) == 'Armenian'
    assert person1.nationality(gender=Gender.FEMALE) == 'Armenian'
    assert person1.nationality(gender=Gender.FEMALE) == 'Armenian'
    assert person1.nationality(gender=Gender.FEMALE) == 'Armenian'


# Generated at 2022-06-12 02:24:32.028038
# Unit test for method nationality of class Person
def test_Person_nationality():
    generator = Generator()
    person = Person(generator)
    
    # Check if method nationality return random nationality
    assert person.nationality() in NATIONALITY
    # Check if method nationality return random nationality for male
    assert person.nationality(gender=Gender.Male) in NATIONALITY_MALE
    # Check if method nationality return random nationality for female
    assert person.nationality(gender=Gender.Female) in NATIONALITY_FEMALE

# Generated at 2022-06-12 02:24:34.009259
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    assert provider.nationality() in self._data['nationality']

# Generated at 2022-06-12 02:24:38.545280
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    surname_reverse = person.surname(reverse=True)
    surname_gender = person.surname(Gender.FEMALE)
    print('Last name:', surname, surname_reverse, surname_gender)


# Generated at 2022-06-12 02:24:44.199779
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname(Person) == 'Васильєв'
    assert Person.surname(Person, Gender.MALE) == 'Васильєв'
    assert Person.surname(Person, Gender.FEMALE) == 'Васильєва'

# Generated at 2022-06-12 02:24:47.277771
# Unit test for method nationality of class Person
def test_Person_nationality():
    with pytest.raises(NonEnumerableError):
        Person().nationality(1)


# Generated at 2022-06-12 02:24:58.915367
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert 'Русский' == Person().nationality()

# Generated at 2022-06-12 02:25:04.676223
# Unit test for method nationality of class Person
def test_Person_nationality():
    print("Testing Person.nationality()")
    gender_male = Gender.MALE
    gender_female = Gender.FEMALE
    gender_not_known = Gender.NOT_KNOWN
    gender_not_applicable = Gender.NOT_APPLICABLE
    gender_not_spec = Gender.NOT_SPECIFIED

    target = Person()
    result = target.nationality()
    print("Result for nationalities: " + result)
    result = target.nationality(gender=gender_male)
    print("Result for male nationalities: " + result)
    result = target.nationality(gender=gender_female)
    print("Result for female nationalities: " + result)
    result = target.nationality(gender=gender_not_known)
    print("Result for not known nationalities: " + result)

# Generated at 2022-06-12 02:25:14.367585
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test function
    def test(method: Callable, input_data: Any, output_data: Any,
             method_name: str, class_name: str) -> str:
        # Test result
        result = method(input_data)
        if result == output_data:
            return 'OK'
        return 'Error: {}.{}({}) is {}, should be {}.' \
               ''.format(class_name, method_name, input_data, result, output_data)

    # Test variables
    test_class = Person
    test_method = test_class.nationality
    test_method_name = test_method.__name__
    test_class_name = test_class.__name__

    nationality = 'Turkish'
    gender = Gender.MAIL

    # Test

# Generated at 2022-06-12 02:25:16.364568
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    username = person.username()
    assert re.fullmatch(r'[a-z]*[a-z]', username)
    assert isinstance(username, str)


# Generated at 2022-06-12 02:25:21.798917
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person."""
    gender = Gender.MALE
    surname = Person.random().surname(gender)
    assert surname in SURNAME_MALE

    gender = Gender.FEMALE
    surname = Person.random().surname(gender)
    assert surname in SURNAME_FEMALE

    assert len(Person.random().surname()) > 0



# Generated at 2022-06-12 02:25:23.502479
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(1000):
        assert Person().nationality() in NATIONALITIES



# Generated at 2022-06-12 02:25:27.378139
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.Male), str)
    assert isinstance(person.surname(gender=Gender.Female), str)


# Generated at 2022-06-12 02:25:29.435897
# Unit test for method surname of class Person
def test_Person_surname():
    name = Person.surname()
    assert name != None
print("Method «surname» seems to work")


# Generated at 2022-06-12 02:25:30.926189
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-12 02:25:31.862887
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert callable(Person.nationality)

# Generated at 2022-06-12 02:25:44.277579
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    test_surnames = [p.surname(), p.surname(), p.surname()]
    assert test_surnames != [None, None, None]


# Generated at 2022-06-12 02:25:45.908734
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    p.surname(gender=Gender.MALE)


# Generated at 2022-06-12 02:25:47.486144
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        country = Person().nationality()
        assert type(country) == str

# Generated at 2022-06-12 02:25:51.326590
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    # Case 1
    nationality = person.nationality()
    assert nationality in person._data['nationality']
    # Case 2
    nationality = person.nationality(gender=Gender.FEMALE)
    assert nationality in person._data['nationality']['f']

# Generated at 2022-06-12 02:25:55.460640
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname(gender=0) != Person().surname(), "Error in method Person.surname"
test_Person_surname()

# Generated at 2022-06-12 02:26:06.802559
# Unit test for method nationality of class Person
def test_Person_nationality():
    '''
    Test for method nationality of class Person
    '''
    with pytest.raises(NonEnumerableError):
        fake = Faker(locale="en_US")
        value = fake.nationality()
    with pytest.raises(NonEnumerableError):
        fake = Faker(locale="en_US")
        value = fake.nationality(Gender.MALE)
    with pytest.raises(NonEnumerableError):
        fake = Faker(locale="en_US")
        value = fake.nationality(Gender.FEMALE)
    with pytest.raises(NonEnumerableError):
        fake = Faker(locale="en_US")
        value = fake.nationality(Gender.OTHER)
    with pytest.raises(NonEnumerableError):
        fake = Faker

# Generated at 2022-06-12 02:26:11.278936
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Tests the method of generating a random surname.
    """
    person = Person(random=Random())
    surname = person.surname(gender=Gender.female)
    assert isinstance(surname, str)

# Generated at 2022-06-12 02:26:12.914094
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(random=Random())
    assert isinstance(p.surname(), str)



# Generated at 2022-06-12 02:26:15.191685
# Unit test for method nationality of class Person
def test_Person_nationality():
    r = Random()
    assert isinstance(r.person.nationality(Gender.MALE), str)
    assert r.person.nationality(Gender.MALE) in NATIONALITIES

# Generated at 2022-06-12 02:26:16.350775
# Unit test for method email of class Person
def test_Person_email():
    p = Person(random=Random())
    print(p.email())

# Generated at 2022-06-12 02:26:38.872742
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test for Person.nationality()."""
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)


# Generated at 2022-06-12 02:26:40.351527
# Unit test for method nationality of class Person
def test_Person_nationality():
    ans = Person().nationality()
    assert isinstance(ans, str)



# Generated at 2022-06-12 02:26:42.977338
# Unit test for method nationality of class Person
def test_Person_nationality():
    test = Person(random=mock_randoms())

    result = test.nationality()
    assert 'Russian' == result



# Generated at 2022-06-12 02:26:45.203400
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(100):
        x = Person().surname()
        assert isinstance(x, str)


# Generated at 2022-06-12 02:26:51.785248
# Unit test for method username of class Person
def test_Person_username():
    from faker.providers.person.ru_RU import Provider as Person
    person = Person()
    result = person.username()
    assert result in ('L.1884', 'L1829', 'L-1868', 'L-64', 'L-34',
                      'L_37', 'L1885', 'L-94', 'L-86', 'l1872',
                      'l.1803', 'l.24', 'l-87', 'L14', 'l-88')


# Generated at 2022-06-12 02:26:54.305622
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(100):
        assert bool(re.match(r'\S+@\S+', Person().email()))

# Generated at 2022-06-12 02:26:57.954173
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert type(person.nationality()) == str, "Nationality must be a string"
    assert len(person.nationality()) > 1, "Nationality must be at least two characters long"
    print("Person.nationality() OK")

# Generated at 2022-06-12 02:27:05.526094
# Unit test for method username of class Person
def test_Person_username():
    seed(1)
    person = Person()
    assert person.username() == 'Bentley_1860'
    assert person.username() == 'Bentley.1860'
    assert person.username() == 'Bentley-1860'
    assert person.username() == 'Bentley_1860'
    assert person.username() == 'Bentley.1860'
    assert person.username() == 'Bentley-1860'
    assert person.username() == 'Babs.1860'
    assert person.username() == 'Babs-1860'
    assert person.username() == 'Babs1860'
    assert person.username() == 'Babs.1860'
    assert person.username() == 'Babs_1860'
    assert person.username() == 'Babs-1860'

# Generated at 2022-06-12 02:27:08.434283
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        nationality = Faker().nationality()
        assert nationality in NATIONALITIES
        assert isinstance(nationality, str)
test_Person_nationality()

# Generated at 2022-06-12 02:27:13.915918
# Unit test for method surname of class Person
def test_Person_surname():
    import random
    from faker_ru.enums import Gender

    p = Person( rnd=random.Random() )
    # Test for method surname of class Person
    # 1
    surname = p.surname()
    assert isinstance(surname, (str,))
    # Test for method surname of class Person
    # 2
    surname = p.surname()
    assert isinstance(surname, (str,))

# Generated at 2022-06-12 02:27:35.902737
# Unit test for method surname of class Person
def test_Person_surname():
    # Assert false if is not a string
    assert not isinstance(Person().surname(), int)
    # Assert true if name is in txt file
    assert Person().surname() in open('generate_data.txt', 'r').read()

# Generated at 2022-06-12 02:27:38.210422
# Unit test for method nationality of class Person
def test_Person_nationality():
    nats = ['Russian', 'American', 'Korean', 'British']
    assert Person().random.choice(nats) in nats


# Generated at 2022-06-12 02:27:39.595660
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert isinstance(person.email(), str)
    
    

# Generated at 2022-06-12 02:27:41.217444
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email()[0] != '@'

test_Person_email()

# Generated at 2022-06-12 02:27:42.923412
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality("Immunologist") == "Immunologist"
    assert Person.nationality("Immunologist", "male") == "Immunologist"
    assert Person.nationality("Immunologist", "female") == "Immunologist"

# Generated at 2022-06-12 02:27:46.353914
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        assert len(Person().nationality()) == len(Person().nationality(Gender.MALE))
        assert len(Person().nationality()) == len(Person().nationality(Gender.FEMALE))
# Test
test_Person_nationality()


# Generated at 2022-06-12 02:27:49.870954
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=0)
    assert person.surname(gender='male') == 'Соколов'
    assert person.surname(gender='female') == 'Иванова'

# Generated at 2022-06-12 02:27:52.527527
# Unit test for method email of class Person
def test_Person_email():
    p1 = Person(seed=1)
    assert p1.email(unique=False) == 'alaric.1841@gmail.com'
    assert p1.email(unique=True) == 'q1@gmail.com'

# Generated at 2022-06-12 02:27:54.726693
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)



# Generated at 2022-06-12 02:27:58.788436
# Unit test for method nationality of class Person
def test_Person_nationality():
    persons = Person()
    for sex in Gender.__members__.values():
        for _ in range(10):
            person = persons.nationality(gender=sex)
            assert isinstance(person, str)
            assert person
            assert len(person)

# Generated at 2022-06-12 02:28:38.042541
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Get a random person's nationality
    n1 = Person().nationality()
    n2 = Person().nationality()
    assert n1 != n2


# Generated at 2022-06-12 02:28:42.746976
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Unit test for Person.surname
    """
    p = Person()    # create an instance of class Person
    all_surnames = []
    for _ in range(1000):
        all_surnames.append(p.surname())
    assert len(list(set(all_surnames))) == 1000


# Generated at 2022-06-12 02:28:52.541382
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person(seed=1).surname() == 'Ramos'
    assert Person(seed=2).surname() == 'Murphy'
    assert Person(seed=3).surname() == 'Welch'
    assert Person(seed=4).surname() == 'Sanchez'
    assert Person(seed=5).surname() == 'Chapman'
    assert Person(seed=6).surname() == 'Ruiz'
    assert Person(seed=7).surname() == 'Carr'
    assert Person(seed=8).surname() == 'Estrada'
    assert Person(seed=9).surname() == 'Barton'
    assert Person(seed=10).surname() == 'Conley'

# Generated at 2022-06-12 02:28:58.072938
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname(Gender.FEMALE) in p._data['surname']['female']
    assert p.surname(Gender.MALE) in p._data['surname']['male']


# Generated at 2022-06-12 02:29:06.179965
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(100):
        # generate name for male and female
        male_name = person.surname(Gender.MALE)
        female_name = person.surname(Gender.FEMALE)

        # surname must be a string
        assert isinstance(male_name, str) is True, "must be a string"
        assert isinstance(female_name, str) is True, "must be a string"

        # surname must be not empty
        assert len(male_name) > 0, "must be not empty"
        assert len(female_name) > 0, "must be not empty"

        # surname must not be the same with different genders
        assert male_name != female_name, "must be not the same"

        # if gender is not specified, method must generate name with random gender
        random_name = person

# Generated at 2022-06-12 02:29:11.321063
# Unit test for method nationality of class Person
def test_Person_nationality():
    import random
    from faker.providers.person import Provider

    rnd = random.Random()
    rnd.seed(0)

    provider = Provider
    for i in range(100):
        assert provider.nationality(provider) == provider.nationality(provider)

    data_set = {
        provider.nationality(provider): provider.nationality(provider)
        for i in range(100)
    }
    assert len(data_set.keys()) > 1



# Generated at 2022-06-12 02:29:12.370894
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname() is not None


# Generated at 2022-06-12 02:29:13.344431
# Unit test for method email of class Person
def test_Person_email():
    for i in range(100):
        assert Person().email()


# Generated at 2022-06-12 02:29:21.624554
# Unit test for method surname of class Person
def test_Person_surname():
    from random import Random
    from faker import Faker
    from string import ascii_letters
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import lists, composite
    from hypothesis.strategies import integers, floats, dictionaries
    from hypothesis.strategies import one_of
    from hypothesis.strategies import builds
    from hypothesis.strategies import tuples
    from hypothesis.strategies import none
    from hypothesis.extra.datetime import datetimes
    from hypothesis.extra.numpy import arrays, integers as ints
    from hypothesis.searchstrategy import SearchStrategy
    from hypothesis.internal.validation import check_type
    from faker.providers.person.en_US import Provider
    from faker.providers.person.en_US import person, gender_value


# Generated at 2022-06-12 02:29:30.169755
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    p = Person()
    expected_result_1 = None
    expected_result_2 = None
    expected_result_3 = None
    # Act
    result_1 = p.nationality(Gender.M)
    result_2 = p.nationality(Gender.F)
    result_3 = p.nationality()
    # Assert
    assert result_1 != expected_result_1
    assert result_2 != expected_result_2
    assert result_3 != expected_result_3
    print('-> test_Person_nationality() OK')

# Generated at 2022-06-12 02:30:45.861445
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=42)
    res = person.surname(Gender.FEMALE)
    assert res == 'Болотова'


# Generated at 2022-06-12 02:30:48.168428
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(10000):
        assert isinstance(Person().surname(), str)


# Generated at 2022-06-12 02:30:57.765778
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(seed=0)
    assert p.surname() == 'Васильева'
    assert p.surname() == 'Толстой'
    assert p.surname() == 'Емелина'
    assert p.surname() == 'Касьянова'
    assert p.surname() == 'Семёнов'
    assert p.surname() == 'Круглов'
    assert p.surname() == 'Иосифов'
    assert p.surname() == 'Аксёнова'
    assert p.surname() == 'Галкин'
   

# Generated at 2022-06-12 02:30:59.932791
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    assert isinstance(provider.nationality(), str)

# Generated at 2022-06-12 02:31:02.072709
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    result = person.surname()
    assert isinstance(result, str)


# Generated at 2022-06-12 02:31:04.544273
# Unit test for method surname of class Person
def test_Person_surname():
   name = Person(lang = 'ru')
   surname = name.surname()
   assert type(surname) == str
   assert len(surname) > 0


# Generated at 2022-06-12 02:31:07.507125
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname().__class__.__name__ == 'str'


# Generated at 2022-06-12 02:31:18.463907
# Unit test for method nationality of class Person
def test_Person_nationality():
    # A graph that contains the result of calling the method nationality
    graph = OrderedDict()
    # Always the same result

# Generated at 2022-06-12 02:31:27.437913
# Unit test for method surname of class Person
def test_Person_surname():
    """Check the method surname of class Person."""
    sample = ['Иванов',
              'Сидоров',
              'Петров',
              'Катасонов',
              'Высотин',
              'Парфенов',
              'Андреев',
              'Дмитриев',
              'Ловцев',
              'Войтихин',
              'Пономарев',
              'Бондарев',
              'Почепихин']
    for i in range(1000):
        assert Person().surname