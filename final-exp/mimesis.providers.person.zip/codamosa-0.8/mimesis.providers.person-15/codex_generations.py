

# Generated at 2022-06-12 02:22:36.968664
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()

# Generated at 2022-06-12 02:22:38.792981
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()

    for _ in range(1000):
        person.nationality()


# Generated at 2022-06-12 02:22:41.613369
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert type(person.nationality()) is str


# Generated at 2022-06-12 02:22:43.000534
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-12 02:22:48.243080
# Unit test for method surname of class Person
def test_Person_surname():
    surname_list = [
        Person().surname()
        for _ in range(100)
    ]
    assert isinstance(surname_list, list)
    assert len(surname_list) == 100
    assert len(surname_list[2]) >= 3
    assert surname_list[2] != surname_list[3]

# Generated at 2022-06-12 02:22:54.318367
# Unit test for method nationality of class Person
def test_Person_nationality():
    from random import seed
    np = Person()

    seed(1)
    assert np.nationality() == 'Russian'

    seed(2)
    assert np.nationality() == 'Russian'

    seed(3)
    assert np.nationality() == 'German'

    seed(4)
    assert np.nationality() == 'German'
test_Person_nationality()


# Generated at 2022-06-12 02:22:56.053914
# Unit test for method username of class Person
def test_Person_username():
    assert Person.username()

# Generated at 2022-06-12 02:23:08.965980
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:23:13.250788
# Unit test for method email of class Person
def test_Person_email():
    from fakegen.common import EMAIL_DOMAINS
    from fakegen.providers import Person

    provider = Person()
    email = provider.email()
    assert email[email.index('@')+1:] in EMAIL_DOMAINS



# Generated at 2022-06-12 02:23:14.650241
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    person.surname()


# Generated at 2022-06-12 02:23:35.226050
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname()
    assert Person().last_name()

# Generated at 2022-06-12 02:23:39.698236
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    names = [person.surname() for _ in range(100)]
    assert all(isinstance(name, str) for name in names)

    names = [person.surname() for _ in range(100)]
    assert all(name for name in names)

    names = [person.surname() for _ in range(100)]
    assert names[0] != names[-1]


# Generated at 2022-06-12 02:23:47.373757
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surnames = person._data['surname']
    assert surnames[Gender.MALE][0] == 'Иванов'
    assert surnames[Gender.MALE][-1] == 'Пугачев'
    assert surnames[Gender.FEMALE][0] == 'Смирнова'
    assert surnames[Gender.FEMALE][-1] == 'Дроздова'

# Generated at 2022-06-12 02:23:54.871851
# Unit test for method surname of class Person
def test_Person_surname():
    import random
    random.seed(0)
    obj = Person()
    for i in range(1000):
        result = obj.surname()
        assert result in SURNAMES
    random.seed(0)
    for i in range(1000):
        result = obj.surname(Gender.MALE)
        assert result in SURNAMES
    random.seed(0)
    for i in range(1000):
        result = obj.surname(Gender.FEMALE)
        assert result in SURNAMES
    return ("Person_surname")

# Generated at 2022-06-12 02:23:57.503121
# Unit test for method surname of class Person
def test_Person_surname():
    inst = fake.get_provider(Person)
    assert isinstance(inst.surname(), str)
test_Person_surname()

# Generated at 2022-06-12 02:23:59.844776
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(101):
        p = Person(seed=1).email()
        assert p == 'ellis.buchanan@gmail.com'


# Generated at 2022-06-12 02:24:01.319054
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert len(p.nationality()) > 0
test_Person_nationality()


# Generated at 2022-06-12 02:24:04.620977
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=1)
    assert person.nationality(Gender.MALE) == 'Russian'
    assert person.nationality(Gender.FEMALE) == 'Russian'
    assert person.nationality() == 'Russian'
    

# Generated at 2022-06-12 02:24:06.768192
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=0)
    assert person.nationality() == 'Bangladeshi'
