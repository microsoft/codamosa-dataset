

# Generated at 2022-06-12 02:21:57.288776
# Unit test for method surname of class Person
def test_Person_surname():
    """ Unit tests for the Person class. """
    from unittest import TestCase

    from faker.providers.person.en_US import Provider as EnUsProvider

    class TestEnUsPerson(TestCase):
        """ Tests for the ``en_US`` person provider. """

        def setUp(self):
            self.factory = Factory.create(locale='en_US')
            self.factory.seed_instance(0)

        def test_surname(self):
            """ Verify that a random, but consistent surname is returned. """
            self.assertEqual(self.factory.surname(), 'Bergnaum')
            self.assertEqual(self.factory.surname(), 'Bergnaum')
            self.assertEqual(self.factory.surname(), 'Bergnaum')

# Generated at 2022-06-12 02:22:00.650303
# Unit test for method surname of class Person
def test_Person_surname():
    Person = Person()
    assert Person.surname(Gender.male) in Person._data["surnames"][Gender.male]
    assert Person.surname(Gender.female) in Person._data["surnames"][Gender.female]

# Generated at 2022-06-12 02:22:04.052266
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(locale='en-US')
    surname = person.surname()
    
    assert surname in PERSON_DATA['names']['en-US']['surnames']['all'], \
    '''
    Expected surnames to be one of the available surnames in the locale en-US but got %s
    ''' % surname



# Generated at 2022-06-12 02:22:16.301498
# Unit test for method surname of class Person
def test_Person_surname():
    """Test method surname of class Person."""
    from random import Random

    rnd = Random()
    p = Person()
    p.random = rnd
    assert p.surname() in ('Иванов', 'Петров', 'Сидоров', 'Прудников')
    assert p.surname(gender=Gender.male) in ('Иванов', 'Петров', 'Сидоров', 'Прудников')

# Generated at 2022-06-12 02:22:28.153486
# Unit test for method surname of class Person
def test_Person_surname():
    Person = Person(seed=1)
    assert Person.surname() == 'Lovgreen'

    Person = Person(seed=1, gender=Person.Gender.MALE)
    assert Person.surname() == 'Anfalov'
    
    Person = Person(seed=1, gender=Person.Gender.FEMALE)
    assert Person.surname() == 'Kremleva'

    with pytest.raises(NonEnumerableError) as err_info:
        Person.surname(gender=Person.Gender.NON_BINARY)

    assert str(err_info.value) == (
        "Enum «gender». 'NON_BINARY' "
        "is not support for now"
    )
    return


# Generated at 2022-06-12 02:22:29.561152
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert type(p.nationality()) == str

# Generated at 2022-06-12 02:22:30.483502
# Unit test for method surname of class Person
def test_Person_surname():
    assert len(Person().surname(Gender.MALE)) > 0


# Generated at 2022-06-12 02:22:33.272288
# Unit test for method surname of class Person
def test_Person_surname():
    assert isinstance(Person().surname(), str)
    assert isinstance(Person().last_name(), str)
    assert isinstance(Person().surname(gender=Gender.MALE), str)



# Generated at 2022-06-12 02:22:35.654680
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    print(nationality)
    assert nationality in person._data['nationality']

test_Person_nationality()


# Generated at 2022-06-12 02:22:41.957592
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    s = p.surname()
    assert isinstance(s, str)
    assert s
    s = p.surname(gender=Gender.male)
    assert isinstance(s, str)
    assert s
    s = p.surname(gender=Gender.female)
    assert isinstance(s, str)
    assert s

# Generated at 2022-06-12 02:22:51.835129
# Unit test for method surname of class Person
def test_Person_surname():
    ln = Person().last_name()
    assert ln is not None
    assert ln == Person().last_name()

# Generated at 2022-06-12 02:22:53.713559
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    value = person.nationality()
    assert value, value

# Generated at 2022-06-12 02:23:02.012122
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Generator
    from pprint import pprint as pp
    from test_data.generator_data.surnames.surnames import SURNAMES
    rnd = Generator()
    rnd.seed_instance(0)
    rnd.random = rnd._random.Random()
    rnd.random.seed(0)
    person = Person(rnd)
    result = person.surname(gender=Gender.MALE)
    assert result == 'Schaefer'
    result = person.surname(gender=Gender.FEMALE)
    assert result == 'Carpenter'
    result = person.surname(gender=Gender.UNKNOWN)
    assert result == 'Muller'
    person.gender_data = GenderData.ENGLISH_US

# Generated at 2022-06-12 02:23:05.031241
# Unit test for method nationality of class Person
def test_Person_nationality():
    tester = Person()
    assert tester.nationality() in NATIONALITIES, \
        "Person().nationality() should return nationality"



# Generated at 2022-06-12 02:23:07.634646
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in PERSON_NATION

# Generated at 2022-06-12 02:23:11.202004
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    count = 0
    while count < 100:
        res = p.surname()
        assert isinstance(res, str) == True
        assert len(res) > 0
        count += 1

# Generated at 2022-06-12 02:23:13.070434
# Unit test for method surname of class Person
def test_Person_surname():
    assert isinstance(Person().surname(), str)



# Generated at 2022-06-12 02:23:15.171048
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        assert len(Person().nationality()) == len(Person().nationality('Female'))

# Generated at 2022-06-12 02:23:25.246737
# Unit test for method surname of class Person
def test_Person_surname():
    from random import seed
    from random import randint
    from pyfaker.constants import Gender

    prng = seed(7)
    names = []
    for i in range(100):
        rand = randint(0, 999999999)
        prng = seed(rand)
        f = Person(random = prng)
        names.append(f.surname())
    assert(names[0] == 'Слесаренко')
    assert(names[1] == 'Анисимов')
    assert(names[2] == 'Усатенко')
    assert(names[3] == 'Федосюк')
    assert(names[4] == 'Дмитренко')

# Generated at 2022-06-12 02:23:34.827985
# Unit test for method nationality of class Person
def test_Person_nationality():

    from loremipsum.testing import MockerTestCase

    class TestPerson_nationality(MockerTestCase):

        person = Person()
        person_data = person._data

        def test_with_gender(self):
            for gender in Gender:
                self.assertIn(self.person.nationality(gender),
                              self.person_data['nationality'][gender.value])

        def test_without_gender(self):
            nationalities = self.person_data['nationality']
            if isinstance(nationalities, dict):
                nationalities = nationalities[list(Gender)[0].value]

            self.assertIn(self.person.nationality(), nationalities)

    test = TestPerson_nationality()
    test.run()

# Generated at 2022-06-12 02:23:46.419424
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality()
    assert p.nationality(Gender.Male)
    assert p.nationality(Gender.Female)


# Generated at 2022-06-12 02:23:48.157576
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person.nationality()
    assert(isinstance(person, str))


# Generated at 2022-06-12 02:23:58.413335
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:24:01.541004
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    from faker_file import Person

    fake = Faker()
    p = Person(fake)
    result = p.surname('male')
    assert result in p._data['surname']['male']

# Generated at 2022-06-12 02:24:08.453586
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(), str)

    assert isinstance(person.surname(gender=Gender.male), str)
    assert isinstance(person.surname(gender=Gender.male), str)

# Generated at 2022-06-12 02:24:17.760323
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pydictionaria import Person
    from pydictionaria.enums import Gender
    from pydictionaria.models.database import Database
    import pytest

    # Load data from files with real names of countries
    data = Database()
    data.load_data(path='tests/data')
    data.load_lang('data/locales/en.json')

    # Set a random seed
    seed = data.random.randint(0, 1000000)
    data.random.seed(seed)

    # Get a random country
    country_code = data.random.choice(list(data.countries))
    country = data.countries[country_code]
    country_name = country['name']
    assert data.nationality(gender=Gender.MALE) == country_name

    # Test with empty json file
    p

# Generated at 2022-06-12 02:24:22.092781
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(10):
        assert (len(Person().surname())>0) 
        assert (len(Person().surname(gender=Gender.MALE))>0) 
        assert (len(Person().surname(gender=Gender.FEMALE))>0) 
    

# Generated at 2022-06-12 02:24:29.660717
# Unit test for method email of class Person
def test_Person_email():
    pr = Person()
    assert pr.email() == pr.email()
    assert pr.email() == pr.email()
    assert pr.email() == pr.email()
    assert pr.email() == pr.email()
    assert pr.email() == pr.email()

    assert pr.email() != pr.email()
    assert pr.email() != pr.email()
    assert pr.email() != pr.email()
    assert pr.email() != pr.email()
    assert pr.email() != pr.email()



# Generated at 2022-06-12 02:24:37.684765
# Unit test for method surname of class Person
def test_Person_surname():
    args = 'surname'
    # Random test
    for _ in range(100):
        args = 'surname'
        test_surname = Person(seed=None).surname()
        assert isinstance(test_surname, str)
        assert len(test_surname) >= 2
        assert len(test_surname) <= 17
        assert test_surname[0].isupper()
        assert args_in_data(args, test_surname)

# Unit tests for method last_name of class Person

# Generated at 2022-06-12 02:24:49.565298
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname() == 'Иванов'
    assert Person.surname(gender=Gender.female) == 'Иванова'
    assert Person.surname(gender=Gender.male) == 'Иванов'
    assert set(Person.surname(gender=Gender)) == {'Иванов', 'Иванова'}
    assert Person.surname(gender='female') == 'Иванова'
    assert Person.surname(gender='male') == 'Иванов'
    assert set(Person.surname(gender='both')) == {'Иванов', 'Иванова'}


# Generated at 2022-06-12 02:25:02.422824
# Unit test for method surname of class Person
def test_Person_surname():
    # get 1 item from surnames
    surname = Person().surname()
    # check that surname is not empty
    assert surname
    # check that type of surname is string
    assert isinstance(surname, str)
    # check that length of surname is more than 2
    assert len(surname) > 2
    


# Generated at 2022-06-12 02:25:12.565812
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random=Random())
    nationality = person.nationality()
    assert isinstance(nationality, str)
    print(nationality)

# Generated at 2022-06-12 02:25:14.332160
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=random.seed)
    nationality = person.nationality()
    assert isinstance(nationality, str)


# Generated at 2022-06-12 02:25:16.226111
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    # The method nationality has to return a string
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-12 02:25:17.936229
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert 'Иванов' == p.surname()

# Generated at 2022-06-12 02:25:19.879521
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in NATIONALITY




# Generated at 2022-06-12 02:25:30.290508
# Unit test for method surname of class Person
def test_Person_surname():
    from parameterized import parameterized
    @parameterized([
        ('International', 'en-GB', ['Smith', 'Brown', 'Jones']),
        ('International', 'en-US', ['Smith', 'Brown', 'Miller']),
        ('Default', None, ['Иванов', 'Петров', 'Сидоров']),
    ])
    def test_surname(data_provider: str, locale: Optional[str], expected: list):
        from faker_ru import ru_RU
        from faker_ja import ja_JP
        from faker_en import en_US, en_GB
        from faker_it import it_IT
        from faker_cs import cs_CZ
        from faker_de import de_DE

# Generated at 2022-06-12 02:25:32.587400
# Unit test for method surname of class Person
def test_Person_surname():
    """Test method surname of class Person."""
    person = Person()
    surname = person.surname()
    assert len(surname) > 0



# Generated at 2022-06-12 02:25:37.905927
# Unit test for method surname of class Person
def test_Person_surname():
    # Used in class Person, return a random surname
    # Create an objet of class Person
    person = fo.Person()
    # unit test code
    # if method return a empty string
    if not person.surname():
        raise AssertionError("No empty value is allowed")
    if not isinstance(person.surname(), str):
        raise AssertionError("Allowed only string value")

# Generated at 2022-06-12 02:25:40.615569
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    email = p.email()

    assert '@' in email
    assert email.count('@') == 1


# Generated at 2022-06-12 02:25:46.283730
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=10)
    person.nationality()
    result = person.nationality()
    print(result)
    assert result == 'Russian'

# Generated at 2022-06-12 02:25:48.118048
# Unit test for method surname of class Person
def test_Person_surname():
    method = Person(seed=100500).surname
    values = method()
    assert(values == 'Perfili')

# Generated at 2022-06-12 02:25:51.448050
# Unit test for method surname of class Person
def test_Person_surname():
    @given(st.text())
    def test_surname(surname):
        number = Person.surname(surname)
        assert type(number) is str
        assert len(number) > 1
    test_surname()

# Generated at 2022-06-12 02:25:54.790150
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str), 'the nationality is not a string'

# Generated at 2022-06-12 02:25:57.094814
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person(rnd=Random())
    
    assert provider.surname() != None
    assert isinstance(provider.surname(), str)

# Generated at 2022-06-12 02:26:08.547127
# Unit test for method nationality of class Person
def test_Person_nationality():
    from collections import Counter


# Generated at 2022-06-12 02:26:12.441422
# Unit test for method nationality of class Person
def test_Person_nationality():
    # When we pass correct gender to method nationality of class Person
    # Then we should get nationality
    assert Person().nationality(gender=Gender.FEMALE)

    # When we do not pass gender to method nationality of class Person
    # Then we should get nationality
    assert Person().nationality()


# Generated at 2022-06-12 02:26:18.814784
# Unit test for method email of class Person
def test_Person_email():
    def validate_email(email):
        return (
            email
            and '@' in email
            and email.replace('@', '').replace('.', '').isalnum()
            and email.count('@') == 1
        )

    person = Person()
    email_1 = person.email()
    email_2 = person.email(domains=('yandex',))
    email_3 = person.email(domains=('example.com',))
    email_4 = person.email(domains=('@live.com', '@gmail.com'))
    email_5 = person.email(unique=True)

    assert validate_email(email_1)
    assert email_2.endswith('@yandex')
    assert email_3.endswith('@example.com')
    assert email_

# Generated at 2022-06-12 02:26:20.293883
# Unit test for method surname of class Person
def test_Person_surname():
    surname = Person.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-12 02:26:24.613059
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    surname = "Anderson"
    person = Person()
    person.random.choice = MagicMock(return_value=surname)

    # Act
    person_surname = person.surname()

    # Assert
    assert person_surname == surname


# Generated at 2022-06-12 02:26:31.118188
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    
    person.nationality()


# Generated at 2022-06-12 02:26:39.238691
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert(p.surname() in p._data['surname'])
    assert(p.surname(Gender.MALE) in p._data['surname']['male'])
    assert(p.surname(Gender.FEMALE) in p._data['surname']['female'])
    assert(p.last_name() in p._data['surname'])
    assert(p.last_name(Gender.MALE) in p._data['surname']['male'])
    assert(p.last_name(Gender.FEMALE) in p._data['surname']['female'])


# Generated at 2022-06-12 02:26:41.633985
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    print('nationality: {}'.format(nationality))
    assert isinstance(nationality, str), 'is not str'


# Generated at 2022-06-12 02:26:46.125930
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit test for method nationality of class Person."""
    provider = Person()
    assert provider.nationality() in NATIONALITIES
    assert provider.nationality('male') in NATIONALITIES
    assert provider.nationality('female') in NATIONALITIES


# Generated at 2022-06-12 02:26:56.358788
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname('female') == 'Васютина'
    assert Person().surname('male') == 'Пасечник'
    assert Person().surname('male') in ['Васютина', 'Пасечник']
    assert Person().surname() in [
        'Васютина', 'Пасечник'
    ]
    assert Person().surname(Gender.MALE) == 'Пасечник'
    assert Person().surname(Gender.FEMALE) == 'Васютина'

# Generated at 2022-06-12 02:26:59.844478
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname(gender=Gender.Maskulin) in p._data['surnames']['maskulin']
    
test_Person_surname()

# Generated at 2022-06-12 02:27:02.037362
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(lang='en')
    ret = person.nationality()
    assert ret
    assert isinstance(ret,str)
    print(ret)


# Generated at 2022-06-12 02:27:05.486777
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname'], \
        'Class Person, method surname doesn\'t work'


# Generated at 2022-06-12 02:27:07.703921
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person('en')
    value = p.nationality()
    assert isinstance(value, str)


# Generated at 2022-06-12 02:27:10.702300
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality()
    assert Person().nationality(Gender.MALE.value) != Person().nationality(Gender.FEMALE.value)
    
test_Person_nationality()


# Generated at 2022-06-12 02:27:25.770937
# Unit test for method nationality of class Person
def test_Person_nationality():
    # when gender is male
    assert Person().nationality(Gender.MALE) in NATIONALITIES_MALE
    # when gender is female
    assert Person().nationality(Gender.FEMALE) in NATIONALITIES_FEMALE
    # when gender is unknown
    assert Person().nationality() in NATIONALITIES


# Generated at 2022-06-12 02:27:28.433035
# Unit test for method nationality of class Person
def test_Person_nationality():
    pl = Person(seed=0)
    result = pl.nationality()
    assert result == 'Russian'


# Generated at 2022-06-12 02:27:33.266643
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    result = provider.email(unique=True)
    assert type(result) == str
    assert len(result) >= 1
    assert result.startswith(str(provider.random.randstr(unique=True)))
    assert result.endswith(tuple(EMAIL_DOMAINS))


# Generated at 2022-06-12 02:27:36.477190
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality_of_male = person.nationality(gender=Gender.MALE)
    nationality_of_female = person.nationality(gender=Gender.FEMALE)
    
    assert nationality_of_male == nationality_of_female

# Generated at 2022-06-12 02:27:38.926849
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nat = person.nationality()
    # nat in PERSON_DATA['nationality']
    assert nat in PERSON_DATA['nationality']


# Generated at 2022-06-12 02:27:43.099461
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    for gender in Gender:
        if isinstance(provider._data['surnames'], dict):
            for _ in range(100):
                surname = provider.surname(gender)
                assert gender.name.title() in surname

        else:
            for _ in range(1000):
                surname = provider.surname()
                assert ' ' not in surname and surname[0].isupper()


# Generated at 2022-06-12 02:27:52.002423
# Unit test for method nationality of class Person
def test_Person_nationality():
    import pytest
    # Test with a single nationality
    p = Person(nationality=("russian"))
    assert isinstance(p.nationality(), str)
    assert p.nationality() == "russian"
    # Test with a few nationalities
    p = Person(nationality=("german", "danish"))
    assert isinstance(p.nationality(), str)
    assert p.nationality() == "german" or p.nationality() == "danish"
    # Test with a list of nationalities
    p = Person(nationality=["russian", "danish"])
    assert isinstance(p.nationality(), str)
    assert p.nationality() == "russian" or p.nationality() == "danish"
    # Test with a tuple of nationalities

# Generated at 2022-06-12 02:27:53.332809
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert isinstance(Person().nationality(), str)
print(test_Person_nationality())


# Generated at 2022-06-12 02:27:59.498787
# Unit test for method nationality of class Person
def test_Person_nationality():
    generator = GeneFactory(Person)
    generator.seed_provider(seed=111)
    # Test the enumerable value of the nationality
    assert isinstance(generator.nationality(), str)
    # Test the numerical value of the nationality
    assert isinstance(generator.nationality(gender=0), str)
    # Test the enumerable value and with gender of the nationality
    assert isinstance(generator.nationality(gender=Gender.MALE), str)



# Generated at 2022-06-12 02:28:03.148674
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(1000):
        nationality = Person().nationality()
        assert isinstance(nationality, str)
        assert len(nationality) >= 1
        assert nationality in NATIONALITIES


# Generated at 2022-06-12 02:28:23.805522
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = list(range(50))
    p = Person.nationality(nationalities = nationalities)
    assert p in nationalities


# Generated at 2022-06-12 02:28:25.321856
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = PersonProvider()
    assert provider.nationality() in provider._data['nationality']

# Generated at 2022-06-12 02:28:28.431619
# Unit test for method nationality of class Person
def test_Person_nationality():
    obj = Person()
    result = obj.nationality()

    assert result is not None
    assert isinstance(result, str)

    assert len(result) > 0

    print(result)

# Generated at 2022-06-12 02:28:33.976803
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random=MockRandom)
    for i in range(10):
        assert person.nationality() == 'Russian'
        assert person.nationality(gender=Gender.FEMALE) == 'Russian'
        assert person.nationality(gender=Gender.MALE) == 'Russian'
        assert person.nationality(gender='male') == 'Russian'
        assert person.nationality(gender='female') == 'Russian'



# Generated at 2022-06-12 02:28:36.156469
# Unit test for method email of class Person
def test_Person_email():
    person = Person()

    assert person.email() == 'foretime10@live.com'
    assert person.email(unique=True) == 'foretime10@live.com'


# Generated at 2022-06-12 02:28:37.421456
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        assert isinstance(Person().nationality(), str)


# Generated at 2022-06-12 02:28:45.920562
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() != Person().surname()
    assert Person().surname(gender = Gender.MALE) == Person().surname(gender = Gender.MALE)
    assert Person().surname(gender = Gender.MALE) != Person().surname(gender = Gender.FEMALE)

    assert Person().last_name() != Person().last_name()
    assert Person().last_name(gender = Gender.MALE) == Person().last_name(gender = Gender.MALE)
    assert Person().last_name(gender = Gender.MALE) != Person().last_name(gender = Gender.FEMALE)
    
# Test for method name of class Person

# Generated at 2022-06-12 02:28:55.967258
# Unit test for method email of class Person
def test_Person_email():
    p = Provider()
    p.seed(1234567890)
    assert p.Person().email() == 'paul.barbeau@hpe.com'
    assert p.Person().email() == 'kurt.koval@oracle.com'
    assert p.Person().email() == 'erik.morocco@ibm.com'
    assert p.Person().email() == 'david.hemmings@apple.com'
    assert p.Person().email() == 'andrew.burt@facebook.com'
    assert p.Person().email() == 'mike.marshall@microsoft.com'
    assert p.Person().email() == 'peter.schulz@canonical.com'
    assert p.Person().email() == 'john.lewycky@yahoo.com'
    assert p.Person

# Generated at 2022-06-12 02:28:59.425631
# Unit test for method surname of class Person
def test_Person_surname():

    # Create a provider
    provider = Person()

    # Getting the random surame
    surname = provider.surname()
    assert surname in provider._data['surname']

    # Getting the random surame with filter
    surname = provider.surname(gender=Gender.female)
    assert surname in provider._data['surname']['female']

# Generated at 2022-06-12 02:29:02.811980
# Unit test for method nationality of class Person
def test_Person_nationality():
    data = get_data()
    person = Person(data)
    value = person.nationality()
    assert value == "Austrian"

test_Person_nationality()

# Generated at 2022-06-12 02:29:41.998579
# Unit test for method nationality of class Person
def test_Person_nationality():
    print('Testing Person.nationality')
    from faker import Faker
    from faker.providers import Person
    fake = Faker('ru_RU')
    fake.add_provider(Person)
    for _ in range(10):
        national = fake.nationality()
        assert national in Person.NATIONALITIES, national


# Generated at 2022-06-12 02:29:53.335565
# Unit test for method nationality of class Person
def test_Person_nationality():
    from .enums import Gender
    male = Gender.MALE
    female = Gender.FEMALE
    
    person = Person()
    
    assert person.nationality() in ("Chinese", "American", "French", "Spanish", "Australian", "New Zealander", "Italian", "German", "Dutch", "Turkish", "Vietnamese", "Finnish", "Japanese", "Brazilian", "Danish")
    assert person.nationality(male) in ("Chinese", "American", "French", "Spanish", "Australian", "New Zealander", "Italian", "German", "Dutch", "Turkish", "Vietnamese", "Finnish", "Japanese", "Brazilian", "Danish")

# Generated at 2022-06-12 02:29:55.952146
# Unit test for method nationality of class Person
def test_Person_nationality():
    mock_person = Person(seed=1234)
    assert mock_person.nationality() == 'Ukrainian'
test_Person_nationality()
test_Person_nationality()
test_Person_nationality()
test_Person_nationality()


# Generated at 2022-06-12 02:30:06.380569
# Unit test for method email of class Person
def test_Person_email():
    """Test method Person.email()."""
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert email.count('@') == 1
    assert email.split('@')[0]
    assert email.split('@')[1] in EMAIL_DOMAINS


if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.exit("Usage: faker.py N_names N_surnames")
    print("Generating dictionaries...")
    N_names = sys.argv[1]
    N_surnames = sys.argv[2]
    p = Person()

# Generated at 2022-06-12 02:30:09.210524
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    name = p.surname()
    assert type(name) == str
    assert len(name) > 0
test_Person_surname()

# Generated at 2022-06-12 02:30:14.625802
# Unit test for method email of class Person
def test_Person_email():
    provider = Provider(seed=0)
    assert provider.email() == 'amery-breeze@hotmail.com'
    assert provider.email(unique=True) == 'amery-breeze2@hotmail.com'
    assert provider.email(unique=True) == 'amery-breeze3@hotmail.com'

    provider = Provider(seed='test')
    assert provider.email() == 'garcia-oswald@hotmail.com'

    provider = Provider(seed='')
    assert provider.email() == 'elba-ellsworth@hotmail.com'



# Generated at 2022-06-12 02:30:18.188978
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    first_call = provider.nationality()
    assert first_call in provider._data['nationality']
    assert first_call != provider.nationality()

    provider = Person()
    first_call = provider.nationality()
    assert first_call in provider._data['nationality']
    assert first_call != provider.nationality()



# Generated at 2022-06-12 02:30:19.546815
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Given
    person = Person()

    # When
    nationality = person.nationality()

    # Then
    assert nationality



# Generated at 2022-06-12 02:30:20.826450
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Get random person
    p = Person()
    # Test method
    assert p.nationality() in p._data['nationality']

# Generated at 2022-06-12 02:30:23.557776
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    person = Person(random=Random())

    # Act
    nationality = person.nationality()
    
    # Assert
    assert person._data['nationality'].__contains__(nationality)


# Generated at 2022-06-12 02:31:00.387765
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(lang='ru')
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-12 02:31:02.408525
# Unit test for method surname of class Person
def test_Person_surname():
    name = Person().surname()
    assert isinstance(name, str) and name

# Generated at 2022-06-12 02:31:03.838472
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITIES

# Generated at 2022-06-12 02:31:05.084270
# Unit test for method nationality of class Person
def test_Person_nationality():
    person=Person()
    nat=person.nationality()
    assert type(nat) == str


# Generated at 2022-06-12 02:31:10.108748
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
    assert person.nationality(gender='woman') in person._data['nationality']['woman']
    assert person.nationality(gender='man') in person._data['nationality']['man']
test_Person_nationality()

# Generated at 2022-06-12 02:31:13.669150
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in SURNAMES


# Generated at 2022-06-12 02:31:15.365858
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-12 02:31:21.201954
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Generator

    g = Generator()
    p = Person(g)

    # verify if random.choice is being called
    with patch('random.choice',
               new_callable=Mock,
               __name__='random.choice') as mock_random:
        # call test method
        p.surname()
        # verify that random.choice is being called
        assert mock_random.called



# Generated at 2022-06-12 02:31:29.770146
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Run this test with python -m doctest name.py
    """
    Test RandomProvider.GetPerson.nationality

    >>> random.seed(0)
    >>> Person(random).nationality()
    'Английский'
    >>> random.seed(1)
    >>> Person(random).nationality()
    'Американский'
    >>> random.seed(2)
    >>> Person(random).nationality()
    'Индийский'
    >>> random.seed(3)
    >>> Person(random).nationality()
    'Английский'
    """
    pass
random.seed(0)