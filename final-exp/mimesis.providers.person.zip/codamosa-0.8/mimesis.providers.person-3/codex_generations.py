

# Generated at 2022-06-12 02:21:48.045518
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    out = person.surname()
    ref = "Conway"
    assert out == ref

# Generated at 2022-06-12 02:21:50.495485
# Unit test for method surname of class Person
def test_Person_surname():
    # Assert that random surname is not None
    assert Person().surname() is not None


# Generated at 2022-06-12 02:21:53.038869
# Unit test for method email of class Person
def test_Person_email():
    assert len(Person().email()) == 10
    assert Person().email(unique=True)[-3:] in EMAIL_DOMAINS

# Generated at 2022-06-12 02:21:54.891020
# Unit test for method email of class Person
def test_Person_email():
    # Creating a random Person object
    person = Person()
    assert person.email()
    assert person.email(unique=True)


# Generated at 2022-06-12 02:21:56.738955
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)

# Generated at 2022-06-12 02:21:58.245454
# Unit test for method nationality of class Person
def test_Person_nationality():
    p_elem = Person()
    assert p_elem.nationality() in NATIONALITIES


# Generated at 2022-06-12 02:21:59.235111
# Unit test for method username of class Person
def test_Person_username():
    pass


# Generated at 2022-06-12 02:22:00.763799
# Unit test for method surname of class Person
def test_Person_surname():
    res = Person.surname()
    assert isinstance(res, str)


# Generated at 2022-06-12 02:22:02.222971
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAMES


# Generated at 2022-06-12 02:22:04.189601
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_data = Person()
    assert type(person_data.nationality()) == str


# Generated at 2022-06-12 02:22:12.977207
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(),str)

# Generated at 2022-06-12 02:22:14.774610
# Unit test for method nationality of class Person
def test_Person_nationality():
    result = Person().nationality()
    assert result == 'Russian'


# Generated at 2022-06-12 02:22:17.467444
# Unit test for method nationality of class Person
def test_Person_nationality():
    l = DataLoader()
    p = Person(l)
    assert p.nationality() in l.get_data('nationality/both')


# Generated at 2022-06-12 02:22:21.534568
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random=MockRandom())

    assert person.nationality() == 'Russian'
    assert person.nationality(Gender.male) == 'Russian'
    assert person.nationality(Gender.female) == 'Russian'

# Generated at 2022-06-12 02:22:23.882220
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    for _ in range(100):
        name = person.surname()
        assert len(name) > 1

# Generated at 2022-06-12 02:22:28.257899
# Unit test for method surname of class Person
def test_Person_surname():
    """Method surname of class Person returns a random surname."""
    surname = Person().surname()
    assert type(surname) == str
    assert len(surname) > 2


# Generated at 2022-06-12 02:22:32.062414
# Unit test for method surname of class Person
def test_Person_surname():
    p1 = Person("p1")
    print("method test_surname of class Person returned : " + p1.surname())
    p2 = Person("p2")
    print("method test_surname of class Person returned : " + p2.surname())
    p3 = Person("p3")
    print("method test_surname of class Person returned : " + p3.surname())


# Generated at 2022-06-12 02:22:33.360843
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-12 02:22:36.762371
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    fake = Faker()
    assert re.match(r'(^[A-Z][a-z]*\'?[a-z]+$)', fake.surname())
test_Person_surname()


# Generated at 2022-06-12 02:22:39.066548
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(seed=42)
    assert p.surname(gender=Gender.Male()) == 'Flynn'

# Generated at 2022-06-12 02:22:53.762754
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person('ru')
    p = person.surname(None)
    assert len(p) != 0

# Generated at 2022-06-12 02:22:56.377618
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random.Random())
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-12 02:23:09.017207
# Unit test for method username of class Person
def test_Person_username():
    from faker.providers.person.en_US import Provider as PersonEnUsProvider
    import faker
    faker = faker.Faker('en_US')
    faker.add_provider(PersonEnUsProvider)

    template = "[U_d]"
    regex = re.compile(r'^[A-Za-z]_\d{4}$')
    # print(faker.username(template))
    assert regex.match(faker.username(template))

    template = "[U.d]"
    regex = re.compile(r'^[A-Za-z]\.\d{4}$')
    # print(faker.username(template))
    assert regex.match(faker.username(template))

    template = "[U-d]"

# Generated at 2022-06-12 02:23:12.455905
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(10):
        national = Person.nationality()
        assert national in PERSON_NATIONALITY, \
        "Nationality must be from list PERSON_NATIONALITY"


# Generated at 2022-06-12 02:23:14.221612
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        assert isinstance(Person().nationality(), str)


# Generated at 2022-06-12 02:23:15.917723
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    result = p.nationality()
    assert result in p._data["nationality"]

# Generated at 2022-06-12 02:23:17.465259
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random=Random())
    assert isinstance(person.nationality(), str)
 

# Generated at 2022-06-12 02:23:19.252550
# Unit test for method nationality of class Person
def test_Person_nationality():
    import random
    rnd = random.Random()
    for i in range(100):
        assert isinstance(Person(rnd).nationality(), str)

# Generated at 2022-06-12 02:23:21.955539
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(10):
        result = Person.nationality()
        print(result)

test_Person_nationality()      


# Generated at 2022-06-12 02:23:26.026429
# Unit test for method surname of class Person
def test_Person_surname():
	# Setup
	personProvider = Person(seed=1)
	gender = Gender.MALE
	expected = "Dupont"

	# Exercise
	actual = personProvider.surname(gender)

	# Verify
	assert actual == expected

# Generated at 2022-06-12 02:23:58.108630
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname('m') == 'Zhang'
    assert Person().surname('f') == 'Li'


# Generated at 2022-06-12 02:24:06.333725
# Unit test for method surname of class Person

# Generated at 2022-06-12 02:24:13.972823
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Base case
    nationality = Personal.nationality()
    assert nationality in NATIONALITIES, 'Nationality is not valid'

    # With gender, the gender is male
    nationality = Personal.nationality(Gender.MALE)
    assert nationality in NATIONALITIES, 'Nationality is not valid'

    # With gender, the gender is female
    nationality = Personal.nationality(Gender.FEMALE)
    assert nationality in NATIONALITIES, 'Nationality is not valid'

test_Person_nationality()

# Generated at 2022-06-12 02:24:24.118688
# Unit test for method username of class Person
def test_Person_username():
    """
    Unit test for method username of class Person.
    """ 
    # Test 1. Generate username with default template.
    person = Person("ru_RU")
    result = person.username()
    assert result == 'nikitin_1898'

    # Test 2. Generate username with 'l.d' template
    person = Person("ru_RU")
    result = person.username(template='l.d')
    assert result == 'alexey.2000'

    # Test 3. Generate username with 'U-d' template
    person = Person("ru_RU")
    result = person.username(template='U-d')
    assert result == 'Joann-2005'

    # Test 4. Generate username with 'UU-d' template
    person = Person("ru_RU")
    result = person

# Generated at 2022-06-12 02:24:30.296030
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert person.surname() in person._data['surname']
    assert person.surname(Gender.FEMALE) in person._data['surname']['FEMALE']
    assert person.surname(Gender.MALE) in person._data['surname']['MALE']


# Generated at 2022-06-12 02:24:34.007889
# Unit test for method nationality of class Person
def test_Person_nationality():
    random = Random()
    obj = Person(random)
    assert obj.nationality() in obj._data['nationality']
    obj.seed(2)
    assert obj.nationality() in obj._data['nationality']


# Generated at 2022-06-12 02:24:38.540792
# Unit test for method nationality of class Person
def test_Person_nationality():
    n1 = Person().nationality(Gender.FEMALE)
    n2 = Person().nationality()
    n3 = Person().nationality(Gender.MALE)
    assert n1 in NATIONALITY and n2 in NATIONALITY and n3 in NATIONALITY

test_Person_nationality()
