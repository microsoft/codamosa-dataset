

# Generated at 2022-06-12 02:21:50.404123
# Unit test for method nationality of class Person
def test_Person_nationality():
    data = Person().nationality()
    assert data in Nationality.vocab
    print(data)


# Generated at 2022-06-12 02:21:57.441409
# Unit test for method email of class Person
def test_Person_email():
    from pydbgen import pydbgen
    from pydbgen import db
    from pydbgen import get_random_item
    from pydbgen import pydb
    from pydbgen import get_random_item
    from pydbgen.db import Gender
    from pydbgen.db import TitleType

    person = pydbgen.Person()

    print (person.email())
    print (person.telephone())
    print (person.telephone())



# Generated at 2022-06-12 02:22:00.174700
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    # Test 1000 times
    i = 0
    while i < 1000:
        if person.nationality() == "American":
            i += 1
    # Test passed
    assert True

# Generated at 2022-06-12 02:22:02.277608
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(locale='ru_RU')
    assert isinstance(person.surname(), str)


# Generated at 2022-06-12 02:22:04.810072
# Unit test for method gender of class Person
def test_Person_gender():
    for _ in range(100):
        p = Person()
        gender = p.gender()
        assert gender in SEXS, gender


# Generated at 2022-06-12 02:22:07.625849
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit test for method nationality of class Person"""
    person = Person()
    assert person.nationality() in person._data['nationality']


# Generated at 2022-06-12 02:22:09.987626
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    nationality = p.nationality()
    assert nationality
    assert nationality.title()
    
    

# Generated at 2022-06-12 02:22:11.586624
# Unit test for method surname of class Person
def test_Person_surname():
    pass


# Generated at 2022-06-12 02:22:14.715097
# Unit test for method email of class Person
def test_Person_email():
    '''
    The function checks if the method return string
    '''
    person = Person()
    assert type(person.email()) == str


# Generated at 2022-06-12 02:22:16.594635
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=1234)
    assert person.nationality() == 'Russian'

# Generated at 2022-06-12 02:22:31.736917
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    for i in range(0,len(person._data['surname'][Gender.MALE])-1):
        assert person.surname(gender=Gender.MALE) == person._data['surname'][Gender.MALE][i]
    for i in range(0,len(person._data['surname'][Gender.FEMALE])-1):
        assert person.surname(gender=Gender.FEMALE) == person._data['surname'][Gender.FEMALE][i]
test_Person_surname()

# Generated at 2022-06-12 02:22:34.041969
# Unit test for method nationality of class Person
def test_Person_nationality():
    generator = Person()
    nationality = generator.nationality() #Nationality Russian
    assert nationality == "Russian"
    
test_Person_nationality()

# Generated at 2022-06-12 02:22:36.186596
# Unit test for method email of class Person
def test_Person_email():

    person = Person()

    assert bool(re.match(r'.*@.*\..*', person.email())) is True


# Generated at 2022-06-12 02:22:42.911530
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Faker()
    for _ in range(10):
        assert provider.gender(iso5218=True) in (0, 1, 2, 9)
    for _ in range(10):
        assert provider.gender(symbol=True) in SEXUALITY_SYMBOLS
    for _ in range(10):
        assert provider.gender() in provider._data['gender']

# Generated at 2022-06-12 02:22:45.594149
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in NATIONALITY
test_Person_nationality()


# Generated at 2022-06-12 02:22:48.074473
# Unit test for method surname of class Person
def test_Person_surname():
    """Tests for the method surname()."""
    assert Person().surname() != ''
    assert Person(rnd=Random()).surname() != ''


# Generated at 2022-06-12 02:22:53.714387
# Unit test for method email of class Person
def test_Person_email():
    name = 'name@gmail.com'
    person = Person()
    email_ = person.email()
    assert email_.startswith('name')
    assert email_.endswith('@gmail.com')
    assert person.email(unique=True) != person.email(unique=True)
    assert email_ != person.email(unique=True)


# Generated at 2022-06-12 02:23:00.625886
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert(isinstance(p.nationality(), str))
    assert(isinstance(p.nationality(gender='male'), str))
    assert(isinstance(p.nationality(gender='female'), str))
    assert(isinstance(p.nationality(gender=Gender.MALE), str))
    assert(isinstance(p.nationality(gender=Gender.FEMALE), str))
    assert(isinstance(p.nationality(gender=1), str))
    assert(isinstance(p.nationality(gender=2), str))

# Generated at 2022-06-12 02:23:03.008362
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        nation = Person().nationality()
        assert nation in NATIONALITIES


# Generated at 2022-06-12 02:23:05.497298
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    output = p.nationality()
    assert type(output) == str

# Generated at 2022-06-12 02:23:27.425560
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test for method nationality of class Person."""
    # Check existing nationalities
    key = Person.EN
    assert 'English' in Person(key)._data['nationality']
    assert 'Russian' in Person(key)._data['nationality']
    assert 'Ukrainian' in Person(key)._data['nationality']

    assert 'Англичанин' in Person()._data['nationality']
    assert 'Русский' in Person()._data['nationality']
    assert 'Украинец' in Person()._data['nationality']

    # Check supported locales
    assert Person.nationality(Person.EN) in Person(Person.EN)._data['nationality']
    assert Person.nationality(Person.RU) in Person

# Generated at 2022-06-12 02:23:34.865616
# Unit test for method nationality of class Person
def test_Person_nationality():
    """
    Make sure that the method Person.nationality()
    returns nationality for male and female.
    """
    person = Person()

    nationalities_males = [person.nationality(Gender.MALE) for _ in range(100)]
    nationalities_females = [person.nationality(Gender.FEMALE) for _ in range(100)]

    assert len(set(nationalities_males)) == len(set(nationalities_females))
    assert '' not in nationalities_females + nationalities_males
    assert all(type(name) == str for name in nationalities_males)



# Generated at 2022-06-12 02:23:36.917149
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person('en')
    surname = person.surname()
    assert isinstance(surname, str) is True

# Generated at 2022-06-12 02:23:44.813990
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=3)
    name = person.surname()
    assert name == 'Рэйдор'
    name = person.surname(gender=Gender.male)
    assert name == 'Рэйдор'
    name = person.surname(gender=Gender.female)
    assert name == 'Абрамова'

# Generated at 2022-06-12 02:23:46.055334
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random=Random())
    nationality = person.nationality()

    # check type of returned value
    assert isinstance(nationality, str)


# Generated at 2022-06-12 02:23:47.848578
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert isinstance(p.surname(),str)


# Generated at 2022-06-12 02:23:50.001007
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    res = person.nationality()
    assert res != ""
    assert type(res) == str


# Generated at 2022-06-12 02:24:00.044303
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(random=Random())
    assert p.surname() in SURNAMES
    assert p.surname(gender='Male') in SURNAMES
    assert p.surname(gender='Female') in SURNAMES
    assert p.surname(gender='male') in SURNAMES
    assert p.surname(gender='female') in SURNAMES
    assert p.surname(gender='F') in SURNAMES
    assert p.surname(gender='M') in SURNAMES
    # Surname separated by gender
    surname_by_gender = {Gender.MALE: ['Smith', 'Johnson'],
                         Gender.FEMALE: ['Williams', 'Jones', 'Brown']}
    p = Person(random=Random(), surnames=surname_by_gender)
    assert p.s

# Generated at 2022-06-12 02:24:01.841109
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    surname = p.surname()
    assert (surname in SURNAMES) == True


# Generated at 2022-06-12 02:24:04.155971
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)
    
test_Person_nationality()

# Generated at 2022-06-12 02:24:24.147312
# Unit test for method email of class Person

# Generated at 2022-06-12 02:24:31.077426
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    name = person.surname(gender=Gender.MALE)

    assert(type(name) is str)
    assert(name in person._data['male_surnames'])
    
    name = person.surname(gender=Gender.FEMALE)

    assert(type(name) is str)
    assert(name in person._data['female_surnames'])
    

test_Person_surname()

# Generated at 2022-06-12 02:24:34.877688
# Unit test for method username of class Person
def test_Person_username():


    # Arrange
    random = Random()
    provider = Person(random=random)


    # Act
    actual = provider.username()


    # Assert
    assert isinstance(actual, str)


# Generated at 2022-06-12 02:24:47.158240
# Unit test for method nationality of class Person
def test_Person_nationality():
    cases = (
        (None, False),
        (Gender.MALE, True),
        (Gender.FEMALE, True),
        (Gender.UNKNOWN, False),
        (Gender.NOT_APPLICABLE, False),
    )
    with Person.override('en'):
            for idx, case in enumerate(cases, 1):
                gender, is_valid = case
                print(f"{idx}) {gender}:")
                person = Person(random=Random(1))
                try:
                    person.nationality(gender)
                except Exception as e:
                    if is_valid:
                        raise e
                    print(f"\tOK: {e}")
                else:
                    if not is_valid:
                        raise Exception("Should be invalid")
                    print("\tOK")

# Generated at 2022-06-12 02:24:48.117667
# Unit test for method nationality of class Person
def test_Person_nationality():
    pass


# Generated at 2022-06-12 02:24:50.569773
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(random_state=42)
    p.nationality()


# Generated at 2022-06-12 02:24:53.320001
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person('en')
    surname = person.surname()
    assert surname, "There is no surname"
    print("Surname is:", surname)


# Generated at 2022-06-12 02:24:54.806216
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    print(person.nationality())

# Generated at 2022-06-12 02:25:02.046870
# Unit test for method email of class Person
def test_Person_email():
    person = Person(seed=12345678)
    assert person.email() == 'laurenkimes@gmail.com'
    assert person.email() == 'ines_duby@outlook.com'
    assert person.email() == 'brian.s.wallace@yahoo.com'
    assert person.email() == 'ameier@gmail.com'
    assert person.email() == 'joshua_hoffman@yahoo.com'
    assert person.email() == 'myrtle_marshall@hotmail.com'
    assert person.email() == 'a.jerde@hotmail.com'
    assert person.email() == 'lenore_haley@yahoo.com'
    assert person.email() == 'ewing_johnson@outlook.com'

# Generated at 2022-06-12 02:25:03.746510
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in PERSON_NATIONALITIES


# Generated at 2022-06-12 02:25:15.888627
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality(Gender.MALE)
    assert nationality in person._data['nationality']['male']

# Generated at 2022-06-12 02:25:25.703404
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()

# Generated at 2022-06-12 02:25:30.796397
# Unit test for method nationality of class Person
def test_Person_nationality():
    from fakegen.core import Fakegen
    from fakegen.enums import Gender
    fake = Fakegen('./tests/fixtures/en_US.json')
    for i in range(1000):
        nationality = fake.nationality(Gender(i % 2))
        print(nationality)
    # print("nationality",nationality)
    assert nationality is not None

# Generated at 2022-06-12 02:25:32.709419
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Test for method surname of class Person
    """
    assert Person().surname() in names.data['surnames']

# Generated at 2022-06-12 02:25:40.151715
# Unit test for method surname of class Person
def test_Person_surname():
    size = 100
    # get list of surnames for different genders
    for gender in Gender:
        surname = []
        for i in range(size):
            surname.append(Person(random=Random(seed=i)).surname(gender))
        # get length of surnames list
        surname_length = len(surname)
        # check that surnames of different genders are different
        for i in range(1, surname_length):
            answer = surname[i] == surname[i-1]
            assert answer is False


# Generated at 2022-06-12 02:25:42.354380
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in NATIONALITIES
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-12 02:25:50.124932
# Unit test for method surname of class Person
def test_Person_surname():
    surnames = Person.data()['surname']
    surnames_male = surnames['male']
    surnames_female = surnames['female']
    surnames_both = surnames['both']

    person = Person('en')

    # Surnames separated by gender.
    assert person.surname(gender=Gender.MALE) in surnames_male
    assert person.surname(gender=Gender.FEMALE) in surnames_female
    assert person.surname(gender=Gender.BOTH) in surnames_both

    # Surnames who not separated by gender.
    assert person.surname() in surnames_both

    # An alias for self.last_name().
    assert person.last_name() == person.surname()



# Generated at 2022-06-12 02:25:53.830346
# Unit test for method surname of class Person
def test_Person_surname():
    pr = Person(['Gurvich'])
    assert pr.surname() == 'Gurvich'


# Generated at 2022-06-12 02:25:58.853866
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    p.surname()
    p.last_name()
    p.last_name()
    p.last_name()
    p.last_name(Gender.MALE)
    p.last_name(Gender.FEMALE)
    p.last_name()
    p.last_name()
    p.last_name(Gender.MALE)
    p.last_name(Gender.FEMALE)


# Generated at 2022-06-12 02:26:06.402233
# Unit test for method surname of class Person
def test_Person_surname():
    
    from faker_eo_person import EoPerson
    from faker import Faker
    from faker.providers.person.en_US import Provider as UsProvider
    
    faker = Faker()
    eoperson = EoPerson()
    
    for _ in range(100):
        name1 = faker.name().split()[1]
        name2 = eoperson.surname()
        assert isinstance(name2, str)
        assert name1.isalpha()
        assert name2.isalpha()
        print(name2)

# Generated at 2022-06-12 02:26:27.466650
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname() in SURNAME


# Generated at 2022-06-12 02:26:33.162408
# Unit test for method surname of class Person
def test_Person_surname():
    data = [
        'Koelpin',
        'Crona',
        'Daniel',
        'Bernhard',
        'Gutkowski',
        'Pfannerstill',
        'Kautzer',
        'Torphy',
        'Kemmer',
        'Kreiger',
        'Smith',
    ]

    provider = Person()
    result_list = [provider.surname() for _ in range(len(data))]
    assert result_list == data



# Generated at 2022-06-12 02:26:36.029319
# Unit test for method nationality of class Person
def test_Person_nationality():
    P = Person()
    result = P.nationality()
    print(result)
test_Person_nationality()


# Generated at 2022-06-12 02:26:40.756837
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        assert isinstance(Person().nationality(), str)
        assert isinstance(Person().nationality(Gender.MALE), str)
        assert isinstance(Person().nationality(Gender.FEMALE), str)
        assert isinstance(Person().nationality(Gender.NOT_KNOWN), str)
        assert isinstance(Person().nationality(Gender.NOT_APPLICABLE), str)
        
test_Person_nationality()

# Generated at 2022-06-12 02:26:49.139606
# Unit test for method surname of class Person
def test_Person_surname():
    # with fixed seed
    g = Person(seed = 43)
    assert g.surname() == 'Соколов'
    assert g.surname(Gender.MALE) == 'Кузнецов'
    assert g.surname(Gender.FEMALE) == 'Капустина'
    # without fixed seed
    g = Person()
    assert type(g.surname()) == str
    assert type(g.surname(Gender.MALE)) == str
    assert type(g.surname(Gender.FEMALE)) == str

# Generated at 2022-06-12 02:26:53.349348
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.factory import Factory
    from faker.utils.data.person_data import NATIONALITY

    fake = Factory.create()
    for _ in range(100):
        nationality = fake.nationality()
        assert nationality in NATIONALITY


# Generated at 2022-06-12 02:27:03.112818
# Unit test for method surname of class Person
def test_Person_surname():
    g = Person()
    g.random = random.Random()
    letter_list = ascii_letters
    #  g.random.seed(0)
    g.random.shuffle(letter_list)
    assert g.surname() == 'YAWN'
    assert g.surname() == 'GRAY'
    assert g.surname() == 'GRAY'
    assert g.surname() == 'MCCUNE'
    assert g.surname() == 'CONGER'
    assert g.surname() == 'BACON'
    assert g.surname() == 'CONGER'
    assert g.surname() == 'MCCUNE'
    assert g.surname() == 'GRAY'
    assert g.surname() == 'MCCUNE'

# Generated at 2022-06-12 02:27:05.414257
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert type(p.nationality()) == str


# Generated at 2022-06-12 02:27:15.454201
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    for _ in range(10):
        assert person.surname() in person._data['surname']['male']

    for _ in range(10):
        assert person.surname(gender='male') in person._data['surname']['male']

    for _ in range(10):
        assert person.surname() in person._data['surname']['male']

    for _ in range(10):
        assert person.surname(gender=Gender.MALE) in person._data['surname']['male']
    
    for _ in range(10):
        assert person.surname(gender='female') in person._data['surname']['female']


# Generated at 2022-06-12 02:27:17.078632
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(100):
        assert '@' in Person().email()

# Generated at 2022-06-12 02:29:38.361186
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=42)
    assert person.surname() == 'Schaefer'
    assert person.surname() == 'Randolph'
    assert person.surname() == 'Mccoy'
    assert person.surname(gender=Gender.male) == 'Klein'
    assert person.surname(gender=Gender.male) == 'Klein'
    assert person.surname(gender=Gender.male) == 'Mccoy'
    assert person.surname(gender=Gender.female) == 'Macy'
    assert person.surname(gender=Gender.female) == 'Macy'
    assert person.surname(gender=Gender.female) == 'Schroeder'

# Generated at 2022-06-12 02:29:40.545856
# Unit test for method surname of class Person
def test_Person_surname():
    
    pr = Person()
    result = pr.surname()
    assert isinstance(result, str)
    

# Generated at 2022-06-12 02:29:43.065587
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert type(nationality) == str
    assert nationality != ""

test_Person_nationality()


# Generated at 2022-06-12 02:29:53.966204
# Unit test for method surname of class Person

# Generated at 2022-06-12 02:29:56.464907
# Unit test for method surname of class Person
def test_Person_surname():
    # Vars
    person = Person()

    # Run
    output = person.surname()

    # Assert
    assert isinstance(output, str)


# Generated at 2022-06-12 02:29:59.878420
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    surname = p.surname()
    assert (type(surname) == str) and (len(surname) > 0)


# Generated at 2022-06-12 02:30:03.258895
# Unit test for method nationality of class Person
def test_Person_nationality():
    print('\n')
    p=Person()
    nationalities=p.nationality()
    # print(nationalities)
    assert nationalities in NATIONALITY

# Generated at 2022-06-12 02:30:11.838306
# Unit test for method surname of class Person
def test_Person_surname():
    # remove trailing comma because json.loads returns dict,
    # where trailing comma means name of the last element
    surnames = load_data('surnames.json')
    surname_mock = mock.Mock(return_value='Иванов')
    # check that person's surname contains russian letters and
    # is equal to 'Иванов'
    p = Person(surname_mock)
    assert all(i in list(punctuation + whitespace + ascii_letters + digits)
               for i in p.surname()), p.surname()
    assert p.surname() in surnames, p.surname()
    assert p.surname() == 'Иванов'

if __name__ == '__main__':
    test

# Generated at 2022-06-12 02:30:13.205713
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    assert result in NATIONALITIES


# Generated at 2022-06-12 02:30:18.743283
# Unit test for method surname of class Person
def test_Person_surname():
    """Test method Person.surname()
    """
    p = Person()
    
    print('Random surname: {}'.format(p.surname()))
    print('Random surname (femenine): {}'.format(p.surname(Gender.FEMALE)))
    print('Random surname (masculine): {}'.format(p.surname(Gender.MALE)))
    
    surnames = {
        Gender.FEMALE: ('Ivanova', 'Sidorova', 'Petrova'),
        Gender.MALE: ('Ivanov', 'Sidorov', 'Petrov'),
    }
    print('Random surname: {}'.format(p.surname(surnames)))
    
    surnames = ('Ivanova', 'Sidorova', 'Petrova')