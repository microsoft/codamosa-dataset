

# Generated at 2022-06-12 02:21:43.309601
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    surname = p.surname()
    assert isinstance(surname, str)

# Generated at 2022-06-12 02:21:45.424132
# Unit test for method gender of class Person
def test_Person_gender():
    gender = Person().gender()
    assert gender in PERSON_GENDER_NAMES



# Generated at 2022-06-12 02:21:50.969720
# Unit test for method surname of class Person
def test_Person_surname():
    surname = [p.surname() for p in Person.iter(10)]
    assert isinstance(surname, list)
    assert all(isinstance(s, str) for s in surname)
    assert len(surname) == 10

test_Person_surname()

# Generated at 2022-06-12 02:21:53.032161
# Unit test for method surname of class Person
def test_Person_surname():
    ex = Person()
    result = ex.surname()
    assert type(result) == str
        

# Generated at 2022-06-12 02:22:02.270831
# Unit test for method surname of class Person
def test_Person_surname():
    # Check method with incorrect gender parameter
    with pytest.raises(NonEnumerableError):
        fh = Faker(seed=1234)
        fh.person.surname(gender='invalid_gender')

    # Check method with «known» gender parameter
    fh = Faker(seed=1234)
    assert fh.person.surname(gender=Gender.MALE) == 'Wood'
    assert fh.person.surname(gender=Gender.FEMALE) == 'Green'

    # Check method with «unknown» gender parameter
    fh = Faker(seed=5678)
    assert fh.person.surname(gender=Gender.MALE) == 'Dixon'
    assert fh.person.surname(gender=Gender.FEMALE) == 'Bennett'

   

# Generated at 2022-06-12 02:22:04.189746
# Unit test for method surname of class Person
def test_Person_surname():
    output = Person().surname()
    assert isinstance(output, str)


# Generated at 2022-06-12 02:22:06.861936
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=777)
    assert p.nationality() == 'Russian'


# Generated at 2022-06-12 02:22:13.129093
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    faker = Faker()
    gender_0_1 = list(range(2))
    for _ in range(10):
        surname = faker.surname(gender=random.choice(gender_0_1))
        assert surname
        print(f'surname = {surname!r}')

test_Person_surname()


# Generated at 2022-06-12 02:22:20.010309
# Unit test for method surname of class Person
def test_Person_surname():
    assert type(Person().surname()) is str
    assert len(Person().surname()) > 2
    assert len(Person().surname(gender=Gender.MALE)) > 2
    assert len(Person().surname(gender=Gender.FEMALE)) > 2
    assert len(Person().surname(gender=Gender.NOT_APPLICABLE)) > 2
    assert len(Person().surname(gender=Gender.NOT_KNOWN)) > 2


# Generated at 2022-06-12 02:22:21.825475
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() in SURNAME

# Generated at 2022-06-12 02:22:34.652090
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    name = p.surname(Gender.FEMALE)
    assert name in SURNAME_FEMALE

test_Person_surname()

# Generated at 2022-06-12 02:22:46.519407
# Unit test for method surname of class Person
def test_Person_surname():
    kwargs = {}
    assert type(Person(**kwargs).surname()) == str

# Generated at 2022-06-12 02:22:49.922502
# Unit test for method surname of class Person
def test_Person_surname():
    s = Person()
    print(s.surname(Gender.MALE))
print(test_Person_surname())


# Generated at 2022-06-12 02:23:00.031323
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test function nationality of class Person."""
    person = Person(lang="en")

    res = person.nationality()
    assert res in PERSON_NATIONALITIES["en"]
    assert len(res) >= 2
    assert res.islower()

    res = person.nationality("male")
    assert res in PERSON_NATIONALITIES["en"]["male"]
    assert len(res) >= 2
    assert res.islower()

    res = person.nationality("female")
    assert res in PERSON_NATIONALITIES["en"]["female"]
    assert len(res) >= 2
    assert res.islower()

    person = Person(lang="ru")

    res = person.nationality()
    assert res in PERSON_NATIONALITIES["ru"]
    assert len(res) >= 2
    assert res.islower()



# Generated at 2022-06-12 02:23:12.809741
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:23:17.582735
# Unit test for method nationality of class Person
def test_Person_nationality():
    print('Test nationality')
    person = Person()

    # Test with gender
    nationalities = []
    for i in range(100):
        nationality = person.nationality(Gender.MALE)
        if nationality not in nationalities:
            nationalities.append(nationality)

    print(nationalities)
    print(len(nationalities))
    
test_Person_nationality()

print()


# Generated at 2022-06-12 02:23:21.393006
# Unit test for method surname of class Person
def test_Person_surname():
    s = Person()
    assert isinstance(s.surname(Gender.MALE), str)
    assert isinstance(s.surname(Gender.FEMALE), str)
    assert isinstance(s.surname(), str)
    assert isinstance(s.last_name(Gender.MALE), str)
    assert isinstance(s.last_name(Gender.FEMALE), str)
    assert isinstance(s.last_name(), str)

# Generated at 2022-06-12 02:23:32.189599
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname('m') == "Shakespeare"
    assert Person().surname('f') == "Woolf"
    assert Person().surname('m') == "Hemingway"
    assert Person().surname('f') == "Piercy"
    assert Person().surname('m') == "Borges"
    assert Person().surname('f') == "Rossetti"
    assert Person().surname('m') == "Austen"
    assert Person().surname('f') == "Cisneros"
    assert Person().surname('m') == "Russell"
    assert Person().surname('f') == "Singer"

# Generated at 2022-06-12 02:23:33.763542
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname()


# Generated at 2022-06-12 02:23:41.218916
# Unit test for method nationality of class Person
def test_Person_nationality():
    import pytest
    person_provider_instance = Person(locale='ru')
    RESULT_GENDER = person_provider_instance.nationality()

# Generated at 2022-06-12 02:23:51.700892
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    res = person.email()
    assert type(res) == str
    assert res
    assert re.match(r'[\w\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$', res)

    res = person.email(domains=('gmail.com',))
    assert re.match(r'[\w\.\-]+@gmail\.com$', res)

    res = person.email(unique=True)
    assert re.match(r'[\w\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$', res)

    res = person.email(domains=('gmail.com',), unique=True)
    assert re.match

# Generated at 2022-06-12 02:23:56.203504
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        try:
            random_nationality = Person().nationality()
        except KeyError:
            assert 1, 'There is not key in dictionary in method nationality'
        except TypeError:
            assert 1, 'TypeError in method nationality of class Person'



# Generated at 2022-06-12 02:23:59.804877
# Unit test for method username of class Person
def test_Person_username():
    code = '''
        from faker import Faker
        fake = Faker()
        fake.username()
    '''
    t = timeit.Timer(code, 'gc.enable()')
    print(t.timeit(number=1000000))


# Generated at 2022-06-12 02:24:07.412901
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    template = "UU_d"
    p.username(template=template) == "AbelParet1873"
    p.username(template=template) == "RalphNeumayr1929"
    p.username(template=template) == "JohannWolfgang1946"
    p.username(template=template) == "VernonCantwell1961"
    p.username(template=template) == "PeterMuller1974"
    p.username(template=template) == "DonaldBaring1978"
    p.username(template=template) == "FranklinKraatz1983"
    p.username(template=template) == "SigismundSperl1987"
    p.username(template=template) == "AbelParet2019"

# Generated at 2022-06-12 02:24:17.268730
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
    assert person.nationality() == 'Russian'
   

# Generated at 2022-06-12 02:24:19.760431
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    fake = Faker()
    assert fake.nationality().isalnum()

# Generated at 2022-06-12 02:24:21.535144
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert 'German' == Person().nationality()

# Generated at 2022-06-12 02:24:24.381280
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = PersonProvider()
    try:
        answer = person.nationality()
    except:
        print(status.FAIL + "Unit test for method nationality of class Person")


# Generated at 2022-06-12 02:24:34.824520
# Unit test for method nationality of class Person
def test_Person_nationality():
    import pytest
    from collections import deque
    from faker.providers.person.en_US import Provider
    provider = Provider()
    assert type(provider.nationality()) == str
    assert type(provider.nationality()) != deque
    assert len(provider.nationality()) > 0 
    content = provider.nationality()
    assert ' ' not in content
    assert content != content.swapcase()
    assert not hasattr(content, "__iter__")
    assert not hasattr(content, "__next__")
    assert len(content) > 0
    assert not content.startswith(' ')
    assert not content.endswith(' ')
    assert not content.startswith(('@'))

# Generated at 2022-06-12 02:24:38.552227
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test method nationality of class Person."""
    person = Person(seed=42)

    assert person.nationality(Gender.MALE) == 'Russian'
    assert person.nationality(Gender.FEMALE) == 'Russian'


# Generated at 2022-06-12 02:24:57.199814
# Unit test for method username of class Person
def test_Person_username():
    Person().username()                  # J842
    Person().username(template='U')      # Kate
    Person().username(template='Ud')     # P878
    Person().username(template='UU')     # Lola
    Person().username(template='l')      # l41
    Person().username(template='l_d')    # l94_93
    Person().username(template='ld')     # l9599
    Person().username(template='U_d')    # J_93
    Person().username(template='U.d')    # J.86
    Person().username(template='U-d')    # J-86
    Person().username(template='UU-d')   # L98-42
    Person().username(template='UU.d')   # L98.42
    Person().username(template='UU_d')

# Generated at 2022-06-12 02:25:02.188627
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    men_nationalities = person.nationality(Gender.MALE)
    print(men_nationalities)
    women_nationalities = person.nationality(Gender.FEMALE)
    print(women_nationalities)
    
test_Person_nationality()


# Generated at 2022-06-12 02:25:05.842969
# Unit test for method email of class Person
def test_Person_email():
    # Seed the random number generator to a known state
    Random.seed(1)  
    p = Person()
    email = p.email()
    assert email == "allenlisa6@hotmail.com"


# Generated at 2022-06-12 02:25:15.373443
# Unit test for method nationality of class Person
def test_Person_nationality():
    print("Unit test for method nationality of class Person")
    print("================================================")
    
    person = Person()
    
    print("Test #1: Gender = Male")
    nationality = person.nationality(Gender.MALE)
    print("Nationality is a {}".format("string" if isinstance(nationality, str) else "NOT string!!!"))
    print("Nationality {}".format(nationality))
    print("Test #1: passed\n")
    
    print("Test #2: Gender = Female")
    nationality = person.nationality(Gender.FEMALE)
    print("Nationality is a {}".format("string" if isinstance(nationality, str) else "NOT string!!!"))
    print("Nationality {}".format(nationality))
    print("Test #2: passed\n")
    
    print

# Generated at 2022-06-12 02:25:21.529920
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=12345678)
    nationalities = []
    
    
    for i in range(0,10):
        nationalities.append(p.nationality())
        
    assert nationalities == ['Cambodian', 'American', 'French', 'Afghan', 'Guatemalan', 'Finnish', 'Swedish', 'McDonald Islands', 'Chilean', 'Iraqi']
    assert nationalities[3] == 'Afghan'
    
    

# Generated at 2022-06-12 02:25:23.958851
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationalities = person.nationality()

    assert len(nationalities) > 0
    assert isinstance(nationalities, str)

# Generated at 2022-06-12 02:25:25.827922
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']

# Generated at 2022-06-12 02:25:33.951709
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.providers.base import BaseProvider
    from faker.providers.person.en_US import Provider as PersonProvider

    class MockPersonProvider(PersonProvider):
        def nationality(self, gender=None):
            return 'Japanese'
    provider = MockPersonProvider()

    person = faker.Faker()
    person.add_provider(provider)

    assert person.nationality() != 'Japanese'

    person.add_provider(MockPersonProvider)

    assert person.nationality() == 'Japanese'
    assert person.nationality(gender="Male") == 'Japanese'
    assert person.nationality(gender="Female") == 'Japanese'


# Generated at 2022-06-12 02:25:41.751602
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    with pytest.raises(NonEnumerableError):
        person.nationality('NonEnumerableError')
        person.nationality(100)
        person.nationality([])
        person.nationality(())
        person.nationality(set())
        person.nationality({})
        person.nationality(None)
        person.nationality(False)
        person.nationality(True)
    assert type(person.nationality(Gender.FEMALE)) == str
    assert type(person.nationality(Gender.MALE)) == str

# Generated at 2022-06-12 02:25:46.067077
# Unit test for method nationality of class Person
def test_Person_nationality():
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(integers())
    def test_Person_nationality(country):
        person = Person()
        res = person.nationality(country)
        assert res in person._data['nationality']
    test_Person_nationality()
Person.nationality()


# Generated at 2022-06-12 02:26:11.751701
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality


# Generated at 2022-06-12 02:26:13.321645
# Unit test for method nationality of class Person
def test_Person_nationality():
    gen = Person()
    assert gen.nationality().__class__ == str


# Generated at 2022-06-12 02:26:21.191972
# Unit test for method nationality of class Person
def test_Person_nationality():
    # test for method nationality of class Person
    person = Person()
    random_nationality = person.nationality()

    assert nationalities.has(random_nationality)
    assert person.nationality(Gender.MALE)
    assert person.nationality(Gender.FEMALE)
    assert person.nationality(Gender.ROBOT)

    person = Person(['nationality'])
    random_nationality = person.nationality()
    assert nationalities.has(random_nationality)
    assert person.nationality(Gender.MALE)
    assert person.nationality(Gender.FEMALE)
    assert person.nationality(Gender.ROBOT)



# Generated at 2022-06-12 02:26:30.767360
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:26:38.873649
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Initialization of provider Person
    with Person.override_defaults(lang='en'):
        provider = Provider(Person)
        # Get positions of arguments
        pos = Person._get_argument_positions()['nationality']
        # Used arguments.
        args = [None] * len(pos)
        # Check nationalities of different genders
        args[pos['gender']] = Gender.M
        assert provider.nationality(*args) in NATIONALITIES[Gender.M]
        args[pos['gender']] = Gender.F
        assert provider.nationality(*args) in NATIONALITIES[Gender.F]
 
test_Person_nationality()


# Generated at 2022-06-12 02:26:40.884206
# Unit test for method nationality of class Person
def test_Person_nationality():

    """
    Test method nationality of class Person.
    """
    person = Person()

    assert isinstance(person.nationality(), str)
test_Person_nationality()

# Generated at 2022-06-12 02:26:42.103954
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert isinstance(Person().nationality(), str)

# Generated at 2022-06-12 02:26:44.893306
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = ['American', 'Indian', 'Russian', 'English']
    assert Person(seed=1).nationality() in nationalities


# Generated at 2022-06-12 02:26:49.246107
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.providers.person.en_US import Provider as PersonProvider
    person = Person("en_US")
    national = person.nationality()
    nationalities = PersonProvider.nationalities
    assert national in nationalities, \
    "This nationality should be in the list of nationalities"
    
    
    


# Generated at 2022-06-12 02:26:51.746795
# Unit test for method nationality of class Person
def test_Person_nationality():
    actual = Person(random.Random()).nationality()
    expected = str
    assert type (actual) == expected
    

# Generated at 2022-06-12 02:27:34.973309
# Unit test for method email of class Person
def test_Person_email():
    """Validation method email of class Person."""
    person = Person()
    value = person.email(domains=('@yandex.ru',))
    assert type(value) == str
    assert re.match(r'.+@yandex\.ru', value)
test_Person_email()

# Generated at 2022-06-12 02:27:40.568159
# Unit test for method email of class Person
def test_Person_email():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import integers

    @given(text(), integers(0, 100))
    def test_Person_email(domains, seed):
        domains = domains.split(',')
        provider = Person(seed=seed)
        email = provider.email(domains=domains)
        for domain in domains:
            if domain.startswith('@'):
                domain = domain[1:]
            assert domain in email



# Generated at 2022-06-12 02:27:42.401002
# Unit test for method email of class Person
def test_Person_email():
    pr = Person('en')

    # not seeded
    assert pr.email()

    # seeded
    pr = Person('en', 12345)
    assert pr.email()


# Generated at 2022-06-12 02:27:43.534714
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert isinstance(person.email(unique=True), str)

# Generated at 2022-06-12 02:27:45.664296
# Unit test for method username of class Person
def test_Person_username():
    person = Person()

    assert isinstance(person.username(), str)
    assert len(person.username()) > 0
test_Person_username()

# Generated at 2022-06-12 02:27:48.234061
# Unit test for method email of class Person
def test_Person_email():
    pl = Provider()
    n = 1000
    for i in range(n):
        email = pl.email()
        assert email

# Generated at 2022-06-12 02:27:49.825391
# Unit test for method email of class Person
def test_Person_email():
    s = 'foretime10@live.com'
    assert Person().email() == s


# Generated at 2022-06-12 02:27:52.492217
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    assert email[email.find('@')-1:].count('.') == 1
    

# Unit tests for method full_name of class Person

# Generated at 2022-06-12 02:27:54.517340
# Unit test for method email of class Person
def test_Person_email():
    provider = Provider()
    assert provider.email() in EMAIL_DOMAINS



# Generated at 2022-06-12 02:27:58.993116
# Unit test for method username of class Person
def test_Person_username():
    pr = Person()
    lst = []
    for i in range(100):
        lst.append(pr.username())
    unique_list = list(set(lst))
    if len(unique_list) == 100:
        assert True
    else:
        assert False

# Generated at 2022-06-12 02:28:28.801615
# Unit test for method email of class Person
def test_Person_email():
    '''
    Unit test for method email of class Person
    '''
    import re
    p = Person(seed=None)
    assert p.email()
    assert re.match(r"[^@]+@[^@]+\.[^@]+", p.email())


# Generated at 2022-06-12 02:28:31.437618
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert person.email() == 'herrerajames65@gmail.com'
 

# Generated at 2022-06-12 02:28:33.144366
# Unit test for method email of class Person
def test_Person_email():
    for i in range(100):
        p = Person(random=Random())
        assert isinstance(p.email(), str)



# Generated at 2022-06-12 02:28:36.407048
# Unit test for method email of class Person
def test_Person_email():
    obj = Person()

    results = []
    for _ in range(100):
        results.append(obj.email())

    # Test that all emails are valid.
    assert all(re.match(r'^[\w]+@[a-z]+\.[a-z]+$', email) for email in results)



# Generated at 2022-06-12 02:28:37.753680
# Unit test for method username of class Person
def test_Person_username():
    gen = Person()
    for _ in range(100):
        res = gen.username()
        assert len(res) >= 2
        assert isinstance(res, str)



# Generated at 2022-06-12 02:28:42.670893
# Unit test for method email of class Person
def test_Person_email():
    generator = Person(seed=0)
    assert generator.email(unique=True) == 'lyberty5@yahoo.com'
    assert generator.email(unique=False) == 'lakeley1981@gmail.com'
    assert generator.email(domains=('google.com',), unique=False) == 'nannette18@google.com'



# Generated at 2022-06-12 02:28:45.958433
# Unit test for method email of class Person
def test_Person_email():
    person = Person('en')
    assert re.fullmatch(r'[a-z]+[.|_|-][0-9]{4}@[a-z]+\.com',person.email())


# Generated at 2022-06-12 02:28:56.002602
# Unit test for method email of class Person
def test_Person_email():
    person_provider = Person()

    for _ in range(100):
        assert '@' in person_provider.email()

    person_provider = Person()
    email = person_provider.email(unique=True)
    assert '@' in email
    assert email not in person_provider.past_values

    person_provider = Person()
    email = person_provider.email(unique='user')
    assert '@' in email
    assert email not in person_provider.past_values

    person_provider = Person(seed=1)

    with pytest.raises(ValueError):
        person_provider.email(unique=True)

    person_provider = Person()

    domain = 'example.com'
    email = person_provider.email(domains=[domain])
    assert domain

# Generated at 2022-06-12 02:28:58.429593
# Unit test for method username of class Person
def test_Person_username():
    p = Person(random=Random())
    assert re.fullmatch(
        r'[a-z]{1,9}_[0-9]{4}', p.username(template='l_d'))



# Generated at 2022-06-12 02:28:59.458049
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert isinstance(p.email(), str)

# Generated at 2022-06-12 02:29:21.683479
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    for i in range(10):
        assert person.email() in EMAIL_DOMAINS



# Generated at 2022-06-12 02:29:24.730893
# Unit test for method email of class Person
def test_Person_email():
    person = Person(seed=10)
    # .check_email is method of class Person that get email and check it
    assert person.check_email(person.email()) == True

test_Person_email()


# Generated at 2022-06-12 02:29:27.068627
# Unit test for method email of class Person
def test_Person_email():
    obj = Person()
    assert type(obj.email()) == str
    print("-> test_Person_email() passed")

# Generated at 2022-06-12 02:29:30.438348
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email(unique=True) == 'c9q-qx5@live.com'

# Generated at 2022-06-12 02:29:33.081608
# Unit test for method username of class Person
def test_Person_username():

    for i in range(1000):
        p = Person()
        username = p.username()
        assert isinstance(username, str)
        assert len(username) > 3    

# Generated at 2022-06-12 02:29:34.841915
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    response = p.username()
    assert isinstance(response, str)


# Generated at 2022-06-12 02:29:44.384922
# Unit test for method username of class Person
def test_Person_username():
    p = Person(random=Random())
    assert p.username(template='U') == 'C'
    assert p.username(template='UU') == 'Ci'
    assert p.username(template='UUU') == 'Cir'
    assert p.username(template='UUUU') == 'Cirv'
    
    assert p.username(template='l') == 'w'
    assert p.username(template='ll') == 'wa'
    assert p.username(template='lll') == 'wam'
    assert p.username(template='llll') == 'wame'
    
    assert p.username(template='l_d') == 'w_10'
    assert p.username(template='l_dd') == 'w_10'

# Generated at 2022-06-12 02:29:55.215365
# Unit test for method email of class Person
def test_Person_email():
    random.seed(0)
    assert Person().email(unique=True) is "l4sx3z@163.com"
    assert Person().email() is "qpgll2w@163.com"
    assert Person().email(unique=True) is "9gjf2u@163.com"
    assert Person().email() is "5j5p5@163.com"
    assert Person().email(unique=True) is "ccw64@163.com"
    assert Person().email() is "ltlm9fvm@163.com"
    assert Person().email(unique=True) is "d8hrv@163.com"
    assert Person().email() is "zv6g1@163.com"

# Generated at 2022-06-12 02:29:58.502374
# Unit test for method email of class Person
def test_Person_email():
    """Unit test for method email of class Person."""
    assert Person().email().split('@')[1] in EMAIL_DOMAINS

# Generated at 2022-06-12 02:30:00.013578
# Unit test for method email of class Person
def test_Person_email():
    faker = Person()
    assert isinstance(faker.email(), str)


# Generated at 2022-06-12 02:30:45.045472
# Unit test for method email of class Person
def test_Person_email():
  p = Person()
  assert re.match(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$', p.email()) is not None
test_Person_email()

# Generated at 2022-06-12 02:30:46.198813
# Unit test for method email of class Person
def test_Person_email():
#     person = Person()
    print(Person().email())

test_Person_email()


# Generated at 2022-06-12 02:30:47.454132
# Unit test for method email of class Person
def test_Person_email():
    provider = Person('en')
    assert provider.email() == 'sadakod8@vk.com'


# Generated at 2022-06-12 02:30:50.580829
# Unit test for method email of class Person
def test_Person_email():
    # Initialization
    person = Person()
    person.random.seed(5)
    # Check
    assert person.email(domains=('ukr.net',)) == 'oN334466@ukr.net'



# Generated at 2022-06-12 02:30:52.804835
# Unit test for method email of class Person

# Generated at 2022-06-12 02:30:54.919698
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email('some_email@gmail.com') == 'some_email@gmail.com'

print(test_Person_email())


# Generated at 2022-06-12 02:31:04.854374
# Unit test for method email of class Person
def test_Person_email():
    person = Person('en')

    # Test with default params (all letters, numbers and symbols)
    for _ in range(100):
        email = person.email()
        assert re.match(r'[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-z]+', email)

    # Test with custom domains
    for _ in range(100):
        email = person.email(domains=('example.com', 'example.org'))
        assert re.match(r'[a-zA-Z0-9._]+@example\.[a-z]+', email)
    print(person.email(domains=('example.com', 'example.org')))

    # Test with unique param
    emails = set()

# Generated at 2022-06-12 02:31:09.627557
# Unit test for method email of class Person
def test_Person_email():
    for i in range(100):
        assert len(Person().email()) == 49
    for i in range(100):
        assert len(Person().email(domains=['dom.com'])) == 22
    for i in range(100):
        assert len(Person().email(unique=True)) == 47

# Generated at 2022-06-12 02:31:12.569494
# Unit test for method email of class Person
def test_Person_email():
    from faker import Faker

    fake = Faker()

    for _ in range(100):
        email = fake.email()
        assert '@' in email and len(email.split('@')) == 2, \
            f'Ошибка формата email: {email}'


# Generated at 2022-06-12 02:31:18.710297
# Unit test for method email of class Person
def test_Person_email():
    # Test for param domains
    for i in range(10):
        assert isinstance(Person.evaluate('email(domains=[\'@ru.ru\'])'), str), \
        'Method Person.email() return incorrect value'
    # Test for param unique
    for i in range(10):
        assert isinstance(Person.evaluate('email(unique=True)'), str), \
        'Method Person.email() return incorrect value'
