

# Generated at 2022-06-12 02:21:53.157664
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()

# Generated at 2022-06-12 02:21:55.897748
# Unit test for method email of class Person
def test_Person_email():
    for _ in range(100):
        email = Provider('en').email()
        assert re.fullmatch(SCHEMA_EMAIL, email)



# Generated at 2022-06-12 02:22:03.943670
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:22:13.430394
# Unit test for method nationality of class Person
def test_Person_nationality():
    import pytest                       # Add pytest package
    from my_fake_data.utils import set_seed  # Add set_seed function
    from my_fake_data.enums import Gender  # Add Gender enum

    # Create an object of class 'Person'
    person = Person()

    # Create a cycle for running test 100 times
    for i in range(100):
        # Run test
        result = person.nationality(Gender.FEMALE)

        # Check the result
        assert result in person._data['nationality']['FEMALE']

test_Person_nationality()


# Generated at 2022-06-12 02:22:16.049223
# Unit test for method gender of class Person
def test_Person_gender():
    random.seed(0)
    result = Person.gender()
    assert result == 'Male'
    random.seed()


# Generated at 2022-06-12 02:22:20.900539
# Unit test for method surname of class Person
def test_Person_surname():
    g = Person(seed=1)
    assert g.surname() == 'Kirillov'
    assert g.surname(gender=Gender.FEMALE) == 'Antipova'
    assert g.surname(gender='male') == 'Kirillov'

# Generated at 2022-06-12 02:22:25.324415
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email(unique=True).split('@')[0].isalnum()
    assert p.email(unique=False).split('@')[0].isalnum()
    assert p.email().split('@')[0].isalnum()

# Generated at 2022-06-12 02:22:26.847009
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert type(p.nationality()) == str

# Generated at 2022-06-12 02:22:28.611259
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality()

# Generated at 2022-06-12 02:22:30.291071
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    fake = Faker()
    for _ in range(100):
        assert isinstance(fake.name(), str)

# Generated at 2022-06-12 02:22:49.409374
# Unit test for method surname of class Person
def test_Person_surname():
    # basic test cases
    assert Person().surname() is not None
    assert Person().surname(Gender.MALE) is not None
    assert Person().surname(Gender.FEMALE) is not None
    # test for american (en) language
    assert Person(language='en').surname(Gender.MALE) is not None
    assert Person(language='en').surname(Gender.FEMALE) is not None
    # test for chinese (zh) language
    assert Person(language='zh').surname(Gender.MALE) is not None
    assert Person(language='zh').surname(Gender.FEMALE) is not None


# Generated at 2022-06-12 02:22:52.049713
# Unit test for method nationality of class Person
def test_Person_nationality():
    '''
    Unit test for method nationality of class Person
    '''
    for i in range(10):
        assert Person().nationality() in NATIONALITIES



# Generated at 2022-06-12 02:23:01.214893
# Unit test for method username of class Person
def test_Person_username():
    print('\n\n|---{}---|'.format(inspect.currentframe().f_code.co_name))
    tests = [
        # (input, output)
        (None, True),
        ('Ud', True),
        ('ld', True),
        ('l_d', True),
        ('l.d', True),
        ('l-d', True),
        ('UUd', True),
        ('UU_d', True),
        ('UU.d', True),
        ('UU-d', True),
        ('U_d', True),
        ('U.d', True),
        ('U-d', True),
        ('', False),
        ('#@', False),
        ('U', False),
        ('l', False),
        ('UU', False),
        ('d', False),
    ]

# Generated at 2022-06-12 02:23:09.157651
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    #print(p.nationality())
    #print(p.nationality(Gender.FEMALE))
    #print(p.nationality(Gender.MALE))
    #print(p.nationality('female'))
    #print(p.nationality('male'))
    #print(p.nationality(Gender.MALE))
    print(p.nationality(Gender.FEMALE))





# Generated at 2022-06-12 02:23:12.152568
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Provider(random=Random())
    surname = provider.surname()
    assert surname in SURNAMES
    assert surname not in NAME
    

# Generated at 2022-06-12 02:23:16.165895
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Faker(locale='en')
    assert provider.gender() in ['Male', 'Female']
    assert provider.gender(iso5218=True) in [0, 1, 2, 9]
    assert provider.gender(symbol=True) in ['M', 'F']


# Generated at 2022-06-12 02:23:19.730219
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()

    assert p.nationality() in p.data('nationality')
    assert p.nationality(Gender.MALE) in p.data('nationality', gender='MALE')
    assert p.nationality(Gender.FEMALE) in p.data('nationality', gender='FEMALE')


# Generated at 2022-06-12 02:23:22.005839
# Unit test for method surname of class Person
def test_Person_surname():
    surname_ = Person().surname(Gender.MALE)
    print(surname_)

# Generated at 2022-06-12 02:23:24.506936
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in ['Russian', 'American', 'English',
                                    'German', 'French']



# Generated at 2022-06-12 02:23:27.881977
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    output = person.nationality(Gender.male)
    assert isinstance(output, str)


# Generated at 2022-06-12 02:23:46.614575
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=1234)
    assert person.nationality() == 'American'



# Generated at 2022-06-12 02:23:48.680064
# Unit test for method email of class Person
def test_Person_email():
    matche = re.match(r'[^@]+@[^@]+\.[^@]+', Person().email())
    assert matche is not None

# Generated at 2022-06-12 02:23:50.132347
# Unit test for method nationality of class Person
def test_Person_nationality():
    result = p.nationality
    assert isinstance(result, str)


# Generated at 2022-06-12 02:23:55.789035
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert isinstance(person.gender(), str)
    assert isinstance(person.gender(iso5218=True), int)
    assert isinstance(person.gender(symbol=True), str)

    assert person.gender(iso5218=True) in [0, 1, 2, 9]
    assert len(person.gender(symbol=True)) > 1


# Generated at 2022-06-12 02:23:57.326945
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert "French" in Person().nationality()


# Generated at 2022-06-12 02:23:58.668668
# Unit test for method surname of class Person
def test_Person_surname():
    assert len(Person().surname()) > 0


# Generated at 2022-06-12 02:24:00.867189
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname(Gender.FEMALE)
    assert surname in NameData.surname_female



# Generated at 2022-06-12 02:24:06.217034
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    pytest.assume(provider.surname())
    pytest.assume(provider.surname(gender=Gender.MALE))
    pytest.assume(provider.surname(gender=Gender.FEMALE))
    pytest.assume_raises(NonEnumerableError, provider.surname, "Male")
    pytest.assume_raises(NonEnumerableError, provider.surname, Gender.MALE.value)


# Generated at 2022-06-12 02:24:16.528248
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:24:20.569521
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    person = Person()

    # Act
    actual = person.nationality()

    # Assert
    assert isinstance(actual, str)
test_Person_nationality()


# Generated at 2022-06-12 02:24:40.228065
# Unit test for method nationality of class Person
def test_Person_nationality():
  # Surname in correct format (str) and correct format (dict)
  surnames = ('Pavlik', 'Kostya')
  surnames_dict = {
    Gender.male: ('Pavlik', 'Kostya'),
    Gender.female: ('Olga', 'Katya'),
  }

  # Test dict
  surname = Person.surname(surnames_dict, Gender.male)
  assert surname in surnames

  # Test str
  surname = Person.surname(surnames)
  assert surname in surnames


# Generated at 2022-06-12 02:24:43.519115
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    result = p.nationality(Gender.FEMALE)

    print(result)
    assert result

test_Person_nationality()


# Generated at 2022-06-12 02:24:45.079185
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person.gender() in ['Male', 'Female']



# Generated at 2022-06-12 02:24:52.372836
# Unit test for method surname of class Person
def test_Person_surname():
    num_iterations = 1000
    # Surnames separated by gender.
    surnames = {Gender.MALE: ['Johnson', 'Smith', 'Young'], Gender.FEMALE: ['Brown', 'White', 'Young']}
    P = Person(surnames=surnames)
    for i in range(num_iterations):
        gender = P.gender()
        assert P.surname(gender) in surnames[gender]
        

# Generated at 2022-06-12 02:24:58.916262
# Unit test for method surname of class Person
def test_Person_surname():
    
    assert isinstance(Person().surname(), str)
    assert isinstance(Person().surname(1), str)
    assert Person().surname('man') in Person()._data['surname']['man']
    assert Person().surname('female') in Person()._data['surname']['female']
    
test_Person_surname()

# Generated at 2022-06-12 02:25:01.843858
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    assert p.gender() in ['Male', 'Female']
    assert p.gender(symbol=True) in GENDER_SYMBOLS
    assert p.gender(iso5218=True) in [0, 1, 2, 9]

# Generated at 2022-06-12 02:25:05.842431
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(Gender.FEMALE), str)
    assert isinstance(person.surname(Gender.MALE), str)


# Generated at 2022-06-12 02:25:10.658041
# Unit test for method nationality of class Person
def test_Person_nationality():
    gender = Gender.Male
    
    data = """
    [nationality]
    male = Russian
    female = Russian
    """
    config = {'data': data}
    p = Person(config)
    
    nationality = p.nationality(gender)
    assert nationality == 'Russian'

# Generated at 2022-06-12 02:25:13.904339
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = prov.Person()
    a = p.nationality()
    assert (a in p._data['nationality'])
    print("Unit test for nationality method of class Person: OK")


# Generated at 2022-06-12 02:25:17.721317
# Unit test for method surname of class Person
def test_Person_surname():
    from faker.factory import Factory
    from faker.utils import get_random_item
    from faker.providers import BaseProvider
    from faker.generator import random
    provider = BaseProvider(random)
    for i in range(100): 
        assert type(provider.surname()) is str
    
    

# Generated at 2022-06-12 02:25:31.218781
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname() == 'Driscoll'


# Generated at 2022-06-12 02:25:34.471416
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() == 'Russian'
    assert Person().nationality() == 'Russian'
    assert Person().nationality() == 'Russian'
    assert Person().nationality() == 'Russian'
    assert Person().nationality() == 'Russian'


# Generated at 2022-06-12 02:25:38.177481
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
#     print(p.gender())
#     print(p.gender(symbol=True))
#     print(p.gender(iso5218=True))
test_Person_gender()


# Generated at 2022-06-12 02:25:41.166431
# Unit test for method surname of class Person
def test_Person_surname():
    person_obj = Person('en_EN')
    surname_val = person_obj.surname()
    assert isinstance(surname_val, str)


# Generated at 2022-06-12 02:25:49.726092
# Unit test for method surname of class Person
def test_Person_surname():
    # Create a random object to not create conflict
    rnd = Random()
    # Create instance of Person
    person = Person(random=rnd)
    # Create a list of gender
    genders = [Gender.MALE, Gender.FEMALE, Gender.OTHER]
    # Generate a random surname
    surname = person.surname()
    # Unit test for is surname str
    assert isinstance(surname, str)
    # Generate 2 random surnames
    surname0 = person.surname(gender=genders[0])
    surname1 = person.surname(gender=genders[1])
    # Unit test for surnames are different
    assert surname0 != surname1
    # Generate 2 random surnames
    surname0 = person.surname(gender=genders[0])

# Generated at 2022-06-12 02:25:59.520878
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    from faker.providers.person.en_US import Provider
    from faker.providers.person.en_US import en_US_nationalities
    from faker.providers.person.en_US import en_US_male_nationalities
    from faker.providers.person.en_US import en_US_female_nationalities

    person = Person(Faker)
    provider = Provider(Faker)

    assert person.nationality() in en_US_nationalities
    assert person.nationality('male') in en_US_male_nationalities
    assert person.nationality('female') in en_US_female_nationalities
    assert person.nationality(provider.random_element(provider.genders)) in en_US_nationalities

# Generated at 2022-06-12 02:26:10.031470
# Unit test for method nationality of class Person
def test_Person_nationality():
    size = 100
    result = []

# Generated at 2022-06-12 02:26:17.169614
# Unit test for method nationality of class Person
def test_Person_nationality():
    import pydash
    # Lang: Russian
    # Gender: Random
    # 
    person = Person(lang='ru')
    nat = person.nationality()
    assert pydash.is_string(nat), 'Is not a string'
    assert nat != '', 'String is empty'
    # Lang: English
    # Gender: Random
    # 
    person = Person(lang='en')
    nat = person.nationality()
    assert pydash.is_string(nat), 'Is not a string'
    assert nat != '', 'String is empty'
    # Lang: German
    # Gender: Random
    # 
    person = Person(lang='de')
    nat = person.nationality()
    assert pydash.is_string(nat), 'Is not a string'

# Generated at 2022-06-12 02:26:20.067250
# Unit test for method email of class Person
def test_Person_email():
    from faker import Faker

    fake = Faker()

    for i in range(10000):
        email = fake.email()
        assert isinstance(email, str), 'Test of method email() failed!'



# Generated at 2022-06-12 02:26:21.622218
# Unit test for method email of class Person
def test_Person_email():
    x = Person()
    assert '@' in x.email()


# Generated at 2022-06-12 02:26:38.872965
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in ('Russian','Finnish','Japanese','Afghan','Ukrainian','Burmese','Greek')

# Generated at 2022-06-12 02:26:48.710260
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pprint import pprint
    
    # Test with gender
    random = Random(42)
    person = Person(random=random)
    assert person.nationality(gender=Gender.male) == 'Русский'
    assert person.nationality(gender=Gender.female) == 'Русская'
    
    # Test without gender
    random = Random(42)
    person = Person(random=random)
    assert person.nationality() == 'Русский'
    
    # Test with error raise
    random = Random(42)
    person = Person(random=random)
    try:
        person.nationality(gender='test')
    except NonEnumerableError as e:
        assert e.msg == 'test is not valid gender'
        


# Generated at 2022-06-12 02:26:51.447728
# Unit test for method surname of class Person
def test_Person_surname():
    # Проверим работу метода.
    name = Person().surname()
    assert name



# Generated at 2022-06-12 02:26:53.874813
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    result = p.nationality()
    assert result in p._data['nationality']


# Generated at 2022-06-12 02:27:02.460038
# Unit test for method gender of class Person
def test_Person_gender():
    provider = faker.Provider

    kwargs = {
        'iso5218': False,
        'symbol': False,
    }
    res = provider.gender(provider, **kwargs)
    assert res in provider._data['gender']

    kwargs['iso5218'] = True
    res = provider.gender(provider, **kwargs)
    assert res in (0,1,2,9)

    kwargs['iso5218'] = False
    kwargs['symbol'] = True
    res = provider.gender(provider, **kwargs)
    assert res in provider.GENDER_SYMBOLS
    

# Generated at 2022-06-12 02:27:05.590710
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    for i in range(100):
        surname = provider.surname()
        assert isinstance(surname, str)
        assert surname

# Generated at 2022-06-12 02:27:07.702207
# Unit test for method nationality of class Person
def test_Person_nationality():
    obj=Person()
    obj.nationality()

#Unit test for method name of class Person

# Generated at 2022-06-12 02:27:10.021566
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(20):
        p = Person()
        assert type(p.surname()) == str

# Generated at 2022-06-12 02:27:12.124659
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert len(person.gender()) > 0
    assert isinstance(person.gender(), str)


# Generated at 2022-06-12 02:27:13.723422
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert type(person.gender()) == int or type(person.gender()) == str


# Generated at 2022-06-12 02:27:27.104983
# Unit test for method gender of class Person
def test_Person_gender():
    print("Testing Person.gender()...", end="")
    assert Person().gender() in Person()._data["gender"]
    print(" OK")
# Test method sex of class Person

# Generated at 2022-06-12 02:27:28.696315
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-12 02:27:30.148288
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    assert not isinstance(result, dict)


# Generated at 2022-06-12 02:27:39.946613
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=123)
    surname1 = person.surname()
    assert surname1 == 'Messersmith'
    surname2 = person.surname()
    assert surname2 == 'Fisher'
    surname3 = person.surname()
    assert surname3 == 'McFadden'
    surname4 = person.surname()
    assert surname4 == 'Cabrera'
    # Test without argument Gender
    person = Person()
    surname1 = person.surname()
    assert surname1 in Person._data['surname']
    # Test with Gender
    person = Person(seed=123)
    surname1 = person.surname(Gender.MALE)
    assert surname1 == 'Messersmith'
    surname2 = person.surname(Gender.FEMALE)
    assert surname2

# Generated at 2022-06-12 02:27:41.578632
# Unit test for method surname of class Person
def test_Person_surname():
    # Initialization
    person = Person(random=Random())

    # Execute the method under testing
    result = person.surname(Gender.MALE)

    # Verify the result
    assert isinstance(result, str)


# Generated at 2022-06-12 02:27:49.073161
# Unit test for method surname of class Person
def test_Person_surname():
    p=Person('hello')

# Generated at 2022-06-12 02:27:54.459378
# Unit test for method gender of class Person
def test_Person_gender():

    # case: 1
    person_ = Person()
    result = person_.gender()
    assert result in GENDER_SYMBOLS
    assert len(result) == 1
    assert result in '♂♀⚦⚨⚩⚪⚫'

    # case: 2
    result = person_.gender(symbol=False)
    assert result in GENDER_DATA

    # case: 3
    result = person_.gender(iso5218=True)
    assert result in [0, 1, 2, 9]
    

# Generated at 2022-06-12 02:28:04.494573
# Unit test for method gender of class Person
def test_Person_gender():
    from pyfaker.enums import Gender, Sex
    from pyfaker.providers import BaseProvider
    from pyfaker.utils import get_random_item

    bp = BaseProvider(random=random)
    sex = [Gender.FEMALE, Gender.MALE]

    for i in range(10):
        assert bp.gender(symbol=True) in SEXUALITY_SYMBOLS
        assert bp.gender(iso5218=True) in [0, 1, 2, 9]

        if bp.seed is not None:
            assert bp.gender() == bp.gender()

        assert bp.gender(symbol=True) == bp.sex(symbol=True)
        assert bp.gender(iso5218=True) == bp.sex(iso5218=True)

       

# Generated at 2022-06-12 02:28:08.393524
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)

# Generated at 2022-06-12 02:28:19.067961
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()

    # From list
    surnames = ['Cher', 'Jagger', 'Ronaldo', 'Lennon']
    surname = provider.surname(names=surnames)

    assert surname in surnames

    # From dict
    surnames = {
        Gender.FEMALE: ['Cher', 'Jagger'],
        Gender.MALE: ['Ronaldo', 'Lennon'],
    }
    surname = provider.surname(names=surnames)

    assert surname in ('Cher', 'Jagger', 'Ronaldo', 'Lennon')

    surname = provider.surname(names=surnames, gender=Gender.FEMALE)

    assert surname in ('Cher', 'Jagger')


# Generated at 2022-06-12 02:28:37.170574
# Unit test for method nationality of class Person
def test_Person_nationality():
    from ving.enums import Gender
    from ving.providers._person import Person

    assert(Person().nationality() in ['Russian', 'Kazakh', 'Ukrainian', 'Belarusian'])
    assert(Person().nationality(gender=Gender.FEMALE) in ['Russian', 'Kazakh', 'Ukrainian', 'Belarusian'])
    assert(Person().nationality(gender=Gender.MALE) in ['Russian', 'Kazakh', 'Ukrainian', 'Belarusian'])
    assert(Person().nationality(gender=Gender.NOT_APPLICABLE) in ['Russian', 'Kazakh', 'Ukrainian', 'Belarusian'])


# Generated at 2022-06-12 02:28:38.670307
# Unit test for method surname of class Person
def test_Person_surname():
    P = Person()
    # print(P.surname())
    assert isinstance(P.surname(), str)

# Generated at 2022-06-12 02:28:46.559920
# Unit test for method surname of class Person
def test_Person_surname():
    from data_faker.person import Person
    from data_faker.enum import Gender
    person = Person()
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(gender=Gender.MALE), str)
    assert isinstance(person.surname(gender=Gender.FEMALE), str)
    assert person.surname(gender=Gender.MALE) in person._data['surname']
    assert person.surname(gender=Gender.FEMALE) in person._data['surname']

# Generated at 2022-06-12 02:28:49.173406
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(100):
        surname = Person.surname()
        
        assert(isinstance(surname, str))
# Create an instance of class Person
person = Person()

# Generated at 2022-06-12 02:28:53.265791
# Unit test for method username of class Person
def test_Person_username():
    items = ('', 'U', 'l', 'd', 'UU', 'UU', 'ld', 'l-d', 'Ud', 'l.d', 'l_d')
    for item in items:
        Person().username(template=item)
test_Person_username()

# Generated at 2022-06-12 02:28:54.208678
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname()


# Generated at 2022-06-12 02:29:04.054776
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person()
    # test when iso5218 is True, symbol is True
    iso5218 = True
    symbol = True
    g = provider.gender(iso5218, symbol)
    assert g in [0, 1, 2, 9, "♂", "♀", "⚲"]
    # test when iso5218 is True, symbol is False
    iso5218 = True
    symbol = False
    g = provider.gender(iso5218, symbol)
    assert g in [0, 1, 2, 9]
    # test when iso5218 is False, symbol is True
    iso5218 = False
    symbol = True
    g = provider.gender(iso5218, symbol)
    assert g in ["♂", "♀", "⚲"]
    # test when iso5218 is False, symbol is False (

# Generated at 2022-06-12 02:29:07.475002
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        # You can specify the gender of a person to get the right nationality
        assert Person().nationality(gender=Gender.MALE) == Person().nationality(Gender.MALE)



# Generated at 2022-06-12 02:29:09.001585
# Unit test for method surname of class Person
def test_Person_surname():
    with pytest.raises(ValueError):
        person = Person()
        person.last_name(Gender.MALE)


# Generated at 2022-06-12 02:29:17.026606
# Unit test for method surname of class Person
def test_Person_surname():
    # WHEN : когда мы создаём экземпляр класса Person, передавая в качестве параметров словарь с полом и фамилиями для мужчин и женщин
    person = Person({"male": ["Fry"], "female": ["Leela"]})
    # THEN: тогда когда метод surname вызывается с параметром

# Generated at 2022-06-12 02:29:34.723519
# Unit test for method surname of class Person
def test_Person_surname():
    from .data import surnames
    from .data import russian_surnames
    for i in range(100):
        assert Person().surname() in surnames
        assert Person().surname(gender=Gender.male) in russian_surnames[Gender.male]
        assert Person().surname(gender=Gender.female) in russian_surnames[Gender.female]


# Generated at 2022-06-12 02:29:36.837377
# Unit test for method surname of class Person
def test_Person_surname():
    lab_person = Person()
    for _ in range(10):
        assert lab_person.surname() in lab_person._data['surname']

# Generated at 2022-06-12 02:29:40.769703
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    # assert that nationality is not an empty string
    assert nationality != ''
    # assert that nationality is in nationality data
    assert nationality in person._data['nationality']

# Generated at 2022-06-12 02:29:43.451537
# Unit test for method surname of class Person
def test_Person_surname():
    # Setup
    person = Person()

    # Exercise
    surname = person.surname()

    # Assert
    assert isinstance(surname, str)


# Generated at 2022-06-12 02:29:54.287326
# Unit test for method surname of class Person

# Generated at 2022-06-12 02:29:55.529366
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert(Person().nationality() in Person._occupation)

# Generated at 2022-06-12 02:29:59.702783
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    surname = p.surname()
    assert(surname != None)
    assert(surname in p._data['surname'])
    # Unit test for method gender of class Person

# Generated at 2022-06-12 02:30:09.571072
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()

    # Surname with gender
    surname = provider.surname(gender=Gender.MALE)
    assert surname in SURNAMES['MALE']

    # Surname without gender
    surname_1 = provider.surname()
    assert surname_1 in SURNAMES['MALE'] or surname_1 in SURNAMES['FEMALE']

    # Surname with Gender Enum
    surname_2 = provider.surname(gender=Gender.FEMALE)
    assert surname_2 in SURNAMES['FEMALE']

    # Surname for dictionary
    surname_3 = provider.surname(
        surnames=SURNAMES['MALE']
    )
    assert surname_3 in SURNAMES['MALE']

    # Surname for dictionary with gender

# Generated at 2022-06-12 02:30:10.972157
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert type(surname) == str

# Generated at 2022-06-12 02:30:17.186230
# Unit test for method surname of class Person
def test_Person_surname():
    
    #Test 1
    #Test random surname
    myFaker = Faker(['en_AU'])
    person = myFaker.name()
    assert isinstance(person.surname(), str) == True
    assert isinstance(person.surname(), int) == False
    assert isinstance(person.surname(), float) == False
    
    #Test 2
    #Test random surname
    myFaker = Faker(['en_GB'])
    person = myFaker.name()
    assert isinstance(person.surname(), str) == True
    assert isinstance(person.surname(), int) == False
    assert isinstance(person.surname(), float) == False
    
    #Test 3
    #Test random surname
    myFaker = Faker(['en_CA'])

# Generated at 2022-06-12 02:30:44.226680
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    #
    results = []
    for i in range(100):
        username = person.username(template='Ud')
        is_username_correct_format = re.fullmatch(r'[A-Z]d', username)
        results.append(is_username_correct_format)
    #
    assert all(results)


# Generated at 2022-06-12 02:30:53.228075
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    print('')
    print(util.func())
    print(person.email())
    print('')
    print(util.func())
    print(person.email(unique=True))
    print('')
    print(util.func())
    print(person.email(domains=('ya.ru', 'gmail.com', 'yahoo.com')))
    print('')
    print(util.func())
    print(person.email(domains=('ya.ru', 'gmail.com', 'yahoo.com')))
    print('')
    print(util.func())
    print(person.email(domains=('ya.ru', 'gmail.com', 'yahoo.com')))
    print('')
    print(util.func())

# Generated at 2022-06-12 02:30:55.628701
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pprint import pprint

    # Sample of the realisations
    for _ in range(10):
        pprint(Person.create().nationality())
    print('nationality: pass\n')



# Generated at 2022-06-12 02:31:05.382227
# Unit test for method username of class Person
def test_Person_username():
    rnd = MockRandom()
    rnd.choice = Mock(side_effect=[
        'default', 'default', 'default', 'default',
        'U_d', 'U.d', 'U-d', 'UU-d', 'UU.d', 'UU_d',
        'ld', 'l-d', 'Ud', 'l.d', 'l_d'
    ])
    rnd.randstr = Mock(return_value='generated_digits_name')
    person = Person(random=rnd)
    assert person.username() == 'generated_digits_name'
    assert person.username() == 'generated_digits_name'
    assert person.username() == 'generated_digits_name'
    assert person.username() == 'generated_digits_name'

# Generated at 2022-06-12 02:31:08.453463
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']



# Generated at 2022-06-12 02:31:19.247527
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pprint import pprint
    Nationality = Provider.Nationality
    p = Person()
    # Test for case when gender is None
    assert p.nationality() in Nationality.all()
    # Test for case when gender is Person.Gender.male
    assert p.nationality(gender=Person.Gender.male) in Nationality.male()
    # Test for case when gender is Person.Gender.female
    assert p.nationality(gender=Person.Gender.female) in Nationality.female()
    # Test for case when gender is not an enum Person.Gender
    try:
        p.nationality(gender='test')
        assert False
    except Exception as error:
        assert error.args[0] == 'Value «test» is not an enum member of Gender'

# Generated at 2022-06-12 02:31:23.152344
# Unit test for method nationality of class Person
def test_Person_nationality():
    for lang in get_available_locales():
        inst = Person(lang)
        
        assert isinstance(inst.nationality(), str)
        assert isinstance(inst.nationality('male'), str)
        assert isinstance(inst.nationality('female'), str)

# Generated at 2022-06-12 02:31:25.244550
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    p.nationality()
    p.nationality(gender=Gender.male)
    p.nationality(gender=Gender.female)

# Generated at 2022-06-12 02:31:28.321286
# Unit test for method email of class Person
def test_Person_email():
    from faker import Faker
    from decimal import Decimal
    fake = Faker()
    decimal_digits = [(Decimal('0.1') * 10 ** i) for i in range(1, 19)] + [1]


# Generated at 2022-06-12 02:31:29.642232
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(locale='en')
    print('nationality:', person.nationality())