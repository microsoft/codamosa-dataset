

# Generated at 2022-06-12 02:21:44.330217
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality(Person) == 'Russian'


# Generated at 2022-06-12 02:21:56.601283
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:22:00.275579
# Unit test for method email of class Person
def test_Person_email():
    # Test with seeded provider and unique
    provider = Person(seed=7)
    email_1 = provider.email(unique=True)

    provider = Person(seed=7)
    email_2 = provider.email(unique=True)

    assert email_1 == email_2



# Generated at 2022-06-12 02:22:02.414047
# Unit test for method surname of class Person
def test_Person_surname():
    aPerson = Person()
    surname = aPerson.surname()
    assert len(surname) > 0


# Generated at 2022-06-12 02:22:14.721751
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Person Gender.MALE
    nat = GEN.Person().nationality(Gender.MALE)
    print(nat)

# Generated at 2022-06-12 02:22:17.070166
# Unit test for method nationality of class Person
def test_Person_nationality():
    obj = Person()
    res = obj.nationality()
    assert isinstance(res, str)
    assert len(res) > 0

# Generated at 2022-06-12 02:22:18.613692
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    assert isinstance(person.email(), str)


# Generated at 2022-06-12 02:22:21.775923
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person('en_US')
    nationality = p.nationality()
    assert nationality in p._data['nationality']
    assert nationality == 'American'

# Generated at 2022-06-12 02:22:33.021976
# Unit test for method nationality of class Person
def test_Person_nationality():
    seed_random(42)
    assert Person().nationality() == 'Russian'
    assert Person().nationality() == 'English'
    assert Person().nationality() == 'Spanish'
    assert Person().nationality() == 'German'
    assert Person().nationality() == 'Aymara'
    assert Person().nationality() == 'Spanish'
    assert Person().nationality() == 'Aymara'
    assert Person().nationality() == 'Swiss'
    assert Person().nationality() == 'Spanish'
    assert Person().nationality() == 'Latvian'
    assert Person().nationality() == 'English'
    assert Person().nationality() == 'English'
    assert Person().nationality() == 'Spanish'
    assert Person().nationality() == 'Kazakh'
    assert Person().nationality() == 'Kazakh'


# Generated at 2022-06-12 02:22:34.232963
# Unit test for method nationality of class Person
def test_Person_nationality():
    generator = Person()
    assert generator.nationality() in NATIONALITIES

# Generated at 2022-06-12 02:22:46.657404
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person() 
    nationality = person.nationality()
    assert type(nationality) == str


# Generated at 2022-06-12 02:22:58.437454
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person"""

    # Arrange
    person = Person()

# Generated at 2022-06-12 02:23:03.799184
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(random=faker)
    assert isinstance(person.surname(), str)
    assert len(person.surname()) >= 3
    assert len(person.surname()) <= 20
    assert ' ' not in person.surname()


# Generated at 2022-06-12 02:23:10.186162
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit test for method nationality of class Person."""
    # Arrange
    from faker.providers import BaseProvider
    from faker import Faker

    fake = Faker()
    fake.add_provider(BaseProvider)
    fake.add_provider(Person)

    # Act
    value = fake.nationality()

    # Assert
    assert isinstance(value, str)


# Generated at 2022-06-12 02:23:14.320327
# Unit test for method surname of class Person
def test_Person_surname():
    sample = random.choices(Person.surname())
    sample_check = all(type(elem) == str for elem in sample)
    assert sample_check == True
# Test sample of method surname of class Person
Person.surname()


# Generated at 2022-06-12 02:23:15.319254
# Unit test for method nationality of class Person
def test_Person_nationality():
    with pytest.raises(NonEnumerableError):
        Person.nationality('Male')

# Generated at 2022-06-12 02:23:25.568959
# Unit test for method nationality of class Person
def test_Person_nationality():

    provider = Person(seed=0)
    assert provider.nationality() == 'Russian'
    assert provider.nationality(gender=provider.gender(symbol='♂')) == 'Russian'
    assert provider.nationality(gender=provider.gender(symbol='♀')) == 'Russian'
    assert provider.nationality(gender=provider.gender(symbol='⚥')) == 'Russian'
    assert provider.nationality(gender=provider.gender(symbol='❌')) == 'Russian'
    assert provider.nationality(gender=provider.gender(symbol='⚢')) == 'Russian'
    assert provider.nationality(gender=provider.gender(symbol='⚣')) == 'Russian'

# Generated at 2022-06-12 02:23:28.285092
# Unit test for method surname of class Person
def test_Person_surname():
    assert type(Person().surname()) == str
    assert len(Person().surname()) > 0


# Generated at 2022-06-12 02:23:30.543136
# Unit test for method nationality of class Person
def test_Person_nationality():
    obj_person = Person()
    assert isinstance(obj_person.nationality(), str)


# Generated at 2022-06-12 02:23:33.428574
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=42)
    assert person.surname() == 'Hansen'



# Generated at 2022-06-12 02:23:47.017014
# Unit test for method nationality of class Person
def test_Person_nationality():
    for n in range(100):
        assert isinstance(Person().nationality(), str)

# Generated at 2022-06-12 02:23:48.287075
# Unit test for method email of class Person
def test_Person_email():

    person = Person()
    email = person.email()
    print(email)
    return isinstance(email, str)


# Generated at 2022-06-12 02:23:55.094727
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    p.seed(12345)
    assert p.nationality() == 'Russian'
    assert p.nationality(Gender.male) == 'Russian'
    assert p.nationality(Gender.female) == 'Russian'
    assert p.nationality(Gender.male) == 'Russian'
    assert p.nationality(Gender.female) == 'Russian'
    assert p.nationality(Gender.male) == 'Russian'
    assert p.nationality(Gender.female) == 'Russian'

# Generated at 2022-06-12 02:23:58.457025
# Unit test for method nationality of class Person
def test_Person_nationality():
    """
    Test Person.nationality
    """
    person = Person()
    result = person.nationality()
    assert result in ['Asian', 'Black', 'Indian', 'Latino', 'Middle Eastern', 'Native American', 'White']

# Generated at 2022-06-12 02:23:59.718996
# Unit test for method surname of class Person
def test_Person_surname():
    assert isinstance(Person().surname(), str)

# Generated at 2022-06-12 02:24:06.729091
# Unit test for method nationality of class Person
def test_Person_nationality():

    # Test with instance
    p1 = Person('en')
    p2 = Person('ru')
    p3 = Person('de')

    assert p1.nationality() in PERSON_NATIONALITY_EN
    assert p2.nationality() in PERSON_NATIONALITY_RU
    assert p3.nationality() in PERSON_NATIONALITY_DE

    # Test with class
    p11 = Person('en')
    p22 = Person('ru')
    p33 = Person('de')

    assert p11.nationality() in PERSON_NATIONALITY_EN
    assert p22.nationality() in PERSON_NATIONALITY_RU
    assert p33.nationality() in PERSON_NATIONALITY_DE

# Generated at 2022-06-12 02:24:16.138999
# Unit test for method surname of class Person
def test_Person_surname():
    name_gen = Person(seed=1)
    assert name_gen.surname() == 'Бурлаков'
    assert name_gen.surname(gender=Gender.Male) == 'Бурлаков'
    assert name_gen.surname(gender=Gender.Female) == 'Львова'

    name_gen = Person(seed=1, lang='en')
    assert name_gen.surname() == 'Sanchez'
    assert name_gen.surname(gender=Gender.Male) == 'Sanchez'
    assert name_gen.surname(gender=Gender.Female) == 'Johnson'

# Generated at 2022-06-12 02:24:18.138595
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    print(person.nationality())


# Generated at 2022-06-12 02:24:25.596661
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.providers.lorem import Provider as LoremProvider
    from faker.providers.date_time import Provider as DateTimeProvider
    from faker.providers.person import Provider as PersonProvider
    from faker.providers.misc import Provider as MiscProvider
    from faker.providers.misc import Provider as MiscProvider
    from faker import Faker
    fake = Faker()
    fake.add_provider(LoremProvider)
    fake.add_provider(DateTimeProvider)
    fake.add_provider(PersonProvider)
    fake.add_provider(MiscProvider)
    person = Person()
    nationality = person.nationality()
    assert nationality == fake.nationality()
    assert nationality in person._data['nationality']



# Generated at 2022-06-12 02:24:36.935238
# Unit test for method surname of class Person
def test_Person_surname():
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.person.ru_RU import Provider as PersonProvider_ru
    #Create object of class Person
    p = Person()
    #Test surname with default parameter
    result = p.surname()
    #Assert that result is in the list of surnames
    assert result in PersonProvider.surnames
    #Test surname with gender Female
    result = p.surname(gender='female')
    #Assert that result is in the list of surnames
    assert result in PersonProvider.surnames
    #Assert that result is not in the list of male surnames
    assert result not in PersonProvider.male_surnames
    #Test surname with gender Male
    result = p.surname(gender='male')
    #