

# Generated at 2022-06-12 02:27:23.171980
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']
test_Person_nationality()


# Generated at 2022-06-12 02:27:25.771216
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), six.text_type)
    

# Generated at 2022-06-12 02:27:27.981894
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITIES # and so on
    # To do
    pass


# Generated at 2022-06-12 02:27:29.503312
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = PERSON.nationality()
    assert isinstance(nationalities, str)



# Generated at 2022-06-12 02:27:39.667425
# Unit test for method surname of class Person
def test_Person_surname():
    # Set a seed for better predictability
    random.seed(42)

    PersonProvider.seed(None)
    provider = PersonProvider()

    assert provider.surname() == 'Коновалов'
    assert provider.surname('male') == 'Коновалов'
    assert provider.surname(Gender.MALE) == 'Коновалов'
    assert provider.surname(gender='male') == 'Коновалов'

    assert provider.surname(gender='female') == 'Коновальцева'
    assert provider.surname('female') == 'Коновальцева'

# Generated at 2022-06-12 02:27:48.018486
# Unit test for method surname of class Person
def test_Person_surname():
    # Testing surname method with default value None
    # for parameter "gender".
    gender = None
    a = Person(gender=gender)
    surname = a.surname(gender=gender)
    
    assert surname in ('Радулов', 'Буряк', 'Ковалев')
    
    # Testing surname method with specific value
    # for parameter "gender", here it is a Male.
    gender = Male
    a = Person(gender=gender)
    surname = a.surname(gender=gender)
    
    assert surname in ('Радулов', 'Буряк', 'Ковалев')
    
    # Testing surname method with specific value
    # for parameter "gender", here it is a Female.

# Generated at 2022-06-12 02:27:50.979760
# Unit test for method email of class Person
def test_Person_email():
    # Init
    p = Person()
    # Run
    ans = p.email()
    # Assert
    assert ans is not None
    assert isinstance(ans, str)
    assert len(ans)>0


# Generated at 2022-06-12 02:27:53.213902
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    # Act
    obj = Person()
    # Assert
    assert isinstance(obj.nationality(), str)
    assert obj.nationality() in obj._data['nationality']

# Generated at 2022-06-12 02:27:54.746796
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    result = person.surname()
    assert type(result) is str
    assert result != ''
    assert result is not None

# Generated at 2022-06-12 02:27:56.925684
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username() != Person().username()


# Generated at 2022-06-12 02:29:18.122062
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person(random=Random())
    surname = provider.surname()

    assert type(surname) == str
    assert len(surname) > 0

# Generated at 2022-06-12 02:29:19.568441
# Unit test for method surname of class Person
def test_Person_surname():
    assert 0, "Not implemented"



# Generated at 2022-06-12 02:29:22.537673
# Unit test for method username of class Person
def test_Person_username():
    rnd = Random()
    provider = Person(rnd)
    for _ in range(1000):
        username = provider.username(template='U_d')
        assert username[0].isupper()
        assert username[2] == '_'
        assert username[6:].isdigit()

# Generated at 2022-06-12 02:29:29.195839
# Unit test for method username of class Person
def test_Person_username():
    for t in ('U_d', 'U.d', 'U-d', 'UU-d', 'UU.d', 'UU_d', 'ld', 'l-d',
              'Ud', 'l.d', 'l_d', 'default'):
        try:
            Person().username(template=t)
        except ValueError:
            assert False
            print(t)


# Generated at 2022-06-12 02:29:31.700354
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(100):
        assert Person().surname() in SURNAMES

if __name__ == '__main__':
    test_Person_surname()

# Generated at 2022-06-12 02:29:34.469154
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    fake = Faker('ru_RU')
    assert fake.nationality() != fake.nationality()

# Generated at 2022-06-12 02:29:43.034383
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    domains = ('gmail.com', 'yandex.ru', 'mail.ru', 'bk.ru')
    assert p.email()
    assert p.email().split('@')[1] in domains
    assert p.email(unique=True)
    assert p.email(unique=True).split('@')[1] in domains
    assert p.email(domains=('yandex.ru',)).split('@')[1] == 'yandex.ru'
    assert p.email(domains=('yandex.ru', 'rambler.ru')).split('@')[1] in \
           ('yandex.ru', 'rambler.ru')

# Generated at 2022-06-12 02:29:44.483411
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    assert len(provider.surname()) > 0

# Generated at 2022-06-12 02:29:48.477531
# Unit test for method surname of class Person
def test_Person_surname():
    print("\nTesting Person.surname...")
    person = Person()
    assert isinstance(person.surname(), str)
    print("Testing Person.surname is done!")
    



# Generated at 2022-06-12 02:29:52.848322
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(100):
        surname = Person.surname()
        assert isinstance(surname, str), \
            'Function returned non-string value'
        assert len(surname) > 0, \
            'Function returned empty value'


# Generated at 2022-06-12 02:31:13.889407
# Unit test for method nationality of class Person
def test_Person_nationality():
    obj = Person()
    assert isinstance(obj.nationality(), str)



# Generated at 2022-06-12 02:31:16.210277
# Unit test for method username of class Person
def test_Person_username():
    rnd = Random()
    provider = Person(rnd)
    for _ in range(10):
        assert re.match(r"(\w+)", provider.username())

# Generated at 2022-06-12 02:31:19.173412
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-12 02:31:20.694582
# Unit test for method surname of class Person
def test_Person_surname():
    d = person.surname()
    assert isinstance(d,str)

# Generated at 2022-06-12 02:31:22.973224
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname() == 'Marquardt'


# Generated at 2022-06-12 02:31:28.486521
# Unit test for method surname of class Person
def test_Person_surname():
    from pydiator.mediatr import Mediator
    from pydiator.request import get_request
    from random_generator.request_handlers.person import Person

    mediator = Mediator()
    mediator.register_handler(Person())

    request = get_request("random_generator.Person", "surname",
                          Gender.MALE, "MENDOZA")

    result = mediator.send(request)

    assert result == "Mendosa"
test_Person_surname()
