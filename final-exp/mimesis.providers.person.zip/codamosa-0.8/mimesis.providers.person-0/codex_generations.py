

# Generated at 2022-06-12 02:21:49.502703
# Unit test for method gender of class Person
def test_Person_gender():
    gen = Generator()
    person = Person(gen)
    person.gender()

    assert person.sex('m') == 'Male'
    assert person.sex('f') == 'Female'

    assert person.sex() == 'Male' or person.sex() == 'Female'
    assert isinstance(person.sex(iso5218=True), int)

    assert person.sex(symbol=True) in GENDER_SYMBOLS



# Generated at 2022-06-12 02:22:00.134832
# Unit test for method nationality of class Person
def test_Person_nationality():
    random.seed(0)
    assert Person().nationality() == 'Afghanistani'
    assert Person().nationality() == 'Indian'
    assert Person().nationality() == 'Albanian'
    assert Person().nationality() == 'The Macedonian'
    assert Person().nationality() == 'Ghanaian'
    assert Person().nationality() == 'Taiwanese'
    assert Person().nationality() == 'Albanian'
    assert Person().nationality() == 'Bolivian'
    assert Person().nationality() == 'Ethiopian'
    assert Person().nationality() == 'Tanzanian'
    assert Person().nationality() == 'Tajikistani'
    assert Person().nationality() == 'Kenyan'
    assert Person().nationality() == 'British'

# Generated at 2022-06-12 02:22:02.222010
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(seed=0)
    assert p.surname() == 'Попов'


# Generated at 2022-06-12 02:22:05.826634
# Unit test for method surname of class Person
def test_Person_surname():
    mock_gender = random.choice([Gender.MALE, Gender.FEMALE])
    assert Person().surname(mock_gender) in SURNAMES[mock_gender]



# Generated at 2022-06-12 02:22:08.952654
# Unit test for method gender of class Person
def test_Person_gender():
    for i in range(100):
        person = Person()
        gender = person.gender()
        assert (gender == 'Male') or (gender == 'Female')


# Generated at 2022-06-12 02:22:12.288923
# Unit test for method email of class Person
def test_Person_email():
    print(Person().email())
    print(Person().email(domains=('example.com', 'gmail.com')))
    print(Person().email(unique=True))


# Generated at 2022-06-12 02:22:13.789365
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() is not None
    
    

# Generated at 2022-06-12 02:22:16.396725
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_gen = Person()
    nationalities = person_gen.nationality()
    assert isinstance(nationalities, str)

# Generated at 2022-06-12 02:22:24.161406
# Unit test for method surname of class Person
def test_Person_surname():
    from fake.constants.random_generator import RandomGenerator
    from fake.constants.items import Gender, Male
    from fake.enums.title_type import TitleType, Suffix

    seed = 8
    generator = RandomGenerator(seed)
    person = Person(rnd=generator)

    gender = Male
    title_type = Suffix

    assert person.surname(gender) == 'Hagenes'
    assert person.surname(title_type=title_type) == 'IV'


# Generated at 2022-06-12 02:22:28.751929
# Unit test for method nationality of class Person
def test_Person_nationality():
    import random
    pr = Person(random=random)
    result = pr.nationality()
    assert type(result) is str, 'result must be of type str'
    assert len(result) > 0, 'result must not be empty'


# Generated at 2022-06-12 02:22:46.974194
# Unit test for method gender of class Person
def test_Person_gender():
    # case 1: Without arguments
    assert Person().gender() in GENDERS
    # case 2: With argument iso5218=True
    assert Person().gender(iso5218=True) in [0, 1, 2, 9]
    # case 3: With argument symbol=True
    assert Person().gender(symbol=True) in GENDER_SYMBOLS


# Generated at 2022-06-12 02:22:56.738965
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    person = Person(seed=1234)

    # Act
    actual1 = person.surname()

    # Assert
    assert actual1 == 'Ebner'

    # Arrange
    person = Person(seed=4321)

    # Act
    actual2 = person.surname(gender="Male")

    # Assert
    assert actual2 == 'Gerecke'

    # Arrange
    person = Person(seed=4231)

    # Act
    actual3 = person.surname(gender="Female")

    # Assert
    assert actual3 == 'Coe'


# Generated at 2022-06-12 02:23:09.065081
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:23:15.078777
# Unit test for method nationality of class Person
def test_Person_nationality():
    # single gender
    for gender in Gender:
        p = Person(gender=gender)
        for _ in range(3):
            assert gender.name in p.nationality()

    # separate genders
    fn_gas = Person(gender=Gender.FEMALE)
    fn_mns = Person(gender=Gender.MALE)
    assert fn_gas.nationality() == fn_mns.nationality()

    # equal to string
    assert fn_gas.nationality() == 'Gasan'

    # random gender
    p = Person(gender=Gender.RANDOM)
    for _ in range(3):
        assert p.nationality() in {'Gasan', 'Mansan'}


# Generated at 2022-06-12 02:23:17.660343
# Unit test for method gender of class Person
def test_Person_gender():
    test_list = [obj.gender() for _ in range(10)]
    assert True if 'Male' in test_list else False
    assert True if 'Female' in test_list else False

# Generated at 2022-06-12 02:23:19.880687
# Unit test for method nationality of class Person
def test_Person_nationality():
    from hypothesis import strategies as st
    from hypothesis import given
    from faker.providers.person.en_US import Provider

    person = Provider.nationality()
    assert person in Provider._data["nationality"]

# Generated at 2022-06-12 02:23:32.279174
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Generate random nationality
    nationality = Person(random=faker.Factory.create(locale='ru')).nationality()
    assert nationality
    print('nationality: ', nationality)

    # Generate male nationality
    nationality = Person(random=faker.Factory.create(locale='ru')).nationality(gender=Gender.MALE)
    assert nationality
    print('nationality: ', nationality)

    # Generate female nationality
    nationality = Person(random=faker.Factory.create(locale='ru')).nationality(gender=Gender.FEMALE)
    assert nationality
    print('nationality: ', nationality)

    # Check invalid values for parameter «gender»
    with pytest.raises(NonEnumerableError):
        Person().nationality(gender='test')


# Generated at 2022-06-12 02:23:40.534939
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker_dstk import Gender
    from faker_dstk.enums import Gender
    from faker_dstk.enums import Gender
    from random import Random
    from tqdm import tqdm

    def repok(item):
        if isinstance(item, str):
            return True
        return False

    # Initialize provider
    provider = Person(random=Random(42))

    # Check method nationality
    result = provider.nationality(gender=Gender.MALE)
    assert result == 'Russian', 'incorrect nationality'

    # Check method nationality
    result = provider.nationality(gender=Gender.FEMALE)
    assert result == 'Russian', 'incorrect nationality'

    # Check method nationality
    result = provider.nationality()
    assert repok(result), 'incorrect nationality'

   

# Generated at 2022-06-12 02:23:46.013570
# Unit test for method gender of class Person
def test_Person_gender():
    l = list(range(1, 101))
    v = [Person().gender(iso5218=True) for _ in l]
    assert all([type(i) == int for i in v])
    assert all([i in [0, 1, 2, 9] for i in v])



# Generated at 2022-06-12 02:23:48.502549
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    # name = p.nationality([Gender.FEMALE])
    assert p.nationality().lower() in p._data['nationality']

# Generated at 2022-06-12 02:24:06.068485
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = {
        Gender.OTHER: [
            'Russian', 'Canadian', 'Polish', 'British'
        ],
        Gender.MALE: [
            'American', 'English'
        ],
        Gender.FEMALE: [
            'French', 'German', 'Greek'
        ]
    }
    # Testing method nationality with parameter gender=Gender.MALE
    assert Person(nationalities=nationalities).nationality(gender=Gender.MALE) in ['English', 'American']
    # Testing method nationality with parameter gender=Gender.FEMALE
    assert Person(nationalities=nationalities).nationality(gender=Gender.FEMALE) in ['French', 'German', 'Greek']
    # Testing method nationality with parameter gender=Gender.OTHER

# Generated at 2022-06-12 02:24:09.130779
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    val1 = p.surname()
    val2 = p.surname()
    assert p.surname() != p.surname()

# Generated at 2022-06-12 02:24:11.776708
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    name = person.nationality()
    assert name, 'Empty name'


# Generated at 2022-06-12 02:24:14.059445
# Unit test for method gender of class Person
def test_Person_gender():
    """Unit test for method gender of class Person."""
    obj = Person()
    assert obj.gender() in ('Male', 'Female')

# Generated at 2022-06-12 02:24:24.174405
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:24:30.331332
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    surname = person.surname(gender=Gender.MALE)
    assert type(surname) == str

    surname = person.surname(gender=Gender.FEMALE)
    assert type(surname) == str

    surname = person.surname(gender=Gender.NOT_KNOWN)
    assert type(surname) == str

# Generated at 2022-06-12 02:24:32.286823
# Unit test for method email of class Person
def test_Person_email():
    obj = Person()
    assert obj.email() in EMAIL_FORMAT

# Generated at 2022-06-12 02:24:37.736691
# Unit test for method nationality of class Person
def test_Person_nationality():
    # we will use Person from the class Faker from faker
    from faker import Faker
    faker = Faker()
    # selecting a random nationality from Person
    nationalities = faker.nationality()
    # showing a random nationality from Person
    print(nationalities)

if __name__=='__main__':
    test_Person_nationality()


# Generated at 2022-06-12 02:24:39.312886
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert_generated(Person, 'nationality', 'America')

# Generated at 2022-06-12 02:24:43.383668
# Unit test for method surname of class Person
def test_Person_surname():
    from data_faker.enums import Gender

    p = Person()
    p.seed(1)
    assert p.surname(gender=Gender.MALE) == 'Кузнецов'



# Generated at 2022-06-12 02:24:58.915372
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    results = {provider.nationality() for i in range(1000)}
    assert results == set(NATIONALITIES)


# Generated at 2022-06-12 02:25:10.190791
# Unit test for method surname of class Person
def test_Person_surname():

    # Surnames not separated by gender
    p1 = Person('en')
    assert len(p1.surname()) == 1

    # Surnames separated by gender
    p2 = Person(locale='ru')
    assert len(p2.surname()) == 1
    assert len(p2.surname(gender='male')) == 1
    assert len(p2.surname(gender='female')) == 1
    assert len(p2.surname(gender='gender-neutral')) == 1
    assert len(p2.surname(gender='unknown')) == 1
    assert len(p2.surname(gender='none')) == 1
    assert len(p2.surname(gender='not-applicable')) == 1
 

# Generated at 2022-06-12 02:25:11.125304
# Unit test for method surname of class Person
def test_Person_surname():
    Person.surname()

# Generated at 2022-06-12 02:25:13.904340
# Unit test for method gender of class Person
def test_Person_gender():
    # Check error: incorrect gender
    with pytest.raises(NonEnumerableError):
        gender = None
        PersonProvider().gender(gender=gender)
test_Person_gender()

# Generated at 2022-06-12 02:25:23.208042
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person.gender('Male') == Gender.Male
    assert Person.gender('Woman') == Gender.Woman
    assert Person.gender() in range(0, 20)
    assert Person.gender(iso5218=True) in range(0, 3)
    assert Person.gender(symbol=True) in GENDER_SYMBOLS


# Generated at 2022-06-12 02:25:29.738706
# Unit test for method gender of class Person
def test_Person_gender():
    """Test the method gender of class Person."""
    person = Person()
    for _ in range(100):
        gender = person.gender()
        assert gender in person._data['gender']

    for _ in range(100):
        gender = person.gender(symbol=True)
        assert gender in GENDER_SYMBOLS

    for _ in range(100):
        gender = person.gender(iso5218=True)
        assert gender in (0, 1, 2, 9)



# Generated at 2022-06-12 02:25:32.912306
# Unit test for method nationality of class Person
def test_Person_nationality():
    def test_Person_nationality_default():
        user_id = 1
        person = items.Person(user_id)
        nationality = person.nationality()
        
    test_Person_nationality_default()

# Generated at 2022-06-12 02:25:43.613130
# Unit test for method username of class Person
def test_Person_username():
    import easydata
    p = easydata.Person()
    assert re.match('[0-9]+', p.username())
    assert re.match('[0-9]+', p.username('U'))
    assert re.match('[a-z]+', p.username('l'))
    assert re.match('[a-z0-9]+', p.username('ld'))
    assert re.match('[a-z0-9]+', p.username('l_d'))
    assert re.match('[a-z0-9]+', p.username('l-d'))
    assert re.match('[a-z0-9]+', p.username('l.d'))
    assert re.match('[a-z]+[0-9]+', p.username('lU'))

# Generated at 2022-06-12 02:25:45.297583
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert all(Person.nationality() in Person._data["nationality"]
                for _ in range(20))

# Generated at 2022-06-12 02:25:47.783673
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(random=Random(32))
    assert p.nationality() == "Dutch"
    assert p.nationality(gender=Gender.FEMALE) == "Netherlands"


# Generated at 2022-06-12 02:26:11.497371
# Unit test for method nationality of class Person
def test_Person_nationality():
        person = Person()
        assert type(person.nationality()) == str

# Generated at 2022-06-12 02:26:12.798804
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in Person()._data['nationality']


# Generated at 2022-06-12 02:26:18.814973
# Unit test for method surname of class Person
def test_Person_surname():
    surname = Person().surname()
    assert name_format_validator.match(surname) is not None, \
        "The surname \"{}\" is incorrect".format(surname)

    surname_dict = Person().surname(gender=Gender.female)
    assert name_format_validator.match(surname_dict) is not None, \
        "The surname dict \"{}\" is incorrect".format(surname_dict)

    surname_list = Person().surname(gender=Gender.male)
    assert name_format_validator.match(surname_list) is not None, \
        "The surname list \"{}\" is incorrect".format(surname_list)

# Generated at 2022-06-12 02:26:20.292992
# Unit test for method nationality of class Person
def test_Person_nationality():
    _Person = Person()

    assert _Person.nationality() in _Person.data['nationality']


# Generated at 2022-06-12 02:26:28.870091
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()

    # If surnames is an empty list.
    provider._data['surname'] = {}
    assert provider.surname() == ''

    # If surnames is a dict.
    surnames = {
        'male': ['Doe'],
        'female': ['Doe']
    }
    provider._data['surname'] = surnames
    assert provider.surname() == 'Doe'

    # If surnames is a list.
    surnames = ['Doe']
    provider._data['surname'] = surnames
    assert provider.surname() == 'Doe'



# Generated at 2022-06-12 02:26:29.504226
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email()

# Generated at 2022-06-12 02:26:34.224965
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit-test for method nationality of class Person"""
    person = Person()
    assert person.nationality(gender='male') in ['American', 'Russian', 'German', 'Japanese']
    assert person.nationality(gender='female') in ['American', 'Russian', 'German', 'Japanese']
# Unit-test code for class Person
# Import package 'pytest' for unit-tests
import pytest

# Unit-test code

# Generated at 2022-06-12 02:26:36.733216
# Unit test for method email of class Person
def test_Person_email():
        provider = Person()
        result = provider.email()
        assert isinstance(result, str)
        assert len(result) == 13


# Generated at 2022-06-12 02:26:38.873062
# Unit test for method surname of class Person
def test_Person_surname():
    Person(seed=12345).surname('m')


# Generated at 2022-06-12 02:26:40.282842
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    # check the surname random generator
    assert p.surname()


# Generated at 2022-06-12 02:27:02.787776
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_provider = Provider()
    nationality = person_provider.nationality()
    print( nationality)


# Generated at 2022-06-12 02:27:06.011265
# Unit test for method email of class Person
def test_Person_email():
    email = Person.email()
    assert isinstance(email, str)
    return

test_Person_email()

# Generated at 2022-06-12 02:27:07.743295
# Unit test for method nationality of class Person
def test_Person_nationality():
    with pytest.raises(NonEnumerableError):
        provider = Person()
        provider.nationality(gender="Woman")

# Generated at 2022-06-12 02:27:16.099862
# Unit test for method nationality of class Person
def test_Person_nationality():
    human = Person()
    # assert that method nationality of class Person 
    # return item from nationalities
    assert human.nationality() in human._data['nationality']
    
    # assert that method nationality of class Person 
    # return item from nationalities of male gender
    assert human.nationality(gender = Gender.male) in human._data['nationality']['male']
    
    # assert that method nationality of class Person 
    # return item from nationalities of female gender
    assert human.nationality(gender = Gender.female) in human._data['nationality']['female']
test_Person_nationality()
Person().nationality(gender=Gender.female)


# Generated at 2022-06-12 02:27:17.600111
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    name = p.surname()

    assert name


# Generated at 2022-06-12 02:27:28.471626
# Unit test for method surname of class Person
def test_Person_surname():
    # Test default surname
    actual = Person(seed=0).surname()
    expected = 'Smith'
    
    assert actual == expected
    
    # Test surname gender M
    actual = Person(seed=0).surname(Gender.M)
    expected = 'Smith'
    
    assert actual == expected
    
    # Test surname gender F
    actual = Person(seed=0).surname(Gender.F)
    expected = 'Foster'
    
    assert actual == expected
    
    # Test surnames dictionary
    surnames = {
        Gender.M: ['John', 'Paul'],
        Gender.F: ['Katie', 'Megan'],
    }
    
    actual = Person(seed=0).surname(surnames)
    expected = 'Megan'
    
    assert actual

# Generated at 2022-06-12 02:27:34.972549
# Unit test for method email of class Person
def test_Person_email():
    # Create a new instance of Person
    person = Person()
    # Read the email
    email = person.email()
    # Get all data of Person
    data = person.__dict__
    # Get internal data of Person
    internal = data.get('_data')
    # Get data of email domains
    email_domains = internal.get('email_domains')
    # Check the email
    assert email.split('@')[-1] in email_domains, 'The email is wrong!'


# Generated at 2022-06-12 02:27:38.285541
# Unit test for method surname of class Person
def test_Person_surname():
  l = Person(seed=0)
  assert l.surname() == 'Пушкин'
  assert type(l.surname()) == str
  assert l.surname() != ''

# Generated at 2022-06-12 02:27:41.115531
# Unit test for method surname of class Person
def test_Person_surname():
    name = Person.surname(Gender.MALE)
    assert name == 'Иванов'
    name = Person.surname(Gender.FEMALE)
    assert name == 'Иванова'

# Generated at 2022-06-12 02:27:42.261012
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    result = person.surname()
    assert type(result) == str
    assert len(result) > 0

# Generated at 2022-06-12 02:28:08.033578
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    for i in range(100):
        assert isinstance(person.nationality(), str)


# Generated at 2022-06-12 02:28:10.117524
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    num = 100
    for i in range(num):
        assert(p.nationality() in NATIONALITY)
    return


# Generated at 2022-06-12 02:28:11.555788
# Unit test for method surname of class Person
def test_Person_surname():
    pr = Provider()
    assert isinstance(pr.surname(), str) == True



# Generated at 2022-06-12 02:28:19.798528
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test gender
    values = []
    for _ in range(1000):
        gender = get_random_item(Gender, rnd=RND)
        values.append(DEMO_DICT['nationality'][gender])
    gendered_values = set(itertools.chain(*values))
    assert gendered_values == set(NAT_FEMALE_NAMES + NAT_MALE_NAMES)

    # Test nationality
    values = []
    for _ in range(1000):
        nationality = Person.nationality(MALE, rnd=RND)
        values.append(nationality)
    assert set(values) == set(NAT_MALE_NAMES)

    # Test nationality
    values = []

# Generated at 2022-06-12 02:28:22.523953
# Unit test for method nationality of class Person
def test_Person_nationality():
    for __ in range(100):
        nationality = Person().nationality()
        assert nationality in NATIONALITIES



# Generated at 2022-06-12 02:28:24.891768
# Unit test for method surname of class Person
def test_Person_surname():
    surname = PERSON.surname()
    print(surname)
    assert isinstance(surname, str)

test_Person_surname()


# Generated at 2022-06-12 02:28:32.502351
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test with seeded provider
    provider = Provider(seed=5)
    assert provider.nationality() == 'Irish'
    provider.reset_seed()

    # Test with non-seeded provider
    # It could be different each time
    provider = Provider()
    assert provider.nationality() in (
        'Irish',
        'English',
        'Scottish',
        'Welsh',
    )

    # Test with specific gender
    provider = Provider(seed=1)
    assert provider.nationality(Gender.MALE) == 'Irish'
    provider.reset_seed()

# Generated at 2022-06-12 02:28:39.793007
# Unit test for method nationality of class Person
def test_Person_nationality():
    import pytest
    faker = Faker('ru_RU')
    Faker.seed(0)
    assert faker.nationality() == 'монгол'
    assert faker.nationality(Gender.MALE) == 'монгол'
    assert faker.nationality(Gender.FEMALE) == 'монгол'
    Faker.seed(1)
    assert faker.nationality() == 'монгол'
    Faker.seed(0)
    assert faker.nationality(Gender.MALE) == 'монгол'
    assert faker.nationality(Gender.FEMALE) == 'монгол'
    Faker.reset_seed()

# Generated at 2022-06-12 02:28:41.315009
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname() != ''


# Generated at 2022-06-12 02:28:51.402706
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:29:32.780402
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person"""
    # Get a random surname
    surname = generate_surname()
    assert isinstance(surname, str)

# Generated at 2022-06-12 02:29:38.701512
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test Russian
    provider = Faker(locale='ru_RU')
    for _ in range(100):
        n = provider.nationality()

# Generated at 2022-06-12 02:29:41.137288
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert_true(isinstance(p.surname(), str))
    assert_greater_equal(len(p.surname()), 2)
    

# Generated at 2022-06-12 02:29:42.325690
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-12 02:29:52.327979
# Unit test for method surname of class Person
def test_Person_surname():
    from faker.providers.person import Provider
    from faker.utils import text, random

    class Person(Provider):
        pass

    person = Person(random)
    assert person.surname() in text.surnames()
    assert person.surname(gender='male') in text.surnames_male()
    assert person.surname(gender='female') in text.surnames_female()

    assert person.last_name() in text.surnames()
    assert person.last_name(gender='male') in text.surnames_male()
    assert person.last_name(gender='female') in text.surnames_female()

# Generated at 2022-06-12 02:29:54.237076
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nation = person.nationality()
    assert isinstance(nation, str)
    assert len(nation) > 0

# Generated at 2022-06-12 02:30:04.715450
# Unit test for method nationality of class Person
def test_Person_nationality():
  from random import seed
  from pydbgen import pydbgen
  obj=pydbgen.pydb()
  seed(0)
  assert obj.nationality()=='American'
  seed(1)
  assert obj.nationality()=='Kenyan'
  seed(2)
  assert obj.nationality()=='Australian'
  seed(3)
  assert obj.nationality()=='Armenian'
  seed(4)
  assert obj.nationality()=='Russian'
  seed(5)
  assert obj.nationality()=='English'
  seed(6)
  assert obj.nationality()=='Pakistani'
  seed(7)
  assert obj.nationality()=='Nigerian'
  seed(8)

# Generated at 2022-06-12 02:30:07.050110
# Unit test for method email of class Person
def test_Person_email():
    person = Person('en')
    person.email()
    # assert person.email() == 'foretime10@live.com'


# Generated at 2022-06-12 02:30:09.210322
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    print(nationality)
    assert isinstance(nationality, str)

# Generated at 2022-06-12 02:30:11.140290
# Unit test for method surname of class Person
def test_Person_surname():
    t = Person()
    assert type(t.surname()) == str
    assert t.surname() in t._data['surnames']
