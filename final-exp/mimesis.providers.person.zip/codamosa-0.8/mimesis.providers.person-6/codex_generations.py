

# Generated at 2022-06-12 02:21:52.592332
# Unit test for method surname of class Person
def test_Person_surname():
    test_surnames = {Gender.MALE: ('Иванов', 'Петров', 'Сидоров')}
    prv = Person(surnames=test_surnames)
    surname = prv.surname()
    assert surname in test_surnames[Gender.MALE]


# Generated at 2022-06-12 02:21:56.218200
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person._data, dict)
    nationality = person.nationality()
    assert isinstance(nationality, str)
    assert len(nationality) > 0
    
test_Person_nationality()

# Generated at 2022-06-12 02:21:57.762487
# Unit test for method surname of class Person
def test_Person_surname():
  persons = Person()
  assert isinstance(persons.surname(), str)


# Generated at 2022-06-12 02:21:59.108703
# Unit test for method email of class Person
def test_Person_email():
    # Check email without domains
    assert len(Person().email()) > 0


# Generated at 2022-06-12 02:22:00.976838
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationalities = person.nationality()
    assert isinstance(nationalities, str)
 

# Generated at 2022-06-12 02:22:04.708723
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person(seed=777)

    assert p.gender(iso5218=True) == 2
    assert not isinstance(p.gender(symbol=True), Gender)
    assert p.gender() == 'Female'


# Generated at 2022-06-12 02:22:07.627518
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(random=Random(42))
    value = p.surname()
    assert value == "Козлов"

# Generated at 2022-06-12 02:22:09.987810
# Unit test for method surname of class Person
def test_Person_surname():
    assert re.fullmatch('[a-zA-Z-]+', Person().surname()) is not None


# Generated at 2022-06-12 02:22:17.315098
# Unit test for method email of class Person
def test_Person_email():
    assert Person.email(Person, 'test@test.com') == 'test@test.com'
    assert Person.email(Person, 'test.test@test.com') == 'test.test@test.com'
    assert Person.email(Person, 'test.test@test.com') != 'test.com'
    # with pytest.raises(ValueError):    
    #     assert Person.email(Person, unique = 'test.test@test.com')

# Generated at 2022-06-12 02:22:19.796856
# Unit test for method nationality of class Person
def test_Person_nationality():
    result = Person.nationality()
    assert result != None
    assert type(result) == str
    
test_Person_nationality()

# Generated at 2022-06-12 02:22:27.896570
# Unit test for method nationality of class Person
def test_Person_nationality():
    t = Person()
    r = t.nationality()
    assert r in NATIONALITIES



# Generated at 2022-06-12 02:22:29.221458
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    take_surname = person.surname()
    assert take_surname in SURNAMES

# Generated at 2022-06-12 02:22:34.381693
# Unit test for method gender of class Person
def test_Person_gender():

    person = Person()

    count = 10000
    gender_count = Counter()

    for _ in range(count):
        gender_count[person.gender()] += 1

    for title in gender_count:
        percents = round(gender_count[title] / count * 100)
        print('{} - {}%'.format(title, percents))

    assert all(value > 0 for value in gender_count.values())

# Generated at 2022-06-12 02:22:36.964678
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person('ru')
    nationality = person.nationality()
    # We can add some test here
    print(nationality)
# unit test for method full_name of class Person

# Generated at 2022-06-12 02:22:39.299773
# Unit test for method nationality of class Person
def test_Person_nationality():
    people = faker.Faker()
    nationality = people.nationality()
    assert nationality
    assert isinstance(nationality, str)

# Generated at 2022-06-12 02:22:42.864747
# Unit test for method surname of class Person
def test_Person_surname():
    # Verify that Person.surname() return not empty string.
    p = Person()
    assert p.surname() is not ''


# Generated at 2022-06-12 02:22:50.100699
# Unit test for method gender of class Person
def test_Person_gender():
    pr = Person(seed=0)
    assert pr.gender() == 'Male'

    # test for symbol of gender
    assert pr.gender(symbol=True) == '♂'

    # test for iso5218
    assert pr.gender(iso5218=True) == 1

    # test for error
    try:
        pr.gender(foo='bar')
    except TypeError as e:
        assert str(e) == 'gender() got an unexpected keyword argument \'foo\''

test_Person_gender()

# Generated at 2022-06-12 02:22:57.094150
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Provider('Person')
    for i in range(0, 10):
        nationality = provider.nationality()
        assert nationality in NATIONALITIES
    for i in range(0, 10):
        nationality = provider.nationality(gender=Gender.male)
        assert nationality in NATIONALITIES[0]
    for i in range(0, 10):
        nationality = provider.nationality(gender=Gender.female)
        assert nationality in NATIONALITIES[1]


# Generated at 2022-06-12 02:22:59.682046
# Unit test for method gender of class Person
def test_Person_gender():
  provider = Person()
  assert provider.gender() in [
    'Male', 'Female', 'Other', 'Prefer not to answer'
  ]


# Generated at 2022-06-12 02:23:11.200245
# Unit test for method email of class Person
def test_Person_email():
    """Test method email of class Person."""
    from provider import Provider
    pr = Provider()
    emails = [pr.email() for _ in range(100)]
    emails_set = list(set(emails))
    assert len(emails_set) == len(emails), \
        '<emails> and <emails_set> lists should have different lengths.'
    # Testing that all emails are unique
    assert pr.email(unique=True) != pr.email(unique=True), \
        'Unique emails should be different.'
    # Testing that all emails are the same
    assert emails[0] == pr.email(unique=True, seed=emails[0]), \
        '<email> and <seeded_email> should be the same.'

# Generated at 2022-06-12 02:23:28.986195
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert not p.surname('u').islower()

# Unit tests for method full name of class Person

# Generated at 2022-06-12 02:23:34.232408
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Test of method surname of class Person
    """

    global PROVIDER
    say('Checking method "surname" of class "Person" ... ', end='')
    try:
        obj = PROVIDER["Person"]
        res = obj.surname()
        assert isinstance(res, str)
        result = True
    except Exception as e:
        result = False
    finally:
        answer(result)
        return result

# Generated at 2022-06-12 02:23:37.328021
# Unit test for method surname of class Person
def test_Person_surname():
  from random import randint
  from generator.person import Person as PersonGen
  from models.person import Person as PersonModel
  person = PersonModel(PersonGen().surname())
  assert person.surname == person.surname


# Generated at 2022-06-12 02:23:40.746816
# Unit test for method surname of class Person
def test_Person_surname():
    result = Person.surname()
    assert isinstance(result, str)
    assert result in PERSON_NAMES


# Generated at 2022-06-12 02:23:50.000452
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username(template='Ul-d')
    assert Person().username(template='Ul.d')
    assert Person().username(template='Ul_d')
    assert Person().username(template='UUU-d')
    assert Person().username(template='UUU.d')
    assert Person().username(template='UUU_d')
    assert Person().username(template='ld')
    assert Person().username(template='l-d')
    assert Person().username(template='l.d')
    assert Person().username(template='l_d')
    assert Person().username(template='Ud')
    assert Person().username()

# Generated at 2022-06-12 02:23:54.581848
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in NATIONALITIES
    assert person.nationality(gender=Gender.MALE) \
        in NATIONALITIES_MALE
    assert person.nationality(gender=Gender.FEMALE) \
        in NATIONALITIES_FEMALE

# Generated at 2022-06-12 02:24:04.045621
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for Person.surname"""
    from faker import Faker, Generator
    from pprint import pprint
    from typing import List, Dict

    fake = Faker(locale='en')

    # initialize Faker instance
    fake = Faker()
    # get person's 'provider'
    person: Generator = fake.provider(category='Person')
    # get person's 'surname'

    for i in range(1000):
        surname: str = fake.provider(category='Person').surname()
        # pprint([surname])

        assert isinstance(surname, str)

        assert surname in fake.provider(category='Person')._data['surname']

        # assert surname in fake.provider(category='Person').surname()


# Generated at 2022-06-12 02:24:08.363512
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Arrange
    p = Provider(Person.DEFAULT_LOCALE)
    
    # Act
    nationality = p.nationality()
    
    # Assert
    assert nationality in PERSON_DEFAULT_NATIONALITY


# Generated at 2022-06-12 02:24:17.726727
# Unit test for method surname of class Person
def test_Person_surname():


 
    assert Person(Random()).surname(Gender.Male, 'ru') == 'Иванов'
    assert Person(Random()).surname(Gender.Female, 'ru') == 'Соловьева'

    assert Person(Random(0)).surname(Gender.Male, 'ru') == 'Иванов'
    assert Person(Random(0)).surname(Gender.Female, 'ru') == 'Соловьева'

    assert Person(Random(1)).surname(Gender.Male, 'ru') == 'Антонов'
    assert Person(Random(1)).surname(Gender.Female, 'ru') == 'Антонова'

    assert Person(Random(2)).s

# Generated at 2022-06-12 02:24:19.711993
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pydiet import Provider

# Generated at 2022-06-12 02:24:35.892730
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    templates = ('U_d', 'U.d', 'U-d', 'UU-d', 'UU.d', 'UU_d',
                     'ld', 'l-d', 'Ud', 'l.d', 'l_d', 'default')
    for template in templates:
        username = person.username(template=template)
        print(username)
        assert re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', username)
    print('\n')

# Generated at 2022-06-12 02:24:42.145678
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    p.seeder(0)
    ret = p.email()
    assert ret != 'foretime10@live.com'
    p.seeder(1)
    ret = p.email()
    assert ret != 'foretime10@live.com'
    p.seeder(2)
    ret = p.email()
    assert ret == 'foretime10@live.com'

# Generated at 2022-06-12 02:24:44.016457
# Unit test for method surname of class Person
def test_Person_surname():
    desired_gender = Gender.female
    assert isinstance(Person().surname(desired_gender), str)



# Generated at 2022-06-12 02:24:54.098955
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    
    # Test correct work of method with default parameters
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in SURNAMES
    
    # Test correct work of method with identificator of gender
    surname = person.surname(gender = Gender.MALE)
    assert isinstance(surname, str)
    assert surname in SURNAMES_MALE
    
    surname = person.surname(gender = Gender.FEMALE)
    assert isinstance(surname, str)
    assert surname in SURNAMES_FEMALE

    # Test correct work of method with gender
    surname = person.surname(gender = Gender.MALE)
    assert isinstance(surname, str)
    assert surname in SURNAMES_MALE


# Generated at 2022-06-12 02:25:00.985854
# Unit test for method surname of class Person
def test_Person_surname():
    from vedis import Vedis
    from random import seed
    from pydantic import BaseModel

    # Arrange
    seed(1)
    db = Vedis(':memory:')
    person = Person(db)

    # Act
    result = person.surname()

    # Assert
    assert result == 'Каримов'

# Generated at 2022-06-12 02:25:01.616879
# Unit test for method nationality of class Person
def test_Person_nationality():
    pass

# Generated at 2022-06-12 02:25:11.885661
# Unit test for method email of class Person
def test_Person_email():
    # 1st test: default params, not unique, random domain
    p1 = Person()
    for _ in range(10):
        email = p1.email()
        assert re.match(r'[A-Za-z0-9._]{5,7}\@[A-Za-z0-9._]{2,12}', email)
    # 2nd test: custom domain
    custom_domain = 'example.com'
    for _ in range(10):
        email = p1.email(domains=(custom_domain))
        assert re.match(r'[A-Za-z0-9._]{5,7}\@{}'.format(custom_domain), email)
    # 3nd test: two custom domains
    custom_domain = 'example.com'

# Generated at 2022-06-12 02:25:13.904345
# Unit test for method nationality of class Person
def test_Person_nationality():
    name = Person(seed=__seed).nationality()
    print(name)

# Generated at 2022-06-12 02:25:14.993230
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in NATIONALITIES

# Generated at 2022-06-12 02:25:16.591478
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    ret = person.nationality()
    assert isinstance(ret, str)

# Generated at 2022-06-12 02:25:40.295577
# Unit test for method surname of class Person
def test_Person_surname():
    actual_1 = Person().surname(1)
    actual_2 = Person().surname(0)

    expected_1 = 'Абрамов'
    expected_2 = 'Абрамова'

    assert actual_1 == expected_1
    assert actual_2 == expected_2

# Generated at 2022-06-12 02:25:42.515030
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)


# Generated at 2022-06-12 02:25:43.979017
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person('ru')
    person.nationality()

# Generated at 2022-06-12 02:25:45.299415
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    assert provider.surname()


# Generated at 2022-06-12 02:25:50.182056
# Unit test for method surname of class Person
def test_Person_surname():
    try:
        # prepare data
        name = 'Ilya'
        surname = 'Kantor'
        title = 'president'
        gender = 'male'
        # Run the code
        random.seed(0)
        company = Person(surnames={gender:surname})
        # Check results
        assert company.surname() == surname
    except Exception as e:
        print('Exception in test_Person_surname(): {}'.format(e))



# Generated at 2022-06-12 02:26:00.533832
# Unit test for method username of class Person
def test_Person_username():
    assert len(Person().username()) == 8
    assert Person().username(template='UUUU') == 'Mull'
    assert Person().username(template='U_d') == 'Smith_2010'
    assert Person().username(template='U-d') == 'Barbara-2050'
    assert Person().username(template='UU-d') == 'Test-2080'
    assert Person().username(template='l.d') == 'j.2010'
    assert Person().username(template='l-d') == 'g-2010'
    assert Person().username(template='ld') == 'e2010'
    assert Person().username() != Person().username()
    # Test exception
    with pytest.raises(ValueError):
        Person().username(template='')
        Person().username(template=None)
        

# Generated at 2022-06-12 02:26:08.428529
# Unit test for method nationality of class Person
def test_Person_nationality():
    def test():
        # Test with default value
        assert Person().nationality() in NATIONALITY

        # Test with gender
        assert Person().nationality(Gender.FEMALE) in NATIONALITY

        # Test with non-enumerable value
        try:
            Person().nationality(Gender.UNKNOWN)
        except Exception as e:
            assert str(e) == 'Unknown enum value: Gender.UNKNOWN'

        print('Person_nationality - ok!')

    test()

if __name__ == '__main__':
    test_Person_nationality()

# Generated at 2022-06-12 02:26:14.931574
# Unit test for method surname of class Person
def test_Person_surname():
    P = Person(provider=TestDataProvider(), rnd=Random(), lang='en')
    assert P.surname(gender=Gender.MALE) == 'Wilson'
    assert P.surname(gender=Gender.FEMALE) == 'Ortiz'
    assert P.surname(gender=Gender.UNKNOWN) == 'Gutierrez'
    assert P.surname(gender='male') == 'Wilson'
    assert P.surname(gender='female') == 'Ortiz'
    assert P.surname(gender='unknown') == 'Gutierrez'


# Generated at 2022-06-12 02:26:17.283397
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    for _ in range(10):
        nationality = provider.nationality()
        assert nationality, str
        assert len(nationality) > 0


# Generated at 2022-06-12 02:26:21.735482
# Unit test for method surname of class Person
def test_Person_surname():
    random = random_value()
    test = random.surname()
    assert test in ['Петрович', 'Иванов', 'Иванович', 'Сидорович', 'Петров']



# Generated at 2022-06-12 02:26:49.605453
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality(Person) != None