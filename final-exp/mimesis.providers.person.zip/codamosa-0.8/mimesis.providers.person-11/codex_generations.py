

# Generated at 2022-06-12 02:21:59.890933
# Unit test for method gender of class Person
def test_Person_gender():
    import random
    from seed.helper.try_except import try_except
    from seed.helper.for_loop import for_loop
    from pprint import pprint
    from collections.abc import Iterable, Iterator
    from itertools import islice

    i_char = '_'
    n = 1000
    p1 = Person()
    islice_n_chars = lambda a, n: iter(lambda : a.__next__(), i_char*n)
    def print_n(it_or_seq, n=n, i_char=i_char):
        if isinstance(it_or_seq, Iterator):
            pprint(list(islice_n_chars(it, n)))

# Generated at 2022-06-12 02:22:03.946137
# Unit test for method surname of class Person
def test_Person_surname():
    sample_data = [
        ('Nygaard', Gender.MALE),
        ('Værum', Gender.FEMALE)
    ]
    for i in range(10):
        person = Person()
        surname, gender = person.surname(), person.sex()
        assert surname in sample_data
        assert gender in sample_data and gender == Gender.MALE or gender == Gender.FEMALE
test_Person_surname()

# Generated at 2022-06-12 02:22:13.027315
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality(Gender.MALE)
    assert Person.nationality(Gender.FEMALE)
    assert Person.nationality(Gender.MALE)
    assert Person.nationality(Gender.FEMALE)
    assert Person.nationality(Gender.MALE)
    assert Person.nationality(Gender.FEMALE)
    assert Person.nationality(Gender.MALE)
    assert Person.nationality(Gender.FEMALE)
    assert Person.nationality(Gender.MALE)
    assert Person.nationality(Gender.FEMALE)


# Generated at 2022-06-12 02:22:16.852993
# Unit test for method gender of class Person
def test_Person_gender():
    gender = Person().gender()
    assert gender in Person()._data['gender']
    assert gender == Person().sex()
    assert gender in Person().gender(iso5218=True)
    assert gender in GENDER_SYMBOLS

# Generated at 2022-06-12 02:22:25.069496
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person."""
    print("Text generation:\n=================\n")
    person = Person()
    print("\n>>> person.surname()")
    surname = person.surname()
    print("\t\t{0}".format(surname))
    # tests
    assert isinstance(surname, str)
    assert len(surname) >= MIN_SURNAME_LENGTH
    assert len(surname) <= MAX_SURNAME_LENGTH


# Generated at 2022-06-12 02:22:35.224787
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert surname in person._data['surname']
if __name__ == '__main__':
    test_Person_surname()
from pyfaker.company import Company
from pyfaker.product import Product
from pyfaker.software import Software
from pyfaker.time import Time

from pyfaker.consts import (
    BIZ_TYPES,
    BRANDS,
    COMPANY_PREFIX_TYPES,
    COMPANY_SUFFIX_TYPES,
    CURRENCIES,
    LANGUAGES,
    OS,
)
from pyfaker.providers.base import BaseProvider

# Generated at 2022-06-12 02:22:42.188749
# Unit test for method nationality of class Person
def test_Person_nationality():
    class PersonMock(Person):
        def __init__(self, *args, **kwargs):
            super(PersonMock, self).__init__(*args, **kwargs)
            self._data['nationality'] = ('russian', 'american')

    p = PersonMock()
    s = 'russian,american'

    assert p.nationality() in s



# Generated at 2022-06-12 02:22:47.815798
# Unit test for method email of class Person
def test_Person_email():
    import re

    # Method must return a string
    assert isinstance(Person().email(), str)

    # Method must return a string with length in range 5 to 100
    length = len(Person().email())
    assert 5 <= length <= 100

    # Method must return a string with a good email
    assert re.fullmatch(r'.*?@.*?\..*?', Person().email()) is not None

# Generated at 2022-06-12 02:22:49.872415
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality() != ""
    

# Generated at 2022-06-12 02:22:52.151071
# Unit test for method email of class Person
def test_Person_email():
    r = Person(seed=100)
    result = r.email()
    assert result == "tabitha11@google.com"


# Generated at 2022-06-12 02:23:15.915814
# Unit test for method surname of class Person
def test_Person_surname():
    rnd = Random()
    # Test for Russian surnames
    for name in rnd.surname(Gender.Male):
        assert name in DATA["surname"]["male"]
    for name in rnd.surname(Gender.Female):
        assert name in DATA["surname"]["female"]
    # Test for English surnames
    for name in rnd.surname(Gender.Male, language='en'):
        assert name in DATA["en"]["surname"]["male"]
    for name in rnd.surname(Gender.Female, language='en'):
        assert name in DATA["en"]["surname"]["female"]

# Generated at 2022-06-12 02:23:21.275132
# Unit test for method nationality of class Person
def test_Person_nationality():
  data = {}
  with open('./tests/fixtures/nationalities.json') as f:
    data = json.load(f)

  for key in data:
    # Get some set of nationalities by gender
    nationalities = data[key]

    # Get single nationalities from set of nationalities
    nationality = Person().nationality(Gender(key))

    assert nationality in nationalities


# Generated at 2022-06-12 02:23:24.556708
# Unit test for method surname of class Person
def test_Person_surname():
    from instafaker.person import Person
    person = Person()
    for _ in range(10):
        surname = person.surname()
        assert surname in SURNAME_LIST


# Generated at 2022-06-12 02:23:27.425383
# Unit test for method surname of class Person
def test_Person_surname():
    provider = BaseProvider(random=Random())
    assert len(provider.surname()) > 0


# Generated at 2022-06-12 02:23:31.396979
# Unit test for method surname of class Person
def test_Person_surname():
    # Assert that you are able to call the method surname of class Person
    # without any error
    try:
        Person.surname()
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-12 02:23:35.801672
# Unit test for method surname of class Person
def test_Person_surname():
    data = [
        ('male', 'Путина'),
        ('female', 'Путина'),
        ('unknown', 'Путина'),
    ]

    for gender, surname in data:
        assert Person.surname(gender=gender) == surname


# Generated at 2022-06-12 02:23:41.390250
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=1)
    a = p.nationality()
    b = p.nationality()
    c = p.nationality()
    d = p.nationality()
    e = p.nationality()
    assert a == 'Russian'
    assert b == 'Russian'
    assert c == 'Russian'
    assert d == 'Russian'
    assert e == 'Russian'

# Generated at 2022-06-12 02:23:52.666861
# Unit test for method nationality of class Person
def test_Person_nationality():
    locale = Locale.parse('en')
    provider = Person(locale=locale)

    def nationality(gender, full_name):
        nationality = provider.nationality(gender)
        full_nationality = provider.nationality(gender)
        assert isinstance(nationality, str)
        assert len(nationality) > 0
        assert full_nationality == nationality + ' woman'
        assert nationality in full_name

    # Nationality for women
    gender = Gender.female
    full_name = provider.full_name(gender)
    nationality(gender, full_name)

    # Nationality for men
    gender = Gender.male
    full_name = provider.full_name(gender)
    nationality(gender, full_name)

    # Nationality for not applicable
    gender = Gender.not_applicable
    full_

# Generated at 2022-06-12 02:23:57.503808
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    nationality = p.nationality()
    assert nationality in p._data['nationality'], "Randome nationality not in _data['nationality']"
    assert nationality in list(p._data['nationality'].keys()), "Randome nationality not in _data['nationality'].keys()"


# Generated at 2022-06-12 02:24:03.159867
# Unit test for method surname of class Person
def test_Person_surname():
    from faker.generator import random
    from faker.utils.enums import Gender, TitleType

    person = Person(random)
    
    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(Gender.MALE), str)
    assert isinstance(person.surname(Gender.FEMALE), str)
    assert isinstance(person.surname(Gender.ANDROGYNOUS), str)
    
    

# Generated at 2022-06-12 02:24:16.544666
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(seed=12345)
    result = p.surname()
    assert result == 'Власов'

# Generated at 2022-06-12 02:24:20.199242
# Unit test for method email of class Person
def test_Person_email():
    person = Person(random=Random())
    assert person.email(['aol.com']) == 'josetompkins@aol.com'

# Generated at 2022-06-12 02:24:28.298163
# Unit test for method nationality of class Person
def test_Person_nationality():
    # nationalities = person.nationality()
    # assert isinstance(nationalities,str)

    # nationalities = person.nationality(Gender.MALE)
    # assert isinstance(nationalities,str)
    person = Person()

    nationalities = person.nationality()
    assert isinstance(nationalities,str)

    # nationalities = person.nationality(Gender.MALE)
    # assert isinstance(nationalities,str)
    nationalities = person.nationality()
    assert isinstance(nationalities,str)
    print("Test is done.")


# Generated at 2022-06-12 02:24:31.432738
# Unit test for method email of class Person
def test_Person_email():
    item = Person()

    val = item.email(unique=True)
    assert isinstance(val, str)

    val = item.email(unique=False)
    assert isinstance(val, str)



# Generated at 2022-06-12 02:24:33.908577
# Unit test for method surname of class Person
def test_Person_surname():
    assert isinstance(Person().surname(), str)
    assert Person().surname() != Person().surname()

# Generated at 2022-06-12 02:24:35.892308
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        assert Person().nationality() != ''


# Generated at 2022-06-12 02:24:47.996818
# Unit test for method surname of class Person
def test_Person_surname():
    from pydantic import BaseModel, root_validator
    from typing import List, Tuple, Dict

    class Person(BaseModel):
        gender: str
        surnames: Dict

        @root_validator
        def surname_is_required(cls, values: Dict) -> Dict:
            # Gender can be any.
            # surnames must be dict and contains at least one key.
            if not isinstance(values['surnames'], dict) \
                    or not values['surnames']:
                raise ValueError('surnames must be dict and '
                                 'contains at least one key')

            # If surnames is dict, then gender is required
            # and it must be one of the values of the enum Gender.

# Generated at 2022-06-12 02:24:49.396106
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-12 02:24:51.341432
# Unit test for method surname of class Person
def test_Person_surname():
    provider = PersonProvider()
    surname = provider.surname()
    assert surname

# Generated at 2022-06-12 02:24:53.224883
# Unit test for method nationality of class Person
def test_Person_nationality():

    for i in range (10000):
        national = Person().nationality()
        assert national in NATIONALITY

