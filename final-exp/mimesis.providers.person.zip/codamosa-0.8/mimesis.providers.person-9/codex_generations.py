

# Generated at 2022-06-12 02:21:45.988672
# Unit test for method surname of class Person
def test_Person_surname():
    a_person = Person()
    res = a_person.surname()
    assert isinstance(res, str)

# Generated at 2022-06-12 02:21:57.402569
# Unit test for method surname of class Person
def test_Person_surname():
    from faker.providers.person.at import Provider
    from faker.providers.person.da import Provider as EnProvider
    from faker.providers.person.sr_Cyrl_RS import Provider as Rs_Cyrl_Provider
    from faker.providers.person.sr_Latn_RS import Provider as Rs_Latn_Provider
    from faker.providers.person.sn import Provider as SnProvider

    p = Person(locales=['en_US', 'de_AT', 'sr_RS@latin', 'sr_RS'])

    # Make sure the placeholder works
    p.surname(gender='')
    p.surname(gender=None)
    p.surname(gender=False)
    p.surname(gender=True)

# Generated at 2022-06-12 02:21:59.065500
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-12 02:22:00.942849
# Unit test for method gender of class Person
def test_Person_gender():
    for _ in range(10):
        genders = Person(seed=SEED).gender()
        assert genders.isalnum()

# Generated at 2022-06-12 02:22:03.312467
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=42)

    for i in range(20):
        print(p.nationality())


# Generated at 2022-06-12 02:22:11.963508
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person(random=Random())

    assert issubclass(type(person.gender()), str)
    assert issubclass(type(person.gender(symbol=True)), str)
    assert person.gender(iso5218=True) in [0, 1, 2, 9]

    assert person.sex() == person.gender()
    assert person.sex(symbol=True) == person.gender(symbol=True)
    assert person.sex(iso5218=True) == person.gender(iso5218=True)


# Generated at 2022-06-12 02:22:17.467187
# Unit test for method surname of class Person
def test_Person_surname():
    random.seed(0) # seed random
    male = Person().surname(Gender.male)
    assert isinstance(male, str)
    assert male == 'Смирнов'
    female = Person().surname(Gender.female)
    assert isinstance(female, str)
    assert female == 'Новикова'

# Generated at 2022-06-12 02:22:19.455222
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-12 02:22:22.591301
# Unit test for method surname of class Person
def test_Person_surname():
    print("Unit test case for surname")
    person = Person()
    print(person.surname())
test_Person_surname()


# Generated at 2022-06-12 02:22:31.191961
# Unit test for method nationality of class Person
def test_Person_nationality():
    seed(123)
    person = Person(seed=123)
    nationalities = ['russian', 'usa', 'english', 'british', 'netherland',
     'french', 'german', 'polish', 'spanish', 'italian', 'chinese', 'japanese',
     'indian', 'ukrainian', 'swiss', 'austrian']
    test_result = [person.nationality() for i in range(1000)]
    for i in test_result:
        assert i in nationalities

test_Person_nationality()

# Generated at 2022-06-12 02:22:37.494548
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality in person._data['nationality']


# Generated at 2022-06-12 02:22:41.658994
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = ParametrizedProvider(random=Generator(random=Random()))
    x = provider.nationality()

    assert x in provider._data['nationality']


# Generated at 2022-06-12 02:22:43.848466
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=1)
    person2 = Person(seed=2)

    # Check return type
    assert isinstance(person.nationality(), str)

    # Check return value
    assert person.nationality() == 'Russian'
    assert person2.nationality() == 'Afghanistani'



# Generated at 2022-06-12 02:22:53.345399
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person('en')
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']

    person = Person('ru')
    surname_male = person.surname(Gender.male)
    assert isinstance(surname_male, str)
    assert surname_male in person._data['surname'][Gender.male]

    surname_female = person.surname(Gender.female)
    assert isinstance(surname_female, str)
    assert surname_female in person._data['surname'][Gender.female]

    surname_other = person.surname(Gender.other)
    assert isinstance(surname_other, str)

# Generated at 2022-06-12 02:23:01.861325
# Unit test for method nationality of class Person
def test_Person_nationality():
    Case = namedtuple('Case', 'seed gender expected')
    cases = {
        #  -212094713:
        -212094713: Case(
            seed=-212094713,
            gender=None,
            expected='Sri Lankan'
        ),
        #  2134635650:
        2134635650: Case(
            seed=2134635650,
            gender=Gender.MALE,
            expected='Mongolian'
        ),
        #  1511661813:
        1511661813: Case(
            seed=1511661813,
            gender=Gender.FEMALE,
            expected='Samoan'
        )
    }
    for seed, case in cases.items():
        person = Person(seed=seed)
        assert case.expected == person.nationality

# Generated at 2022-06-12 02:23:05.747524
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit tests for method nationality of class Person."""
    provider = Person()
    assert provider.nationality() in NATIONALITIES,\
        'Nationality of Person class should be in NATIONALITIES'



# Generated at 2022-06-12 02:23:08.703784
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(10):
        provider = Person()
        surname = provider.surname()
        assert surname in SURNAMES

# Generated at 2022-06-12 02:23:13.015284
# Unit test for method nationality of class Person
def test_Person_nationality():
    from dataprovider import Person

    person = Person()
    actual = person.nationality(gender=Gender.FEMALE)
    expected = "Russian"
    assert actual == expected, \
        f"Should be {expected}, but was {actual}"

# Generated at 2022-06-12 02:23:16.452162
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = faker.Faker(providers=['uk_UA'], locale = 'uk_UA') #initialize the object
    result = person.nationality()
    assert result != None
    assert result != ''
    assert type(result) == str 

# Generated at 2022-06-12 02:23:18.581346
# Unit test for method email of class Person
def test_Person_email():
    provider = Person(random=faker.Faker())

    assert provider.email().find('@') == 2



# Generated at 2022-06-12 02:23:24.453252
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    email = person.email()
    assert isinstance(email, str)

# Generated at 2022-06-12 02:23:29.625979
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker_architeture.faker.providers.person.base_person import BasePerson
    person = BasePerson('en')
    for _ in range(10):
        nationality = person.nationality()
        assert isinstance(nationality, str)

# Generated at 2022-06-12 02:23:32.098461
# Unit test for method surname of class Person
def test_Person_surname():
    # Init
    p = Person()
    # Check data
    assert p.surname() in SURNAME


# Generated at 2022-06-12 02:23:40.425520
# Unit test for method surname of class Person

# Generated at 2022-06-12 02:23:45.118055
# Unit test for method surname of class Person
def test_Person_surname():
    g = Person()
    assert type(g.surname()) == str
    assert len(g.surname()) >= NAMES_MIN_LENGTH
    assert len(g.surname()) <= NAMES_MAX_LENGTH
    

# Generated at 2022-06-12 02:23:48.847192
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname('male') == 'Иванов'
    assert Person.surname('female') == 'Светлана'
    assert Person.surname(gender='male') == 'Иванов'
    assert Person.surname(gender='female') == 'Светлана'
    assert Person.surname(gender=Gender.male) == 'Иванов'
    assert Person.surname(gender=Gender.female) == 'Светлана'


# Generated at 2022-06-12 02:23:54.061432
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert(p.surname() in p._data['surname'])
    assert(p.surname(gender=Gender.MALE) in p._data['surname']["male"])
    assert(p.surname(gender=Gender.FEMALE) in p._data['surname']["female"])
    

# Generated at 2022-06-12 02:23:55.467822
# Unit test for method email of class Person
def test_Person_email():
    provider = Provider()
    assert '@' in provider.email()

# Generated at 2022-06-12 02:23:57.374126
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person._data['surname']


# Generated at 2022-06-12 02:23:58.709035
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() != Person().nationality()

# Generated at 2022-06-12 02:24:07.694332
# Unit test for method surname of class Person
def test_Person_surname():
    Faker.seed(0)

    p = Faker()

    assert p.surname() == "Kulas"
    assert p.surname(gender='male') == "Kulas"
    assert p.surname(gender='female') == "Green"


# Generated at 2022-06-12 02:24:09.900062
# Unit test for method nationality of class Person
def test_Person_nationality():
    random.seed(1)
    p = Person()
    assert p.nationality() == 'Russian'

# Generated at 2022-06-12 02:24:16.332710
# Unit test for method surname of class Person
def test_Person_surname():
    
    def test_surname_1():
        p = Person()
        assert len(p.surname()) >= 2
        assert isinstance(p.surname(), str)

    def test_surname_2():
        p = Person()
        assert isinstance(p.surname(gender="male"), str)

    def test_surname_3():
        p = Person()
        assert isinstance(p.surname(gender=Gender.female), str)

# Generated at 2022-06-12 02:24:21.714496
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality(gender='MALE') in {'Russian', 'Kazakh', 'Belarusian', 'Ukrainian', 'Tatar'}
    assert Person.nationality(gender='FEMALE') in {'Mixed', 'Korean', 'Japanese', 'Chinese', 'Mongolian'}


# Generated at 2022-06-12 02:24:24.998812
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=123)
    assert person.nationality() == 'Irish'
    assert person.nationality(Gender.MALE) == 'Russian'
    assert person.nationality(Gender.FEMALE) == 'Irish'


# Generated at 2022-06-12 02:24:27.443698
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname() == 'Григоров'

# Generated at 2022-06-12 02:24:32.185476
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    from faker.providers.person.en_US import Provider

    faker = Faker()
    faker.add_provider(Provider)

    for _ in range(100):
        assert isinstance(faker.nationality(), str)


# Generated at 2022-06-12 02:24:33.287060
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() != ''

# Generated at 2022-06-12 02:24:42.250430
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = {
        Gender.MALE: ('American', 'Russian', 'Mexican'),
        Gender.FEMALE: ('American', 'Russian', 'Mexican'),
    }

    person = Person(nationalities=nationalities)

    # Method nationality() should return a random nationality.
    assert person.nationality() in nationalities.values()

    # Method nationality() should return a random nationality by gender.
    assert person.nationality(gender=Gender.MALE) in nationalities[Gender.MALE]
    assert person.nationality(gender=Gender.FEMALE) in nationalities[Gender.FEMALE]


# Generated at 2022-06-12 02:24:46.216101
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(random=Random())
    assert len(p.nationality()) > 0
    assert len(p.nationality(gender=Gender.MALE)) > 0
    assert len(p.nationality(gender=Gender.FEMALE)) > 0

# Generated at 2022-06-12 02:24:57.010778
# Unit test for method nationality of class Person
def test_Person_nationality():
    import numpy as np
    for i in range(100):
        result = Person.nationality()
        assert isinstance(result, str)


# Generated at 2022-06-12 02:25:07.498168
# Unit test for method surname of class Person
def test_Person_surname():
    surname = Person(lang='en').surname(gender=Gender.FEMALE)
    assert surname in SURNAME_FEMALE

    surname = Person(lang='en').surname(gender=Gender.MALE)
    assert surname in SURNAME_MALE

    surname = Person(lang='ru').surname(gender=Gender.FEMALE)
    assert surname in SURNAME_FEMALE_RU

    surname = Person(lang='ru').surname(gender=Gender.MALE)
    assert surname in SURNAME_MALE_RU

    surname = Person(lang='en').last_name(gender=Gender.FEMALE)
    assert surname in SURNAME_FEMALE

    surname = Person(lang='en').last_name(gender=Gender.MALE)
    assert surname in SURNAME_MALE

   

# Generated at 2022-06-12 02:25:13.905061
# Unit test for method email of class Person
def test_Person_email():
    # Create an object of class Person
    p = Person()

    # Use method email of class Person
    result = p.email()

    # Check is result string
    assert isinstance(result, str)

    # Check is email valid
    assert re.match(r'^[\w\d]+@([\w\d\-]+\.)+[\w\d]+$', result)


# Generated at 2022-06-12 02:25:15.559156
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert type(surname) == str



# Generated at 2022-06-12 02:25:18.911498
# Unit test for method nationality of class Person
def test_Person_nationality():
    tempPerson = Person()
    for i in range(100):
        nationality = tempPerson.nationality()
        assert type(nationality) == str, f"{i} test failed"
        assert nationality in NATIONALITIES, f"{i} test failed"


# Generated at 2022-06-12 02:25:29.255501
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person
    """

# Generated at 2022-06-12 02:25:34.862340
# Unit test for method surname of class Person
def test_Person_surname():
    random_Person = Person(seed=42)
    name1 = random_Person.surname()
    name2 = random_Person.surname()
    name3 = random_Person.surname()
    # Check for equality of two different names
    assert name1 != name2 != name3
    # Check for equal seed
    assert name1 == 'González'
    assert name2 == 'Sánchez'
    assert name3 == 'García'

# Generated at 2022-06-12 02:25:38.512764
# Unit test for method nationality of class Person
def test_Person_nationality():
    provider = Person()
    assert type(provider.nationality(gender=Gender.MALE)) == str
    assert type(provider.nationality(gender=Gender.FEMALE)) == str

test_Person_nationality()

# Generated at 2022-06-12 02:25:42.273867
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality(Gender.MALE) in ('Russian', 'American', 'German', 'Japanese')
    assert Person().nationality(Gender.FEMALE) in ('Russian', 'American', 'German', 'Japanese')

# Generated at 2022-06-12 02:25:45.867816
# Unit test for method nationality of class Person
def test_Person_nationality():
    obj = Person()
    rv = obj.nationality(Gender.Male)

    assert isinstance(rv, str) or isinstance(rv, unicode)
Person.nationality = types.MethodType(test_Person_nationality, None, Person)


# Generated at 2022-06-12 02:26:00.641108
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    from faker.providers.person.fi_FI import Provider as FiProvider
    from faker.providers.person.no_NO import Provider as NoProvider
    
    fake = Faker()
    
    en_US_provider = fake.provider('faker.providers.person')
    fi_FI_provider = FiProvider(fake)
    no_NO_provider = NoProvider(fake)

    def test_surname_single_gender(provider):
        surnames = provider._data['surname']
        assert provider.surname() in surnames
        gender = provider.random.choice([0, 1])
        if isinstance(surnames, dict):
            assert provider.surname(gender=gender) in surnames[gender]

# Generated at 2022-06-12 02:26:11.241159
# Unit test for method nationality of class Person
def test_Person_nationality():
    values = ['German', 'Italian', 'Spanish']
    p = Person(seed=12345)
    assert p.nationality() in values
    assert p.nationality(Gender.male) in values
    assert p.nationality(Gender.female) not in values
"""
Created on Sat Jul  6 17:59:35 2019

@author: Andrea Bassi
"""

import random
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import rcParams

from names import get_full_name
from names import Person


# Generated at 2022-06-12 02:26:13.175022
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()

    assert result in person.NATIONALITY, "Method returns incorrect result"



# Generated at 2022-06-12 02:26:14.667272
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)

# Generated at 2022-06-12 02:26:17.033938
# Unit test for method surname of class Person
def test_Person_surname():
    surname = Person().surname()
    assert isinstance(surname, str)
    assert surname
    
test_Person_surname()

# Generated at 2022-06-12 02:26:18.815119
# Unit test for method surname of class Person
def test_Person_surname():
    assert Provider().surname() != ""

# Generated at 2022-06-12 02:26:28.870035
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pydbgen.random_generator import random_gen
    from pydbgen import pydbgen
    myDB=pydbgen.pydb()
    flag = 1
    all_nationality = myDB.nationality()
    all_female_nationality = myDB.nationality(gender="Female")
    all_male_nationality = myDB.nationality(gender="Male")
    res = "Pass"

# Generated at 2022-06-12 02:26:36.735585
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    # Surname without parameters
    surname = p.surname()
    assert isinstance(surname, (str, bytes))
    print(surname)
    
    # Surname with parameters
    surname = p.surname(Gender.MALE)
    assert isinstance(surname, (str, bytes))
    print(surname)
    
    # Surname with incorrect parameters
    try:
        p.surname(12)
    except NonEnumerableError:
        print("Exception successfully passed")

# Test run
test_Person_surname()


# Generated at 2022-06-12 02:26:38.917336
# Unit test for method email of class Person
def test_Person_email():
    provider = Person(random=Random())
    for _ in range(1000):
        email = provider.email()
        assert email
        assert '@' in email



# Generated at 2022-06-12 02:26:40.604306
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()

    # Assert correct type of returning value from method
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-12 02:27:00.721879
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username()[0].isdigit() or Person().username()[0] == '_' or Person().username()[0].isalpha()


# Generated at 2022-06-12 02:27:02.273645
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    sut = person.nationality()
    assert isinstance(sut, str)


# Generated at 2022-06-12 02:27:05.379477
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(TEST_RUNS):
        nationality = Person().nationality()
        assert isinstance(nationality, str)
        assert nationality in COUNTRIES


# Generated at 2022-06-12 02:27:07.224043
# Unit test for method nationality of class Person
def test_Person_nationality():
    person_ = Person()

    assert person_.nationality() in NATIONALITIES,\
        "Invalid nationality."

# Generated at 2022-06-12 02:27:10.227521
# Unit test for method surname of class Person
def test_Person_surname():
    surname = 'Гальчук'.lower()
    surname_generator = Person()
    assert surname.lower() in surname_generator.surname().lower()


# Generated at 2022-06-12 02:27:19.029432
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    random_object = MagicMock()
    random_object.choice.return_value = 'surname'
    person.random = random_object
    person._data = {
            'male': ['Иванов', 'Петров', 'Сидоров'],
            'female': ['Колотушкина', 'Петрова'],
            'surname': ['Иванов', 'Петров', 'Сидоров',
                        'Колотушкина', 'Петрова'],
        }
    assert isinstance(person.surname(), str)
    assert person.s

# Generated at 2022-06-12 02:27:30.228716
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:27:33.897240
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(enumerable_classes=EnumerableClasses)
    
    # test for return value of method nationality of class Person
    assert isinstance(p.nationality(), str)


# Generated at 2022-06-12 02:27:35.869877
# Unit test for method surname of class Person
def test_Person_surname():
    person_surname = Person().surname()
    assert person_surname == 'Иванов'

# Generated at 2022-06-12 02:27:43.861755
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.person.ko_KR import Provider as PersonProvider
    from faker.providers.person.ar_EG import Provider as PersonProvider
    from faker.providers.person.fa_IR import Provider as PersonProvider
    from faker.providers.person.zh_CN import Provider as PersonProvider
    from faker.providers.person.ru_RU import Provider as PersonProvider
    from faker.providers.person.ja_JP import Provider as PersonProvider
    from faker.providers.person.es_ES import Provider as PersonProvider
    from faker.providers.person.de_DE import Provider as PersonProvider
    from faker.providers.person.hi_IN import Provider as PersonProvider


# Generated at 2022-06-12 02:28:02.128932
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(100):
        nationality = Person().nationality()
        assert nationality in NATIONALITIES

# Generated at 2022-06-12 02:28:03.530899
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str), 'Should be string'
    
    

# Generated at 2022-06-12 02:28:15.885892
# Unit test for method username of class Person
def test_Person_username():
    # Test username method of the Person class
    assert Person().username(template='UU.d') is not None
    assert Person().username(template='ld') is not None
    assert Person().username(template='l_d') is not None
    assert Person().username(template='l-d') is not None
    assert Person().username(template='Ud') is not None
    assert Person().username(template='U-d') is not None
    assert Person().username(template='U_d') is not None
    assert Person().username(template='UUd') is not None
    assert Person().username(template='UU_d') is not None
    assert Person().username(template='UU-d') is not None
    assert Person().username(template='UU.d') is not None
    assert Person().username(template='default') is not None


# Generated at 2022-06-12 02:28:18.368774
# Unit test for method nationality of class Person
def test_Person_nationality():
    """
    Test Person nationality method.
    """
    for _ in range(20):
        assert Person().nationality() in NATIONALITIES

# Generated at 2022-06-12 02:28:22.840274
# Unit test for method nationality of class Person
def test_Person_nationality():
    from pydatagen.providers.enums.gender import Gender
    from pydatagen.providers.enums.title_type import TitleType
    
    p = Person()
    p.nationality(Gender.MALE)
test_Person_nationality()

# Generated at 2022-06-12 02:28:32.776361
# Unit test for method email of class Person
def test_Person_email():
    # standard
    assert Person().email() == 'wquilliams0@mysql.com'
    assert Person('default').email() == 'wquilliams0@mysql.com'
    assert Person().email() == 'hkerr1@gizmodo.com'
    assert Person().email() == 'wsteeples2@guardian.co.uk'
    assert Person().email() == 'ekersley3@printfriendly.com'
    assert Person().email() == 'ckeats4@harvard.edu'

    # custom domains
    assert Person(domains=['test.com', 'test.org']).email() == 'zdudman0@test.org'

# Generated at 2022-06-12 02:28:35.203391
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit test for method nationality of class Person."""
    provider = Person(None)
    nat = provider.nationality()
    assert nat in provider._data['nationality'], \
        'Failed Person.nationality()'

# Generated at 2022-06-12 02:28:37.014267
# Unit test for method email of class Person
def test_Person_email():
    p = Person(seed=556)
    for _ in range(1000):
        assert p.email(unique=True) != p.email(unique=True)

# Generated at 2022-06-12 02:28:38.482945
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p.surnames()
test_Person_surname()

# Generated at 2022-06-12 02:28:41.425476
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Check: Person.surname
    Make sure: -> str
    """
    assert isinstance(Person().surname(), str)


# Generated at 2022-06-12 02:29:21.218769
# Unit test for method surname of class Person
def test_Person_surname():
    # List of items
    items = [
        {'gender': None, 'surnames': ['Иванов', 'Петров', 'Сидоров']},
        {'gender': Gender.male, 'surnames': ['Иванов', 'Петров', 'Сидоров']},
        {'gender': Gender.female, 'surnames': ['Иванова', 'Петрова', 'Сидорова']},
    ]

    for item in items:
        obj = Person(surnames=item['surnames'])
        surname = obj.surname(item['gender'])
        assert surname in item['surnames']
# Unit

# Generated at 2022-06-12 02:29:31.202972
# Unit test for method nationality of class Person
def test_Person_nationality():
    
    N = 100000
    
    r = [Person().nationality() for _ in range(N)]
    p = np.array([(i, r.count(i) / N) for i in set(r)], dtype=[('nationality', 'U20'), ('p', 'f4')])
    
    assert(p.shape[0] > 1)
    assert(np.isclose(p['p'].sum(), 1))
    assert(np.all(p['p'] > 0))
    
    print({i:r.count(i) for i in set(r)})
    
#test_Person_nationality()
test_Person_nationality()
test_Person_nationality()


# Generated at 2022-06-12 02:29:35.339154
# Unit test for method nationality of class Person
def test_Person_nationality():
    pr = Person()
    assert pr.nationality() in pr._data["nationality"]
    if isinstance(pr._data.get("nationality", None), dict):
        for k, v in pr._data.get("nationality").items():
            assert pr.nationality(gender=k) in v



# Generated at 2022-06-12 02:29:44.781084
# Unit test for method surname of class Person
def test_Person_surname():

    person = Person()
    passport.seed(0)

    assert person.surname() == 'Баранов'
    assert person.surname() == 'Беляев'
    assert person.surname() == 'Колесников'
    assert person.surname() == 'Соломина'
    assert person.surname() == 'Тетерина'
    assert person.surname() == 'Борисов'
    assert person.surname() == 'Семёнова'
    assert person.surname() == 'Мартынова'

# Generated at 2022-06-12 02:29:47.471182
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)
    assert(len(person.surname()) >= 2)

# Generated at 2022-06-12 02:29:49.578539
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    names_list = p.surname()
    try:
        assert type(names_list) == str
        assert names_list != ""
        assert names_list != None
    except:
        assert False
    print ("Method Person().surname() passed !!")
    print ("-"*50)


# Generated at 2022-06-12 02:29:55.735107
# Unit test for method surname of class Person
def test_Person_surname():

    provider = Faker('ru_RU')
    data = provider._data['surname']
    count_data = len(data)

    expected = {'MALE': count_data, 'FEMALE': count_data}

    for gender in Gender:

        result = provider.surname(gender)

        if gender in expected:
            expected[gender] -= 1
        else:
            expected[gender] = -1

        assert result in data

    assert expected == {'MALE': 0, 'FEMALE': 0}

# Generated at 2022-06-12 02:30:01.159267
# Unit test for method nationality of class Person
def test_Person_nationality():
    # sample code
    p = Person(locale='en')
    g = Gender.MALE
    f = p.nationality(gender=g)
    g = Gender.FEMALE
    m = p.nationality(gender=g)
    if m == f:
        print(m)


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-12 02:30:10.879362
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person(random=Random(seed=11))
    assert p.surname() == "Чернов"
    assert p.surname(gender=Gender.male) == "Иванов"
    assert p.surname(gender=Gender.female) == "Петрова"
    for i in range(0, 10000):
        p = Person(random=Random(seed=11 + i))
        assert p.surname(gender=Gender.female) == "Петрова"
    for i in range(0, 10000):
        p = Person(random=Random(seed=10000 + 11 + i))
        assert p.surname() == "Чернов"
    # Surname from list

# Generated at 2022-06-12 02:30:11.918587
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in Person._data['nationality']
    

# Generated at 2022-06-12 02:31:13.713976
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    print(p.nationality())
    

# Generated at 2022-06-12 02:31:16.365242
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    fake = Faker(['ru_RU'])
    for _ in range(100):
        result = fake.surname(gender='male')
        assert isinstance(result, str)

# Generated at 2022-06-12 02:31:26.476109
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Check if function returns nationality
    assert Person(language='en').nationality() in NATIONALITIES

    # Check if function returns Russian nationality
    assert Person(language='en', country_code='ru').nationality() == 'Russian'

    # Check if function returns American nationality
    assert Person(language='en', country_code='us').nationality() in ('American', 'Native American')

    # Check if function returns Brazilian nationality
    assert Person(language='en', country_code='br').nationality() in ('Brazilian', 'Amerindian')

    # Check if function returns German nationality
    assert Person(language='en', country_code='de').nationality() == 'German'

    # Check if function returns Spanish nationality
    assert Person(language='en', country_code='es').nationality() == 'Spanish'

    # Check if function returns French nationality


# Generated at 2022-06-12 02:31:28.423255
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test the method nationality of class Person."""
    person = Person()
    nationality = person.nationality()

    assert nationality in person._data['nationality']


# Generated at 2022-06-12 02:31:34.724715
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()