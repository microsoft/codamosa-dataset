

# Generated at 2022-06-12 02:21:42.258098
# Unit test for method surname of class Person
def test_Person_surname():
    obj_Person = Person()
    assert obj_Person.surname(None) == "Paller"



# Generated at 2022-06-12 02:21:46.196777
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    print(p.surname(Gender.FEMALE))
    print(p.surname(Gender.MALE))
    print(p.surname(Gender.NOT_APPLICABLE))


# Generated at 2022-06-12 02:21:47.132779
# Unit test for method surname of class Person
def test_Person_surname():
    assert PersonProvider().surname()

# Generated at 2022-06-12 02:21:52.015742
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random=Random(seed=1337))

    assert person.nationality() == 'Belarusian'
    assert person.nationality(Gender.MALE) == 'Russian'
    assert person.nationality(Gender.FEMALE) == 'Russian'


# Generated at 2022-06-12 02:21:54.092869
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert len(person.surname()) > 0


# Generated at 2022-06-12 02:22:01.839052
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()

    assert isinstance(person.surname(), str)
    assert isinstance(person.surname(Gender.FEMALE), str)
    assert isinstance(person.surname(Gender.MALE), str)

    surnames_male = person._data['name']['male']
    surnames_female = person._data['name']['female']

    for _ in range(100):
        assert person.surname(Gender.FEMALE) in surnames_female
        assert person.surname(Gender.MALE) in surnames_male
        assert person.surname() in surnames_female + surnames_male

# Generated at 2022-06-12 02:22:13.840348
# Unit test for method surname of class Person
def test_Person_surname():
    # First
    assert Person().surname(gender=Gender.FEMALE) in FEMALE_SURNAMES
    # Second
    assert Person(gender=Gender.FEMALE).surname() in FEMALE_SURNAMES
    # Third
    assert Person().surname(Gender.FEMALE) in FEMALE_SURNAMES
    # Fourth
    female_surnames = {Gender.MALE: MALE_SURNAMES, Gender.FEMALE: FEMALE_SURNAMES}
    assert Person().surname(female_surnames) in FEMALE_SURNAMES
    # Fifth
    assert Person().surname(MALE_SURNAMES) in MALE_SURNAMES
    # Sixth
    assert Person().surname(Gender.MALE) in MALE_SURNAMES


# Generated at 2022-06-12 02:22:25.684175
# Unit test for method surname of class Person
def test_Person_surname():
    from .enums import Gender

    p = Person(random.Random(2))

    assert p.surname() == 'Константинов'
    assert p.surname(gender=Gender.MALE) == 'Константинов'
    assert p.surname(gender=Gender.FEMALE) == 'Коржикова'
    assert p.surname(gender=Gender.FEMALE) == 'Коржикова'
    assert p.surname(gender=Gender.FEMALE) == 'Коржикова'

# Generated at 2022-06-12 02:22:29.093352
# Unit test for method surname of class Person
def test_Person_surname():
    # Initialize
    p = Person()

    # Execute
    rv = p.surname()

    # Verify
    assert isinstance(rv, str)



# Generated at 2022-06-12 02:22:30.480493
# Unit test for method email of class Person
def test_Person_email():
    assert Person.email() == 'foretime10@live.com'


# Generated at 2022-06-12 02:22:36.186791
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(lang = 'ru')
    assert p.nationality() != None

# Generated at 2022-06-12 02:22:37.853059
# Unit test for method nationality of class Person
def test_Person_nationality():
    for i in range(1, 100):
        assert Person.nationality() in NATIONALITIES

# Generated at 2022-06-12 02:22:49.310621
# Unit test for method surname of class Person

# Generated at 2022-06-12 02:22:59.578110
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username('U.d') in [
        'V.1990', 'B.2002', 'F.1980', 'M.2003', 'C.1948',
        'H.2001', 'D.1954', 'C.2071', 'B.2005', 'D.2027',
    ]
    assert Person().username('ld') in [
        'h2000', 'b1957', 'd2008', 'f2003', 'e1952',
        'a1951', 'h1952', 'a1952', 'g1994', 'g1987',
    ]

# Generated at 2022-06-12 02:23:01.832724
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']

# Generated at 2022-06-12 02:23:02.712682
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    assert p.surname() in p._data['surnames_male']


# Generated at 2022-06-12 02:23:05.744557
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=1)

    assert p.nationality(gender=Gender.MALE) == "Russian"


# Generated at 2022-06-12 02:23:08.709947
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    s = person.surname()
    assert type(s) is str
    # print(s)

# Generated at 2022-06-12 02:23:09.903508
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert any(isinstance(person.surname(), str) for _ in range(100))

# Generated at 2022-06-12 02:23:19.319937
# Unit test for method surname of class Person
def test_Person_surname():
    person_provider = Person()
    assert len(person_provider.surname()) <= 25
    assert len(person_provider.surname('ru')) <= 25
    assert len(person_provider.surname('en')) <= 25
    assert len(person_provider.surname('es')) <= 25
    assert len(person_provider.surname('de')) <= 25
    assert len(person_provider.surname('fr')) <= 25
    assert len(person_provider.surname('it')) <= 25
    assert len(person_provider.surname('cs')) <= 25
    assert len(person_provider.surname('pl')) <= 25
    assert len(person_provider.surname('hu')) <= 25
    assert len

# Generated at 2022-06-12 02:23:28.746958
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    p.surname() == "Doe"


# Generated at 2022-06-12 02:23:31.345767
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    n = p.nationality()
    assert n != n



# Generated at 2022-06-12 02:23:40.110122
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person"""
    person = Person()

# Generated at 2022-06-12 02:23:41.845984
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']


# Generated at 2022-06-12 02:23:53.339115
# Unit test for method nationality of class Person
def test_Person_nationality():
    from .helpers import assert_in_list
    from .helpers import assert_non_empty_list
    from .helpers import assert_list_length
    from .helpers import enum_to_list
    from .helpers import mock_value
    from faker.generator import Generator

    def test_sample(g: Generator, *args, **kwargs):
        nationalities = enum_to_list(Nationality, inclusive=True)
        nationality = g.person.nationality(*args, **kwargs)
        assert_in_list(nationality, nationalities)
        assert_non_empty_list(nationalities)

    def test_with_gender_male(g: Generator):
        nationalities = enum_to_list(Nationality, inclusive=True)

# Generated at 2022-06-12 02:24:01.244246
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=42)
    assert person.surname(gender=Gender.MALE) == "Χαρούλιδης"
    assert person.surname(gender=Gender.MAN) == "Χαρούλιδης"
    
    with raises(NonEnumerableError):
        person.surname(gender=Gender.OTHER)
    
    assert person.surname(gender=Gender.FEMALE) == "Ροκούση"
    assert person.surname(gender=Gender.WOMAN) == "Ροκούση"

# Generated at 2022-06-12 02:24:07.188435
# Unit test for method surname of class Person
def test_Person_surname():
    Person.surname()  # No error
    Person.surname(Gender.FEMALE)  # No error
    Person.surname(Gender.MALE)  # No error
    Person.surname('male')  # No error
    Person.surname('female')  # No error
    Person.surname(0)  # No error
    Person.surname(1)  # No error
    Person.surname(1.0) # No error
    Person.surname('invalid_parameter')  # Raises NonEnumerableError


# Generated at 2022-06-12 02:24:09.804441
# Unit test for method nationality of class Person
def test_Person_nationality():
  print("Nationality: " + Person.nationality())

if __name__ == '__main__':
  test_Person_nationality()

# Generated at 2022-06-12 02:24:11.829399
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITIES


# Generated at 2022-06-12 02:24:13.902351
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert isinstance(person.surname(), str)


# Generated at 2022-06-12 02:24:22.647316
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    data = person.username(template='l-d')


# Generated at 2022-06-12 02:24:26.267336
# Unit test for method nationality of class Person
def test_Person_nationality():
    """ Unit test for method nationality of class Person. """
    arg = "MALE"
    person = Person()
    result = person.nationality(arg)
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-12 02:24:27.345136
# Unit test for method nationality of class Person
def test_Person_nationality():
    Person()


# Generated at 2022-06-12 02:24:38.592040
# Unit test for method surname of class Person

# Generated at 2022-06-12 02:24:44.595858
# Unit test for method surname of class Person
def test_Person_surname():
    from pydantic import ValidationError

    greeks = Person(names='Greek', surnames=['Chalkoker', 'Pigarets'])
    assert greeks.surname() in ['Chalkoker', 'Pigarets']
    assert greeks.surname() in ['Chalkoker', 'Pigarets']
    assert greeks.surname() in ['Chalkoker', 'Pigarets']

    pirates = Person(names='Pirate', surnames={Gender.female: ['Anne', 'Lisa'], Gender.male: ['John', 'Pete']})
    assert pirates.surname(Gender.male) in ['John', 'Pete']
    assert pirates.surname(Gender.female) in ['Anne', 'Lisa']

# Generated at 2022-06-12 02:24:54.670752
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    print(result)

# test_Person_nationality()
first_name_list = []
last_name_list = []
gender_list = []
title_list = []
full_name_list = []
username_list = []
password_list = []
email_list = []
social_media_profile_list = []
gender_list = []
height_list = []
weight_list = []
blood_type_list = []
political_views_list = []
worldview_list = []
views_on_list = []
nationality_list = []
university_list = []
academic_degree_list = []
language_list = []
telephone_list = []
avatar_list = []
identifier_list = []

# Generated at 2022-06-12 02:25:04.156733
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    from faker import Provider
    from faker.generator import random

    fake = Faker()

    fake.add_provider(Provider)
    for _ in range(99):
        rnd1 = random.random()
        nationalities = fake._get_dict('nationality')
        rnd2 = random.random()

        if isinstance(nationalities, dict):
            nationality = fake.nationality()
            key = fake._validate_enum(nationality, Gender)
            assert nationality in nationalities[key]
        else:
            assert rnd1 == rnd2
            assert nationality in nationalities


# Generated at 2022-06-12 02:25:06.824515
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    actual = p.nationality()
    assert type(actual) == str
    assert actual in p.data['nationality']
    

# Generated at 2022-06-12 02:25:08.667889
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    result = p.nationality()

    assert result is not None


# Generated at 2022-06-12 02:25:14.255042
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = ('Russian', 'Ukrainian', 'American', 'German',)
    person = Person(nationalities=nationalities)
    # Expected result: 'Ukrainian'
    result = person.nationality()
    assert result in nationalities, \
        "Method nationality of class Person is incorrect"
    print(result)


# Run unit tests
if __name__ == '__main__':
    test_Person_nationality()

# End

# Generated at 2022-06-12 02:25:32.272049
# Unit test for method nationality of class Person

# Generated at 2022-06-12 02:25:34.189096
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Test Person.nationality() method."""
    person = Person()
    person.nationality('Russian')


# Generated at 2022-06-12 02:25:35.471819
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname("Anna")
#Unit test for method name of class Person

# Generated at 2022-06-12 02:25:37.711545
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)


# Generated at 2022-06-12 02:25:40.796285
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname(Gender.FEMALE)
    assert isinstance(surname, str)
    assert ' ' not in surname


# Generated at 2022-06-12 02:25:49.453005
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.utils.load_data import load_nats
    from pytest import raises, raises
    from random import choice
    from unittest import TestCase

    data = load_nats()
    for _ in range(0,1000):
        # Tests for method nationality of class Person
        person = Person('ru')
        person_result = person.nationality()
        assert person_result in data
        assert person_result is not None
        assert person_result != ''
        # Tests for method nationality of class Person
        person = Person('ru')
        person_result = person.nationality(gender='male')
        assert person_result in data
        assert person_result is not None
        assert person_result != ''
        assert person_result.endswith('ой')
        # Tests for method nationality of class Person

# Generated at 2022-06-12 02:25:50.820790
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person(random=RandomGenerator()).surname()



# Generated at 2022-06-12 02:25:54.193633
# Unit test for method username of class Person
def test_Person_username():
    assert len(Person().username()) == 15
    assert len(Person(seed=0).username()) == 15



# Generated at 2022-06-12 02:25:55.593078
# Unit test for method email of class Person
def test_Person_email():
    assert len(Person().email()) == 20


# Generated at 2022-06-12 02:26:02.716513
# Unit test for method surname of class Person
def test_Person_surname():
    '''
    Тестирование функции surname класса Person
    '''
    p = Person()
    for _ in range(100):
        assert type(p.surname(gender=Gender.Male)) in (str, int)
        assert type(p.surname(gender=Gender.Female)) in (str, int)

# Generated at 2022-06-12 02:26:14.567732
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname.isupper() is False
    assert surname.islower()
    assert surname.isalpha()


# Generated at 2022-06-12 02:26:18.814965
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITIES
    assert Person().nationality(gender=Gender.FEMALE) in NATIONALITIES_FEMALE
    assert Person().nationality(gender=Gender.MALE) in NATIONALITIES_MALE


# Generated at 2022-06-12 02:26:28.865246
# Unit test for method email of class Person
def test_Person_email():
    import pytest

    person = Person(seed=1)
    assert person.email(
        unique=True,
        domains=('mydomain.com',)
    ) == 'tuvie13@mydomain.com'

    person = Person(seed=1)
    assert person.email(
        unique=True,
        domains=('mydomain.com', 'mydomain2.com')
    ) == 'tuvie13@mydomain.com'

    with pytest.raises(ValueError):
        person.email(unique=True)

    # Test custom domains
    person = Person(seed=1)
    assert person.email(
        domains=('mydomain.com',)
    ) == 'vievas13@mydomain.com'

    # Test non-unique

# Generated at 2022-06-12 02:26:38.873823
# Unit test for method email of class Person
def test_Person_email():
    from pydaker.faker.providers.person import Person
    from pydaker.faker.providers.internet import Internet
    from pydaker.faker.utils.loader import Provider as Loader
    from pydaker.faker import Factory

    loader = Loader(Factory.create(), ['internet', 'person'])
    internet = Internet(loader)
    person = Person(loader, internet)
    assert person.email(unique=True) == 'i0r9r0r9r0r9r0r9r0r9r0r9r0r9r0r9r0r9r0r9@example.com'

    loader = Loader(Factory.create('it_IT'), ['internet', 'person'])
    internet = Internet(loader)
    person = Person(loader, internet)

# Generated at 2022-06-12 02:26:43.804313
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    
    nationalities = person._data['nationality']
    keys = list(nationalities.keys())
    rv = person.nationality(get_random_item(Gender, rnd=person.random))
    assert rv in nationalities and rv in nationalities[keys[0]] and rv in nationalities[keys[1]]


# Generated at 2022-06-12 02:26:49.209108
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Instantiate a Person object
    person = Person()
    # Select a random nationality and store it in the nationality variable
    nationality = person.nationality()
    # We have a value stored in the nationality variable, now check if it is a string
    assert isinstance(nationality, str)
    # Pass the test
    print(f"Test Person.nationality(): {nationality}")
test_Person_nationality()


# Generated at 2022-06-12 02:26:51.708696
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    for _ in range(1000):
        assert p.surname() in SURNAME


# Generated at 2022-06-12 02:26:53.832719
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    assert isinstance(result, str)

# Generated at 2022-06-12 02:26:56.236817
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(100):
        assert Person(_random.Random()).surname() in SURNAMES


# Generated at 2022-06-12 02:26:57.775699
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()

    assert(isinstance(p.nationality(), str))


# Generated at 2022-06-12 02:27:07.319595
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert(p.nationality() in NATIONALITIES)


# Generated at 2022-06-12 02:27:10.631718
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person
    surnames = person._data['surname']
    c = 0
    while c < len(surnames):
        assert surnames[c] == person.surname()
        c += 1



# Generated at 2022-06-12 02:27:18.457792
# Unit test for method surname of class Person
def test_Person_surname():
    person_provider = Person(seed=1)

    assert person_provider.surname() == 'Ashley'
    assert person_provider.surname(gender=Gender.MALE) == 'Ashley'
    assert person_provider.surname(gender=Gender.FEMALE) == 'Bianca'
    assert person_provider.surname(gender='male') == 'Ashley'
    assert person_provider.surname(gender='female') == 'Bianca'
    assert person_provider.surname('MALE') == 'Ashley'
    assert person_provider.surname('FEMALE') == 'Bianca'
        

# Generated at 2022-06-12 02:27:22.676330
# Unit test for method email of class Person
def test_Person_email():
    gen = Person()
    for _ in range(1000):  # generation of 1000 email
        assert gen.email(domains=('example.com',)) == 'some_user@example.com'
        
test_Person_email()



# Generated at 2022-06-12 02:27:33.350956
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker.providers.person.en_US import Provider as Person
    from faker.generator import Generator
    generator = Generator()
    generator.add_provider(Person)

    def nationality_ru():
        """Тестируем метод nationality на русский язык."""
        for r in range(100):
            nationality = generator.person.nationality()
            if nationality == 'Russian':
                r += 1
        return (r == 100)


# Generated at 2022-06-12 02:27:38.573628
# Unit test for method surname of class Person
def test_Person_surname():
    # Arrange
    test_seed = 123456789
    test_person_instance = Person(test_seed)
    test_person_instance.seed_instance(test_seed)
    test_person_instance.random.random()

    # Act
    test_result = test_person_instance.surname(gender=Gender.female)

    # Assert
    assert test_result == 'Иванова'



# Generated at 2022-06-12 02:27:41.123913
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert isinstance(person.nationality(), str)
    assert isinstance(person.nationality(Gender.FEMALE), str)
    assert isinstance(person.nationality(Gender.MALE), str)

# Generated at 2022-06-12 02:27:42.430119
# Unit test for method surname of class Person
def test_Person_surname():
    element = Faker().surname()
    assert isinstance(element, str)
    assert element



# Generated at 2022-06-12 02:27:44.561374
# Unit test for method surname of class Person
def test_Person_surname():
    sample = Person.surname
    assert isinstance(sample(),str)
    assert 3 < len(sample()) < 16


# Generated at 2022-06-12 02:27:53.276148
# Unit test for method nationality of class Person
def test_Person_nationality():
    from random import seed
    import pytest
    from pytest import approx

    # Seed value for random number generator
    seed(0)
    person = Person()

    # Nationalities of gender is Male
    nationalities_Male = ['Russian', 'Belarusian', 'German', 'Ukrainian', 'Kazakh']

    # Value for the argument gender of method nationality of class Person
    test_cases_gender_for_nationality = [
        (None, approx(0.2)),
        (Gender.Male, approx(0.8)),
        (Gender.Female, approx(0.2))
    ]

    # Value of the attributes of method nationality of class Person
    def test_Person_gender_nationality():
        for gender in test_cases_gender_for_nationality:
            pass

            assert gender[0] == person.gender()

# Generated at 2022-06-12 02:28:14.017837
# Unit test for method nationality of class Person
def test_Person_nationality():
    ud = Person(seed=9)
    res = [ud.nationality() for i in range(100)]

# Generated at 2022-06-12 02:28:20.809850
# Unit test for method username of class Person
def test_Person_username():
    assert Person(seed=47).username() == 'h_09'
    assert Person(seed=48).username() == 'h.09'
    assert Person(seed=49).username() == 'h09'
    assert Person(seed=50).username() == 'h.09'
    assert Person(seed=51).username() == 'h.09'
    assert Person(seed=52).username() == 'h_09'
    assert Person(seed=53).username() == 'h-09'
    assert Person(seed=54).username() == 'h.09'
    assert Person(seed=55).username() == 'h-09'
    assert Person(seed=56).username() == 'h.09'
    assert Person(seed=57).username() == 'h.09'

# Generated at 2022-06-12 02:28:25.360269
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person
    """
    with LocalTest() as test:
        provider = test.provider
        for _ in range(100):
            assert isinstance(provider.surname(), str)
            assert isinstance(provider.last_name(), str)

# Generated at 2022-06-12 02:28:32.154787
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Provider()
    print(p.nationality())
    print(p.nationality(gender=Gender.FEMALE))
    print(p.nationality())
    print(p.nationality(gender=Gender.MALE))
    print(p.nationality())
    print(p.nationality(gender=Gender.FEMALE))
    print(p.nationality())
    print(p.nationality(gender=Gender.FEMALE))

# Generated at 2022-06-12 02:28:39.002791
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    # (This list may be not complete)

# Generated at 2022-06-12 02:28:41.913822
# Unit test for method surname of class Person
def test_Person_surname():
    surname = Person.surname()
    assert isinstance(surname, str)
    assert len(surname) > 0

# Generated at 2022-06-12 02:28:44.705558
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)
    assert surname in person._data['surname']


# Generated at 2022-06-12 02:28:53.485582
# Unit test for method surname of class Person
def test_Person_surname():
    from random import seed
    from faker.providers.person.en_US import Provider
    
    provider = Provider
    names = provider.last_names
    surname = provider.surname()
    assert surname in names
    assert surname != provider.surname()
    
    seed(0)
    assert provider.surname(gender='M') in names['M']
    assert provider.surname(gender='F') in names['F']

    seed(0)
    assert provider.surname(gender='male') in names['M']
    assert provider.surname(gender='female') in names['F']

    seed(0)
    assert provider.surname(gender='M') == 'Greene'
    assert provider.surname(gender='F') == 'Lynch'

# Generated at 2022-06-12 02:28:58.428859
# Unit test for method surname of class Person
def test_Person_surname():
    from faker import Faker
    fake = Faker()
    gp = Gender.MALE
    gn = Gender.FEMALE
    sn = fake.surname()
    sn_female = fake.surname(gender=gn)
    sn_male = fake.surname(gender=gp)
    assert sn == sn_female or sn == sn_male
      

# Generated at 2022-06-12 02:29:06.405177
# Unit test for method nationality of class Person
def test_Person_nationality():
    from .faker_factory import faker_factory
    from .person import Person
    from .enum.gender import Gender
    
    faker = faker_factory.create(locale='en')
    f = Person(faker)
    assert f.nationality() in ['Chinese', 'Mexican', 'American']
    assert f.nationality(gender=Gender.FEMALE) in ['Chinese', 'Mexican', 'American']
    assert f.nationality(gender=Gender.MALE) in ['Chinese', 'Mexican', 'American']
    assert f.nationality(gender=Gender.MALE) in f.nationality(gender=Gender.FEMALE)
    assert f.nationality(gender=Gender) in f.nationality(gender=Gender.MALE)

# Generated at 2022-06-12 02:29:29.269555
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email(unique = False) is not None
    assert Person().email(unique = False) == Person().email(unique = False)
    assert Person().email(unique = True) is not None
    assert Person().email(unique = True) != Person().email(unique = True)
    assert Person().email(unique = True) != Person().email(unique = False)

# Generated at 2022-06-12 02:29:33.991243
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert all([Person().nationality('male') in Nationality])
    assert all([Person().nationality('female') in Nationality])
    assert all([Person().nationality() in Nationality])
    
if __name__ == '__main__':
    test_Person_nationality()

# Generated at 2022-06-12 02:29:43.691265
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert len(p.email()) == 23, "Expected 23 characters"
    assert p.email()[-8:] == "yahoo.com", "Expected 'yahoo.com'"
    assert len(p.email(unique=True)) == 21, "Expected 21 characters, got {0}".format(len(p.email(unique=True)))
    assert p.email(unique=True).endswith(".com"), "Expected to end with '.com', got {0}".format(p.email(unique=True))
    assert p.email(domains=["gmail.com"]).endswith("@gmail.com"), "Expected '@gmail.com', got {0}".format(p.email(domains=["gmail.com"]))
    assert p.email(domains=[".com"]).endsw

# Generated at 2022-06-12 02:29:46.018545
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person('random')
    one_of_surname = p.surname()
    assert one_of_surname in p._data['surname']
    
    

# Generated at 2022-06-12 02:29:49.379802
# Unit test for method surname of class Person
def test_Person_surname():

    p = Person(seed=42)
    assert p.surname() == 'Brady'

# Generated at 2022-06-12 02:29:52.371625
# Unit test for method surname of class Person
def test_Person_surname():
    from faker.providers.person.en import Provider
    person = Provider()
    name = person.surname('*')
    assert isinstance(name, str)


# Generated at 2022-06-12 02:29:55.918662
# Unit test for method nationality of class Person
def test_Person_nationality():
    _nationality = Person(seed=42).nationality()
    assert isinstance(_nationality, str)

    _nationality = Person(seed=42).nationality(gender=Gender.FEMALE)
    assert isinstance(_nationality, str)

    _nationality = Person(seed=42).nationality(gender=Gender.MALE)
    assert isinstance(_nationality, str)

    try:
        _nationality = Person(seed=42).nationality(gender='invalid')
    except NonEnumerableError as error:
        assert error.args == ('Gender',)
    else:
        assert False, 'Exception was not raised'



# Generated at 2022-06-12 02:30:00.542120
# Unit test for method surname of class Person
def test_Person_surname():
    g = Genealogical()
    assert g.surname(gender='male') in SURNAME_MALE
    assert g.surname(gender='female') in SURNAME_FEMALE
    assert g.surname() in (SURNAME_MALE + SURNAME_FEMALE)

# Generated at 2022-06-12 02:30:06.339842
# Unit test for method nationality of class Person
def test_Person_nationality():
    _Person = Person(seed=42)
    assert _Person.nationality() == 'Tonga'
    # Separated by gender.
    assert _Person.nationality(Gender.MALE) == 'Tonga'
    assert _Person.nationality(Gender.FEMALE) == 'Tajikistan'
    # Invalid gender.
    with pytest.raises(NonEnumerableError):
        _Person.nationality(None)


# Generated at 2022-06-12 02:30:09.209872
# Unit test for method surname of class Person
def test_Person_surname():
    result = Person(seed=1234).surname()
    assert result == 'Кормен'


# Generated at 2022-06-12 02:30:32.528716
# Unit test for method email of class Person
def test_Person_email():
    faker = Person()
    assert faker.email().count('@') == 1
    assert faker.email('test.com').count('@') == 1
    assert faker.email('test.com').count('.') == 1
    assert faker.email(['test.com']).count('@') == 1
    assert faker.email(['test.com']).count('.') == 1
    assert faker.email(['test.com', 'test.com']).count('@') == 1
    assert faker.email(['test.com', 'test.com']).count('.') == 1
    assert faker.email(['test.com', 'test1.com']).count('.') == 1
    assert faker.email(['test.com', 'test1.com']).count('@') == 1


# Generated at 2022-06-12 02:30:34.654634
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    nat = p.nationality()
    print(nat)
    assert isinstance(nat, str)

# Generated at 2022-06-12 02:30:37.253739
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surnames = person.surname()
    assert surnames in person._data['surname']



# Generated at 2022-06-12 02:30:38.756425
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert is_domain_name(p.email().split('@')[1])



# Generated at 2022-06-12 02:30:45.652038
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(1000):
        # Russian surnames
        russian_surnames = Person.surname(gender=Gender.Male,
                                          surnames=RUSSIAN_SURNAMES)
        assert russian_surnames in RUSSIAN_SURNAMES

        russian_surnames = Person.surname(gender=Gender.Female,
                                          surnames=RUSSIAN_SURNAMES)
        assert russian_surnames in RUSSIAN_SURNAMES

        # English surnames
        english_surnames = Person.surname(gender=Gender.Male,
                                          surnames=ENGLISH_SURNAMES)
        assert english_surnames in ENGLISH_SURNAMES


# Generated at 2022-06-12 02:30:48.614849
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(seed=457)
    person.nationality(gender=Gender.MALE)
    assert person.nationality() == 'Russian'


# Generated at 2022-06-12 02:30:50.287375
# Unit test for method surname of class Person
def test_Person_surname():
    p_rand = Provider()
    assert p_rand.surname() != ''

# Generated at 2022-06-12 02:30:52.059799
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert isinstance(p.nationality(), str)

# Generated at 2022-06-12 02:30:54.789424
# Unit test for method nationality of class Person
def test_Person_nationality():
    _nationality = []
    for _ in range(5):
        _nationality.append(Person(generator).nationality())
    _nationality = list(set(_nationality))
    assert len(_nationality) >= 1

# Generated at 2022-06-12 02:30:58.236430
# Unit test for method nationality of class Person
def test_Person_nationality():
    gender = get_random_item(Gender, rnd=get_random_instance())
    nationality = get_random_item(Person.nationality, kwargs={'gender': gender})
    assert isinstance(nationality, str)

# Generated at 2022-06-12 02:31:15.092421
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Get a random nationality of class Person
    nationalities = Person().nationality()
    # Check that the method returns a string
    assert isinstance(nationalities, str)


# Generated at 2022-06-12 02:31:16.288543
# Unit test for method surname of class Person
def test_Person_surname():
    assert len(Person().surname()) > 0


# Generated at 2022-06-12 02:31:21.858569
# Unit test for method username of class Person
def test_Person_username():
    provider = Person()
    user = provider.username()
    # Regex pattern for test a username
    pattern = re.compile(
        r"^(?=.{4,20}$)(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])$")
    assert re.match(pattern, user) is not None

# Generated at 2022-06-12 02:31:27.844814
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker import Faker
    fake = Faker()

    nationality = fake.nationality()
    assert nationality

    nationality = fake.nationality(gender=None)
    assert nationality
    
    nationality = fake.nationality(gender=Gender.MALE)
    assert nationality
    
    nationality = fake.nationality(gender=Gender.FEMALE)
    assert nationality
    
    with pytest.raises(NonEnumerableError):
        nationality = fake.nationality(gender='UNKNOWN')



# Generated at 2022-06-12 02:31:29.429625
# Unit test for method surname of class Person
def test_Person_surname():
    for i in range(200):
        person = Person()
        surname = person.surname()
        assert surname in PERSON_SURNAMES

# Generated at 2022-06-12 02:31:34.112286
# Unit test for method surname of class Person
def test_Person_surname():
    person1 = Person(seed=23)
    # For making it "deterministic"
    person1.random.seed(1)
    person1.surname(gender=Gender.MALE) == "Pate"
    person1.surname(gender=Gender.MALE) == "Brantner"
    person1.surname(gender=Gender.FEMALE) == "Harkaitz"
    person1.surname(gender=Gender.FEMALE) == "Riedl"
test_Person_surname()