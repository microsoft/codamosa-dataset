

# Generated at 2022-06-12 02:21:54.736571
# Unit test for method email of class Person
def test_Person_email():
    from datetime import datetime
    from typing import Text, List

    from faker import Faker
    from faker.providers.person.en_US import Provider

    from faker.utils import text

    fake = Faker(locale="en_US")
    person = fake.provider(Provider)

    EMAIL = person.random_element(person.email_formats)
    EMAIL_DOMAIN = person.random_element(EMAIL_DOMAINS)

    email = text(EMAIL, EMAIL_DOMAIN)

    assert email == person.email(EMAIL_DOMAIN)

# Generated at 2022-06-12 02:22:04.304487
# Unit test for method email of class Person
def test_Person_email():
    @pytest.fixture(scope="function")
    def provider():
        return Person()

    @pytest.mark.parametrize('domains', [
        [], None, ['example.com'], ['.example.com'], ['example.com']
    ])
    def test_return_type(provider, domains):
        assert isinstance(provider.email(domains), str)

    @pytest.mark.parametrize('length', [1, 2])
    def test_length(provider, length):
        name = provider.username(template='U' * length)
        domain = '@' + provider.random.choice(EMAIL_DOMAINS)
        assert len(provider.email(unique=name)) == length + len(domain)


# Generated at 2022-06-12 02:22:16.553436
# Unit test for method nationality of class Person
def test_Person_nationality():
    from random import choice
    from string import ascii_letters
    from faker_ru.data import RUSSIAN_MALE_NAMES, RUSSIAN_FEMALE_NAMES
    from faker_ru.providers.person import Person
    
    fake = Person(random=choice, seed=None)
    
    result = fake.name(gender=None)
    assert result in RUSSIAN_MALE_NAMES + RUSSIAN_FEMALE_NAMES
    
    result = fake.name(gender=Gender.male)
    assert result in RUSSIAN_MALE_NAMES
    
    result = fake.name(gender=Gender.female)
    assert result in RUSSIAN_FEMALE_NAMES
    
    result = fake.name(gender=Gender.undefined)


# Generated at 2022-06-12 02:22:18.921183
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    print(person.email())

if __name__ == "__main__":
    test_Person_email()


# Generated at 2022-06-12 02:22:22.543487
# Unit test for method email of class Person
def test_Person_email():
    person = Person(seed=12345)
    result = person.email(domains=['me.com', 'gmail.com'])
    assert result == 'lucius.craig@me.com'

# Generated at 2022-06-12 02:22:33.606355
# Unit test for method email of class Person
def test_Person_email():
    provider = PersonProvider()
    # Create list of domains.
    domains = (
        'bitbucket.org',
        'codecademy.com',
        'github.com',
        'gitlab.com',
        'hub.com',
        'kaggle.com',
        'linkedin.com',
        'live.com',
        'mail.ru',
        'mendeley.com',
        'npmjs.com',
        'reddit.com',
        'researchgate.net',
        'stackoverflow.com',
    )
    res = provider.email(domains=domains)

# Generated at 2022-06-12 02:22:41.273155
# Unit test for method surname of class Person
def test_Person_surname():
    provider = PersonProvider()
    # Assert to test method surname of class Person
    surname_list = ["Anderson", "Chen", "Doe", "Griffin", "Jackson" \
        , "Johnson", "Jones", "Li", "Martinez", "Nguyen", "Peterson" \
        , "Richardson", "Rodriguez", "Smith", "Taylor", "Thomas", "Wright"]
    for _ in range(1000):
        assert provider.surname() in surname_list


# Generated at 2022-06-12 02:22:51.527978
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname(Gender.FEMALE) in SURNAME_FEMALE
    assert Person().surname(Gender.MALE) in SURNAME_MALE
    assert Person().surname() in SURNAME_FEMALE + SURNAME_MALE
    assert Person().surname(Gender.FEMALE) in SURNAMES
    assert Person().surname(Gender.MALE) in SURNAMES
    assert Person().surname() in SURNAMES
    assert Person().last_name(Gender.FEMALE) in SURNAME_FEMALE
    assert Person().last_name(Gender.MALE) in SURNAME_MALE
    assert Person().last_name() in SURNAME_FEMALE + SURNAME_MALE
    assert Person().last_name(Gender.FEMALE) in SURNAMES

# Generated at 2022-06-12 02:22:57.998245
# Unit test for method email of class Person
def test_Person_email():
    kb = KnowledgeBase()
    kb += Fact(Relation('person'), 'unique')

    gen = Generator(kb)
    gen.seed(23)

    # Tested function
    func = partial(gen.person.email, 'unique')

    # Expected results
    expected = 'zhou.1756@mail.ru'

    # Test it!
    _tester('email', func, expected, test_Person_email.__name__)

# Generated at 2022-06-12 02:23:08.499255
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    assert person.surname() in person.surname(gender=Gender.male)
    assert person.surname() in person.surname(gender=Gender.male)
    assert person.surname(gender='male') in person.surname(gender=Gender.male)
    assert person.surname(gender='male') in person.surname(gender='male')
    assert person.surname(gender='female') in person.surname(gender=Gender.female)
    assert person.surname(gender='female') in person.surname(gender='female')

# Generated at 2022-06-12 02:23:28.062806
# Unit test for method nationality of class Person
def test_Person_nationality():
    a = Person().nationality()
    b = Person().nationality()
    assert a != b
    assert a in NATIONALITY
    assert b in NATIONALITY


# Generated at 2022-06-12 02:23:32.602216
# Unit test for method nationality of class Person
def test_Person_nationality():
    import pytest
    from faker import Faker
    fake = Faker()
    fake.add_provider(Person)
    nationalities = []
    for item in range(100):
        nationalities.append(fake.nationality())
    pytest.assumptions("Belarusian" in nationalities)

# Generated at 2022-06-12 02:23:36.376558
# Unit test for method surname of class Person
def test_Person_surname():
    range_ = range(1, 101)

    result = [Person().surname() for i in range_]

    validator.validate_list(result, expected_length=100)
    [validator.validate_string(i) for i in result]

# Generated at 2022-06-12 02:23:37.359676
# Unit test for method surname of class Person
def test_Person_surname():
    pass # print(Person().surname())
    

# Generated at 2022-06-12 02:23:40.086887
# Unit test for method surname of class Person
def test_Person_surname():
    assert type(Person().surname()) == str



# Generated at 2022-06-12 02:23:46.613217
# Unit test for method nationality of class Person
def test_Person_nationality():
    from faker_generator.helpers import parse_random_enum_key
    from faker_generator.enums import Gender

    for _ in range(100):
        # for gender in Gender:
        #     assert parse_random_enum_key(Person.nationality, gender) == gender
        for gender in Gender:
            assert parse_random_enum_key(Person.nationality, gender) == gender



# Generated at 2022-06-12 02:23:48.846846
# Unit test for method surname of class Person
def test_Person_surname():
   # Load data and create object
    data = load_data('en')
    provider = Person(data=data)

    # Run method
    name = provider.surname()
    assert name

    # Run method again
    name = provider.surname()
    assert name
assert True == True


# Generated at 2022-06-12 02:23:51.150834
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person(seed=12)
    print(provider.surname())
test_Person_surname()


# Generated at 2022-06-12 02:23:53.168744
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname(gender=Gender.male).isalpha()
test_Person_surname()

# Generated at 2022-06-12 02:23:57.104275
# Unit test for method surname of class Person
def test_Person_surname():
    import random
    provider = Person(random.Random())
    assert provider.surname(gender=Gender.male) in provider._data['surname'][Gender.male]
    assert provider.surname() in provider._data['surname']


# Generated at 2022-06-12 02:24:14.266176
# Unit test for method nationality of class Person
def test_Person_nationality():
    list_nationality = []
    for _ in range(100):
        national = Person().nationality()
        list_nationality.append(national)
    print(list_nationality)
    assert (len(list_nationality)) == 100
test_Person_nationality()


# Generated at 2022-06-12 02:24:23.077134
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Person without gender (default)
    person = Person()
    nationality = person.nationality()
    assert isinstance(nationality, str)
    # Person with gender
    person = Person()
    nationality = person.nationality(Gender.MALE)
    assert isinstance(nationality, str)
    # Person with incorrect gender
    person = Person()
    with pytest.raises(NonEnumerableError):
        person.nationality(Gender.NONE)
    # Person with str gender
    person = Person()
    with pytest.raises(NonEnumerableError):
        person.nationality('Male')


# Generated at 2022-06-12 02:24:26.372246
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    print(surname)
    assert isinstance(surname, str)
test_Person_surname()

# Generated at 2022-06-12 02:24:30.672082
# Unit test for method nationality of class Person
def test_Person_nationality():
    region = "Ukraine"
    gender = Person.Gender.FEMALE
    n = Person()

    assert(n.nationality() in n._data['nationality'])
    assert(n.nationality(gender) in n._data['nationality'][gender.value])

# Generated at 2022-06-12 02:24:42.145828
# Unit test for method surname of class Person
def test_Person_surname():
    from vedis import Vedis
    
    #Test person surname
    result = Person().surname('nc')
    assert result != None
    assert result != ''
    assert result != ' '
    assert len(result) >= 3
    assert len(result) <= 20
    assert result == result.lower()
    assert result == result.upper()
    assert result == result.capitalize()
    assert result == result.title()
    assert result.isalpha() == True
    
    #Test if surname value is in db
    with Vedis("/home/ivan/Documents/person_info_db/surnames.vedis") as db:
        value = db.get(result)
        assert value == b'nc'
        
    #Test if gb surname is separate
    result = Person().surname('gb')

# Generated at 2022-06-12 02:24:44.374654
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unit test for method nationality of class Person."""
    person = Person()
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-12 02:24:46.759891
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person.nationality() in PERSON_NATIONALITIES

# Generated at 2022-06-12 02:24:48.241740
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in NATIONALITY

# Generated at 2022-06-12 02:24:49.367873
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username() is not None


# Generated at 2022-06-12 02:24:53.424657
# Unit test for method nationality of class Person
def test_Person_nationality():
    print('Testing method nationality of class Person')
    class_ = Person
    Person_method = class_.nationality
    values = 'Russian'
    Russian = Person_method()
    if Russian != 'Russian':
        print(Russian)
        print('Expected: ' + str(values))
    else:
        print('Passed')
