

# Generated at 2022-06-21 16:31:45.114114
# Unit test for method nationality of class Person
def test_Person_nationality():
    def test_default():
        russian = 'Russian'
        assert russian in Person(lang='ru').nationality()

    def test_no_capitalize():
        russian = 'russian'
        assert russian in Person(
            lang='ru', capitalize_names=False).nationality()

    def test_by_gender():
        man = 'American'
        woman = 'American'
        assert man in Person(gender='male').nationality()
        assert woman in Person(gender='female').nationality()

    def test_invalid_gender():
        with pytest.raises(NonEnumerableError):
            Person().nationality(gender='bad')


# Generated at 2022-06-21 16:31:50.393486
# Unit test for method title of class Person
def test_Person_title():
    assert Person().title(title_type=TitleType.prefix) in [
        'Dr.',
        'Mr.',
        'Mrs.',
        'Miss.',
        'Ms.',
        'Prof.',
    ]

    assert Person().title(title_type=TitleType.suffix) in [
        'I',
        'II',
        'III',
        'IV',
        'Jr.',
        'Sr.',
    ]

# Generated at 2022-06-21 16:31:56.820081
# Unit test for method language of class Person
def test_Person_language():
    from faker.providers.person.en_US import Provider
    from faker import Faker
    import pdb
    # pdb.set_trace()
    fake = Faker('en_US')
    f = fake.language()
    assert type(f) == str
    assert f in Provider.languages


# Generated at 2022-06-21 16:32:04.458406
# Unit test for method title of class Person
def test_Person_title():
    person = Person()

    for _ in range(100):
        person.title("", TitleType.suffix)
        person.title("", TitleType.prefix)
        person.title(Gender.male, TitleType.prefix)
        person.title(Gender.female, TitleType.suffix)

    person.title("", TitleType.suffix)
    person.title("", TitleType.prefix)
    person.title(Gender.male, TitleType.prefix)
    person.title(Gender.female, TitleType.suffix)


# Generated at 2022-06-21 16:32:10.943490
# Unit test for method identifier of class Person
def test_Person_identifier():
    import random

    # random seed for repeatable tests
    random.seed(0)

    provider = Person(rnd=random)

    # test a default mask
    assert isinstance(provider.identifier(), str)
    assert re.fullmatch(r'[0-9][0-9]-[0-9][0-9]/[0-9][0-9]', provider.identifier())

    # test a non-default mask including letters and digits
    mask = '@@-##/##'
    assert isinstance(provider.identifier(mask=mask), str)
    assert re.fullmatch(r'[a-zA-Z][a-zA-Z]-[0-9][0-9]/[0-9][0-9]', provider.identifier(mask=mask))


# Generated at 2022-06-21 16:32:12.082382
# Unit test for method gender of class Person
def test_Person_gender():
    for idx in range(100):
        assert isinstance(Person().gender(), str)

# Generated at 2022-06-21 16:32:15.342157
# Unit test for method avatar of class Person
def test_Person_avatar():
    gen = Generator()
    assert gen.person().avatar() != ""
    assert len(gen.person().avatar()) > 0
    assert gen.person().avatar() != None


# Generated at 2022-06-21 16:32:16.493020
# Unit test for method email of class Person
def test_Person_email():
    pass


# Generated at 2022-06-21 16:32:24.596055
# Unit test for method username of class Person
def test_Person_username():
    """Test method username of class Person."""
    provider = Person()

    result = provider.username("U.d")
    expected = re.match("[a-zA-Z]+[.]\d{4}", result)
    assert expected

    result = provider.username("ld")
    expected = re.match("[a-z]+\d{4}", result)
    assert expected

    result = provider.username("Ud")
    expected = re.match("[a-zA-Z]+\d{4}", result)
    assert expected

    result = provider.username("U-d")
    expected = re.match("[a-zA-Z]+[-]\d{4}", result)
    assert expected

    result = provider.username("U_d")

# Generated at 2022-06-21 16:32:33.994392
# Unit test for method height of class Person
def test_Person_height():
    person = Person(seed=7)
    assert person.height() == '1.92'
    assert person.height(minimum=1.1, maximum=1.7) == '1.45'
    assert person.height(minimum=1.0) == '2.00'
    assert person.height(maximum=1.0) == '1.00'



# Generated at 2022-06-21 16:32:43.274031
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    res = person.occupation()
    assert isinstance(res, str)


# Generated at 2022-06-21 16:32:46.701190
# Unit test for method views_on of class Person
def test_Person_views_on():
    for i in range(100):
        value = Person().views_on()
        assert value in VK_VIEWS_ON
# For example:
Person().views_on()


# Generated at 2022-06-21 16:32:51.717535
# Unit test for method full_name of class Person
def test_Person_full_name():
    
    for i in range(100):
        person = Person()
        gender = person.random.choice([Gender.MALE, Gender.FEMALE])
        full_name = person.full_name(gender)
        assert full_name is not None
        assert isinstance(full_name, str)
        assert full_name.strip()
test_Person_full_name()

# Generated at 2022-06-21 16:32:53.051160
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert Person().sexual_orientation() in SEXUALITIES

# Generated at 2022-06-21 16:32:57.782305
# Unit test for method last_name of class Person
def test_Person_last_name():
    """Unit test for method last_name of class Person."""
    # arrange
    provider = Provider()

    # act
    result = provider.last_name()

    # assert
    assert isinstance(result, str)


# Generated at 2022-06-21 16:33:00.714262
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    value = person.blood_type()
    assert value in BLOOD_GROUPS


# Generated at 2022-06-21 16:33:02.439355
# Unit test for method title of class Person
def test_Person_title():
    assert Person.title(Person) != None
    assert Person.title(Person) != ' '


# Generated at 2022-06-21 16:33:13.488167
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person('en')

# Generated at 2022-06-21 16:33:19.795611
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person('en')
    mask = '#'

    for i in range(100):
        result = person.telephone(mask)
        assert result.count('#') == len(result)

    mask = '+7-(###)-###-##-##'
    for i in range(100):
        result = person.telephone(mask)
        assert len(result) == len(mask)



# Generated at 2022-06-21 16:33:25.284731
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(100):
        worldview = get_random_item(WorldView, rnd=Random())
        assert worldview in (WorldView.ATHEISM, WorldView.AGNOSTICISM,
                             WorldView.PANTHEISM, WorldView.POLYTHEISM,
                             WorldView.THEISM, WorldView.IDEOISM,
                             WorldView.BUDDHISM, WorldView.CHRISTIANITY,
                             WorldView.CONFUCIANISM, WorldView.HINDUISM,
                             WorldView.ISLAM, WorldView.JUDAISM,
                             WorldView.SHINTOISM, WorldView.TENGRIISM,
                             WorldView.ZOROASTRIANISM)

test_Person_worldview()

# Generated at 2022-06-21 16:33:44.066332
# Unit test for method username of class Person
def test_Person_username():
    import datetime
    from mimesis.enums import Specialization

    x = datetime.datetime.now()
    y = datetime.datetime.now()

    # Test for correct work of method username with saving random state for
    # next call of random object with random state saved before
    person = Person('en')

    person.random.seed(12345)
    assert person.username(template='Ud') == 'R899'

    person.random.seed(12345)
    assert person.username(template='Ud') == 'R899'

    person.random.seed(12345)
    assert person.username(template='Ud') == 'R899'

    # Test for correct work of method username with any template and
    # with any number of call of random object with random state
    # saved before

# Generated at 2022-06-21 16:33:47.717281
# Unit test for method views_on of class Person
def test_Person_views_on():
    for _ in range(10):
        provider = Person()
        result = provider.views_on()
        assert result in provider._data['views_on']

# Generated at 2022-06-21 16:33:58.703007
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()

# Generated at 2022-06-21 16:34:00.168430
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in VIEWS_ON


# Generated at 2022-06-21 16:34:05.108622
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()

    result = person.full_name(Gender.MALE)

    assert result is not None
    assert isinstance(result, str)
    assert result.count(' ') is 1
    assert result.split(' ')[0] in person.data['name'][Gender.MALE]
    assert result.split(' ')[1] in person.data['surname'][Gender.MALE]

# Generated at 2022-06-21 16:34:14.554889
# Unit test for method identifier of class Person
def test_Person_identifier():
    r = Person()
    r.seed(1)
    assert r.identifier() == '07-97/04'
    r.seed(1)
    assert r.identifier('##-#/') == '07-9/'
    r.seed(1)
    assert r.identifier('##') == '07'
    r.seed(1)
    assert r.identifier('#') == '7'
    r.seed(1)
    assert r.identifier('@##') == 'w07'
    r.seed(1)
    assert r.identifier('@@##') == 'ww07'


PERSON_CLASSES = [
    Person,
]
if __name__ == '__main__':
    import pytest

    pytest.main()

# Generated at 2022-06-21 16:34:25.029327
# Unit test for method weight of class Person
def test_Person_weight():
    assert Person().weight(minimum=38, maximum=90) == Person().weight(minimum=38, maximum=90)
    assert Person(seed=1000).weight(minimum=38, maximum=90) == Person(seed=1000).weight(minimum=38, maximum=90)
    assert Person().weight(minimum=38, maximum=90) != Person(seed=1000).weight(minimum=38, maximum=90)
    assert Person().weight(minimum=38, maximum=90) != Person().weight(minimum=39, maximum=91)
    assert Person().weight(minimum=38, maximum=90) != Person().weight(minimum=38, maximum=91)
    assert Person().weight(minimum=38, maximum=90) != Person().weight(minimum=39, maximum=90)

# Generated at 2022-06-21 16:34:26.325695
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    assert person.username()



# Generated at 2022-06-21 16:34:32.941855
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert len(Person().identifier()) == len('##-##/##')
    assert Person().identifier('##/##-##')
    assert Person().identifier('##/##)##')
    assert Person().identifier('##/##)##')
    assert Person().identifier('##-##-##')
    assert Person().identifier('##-##-##-##')
    assert Person().identifier('##-##-##-##')


# Generated at 2022-06-21 16:34:44.427176
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    lst = []
    for i in range(0,10):
        x = person.occupation()
        lst.append(x)
    assert list.count('Programmer')>=1
    assert list.count('Engineer')>=1
    assert list.count('Contractor')>=1
    assert list.count('Student')>=1
    assert list.count('Designer')>=1
    assert list.count('Teacher')>=1
    assert list.count('Recruiter')>=1
    assert list.count('Librarian')>=1
    assert list.count('Professor')>=1
    assert list.count('Psychologist')>=1
    assert list.count('Doctor')>=1
    assert list.count('Lawyer')>=1

# Generated at 2022-06-21 16:35:06.893955
# Unit test for method avatar of class Person
def test_Person_avatar():
    from pyfaker.tests.mock import MockProvider

    provider = MockProvider()

    for _ in range(500):
        avatar = provider.avatar()
        assert isinstance(avatar, str)

        assert avatar.startswith('https://api.adorable.io/avatars/256')
        assert avatar.endswith('.png')



# Generated at 2022-06-21 16:35:15.343447
# Unit test for method password of class Person
def test_Person_password():
    for seed in range(1000):
        rnd = random.Random(seed)
        p = Person(random=rnd)
        result = p.password(8, hashed=True)
        expected1 = '741d8e6cab68700e91b6d3d6a856f3b9'
        expected2 = 'd1ee8f139f279b6e5d5f5f5d564e3e3d'
        assert result in (expected1, expected2), \
            "result:   {}\n" \
            "expected: {}\n" \
            "         or\n" \
            "expected: {}\n" \
            "".format(result, expected1, expected2)
test_Person_password()

# Generated at 2022-06-21 16:35:18.042384
# Unit test for method political_views of class Person
def test_Person_political_views():
    # Check current method
    person = Person()
    political_views = person.political_views()
    assert political_views in person._data['political_views']

# Generated at 2022-06-21 16:35:21.568185
# Unit test for method views_on of class Person
def test_Person_views_on():
    names = [Person().views_on() for i in range(10)]
    
    assert isinstance(names, list)
    assert all(isinstance(name, str) for name in names)
    assert all(name for name in names)

# Generated at 2022-06-21 16:35:29.313485
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person(seed=0)
    assert p.telephone() == '+5-(569)-799-1634'
    assert p.telephone('+# (###) ###-####') == '+7 (971) 743-9167'
    assert p.telephone(mask='+# (###) ###-####', placeholder='@') == '+7 (971) 743-9167'
    assert p.telephone(mask='+# (###) ###-####', placeholder='#') == '+# (###) ###-####'
    assert p.telephone(mask='+# (###) ###-####', placeholder='@@@') == '+7 (971) 743-9167'

# Generated at 2022-06-21 16:35:31.389464
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person().political_views() in POLITICAL_VIEWS



# Generated at 2022-06-21 16:35:34.318162
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    """Test for social_media_profile."""
    provider = Person()

    for _ in range(100):
        profile = provider.social_media_profile()
        assert len(profile) > 5


# Unit tests for method telephone of class Person

# Generated at 2022-06-21 16:35:39.350192
# Unit test for method password of class Person
def test_Person_password():
    person = Fake('uk_UA').person

    password = person.password()
    assert type(password) == str
    assert len(password) == 8

    password = person.password(hashed=True)
    assert type(password) == str
    assert len(password) == 32

    password = person.password(length=20)
    assert type(password) == str
    assert len(password) == 20

    password = person.password(length=20, hashed=True)
    assert type(password) == str
    assert len(password) == 32

# Generated at 2022-06-21 16:35:41.673949
# Unit test for method email of class Person
def test_Person_email():
    # Test the Person.email() method
    person = Person()
    email = person.email()
    assert '@' in email

# Generated at 2022-06-21 16:35:44.866841
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    for i in range(100):
        name = person.name()

        assert name



# Generated at 2022-06-21 16:36:25.533902
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    assert person.social_media_profile(site='facebook') == 'https://facebook.com/some_user'
    assert person.social_media_profile(site='twitter') == 'https://twitter.com/some_user'
    assert person.social_media_profile(site='reddit') == 'https://reddit.com/some_user'

test_Person_social_media_profile()

 

# Generated at 2022-06-21 16:36:27.747685
# Unit test for method weight of class Person
def test_Person_weight():
    for _ in range(100):
        assert Person().weight(minimum=0, maximum=1000) >= 0
        assert Person().weight(minimum=0, maximum=1000) <= 1000


# Generated at 2022-06-21 16:36:29.208264
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname(Person()) != "", "WTF?"
    # Unit test for method name of class Person

# Generated at 2022-06-21 16:36:37.859550
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person()
    result = person.political_views()
    assert result in PERSON_POLITICAL_VIEWS
PERSON_WORLDVIEWS = ('Agnosticism', 'Atheism', 'Buddhism', 'Christianity', 'Confucianism', 'Hinduism', 'Islam', 'Judaism', 'Neopaganism', 'Pantheism', 'Scientology', 'Shintoism', 'Spiritualism', 'Taoism', 'Tenrikyo', 'Unitarianism', 'Zoroastrianism')

# Generated at 2022-06-21 16:36:40.409007
# Unit test for method gender of class Person
def test_Person_gender():
    print('\n\n>>> Unit test for method gender of class Person:')
    p = Person()
    gender = p.gender()
    print(gender)

# Generated at 2022-06-21 16:36:48.232978
# Unit test for constructor of class Person
def test_Person():
    p = Person()

    assert isinstance(p.name(), str)
    assert isinstance(p.first_name(), str)
    assert isinstance(p.last_name(), str)
    assert isinstance(p.full_name(), str)
    assert isinstance(p.username(), str)
    assert isinstance(p.password(), str)
    assert isinstance(p.email(), str)
    assert isinstance(p.social_media_profile(), str)
    assert isinstance(p.gender(), str)
    assert isinstance(p.sex(), str)
    assert isinstance(p.height(), str)
    assert isinstance(p.weight(), int)
    assert isinstance(p.blood_type(), str)
    assert isinstance(p.sexual_orientation(), str)

# Generated at 2022-06-21 16:36:51.708917
# Unit test for method title of class Person
def test_Person_title():
    person = Person(locale='ru')
    female_title = person.title(gender=Gender.female)

    assert female_title in person.data['title']['female']


# Generated at 2022-06-21 16:37:00.982539
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from faker.providers.person import Provider as PersonProvider
    from faker.providers.social_network import Provider as SocialNetworkProvider
    from faker.providers.en_US.en_US_person import en_USProvider as PersonProvider_en_US, Provider as SocialNetworkProvider_en_US

    faker = Faker()
    faker.add_provider(PersonProvider)
    faker.add_provider(SocialNetworkProvider)
    faker.add_provider(PersonProvider_en_US)
    faker.add_provider(SocialNetworkProvider_en_US)

    # Test US locale
    test_locale("en_US")
    faker.seed(0)
    assert faker.social_media_profile(SocialNetwork.FACEBOOK) == "https://facebook.com/davis47"


# Generated at 2022-06-21 16:37:05.779397
# Unit test for method views_on of class Person
def test_Person_views_on():

    random_int = randint(0, len(Person.views_on.__doc__))
    expected = Person.views_on(random_int)

    assert isinstance(expected, views_on)
    assert expected == ViewsOn(random_int)


# Generated at 2022-06-21 16:37:07.459979
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    assert person.telephone()

# Generated at 2022-06-21 16:38:25.689735
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person(random=Random())
    gt = p.weight(38, 90)
    gt_val = range(38, 90)
    
    assert gt in gt_val, 'Should be within range'


# Generated at 2022-06-21 16:38:27.577936
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    degree = person.academic_degree()
    assert isinstance(degree, str)
    assert degree in person._data['academic_degree']