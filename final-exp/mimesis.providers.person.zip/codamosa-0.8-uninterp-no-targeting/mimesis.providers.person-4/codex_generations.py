

# Generated at 2022-06-21 16:33:32.399107
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person(seed=0)
    assert person.sexual_orientation() == "Bisexuality"



# Generated at 2022-06-21 16:33:33.265445
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert isinstance(person.height(), str)

# Generated at 2022-06-21 16:33:36.041034
# Unit test for method identifier of class Person
def test_Person_identifier():
    method = getattr(Person, inspect.stack()[0][3])
    person = Person()
    assert len(method(person)) == 12

# Generated at 2022-06-21 16:33:37.462182
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    e = Person()
    assert callable(e.academic_degree)

# Generated at 2022-06-21 16:33:39.551685
# Unit test for method occupation of class Person
def test_Person_occupation():
    occupation = Person(random=MockRandom()).occupation()
    # occupation must be string
    assert isinstance(occupation, str)


# Generated at 2022-06-21 16:33:47.845473
# Unit test for method password of class Person
def test_Person_password():
    @given(strategies.lists(strategies.integers(), min_size=1, max_size=1))
    def test_Person_password_t(length):
        length = length[0]
        provider = Person(seed=12345)
        provider.password(length=length, hashed=True)

    test_Person_password_t()


# Generated at 2022-06-21 16:33:57.792996
# Unit test for method age of class Person
def test_Person_age():
    from hypothesis import given, example, settings
    from hypothesis.strategies import integers, tuples

    from vgen.core import Person, Settings

    @given(integers(min_value=0, max_value=150),
           integers(min_value=15, max_value=150),
           integers(min_value=1955, max_value=2000))
    @settings(max_examples=100)
    @example(19, 15, 1980)
    def test_age(age, min_age, year):
        person = Person(Settings(seed=42))
        assert person.age(min_age=min_age, year=year) == age
test_Person_age()

# Generated at 2022-06-21 16:34:01.885349
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Test method telephone of class Person
       because it is difficult to test a random function.
    """
    generator = Generator()
    person = Person(generator)
    # The length of our phone number is 12 + 2 = 14
    assert len(person.telephone()) == 14


# Generated at 2022-06-21 16:34:04.350455
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    Twitter = SocialNetwork.TWITTER
    assert Person.social_media_profile(Twitter) == 'https://twitter.com/some_user'



# Generated at 2022-06-21 16:34:14.805128
# Unit test for method username of class Person
def test_Person_username():
    def all_templates():
        return ['U.d', 'U_d', 'U-d', 'UU-d',
                'UU.d', 'UU_d', 'ld', 'l-d',
                'Ud', 'l.d', 'l_d']

    def all_splitter():
        return ['-', '.', '_']

    valid_templates = []
    for symbol in all_templates():
        for splitter in all_splitter():
            valid_templates.append('{}{}'.format(symbol, splitter))

    valid_templates.extend(all_templates())

    for template in valid_templates:
        user = Person().username(template=template)

# Generated at 2022-06-21 16:36:11.698842
# Unit test for method first_name of class Person
def test_Person_first_name():
    for i in range(1000):
        assert get_first_name()


# Generated at 2022-06-21 16:36:22.158446
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from faker.providers.date_time import Provider
    from datetime import datetime

    person = Person(random=Provider.random, locale='en')

    now = datetime.now()

    assert re.match(r'(\d{4}-)\d{4}', person.work_experience())
    assert re.match(r'(\d{4}-){2}\d{4}', person.work_experience(start=now))
    assert re.match(r'(\d{4}-){2}\d{4}',
                    person.work_experience(
                        start=now,
                        only_years=True,
                    ))

# Generated at 2022-06-21 16:36:26.285370
# Unit test for method name of class Person
def test_Person_name():
    @pytest.mark.parametrize('gender, value', [(Gender.MALE, 'Name'), (Gender.FEMALE, 'Name')])
    def should_return_name(gender, value):
        p = Provider(seed=123)
        assert p.name(gender) == value

    should_return_name()


# Generated at 2022-06-21 16:36:27.939851
# Unit test for method password of class Person
def test_Person_password():
    password = Person().password()
    assert len(password) == 8
    assert password[0] in ascii_letters

# Generated at 2022-06-21 16:36:30.455177
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert len(Person().identifier()) == len(Identifier().code())
    assert Person().identifier() == Identifier().code()
    assert Person().identifier(mask='##-##/##') == Identifier().code(mask='##-##/##')


# Generated at 2022-06-21 16:36:33.013512
# Unit test for method university of class Person
def test_Person_university():
    provider = Person(random=Random())
    for _ in range(100):
        university = provider.university()
        assert university in Person._data['university']

# Generated at 2022-06-21 16:36:35.688116
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert Person().first_name(Gender.FEMALE) in GIRLS


# Generated at 2022-06-21 16:36:39.589807
# Unit test for method language of class Person
def test_Person_language():
    seed = 0
    rnd = Random()
    rnd.seed(seed)

    pn = Person(seed=seed, random=rnd)
    language = pn.language()
    assert language == "Afrikaans"


# Generated at 2022-06-21 16:36:42.970135
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person.views_on() in Person._data['views_on']


# Generated at 2022-06-21 16:36:46.902870
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():

    # Test method social_media_profile with default argument.
    person = Person()
    assert person.social_media_profile()

    # Assert that method get random site.
    random_site = person.social_media_profile().split('/')[2]
    assert random_site in SOCIAL_NETWORKS.values()

    # Test method social_media_profile with non-default argument.
    assert person.social_media_profile(site='Facebook')

    # Test method social_media_profile with incorrect argument.
    try:
        person.social_media_profile(site='Facebook1')
    except NonEnumerableError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 16:38:01.957428
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert 'Bachelor' == Person.academic_degree()


# Generated at 2022-06-21 16:38:04.150726
# Unit test for method university of class Person
def test_Person_university():
    for _ in range(20):
        assert len(seed(1).person.university())

# Generated at 2022-06-21 16:38:05.394922
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    assert provider.email() != provider.email()


# Generated at 2022-06-21 16:38:07.143971
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    provider = PersonProvider(random=Random())
    value = provider.academic_degree()
    assert value in ('PhD', 'MA', 'BA', 'Bachelor', 'Master', 'Doctor',)


# Generated at 2022-06-21 16:38:08.627497
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person().work_experience()
if __name__ == '__main__':
    test_Person_work_experience()
 

# Generated at 2022-06-21 16:38:13.183262
# Unit test for method name of class Person
def test_Person_name():
    instance = Person(_=None)
    assert isinstance(instance.name(Gender.MALE), str)
    assert isinstance(instance.name(Gender.FEMALE), str)


# Generated at 2022-06-21 16:38:14.355074
# Unit test for method last_name of class Person
def test_Person_last_name():
    result = Person().last_name()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-21 16:38:17.850723
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person()
    p.random.seed(12345)
    work_exp = p.work_experience()

    assert work_exp == '2 years'



# Generated at 2022-06-21 16:38:20.460191
# Unit test for method last_name of class Person
def test_Person_last_name():
    from faker import Faker
    fake = Faker(seed=1)
    a = fake.last_name()
    assert a == 'Luettgen'


# Generated at 2022-06-21 16:38:26.682548
# Unit test for method worldview of class Person
def test_Person_worldview():
    rnd = random.Random()
    values = tuple(rnd.choices(['A', 'B', 'C', 'D'], weights=(2, 3, 4, 1), k=200))
    rnd.seed(1)
    
    persons = [Person(seed=1) for _ in range(len(values))]
    actual = tuple(person.worldview() for person in persons)
    expected = values
    assert actual == expected


# Generated at 2022-06-21 16:39:42.189510
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person()
    o = p.occupation()

    assert o, 'occupation() method is empty'
    assert len(o) >= 8, \
        'occupation() method should return at least 8 characters'


# Generated at 2022-06-21 16:39:51.333284
# Unit test for method title of class Person
def test_Person_title():
    # Get a random title
    title = Person().title()
    assert isinstance(title, str)
    print(title)

    # Get a random suffix title
    suffix = Person().title(title_type=TitleType.SUFFIX)
    assert isinstance(suffix, str)
    print(suffix)

    # Get a random prefix title
    prefix = Person().title(title_type=TitleType.PREFIX)
    assert isinstance(prefix, str)
    print(prefix)

    # Get a random prefix title for female
    prefix = Person().title(title_type=TitleType.PREFIX, gender=Gender.FEMALE)
    assert isinstance(prefix, str)
    print(prefix)

    # Get a random suffix title for female

# Generated at 2022-06-21 16:39:53.464387
# Unit test for constructor of class Person
def test_Person():
    from os.path import dirname, abspath, join

    path = join(dirname(abspath(__file__)), 'data')
    p = Person(path)
    assert p.path == path

# Generated at 2022-06-21 16:39:55.025577
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    for _ in range(100):
        assert Person().sexual_orientation() in SEXUALITY

# Generated at 2022-06-21 16:40:02.987816
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    assert person.username(template='UUd') == 'TD1973'
    assert person.username(template='ld') == 'h1899'
    assert person.username(template='l_d') == 'h_1899'
    assert person.username(template='l.d') == 'h.1899'
    assert person.username(template='UUd-d') == 'TD1973-6681'
    assert person.username(template='l-d') == 'h-1899'
    assert person.username(template='Ud') == 'U1973'
    assert person.username(template='U_d') == 'U_1973'
    assert person.username(template='U.d') == 'U.1973'
    assert person.username(template='l.d') == 'h.1899'

# Generated at 2022-06-21 16:40:09.653756
# Unit test for method height of class Person
def test_Person_height():
    p = Person('en')
    assert p.height() in [1.5, 1.6, 1.7, 1.8, 1.9, 2.0]
    assert p.height(maximum=1.9) in [1.5, 1.6, 1.7, 1.8, 1.9]
    assert 1.5 <= float(p.height()) <= 2.0
    assert 1.5 <= float(p.height(maximum=1.9)) <= 1.9
    
test_Person_height() # testing

# Generated at 2022-06-21 16:40:19.319358
# Unit test for method language of class Person
def test_Person_language():
    from . import Person, Gender

    # TEST 1: all languages
    languages = Person().languages()
    assert all(
        isinstance(lang, str)
        for lang in languages
    ) == True
    # TEST 2: men languages
    men_languages = Person().languages(gender=Gender.MALE)
    assert all(
        isinstance(lang, str)
        for lang in men_languages
    ) == True
    assert men_languages != languages
    # TEST 3: women languages
    women_languages = Person().languages(gender=Gender.FEMALE)
    assert all(
        isinstance(lang, str)
        for lang in women_languages
    ) == True
    assert women_languages != languages
    # TEST 4: empty list

# Generated at 2022-06-21 16:40:20.608027
# Unit test for method avatar of class Person
def test_Person_avatar():
    assert Person().avatar() != ''

# Generated at 2022-06-21 16:40:31.429045
# Unit test for method occupation of class Person

# Generated at 2022-06-21 16:40:35.467938
# Unit test for method worldview of class Person
def test_Person_worldview():
  from faker.providers.person import Provider
  from faker import Faker
  import pytest
  fake=Faker("en_IN")
  fake.add_provider(Provider)
  worldview=fake.worldview()
  assert worldview == worldview
