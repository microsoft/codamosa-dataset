

# Generated at 2022-06-21 16:31:51.301831
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name(gender={"MALE", "FEMALE"})
    assert Person().last_name(gender={"MALE", "FEMALE"})
    assert Person().last_name(gender={"MALE", "FEMALE"})


# Generated at 2022-06-21 16:31:55.490504
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    weight = [person.weight() for _ in range(100)]

    assert all(True for i in weight if 38 <= i <= 90)
    assert any(True for i in weight if i != weight[0])


# Generated at 2022-06-21 16:31:57.995746
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    blood_type = person.blood_type()
    assert isinstance(blood_type, str)

# Generated at 2022-06-21 16:32:08.211224
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    provider = Provider()
    """
    Test for method work_experience of class Person

    :return:
    """
    # Create a random object
    person_object = Person(provider, middle_name=True)

    # Create a random work-experience
    work_experience = person_object.work_experience()

    # Check if work-experience is a dictionary and has the correct keys
    assert isinstance(work_experience, dict)
    assert set(['company', 'position', 'period', 'description']) < set(work_experience)

    # Check if company is a string
    assert isinstance(work_experience['company'], str)
    # Check if position is a string
    assert isinstance(work_experience['position'], str)
    # Check if period is a string

# Generated at 2022-06-21 16:32:12.320710
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    language = person.language()
    print(language)
    assert language != ''
    
test_Person_language()


# Generated at 2022-06-21 16:32:17.574543
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Test case 1
    assert Person().social_media_profile(site=SocialNetwork.facebook) == 'https://facebook.com/{0}'.format(Person().username())

    # Test case 2
    assert Person().social_media_profile(site=SocialNetwork.telegram) == 'https://telegram.me/{0}'.format(Person().username())



# Generated at 2022-06-21 16:32:19.018732
# Unit test for method title of class Person
def test_Person_title():
    provider = Person()
    title = provider.title()
    assert title



# Generated at 2022-06-21 16:32:24.496489
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    assert provider.email() in [
        'awhitehead@gmail.com',
        'o.jensen@aol.com',
        'lsims@verizon.net',
        'k.eason@me.com',
        'kwilliams@me.com',
        'sreed@mac.com',
        'sgregory@gmail.com',
        'n.miller@sbcglobal.net',
        'tcoleman@aol.com',
        'kprice@comcast.net',
    ]


# Generated at 2022-06-21 16:32:31.764547
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    data = [str(Person().blood_type()) for _ in range(20)]
    assert data == ['O+', 'AB-', 'AB+', 'AB+', 'AB-', 'AB+', 'AB-', 'AB+', 'A-',
                    'A+', 'AB-', 'AB-', 'AB+', 'AB+', 'AB+', 'A+', 'O-', 'O+',
                    'AB+', 'AB+']



# Generated at 2022-06-21 16:32:42.353078
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    parser = get_parser()
    # Test case 1
    space = parser.parse_args(['Person', 'work_experience'])
    assert len(space.work_experience) == 2
    # Test case 2
    space = parser.parse_args(['Person', 'work_experience', '--minimum=10'])
    assert len(space.work_experience) == 10
    # Test case 3
    space = parser.parse_args(['Person', 'work_experience', '--maximum=50'])
    assert len(space.work_experience) == 50
    # Test case 4
    with pytest.raises(SystemExit):
        parser.parse_args(['Person', 'work_experience', '--minimum=10', '--maximum=1'])

# Generated at 2022-06-21 16:32:56.542518
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()

    for loop in range(100):
        r = p.gender(symbol=True)
        assert repr(r) == repr(chr(r))

# Generated at 2022-06-21 16:33:07.716134
# Unit test for method language of class Person
def test_Person_language():
    p = Person(seed = [2, 3, 1, 5, 4])
    lang = p.language()
    assert lang == 'Thai'

    p = Person(seed = [1, 2, 3, 4, 5])
    lang = p.language()
    assert lang == 'English'

    p = Person(seed = [3, 1, 4, 2, 5])
    lang = p.language()
    assert lang == 'Chinese'

    p = Person(seed = [4, 5, 2, 1, 3])
    lang = p.language()
    assert lang == 'French'

    p = Person(seed = [5, 4, 3, 2, 1])
    lang = p.language()
    assert lang == 'Spanish'

# Generated at 2022-06-21 16:33:13.449237
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from fake import Fake
    from fake.constants import DEFAULT_LANGUAGE
    from ..types import Provider

    fake = Fake(locale=DEFAULT_LANGUAGE)

    provider = Provider(fake, fake.random)

    provider.random.seed(0)

    result = provider.work_experience()

    # Assert the method returns a valid result
    assert result.get('employer')

    # Verify for correct generation
    assert result == provider.work_experience()



# Generated at 2022-06-21 16:33:18.064231
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in GENDER_CHOICES
    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert Person().gender(iso5218=True) in (0, 1, 2, 9)


# Generated at 2022-06-21 16:33:20.817495
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    username = p.last_name()
    assert isinstance(username, str)
    assert len(username) > 0
    assert ' ' not in username

# Generated at 2022-06-21 16:33:25.689907
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Factory.create('en')
    gender = Gender.MALE
    nationality = person.nationality(gender)
    assert(isinstance(nationality, str))
    assert(len(nationality) > 0)

if __name__ == '__main__':
    test_Person_nationality()
 

# Generated at 2022-06-21 16:33:29.841869
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person(seed=0)
    result = person.social_media_profile()
    result_example = 'http://twitter.com/8wvxnsk_'
    assert result == result_example

# Generated at 2022-06-21 16:33:34.408407
# Unit test for method first_name of class Person
def test_Person_first_name():
    from random import seed
    from pprint import pprint

    provider = Person(seed=3)
    results = provider.first_name(
        gender=Gender.FEMALE,
        minimum_length=5,
        maximum_length=5)
    pprint(results)
    # 'Madalyn'
    

test_Person_first_name()

# Generated at 2022-06-21 16:33:44.207542
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person.political_views('Buddhism') == 'Buddhism'
    assert Person.political_views('Socialism') == 'Socialism'
    assert Person.political_views('Communism') == 'Communism'
    assert Person.political_views('Monarchism') == 'Monarchism'
    assert Person.political_views('Theocracy') == 'Theocracy'
    assert Person.political_views('Atheism') == 'Atheism'
    assert Person.political_views('Rejection') == 'Rejection'
    assert Person.political_views('Secularism') == 'Secularism'
    assert Person.political_views('Anarchism') == 'Anarchism'
    assert Person.political_views('Anarcho-communism') == 'Anarcho-communism'

# Generated at 2022-06-21 16:33:46.042931
# Unit test for method email of class Person
def test_Person_email():
    obj = Person()
    assert obj.email() == 'foretime10@live.com'

# Generated at 2022-06-21 16:34:06.319388
# Unit test for method full_name of class Person
def test_Person_full_name():
    import pytest
    person = Person()
    result = person.full_name()
    assert result

test_Person_full_name()
result

if "person" in globals():
    del person
else:
    person = Person()
result

if "person" in globals():
    del person
try:
    result = Person().full_name()
except:
    pass
else:
    print(result)

if "person" in globals():
    del person
try:
    result = Person().full_name()
except:
    pass
else:
    print(result)

if "person" in globals():
    del person
try:
    result = Person().full_name()
except:
    pass
else:
    print(result)


# Generated at 2022-06-21 16:34:08.102449
# Unit test for method password of class Person
def test_Person_password():
    password = Person().password()

    assert isinstance(password, str)
    assert len(password) == 8


# Generated at 2022-06-21 16:34:10.929571
# Unit test for method surname of class Person
def test_Person_surname():
    x = Person()
    ran_sur = x.surname()
    test = str(type(ran_sur))
    assert test == "<class 'str'>"


# Generated at 2022-06-21 16:34:15.829501
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    assert person.sexual_orientation() in SEXUALITY_SYMBOLS
    assert person.sexual_orientation(symbol=True) in SEXUALITY_SYMBOLS
    assert person.sexual_orientation() in person._data['sexuality']
    assert person.sexual_orientation(symbol=True) in SEXUALITY_SYMBOLS



# Generated at 2022-06-21 16:34:23.346300
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person().work_experience() == 'less than 1 year'
    assert Person().work_experience() == 'less than 1 year'
    assert Person().work_experience() == '1-3 years'
    assert Person().work_experience() == '3-5 years'
    assert Person().work_experience() == '5-7 years'  
    assert Person().work_experience() == 'more than 7 years'

# Generated at 2022-06-21 16:34:24.638157
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    name = person.name()
    assert name in NAMES


# Generated at 2022-06-21 16:34:25.857218
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    assert p.height(1, 2)


# Generated at 2022-06-21 16:34:31.592943
# Unit test for method first_name of class Person
def test_Person_first_name():
    # Make a new instance of Person
    person = Person()
    # Get a person's first name
    first_name = person.first_name()
    print(first_name)
    # Check length of first_name
    assert len(first_name) >= 2
    # Check if first_name is a string
    assert isinstance(first_name, str)


# Generated at 2022-06-21 16:34:42.827470
# Unit test for method title of class Person
def test_Person_title():
    gender = Gender.MALE
    title_type = TitleType.PREFIX
    title = Person().title(gender, title_type)
    assert isinstance(title, str)
    assert title in PERSON_TITLE_MALE_PREFIX
    gender = Gender.FEMALE
    title_type = TitleType.PREFIX
    title = Person().title(gender, title_type)
    assert isinstance(title, str)
    assert title in PERSON_TITLE_FEMALE_PREFIX
    gender = Gender.MALE
    title_type = TitleType.SUFFIX
    title = Person().title(gender, title_type)
    assert isinstance(title, str)
    assert title in PERSON_TITLE_MALE_SUFFIX
    gender = Gender.FEMALE

# Generated at 2022-06-21 16:34:49.237375
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person().identifier('##-##') == '01-88'
    assert Person().identifier('@##-##') == 'a01-88'
    assert Person().identifier('##-@@') == '01-ab'
    assert Person().identifier('@##-@@') == 'a01-ab'
    # Cannot write digit and character in one placeholder.
    with pytest.raises(ValueError):
        Person().identifier('##-@#')
        
prs = Person()
assert isinstance(prs.identifier(), str)
assert prs.identifier() != prs.identifier()
assert len(prs.identifier()) == 8
assert prs.identifier()[2] == '-'
assert prs.identifier()[5] == '/'
print(prs.identifier())

# Unit

# Generated at 2022-06-21 16:35:01.398462
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person(seed=42)
    result = person.views_on()
    assert result == 'Positive'
    

# Generated at 2022-06-21 16:35:05.006985
# Unit test for method telephone of class Person
def test_Person_telephone():
    seed = b'Lorem Ipsum'
    rnd = Random()
    rnd.seed(seed)
    faker = Person(rnd=rnd)

    result = faker.telephone()
    assert result == '+7-(933)-168-03-36'

# Generated at 2022-06-21 16:35:07.391796
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    assert isinstance(p.sexual_orientation(), str)
    assert isinstance(p.sexual_orientation(symbol=True), str)


# Generated at 2022-06-21 16:35:12.825658
# Unit test for method age of class Person
def test_Person_age():
    person = Person()
    age_range = [0, 18, 27, 45, 65, 100]
    start = 0
    end = 0
    for i in age_range:
        end = i
        for _ in range(100):
            assert start <= person.age(start, end) <= end, "Wrong age!"
        start = end

# Generated at 2022-06-21 16:35:24.717960
# Unit test for method gender of class Person
def test_Person_gender():
    q = [
        (None, ['man', 'woman'], True),
        (Gender.MALE, ['man'], True),
        (Gender.FEMALE, ['woman'], True),
        (Gender.NOT_KNOWN, ['man', 'woman'], True),
        (Gender.NOT_APPLICABLE, ['man', 'woman'], True),
    ]

    for gender, expected, is_valid in q:
        if not is_valid:
            with pytest.raises(NonEnumerableError):
                Person(seed=42).gender(gender)
        else:
            gender_ = Person(seed=42).gender(gender)
            gender_ = gender_ if hasattr(gender_, 'lower') else str(gender_)
            assert gender_ in expected


# Generated at 2022-06-21 16:35:28.198822
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    from random_gen.main import random_gen
    p = random_gen.person()
    assert callable(p.sexual_orientation)


# Generated at 2022-06-21 16:35:29.997748
# Unit test for method university of class Person
def test_Person_university():
    person = Person(seed=11)

    assert person.university() == 'Harvard University'


# Generated at 2022-06-21 16:35:38.567268
# Unit test for method weight of class Person
def test_Person_weight():
    import pytest
    from hypothesis import given, settings
    from hypothesis import strategies as st

    settings.register_profile("ci", max_examples=200, deadline=None)
    settings.load_profile("ci")

    @given(minimum=st.integers(min_value=38, max_value=90),
           maximum=st.integers(min_value=38, max_value=90))
    @settings(deadline=None)
    @pytest.mark.parametrize("minimum, maximum", [
        (38, 90),
    ])
    def test_Person_weight_parametrized(minimum, maximum):
        value = Person.weight(minimum=minimum, maximum=maximum)
        assert minimum <= value <= maximum
    test_Person_weight_parametrized()



# Generated at 2022-06-21 16:35:42.953320
# Unit test for method worldview of class Person
def test_Person_worldview():
    generator = Person('en')
    for _ in range(100):
        worldview = generator.worldview()
        assert worldview in generator._data['worldview']
        print(worldview)
test_Person_worldview()


# Generated at 2022-06-21 16:35:45.611048
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()
    result = provider.telephone()
    #print(result)
    assert isinstance(result, str)
    assert len(result) > 6
 

# Generated at 2022-06-21 16:35:57.401091
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    res = person.work_experience()
    assert isinstance(res, str)
    assert res


# Generated at 2022-06-21 16:35:59.602458
# Unit test for method avatar of class Person
def test_Person_avatar():
    avatar = Person().avatar()
    assert avatar is not None, "The function returned None."
    assert avatar != '', "The function returned an empty string."


# Generated at 2022-06-21 16:36:00.554009
# Unit test for method language of class Person
def test_Person_language():
    assert 'English' in Person.language()

# Generated at 2022-06-21 16:36:04.147126
# Unit test for method first_name of class Person
def test_Person_first_name():
    first_name = Person().first_name()
    assert type(first_name).__name__ == 'str'
    assert first_name != ''
    assert len(first_name) >= 3
    assert first_name[0].isupper()



# Generated at 2022-06-21 16:36:11.144828
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from fake2db.providers.person import SocialNetwork

    pers = Person()

    site = pers.random.choice(list(SocialNetwork))
    assert pers.social_media_profile(site) == pers.social_media_profile(site.value)

    with pytest.raises(NonEnumerableError):
        pers.social_media_profile('')

    with pytest.raises(NonEnumerableError):
        pers.social_media_profile(999)

    with pytest.raises(NonEnumerableError):
        pers.social_media_profile('instagram')

# Generated at 2022-06-21 16:36:17.032825
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person(seed=42)
    random.seed(42)

# Generated at 2022-06-21 16:36:19.295915
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Test work_experience of class Person
    person = Person()
    work_experience = person.work_experience()
    assert work_experience >= 0

# Generated at 2022-06-21 16:36:28.062665
# Unit test for method username of class Person
def test_Person_username():
    username = Person.username()
    assert username
    assert isinstance(username, str)

    username = Person.username('U_d')
    assert username
    assert isinstance(username, str)
    assert username.count('_') == 1
    assert username[0].isupper()
    assert username[-1].isdigit()

    username = Person.username('U.d')
    assert username
    assert isinstance(username, str)
    assert username.count('.') == 1
    assert username[0].isupper()
    assert username[-1].isdigit()

    username = Person.username('U-d')
    assert username
    assert isinstance(username, str)
    assert username.count('-') == 1
    assert username[0].isupper()
    assert username[-1].isdigit()



# Generated at 2022-06-21 16:36:30.317799
# Unit test for method occupation of class Person
def test_Person_occupation():
    """Checking method occupation of class Person."""
    person = Person()

    def test_occupation(data):
        result = person.occupation()
        assert result in data

    test_occupation(person._data['occupation'])


# Generated at 2022-06-21 16:36:32.066015
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    assert 38 <= p.weight() <= 90
    assert isinstance(p.weight(), int)
    assert 38 <= p.weight(38, 90) <= 90


# Generated at 2022-06-21 16:36:44.971176
# Unit test for method occupation of class Person
def test_Person_occupation():
    if not PERSON.occupation():
        raise AssertionError("Person, occupation: Can't be empty.")

# Generated at 2022-06-21 16:36:46.724502
# Unit test for method worldview of class Person
def test_Person_worldview():
    from faker import Faker
    fake = Faker()
    fake.random.seed(0)
    assert fake.worldview() == 'God'



# Generated at 2022-06-21 16:36:57.660116
# Unit test for method name of class Person
def test_Person_name():
    provider = Person()
    #use gender = None -> gender = get_random_item(Gender, rnd=self.random) in Person.name()
    assert provider.name() in provider._data['name'][0] + provider._data['name'][1]
    #use gender = Gender.MALE
    assert provider.name(gender=Gender.MALE) in provider._data['name'][1]
    #use gender = Gender.FEMALE
    assert provider.name(gender=Gender.FEMALE) in provider._data['name'][0]
    #use gender = Gender.NOT_SURE
    assert provider.name(gender=Gender.NOT_SURE) in provider._data['name'][0] + provider._data['name'][1]
import pytest
#Unit test for method surname of class Person

# Generated at 2022-06-21 16:37:04.001105
# Unit test for method telephone of class Person
def test_Person_telephone():
    import random
    import string
    import doctest
    import pyfaker.locales.ru_RU.providers.person as person

    def get_random_string(length=10):
        letters = string.ascii_lowercase
        return str(''.join(random.choice(letters) for i in range(length)))

    _ = get_random_string
    args = [_(), _(), _(), _(), _(), _(), _(), _(), _(), _()]
    kwargs = {
        'mask': _(),
        'placeholder': _()
    }
    doctest.run_docstring_examples(person.Person.telephone, globals(), *args, **kwargs)


# Generated at 2022-06-21 16:37:12.695570
# Unit test for method surname of class Person
def test_Person_surname():
    """Verify that the Person class method surname()"""

    provider = Person(seed=0)

    # Valid

# Generated at 2022-06-21 16:37:15.103195
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person(random=Random())

    # Test all social network

    for key in SOCIAL_NETWORKS:
        profile = person.social_media_profile(key)
        assert profile.startswith('http')


# Generated at 2022-06-21 16:37:16.479995
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    p = Person(seed=0)
    assert p.academic_degree() == 'Bachelor'


# Generated at 2022-06-21 16:37:19.006740
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name() != Person().last_name()


# Generated at 2022-06-21 16:37:19.683140
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person


# Generated at 2022-06-21 16:37:29.572104
# Unit test for method gender of class Person
def test_Person_gender(): 
    faker = Faker()
    
    number = faker.random.randint(0, 10)
    for _ in range(number):
        gender1 = faker.gender()
        gender2 = faker.random.choice(['male', 'female'])
        assert gender1 in ['male', 'female']
        assert gender2 in ['male', 'female']
        
    number = faker.random.randint(0, 10)
    for _ in range(number):
        gender1 = faker.gender(symbol=True)
        assert gender1 in ['♂', '♀']
        
    number = faker.random.randint(0, 10)
    for _ in range(number):
        gender1 = faker.gender(iso5218=True)

# Generated at 2022-06-21 16:37:48.762778
# Unit test for method weight of class Person
def test_Person_weight():
    from Faker import Faker
    from random import seed, randint
    def test_method(seed_arg):
        seed_arg = seed_arg
        f = Faker(seed_arg)
        assert f.weight(38, 90) in range(38, 91)

    test_method(1)
    test_method(2)
    test_method(3)
    test_method(4)
    test_method(5)
    test_method(6)
    test_method(7)
    test_method(8)
    test_method(9)
    test_method(10)
    test_method(11)
    test_method(12)
    test_method(13)
    test_method(14)
    test_method(15)
    test_method(16)

# Generated at 2022-06-21 16:37:52.667071
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Test for method blood_type of class Person.
    from hypothesis import given, Settings

    from .strategies import person_strategy

    settings = Settings(max_examples=100)

    @given(person_strategy, settings=settings)
    def test_Person_blood_type(person: Person) -> None:
        """Test for method blood_type of class Person."""
        result = person.blood_type()
        assert isinstance(result, str)

    test_Person_blood_type()


# Generated at 2022-06-21 16:37:54.404937
# Unit test for method surname of class Person
def test_Person_surname():
    Personal = Person()
    assert (type(Personal.surname()) is str)

# Generated at 2022-06-21 16:38:01.240586
# Unit test for method identifier of class Person
def test_Person_identifier():
    answer = '07-97/04'
    assert Person().identifier() == answer
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()
test_Person_identifier()

# Generated at 2022-06-21 16:38:05.740610
# Unit test for method weight of class Person
def test_Person_weight():
    from collections import defaultdict
    from random import Random
    random = Random()
    random.seed(0)
    provider = Person(random)
    data = defaultdict(int)
    for _ in range(10000):
        data[provider.weight(38, 90)] += 1
    assert len(data) >= 45
    assert max(data.values()) - min(data.values()) < 100
    assert data[provider.weight(38, 90)] == 609
test_Person_weight()


# Generated at 2022-06-21 16:38:09.871706
# Unit test for method first_name of class Person
def test_Person_first_name():
    person, rnd = Person(), Random()
    rnd.set_seed(42)

    assert person.first_name(gender=Gender.MALE) == 'Владимир'
    assert person.first_name(gender=Gender.FEMALE) == 'Анастасия'

    rnd.set_seed()
    assert len(person.first_name(gender=Gender.MALE)) > 0
    assert len(person.first_name(gender=Gender.FEMALE)) > 0


# Generated at 2022-06-21 16:38:14.354942
# Unit test for method name of class Person
def test_Person_name():
    obj = Person()

    assert(obj.name(Gender.MALE).lower() in NAMES[Gender.MALE])
    assert(obj.name(Gender.FEMALE).lower() in NAMES[Gender.FEMALE])


# Generated at 2022-06-21 16:38:16.699374
# Unit test for method title of class Person
def test_Person_title():
    person = Person()

    for i in range(3):
        title_type = random.choice([TitleType.prefix, TitleType.suffix])
        gender = random.choice([Gender.female, Gender.male])

        title = person.title(title_type=title_type, gender=gender)
        print(title)



# Generated at 2022-06-21 16:38:18.247636
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    for degree in Person().academic_degree():
        assert degree in Person().academic_degree()


# Generated at 2022-06-21 16:38:21.373575
# Unit test for method occupation of class Person
def test_Person_occupation():
    from pydbgen import pydbgen
    myDB=pydbgen.pydb()
    data=myDB.occupation()
    print(data)

# Generated at 2022-06-21 16:38:36.796965
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person()

    # test default gender
    default_genders = [provider.gender() for _ in range(100)]
    assert set(default_genders).issubset(GENDER_TYPES)

    # test iso5218
    iso5218_genders = [provider.gender(iso5218=True) for _ in range(100)]
    assert set(iso5218_genders).issubset({0, 1, 2, 9})

    # test symbol
    symbol_genders = [provider.gender(symbol=True) for _ in range(100)]
    assert set(symbol_genders).issubset(GENDER_SYMBOLS)
    # Unit test for method sex of class Person


# Generated at 2022-06-21 16:38:39.488023
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(seed=1)
    assert person.surname() == 'Williams'
    assert person.last_name() == 'Williams'


# Generated at 2022-06-21 16:38:42.402944
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    for i in range(100):
        assert Person.academic_degree() in {"PhD", "Master",
                                            "Bachelor", "Doctor",
                                            "Candidate", "Associate Professor", "Professor"}


# Generated at 2022-06-21 16:38:48.704483
# Unit test for method username of class Person
def test_Person_username():
    seed = 32687
    provider = Person(seed=seed)

    # test default template
    assert provider.username() == 'carlos.1995'

    # test custom templates
    assert provider.username(template='U.d') == 'Bruno.2074'
    assert provider.username(template='U-d') == 'Carlos-1974'
    assert provider.username(template='UU-d') == 'Lana-2013'
    assert provider.username(template='UU.d') == 'Chava.2004'
    assert provider.username(template='UU_d') == 'Luz_2049'
    assert provider.username(template='ld') == 'joni.2055'
    assert provider.username(template='l-d') == 'jose-2009'

# Generated at 2022-06-21 16:38:58.142744
# Unit test for method telephone of class Person
def test_Person_telephone():
    from names import Person
    person = Person()
    assert person.telephone(mask="8-(###)-###-##-##") == '8-(356)-869-11-92'
    assert person.telephone(mask="+7-(###)-###-##-##") == '+7-(567)-526-87-21'
    assert person.telephone(mask="8-(###)-###-##-##") == '8-(567)-526-87-21'
    assert person.telephone(mask="+7-(###)-###-##-##") == '+7-(228)-769-48-82'
    assert person.telephone(mask="8-(###)-###-##-##") == '8-(228)-769-48-82'

# Generated at 2022-06-21 16:39:06.650273
# Unit test for method username of class Person
def test_Person_username():
    person = Person(seed=42)

    assert person.username(template=None) == 'bjt-34'
    assert person.username(template='l-d') == 'p-48'
    assert person.username(template='l.d') == 'j.79'
    assert person.username(template='U_d') == 'B_60'
    assert person.username(template='UU_d') == 'JW_42'
    assert person.username(template='UU_d') == 'JW_42'
    assert person.username(template='UUU_d') == 'JPZ_37'
    assert person.username(template='UUUU_d') == 'JEJO_72'
    assert person.username(template='UUUUU_d') == 'JWQQ_61'

# Generated at 2022-06-21 16:39:09.132999
# Unit test for method gender of class Person
def test_Person_gender():
    faker = Faker()
    gender = faker.gender()
    assert isinstance(gender, str)

# Generated at 2022-06-21 16:39:10.552883
# Unit test for method last_name of class Person
def test_Person_last_name():
    print(Person.last_name)
    print(Person.last_name() is not None)


# Generated at 2022-06-21 16:39:13.809180
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    """Test method academic_degree of class Person"""

    person = Person()
    assert person.academic_degree() in person._data['academic_degree']


# Generated at 2022-06-21 16:39:16.907581
# Unit test for method height of class Person
def test_Person_height():
    result = provider.Person.height()
    assert isinstance(result, str)
    assert isinstance(float(result), float)
    assert '0.00' <= result <= '3.00'

# Generated at 2022-06-21 16:39:35.144075
# Unit test for method avatar of class Person
def test_Person_avatar():
    def test_Person_avatar_size(size):
        assert re.fullmatch(r'https:\/\/api\.adorable\.io\/avatars\/[0-9]+\/[a-z0-9]+\.png',
                            Person.avatar(size)), "The avatar size is not like 256x256"
    # Test with random value
    size = random.randint(1, 256)
    test_Person_avatar_size(size)
    # Test with a particular value
    size = 256
    test_Person_avatar_size(size)


# Generated at 2022-06-21 16:39:43.073822
# Unit test for method age of class Person
def test_Person_age():
    """Unit test for method age of class Person."""
    for i in range(200):
        p = Person(seed=i)
        min_age = p.random.randint(MIN_AGE, MAX_AGE)
        max_age = min_age + p.random.randint(5, 50)
        age = p.age(minimum=min_age, maximum=max_age)
        assert age >= min_age
        assert age <= max_age

# Generated at 2022-06-21 16:39:45.621267
# Unit test for method weight of class Person
def test_Person_weight():
    g = Person()
    w = g.weight(minimum = 40, maximum = 100)
    print(w)
    assert 40 <= w <= 100


# Generated at 2022-06-21 16:39:46.749349
# Unit test for constructor of class Person
def test_Person():
    assert Person()

# Unit tests for method of class Person

# Generated at 2022-06-21 16:39:47.757516
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert p is not None

# Generated at 2022-06-21 16:39:48.786542
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert isinstance(Person().occupation(), str)


# Generated at 2022-06-21 16:39:54.910560
# Unit test for method gender of class Person
def test_Person_gender():
    
    from random import seed, choices
    seed(1)
    r = choices(range(-3, 3), k=100_000)
    
    from faker import Faker
    from faker.providers import Person
    f = Faker('en_US')
    f.add_provider(Person)
    
    for i in range(len(r)):
        data = f.gender(r[i])
        assert data in PERSON_GENDER
    assert True



# Generated at 2022-06-21 16:39:56.731369
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    result = p.surname()
    return result

# Generated at 2022-06-21 16:39:57.929662
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert type(person.height()) == str


# Generated at 2022-06-21 16:39:59.420889
# Unit test for method age of class Person
def test_Person_age():
    provider = Fake('en')
    sample = provider.age()
    assert type(sample) == int



# Generated at 2022-06-21 16:40:09.695720
# Unit test for method password of class Person
def test_Person_password():
    Person.password()

    # Test with argument
    Person.password(length=10, hashed=True)

    # Test without argument
    Person.password()

# Generated at 2022-06-21 16:40:12.592391
# Unit test for method username of class Person
def test_Person_username():
    # Given
    person = Person()
    # When
    username = person.username()
    # Then
    assert isinstance(username, str)
    assert username


# Generated at 2022-06-21 16:40:13.751720
# Unit test for method university of class Person
def test_Person_university():
    p = Person()
    p.university()


# Generated at 2022-06-21 16:40:15.577797
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person(random=Random())
    assert isinstance(person.sexual_orientation(), str)


# Generated at 2022-06-21 16:40:17.520684
# Unit test for method first_name of class Person
def test_Person_first_name():
    obj = Provider().person()
    assert obj.first_name()


# Generated at 2022-06-21 16:40:21.127008
# Unit test for method full_name of class Person
def test_Person_full_name():
    """Tests the Person class's method full_name"""
    person = Person()
    full_name = person.full_name()

    assert(isinstance(full_name, str))
    assert(len(full_name) > 1)
    assert(full_name.strip() == full_name)
    for word in full_name.split(' '):
        assert(len(word) > 0)


# Generated at 2022-06-21 16:40:24.081080
# Unit test for method language of class Person
def test_Person_language():
    # Test for method language of class Person
    assert len(Person().language()) == isinstance(Person().language(), str)
test_Person_language()


# Generated at 2022-06-21 16:40:34.395487
# Unit test for method title of class Person
def test_Person_title():
    person = Fake('en').person()
    assert person.title() == person.title()
    assert person.title() in person._data['title'][Gender.MALE.value]
    assert person.title(gender=Gender.MALE) in person._data['title'][Gender.MALE.value]
    assert person.title(gender=Gender.FEMALE) in person._data['title'][Gender.FEMALE.value]
    assert person.title(title_type=TitleType.prefix) in person._data['title'][Gender.MALE.value][TitleType.prefix.value]
    assert person.title(title_type=TitleType.suffix) in person._data['title'][Gender.MALE.value][TitleType.suffix.value]


# Generated at 2022-06-21 16:40:37.090566
# Unit test for method age of class Person
def test_Person_age():
    assert Person().age(minimum=6, maximum=6) == 6
    assert Person().age(minimum=15, maximum=20) in range(15, 20+1)
    assert Person().age(minimum=20, maximum=20) == 20

# Generated at 2022-06-21 16:40:48.923021
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person()
    full_name = p.full_name()
    for ch in full_name:
        assert ch in string.ascii_letters

# Generated at 2022-06-21 16:41:03.560571
# Unit test for method age of class Person
def test_Person_age():
    """Let's test the method age of class Person"""
    person = Person()
    for i in range(0, 100):
        age = person.age()
        assert isinstance(age, int)
        assert age > 0 and age < 100

# Generated at 2022-06-21 16:41:05.099758
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    languages = person.language()

    assert type(languages) is str


# Generated at 2022-06-21 16:41:07.747343
# Unit test for method name of class Person
def test_Person_name():
    person = Person(seed=42)
    assert person.name(Gender.male) == 'John'
    assert person.name(Gender.female) == 'Ruth'
    assert person.name() == 'Mabel'



# Generated at 2022-06-21 16:41:15.019920
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person('en')
    assert re.fullmatch('\d{2}-\d{2}/\d{2}', p.identifier('##-##/##'))
    assert re.fullmatch('\d{6}', p.identifier('######'))
    assert re.fullmatch('\w{2}-\w{2}/\w{2}', p.identifier('@@-@@/##'))
    assert re.fullmatch('\w{1}-\w{2}/\w{2}', p.identifier('@-@@/##'))



# Generated at 2022-06-21 16:41:17.413020
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(100):
        worldview = Person.worldview()
        assert worldview in worldviews



# Generated at 2022-06-21 16:41:23.820775
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    assert person.title(title_type=TitleType.PREFIX) in person._data['title']['all']['prefix']
    assert person.title(title_type=TitleType.SUFFIX) in person._data['title']['all']['suffix']
    assert person.title(title_type=TitleType.PREFIX, gender=Gender.MALE) in person._data['title']['male']['prefix']
    assert person.title(title_type=TitleType.SUFFIX, gender=Gender.MALE) in person._data['title']['male']['suffix']
    assert person.title(title_type=TitleType.PREFIX, gender=Gender.FEMALE) in person._data['title']['female']['prefix']