

# Generated at 2022-06-21 16:31:48.556839
# Unit test for method height of class Person
def test_Person_height():
    rvs = [Person(random_state=random.Random()).height(minimum=1.5, maximum=2.0) for _ in range(1000)]
    assert 0.01 < stats.hmean(rvs) < 1.5

# Generated at 2022-06-21 16:31:50.944764
# Unit test for method surname of class Person
def test_Person_surname():
    """Test method surname of class Person."""
    # Setup
    person = Person()

    # Exercise
    result = person.surname()

    # Verify
    assert isinstance(result, str)

# Generated at 2022-06-21 16:31:52.499401
# Unit test for method height of class Person
def test_Person_height():
    person = Person('en')


# Generated at 2022-06-21 16:31:55.284555
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(100):
        worldview = Person().worldview()
        assert isinstance(worldview, str)



# Generated at 2022-06-21 16:31:57.416747
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()
    assert worldview in WORLD_VIEWS



# Generated at 2022-06-21 16:32:05.420261
# Unit test for method telephone of class Person
def test_Person_telephone():
    for _ in range(10):
        obj = Person()
        assert re.match(r'^\+\d{1,3}\-\(\d{3}\)\-\d{3}\-\d{4}$',
                        obj.telephone(),
                        ) is not None, 'Phone number does not match the template.'
        assert re.match(r'^\d{2}\-\d{2}\/\d{2}$',
                        obj.telephone('##-##/##'),
                        ) is not None, 'Phone number does not match the template.'

# Generated at 2022-06-21 16:32:07.024196
# Unit test for method name of class Person
def test_Person_name():
    assert Person(seed=0).name(Gender.MALE) == 'Johann'


# Generated at 2022-06-21 16:32:08.209446
# Unit test for method email of class Person
def test_Person_email():
    assert len(Person().email().split('@')) == 2

# Generated at 2022-06-21 16:32:09.326331
# Unit test for method password of class Person
def test_Person_password():
    pass
    

# Generated at 2022-06-21 16:32:20.887344
# Unit test for method identifier of class Person
def test_Person_identifier():
    provider = Person(seed=1)
    assert provider.identifier() == '0-5/0'
    assert provider.identifier(mask='###-##/##') == '2-2/9'
    assert provider.identifier(mask='##-#/##') == '4-4/8'
    assert provider.identifier(mask='#######') == '8366026'
    assert provider.identifier(mask='###-##-####') == '8-8-1533'
    assert provider.identifier(mask='## @###') == '9 B464'
    assert provider.identifier(mask='## @##') == '4 E63'
    assert provider.identifier(mask='## @## @#') == '5 P7 N1'

# Generated at 2022-06-21 16:32:29.605787
# Unit test for method height of class Person
def test_Person_height():
    person = Person(random = MockRandom(1.0))
    assert(person.height() == '1.00')

# Generated at 2022-06-21 16:32:39.923557
# Unit test for constructor of class Person
def test_Person():
    from pydantic import ValidationError
    from faker import Faker
    from faker.providers.person import Gender

    # Test for correct initialization.
    faker = Faker()
    assert "Person" in faker.providers
    assert "Person" in faker.__providers__
    assert isinstance(faker.person, PersonProvider)
    assert isinstance(faker.random, Random)
    assert faker.random is faker.person.random

    # Test for incorrect initialization.
    try:
        Faker(random=20)
    except TypeError:
        pass
    else:
        assert False, "Incorrect initialization of constructor."

    # Test for correct seed.
    faker = Faker(seed=0)
    assert 'Johann Griesser' == faker.person.full_name()

# Generated at 2022-06-21 16:32:44.324058
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person(seed=0)
    result = person.academic_degree()

    assert result == 'Bachelor'
test_Person_academic_degree()

# Generated at 2022-06-21 16:32:52.929145
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    assert p.identifier() == '23-80/39'
    assert p.identifier() == '08-50/52'
    assert p.identifier() == '51-04/85'
    assert p.identifier() == '79-09/05'
    assert p.identifier() == '85-99/63'
    assert p.identifier() == '35-06/96'
    assert p.identifier() == '90-02/37'
    assert p.identifier() == '41-22/41'
    assert p.identifier() == '65-24/91'
    assert p.identifier() == '16-05/34'



# Generated at 2022-06-21 16:32:58.028118
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    for _ in range(100):
        # Check that result is not empty
        assert person.sexual_orientation() is not None
        # Check that result is not empty
        assert person.sexual_orientation(symbol=True) is not None

# Generated at 2022-06-21 16:33:00.579059
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person().political_views() in POLITICAL_VIEWS
test_Person_political_views()

# Generated at 2022-06-21 16:33:05.944007
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    result = p.identifier(mask='##-##/##')
    assert result in ['56-76/81']


if __name__ == "__main__":
    p = Person()
    print(p.identifier())
    print(p.full_name(reverse=True))
    print(p.username(template='Ud'))

# Generated at 2022-06-21 16:33:07.703970
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    fake = Faker(seed=21)
    for _ in range(100):
        degree = fake.academic_degree()
        assert degree in ACADEMIC_DEGREE

# Generated at 2022-06-21 16:33:09.402333
# Unit test for method telephone of class Person
def test_Person_telephone():
    pr = Person('RU')
    assert pr.telephone(mask='+7 (###) ###-##-##') == '+7 (769) 541-64-66'

# Generated at 2022-06-21 16:33:16.962740
# Unit test for constructor of class Person
def test_Person():
    import pytest

    with pytest.raises(ValueError):
        Person(seed=100)

    with pytest.raises(ValueError):
        Person(seed='100')

    with pytest.raises(ValueError):
        Person(seed=None, locale=None)

    # Test values for person
    test_person = Person()
    assert test_person.seed == 'test seed'
    assert test_person.locale == 'en_US'
    assert test_person.random.seed == 'test seed'



# Generated at 2022-06-21 16:33:30.777668
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person.full_name(None) == 'Tristan Jordan'

# Generated at 2022-06-21 16:33:32.463219
# Unit test for method sex of class Person
def test_Person_sex():
    provider = Person()
    assert provider.sex() in ('Male', 'Female', 'Not known', 'Not applicable')

# Generated at 2022-06-21 16:33:39.827370
# Unit test for method gender of class Person
def test_Person_gender():
    obj = Person(seed=5)

    exp_0 = 'Male'
    obj_0 = obj.gender()
    assert_equal(obj_0, exp_0)

    exp_1 = 'Male'
    obj_1 = obj.gender()
    assert_equal(obj_1, exp_1)

    exp_2 = 1
    obj_2 = obj.gender(iso5218=True)
    assert_equal(obj_2, exp_2)

    exp_3 = '♂'
    obj_3 = obj.gender(symbol=True)
    assert_equal(obj_3, exp_3)

# Generated at 2022-06-21 16:33:44.074630
# Unit test for method worldview of class Person
def test_Person_worldview():
    result = Person.worldview()
    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-21 16:33:48.515936
# Unit test for method work_experience of class Person
def test_Person_work_experience():

  # Get a random work experience
  work_experience = Person.work_experience()

  # Check that work experience is in list of work experience
  assert work_experience in Person._data['work_experience']

# Generated at 2022-06-21 16:33:51.912194
# Unit test for method height of class Person
def test_Person_height():
    some_person = Person()
    result = some_person.height()
    assert isinstance(result, str)
    assert len(result) >= 1
    assert len(result) <= 4
    assert result[0] == "1"


# Generated at 2022-06-21 16:33:53.791909
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    provider = EntityProvider(random=Random())
    value = provider.academic_degree()

    assert isinstance(value, str)
assert len(test_Person_academic_degree.__doc__) > 10

# Generated at 2022-06-21 16:33:55.448372
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    assert p.views_on() == 'Positively'

# Generated at 2022-06-21 16:34:01.850320
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    assert person.telephone()
    assert person.telephone('#-#-#-#')
    assert person.telephone('#-###-###')
    assert person.telephone('+7-(###)###-##-##')
    assert person.telephone('(###)###-##-##')
test_Person_telephone()

# Generated at 2022-06-21 16:34:10.167132
# Unit test for method username of class Person
def test_Person_username():
    
    person = Person()
    

# Generated at 2022-06-21 16:34:33.994945
# Unit test for method title of class Person
def test_Person_title():
    person = Person(random=Random())
    assert isinstance(person.title(gender=Gender.male), str)


# Generated at 2022-06-21 16:34:39.288402
# Unit test for method username of class Person
def test_Person_username():
    """Test Person.username() method"""

    p = Person(seed=0)

    # Template with one "U" & no separators
    assert p.username(template='U') == 'R'
    assert p.username(template='U') == 'Q'

    # Template with one "U" & separators
    assert p.username(template='U.') == 'T.'
    assert p.username(template='U.') == 'A.'
    assert p.username(template='U-') == 'X-'
    assert p.username(template='U-') == 'M-'
    assert p.username(template='U_') == 'X_'
    assert p.username(template='U_') == 'M_'

    # Template with multiple "U"
    assert p.username(template='UU') == 'FQ'
   

# Generated at 2022-06-21 16:34:41.873553
# Unit test for method weight of class Person
def test_Person_weight():
    for i in range(100):
        assert Person.weight(38, 90) <= 90
        assert Person.weight(38, 90) >= 38


# Generated at 2022-06-21 16:34:45.421536
# Unit test for constructor of class Person
def test_Person():
    """
    >>> import random
    >>> p = Person(random.Random())
    >>> p1 = Person()
    >>> isinstance(p.random, random.Random)
    True
    >>> isinstance(p1.random, random.Random)
    True
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 16:34:51.090065
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    assert isinstance(avatar, str)
    assert re.match(
        r'^(http|https)\:\/\/api\.adorable\.io\/avatars\/[0-9]+\/[a-z0-9]{32}\.png$',
        avatar
    )


# Generated at 2022-06-21 16:34:59.877766
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    assert provider.email() == 'gracious69@sbcglobal.net'
    assert provider.email(unique=True) == '0a0f0a04@live.nl'
    assert provider.email(domains=(
        'mydomain.com', 'yourdomain.com', 'hisdomain.com'
    )) == 'k.smith@hisdomain.com'
    assert provider.email(domains=('@vk.com', '@facebook.com')) == \
        'trevor.green@facebook.com'
    provider.localize(locale='uk')
    assert provider.email() == 'odarka92@ukr.net'
    provider.localize(locale='uk_UA')
    assert provider.email() == 'odarka92@ukr.net'



# Generated at 2022-06-21 16:35:11.570686
# Unit test for method first_name of class Person
def test_Person_first_name():

    generator = Generator()
    person = Person()

    for _ in range(100):
        assert person.first_name() in person._data['name'][Gender.male]
        assert person.first_name(gender=Gender.male) in person._data['name'][Gender.male]
        assert person.first_name(gender=Gender.female) in person._data['name'][Gender.female]

    for _ in range(100):
        assert person.first_name(gender=generator.random.choice(list(Gender))) in person._data['name'][Gender.female]

    # Test for ``name_male`` property.
    name = person.first_name(gender=Gender.male)
    assert name in person._data['name'][Gender.male]
    assert name == person.name_male

    # Test for ``name

# Generated at 2022-06-21 16:35:14.302766
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    print("work_experience")
    random.seed(2)
    Provider = Person(random)
    assert Provider.work_experience() == '10 years, 6 months'


# Generated at 2022-06-21 16:35:25.561735
# Unit test for method email of class Person
def test_Person_email():
    p = Person(seed=123)
    assert p.email() == 'vowen9@live.com'
    assert p.email() == 'hspears4@live.com'
    assert p.email() == 'tjohnson5@live.com'
    assert p.email() == 'msimpson1@live.com'
    assert p.email() == 'mjackson7@live.com'
    assert p.email() == 'gberner0@live.com'
    assert p.email() == 'mthomas0@live.com'
    assert p.email() == 'sharris67@live.com'
    assert p.email() == 'jwilson3@live.com'
    assert p.email() == 'pbell8@live.com'

# Generated at 2022-06-21 16:35:28.728427
# Unit test for method password of class Person
def test_Person_password():
    p = Person(random.Random(0))
    assert p.password() == '\x82\x84\x91\xfc\x99\xa8\xcc\x0b'

# Generated at 2022-06-21 16:36:50.749402
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()
    for _ in range(10):
        phone = provider.telephone()
        assert isinstance(phone, str)
        assert len(phone) > 0
test_Person_telephone()



# Generated at 2022-06-21 16:36:57.928765
# Unit test for method email of class Person
def test_Person_email():
    vk = Faker(seed=42)
    a = vk.email()
    # '69@falconfanatics.com'
    assert a == '69@falconfanatics.com'
    vk.seed(42)
    a = vk.email()
    b = vk.email()
    assert a == '69@falconfanatics.com'
    assert a == b
    assert a == '69@falconfanatics.com'
    assert b == '69@falconfanatics.com'


# Generated at 2022-06-21 16:37:04.753687
# Unit test for method name of class Person
def test_Person_name():
    rnd = Random()
    #
    # Input data suite
    #

# Generated at 2022-06-21 16:37:08.550971
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Initialize the class with a fixed seed
    obj = Person(seed = 1)
    # Get random value
    result = obj.views_on()
    # Check if the random value is "Agree"
    assert result == 'Agree'

# Generated at 2022-06-21 16:37:11.001102
# Unit test for method sex of class Person
def test_Person_sex():
    assert Person.sex(None) in [0, 1, 2, 9]
    assert Person.sex(True) in ['♂', '♀']
    assert Person.sex() in ['Male', 'Female']


# Generated at 2022-06-21 16:37:12.078114
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in get_data('views_on')
