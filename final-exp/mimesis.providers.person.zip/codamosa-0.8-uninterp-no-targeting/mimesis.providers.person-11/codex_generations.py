

# Generated at 2022-06-21 16:31:45.667551
# Unit test for method first_name of class Person
def test_Person_first_name():
    # Create an instance of the class Person
    person = Person()
    # Create a variable 'first_name' and set a random first name
    first_name = person.first_name()
    # Check if the length of variable 'first_name' is less than 32
    if len(first_name) <= 32:
        # Print a message and the value of variable 'first_name'
        print('SUCCESS: test_Person_first_name()')
        print('> first_name:', first_name)
    else:
        # Print a message and the value of variable 'first_name'
        print('ERROR: test_Person_first_name()')
        print('> first_name:', first_name)

# Generated at 2022-06-21 16:31:48.799081
# Unit test for method email of class Person
def test_Person_email():
    @given(m=st.text())
    def email_should_have_some_domain(m):
        provider = Person()
        email = provider.email(m)
        assert email.split('@')[1] in m

    email_should_have_some_domain()

# Generated at 2022-06-21 16:31:53.589908
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person()
    assert isinstance(p.work_experience(), list) == True
    assert len(p.work_experience()) == 1
    assert isinstance(p.work_experience()[0], dict) == True


# Generated at 2022-06-21 16:31:57.417100
# Unit test for method sex of class Person
def test_Person_sex():
    from faker_ru import RU

    f = RU()
    sex = f.sex()
    assert sex in ('Мужской', 'Женский')



# Generated at 2022-06-21 16:32:07.715414
# Unit test for method occupation of class Person
def test_Person_occupation():
    from string import ascii_lowercase
    from datetime import datetime
    from faker.providers.person.en import Provider
    
    # Make instance of Person class
    provider = Provider(local='en_US')

    # Make a set of occupations
    occupations = set([provider.occupation() for _ in range(1000)])
    
    # Make a set of occupations
    occupations_test = set([provider.occupation() for _ in range(1000)])

    # Make a list of occupations
    occupations_list = [i.lower() for i in occupations]

    # Make a list of occupations
    occupations_test_list = [i.lower() for i in occupations_test]

    # Make a string of occupations
    occupations_string = ''.join(sorted(occupations_list))

    # Make a string of

# Generated at 2022-06-21 16:32:12.266854
# Unit test for method gender of class Person
def test_Person_gender():
    p = Person()
    for _ in range(100):
        assert isinstance(p.gender(), str)
        assert isinstance(p.gender(iso5218=True), int)

# Generated at 2022-06-21 16:32:13.420202
# Unit test for method worldview of class Person
def test_Person_worldview():
    Person.worldview()

# Generated at 2022-06-21 16:32:14.918752
# Unit test for method email of class Person
def test_Person_email():
    assert Person.email() == 'coolforetime10@live.com'



# Generated at 2022-06-21 16:32:19.574613
# Unit test for method surname of class Person
def test_Person_surname():
    # Test for integer argument
    try:
        # Test if argument is integer or not
        if isinstance(1, int):
            Person.surname(1)
    except NonEnumerableError:
        # Test case failed if exception was raised
        assert True
    else:
        # Test case failed if exception was not raised
        assert False


# Generated at 2022-06-21 16:32:22.214451
# Unit test for method political_views of class Person
def test_Person_political_views():
    # Arrange
    person = Faker(locale='en')
    # Act
    result = person.political_views()
    # Assert
    assert result in PERSON_POLITICAL_VIEWS_EN

# Generated at 2022-06-21 16:32:29.383342
# Unit test for method university of class Person
def test_Person_university():
    assert isinstance(Person().university(), str)


# Generated at 2022-06-21 16:32:31.767073
# Unit test for method political_views of class Person
def test_Person_political_views():
    actual = Person().political_views()
    expected = random.choice(Person()._data['political_views'])
    assert actual == expected

# Generated at 2022-06-21 16:32:33.992957
# Unit test for method views_on of class Person
def test_Person_views_on():
    obj = Person()
    result = obj.views_on()
    assert result in PERSON_VIEWS_ON

# Generated at 2022-06-21 16:32:36.864736
# Unit test for method occupation of class Person
def test_Person_occupation():
    from speaklater import _LazyString    
    from faker import Faker
    fake = Faker()
    if isinstance(fake.occupation(), str):
        assert True
    else:
        assert False
    if isinstance(fake.occupation(), _LazyString):
        assert True
    else:
        assert False

##Unit test for method political_views of class Person

# Generated at 2022-06-21 16:32:41.691949
# Unit test for method age of class Person
def test_Person_age():
    for seed in range(10):
        random.seed(seed)
        person = Person(seed=seed)
        from_date = datetime.utcnow().date() - timedelta(days=365 * 20)
        to_date = datetime.utcnow().date() - timedelta(days=365 * 30)
        assert person.age(from_date=from_date, to_date=to_date) == random.choice(range(20, 30))



# Generated at 2022-06-21 16:32:47.461309
# Unit test for method views_on of class Person
def test_Person_views_on():
    # arrange
    NUMBER_OF_TEST = 10
    people = Person()

    # act
    views = []
    for _ in range(NUMBER_OF_TEST):
        views.append(people.views_on())

    # assert
    assert set(views) == {'Neutral',
                          'Positive',
                          'Negative'}

# Generated at 2022-06-21 16:32:50.495187
# Unit test for method username of class Person
def test_Person_username():
    print("\n===== TEST 1 =====")
    p = Person(seed=0)
    print("p.username(template='U_d'):", p.username(template='U_d'))


# Generated at 2022-06-21 16:32:57.512305
# Unit test for method title of class Person
def test_Person_title():
    person = Fake.create()
    assert type(person.title(gender=None)) == str
    assert type(person.title(gender=Gender.MALE)) == str
    assert type(person.title(gender=Gender.FEMALE)) == str
    assert type(person.title(gender=Gender.NOT_APPLICABLE)) == str
    assert type(person.title(gender=Gender.NOT_KNOWN)) == str
    
    
    assert type(person.title(gender=None,title_type=None)) == str
    assert type(person.title(gender=Gender.MALE,title_type=TitleType.PREFIX)) == str
    assert type(person.title(gender=Gender.FEMALE,title_type=TitleType.SUFFIX)) == str

# Generated at 2022-06-21 16:33:06.194191
# Unit test for method age of class Person
def test_Person_age():
    p = Person()
    p.age = 0
    assert p.age == 0
    p.age = 10
    assert p.age == 10
    p.age = 20
    assert p.age == 20
    p.age = 30
    assert p.age == 30
    p.age = 40
    assert p.age == 40
    p.age = 50
    assert p.age == 50
    p.age = 60
    assert p.age == 60
    p.age = 70
    assert p.age == 70
    p.age = 80
    assert p.age == 80
    p.age = 90
    assert p.age == 90
    p.age = 100
    assert p.age == 100
    p.age = 110
    assert p.age == 110
    p.age = 120

# Generated at 2022-06-21 16:33:16.675477
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    gen = Person()

    result = gen.social_media_profile()
    assert re.fullmatch(r'^https?://\w+\.com/\w+$', result)

    result = gen.social_media_profile(site=SocialNetwork.Twitter)
    assert re.fullmatch(r'^https?://twitter\.com/\w+$', result)

    result = gen.social_media_profile(site=SocialNetwork.Instagram)
    assert re.fullmatch(r'^https?://instagram\.com/\w+$', result)

    result = gen.social_media_profile(site=SocialNetwork.Facebook)
    assert re.fullmatch(r'^https?://facebook\.com/\w+$', result)

    result = gen.social_media_profile(site=SocialNetwork.GooglePlus)


# Generated at 2022-06-21 16:33:27.449558
# Unit test for method height of class Person
def test_Person_height():
    print('Test method height of class Person')
    for _ in range(4):
        min_height = 1.50
        max_height = 2.00
        height = Person().height(min_height, max_height)
        print(height)
        assert isinstance(height, str)

# Generated at 2022-06-21 16:33:30.083016
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person()
    gender = provider.gender()
    expected_values = ['Male', 'Female']
    assert gender in expected_values

# Generated at 2022-06-21 16:33:31.792296
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    assert person.academic_degree() in person._data['academic_degree']

# Generated at 2022-06-21 16:33:33.833788
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person().identifier(mask='##-##/##') == '07-97/04'
    
    

# Generated at 2022-06-21 16:33:36.038699
# Unit test for method political_views of class Person
def test_Person_political_views():
    """ Unit test for method political_views of class Person """
    assert Person().political_views() in POLITICAL_VIEWS

# Generated at 2022-06-21 16:33:37.109127
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person(random=Random())
    assert provider.telephone()

# Generated at 2022-06-21 16:33:39.745751
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Call method views_on of class Person
    result = Person().views_on()

    # Check that result is an instance of str class
    assert(isinstance(result, str))


# Generated at 2022-06-21 16:33:52.664417
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    state = {
        "decimal": 0,
        "path": "tests/fixtures/work_experience.json",
        "dict": {
            "type": "dict",
            "schema": {
                "experience": {"type": "int"}
            }
        },
        "factories": [
            {
                "factory": "tests.fixtures.experience_factory.ExperienceFactory",
                "kwargs": {
                    "min_years": "min_years",
                    "max_years": "max_years"
                }
            }
        ]
    }

# Generated at 2022-06-21 16:33:57.913916
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    for _ in range(10):
        blood_type = person.blood_type()
        if blood_type not in BLOOD_GROUPS:
            raise Exception(
                'Returned value "{0}" is not in list of blood groups'.format(
                    blood_type))


# Generated at 2022-06-21 16:33:59.290274
# Unit test for method telephone of class Person
def test_Person_telephone():
    for _ in range(100):
        assert len(Person().telephone()) == len('+7-(963)-409-11-22')



# Generated at 2022-06-21 16:34:10.671156
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    provider = Person()
    assert type(provider.academic_degree()) == str

# Generated at 2022-06-21 16:34:13.184244
# Unit test for method language of class Person
def test_Person_language():
    person = Person('en')
    result = person.language()
    print(result)


# Generated at 2022-06-21 16:34:15.618150
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    assert person.title(title_type=TitleType.SUFFIX) in person._data['title'][0][1]
    assert person.title(title_type=TitleType.PREFIX) in person._data['title'][0][0]
# Testing of method title
test_Person_title()

# Generated at 2022-06-21 16:34:16.695342
# Unit test for method username of class Person
def test_Person_username():
    print(Person().username(template='l.d'))

# Generated at 2022-06-21 16:34:22.763092
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    # Create a instance of class Person
    fake = Person(seed=2111)
    # Generate a random sexual orientation
    sexual_orientation = fake.sexual_orientation()
    # Check that the generated sexual orientation matches the expected value
    assert sexual_orientation == 'Bisexuality'


# Generated at 2022-06-21 16:34:24.137501
# Unit test for constructor of class Person
def test_Person():
    Person()


# Generated at 2022-06-21 16:34:25.332577
# Unit test for method language of class Person
def test_Person_language():
    test = Person().language()
    assert(test)


# Generated at 2022-06-21 16:34:36.358187
# Unit test for method name of class Person
def test_Person_name():
    print('\n'+'-'*10,'Unit test for method name of class Person', '-'*10+'\n')
    # Get names of male sex
    gender = Gender.MALE
    for i in range(5):
        print(f'Name of male #{i}:{Person().name(gender)}')
    # Get names of female sex
    gender = Gender.FEMALE
    for i in range(5):
        print(f'Name of female #{i}:{Person().name(gender)}')
    # Get names of unknown sex
    gender = Gender.UNKNOWN
    for i in range(5):
        print(f'Name of unknown #{i}:{Person().name(gender)}')
    # Get names of all genders
    for i in range(5):
        gender = get_random_item(Gender)


# Generated at 2022-06-21 16:34:38.639118
# Unit test for method political_views of class Person
def test_Person_political_views():
    data = [Person().political_views() for _ in range(10000)]

    results = set()
    for s in data:
        if s in POLITICAL_VIEWS:
            results.add(s)

    assert len(results) == len(POLITICAL_VIEWS)


# Generated at 2022-06-21 16:34:42.256387
# Unit test for method views_on of class Person
def test_Person_views_on():
    from faker_generator import FakerGenerator
    from faker_generator.constants import Language
    with FakerGenerator.seed(10):
        assert FakerGenerator(Language.EN).person.views_on() == 'Negative'

# Generated at 2022-06-21 16:35:07.394164
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person.work_experience(achievements = True) == {
        'current_job': 'Project Manager', 
        'job_country': 'United Kingdom', 
        'job_region': 'England', 
        'job_city': 'Cambridge', 
        'achievements': [
            'Collaborated with design teams to develop and improve our products and services.', 
            'Developed and managed service and product plans that lead to consistent upgrades and improvements.', 
            'Created and maintained a master project calendar and communicated schedule changes to team.'
        ], 
        'achievement_count': 3
    }

# Generated at 2022-06-21 16:35:12.533226
# Unit test for method password of class Person
def test_Person_password():
    random_person = Person()
    password = random_person.password()
    print(password)
    password = random_person.password(hashed=True)
    print(password)
    password = random_person.password(length=12, hashed=True)
    print(password)

# Generated at 2022-06-21 16:35:20.045580
# Unit test for method university of class Person
def test_Person_university():
    person = Person(random=Random(1))
    assert person.university() == 'MIT'
    person = Person(random=Random(2))
    assert person.university() == 'Stanford'
    person = Person(random=Random(3))
    assert person.university() == 'Harvard'
    person = Person(random=Random(4))
    assert person.university() == 'Cambridge'


# Generated at 2022-06-21 16:35:28.486247
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person1 = Person(1, ['Альбертович', 'Альбертовна', 'Альбертов'], ['Максимович', 'Максимовна', 'Максимов'])
    assert person1.work_experience() == 0
    person2 = Person(4, ['Альбертович', 'Альбертовна', 'Альбертов'], ['Максимович', 'Максимовна', 'Максимов'])


# Generated at 2022-06-21 16:35:32.955524
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person(random=Random())
    # Run 1000 loops to test the output
    for _ in range(1000):
        first_name = person.first_name()
        assert first_name in NAMES, f'first_name = {first_name}'

# Generated at 2022-06-21 16:35:40.241522
# Unit test for method username of class Person
def test_Person_username():
    # Test case 1
    person = Person()

# Generated at 2022-06-21 16:35:42.525567
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
  person = Person()
  assert person.academic_degree() in person._data['academic_degree']


# Generated at 2022-06-21 16:35:44.708356
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    for i in range(100):
        person.nationality()

# Generated at 2022-06-21 16:35:47.597231
# Unit test for method last_name of class Person
def test_Person_last_name():
    # Person with seed.
    obj = Person(seed=42)
    assert obj.last_name() == 'Колос'



# Generated at 2022-06-21 16:35:50.438459
# Unit test for method gender of class Person
def test_Person_gender():
    rv = Person.gender
    assert callable(rv)

# Generated at 2022-06-21 16:36:03.988605
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert isinstance(Person().sexual_orientation(), str)

# Generated at 2022-06-21 16:36:07.914790
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    rnd = Random()
    provider = Person(rnd)
    result = provider.blood_type()
    assert isinstance(result, str)
    assert result in [
        'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', '0+', '0-'
    ]

# Generated at 2022-06-21 16:36:09.187373
# Unit test for method university of class Person
def test_Person_university():
    uni = Person.university()
    assert(last_name in uni)


# Generated at 2022-06-21 16:36:15.439399
# Unit test for method gender of class Person
def test_Person_gender():
    import pytest
    def _generate_gender(gender, symbol, iso5218):
        return fake.Person(None).gender(symbol=symbol, iso5218=iso5218)

    def _test_gender_result(gender, symbol, iso5218):
        gender = _generate_gender(gender, symbol, iso5218)

        if symbol:
            assert isinstance(gender, GenderSymbol)
        elif iso5218:
            assert isinstance(gender, GenderCode)
        else:
            assert isinstance(gender, Gender)

    @pytest.mark.parametrize('symbol,iso5218', [
        (True, False),
        (False, True),
        (False, False),
    ])
    def test_gender(symbol, iso5218):
        _test_gender_result

# Generated at 2022-06-21 16:36:19.716508
# Unit test for method views_on of class Person
def test_Person_views_on():
    """
    Test for method views_on of class Person.
    """
    # Check the correctness of values
    assert isinstance(Person().views_on(), str), \
        'Should be instance of str'
    # Checks for the presence of values
    assert Person().views_on() in __all__, 'Should be a valid value'


# Generated at 2022-06-21 16:36:22.334599
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    try:
        degree = person.academic_degree()
    except AssertionError:
        degree = None
    assert degree

# Generated at 2022-06-21 16:36:24.905425
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    min_weight = 38
    max_weight = 40
    weight = person.weight(min_weight, max_weight)
    assert weight < max_weight and weight > min_weight


# Generated at 2022-06-21 16:36:28.248668
# Unit test for method avatar of class Person
def test_Person_avatar():
    for i in range(100):
        random_avatar = Provider().avatar()
        assert isinstance(random_avatar, str), 'Avatar must be a string'
        assert (random_avatar.startswith('https://api.adorable.io/avatars/'), 'Avatar must start with API url')
        

# Generated at 2022-06-21 16:36:30.402678
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    telephone_number = person.telephone()
    assert len(telephone_number) > 7 and len(telephone_number) < 20
    assert isinstance(telephone_number, str)


# Generated at 2022-06-21 16:36:35.464682
# Unit test for method height of class Person
def test_Person_height():
    """Test method height of class Person.
    """
    person = Person()
    height = person.height()
    height2 = person.height(minimum=1.0, maximum=9.0)
    assert isinstance(height, str)
    assert isinstance(height2, str)
    assert height != height2


# Generated at 2022-06-21 16:36:50.699741
# Unit test for method weight of class Person
def test_Person_weight():
    from datamaker.types import Person
    a = Person()
    b = a.weight()
    print(b)

# Generated at 2022-06-21 16:36:54.520875
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person()
    assert p.political_views() in ["Conservative", "Libertarian", "Green", "Moderate","Libertarian socialist",
                                   "Liberal", "Communism", "Capitalism", "Anarchism"]

# Generated at 2022-06-21 16:37:02.870572
# Unit test for method title of class Person
def test_Person_title():
    assert len(Person().title()) > 1
    assert len(Person().title(Gender.MALE)) > 1
    assert len(Person().title(Gender.FEMALE)) > 1
    assert len(Person().title(Gender.OTHER)) > 1
    assert len(Person().title(title_type=TitleType.PREFIX)) > 1
    assert len(Person().title(title_type=TitleType.SUFFIX)) > 1
    assert len(Person().title(gender=Gender.MALE,
                              title_type=TitleType.PREFIX)) > 1
    assert len(Person().title(gender=Gender.FEMALE,
                              title_type=TitleType.SUFFIX)) > 1
    assert len(Person().title(gender=Gender.OTHER,
                              title_type=TitleType.SUFFIX)) > 1


# Generated at 2022-06-21 16:37:05.225175
# Unit test for method worldview of class Person
def test_Person_worldview():
    for _ in range(100):
        result = Person.worldview()
        assert isinstance(result, str)


# Generated at 2022-06-21 16:37:07.578696
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = providers.Person()
    assert provider.last_name() == 'Hull'

    

# Generated at 2022-06-21 16:37:09.437980
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person.academic_degree.__doc__ is not None
    assert Person.academic_degree() in ACADEMIC_DEGREE

# Generated at 2022-06-21 16:37:11.621529
# Unit test for method identifier of class Person
def test_Person_identifier():
    import random
    from faker import Faker
    fake = Faker(_random=random.seed(42))
    assert fake.Person.identifier(mask='##-##/##') == '06-35/10'

# Generated at 2022-06-21 16:37:13.444918
# Unit test for method email of class Person
def test_Person_email():
    person = Person(seed=1.5)
    value = person.email(unique=True)
    assert value == 'hk5c5cv5@gmail.com'


# Generated at 2022-06-21 16:37:20.565667
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    obj = Person(seed = 'test')
    # Test for returns type "str"
    obj.seed = 'test'
    assert type(obj.blood_type()) is str
    # Test for returns "C"
    obj.seed = 'test'
    assert obj.blood_type() == 'C'
    # Test for returns "AB "
    obj.seed = 'test'
    assert obj.blood_type() == 'AB '
    # Test for returns "O "
    obj.seed = 'test'
    assert obj.blood_type() == 'O '
    # Test for returns "B"
    obj.seed = 'test'
    assert obj.blood_type() == 'B'
    # Test for returns "A "
    obj.seed = 'test'
    assert obj.blood_type() == 'A '
   

# Generated at 2022-06-21 16:37:23.090923
# Unit test for method email of class Person
def test_Person_email():
    provider = Person()
    s = ''
    for _ in range(10000):
        s += provider.email() + '\n'
    with open('emails.txt', 'w') as f:
        f.write(s)


# Generated at 2022-06-21 16:37:35.524489
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    arr = person.work_experience()
    assert len(arr) == person.random.randint(1, 15)



# Generated at 2022-06-21 16:37:44.898634
# Unit test for method avatar of class Person
def test_Person_avatar():
    """Test for method avatar of class Person."""
    p = Person(charset=(
        'abcdefghijklmnopqrstuvwxyz',
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        '0123456789'))
    assert p.avatar() == (
        'https://api.adorable.io/avatars/256/'
        '40f34a74e08ff8420aa8de3f3d3e2b51.png'
    )
    assert p.avatar(size=100) == (
        'https://api.adorable.io/avatars/100/'
        '40f34a74e08ff8420aa8de3f3d3e2b51.png')
    assert p.avatar(size=100)

# Generated at 2022-06-21 16:37:51.977444
# Unit test for method name of class Person
def test_Person_name():
    person_generator = Person()
    person_generator.seed(1)
    assert person_generator.name() == "زينب"
    person_generator.seed(2)
    assert person_generator.name() == "عبدالحميد"
    person_generator.seed(3)
    assert person_generator.name() == "مهدي"
    person_generator.seed(4)
    assert person_generator.name() == "ماجد"
    person_generator.seed(5)
    assert person_generator.name() == "فهد"
    person_generator.seed(6)
    assert person_generator.name() == "عبدالرحمن"
    person_generator.seed(7)


# Generated at 2022-06-21 16:37:57.510441
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
    for _ in range(100):
        assert Person.blood_type() in BLOOD_GROUPS
test_Person_blood_type()
Person.sex()


# Generated at 2022-06-21 16:38:01.358694
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    p1 = Person()
    assert p1.__module__ == 'faker_ru.person'
    assert p.seed == p1.seed
    assert p.generator == p1.generator
    assert p.random == p1.random
    assert p.__module__ == 'faker_ru.person'


# Generated at 2022-06-21 16:38:02.947094
# Unit test for method identifier of class Person
def test_Person_identifier():
    result = Person().identifier()
    assert re.match(r'\d\d-\d\d/\d\d', result)


# Generated at 2022-06-21 16:38:09.050921
# Unit test for constructor of class Person
def test_Person():
    data = {
        'name': {
            'male': ['John', 'Peter'],
            'female': ['Mary', 'Kate'],
        }
    }

    person_1 = Person(data)
    person_2 = Person(data)

    assert person_1.name(Gender.MALE) in ('John', 'Peter')
    assert person_1.name(Gender.FEMALE) in ('Mary', 'Kate')
    assert person_1.full_name(Gender.MALE) in ('Mary Johnson', 'Kate Johnson')
    assert person_1.full_name(Gender.FEMALE) in ('John Johnson', 'Peter Johnson')

    assert isinstance(person_2.name(), str)
    assert isinstance(person_2.full_name(), str)



# Generated at 2022-06-21 16:38:19.465935
# Unit test for constructor of class Person
def test_Person():
    """
    >>> rnd = Person(seed=1)
    >>> rnd.seed
    1
    >>> rnd = Person(locale='uk')
    >>> rnd.locale
    'uk'
    >>> rnd = Person(locale='ru')
    >>> rnd.locale
    'ru'
    >>> rnd = Person(locale='unknown')
    Traceback (most recent call last):
      ...
    ValueError: «locale» parameter must be in ('ru', 'uk')
    >>> rnd = Person(locale='uk', seed=1)
    >>> rnd.seed
    1
    >>> rnd.locale
    'uk'
    """


# Generated at 2022-06-21 16:38:21.787049
# Unit test for method avatar of class Person
def test_Person_avatar():
    profile = Person()
    avatar = profile.avatar()
    assert type(avatar) is str


# Generated at 2022-06-21 16:38:23.458944
# Unit test for method nationality of class Person
def test_Person_nationality():
    # Test that the nationality type is not empty
    assert len(Person().nationality()) > 0


# Generated at 2022-06-21 16:38:40.138706
# Unit test for method email of class Person
def test_Person_email():

    # If domains is None,
    # use "EMAIL_DOMAINS" from module global scope.

    # Option "unique" is False.

    # Call method email of class Person.

    # Check result.
    assert True

    """
    When:
        domains = None,
        unique = False.

    Result:
        variable "email" must be random email.
    """


# Generated at 2022-06-21 16:38:41.436510
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert callable(Person.occupation)


# Generated at 2022-06-21 16:38:42.621637
# Unit test for method name of class Person
def test_Person_name():
    person = Person(seed=1)
    for _ in range(10):
        r = person.name(Gender.MAN)
        assert r == 'Amit'



# Generated at 2022-06-21 16:38:44.509762
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    for _ in range(100):
        assert Person().blood_type() in BLOOD_GROUPS


# Generated at 2022-06-21 16:38:45.505915
# Unit test for method age of class Person
def test_Person_age():
    Person.age()


# Generated at 2022-06-21 16:38:50.482593
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert Person().occupation() in ['Programmer', 'Musician', 'Architect', 'Environment Artist',
                                     'Writer', 'Banker', 'Tailor', 'Sculptor', 'Baker', 'Engineer',
                                     'Landscape Architect', 'Professor', 'Web Developer', 'Graphic Designer']
    

# Generated at 2022-06-21 16:38:52.652333
# Unit test for method name of class Person
def test_Person_name():
    assert Person().name(Gender.MALE) == 'John'
    assert Person().name(Gender.FEMALE) == 'Emily'


# Generated at 2022-06-21 16:38:56.208893
# Unit test for method height of class Person
def test_Person_height():
    # Setup
    person = Person()
    # Exercise
    message = person.height(minimum=1.0, maximum=2.0)
    # Verify
    expected = "1.42"
    assert message == expected, "A random number from the specified range"
            


# Generated at 2022-06-21 16:38:58.175043
# Unit test for constructor of class Person
def test_Person():
    """
    The test is passed if the constructor
    Person() without parameters has not failed
    """
    assert Person() is not None


# Generated at 2022-06-21 16:39:02.417807
# Unit test for method username of class Person
def test_Person_username():
    for i in range(10):
        assert Person().username(template='Ud') != Person().username(template='ld')
        assert Person().username(template='l-d') != Person().username(template='l.d')

 

# Generated at 2022-06-21 16:39:17.806988
# Unit test for method age of class Person
def test_Person_age():
    person = Person()
    start_year = datetime.datetime.now().year - 1
    end_year = datetime.datetime.now().year
    assert start_year <= person.age <= end_year

# Generated at 2022-06-21 16:39:20.603373
# Unit test for method university of class Person
def test_Person_university():
    p = Person()
    assert p.university() in p._data['university']

# Generated at 2022-06-21 16:39:22.293114
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert isinstance(Person().political_views(), str)
    assert Person().political_views() in PERSON_POLITICAL_VIEWS


# Generated at 2022-06-21 16:39:24.437908
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Arrange
    person = Person()

    # Act
    data = person.views_on()

    # Assert
    assert isinstance(data, str)
    assert len(data) > 0

# Generated at 2022-06-21 16:39:31.626164
# Unit test for method gender of class Person
def test_Person_gender():
    # Init provider
    Person = Provider(locale='en')

    # Test default generation
    for _ in range(100):
        assert isinstance(Person.gender(), str)

    for _ in range(100):
        assert isinstance(Person.sex(), str)

    # Test generation with different kwargs
    for _ in range(100):
        assert isinstance(Person.gender(symbol=True), str)

    for _ in range(100):
        assert isinstance(Person.gender(iso5218=True), int)


# Generated at 2022-06-21 16:39:33.171087
# Unit test for method university of class Person
def test_Person_university():
    person = Person('en')
    university = person.university()
    assert(len(university) != 0)

# Generated at 2022-06-21 16:39:35.583059
# Unit test for method title of class Person
def test_Person_title():
    person = Person(random=Random())

    result = person.title(gender=Gender.MALE, title_type=TitleType.PREFIX)

    assert isinstance(result, str)


# Generated at 2022-06-21 16:39:37.541067
# Unit test for method language of class Person
def test_Person_language():
    from faker import Faker
    fake = Faker()
    assert isinstance(fake.language(), str)

# Generated at 2022-06-21 16:39:42.453698
# Unit test for method age of class Person
def test_Person_age():
    p = Person()
    assert p.age.get(13) == '13 лет'
    assert p.age.get(80) == '80 лет'

# Generated at 2022-06-21 16:39:44.660520
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    r = Random()
    obj = Person(r)

    assert isinstance(obj.work_experience(), str) == True

# Generated at 2022-06-21 16:39:57.802361
# Unit test for method nationality of class Person
def test_Person_nationality():
    # arrange
    p = Person()
    # act
    result = p.nationality()
    # assert
    assert result == 'Russian'
    print(result)

test_Person_nationality()


# Generated at 2022-06-21 16:40:00.551054
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person('en')
    first_name = person.first_name(Gender.MALE)
    assert isinstance(first_name, str)
    assert first_name
    assert len(first_name) > 2

# Generated at 2022-06-21 16:40:10.356770
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person(seed=1)
    p.random.seed(1)

    assert p.worldview() == 'Atheism'
    assert p.worldview() == 'Nihilism'
    assert p.worldview() == 'Nihilism'
    assert p.worldview() == 'Monotheism'
    assert p.worldview() == 'Monotheism'
    assert p.worldview() == 'Positivism'
    assert p.worldview() == 'Pastafarianism'
    assert p.worldview() == 'Pantheism'
    assert p.worldview() == 'Naturalism'
    assert p.worldview() == 'Pantheism'
    assert p.worldview() == 'Atheism'
    assert p.worldview() == 'Atheism'

# Generated at 2022-06-21 16:40:19.852353
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider, Person)
    assert isinstance(provider.random, Random)
    assert isinstance(provider._data, dict)

    provider = Person(seed=1)
    assert isinstance(provider, Person)
    assert isinstance(provider.random, Random)
    assert isinstance(provider._data, dict)

    provider = Person(seed='foo')
    assert isinstance(provider, Person)
    assert isinstance(provider.random, Random)
    assert isinstance(provider._data, dict)

    provider = Person(random=Random(1))
    assert isinstance(provider, Person)
    assert isinstance(provider.random, Random)
    assert isinstance(provider._data, dict)


# Generated at 2022-06-21 16:40:21.584785
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person(seed=1)
    for _ in range(10):
        assert person.blood_type() in BLOOD_GROUPS


# Generated at 2022-06-21 16:40:24.587586
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    """Unit test for method social_media_profile of class Person"""
    p = Person()
    assert p.social_media_profile(site=SocialNetwork.FACEBOOK) == 'https://facebook.com/' + p.username()

# Generated at 2022-06-21 16:40:29.317901
# Unit test for method avatar of class Person
def test_Person_avatar():
    gender = Gender.female
    assert gender is not None
    assert gender == Gender.female
    assert gender == 0
    assert gender != 'female'
    assert gender != Gender.male
    assert gender != 1
    assert gender != Gender.not_specified
    assert gender != 2

# Generated at 2022-06-21 16:40:31.480257
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    for _ in range(100):
        # Check for sexual_orientation is a string
        assert type(faker.sexual_orientation()) is str


# Generated at 2022-06-21 16:40:34.751171
# Unit test for method views_on of class Person
def test_Person_views_on():

	# Run method
	views_on = Person().views_on()

	# Check format
	assert isinstance(views_on, str)
	assert views_on in ['Positive', 'Negative']

# Generated at 2022-06-21 16:40:37.090571
# Unit test for method last_name of class Person
def test_Person_last_name():
    provider = Person('ru')
    print(provider.last_name())
    print(provider.last_name(provider.random.choice(Gender)))

test_Person_last_name()


# Generated at 2022-06-21 16:41:06.612135
# Unit test for method university of class Person
def test_Person_university():
    seed(0)
    data = [Person.university() for _ in range(20)]
    data_test = ['Universidad de Salamanca', 'Uppsala University', 'McGill University', 'Uppsala University', 'Universidad de Zulia', 'University of Jyväskylä', 'University of Heidelberg', 'McMaster University', 'Harvard University', 'University of Manchester', 'University of Cape Town', 'University of Maryland, College Park', 'University of Tampere', 'Université de Montréal', 'Royal Holloway, University of London', 'University of Helsinki', 'Universidad de Salamanca', 'Universidad Simón Bolívar', 'University of Jyväskylä', 'University of Helsinki']
    assert data == data_test


# Generated at 2022-06-21 16:41:07.993488
# Unit test for method last_name of class Person
def test_Person_last_name():
    sc = Person()
    assert len(sc.last_name()) > 0
    


# Generated at 2022-06-21 16:41:13.342916
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person().political_views() in (
        'Liberal', 'Communist', 'Socialist', 'Conservatism',
        'Anarchism', 'Centrism', 'Green politics', 'Nationalism',
        'Capitalism', 'Fascism', 'Monarchism', 'Agrarianism',
        'Libertarianism', 'Monarchism'
    )

 

# Generated at 2022-06-21 16:41:14.472637
# Unit test for method university of class Person
def test_Person_university():
    assert Person().university() in UNIVERSITY
    

# Generated at 2022-06-21 16:41:17.832760
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    academic_degree = next(Person()).academic_degree()
    assert academic_degree in _dict_keys('data/academic_degree.json')
test_Person_academic_degree()


# Generated at 2022-06-21 16:41:20.720279
# Unit test for method age of class Person
def test_Person_age():
    person = Person()
    assert isinstance(person.age(), int)
    assert isinstance(person.age(0, 80), int)
    assert isinstance(person.age(0, 80, seed=42), int)


# Generated at 2022-06-21 16:41:21.796035
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert Person.occupation() in Person.occupation.__doc__


# Generated at 2022-06-21 16:41:26.652682
# Unit test for method sex of class Person
def test_Person_sex():
    test_instance = Person()
    test_instance.random = Random()
    test_instance.random.seed(2)
    
    assert test_instance.sex() == 'Woman'
    test_instance.random.seed(2)
    assert test_instance.sex(True) == 2
    test_instance.random.seed(2)
    assert test_instance.sex(False, True) == '♀'