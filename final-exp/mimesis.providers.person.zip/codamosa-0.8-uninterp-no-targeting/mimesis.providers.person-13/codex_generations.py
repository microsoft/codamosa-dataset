

# Generated at 2022-06-21 16:31:39.317027
# Unit test for method avatar of class Person
def test_Person_avatar():
    provider = Person()
    avatar = provider.avatar()
    parts = avatar.split('/')
    link = parts[-1]
    assert len(link) == 33



# Generated at 2022-06-21 16:31:42.808285
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    from dataknead import Knead
    Person = Person(Knead())
    data = Person.academic_degree()
    assert isinstance(data, str)

# Generated at 2022-06-21 16:31:46.528165
# Unit test for method email of class Person
def test_Person_email():
    text = 'test@test.com'
    # assert Person.email() == text
    # assert isinstance(Person.email(), string_types)
    assert Person().email() in EMAIL_DOMAINS
    assert isinstance(Person().email(), string_types)
    
    

# Generated at 2022-06-21 16:31:49.475764
# Unit test for constructor of class Person
def test_Person():
    print('\nConstructor of class Person:\n')

    fake = Faker(shuffle=False)
    person = Person(fake)

    assert isinstance(person, Person)

if __name__ == '__main__':
    test_Person()

# Generated at 2022-06-21 16:31:51.815800
# Unit test for method sex of class Person
def test_Person_sex():
    provider = Person()
    assert provider.sex() in [0, 1, 2, 9]

# Generated at 2022-06-21 16:31:56.481431
# Unit test for method identifier of class Person
def test_Person_identifier():
    generator = Generator()
    print(generator.person.identifier("##-##/##"))
    print(generator.person.identifier("@@-@@/@@"))
    print(generator.person.identifier("@@-@@/##"))


# Generated at 2022-06-21 16:32:02.975348
# Unit test for method identifier of class Person
def test_Person_identifier():
    from nose.tools import assert_is_instance, assert_regexp_matches
    from faker import Faker
    Faker.seed(0)

    person = Faker().person()
    identifier = person.identifier()

    assert_is_instance(identifier, str)
    assert_regexp_matches(identifier, r'^\d{2}\-\d{2}\/\d{2}$')


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 16:32:07.147051
# Unit test for method telephone of class Person
def test_Person_telephone():
    for _ in range(100):
        mask = '+7-(###)-###-####'
        placeholder = '#'
        phone = Person().telephone(mask, placeholder)
        assert re.fullmatch(r'\+7-\(\d{3}\)-\d{3}-\d{4}', phone)

# Generated at 2022-06-21 16:32:08.024691
# Unit test for method avatar of class Person
def test_Person_avatar():
    assert Person().avatar()



# Generated at 2022-06-21 16:32:10.709101
# Unit test for method username of class Person
def test_Person_username():
    p = Person(seed=1337)
    assert p.username() == 'bmvz9893'



# Generated at 2022-06-21 16:32:25.047498
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    val = p.weight(90,200)
    assert(val >= 90 and val <= 200)
    

# Generated at 2022-06-21 16:32:27.364173
# Unit test for method nationality of class Person
def test_Person_nationality():
    n = Person().nationality()
    assert n in Person.get_data('nationality')

# Generated at 2022-06-21 16:32:29.394346
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person()
    assert isinstance(p.political_views(), str)

# Generated at 2022-06-21 16:32:39.920218
# Unit test for method username of class Person
def test_Person_username():
    provider = Person(rnd=random.Random())
    template = "Ud"
    n = 100
    result = [provider.username(template) for i in range(n)]

# Generated at 2022-06-21 16:32:49.298387
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person(random=Random())
    
    assert person.occupation() == 'Dentist'
    assert person.occupation() == 'Civil Engineer'
    assert person.occupation() == 'Mechanical Engineer'
    assert person.occupation() == 'Turner'
    assert person.occupation() == 'Sales Assistant'
    assert person.occupation() == 'Horticulturalist'
    assert person.occupation() == 'Roofer'
    assert person.occupation() == 'Florist'
    assert person.occupation() == 'Baker'
    assert person.occupation() == 'Accountant'

# Generated at 2022-06-21 16:32:54.149508
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()

    tmp = person.avatar()
    assert re.match('https://api.adorable.io/avatars/256/[0-9a-f]{32}.png', tmp) is not None

    tmp = person.avatar(size=512)
    assert re.match('https://api.adorable.io/avatars/512/[0-9a-f]{32}.png', tmp) is not None

# Generated at 2022-06-21 16:32:56.227425
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person(seed=1)
    assert p.nationality() == 'Russian'

# Generated at 2022-06-21 16:32:57.783095
# Unit test for method title of class Person
def test_Person_title():
    assert Person(seed=42).title() == 'Mr.'


# Generated at 2022-06-21 16:33:00.024204
# Unit test for method worldview of class Person
def test_Person_worldview():
    p=Person()
    assert p.worldview() in WORLDVIEWS

# Generated at 2022-06-21 16:33:03.157156
# Unit test for method password of class Person
def test_Person_password():
	assert len(Person().password()) == 8
	assert isinstance(Person().password(hashed=True),str)
	assert len(Person().password(12)) == 12
	assert len(Person().password(hashed=True)) == 32


# Generated at 2022-06-21 16:33:21.041804
# Unit test for method email of class Person
def test_Person_email():
    from faker.providers.person.ja_JP import Provider as PersonProvider
    from faker.providers.internet.ja_JP import Provider as InternetProvider
    from faker.providers.internet import Provider as InternetProvider
    from faker.providers.person import Provider as PersonProvider
    from faker import Generator
    import copy
    import sys
    
    internet_provider = InternetProvider(seed_instance=None)
    person_provider = PersonProvider(seed_instance=None)
    seed_instance = None
    

# Generated at 2022-06-21 16:33:22.607607
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    print(Person().sexual_orientation())


# Generated at 2022-06-21 16:33:25.639299
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    _height = person.height() # Get value of height using method height
    # Check the value of height that are not equal to the value 0
    assert _height != 0

# Generated at 2022-06-21 16:33:28.525280
# Unit test for method password of class Person
def test_Person_password():
    assert Person().password(length=2, hashed=True) == hashlib.md5('1g'.encode()).hexdigest()

# Generated at 2022-06-21 16:33:31.175068
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Unit test for method telephone of class Person."""
    p = Person()
    assert generate_valid_phone_number(p.telephone())

# Generated at 2022-06-21 16:33:37.596297
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from faker import Faker

    fake = Faker('uk_UA')
    network = fake.random.choice(SOCIAL_NETWORKS.keys())
    profile = fake.social_media_profile(network)

    url = 'https://' + SOCIAL_NETWORKS[network]

    assert re.fullmatch(r'http[s]?://.*', profile), 'Profile ' \
                                                    'should be valid url'
    assert profile.startswith(url), 'Profile should starts with ' \
                                    'social network url'



# Generated at 2022-06-21 16:33:46.192597
# Unit test for method username of class Person
def test_Person_username():
    ring = Daikon(seed=4)
    test_cases = [
        {'template': None},
        {'template': 'U_d'},
        {'template': 'U.d'},
        {'template': 'U-d'},
        {'template': 'UU-d'},
        {'template': 'UU.d'},
        {'template': 'UU_d'},
        {'template': 'Ud'},
        {'template': 'ld'},
        {'template': 'l.d'},
        {'template': 'l-d'},
        {'template': 'l_d'},
        {'template': 'default'},
    ]
    assert ring.Person.username(**test_cases[0]) == 'Annie80'

# Generated at 2022-06-21 16:33:50.022569
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    p1 = person.avatar()
    p2 = person.avatar()
    p3 = person.avatar(size=300)
    assert p1 != p2
    assert p1 != p3
    assert p2 != p3
    assert p1 != ''
    assert p2 != ''
    assert p3 != ''
    assert p1[0] == 'h'
    assert p2[0] == 'h'
    assert p3[0] == 'h'



# Generated at 2022-06-21 16:34:02.126820
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert Person(seed=1).first_name() == 'Лариса'
    assert Person(seed=2).first_name() == 'Полина'
    assert Person(seed=3).first_name() == 'Анна'
    assert Person(seed=4).first_name() == 'Анастасия'
    assert Person(seed=5).first_name() == 'Александра'
    assert Person(seed=6).first_name() == 'Мария'
    assert Person(seed=7).first_name() == 'Дарья'
    assert Person(seed=8).first_name() == 'Виктория'
    assert Person(seed=9).first_

# Generated at 2022-06-21 16:34:10.352251
# Unit test for method username of class Person
def test_Person_username():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import lists
    from hypothesis.strategies import from_regex
    from hypothesis.strategies import characters
    from hypothesis.strategies import integers
    from hypothesis.strategies import sampled_from
    from hypothesis.strategies import floats
    from hypothesis.strategies import composite
    person = Person()

    @composite
    def naturals(draw):
        n = draw(integers(min_value=1, max_value=100,))
        return n

    @composite
    def floats_(draw):
        x = draw(floats(min_value=1, max_value=1))
        return '{:0.2f}'.format(x)


# Generated at 2022-06-21 16:34:24.989462
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    emails = []
    for i in range(1000):
        email = person.email()
        if email in emails:
            raise Exception('Error during test generation emails')
        emails.append(email)

# Generated at 2022-06-21 16:34:36.023782
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert Person.identifier(Person, mask='##-##/##') == '17-80/83'
    assert Person.identifier(Person, mask='##-##/##') == '63-81/66'
    assert Person.identifier(Person, mask='##-##/##') == '67-82/54'
    assert Person.identifier(Person, mask='##-##/##') == '84-41/54'
    assert Person.identifier(Person, mask='##-##/##') == '82-23/64'
    assert Person.identifier(Person, mask='##-##/##') == '18-82/53'
    assert Person.identifier(Person, mask='##-##/##') == '58-66/79'
    assert Person.identifier(Person, mask='##-##/##')

# Generated at 2022-06-21 16:34:44.094792
# Unit test for method first_name of class Person
def test_Person_first_name():
    # Generate a random first name
    first_name = faker.first_name()
    print("First name: {0}".format(first_name))
    # Generate a random first name with gender
    first_name = faker.first_name(gender=Gender.MALE)
    print("First name (male): {0}".format(first_name))
    first_name = faker.first_name(gender=Gender.FEMALE)
    print("First name (female): {0}".format(first_name))



# Generated at 2022-06-21 16:34:45.539268
# Unit test for method full_name of class Person
def test_Person_full_name():
    name = Person().full_name()
    assert name
    assert isinstance(name, str)



# Generated at 2022-06-21 16:34:50.236144
# Unit test for method avatar of class Person
def test_Person_avatar():
    values = []
    fake = Faker()
    for _ in range(100):
        value = fake.avatar()
        assert value not in values
        values.append(value)


# Generated at 2022-06-21 16:34:56.523674
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """Test method blood_type."""
    random_data = {
        'blood_group': BLOOD_GROUPS}
    pr = Person(random_data, random=MockRandom())
    result = pr.blood_type()
    assert result in BLOOD_GROUPS


# def test_create_person():
#     """Test to create person."""
#     name_person = Person('')



# Generated at 2022-06-21 16:34:59.788135
# Unit test for method language of class Person
def test_Person_language():
    assert Person().language() in  """
    English
    German
    French
    Spanish
    Italian
    Latin
    Greek
    Turkish
    Russian
    Polish
    Ukrainian
    Belarusian
    Romanian
    Bulgarian
    Serbian
    Croatian
    Hungarian
    Czech
    Slovak
    Albanian
    Georgian
    Armenian
    Azerbaijani
    Kazakh
    Kyrgyz
    Tajik
    Turkmen
    Uzbek
    Chinese
    Japanese
    Korean
    Hindi
    Arabic
    Persian
    Portuguese
    Dutch
    Buryat
    Tatar
""".split()

# Generated at 2022-06-21 16:35:02.814018
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person(seed=786)
    for _ in range(10):
        assert len(person.avatar()) > 100 and len(person.avatar()) < 110
        

# Generated at 2022-06-21 16:35:05.573262
# Unit test for method worldview of class Person
def test_Person_worldview():
    worlds = []
    for _ in range(5):
        worlds.append(Person().worldview())
    print(worlds)
    
test_Person_worldview()


# Generated at 2022-06-21 16:35:11.924447
# Unit test for method gender of class Person
def test_Person_gender():
    prv = Person()
    assert prv._validate_enum(Gender.FEMALE, Gender) == 'female'
    assert prv._validate_enum(Gender.MALE, Gender) == 'male'
    assert prv.gender(iso5218=True) in [0, 1, 2, 9]
    assert prv.gender(symbol=True) in GENDER_SYMBOLS

# Generated at 2022-06-21 16:35:29.622747
# Unit test for method occupation of class Person
def test_Person_occupation():
    """
    Проверка случайного выпадения занятия пользователя
    :return:
    """
    from random import seed,randint
    from datetime import datetime
    print('\nUnit test for method occupation of class Person')
    t1 = datetime.now()
    seed(datetime.now().timestamp())
    tests = 100000
    count = 0
    for i in range(tests):
        fire_station = Person().occupation()
        if fire_station == 'Программист':
            count +=1
    p = count/tests*100

# Generated at 2022-06-21 16:35:32.484459
# Unit test for method language of class Person
def test_Person_language():

    # Get an instance of Person
    person = Person()

    # Check type of returned value
    assert isinstance(person.language(), str)


# Generated at 2022-06-21 16:35:34.086437
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Check the type of return value
    assert type(Person().views_on()) == str


# Generated at 2022-06-21 16:35:35.800369
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person(seed=0)
    assert p.blood_type() == 'O-'


# Generated at 2022-06-21 16:35:37.402555
# Unit test for method title of class Person
def test_Person_title():
    test_value_1 = Person().title()
    if test_value_1 is None:
        raise AssertionError("Empty Var")

# Generated at 2022-06-21 16:35:40.484941
# Unit test for method email of class Person
def test_Person_email():
    test = Generator()
    for i in range(10):
        email = test.Person().email()
        assert len(email) == len('foretime10@live.com')


# Generated at 2022-06-21 16:35:43.040052
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    username = person.username()
    print(username)

# Generated at 2022-06-21 16:35:45.972440
# Unit test for method name of class Person
def test_Person_name():
    example = 'Анатолий'
    instance = Person()
    result = instance.name(Gender.MALE)
    assert isinstance(result, str)
    assert result == example

# Generated at 2022-06-21 16:35:48.927373
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    assert re.match(r'[\w\-\'\.]+', person.last_name())


# Generated at 2022-06-21 16:35:57.909926
# Unit test for method surname of class Person
def test_Person_surname():
    """
    Test method surname of class Person

    :return: None
    """
    p = Person(seed=1990)
    # Check the number of elements of the list.
    # It should be equal to the number of surnames.
    assert len(p._data['surname'][Gender.MALE.name]) == 51
    assert len(p._data['surname'][Gender.FEMALE.name]) == 13
    assert len(p._data['surname'][Gender.UNISEX.name]) == 22
    assert len(p._data['surname']['all']) == 86
    # Check a random surname
    assert p.last_name() == 'Голицын'
    # Check a random surname by gender

# Generated at 2022-06-21 16:36:15.841233
# Unit test for method gender of class Person
def test_Person_gender():
    from random import Random
    from string import ascii_letters, digits, punctuation
    from hashlib import md5
    from pyt.enums import Gender

    # Initial values
    seed_value = 15444444444444444444444444444444444444444444444444444444444444
    rnd = Random(seed_value)
    text = ascii_letters + digits + punctuation
    length = 17
    name = ''.join([rnd.choice(text) for _ in range(length)])
    min_date = 1800
    max_date = 2070
    default_template = 'l.d'
    template = 'ld'
    minimum = 1.5
    maximum = 2.0
    minimum_weight = 38
    maximum_weight = 90
    minimum_age

# Generated at 2022-06-21 16:36:18.454757
# Unit test for method sex of class Person
def test_Person_sex():
    from . import Provider
    z = Provider.Person()

    assert z.sex() in ['Male', 'Female', 'Transgender', 'Gender variant']


# Generated at 2022-06-21 16:36:27.304713
# Unit test for method name of class Person
def test_Person_name():
    np = Person()

# Generated at 2022-06-21 16:36:32.265667
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert get_random_item(GANP) == 'Sandeep'
    assert get_random_item(GANP, gender='MALE') == 'Sandeep'
    assert get_random_item(GAP) == 'Priyanka'
    assert get_random_item(GAP, gender='FEMALE') == 'Priyanka'
    

# Generated at 2022-06-21 16:36:33.909083
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person(random=Random())
    assert isinstance(person.full_name(), (str,))


# Generated at 2022-06-21 16:36:37.603214
# Unit test for method first_name of class Person
def test_Person_first_name():
    try:
        assert Person.first_name()
    except Exception as exc:
        print(exc)
        assert False

# Generated at 2022-06-21 16:36:40.453564
# Unit test for method gender of class Person
def test_Person_gender():
    data = Person()
    assert data.gender(symbol=True) in GENDER_SYMBOLS, 'Method gender has problem'
#testing method gender
test_Person_gender()

# Generated at 2022-06-21 16:36:48.232473
# Unit test for method political_views of class Person
def test_Person_political_views():
    """Test method political_views of class Person."""
    # Error for method political_views of class Person
    with pytest.raises(NonEnumerableError):
        Person(political_views='any')

    # Test method political_views of class Person return True
    person = Person(political_views=PoliticalViews.ultraconservative)
    assert person.political_views() == 'ultraconservative'

    # Test method political_views of class Person return True
    person = Person(political_views=PoliticalViews.left)
    assert person.political_views() == 'left'

    # Test method political_views of class Person return True
    person = Person(political_views=PoliticalViews.center)
    assert person.political_views() == 'center'

    # Test method political_views of class Person return True

# Generated at 2022-06-21 16:36:52.700373
# Unit test for method age of class Person
def test_Person_age():
    for i in range(1000):
        print(Person.random().age(minimum=0, maximum=30))
assert (Person.random().age(minimum=0, maximum=30) > 0) and (Person.random().age(minimum=0, maximum=30) < 31)

# Generated at 2022-06-21 16:36:58.175948
# Unit test for method weight of class Person
def test_Person_weight():
    x = Person().weight()
    assert x >= 38 and x <= 90

    x = Person().weight(40, 92)
    assert x >= 40 and x <= 92

    x = Person().weight(42)
    assert x >= 42 and x <= 90

    x = Person().weight(maximum=94)
    assert x >= 38 and x <= 94

    x = Person().weight(None, 92)
    assert x >= 38 and x <= 92


# Generated at 2022-06-21 16:37:31.748791
# Unit test for method last_name of class Person

# Generated at 2022-06-21 16:37:33.428302
# Unit test for method gender of class Person
def test_Person_gender():
    provider = new_provider()
    gender = provider.gender()
    gender in GENDER


# Generated at 2022-06-21 16:37:35.727967
# Unit test for method height of class Person
def test_Person_height():
    with Person() as p:
        assert p.height()
        assert p.height(0, 0)
        assert p.height(0, 1)
        assert p.height(1, 1)



# Generated at 2022-06-21 16:37:38.188904
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname()
    assert isinstance(surname, str)



# Generated at 2022-06-21 16:37:42.558379
# Unit test for method sex of class Person
def test_Person_sex():
    for _ in range(10):
        p = Person()
        assert isinstance(p.sex(), int)
        assert isinstance(p.sex(symbol=True), str)
        assert isinstance(p.sex(iso5218=True), int)
        
test_Person_sex()

# Generated at 2022-06-21 16:37:46.041081
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Generate default phone number
    print(Person.telephone())

    # Generate custom phone number
    fmt = '+7-(###)-###-##-##'
    print(Person.telephone(fmt))


if __name__ == '__main__':
    test_Person_telephone()

# Generated at 2022-06-21 16:37:49.250431
# Unit test for method nationality of class Person
def test_Person_nationality():
    """Unittest for method nationality of class Person"""

    # Test for default scenario
    correct_values = (
        'Spaniard',
        'Japanese',
        'French',
    )
    p = Person()

    for _ in range(3):
        assert p.nationality() in correct_values

# Generated at 2022-06-21 16:37:50.477097
# Unit test for method username of class Person
def test_Person_username():
    test_provider = Provider()
    assert test_provider.username()


# Generated at 2022-06-21 16:38:01.631424
# Unit test for method height of class Person
def test_Person_height():
    from  Faker.providers.Person.en_US import Provider

    person = Person(providers_locales=['en_US'])
    r = person.height()

# Generated at 2022-06-21 16:38:04.818515
# Unit test for method first_name of class Person
def test_Person_first_name():
    first_name = Person().first_name()
    assert first_name, 'Person().first_name() should return value of type str. Got %s' % (first_name,)
    assert isinstance(first_name, str), \
        'Result type should be %s. Got %s' % (str, type(first_name))
    

# Generated at 2022-06-21 16:38:27.046633
# Unit test for method nationality of class Person
def test_Person_nationality():
  p = Person()
  assert isinstance(p.nationality(), str)
 

# Generated at 2022-06-21 16:38:31.028349
# Unit test for method age of class Person
def test_Person_age():
    # Creating a Person object
    person=Person()
    # Asserting that only int values are generated or not
    assert type(person.age(13))==int
    # Asserting that only positive values are generated or not
    assert person.age(13)>0
# Creating an object of class Person and an object of Person_US class
person=Person()
person_us=Person_US()

# Generated at 2022-06-21 16:38:32.625343
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    # Setup
    pe = Person()
    # Exercise
    result = pe.sexual_orientation()
    # Verify
    assert result in pe._data['sexuality']

# Generated at 2022-06-21 16:38:35.339232
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    avatar = person.avatar()
    assert len(avatar) > 0, avatar

# Generated at 2022-06-21 16:38:38.091082
# Unit test for method language of class Person
def test_Person_language():
    with pytest.raises(NonEnumerableError) as error:
        Person().language('None')
    assert error.match('LANGUAGE_CODES is not a enumerable type!')


# Generated at 2022-06-21 16:38:41.387085
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    foo = Person()
    social_media_profile = foo.social_media_profile
    site = SocialNetwork.Twitter
    assert social_media_profile(site) == 'https://twitter.com/some_user'

# Generated at 2022-06-21 16:38:43.728763
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert len(Person().academic_degree())
    assert Person().academic_degree() in ACADEMIC_DEGREES


# Generated at 2022-06-21 16:38:48.620425
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
    assert person.nationality() in person._data['nationality']['male']
    assert person.nationality() in person._data['nationality']['female']
    
test_Person_nationality()


# Generated at 2022-06-21 16:38:58.081143
# Unit test for method sex of class Person
def test_Person_sex():
    from fake2db.query import Query

    gender = Gender.FEMALE

    query = Query('sex', 'gender', gender=gender)
    result = Person().execute(query)
    assert (
        result == 'женский'
    ), f'Method sex() return {result}. ' \
        f'Expected женский'
    
    gender = Gender.MALE

    query = Query('sex', 'gender', gender=gender)
    result = Person().execute(query)
    assert (
        result == 'мужской'
    ), f'Method sex() return {result}. ' \
        f'Expected мужской'
import unittest

query = Query('sex', 'gender', gender=Gender.FEMALE)

# Generated at 2022-06-21 16:39:06.580363
# Unit test for method telephone of class Person
def test_Person_telephone():
    
    class Data_for_assert():

        @staticmethod
        def get_data():
            data = {}
            data['telephone_fmt'] = [
                '+7-(963)-409-##-##',
                '+1-202-555-####',
                '+7-(927)-###-##-##',
                '+7-(495)-###-##-##'
            ]
            data['calling_codes'] = [
                '7',
                '1',
                '7',
                '7'
            ]

# Generated at 2022-06-21 16:39:36.002619
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    with pytest.raises(ValueError):
        Person().social_media_profile() # noqa: F841
    result = Person().social_media_profile(
        SocialNetwork.FACEBOOK
    )
    assert result.startswith('https://www.facebook.com/')
    result = Person().social_media_profile(
        SocialNetwork.TWITTER
    )
    assert result.startswith('https://twitter.com/')

# Generated at 2022-06-21 16:39:42.165229
# Unit test for method age of class Person
def test_Person_age():
    provider = Person()
    age = provider.age(10, 20)
    # Check that age >= 10
    assert age >= 10
    # Check that age <= 20
    assert age <= 20

# Generated at 2022-06-21 16:39:44.737232
# Unit test for method email of class Person
def test_Person_email():
    value = Person.email(None)
    assert isinstance(value, str)
    assert len(value) > 0
    assert '@' in value

# Generated at 2022-06-21 16:39:47.177212
# Unit test for method password of class Person
def test_Person_password():
    """Test password method of class Person."""
    faker = Person()
    password = faker.password(length=2)
    assert type(password) is str
    assert len(password) == 2


# Generated at 2022-06-21 16:39:48.461137
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()

    academic_degree = person.academic_degree()
    assert academic_degree in ACADEMIC_DEGREE



# Generated at 2022-06-21 16:39:51.429741
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    assert p.title()
    assert p.title(title_type=TitleType.suffix)
    assert p.title(gender=Gender.female)

# Generated at 2022-06-21 16:39:53.601582
# Unit test for method gender of class Person
def test_Person_gender():
    random.seed(0)
    provider = Person(random=random)
    for i in range(100):
        assert provider.gender() in ('Male', 'Female')

# Generated at 2022-06-21 16:39:57.612557
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Initialize a basic generator
    r = Random()

    # Generate a random blood type
    random_blood_type = r.person.blood_type()

    assert isinstance(random_blood_type, str)

    # The result should be a random blood type from the dictionary
    assert random_blood_type in BLOOD_GROUPS

# Generated at 2022-06-21 16:39:59.080267
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person()
    assert p.sex() in p._data['gender']
test_Person_sex()

# Generated at 2022-06-21 16:40:09.070233
# Unit test for method identifier of class Person
def test_Person_identifier():
    # Test 1:
    person = Person('en')
    identifier = person.identifier()
    assert len(identifier) == 9
    assert re.fullmatch(r'[a-zA-Z0-9]+', identifier) is not None
    assert identifier.count('/') == 1
    assert identifier.count('-') == 1
    # Test 2:
    identifier = person.identifier(mask='##.##.##')
    assert len(identifier) == 9
    assert re.fullmatch(r'[a-zA-Z0-9]+', identifier) is not None
    assert identifier.count('.') == 2
    # Test 3:
    identifier = person.identifier(mask='#####')
    assert len(identifier) == 5
    assert identifier.isdigit()
    # Test 4:
   

# Generated at 2022-06-21 16:41:07.751700
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """
    Test the method "blood_type" of class "Person"
    """
    # Arrange
    person = Person()

    # Act
    person_blood_type = person.blood_type()

    # Assert
    assert person_blood_type in BLOOD_GROUPS


# Generated at 2022-06-21 16:41:13.992924
# Unit test for method full_name of class Person
def test_Person_full_name():
    faker = Person()
    result1 = faker.full_name(gender=Gender.male)
    result2 = faker.full_name(gender=Gender.female)
    assert re.search(r'([a-z]\s)+', result1, re.I) is not None
    assert re.search(r'([a-z]\s)+', result2, re.I) is not None
    assert result1 != result2


# Generated at 2022-06-21 16:41:21.980590
# Unit test for method last_name of class Person
def test_Person_last_name():
    
    # Create a instance of class Person
    p = Person(seed=7777)
    p1 = Person(seed=7777)
    p2 = Person(seed=7777)
    p3 = Person(seed=7777)
    p4 = Person(seed=7777)
    p5 = Person(seed=7777)
    p6 = Person(seed=7777)
    p7 = Person(seed=7777)
    
    # Use method last_name of class Person
    a = p.last_name(gender=Gender.MALE)
    b = p.surname(gender=Gender.MALE)
    c = p.last_name(gender=Gender.MALE)
    d = p.surname(gender=Gender.MALE)

# Generated at 2022-06-21 16:41:24.165573
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    sex_actual = person.sex()
    assert isinstance(sex_actual, str)
    # Unit test for method height of class Person

# Generated at 2022-06-21 16:41:26.531547
# Unit test for method age of class Person
def test_Person_age():
    assert Person.age(datetime.datetime(2001, 9, 5), "06/04/2020") == 18
    
    