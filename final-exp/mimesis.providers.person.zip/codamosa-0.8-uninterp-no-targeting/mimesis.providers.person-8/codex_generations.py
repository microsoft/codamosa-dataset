

# Generated at 2022-06-21 16:31:38.145015
# Unit test for method university of class Person
def test_Person_university():
    assert Person['university']() in UNIVERSITY

# Generated at 2022-06-21 16:31:47.866927
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    identifier = p.identifier()

    assert isinstance(identifier, str)
    assert re.fullmatch(r'[\d#-@]*[\d#]+[\d#-@]*', identifier)


if __name__ == '__main__':
    p = Person()

    print('Name: {}'.format(p.full_name()))
    print('Username: {}'.format(p.username()))
    print('Gender: {}'.format(p.gender()))
    print('Height: {} meters'.format(p.height()))
    print('Weight: {} Kg'.format(p.weight()))
    print('Email: {}'.format(p.email()))
    print('Sex: {}'.format(p.sex()))

# Generated at 2022-06-21 16:32:00.034618
# Unit test for method email of class Person
def test_Person_email():
    obj = Person(['GMAIL.COM'], random=RandomState(1))

    assert obj.email(unique=True) == 'foretime10@gmail.com'
    assert obj.email() == 'p7e9q3@ymail.com'
    assert obj.email(unique=True) == 'd7e4x4@gmail.com'
    assert obj.email(unique=True) == 'o7e2a2@gmail.com'
    assert obj.email(unique=True) == 'y7e9z6@gmail.com'
    assert obj.email(unique=True) == 'h7e9d2@gmail.com'
    assert obj.email() == 'q3m8w3@gmail.com'
    assert obj.email() == 'm7e1r1@gmail.com'


# Generated at 2022-06-21 16:32:02.661294
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    height = person.height()
    assert len(height) == 5

# Generated at 2022-06-21 16:32:05.152509
# Unit test for method weight of class Person
def test_Person_weight():
    gf = GeneratorFactory('ru')
    p = gf.create_person()
    assert p.weight() in range(38, 90)



# Generated at 2022-06-21 16:32:06.917003
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()
    p.surname()
import unittest


# Generated at 2022-06-21 16:32:09.946291
# Unit test for method age of class Person
def test_Person_age():
    assert Person().age() > 0
    assert Person().age(minimum=18) >= 18
    assert Person().age(maximum=18) < 18
    assert Person().age(minimum=18, maximum=20) >= 18
    assert Person().age(minimum=18, maximum=20) <= 20


# Generated at 2022-06-21 16:32:14.228189
# Unit test for method username of class Person
def test_Person_username():
    f = Person(seed=1)
    result = f.username()
    expected = 'carmel.1915'
    assert result == expected, 'Method username() of class Person returns incorrect data.'

# Generated at 2022-06-21 16:32:17.435865
# Unit test for method last_name of class Person
def test_Person_last_name():
    faker = Faker()
    p = Person(faker)
    assert p.last_name() in NAMES_DATA['surnames']
test_Person_last_name()

# Generated at 2022-06-21 16:32:18.092493
# Unit test for method university of class Person
def test_Person_university():
    pass

# Generated at 2022-06-21 16:32:35.115966
# Unit test for method nationality of class Person
def test_Person_nationality():
    data = {
        ('male', 'en_EN'): 'Englishman',
        ('female', 'en_EN'): 'Englishwoman',
        ('male', 'it_IT'): 'Inglese',
        ('female', 'it_IT'): 'Inglese',
    }

    from faker.providers import BaseProvider


    class GenderProvider(BaseProvider):

        def gender(self):
            return self.random.choice(['male', 'female'])


    faker.add_provider(GenderProvider)

    for gender, locale in [
        ('male', 'en_EN'),
        ('female', 'en_EN'),
        ('male', 'it_IT'),
        ('female', 'it_IT'),
    ]:
        person = faker.Faker(locale=locale)

# Generated at 2022-06-21 16:32:40.072024
# Unit test for method password of class Person
def test_Person_password():
    provider = Person()
    assert len(provider.password()) == 8
    assert len(provider.password(length=10)) == 10
    assert len(provider.password(length=1)) == 1
    assert len(provider.password(hashed=True)) == 32
    assert provider.password(hashed=True) != provider.password(hashed=True)


# Generated at 2022-06-21 16:32:49.870292
# Unit test for method email of class Person
def test_Person_email():
    p = Person('en', 'ru')

    # Test for unique
    unique_emails = set()
    for _ in range(100):
        unique_email = p.email(unique=True)
        assert unique_email not in unique_emails, 'Pay attention to the error'
        unique_emails.add(unique_email)

    # Test for custom domains
    custom_domains = ('gmail.com', twitter.com, 'dummy.com')
    for _ in range(100):
        custom_domain = p.email(domains=custom_domains)
        assert '.' in custom_domain, 'Pay attention to the error'

# Generated at 2022-06-21 16:32:51.336442
# Unit test for method views_on of class Person
def test_Person_views_on():
    views = ['Positive', 'Negative', 'Neutral']
    assert Person().views_on() in views

# Generated at 2022-06-21 16:32:54.532227
# Unit test for method telephone of class Person
def test_Person_telephone():
    obj = Person()
    assert len(obj.telephone()) == len('+7-(963)-409-11-22')


# Generated at 2022-06-21 16:32:55.661339
# Unit test for method title of class Person
def test_Person_title():
    assert Person().title() != ""


# Generated at 2022-06-21 16:33:00.851483
# Unit test for method age of class Person
def test_Person_age():
    person = Person()
    assert person.age() >= 18 and person.age() <= 100


# Generated at 2022-06-21 16:33:03.820913
# Unit test for method password of class Person
def test_Person_password():
    print('\n# Unit test for method password of class Person\n')
    p = Person()
    print(p.password())
    print(p.password(length=10))
    print(p.password(hashed=True))


# Generated at 2022-06-21 16:33:07.379848
# Unit test for method weight of class Person
def test_Person_weight():
    for i in range(100):
        p = Person()
        w = p.weight()
        assert isinstance(w, int) == True


# Generated at 2022-06-21 16:33:10.215741
# Unit test for method university of class Person
def test_Person_university():
    person = Person(random=SystemRandom())
    result = person.university()
    assert isinstance(result, str)
    assert result != ''
    assert result in person._data['university']


# Generated at 2022-06-21 16:33:27.278384
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from faker import Factory

    fake = Factory.create()

    for _ in range(100):
        profile = fake.social_media_profile()
        assert re.match(
            r'https?://(www\.)?(?:facebook|twitter|instagram|vk|ok|github).com/\w+',
            profile
        )

# Generated at 2022-06-21 16:33:31.351703
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    from random import Random
    from databaker.constants import SocialNetwork

    person = Person(Random())
    profile = person.social_media_profile(site=SocialNetwork.Twitter)
    assert profile.startswith('https://twitter.com/')



# Generated at 2022-06-21 16:33:40.820793
# Unit test for method age of class Person
def test_Person_age():
    from faker.providers.person import Provider
    from faker.generator import Generator
    from faker import Faker
    from datetime import date
    fake = Faker()
    fake.add_provider(Provider)
    current_year = date.today().year
    age = fake.age(min_age=10, max_age=90)
    assert age >= 10 and age <=90
# Create a person using a class Person
# Display the Person object
# Get random person object using faker library
person = faker.profile()
# Display person
person

# Get first name of person
person['name']

# Get name of person
person['first_name']

# Get last name of person
person['last_name']

# Get full name of person
person['full_name']

# Get username of person


# Generated at 2022-06-21 16:33:44.669024
# Unit test for method email of class Person
def test_Person_email():
    """Unit test for method email of class Person"""
    person = Person()
    email = person.email()
    assert isinstance(email, str)
    
    

# Generated at 2022-06-21 16:33:48.189095
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    site = person.random.choice(list(SocialNetwork))
    assert(person.social_media_profile(site))


# Generated at 2022-06-21 16:33:59.230719
# Unit test for method title of class Person
def test_Person_title():
    from faker import Faker
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.person.pt_PT import Provider as PersonProviderPortuguese

    fake = Faker()
    fake.add_provider(PersonProvider)
    fake.add_provider(PersonProviderPortuguese)

    # Test with default title
    default_title = fake.title()
    assert default_title in PersonProvider.titles

    # Test with default title and default gender
    default_title_default_gender = fake.title(gender=None)
    assert default_title_default_gender in PersonProvider.titles

    # Test with gender
    female_title = fake.title(Gender.FEMALE)
    assert female_title in PersonProvider.titles


# Generated at 2022-06-21 16:34:06.625522
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Prepare data for test
    test_data = dict(dict_filter(PERSON_DATA))
    # Assign key to test_data
    test_data_key = "work_experience"
    # Get value from key test_data_key
    test_value = test_data.get(test_data_key)
    # Create object of class Person
    cls = Person()
    # Initialize object method
    obj_method = cls.work_experience
    # Check if object method is callable
    assert callable(obj_method)
    # Check result of object method
    assert obj_method() in test_value
 

# Generated at 2022-06-21 16:34:08.323330
# Unit test for method name of class Person
def test_Person_name():
    assert Person.name(Person) not in (None, "", " ", "  ")


# Generated at 2022-06-21 16:34:11.142099
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    rnd = Random()
    provider = Person(rnd)
    for _ in range(1000):
        assert provider.blood_type() in BLOOD_GROUPS


# Generated at 2022-06-21 16:34:14.028417
# Unit test for method sex of class Person
def test_Person_sex():
    assert Person.sex.__name__ == 'sex'
    assert Person().sex.__name__ == 'sex'
    assert callable(Person().sex)
    assert Person().sex() in SEX



# Generated at 2022-06-21 16:34:36.264587
# Unit test for method worldview of class Person
def test_Person_worldview():
	result = Person().worldview()
	assert result == result
	

# Generated at 2022-06-21 16:34:38.192412
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person()
    assert bool(re.match(PERSON_FULL_NAME_REGEX, p.full_name()))
    
test_Person_full_name()



# Generated at 2022-06-21 16:34:40.351502
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    print(person.email())

test_Person_email()


# Generated at 2022-06-21 16:34:42.923371
# Unit test for method political_views of class Person
def test_Person_political_views():
    political_views = p.political_views()
    assert political_views in _PERSON_POLITICAL_VIEWS
test_Person_political_views()

# Generated at 2022-06-21 16:34:49.280292
# Unit test for method username of class Person
def test_Person_username():
    print(Person.username())
    print(Person.username(template='UU.d'))
    print(Person.username(template='U.d'))
    print(Person.username(template='U-d'))
    print(Person.username(template='ld'))
    print(Person.username(template='l_d'))
    print(Person.username(template='l-d'))
    print(Person.username(template='UU-d'))
    print(Person.username(template='UU_d'))
    print(Person.username(template='U_d'))
    # print(Person.username(template='.'))  # raise ValueError
    # print(Person.username(template='-d'))  # raise ValueError

# Generated at 2022-06-21 16:34:54.704636
# Unit test for method language of class Person
def test_Person_language():
    class MockedRandom:
        def __init__(self, seed):
            self.seed = seed

        def choice(self, items):
            return items[0]

    random = MockedRandom(seed=None)
    person = Person(random=random)

    language = person.language()
    assert language == 'Irish'



# Generated at 2022-06-21 16:35:01.350818
# Unit test for method weight of class Person
def test_Person_weight():
    assert Person().weight(90, 90) == 90
    assert Person(random=Random()).weight(1, 1) == 1
    assert Person(random=Random()).weight(1, 1, 1) == 1
    assert Person(random=Random()).weight(5, 1, 1) == 1
    assert Person(random=Random()).weight(1, 5, 1) == 1
    assert Person(random=Random()).weight(1, 1, 5) == 1
    assert Person(random=Random()).weight(1, 5, 5) == 5
    assert Person(random=Random()).weight(5, 1, 5) == 5
    assert Person(random=Random()).weight(5, 5, 1) == 5

# Generated at 2022-06-21 16:35:05.624847
# Unit test for method height of class Person
def test_Person_height():
    P = Person()

    for i in range(10):
        height = float(P.height())
        assert height >= 1.5
        assert height < 2.0

if __name__ == '__main__':
    test_Person_height()


# Generated at 2022-06-21 16:35:09.612776
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Arrange
    provider = Person()

    # Act
    result = provider.work_experience()

    # Assert
    assert_that(isinstance(result, str))



# Generated at 2022-06-21 16:35:12.035452
# Unit test for method avatar of class Person
def test_Person_avatar():
    data = {
        'size': 256
    }
    person = Person()
    result = person.avatar(**data)
    assert result



# Generated at 2022-06-21 16:35:38.037568
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person('en')
    person.seed(1)
    assert person.sex()=='Not Known'
    assert person.sex() == 'Female'
    assert person.sex() == 'Male'
    assert person.sex() == 'Not Applicable'
    assert person.sex() == 'Female'
    
    
test_Person_sex()


# Generated at 2022-06-21 16:35:47.848452
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person()

    # С проверкой маски
    assert re.fullmatch(r'[A-Za-z0-9]{2}-[A-Za-z0-9]{2}/[A-Za-z0-9]{2}', person.identifier(mask='##-##/##'))
    assert re.fullmatch(r'[A-Za-z0-9]{2}-[A-Za-z0-9]{2}/[A-Za-z0-9]{2}', person.identifier(mask='@@-@@/#/#'))

# Generated at 2022-06-21 16:35:57.627958
# Unit test for method title of class Person
def test_Person_title():
    """Test method Person::title.

    Checks whether method Person::title returns the expected value
    """
    from random import Random

    random = Random(8960)

    person = Person(seed=8960)

    # Test with argument title_type=TitleType.SUFFIX
    assert person.title(
            gender=Gender.MALE, title_type=TitleType.SUFFIX,
            ) == 'M.A.'
    assert person.title(
            gender=Gender.MALE, title_type=TitleType.SUFFIX,
            ) == 'M.D.'
    assert person.title(
            gender=Gender.MALE, title_type=TitleType.SUFFIX,
            ) == 'MD'

# Generated at 2022-06-21 16:36:01.541448
# Unit test for method username of class Person
def test_Person_username():
    assert Person(random=Random()).username(template='ld') == 'b.67'
    assert Person(random=Random()).username(template='d') == '75'
    assert Person(random=Random()).username(template='l') == 'a'
    assert Person(random=Random()).username(template='U') == 'B'

# Generated at 2022-06-21 16:36:09.821894
# Unit test for method name of class Person
def test_Person_name():
    person = Person()

    assert type(person.name()) == str
    assert (person.name(gender=Gender.MALE) in person._data['male_name']) == True
    assert (person.name(gender=Gender.FEMALE) in person._data['female_name']) == True

    person = Person(seed=42)

    assert person.name() == 'Павлик'
    assert person.name(gender=Gender.MALE) == 'Данил'
    assert person.name(gender=Gender.FEMALE) == 'Маришка'

    user = Person(seed=42, gender=Gender.MALE)

    assert user.name() == 'Данил'

# Generated at 2022-06-21 16:36:20.539161
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person(seed=0)

    assert p.telephone(mask='#-###-###-#-##') == '5-624-131-9-38'
    assert p.telephone(mask='##.###.###') == '26.202.075'
    assert p.telephone(mask='+#(###)###-###') == '+7(382)930-150'

    p = Person(seed=1)

    assert p.telephone(mask='#-###-###-#-##') == '7-940-927-9-46'
    assert p.telephone(mask='##.###.###') == '77.159.506'
    assert p.telephone(mask='+#(###)###-###') == '+7(710)886-753'


# Generated at 2022-06-21 16:36:24.005345
# Unit test for method avatar of class Person
def test_Person_avatar():
    rnd = Random()
    provider = Person(random=rnd)

    avatar_url = provider.avatar(rnd.randint(128, 256))
    assert re.fullmatch(r'https://api.adorable.io/avatars/\d+/\w+\.png', avatar_url)

# Generated at 2022-06-21 16:36:29.737718
# Unit test for method telephone of class Person
def test_Person_telephone():
    random_faker = Factory.create()

    for i in range(100):
        code = random_faker.random.choice(CALLING_CODES)
        default = '{}-(###)-###-####'.format(code)
        masks = random_faker.data['telephone_fmt']

        if not masks:
            masks = [default]

        mask = random_faker.random.choice(masks)

        assert re.fullmatch(r'[\d\.\(\)-]*', mask)

        random_faker.random.custom_code(mask=mask, digit='#')



# Generated at 2022-06-21 16:36:32.988515
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Provider()
    assert p.sexual_orientation() != None
    assert isinstance(p.sexual_orientation(), str)
    assert len(p.sexual_orientation()) > 0

# Generated at 2022-06-21 16:36:35.551624
# Unit test for method sex of class Person
def test_Person_sex():
    for _ in range(100):
        assert Person.sex(None) in GENDER_MALE



# Generated at 2022-06-21 16:37:25.723185
# Unit test for method height of class Person
def test_Person_height():
    minimum = 1.5
    maximum = 2.0
    person = Person()
    h = person.height(minimum, maximum)
    assert isinstance(h, str) and len(h) <= 4
test_Person_height()


# Generated at 2022-06-21 16:37:29.894596
# Unit test for method sex of class Person
def test_Person_sex():
    for i in range(100):
        person = Person()
        assert person.sex() in ['Male', 'Female']
        assert person.sex(symbol=True) in '♂♀'
        assert person.sex(iso5218=True) in [0, 1, 2, 9]


# Generated at 2022-06-21 16:37:31.744112
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person().work_experience(
        year_start=None,
        year_end=None,
        current=False,
        company=None,
        position=None
    )

# Generated at 2022-06-21 16:37:33.971533
# Unit test for method nationality of class Person
def test_Person_nationality():
    persons = Person()
    expected = "Russian"
    result = persons.nationality()
    assert result == expected

# Generated at 2022-06-21 16:37:40.619475
# Unit test for method username of class Person
def test_Person_username():
    gen = Generator()

    for _ in range(20):  # 20 is enough for validation
        # Template must contain at least one "U" or "l" placeholder.
        try:
            gen.username(template='d')
        except ValueError:
            pass
        else:
            raise AssertionError('AssertionError was expected')

        # Supported template placeholders: (U, l, d)
        try:
            gen.username(template='b')
        except ValueError:
            pass
        else:
            raise AssertionError('AssertionError was expected')

        # Supported separators: (-, ., _)
        try:
            gen.username(template='U&l')
        except ValueError:
            pass
        else:
            raise AssertionError('AssertionError was expected')
# Unit test

# Generated at 2022-06-21 16:37:44.266466
# Unit test for method email of class Person
def test_Person_email():
    random_Person = Person()
    random_Person.email()
    random_Person.email(unique = True)
    random_Person.email(unique = True, domains = ('gmail.com', 'mail.ru'))

#Unit test for method full_name of class Person

# Generated at 2022-06-21 16:37:48.419825
# Unit test for method password of class Person
def test_Person_password():
    p = Person()
    assert p.password() == 'Y@(3q3A[tw'
    assert p.password(length=15) == '!S/FNXuUF7VWC1'
    assert p.password(length=25, hashed=True) == 'fe6f091f8e2dd67b6623a5c6a5e0e630'



# Generated at 2022-06-21 16:37:49.779028
# Unit test for method username of class Person
def test_Person_username():
    assert Person(random=Random()).username(template='ld') == 'e.1991'

# Generated at 2022-06-21 16:37:51.927174
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Can call method blood_type
    Person().blood_type()

# Generated at 2022-06-21 16:37:54.465913
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = PersonFactory()
    views_on = p.views_on()
    assert views_on in PERSON_VIEWS_ON

