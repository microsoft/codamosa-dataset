

# Generated at 2022-06-21 16:32:06.321575
# Unit test for method identifier of class Person
def test_Person_identifier():
    provider = Person(seed=123)
    assert provider.identifier() == "28-10/20"
    assert provider.identifier() == "27-49/43"
    assert provider.identifier(mask="##-##/##") == "64-02/53"
    assert provider.identifier(mask="####-###") == "3691-648"
    assert provider.identifier(mask="##-##/##") == "42-96/71"
    assert provider.identifier(mask="####-###") == "0540-447"
    assert provider.identifier(mask="##-##/##") == "96-23/32"
    assert provider.identifier(mask="####-###") == "6795-603"

# Generated at 2022-06-21 16:32:08.493261
# Unit test for method email of class Person
def test_Person_email():
    rnd = Random()
    for i in range(10000):
        email_1 = rnd.person().email()
        email_2 = rnd.person().email()
        assert email_1 != email_2

# Generated at 2022-06-21 16:32:12.929641
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    phone = p.telephone(mask='+7-(###)-###-###')
    print("The phone is: " + phone)


test_Person_telephone()




# Generated at 2022-06-21 16:32:15.273672
# Unit test for method name of class Person
def test_Person_name():
    from faker import Faker
    f = Faker()
    for i in range(0,10):
        print(f.name())


# Generated at 2022-06-21 16:32:19.869782
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    true_results = [
        'Asexuality', 'Bisexuality', 'Heterosexuality', 'Homosexuality', 'Pansexuality', 'Polysexuality', 'Queer'
    ]
    
    for i in range(100):
        result = Person.sexual_orientation()
        assert result in true_results



# Generated at 2022-06-21 16:32:26.176773
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Create new instance of class
    person = Person()

    for _ in range(5):
        job_experience = person.work_experience()
        # Check that job_experience is data list
        assert isinstance(job_experience, list)
        # Check that job_experience has items
        assert len(job_experience) > 0

    for _ in range(5):
        # Generate job_experience
        job_experience = person.work_experience(full_info=True)

        # Check that job_experience is data list
        assert isinstance(job_experience, list)
        # Check that job_experience has items
        assert len(job_experience) > 0

        # Get first job_experience item
        item = job_experience[0]

        # Check that item is data

# Generated at 2022-06-21 16:32:29.192835
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert (Person().identifier() == '75-38/24')

# Unittest for method sex of class Person

# Generated at 2022-06-21 16:32:33.993092
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    from yandex_fotki import Person
    from yandex_fotki.enums import BloodGroup
    for n in range(50):
        blood_type = Person().blood_type()
        flag = hasattr(BloodGroup, blood_type)
        assert flag

# Generated at 2022-06-21 16:32:37.515347
# Unit test for method telephone of class Person
def test_Person_telephone():
    from fake_ocean import Fake
    obj = Fake()
    obj.person.telephone("###-###-####")
    print(obj.person.telephone("###-###-####"))
    print("Test for method telephone of class Person")
from fake_ocean import Fake
obj = Fake()
obj.person.telephone("###-###-####")
print(obj.person.telephone("###-###-####"))
print("Test for method telephone of class Person")


# Generated at 2022-06-21 16:32:40.866714
# Unit test for method name of class Person
def test_Person_name():

    # test an unknown gender
    person = Person()
    with pytest.raises(NonEnumerableError) as exception:
        person.name(Gender(''))

    # test a correct parameters
    person = Person(seed=0)
    assert person.name(Gender.MALE) == 'Test'



# Generated at 2022-06-21 16:32:57.022134
# Unit test for method views_on of class Person
def test_Person_views_on():
    random_data = Person()
    views_data = random_data.views_on()
    assert views_data in [
        'Neutral',
        'Negative',
        'Positive'
    ]

# Generated at 2022-06-21 16:33:00.441906
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person('en')
    person.occupation()

# Generated at 2022-06-21 16:33:01.100122
# Unit test for method nationality of class Person
def test_Person_nationality():
    pass

# Generated at 2022-06-21 16:33:03.432283
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    for gender in Gender:
        for i in range(10):
            assert person.last_name(gender) in person.surnames(gender)


# Generated at 2022-06-21 16:33:09.493933
# Unit test for method identifier of class Person
def test_Person_identifier():
    """Unit test for method identifier of class Person."""
    try:
        x = PERSON.identifier()
        y = x.find('/')
        assert x[y-2] == '-'
    except AssertionError:
        print('Unit test for method identifier of class Person has failed.')
    else:
        print('Unit test for method identifier of class Person has passed.')



# Generated at 2022-06-21 16:33:11.977373
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email() != Person().email()

if __name__ == '__main__':
    import pytest, sys
    sys.exit(pytest.main(['-l', __file__]))

# Generated at 2022-06-21 16:33:13.447480
# Unit test for method name of class Person
def test_Person_name():
    faker = Faker()
    print(faker.name())

# Generated at 2022-06-21 16:33:16.394580
# Unit test for method weight of class Person
def test_Person_weight():
    assert(type(Person.weight())!=type(Person.weight(minimum=45, maximum=65)))

# Generated at 2022-06-21 16:33:17.783683
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert isinstance(person.height(), str)

# Generated at 2022-06-21 16:33:20.818274
# Unit test for method email of class Person
def test_Person_email():
    # Arrange
    person = Person()

    # Act
    actual = person.email()

    # Assert
    assert '@' in actual


# Generated at 2022-06-21 16:33:42.890021
# Unit test for method title of class Person
def test_Person_title():
    from hashlib import md5
    from random import seed
    from faker import Faker
    from faker.providers import BaseProvider
    from faker.providers.person.en_US import Provider as PersonProvider
    from faker.providers.person.es_MX import Provider as PersonProviderMX
    from faker.providers.person.ru_RU import Provider as PersonProviderRU

    f = Faker('ru_RU')
    f.add_provider(PersonProvider)
    f.add_provider(PersonProviderMX)
    f.add_provider(PersonProviderRU)

    f.seed_instance(0)
    f.seed(0)

    # en_US, gender=None
    seed(0)
    assert f.title() == 'MSc'
    seed(0)

# Generated at 2022-06-21 16:33:45.031709
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert Person().social_media_profile() == 'https://facebook.com/some_user'

# Generated at 2022-06-21 16:33:48.079470
# Unit test for method age of class Person
def test_Person_age():
    seed(1)               # constant seed for random
    p = Person()
    assert("21" == p.age())


# Generated at 2022-06-21 16:33:50.962419
# Unit test for method sex of class Person
def test_Person_sex():
    from fake.constants import Gender
    from fake import Fake
    fake = Fake()
    sex = fake.sex()
    assert sex in Gender._member_names_

# Generated at 2022-06-21 16:33:52.301642
# Unit test for method email of class Person
def test_Person_email():
    pass

# Generated at 2022-06-21 16:33:56.424815
# Unit test for method full_name of class Person
def test_Person_full_name():
    from faker.providers.person.ru_RU import Provider as Person
    pr = Person(None)
    name = pr.full_name()
    assert isinstance(name, str)
    assert name
    name = pr.full_name(reverse=True)
    assert isinstance(name, str)
    assert name
    obj = pr.full_name()
    assert obj != pr.full_name()
    assert obj != pr.full_name(reverse=True)
    obj = pr.full_name(reverse=True)
    assert obj != pr.full_name()
    assert obj != pr.full_name(reverse=True)

# Generated at 2022-06-21 16:34:00.447565
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person()
    assert '+7-(###)-###-####' in provider.telephone()
    assert '+7-(###)-###-####' in provider.telephone(mask=' +7-(###)-###-####')



# Generated at 2022-06-21 16:34:01.893948
# Unit test for method title of class Person
def test_Person_title():

    person = Person()
    print(person.title())



# Generated at 2022-06-21 16:34:03.592602
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert re.match(r'\S+', Person().sexual_orientation()) is not None


# Generated at 2022-06-21 16:34:07.238781
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    academic_degree_list = [Person().academic_degree() for _ in range(1000)]
    assert academic_degree_list == pytest.approx(["Bachelor", "Master", "Candidate of Sciences", "PhD", "Doctor of Sciences"], rel=0.1)

# Unit test fot method views_on of class Person

# Generated at 2022-06-21 16:34:20.981106
# Unit test for method language of class Person
def test_Person_language():
    for _ in range(10):
        assert Person().language()

# Generated at 2022-06-21 16:34:23.421584
# Unit test for method weight of class Person
def test_Person_weight():
    # Arrange
    person = Person()
    # Act
    result = person.weight()
    # Assert
    assert isinstance(result, int)

# Generated at 2022-06-21 16:34:25.295052
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']
    assert isinstance(person.nationality(), str)

# Generated at 2022-06-21 16:34:36.359761
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    with Person().seed(10):
        assert Person().work_experience() == 'Work experience: 2 years.'
        assert Person().work_experience(minimum=1) == 'Work experience: 1 year.'
        assert Person().work_experience(minimum=2) == 'Work experience: 2 years.'
        assert Person().work_experience(minimum=3) == 'Work experience: 3 years.'
        assert Person().work_experience(minimum=5) == 'Work experience: 5 years.'
        assert Person().work_experience(minimum=1, maximum=4) == 'Work experience: 2 years.'
        assert Person().work_experience(minimum=1, maximum=5) == 'Work experience: 2 years.'
        assert Person().work_experience(minimum=1, maximum=6) == 'Work experience: 2 years.'
        assert Person().work_

# Generated at 2022-06-21 16:34:41.179370
# Unit test for method telephone of class Person
def test_Person_telephone():
    pr = Person(seed=12345)
    assert pr.telephone() == '+1-(916)-568-4133'
    assert pr.telephone() == '+1-(929)-148-0914'
    assert pr.telephone() == '+1-(986)-054-2284'
    assert pr.telephone() == '+1-(988)-184-2120'
    assert pr.telephone() == '+1-(928)-948-4952'

    assert pr.telephone('8-###-###-##-##', '#') == '8-988-184-21-20'
    assert pr.telephone('8-###-###-##-##', '#') == '8-928-948-49-52'

# Generated at 2022-06-21 16:34:44.044674
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    for i in range(100):
        print(Person().academic_degree())
    print('Unit test for method academic_degree of class Person is OK')

# Generated at 2022-06-21 16:34:44.875574
# Unit test for method first_name of class Person
def test_Person_first_name():
    assert Person().first_name()

# Generated at 2022-06-21 16:34:56.437955
# Unit test for method age of class Person
def test_Person_age():
    from fakeit.datasets import GENDERS
    from fakeit.distribution import Samples
    from fakeit.utils import get_random_item
    from fakeit.numbergenerator import NumberGenerator as ng
    from fakeit.enum import Gender
    from fakeit.person import Person
    from fakeit.randomprovider import RandomProvider
    from fakeit.randomprovider import SEED

    NUMBER_OF_TESTS = 1000

    def assert_age(minimum: int, maximum: int, gender: Gender,
                   random: RandomProvider) -> None:
        person = Person(rnd=random)
        age = person.age(minimum, maximum, gender)
        assert age <= maximum
        assert age >= minimum
        assert isinstance(age, int)


# Generated at 2022-06-21 16:34:57.199135
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider, Person)



# Generated at 2022-06-21 16:35:01.350814
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    result = person.nationality()
    assert isinstance(result, str)
 

# Generated at 2022-06-21 16:35:28.361859
# Unit test for method name of class Person
def test_Person_name():
    import pytest
    from pydenticon import Person, Gender, NonEnumerableError
    from random import Random

    rnd = Random(123456)
    rnd.seed(123456)
    person = Person(rnd)

    # Assert name getter
    male_name = person.name(Gender.male)
    assert male_name in MALE_NAMES

    # Assert NonEnumerableError
    with pytest.raises(NonEnumerableError):
        person.name(None)