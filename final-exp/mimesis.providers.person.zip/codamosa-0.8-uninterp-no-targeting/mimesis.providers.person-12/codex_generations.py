

# Generated at 2022-06-21 16:31:46.143884
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person.academic_degree()  in (Person.get_data('academic_degree'))


# Generated at 2022-06-21 16:31:48.487402
# Unit test for method sex of class Person
def test_Person_sex():
    for _ in range(100):
        sex = Person(random.Random()).sex()
        assert isinstance(sex, str)

test_Person_sex()

# Generated at 2022-06-21 16:31:50.026820
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person(seed=123)
    assert p.work_experience() == '7 years'


# Generated at 2022-06-21 16:31:53.806452
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    """Tests the method blood_type of the class Person"""
    assert getattr(Person, 'blood_type')
    assert callable(Person.blood_type)

# Generated at 2022-06-21 16:31:56.057321
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    assert person.nationality() in person._data['nationality']



# Generated at 2022-06-21 16:31:58.829505
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Arrange
    # Act
    blood_group = Person().blood_type()
    # Assert
    assert blood_group in BLOOD_GROUPS


# Generated at 2022-06-21 16:32:02.285589
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert Alias(Person(), 'social_media_profile')(
        site=SocialNetwork.VK) == Person().social_media_profile(
            site=SocialNetwork.VK)

# Generated at 2022-06-21 16:32:10.423387
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    occupation = person.occupation()

# Generated at 2022-06-21 16:32:15.222989
# Unit test for method political_views of class Person
def test_Person_political_views():
    try:
        assert isinstance(Person().political_views(), str)
    except AssertionError:
        print('Method Person.political_views() returned %s instead of str'
              % type(Person().political_views()))
        
test_Person_political_views()

# Generated at 2022-06-21 16:32:20.167768
# Unit test for method height of class Person
def test_Person_height():
    # Test edge cases
    r = Person()
    assert(r.height(0, 0) == "0.00")
    assert(r.height(1, 1) == "1.00")
    assert(r.height(1, 2) == "2.00")
    assert(r.height(1, 2.5) == "2.50")
    
    

# Generated at 2022-06-21 16:32:29.044756
# Unit test for method age of class Person
def test_Person_age():
    age = Person().age()
    assert age > 0 and age < 100

# Generated at 2022-06-21 16:32:30.929783
# Unit test for method political_views of class Person
def test_Person_political_views():
    person = Person(seed=0)
    assert person.political_views() == 'Nonpartisan'

# Generated at 2022-06-21 16:32:33.992878
# Unit test for method sex of class Person
def test_Person_sex():
    item = Person().sex()

    assert item is not None



# Generated at 2022-06-21 16:32:35.659567
# Unit test for method telephone of class Person
def test_Person_telephone():
    r = Person(random=Random())
    default = '+7-(###)-###-####'
    assert r.telephone() == r.telephone(default)

# Generated at 2022-06-21 16:32:37.622971
# Unit test for method email of class Person
def test_Person_email():
    
    person = Person(random=Random())
    person.email()

# Generated at 2022-06-21 16:32:39.919286
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        assert Person.nationality() in NATIONALITIES



# Generated at 2022-06-21 16:32:42.915938
# Unit test for method age of class Person
def test_Person_age():
    p = Person()
    assert p.age(min_age=20, max_age=30) in range(20, 30)


# Generated at 2022-06-21 16:32:51.588290
# Unit test for method full_name of class Person
def test_Person_full_name():
    p1 = Person()
    assert isinstance(p1.full_name(), str)
    assert isinstance(p1.full_name(reverse=True), str)
    p1 = Person(gender='male')
    assert isinstance(p1.full_name(), str)
    assert isinstance(p1.full_name(reverse=True), str)
    p1 = Person(gender='female')
    assert isinstance(p1.full_name(), str)
    assert isinstance(p1.full_name(reverse=True), str)
    
test_Person_full_name()

# Generated at 2022-06-21 16:32:54.224452
# Unit test for method views_on of class Person
def test_Person_views_on():
    for _ in range(10):
        assert len(Person().views_on()) > 1
        

# Generated at 2022-06-21 16:32:57.978294
# Unit test for method views_on of class Person
def test_Person_views_on():
    random.seed(12345)
    r = random.Random()
    
    p = Person(seed=r)
    
#     views_on = p.views_on()
    assert p.views_on() == 'Negative'



# Generated at 2022-06-21 16:33:22.869607
# Unit test for method password of class Person

# Generated at 2022-06-21 16:33:23.788968
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    Person().work_experience()


# Generated at 2022-06-21 16:33:27.100269
# Unit test for method surname of class Person
def test_Person_surname():
    provider = Person()
    result = provider.surname()
    assert result in provider._data['surname']


# Generated at 2022-06-21 16:33:31.569841
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # The case of None value of parameter
    assert Person().work_experience() is None
    # The case of random value of parameter
    assert Person().work_experience(random=True) is None
    # The case of given value of parameter
    assert Person().work_experience(years=10) == 10

# Generated at 2022-06-21 16:33:36.285869
# Unit test for method occupation of class Person
def test_Person_occupation():
    occupation_list = []
    for i in range(0,1000):
        new_occupation = Person().occupation()
        if new_occupation not in occupation_list:
            occupation_list.append(new_occupation)
    print(occupation_list)
    print(len(occupation_list))
test_Person_occupation()


# Generated at 2022-06-21 16:33:37.934067
# Unit test for method university of class Person
def test_Person_university():
    person = Person()

    assert person.university() in PERSON_UNIVERSITIES


# Generated at 2022-06-21 16:33:38.869560
# Unit test for method telephone of class Person
def test_Person_telephone():
    assert Person().telephone()

# Generated at 2022-06-21 16:33:43.601388
# Unit test for method language of class Person
def test_Person_language():
    # Initialize faker object
    faker = Person()
    result = faker.language()
    
    # Expected result
    expected_result = faker._data["language"][0]

    # Check if result is as expected
    assert result == expected_result
test_Person_language()

# Generated at 2022-06-21 16:33:50.962414
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    # Instance of class Person
    person = Person()

    # Check method sexual_orientation with default params
    sexuality = person.sexual_orientation()
    assert sexuality in list(PERSON_SEXUALITY)

    # Check method sexual_orientation with True symbol
    sexuality = person.sexual_orientation(symbol=True)
    assert sexuality in list(PERSON_SEXUALITY_SYMBOLS)

# Generated at 2022-06-21 16:33:53.078246
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    for _ in range(100):
        assert person.university() in UNIVERSITIES

# Generated at 2022-06-21 16:34:02.177932
# Unit test for method last_name of class Person
def test_Person_last_name():
    # Testing last_name method
    from faker import Faker
    fake = Faker('ru_RU')
    assert isinstance(fake.last_name(), str)


# Generated at 2022-06-21 16:34:03.506706
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person.seed is None


# Generated at 2022-06-21 16:34:05.754384
# Unit test for method nationality of class Person
def test_Person_nationality():
    for _ in range(100):
        nationality = Person().nationality()
        assert isinstance(nationality, str)
        assert len(nationality) > 0


# Generated at 2022-06-21 16:34:07.926251
# Unit test for method title of class Person
def test_Person_title():
    person = Person(random=MockRandom())
    gen = person.title()
    assert gen == 'Dr'

# Generated at 2022-06-21 16:34:12.401974
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person()
    first_name = p.first_name()
    assert isinstance(first_name, str), 'Is not string'
    assert len(first_name) > 0, 'Is empty string'
    print(f'Person.first_name() = {first_name}')


# Generated at 2022-06-21 16:34:21.737316
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Faker()
    code = provider.random.choice(CALLING_CODES)
    default_mask = '{}-(###)-###-####'.format(code)
    telephone = provider.telephone(provider.random.choice(CALLING_CODES))
    assert re.fullmatch('^\+\d{1,2}\-(?:\d{3}\-){2}\d{4}$', telephone) is not None, \
        'telephone {} not match default mask: {}'.format(telephone, default_mask)



# Generated at 2022-06-21 16:34:24.333665
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    assert isinstance(person.weight(38, 90), int) == True,\
        "Expected int, got {0}".format(type(person.weight(38, 90)))

# Generated at 2022-06-21 16:34:25.180970
# Unit test for method title of class Person
def test_Person_title():
    assert Person().title()

# Generated at 2022-06-21 16:34:29.983667
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    id_ = rnd_id()
    p = Person()
    res1 = p.academic_degree()
    seed(id_)
    p = Person()
    res2 = p.academic_degree()
    assert res1 == res2
    print(res1)


# Generated at 2022-06-21 16:34:33.244631
# Unit test for method surname of class Person
def test_Person_surname():
    """Unit test for method surname of class Person"""
    # Generate object
    person = Person(seed=1)
    # Check type
    assert isinstance(person.surname(Gender.MALE), str)


# Generated at 2022-06-21 16:34:47.501768
# Unit test for method username of class Person
def test_Person_username():

    from mimesis.providers.base import BaseProvider


# Generated at 2022-06-21 16:34:52.406132
# Unit test for method worldview of class Person
def test_Person_worldview():
    from faker.generator import Generator
    provider = Person(Generator())
    for _ in range(10):
        worldview = provider.worldview()
        assert isinstance(worldview, str)
person = Person()
for _ in range(10):
    print(person.worldview())


# Generated at 2022-06-21 16:34:55.574588
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    for _ in range(100):
        profile = Person().social_media_profile()
        assert isinstance(profile, str) and profile.count('/') == 1

# Generated at 2022-06-21 16:35:01.452718
# Unit test for method university of class Person
def test_Person_university():
    import hypothesis
    import hypothesis.strategies

    @hypothesis.given(hypothesis.strategies.integers())
    def test(seed_value: int):
        seed = seed_value
        random = Random(seed=seed)

        # Unit test for method university of class Person
        person = Person(seed=seed)
        result = person.university()
        result_hash = hashlib.sha256(result.encode()).hexdigest()
        assert result_hash == 'e365c1b2cdc5ef5ad3f3a5d5b2434bc461365e01b8d1be2442744fa7a9fa9c64'

    test()

# Generated at 2022-06-21 16:35:12.357299
# Unit test for method title of class Person
def test_Person_title():
    person_generator = Person()
    person_generator._random_seed(5)

    assert person_generator.title() == "PhD"
    assert person_generator.title() == "PhD"
    assert person_generator.title() == "PhD"
    assert person_generator.title() == "Dr."
    assert person_generator.title() == "Dr."
    assert person_generator.title() == "Dr."
    assert person_generator.title() == "Dr."
    assert person_generator.title() == "Jr."
    assert person_generator.title() == "Jr."
    assert person_generator.title() == "Jr."
    assert person_generator.title() == "Jr."
 

# Generated at 2022-06-21 16:35:13.853782
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person()
    assert type(p.avatar()) == str


# Generated at 2022-06-21 16:35:18.924700
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    from distark.commons.lang.l_enum import BloodType
    
    p = Person()
    for i in range(10):
        assert BloodType.is_oneof(p.blood_type())
        
test_Person_blood_type()

 

# Generated at 2022-06-21 16:35:21.754020
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    university = person.university()
    assert university
    assert isinstance(university, str) is True
    assert len(university) > 0


# Generated at 2022-06-21 16:35:28.155287
# Unit test for method first_name of class Person
def test_Person_first_name():
    sex = Gender.male
    provider = Person(seed=42)
    assert provider.name(sex) == 'Максим'
    assert provider.name(sex).lower() == 'максим'
    assert provider.name(sex) == 'Максим'
    assert provider.name(gender=sex) == 'Максим'
    assert provider.first_name(gender=sex) == 'Максим'
    assert provider.name(gender=sex) == 'Максим'

# Generated at 2022-06-21 16:35:29.946202
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person(seed=6)
    assert p.sex() == 'Female'

# Generated at 2022-06-21 16:35:38.728568
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    rnd = Random()
    test = rnd.choice(BLOOD_GROUPS)
    # Start of test
    rnd.seed(0)
    person = Person(rnd)
    assert person.blood_type() == test

# Generated at 2022-06-21 16:35:40.870687
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    assert person.views_on() in ['Negative', 'Positive']


# Generated at 2022-06-21 16:35:46.619157
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person(seed=42)

    assert person.first_name() == 'John'
    assert person.first_name() == 'Daniel'
    assert person.first_name() == 'Henry'
    assert person.first_name(gender=Gender.MASCULINE) == 'James'
    assert person.first_name(gender=Gender.FEMININE) == 'Michelle'


# Generated at 2022-06-21 16:35:50.660896
# Unit test for method password of class Person
def test_Person_password():
    person = Person()
    password = person.password()

    assert len(password) == 8
    assert isinstance(password, str)

# Generated at 2022-06-21 16:35:52.967387
# Unit test for method worldview of class Person
def test_Person_worldview():
    provider = Person(seed=1)
    assert provider.worldview() == 'Atheism'

# Generated at 2022-06-21 16:35:59.929436
# Unit test for method name of class Person
def test_Person_name():
    for _ in range(100):
        # get random object
        gender = get_random_item(Gender, rnd=random)
        
        # get object of class Person
        obj = Person(random)
        
        # get name
        name = obj.name(gender)
        
        # test
        assert isinstance(name, str)
        
        if gender == Gender.MALE:
            assert name in MALE_FIRST_NAMES
        elif gender == Gender.FEMALE:
            assert name in FEMALE_FIRST_NAMES
        elif gender == Gender.UNKNOWN:
            assert name in UNISEX_FIRST_NAMES

# Generated at 2022-06-21 16:36:02.358650
# Unit test for method password of class Person
def test_Person_password():
    """Unit test for method password of class Person."""
    p = Person(random=Random())
    assert len(p.password(length=10)) == 10



# Generated at 2022-06-21 16:36:03.441777
# Unit test for method political_views of class Person
def test_Person_political_views():
    gender = Gender.MALE

    result = Person().political_views()
    expected = "Libertarian"

    assert result == expected


# Generated at 2022-06-21 16:36:05.923748
# Unit test for method university of class Person
def test_Person_university():
    provider = Person()
    result = provider.university()
    assert result in UNIVERSITIES

# Generated at 2022-06-21 16:36:08.037493
# Unit test for method surname of class Person
def test_Person_surname():
    random.seed(87645)
    assert Person(locale='ru_RU').surname() == 'Виноградов'


# Generated at 2022-06-21 16:36:25.100594
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():

    # Get Facebook profile
    facebook_profile = Person().social_media_profile(SocialNetwork.FACEBOOK)

    assert 'https://facebook.com/' in facebook_profile

    # Get Twitter profile
    twitter_profile = Person().social_media_profile(SocialNetwork.TWITTER)

    assert 'https://twitter.com/' in twitter_profile


# Generated at 2022-06-21 16:36:26.573142
# Unit test for method full_name of class Person
def test_Person_full_name():
    p = Person()
    assert isinstance(p.full_name(), str)


# Generated at 2022-06-21 16:36:27.651680
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert Person().occupation() in Person()._data['occupation']


# Generated at 2022-06-21 16:36:29.412673
# Unit test for method nationality of class Person
def test_Person_nationality():

    # arrange
    person = Person()

    # act
    nationality = person.nationality()

    # assert
    print(nationality)

# Generated at 2022-06-21 16:36:33.291529
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    # Testing work_experience method
    assert person.work_experience(maximum=20) < 21 and person.work_experience(maximum=20) > -1
test_Person_work_experience()

# Generated at 2022-06-21 16:36:37.647218
# Unit test for method worldview of class Person
def test_Person_worldview():
    import random
    import string
    import names
    provider = names.Provider(random.Random(12345))
    assert provider.worldview() == 'Theism'
    
    

# Generated at 2022-06-21 16:36:39.325454
# Unit test for constructor of class Person
def test_Person():
    """Test the constructor of the class Person."""
    person = Person()
    assert isinstance(person, Person)

# Generated at 2022-06-21 16:36:42.923020
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    for i in range(99):
        assert isinstance(person.name(), str)

# Generated at 2022-06-21 16:36:45.607819
# Unit test for method occupation of class Person
def test_Person_occupation():
    # Unit test for method occupation of class Person
    print('Method Person.occupation')
    print('-' * 20)

    for _ in range(1, 5):
        print(Person.occupation())
        print()

    print('-' * 20)
    print()



# Generated at 2022-06-21 16:36:47.066542
# Unit test for method height of class Person
def test_Person_height():
    #assert Person().height() == '1.81'
    assert len(Person().height()) == 4
    
    

# Generated at 2022-06-21 16:37:02.057235
# Unit test for method password of class Person
def test_Person_password():
    for _ in range(100):
        provider = Person()
        assert len(provider.password()) == 8

# Generated at 2022-06-21 16:37:08.555322
# Unit test for method occupation of class Person
def test_Person_occupation():
    import unittest
    from Person import Person
    from pprint import pprint

    class PersonTestCase(unittest.TestCase):
        def setUp(self):
            self.p = Person(seed=1234)

        def test_person_occupation(self):
            occupation = self.p.occupation()
            result = occupation
            self.assertEqual(result, 'Psychotherapist')

    unittest.main()


# Generated at 2022-06-21 16:37:10.443956
# Unit test for method full_name of class Person
def test_Person_full_name():
    s = Seed.random()
    p = Person(s)
    for i in range(100):
        n = p.full_name()
        assert len(n.split(' ')) == 2
    
test_Person_full_name()

# Generated at 2022-06-21 16:37:14.972516
# Unit test for method identifier of class Person
def test_Person_identifier():
    solutions = [
        '07-97/04',
        '07-97/04',
        '07-97/04',
        '07-97/04',
        '07-97/04',
        '07-97/04',
        '07-97/04',
        '07-97/04',
        '07-97/04',
        '07-97/04',
    ]
    for i in range(10):
        assert solutions[i] == Person().identifier()

# Generated at 2022-06-21 16:37:16.607084
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert isinstance(Person().academic_degree(), str)
    assert 0 < len(Person().academic_degree()) < 15


# Generated at 2022-06-21 16:37:22.880873
# Unit test for method worldview of class Person
def test_Person_worldview():
    # create an instance of the class Person
    person = Person()
    # get a random worldview
    worldview = person.worldview()
    # check the length of worldview
    assert isinstance(worldview, str)
    assert len(worldview) >= 1
    # repeat 100 times
    for _ in range(100):
        # get a random worldview
        worldview = person.worldview()
        # check the length of worldview
        assert isinstance(worldview, str)
        assert len(worldview) >= 1


# Generated at 2022-06-21 16:37:27.015577
# Unit test for method password of class Person
def test_Person_password():
    # Arrange
    fake = Faker()
    length = 12

    # Act
    password = fake.password(length, hashed=False)

    # Assert
    assert isinstance(password, str)
    assert len(password) == length
    
    

# Generated at 2022-06-21 16:37:30.118228
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person()
    result = p.sex(symbol=True)
    if result in ('❌', '⭕'):
        assert True
    else:
        raise AssertionError('Incorrect result.')
import unittest

# Generated at 2022-06-21 16:37:32.129961
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person.last_name() in \
           ['Brooks', 'Riley', 'Walsh', 'Barbosa', 'Perez', 'Fischer', 'Elliott']

# Generated at 2022-06-21 16:37:39.714875
# Unit test for method weight of class Person
def test_Person_weight():
    # Test 1
    assert (Person.weight(0,0) == 0)
    # Test 2
    assert (Person.weight(5,5) == 5)
    # Test 3
    assert (len(str(Person.weight(5,5))) == 1)
    # Test 4
    assert (len(str(Person.weight(5,6))) == 1)
    # Test 5
    assert(len(str(Person.weight(5,7))) == 1)
    # Test 6
    assert (len(str(Person.weight(5,8))) == 1)
    # Test 7
    assert (len(str(Person.weight(5,9))) == 1)
    # Test 8
    assert (len(str(Person.weight(5,10))) == 2)
    # Test 9

# Generated at 2022-06-21 16:38:07.746715
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    seeds = [3646, 4346, 4352, 96884, 78024, 87594]
    for i in range(len(seeds)):
        person = Person(i)
        assert person.work_experience() == "8"


# Generated at 2022-06-21 16:38:10.628243
# Unit test for method avatar of class Person
def test_Person_avatar():
    p = Person(seed=1234)
    for i in range(10):
        result = p.avatar()
        expected = 'https://api.adorable.io/avatars/256/' \
                   'dc7547fed509e6c1e9e392c6d2cbab0c.png'
        assert result == expected


# Generated at 2022-06-21 16:38:16.758896
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person(providers={'social_network': 'test'})
    data = provider.random.choice(SOCIAL_NETWORKS.values())

    assert provider.social_media_profile(provider.random.choice(list(SOCIAL_NETWORKS))) == f'http://{data}/%s' % provider.username()


# Generated at 2022-06-21 16:38:19.010472
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    assert re.match(r'^[A-Z][a-z]{1,10}', person.last_name())



# Generated at 2022-06-21 16:38:23.988515
# Unit test for method gender of class Person
def test_Person_gender():
    """
    Generate gender, code for the representation of human sexes is an
    international standard that defines a representation of human sexes
    through a language-neutral single-digit code or symbol of gender.
    """
    gender = Person(random=Random()).gender(iso5218=False)
    assert gender in ('Male', 'Female', 'Not specified')
    
    

# Generated at 2022-06-21 16:38:29.145410
# Unit test for method email of class Person
def test_Person_email():
    person_a = Person()
    person_b = Person()
    assert person_a.email() != person_b.email()

    # Testing unique parameter of method email
    email = person_a.email(unique=True)

    # If we use same object we should get the same email
    assert person_a.email(unique=True) == email
    # If we use a new object we should get a different email
    assert person_b.email(unique=True) != email


# Generated at 2022-06-21 16:38:31.099931
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    data = person.work_experience(period='month')
    assert data.count(' ') == 1


# Generated at 2022-06-21 16:38:32.456418
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    occupations = person.occupation()
    assert occupations in person._data['occupation']


# Generated at 2022-06-21 16:38:34.794210
# Unit test for constructor of class Person
def test_Person():

    random = Random()
    random.seed(1234)

    person = Person(seed=1234)
    assert person.random.randstr(1) == 'a'

    person = Person(random=random)
    assert person.random.randstr(1) == 'a'



# Generated at 2022-06-21 16:38:40.106769
# Unit test for method sex of class Person
def test_Person_sex():
    """Tests for method Person.sex
    """
    print('method Person.sex')

    # Test without gender
    person = Person()
    sex = person.sex()
    assert sex in GENDER_TYPES

    # Test with symbol
    sex_symbol = person.sex(symbol=True)
    assert sex_symbol in GENDER_SYMBOLS

# Generated at 2022-06-21 16:39:35.642129
# Unit test for method age of class Person
def test_Person_age():
    provider = Person()

    # min = default = 18
    assert provider.age() == 18

    # min = 18
    # max = 40
    assert provider.age(maximum=40) == 18

    # min = 15
    # max = default = 100
    assert provider.age(minimum=15) == 18

    # min = 15
    # max = 40
    assert provider.age(minimum=15, maximum=40) == 18


# Generated at 2022-06-21 16:39:37.913451
# Unit test for method worldview of class Person
def test_Person_worldview():
    generator = Generator()
    worldview = generator.worldview()
    assert worldview in PERSON_DATA['worldview']
test_Person_worldview()

# Generated at 2022-06-21 16:39:51.044179
# Unit test for constructor of class Person
def test_Person():
    p = Person()
    assert p.full_name()
    assert p.full_name(reverse=True)
    assert p.full_name(Gender.MALE)
    assert p.full_name(Gender.MALE, reverse=True)
    assert p.full_name(Gender.FEMALE)
    assert p.full_name(Gender.FEMALE, reverse=True)
    assert p.name()
    assert p.name(Gender.MALE)
    assert p.name(Gender.FEMALE)
    assert p.surname()
    assert p.surname(Gender.MALE)
    assert p.surname(Gender.FEMALE)
    assert p.last_name()
    assert p.last_name(Gender.MALE)

# Generated at 2022-06-21 16:39:52.410132
# Unit test for method weight of class Person
def test_Person_weight():
    assert w.weight() in range(38, 90)



# Generated at 2022-06-21 16:39:59.420853
# Unit test for method first_name of class Person
def test_Person_first_name():
    for i in range(5):
        p = Person()
        assert_equal(isinstance(p.first_name(), str) is True, True)
        assert_equal(isinstance(p.first_name(Gender.FEMALE), str) is True, True)
        assert_equal(isinstance(p.first_name(Gender.MALE), str) is True, True)
        assert_equal(isinstance(p.first_name(Gender.OTHER), str) is True, True)
        # This will throw an exception.
        # assert_equal(isinstance(p.first_name(Gender.GENDER), str) is True, True)

# Generated at 2022-06-21 16:40:04.996384
# Unit test for method political_views of class Person
def test_Person_political_views():
    '''
    Test Person.political_views
    '''
    print('Test Person.political_views')

    p = Person()
    assert p.political_views() in ('Centrism', 'Liberalism',
                                   'Left-wing', 'Socialism',
                                   'Communism', 'Fascism',
                                   'Right-wing', 'Monarchism',
                                   'Anarchism', 'Conservatism')

# Generated at 2022-06-21 16:40:09.309536
# Unit test for method telephone of class Person
def test_Person_telephone():
    import json

    with open(os.path.join(os.path.dirname(__file__), 'data.json')) as fd:
        data = json.load(fd)

    person = Person(data)
    assert person.telephone().startswith('+')



# Generated at 2022-06-21 16:40:12.046744
# Unit test for method last_name of class Person
def test_Person_last_name():
    """Generate a random last name."""
    fake = Faker()
    person = Person(fake)

    result = person.last_name()
    assert isinstance(result, str)

# Generated at 2022-06-21 16:40:19.021183
# Unit test for method university of class Person
def test_Person_university():
    new_person = Person() # instantiation of the Person class
    list_university = [] # empty list will be populated by the Person.university method
    
    for i in range(100):
        university = new_person.university()
        list_university.append(university)
        
    print(list_university)

# Generated at 2022-06-21 16:40:22.604670
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in GENDERS
    assert isinstance(Person().gender(), str)

    assert Person().gender(iso5218=True) in [0, 1, 2, 9]
    assert isinstance(Person().gender(iso5218=True), int)

    assert Person().gender(symbol=True) in GENDER_SYMBOLS
    assert isinstance(Person().gender(symbol=True), str)