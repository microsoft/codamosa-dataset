

# Generated at 2022-06-21 16:31:43.493716
# Unit test for method first_name of class Person
def test_Person_first_name():
    p = Person()
    generated_name = p.first_name()
    assert (type(generated_name) == str), "function Person.first_name() returns not a string"
        

# Generated at 2022-06-21 16:31:45.194617
# Unit test for method gender of class Person
def test_Person_gender():
    for i in range(1000):
        assert isinstance(Person().gender(), str), 'The method returned an incorrect value'

# Generated at 2022-06-21 16:31:46.498853
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert is_enum(Person.academic_degree())



# Generated at 2022-06-21 16:31:50.066717
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    for i in range(100):
        x = p.sexual_orientation()
        assert isinstance(x, str)
        assert x in SEXUALITY
test_Person_sexual_orientation()
Person.sexual_orientation.__annotations__


# Generated at 2022-06-21 16:31:53.856510
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    p = Person()
    deg = p.academic_degree()
    assert isinstance(deg, str)
    assert deg in ACADEMIC_DEGREES



# Generated at 2022-06-21 16:31:55.642906
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert Person().blood_type() in BLOOD_GROUPS

# Generated at 2022-06-21 16:31:57.315728
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert person.random is not None


# Generated at 2022-06-21 16:32:07.636920
# Unit test for method email of class Person
def test_Person_email():
    # Test email
    r = Person()
    assert isinstance(r.email(), str)
    assert isinstance(r.email(unique=False), str)
    assert isinstance(r.email(unique=True), str)
    assert isinstance(r.email(domains=('primer.org',), unique=False), str)
    assert isinstance(r.email(domains=('primer.org',), unique=True), str)
    assert re.match(
        r"^[\w!#\$%&'\*\+\-/=\?\^`\{\|\}~]+@[\w\.-]+$", r.email())

# Generated at 2022-06-21 16:32:13.034444
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person().political_views() in ['Liberal', 'Socialist', 'Neutral', 'Capitalist', 'Communist', 'Conservative', 'Patriot', 'Monarchist', 'Anarchist', 'It is political nonsense', 'None']

# Generated at 2022-06-21 16:32:17.436298
# Unit test for method title of class Person
def test_Person_title():
    profile = Person(None)
    title_type: TitleType = profile._validate_enum(TitleType.Prefix, TitleType)
    gender: Gender = profile._validate_enum(Gender.Male, Gender)
    result = profile.title(gender, title_type)
    print(result)


# Generated at 2022-06-21 16:32:29.692535
# Unit test for constructor of class Person
def test_Person():
    person = Person()

    assert person.seed is None
    assert person.random.seed is None
    assert isinstance(person._data, dict)
    assert 'name' in person._data

    person = Person(seed=12345)

    assert person.seed == 12345
    assert person.random.seed == 12345


# Generated at 2022-06-21 16:32:31.149844
# Unit test for method height of class Person
def test_Person_height():
    height = Person.height()
    assert isinstance(height, str)

# Generated at 2022-06-21 16:32:39.919454
# Unit test for method height of class Person
def test_Person_height():
    from ..utils.random import RANDOM
    from ..utils.enum import Gender
    from .birthday import Birthday

    person = Person(RANDOM)
    gender = Gender.MALE

    assert type(person.height()) is str
    assert type(person.height(minimum=1, maximum=2)) is str
    assert person.height(minimum=1, maximum=2) < "2"
    assert person.height(minimum=0.45, maximum=2) < "2"
    assert person.height(minimum=1, maximum=1.8) < "1.8"


# Generated at 2022-06-21 16:32:42.558932
# Unit test for method full_name of class Person
def test_Person_full_name():
    assert Person().full_name().split()[-1] in Surnames.list()

# Generated at 2022-06-21 16:32:45.500519
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    for i in range(100):
        assert isinstance(p.views_on(), str)



# Generated at 2022-06-21 16:32:49.541323
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert Person().social_media_profile(SocialNetwork.FACEBOOK) == \
        'https://facebook.com/mann1'
    assert Person().social_media_profile(SocialNetwork.VK) == \
        'https://vk.com/milton_wissing'


# Generated at 2022-06-21 16:32:50.938562
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    person.last_name()

# Generated at 2022-06-21 16:32:54.505031
# Unit test for method age of class Person
def test_Person_age():
    assert Person().age(42) == 42
    assert isinstance(Person().age(42, 'min'), int)
    assert isinstance(Person().age(42, 'max'), int)
    assert isinstance(Person().age(42, 'random'), int)
    assert isinstance(Person().age(42, 'all'), dict)


# Generated at 2022-06-21 16:33:00.052905
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    print(person.work_experience())


# Generated at 2022-06-21 16:33:05.945484
# Unit test for method username of class Person
def test_Person_username():
    """Test Person.username() method"""
    person = Person()

    for i in range(100):
        assert re.match(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*',
                        person.username('UUU_d'))

    with pytest.raises(ValueError) as e:
        person.username('UUUdd')
    assert 'not supported' in str(e.value)

    # Test alias
    person.username('UUUdd')  # Test for exception.



# Generated at 2022-06-21 16:33:14.500165
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    assert person.views_on() in person._data['views_on']

# Generated at 2022-06-21 16:33:16.640026
# Unit test for method nationality of class Person
def test_Person_nationality():
  pass

# Generated at 2022-06-21 16:33:18.003736
# Unit test for method first_name of class Person
def test_Person_first_name():
    g = Person()
    assert g.first_name() != ''

# Generated at 2022-06-21 16:33:22.220050
# Unit test for method title of class Person
def test_Person_title():
    pl = Person(random=FakeRandom(4))
    assert pl.title(gender=Gender.MALE) == 'PhD'
    pl = Person(random=FakeRandom(5))
    assert pl.title(gender=Gender.FEMALE, title_type=TitleType.PREFIX) == ''
    pl = Person(random=FakeRandom(10))
    assert pl.title(title_type=TitleType.SUFFIX) == ""



# Generated at 2022-06-21 16:33:24.570595
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    faker = Faker()
    num = faker.random.randint(0, 5)
    assert num != 0
    assert isinstance(num, int)


# Generated at 2022-06-21 16:33:31.792420
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    assert p.title() == p.title()
    assert p.title(gender='Male') == p.title(gender='Male')
    assert p.title(gender='Female') == p.title(gender='Female')
    assert p.title(title_type='prefix') == p.title(title_type='prefix')
    assert p.title(title_type='suffix') == p.title(title_type='suffix')


# Generated at 2022-06-21 16:33:33.470927
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person(seed=42)
    assert person.last_name() == 'King'


# Generated at 2022-06-21 16:33:36.380361
# Unit test for method password of class Person
def test_Person_password():
    password = Person().password()
    assert (
        len(password) == 8
    )
    assert (
        all(char in string.printable for char in password)
    )

# Generated at 2022-06-21 16:33:39.373634
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person(random=Random(seed=2))
    assert p.social_media_profile(
        site=SocialNetwork.FACEBOOK
    ) == 'https://facebook.com/Celestia_27'


# Generated at 2022-06-21 16:33:43.899882
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    for i in range(0, 100):
        assert person.last_name() != None

# Generated at 2022-06-21 16:33:57.439252
# Unit test for method avatar of class Person
def test_Person_avatar():
    assert Person().avatar() == 'https://api.adorable.io/avatars/256/d41d8cd98f00b204e9800998ecf8427e.png'
    assert Person().avatar(size=128) == 'https://api.adorable.io/avatars/128/d41d8cd98f00b204e9800998ecf8427e.png'


# Generated at 2022-06-21 16:33:59.740558
# Unit test for method title of class Person
def test_Person_title():
    p = Person(generator=Generator())
    ans = p.title()
    assert isinstance(ans, str)

# Generated at 2022-06-21 16:34:02.443663
# Unit test for method email of class Person
def test_Person_email():
    p = Person()
    assert p.email() == p.email()
    assert p.email() != p.email()
# Unit tests for method gender of class Person

# Generated at 2022-06-21 16:34:04.111391
# Unit test for method first_name of class Person
def test_Person_first_name():
    gen = Person()
    assert gen.first_name() in gen.names()


# Generated at 2022-06-21 16:34:11.644112
# Unit test for method weight of class Person
def test_Person_weight():
    print("\n Unit test for method weight of class Person")
    print("Test 1: 38<=weight<=90")
    ob1 = Person()
    i = 0
    while(i < 100):
        weight = ob1.weight(38, 90)
        if weight<38 or weight>90:
            print("Test 1: failed")
            exit(-1)
        i += 1
    print("Test 1: passed")
    print("Test 2: 98<=weight<=100")
    ob1 = Person()
    i = 0
    while(i < 100):
        weight = ob1.weight(98, 100)
        if weight<98 or weight>100:
            print("Test 2: failed")
            exit(-1)
        i += 1
    print("Test 2: passed")

# Generated at 2022-06-21 16:34:16.504415
# Unit test for method last_name of class Person
def test_Person_last_name():
    '''
    Check that method last_name returns a surname.
    '''
    # Initialization
    provider = Person()
    
    # Execution
    surname = provider.last_name()

    # Verification
    assert surname in SURNAMES, '''
    The name must be selected from the list of names.
    '''
    
    
test_Person_last_name()
 

# Generated at 2022-06-21 16:34:24.094410
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person(seed=1234)
    name1 = person.full_name()
    assert type(name1) is str
    name2 = person.full_name(reverse=True)
    assert type(name2) is str
    name3 = person.full_name(gender=Gender.Male)
    assert type(name3) is str
    name4 = person.full_name(gender=Gender.Female)
    assert type(name4) is str
    
    

# Generated at 2022-06-21 16:34:26.315128
# Unit test for method weight of class Person
def test_Person_weight():
    p = Person()
    w = p.weight()
    assert w >= 38 and w <= 90, 'weight should be >= 38 and <= 90'
    

# Generated at 2022-06-21 16:34:31.799349
# Unit test for method password of class Person
def test_Person_password():
    for _ in range(5):
        generated_password = Person().password()
        assert(len(generated_password)>=8) # pass
        assert(len(generated_password)<=16) # pass
        assert(generated_password[0].isalpha()) # pass
        assert(generated_password[-1].isalnum()) # pass


# Generated at 2022-06-21 16:34:43.022746
# Unit test for method first_name of class Person
def test_Person_first_name():
    import pytest

    TEST_CASES = (
        (
            {'gender': Gender.MALE},
            'first_name',
            Gender.MALE
        ),
        (
            {'gender': Gender.FEMALE},
            'first_name',
            Gender.FEMALE
        ),
    )

    for test_case in TEST_CASES:
        provider = Person(**test_case[0])
        method = getattr(provider, test_case[1])
        value = method(test_case[2])
        exception = False

        try:
            assert isinstance(value, str)
        except Exception:
            exception = True


# Generated at 2022-06-21 16:34:59.787692
# Unit test for method language of class Person
def test_Person_language():
    n = 0
    for i in range(1000):

        p = Person()
        p.set_seed(3)
        out = p.language()
        assert out in ['English', 'German', 'Spanish', 'French', 'Italian', 'Irish'], \
            "Failed Person.language(): language != 'English', 'German', 'Spanish', 'French', 'Italian', 'Irish'"
        n += 1


# Generated at 2022-06-21 16:35:06.782956
# Unit test for method identifier of class Person
def test_Person_identifier():
    prov = Provider()
    assert isinstance(prov.identifier(), str)
    assert re.match(r'^(?:\d{2}-\d{2}/\d{2})|(?:##-##/##)$', prov.identifier())
    assert re.match(r'^(?:\d{2}-\d{2}/\d{2})|(?:##-##/##)$', prov.identifier(mask='##-##/##'))


# Generated at 2022-06-21 16:35:11.443726
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person."""
    provider = Person(seed=0)
    assert provider.seed == 0
    assert provider.random_state.uniform() == 0.8444218515250481



# Generated at 2022-06-21 16:35:12.980284
# Unit test for method work_experience of class Person
def test_Person_work_experience():

    provider = Person()
    results = provider.work_experience()
    assert isinstance(results, list)
    assert len(results) <= 2


# Generated at 2022-06-21 16:35:19.056527
# Unit test for method identifier of class Person
def test_Person_identifier():
    assert repr(Person().identifier(mask='#')) not in ['(None)', 'None', '()']
    assert isinstance(Person().identifier(mask='#'), str)
    assert isinstance(Person().identifier(mask='@'), str)
    assert isinstance(Person().identifier(mask='##-##/##'), str)

# Generated at 2022-06-21 16:35:20.245371
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert(len(Person().political_views())>0)

# Generated at 2022-06-21 16:35:22.551962
# Unit test for method avatar of class Person
def test_Person_avatar():
    for _ in range(10):
        size: int = random.randint(10, 512)
        assert Person.avatar(size)

# Generated at 2022-06-21 16:35:24.590353
# Unit test for method age of class Person
def test_Person_age():
    for i in range(100):
        age = Person.age()
        assert isinstance(age, int)

# Generated at 2022-06-21 16:35:27.159868
# Unit test for constructor of class Person
def test_Person():
    provider = Person(seed=42)
    assert isinstance(provider, Person)



# Generated at 2022-06-21 16:35:29.299602
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    assert Person.work_experience() != None
# Test for method work_experience of class Person

# Generated at 2022-06-21 16:36:05.556605
# Unit test for method worldview of class Person
def test_Person_worldview():
    choices = [
        'Pantheism', 'Deism', 'Agnosticism', 'Atheism', 'Theism',
        'Christianity', 'Judaism', 'Islam', 'Orthodoxy', 'Buddhism',
        'Neopaganism', 'Neopaganism', 'Hinduism', 'Neopaganism',
        'Neopaganism', 'Neopaganism', 'Neopaganism', 'Neopaganism',
        'Neopaganism', 'Neopaganism', 'Council', 'Confucianism',
        'Neopaganism', 'Neopaganism', 'Neopaganism', 'Neopaganism',
        'Neopaganism', 'Neopaganism', 'Neopaganism', 'Neopaganism',
        'Neopaganism'
    ]
    p = Person()

# Generated at 2022-06-21 16:36:07.093493
# Unit test for method height of class Person
def test_Person_height():
    provider = faker.providers.person.Person()
    assert isinstance(provider.height(), str)

# Generated at 2022-06-21 16:36:16.593466
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person.surname(None) != None
    assert Person.surname(None) != ''
    assert Person.surname(None) != ' '
    assert Person.surname(None) != '   '
    assert Person.surname(None) != '    ' 
    assert Person.surname(None) != '     '
    assert Person.surname(None) != '      '
    assert Person.surname(None) != '       '
    assert Person.surname(None) != '        '
    assert Person.surname(None) != '         '
    assert Person.surname(None) != '          '
    assert Person.surname(None) != '           '
    assert Person.surname(None) != '            '

# Generated at 2022-06-21 16:36:20.048034
# Unit test for method first_name of class Person
def test_Person_first_name():
    # GIVEN a Person object
    person = Person()

    # WHEN calling the method first_name
    first_name: str = person.first_name()

    # THEN the first_name is a string
    assert isinstance(first_name, str)


# Generated at 2022-06-21 16:36:21.162850
# Unit test for method university of class Person
def test_Person_university():
    assert Person().university() in UNIVERSITY

# Generated at 2022-06-21 16:36:22.714330
# Unit test for method name of class Person
def test_Person_name():
    # print(Person().name()) # for test
    assert isinstance(Person().name(), str)


# Generated at 2022-06-21 16:36:24.646853
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person('ru')
    assert "\+7-(###)-###-##-##" == person.telephone()

# Generated at 2022-06-21 16:36:29.864184
# Unit test for method identifier of class Person
def test_Person_identifier():
    from faker import Faker
    from .utils import dist
    from .utils.general import seed_it

    seed_it(a=8, b=1)  # Set the seed
    faker = Faker('ru_RU')
    ids = ['07-97/04', 'U6-08/45', 'F6-47/22', 'P6-30/90']
    assert [faker.person.identifier() for _ in range(4)] == ids
    assert dist([faker.person.identifier() for _ in range(20)], ids) < 0.05

# Generated at 2022-06-21 16:36:35.309270
# Unit test for method surname of class Person
def test_Person_surname():
    p = Person()

# Generated at 2022-06-21 16:36:37.257431
# Unit test for method surname of class Person
def test_Person_surname():
    # Full coverage
    surname = Person().surname()
    assert surname

# Generated at 2022-06-21 16:37:13.387352
# Unit test for method password of class Person
def test_Person_password():
    import pytest
    person = Person()

    # Test that persons's password method returns string
    assert isinstance(person.password(), str)
    # Test that person's password method returns string with length 8
    assert len(person.password()) == 8
    # Test that person's password method returns string with length 10
    assert len(person.password(10)) == 10
    # Test that person's password method returns string with length 20
    assert len(person.password(20)) == 20
    # Test that person's password method returns string with length 40
    assert len(person.password(40)) == 40
    # Test that person's password method returns string with length 50
    assert len(person.password(50)) == 50
    # Test that person's password method returns string with length 100
    assert len(person.password(100)) == 100
    # Test that person

# Generated at 2022-06-21 16:37:15.334412
# Unit test for method language of class Person
def test_Person_language():
    a = Person()
    assert a.language() in LANGUAGES
    assert a.language() not in ['\ufeff', ' ']


# Generated at 2022-06-21 16:37:15.857831
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    pass

# Generated at 2022-06-21 16:37:18.916562
# Unit test for method first_name of class Person
def test_Person_first_name():
    """
    Make sure that the method «first_name» of the class
    «Person» returns the name of the person.
    """

    name = Person().first_name()
    assert name.isalpha()
    assert isinstance(name, str)


# Generated at 2022-06-21 16:37:21.570170
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    x = person.occupation()
    assert x


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-21 16:37:24.387845
# Unit test for method political_views of class Person
def test_Person_political_views():
    # Call the function under test.
    function_under_test = Person.political_views
    #
    # Testing
    #
    assert function_under_test() == function_under_test()
    assert isinstance(function_under_test(), str)

# Generated at 2022-06-21 16:37:27.902698
# Unit test for method views_on of class Person
def test_Person_views_on():
    fake = Faker(seed=20) # Initialize Faker with a fixed seed for test repeatability
    for _ in range(100):
        assert fake.views_on() == 'Positive'

        

# Generated at 2022-06-21 16:37:30.394754
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    weight = person.weight()
    assert isinstance(weight, int)
    assert weight > 0
    assert weight < 91

# Generated at 2022-06-21 16:37:36.981230
# Unit test for method height of class Person
def test_Person_height():
    Faker.seed(0)
    assert Faker().height() in ['1.50', '1.80', '1.69', '1.84', '1.93', '1.72', '1.79', '1.54', '1.82', '1.83', '1.78', '1.60', '1.88', '1.91', '1.65', '1.86', '1.71', '1.59', '1.85', '1.58']



# Generated at 2022-06-21 16:37:38.788133
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    assert isinstance(person.weight(), int)



# Generated at 2022-06-21 16:38:35.882195
# Unit test for method username of class Person
def test_Person_username():
    kwargs = {'template': 'ld'}
    person = Person()
    assert person.username(**kwargs) == 'horton1935'
    person = Person(seed=42)
    assert person.username(**kwargs) == 'zach3956'
    assert person.username(**kwargs) == 'zach3956'
    person = Person(seed=42)
    assert person.username(**kwargs) == 'zach3956'
    assert person.username(**kwargs) == 'zach3956'
    kwargs = {'template': 'l-d'}
    person = Person()
    assert person.username(**kwargs) == 'wolff-17'
    person = Person(seed=42)
    assert person.username(**kwargs) == 'zach-18'

# Generated at 2022-06-21 16:38:45.047718
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    assert re.match(r'\+([1-9][0-9]{1,2})\-(\d{3})\-(\d{3})\-(\d{4})',
                    p.telephone())

    assert re.match(r'\+([1-9][0-9]{1,2})\-(\d{3})\-(\d{3})\-(\d{4})',
                    p.telephone(mask='+#-###-###-####'))

    assert p.telephone(mask='+#   ###   ###   ####', placeholder=' ')


# Generated at 2022-06-21 16:38:46.275623
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert Person().blood_type() in BLOOD_GROUPS

# Generated at 2022-06-21 16:38:54.826095
# Unit test for method password of class Person
def test_Person_password():
    """ Tests for method password of class Person

    Test for limits for password length
    Test for hash of password
    Test for good case
    """

    # Good case
    person = Person()
    assert person.password(length=8, hashed=False)

    # Hash case
    assert person.password(length=8, hashed=True)

    # Bad case
    with pytest.raises(ValueError):
        person.password(length=0, hashed=False)
        
    # Bad case
    with pytest.raises(ValueError):
        person.password(length=999, hashed=False)

# Generated at 2022-06-21 16:38:56.435868
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person('en_EN')
    assert person.blood_type() in BLOOD_GROUPS

# Generated at 2022-06-21 16:39:04.836557
# Unit test for method username of class Person
def test_Person_username():
    assert len(Person().username()) == 10
    assert Person().username(template='U_d') == Person().username()
    assert Person().username(template='l.d') == Person().username()
    assert Person().username(template='l-d') == Person().username()
    assert Person().username(template='ld') == Person().username()
    assert Person().username(template='UU-d') == Person().username()
    assert Person().username(template='UU.d') == Person().username()
    assert Person().username(template='UU_d') == Person().username()
    assert Person().username(template='U.d') == Person().username()
    assert Person().username(template='U-d') == Person().username()
    
    

# Generated at 2022-06-21 16:39:06.369475
# Unit test for method full_name of class Person
def test_Person_full_name():
    """Unit test for method full_name of class Person."""
    p = Person()
    assert type(p.full_name()) == str



# Generated at 2022-06-21 16:39:07.936353
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    degree = Person().academic_degree()
    assert degree in ACADEMIC_DEGREES
    assert isinstance(degree, str)



# Generated at 2022-06-21 16:39:09.660520
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person()
    b = p.blood_type()
    assert b in BLOOD_GROUPS

# Generated at 2022-06-21 16:39:11.606722
# Unit test for method full_name of class Person
def test_Person_full_name():
    """
    >>> p = Person('uk')
    >>> p.full_name()
    'Олег Сорокін'
    """
    pass


# Generated at 2022-06-21 16:41:08.801887
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    fuck = Person()
    data = fuck.work_experience()
    assert isinstance(data, str)


# Generated at 2022-06-21 16:41:12.602563
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    value = person.username(template='Ud')
    assert re.fullmatch(r'[A-Z][a-z]+\d{4}', value)



# Generated at 2022-06-21 16:41:20.871441
# Unit test for method age of class Person
def test_Person_age():
    with pytest.raises(AssertionError):
        Person.age(minimum=15, maximum=10)

    with pytest.raises(AssertionError):
        Person.age(minimum=0.5)

    with pytest.raises(AssertionError):
        Person.age(maximum=-1)

    age1 = Person.age(minimum=20, maximum=30)
    assert 20 <= age1 <= 30

    age2 = Person.age(maximum=90)
    assert 0 <= age2 <= 90

    age3 = Person.age(minimum=10)
    assert 10 <= age3 <= 120

    age4 = Person.age()
    assert 0 <= age4 <= 120

    Person.set_locale('ru')
    age5 = Person.age()
    assert 0 <= age5 <= 120


# Unit test