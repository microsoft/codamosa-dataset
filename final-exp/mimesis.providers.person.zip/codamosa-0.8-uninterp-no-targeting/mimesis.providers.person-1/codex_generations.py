

# Generated at 2022-06-21 16:31:51.032478
# Unit test for method blood_type of class Person
def test_Person_blood_type():    
    # Loop over blood_type() from Person class, 1000 times.
    for _ in range(1000):
        # Assert test_Person_blood_type of class Person
        assert blood_type() in BLOOD_GROUPS

# Generated at 2022-06-21 16:31:52.902842
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in VIEWS_ON



# Generated at 2022-06-21 16:31:57.171011
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    p = Person()
    blood_type = p.blood_type()
    assert type(blood_type) == str
    assert blood_type in BLOOD_GROUPS
    
test_Person_blood_type()

# Generated at 2022-06-21 16:32:04.045275
# Unit test for method surname of class Person
def test_Person_surname():
    assert Person().surname(gender=Gender.FEMALE)
    assert Person().surname(gender=Gender.MALE)
    assert Person().surname(gender=Gender.UNKNOWN)
    assert Person().surname()

    with pytest.raises(TypeError):
        assert Person().surname(gender=None)

    with pytest.raises(NonEnumerableError):
        assert Person().surname(gender=0)



# Generated at 2022-06-21 16:32:07.412823
# Unit test for method sex of class Person
def test_Person_sex():

    assert(Person().sex() in ('Male', 'Female')), 'Failed to test function sex'
    assert(Person().sex(symbol=True) in ('♂', '♀')), 'Failed to test function sex'


# Generated at 2022-06-21 16:32:08.809082
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    unit_test = Person()
    assert unit_test.blood_type() in BLOOD_GROUPS



# Generated at 2022-06-21 16:32:12.880863
# Unit test for method identifier of class Person
def test_Person_identifier():
    generator = Person()
    result = generator.identifier('##-##/##')
    assert result == '13-59/03', 'Failed test Person.identifier()'

# Generated at 2022-06-21 16:32:14.369728
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    assert isinstance(person.worldview, str)

# Generated at 2022-06-21 16:32:16.401372
# Unit test for method first_name of class Person
def test_Person_first_name():
    with Person() as person:
        assert type(person.first_name()) is str


# Generated at 2022-06-21 16:32:20.085869
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person()
    assert person.avatar() == 'https://api.adorable.io/avatars/256/efac10f41d7e8b0bf8d7f558f933a2f1.png'

test_Person_avatar()

# Generated at 2022-06-21 16:32:33.993072
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person(localization='en')
    assert type(person.weight()) is int

# Generated at 2022-06-21 16:32:36.696251
# Unit test for method identifier of class Person
def test_Person_identifier():
    pid = Person().identifier(mask='@##/####')
    assert pid
    assert re.match(r'[a-zA-Z]{1,2}\d{2}/\d{4}', pid)


if __name__ == '__main__':
    # Unit test for method identifier of class Person
    test_Person_identifier()

# Generated at 2022-06-21 16:32:37.737868
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person('en')
    assert person.social_media_profile() in SOCIAL_NETWORKS.values()

# Generated at 2022-06-21 16:32:44.592804
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    academic_degrees = ["Master's degree",
                        "Certificate of Higher Education",
                        "Honours degree",
                        "Associate degree",
                        "Doctoral degree",
                        "Undergraduate degree",
                        "Higher National Diploma",
                        "A Level",
                        "Bachelor's degree",
                        "GCSE",
                        "Higher School Certificate",
                        "International Baccalaureate",
                        "National Certificate",
                        "Ordinary National Diploma",
                        "PhD/doctorate",
                        "Postgraduate Certificate",
                        "Postgraduate Diploma",
                        "Professional Graduate Diploma in Education"]
                                
    p1 = Person()
    p2 = Person()
    p3 = Person()
    p4 = Person()
    p5 = Person()
    p6 = Person()
    p7 = Person()

# Generated at 2022-06-21 16:32:52.011931
# Unit test for method username of class Person
def test_Person_username():
    person = Person(random=Random())

    templates = ['U_d', 'U.d', 'U-d', 'UU-d', 'UU.d', 'UU_d', 'ld', 'l-d',
                 'Ud', 'l.d', 'l_d']

    for i in range(1000):
        template = person.random.choice(templates)
        username = person.username(template=template)
        assert re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', username)



# Generated at 2022-06-21 16:32:55.764955
# Unit test for method age of class Person
def test_Person_age():
    sut = Person()
    actual = sut.age()
    expected = int
    assert isinstance(actual, expected)
    assert 0 <= actual <= 100


# Generated at 2022-06-21 16:33:03.278956
# Unit test for method title of class Person
def test_Person_title():
    person = Person(['ru'])
    assert person.title(Gender.MALE, TitleType.PREFIX) == 'Джордж'
    assert person.title(Gender.MALE, TitleType.SUFFIX) == 'Барон'
    assert person.title(Gender.FEMALE, TitleType.PREFIX) == 'Росси'
    assert person.title(Gender.FEMALE, TitleType.SUFFIX) == 'Леди'



# Generated at 2022-06-21 16:33:08.132920
# Unit test for method language of class Person
def test_Person_language():
    """This function is unit-test for method language of class Person.
    """
    from faker import Faker
    fake = Faker()
    language = fake.language()
    assert(language.isalpha() == True) # All letters.


# Generated at 2022-06-21 16:33:10.215740
# Unit test for method password of class Person
def test_Person_password():
    assert len(Person(seed=123).password()) == 8
    assert len(Person(seed=123).password(length=20)) == 20

# Generated at 2022-06-21 16:33:17.470721
# Unit test for method weight of class Person
def test_Person_weight():
    from datetime import datetime
    from random import seed
    from faker import Faker

    fake = Faker()

    for i in range(10):
        # seed(i)  # NOT WORKING
        # datetime(i)  # same as seed(i)
        fake.seed_instance(i)
        assert isinstance(fake.weight(1, 5), int)
        assert fake.weight(1,5) >= 1
        assert fake.weight(1,5) <= 5


# Generated at 2022-06-21 16:33:44.340872
# Unit test for method password of class Person
def test_Person_password():
    person = Person('en')
    assert re.match(r'^\w{8}$', person.password())


# Generated at 2022-06-21 16:33:49.434396
# Unit test for method worldview of class Person
def test_Person_worldview():

    persons = [
        Person().worldview()
        for _ in range(1000)
    ]

    # All objects must be strings
    assert all(isinstance(person, str) for person in persons)

    # We have 10 distinct worldviews at the moment
    assert len(set(persons)) == 10



# Generated at 2022-06-21 16:33:53.454821
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    orientation = Person.sexual_orientation()
    assert isinstance(orientation, str)
    assert len(orientation) > 0

    orientation = Person.sexual_orientation(symbol=True)
    assert isinstance(orientation, str)
    assert len(orientation) > 0

# Generated at 2022-06-21 16:33:55.488488
# Unit test for method height of class Person
def test_Person_height():
    for _ in range(100):
        assert Person.height(0.5, 1.5) == '1.51'



# Generated at 2022-06-21 16:33:58.996643
# Unit test for method name of class Person
def test_Person_name():
    # Simple
    assert Person(random).name()
    # With gender
    assert Person(random).name(gender=Gender.female)

# Generated at 2022-06-21 16:34:01.757830
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    # arrange
    person = PersonProvider()
    # act
    result = person.sexual_orientation()
    # assert
    assert type(result) is str



# Generated at 2022-06-21 16:34:03.803296
# Unit test for method email of class Person
def test_Person_email():
    p = Person('ru')
    r = p.email(unique=True)
    assert r
    assert '@' in r


# Generated at 2022-06-21 16:34:11.457365
# Unit test for method email of class Person
def test_Person_email():
    import random
    from faker_e164.providers.person import Person
    from faker_e164 import E164PhoneNumber
    from faker import Generator
    from faker.providers.internet import Provider as InternetProvider
    from faker.providers.internet import Provider as InternetProvider
    from faker.providers.telephone_number import Provider as TelephoneNumberProvider
    # Arrange
    faker_gen = Generator()
    random.seed(1)
    faker_gen.add_provider(InternetProvider(faker_gen))
    faker_gen.add_provider(TelephoneNumberProvider(faker_gen))
    faker_gen.add_provider(Person(faker_gen))
    # Act
    actual = faker_gen.email()
    # Assert

# Generated at 2022-06-21 16:34:15.868928
# Unit test for method language of class Person
def test_Person_language():
    # instance without seed
    person = Person()
    res = person.language()
    assert res in PERSON_LANGUAGES
    assert isinstance(res, str)
    assert type(res) == str

    # instance with seed
    seed = 17
    person = Person(seed)
    res = person.language()
    assert res == 'Italian'


# Generated at 2022-06-21 16:34:24.094690
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Arrange
    person = Person(seed=0)
    expected = {'from': datetime.date(2016, 5, 8), 'to': None, 'position': 'accountant', 'location': 'Moscow'}
    # Action
    result = person.work_experience()
    # Assert
    assert expected == result, 'Expected {0}, but got {1}!'.format(expected, result)
    # OK
    print('A test for method work_experience of class Person has just passed.')

# Generated at 2022-06-21 16:34:41.831775
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person()
    assert(p.sex() in ['male', 'female', 'not specified'])
    assert(p.sex(symbol=True) in ['\U0001F6B9', '\U0001F6B9\U0001F3FB', '\U0001F6B9\U0001F3FB\U0001F3FD'])
    with pytest.raises(NonEnumerableError):
        p.sex(symbol=True, iso5218=9)

# Generated at 2022-06-21 16:34:48.767092
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    # surname is not tuple or list
    surname = person.surname(None)
    assert isinstance(surname, str)
    # surname is tuple or list
    surname1 = person.surname(None, 'A')
    assert isinstance(surname1, str)
    # Test surname with empty parameter
    assert isinstance(person.surname(None, ''), str)
    # Surname separated by gender.
    surname2 = person.surname(Gender.FEMALE)
    assert isinstance(surname2, str)
    # surname is None
    assert isinstance(person.surname(None, None), str)
    # surname is string
    assert isinstance(person.surname(None, 'A'), str)
    # surname is list

# Generated at 2022-06-21 16:34:51.529250
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person(seed=42)

    for _ in range(100):
        assert p.occupation() == 'Programmer'
        
test_Person_occupation()

# Generated at 2022-06-21 16:34:55.861104
# Unit test for method first_name of class Person
def test_Person_first_name():
    print("Method: first_name of class Person")

    assert Person().first_name() == "Vaness"
    assert Person().first_name(Gender.male) == "Kees"
    assert Person().first_name(Gender.female) == "Helena"

# Generated at 2022-06-21 16:34:57.317805
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    assert isinstance(person.work_experience(), str)


# Generated at 2022-06-21 16:35:01.350813
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    with pytest.raises(Exception):
        Person().work_experience(0, 1)


# Generated at 2022-06-21 16:35:05.573615
# Unit test for method email of class Person
def test_Person_email():
    # arrange
    provider = Person()
    # action
    result = provider.email(domains=('gmail.com',))
    result2 = provider.email(domains=('@gmail.com',))
    # assert
    assert result
    assert result2


# Generated at 2022-06-21 16:35:09.162675
# Unit test for method username of class Person
def test_Person_username():
    person = Person()

    assert re.fullmatch(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*',
                        person.username(template=None))

# Generated at 2022-06-21 16:35:13.079177
# Unit test for method height of class Person
def test_Person_height():
    a = Faker(seed=0)
    a.add_provider(Person)
    assert a.height() == "1.61"
    assert a.height(minimum=1.7) == "1.76"
    assert a.height(maximum=1.8) == "1.76"


# Generated at 2022-06-21 16:35:25.118346
# Unit test for method password of class Person
def test_Person_password():
    """
    Unit test for method password of class Person
    :return: None
    """
    from faker.providers.person import PERSON
    from faker.providers.user_agent import USER_AGENT

    seed = 0

    Person = PERSON(RND=RND, sprintf=sprintf, random=RND, seed=seed)
    UserAgent = USER_AGENT(RND=RND, sprintf=sprintf, random=RND, seed=seed)

    assert len(Person.password()) <= 8
    assert Person.password() == 'B,2X9?hN'

    assert len(Person.password(length=7)) <= 7
    assert Person.password(length=7) == 'bW,:.H\'6'

    assert len(Person.password(length=10)) <= 10

# Generated at 2022-06-21 16:35:34.656815
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person(random=Random(seed=1))
    print(person.nationality())
    assert person.nationality() == "Russian"


# Generated at 2022-06-21 16:35:37.059455
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()
    assert person.work_experience() != person.work_experience()
    assert person.work_experience()
    assert isinstance(person.work_experience(), str)


# Generated at 2022-06-21 16:35:47.245628
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from datetime import date
    from pydantic import BaseModel

    class Test(BaseModel):
        start_date: date
        end_date: date
        position: str
        company: str
        city: str

    person = Person()
    start_date = date(2018, 1, 1)
    end_date = date(2020, 1, 1)

    test_experience = person.work_experience(
        start_date=start_date, end_date=end_date)
    test_experience = [Test(**entry) for entry in test_experience]
    assert len(test_experience) == 3
    assert all(entry.start_date >= start_date for entry in test_experience)
    assert any(entry.start_date == start_date for entry in test_experience)
    assert all

# Generated at 2022-06-21 16:35:50.945053
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    provider = Person(random=Random())
    result = provider.sexual_orientation()
    assert result in SEXUALITY
    assert type(result) is str

# Generated at 2022-06-21 16:35:56.955224
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person(seed=1)
    value = person.last_name()
    assert value == 'Vandeventer'
    value = person.last_name(Gender.man)
    assert value == 'Mascarenas'
    value = person.last_name(Gender.woman)
    assert value == 'Peetoom'
    value = person.last_name(Gender.man, seed=1)
    assert value == 'Vandeventer'
    value = person.last_name(Gender.woman, seed=1)
    assert value == 'Peetoom'

# Generated at 2022-06-21 16:35:58.672388
# Unit test for method weight of class Person
def test_Person_weight():
    rnd = Random()
    p = Person(seed=7, random=rnd)
    assert p.weight() == 65



# Generated at 2022-06-21 16:36:02.999017
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    # Если метод не выбрасывает исключение
    try:
        test = Person()
        for i in range(5):
            test.work_experience()
    except Exception as e:
        raise

# Generated at 2022-06-21 16:36:05.835157
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    pr = Person()
    blood_type = pr.blood_type()
    assert (blood_type in BLOOD_GROUPS) == True
test_Person_blood_type()

# Generated at 2022-06-21 16:36:09.794570
# Unit test for method worldview of class Person
def test_Person_worldview():
    answer=Person().worldview()
    assert(answer == 'Pantheism' or answer == 'Christianity' or answer == 'Agnosticism' or answer == 'Judaism' or answer == 'Islam' or answer == 'Buddhism' or answer == 'Confucianism' or answer == 'Hinduism' or answer == 'Taoism' or answer == 'Atheism' or answer == 'Shintoism')
    return True


# Generated at 2022-06-21 16:36:14.173841
# Unit test for method telephone of class Person
def test_Person_telephone():
    generator = Generator()
    for i in range(100):
        assert re.match(r"^(\+\d{1,3}-)?\d{3}-\d{3}-\d{2}-\d{2}$",
                        generator.Person().telephone())

# Generated at 2022-06-21 16:36:42.923801
# Unit test for method full_name of class Person
def test_Person_full_name():
    import argparse
    parser = argparse.ArgumentParser(description='Faker tests')
    parser.add_argument('-g', '--generations', default=10 ** 6, type=int, help='For loop generations')
    args = parser.parse_args()

    import timeit
    start = timeit.default_timer()

    p = Person()
    for i in range(args.generations):
        assert type(p.full_name()) == str
        assert type(p.full_name(reverse=True)) == str

    stop = timeit.default_timer()
    print("(" + str(args.generations) + " Generations)")
    print('Time: ', stop - start)

    start = timeit.default_timer()

    p_seeded = Person(seed=123)

# Generated at 2022-06-21 16:36:43.946098
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person()
    worldview = person.worldview()
    assert worldview in worldviews

# Generated at 2022-06-21 16:36:44.836083
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    res = person.first_name()
    print(res)

# Generated at 2022-06-21 16:36:46.840673
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    profile = person.social_media_profile(site='Facebook')
    assert re.fullmatch(r'https://facebook.com/\w+', profile) is not None


# Generated at 2022-06-21 16:36:49.469257
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person(seed=12345)
    types_of_sexual_orientation = set([
        p.sexual_orientation() for _ in range(1000)])
    assert types_of_sexual_orientation == {'Heterosexuality',
                                           'Bisexuality',
                                           'Homosexuality'}
test_Person_sexual_orientation()

# Generated at 2022-06-21 16:36:51.172279
# Unit test for method views_on of class Person
def test_Person_views_on():
    # Test if the function returns a string
    assert isinstance(Person().views_on(), str)

# Generated at 2022-06-21 16:36:55.304569
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Test for method blood_type of class Person
    blood_type = Person.blood_type()
    assert blood_type in BLOOD_GROUPS
blood_type = Person.blood_type()
assert blood_type in BLOOD_GROUPS


# Generated at 2022-06-21 16:36:59.338595
# Unit test for method first_name of class Person
def test_Person_first_name():
    prs = Person()
    assert prs.first_name() == 'Johann'
    assert prs.first_name(gender=Gender.male) == 'Johann'
    assert prs.first_name(gender=Gender.female) == 'Elisabeth'



# Generated at 2022-06-21 16:37:01.004418
# Unit test for method gender of class Person
def test_Person_gender():
    assert Person().gender() in ('Male', 'Female')

# Generated at 2022-06-21 16:37:06.845021
# Unit test for method nationality of class Person
def test_Person_nationality():
    nationalities = ('Russian', 'Tajik', 'Latvian', 'Belarusian',
                     'Kazakh', 'Uzbek', 'Ukrainian', 'Kyrgyz', 'Estonian')

    person = Person()
    assert person.nationality() in nationalities


# Generated at 2022-06-21 16:37:54.715975
# Unit test for method email of class Person
def test_Person_email():
    assert Person('en').email() == 'g_fischer@skyrock.net'
    assert Person('en').email() == 'robinson@douban.com'
    assert Person('en').email() == 'k_w_chase@myspace.com'
    assert Person('en').email() == 'nathan@flavors.me'
    assert Person('en').email() == 'lonely_of_s_s_s@livejournal.com'
    assert Person('en').email() == 'jason@bandcamp.com'
    assert Person('en').email() == 's_j_k_s@pinterest.com'
    assert Person('en').email() == 'jonathan@live.com'
    assert Person('en').email() == 'kurt_a_t@wordpress.com'

# Generated at 2022-06-21 16:37:58.635429
# Unit test for method first_name of class Person
def test_Person_first_name():
	test = Person()
	try:
		val = test.first_name(gender='M')
		assert True, 'No error'
	except TypeError as e:
		assert False, 'Wrong TypeError'


# Generated at 2022-06-21 16:37:59.649499
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username()