

# Generated at 2022-06-21 16:31:41.642983
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    # TODO: Test the method sexual_orientation() from class Person

# Generated at 2022-06-21 16:31:44.051426
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    provider = Person()
    provider.seed(42)
    assert provider.work_experience() == -1.0


# Generated at 2022-06-21 16:31:44.910344
# Unit test for method height of class Person
def test_Person_height():
    person = Person()
    assert person.height()
    assert isinstance(person.height(), str)


# Generated at 2022-06-21 16:31:46.229935
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert person.blood_type() in BLOOD_GROUPS


# Generated at 2022-06-21 16:31:47.600069
# Unit test for method title of class Person
def test_Person_title():
    result = Person().title()
    assert isinstance(result, str)


# Generated at 2022-06-21 16:31:48.872442
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert Person().sexual_orientation() == 'Heterosexuality'

# Generated at 2022-06-21 16:31:54.674654
# Unit test for method height of class Person
def test_Person_height():
    def test_float_type_Person_height(number):
        assert isinstance(number, float)
    height = Person().height(minimum=1.0, maximum=1.9)
    # test_float_type_Person_height(height)
    assert isinstance(height, float)


# Generated at 2022-06-21 16:31:59.736792
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    p = Person()
    assert p.work_experience()
    assert isinstance(p.work_experience(), str)
    assert len(p.work_experience()) > 2
   
    for i in range(20):
        assert p.work_experience() in WORK_EXPERIENCE
# Test for method age of class Person

# Generated at 2022-06-21 16:32:02.706783
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    title = person.title()
    assert title
    assert decorators.length(title) > 0



# Generated at 2022-06-21 16:32:04.997884
# Unit test for method username of class Person
def test_Person_username():
    assert Person().username()
    assert '-' not in Person().username()
    assert '_' not in Person().username()
    assert '.' not in Person().username()



# Generated at 2022-06-21 16:32:12.829862
# Unit test for method views_on of class Person
def test_Person_views_on():
    for __ in range(100):
        result = Person.views_on()
        assert_instance_of(result, str)



# Generated at 2022-06-21 16:32:15.173033
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    prov = Person(seed=1)
    assert prov.work_experience() == '-2.5'



# Generated at 2022-06-21 16:32:23.944094
# Unit test for method username of class Person
def test_Person_username():
    p = Person('ru')
    username = p.username(template='l.d')
    assert isinstance(username, str)
    assert len(username) == 7
    assert username.count('.') == 1
    assert re.fullmatch(r'\w+\.d{4}', username)

    username = p.username(template='U-d')
    assert isinstance(username, str)
    assert username.count('-') == 1
    assert re.fullmatch(r'\w+-d{4}', username)

    username = p.username(template='UUd')
    assert isinstance(username, str)
    assert len(username) == 7
    assert re.fullmatch(r'\w\w+d{4}', username)

    username = p.username(template='UU-d')

# Generated at 2022-06-21 16:32:28.339331
# Unit test for method age of class Person
def test_Person_age():
    """Tests for method age of class Person."""
    p = Person('ru')
    for i in range(100):
        age = p.age(minimum=0, maximum=110)
        assert 0 <= age <= 110

# Generated at 2022-06-21 16:32:39.919020
# Unit test for method full_name of class Person
def test_Person_full_name():
    # type: () -> None

    # Check if full name is a str
    p = Person()
    full_name = p.full_name()
    assert isinstance(full_name, str)

    # Check if names are male
    p = Person()
    full_name = p.full_name(Gender.MALE)
    assert full_name.split()[0] not in FEMALE_NAMES
    p = Person()
    full_name = p.full_name(Gender.UNDISCLOSED)
    assert full_name.split()[0] not in FEMALE_NAMES

    # Check if names are female
    p = Person()
    full_name = p.full_name(Gender.FEMALE)
    assert full_name.split()[0] not in MALE_NAMES
    p = Person

# Generated at 2022-06-21 16:32:43.906034
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    """Tests for method academic_degree of class Person."""

    p = Person()
    assert p.academic_degree() in ACADEMIC_DEGREES



# Generated at 2022-06-21 16:32:53.579498
# Unit test for constructor of class Person

# Generated at 2022-06-21 16:32:56.125524
# Unit test for method language of class Person
def test_Person_language():
    person = Person(random_seed=time.time())
    assert person.language() in LANGUAGES

# Generated at 2022-06-21 16:32:58.080603
# Unit test for method surname of class Person
def test_Person_surname():
    from pprint import pprint

    p = Person()
    pprint(p.surname())


# Generated at 2022-06-21 16:33:06.290343
# Unit test for method political_views of class Person
def test_Person_political_views():
    political_views = [
        'Anarchist',
        'Communist',
        'Centrist',
        'Conservative',
        'Eco-socialist',
        'Eco-socialist',
        'Fascist',
        'Liberal',
        'Libertarian',
        'Maoist',
        'Marxist',
        'New Left',
        'Post-Marxist',
        'Social democracy',
        'Socialist',
        'Stalinist',
        'Trotskyist',
        'Ultra-left',
        'Ultra-right',
        'Zhdanovism',
        'Zionism']
    p = Person(seed=None)
    assert p.political_views() in political_views
    print('Successfully passed!')


# Generated at 2022-06-21 16:33:12.357110
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person()
    assert person.random.seed is None
    person.identifier()
    assert person.random.seed is not None



# Generated at 2022-06-21 16:33:22.198426
# Unit test for method weight of class Person
def test_Person_weight():
    # Test for weight between 38 and 90 (inclusive)
    for i in range(100):
        value = Person.weight(minimum=38, maximum=90)
        assert value >= 38 and value <= 90

    # Test for weight between 38 and 90 (not inclusive)
    for i in range(100):
        value = Person.weight(minimum=38, maximum=90)
        assert value > 38 and value < 90

    # Test for non-integer minimum and maximum
    value = Person.weight(minimum=38.5, maximum=90.5)
    assert isinstance(value, int)

    # Test for non-integer minimum and maximum
    value = Person.weight(minimum=38.5, maximum=90.5)
    assert value >= 38 and value <= 90

    # Test for non-integer minimum and maximum (not inclusive)
    value = Person

# Generated at 2022-06-21 16:33:23.302857
# Unit test for method height of class Person
def test_Person_height():
    assert Person.height()


# Generated at 2022-06-21 16:33:25.957353
# Unit test for method age of class Person
def test_Person_age():
    person = Person(seed=9)
    actual = person.age(minimum=18, maximum=35)
    expected = 25
    assert actual == expected

# Generated at 2022-06-21 16:33:30.411587
# Unit test for method age of class Person
def test_Person_age():
    r = Person()
    r.seed(0)
    assert r.age() == 8
    r.seed(1)
    assert r.age() == 15
    r.seed(2)
    assert r.age() == 16


# Generated at 2022-06-21 16:33:32.461692
# Unit test for method last_name of class Person
def test_Person_last_name():
    """Testing Person.last_name()"""
    person = Person()
    assert isinstance(person.last_name(), str)



# Generated at 2022-06-21 16:33:34.501379
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    with pytest.raises(NonEnumerableError):
        Person().sexual_orientation(symbol='all')

# Generated at 2022-06-21 16:33:37.681650
# Unit test for method age of class Person
def test_Person_age():
    assert Person().age() in range(18, 50)
    assert Person().age(minimum=25) >= 25
    assert Person().age(maximum=61) <= 61
    assert Person().age(minimum=25, maximum=61) in range(25, 61)

# Generated at 2022-06-21 16:33:38.992073
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    assert person.university() != None

# Generated at 2022-06-21 16:33:44.179189
# Unit test for method occupation of class Person
def test_Person_occupation():
    from fake.generators import Person
    p = Person(seed=42)

    assert p.occupation() == 'Government official',\
           'The nationality of seed 42 should be "Government official"'

    p = Person(seed=42)
    assert p.occupation() == 'Government official',\
           'Calling twice with the same seed should give the same results.'



# Generated at 2022-06-21 16:33:58.123689
# Unit test for method email of class Person
def test_Person_email():
    person = Person()
    result = person.email()
    assert result == 'eliezer45@sbcglobal.net'
    result = person.email(unique=True)
    assert result == 'esuitedc@yahoo.com'

# Just a common test for the Person class

# Generated at 2022-06-21 16:34:07.176715
# Unit test for method last_name of class Person
def test_Person_last_name():
    from faker import Factory
    from faker.providers import person as p
    from faker.providers.person.zh_CN import Provider as PersonZh_CN
    from faker.providers.person.sv_SE import Provider as PersonSv_SE
    from faker.providers.person.ja_JP import Provider as PersonJa_JP
    from faker.providers.person.ko_KR import Provider as PersonKo_KR
    from faker.providers.person.ru_RU import Provider as PersonRu_RU
    from faker.providers.person.it_IT import Provider as PersonIt_IT
    from faker.providers.person.es_ES import Provider as PersonEs_ES
    from faker.providers.person.en_CA import Provider as PersonEn_CA

# Generated at 2022-06-21 16:34:09.619061
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    surname = person.surname(gender=Gender.male)
    assert isinstance(surname, str)

# Generated at 2022-06-21 16:34:13.272565
# Unit test for method identifier of class Person
def test_Person_identifier():
    person = Person()
    mask = '@@-@@/##'
    identifier = person.identifier(mask)
    length = len(identifier)
    print(identifier, length)


if __name__ == '__main__':
    test_Person_identifier()

# Generated at 2022-06-21 16:34:14.479809
# Unit test for method worldview of class Person
def test_Person_worldview():
    result = Person.worldview()
    assert isinstance(result, str)

# Generated at 2022-06-21 16:34:24.094812
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    provider = Person()
    arg = 'de'
    func = provider.work_experience
    result = func(arg)
    assert result == provider.work_experience(arg)
    assert result != provider.work_experience()
    assert result != provider.work_experience('en')
    assert result != provider.work_experience(arg,in_years=True)
    assert result != provider.work_experience(arg,in_years=True,minimum=1)
    assert result != provider.work_experience(arg,in_years=True,minimum=1,maximum=7)
    assert len(result) > 0



# Generated at 2022-06-21 16:34:26.014339
# Unit test for method surname of class Person
def test_Person_surname():
    with Person() as p:
        p.surname(gender=Gender.MALE) == 'Пушкин'


# Generated at 2022-06-21 16:34:31.142867
# Unit test for method sex of class Person
def test_Person_sex():
    """Unit test for method sex of class Person"""
    from faker import Faker
    fake = Faker()
    fake.seed(0)
    sex = fake.sex(iso5218=True)
    assert sex == 1, sex


# Generated at 2022-06-21 16:34:33.160798
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person(locale='ru')
    result = person.academic_degree()
    assert isinstance(result, str)

# Generated at 2022-06-21 16:34:36.275729
# Unit test for method occupation of class Person
def test_Person_occupation():
    provider = Person()
    assert provider.occupation() in provider._data['occupation']

Person.test_Person_occupation = test_Person_occupation


# Generated at 2022-06-21 16:34:48.690673
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    blood_type = person.blood_type()
    assert isinstance(blood_type, str)
    assert blood_type in BLOOD_GROUPS

# Generated at 2022-06-21 16:34:56.773341
# Unit test for method full_name of class Person
def test_Person_full_name():
    person1 = Person('1')
    person2 = Person('2')
    person3 = Person('3')
    person4 = Person('4')
    person5 = Person('5')

    assert person1.full_name(reverse=True) != person2.full_name(reverse=True)
    assert person3.full_name(reverse=True) != person4.full_name(reverse=True)
    assert person5.full_name(reverse=True) != person1.full_name(reverse=True)
    
    assert isinstance(person5.full_name(reverse=True), str)

# Generated at 2022-06-21 16:35:06.469835
# Unit test for method title of class Person
def test_Person_title():
    from datetime import datetime
    from random import seed
    from enum import Enum
    from pydbgen import pydbgen
    from pydbgen import generator
    from pydbgen.enum_generator import TitleType
    from pydbgen.enum_generator import Gender

    seed(datetime.now())

    name = pydbgen.pydb()
    name.random = generator.Generator()

    title = name.title(gender=Gender.MALE, title_type=TitleType.PREFIX)
    print(title)


# Generated at 2022-06-21 16:35:13.142593
# Unit test for method telephone of class Person
def test_Person_telephone():
    """Unit test for method telephone of class Person."""
    rnd = Random()
    rnd.seed(0)

    p = Person(rnd=rnd)
    result = p.telephone(mask='+7-(###)-###-##-##')
    assert result == '+7-(985)-897-24-60', 'Method telephone failed.'


print(test_Person_telephone.__doc__)
test_Person_telephone()
print('- ' * 10)

# Generated at 2022-06-21 16:35:16.103062
# Unit test for method language of class Person
def test_Person_language():
    language = Person().language()
    assert type(language) == str

# Generated at 2022-06-21 16:35:19.894224
# Unit test for method identifier of class Person
def test_Person_identifier():

    mask = '##-##/##'

    identifier = Person(random=RANDOM).identifier(mask=mask)

    assert re.match('\d{2}-\d{2}/\d{2}', identifier) is not None

# Generated at 2022-06-21 16:35:21.709480
# Unit test for method weight of class Person
def test_Person_weight():
    aleatory = Person().weight()
    assert aleatory >= 38
    assert aleatory <= 90

# Generated at 2022-06-21 16:35:27.161732
# Unit test for method last_name of class Person
def test_Person_last_name():
    from faker import Faker
    from faker.providers.person.en_US import Provider

    fake = Faker('en_US')
    fake.add_provider(Provider)

    for _ in range(100):
        assert isinstance(fake.last_name(), str)
        assert isinstance(fake.last_name(Gender.MALE), str)
        assert isinstance(fake.last_name(Gender.FEMALE), str)


# Generated at 2022-06-21 16:35:28.946418
# Unit test for method occupation of class Person
def test_Person_occupation():
    for _ in range(10):
        # Testing method occupation of class Person
        # with ipdb debugger
        ipdb.set_trace()
        assert len(Person().occupation()) > 1


# Generated at 2022-06-21 16:35:31.212803
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    username = person.username()
    print(username)

# Generated at 2022-06-21 16:35:49.705730
# Unit test for method email of class Person
def test_Person_email():
    obj = Person()
    obj.seed(0)
    assert obj.email() == 'darryl04@gmail.com'
    assert obj.email() == 'annette10@yahoo.com'
    assert obj.email() == 'darryl37@hotmail.com'
    assert obj.email() == 'annette04@yandex.ru'
    assert obj.email() == 'darryl13@163.com'
    assert obj.email() == 'a.lebaron@yahoo.com'
    assert obj.email() == 'f.e.coulson@gmail.com'
    assert obj.email() == 'darryl03@163.com'
    assert obj.email() == 'annette27@live.com'
    assert obj.email() == 'a.lebaron@rambler.ru'

# Generated at 2022-06-21 16:35:52.966089
# Unit test for method first_name of class Person
def test_Person_first_name():
    # test for first_name method of class Person
    pr = Person(seed=65)
    assert pr.first_name(gender=Gender.Male) == "Otho"
    assert pr.first_name(gender=Gender.Female) == "Nita"

# Generated at 2022-06-21 16:35:55.685279
# Unit test for method views_on of class Person
def test_Person_views_on():
    gen = Person()
    for i in range(1000):
        views_on = gen.views_on()
        assert views_on in ('Negative', 'Positive', 'Neutral')
    return True

# Generated at 2022-06-21 16:35:59.388823
# Unit test for method weight of class Person
def test_Person_weight():
    # Arrange
    from . import default_person_data
    from .default_person_data import DEFAULT_PERSON_DATA
    provider = Person(DEFAULT_PERSON_DATA)
    # Act
    actual = provider.weight()
    # Assert
    assert actual in range(38, 90)
    
    

# Generated at 2022-06-21 16:36:02.997933
# Unit test for method gender of class Person
def test_Person_gender():
    data = [('M', Gender.male), ('F', Gender.female), ('N/A', Gender.unknown)]
    for data_item in data:
        assert data_item[1] == Person.gender(data_item[0])

test_Person_gender()

# Generated at 2022-06-21 16:36:04.361932
# Unit test for method height of class Person
def test_Person_height():
    assert Person().height(0, 10)


# Generated at 2022-06-21 16:36:06.086794
# Unit test for method sex of class Person
def test_Person_sex():
    assert Person(seed=22).sex() == 'Female', 'Failed test_Person_sex'


# Generated at 2022-06-21 16:36:07.478158
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    sample_result = Person.sexual_orientation()
    assert sample_result in SEXUALITY



# Generated at 2022-06-21 16:36:08.834598
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    provider = Person(random=Random())
    assert provider.work_experience()


# Generated at 2022-06-21 16:36:10.626094
# Unit test for method university of class Person
def test_Person_university():
        # Arrange
        person = Person()
        # Act
        result = person.university()
        # Assert
        assert isinstance(result, str)

# Generated at 2022-06-21 16:36:31.370339
# Unit test for method language of class Person
def test_Person_language():
    person = Person(random = Random())
    assert isinstance(person.language(), str)

# Generated at 2022-06-21 16:36:40.293002
# Unit test for method title of class Person
def test_Person_title():
    from faker_ru.enums import Gender
    from faker_ru.enums import TitleType
    import pytest
    f = Person(lang='ru')
    test = f.title(gender=Gender.FEMALE, title_type=TitleType.SHORT)
    assert test in ['Инж.', 'Д-р', 'Канд.', 'Проф.',
                    'Доц.', 'Проф.', 'Проф.', 'Маг.', 'Ассист.']

# Generated at 2022-06-21 16:36:44.147053
# Unit test for method political_views of class Person
def test_Person_political_views():
    assert Person.political_views(None) in ["Liberal", "Communist", "Nationalist", "Conservative",
                                            "Socialist", "Green", "Moderate", "Libertarian", "Authoritarian", "Monarchist"]
    
    

# Generated at 2022-06-21 16:36:45.426548
# Unit test for method views_on of class Person
def test_Person_views_on():
    p = Person()
    r = p.views_on()
    assert r is not None



# Generated at 2022-06-21 16:36:57.622994
# Unit test for method username of class Person
def test_Person_username():
    p = Person(random = Random())
    assert p.username("U_d") == 'Celloid1873'
    assert p.username("U.d") == 'F8onzv96'
    assert p.username("U-d") == 'G.ga.Y77'
    assert p.username("UU-d") == 'L.a.07'
    assert p.username("UU.d") == 'I.K.08'
    assert p.username("UU_d") == 'I.K.08'
    assert p.username("ld") == 'b8'
    assert p.username("l-d") == 'b8'
    assert p.username("Ud") == 'Gg7'
    assert p.username("l.d") == 'b8'

# Generated at 2022-06-21 16:37:04.179243
# Unit test for method title of class Person
def test_Person_title():
    assert Person.title(Gender.MALE) in [
        'Dr',
        'Mr',
        'Professor',
        'Reverend',
        'Sir',
        'Hon.',
        'Count',
        'King',
        'Duke',
        'Prince',
        'Def.',
    ]

    assert Person.title(Gender.FEMALE) in [
        'Ms',
        'Miss',
        'Mrs',
        'Dr',
        'Professor',
        'Reverend',
        'Lady',
        'Dame',
        'Hon.',
        'Countess',
        'Queen',
        'Duchess',
        'Princess',
        'Def.',
    ]

# Generated at 2022-06-21 16:37:05.988125
# Unit test for method name of class Person
def test_Person_name():
    for _ in range(100):
        assert len(Person().name()) <= 17


# Generated at 2022-06-21 16:37:08.551946
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    for i in range(10):
        assert p.nationality() in NATIONALITIES


# Generated at 2022-06-21 16:37:09.957500
# Unit test for method views_on of class Person
def test_Person_views_on():
    provider = Person()
    assert isinstance(provider.views_on(), str) == True


# Generated at 2022-06-21 16:37:10.733141
# Unit test for constructor of class Person
def test_Person():
    p = Person()

    assert p is not None

# Generated at 2022-06-21 16:37:57.992394
# Unit test for method age of class Person
def test_Person_age():
    print("----test_Person_age")
    p = Person(seed=10)
    print(p.age())
    print(p.age(which=AgeType.CHILD))
    print(p.age(which=AgeType.YOUTH))
    print(p.age(which=AgeType.MIDDLE_AGE))
    print(p.age(which=AgeType.OLD_AGE))


# Generated at 2022-06-21 16:38:05.527169
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from datetime import timedelta
    from fake_factory.providers.date_time import date_time
    from fake_factory.providers.random_gen import RandomGenerator
    gen = RandomGenerator()
    gen.seed(7)
    p = Person(gen)
    today = date_time().date()
    assert p.work_experience() == p.work_experience(today) == timedelta(0)
    assert p.work_experience(today + timedelta(days=1)) == timedelta(1)
    assert p.work_experience(today + timedelta(days=2)) == timedelta(2)
    assert p.work_experience(today + timedelta(days=3)) == timedelta(3)
    assert p.work_experience(today + timedelta(days=4)) == timed

# Generated at 2022-06-21 16:38:10.639102
# Unit test for method university of class Person
def test_Person_university():
    provider = Person(seed=42)
    term = provider.university()
    assert term == 'California College of the Arts'
    term = provider.university()
    assert term == 'Michigan State University'
    term = provider.university()
    assert term == 'University of Exeter'
    term = provider.university()
    assert term == 'MIT'
    term = provider.university()
    assert term == 'New York University'
    term = provider.university()
    assert term == 'University of Exeter'
    term = provider.university()
    assert term == 'Massachusetts Institute of Technology'
    term = provider.university()
    assert term == 'Université de Montréal'
    term = provider.university()
    assert term == 'Universidad Autónoma de Madrid'

# Generated at 2022-06-21 16:38:13.083946
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    assert p.height() == '1.85'


# Generated at 2022-06-21 16:38:17.842313
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    assert p.title(Gender.MALE, TitleType.PREFIX) in p._data.get('title', {}).get(Gender.MALE.value, {}).get(TitleType.PREFIX.value, [])
    assert p.title(Gender.MALE, TitleType.SUFFIX) in p._data.get('title', {}).get(Gender.MALE.value, {}).get(TitleType.SUFFIX.value, [])
    assert p.title(Gender.FEMALE, TitleType.PREFIX) in p._data.get('title', {}).get(Gender.FEMALE.value, {}).get(TitleType.PREFIX.value, [])

# Generated at 2022-06-21 16:38:20.509331
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    assert person.sexual_orientation() in [
        "Heterosexuality",
        "Bisexuality",
        "Homosexuality",
        "Abstinence",
        "Asexuality",
        "Pansexuality",
        "Polysexuality",
        "Androphilia",
        "Gynephilia",
        "Skoliosexuality"
    ]
test_Person_sexual_orientation()


# Generated at 2022-06-21 16:38:23.494414
# Unit test for method name of class Person
def test_Person_name():
    # Arrange
    person = Person()
    # Act
    name = person.name()
    # Assert
    assert type(name) == str

print(test_Person_name())



# Generated at 2022-06-21 16:38:24.872945
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert type(p.nationality()) == str


# Generated at 2022-06-21 16:38:26.792431
# Unit test for method political_views of class Person
def test_Person_political_views():
    provider = Person()
    result = provider.political_views()
    assert type(result) == str

# Generated at 2022-06-21 16:38:31.482995
# Unit test for method weight of class Person
def test_Person_weight():
    # Possible values for test for person's weight
    weight_list=[32,36,38,39,40,42,43,45,46,47,48,49,50,51,52,53,54,55,56]
    # A function to get a random weight
    def test_weight(x):
        p = Person(locale='en')
        weight = p.weight()
        while x>0:
            assert weight in weight_list
            x-=1
    test_weight(10)
