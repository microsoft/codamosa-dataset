

# Generated at 2022-06-21 16:31:43.681947
# Unit test for method email of class Person
def test_Person_email():
    assert Person().email(unique=True).startswith('foretime10')



# Generated at 2022-06-21 16:31:51.886793
# Unit test for method age of class Person
def test_Person_age():
    
    import faker
    from faker.providers import person

    for _ in range(10):
        provider = person.PersonProvider(faker.Faker())
        age = provider.age()
        assert isinstance(age, int)

    for _ in range(10):
        provider = person.PersonProvider(faker.Faker())
        age = provider.age(minimum=18, maximum=60)
        assert isinstance(age, int)
        assert 0 < age < 100

    provider = person.PersonProvider(faker.Faker())
    oldest = provider.age(minimum=100, maximum=100)
    assert oldest == 100

    provider = person.PersonProvider(faker.Faker())
    youngest = provider.age(minimum=0, maximum=0)
    assert youngest == 0

# Generated at 2022-06-21 16:32:03.675805
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person()

# Generated at 2022-06-21 16:32:07.757652
# Unit test for method avatar of class Person
def test_Person_avatar():
    print('test_Person_avatar')
    print(p.avatar())
    print(p.avatar(30))
    print(p.avatar(50))
    print(p.avatar(100))
    print(p.avatar(200))
    print(p.avatar(513))


# Generated at 2022-06-21 16:32:10.713201
# Unit test for method sex of class Person
def test_Person_sex():
    for i in range(100):
        assert isinstance(Person.sex(), str)



# Generated at 2022-06-21 16:32:13.802877
# Unit test for method views_on of class Person
def test_Person_views_on():
    processor = Processor(locale='en')
    provider = Person(random=processor)

    assert provider.views_on() in VIEWS_ON

# Generated at 2022-06-21 16:32:21.807272
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person(random=Random())
    name = person.first_name()
    assert isinstance(name, str)
    assert name in (person._data['first_names']['female'] +
                    person._data['first_names']['male'])

    name = person.first_name(gender=Gender.MALE)
    assert isinstance(name, str)
    assert name in person._data['first_names']['male']

    name = person.first_name(gender=Gender.FEMALE)
    assert isinstance(name, str)
    assert name in person._data['first_names']['female']

# Generated at 2022-06-21 16:32:33.992880
# Unit test for method sex of class Person
def test_Person_sex():
    # Create a container with the correct data
    correct_data = [ 'Male', 'Female', 'Transgender', ]
    # Create a container with the incorrect data
    incorrect_data = [ "Male", "Female", "Transgender", ]
    # Create a container for storing test results
    results = []
    # For each element of the correct data
    for item in correct_data:
        # Run the method under test
        result = fake.sex(item)
        # Add the result of the method under test to the container with results
        results.append(result)
    # Check that the length of the container with the correct data is equal to the length
    # container with the test results
    assert len(correct_data) == len(results)
    # Check that the length of the container with the incorrect data is equal to the length
    # container with the test results

# Generated at 2022-06-21 16:32:35.684694
# Unit test for method surname of class Person
def test_Person_surname():
    for _ in range(100):
        surname = Person(random.Random()).surname()
        assert isinstance(surname, str)


# Generated at 2022-06-21 16:32:37.982815
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    language = person.language()
    assert language in PERSON_LANGUAGES

# Generated at 2022-06-21 16:32:55.535533
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from random import Random
    from datetime import datetime
    from datetime import timedelta
    from enum import Enum
    from enum import unique
    from faker import Faker

    @unique
    class ExampleType(Enum):
        #: First example type
        first_example = 1
        #: Second example type
        last_example = 2

    @unique
    class AnotherExampleType(Enum):
        #: First example type
        first_example = 1
        #: Second example type
        last_example = 2
        
    f = Faker(['en_US', 'ru_RU'], random=Random())
    p = Person(random=f, locale='en_US')
    # Test random values
    years_list = [i for i in range(1, 10)]
    count = 0

# Generated at 2022-06-21 16:33:05.944495
# Unit test for method telephone of class Person
def test_Person_telephone():
    results = []
    obj = Person()
    assert isinstance(obj, Person)

    # Test #1. Default
    result = obj.telephone()
    results.append(result)

    # Test #2. Default
    result = obj.telephone()
    results.append(result)

    # Test #3. Default
    result = obj.telephone()
    results.append(result)

    # Test #4. Empty string
    result = obj.telephone(mask='')
    results.append(result)

    # Test #5. Empty string
    result = obj.telephone(mask='')
    results.append(result)

    # Test #6. Empty string
    result = obj.telephone(mask='')
    results.append(result)

    # Test #7. Default

# Generated at 2022-06-21 16:33:07.561559
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    p = Person()
    res = p.academic_degree()
    assert not res.isspace(), "The field 'academic_degree' is empty."
    assert res


# Generated at 2022-06-21 16:33:09.782824
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert len(set(_.sexual_orientation()
                   for _ in range(100))) == len(SEXUALITY)


# Generated at 2022-06-21 16:33:15.476257
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Word of default mask for telephone in class Person
    default_mask = '{}-{}-###-####'.format(CALLING_CODES[0], '###')
    # Create new object of class Person
    person = Person()
    # Generate telephone number with default mask
    telephone = person.telephone()
    # Check that telephone number matches with mask
    assert re.fullmatch(default_mask, telephone), 'Bad telephone number'

test_Person_telephone()

# Generated at 2022-06-21 16:33:19.343030
# Unit test for method weight of class Person
def test_Person_weight():
    provider = Person()

    results = []
    for _ in range(10):
        results.append(provider.weight())
    # print(results)
    assert isinstance(results, list)
    assert results != []

# Generated at 2022-06-21 16:33:20.952930
# Unit test for method height of class Person
def test_Person_height():
    Faker.seed(0)
    assert Faker.Person().height() == '1.89'


# Generated at 2022-06-21 16:33:22.952389
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    g = person.gender()
    assert g in ('Male', 'Female')


# Generated at 2022-06-21 16:33:33.737790
# Unit test for method weight of class Person
def test_Person_weight():
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
    assert len(Person.weight()) <= 2
   

# Generated at 2022-06-21 16:33:43.820045
# Unit test for method email of class Person
def test_Person_email():
    # Test 1
    provider = Person()
    # It should return a correct email.
    email = provider.email()
    assert re.match('^[\w-]+@[\wa-zA-Z.]+\.[a-z]+$', email) is not None

    # Test 2
    domains = ('gmail.com', 'hotmail.com', 'yahoo.com')
    provider = Person()
    email = provider.email(domains=domains)
    assert re.match('^[\w-]+@(' + '|'.join(domains) + ')$', email) is not None

    # Test 3
    provider = Person()
    email = provider.email(unique=True)
    assert re.match('^.+@[\w-]+\.com$', email) is not None

# Generated at 2022-06-21 16:34:03.717494
# Unit test for method last_name of class Person
def test_Person_last_name():
    names = ['Иван', 'Антон', 'Артем', 'Никита', 'Максим', 'Денис', 'Дмитрий', 'Илья', 'Степан', 'Матвей']
    surnames = ['Иванов', 'Смирнов', 'Кузнецов', 'Попов', 'Васильев', 'Петров', 'Соколов', 'Михайлов', 'Новиков', 'Федоров']


# Generated at 2022-06-21 16:34:05.947972
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    weight = person.weight(minimum=38, maximum=90)
    assert type(weight) == int
    assert weight >= 38 or weight <= 90


# Generated at 2022-06-21 16:34:07.348334
# Unit test for method political_views of class Person
def test_Person_political_views():
    for _ in range(100):
        assert Person().political_views()

# Generated at 2022-06-21 16:34:10.131739
# Unit test for method password of class Person
def test_Person_password():
    result = Person().password(length=11, hashed=False)
    assert isinstance(result, str)
    assert len(result) == 11


# Generated at 2022-06-21 16:34:15.362088
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    assert person.title() != ''
    assert person.title(Gender.male) != ''
    assert person.title(Gender.female) != ''
    assert person.title(TitleType.prefix) != ''
    assert person.title(TitleType.suffix) != ''

    for gender, _ in Gender.__members__.items():
        assert person.title(gender) != ''

    for title, _ in TitleType.__members__.items():
        assert person.title(title_type=title) != ''

    for gender, _ in Gender.__members__.items():
        for title, _ in TitleType.__members__.items():
            assert person.title(gender, title) != ''


# Generated at 2022-06-21 16:34:25.706500
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    from fake2db import Fake2DB
    from fake2db.providers.person import Person
    from fake2db.providers.internet import Internet
    from fake2db.providers.company import Company
    from enum import Enum
    from datetime import date
    from datetime import datetime
    from datetime import timedelta

    class TypeOfWork(Enum):
        TEMPORARY = 'temporary'
        PERMANENT = 'permanent'

    class TypeOfWorkExperience(Enum):
        WORK = 'work'
        EDUCATION = 'education'

    ###########################################################################
    # Set data
    ###########################################################################
    f = Fake2DB(seed=42)

# Generated at 2022-06-21 16:34:28.808947
# Unit test for method occupation of class Person
def test_Person_occupation():
    person = Person()
    assert person.occupation() in ["Janitor", "Choreographer", "Clergy"]

# Generated at 2022-06-21 16:34:31.759636
# Unit test for method age of class Person
def test_Person_age():
    p = Person()
    # Function call
    age = p.age(minimum=18, maximum=99)
    # Basic checks
    assert type(age) is int
    assert age >= 18 and age <= 99

# Generated at 2022-06-21 16:34:37.612191
# Unit test for constructor of class Person
def test_Person():
    provider = Person()
    assert isinstance(provider._data, dict)
    assert isinstance(provider.random, Random)
    assert hasattr(provider, 'seed')
    assert hasattr(provider, 'unique')

    # Ensure that the internal _data is a copy
    # so that modifications do not affect the class
    provider._data['test'] = 42
    assert 'test' not in Person._data

# Generated at 2022-06-21 16:34:39.856822
# Unit test for method password of class Person
def test_Person_password():
    assert Person().password(hashed=True) is not None


# Generated at 2022-06-21 16:34:57.930855
# Unit test for method gender of class Person
def test_Person_gender():
    provider = Person()
    sex = provider.gender()
    assert isinstance(sex, str) == True
    assert sex in provider._data['gender'] == True




# Generated at 2022-06-21 16:35:01.351074
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person()
    actual = person.surname()
    assert type(actual) == str


# Generated at 2022-06-21 16:35:02.483971
# Unit test for method email of class Person
def test_Person_email():
    p = Person()

    result = p.email()

    assert isinstance(result, str)


# Generated at 2022-06-21 16:35:06.687946
# Unit test for method first_name of class Person
def test_Person_first_name():
    for _ in range(10):
        num = random.randint(1, 500)
        person = Person(seed=num)
        data = person.fake.first_name()
        assert data is not None
        assert data != ''
        assert data != []
        assert data != {}

# Generated at 2022-06-21 16:35:10.217242
# Unit test for method identifier of class Person
def test_Person_identifier():
    person_factory = Person()
    assert person_factory.identifier('##-##/##') == '07-97/04'


# Generated at 2022-06-21 16:35:14.971894
# Unit test for method age of class Person
def test_Person_age():
    def generate_age(min_age, max_age, year_of_birth, year_of_death):
        age = Person(seed=None).age(min_age, max_age, year_of_birth, year_of_death)
        return age
    assert generate_age(18, 99, 1300, 1300) == 99
    assert generate_age(1, 99, 2021, 2021) == 1
    assert generate_age(18, 99, 2021, 2000) == 18
    assert generate_age(18, 99, 1921, 2021) == 99

# Generated at 2022-06-21 16:35:17.647900
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()
    sexual_orientation = person.sexual_orientation()
    assert sexual_orientation == 'Heterosexuality'

# Generated at 2022-06-21 16:35:19.627840
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()

    assert person.blood_type() in BLOOD_GROUPS


# Generated at 2022-06-21 16:35:23.868494
# Unit test for method height of class Person
def test_Person_height():
    fake = Faker()
    assert fake.height() != fake.height()
    assert fake.height() != fake.height()
    assert fake.height() != fake.height()
    assert fake.height() != fake.height()
    assert fake.height() != fake.height()

# Generated at 2022-06-21 16:35:24.927352
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() in VIEWS_ON


# Generated at 2022-06-21 16:36:02.340389
# Unit test for method nationality of class Person
def test_Person_nationality():
    assert Person().nationality() in PERSON_DATA['nationality']


# Generated at 2022-06-21 16:36:04.133494
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # check if the output is valid
    assert all(('+', '-'))



# Generated at 2022-06-21 16:36:07.063998
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Arrange
    obj = Person()

    # Act
    actual = obj.social_media_profile()

    # Assert
    assert isinstance(actual, str)



# Generated at 2022-06-21 16:36:09.732704
# Unit test for method gender of class Person
def test_Person_gender():
    person = Person()
    assert person.gender(iso5218 = True) in (0, 1, 2, 9)
    assert person.gender(symbol = True) in GENDER_SYMBOLS
    assert person.gender() in person._data['gender']

# Generated at 2022-06-21 16:36:11.685954
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    title = person.title()

    assert isinstance(title, str)

# Generated at 2022-06-21 16:36:14.173793
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    title = p.title(title_type=TitleType.SUFFIX)
    assert type(title) == str



# Generated at 2022-06-21 16:36:18.452750
# Unit test for method last_name of class Person
def test_Person_last_name():
    # Set up
    p = Person()
    # Exercise

    # Verify
    assert p.last_name() not in (p.name(), p.first_name(), p.middle_name())

# Generated at 2022-06-21 16:36:20.976556
# Unit test for method language of class Person
def test_Person_language():
    language = Person().language()
    print(language)

if __name__ == '__main__':
    test_Person_language()


# Generated at 2022-06-21 16:36:22.190369
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person.last_name() is not None

# Generated at 2022-06-21 16:36:27.426064
# Unit test for method telephone of class Person
def test_Person_telephone():
    '''
    The function tests the function telephone of class Person
    '''
    seed = "1234567890"
    person = Person('ru_RU', seed=seed)
    assert person.telephone() == "+7-(461)-947-89-41"

    seed = "12345678901234567890"
    person = Person('ru_RU', seed=seed)
    assert person.telephone() == "+7-(911)-297-58-52"


# Generated at 2022-06-21 16:37:47.837241
# Unit test for method occupation of class Person
def test_Person_occupation():
    res = Person.occupation()
    assert res in PERSON_OCCUPATION
test_Person_occupation()

# Generated at 2022-06-21 16:37:50.055483
# Unit test for method username of class Person
def test_Person_username():
    provider = Person(random=Random())
    result = provider.username()
    assert isinstance(result, str)
test_Person_username()

faker = Person(random=Random())

# Generated at 2022-06-21 16:37:54.552246
# Unit test for method university of class Person
def test_Person_university():
    person = Person()
    university = person.university()
    assert isinstance(university, str), 'Function must return str'
    assert len(university) >= 1, 'Size of str must be greater than or equal 1'

# Generated at 2022-06-21 16:37:56.460429
# Unit test for method occupation of class Person
def test_Person_occupation():
    rnd = Random()
    assert Person(random=rnd).occupation() == 'Baker'


# Generated at 2022-06-21 16:38:04.743193
# Unit test for method surname of class Person

# Generated at 2022-06-21 16:38:07.625122
# Unit test for method university of class Person
def test_Person_university():
    """ Test for method university of class Person
    Test #1: Normal Test """
    person1 = Person(random=Mock())
    person1.random.choice = Mock(side_effect=['Yale University', 'MIT'])
    assert person1.university() == 'Yale University'
    assert person1.university() == 'MIT'

# Generated at 2022-06-21 16:38:09.898679
# Unit test for method gender of class Person
def test_Person_gender():
    # Tests for Person._get_random_gender()
    random_gender = Person()._get_random_gender()
    assert random_gender in GENDER_TITLES
    # Tests for Person.gender()
    assert Person().gender() in GENDER_TITLES


# Generated at 2022-06-21 16:38:13.457577
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    person = Person()
    assert person.academic_degree() in person._data['academic_degree']
    print('Test Person_academic_degree - OK!')


# Generated at 2022-06-21 16:38:21.170921
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    value = person.first_name()

    assert isinstance(value, str), \
        'Value must be str type.'
    assert 3 <= len(value) <= 20, \
        'Value len must be in range 3..20.'
    assert value[0].isupper(), \
        'Value must start with capital letter.'
    assert re.match(r'^[A-Za-z]+$', value), \
        'Value must contain only characters.'



# Generated at 2022-06-21 16:38:23.063375
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    a = Person()
    result = a.academic_degree()
    print(result)
    assert isinstance(result,str)
