

# Generated at 2022-06-21 16:31:46.998360
# Unit test for constructor of class Person
def test_Person():
    value = Person()
    assert isinstance(value, Person)

# Generated at 2022-06-21 16:31:52.195528
# Unit test for method full_name of class Person
def test_Person_full_name():
    test_obj = Person()
    test_obj.random = MagicMock()
    test_obj.name = MagicMock()
    test_obj.surname = MagicMock()
    test_obj.random.choice = MagicMock()
    test_obj.gender = Gender.MALE
    test_obj.full_name()

    test_obj.name.assert_called_once_with(Gender.MALE)
    test_obj.surname.assert_called_once_with(Gender.MALE)


# Generated at 2022-06-21 16:31:54.879038
# Unit test for method views_on of class Person
def test_Person_views_on():
    person = Person()
    assert person.views_on() in ('Negative', 'Positive', 'Indifferent')

# Generated at 2022-06-21 16:31:57.123707
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    assert Person().sexual_orientation() in ('Heterosexuality', 'Homosexuality')



# Generated at 2022-06-21 16:31:59.571309
# Unit test for method university of class Person
def test_Person_university():
    
    # GIVEN
    pl = Person()
    
    # WHEN
    result = pl.university()
    
    # THEN
    assert isinstance(result, str)

# Generated at 2022-06-21 16:32:09.234916
# Unit test for method first_name of class Person
def test_Person_first_name():
    locale_rus = Person('ru_RU')
    locale_eng = Person('en_US')
    locale_esp = Person('es_ES')
    locale_fra = Person('fr_FR')
    locale_deu = Person('de_DE')
    locale_ita = Person('it_IT')
    locale_por = Person('pt_PT')
    locale_jpn = Person('ja_JP')
    locale_tur = Person('tr_TR')
    locale_kor = Person('ko_KR')
    locale_cmn = Person('zh_CN')
    locale_swe = Person('sv_SE')
    locale_fin = Person('fi_FI')
    locale_cze = Person('cs_CZ')
    locale_pol = Person('pl_PL')
    locale_gre = Person('el_GR')

# Generated at 2022-06-21 16:32:13.296196
# Unit test for method sex of class Person
def test_Person_sex():
    provider = Person()
    s = provider.sex()
    assert (s in GENDER), "Sex must be from GENDER"
    
test_Person_sex()

# Generated at 2022-06-21 16:32:14.815952
# Unit test for constructor of class Person
def test_Person():
    """Unit test for constructor of class Person"""
    provider = Person()
    assert provider

# Generated at 2022-06-21 16:32:17.935569
# Unit test for method age of class Person
def test_Person_age():
    import random
    import datetime

    random.seed(1)
    p = Person(random=random)
    result = p.age()

    assert(result == 21)


# Generated at 2022-06-21 16:32:20.142742
# Unit test for method political_views of class Person
def test_Person_political_views():

    provider = Person()
    assert type(provider.political_views()) is str
test_Person_political_views()


# Generated at 2022-06-21 16:32:29.617552
# Unit test for method occupation of class Person
def test_Person_occupation():
    assert(Person().occupation() in PERSON_OCCUPATIONS)
test = Person()
test.occupation()


# Generated at 2022-06-21 16:32:34.817834
# Unit test for method full_name of class Person
def test_Person_full_name():
    for gender in Gender:
        for num in range(100):
            f = Person().full_name(gender=gender)
            assert isinstance(f, str)
            assert f
            assert len(f.split()) == 2
            assert f.split()[-1] in LN_LIST
            assert f.split()[0] in FN_LIST


# Generated at 2022-06-21 16:32:36.185924
# Unit test for method worldview of class Person
def test_Person_worldview():
    person = Person('en')

    assert person.worldview()


# Generated at 2022-06-21 16:32:38.124898
# Unit test for method name of class Person
def test_Person_name():
    name = Person().name()
    assert isinstance(name, str)


# Generated at 2022-06-21 16:32:40.031916
# Unit test for method first_name of class Person
def test_Person_first_name():
    value = Person.first_name(Person())
    assert isinstance(value, str)


# Generated at 2022-06-21 16:32:42.689298
# Unit test for method university of class Person
def test_Person_university():
    university = Person().university()
    assert university in PERSON['university']



# Generated at 2022-06-21 16:32:46.223075
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    # Setup
    random_seed(1)
    
    # Exercise
    actual = Person().blood_type()
    
    # Verify
    assert actual == 'A-'

# Generated at 2022-06-21 16:32:48.430939
# Unit test for method sex of class Person
def test_Person_sex():
    p1 = Person()
    s1 = p1.sex()
    assert (type(s1) == str)


# Generated at 2022-06-21 16:32:53.579407
# Unit test for method height of class Person
def test_Person_height():
    from faker.providers.person.de_DE import Provider
    from faker import Faker
    from math import isclose

    fake = Faker(locale='de_DE', providers=[Provider])
    h = fake.height()

    assert isinstance(h, str)
    assert isclose(float(h), fake.random.uniform(1.5, 2.0), rel_tol=1e-6)

# Generated at 2022-06-21 16:33:00.221471
# Unit test for method political_views of class Person
def test_Person_political_views():
    generated_items = [name() for name in [
        Person(seed=0).political_views for i in range(10)]]

    assert generated_items == ['Neutral', 'Neutral', 'Neutral', 'Neutral',
                               'Neutral', 'Neutral', 'Neutral', 'Neutral',
                               'Neutral', 'Neutral']



# Generated at 2022-06-21 16:33:18.206212
# Unit test for method nationality of class Person
def test_Person_nationality():
    person = Person()
    nationality = person.nationality()
    assert nationality == 'Russian'

test_Person_nationality()

# Generated at 2022-06-21 16:33:19.875824
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    with pytest.raises(Exception):
        person = Person()
        person.work_experience()


# Generated at 2022-06-21 16:33:21.141418
# Unit test for method title of class Person
def test_Person_title():
    p = Person()
    p.title()

# Generated at 2022-06-21 16:33:25.156135
# Unit test for method telephone of class Person
def test_Person_telephone():
    for _ in range(100):
        _ = Person().telephone()
    for _ in range(100):
        _ = Person().telephone(mask='##-##/##')
    for _ in range(100):
        _ = Person().telephone('### ### ####')

# Generated at 2022-06-21 16:33:27.648424
# Unit test for method views_on of class Person
def test_Person_views_on():
    obj = Person()
    assert isinstance(obj.views_on(), str)


# Generated at 2022-06-21 16:33:37.555824
# Unit test for method title of class Person
def test_Person_title():
    # simple tests
    assert Person.title() in ['Dr.', 'Dr', 'Mr.', 'Mrs.', 'Ms.']
    # class validation test
    assert Person.title(gender=Gender.MAN, title_type=TitleType.SUFFIX) in ['Jr.', 'Sr.']
    assert Person.title(gender=Gender.WOMAN, title_type=TitleType.SUFFIX) in ['Jr.', 'Sr.']
    assert Person.title(gender=Gender.NOT_KNOWN, title_type=TitleType.SUFFIX) in ['Jr.', 'Sr.']
    assert Person.title(gender=Gender.NOT_APPLICABLE, title_type=TitleType.SUFFIX) in ['Jr.', 'Sr.']
    # object validation test

# Generated at 2022-06-21 16:33:39.017875
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    p = Person()
    for i in range(100):
        profile = p.social_media_profile(site=None)
        assert profile.startswith('https://')

# Generated at 2022-06-21 16:33:43.214581
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    l = []
    for _ in range(1000):
        l.append(Person().sexual_orientation())
    return len(set(l)) == len(l)

test_Person_sexual_orientation()


# Generated at 2022-06-21 16:33:45.993372
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person('en')
    surname = person.surname()
    assert isinstance(surname, str)

# Generated at 2022-06-21 16:33:47.775908
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    es = Person(seed=42)
    assert es.academic_degree() == "преподаватель"



# Generated at 2022-06-21 16:34:09.781939
# Unit test for method username of class Person
def test_Person_username():
    # Call method username of class Fake
    # Use method username of class Person
    username = fake.username()

    # Test result
    assert isinstance(username, str)
# Test method username with custom template of class Person
# Use method username of class Person
username = fake.username(template='Ud')

# Test result
print(username)
assert isinstance(username, str)
# Use method username of class Person
username = fake.username(template='ld')

# Test result
print(username)
assert isinstance(username, str)
# Use method username of class Person
username = fake.username(template='U')

# Test result
print(username)
assert isinstance(username, str)
# Use method username of class Person
username = fake.username(template='ldl')

# Test result
print(username)

# Generated at 2022-06-21 16:34:12.778801
# Unit test for method nationality of class Person
def test_Person_nationality():
    # test with default value
    with pytest.raises(TypeError):
        Person().nationality()
    # test with correct value
    assert 'Russian' in Person().nationality(Gender.MALE)

# Generated at 2022-06-21 16:34:22.722245
# Unit test for method sex of class Person
def test_Person_sex():
    data = {
        'sex': {
            Gender.MALE: 'male',
            Gender.FEMALE: 'female',
        },
    }

    provider = Person(data=data)
    for i in range(10):
        assert provider.sex() in data['sex'].values()

    for i in range(10):
        assert provider.sex(iso5218=True) in [0, 1, 2, 9]

    for i in range(10):
        assert provider.sex(symbol=True) in GENDER_SYMBOLS


if __name__ == '__main__':
    test_Person_sex()

# Generated at 2022-06-21 16:34:26.150606
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    values = [p.sexual_orientation(symbol=True) for _ in range(100)]
    assert len(values) == 100

    assert mu.check_iter(values, mu.is_symbol)

    values = [p.sexual_orientation() for _ in range(100)]
    assert len(values) == 100

    assert mu.check_iter(values, mu.is_str)



# Generated at 2022-06-21 16:34:28.981608
# Unit test for method full_name of class Person
def test_Person_full_name():
    pp = Person()
    assert isinstance(pp.full_name(), str)


# Generated at 2022-06-21 16:34:31.552520
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    assert re.match(r'[Ul\.\-\_d]*[Ul]+[Ul\.\-\_d]*', p.username())

# Generated at 2022-06-21 16:34:42.628981
# Unit test for constructor of class Person
def test_Person():
    person = Person()
    assert isinstance(person, Person)
    assert isinstance(person.name(), str)
    assert isinstance(person.surname(), str)
    assert isinstance(person.last_name(), str)
    assert isinstance(person.title(), str)
    assert isinstance(person.full_name(), str)
    assert isinstance(person.username(), str)
    assert isinstance(person.password(), str)
    assert isinstance(person.blood_type(), str)
    assert isinstance(person.email(), str)
    assert isinstance(person.social_media_profile(), str)
    assert isinstance(person.gender(), str)
    assert isinstance(person.sex(), str)
    assert isinstance(person.height(), str)
    assert isinstance(person.weight(), int)

# Generated at 2022-06-21 16:34:44.605468
# Unit test for method political_views of class Person
def test_Person_political_views():
    instance = Person()
    result = instance.political_views()
    assert result in POLITICAL_VIEWS

# Generated at 2022-06-21 16:34:47.380325
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person: Person = Person()
    
    sexual_orientation = person.sexual_orientation()
    assert sexual_orientation in SEXUAL_ORIENTATION

# Generated at 2022-06-21 16:34:52.405869
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person(seed=12345)
    assert person.last_name() == 'Brenner'
    assert person.last_name(gender=Gender.FEMALE) == 'Henry'
    assert person.last_name(gender=Gender.MALE) == 'Brenner'



# Generated at 2022-06-21 16:39:59.973948
# Unit test for method title of class Person
def test_Person_title():
    Person_test = Person()
    title_test = Person_test.title()
    assert type(title_test) == str

# Generated at 2022-06-21 16:40:01.679099
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    name = person.last_name()
    assert isinstance(name, str)

# Generated at 2022-06-21 16:40:03.461941
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    p = Person()
    assert p.sexual_orientation()
    

# Generated at 2022-06-21 16:40:11.658911
# Unit test for method telephone of class Person
def test_Person_telephone():
    data = []
    fmt = [
        '#-##-###-##-##',
        '(##)-###-##-##',
        '#-###-###-##-##',
        '####-####-##-##',
    ]
    for i in range(20):
        for item in fmt:
            data.append(Person().telephone(mask=item))

    assert len(data) == 80

    for item in data:
        assert isinstance(item, str)
        assert re.match(r'(\d|\w|\(|\)|\-|\s|\/)+$', item) is not None

# Generated at 2022-06-21 16:40:15.820030
# Unit test for method work_experience of class Person
def test_Person_work_experience():

    tester = Person()

    # When
    val1 = tester.work_experience()
    val2 = tester.work_experience()

    # Then
    assert isinstance(val1, datetime.date)
    assert isinstance(val2, datetime.date)
    assert val1.year != val2.year

# Generated at 2022-06-21 16:40:23.081336
# Unit test for method email of class Person
def test_Person_email():
    kwargs = {'seed': None}
    obj = Person(**kwargs)
    obj.random.seed(1)
    assert obj.email() == 'd.j@hotmail.com'
    obj.random.seed(2)
    assert obj.email() == 'j.c@hotmail.com'
    obj.random.seed(3)
    assert obj.email() == 'l.m@gmail.com'
    obj.random.seed(4)
    assert obj.email() == 'j.h@gmail.com'
    obj.random.seed(5)
    assert obj.email() == 'a.j@gmail.com'
    obj.random.seed(6)
    assert obj.email() == 't.r@gmail.com'
    obj.random.seed(7)
    assert obj

# Generated at 2022-06-21 16:40:24.982773
# Unit test for method email of class Person
def test_Person_email():
    email = Person().email()
    print('Email:', email)
    assert isinstance(email, str)


# Generated at 2022-06-21 16:40:30.669392
# Unit test for method full_name of class Person
def test_Person_full_name():
    # Test with correct values
    p = Person(random)
    assert p.full_name()
    assert p.full_name(Gender.male)
    assert p.full_name(Gender.female)
    
    # Test with incorrect values
    try:
        p.full_name(1)
        assert False
    except NonEnumerableError:
        assert True


# Generated at 2022-06-21 16:40:34.033124
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    person = Person()

    assert person.random == random
    assert person.random.seed == Seed.get_seed()

    sexuality = person.sexual_orientation()
    assert sexuality in SEXUALITY



# Generated at 2022-06-21 16:40:46.987348
# Unit test for method political_views of class Person