

# Generated at 2022-06-21 16:32:00.755600
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    assert isinstance(person.full_name(), str)
    assert isinstance(person.full_name(gender=Gender.male), str)
    assert isinstance(person.full_name(gender=Gender.female), str)
    assert isinstance(person.full_name(reverse=True), str)
    assert isinstance(person.full_name(reverse=True, gender=Gender.male), str)
    assert isinstance(person.full_name(reverse=True, gender=Gender.female), str)

test_Person_full_name()
from faker.providers.person.en_GB import Provider as PersonProviderGB
from faker.providers.person.en_US import Provider as PersonProviderUS
from faker.providers.person.es_ES import Provider as PersonProviderES

# Generated at 2022-06-21 16:32:09.772177
# Unit test for method age of class Person
def test_Person_age():
    # Make sure that age is not greater than current age
    p = Person()
    now = datetime.now()
    current_year = now.year
    assert p.age() <= current_year

    # Make sure that age is not less than 1900
    p = Person()
    assert p.age() >= 1900

    # Make sure that returns an integer type
    p = Person()
    assert isinstance(p.age(), int)

    # Make sure that age is included in a specific range
    p = Person()
    assert p.age(minimum=10, maximum=20) in range(10, 21)

    # Make sure that age is included in a specific range
    p = Person()
    assert p.age(minimum=18, maximum=40) in range(18, 41)


# Generated at 2022-06-21 16:32:21.170432
# Unit test for constructor of class Person
def test_Person():
    p = Person()

    # Test Person.name()
    name1 = p.name(Gender.MALE)
    name2 = p.name(Gender.FEMALE)
    name4 = p.name(Gender.NON_BINARY)
    assert isinstance(name1, str)
    assert isinstance(name2, str)
    assert isinstance(name4, str)
    names = p.name((Gender.MALE, Gender.FEMALE))
    assert isinstance(names, list)
    assert len(names) == 2
    assert names[0] == name1 and names[1] == name2

    # Test Person.first_name()
    fname1 = p.first_name(Gender.MALE)
    fname2 = p.first_name(Gender.FEMALE)
    fname4

# Generated at 2022-06-21 16:32:24.332918
# Unit test for method political_views of class Person
def test_Person_political_views():
    # Calling method political_views from class Person
    pv = Person.political_views()
    # Verification, if returned value is a instance of string
    assert isinstance(pv, str)
    


# Generated at 2022-06-21 16:32:25.885039
# Unit test for method username of class Person
def test_Person_username():
    assert Person.username(Person, 'UU-d') == 'Lukas.1955'

# Generated at 2022-06-21 16:32:29.474856
# Unit test for method telephone of class Person
def test_Person_telephone():
	person = Person('en')
	print(person.telephone())
	print(person.telephone())
	print(person.telephone())

# Generated at 2022-06-21 16:32:31.334275
# Unit test for method language of class Person
def test_Person_language():
    person = Person()
    languages = person.language()
    assert isinstance(languages,str)

# Generated at 2022-06-21 16:32:34.613193
# Unit test for method title of class Person
def test_Person_title():
    for i in range(1000):
        title = p.title(gender=Gender.MALE, title_type=TitleType.SUFFIX)
        assert title in p.name_titles.values()


# Generated at 2022-06-21 16:32:35.979379
# Unit test for method username of class Person
def test_Person_username():
    #@TODO: Write test
    assert True is True
    

# Generated at 2022-06-21 16:32:37.889335
# Unit test for method identifier of class Person
def test_Person_identifier():
    p = Person()
    identifier = p.identifier()
    assert identifier




# Generated at 2022-06-21 16:32:49.872088
# Unit test for method language of class Person
def test_Person_language():
    x = Person().language()
    assert x in LANGUAGE_NAMES

# Generated at 2022-06-21 16:32:54.026671
# Unit test for method sex of class Person
def test_Person_sex():
    p = Person(random=Random())
    for _ in range(10):
        assert p.sex() in ["Female", "Male"]
        assert p.sex(symbol=True) in ["♀", "♂"]
        assert type(p.sex(iso5218=True)) is int
        assert p.sex() in p._data["gender"]



# Generated at 2022-06-21 16:32:56.161587
# Unit test for method gender of class Person
def test_Person_gender():
    pr = Person()
    assert pr.gender() in pr._data['gender'], \
        """The result of the method 'gender' of the class Person
            must be in the dictionary of gender."""


# Generated at 2022-06-21 16:32:59.254888
# Unit test for method identifier of class Person
def test_Person_identifier():
    v = Person(seed=0)
    assert v.identifier(mask='##-##/##') == '07-97/04'


# Generated at 2022-06-21 16:33:00.667531
# Unit test for method language of class Person
def test_Person_language():
    p = Person()
    print(p.language())

# Generated at 2022-06-21 16:33:05.943972
# Unit test for method last_name of class Person
def test_Person_last_name():
	p = Person()
	s = p.last_name()
	assert s == 'Hernandez'
	s = p.last_name()
	assert s == 'Mcdonald'
	s = p.last_name()
	assert s == 'Johnson'
	s = p.last_name()
	assert s == 'Garcia'

# Generated at 2022-06-21 16:33:10.629424
# Unit test for method title of class Person
def test_Person_title():
    from pydiet import Data

    # When a title type was not passed and gender is not passed
    assert Person().title()

    # When a title type was passed but gender is not passed
    assert Person().title(title_type=TitleType.PREFIX)

    # When a title type was not passed but gender was passed
    assert Person().title(gender=Gender.MAN)

    # When a title type was passed and gender was passed
    assert Person().title(gender=Gender.MAN, title_type=TitleType.PREFIX)

    # When an incorrect value was passed for gender
    with pytest.raises(NonEnumerableError):
        Person().title(gender='test')

    # When an incorrect value was passed for title_type
    with pytest.raises(NonEnumerableError):
        Person().title(title_type='test')

# Generated at 2022-06-21 16:33:12.702532
# Unit test for method full_name of class Person
def test_Person_full_name():
    person = Person()
    full_name = person.full_name()
    assert full_name in person._data['first_name'].values()

# Generated at 2022-06-21 16:33:14.078645
# Unit test for method avatar of class Person
def test_Person_avatar():
    instance = Person(seed=1)

    assert len(instance.avatar()) > 0

# Generated at 2022-06-21 16:33:18.005349
# Unit test for method occupation of class Person
def test_Person_occupation():
    for _ in range(20):
        p = Person(seed=_)
        occupation = p.occupation()
        assert occupation in OCCUPATIONS



# Generated at 2022-06-21 16:33:32.013008
# Unit test for method age of class Person
def test_Person_age():
    # Sample date
    date = date(1998, 7, 17)
    person = Person(date=date)

    # Check
    assert person.age == 21



# Generated at 2022-06-21 16:33:36.015631
# Unit test for method telephone of class Person
def test_Person_telephone():
    person = Person()
    assert re.match(
        r'\+7\(?\d{3}\)?\-?\d{3}\-?\d{2}\-?\d{2}',
        person.telephone()
    )


# Test for method password of class Person

# Generated at 2022-06-21 16:33:38.700508
# Unit test for method occupation of class Person
def test_Person_occupation():
    # Create a person object
    person = Person()
    # Check that the occupation is in the list of occupations
    assert person.occupation in OCCUPATIONS
test_Person_occupation()

# Generated at 2022-06-21 16:33:47.039919
# Unit test for method first_name of class Person
def test_Person_first_name():
    """Unit test for method first_name of class Person."""
    # Create instance of class Person
    person = Person()

    # Call method first_name by passing valid arguments and compare result
    assert person.first_name() in PERSON_FIRST_NAMES
    # Call method first_name by passing invalid arguments and compare result
    try:
        person.first_name('some_gender')
    except NonEnumerableError as err:
        assert str(err) == 'Gender'
    # Call method first_name by passing invalid arguments and compare result
    try:
        person.first_name(gender=Gender.FEMALE)
    except NonEnumerableError as err:
        assert str(err) == 'Gender'
    # Call method first_name by passing invalid arguments and compare result

# Generated at 2022-06-21 16:33:49.664921
# Unit test for method first_name of class Person
def test_Person_first_name():
    with pytest.raises(NonEnumerableError):
        Person().first_name(Gender.MALE)
    assert Person().first_name(Gender.MALE) in ('Егор', 'Петр', 'Сергей', 'Степан')

# Generated at 2022-06-21 16:33:52.665042
# Unit test for method email of class Person
def test_Person_email():
    items = [Person().email() for _ in range(100)]
    assert all(isinstance(e, str) for e in items)
    assert all(('@' in e) for e in items)

# Generated at 2022-06-21 16:33:54.779161
# Unit test for method weight of class Person
def test_Person_weight():
    person = Person()
    p = person.weight(minimum = 80, maximum = 100)

    assert(p >= 80 and p <= 100)

# Generated at 2022-06-21 16:34:00.795796
# Unit test for method nationality of class Person
def test_Person_nationality():
    p = Person()
    assert p.nationality() in p._data['nationality']

    # Separated by gender
    assert p.nationality(Gender.MALE) in p._data['nationality']['male']
    assert p.nationality(Gender.FEMALE) in p._data['nationality']['female']



# Generated at 2022-06-21 16:34:02.221445
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    assert Person().blood_type() in BLOOD_GROUPS


# Generated at 2022-06-21 16:34:05.874030
# Unit test for method avatar of class Person
def test_Person_avatar():
    person = Person(seed=12)
    expected = 'https://api.adorable.io/avatars/256/a7d35b12cdad3cf3f9c9f1b4610c4a4d.png'
    actual = person.avatar()

    assert expected == actual

# Generated at 2022-06-21 16:34:28.441834
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    assert Person().academic_degree() in [
        'Bachelor', 'Master', 'Doctor of Science',
        'Candidate of Science', 'Professor', 'Academician',
        'Associate professor', 'Honored worker of science'
    ]


# Generated at 2022-06-21 16:34:30.512894
# Unit test for method political_views of class Person
def test_Person_political_views():
  if not (Person.political_views() == "Liberal"):
    print("Error: political_views")
    return False
  return True


# Generated at 2022-06-21 16:34:41.787974
# Unit test for method views_on of class Person
def test_Person_views_on():
    # GIVEN
    gender = Gender.MALE
    title_type = TitleType.PREFIX
    minimum = 1800
    maximum = 2070
    template = 'U_d'
    args = None
    kwargs = None
    minimum = 1.5
    maximum = 2.0
    minimum = 38
    maximum = 90
    minimum = 5
    maximum = 50
    mask = '##-##/##'
    mask = '@##-##/##'
    mask = '@@##-##/##'
    mask = '@#$-##/##'
    mask = '@##$-##/##'
    size = 256
    symbol = False
    domains = None
    unique = False
    unique = True
    index = 0
    hashed = False
    hashed = True

# Generated at 2022-06-21 16:34:45.875035
# Unit test for method age of class Person
def test_Person_age():
    assert isinstance(Person().age(), int)
    assert 25 <= Person(age=30).age() <= 35
    assert Person(age=30).age() == Person(age=30, rnd=0).age()
    assert Person(age=30).age() != Person(age=30, rnd=1).age()



# Generated at 2022-06-21 16:34:48.778656
# Unit test for method gender of class Person
def test_Person_gender():
    roman = Person()
    assert len(roman.gender()) == 6
    
    

# Generated at 2022-06-21 16:34:50.150519
# Unit test for method views_on of class Person
def test_Person_views_on():
    assert Person().views_on() == "Positive"


# Generated at 2022-06-21 16:34:52.121744
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    x = Person().social_media_profile()
    assert x is not None
    assert x is not ''


# Generated at 2022-06-21 16:34:55.818475
# Unit test for method weight of class Person
def test_Person_weight():
    Person = PersonProvider()
    expected_result = Person.weight(38, 90)
    assert type(expected_result) == int
    assert expected_result >= 38
    assert expected_result <= 90


# Generated at 2022-06-21 16:34:57.562978
# Unit test for method password of class Person
def test_Person_password():
    # Test result
    password = Person().password()
    assert len(password) == 8
    assert type(password) is str

# Generated at 2022-06-21 16:35:01.350895
# Unit test for method nationality of class Person
def test_Person_nationality():
    minimal_size = 1
    provider = Person()
    assert len(provider.nationality()) >= minimal_size
    
    

# Generated at 2022-06-21 16:37:12.940530
# Unit test for method password of class Person
def test_Person_password():
    # Only for coverage.
    Person.password(length=14, hashed=True)
    Person.password(length=14)
    Person.password(hashed=True)
    Person.password()

    password = Person().password(length=30, hashed=True)
    assert len(password) == 32

    password = Person().password(length=30)
    assert len(password) == 30

    password = Person().password(hashed=True)
    assert len(password) == 32

    password = Person().password()
    assert len(password) == 8



# Generated at 2022-06-21 16:37:20.304070
# Unit test for method telephone of class Person
def test_Person_telephone():
    provider = Person(seed=42)
    assert provider.telephone(mask='') == '+7-(921)-825-37-69'
    assert provider.telephone(mask='##### ##-##-##') == '90401 48-77-40'
    assert provider.telephone(mask='##### ###-##-##') == '90401 825-37-69'
    assert provider.telephone(mask='###### ##-##-##') == '190401 48-77-40'
    assert provider.telephone(mask='+7-##### ##-##-##') == '+7-90401 48-77-40'
    assert provider.telephone(mask='+7-##### ###-##-##') == '+7-90401 825-37-69'

# Generated at 2022-06-21 16:37:22.872038
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    assert isinstance(person.name(), str)
    assert isinstance(person.name(Gender.Female), str)
    assert isinstance(person.name(Gender.Male), str)

# Generated at 2022-06-21 16:37:27.295450
# Unit test for method height of class Person
def test_Person_height():
    p = Person()
    for i in range(100):
        assert round(float(p.height()),2) >= 1.5
        assert round(float(p.height()),2) <= 2.0
        assert isinstance(p.height(),str)

# Generated at 2022-06-21 16:37:29.637242
# Unit test for method political_views of class Person
def test_Person_political_views():
    pr = Provider()
    political_view = pr.political_views()
    assert political_view in POLITICAL_VIEWS


# Generated at 2022-06-21 16:37:35.786788
# Unit test for method blood_type of class Person
def test_Person_blood_type():
    person = Person()
    dic = {}
    for i in range(200):
        dic[person.blood_type()] = dic.setdefault(person.blood_type(), 0) + 1
    print(dic)
    assert isinstance(dic, dict)
    # {'O+': 57, 'A-': 32, 'A+': 40, 'AB+': 24, 'B+': 36, 'B-': 32, 'AB-': 20, 'O-': 9}

# Generated at 2022-06-21 16:37:37.808402
# Unit test for method password of class Person
def test_Person_password():
    import pytest
    p = Person()
    result = p.password(1, 1)
    assert isinstance(result, str)



# Generated at 2022-06-21 16:37:40.709392
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person(seed=99)
    assert person.sex() == 'Male'
    assert person.sex(iso5218=True) == 1
    assert person.sex(symbol=True) == '♂'

# Generated at 2022-06-21 16:37:46.648987
# Unit test for method email of class Person
def test_Person_email():
    random.seed(0)
    P = Person(seed=0)

    assert P.email() == 'foretime10@live.com'
    assert P.email() == 'foretime10@live.com'
    assert P.email(unique=True) == 'foretime10@live.com'
    assert P.email(unique=True) == 'foretime10_1@live.com'
    assert P.email(unique=True) == 'foretime10_2@live.com'

# Generated at 2022-06-21 16:37:48.693910
# Unit test for method telephone of class Person
def test_Person_telephone():
    p = Person()
    assert re.match(r"\+\d{1,3}-\(\d{3}\)-\d{3}-\d{4}", p.telephone())
