

# Generated at 2022-06-21 16:31:47.198601
# Unit test for method last_name of class Person
def test_Person_last_name():
    rnd_pers = Person(seed=12345)
    lst_name = rnd_pers.last_name() # surname
    print("Random surname: " + lst_name)
    assert lst_name == "Krajnc"
    
test_Person_last_name()


# Generated at 2022-06-21 16:31:52.812960
# Unit test for method age of class Person
def test_Person_age():
    provider = factories.Faker()
    data = provider.data['age_range']
    person = Person(provider)

    for _ in range(100):
        minimum, maximum = data
        age = person.age()
        msg = 'Invalid age. Must be from {} to {}'
        assert minimum <= age <= maximum, msg.format(minimum, maximum)



# Generated at 2022-06-21 16:31:57.124642
# Unit test for method username of class Person
def test_Person_username():
    p = Person()
    res = p.username()
    assert res
    # Test for email uniqueness
    res1 = p.email()
    res2 = p.email()
    assert res1 != res2


# Generated at 2022-06-21 16:31:58.503934
# Unit test for method language of class Person
def test_Person_language():
    res = Person.language()
    assert res in LANGUAGES

# Generated at 2022-06-21 16:32:04.964283
# Unit test for method work_experience of class Person
def test_Person_work_experience():
    person = Person()

    # The count of letters in a string
    def letters(string):
        counter = 0
        for char in string:
            if char == ',':
                counter += 1
        return counter


    test1 = person.work_experience()
    test2 = person.work_experience()

    assert test1 != test2
    assert letters(test1) == letters(test2)


# Generated at 2022-06-21 16:32:06.766567
# Unit test for method age of class Person
def test_Person_age():
    result = Person().age()
    assert result >= 18 and result <= 70


# Generated at 2022-06-21 16:32:13.318603
# Unit test for method last_name of class Person
def test_Person_last_name():
    for i in range(100):
        # try each of the genders
        for gender in [Gender.MALE, Gender.FEMALE]:
            name = Faker.get_instance(locale='en').person.last_name(gender)
            assert name is not None
            assert len(name) > 0
            assert name.count('-') < 2
            assert name.count(' ') < 2
    
    # all other genders return values for both genders
    for i in range(100):
        for gender in ['', Gender.ANDROGYNOUS, Gender.UNKNOWN]:
            name1 = Faker.get_instance(locale='en').person.last_name(gender)
            name2 = Faker.get_instance(locale='en').person.last_name(Gender.MALE)
            name3 = Faker.get

# Generated at 2022-06-21 16:32:17.279575
# Unit test for method name of class Person
def test_Person_name():
    """Unit test for method name of class Person."""
    person = Person()
    name = person.name(Gender.MALE)
    assert name != None
    assert isinstance(name, str)
    assert name != ''
    assert name.isalpha()
    assert name.lower() in [name.lower() for name in MAN_NAMES]


# Generated at 2022-06-21 16:32:21.924017
# Unit test for method language of class Person
def test_Person_language():
    """ Tests method language of class Person"""
    random_number = random.random()
    random.seed(random_number)
    assert(random_number == random.random())
    person = Person()
    assert(type(person.language()) == str)
    random.seed(random_number)
    assert(person.language() == Person().language())

# Generated at 2022-06-21 16:32:23.703252
# Unit test for method worldview of class Person
def test_Person_worldview():
    test = Person()
    worldview = test.worldview()
    assert worldview in test._data['worldview']
    

# Generated at 2022-06-21 16:32:33.992877
# Unit test for method height of class Person
def test_Person_height():
    persn = Person()
    assert persn.height()

# Generated at 2022-06-21 16:32:37.917446
# Unit test for method surname of class Person
def test_Person_surname():
    person = Person(random=Random(x=1))
    assert person.surname() == 'X'
    assert person.surname(gender=Gender.MALE) == 'X'
    assert person.surname(gender=Gender.FEMALE) == 'X'
    # assert person.last_name() == 'X'
    # assert person.last_name(gender=Gender.MALE) == 'X'
    # assert person.last_name(gender=Gender.FEMALE) == 'X'


# Generated at 2022-06-21 16:32:40.899287
# Unit test for method political_views of class Person
def test_Person_political_views():
    from faker import Faker as Expected

    actual = Faker(random=MockRandom(), locale='en_US').political_views()
    expected = Expected(random=MockRandom(), locale='en_US').political_views()

    assert actual == expected


# Generated at 2022-06-21 16:32:51.937481
# Unit test for method last_name of class Person
def test_Person_last_name():
    p = Person()
    assert isinstance(p.last_name(), str)
    assert isinstance(p.last_name(gender=Gender.MALE), str)
    assert isinstance(p.last_name(gender=Gender.FEMALE), str)
    assert isinstance(p.last_name(gender=Gender.UNKNOWN), str)
    assert isinstance(p.last_name(gender=Gender.OTHER), str)
    #
    # Reverse
    assert isinstance(p.last_name(), str)
    assert isinstance(p.last_name(gender=Gender.MALE), str)
    assert isinstance(p.last_name(gender=Gender.FEMALE), str)
    assert isinstance(p.last_name(gender=Gender.UNKNOWN), str)

# Generated at 2022-06-21 16:32:56.591579
# Unit test for method identifier of class Person
def test_Person_identifier():
    # test 1
    identifier = Person().identifier()
    assert isinstance(identifier, str)

    # test 2
    identifier = Person().identifier(mask='##-##/##')
    assert isinstance(identifier, str)



# Generated at 2022-06-21 16:33:05.944602
# Unit test for method sexual_orientation of class Person
def test_Person_sexual_orientation():
    # Assuming that a single call to this method could have 5 possible results,
    # if the probability of a result is 1/5, then in a single test,
    # at least 1 result should have 5 or more repetitions.
    # The code below is the implementation of the empirical test.
    sexual_orientations = set()

# Generated at 2022-06-21 16:33:06.869809
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    print(Person.social_media_profile(site="facebook"))

# Generated at 2022-06-21 16:33:09.286166
# Unit test for method political_views of class Person
def test_Person_political_views():
    res = Person.political_views()
    assert (res in Person._data['political_views']) == True
test_Person_political_views()

# Generated at 2022-06-21 16:33:10.581656
# Unit test for method name of class Person
def test_Person_name():
    person = Person()
    assert 'A' in person.name()


# Generated at 2022-06-21 16:33:18.812592
# Unit test for method full_name of class Person
def test_Person_full_name():

    # You can create object of class Person with any arguments.
    obj = Person()

    # You can get full name with surname or without it.
    full_name = obj.full_name()
    print(full_name)
    # Output: Günter Weiss

    full_name = obj.full_name(reversed=True)
    print(full_name)
    # Output: Fransois Bernard

    full_name = obj.full_name(reversed=True, gender=Gender.male)
    print(full_name)
    # Output: Stephan Schmidt

    full_name = obj.full_name(reversed=False, gender=Gender.female)
    print(full_name)
    # Output: Brigitte Fürst

    # Separated by gender
    obj = Person(gender=Gender.female)

# Generated at 2022-06-21 16:33:33.738069
# Unit test for method first_name of class Person
def test_Person_first_name():
    """Unit test for method first_name of class Person."""
    person_provider = Person()
    first_name = person_provider.first_name()

    assert type(first_name) == str, \
        '\'first_name\' should be a string'

    assert len(first_name) > 2, \
        '\'first_name\' should have at least 3 characters'



# Generated at 2022-06-21 16:33:35.881499
# Unit test for method first_name of class Person
def test_Person_first_name():
    person = Person()
    assert person.first_name() in person._data['name']


# Generated at 2022-06-21 16:33:36.929883
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    assert True == True


# Generated at 2022-06-21 16:33:45.735044
# Unit test for method telephone of class Person
def test_Person_telephone():
    # Test for method telephone of class Person
    # - Part one
    assert Person().telephone() == '+7-(771)-828-5677'
    # - Part two
    r = Random()
    p = Person()

    r.seed(0)
    assert p.telephone() == '+7-(771)-828-5677'

    r.seed(1)
    assert p.telephone() == '+7-(241)-596-1691'

    r.seed(2)
    assert p.telephone() == '+7-(241)-596-1691'

    r.seed(3)
    assert p.telephone() == '+7-(155)-570-7278'

    r.seed(4)
    assert p.telephone() == '+7-(738)-890-7723'

   

# Generated at 2022-06-21 16:33:48.923482
# Unit test for method avatar of class Person
def test_Person_avatar():
    """
    Test Person's method avatar.
    """
    assert Person().avatar()[:30] == 'https://api.adorable.io/avatars'

# Generated at 2022-06-21 16:33:50.962414
# Unit test for method sex of class Person
def test_Person_sex():
    person = Person()
    assert person.sex() in Gender._member_names_

# Generated at 2022-06-21 16:33:56.963948
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    provider = Person(random=Random(2))
    assert provider.social_media_profile(SocialNetwork.Twitter) == \
        'https://twitter.com/Korea90'
    assert provider.social_media_profile(SocialNetwork.SoundCloud) == \
        'https://soundcloud.com/Korea90'
    assert provider.social_media_profile(SocialNetwork.Facebook) == \
        'https://facebook.com/Korea90'
    assert provider.social_media_profile(SocialNetwork.Instagram) == \
        'https://instagram.com/Korea90'
    assert provider.social_media_profile(SocialNetwork.GitHub) == \
        'https://github.com/Korea90'

# Generated at 2022-06-21 16:34:06.494602
# Unit test for method language of class Person
def test_Person_language():
    person = Person(seed=1)

# Generated at 2022-06-21 16:34:12.052239
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    # Setup
    person = Person()

    # Exercise
    profile = person.social_media_profile()

    # Verify
    assert profile is not None
    assert len(profile) != 0
    assert isinstance(profile, str)
    assert profile != "None"
    assert profile != "False"
# This test a method social_media_profile from Person class
test_Person_social_media_profile()


# Generated at 2022-06-21 16:34:15.281231
# Unit test for method age of class Person
def test_Person_age():
    # 1. ARRANGE
    person = Person()
    minimum = 12  # Minimum age
    maximum = 18  # Maximum age

    # 2. ACT 
    age = person.age(minimum, maximum)

    # 3. ASSERT
    assert minimum <= age <= maximum


# Generated at 2022-06-21 16:34:29.873582
# Unit test for method political_views of class Person
def test_Person_political_views():
    p = Person()
    res = p.political_views()
    assert isinstance(res, str)
    assert len(res) >= 3



# Generated at 2022-06-21 16:34:32.088591
# Unit test for method views_on of class Person
def test_Person_views_on():
    s = Faker()
    views_on = s.views_on()
    assert views_on in VIEWS_ON




# Generated at 2022-06-21 16:34:37.648567
# Unit test for method title of class Person
def test_Person_title():
    person = Person()
    expected = True
    value = (isinstance(person.title(), str) or 
             isinstance(person.title(title_type=TitleType.SUFFIX), str) or 
             isinstance(person.title(title_type=TitleType.PREFIX), str))
    assert value == expected
test_Person_title()

# Generated at 2022-06-21 16:34:41.832953
# Unit test for method full_name of class Person
def test_Person_full_name():
    for num in range(10):
        f_name = Person().full_name()
        assert isinstance(f_name, str)
        assert ' ' in f_name
        assert len(f_name.split(' ')) == 2


# Generated at 2022-06-21 16:34:44.003627
# Unit test for method worldview of class Person
def test_Person_worldview():
    p = Person()
    assert p.worldview() in PERSON_WORLDVIEW

# Generated at 2022-06-21 16:34:45.452618
# Unit test for method name of class Person
def test_Person_name():
    print(Person._data['name'])
    print(Person.name(gender=Gender(1)))



# Generated at 2022-06-21 16:34:48.645940
# Unit test for method political_views of class Person
def test_Person_political_views():
    provider = Person()
    assert provider.political_views() in provider._data['political_views']

# Generated at 2022-06-21 16:34:51.396988
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    last_name = person.last_name()

    # Test that method return string
    assert isinstance(last_name, str)


# Generated at 2022-06-21 16:34:53.986736
# Unit test for method academic_degree of class Person
def test_Person_academic_degree():
    academic_degree = Person().academic_degree()
    assert academic_degree



# Generated at 2022-06-21 16:34:55.660395
# Unit test for method avatar of class Person
def test_Person_avatar():
    obj = Person()
    assert isinstance(obj.avatar(), str)


# Generated at 2022-06-21 16:35:16.936755
# Unit test for method email of class Person
def test_Person_email():
    for i in range(10):
        assert Person().email()
        assert Person().email(unique=True)

# Generated at 2022-06-21 16:35:18.704096
# Unit test for method university of class Person
def test_Person_university():
    pass
    # university = Person.university()
    # assert isinstance(university, str)



# Generated at 2022-06-21 16:35:27.888579
# Unit test for method identifier of class Person
def test_Person_identifier():
    from lib.text_generator import Person
    provider = Person()
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print(provider.identifier())
    print

# Generated at 2022-06-21 16:35:29.742930
# Unit test for method name of class Person
def test_Person_name():
    # Testing of method name if exist in class Person
    assert hasattr(Person, "name")



# Generated at 2022-06-21 16:35:32.559849
# Unit test for method username of class Person
def test_Person_username():
    global p
    p = Person()
    assert p.username(template='l.d') == 'j.25'

# Generated at 2022-06-21 16:35:39.597269
# Unit test for method occupation of class Person
def test_Person_occupation():
    p = Person()
    assert p.occupation() == 'Kaplan' or p.occupation() == 'Çavuş' or p.occupation() == 'Öğretmen' or p.occupation() == 'Memur' or p.occupation() == 'Şoför' or p.occupation() == 'Doçent' or p.occupation() == 'Yönetici' or p.occupation() == 'Araştırmacı' or p.occupation() == 'Görevli' or p.occupation() == 'Mühendis' or p.occupation() == 'Sekreter' or p.occupation() == 'Vekil' or p.occupation() == 'Analist' or p.occupation() == 'Müdür' or p.occupation() == 'Operatör'

# Generated at 2022-06-21 16:35:42.952988
# Unit test for method occupation of class Person
def test_Person_occupation():
    provider = Person(random=Random())

    for i in range(10):
        result = provider.occupation()
        assert isinstance(result, str)


# Generated at 2022-06-21 16:35:46.198648
# Unit test for method first_name of class Person
def test_Person_first_name():
    """Unit test for method first_name of class Person"""
    provider = PersonProvider(random=FakeRandom(0))
    first_name = provider.first_name()
    assert first_name == 'Елена'


# Generated at 2022-06-21 16:35:52.965354
# Unit test for method age of class Person
def test_Person_age():
    p = Person()
    assert isinstance(p.age(), int)
    assert p.age() >= 0
    assert p.age(minimum=10, maximum=20) <= 20
    assert p.age(minimum=10, maximum=20) >= 10



# Generated at 2022-06-21 16:35:57.114162
# Unit test for method gender of class Person
def test_Person_gender():
    # Test method gender in class Person
    person = Person(random=Random())
    assert person.gender() in PERSON.GENDERS,\
        "method gender() failed for class Person"

    assert person.sex() in PERSON.GENDERS,\
        "method sex() failed for class Person"

    print("Test method gender() of class Person: successful!")



# Generated at 2022-06-21 16:36:43.571113
# Unit test for method password of class Person
def test_Person_password():
    p = Person()
    assert len(p.password()) == 8
    assert isinstance(p.password(hashed=True), str)
    assert len(p.password(length=10)) == 10
    assert len(p.password(length=12)) == 12
    assert len(p.password(length=14)) == 14
    assert len(p.password(length=5)) == 5
    assert len(p.password(length=7)) == 7
    assert len(p.password(length=17)) == 17
    assert len(p.password(length=9)) == 9
    assert len(p.password(length=6)) == 6
    assert len(p.password(length=11)) == 11
    assert len(p.password(length=13)) == 13
    assert len(p.password(length=16)) == 16



# Generated at 2022-06-21 16:36:44.877233
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    person = Person()
    profiles = person.social_media_profile()
    assert profiles is not None

# Generated at 2022-06-21 16:36:47.102710
# Unit test for method last_name of class Person
def test_Person_last_name():
    person = Person()
    person_last_name = person.last_name()
    assert person_last_name in MAN_NAME_LAST_NAME or person_last_name in WOMAN_NAME_LAST_NAME


# Generated at 2022-06-21 16:36:48.869291
# Unit test for method last_name of class Person
def test_Person_last_name():
    assert Person().last_name() == Person().surname()
    
    

# Generated at 2022-06-21 16:36:59.261062
# Unit test for method title of class Person
def test_Person_title():
    person = Person(seed=1)
    assert person.title() == "Ms."
    assert person.title(Gender.MALE) == "Mr."
    assert person.title(TitleType.SUFFIX) == "III"
    assert person.title(Gender.FEMALE, TitleType.PREFIX) == "Dr."
    assert person.title(Gender.MALE, TitleType.SUFFIX) == "Jr."
    assert person.title(gender=Gender.FEMALE, title_type=TitleType.PREFIX) == "Mr."
    assert person.title(title_type=TitleType.SUFFIX, gender=Gender.MALE) == "Jr."
    assert person.title(title_type=TitleType.PREFIX, gender=Gender.FEMALE) == "Mrs."

# Generated at 2022-06-21 16:37:10.199685
# Unit test for method university of class Person
def test_Person_university():
        P = Person()
        # Dictionaries and lists should contain the following values.

# Generated at 2022-06-21 16:37:12.326336
# Unit test for method height of class Person
def test_Person_height():
    height=Person(random_state=1)
    assert height.height()=="1.58"
    return "Method 'height' works fine."

print(test_Person_height())

# Generated at 2022-06-21 16:37:13.945947
# Unit test for method weight of class Person
def test_Person_weight():
    for i in range(100):
        provider = Person()
        assert provider.weight(38,90) <= 90
        assert provider.weight(38,90) >= 38


# Generated at 2022-06-21 16:37:15.916216
# Unit test for method username of class Person
def test_Person_username():
    person = Person()
    print("\n ##### This is unit test for method username of class Person #####\n")
    print("Username is: ", person.username() )


# Generated at 2022-06-21 16:37:18.977263
# Unit test for method social_media_profile of class Person
def test_Person_social_media_profile():
    lst = []
    for _ in range(100):
        sp = Person().social_media_profile()
        lst.append(sp)
    return lst
print(test_Person_social_media_profile())

# Test for method social_media_profile of class Person