

# Generated at 2022-06-11 20:34:02.058673
# Unit test for function unzip
def test_unzip(): # pragma: no cover
    import os
    import shutil
    import tempfile
    from zipfile import ZipFile
    from nose.tools import assert_equal

    # First create a dummy zip file
    zip_path = os.path.join(tempfile.mkdtemp(), 'dummy.zip')
    dummy_zip = ZipFile(zip_path, 'w')
    dummy_zip.writestr('test/test.txt', 'Hello')
    dummy_zip.close()

    # Now try to unzip it
    unzipped = unzip(zip_path, False)
    assert_equal(
        os.path.exists(os.path.join(unzipped, 'test', 'test.txt')),
        True
    )

    # Clean up

# Generated at 2022-06-11 20:34:15.067902
# Unit test for function unzip
def test_unzip():
    from zipfile import PyZipFile
    import zipfile
    import tempfile, os, shutil
    tmp_dir = tempfile.mkdtemp()

    # Testing repo with password and dir structure
    zip_path = os.path.join(tmp_dir,'tmp.zip')


# Generated at 2022-06-11 20:34:24.963358
# Unit test for function unzip
def test_unzip():
    is_url = True
    no_input = False
    url = 'https://github.com/makasim/cookiecutter-aiohttp/archive/master.zip'
    path = os.path.dirname(__file__)
    unzip_path = unzip(url, is_url, path, no_input)
    assert os.path.exists(os.path.join(unzip_path, '.cookiecutter.yaml')) is True
    assert os.path.exists(os.path.join(unzip_path, '.gitignore')) is True
    assert os.path.exists(os.path.join(unzip_path, 'hooks')) is True
    assert os.path.exists(os.path.join(unzip_path, 'tests')) is True

# Generated at 2022-06-11 20:34:35.913379
# Unit test for function unzip
def test_unzip():
    import sys
    from os import getcwd, chdir
    from os.path import dirname, join, abspath

    working_dir = getcwd()
    cookiecutter_dir = dirname(dirname(dirname(abspath(__file__))))
    chdir(cookiecutter_dir)
    sys.path.insert(0, cookiecutter_dir)

    from cookiecutter.utils import unzip

    local_zip_tempdir = unzip(
        'tests/fixtures/fake-repo-tmpl/fake-repo-tmpl.zip', False
    )
    http_zip_tempdir = unzip(
        'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True
    )

# Generated at 2022-06-11 20:34:37.483276
# Unit test for function unzip
def test_unzip():

    unzip('doesnotexist', True, '.', True, None)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-11 20:34:39.140388
# Unit test for function unzip
def test_unzip():
    assert os.path.exists("tests/test-repo-unzip/")

# Generated at 2022-06-11 20:34:48.576327
# Unit test for function unzip
def test_unzip():
    import unittest
    import requests
    import requests_mock
    from requests.exceptions import HTTPError

    class TestUnzip(unittest.TestCase):
        def test_bad_zip(self):
            # Bad zipfile.
            with self.assertRaises(InvalidZipRepository):
                unzip('does/not/exist', True)

        def test_bad_url(self):
            # Bad URL.
            with self.assertRaises(HTTPError):
                unzip('http://does-not-exist/not-a-zip-file.zip', True)

        def test_bad_local_zip(self):
            # Bad local zip.
            with self.assertRaises(InvalidZipRepository):
                unzip('tests/data/unzip/not-a-zip-file.zip', False)

       

# Generated at 2022-06-11 20:34:56.807700
# Unit test for function unzip
def test_unzip():
    """Test unzip function"""
    try:
        # check it works with an unprotected repo
        unzip_zip_uri = unzip('tests/test-unprotect-repo/cookiecutter-unprotect-repo.zip',
                              is_url=False,
                              clone_to_dir=None,
                              no_input=True)
        assert unzip_zip_uri
        # check it works with a protected repo
        unzip_zip_uri = unzip('tests/test-protect-repo/cookiecutter-protect-repo.zip',
                              is_url=False,
                              no_input=True,
                              password='password')
        assert unzip_zip_uri
    except InvalidZipRepository:
        # good, this means it didn't unzip properly
        pass

# Generated at 2022-06-11 20:34:59.434621
# Unit test for function unzip
def test_unzip():
    unzip_path = unzip("test_repo.zip", False)
    assert os.path.exists(unzip_path)



# Generated at 2022-06-11 20:35:00.109274
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:35:13.595396
# Unit test for function unzip
def test_unzip():
    import filecmp

    # Simple test
    assert unzip('tests/test_unzip.zip', True) == \
        'tests/test_unzip_extract'

    # Simple test: the zipfile is a directory
    assert unzip('tests/test_unzip_directory.zip', True) == \
        'tests/test_unzip_extract'

    # Simple test: the zipfile is a file
    assert unzip('tests/test_unzip_file.zip', True) == \
        'tests/test_unzip_extract'

    # Simple test: the zipfile is empty

# Generated at 2022-06-11 20:35:24.970494
# Unit test for function unzip
def test_unzip():
    from tempfile import mkdtemp
    from shutil import rmtree
    from zipfile import ZipFile, ZIP_DEFLATED
    from unittest import TestCase

    class TestUnzip(TestCase):
        def setUp(self):
            self.tmpdir = mkdtemp()

        def tearDown(self):
            rmtree(self.tmpdir)

        def test_unzip_url(self):
            # Create a zipfile
            zdir = os.path.join(self.tmpdir, 'zipdir')
            os.makedirs(zdir)
            file = os.path.join(zdir, 'file.txt')
            with open(file, 'w') as f:
                f.write('Test')
            zfile = os.path.join(self.tmpdir, 'test.zip')


# Generated at 2022-06-11 20:35:36.405438
# Unit test for function unzip
def test_unzip():
    """
    Test to ensure that a zip repository is unzipped properly
    """
    import shutil
    # Create a directory to act as the user's cookiecutter repository
    repository_dir = tempfile.mkdtemp()
    # Create the zip file that should be downloaded
    zip_filename = 'test_project'
    zip_file = os.path.join(repository_dir, zip_filename + '.zip')
    import zipfile
    zip_file_obj = zipfile.ZipFile(zip_file, 'w')
    zip_file_obj.write(os.path.join(repository_dir, 'file.txt'), 'test_project/file.txt')
    zip_file_obj.close()

    # The function that we are testing
    unzip(zip_file, False, repository_dir)

    #

# Generated at 2022-06-11 20:35:36.850509
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:35:37.332870
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:35:38.485940
# Unit test for function unzip
def test_unzip():
    unzip()

# Generated at 2022-06-11 20:35:48.052214
# Unit test for function unzip
def test_unzip():
    from unittest import mock

    # Test invalid zip archive
    with mock.patch('cookiecutter.utils.zipfile.ZipFile') as patch_zipfile:
        # Set up an exception on the first call to open()
        # after the original call to __init__
        patch_zipfile.side_effect = [Exception(), None]
        # This should raise a BadZipFile exception
        try:
            unzip('foo', False)
        except BadZipFile as e:
            pass
        except:
            raise AssertionError('BadZipFile expected')
        
        # Test valid zip archive with no password
        clone_to = '~/cookiecutters'

# Generated at 2022-06-11 20:35:58.379305
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    import unittest
    import zipfile
    import requests_mock

    class TestUnzip(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = os.path.abspath(tempfile.mkdtemp())
            self.zip_archive = os.path.join(self.tmp_dir, 'tmp.zip')
            self.zip_url = 'http://example.com/repo.zip'
            self.project_name = 'repo'
            self.repo_name = 'repo-master'
            self.zip_file = zipfile.ZipFile(self.zip_archive, mode='w')
            self.zip_file.writestr('{}/'.format(self.project_name), '')



# Generated at 2022-06-11 20:36:06.425460
# Unit test for function unzip
def test_unzip():
    zip_uri = 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(zip_uri,'url')
    assert os.path.exists(unzip_path)
    try:
        shutil.rmtree(unzip_path)
    except:
        pass

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-11 20:36:07.701709
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:36:21.617183
# Unit test for function unzip

# Generated at 2022-06-11 20:36:27.498544
# Unit test for function unzip
def test_unzip():
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = None
    #zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    zip_uri = 'https://github.com/AnthonyLouis/cookiecutter-audreyr-pypackage/archive/master.zip'
    unzip(zip_uri, is_url, clone_to_dir, no_input, password)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-11 20:36:31.852154
# Unit test for function unzip
def test_unzip():
    import shutil
    assert 'cookiecutter' in unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True, clone_to_dir='/tmp')
    shutil.rmtree('/tmp/cookiecutter-pypackage-')

# Generated at 2022-06-11 20:36:41.649997
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile

    # Create a temporary zip file
    _cwd = os.getcwd()
    _zip_base = tempfile.mkdtemp()

    os.chdir(_zip_base)
    test_file = open("test", "w")
    test_file.write("content")
    test_file.close()

    # Create zip archive
    import zipfile
    with zipfile.ZipFile("test_zip_file.zip", "w") as zf:
        zf.write("test", "test/test")
    
    # Test unzip function
    unzip_path = unzip("test_zip_file.zip", False)
    assert os.path.exists(unzip_path)

# Generated at 2022-06-11 20:36:51.989683
# Unit test for function unzip
def test_unzip():
    """Unit test to verify zip file unzipping.

    Creates a zip file containing a simple file in a directory and 
    verifies that the file is extracted to the expected location.
    """

    # Create a temporary file to hold the zipped file contents
    zip_file = tempfile.NamedTemporaryFile(delete=False)
    zip_file_path = zip_file.name
    zip_file.close()

    # Create a temporary file to hold the simple file
    simple_file = tempfile.NamedTemporaryFile(delete=False)
    simple_file_path = simple_file.name
    simple_file.close()

    # Create the zip file
    import zipfile

# Generated at 2022-06-11 20:37:02.106979
# Unit test for function unzip
def test_unzip():
    import os
    from glob import glob
    from os.path import exists, join, isdir
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase
    from unittest.mock import patch, MagicMock

    class UnzipTest(TestCase):
        """Test the function unzip"""

        def setUp(self):
            self.tmpdir = mkdtemp()
            self.zip_repo_path = join(self.tmpdir, 'zip_repo.zip')
            self.zip_repo_dir = join(self.tmpdir, 'zip_repo')

        def tearDown(self):
            if exists(self.tmpdir):
                rmtree(self.tmpdir)


# Generated at 2022-06-11 20:37:07.178027
# Unit test for function unzip
def test_unzip():
	"""
	This function will test the unzip function by unzipping a zip file, then checking that the zip file is indeed 
	in a temporary directory.
	"""
	assert os.path.isdir(unzip("https://github.com/ONRTestAccount/ONRTest/archive/master.zip", True))

# Generated at 2022-06-11 20:37:14.719825
# Unit test for function unzip
def test_unzip():
    import shutil
    from cookiecutter.main import cookiecutter
    from cookiecutter import __version__ as cookiecutter_version
    from pkg_resources import parse_version

    # create temporary directory for cookies
    cookie_dir = tempfile.mkdtemp()

    repo = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    zip_path = os.path.join(cookie_dir, 'cookiecutter-pypackage.zip')
    unzip_path = unzip(repo, True, cookie_dir)

    # check that zip file is downloaded
    assert os.path.exists(zip_path)

    # check that the zip file is not empty
    zip_file = ZipFile(zip_path)

# Generated at 2022-06-11 20:37:17.495953
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    import shutil

    clone_to_dir = './tests/fixtures'
    zip_path = './tests/fixtures/test_unzip.zip'

    # test: can unzip a zip file in zip_path
    try:
        unzip_path = unzip(zip_path, False)
        assert os.path.isfile(os.path.join(unzip_path, 'test.txt'))
    finally:
        shutil.rmtree(unzip_path)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-11 20:37:25.485735
# Unit test for function unzip
def test_unzip():
    """
    unzip()
    """
    zip_url = "https://github.com/chintal/cookiecutter-pypackage/archive/master.zip"
    is_url = True
    clone_to_dir='.'
    no_input = True
    password=None
    unzip_dir = unzip(zip_url, is_url, clone_to_dir, no_input, password)
    assert os.path.exists(unzip_dir)
    assert os.path.exists(os.path.join(unzip_dir, 'cookiecutter.json'))
    assert os.path.exists(os.path.join(unzip_dir, 'setup.py'))

    # Password protected zip file.

# Generated at 2022-06-11 20:38:05.208751
# Unit test for function unzip
def test_unzip():
    repo_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    clone_to_dir = os.path.expanduser('~/PycharmProjects/test')
    is_url = True
    no_input = False
    password = None

    clone_dir = clone(repo_url, is_url, clone_to_dir, no_input)

    assert os.path.isdir(clone_dir)
    assert os.listdir(clone_dir)

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-11 20:38:14.237833
# Unit test for function unzip
def test_unzip():
    unzip_test_dir = os.path.realpath(
        os.path.join(os.path.dirname(__file__),'unzip_test_dir')
    )

    # Ensure the repository directory exists
    make_sure_path_exists(unzip_test_dir)

    # Build the name of the cached zipfile,
    # and prompt to delete if it already exists.
    zip_url_path = "https://github.com/wdm0006/cookiecutter-data-science/archive/master.zip"
    zip_url_path = os.path.join(unzip_test_dir, zip_url_path.rsplit('/', 1)[1])
    zip_local_path = os.path.join(os.path.dirname(__file__), 'test.zip')

    #

# Generated at 2022-06-11 20:38:22.095637
# Unit test for function unzip
def test_unzip():
    '''unit test for function unzip'''
    import pytest
    with pytest.raises(InvalidZipRepository):
        clone_to_dir = os.path.join(tempfile.mkdtemp(), 'repo')
        os.makedirs(clone_to_dir)
        unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/' \
              '0.4.2.zip', is_url=True, clone_to_dir=clone_to_dir, no_input=True)

# Generated at 2022-06-11 20:38:32.506398
# Unit test for function unzip
def test_unzip():
    import requests
    import requests_mock
    import os
    import pytest
    import shutil

    import cookiecutter.utils.zipfile
    from cookiecutter.exceptions import InvalidZipRepository
    from cookiecutter.prompt import read_repo_password

    # Create mocked zip files
    zip_url = 'https://github.com/cookiecutter/cookiecutter/archive/master.zip'
    zip_path = os.path.abspath(os.path.join(os.getcwd(), 'tests', 'files', 'tests.zip'))
    zip_password_path = os.path.abspath(os.path.join(os.getcwd(), 'tests', 'files', 'tests_password.zip'))

# Generated at 2022-06-11 20:38:41.917679
# Unit test for function unzip
def test_unzip():
    """Test unzip function.
    """
    import platform
    if platform.system()=='Windows':
        clone_to_dir=os.getenv("USERPROFILE")
    else:
        clone_to_dir=os.path.expanduser("~")

    zip_uri = 'https://github.com/mikejdavis03/api/archive/master.zip'
    result = unzip(zip_uri, is_url=True, clone_to_dir=clone_to_dir, no_input=True, \
        password=None)
    assert result.startswith('/tmp')
    assert result.endswith('api-master')
    assert os.path.isdir(result)

# Generated at 2022-06-11 20:38:51.841483
# Unit test for function unzip
def test_unzip():
    import pytest
    from .test_utils import make_temp_directory
    from .mock_data import EXAMPLE_ZIP, EXAMPLE_ZIP_PASSWORD

    # Setup
    template_name = "unzip"
    template_dir = os.path.join(make_temp_directory(), template_name)
    os.makedirs(template_dir)

    # Test: unzip function should not raise an exception
    zip_path = os.path.join(template_dir, 'example-repo.zip')
    with open(zip_path, 'wb') as f:
        f.write(EXAMPLE_ZIP)
    unzip(zip_path, False, template_dir)

    # Teardown
    shutil.rmtree(template_dir)

# Generated at 2022-06-11 20:38:52.244436
# Unit test for function unzip
def test_unzip():
    assert True

# Generated at 2022-06-11 20:39:03.056475
# Unit test for function unzip
def test_unzip():
    import shutil
    from zipfile import ZipFile 
    from pathlib import Path
    zip_path = 'tmp/'
    file_name = 'repository.zip'
    # create zip file
    def zipdir(path, ziph):
        # ziph is zipfile handle
        for root, dirs, files in os.walk(path):
            for file in files:
                ziph.write(os.path.join(root, file))
    if not os.path.exists(zip_path):
        os.makedirs(zip_path)
    zipf = ZipFile(zip_path + file_name, 'w', zipfile.ZIP_DEFLATED)
    zipdir('tmp', zipf)
    zipf.close()
    

# Generated at 2022-06-11 20:39:10.889568
# Unit test for function unzip
def test_unzip():
    # Test for checking zip file
    test_file = '/Users/clw/Cloud/Github/pyecoregen/examples/sample_ecore_models/ecore.zip'
    # Create password variable to test the exception
    password = 'InvalidPassword'
    is_url  = False
    no_input = True

    unzip_path = unzip(test_file, is_url, password=password, no_input=no_input)

    print('Unzip path: ' + unzip_path)

# Generated at 2022-06-11 20:39:16.026681
# Unit test for function unzip
def test_unzip():
    # Arrange
    is_url = True
    clone_to_dir = './datastore'
    zip_uri = 'https://github.com/taniarascia/dotfiles/archive/master.zip'
    no_input = False

    # Act
    unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input)
    print(unzip_path)
    # Assert
    assert True

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-11 20:39:46.050593
# Unit test for function unzip
def test_unzip():
    import shutil
    import pytest

    clone_to_dir = tempfile.mkdtemp()
    project_path = os.path.join(clone_to_dir, 'cookiecutter-pe')
    zip_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '../../tests/test-data/cookiecutter-pe.zip'
    )
    produced_archive = unzip(zip_path, False, clone_to_dir, no_input=True)
    shutil.rmtree(clone_to_dir)
    assert os.path.exists(produced_archive)
    assert produced_archive.startswith('/tmp')
    assert produced_archive.endswith(project_path)

# Generated at 2022-06-11 20:39:54.910598
# Unit test for function unzip
def test_unzip():
    import shutil
    from tempfile import mkdtemp

    # Create a zip file
    tmp_dir = mkdtemp()
    base = os.path.join(tmp_dir, 'tmp')
    make_sure_path_exists(base)
    make_sure_path_exists(os.path.join(base, 'test'))
    make_sure_path_exists(os.path.join(base, 'test', 'test2'))
    with open(os.path.join(base, 'test', 'test2', 'test.txt'), 'w') as f:
        f.write('foo')

    # Create the zipfile archive
    import zipfile
    zf = zipfile.ZipFile(os.path.join(tmp_dir, 'tmp_zip'), 'w')

# Generated at 2022-06-11 20:39:57.707530
# Unit test for function unzip
def test_unzip():
    assert unzip("/C/Users/CGD/Desktop/KMProject/cookiecutters/cookiecutter-pypackage-minimal/cookiecutter.zip", False) != None

# Generated at 2022-06-11 20:40:06.986694
# Unit test for function unzip
def test_unzip():
    with tempfile.TemporaryDirectory() as temp_dir:
        with tempfile.TemporaryDirectory() as temp_parent:
            make_sure_path_exists(os.path.join(temp_parent, 'private_repo'))
            
            # Test case 1: unzip non-protected repo
            # Create non-protected test repo
            with tempfile.TemporaryDirectory() as temp_non_pro:
                with open(os.path.join(temp_non_pro, 'test.txt'), 'w') as f:
                    f.write('test')
                with ZipFile(os.path.join(temp_non_pro, 'non_protected_repo.zip'), 'w') as z:
                    z.write(os.path.join(temp_non_pro, 'test.txt'), 'test.txt')
            #

# Generated at 2022-06-11 20:40:07.920401
# Unit test for function unzip
def test_unzip():
    pass


# Generated at 2022-06-11 20:40:08.512347
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:40:09.748944
# Unit test for function unzip
def test_unzip():
    assert unzip('~/test/cookiecutter-test', False) is not None

# Generated at 2022-06-11 20:40:19.682292
# Unit test for function unzip
def test_unzip():
    """Test to make sure that unzip successfully unzips a repo
    """
    repo_zip_uri = 'https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/master'
    repo_zip_uri_file = 'https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/9c9b001888a35c04a8a2'
    local_zip_uri = 'tests/test-repo-tmpl/cookiecutter-pypackage-master.zip'
    repo_unzipped_path = unzip(repo_zip_uri, True)
    repo_file_unzipped_path = unzip(repo_zip_uri_file, True)

# Generated at 2022-06-11 20:40:29.433697
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile

    test_path = tempfile.mkdtemp()

    shutil.copy('tests/test-repo.zip', test_path)

    extracted_path = unzip(os.path.join(test_path, 'test-repo.zip'), False)
    assert os.path.exists(os.path.join(extracted_path, 'cookiecutter.json'))

    try:
        unzip(os.path.join(test_path, 'test-repo.zip'), False, password='test')
    except InvalidZipRepository:
        pass
    else:
        raise AssertionError('Unable to detect invalid password')

    shutil.rmtree(test_path)

# Generated at 2022-06-11 20:40:36.495015
# Unit test for function unzip
def test_unzip():
    """Validate that the unzip function properly unzips a test repo archive."""
    here = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(here, '..', 'tests', 'test-unzip')
    repo_archive = os.path.join(test_dir, 'test-repo.zip')
    unzip(repo_archive, False)

# Generated at 2022-06-11 20:41:13.848575
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:41:25.856008
# Unit test for function unzip
def test_unzip():
    import pytest 
    import os
    import shutil
    import tempfile
    import zipfile

    test_path = os.path.dirname(os.path.realpath(__file__))
    template_dir = os.path.join(test_path,"..", "tests", "test-data", "fake-repo-tmpl")
    template_zip = os.path.join(test_path, "fake-repo.zip")

    def make_zip(input_dir,output_file):
        """makes an archive of a given directory"""
        with zipfile.ZipFile(output_file, 'w') as myzip:
            for root, dirs, files in os.walk(input_dir):
                for file in files:
                    myzip.write(os.path.join(root, file))

    # create

# Generated at 2022-06-11 20:41:31.388858
# Unit test for function unzip
def test_unzip():
    """Test unzip function."""
    unzip_path = unzip(zip_uri="https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip",
                       is_url=True,
                       clone_to_dir='.',
                       no_input=False)
    assert os.path.exists(unzip_path)

# Generated at 2022-06-11 20:41:34.222464
# Unit test for function unzip
def test_unzip():
    r = unzip('badzip.zip', False, '.')
    assert r == None


# Generated at 2022-06-11 20:41:39.529213
# Unit test for function unzip
def test_unzip():
    """ Test whether unzip works in case of unprotected, and protected repositories """
    import doctest
    assert unzip(os.path.abspath('tests/test-unzip/protected-cookiecutter-repo.zip'), is_url=False)
    assert unzip(os.path.abspath('tests/test-unzip/cookiecutter-repo.zip'), is_url=False)


# Generated at 2022-06-11 20:41:44.422885
# Unit test for function unzip
def test_unzip():
    """Test unzip to make sure it returns the right thing.

    This is used if the user pushes a zipfile that contains an archive, but
    the first file in the archive is a file instead of a directory.
    """
    try:
        unzip('tests/files/invalid-repo.zip', False)
    except InvalidZipRepository as e:
        assert 'Zip repository tests/files/invalid-repo.zip is not a valid zip archive:' in e.args
    else:
        assert False, 'Zipfile should have raised exception!'

# Generated at 2022-06-11 20:41:44.991799
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:41:45.914010
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    pass

# Generated at 2022-06-11 20:41:52.543286
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    test_unzip = unzip(zip_uri, is_url=True, clone_to_dir='.', no_input=True)
    assert os.path.exists(test_unzip)
    assert test_unzip.endswith('.zip')

# Generated at 2022-06-11 20:42:02.754772
# Unit test for function unzip
def test_unzip():
    import shutil
    import zipfile

    test_loc = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test')
    # Build a test zipfile
    f = zipfile.ZipFile('test.zip', 'w', zipfile.ZIP_DEFLATED)
    f.writestr('foo/', '')
    f.writestr('foo/bar.txt', 'Hello, World')
    f.close()
    
    # Copy the zip file to the test repository, and clean up afterwards