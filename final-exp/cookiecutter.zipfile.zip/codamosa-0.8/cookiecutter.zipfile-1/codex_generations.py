

# Generated at 2022-06-11 20:34:01.747237
# Unit test for function unzip
def test_unzip():
    try:
        import zipfile
    except ImportError:
        # Skip test
        return

    # Create a test zipfile
    testFile = tempfile.NamedTemporaryFile(prefix='cookiecutterTest', suffix='.zip')
    testZip = zipfile.ZipFile(testFile, mode='w')

    # Arrange for a known directory structure and files
    testPath = tempfile.mkdtemp()
    os.mkdir(os.path.join(testPath, 'foo'))
    os.mkdir(os.path.join(testPath, 'foo', 'bar'))
    with open(os.path.join(testPath, 'foo', 'bar', 'content.txt'), 'w') as f:
        f.write("Hello world")

    testZip.write(testPath, arcname='root')

    test

# Generated at 2022-06-11 20:34:03.251608
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:34:07.465489
# Unit test for function unzip
def test_unzip():
    # the existing test is not sufficient
    # the test here is not complete
    # test_cookiecutter.py is already a heavy test
    # do not repeat the test here
    pass

# Generated at 2022-06-11 20:34:18.400213
# Unit test for function unzip
def test_unzip():
    # Create a test zip file
    import shutil
    import zipfile
    from cookiecutter.utils import rmtree

    temp_dir = tempfile.mkdtemp()
    zip_file = os.path.join(temp_dir, 'repo.zip')
    zf = zipfile.ZipFile(zip_file, mode='w', compression=zipfile.ZIP_DEFLATED)
    for name in ['foo/', 'foo/bar.txt', 'flup.txt']:
        zf.write(os.path.join(temp_dir, name), arcname=name)
    zf.close()

    clone_to_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 20:34:22.341264
# Unit test for function unzip
def test_unzip():
    # Verify that a zipfile can be extracted
    unzip = unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master',is_url=True)
    assert os.path.exists(unzip)
test_unzip()

# Generated at 2022-06-11 20:34:34.072638
# Unit test for function unzip

# Generated at 2022-06-11 20:34:38.463249
# Unit test for function unzip
def test_unzip():
    import shutil
    import zipfile

    with zipfile.ZipFile('../samples/testsample.zip', 'r') as zip_ref:
        zip_ref.extractall('examples/testsample')

    unzip('examples/testsample/testsample.zip', False, clone_to_dir='.', no_input=True)
    shutil.rmtree('examples/testsample')

# Generated at 2022-06-11 20:34:48.133926
# Unit test for function unzip
def test_unzip():
    os.remove('zip_example.zip')
    with open('zip_example.zip', 'wb') as f:
        f.write(ziptest)
    unzip('zip_example.zip', False)
    os.remove('zip_example.zip')


# Generated at 2022-06-11 20:34:51.737211
# Unit test for function unzip
def test_unzip():
    unzip_path = unzip('tests/test-unzip', is_url=False)
    content = os.listdir(unzip_path)
    if content == ['test.txt']:
        return True
    return False


# Generated at 2022-06-11 20:35:03.411513
# Unit test for function unzip
def test_unzip():
    import shutil

    tempdir = os.path.abspath('tmp')
    zipfile_url = 'https://codeload.github.com/django/django/zip/master'
    temp_path = os.path.join(tempdir, 'django.zip')

    r = requests.get(zipfile_url, stream=True)
    with open(temp_path, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:  # filter out keep-alive new chunks
                f.write(chunk)

    unzip_base = tempfile.mkdtemp()
    unzip_path = unzip(temp_path, False, clone_to_dir=unzip_base, no_input=True)
    contains_files = os.listdir

# Generated at 2022-06-11 20:35:23.469928
# Unit test for function unzip
def test_unzip():
    """Tests for the unzip function."""
    # download a zip file to local file
    url = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    r = requests.get(url, stream = True)
    with tempfile.NamedTemporaryFile() as f:
        for chunk in r.iter_content(chunk_size = 1024):
            f.write(chunk)
        f.flush()

        # archiving and unarchive files, compare file contents
        temp_dir = tempfile.mkdtemp()
        unzip_path = unzip(f.name, False, temp_dir, True)
        assert os.path.exists(unzip_path)
        dir_contents = set(os.listdir(unzip_path))
        orig_

# Generated at 2022-06-11 20:35:24.363725
# Unit test for function unzip
def test_unzip():
    # TODO
    pass


# Generated at 2022-06-11 20:35:27.629863
# Unit test for function unzip
def test_unzip():
    # PROBLEM: There is no code for testing the unit test yet.
    assert(unzip != "")
    return


# Generated at 2022-06-11 20:35:28.466739
# Unit test for function unzip
def test_unzip():
    # TODO: Implement this unit test
    pass

# Generated at 2022-06-11 20:35:38.841414
# Unit test for function unzip
def test_unzip():
    import shutil
    import requests
    from zipfile import ZipFile
    from cookiecutter.exceptions import InvalidZipRepository

    # build a zip file from a local directory
    tmp_dir = tempfile.mkdtemp()
    zip_filename = os.path.join(tmp_dir, 'test.zip')
    with ZipFile(zip_filename, 'w') as zip:
        zip.write(os.path.join("tests","files","test-repo-tmpl", "{{cookiecutter.repo_name}}"),'{{cookiecutter.repo_name}}')
        
    # download a zip file
    r = requests.get("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", stream=True)

    # test unzip local file
    unzip_path

# Generated at 2022-06-11 20:35:45.211044
# Unit test for function unzip
def test_unzip():
    from os import getcwd
    import tempfile
    from zipfile import ZipFile
    from contextlib import contextmanager

    @contextmanager
    def make_temp_directory():
        dir_name = tempfile.mkdtemp()
        try:
            yield dir_name
        finally:
            import shutil
            shutil.rmtree(dir_name)

    @contextmanager
    def make_zip_archive(path):
        with ZipFile(path, 'w') as zip_file:
            yield zip_file

    with make_temp_directory() as unzip_dir:
        with make_temp_directory() as repository_dir:
            repository_path = os.path.join(repository_dir, 'file.txt')

# Generated at 2022-06-11 20:35:54.493783
# Unit test for function unzip
def test_unzip():
    """Test the unzip function."""
    dir_path = os.path.dirname(os.path.realpath(__file__))
    zip_path = os.path.join(dir_path, 'zip-repos', 'cookiecutter-pypackage')
    unzip_path = unzip(zip_path, False)

    assert os.path.exists(unzip_path)
    assert os.path.exists(os.path.join(unzip_path, 'tests'))
    assert os.path.exists(os.path.join(unzip_path, 'setup.py'))

    os.rmdir(unzip_path)



# Generated at 2022-06-11 20:35:55.052047
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:36:08.980376
# Unit test for function unzip
def test_unzip():
    import zipfile
    import shutil
    pwd = os.getcwd()
    clone_to_dir = tempfile.mkdtemp()
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    zip_file = 'cookiecutter-master.zip'
    f = open(zip_file, 'w')
    f.close()
    filename = 'cookiecutter-master/README.rst'
    zipf = zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED)
    zipf.write(filename)
    zipf.close()
    unzip_path = unzip(zip_file, False, clone_to_dir)

# Generated at 2022-06-11 20:36:19.249934
# Unit test for function unzip
def test_unzip():
    import pytest
    import requests
    import six
    import shutil
    import tempfile
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.utils import rmtree
    from tests.sample_vcs import SampleBitbucket

    clone_to_dir = tempfile.mkdtemp()

    # Create a sample Bitbucket repository
    sb = SampleBitbucket()
    sb.run()

    # First, pull down the repository files
    sb.add_file('README.md')
    sb.commit('Initial commit')
    sb.add_folder('tests')
    sb.add_file('tests/foo.py')
    sb.commit('Add tests')

    # Create the zip archive


# Generated at 2022-06-11 20:36:31.289837
# Unit test for function unzip
def test_unzip():
    import tempfile
    import shutil
    import zipfile
    import os
    import random
    import string
    import requests

    # Create a zipfile
    src_dir = tempfile.mkdtemp()
    zip_filename = "/tmp/{}.zip".format(''.join(random.choice(string.ascii_letters) for i in range(10)))
    test_filename = os.path.join(src_dir, "test_file.txt")
    with open(test_filename, 'w') as f:
        f.write("Test file")

    with zipfile.ZipFile(zip_filename, 'w') as zip:
        zip.write(test_filename)

    # Test unzip from file
    repo_dir = tempfile.mkdtemp()
    unzip(zip_filename, False, repo_dir)

# Generated at 2022-06-11 20:36:41.102828
# Unit test for function unzip
def test_unzip():
    # When it is a local file
    zip_uri = 'tests/test-repo-tmpl/'
    clone_to_dir = 'tests/test-repo-tmpl/'
    unzip_path = unzip(zip_uri, False, clone_to_dir)
    assert unzip_path.endswith(clone_to_dir)

    # When it is a remote file, but it does not exist
    zip_uri = 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    clone_to_dir = 'tests/test-repo-tmpl/'
    unzip_path = unzip(zip_uri, True, clone_to_dir)
    assert not unzip_path.endswith(clone_to_dir)

    # When it

# Generated at 2022-06-11 20:36:41.655039
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:36:45.522306
# Unit test for function unzip
def test_unzip():  
    zip_file = unzip('/path/to/file/cookiecutter-django.zip', False, '.', True, 'None')
    assert os.path.exists(zip_file)
    assert os.path.getsize(zip_file) > 0

# Generated at 2022-06-11 20:36:46.099115
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:36:46.987797
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:36:55.842177
# Unit test for function unzip
def test_unzip():
    import shutil
    import zipfile
    from click.testing import CliRunner

    temp_dir = tempfile.mkdtemp()
    template_name = 'cookiecutter_template_for_unzip'
    test_template_path = os.path.join(temp_dir, template_name)

    # Build the template
    zip_path = os.path.join(temp_dir, 'zip_repo_for_unzip.zip')
    os.mkdir(test_template_path)
    with open(os.path.join(test_template_path, 'test_file'), 'w') as f:
        f.write('test')
    with zipfile.ZipFile(zip_path, 'w') as f:
        f.write(test_template_path, template_name)

    # Test the function
   

# Generated at 2022-06-11 20:37:00.528368
# Unit test for function unzip
def test_unzip():
    unzip(
        zip_uri = 'https://github.com/DSE-Cookiecutter/cookiecutter-data-science/archive/master.zip',
        is_url = 1,
        clone_to_dir = './'
    )

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-11 20:37:09.058951
# Unit test for function unzip
def test_unzip():
    test_zip_uri = os.path.expanduser(
        '/home/somnath/PycharmProjects/cookiecutter/tests/test-data/test-repo.zip'
    )
    is_url = False
    clone_to_dir = '/home/somnath/PycharmProjects/cookiecutter/tests/test-data/'
    ret = unzip(test_zip_uri, is_url, clone_to_dir)
    assert ret.split('/')[-1] == 'test-repo'
    shutil.rmtree(ret)

# Generated at 2022-06-11 20:37:21.212057
# Unit test for function unzip
def test_unzip():
    import shutil
    from zipfile import ZipFile
    from cookiecutter.utils import rmtree
    from cookiecutter import utils as cookiecutter_utils

    # Build a dummy zip file for testing
    temp_dir = tempfile.mkdtemp()
    dummy_source = os.path.join(temp_dir, 'dummy_zip_source')
    cookiecutter_utils.make_sure_path_exists(dummy_source)
    root_dir = os.path.join(temp_dir, 'dummy_zip_source', 'demo')
    cookiecutter_utils.make_sure_path_exists(root_dir)

# Generated at 2022-06-11 20:37:37.616230
# Unit test for function unzip
def test_unzip():
    """
    Test unzip function unit
    """
    import shutil
    import sys
    import zipfile
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from .test_find import test_find_repo

    # Make a basic cookiecutter template
    template = os.path.join(DEFAULT_CONFIG['cookiecutters_dir'], 'cookiecutter-pypackage')
    if os.path.exists(template):
        shutil.rmtree(template)
    cookiecutter('tests/test-cookiecutter-pypackage')

    # Make the repository
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:37:45.725033
# Unit test for function unzip
def test_unzip():
    try:
        # Test normal zip file
        unzip(
            'https://github.com/yuvipanda/gameoflife/archive/master.zip',
            is_url=True
        )

        # Test password protected zip file
        unzip(
            'https://github.com/yuvipanda/gameoflife/archive/master.zip',
            is_url=True,
            password='cookiecutter'
        )
    finally:
        pass

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-11 20:37:50.617229
# Unit test for function unzip
def test_unzip():
    test_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    test_clone_to_dir = '.'
    unzip(test_url, is_url=True, clone_to_dir=test_clone_to_dir)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-11 20:38:01.881333
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    from zipfile import ZipFile

    base_dir = tempfile.mkdtemp()
    test_dir = tempfile.mkdtemp()
    test_path = os.path.join(test_dir, 'testing.zip')

    z = ZipFile(test_path, 'w')
    z.writestr('repo/test.txt', 'This is a test')
    z.close()

    unzip_path = unzip(test_path, False, base_dir)

    try:
        assert os.path.exists(unzip_path)
        assert os.path.exists(os.path.join(unzip_path, 'test.txt'))
    finally:
        if os.path.exists(test_dir):
            shutil.r

# Generated at 2022-06-11 20:38:10.610962
# Unit test for function unzip
def test_unzip():
    """
    Test we can actually unzip files
    """
    import shutil
    import zipfile
    from shutil import rmtree
    from pathlib import Path
    from cookiecutter.utils import make_sure_path_exists

    # Create a test zip file, with one file
    zip_file_name = 'test_file.txt'
    zip_file_content = 'This is just some text, for testing'
    zfile_path = Path('/tmp/zipfile.zip')
    if zfile_path.exists():
        zfile_path.unlink()

    with ZipFile(zfile_path, 'w') as zfile:
        zfile.writestr(zip_file_name, zip_file_content)

    # unzip the zip file

# Generated at 2022-06-11 20:38:11.209206
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:38:21.723356
# Unit test for function unzip
def test_unzip():
    import shutil

# Generated at 2022-06-11 20:38:32.245800
# Unit test for function unzip
def test_unzip():
    """Unpack a password protected zip file."""
    import shutil
    import zipfile
    try:
        from unittest import mock  # py3
    except ImportError:
        import mock  # py2

    # Setup the mocks
    password = 'password'
    url = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    redirect = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    zip_path = 'cookiecutter-master.zip'
    unzip_path = 'cookiecutter-master'

# Generated at 2022-06-11 20:38:42.992192
# Unit test for function unzip
def test_unzip():
    test_zip_url = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"

    def unzip_test_repo_from_url(zip_uri):
        repo_dir = os.path.expanduser('~/.cookiecutters/')
        make_sure_path_exists(repo_dir)

        ret = unzip(zip_uri, True, repo_dir)
        # Assert that all files are extracted in repo_dir/cookiecutter-pypackage-*
        assert os.path.exists(ret)
        reponame = "cookiecutter-pypackage-master"
        assert os.path.exists(os.path.join(ret, 'README.rst'))

# Generated at 2022-06-11 20:38:46.899716
# Unit test for function unzip
def test_unzip():
    url = "https://github.com/audreyr/cookiecutter-pypackage/zipball/master"
    result = unzip(url, is_url=True, clone_to_dir='.', no_input=True)
    assert result is not None

# Generated at 2022-06-11 20:39:37.077014
# Unit test for function unzip
def test_unzip():
    # Set up
    zf_name = 'test.zip'
    zf_path = os.path.join(os.path.dirname(__file__), zf_name)
    zip_uri = 'local'
    test_dir = 'local_dir'
    no_input = False
    password = '123456'

    # Test unzip file ok
    unzip_path = unzip(zip_uri, zip_uri, test_dir, no_input, password, zf_path)
    assert os.path.exists(unzip_path)
    files = os.listdir(unzip_path)
    assert len(files) == 1

    # Test unzip file bad

# Generated at 2022-06-11 20:39:41.523148
# Unit test for function unzip
def test_unzip():
    import pytest
    from zipfile import BadZipFile
    from cookiecutter.exceptions import InvalidZipRepository
    from cookiecutter.utils import make_sure_path_exists, prompt_and_delete
    zip_path = 'tests/test-repos/example-repo-master.zip'
    clone_to_dir = '.'
    make_sure_path_exists(clone_to_dir)
    identifier = zip_path.rsplit('/', 1)[1]
    zip_path = os.path.join(clone_to_dir, identifier)
    unzip_base = tempfile.mkdtemp()

# Generated at 2022-06-11 20:39:42.000263
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:39:47.534106
# Unit test for function unzip
def test_unzip():
    import tempfile, shutil, os
    try:
        tempdir = tempfile.mkdtemp()
        test_url = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
        unzip_path = unzip(test_url, is_url=True, clone_to_dir=tempdir)
        assert os.path.exists(unzip_path)
        assert os.path.basename(unzip_path) == "cookiecutter-pypackage-master"
        shutil.rmtree(unzip_path)
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-11 20:39:48.696506
# Unit test for function unzip
def test_unzip():
    # TODO
    pass

# Generated at 2022-06-11 20:39:55.433666
# Unit test for function unzip
def test_unzip():
    test_zip_file = '/tmp/test_zip.zip'
    test_zip_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    test_dir = '/tmp/'

    if os.path.exists(test_zip_file):
        os.remove(test_zip_file)

    tmp_dir = unzip(test_zip_url,True,test_dir,True)
    assert os.path.isdir(tmp_dir)

    #remove directory
    import shutil
    shutil.rmtree(tmp_dir)
    os.remove(test_zip_file)

# Generated at 2022-06-11 20:39:56.075163
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:40:03.686211
# Unit test for function unzip
def test_unzip():
    assert unzip(
        'https://github.com/audreyr/cookiecutter-pypackage/zipball/master',
        True,
    )
    assert unzip(
        'https://github.com/audreyr/cookiecutter-pypackage/zipball/master',
        True,
        'tests/files/repos/',
    )
    assert unzip(
        'tests/files/repos/cookiecutter-pypackage.zip',
        False,
        'tests/files/repos/',
    )

# Generated at 2022-06-11 20:40:04.861839
# Unit test for function unzip

# Generated at 2022-06-11 20:40:14.480633
# Unit test for function unzip
def test_unzip():
    from os.path import join
    from shutil import copyfile
    from random import randrange
    from zipfile import ZipFile

    # Generate a temp file with random content
    test_file = open('test_file.txt', 'w+')
    test_file.write(str(randrange(0, 1000000)))
    test_file.seek(0)

    # Get the content of the temp file
    test_file_content = test_file.read()

    # Generate a random temp password
    test_file_password = str(randrange(0, 1000000))

    # Test with a file that is not a zip file
    unzip_path = unzip(test_file.name, False)
    assert(False)

    # Test with a file that exists but is not a valid zip file
    test_file.close()

# Generated at 2022-06-11 20:42:16.103964
# Unit test for function unzip
def test_unzip():
    """Unit test to check function unzip in utils.py"""
    # Check if the function raises appropriate exceptions
    try:
        unzip('abc/123/xyz.zip', True, '.', True, 'password')
    except TypeError as e:
        pass
    else:
        raise

# Generated at 2022-06-11 20:42:22.686727
# Unit test for function unzip
def test_unzip():
  import os
  import tempfile
  tmp_dir = tempfile.mkdtemp()
  print(tmp_dir)
  zip_path = os.path.join(tmp_dir, 'test.zip')
  file = open(zip_path, 'w')
  file.write('zipfile')
  file.close()
  unzip_path = unzip(zip_path, is_url=False, clone_to_dir='.', no_input=True, password=None)
  print(unzip_path)

# Generated at 2022-06-11 20:42:23.861108
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:42:26.906136
# Unit test for function unzip
def test_unzip():
    unzip_path = unzip('https://github.com/neo4j/neo4j/archive/2.0.1.zip', True, clone_to_dir='.')
    assert os.path.exists(unzip_path)

# Generated at 2022-06-11 20:42:36.991372
# Unit test for function unzip
def test_unzip():
    repo_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
    is_url=True)
    assert os.path.isdir(repo_path)
    assert os.listdir(repo_path)

    repo_path = unzip('~/zipfile.zip', is_url=False)
    assert os.path.isdir(repo_path)
    assert os.listdir(repo_path)

    repo_path = unzip('/zipfile.zip', is_url=False)
    assert os.path.isdir(repo_path)
    assert os.listdir(repo_path)

# Generated at 2022-06-11 20:42:47.171269
# Unit test for function unzip
def test_unzip():
    from .loaders import extract_repo_info

    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/1.7'
    is_url = True
    clone_to_dir = os.path.join(os.path.dirname(__file__), 'test-repos')
    unzip_path = unzip(
        zip_uri=zip_uri,
        is_url=is_url,
        clone_to_dir=clone_to_dir,
        no_input=True
    )
    assert os.path.exists(unzip_path)
    repo_dir = os.path.dirname(unzip_path)
    assert os.path.exists(repo_dir)

# Generated at 2022-06-11 20:42:49.704110
# Unit test for function unzip
def test_unzip():
    assert (unzip('http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',True)) != ''
test_unzip()

# Generated at 2022-06-11 20:42:57.094071
# Unit test for function unzip
def test_unzip():
        zip_uri = "tests/test-repo.zip"
        is_url = False
        clone_to_dir = 'cookiecutter-repo'
        no_input = False
        password = None
        unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
        assert os.path.isdir(unzip_path)
        assert os.path.isfile(unzip_path + '/README.md')
        assert os.path.isfile(unzip_path + '/hooks/post_gen_project.py')

# Generated at 2022-06-11 20:42:58.810691
# Unit test for function unzip
def test_unzip():
    assert 'zip_repo' in os.listdir(unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
                                          True))

# Generated at 2022-06-11 20:43:06.854070
# Unit test for function unzip
def test_unzip():
    # Template: https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip
    zip_uri = 'https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/master'
    is_url = True
    clone_to_dir = '.'
    no_input = False
    unzip(zip_uri, is_url, clone_to_dir, no_input)