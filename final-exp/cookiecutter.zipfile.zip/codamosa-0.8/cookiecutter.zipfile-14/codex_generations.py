

# Generated at 2022-06-11 20:34:01.047376
# Unit test for function unzip
def test_unzip():
    from cookiecutter.main import cookiecutter
    if os.path.exists("test_unzip"):
        import shutil
        shutil.rmtree("test_unzip")
    os.mkdir("test_unzip")
    try:
        unzip("tests/test-repo-pre/{{cookiecutter.repo_name}}.zip", False, "test_unzip")
        cookiecutter("test_unzip/cookiecutter-pypackage", no_input=True)
    finally:
        import shutil
        shutil.rmtree("test_unzip")

# Generated at 2022-06-11 20:34:14.408958
# Unit test for function unzip
def test_unzip():
    zip_url = os.path.join(os.path.dirname(__file__), 'files', 'basic.zip')
    clone_to_dir = os.path.dirname(__file__)
    unzip_dir = unzip(zip_url, is_url=False, clone_to_dir=clone_to_dir, no_input=True)
    
    assert os.path.exists(unzip_dir)
    assert os.path.isdir(unzip_dir)
    assert os.path.exists(os.path.join(unzip_dir, 'file1.txt'))
    assert os.path.exists(os.path.join(unzip_dir, 'subdir1'))

# Generated at 2022-06-11 20:34:22.069629
# Unit test for function unzip
def test_unzip():
    import json
    import shutil

    from zipfile import ZipFile
    from tests.test_utils import (
        clean_system_paths,
        make_empty_test_dict,
        patch_find_project_templates,
    )

    # remove two created templates
    print('test_unzip')
    project_dir = 'tests/test-unzip'
    project_dir_tmp = project_dir + '/tmp'
    project_dir_test = project_dir + '/test'
    shutil.rmtree(project_dir, True)
    shutil.rmtree(project_dir_tmp, True)
    project_dir_zip = os.path.abspath(project_dir + '/test-unzip.zip')

# Generated at 2022-06-11 20:34:30.816646
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    import zipfile

    cwd = os.getcwd()
    os.chdir(tempfile.gettempdir())

    # Create a temporary test directory, and
    # add a zipfile of that directory to it.
    test_root_temp = tempfile.mkdtemp(prefix='test-unzip-')

    test_root = os.path.join(test_root_temp, 'testroot')
    os.makedirs(test_root)

    temp_zip = os.path.join(test_root_temp, 'testroot.zip')

    with zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(test_root)

    # Now try to unzip the test file

# Generated at 2022-06-11 20:34:38.730637
# Unit test for function unzip
def test_unzip():
    import os
    import shutil

    from cookiecutter.utils import generate_tests_for_unzip
    from cookiecutter.utils import rmtree

    # Create the test directory
    temp_dir = tempfile.mkdtemp()
    # Get the path of the testdata directory, included in the source
    # distribution, and create a full path to the zipfile
    testdata_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'testdata', 'fakezipfile'
    )
    testdata_file = os.path.join(testdata_path, 'fakezipfile.zip')
    # Get the path of the testdata directory, included in the source
    # distribution, and create a full path to the zipfile with a password
    testdata_path_protected

# Generated at 2022-06-11 20:34:47.230704
# Unit test for function unzip
def test_unzip():
    """Test unzip function"""
    # Test url unzip
    url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(url, is_url=True, no_input=True)
    assert unzip_path.startswith('/tmp')
    assert os.path.exists(os.path.join(unzip_path, 'README.rst'))

    # Test file unzip
    try:
        unzip_path = unzip(url, is_url=False, no_input=True)
        assert False
    except RuntimeError:
        assert True

# Generated at 2022-06-11 20:34:56.312213
# Unit test for function unzip
def test_unzip():
    import pytest
    from cookiecutter.utils import ensure_dir
    from cookiecutter.utils import rmtree

    clone_to_dir = tempfile.mkdtemp()

    unzip_path = os.path.join(clone_to_dir,"jack.zip")
    open(unzip_path,'w').close()

    with pytest.raises(InvalidZipRepository):
        unzip(unzip_path,False,clone_to_dir)

    rmtree(clone_to_dir)
    clone_to_dir = tempfile.mkdtemp()
    unzip_path = os.path.join(clone_to_dir,"jack.zip")

    with pytest.raises(InvalidZipRepository):
        unzip(unzip_path,False,clone_to_dir)


# Generated at 2022-06-11 20:35:07.485800
# Unit test for function unzip
def test_unzip():
    import shutil
    import requests
    from zipfile import ZipFile

    def check_zip_file():
        file_name = 'test.zip'
        url = "https://github.com/audreyr/cookiecutter/archive/master.zip"

        r = requests.get(url, stream=True)
        with open(file_name, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024):
                if chunk:  # filter out keep-alive new chunks
                    f.write(chunk)

        with ZipFile(file_name) as f:
            with f.open(f.namelist()[0]) as first_file:
                return first_file.readline()

    # Check the zip file at url
    # The first line of test.zip is "PK\003

# Generated at 2022-06-11 20:35:12.280799
# Unit test for function unzip
def test_unzip():
    '''
    Unit testing for function unzip
    '''
    import os
    import shutil
    import tempfile
    import requests
    from zipfile import ZipFile
    from cookiecutter.config import get_user_config
    from cookiecutter.exceptions import InvalidZipRepository
    from cookiecutter.utils import make_sure_path_exists
    from cookiecutter.utils import prompt_and_delete

    # Ensure that clone_to_dir exists
    CONFIG_FILE = get_user_config()
    clone_to_dir = os.path.expanduser(CONFIG_FILE['cookiecutters_dir'])
    make_sure_path_exists(clone_to_dir)

    # Test URL

# Generated at 2022-06-11 20:35:24.237710
# Unit test for function unzip
def test_unzip():
    # First, create a temporary zip file for testing
    import os
    import zipfile

    zip_file = tempfile.NamedTemporaryFile(
        suffix='.zip', delete=False, dir='tests/fake-repo-tmpl'
    )
    zip_file.close()

    zip_path = zip_file.name

    zip_file = zipfile.ZipFile(zip_path, 'w')
    zip_file.write('tests/fake-repo-tmpl/fake_repo/', 'fake_repo/')
    zip_file.write('tests/fake-repo-tmpl/fake_repo/fake_repo/', 'fake_repo/fake_repo/')

# Generated at 2022-06-11 20:35:38.528880
# Unit test for function unzip
def test_unzip():
    """
    Unit test for the function unzip
    """
    # Create a temp directory to unzip the test into
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()
    shutil.copy('tests/test-repo.zip', os.path.join(tempdir, 'test-repo.zip'))
    os.chdir(tempdir)
    unzip_path = unzip("test-repo.zip", False)
    assert os.path.exists(unzip_path)
    # Cleanup
    shutil.rmtree(tempdir)

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-11 20:35:45.126239
# Unit test for function unzip
def test_unzip():
    """
    Unit-test function unzip
    :return:
    """
    import shutil
    import time
    import unittest

    def _download_files():
        """
        Downloads the required test files
        :return:
        """
        print('Downloading test files')

        url = 'https://api.github.com/repos/cookiecutter/cookiecutter/zipball/d8bbf612b68e97aa1d9e4f4ca7547fb0eeb6a3d3'
        tmp_dir = tempfile.mkdtemp()
        file_path = os.path.join(tmp_dir, 'cookiecutter_test.zip')
        r = requests.get(url, stream=True)

# Generated at 2022-06-11 20:35:55.666419
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    repo_path=os.path.join(os.getcwd(), "tests/dummy-zip-repo")
    local_path=os.path.join(os.getcwd(), "tests/local-zip.zip")
    cachedir_path=os.path.join(os.getcwd(), "tests/mycachedir")
    unzip_path=unzip(repo_path, False, cachedir_path)
    unzip_path1=unzip(repo_path, False, cachedir_path)
    unzip_path2=unzip(local_path, True, cachedir_path)

# Generated at 2022-06-11 20:36:09.409428
# Unit test for function unzip
def test_unzip():
    """Test unzip function"""
    import pytest
    from cookiecutter.utils import rmtree
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter import main

    # Create a temporary directory
    base_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 20:36:11.601663
# Unit test for function unzip
def test_unzip():
  assert unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", is_url=True)

# Generated at 2022-06-11 20:36:12.244128
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:36:12.788819
# Unit test for function unzip
def test_unzip():
    return

# Generated at 2022-06-11 20:36:13.347240
# Unit test for function unzip
def test_unzip():
    assert True is True

# Generated at 2022-06-11 20:36:14.725058
# Unit test for function unzip
def test_unzip():
    assert unzip('./tests/test-repo-tmpl/', False)

# Generated at 2022-06-11 20:36:15.578918
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-11 20:36:28.212472
# Unit test for function unzip
def test_unzip():
    """Test the unzip function."""
    import shutil

    repo = 'https://github.com/cookiecutter/cookiecutter-simple/archive/master.zip'
    clone_to_dir = 'tests/test-cloned-repos'
    dir = unzip(repo, True, clone_to_dir)

    assert os.path.exists(dir)
    assert os.path.exists(os.path.join(dir, 'setup.py'))
    assert os.path.exists(os.path.join(dir, 'LICENSE'))
    assert os.path.exists(os.path.join(dir, 'README.md'))

    shutil.rmtree(dir, ignore_errors=True)


# Generated at 2022-06-11 20:36:36.712261
# Unit test for function unzip
def test_unzip():
    # Ensure that clone_to_dir exists
    clone_to_dir = "./"
    make_sure_path_exists(clone_to_dir)

    zip_path = 'https://github.com/xuha0/cookiecutter-java-maven/archive/master.zip'
    unzip_path = unzip(zip_path, True, clone_to_dir)

    # Ensure that the download directory exists
    assert os.path.exists(unzip_path)

    # Cleanup
    os.remove('./master.zip')
    os.rmdir(unzip_path)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-11 20:36:46.941889
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import filecmp
    import logging
    import tempfile
    from zipfile import ZipFile
    import shutil
    from tests.test_utils import TEST_USER_CONFIG_YAML

    logger = logging.getLogger(__name__)

    def create_zip(zip_path, base_repo, repo_names):
        with ZipFile(zip_path, 'w') as zip:
            for repo_name in repo_names:
                file_path = os.path.join(base_repo, repo_name)
                zip.write(file_path, repo_name)


# Generated at 2022-06-11 20:36:55.843421
# Unit test for function unzip
def test_unzip():
    """Test utility function unzip."""
    import shutil
    import six

    if six.PY2:
        import uuid
        from mock import patch

        from cookiecutter import __version__
        from cookiecutter import generate

        password = uuid.uuid4().hex
        shutil.rmtree('tests/fake-repo-pre/', ignore_errors=True)

        # Mock the user_config
        def mock_config_data(**kwargs):
            return {'cookiecutters_dir': "tests/fake-repo-pre/"}

        # Mock the user_config
        def mock_config_data_fail(**kwargs):
            return None

        # Mock the return of the user_config
        def mock_config(**kwargs):
            return mock_config_data_fail


# Generated at 2022-06-11 20:37:04.463160
# Unit test for function unzip
def test_unzip():
    unzip(zip_uri='https://github.com/audreyr/cookiecutter-pypackage.git', is_url=True, clone_to_dir='.', no_input=False, password=None)
    unzip(zip_uri='https://github.com/audreyr/cookiecutter-pypackage/archive/0.1.2.zip', is_url=True, clone_to_dir='.', no_input=False, password=None)
    unzip(zip_uri='../cookiecutter-pypackage.git', is_url=False, clone_to_dir='.', no_input=False, password=None)            

# Generated at 2022-06-11 20:37:12.617222
# Unit test for function unzip
def test_unzip():
    os.chdir(os.path.join(os.path.dirname(__file__), '..'))
    temp_path = os.path.abspath(os.path.join('tests', 'fake-repo-tmpl1.zip'))
    unzip('fake-repo-tmpl1.zip', False, os.path.join('tests', 'fake-repo'), no_input=True)

    temp_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True, '.', no_input=True)
    assert os.path.exists(temp_path)

# Generated at 2022-06-11 20:37:13.538172
# Unit test for function unzip
def test_unzip():
    assert unzip('a', 'b') == None

# Generated at 2022-06-11 20:37:15.636074
# Unit test for function unzip
def test_unzip():
    """Test unzipping a repository."""
    # TODO: Create a test zip repository, and use it for testing
    pass

# Generated at 2022-06-11 20:37:22.404890
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    path = unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master',
                 True)
    expected_path = os.path.join(
        os.path.abspath(os.path.curdir),
        'audreyr-cookiecutter-pypackage-1718c09'
    )
    assert path == expected_path

# Generated at 2022-06-11 20:37:33.797856
# Unit test for function unzip
def test_unzip():
    import shutil, sys
    # Create a test folder
    test_folder = 'tests/test_unzipping_dir/'
    try:
        os.makedirs(test_folder)
    except OSError as e:
        # Handle the exception if the test folder already exists
        pass
    # Find out current dir
    curr_dir = os.getcwd()
    # Set the current working dir to the tests folder
    os.chdir(test_folder)
    # Test the function unzip with a zip file
    res = unzip('../test_unzipping.zip', is_url=False)
    assert os.path.dirname(res) == test_folder
    # Test the function unzip with a zip repository

# Generated at 2022-06-11 20:38:05.412013
# Unit test for function unzip
def test_unzip():
    import shutil
    # Given
    clone_to_dir = '.'
    is_url = False
    zip_uri = 'tests/test-repo-tmpl/cookiecutter-test-repo.zip'
    zip_repo_name = 'cookiecutter-test-repo'

    # When
    unzip_path = unzip(
        zip_uri, is_url, clone_to_dir=clone_to_dir
    )

    # Then
    assert os.path.exists(unzip_path)
    assert os.path.isdir(unzip_path)

    shutil.rmtree(unzip_path)

# Generated at 2022-06-11 20:38:14.940976
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    import os, shutil

    # Obtain the current working directory
    cwd = os.getcwd()

    # The zip file is in the test directory
    zip_uri = cwd + "/test/" + 'mycookie' + ".zip"

    # The test directory
    clone_to_dir = cwd + "/test/test_unzip"
    unzip_path = unzip(zip_uri, is_url=False, clone_to_dir=clone_to_dir, no_input=True)

    # Remove the directory test_unzip
    shutil.rmtree(clone_to_dir)

    # Make a test if the the unzip_path directory is the same as the working directory
    assert(unzip_path == cwd + "/test/mycookie")

# Generated at 2022-06-11 20:38:26.254647
# Unit test for function unzip
def test_unzip():
    import pytest
    from cookiecutter.utils.tests.test_unzip import unzip_path
    from tempfile import TemporaryDirectory
    import shutil
    from os.path import join
    from cookiecutter.utils import make_sure_path_exists
    from requests.exceptions import MissingSchema, ConnectionError
    from urllib.error import URLError

    # Test incorrect url
    with pytest.raises(MissingSchema):
        unzip('/foo/bar', is_url=True)

    with pytest.raises(URLError):
        unzip('http://my_domain/foo/bar', is_url=True)

    with pytest.raises(ConnectionError):
        unzip('http://github.com/test/test', is_url=True)

    # Test incorrect type


# Generated at 2022-06-11 20:38:29.617709
# Unit test for function unzip
def test_unzip():
    import requests
    
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = None
    unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    
    assert os.path.isfile(unzip_path) == True
test_unzip()

# Generated at 2022-06-11 20:38:35.313322
# Unit test for function unzip
def test_unzip():
    # This test is slow because it makes a call to the web
    # import sys
    # sys.exit(0)
    assert os.path.exists(unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True))
    assert os.path.exists(unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True))
    assert os.path.exists(unzip('test_templates/invalid_repo_1', False))

# Generated at 2022-06-11 20:38:45.744070
# Unit test for function unzip
def test_unzip():
    # Get path of test zip file
    from . import load_test_zip
    from .utils import rm_empty_dir

    # Temporary directory to clone zip file into
    clone_to_dir = tempfile.mkdtemp()

    # Unzip test file
    unzip_path = unzip(load_test_zip(), is_url=False, clone_to_dir=clone_to_dir)

    # Assert that the unzipped directory is as expected
    assert os.path.exists(unzip_path)
    assert len([f for f in os.listdir(unzip_path) if os.path.isfile(f)]) > 0

    # Clean up temporary directory
    rm_empty_dir(clone_to_dir)

# Generated at 2022-06-11 20:38:51.514857
# Unit test for function unzip
def test_unzip():
    """Test the unzip function with different conditions"""
    def is_valid_zip_file(zip_file):
        """Check if the zip file is valid"""
        try:
            with ZipFile(zip_file, 'r') as zip_ref:
                zip_ref.namelist()
        except BadZipFile:
            return False
        else:
            return True

    # First we test with a valid zipfile
    valid_zipfile_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(valid_zipfile_url, is_url=True)
    assert is_valid_zip_file(unzip_path) is True

    # We test again with a local file instead of a URL

# Generated at 2022-06-11 20:39:02.773550
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile
    import sys

    from cookiecutter.main import cookiecutter

    # Test for a valid zip archive
    sys.argv = ['cookiecutter', 'tests/resources/fake-repo-tmpl']
    repo_path = cookiecutter()

    assert os.path.exists(repo_path)

    shutil.rmtree(repo_path)

    # Test for an empty zip archive
    sys.argv = ['cookiecutter', 'tests/resources/fake-repo-empty-tmpl']

    try:
        repo_path = cookiecutter()
    except InvalidZipRepository:
        assert True

    # Test for a zip file with no top-level directory

# Generated at 2022-06-11 20:39:13.956353
# Unit test for function unzip
def test_unzip():
    import platform
    import shutil
    import tempfile
    import zipfile
    import cookiecutter

    def is_pwd_protected(zip_uri, is_url):
        """Check if zip file is password protected"""

        if is_url:
            identifier = zip_uri.rsplit('/', 1)[1]
            zip_path = os.path.join(clone_to_dir, identifier)
        else:
            zip_path = os.path.abspath(zip_uri)

        # Now unpack the repository. The zipfile will be unpacked
        # into a temporary directory

# Generated at 2022-06-11 20:39:24.984476
# Unit test for function unzip
def test_unzip():
    import requests_mock
    import shutil
    import tempfile
    import zipfile

    test_dir = tempfile.mkdtemp()
    test_filename = 'example-repo.zip'
    test_filepath = os.path.join(test_dir, test_filename)
    test_password = b'password'

    with zipfile.ZipFile(test_filepath, 'w') as test_zipfile:
        test_zipfile.writestr('example/repo/README.rst', 'example readme')
        test_zipfile.setpassword(test_password)
        test_zipfile.writestr('example/repo/template.rst', 'example template')

    # Test an empty zip file

# Generated at 2022-06-11 20:40:16.556369
# Unit test for function unzip
def test_unzip():
    """Test unzip function"""
    # Import here to avoid issues with importing from submodules
    # in the main module.
    import pytest
    is_url = True
    dir = ''
    no_input = False

    # Check for invalid zip file
    with pytest.raises(InvalidZipRepository):
        unzip('https://github.com/not-a-repo', is_url, dir, no_input)

    # Checks for valid zip file
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/1.5.tar.gz',
          is_url, dir, no_input)

# Generated at 2022-06-11 20:40:27.212836
# Unit test for function unzip
def test_unzip():
    import shutil
    import os
    test_folder = os.path.abspath(os.path.join(os.path.dirname(__file__),os.pardir))
    try:
        unpack_path = unzip(
            zip_uri=os.path.join(test_folder,'bitbucket_sample.zip'),
            is_url=False,clone_to_dir=os.path.join(test_folder,'HH'),
            no_input=True)
        if os.path.isdir(unpack_path):
            shutil.rmtree(unpack_path)
            print('Unit test for function unzip ... ok')
        else:
            print('Unit test for function unzip ... not ok')
    except Exception as e:
        print('Unit test for function unzip ... not ok')
   

# Generated at 2022-06-11 20:40:34.216594
# Unit test for function unzip
def test_unzip():
    import tempfile
    # Create a directory for the test
    with tempfile.TemporaryDirectory() as tempdir:
        # Copy the test zip file to the temp directory
        test_zipfile = os.path.join(tempdir, 'test.zip')
        test_file_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 'test.zip'
        )
        # Make sure path exists
        make_sure_path_exists(tempdir)
        # Copy test.zip to tempdir
        with open(test_zipfile, 'wb') as f:
            with open(test_file_path, 'rb') as test_file:
                f.write(test_file.read())
        # Test that a password protected zip file gets extracted

# Generated at 2022-06-11 20:40:44.094408
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    import shutil

    # We use a small test file uploaded to Github,
    # and the username & password for the Travis CI account
    password = 'Travis-Ci-Password-Test-Zip'
    username = 'travis-ci'
    zip_uri = 'https://github.com/{}/cookiecutter-test-pattern/archive/master.zip'.format(username)
    unzip_dir = unzip(zip_uri, is_url=True, password=password)
    try:
        assert os.path.isdir(unzip_dir)
    finally:
        shutil.rmtree(unzip_dir)

    # Test that invalid password is caught
    password = 'ThisIsAnInvalidPassword'
    import pytest

# Generated at 2022-06-11 20:40:47.736533
# Unit test for function unzip
def test_unzip():
    """Test unzip function."""
    assert unzip("C:\\Temp\\test.zip", True) is not None
    assert unzip("C:\\Temp\\test.zip", False) is not None
    assert unzip("C:\\Temp\\test.zip", True, password='test.zip') is not None

# Generated at 2022-06-11 20:40:59.099595
# Unit test for function unzip
def test_unzip():
    import shutil
    from .compat import mock
    from .compat import unittest

    # Mocked requests session
    session = mock.MagicMock()

    # Zip archive with no password

# Generated at 2022-06-11 20:41:07.376563
# Unit test for function unzip
def test_unzip():
    import hashlib
    import shutil
    import sys
    import textwrap
    import time

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    zipfile_0 = textwrap.dedent(
        """
        import os, sys
        import shutil
        from setuptools import setup, find_packages

        if __name__ == '__main__':
            here = os.path.abspath(os.path.dirname(__file__))
            make_sure_path_exists(os.path.join(here, 'test_dir'))
            print('ZipFile 0 directory')
        """
    )


# Generated at 2022-06-11 20:41:11.309572
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip(zip_uri, True)

# Generated at 2022-06-11 20:41:23.992662
# Unit test for function unzip
def test_unzip():
    import shutil
    import subprocess
    import tempfile

    # Get an archive
    tempdir = tempfile.mkdtemp()
    archive_zip = os.path.join(tempdir, 'archive.zip')
    dir_path = os.path.abspath(os.path.dirname(__file__))
    test_archive_zip = os.path.join(dir_path, 'example_repo_templates', 'archive.zip')
    shutil.copy(test_archive_zip, archive_zip)

    # Create the target directory for the unzip
    clone_to_dir = os.path.join(tempdir, 'clone')

    # Check the archive

# Generated at 2022-06-11 20:41:26.504572
# Unit test for function unzip
def test_unzip():
    #make sure unzip returns a valid path
    assert os.path.isdir("/tmp")