

# Generated at 2022-06-21 11:04:34.613853
# Unit test for function unzip
def test_unzip():

    clone_to_dir = tempfile.mkdtemp()
    unzip("https://codeload.github.com/honglilai/cookiecutter-django-cms/zip/master", True, clone_to_dir, False, None)

# Generated at 2022-06-21 11:04:43.315414
# Unit test for function unzip
def test_unzip():
    """Test for cookiecutter.zipfile.unzip."""
    import shutil

    # TODO: Remove when Python 2 support dropped
    from builtins import input

    class args:
        pass

    args.no_input = False
    args.checkout = None
    args.replay = None
    args.directory = None
    args.no_input = False

    # Create a temporary local git repository
    tmp_repo = tempfile.mkdtemp()
    tmp_zipfile = os.path.join(tmp_repo, 'zipfile.zip')
    tmp_zipfile_py = os.path.join(tmp_repo, 'zipfile.py')


# Generated at 2022-06-21 11:04:50.308839
# Unit test for function unzip
def test_unzip():
    #create a local zip that contains a test directory
    zip_path = "test.zip"
    zip = ZipFile(zip_path, "w")
    zip.write("testdirectory")
    zip.close()

    #extract to temporary directory
    unzip_path = unzip(zip_path, False)

    #check that the directory exists
    assert os.path.isdir(unzip_path)

# Generated at 2022-06-21 11:04:59.219839
# Unit test for function unzip
def test_unzip():
    import pytest
    import os

    from cookiecutter import utils

    with pytest.raises(InvalidZipRepository):
        utils.unzip('tests/fake-repo-tmpl/', False)

    # Unzip using a file path
    unzip_path = utils.unzip('tests/fake-repo-tmpl.zip', False)
    assert os.path.isdir(unzip_path)

    # Unzip using a URL
    unzip_path = utils.unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
    assert os.path.isdir(unzip_path)

# Generated at 2022-06-21 11:05:05.730912
# Unit test for function unzip
def test_unzip():

    dirpath = tempfile.mkdtemp()
    os.chdir(dirpath)
    link = 'https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/1.0'
    destination = unzip(link, is_url=True, password=None)
    assert os.path.isdir(destination)

# Generated at 2022-06-21 11:05:11.104883
# Unit test for function unzip
def test_unzip():
    """Test that the zip file is extracted and the unzip_path
    is returned by function unzip
    """
    zip_uri = '/tmp/test_cookiecutter/archive_test.zip'
    is_url = False
    clone_to_dir = '/tmp/test_cookiecutter'
    no_input = False

    assert unzip(zip_uri, is_url, clone_to_dir, no_input) == '/tmp/test_cookiecutter/archive_test'

# Generated at 2022-06-21 11:05:12.960579
# Unit test for function unzip
def test_unzip():
    """Utility function tests for unzip function"""
    unzip('test', True, '.', False, None)

# Generated at 2022-06-21 11:05:17.263427
# Unit test for function unzip
def test_unzip():
    unzip_path = unzip('http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '.', True)
    assert unzip_path.startswith('/tmp/cookiecutter-pypackage-master')

# Generated at 2022-06-21 11:05:24.669116
# Unit test for function unzip
def test_unzip():
    import urllib.request
    import urllib.parse
    from zipfile import ZipFile

    # construct test zip archive
    dirname = 'cookiecutter-pypackage'
    
    filename = 'cookiecutter-pypackage.zip'
    url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    urllib.request.urlretrieve(url, filename)

    # extract to temporary folder
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '.')

    # test if

# Generated at 2022-06-21 11:05:28.098927
# Unit test for function unzip
def test_unzip():
    unzip_path = unzip('http://github.com/kushaldas/cookiecutter-pylibrary/zipball/master',
                       True,
                       clone_to_dir='.',
                       no_input=False,
                       password=None)
    assert unzip_path

# Generated at 2022-06-21 11:06:08.685286
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile

    script_dir = os.path.dirname(os.path.abspath(__file__))
    zip_test_dir = os.path.join(script_dir, "zip_test")
    zip_path = os.path.join(zip_test_dir, "test1.zip")
    clone_to_dir = os.path.join(zip_test_dir, "test1")
    make_sure_path_exists(clone_to_dir)

    # Get the expected directory names
    expected = os.path.join(clone_to_dir, "cookiecutter-test1")

# Generated at 2022-06-21 11:06:16.540050
# Unit test for function unzip
def test_unzip():
    # Download and unzip the repository
    unzip_path = unzip(
        zip_uri='https://github.com/audreyr/cookiecutter-pypackage/archive/'
        'master.zip',
        is_url=True,
        clone_to_dir='.',
        no_input=False,
        password=None
    )
    assert os.path.exists(unzip_path)

    # Clean up
    os.system('rm -rf {0}'.format(unzip_path))
    os.system('rm -f cookiecutter-pypackage-master.zip')

# Generated at 2022-06-21 11:06:18.442090
# Unit test for function unzip
def test_unzip():
    try:
        from ..tests import test_zip
    except ValueError:
        from .tests import test_zip

    test_zip.test_unzip()

# Generated at 2022-06-21 11:06:19.957350
# Unit test for function unzip
def test_unzip():
    #@TODO: Add tests for this function
    pass

# Generated at 2022-06-21 11:06:30.890948
# Unit test for function unzip
def test_unzip():
    import pytest

    from cookiecutter.config import DEFAULT_REPOSITORY, get_user_config

    # Set up the directory for the temporary repository
    clone_dir = os.path.dirname(tempfile.mkdtemp())

    # Fetch the 'cookiecutter-pypackage' repository
    test_zip = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    test_template_path = unzip(
        test_zip, True, clone_to_dir=clone_dir, no_input=True
    )

    # Override the default repository to make it the temporary repository
    # path, so that the test is able to find the template inside.
    override_dir = [{'cookiecutters_dir': clone_dir}]
    config_dict

# Generated at 2022-06-21 11:06:41.279917
# Unit test for function unzip
def test_unzip():
    import zipfile
    import sys

    # Create a test zipfile
    testzip_path = '/tmp/test.zip'
    testzip_directory = tempfile.mkdtemp(
        prefix='test-cookiecutter-',
        suffix='-zip',
    )
    testzip_file = zipfile.ZipFile(testzip_path, 'w')
    testzip_file.write(
        os.path.join(testzip_directory, 'test.py'),
        arcname='test/test.py',
    )
    testzip_file.write(
        os.path.join(testzip_directory, 'test.py'),
        arcname='test/test.py',
    )
    testzip_file.close()

    # Unzip it with unzip

# Generated at 2022-06-21 11:06:51.111631
# Unit test for function unzip
def test_unzip():
    import shutil
    test_dir_path = tempfile.mkdtemp()

    # First, test with an unencrypted archive
    test_rep_base = os.path.join(test_dir_path, 'test_rep_base')
    os.makedirs(test_rep_base)

    # The archive will contain a single file and a single directory
    test_file_dir = os.path.join(test_dir_path, '1-dir')
    os.makedirs(test_file_dir)
    test_file_path = os.path.join(test_file_dir, 'test.yaml')
    with open(test_file_path, 'wt') as test_file:
        test_file.write('test data\n')

# Generated at 2022-06-21 11:06:55.631926
# Unit test for function unzip
def test_unzip():
    # Example of git repo in cookiecutter.json
    zip_uri = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = None
    proj_dir = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    assert proj_dir.startswith('/var/folders')

# Generated at 2022-06-21 11:06:58.440155
# Unit test for function unzip
def test_unzip():
    zip_uri = 'cookiecutter-demo'
    is_url = False
    clone_to_dir = '.'
    unzip(zip_uri, is_url, clone_to_dir)

# Generated at 2022-06-21 11:07:00.604442
# Unit test for function unzip
def test_unzip():
    import os
    os.chdir('~/')
    uri = '/cookiecutter.zip'
    unzip(uri, False)

# Generated at 2022-06-21 11:07:36.564576
# Unit test for function unzip
def test_unzip():
    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
                is_url=True) != None


# Generated at 2022-06-21 11:07:44.151310
# Unit test for function unzip
def test_unzip():
    from unittest.mock import patch

    with patch('cookiecutter.utils.prompt_and_delete') as mock_prompt_and_delete:
        mock_prompt_and_delete.return_value = True
        with patch('cookiecutter.utils.make_sure_path_exists'):
            with patch('requests.get'):
                unzip_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
                assert unzip_path == 'cookiecutter-pypackage-master'

# Generated at 2022-06-21 11:07:48.908929
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    clone_to_dir = '.'
    no_input = True

    try:
        unzip(zip_uri, is_url=True, clone_to_dir=clone_to_dir, no_input=no_input)
    except InvalidZipRepository:
        print('test case failed')

# Generated at 2022-06-21 11:08:00.975587
# Unit test for function unzip
def test_unzip():
    def setup_function(function):
        if not os.path.exists("foo"):
            os.makedirs("foo")
        if not os.path.exists("bar"):
            os.makedirs("bar")
        if not os.path.exists("foo/test.zip"):
            os.mknod("foo/test.zip")
        if not os.path.exists("foo/test2.zip"):
            os.mknod("foo/test2.zip")
        if not os.path.exists("foo/test3.zip"):
            os.mknod("foo/test3.zip")
        if not os.path.exists("foo/test4.zip"):
            os.mknod("foo/test4.zip")

# Generated at 2022-06-21 11:08:08.860586
# Unit test for function unzip
def test_unzip():
    """unit test for function unzip"""
    # Build the name of the cached zipfile,
    # and prompt to delete if it already exists.
    import pytest
    from tempfile import mkdtemp
    from zipfile import ZipFile
    from shutil import rmtree, copy2

    test_base = mkdtemp()
    origin = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '../tests/repos/cookiecutter-django/'
    )
    destination = os.path.join(test_base, "test_archive.zip")
    extract_dir = mkdtemp()

# Generated at 2022-06-21 11:08:10.230987
# Unit test for function unzip
def test_unzip():
    import doctest
    doctest.testmod(unzip)

# Generated at 2022-06-21 11:08:21.762837
# Unit test for function unzip
def test_unzip():
    import subprocess
    import os
    import shutil
    from zipfile import BadZipFile, ZipFile

    clone_to_dir = tempfile.mkdtemp()
    os.chdir(clone_to_dir)

    url = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master/'
    assert not os.path.exists('cookiecutter-pypackage-8437cb0')
    repo_dir = unzip(
        zip_uri=url,
        is_url=True,
        clone_to_dir=clone_to_dir
    )
    assert os.path.exists(repo_dir)
    shutil.rmtree(repo_dir)
    shutil.rmtree(clone_to_dir)

    clone_to_

# Generated at 2022-06-21 11:08:29.422479
# Unit test for function unzip
def test_unzip():
    """Test unzip function with a valid zip file."""
    zip_uri = 'https://github.com/edelvalle/cookiecutter-simple-python-package/zipball/master'
    clone_to_dir = '/tmp'
    unzip_path = unzip(zip_uri, is_url=True, clone_to_dir=clone_to_dir)
    assert(os.path.exists(unzip_path))
    assert(os.path.exists(os.path.join(unzip_path, 'README.rst')))

# Generated at 2022-06-21 11:08:40.852233
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile
    from zipfile import ZipFile
    from cookiecutter.config import CC_DEFAULT_CONFIG

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-21 11:08:49.551004
# Unit test for function unzip
def test_unzip():
    """Test the unzip function. It doesn't test downloading or
    unpacking a repository, but it does ensure that the function doesn't
    error out if there is no password-protected repository.
    """
    import pytest
    from cookiecutter import utils
    from cookiecutter.utils import unzip
    import mock

    '''
    Test unzipping of a password protected repository (no password provided)
    '''
    with mock.patch('cookiecutter.utils.read_repo_password', return_value=''):
        with pytest.raises(InvalidZipRepository):
            zip_repo = os.path.join(utils.tests_dir, 'test-password-protected-repo.zip')
            unzip(zip_path=zip_repo, is_url=False)


# Generated at 2022-06-21 11:09:34.145862
# Unit test for function unzip
def test_unzip():
    import unittest
    from mock import patch
    from cookiecutter.environment import StrictEnvironment
    from cookiecutter.prompt import read_user_yes_no
    from cookiecutter.config import DEFAULT_CONFIG


# Generated at 2022-06-21 11:09:34.724507
# Unit test for function unzip
def test_unzip():
    pass;

# Generated at 2022-06-21 11:09:40.527631
# Unit test for function unzip
def test_unzip():
    import zipfile
    import shutil
    temp_dir_name = './test_cc_zip_repo'
    os.makedirs(temp_dir_name)
    # Create a zip archive, and make sure the first file entry is a
    # directory entry
    zip_file_path = os.path.join(temp_dir_name, 'test.zip')
    with zipfile.ZipFile(zip_file_path, 'w') as test_zip:
        test_zip.writestr('testdir/', '')
        test_zip.writestr('testdir/test_file', 'Test Content')
    unzip_path = unzip(zip_file_path, is_url=False)
    # Check the unpacked archive

# Generated at 2022-06-21 11:09:48.379931
# Unit test for function unzip
def test_unzip():
    import tempfile
    test_zip_name = os.path.join(os.path.dirname(__file__), 'test-repo.zip')
    test_zip_dir = unzip(test_zip_name, False,
                         clone_to_dir=tempfile.gettempdir(), no_input=True)
    assert os.path.isdir(test_zip_dir)

    content = set(os.listdir(test_zip_dir))
    expected = {'empty', 'even', 'odd', 'README.md'}
    assert content == expected

# Generated at 2022-06-21 11:09:48.980362
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:09:52.164954
# Unit test for function unzip
def test_unzip():
    assert unzip('https://github.com/audreyr/cookiecutter/archive/0.9.1.zip',
                 True,'.', True, None) is not None

# Generated at 2022-06-21 11:09:58.552364
# Unit test for function unzip
def test_unzip():
    """
    Generate a zip archive
    """
    zip_uri = "./example_repos/bakery"
    is_url = False
    clone_to_dir = '.'
    password = None
    no_input = False
    unzip_path = unzip(zip_uri=zip_uri,
                       is_url=is_url,
                       clone_to_dir=clone_to_dir,
                       no_input=no_input,
                       password=password)
    assert unzip_path=="/tmp/tmph0njn4gf/bakery"

# Generated at 2022-06-21 11:10:09.535715
# Unit test for function unzip
def test_unzip():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path, environ
    from zipfile import ZipFile

    testdir = mkdtemp()
    testzip = path.join(testdir, 'test.zip')
    with ZipFile(testzip, 'w') as zf:
        zf.writestr('foo', 'bar')
    assert not path.exists(path.join(testdir, 'foo'))
    unzip(testzip, False, testdir)
    assert path.exists(path.join(testdir, 'foo'))
    rmtree(testdir)

    # Test password protected zip file
    testdir = mkdtemp()
    testzip = path.join(testdir, 'test.zip')

# Generated at 2022-06-21 11:10:15.471982
# Unit test for function unzip
def test_unzip():
    url = "https://github.com/mavcunha/cookiecutter-pyviz/archive/master.zip"
    unzip_path = unzip(
        zip_uri=url,
        is_url=True,
        clone_to_dir=os.path.abspath(os.path.curdir),
        no_input=True,
        password=None
    )
    assert os.path.exists(unzip_path)


# Generated at 2022-06-21 11:10:22.600082
# Unit test for function unzip
def test_unzip():
    # Test valid zipfile
    zip_path=os.path.join(os.path.abspath(os.path.curdir),'../tests/test-unzip.zip')
    unzip_path=unzip(zip_path,is_url=False, clone_to_dir='../tests',password=None)
    assert os.path.exists(unzip_path)
    assert os.path.exists(unzip_path+'/test1.txt')
    assert os.path.exists(unzip_path+'/test2/test3.txt')
    assert os.path.exists(unzip_path+'/test2/test4/test5.txt')
    assert os.path.exists(unzip_path+'/test2/test4/test6/test7.txt')

# Generated at 2022-06-21 11:11:37.841343
# Unit test for function unzip
def test_unzip():
    unzip("/Users/reilly/Code/cookiecutter-django/tests/test-data/fake-repo-tmpl.zip", True)

# Generated at 2022-06-21 11:11:39.819255
# Unit test for function unzip
def test_unzip():
    import doctest
    doctest.testmod(name="unzip", optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 11:11:49.189982
# Unit test for function unzip
def test_unzip():
    # download an existing zip, unzip it to a temp directory and then delete it
    from pathlib import Path

    from cookiecutter import utils

    # create a temp directory and file to zip
    with tempfile.TemporaryDirectory() as tmp_dir:

        # create a few files
        file1 = Path(utils.make_sure_path_exists(os.path.join(tmp_dir, 'file1')))
        file2 = Path(utils.make_sure_path_exists(os.path.join(tmp_dir, 'file2')))
        file1.write_text('a file')
        file2.write_text('yet another file')

        # zip the directory
        zip_path = utils.zip(tmp_dir, tmp_dir + '.zip')

        # unzip the directory again to a temp directory


# Generated at 2022-06-21 11:11:58.601955
# Unit test for function unzip
def test_unzip():
    # download a zipfile for testing
    import urllib.request

    test_download_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    urllib.request.urlretrieve(test_download_url, 'test.zip')

    # now test unzip on it
    unzip_temp = unzip("test.zip", False, clone_to_dir="/tmp/", no_input=True, password=None)

    # check that the zip was unpacked successfully
    assert os.path.isdir(unzip_temp)

    # remove the test files
    os.remove(os.path.join(unzip_temp, "cookiecutter.json"))
    os.remove(os.path.join(unzip_temp, "tests"))
    os.rem

# Generated at 2022-06-21 11:12:10.228262
# Unit test for function unzip
def test_unzip():
    base_dir = tempfile.mkdtemp()
    zipped_repo_path = os.path.join(base_dir, 'cookiecutter-foobar.zip')

    # Create an empty zipfile
    empty_zip = ZipFile(zipped_repo_path, 'w')
    empty_zip.close()

    # Test that an empty zipfile raises an exception
    try:
        unzip(zipped_repo_path, False, clone_to_dir=base_dir)
        assert False
    except InvalidZipRepository:
        assert True

    # Create a zipfile with a file at the top-level (no directory)
    no_dir_zip = ZipFile(zipped_repo_path, 'w')
    no_dir_zip.writestr('foobar', 'foobar')
    no_

# Generated at 2022-06-21 11:12:14.200216
# Unit test for function unzip
def test_unzip():
    # Module is supposed to import its dependencies inside function scope
    # to avoid polluting the global scope.
    # It is hard to generalize module import testing, so we will just
    # test the presence of the module constants.
    assert len(BadZipFile) == 0
    assert len(ZipFile) == 0


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:12:21.708594
# Unit test for function unzip
def test_unzip():
    from cookiecutter.environment import StrictUndefined
    from cookiecutter.main import cookiecutter
    from cookiecutter.vcs import clone
    import shutil
    import json

    # Make a temporary repo folder, copy the zip repo into it, and build a
    # temporary cookiecutter.json for testing
    tmp_repo = tempfile.mkdtemp()
    shutil.copyfile(
        os.path.join('tests', 'test-repo', 'test_zip_repo.zip'),
        os.path.join(tmp_repo, 'test_zip_repo.zip')
    )

# Generated at 2022-06-21 11:12:22.733721
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:12:24.000468
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:12:33.511529
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile
    from zipfile import PyZipFile, ZIP_DEFLATED
    
    def _write_foobar_zip_file(dirpath, filepath):
        # write a zip file with a foobar folder
        # and return the created zipfile object
        zipname = os.path.join(dirpath, os.path.basename(filepath))
        zipfile = PyZipFile(zipname, mode='w', compression=ZIP_DEFLATED)
        zipfile.writepy(filepath)
        zipfile.close()
        return zipfile
    
    def _test_unzip_file(iszip):
        #create temporary directory
        dirpath = tempfile.mkdtemp()
        # create temporary foobar folder

# Generated at 2022-06-21 11:14:02.062233
# Unit test for function unzip
def test_unzip():
    import pytest
    from requests.exceptions import RequestException
    from unittest.mock import patch
    from cookiecutter.config import DEFAULT_CLONE_DIR

    with patch('cookiecutter.utils.make_sure_path_exists') as msp:
        unzip(zip_uri='fakeuri', is_url=True, clone_to_dir=DEFAULT_CLONE_DIR, no_input=False, password=None)
        assert msp.call_count == 1

    with patch('cookiecutter.utils.make_sure_path_exists') as msp:
        unzip(zip_uri='fakeuri', is_url=False, clone_to_dir=DEFAULT_CLONE_DIR, no_input=False, password=None)
        assert msp.call_count == 1


# Generated at 2022-06-21 11:14:13.730824
# Unit test for function unzip
def test_unzip():
    import pytest
    # This test is conditional on the presence of the appropriate
    # environment variables, so it's not included as a normal test.
    from os import getenv
    from os import remove
    from shutil import rmtree
    from sys import version_info
    from zipfile import ZipFile
    import requests


    # Test inputs
    uri = getenv('ZIP_TEST_URI', None)
    pwd = getenv('ZIP_TEST_PWD', None)


# Generated at 2022-06-21 11:14:23.256655
# Unit test for function unzip
def test_unzip():
    import nose.tools
    from zipfile import ZipFile

    zip_uri =  os.path.join(os.path.abspath(os.path.dirname(__file__)), '../resources/test_zip_repo.zip')
    clone_to_dir = '.'
    zip_path = os.path.join(clone_to_dir, zip_uri)
    success_path = os.path.join(
        os.path.join(os.path.abspath(os.path.dirname(__file__)), '../resources/test_zip_repo'),
        'test_zip_repo'
    )

    print('test_unzip()')
    print('zip_uri:', zip_uri)
    print('zip_path:', zip_path)

# Generated at 2022-06-21 11:14:30.951223
# Unit test for function unzip
def test_unzip():
    from .prompt import MockPromptSession
    from .compat import patch

    try:
        import mock
    except ImportError:
        from unittest import mock

    def side_effect(*args, **kwargs):
        class MockResponse:
            pass

        mock_response = MockResponse()
        mock_response.iter_content = lambda chunk_size=None: "data"

        return mock_response

    with patch('cookiecutter.zipfile.ZipFile') as mock_zipfile:
        with patch('cookiecutter.prompt.prompt_and_delete') as mock_prompt:
            with patch('cookiecutter.prompt.read_repo_password') as mock_prompt_pass:
                mock_prompt.return_value = True
                mock_prompt_pass.return_value = "secret"

