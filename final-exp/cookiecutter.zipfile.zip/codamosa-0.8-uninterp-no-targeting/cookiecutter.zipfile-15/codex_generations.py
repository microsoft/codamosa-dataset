

# Generated at 2022-06-21 11:04:42.376421
# Unit test for function unzip
def test_unzip():
    import unittest
    import responses
    import requests
    import requests_mock
    import shutil
    import os
    import sys
    import zipfile
    import tempfile
    from mock import patch
    from cookiecutter.zipfile import unzip

    Response = requests.models.Response

    class TestUnzip(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.cloned_to_dir = tempfile.mkdtemp()
            self.cookiecutter_dir = os.path.join(self.temp_dir, 'cookiecutter')
            os.makedirs(self.cookiecutter_dir)

        def test_unzip_bad_zip(self):
            with self.assertRaises(InvalidZipRepository):
                un

# Generated at 2022-06-21 11:04:50.258816
# Unit test for function unzip
def test_unzip():
    from . import repo_testutils
    from . import here

    try:
        repo_testutils.create_empty_repo(here)
        repo_testutils.create_zip_of_repo(here)
        unzip(here + '/test_repo.zip', is_url=False, clone_to_dir='.', no_input=False, password=None)
    finally:
        repo_testutils.clean_up_generated_files(here)

# Generated at 2022-06-21 11:04:59.731392
# Unit test for function unzip
def test_unzip():
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    test_zip = os.path.join(temp_dir, 'test.zip')

    zip_file = ZipFile(test_zip, 'w')
    zip_file.writestr('test/test.txt', 'This is a test file')
    zip_file.close()

    # Simple test with a local zip file.
    test_path = unzip(
        zip_uri = test_zip,
        is_url = False,
        no_input = True
    )

    assert os.path.exists(os.path.join(temp_dir, test_path, 'test.txt'))

    shutil.rmtree(temp_dir)

# Generated at 2022-06-21 11:05:05.820586
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    unzip_path = unzip(zip_uri, True, '.', False)
    assert os.path.exists(unzip_path)
    unzip_path = unzip(zip_uri, True, '.', True)
    assert os.pa

# Generated at 2022-06-21 11:05:06.376842
# Unit test for function unzip
def test_unzip():
        unzip("zipfile",False,True)

# Generated at 2022-06-21 11:05:13.535821
# Unit test for function unzip
def test_unzip():
    import mock
    from pkg_resources import resource_filename
    import shutil
    # create a test repo and clone to test dir
    repo_path = resource_filename('cookiecutter.tests', 'test-repo-pre/')
    test_path = os.path.join(repo_path, '..', 'test-repo')
    shutil.copytree(repo_path, test_path)

    # create a function that returns a path to a test repo
    def get_path():
        return os.path.join(test_path, '{{cookiecutter.repo_name}}.zip')


# Generated at 2022-06-21 11:05:23.025205
# Unit test for function unzip
def test_unzip():
    from unittest import mock
    from pathlib import Path
    from cookiecutter.main import cookiecutter

    with mock.patch('cookiecutter.utils.make_sure_path_exists', mock.Mock()), \
         mock.patch('cookiecutter.utils.prompt_and_delete', mock.Mock()), \
         mock.patch('cookiecutter.prompt.read_repo_password', mock.Mock()), \
         mock.patch('cookiecutter.main.log') as mocked_log:
        unzip_path = unzip(
            'https://github.com/audreyr/cookiecutter-pypackage/archive/0.1.zip',
            is_url=True,
            password='secret',
        )


# Generated at 2022-06-21 11:05:29.810249
# Unit test for function unzip
def test_unzip():
    test_path = os.path.dirname(os.path.abspath(__file__))
    clone_to_dir = os.path.join(test_path, 'test-fixtures', 'fake-repo-tmpl')
    zip_path = os.path.join(test_path, 'test-fixtures', 'fake-repo-tmpl.zip')
    unzip_path = unzip(zip_uri=zip_path, is_url=False, clone_to_dir=clone_to_dir)
    assert os.path.exists(unzip_path)
    assert os.path.isdir(unzip_path)

# Generated at 2022-06-21 11:05:39.235756
# Unit test for function unzip
def test_unzip():
    with tempfile.TemporaryDirectory() as t:
        path = os.path.join(t, 'cookiecutter-foobar.zip')

# Generated at 2022-06-21 11:05:49.869030
# Unit test for function unzip
def test_unzip():
    """
    This function is use to unit test the unzip method.
    """
    try:
        # Create a temporary zip file
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as temp:
            filename = temp.name
            temp.write(b'This is a dummy zip file')

        # The unzip function should create a copy of the zip file in the temporary
        # directory and then delete the original zip file
        assert not os.path.exists(filename + '.copy')
        unzip(filename, False)
        assert os.path.exists(filename + '.copy')
        assert not os.path.exists(filename)

    finally:
        # Clean up temporary directory and zip file
        os.remove(filename + '.copy')

# Generated at 2022-06-21 11:06:09.413648
# Unit test for function unzip
def test_unzip():
    """ Test the unzip function.

        Tested in test_zip.py
    """
    pass

# Generated at 2022-06-21 11:06:19.160076
# Unit test for function unzip
def test_unzip():
    expected = 'tests/test-output/git-test/{{cookiecutter.repo_name}}'
    actual = unzip(
        'https://github.com/audreyr/cookiecutter-pypackage/zipball/master',
        is_url=True,
        clone_to_dir='tests/test-output/git-test'
    )
    assert expected == actual

    expected = 'tests/test-output/git-test/{{cookiecutter.repo_name}}'
    actual = unzip(
        'tests/test-output/git-test/cookiecutter-pypackage-0.1.1.zip',
        is_url=False,
        clone_to_dir='tests/test-output/git-test'
    )
    assert expected == actual

# Generated at 2022-06-21 11:06:30.131028
# Unit test for function unzip
def test_unzip():
    from shutil import rmtree, copyfile, copytree
    from cookiecutter import repository
    from cookiecutter.config import get_user_config
    from cookiecutter.exceptions import FailedHookException
    from cookiecutter.file_utils import make_sure_path_exists
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import dump, play

    # Setup
    temp_dir = tempfile.mkdtemp()
    test_dir = os.path.dirname(os.path.abspath(__file__))
    repo_dir = os.path.join(test_dir, '..', 'tests', 'fake-repo-tmpl')

# Generated at 2022-06-21 11:06:40.768196
# Unit test for function unzip
def test_unzip():
    """test_unzip and test_unzip_invalid are helper functions for
    testing `unzip`.

    #TODO: Move this to tests/test_unzip.py
    """
    # Test downloading a zip archive
    def test_unzip(self):
        """Fetch a zip archive from Github, and unpack it.

        Checks that the top-level directory in the zip file is
        unpacked and that the directory contains a contents file.
        """
        # Fetch the zip archive
        zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
        clone_to_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 11:06:50.764075
# Unit test for function unzip
def test_unzip():
    from os import path
    import shutil
    from tempfile import mkdtemp
    from unittest.mock import ANY, patch

    # Patch the 'requests' library so that it does not try to
    # download anything from the real internet.
    with patch('requests.get', return_value=ANY) as mock_get:
        # Run the test
        unzip('http://example.com/example.zip', True)

    # Ensure that requests.get was called with the expected URLs
    expected_urls = [
        'http://example.com/example.zip'
    ]
    actual_urls = []
    for call in mock_get.call_args_list:
        actual_urls.append(call[0][0])

    assert expected_urls == actual_urls

    # Create a test ZIP archive

# Generated at 2022-06-21 11:06:56.199930
# Unit test for function unzip
def test_unzip():
    if __name__ != '__main__':
        return
    unzip_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
                       True, clone_to_dir='.',
                       no_input=False, password=None)
    print(unzip_path)
    assert unzip_path

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:06:58.353793
# Unit test for function unzip
def test_unzip():
    unzip("test/test_files/test_zip.zip", True)
    unzip("test/test_files/test_zip.zip", False)

# Generated at 2022-06-21 11:07:05.437711
# Unit test for function unzip
def test_unzip():
    password = 'test1234'
    test_zip = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    test_zip_protected = 'http://foobar.com/protected.zip'

    unzip_path = unzip(test_zip, False)
    unzip_path = unzip(test_zip, True)
    unzip_path = unzip(test_zip, True, password=password)
    unzip_path = unzip(test_zip_protected, True, password=password)

# Generated at 2022-06-21 11:07:17.694528
# Unit test for function unzip
def test_unzip():
    """Test unzip function."""
    import pytest
    from cookiecutter.repository import check_repo_name
    from cookiecutter.config.config import get_user_config

    check_repo_name('cookiecutter-pypackage')
    repo_dir = 'tests/test-repos/cookiecutter-pypackage'
    context = get_user_config(repo_dir)
    assert context['project_name'] == 'Cookiecutter pypackage'
    assert context['repo_name'] == 'cookiecutter-pypackage'
    assert context['pkg_name'] == 'cookiecutter_pypackage'

    # Test without password

# Generated at 2022-06-21 11:07:24.821768
# Unit test for function unzip
def test_unzip():
    import zipfile
    
    zip_path = tempfile.mkdtemp()
    project_name = 'my_project'
    sub_project_name = 'my_subproject'
    clone_to_dir = os.path.expanduser(zip_path)
    make_sure_path_exists(clone_to_dir)
    
    
    zip_filename = 'test.zip'
    zip_uri = os.path.join(zip_path, zip_filename)
    with zipfile.ZipFile(zip_uri, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('README.md', '')
        zf.writestr(project_name + '/', '')

# Generated at 2022-06-21 11:08:01.696016
# Unit test for function unzip
def test_unzip():
    """Unit test for the unzip function.
    """
    import shutil
    import zipfile

    zip_uri = 'https://codeload.github.com/hackebrot/cookiecutter-pypackage/zip/master'
    clone_to_dir = '~/repository'
    unzip_path = unzip(zip_uri, True, clone_to_dir, True)

    assert os.path.isdir(unzip_path)

    zip_file = zipfile.ZipFile('~/repository/cookiecutter-pypackage-master.zip')

    shutil.rmtree(clone_to_dir)
    shutil.rmtree(unzip_path)


# Generated at 2022-06-21 11:08:09.175282
# Unit test for function unzip
def test_unzip():
    try:
        os.remove("./tests/test-output/nestedenv_archive.zip")
    except:
        pass
    unzip("https://bitbucket.org/dhellmann/virtualenvwrapper.nested/get/tip.zip", is_url=True, clone_to_dir="./tests/test-output")
    assert os.path.exists("./tests/test-output/nestedenv_archive.zip")
    assert os.path.exists("./tests/test-output/dhellmann-virtualenvwrapper.nested-f163cf3d3a26")
    os.remove("./tests/test-output/nestedenv_archive.zip")

# Generated at 2022-06-21 11:08:20.757455
# Unit test for function unzip
def test_unzip():
    # Create temp directory
    tempdir = tempfile.mkdtemp()
    # This script will create a one-level zip archive with 1 file inside
    script = '''
    import os
    import zipfile
    with zipfile.ZipFile('test_archive.zip', 'w', zipfile.ZIP_DEFLATED) as zp:
        zp.write('test_file.txt')
    os.unlink('test_file.txt')
    '''
    # Create temp directory and change working directory to that directory
    with tempfile.TemporaryDirectory() as tempdir:
        os.chdir(tempdir)
        # Create the file "test_file.txt" inside temp directory
        test_file = open('test_file.txt', 'w')
        test_file.write('this is a test file')
        test_

# Generated at 2022-06-21 11:08:26.426126
# Unit test for function unzip
def test_unzip():
    uri = 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(uri, True, clone_to_dir='.', no_input=True)
    assert os.path.isdir(unzip_path)
    os.rmdir(unzip_path)
    os.rmdir(os.path.dirname(unzip_path))

# Generated at 2022-06-21 11:08:37.104849
# Unit test for function unzip
def test_unzip():
    test_zip_url = "https://bitbucket.org/dhellmann/setupfiles/get/tip.zip"
    test_url_password = "dhellmann"
    test_zip_file = "../tests/fake-repo-tmpl/.zip/setupfiles.zip"
    test_file_password = "tmpl"
    unzip(test_zip_file, False, no_input = True, password = test_file_password)
    unzip(test_zip_url, True, no_input = True, password = test_url_password)
    try:
        unzip(test_zip_url, True, no_input = True, password = "wrong")
    except InvalidZipRepository:
        pass
    else:
        assert False

# Generated at 2022-06-21 11:08:42.529234
# Unit test for function unzip
def test_unzip():
    import shutil
    unzip_path = unzip(
        'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
        True,
    )
    assert os.path.exists(unzip_path)
    assert unzip_path.startswith('/tmp/')
    shutil.rmtree(unzip_path)

# Generated at 2022-06-21 11:08:50.545523
# Unit test for function unzip
def test_unzip():
    '''Test downloading the zip repository'''
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    unittest.TestCase.assertTrue = unittest.TestCase.assertIs
    unittest.TestCase.assertFalse = unittest.TestCase.assertIsNot
    class TestUnzipMethods(unittest.TestCase):
        '''Test the download of the zip repository'''
        def test_unzip_zip_url(self):
            '''Test the download of the cookiecutter-pypackage zip archive from pypi'''
            # test zip url from pypi

# Generated at 2022-06-21 11:08:56.126955
# Unit test for function unzip
def test_unzip():
    testpath = os.path.abspath(os.path.dirname(__file__))
    testzip = os.path.join(testpath, 'test_repo.zip')
    destpath = unzip(testzip, False)
    assert os.path.exists(os.path.join(destpath, 'test_repo'))

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:09:02.824334
# Unit test for function unzip
def test_unzip():
    """Test if function unzip() returns the right directory path."""
    tempdir = tempfile.mkdtemp()
    assert unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip",
                 is_url=True,
                 clone_to_dir=tempdir,
                 no_input=True) == os.path.join(tempdir, 'cookiecutter-pypackage')



# Generated at 2022-06-21 11:09:03.837601
# Unit test for function unzip
def test_unzip():
    # TODO: Need a test repository.
    pass

# Generated at 2022-06-21 11:09:35.879241
# Unit test for function unzip
def test_unzip():
    from zipfile import is_zipfile, ZipFile
    from shutil import rmtree
    from tempfile import mkdtemp as tmp
    import os
    import tempfile
    from cookiecutter.utils import make_sure_path_exists, prompt_and_delete

    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    password = None
    no_input = False
    clone_to_dir = tmp()
    os.makedirs(clone_to_dir)

    unzip_path = unzip(zip_uri, True, clone_to_dir, password=password,no_input=no_input)

    assert os.path.exists(unzip_path) == True
    assert is_zipfile(unzip_path) == True


# Generated at 2022-06-21 11:09:41.387094
# Unit test for function unzip
def test_unzip():
    """
    test_unzip()
    """
    unzipped_path = unzip('cookiecutter-pypackage', True, '.')
    os.remove(os.path.join(unzipped_path, 'README.rst'))
    os.rmdir(unzipped_path)
    assert os.path.exists(unzipped_path)

# Generated at 2022-06-21 11:09:52.291510
# Unit test for function unzip
def test_unzip():
    import pytest
    import shutil
    import tempfile
    # Testing with test.zip of current directory
    zip_uri = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test.zip')
    is_url = False
    clone_to_dir = os.path.join(tempfile.mkdtemp(), 'unzip')
    no_input = True
    password = None

    unzipped_dir = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    assert unzipped_dir is not None
    assert os.path.exists(os.path.join(unzipped_dir, 'cookiecutter.json'))
    shutil.rmtree(os.path.dirname(unzipped_dir))



# Generated at 2022-06-21 11:10:00.264319
# Unit test for function unzip
def test_unzip():
    import pytest
    import shutil
    import requests as req
    import time
    import zipfile
    from zipfile import ZipFile

    with open('temp.zip', 'wb') as f:
        r = req.get('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip')
        f.write(r.content)
        f.close()

    zip = ZipFile('temp.zip')
    first_filename = zip.namelist()[0]
    project_name = first_filename[:-1]
    unzip_base = tempfile.mkdtemp()
    unzip_path = os.path.join(unzip_base, project_name)
    zip.extractall(path=unzip_base)

# Generated at 2022-06-21 11:10:10.498372
# Unit test for function unzip
def test_unzip():
    """
    This unit test tests that this module can unzip with a password,
    and also that it handles an empty zip archive properly.
    """
    import zipfile
    import shutil

    def delete_dir(dirname):
        shutil.rmtree(dirname)
        assert not os.path.exists(dirname)

    # Test unzipping a normal zip archive.
    dirname = tempfile.mkdtemp()
    test_zip = os.path.join(dirname, 'test.zip')
    z = zipfile.ZipFile(test_zip, mode='w')
    z.writestr('a', 'b')
    z.close()
    unzip_dir = unzip(test_zip, is_url=False)
    assert os.path.exists(unzip_dir)

# Generated at 2022-06-21 11:10:19.026895
# Unit test for function unzip
def test_unzip():
    import requests
    import json
    import os
    import tempfile
    from zipfile import ZipFile

    # Create a repository on GitHub and test unzipping it.
    repo_name = 'test_repo'
    repo_description = 'Temporary test repository for cookiecutter'
    temp_dir = tempfile.mkdtemp()
    temp_repo = os.path.join(temp_dir, repo_name)
    test_file = os.path.join(temp_repo, 'test.txt')

    # Create the temporary git repository.
    os.mkdir(temp_repo)

    # creating zip file of created repository
    zip_path = os.path.join(temp_dir, repo_name + '.zip')
    zip_repo = ZipFile(zip_path, 'w')
    zip_repo

# Generated at 2022-06-21 11:10:27.672907
# Unit test for function unzip
def test_unzip():
    import os
    from zipfile import ZipFile
    import tempfile
    from shutil import rmtree

    expected_zip_dir="python_boilerplate"
    expected_zip_dir_path=os.path.join(os.path.dirname(__file__), expected_zip_dir)
    expected_zip_file_path=os.path.join(os.path.dirname(__file__), 'test_unzip.zip') # This is created via command line: 'zip -r test_unzip.zip test_unzip'
    expected_zip_file_password='test'

    # The actual zip file test
    unzip_base = tempfile.mkdtemp()

# Generated at 2022-06-21 11:10:35.135814
# Unit test for function unzip
def test_unzip():
    """Unit test for function 'unzip' """
    # The zip file is password protected. The correct password is "test"
    zip_url = 'https://github.com/JackMcKew/test_zip_https/archive/master.zip'
    clone_to_dir = '.'
    no_input = False
    password = 'test'

    unzip(zip_url, 1, clone_to_dir, no_input, password)


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:10:44.343590
# Unit test for function unzip
def test_unzip():
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.environment import generate_context
    from cookiecutter.main import cookiecutter
    from shutil import rmtree

    with tempfile.TemporaryDirectory() as tmpdir:
        clone_to_dir = tmpdir
        # Create a temporary directory to serve as the 'cookiecutter repository'
        tmprepo = tempfile.mkdtemp()
        # Create a temporary directory to serve as the 'cookiecutter repository'
        tmprepo = tempfile.mkdtemp()
        test_project_name = 'my-project'
        test_project_path = os.path.join(tmprepo, test_project_name)
        os.makedirs(test_project_path)
        # Create a simple cookiecutter

# Generated at 2022-06-21 11:10:48.757184
# Unit test for function unzip
def test_unzip():
    """
    Unit test for function unzip
    """
    print('Test function unzip')
    unzip('test_cookiecutter/test_unzip_archive/cookiecutter-pypackage.zip',
          is_url=True, no_input=True)
    print('End of the test')

# Generated at 2022-06-21 11:11:39.142920
# Unit test for function unzip
def test_unzip():
    import shutil
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 11:11:48.579007
# Unit test for function unzip
def test_unzip():
    test_zip_uri = \
        "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    test_zip_file = unzip(test_zip_uri, is_url=True)
    assert test_zip_file
    
if __name__ == '__main__':
    import sys, os
    # use first argument as the zip file to download
    if len(sys.argv) > 1:
        test_zip_uri = sys.argv[1]
    else:
        test_zip_uri = \
            "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    print(test_zip_uri)

# Generated at 2022-06-21 11:11:54.327780
# Unit test for function unzip
def test_unzip():
    import shutil
    from cookiecutter.utils import _make_zip, rmtree
    try:
        out_dir = rmtree('temp')
    except:
        pass
    out_dir = _make_zip()
    in_dir = unzip(out_dir+'test.zip',False,'out') 
    assert in_dir
    os.chdir(in_dir)
    assert os.path.exists('test')
    assert os.path.exists('test/test.txt')
    assert os.path.exists('test/test2')
    assert os.path.exists('test/test2/test2.txt')
    os.chdir('..')
    shutil.rmtree(out_dir)
    shutil.rmtree(in_dir)
    

# Generated at 2022-06-21 11:11:55.018305
# Unit test for function unzip
def test_unzip():
    # Test for the function unzip in github.py
    pass

# Generated at 2022-06-21 11:11:55.544303
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:12:01.799286
# Unit test for function unzip
def test_unzip():
    my_zip_path = os.path.join(
        os.path.dirname(__file__), '..', '..', 'tests', 'fake-repo.zip'
    )
    tmp_dir = tempfile.mkdtemp()
    unzip(my_zip_path, False, tmp_dir)
    assert len(
        os.listdir(tmp_dir)
    ) == 1, "Unzipped project directory not created under {}".format(tmp_dir)

# Generated at 2022-06-21 11:12:07.064200
# Unit test for function unzip
def test_unzip():
    import shutil

    unzip_path = unzip('https://github.com/lukasgeiter/cookiecutter-pypackage-minimal/archive/master.zip', is_url=True)
    assert(os.path.exists(unzip_path))
    shutil.rmtree(unzip_path)

# Generated at 2022-06-21 11:12:14.465422
# Unit test for function unzip
def test_unzip():
    import pytest
    from cookiecutter import utils

    file_path = os.path.abspath(__file__)
    dir_path = os.path.dirname(file_path)
    zip_path = os.path.join(dir_path, 'files/fake-repo.zip')

    with pytest.raises(InvalidZipRepository) as excinfo:
        utils.unzip(zip_path, os.path.join(dir_path, 'files'), no_input=True)

    assert 'Zip repository files/fake-repo.zip is not a valid zip archive' in str(excinfo.value)

# Generated at 2022-06-21 11:12:22.276689
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    import zipfile
    import zipfile

    url = 'https://github.com/cookiecutter/cookiecutter-pypackage/archive/master.zip'
    tempdir = tempfile.mkdtemp()

    unzip_dir = unzip(url, True, tempdir)
    unzip_path = os.path.join(unzip_dir, '.cookiecutterrc')
    assert os.path.exists(unzip_path)

    # Test unzipping a password protected archive
    # Create a password protected zip archive
    zip_path = os.path.join(tempdir, 'protected.zip')
    zip_ref = zipfile.ZipFile(zip_path, 'w')
    zip_ref.setpassword('password'.encode('utf-8'))

# Generated at 2022-06-21 11:12:25.524025
# Unit test for function unzip
def test_unzip():
    """
    Since we are going to have to have a test zip with a password to test for
    the password requirement, it's best if we put it behind a flag.
    """
    pass

# Generated at 2022-06-21 11:14:11.205000
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(zip_uri, True, clone_to_dir='./', no_input=True)
    expected_unzip_path = 'cookiecutter-pypackage-master'
    unzip_path_list = unzip_path.split(os.sep)
    assert unzip_path_list[-1] == expected_unzip_path

# Generated at 2022-06-21 11:14:17.468402
# Unit test for function unzip
def test_unzip():
    class MockZipFile(object):
        def __init__(self, first_filename):
            self.namelist = [first_filename]

        def extractall(self, path):
            pass

    zip_uri = 'TestUri'
    zip_path = 'TestPath'
    project_name = 'TestProject'
    unzip_base = 'TestUnzipBase'
    unzip_path = 'TestUnzipPath'

    def mock_requests_get(zip_uri, stream=True):
        return None

    def mock_os_path_exists(zip_path):
        return False

    def mock_os_path_abspath(zip_uri):
        return zip_path

    def mock_tempfile_mkdtemp():
        return unzip_base


# Generated at 2022-06-21 11:14:27.135670
# Unit test for function unzip
def test_unzip():
    from unittest.mock import patch, MagicMock
    from requests.exceptions import ConnectionError
    from cookiecutter.exceptions import NetworkError
    import zipfile
    test_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    test_path = 'cookiecutter-pypackage-master'
    error_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/2.0.1.zip'

    # Test unzip
    with patch('cookiecutter.utils.unzip.requests.get') as mock_get:
        mock_get.return_value = MagicMock()
        mock_get.return_value.status_code = 200
        mock_get.return_value.iter_content