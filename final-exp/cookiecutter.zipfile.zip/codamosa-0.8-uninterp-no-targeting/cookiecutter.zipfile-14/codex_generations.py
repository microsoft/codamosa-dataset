

# Generated at 2022-06-21 11:04:44.057937
# Unit test for function unzip
def test_unzip():
    """
    unit test for function unzip
    :return: None
    """
    import os
    import shutil
    from cookiecutter.utils import rmtree

    repo_dir = os.path.abspath(os.path.dirname(__file__))
    tests_dir = os.path.join(repo_dir, 'tests')
    fixtures_dir = os.path.join(tests_dir, 'fixtures')
    repo_path = os.path.join(fixtures_dir, 'test-repo.zip')
    expected_repo_dir = os.path.join(fixtures_dir, 'test-repo')

    is_url = False
    unzip_to_dir = os.path.join(tests_dir, 'unzip_test')

# Generated at 2022-06-21 11:04:56.698082
# Unit test for function unzip
def test_unzip():
    assert unzip(zip_uri='fixtures/fake_repo_templates.zip', is_url=False, clone_to_dir='.', no_input=True, password=None)
    assert unzip(zip_uri='../fixtures/fake_repo_templates.zip', is_url=False, clone_to_dir='.', no_input=True, password=None)
    assert unzip(zip_uri='/Users/lisahamilton/dev/cookiecutter/tests/fixtures/fake_repo_templates.zip', is_url=False, clone_to_dir='.', no_input=True, password=None)

# Generated at 2022-06-21 11:05:04.955716
# Unit test for function unzip
def test_unzip():
    tempdir = tempfile.mkdtemp()
    origdir = os.getcwd()
    os.chdir(tempdir)

    try:
        unzip_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '.', False)
        assert os.path.exists(unzip_path)
    finally:
        os.chdir(origdir)
        shutil.rmtree(tempdir)

# Generated at 2022-06-21 11:05:07.764340
# Unit test for function unzip
def test_unzip():
    try:
        unzip('invalid_path', False)
        assert False, "This path is invalid."
    except InvalidZipRepository:
        assert True


# Generated at 2022-06-21 11:05:14.168451
# Unit test for function unzip
def test_unzip():
  # Prepare a temporary directory
  clone_to_dir = tempfile.mkdtemp(prefix='cookiecutter-')

# Generated at 2022-06-21 11:05:15.628776
# Unit test for function unzip
def test_unzip():
    unzip('test-zip-repo', True, 'test_zip_repo')

# Generated at 2022-06-21 11:05:21.481368
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    is_url = True
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    clone_to_dir = '.'
    no_input = False
    password = None
    unzipped_path = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    assert unzipped_path is not None
    print(unzipped_path)

# Generated at 2022-06-21 11:05:29.885396
# Unit test for function unzip
def test_unzip():
    """Test suite for unzip function."""
    import unittest
    import shutil

    class TestUnzip(unittest.TestCase):

        def setUp(self):
            self.repo_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.repo_dir)

        def test_valid_zip(self):
            """Test valid zip repo."""
            zip_repo = unzip(
                zip_uri='https://github.com/hackebrot/cookiecutter-pypackage-minimal/archive/master.zip',
                is_url=True,
                clone_to_dir=self.repo_dir
            )
            self.assertTrue(os.path.isdir(zip_repo))
            self.assertTrue

# Generated at 2022-06-21 11:05:39.263242
# Unit test for function unzip
def test_unzip():
    import shutil
    import os, tempfile
    basedir = tempfile.mkdtemp()

# Generated at 2022-06-21 11:05:48.111414
# Unit test for function unzip
def test_unzip():
    # download zip file on pypi.org
    zip_uri = 'https://pypi.python.org/packages/source/p/pyserial/pyserial-2.7.tar.gz'
    clone_to_dir = '.'
    project_name = 'pyserial-2.7'
    # unpack the repository
    unzip_path = unzip(zip_uri, is_url=True, clone_to_dir=clone_to_dir)
    assert os.path.exists(unzip_path)
    assert project_name == os.path.basename(unzip_path)

# Generated at 2022-06-21 11:06:15.369536
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    from cookiecutter.exceptions import InvalidZipRepository

    from .utils import chdir, make_empty_dir
    
    # Create temporary directories for unit test
    tmp_base_dir = tempfile.mkdtemp()
    tmp_empty_dir = os.path.join(tmp_base_dir, 'empty')
    tmp_dir = os.path.join(tmp_base_dir, 'test')
    tmp_zip = os.path.join(tmp_dir, 'repo.zip')
    tmp_extract = os.path.join(tmp_dir, 'extract')

    # Create the empty archives to test
    make_empty_dir(tmp_empty_dir)
    os.system('zip -r {} {}'.format(tmp_zip, tmp_empty_dir))

    #

# Generated at 2022-06-21 11:06:22.877256
# Unit test for function unzip
def test_unzip():
    import filecmp
    import shutil
    from tempfile import mkdtemp

    from cookiecutter.utils import rmtree
    from . import SCHEMA_JSON

    temp_dir = mkdtemp()
    test_zip = os.path.join(temp_dir, 'test_zip.zip')

    # Build a test zipfile
    try:
        with ZipFile(test_zip, 'w') as zf:
            zf.write('tests/test-repo-pre/', arcname='test-repo-pre')
            zf.write(SCHEMA_JSON, arcname='test-repo-pre/cookiecutter.json')
    except BadZipFile:
        assert False, 'Bad zip file'

    # Expand zip to temp dir
    unzip_dir = unzip(test_zip, False)



# Generated at 2022-06-21 11:06:23.926125
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:06:35.368415
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile
    import unittest
    import zipfile

    # Ensure cookiecutter does not already exists
    zip_uri = "./tests/files/cookiecutter_example.zip"
    clone_to_dir = tempfile.mkdtemp()
    make_sure_path_exists(clone_to_dir)
    cookiecutter_dir = os.path.join(clone_to_dir, "cookiecutter-example")

    # Unzip the zip file
    unzip_path = unzip(zip_uri, is_url=False, clone_to_dir=clone_to_dir)

    # Move the unzip to the right place
    shutil.move(unzip_path, cookiecutter_dir)

    # Check its contents

# Generated at 2022-06-21 11:06:40.577086
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/nayukim/cookiecutter-django/zipball/master'
    is_url = True
    clone_to_dir = '.'
    no_input = True

    unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input=no_input)
    assert os.path.isdir(unzip_path)

# Generated at 2022-06-21 11:06:50.544562
# Unit test for function unzip
def test_unzip():
    import shutil
    import sys
    import os

    # create test directory
    testdir = 'testdir'
    if os.path.exists(testdir):
        if os.path.isdir(testdir):
            shutil.rmtree(testdir)
        else:
            os.unlink(testdir)
        os.makedirs(testdir)
    # create test zip file
    zip_path = 'testdir/testzip'
    zip_file = ZipFile(zip_path, mode='w')
    zip_file.write('cookiecutter/tests/test-repo-tmpl/foo/README.md')
    zip_file.write('cookiecutter/tests/test-repo-tmpl/hooks/pre_gen_project.py')

# Generated at 2022-06-21 11:06:57.124749
# Unit test for function unzip
def test_unzip():
    # Function for unzipping the zip archive
    def unzipit(zip_uri, is_url, clone_to_dir='.', no_input=False, password=None):
        # We need to unzip the archive ourselves, so we can check
        # what's in it.
        zip_path = unzip(
            zip_uri=zip_uri,
            is_url=is_url,
            clone_to_dir=clone_to_dir,
            no_input=no_input,
            password=password,
            test_unzip=True
        )

        with ZipFile(zip_path) as zip_file:
            namelist = zip_file.namelist()

        return namelist

    # Test an empty zip archive
    assert unzipit('empty.zip', False) == []

    # Test an

# Generated at 2022-06-21 11:07:06.945464
# Unit test for function unzip
def test_unzip():
    from cookiecutter.config import DEFAULT_REPO_DIR
    from cookiecutter.utils import rmtree
    
    clone_to_dir = os.path.expanduser(DEFAULT_REPO_DIR)
    cookiecutter_dir = os.path.dirname(os.path.dirname(__file__))
    
    zip_uri = os.path.join(cookiecutter_dir, 'tests', 'files', 'zip-files', 'pytest-cookiecutter.zip')
    unzip(zip_uri, False)
    
    zip_uri = os.path.join(cookiecutter_dir, 'tests', 'files', 'zip-files', 'pytest_cookiecutter.zip')
    unzip(zip_uri, False, clone_to_dir, password='testing123')
    
    zip

# Generated at 2022-06-21 11:07:18.437249
# Unit test for function unzip
def test_unzip():
    """This function was created to test the function unzip()"""
    import shutil
    from tempfile import mkdtemp
    tempdir = mkdtemp()
    unzipdir = mkdtemp()
    shutil.copy('tests/test-repo.zip', tempdir)
    unzip(os.path.join(tempdir, 'test-repo.zip'), False, no_input=True, clone_to_dir=unzipdir)
    expected = ['tests/test-repo', 'tests/test-repo/{{cookiecutter.repo_name}}', 'tests/test-repo/hooks', 'tests/test-repo/{{cookiecutter.repo_name}}/README.rst']
    assert sorted(os.listdir(unzipdir)) == expected

# Generated at 2022-06-21 11:07:21.821389
# Unit test for function unzip
def test_unzip():
    """ Unit test for function unzip
    Args:

    Returns:
        None

    Raises:
        None
    """

    unzip_path = unzip('./tests/test-repo', False)
    assert unzip_path
    os.unlink(unzip_path)

# Generated at 2022-06-21 11:07:41.191230
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:07:48.060404
# Unit test for function unzip
def test_unzip():

    check_unzip = unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True,
                        clone_to_dir='/tmp', no_input=False, password=None)

    assert os.path.exists(check_unzip)

    check_unzip2 = unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True,
                        clone_to_dir='/tmp', no_input=False, password='xxx')

    assert os.path.exists(check_unzip2)


# Generated at 2022-06-21 11:07:50.443272
# Unit test for function unzip
def test_unzip():
    # TODO: fix test
    unzip("test_repo.zip", "test_repo", "test_cookiecutter")

# Generated at 2022-06-21 11:07:51.406149
# Unit test for function unzip
def test_unzip():
    # TODO: Test unit
    pass

# Generated at 2022-06-21 11:08:03.922272
# Unit test for function unzip
def test_unzip():
    # Test on empty zipfile
    try:
        # Using a path in here so that a corresponding zipfile to 
        # this path will never be found
        unzip(zip_uri='../data/invalid_empty.zip', is_url=False,
              clone_to_dir='/tmp', no_input=False)
        assert False
    except InvalidZipRepository:
        assert True

    # Test on non-empty zipfile
    try:
        unzip_path = unzip(
            zip_uri='../data/invalid_missing_top_level.zip', is_url=False,
            clone_to_dir='/tmp', no_input=False
        )
        assert False
    except InvalidZipRepository:
        assert True
        # Check that unzip_path has been removed, if any
        assert not os

# Generated at 2022-06-21 11:08:16.361888
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile

    import pytest

    from cookiecutter.utils import unzip

    @pytest.fixture(scope='module')
    def encrypted_zip():
        answer = """\
        <html>
        <head><title>302 Found</title></head>
        <body bgcolor="white">
        <center><h1>302 Found</h1></center>
        <hr><center>nginx</center>
        </body>
        </html>
        """
        encrypted_zip_file = tempfile.NamedTemporaryFile(suffix='.zip', delete=False)
        encrypted_zip_file.write(answer.encode('utf-8'))
        encrypted_zip_file.close()
        yield encrypted_zip_file.name

# Generated at 2022-06-21 11:08:27.349103
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile
    import zipfile

    cookiecutter_path = tempfile.mkdtemp()
    test_file_path = tempfile.mkdtemp()
    result_path = os.path.join(test_file_path,"test1")

# Generated at 2022-06-21 11:08:28.374621
# Unit test for function unzip
def test_unzip():
    # TODO: write unit test
    pass

# Generated at 2022-06-21 11:08:39.814523
# Unit test for function unzip
def test_unzip():
    # Download a zipfile, unzip it, and display the files within
    # using unzip.
    import os.path
    import tempfile

    # Create the zipfile
    zf_path = os.path.join(tempfile.gettempdir(), 'example.zip')
    zf = ZipFile(zf_path, 'w')
    zf.writestr('testfile.txt', b'test')
    zf.close()

    # Unzip the zipfile
    unzip_path = unzip(zip_uri=zf_path, is_url=False)

    # Iterate over the files in the unzip_path and display them.
    for root, dirs, files in os.walk(unzip_path):
        path = root.split(os.sep)

# Generated at 2022-06-21 11:08:48.845378
# Unit test for function unzip
def test_unzip():
    import shlex
    import subprocess
    import sys
    import os

    # Check that file can be unzipped
    unzip_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, 'tests', True)
    assert os.path.exists(unzip_path)

    # Check that a zip file can be unzipped locally if the file exists
    unzip_path = unzip('tests/repo-templates/foo-master.zip', False, 'tests', True)
    assert os.path.exists(unzip_path)

    # Check that unzipping an invalid zip file raises an exception

# Generated at 2022-06-21 11:09:16.798474
# Unit test for function unzip
def test_unzip():
    """Test for unzip function"""
    import subprocess
    import filecmp
    import shutil
    import os

    subprocess.call(["rm","-rf","testdir"])
    try:
        os.mkdir("testdir")
    except:
        pass
    os.chdir("testdir")

    #test zip downloading from github
    zip_uri="https://github.com/pytest-dev/cookiecutter-pytest-plugin/archive/master.zip"
    unzip_path=unzip(zip_uri,True,clone_to_dir='.',no_input=True, password=None)
    shutil.rmtree(unzip_path)
    zip_uri="https://github.com/cookiecutter/cookiecutter/archive/master.zip"

# Generated at 2022-06-21 11:09:17.676667
# Unit test for function unzip
def test_unzip():
    # TODO: Test real zip
    pass

# Generated at 2022-06-21 11:09:18.466705
# Unit test for function unzip
def test_unzip():
    assert True

# Generated at 2022-06-21 11:09:29.173712
# Unit test for function unzip
def test_unzip():
    import filecmp
    extract_path = '.'
    t = tempfile.mkdtemp()
    zip_path = os.path.join(t, 'download_and_extract_zip.zip')
    shutil.copy('tests/test-repo-tmpl/some-repo.zip', zip_path)
    unzip_path = unzip(zip_path, False, extract_path)
    assert os.listdir(unzip_path) == os.listdir('tests/test-repo-tmpl/some-repo')
    assert filecmp.dircmp(unzip_path, 'tests/test-repo-tmpl/some-repo')
    shutil.rmtree(t)

# Generated at 2022-06-21 11:09:35.739754
# Unit test for function unzip
def test_unzip():
    # Enter your own username and password to run test on your own repository.
    # The repository must be password protected.
    zip_uri = 'https://github.com/RaghavPrabhu/cookiecutter-pypackage-min/archive/master.zip'
    clone_to_dir = '.'
    is_url = True
    unzip_path = unzip(zip_uri, is_url, clone_to_dir, password=password)

    assert unzip_path is not None

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:09:46.312917
# Unit test for function unzip
def test_unzip():
    import pytest
    import urllib.parse
    import zipfile

    from cookiecutter.operator import get_zip_file
    from cookiecutter.utils import rmtree

    url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'

    clone_to_dir = tempfile.mkdtemp()
    zip_uri = '{}/master.zip'.format(clone_to_dir)

    r = requests.get(url)
    with open(zip_uri, 'wb') as f:
        f.write(r.content)
    unzip_path = unzip(url, True, clone_to_dir=clone_to_dir)

# Generated at 2022-06-21 11:09:48.891105
# Unit test for function unzip
def test_unzip():
    print(unzip('test/test-repo.zip', is_url=False, clone_to_dir='~'))

test_unzip()

# Generated at 2022-06-21 11:09:58.649000
# Unit test for function unzip
def test_unzip():
    from cookiecutter import utils
    import os
    # Create test directory, write file, and zip it
    # We'll use the file's contents to know that the data was extracted
    # correctly
    test_data = b'Test data'
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    with open('test.txt', 'wb') as f:
        f.write(test_data)
    utils.make_zipfile(
        'test.zip',
        'test.txt')
    # Process the zip file

# Generated at 2022-06-21 11:10:06.127131
# Unit test for function unzip
def test_unzip():
	import pytest

	zip_uri = "https://github.com/jacebrowning/template-python/archive/master.zip" 
	is_url = True
	clone_to_dir = '.'
	no_input = True
	password = None
	with pytest.raises(InvalidZipRepository):
		unzip(zip_uri,is_url,clone_to_dir='.',no_input=True,password=True)



# Generated at 2022-06-21 11:10:07.181499
# Unit test for function unzip
def test_unzip():
    # test unzip function
    pass

# Generated at 2022-06-21 11:10:42.779580
# Unit test for function unzip
def test_unzip():
    import unittest
    import shutil
    import requests
    import sys
    import os
    

# Generated at 2022-06-21 11:10:52.404919
# Unit test for function unzip
def test_unzip():
    """ Test the function unzip, which downloads and unpacks a zipfile."""
    import shutil
    import zipfile
    from cookiecutter.compat import open

    # Create a tmp directory,
    tmp_dir = tempfile.mkdtemp()

    # Copy the test zip file to tmp directory
    test_zip_file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'tests', 'test-repo.zip')
    test_zip_file_new = os.path.join(tmp_dir, 'test-repo.zip')
    shutil.copyfile(test_zip_file, test_zip_file_new)

    # Create an empty zip file

# Generated at 2022-06-21 11:10:59.875932
# Unit test for function unzip
def test_unzip():
    """Test the unzip function.
    """

    # Test unzipping a repository with a top level directory
    testzipdir = os.path.dirname(__file__)
    testzip = os.path.join(testzipdir, 'testzip')
    unzip_path = unzip(testzip, False)
    assert os.path.exists(unzip_path)
    assert os.path.isdir(unzip_path)

    # Test unzipping a repository without a top-level directory
    testinvalidzip = os.path.join(testzipdir, 'invalidtestzip')
    try:
        unzip(testinvalidzip, False)
    except InvalidZipRepository:
        pass
    else:
        raise AssertionError('Invalid zip repository did not throw exception')

# Generated at 2022-06-21 11:11:08.521361
# Unit test for function unzip
def test_unzip():
    zipname = 'tests/test-zip.zip'
    project_name = os.path.abspath('tests/test-zip')
    downloaded_zip_path = os.path.abspath('tests/test-zip.zip')
    assert os.path.exists(project_name) == True
    assert os.path.exists(zipname) == True
    assert os.path.exists(downloaded_zip_path) == False

    unzip(zipname, False)
    assert os.path.exists(downloaded_zip_path) == True
    assert os.path.exists(project_name) == True

# Generated at 2022-06-21 11:11:17.864981
# Unit test for function unzip
def test_unzip():
    # Test for unzip code
    
    # Testing for normal case
    unzip_path = unzip(zip_uri="/home/nikhil/Desktop/miscellaneous/flask-master.zip", is_url=False, clone_to_dir="/home/nikhil/Desktop/miscellaneous", no_input=False, password=None)
    assert(unzip_path == "/home/nikhil/Desktop/miscellaneous/flask-master")
    
    
    try:
        # Testing for case when zipfile is empty
        unzip_path = unzip(zip_uri="/home/nikhil/Desktop/miscellaneous/test.zip", is_url=False, clone_to_dir="/home/nikhil/Desktop/miscellaneous", no_input=False, password=None)
    except:
        assert(1)


# Generated at 2022-06-21 11:11:18.530447
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:11:28.284311
# Unit test for function unzip
def test_unzip():
    # Create a temporary directory to store the zip files.
    import shutil
    import tempfile
    import zipfile
    tempdir = tempfile.mkdtemp()
    zip_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    zip_file = 'cookiecutter-pypackage.zip'
    zip_path = os.path.join(tempdir, zip_file)

    # Download the zipfile.
    r = requests.get(zip_url, stream=True)
    with open(zip_path, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:  # filter out keep-alive new chunks
                f.write(chunk)

    # Test the unzip function by asserting

# Generated at 2022-06-21 11:11:29.848225
# Unit test for function unzip
def test_unzip():
    """Simple unit test for function unzip"""
    assert unzip(os.getcwd(), False) is not None

# Generated at 2022-06-21 11:11:38.592765
# Unit test for function unzip
def test_unzip():
    import os
    import tempfile
    import shutil


# Generated at 2022-06-21 11:11:39.383213
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:12:37.666458
# Unit test for function unzip
def test_unzip():
    # TODO: test all cases we have to handle,
    #       - invalid zip files
    #       - empty zip files
    #       - zip files without a top level directory
    #       - protected password zip files
    pass


# Generated at 2022-06-21 11:12:43.415054
# Unit test for function unzip
def test_unzip():
    # Assert that a valid zip archive is correctly unpacked
    unzipped_location = unzip('pytest.zip', False)
    assert os.path.isdir(unzipped_location)
    zip_contents = os.listdir(unzipped_location)
    assert 'pytest/' in zip_contents
    assert 'pytest/pytest.yaml' in zip_contents


# Generated at 2022-06-21 11:12:51.473901
# Unit test for function unzip
def test_unzip():
    import random
    import string
    import shutil
    from uuid import uuid4
    from cookiecutter.utils import generate_files

    # Create random zip file name
    zip_file = uuid4().hex + '.zip'
    # Create temp file system
    tmpdir = os.path.join(tempfile.gettempdir(), uuid4().hex)
    # Create temp dir
    os.mkdir(tmpdir)
    os.chdir(tmpdir)
    # Create zip file
    test_template = generate_files(tmpdir)
    shutil.make_archive(zip_file, 'zip', tmpdir)
    # Unzip test
    unzip_path = unzip(zip_file + '.zip', False)
    assert os.path.isdir(unzip_path)
    assert os.path.isf

# Generated at 2022-06-21 11:12:58.254963
# Unit test for function unzip
def test_unzip():
    import pytest
    from cookiecutter.config import DEFAULT_REPOSITORY_DIR
    from cookiecutter.main import cookiecutter

    tar_uri = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    result = cookiecutter(tar_uri, no_input=True)
    assert result['repo_dir'] == os.path.join(DEFAULT_REPOSITORY_DIR, 'cookiecutter-pypackage.zip')
    assert os.path.exists(result['repo_dir'])

    # Test that the zipfile can be re-downloaded and remain valid
    result = cookiecutter(tar_uri, no_input=True)
    assert os.path.exists(result['repo_dir'])

    # Test that zipfile doesn't

# Generated at 2022-06-21 11:13:09.256383
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    from cookiecutter.exceptions import InvalidZipRepository

    zip_uri = 'https://github.com/cookiecutter/cookiecutter/archive/master.zip'
    is_url = True
    clone_to_dir = 'tests/files'
    no_input = True

    # Test successful download and unzip

# Generated at 2022-06-21 11:13:20.787979
# Unit test for function unzip
def test_unzip():
    import pytest
    from random import randint

    from cookiecutter import utils

    @pytest.mark.parametrize(
        'zip_uri, is_url',
        [('http://github.com/audreyr/cookiecutter-pypackage/zipball/master', True), 
        ('audreyr/cookiecutter-pypackage/zipball/master', False)],
    )
    def test_unzip_runs(monkeypatch, zip_uri, is_url):
        repo_dir = 'tests/repo-tmps'
        monkeypatch.setattr('zipfile.ZipFile', lambda x: None)
        monkeypatch.setattr('cookiecutter.utils.make_sure_path_exists', lambda x: None)

# Generated at 2022-06-21 11:13:29.452041
# Unit test for function unzip
def test_unzip():
    import shutil
    try:
        shutil.rmtree('/tmp/cookiecutter-test')
    except OSError:
        pass

    try:
        make_sure_path_exists('/tmp/cookiecutter-test')

        unzip_path=unzip('https://github.com/tuvistavie/cookiecutter-html-paper/archive/master.zip', True, '/tmp/cookiecutter-test')
        assert os.path.exists(unzip_path)
    finally:
        shutil.rmtree('/tmp/cookiecutter-test')

# Generated at 2022-06-21 11:13:33.419741
# Unit test for function unzip
def test_unzip():
    unzip('/home/johndoe/cookiecutter-my-project', False, '.', False, '12345678')
    unzip('.', False, '.', False, '12345678')


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:13:39.805662
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    clone_to_dir = '/tmp'
    is_url = True
    no_input = False
    password = None
    unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    assert os.path.isdir(unzip_path) == True
    assert os.path.basename(unzip_path) == 'cookiecutter-pypackage-master'

# Generated at 2022-06-21 11:13:40.903100
# Unit test for function unzip
def test_unzip():
    string = 'unzip'
    assert string == 'unzip'