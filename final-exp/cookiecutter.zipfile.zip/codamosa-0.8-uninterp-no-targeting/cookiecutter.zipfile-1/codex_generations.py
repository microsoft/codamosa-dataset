

# Generated at 2022-06-21 11:04:40.573171
# Unit test for function unzip
def test_unzip():
    """Test for the unzip() function."""
    import shutil
    from cookiecutter import main
    from cookiecutter.main import cookiecutter
    from .sample_projects import zip_repo

    zip_uri = zip_repo

    # Main function can't be called without a template to use.
    # Create a temporary one.
    tmp_dir = tempfile.mkdtemp()
    main.cookiecutter(zip_repo, no_input=True, output_dir=tmp_dir)
    shutil.rmtree(tmp_dir)

    # Now we can safely call unzip()
    unzip_path = unzip(zip_uri, True, clone_to_dir=tmp_dir, no_input=True)

    # Let's check the contents of the unpacked directory

# Generated at 2022-06-21 11:04:49.779896
# Unit test for function unzip
def test_unzip():
    """
    test unzip function
    :return:
    """
    zip_uri = 'https://github.com/tqh_2017/cookiecutter-pypackage-min/archive/master.zip'
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = None
    return unzip(zip_uri, is_url, clone_to_dir, no_input, password)

if __name__ == '__main__':
    res = test_unzip()
    print(res)

# Generated at 2022-06-21 11:04:59.984417
# Unit test for function unzip
def test_unzip():
    """Function unzip is tested"""
    import shutil

    shutil.rmtree('tests/files/fake-repo-dist', ignore_errors=True)
    clone_to_dir = 'tests/files/fake-repo-dist'

    # Test no_input option
    unzip('tests/files/fake-repo.zip', False, clone_to_dir, no_input=True)

    # Test encrypted zip file
    unzip('tests/files/test_repo_2.zip', False, clone_to_dir, password='secret')

    # Test encrypted zip file with wrong password
    try:
        unzip('tests/files/test_repo_2.zip', False, clone_to_dir, password='wrong')
    except InvalidZipRepository:
        pass

    # Remove fake-repo-dist

# Generated at 2022-06-21 11:05:10.616965
# Unit test for function unzip
def test_unzip():
    """Build a zip archive and then unzip it using the unzip() function."""
    # Set up the zipfile
    zip_path = 'tests/test-repo.zip'
    zip_name = 'cookiecutter-test-repo'

    # Ensure that the zipfile doesn't already exist
    if os.path.exists(zip_path):
        os.remove(zip_path)

    # Create the archive
    import zipfile
    zip_file = zipfile.ZipFile(zip_path, 'w')
    # ZipFile.write() requires paths, so we can't use the
    # os.path.join() format.
    zip_file.write('tests/test-repo', zip_name)
    zip_file.close()

    # Now unzip the archive using the unzip() function
    unzip_

# Generated at 2022-06-21 11:05:12.869465
# Unit test for function unzip
def test_unzip():
    assert unzip("cookiecutter-master.zip", False)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:05:14.732973
# Unit test for function unzip
def test_unzip():
    assert unzip("test.zip") == os.getcwd()

# Generated at 2022-06-21 11:05:15.410131
# Unit test for function unzip
def test_unzip():
    assert True

# Generated at 2022-06-21 11:05:20.627459
# Unit test for function unzip
def test_unzip():
    assert(unzip("https://github.com/hqshah/cookiecutter-pypackage/archive/0.1.8.zip",True))
    assert(unzip("/Users/haresh.shah/Downloads/cookiecutter-pypackage-0.1.8.zip",False))
    assert(unzip("https://github.com/hqshah/cookiecutter-pypackage.git",False))==None

# Generated at 2022-06-21 11:05:29.089482
# Unit test for function unzip
def test_unzip():
    """ Test unzip function for valid and invalid zip files"""
    # Unzip the valid zip file
    unzip("tests/test-data/unzip_test.zip", False)
    try:
        # Unzip the invalid zip file
        unzip("tests/test-data/unzip_test_error.zip", False)
    except InvalidZipRepository:
        #pass
        print("Invaid zip file")
    # Unzip the valid password protected zip file
    unzip("tests/test-data/unzip_test_password.zip", False, password="test")
    try:
        # Unzip the invalid password protected zip file
        unzip("tests/test-data/unzip_test_password_error.zip", False, password="error")
    except InvalidZipRepository:
        #pass
        print("Invalid password")

# Generated at 2022-06-21 11:05:34.294656
# Unit test for function unzip
def test_unzip():
    import os
    import sys
    import shutil

    # Local repository
    verification_folder = '.verification'
    base_zip_path = 'tests/fixtures/fake-repo-tmpl'
    zip_path = os.path.abspath('tests/fixtures/fake-repo-tmpl.zip')
    base_unzip_path = os.path.abspath(verification_folder)
    unzip_path = os.path.abspath(verification_folder + '/fake-repo-tmpl')

    # Downloaded repository
    base_clone_to_dir = 'tests/fixtures/fake-repo-tmpl'
    base_dl_zip_path = base_clone_to_dir +'/master.zip'

# Generated at 2022-06-21 11:05:46.905379
# Unit test for function unzip
def test_unzip():
    # This test is currently skipped.
    #
    # An automated test for this would normally involve checking the
    # content of the zip file, which would require us to provide a
    # known zip file.
    #
    # Instead, this should be tested manually.
    pass

# Generated at 2022-06-21 11:05:54.345915
# Unit test for function unzip
def test_unzip():
    """Test function unzip"""
    # pylint: disable=unused-variable

    # Test without password
    # zipped_folder_path = 'test/test_file_repo/v1.zip'
    # unzip_path = unzip(zipped_folder_path, is_url=False, clone_to_dir='test/test_file_repo/zip-downloads/')
    # print('Unzipped folder path: {}'.format(unzip_path))
    #
    # # Test with password
    # zipped_folder_path = 'test/test_file_repo/v2.zip'
    # unzip_path = unzip(zipped_folder_path, is_url=False, clone_to_dir='test/test_file_repo/zip-downloads/', password='My

# Generated at 2022-06-21 11:06:04.475109
# Unit test for function unzip
def test_unzip():
    # Test on a valid Zip URI
    result = unzip('https://github.com/wdm0006/cookiecutter-pypackage-min/archive/master.zip','Y')
    assert os.path.exists(result)
    # Test on a valid local Zip file
    result = unzip('https://github.com/wdm0006/cookiecutter-pypackage-min/archive/master.zip','N')
    assert os.path.exists(result)
    # Test on an invalid Zip file
    try:
        result = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip','Y')
    except InvalidZipRepository as e:
        assert 'Zip repository is not a valid zip archive' in str(e)
    # Test on an empty Zip

# Generated at 2022-06-21 11:06:11.895492
# Unit test for function unzip
def test_unzip():
    temp_zip_path = os.path.join(os.path.dirname(__file__), '..', 'tests', 'files', 'tmp_repo.zip')
    temp_dir_path = tempfile.mkdtemp()
    unzip_path = unzip(temp_zip_path, False, temp_dir_path, no_input=True)
    temp_files = ['repo_files', 'files_files']
    for file in temp_files:
        t_file = os.path.join(unzip_path, file)
        assert os.path.isfile(t_file)



# Generated at 2022-06-21 11:06:17.345876
# Unit test for function unzip
def test_unzip():
    import shutil
    from .repo import determine_repo_dir
    zip_path = os.path.join(determine_repo_dir(), 'tests/test-repo.zip')
    unzip_path = unzip(zip_path, False)
    shutil.rmtree(unzip_path)
    assert os.path.exists(unzip_path)

# Generated at 2022-06-21 11:06:17.922623
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:06:28.892153
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    from urllib.parse import urljoin
    from requests.exceptions import MissingSchema
    from . import version
    from .exceptions import FailedHookException
    from .main import cookiecutter

    # Repository without directories
    with tempfile.TemporaryDirectory() as tempdir:
        cookiecutter(
            urljoin(
                'https://github.com/',
                'audreyr/cookiecutter-pypackage/archive/{}.zip'.format(version.__version__),
            ),
            output_dir=tempdir,
            no_input=True,
            overwrite_if_exists=True,
        )
        cookiecutter.basedir = tempdir
        assert 'Checking contents' not in cookiecutter.output

# Generated at 2022-06-21 11:06:36.642921
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    clone_to_dir = tempfile.mkdtemp()
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/develop'
    unpacked = unzip(zip_uri, is_url=True, clone_to_dir=clone_to_dir)
    assert os.path.exists(unpacked), "zip file not unpacked"
    # cleanup
    shutil.rmtree(clone_to_dir)

# Generated at 2022-06-21 11:06:40.578083
# Unit test for function unzip
def test_unzip():
    from cookiecutter import __version__

    if __version__ == '0.5.5':
        pass # Fix zip 'password protected' error
    else:
        assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, password='')

# Generated at 2022-06-21 11:06:50.555335
# Unit test for function unzip
def test_unzip():
    """
    Simple test to see if a zip file can be unzipped to a temporary directory
    """
    # unzip the 'cookiecutter-pypackage' template from remote url
    unzip_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)

    # assert that the template has been unzipped to a temporary directory
    assert os.path.exists(unzip_path)

    # assert that the project name is present in the temporary directory
    assert os.path.isdir(os.path.join(unzip_path, 'cookiecutter-pypackage-master'))

    # delete the temporary directory
    os.rmdir(unzip_path)

    # unzip the 'cookiecutter-pypackage' template from local

# Generated at 2022-06-21 11:07:20.164621
# Unit test for function unzip
def test_unzip():
    from zipfile import ZipFile

    cwd = os.getcwd()
    archive_name = 'cookiecutter-pypackage.zip'
    dir_name = 'cookiecutter-pypackage'

    # Create a temporary directory and a path to a zip archive
    tmp_dir = tempfile.mkdtemp()
    archive_path = os.path.join(tmp_dir, archive_name)

    # Create a zip archive with a cookiecutter template
    os.chdir(cwd)
    with ZipFile(archive_path, 'w') as myzip:
        myzip.write(dir_name)

    # Create a temporary directory to unzip the archive
    unzip_base = tempfile.mkdtemp()
    unzip_path = os.path.join(unzip_base, dir_name)



# Generated at 2022-06-21 11:07:20.972698
# Unit test for function unzip
def test_unzip():
    """Check whether the unzip function works
    """
    # TODO Auto-generated method stub



# Generated at 2022-06-21 11:07:24.308286
# Unit test for function unzip
def test_unzip():
    unzip("https://github.com/frojd/cookiecutter-django-paas/archive/master.zip",
          is_url=True)

# Generated at 2022-06-21 11:07:36.563791
# Unit test for function unzip
def test_unzip():
    """
    test function unzip
    """
    from cookiecutter.config import DEFAULT_REPO_DIR
    import shutil
    no_input = True
    add_password = True
    # Get the location of the cookiecutters repo, and create an archive
    cookiecutters_zip = os.path.join(DEFAULT_REPO_DIR, "cookiecutter-bootstrap.zip")
    if os.path.exists(cookiecutters_zip):
        # Create a temporary folder to store the unarchived items
        archive_dir = tempfile.mkdtemp()
        clone_dir = '.'
        # Unzip the archive and store in the temporary folder
        unzip_path = unzip(cookiecutters_zip, 'file', clone_dir, no_input, add_password)
        # Read the contents of the archive

# Generated at 2022-06-21 11:07:46.241337
# Unit test for function unzip
def test_unzip():
    import shutil
    import json
    import subprocess
    import time
    import re

    # Creating a test repository with password
    password = 'test_password'
    with tempfile.NamedTemporaryFile('w+', prefix='zip_repository', suffix='.zip', delete=False) as f:
        f.write('test_zip')
        f.seek(0)
        res = subprocess.call(['zip', '--encrypt', '-e', '--password', password, f.name])
        assert res == 0

    # Unzip successful repository
    unzip_path = unzip(f.name, is_url=False, no_input=True, clone_to_dir='.', password=password)

# Generated at 2022-06-21 11:07:47.303618
# Unit test for function unzip
def test_unzip():
    unzip('/home/user/cookiecutter-python', False)

# Generated at 2022-06-21 11:07:54.784327
# Unit test for function unzip
def test_unzip():
    import pytest
    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',True)
    #assert unzip('https://github.com/yutang/cookiecutter-unicore-cms-app/archive/unicore-cms-app.zip',True)
    #assert unzip('https://github.com/yutang/cookiecutter-unicore-cms-app/archive/unicore-cms-app.zip',False)

# Generated at 2022-06-21 11:08:05.955038
# Unit test for function unzip
def test_unzip():
    import pytest
    from zipfile import ZipFile
    from cookiecutter.main import cookiecutter
    from os import path
    import urllib.request

    urllib.request.urlretrieve(
        'https://github.com/astronouth7303/cookiecutter-example/archive/gh-pages.zip',
        'gh-pages.zip')

    def _test_unzip_zip_file(zip_path):
        with open(zip_path, 'rb') as f:
            z = ZipFile(f)
            assert z.testzip() is None

        assert unzip(zip_path, False, '.')

    def _test_unzip_no_input_zip_file(zip_path):
        with open(zip_path, 'rb') as f:
            z = ZipFile(f)

# Generated at 2022-06-21 11:08:17.433581
# Unit test for function unzip
def test_unzip():
    import requests_mock
    import shutil
    import tempfile
    from pathlib import Path
    from cookiecutter.prompt import read_repo_password

    uri = 'https://github.com/astronomerio/cookiecutter-airflow-dag/archive/v0.0.0.zip'
    is_url = True
    clone_to_dir = tempfile.mkdtemp()
    no_input = False
    password = 'test'

    with requests_mock.mock() as m:
        m.get(uri, text='test', stream=True)
        zip_path = unzip(uri, is_url, clone_to_dir=clone_to_dir, no_input=no_input, password=password)
        assert zip_path is not None
        assert zip_path.start

# Generated at 2022-06-21 11:08:28.582056
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    from zipfile import ZipFile
    from cookiecutter.utils import unzip
    from cookiecutter.utils import make_sure_path_exists

    # Create a temp directory and copy the test template archive there
    tmp_dir = tempfile.TemporaryDirectory()

    this_dir = os.path.dirname(os.path.realpath(__file__))
    test_archive = os.path.join(this_dir, 'files', 'tests', 'test-archive.zip')
    archive_path = os.path.join(tmp_dir.name, 'test-archive.zip')
    shutil.copyfile(test_archive, archive_path)

    # Create a temp directory to hold the unzip
    unzip_dir = tempfile.mkdtemp()

    #

# Generated at 2022-06-21 11:09:09.400408
# Unit test for function unzip
def test_unzip():
    zip_path = "./tests/test-repo.zip"
    unzip(zip_path, False, clone_to_dir='./')

# Generated at 2022-06-21 11:09:10.282554
# Unit test for function unzip
def test_unzip():
    pass


# Generated at 2022-06-21 11:09:11.874319
# Unit test for function unzip
def test_unzip():
    zipfile = 'test_file.zip'
    unzip(zipfile, False)

# Generated at 2022-06-21 11:09:15.865341
# Unit test for function unzip
def test_unzip():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    unzip_path = unzip(dir_path+"/archives/test.zip", False)
    assert os.path.exists(unzip_path)


# Main for fetch_repo function
if __name__ == '__main__':
    print(unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True))

# Generated at 2022-06-21 11:09:27.536360
# Unit test for function unzip
def test_unzip():
    # unzip from url, not exist, no_input=False, no password
    zip_uri='http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url=True
    clone_to_dir='.'
    no_input=False
    password=None
    test_unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    assert test_unzip_path.startswith('/tmp/')
    # unzip from url, exist, no_input=True, no password
    zip_uri='http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url=True
    clone_to_dir='.'
    no_input=True

# Generated at 2022-06-21 11:09:36.545219
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    import doctest
    import os
    import shutil
    import urllib.parse
    import tempfile

    from .main import WORKING_DIR

    current_dir = os.getcwd()

    # Create a temp dir to store test results
    temp_dir = tempfile.mkdtemp()

    os.chdir(temp_dir)
    # Create the base directory and subfolders
    make_sure_path_exists(WORKING_DIR)
    clone_to_dir = os.path.join(temp_dir, 'repo')
    make_sure_path_exists(clone_to_dir)

    # Prepare a test zipfile
    test_zipfile, test_zipfile_path = tempfile.mkstemp(suffix='.zip')
    test_zip

# Generated at 2022-06-21 11:09:41.295892
# Unit test for function unzip
def test_unzip():
    unzip('/home/srinivas/srinivas/projects/python/cookiecutter/tests/fake-repo-tmpl',
          False,
          '/home/srinivas/srinivas/projects/python/cookiecutter/tests/fake-repo',
          True)

# Generated at 2022-06-21 11:09:52.206805
# Unit test for function unzip
def test_unzip():
    # Arrange
    import shutil
    from cookiecutter.config import DEFAULT_CONFIG

    from .vendor import mock


    mock_is_url = mock.patch('cookiecutter.vcs.git.is_url').start()
    mock_prompt_and_delete = mock.patch(
        'cookiecutter.utils.prompt_and_delete'
    ).start()

    config_dict = DEFAULT_CONFIG
    config_dict['cookiecutters_dir'] = os.path.join('tests', 'fake-repo-tmpl')
    config = mock.Mock(**config_dict)

    mock_is_url.return_value = True
    mock_prompt_and_delete.return_value = True

    # Act

# Generated at 2022-06-21 11:10:00.208217
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip
    """
    import os
    import shutil
    GENERIC_ZIP = os.path.dirname(__file__) + '/files/archive.zip'
    GENERIC_ZIP_SUBDIR = os.path.dirname(__file__) + '/files/archive1.zip'
    PROTECTED_ZIP = os.path.dirname(__file__) + '/files/protected.zip'
    DESTDIR = os.path.dirname(__file__) + '/files/test_unzip'
    if os.path.exists(DESTDIR):
        shutil.rmtree(DESTDIR)
    os.mkdir(DESTDIR)
    unzip_path = unzip(GENERIC_ZIP, False, DESTDIR)
    un

# Generated at 2022-06-21 11:10:08.904150
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',True, '.', True)
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '.', True, 'testpassword')
    try:
        unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '.', True, 'wrongpassword')
    except InvalidZipRepository:
        pass

# Generated at 2022-06-21 11:10:43.359747
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    from cookiecutter.utils import temp_chdir
    from cookiecutter import config
    from cookiecutter.repository import determine_repo_dir

    # check if function unzip return proper value
    # for valid zip file
    with temp_chdir():
        config.replay = False
        temp = tempfile.mkdtemp()
        unzip_path = unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", True)
        try:
            assert unzip_path[:len(temp)] == temp
            assert os.path.exists('README.rst')
        finally:
            shutil.rmtree(temp)

    # check if function unzip return proper value
    # for inexistent zip file
   

# Generated at 2022-06-21 11:10:49.311289
# Unit test for function unzip
def test_unzip():
    """
    smoketest
    """
    test_zipfile_location = os.path.join(
        os.getcwd(),
        "tests",
        "test-repo-templates",
        "pyproj-j2-bin.zip"
    )
    unzip(test_zipfile_location,
          is_url=False,
          clone_to_dir='.',
          no_input=False,
          password=None)
    assert True

# Generated at 2022-06-21 11:10:58.134496
# Unit test for function unzip
def test_unzip():
    """Test downloading a zip archive and then unzipping it."""
    # First create the zipfile with a unique name
    (zip_file, zip_path) = tempfile.mkstemp()
    os.close(zip_file)

    # Create a zipfile containing a single directory 'example-repo'
    # with file 'testfile.txt'

# Generated at 2022-06-21 11:11:09.396294
# Unit test for function unzip
def test_unzip():
    import mock
    from tempfile import mkdtemp
    import shutil
    import requests

    def mock_requests_get(url, *args, **kwargs):
        filename = os.path.basename(url)
        temp_zip_file = os.path.join(temp_zip_dir, filename)
        if not os.path.exists(temp_zip_file):
            raise Exception('The mock resource {} was not found'.format(url))
        with open(temp_zip_file, 'rb') as f:
            return f.read()

    requests_backup = requests.get
    requests.get = mock_requests_get

    temp_zip_dir = mkdtemp()
    temp_zip_name = os.path.join(temp_zip_dir, 'test_repo.zip')

# Generated at 2022-06-21 11:11:16.403142
# Unit test for function unzip
def test_unzip():
    # TODO : Test unzip with a real password
    # (i.e., one that's NOT 'Cookiecutter Rocks!')
    zip_base = os.path.abspath(os.path.join(
        os.path.dirname(__file__), 'repo-tmpl'
    ))
    zip_uri = os.path.join(zip_base, 'cookiecutter-pypackage.zip')
    unzip(zip_uri, False)
    unzip(zip_uri, False, no_input=True)

    # TODO : Add tests for various bad zip files

# Generated at 2022-06-21 11:11:26.519223
# Unit test for function unzip
def test_unzip():
    import shutil
    import os
    import requests
    import cookiecutter
    import filecmp
    import tempfile
    import sys
    import zipfile
    import shutil
    import subprocess
    import sys
    import os

    #Get repo from GitHub to local drive
    repo_dir = os.path.join(os.path.dirname(cookiecutter.__file__),
                               'replay_data', 'test-repo-replay-data')

    # Zip it up
    repo_name = "test-repo-replay-data"
    zip_name = repo_name + ".zip"
    zip_path = os.path.join(os.path.dirname(cookiecutter.__file__),
                            'replay_data', zip_name)

# Generated at 2022-06-21 11:11:27.236944
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:11:35.296735
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    import shutil
    import tempfile
    import zipfile

    def zipfolder(foldername, archive_name):
        zipobj = zipfile.ZipFile(archive_name, 'w', zipfile.ZIP_DEFLATED)
        rootlen = len(foldername) + 1
        for base, dirs, files in os.walk(foldername):
            for file in files:
                fn = os.path.join(base, file)
                zipobj.write(fn, fn[rootlen:])

    # Create a temporary folder and set it as current working directory
    # to be used as a test folder
    tempfolder = tempfile.mkdtemp()
    os.chdir(tempfolder)

    # Create a test folder with a dummy file

# Generated at 2022-06-21 11:11:39.558257
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip"""
    print("Testing unzip")
    temp_path = unzip("tests/fixtures/files/toto.zip", False)
    print(temp_path)
    assert os.path.isdir(temp_path)
    cleanup(temp_path)



# Generated at 2022-06-21 11:11:48.992206
# Unit test for function unzip
def test_unzip():
    import os, sys
    import shutil

    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    result = unzip(zip_uri, True, '.', False)
    assert os.path.exists(result)
    shutil.rmtree(result)

    zip_uri = os.path.join(os.path.dirname(os.path.dirname(sys.argv[0])), 'tests', 'test-repo.zip')
    result = unzip(zip_uri, False, '.', False)
    assert os.path.exists(result)
    shutil.rmtree(result)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:12:45.208930
# Unit test for function unzip
def test_unzip():
    assert unzip


# Generated at 2022-06-21 11:12:53.547261
# Unit test for function unzip
def test_unzip():
    class _MockZipFile:
        def __init__(self, namelist):
            self.namelist = namelist

        def extractall(self, *args, **kwargs):
            pass

    zip_uri = '~/zipfile'
    is_url = False
    clone_to_dir='~/clone_to_dir'
    no_input = False
    password='test_password'


# Generated at 2022-06-21 11:12:54.294408
# Unit test for function unzip
def test_unzip():
    assert unzip('/tmp/foo.zip', False)

# Generated at 2022-06-21 11:13:00.062119
# Unit test for function unzip
def test_unzip():
    from zipfile import ZipFile
    from io import BytesIO
    from io import StringIO
    import cookiecutter
    import shutil
    import tempfile
    import pytest
    import os.path
    import os
    import unittest
    import requests

    class UnzipFunctionTests(unittest.TestCase):
        def test_unzip_faulty(self):
            # Test faulty URL
            with pytest.raises(InvalidZipRepository):
                unzip('http://wrong.zip', True, password='wrong')

            with pytest.raises(InvalidZipRepository):
                unzip('not_a_file.zip', False, password='wrong')

            # Test faulty encoding format for password

# Generated at 2022-06-21 11:13:09.869908
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import zipfile

    from cookiecutter.main import find_template
    from cookiecutter.utils import make_sure_path_exists
    from cookiecutter.utils import rmtree

    from . import cookiecutter as cookiecutterpy

    # Check that non-existing zip file raises IOError
    try:
        unzip('foo', True)
    except InvalidZipRepository:
        pass
    else:
        raise Exception("IOError not raised for non-existing zip file.")

    # Check that corrupted zip file raises IOError
    corrupted_zip = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'corrupted.zip')
    try:
        unzip(corrupted_zip, False)
    except InvalidZipRepository:
        pass

# Generated at 2022-06-21 11:13:16.595249
# Unit test for function unzip
def test_unzip():
    test_path = 'tests/files/input/tests/{{cookiecutter.repo_name}}'
    zip_file = os.path.join(test_path, 'tests_repo.zip')
    unzip(zip_uri=zip_file, is_url=False)
    unzip(zip_uri=zip_file, is_url=False, password='tests')

# Generated at 2022-06-21 11:13:23.825390
# Unit test for function unzip
def test_unzip():
    import os
    import pytest
    from .test_utils import TEST_USER_CONFIG

    tmpdir = TEST_USER_CONFIG['replay_dir']
    archive = 'https://github.com/audreyr/cookiecutter-pypackage/archive/1.0.1.zip'

    zip_path = os.path.join(tmpdir, 'test.zip')
    with open(zip_path, 'wb') as f:
        assert os.path.isfile(zip_path)
        f.write(b'bogus zip file')
    with pytest.raises(InvalidZipRepository) as e:
        unzip(zip_path, is_url=False)
    assert 'is not a valid zip archive' in e.value.error


# Generated at 2022-06-21 11:13:34.210845
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip."""

    import pytest
    import requests_mock

    from cookiecutter.utils import patch
    from cookiecutter.utils import rmtree

    test_dir = patch('cookiecutter.repository.utils.os.getcwd')
    test_dir.return_value = os.path.join(
        os.path.dirname(__file__), 'test_utils'
    )
    test_dir = os.path.abspath(os.path.join(
        os.path.dirname(__file__), 'test_utils'
    ))

    # Test the download and unzip URL case

# Generated at 2022-06-21 11:13:38.938519
# Unit test for function unzip
def test_unzip():
    from cookiecutter import main
    from cookiecutter.main import cookiecutter

    # Download a cookiecutter template locally
    password = '1234'
    cookiecutter('https://github.com/cookiecutter-archive/cookiecutter-pypackage.git',
                '--password', password, '--no-input')

    # Unzip the downloaded file
    zip_uri = '~/.cookiecutters/cookiecutter-pypackage.zip'
    unzip(zip_uri, False, no_input=True, password=password)

# Generated at 2022-06-21 11:13:44.173741
# Unit test for function unzip
def test_unzip():
    is_url = True
    clone_to_dir = '.'
    zip_uri = 'https://api.github.com/repos/cookiecutter/cookiecutter-audreyr/zipball/v0.1.1'
    unzip_path = unzip(zip_uri, is_url, clone_to_dir)
    assert unzip_path