

# Generated at 2022-06-21 11:04:43.584653
# Unit test for function unzip
def test_unzip():
    # testing unzip function
    import shutil
    import requests
    import os
    import pytest
    from cookiecutter.utils import make_sure_path_exists
    from cookiecutter.repository import unzip
    from cookiecutter.exceptions import InvalidZipRepository
    import urllib.request
    import zipfile
    import requests
    import tempfile
    import zipfile
    import shutil
    import os
    import pytest
    from cookiecutter.utils import make_sure_path_exists
    from cookiecutter.repository import unzip
    from cookiecutter.exceptions import InvalidZipRepository

    # Create a repo zip file and a folder with the same name
    url_base = 'https://codeload.github.com/audreyr/{}/zip/master'
    rep

# Generated at 2022-06-21 11:04:51.023821
# Unit test for function unzip
def test_unzip():
    download_url = 'https://github.com/kadnan/cookiecutter-pypackage-min/archive/master.zip'
    is_url = True
    clone_to_dir = './tests/'
    no_input = True
    password = None
    unzip_path = unzip(download_url, is_url,
                    clone_to_dir, no_input, password)
    assert len(unzip_path) > 0

# Generated at 2022-06-21 11:05:00.756703
# Unit test for function unzip
def test_unzip():
    import inspect


# Generated at 2022-06-21 11:05:10.750706
# Unit test for function unzip
def test_unzip():
    print('\n')
    cookiecutter_dir = os.path.dirname(os.path.abspath(__file__))
    test_file_dir = os.path.join(cookiecutter_dir, 'tests', 'test-files')
    # get a valid zip file
    zip_path = os.path.join(test_file_dir, 'valid-zip-file.zip')
    # get an invalid zip file
    invalid_zip_path = os.path.join(test_file_dir, 'invalid-zip-file.zip')
    # get a password protected zip file
    password_zip_path = os.path.join(test_file_dir, 'protected-zip-file.zip')
    # get the password for testing

# Generated at 2022-06-21 11:05:20.868086
# Unit test for function unzip
def test_unzip():
    #import shutil
    #try:
    #    os.remove('/Users/alex/repos/cookiecutter-django/testrepo.zip')
    #except OSError:
    #    pass
    #try:
    #    shutil.rmtree('/Users/alex/repos/cookiecutter-django/testrepo/')
    #except OSError:
    #    pass
    unzip('https://github.com/pydanny/cookiecutter-django/archive/master.zip', True, '/Users/alex/repos/cookiecutter-django')

# Generated at 2022-06-21 11:05:25.201142
# Unit test for function unzip
def test_unzip():
    """Test for unzip function."""
    try:
        unzip(
            zip_uri='https://github.com/The-Lonely-Coder/cookiecu',
            is_url=True,
            clone_to_dir='.',
            no_input=False,
            password='1234'
        )
    except InvalidZipRepository:
          print('Zip file test passed')

# Generated at 2022-06-21 11:05:27.325941
# Unit test for function unzip
def test_unzip():
    assert unzip('/Users/fernandoaleman/cookiecutter-pypackage', True, '/Users/fernandoaleman/', False)

# Generated at 2022-06-21 11:05:33.372791
# Unit test for function unzip
def test_unzip():
    """Unit test for the unzip function."""
    from . import get_user_config
    from . import cleanup

    # Get a user config
    config_dict = get_user_config()
    testing_workdir = os.path.abspath(config_dict['cookiecutters_dir'])

    # Get a zipfile
    is_url = True
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    clone_to_dir = testing_workdir
    password = None

    # Unzip it

# Generated at 2022-06-21 11:05:41.098789
# Unit test for function unzip
def test_unzip():
    from tests.test_replay import TEST_REPO_DIR

    git_test_repo = os.path.join(TEST_REPO_DIR, 'test-repo.git')
    zip_file = os.path.join(TEST_REPO_DIR, 'test-repo.git.zip')

    assert os.path.exists(git_test_repo)
    assert os.path.exists(zip_file)

    # We can't do this test on a system without git so just return
    try:
        subprocess.Popen(['git', '--version'])
    except OSError:
        return True

    # Create a zip file from git repository

# Generated at 2022-06-21 11:05:46.088921
# Unit test for function unzip
def test_unzip():
    import shutil
    try:
        test_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
        result = unzip(test_url, True, 'test')
        assert os.path.exists(result)
    finally:
        shutil.rmtree('test')

# Generated at 2022-06-21 11:05:57.441804
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:06:06.067805
# Unit test for function unzip
def test_unzip():
    from cookiecutter.utils import rmtree
    from zipfile import ZipFile

    name = 'test'
    suffix = '.zip'
    archive = 'Test_Externals/{}{}'.format(name, suffix)
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),archive)
    is_url = False
    unzip_path = unzip(path, is_url)
    fpath = os.path.join(unzip_path, name+'.txt')
    f = open(fpath,'r')
    assert f.read() == 'This is a test file'
    f.close()
    rmtree(unzip_path)

# Generated at 2022-06-21 11:06:16.403932
# Unit test for function unzip
def test_unzip():
    import tempfile, zipfile
    import sys

    def assertEqual(a, b):
        a = os.path.abspath(a)
        b = os.path.abspath(b)
        if not a == b:
            sys.exit(1)

    temp_dir = tempfile.mkdtemp()

    # Create a zipfile in memory for testing purposes
    test_zip_file = tempfile.NamedTemporaryFile(suffix='.zip')
    z = zipfile.ZipFile(test_zip_file.name, mode="w")
    z.writestr("repo/file.txt", "")
    z.close()

    # Perform the extraction
    temp_path = unzip(test_zip_file.name, False, temp_dir)

    # Check that the file was unpacked to

# Generated at 2022-06-21 11:06:27.041018
# Unit test for function unzip
def test_unzip():
    import os
    import unittest
    import shutil
    from zipfile import ZipFile
    from cookiecutter.utils import make_sure_path_exists

    class TestZipRepo(unittest.TestCase):
        """Test the unzip function. Unzip with HTTP.

        """
        @classmethod
        def setUpClass(cls):
            cls.repo_url = 'https://github.com/pygobject/pygobject/archive/master.zip'
            cls.tmp_dir = tempfile.mkdtemp()

            cls.zip_path = os.path.join(cls.tmp_dir, cls.repo_url.rsplit('/', 1)[1])
            r = requests.get(cls.repo_url, stream=True)

# Generated at 2022-06-21 11:06:38.365309
# Unit test for function unzip
def test_unzip():
    """Unit test for unzip function."""
    # Valid zip file
    zip_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip(zip_url, True, '.', False)

    # Valid zip file with password
    zip_url = 'https://github.com/audreyr/cookiecutter-pypackage-encrypted/archive/master.zip'
    unzip(zip_url, True, '.', False, 'cookiecutter')

    # Valid file path to zip file
    unzip('tests/files/valid-repo.zip', False, '.', False)

    # Invalid zip file
    bad_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
   

# Generated at 2022-06-21 11:06:45.147461
# Unit test for function unzip
def test_unzip():
    from cookiecutter.tests.fixtures import FIXTURE_REPO_DIR
    from cookiecutter.tests.test_utils import remove_repo_dir
    from cookiecutter.tests.test_main import get_eos_message
    from cookiecutter.utils import rmtree
    import cookiecutter.replay

    # Save original value of replay module's INPUT_FILE_ORDER
    # in order to restore it after the test is completed
    orig_input_order = cookiecutter.replay.INPUT_FILE_ORDER

    # Create a temporary directory for the cookiecutter repository

# Generated at 2022-06-21 11:06:54.906446
# Unit test for function unzip
def test_unzip():
    import shutil
    # create temporary directory that contains zipfile
    clone_to_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 11:06:56.721045
# Unit test for function unzip
def test_unzip():
    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)

# Generated at 2022-06-21 11:07:02.719798
# Unit test for function unzip
def test_unzip():
    try:
        os.mkdir('app_test')
        test_case = 'https://github.com/cookiecutter/cookiecutter-django/zipball/master'
        unzip(test_case, True, 'app_test')
    except InvalidZipRepository as e:
        print(e)
        assert False

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:07:03.720447
# Unit test for function unzip
def test_unzip():
    assert unzip("test_unzip.zip", False)

# Generated at 2022-06-21 11:07:22.528345
# Unit test for function unzip
def test_unzip():
    clear_zip_dir()
    zip_dir = "./test_dir"
    zip_path = os.path.join(zip_dir, 'test_repo.zip')
    unzip_path = unzip(zip_path, False, zip_dir)
    assert(os.path.exists(unzip_path))
    assert(os.path.exists(os.path.join(unzip_path, 'cookiecutter.json')))
    assert(os.path.exists(os.path.join(unzip_path, 'hooks/pre_gen_project.py')))
    assert(os.path.exists(os.path.join(unzip_path, 'tests', 'test_hooks.py')))
    clear_zip_dir()

# Generated at 2022-06-21 11:07:23.584164
# Unit test for function unzip
def test_unzip():
    pass



# Generated at 2022-06-21 11:07:26.605303
# Unit test for function unzip
def test_unzip():
    unzip('Python-2.7.10.zip', False, 'C:\\Users\\qend\\Desktop')


if __name__ == "__main__":                  # 测试
    test_unzip()

# Generated at 2022-06-21 11:07:38.824380
# Unit test for function unzip
def test_unzip():
    import shutil
    import sys
    import subprocess
    import os
    import unittest

    testdir = os.path.dirname(os.path.abspath(__file__))
    testdir = os.path.join(testdir, 'test_zip')
    sys.path.insert(0,testdir)
    from test_zip.test_zip import test_zip_url, test_zip_local

    # test with zip url
    os.chdir(testdir)
    test_zip_url() # make sure that test_zip.zip is present
    shutil.rmtree('test_zip')
    unzip('test_zip.zip', is_url=True) # unzip test_zip.zip

# Generated at 2022-06-21 11:07:46.861235
# Unit test for function unzip
def test_unzip():
    assert unzip(zip_uri="./cookiecutter/tests/test-data/fake-repo-tmpl.zip", is_url=False, clone_to_dir='./cookiecutter/tests/test-data/fake-repo-tmpl.zip', no_input=False, password="cookiecutter") != None
    assert unzip(zip_uri="./cookiecutter/tests/test-data/fake-repo-tmpl.zip", is_url=False, clone_to_dir='./cookiecutter/tests/test-data/fake-repo-tmpl.zip', no_input=False, password="cookiecutters") == None

# Generated at 2022-06-21 11:07:48.064958
# Unit test for function unzip
def test_unzip():
    # Check exception for a BadZipFile
    raise NotImplementedError


# Generated at 2022-06-21 11:08:00.124925
# Unit test for function unzip
def test_unzip():
    import shutil
    import requests_cache

    requests_cache.install_cache(cache_name='github_cache')
    ZIP_TARGET_DIR = 'tests/sample_zip_repos'
    ZIP_TARGET_NAME = 'cookiecutter-pypackage-2017.1.tar.gz'
    DOWNLOADED_ZIP_PATH = os.path.join(ZIP_TARGET_DIR, ZIP_TARGET_NAME)
    UNZIPPED_PATH = unzip(DOWNLOADED_ZIP_PATH, False)

    assert os.path.isdir(UNZIPPED_PATH)
    assert os.path.exists(os.path.join(UNZIPPED_PATH, 'setup.py'))

    shutil.rmtree(UNZIPPED_PATH)

# Generated at 2022-06-21 11:08:00.766563
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:08:08.766633
# Unit test for function unzip
def test_unzip():
    import requests
    import mock
    import shutil
    import time
    import zipfile

    # Mock time.clock to speed up tests. Assumes clock is only
    # called once per request, which is true at the time of writing.
    with mock.patch('time.clock') as mock_clock:
        mock_clock.return_value = 0.0

        # Mock requests.get, replacing it with a function that returns
        # a zipfile with one entry "test/"
        with mock.patch.object(requests.sessions.Session, 'get') as mock_get:

            def mock_get_response(*args, **kwargs):
                mock_resp = mock.Mock()

                def zip_stream():
                    with zipfile.ZipFile('test.zip', 'w') as test_zip:
                        test_zip.writestr

# Generated at 2022-06-21 11:08:18.580330
# Unit test for function unzip
def test_unzip():

    import shutil
    import zipfile

    # create test sample
    sample = 'sample.zip'
    with zipfile.ZipFile('sample.zip', 'w') as z:
        z.writestr('text.txt', 'abc')
        
    # test simple unzip
    try:
        unzip(sample, is_url=False)
    except Exception as e:
        print(e)

    # test unzip with non-existent file
    try:
        unzip('fake.zip', is_url=False)
    except Exception as e:
        print(e)

    # cleanup
    os.remove(sample)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:08:49.516182
# Unit test for function unzip
def test_unzip():
    import shutil
    import unittest

    class TestUnzip(unittest.TestCase):

        def setUp(self):
            """The setup method."""
            self.clone_to_dir = '/tmp/cookiecutter_test_repo'
            self.zip_path = os.path.join(self.clone_to_dir, 'test_repo.zip')
            self.zip_uri = os.path.abspath(os.path.join('tests', 'test-repo.zip'))
            self.no_input = True
            self.is_url = False
            self.password = None
            make_sure_path_exists(self.clone_to_dir)

        def tearDown(self):
            """The tear-down method."""

# Generated at 2022-06-21 11:09:00.238962
# Unit test for function unzip

# Generated at 2022-06-21 11:09:10.370221
# Unit test for function unzip
def test_unzip():
    unzip_path = unzip(
        zip_uri='https://github.com/audreyr/cookiecutter-pypackage/zipball/master',
        is_url=True,
        clone_to_dir='.',
        no_input=True,
        password=None
    )
    assert unzip_path.startswith('/tmp/')
    assert unzip_path.endswith('cookiecutter-pypackage-')
    assert os.path.exists(unzip_path)
    assert os.path.isdir(unzip_path)
    assert os.path.exists(os.path.join(unzip_path, 'README.rst'))
    assert os.path.exists(os.path.join(unzip_path, 'setup.py'))

# Generated at 2022-06-21 11:09:11.403266
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:09:15.733074
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url = True

# Generated at 2022-06-21 11:09:25.299255
# Unit test for function unzip
def test_unzip():
    """
    Test the unzip function
    """
    from cookiecutter.main import cookiecutter

    zip_file = os.path.join(os.path.dirname(__file__),
                            'files', 'test-repo.zip')
    clone_to_dir = os.path.join(os.path.dirname(__file__),
                                'files', 'fake-repos')

    zip_path = unzip(zip_file, False, clone_to_dir, no_input=True)
    clone_dir = cookiecutter(zip_path)
    assert os.path.isdir(clone_dir) is True

# Generated at 2022-06-21 11:09:35.129401
# Unit test for function unzip
def test_unzip():
    """Test unzip function
    """
    import shutil
    import pytest

    tmpdir = 'tmp'
    clone_to_dir = os.path.join(tmpdir, 'cookiecutter-repo')

    # Create a URL and local zip repo to test
    filepath = 'tests/test-repo/'
    zip_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    zip_file = 'tests/test-repo.zip'

    def test_url_repo(clone_to_dir):
        unzip(zip_url, True, clone_to_dir)
        assert os.path.exists(os.path.join(clone_to_dir, 'master.zip')) is True

# Generated at 2022-06-21 11:09:40.865657
# Unit test for function unzip
def test_unzip():
    from cookiecutter.main import cookiecutter

    example_json = {
        'cookiecutters_dir': '~/.cookiecutters/',
        'replay_dir': '~/.cookiecutter_replay/',
        'no_input': True,
    }

    context = cookiecutter(
        'tests/test-repo-pre/',
        extra_context={'full_name': 'Your Name'},
        no_input=True
    )

    filename = 'tests/test-repo-pre/cookiecutter.json'
    f = open(filename, 'r')

    try:
        json_data = json.load(f)
        assert json_data == example_json
    except ValueError as e:
        msg = 'There was a problem parsing {}'.format(filename)
        raise Assert

# Generated at 2022-06-21 11:09:51.677917
# Unit test for function unzip
def test_unzip():
    from pkg_resources import resource_filename
    import io
    import tempfile
    with io.open('cookiecutter.json', 'rb') as f:
        test_zipfile = io.BytesIO(f.read())
    test_zipfile.seek(0)
    test_zipfile_path = resource_filename('tests', 'files/cookiecutter.json')
    test_zip_uri = 'http://foo.bar/baz.zip'
    test_clone_to_dir = tempfile.mkdtemp()
    # test a is_url=True
    unzip_path = unzip(test_zip_uri, is_url=True, clone_to_dir=test_clone_to_dir)
    assert unzip_path.endswith('/cookiecutter')
    # test a is_url=False

# Generated at 2022-06-21 11:09:52.253758
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:11:00.045648
# Unit test for function unzip
def test_unzip():
    import os
    # unzip a zip file without password
    test_file = './test_cookiecutter/test_data/test_zip_repo_without_password.zip'
    target_dir = './test_cookiecutter/'
    target_path = unzip(test_file, False, target_dir)
    assert os.path.exists('{}{}/{{cookiecutter.repo_name}}/'.format(target_dir, target_path))
    os.remove('{}{}/{{cookiecutter.repo_name}}/'.format(target_dir, target_path))
    os.remove('{}{}/{{cookiecutter.repo_name}}/README.md'.format(target_dir, target_path))

# Generated at 2022-06-21 11:11:06.920243
# Unit test for function unzip
def test_unzip():
    import shutil
    from .mock import mock_repo

    # Create a local mock zip archive.
    mock_repo('cookiecutter-master.zip')

    unzip_path = unzip(zip_uri='cookiecutter-master.zip', is_url=False)

    assert os.path.isdir(unzip_path)
    shutil.rmtree(unzip_path)
    os.remove('cookiecutter-master.zip')


# vim: filetype=yaml

# Generated at 2022-06-21 11:11:16.495392
# Unit test for function unzip
def test_unzip():
    """Unzip a sample zip file and compare to a template."""
    import shutil
    import zipfile
    from cookiecutter.main import cookiecutter
    import os.path
    import tempfile
    import pytest
    import requests

    # Create a temporary directory.
    temp_directory = tempfile.mkdtemp()

    # Download the cookiecutter-example-zip repo (sample-repo.zip)
    r = requests.get(
        'https://github.com/audreyr/cookiecutter-example-zip/archive/master.zip',
        stream=True)

# Generated at 2022-06-21 11:11:19.459125
# Unit test for function unzip
def test_unzip():
    file_path = 'tests/test-repo-template'
    unzip_path = unzip(file_path, False)
    assert os.path.exists(unzip_path)


# Generated at 2022-06-21 11:11:25.408864
# Unit test for function unzip
def test_unzip():
    unzip_path = unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", True, ".", True)
    assert os.path.exists(unzip_path)

if __name__ == '__main__':
    unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", True, ".", True)

# Generated at 2022-06-21 11:11:28.645127
# Unit test for function unzip
def test_unzip():

    local_zipfile = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'fixtures', 'fake-repo.zip',
    )
    unzip(local_zipfile, is_url=False)

# Generated at 2022-06-21 11:11:37.493338
# Unit test for function unzip
def test_unzip():
    import shutil
    import zipfile

    dir_path = os.path.dirname(os.path.realpath(__file__))
    test_file_path = os.path.join(dir_path, 'test_cookiecutter.zip')
    test_file_url = 'http://test.test/test_cookiecutter.zip'

    with zipfile.ZipFile(test_file_path, 'w') as new_zip:
        new_zip.write('tests/test-repo/abc/abc.txt')
        new_zip.write('tests/test-repo/bar/baz/qux.txt')

    zip_path = unzip(test_file_path, False)
    assert os.path.isdir(zip_path)


# Generated at 2022-06-21 11:11:47.341027
# Unit test for function unzip
def test_unzip():
    '''Check unzip()
    '''
    import shutil
    import requests

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    tmpdir = os.path.join(tmpdir, 'unittest')

    # Create zip file
    dd = requests.get('https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/master')
    with open(os.path.join(tmpdir, 'repo.zip'), "wb") as code:
        code.write(dd.content)

    # Test unzip
    r = unzip(os.path.join(tmpdir, 'repo.zip'), False, os.path.join(tmpdir, 'clone'))

    # Cleanup
    shutil.rmtree(tmpdir)

    # Check


# Generated at 2022-06-21 11:11:53.491005
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import subprocess
    import tempfile
    import zipfile

    # Clone the repository to a temporary directory
    tmp = tempfile.mkdtemp()
    repo = "https://github.com/audreyr/cookiecutter-pypackage.git"
    subprocess.call([
        "git", "clone", repo, os.path.join(tmp, "cookiecutter-pypackage")
    ])

    # Create a zip archive in the temporary directory
    archive = zipfile.ZipFile(os.path.join(tmp, "cookiecutter-pypackage.zip"), "w")
    archive.write(
        os.path.join(tmp, "cookiecutter-pypackage"), "cookiecutter-pypackage"
    )
    archive.close()

   

# Generated at 2022-06-21 11:12:04.587856
# Unit test for function unzip
def test_unzip():
    from tests.test_downloads import mock_url_requests

    def test_url(url):
        assert url == 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'

    def test_data(data):
        assert data is None

    with mock_url_requests(test_url, test_data) as urlopen_mock:
        # unzip a repo
        zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
        is_url = True
        clone_to_dir = '.'
        no_input = False
        unzip_path = unzip(zip_uri, is_url, clone_to_dir=clone_to_dir,
                           no_input=no_input)
       

# Generated at 2022-06-21 11:14:09.927685
# Unit test for function unzip
def test_unzip():
    # This function isn't included in unit tests because
    # it relies on external facilities (requests, zipfile).
    # Also, it's unlikely to be a problem area, since it's
    # just a thin wrapper around function calls.
    pass

# Generated at 2022-06-21 11:14:16.717270
# Unit test for function unzip
def test_unzip():
    from cookiecutter.main import cookiecutter, utils
    import requests_mock

    # Create a zip file
    zip_dest = os.path.join(os.getcwd(), 'tests/test-zip', 'test.zip')
    utils.make_sure_path_exists(zip_dest)
    utils.zip_dir('tests/test-zip/fake-repo-tmpl/', zip_dest)

    # Test to see if unzip returns the correct directory
    repo_dir = unzip(zip_dest, False)

    assert os.path.exists(repo_dir)
    assert repo_dir.endswith('/fake-repo-tmpl/')

    # Test to make sure the zip file is deleted
    assert not os.path.exists(zip_dest)

    # Test

# Generated at 2022-06-21 11:14:17.245922
# Unit test for function unzip
def test_unzip():
    assert True

# Generated at 2022-06-21 11:14:26.956859
# Unit test for function unzip
def test_unzip():
    import requests_mock
    from cookiecutter.main import cookiecutter
    from tests.test_utils import TEST_USERNAME, TEST_PASSWORD
    from .compat import mock

    gh_url = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    gh_url_3rdparty = 'https://github.com/azavea/cookiecutter-esri-toolbox.git'

    with requests_mock.Mocker() as m:
        m.get(gh_url, text='', status_code=200)
        m.get(gh_url_3rdparty, text='', status_code=200)