

# Generated at 2022-06-21 11:04:42.394714
# Unit test for function unzip
def test_unzip():
    import shutil
    import os
    # Create a fake zip file, and extract
    dir = os.getcwd()
    os.chdir(os.path.join(os.path.dirname(dir), 'tests'))
    dir = os.getcwd()
    os.chdir('repo_templates')

    zip_file = 'fake_repo.zip'
    shutil.make_archive(zip_file, 'zip', 'fake_repo_template')

    dir = os.getcwd()
    os.chdir('..')

    # Call to unzip function
    unzip(zip_file+'.zip', False)

    # Clean up
    os.remove(zip_file+'.zip')
    os.chdir(dir)


# Generated at 2022-06-21 11:04:54.826314
# Unit test for function unzip
def test_unzip():
    # create zip file
    z = zipfile.ZipFile('./sample.zip', mode='w')
    z.writestr('sample/cookiecutter.json', b'''
        {
            "project_name": "{{cookiecutter.project_name}}",
            "project_slug": "{{cookiecutter.project_slug}}",
            "foo": "{{cookiecutter.foo}}",
            "bar": "{{cookiecutter.bar}}"
        }
    ''')
    z.close()

    # unzip
    inputs = {
        'project_name': 'Some-sample-project',
        'project_slug': 'some_sample_project',
        'foo': 'Baz',
        'bar': 'Qux'
    }
    unzip('sample.zip', False)



# Generated at 2022-06-21 11:04:56.264893
# Unit test for function unzip
def test_unzip():
    uri = "https://github.com/alembic/cookiecutter-alembic/archive/0.7.1.zip"
    unzip(uri, True)

# Generated at 2022-06-21 11:05:05.820754
# Unit test for function unzip
def test_unzip():
    import shutil
    from cookiecutter.utils import rmtree

    unpack_path = '/tmp/cookie/'
    path = os.path.join(unpack_path, 'cookiecutter-pypackage')

    if os.path.exists(path):
        rmtree(path)

    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',is_url=True,clone_to_dir='/tmp/') == path

    shutil.rmtree(unpack_path)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:05:13.005538
# Unit test for function unzip
def test_unzip():
    #!/usr/bin/env python
    # -*- coding: utf-8 -*-
    """
    Cookiecutter unit tests
    ~~~~~~~~~~~~~~~~~~~~~~~

    This file contains unit tests for the Cookiecutter's archive functions.

    :copyright: (c) 2014 by AudioVision San Diego.
    :license: BSD, see LICENSE for more details.
    """
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.exceptions import RepositoryNotFound
    from tests.test_cookiecutter import (
        create_fake_repo,
        remove_fake_repo,
        make_fake_repo_with_submodules,
        remove_fake_repo_with_submodules,
    )
    import os
    import pytest


# Generated at 2022-06-21 11:05:22.946910
# Unit test for function unzip
def test_unzip():
    """Check that a zip file is decompressed correctly"""

    # create a temp folder
    dir_path = tempfile.mkdtemp()
    # create a short list of elements to compress
    sample = ['abc', 'def', 'ghi']
    # create a zip file with the sample, then decompress it
    # and checks that the sample is present
    with ZipFile('sample.zip', 'w') as myzip:
        for file in sample:
            myzip.writestr(file+'.txt', '')
    result = unzip('sample.zip', False, dir_path)
    assert os.path.isdir(result)
    files = os.listdir(result)
    assert sample == [file[:-4] for file in files]
    # delete the temp folder

# Generated at 2022-06-21 11:05:30.558567
# Unit test for function unzip
def test_unzip():
    """Sanity checks for the unzip function."""
    from .utils import TEST_USER
    from .paths import cookiecutters_dir
    from .main import cookiecutter
    import shutil

    # Download the unittest repository and unpack it.
    unittest_zip = 'https://github.com/{}/cookiecutter-example-unittest/archive/master.zip'
    unittest_repo = unzip(
        zip_uri=unittest_zip.format(TEST_USER),
        is_url=True,
        clone_to_dir=cookiecutters_dir()
    )

    # Run Cookiecutter, like we do in the CLI.

# Generated at 2022-06-21 11:05:34.214877
# Unit test for function unzip
def test_unzip():
    unzip('/Users/mikem/repos/cookiecutter-pypackage/tests/test-repo-pre/', False, '/Users/mikem/repos/cookiecutter-pypackage/tests/test-repo-pre/')

# Generated at 2022-06-21 11:05:37.907060
# Unit test for function unzip
def test_unzip():
    import pytest
    
    # URL
    url = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    is_url = True
    assert unzip(url, is_url).strip().endswith("master")
    
    # File
    url = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    is_url = False
    assert unzip(url, is_url).strip().endswith("master")

# Generated at 2022-06-21 11:05:49.584570
# Unit test for function unzip
def test_unzip():
    import shutil
    import zipfile

    # For this test, we must create a working zipfile in a temporary
    # directory.
    base_dir = tempfile.mkdtemp()
    zip_path = os.path.join(base_dir, 'test.zip')
    project_name = 'test-repo'
    project_dir = os.path.join(base_dir, project_name)

    # Create a temporary directory for the test project
    os.mkdir(project_dir)
    os.mkdir(os.path.join(project_dir, 'tests'))
    with open(os.path.join(project_dir, 'README.md'), 'w') as f:
        f.write('README')

    # Create a temporary zipfile for the test project

# Generated at 2022-06-21 11:06:04.749404
# Unit test for function unzip
def test_unzip():
    import pytest 
    import shutil
    from pathlib import Path
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.repository import determine_repo_dir

    TMP_DIR = Path("tests/tmp")
    TEST_ZIP = Path("tests/fixtures/broken_zip.zip")

    # set config to default
    DEFAULT_CONFIG["no_input"] = True
    DEFAULT_CONFIG["cached_repo_dir"] = TMP_DIR

    # cleanup
    TMP_DIR.mkdir(parents=True, exist_ok=True)
    if TMP_DIR.exists():
        shutil.rmtree(TMP_DIR)

    # test file

# Generated at 2022-06-21 11:06:14.619943
# Unit test for function unzip
def test_unzip():
    """
    Given the url and destination path of a zip file
    When i call the function unzip
    Then The zip file is downloaded, extracted and a temporary folder is returned
    """
    import platform
    import sys

    # WARNING: This test may fail if the zip file is password protected
    # (this is not supported by the function unzip right now)
    url = 'https://github.com/repo/archive/master.zip'
    is_url = True
    dest = '..'
    no_input = False
    password = None
    if sys.version_info[0] >= 3 and platform.system() == 'Windows':
        dest = '..\\'
    elif sys.version_info[0] >= 3 and platform.system() != 'Windows':
        dest = '../'
    else:
        dest = '..'

# Generated at 2022-06-21 11:06:22.493860
# Unit test for function unzip
def test_unzip():
    # Download a test zip file
    import sys, os
    import urllib
    url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    zip_path = 'cookiecutter-pypackage-master.zip'
    if not os.path.isfile(zip_path):
        urllib.urlretrieve(url, zip_path)

    # Test unzip function

# Generated at 2022-06-21 11:06:24.741546
# Unit test for function unzip
def test_unzip():
    assert os.path.isdir(unzip('test-repo-master', True, clone_to_dir='.'))

# Generated at 2022-06-21 11:06:36.193708
# Unit test for function unzip
def test_unzip():
    from cookiecutter.utils import rmtree
    import os
    import pytest
    from zipfile import ZipFile
    import shutil
    from shutil import copyfile

    # Create a repository zip file
    test_zip = 'test-repo.zip'
    with ZipFile(test_zip, 'w') as new_zip:
        new_zip.write('README.rst')
        new_zip.write('hooks/post_gen_project.py')

    unzipped_repo = unzip(test_zip, is_url=0)

    # Check that the zip file has been extracted in a right way
    assert os.path.isfile(os.path.join(unzipped_repo, "README.rst"))

# Generated at 2022-06-21 11:06:37.782450
# Unit test for function unzip
def test_unzip():
    pass

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:06:42.105833
# Unit test for function unzip
def test_unzip():
    # url="https://github.com/karixed/cookiecutter-django-pylint/archive/master.zip"
    # url = "https://github.com/karixed/cookiecutter-django-pylint/archive/master.zip"
    # find out cookiecutter-django-pylint/cookiecutter.json
    # then check if it has a django_version
    pass

# Generated at 2022-06-21 11:06:42.610420
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:06:52.413279
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile

    import requests_mock

    zip_path = os.path.join(os.path.dirname(__file__), 'test_files/test_zip.zip')
    password_zip_path = os.path.join(os.path.dirname(__file__), 'test_files/test_password_zip.zip')
    bad_zip_path = os.path.join(os.path.dirname(__file__), 'test_files/test_bad_zip.zip')
    empty_zip_path = os.path.join(os.path.dirname(__file__), 'test_files/test_empty_zip.zip')

    # test with a file path
    path = unzip(zip_path, is_url=False)
    assert os.path

# Generated at 2022-06-21 11:06:54.323793
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/jacebrowning/template-python/archive/2.7.zip',
          is_url=True, clone_to_dir='/tmp')

# Generated at 2022-06-21 11:07:07.795992
# Unit test for function unzip
def test_unzip():
    import pytest
    import requests
    import tempfile
    import shutil
    import os
    import sys
    import zipfile

    # Test empty zip
    with pytest.raises(InvalidZipRepository):
        unzip("tests/fixtures/test-empty.zip", 0) # test-empty.zip is empty
    
    # url path
    url_path = "https://github.com/pinax/pinax-starter-projects/archive/master.zip"

    # Test empty zip
    with pytest.raises(InvalidZipRepository):
        unzip(url_path, 1)

    # Test unzip to temp directory
    # The following test does not work on Windows due to access restrictions
    # for the temporary folder.

# Generated at 2022-06-21 11:07:08.501400
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:07:19.647160
# Unit test for function unzip
def test_unzip():
    clone_to_dir = tempfile.mkdtemp()
    unzip_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, clone_to_dir)
    assert os.path.exists(os.path.join(unzip_path, 'setup.py'))
    assert os.path.exists(os.path.join(unzip_path, 'README.rst'))
    assert os.path.exists(os.path.join(unzip_path, 'setup.cfg'))
    assert os.path.exists(os.path.join(unzip_path, 'tox.ini'))
    assert os.path.exists(os.path.join(unzip_path, 'tests'))
    assert os.path

# Generated at 2022-06-21 11:07:19.983433
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:07:21.812147
# Unit test for function unzip
def test_unzip():
    try:
        unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
    except InvalidZipRepository:
        assert False
    try:
        unzip('tests/test-repo-tmpl', False)
    except InvalidZipRepository:
        assert False

# Generated at 2022-06-21 11:07:33.886300
# Unit test for function unzip
def test_unzip():
    from cookiecutter.exceptions import InvalidZipRepository

    try:
        unzip("https://github.com/aviaryan/cookiecutter-simple/archive/master.zip", True, 'temp', False, None)
    except InvalidZipRepository:
        # The repo is not a password protected repo hence invalid zip repository
        # exception is received on unzipping
        pass

    try:
        unzip("https://github.com/aviaryan/cookiecutter-protected/archive/master.zip", True, 'temp', False, '123')
    except InvalidZipRepository:
        # The repo is a password protected repo hence invalid zip repository
        # exception is received on unzipping since the password 123 is invalid
        pass


# Generated at 2022-06-21 11:07:35.474547
# Unit test for function unzip
def test_unzip():
    # Unit tests are omitted due to dependency on a valid zip file.
    pass

# Generated at 2022-06-21 11:07:39.580302
# Unit test for function unzip
def test_unzip():
    """
    Function test_unzip tests the unzip function by first creating a dummy zip file and then
    deleting it after unzipping it.
    """
    # Create test directory with dummy files and zip it
    test_temp_directory = tempfile.mkdtemp()
    dummy_file = os.path.join(test_temp_directory, 'test1.txt')
    dummy_file2 = os.path.join(test_temp_directory, 'test2.txt')
    test_zip = os.path.join(test_temp_directory, 'test.zip')
    test_file_content = 'content test'
    with open(dummy_file, 'w') as f:
        f.write(test_file_content)

# Generated at 2022-06-21 11:07:40.235975
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:07:47.297703
# Unit test for function unzip
def test_unzip():
    """Make sure that the function returns the unzipped path

    """
    assert (
        unzip('zip', True, '.', no_input=True) == os.path.abspath(
            'cookiecutter-master')
    )
    assert (
        unzip('zip', True, '.', no_input=True) == os.path.abspath(
            'cookiecutter-master')
    )
    assert (
        unzip('zip', True, '.', no_input=True) == os.path.abspath(
            'cookiecutter-master')
    )

# Generated at 2022-06-21 11:08:28.027254
# Unit test for function unzip
def test_unzip():
    import shutil

    unzip('/tmp/dummy.zip', is_url=False)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-21 11:08:28.417775
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:08:32.632176
# Unit test for function unzip
def test_unzip():
    """Test the unzip function with a temp file"""
    import os
    import shutil
    import tempfile
    from zipfile import ZipFile
    from cookiecutter.zipfile import unzip

    content = b"content_for_unzip_test"
    tempdir = tempfile.mkdtemp()
    zipped_dir = tempfile.mkdtemp()


# Generated at 2022-06-21 11:08:33.244086
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-21 11:08:42.255700
# Unit test for function unzip
def test_unzip():
    # Sample zip file with password 'secret'
    sample_zip = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_file.zip'
    )

    # unzip file to temporary destination
    destination = unzip(sample_zip, False, password='secret')

    # ensure destination was created
    assert os.path.exists(destination)

    # ensure sample file is in destination
    assert os.path.exists(os.path.join(destination, 'test_file'))
    # remove the temporary destination
    os.removedirs(destination)

# Generated at 2022-06-21 11:08:50.399805
# Unit test for function unzip
def test_unzip():
    import unittest
    import shutil
    import requests

    class UnzipTestCase(unittest.TestCase):

        def setUp(self):
            self.setUpTestDir()
            self.setUpZipfile()
            self.setUpZipfileURL()

        def tearDown(self):
            shutil.rmtree(self.test_dir)
            os.remove(self.zip_path)

        def setUpTestDir(self):
            """Create the temporary test directory."""
            self.test_dir = tempfile.mkdtemp()

        def setUpZipfile(self):
            """Create the zipfile to use in tests."""
            self.zip_path = os.path.join(self.test_dir, 'test.zip')

# Generated at 2022-06-21 11:09:00.898367
# Unit test for function unzip
def test_unzip():
    archive_path = os.path.abspath('./tests/test-unzip-repo.zip')
    unzip_path = unzip(zip_uri=archive_path, is_url=False, clone_to_dir='.')

    # Ensure that the unzip_path represents a directory. It should be
    # of a form similar to '.../.../.../.../cc-test-zip'
    assert unzip_path.endswith('cc-test-zip')

    # Make sure there is a file in it with the expected name
    assert os.path.exists(os.path.join(unzip_path, 'baz.txt'))

    # Delete the unzip_path directory
    os.rmdir(unzip_path)

    # Try to unzip a zipfile without a directory entry. This

# Generated at 2022-06-21 11:09:04.642108
# Unit test for function unzip
def test_unzip():
    """Check unzip returns a string"""
    assert isinstance(unzip('.', False, '.', True), str)
    assert isinstance(unzip('https://github.com/', True, '.', True), str)
    

# Generated at 2022-06-21 11:09:13.480819
# Unit test for function unzip
def test_unzip():
    import zipfile
    from io import BytesIO
    from io import StringIO
    from tempfile import NamedTemporaryFile

    # Create a test string to zip up
    test_string = b"TEST_STRING"

    # Create a test archive with zipfile module
    zip_file = BytesIO()
    z = zipfile.ZipFile(zip_file, mode='w')
    z.writestr('archive/', '')  # creating the root directory
    z.writestr('archive/test.txt', test_string)
    z.close()

    # Write zip_file to temporary file
    test_archive = NamedTemporaryFile()
    test_archive.write(zip_file.getvalue())
    test_archive.seek(0)

    # Create expected output string

# Generated at 2022-06-21 11:09:25.420934
# Unit test for function unzip
def test_unzip():
    import shutil
    from zipfile import ZIP_DEFLATED
    # A zip file that is password protected
    with tempfile.TemporaryDirectory() as tempdir:
        with open(os.path.join(tempdir, "test.zip"), 'w') as f:
            zip_file = ZipFile(f, 'w', ZIP_DEFLATED)
            zip_file.writestr("file", "content")
            zip_file.setpassword(b'password')
            zip_file.close()
        # Try to unzip without a password
        try:
            unzip(os.path.join(tempdir, "test.zip"), False, no_input=True)
            assert False
        except InvalidZipRepository:
            pass
        # Try to unzip with wrong password

# Generated at 2022-06-21 11:10:56.552484
# Unit test for function unzip
def test_unzip():
    """
    unzip() takes a zip file as an argument and returns the directory that it got unpacked to.
    """
    import os
    zip_uri = os.path.join(os.path.dirname(__file__), 'test-repo.zip')
    is_url = False
    clone_to_dir = os.path.join(os.path.dirname(__file__), 'test-output')
    no_input = False
    password = None

    # Run the function
    new_directory = unzip(zip_uri, is_url, clone_to_dir, no_input, password)

    # Delete the directory
    import shutil
    shutil.rmtree(new_directory)

# Generated at 2022-06-21 11:11:03.617644
# Unit test for function unzip
def test_unzip():
    # Test function unzip
    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, no_input=True)
    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, True, no_input=True)
    assert unzip('tests/files/test-repo.zip', False, no_input=True)
    assert unzip('tests/files/test-repo.zip', False, True, no_input=True)

# Generated at 2022-06-21 11:11:13.448258
# Unit test for function unzip
def test_unzip():
    import os, shutil, sys
    import tempfile
    
    tempdir = tempfile.mkdtemp()

    os.chdir(tempdir)

# Generated at 2022-06-21 11:11:23.760136
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    import zipfile
    import requests
    test_repo = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    temp_dir = tempfile.mkdtemp()
    identifier = test_repo.rsplit('/', 1)[1]
    zip_path = os.path.join(temp_dir, identifier)


# Generated at 2022-06-21 11:11:32.245052
# Unit test for function unzip
def test_unzip():
    import zipfile
    from shutil import rmtree

    # Setup a zipfile containing a simple directory structure.
    testdir = tempfile.mkdtemp()
    testdir_path = os.path.join(testdir, 'cookiecutter-test')
    os.makedirs(testdir_path)

    with open(os.path.join(testdir_path, 'test.txt'), 'w') as f:
        f.write('test')

    testzip = tempfile.NamedTemporaryFile()
    zip_file = zipfile.ZipFile(testzip, 'w')
    zip_file.write(testdir_path, 'cookiecutter-test')
    zip_file.close()

    # Run the unzip function on our test zip file.

# Generated at 2022-06-21 11:11:41.844138
# Unit test for function unzip
def test_unzip():
    from unittest import TestCase

    import shutil
    import zipfile

    from cookiecutter.exceptions import InvalidZipRepository

    class TempDirMixin(TestCase):
        def setUp(self):
            self.temp_dir = 'test'
            self.zip_path = os.path.join(self.temp_dir, 'test.zip')
            make_sure_path_exists(self.temp_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

    class UnzipTests(TempDirMixin):

        def test_unzip_existing_file(self):
            with open(self.zip_path, 'w') as f:
                f.write('empty file')

# Generated at 2022-06-21 11:11:50.421020
# Unit test for function unzip
def test_unzip():
    import requests_mock
    import shutil

    zip_filename = '/tmp/example.zip'
    zip_uri = 'file://{}'.format(zip_filename)
    clone_to_dir = '/tmp'

    def mock_response_zip(request, context):
        context.status_code = 200
        with open(zip_filename, 'rb') as f:
            return f.read()

    with requests_mock.Mocker() as m:
        m.get('example.com', content=mock_response_zip)
        with open(zip_filename, 'w') as f:
            f.write('test')
        unzip_path = unzip(zip_uri, True, clone_to_dir)
        shutil.rmtree(unzip_path)
        os.remove(zip_filename)

# Generated at 2022-06-21 11:11:58.375526
# Unit test for function unzip
def test_unzip():
    is_url = True
    clone_to_dir = 'test_zip'
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.6.0.tar.gz'  # noqa
    assert unzip(zip_uri, is_url, clone_to_dir)
    is_url = True
    clone_to_dir = 'test_zip'
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.6.0.zip'  # noqa
    assert unzip(zip_uri, is_url, clone_to_dir)

# Generated at 2022-06-21 11:12:00.501693
# Unit test for function unzip
def test_unzip():
    assert os.path.isdir("/tmp/cookiecutter-tests/cookiecutter-pypackage")

# Generated at 2022-06-21 11:12:01.048820
# Unit test for function unzip
def test_unzip():
    pass