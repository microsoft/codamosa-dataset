

# Generated at 2022-06-23 16:34:28.920063
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/release_0.0.2',
          True)
    unzip('https://github.com/audreyr/cookiecutter-pypackage/releases/download/release_0.0.2/release_0.0.2.zip',
          True)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-23 16:34:30.919125
# Unit test for function unzip
def test_unzip():
    assert unzip(test_unzip.__name__, False) == \
           unzip(test_unzip.__name__, True)

# Generated at 2022-06-23 16:34:40.204339
# Unit test for function unzip
def test_unzip():
    import pickle
    import uuid
    import zipfile

    NO_INPUT = True

    test_dir = tempfile.mkdtemp()
    test_root = os.path.abspath(os.path.dirname(__file__))

    # We have a test repo in the repository
    repo_path = os.path.join(test_root, 'test-repo.zip')

    password = uuid.uuid4().hex
    # Create a copy of the test repo with a password

# Generated at 2022-06-23 16:34:43.784413
# Unit test for function unzip
def test_unzip():
    zip_uri = 'http://google.com/google.zip'
    clone_to_dir = '.'
    no_input = False 
    is_url = True
    unzip(zip_uri, is_url, clone_to_dir, no_input)


# Generated at 2022-06-23 16:34:52.624827
# Unit test for function unzip
def test_unzip():
    from cookiecutter.main import cookiecutter
    from os.path import exists, isdir
    from shutil import rmtree
    from subprocess import check_call

    repo_dir = '~/cookiecutters'
    zip_path = '~/Downloads/cookiecutter-pypackage-minimal-1.0.zip'
    cloned_path = unzip('/Users/audreyr/Downloads/cookiecutter-pypackage-minimal-1.0.zip', False, repo_dir)
    assert exists(cloned_path)
    assert isdir(cloned_path)

    # Try the full cookiecutter flow with the extracted archive

# Generated at 2022-06-23 16:34:58.202952
# Unit test for function unzip
def test_unzip():
    import filecmp
    import shutil
    import sys
    import zipfile
    import pytest

    # test missing file
    with pytest.raises(FileNotFoundError):
        unzip('/tmp/no-such-zipfile', is_url=False)

    # Create a temporary directory for testing purposes
    temp_dir = tempfile.mkdtemp()
    unzip_dir = None

    # Prepare a simple zipfile for test purposes
    zip_path = os.path.join(temp_dir, 'test.zip')
    with ZipFile(zip_path, 'w') as zip_file:
        zip_file.writestr('readme.txt', bytes('README', 'utf-8'))
        zip_file.writestr('cookiecutter.json', bytes('{}', 'utf-8'))


# Generated at 2022-06-23 16:35:05.531842
# Unit test for function unzip
def test_unzip():
    import time
    import shutil
    from .config import DEFAULT_CONFIG
    from .prompt import read_user_yes_no
    
    test_dir = tempfile.mkdtemp()
    config_file = os.path.join(test_dir, 'config.yaml')
    with open(config_file, 'w') as f:
        f.write(DEFAULT_CONFIG)

    cookiecutters_dir = os.path.join(test_dir, 'cookiecutters')
    os.makedirs(cookiecutters_dir)


# Generated at 2022-06-23 16:35:14.627051
# Unit test for function unzip
def test_unzip():
    from os.path import abspath, exists
    from tempfile import mkdtemp
    from time import sleep

    from cookiecutter import generate  # noqa

    from . import clean_repo_checkout

    test_repo = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/0.4.0'

    # Create a temporary directory
    clone_to_dir = mkdtemp()

    # Get the zip repository into the temporary directory
    unzip_path = unzip(test_repo, True, clone_to_dir)

    # Generate a project from the zip repository

# Generated at 2022-06-23 16:35:24.357182
# Unit test for function unzip
def test_unzip():
    from os import mkdir, unlink
    from os.path import relpath, join, isfile
    import tempfile

    temp_dir = tempfile.mkdtemp()
    repo_path = None

# Generated at 2022-06-23 16:35:33.685129
# Unit test for function unzip
def test_unzip():
    import time
    import shutil
    passwd = 'passwd'
    pwd_file = 'tests/fixtures/abcd.txt'
    zips_file = 'tests/fixtures/abcd.zip'

    try:
        # local zip file not password protected
        unzip(zips_file, False)

        # local zip file protected
        unzip(zips_file, False, password = passwd)

        # url zip file not password protected
        unzip(zips_file, True)

        # url zip file protected
        unzip(zips_file, True, password = passwd)

        # BadZipFile
        unzip(pwd_file, False)
    except:
        assert False
    else:
        assert True
    # cleanup

# Generated at 2022-06-23 16:35:35.685400
# Unit test for function unzip
def test_unzip():
    pass

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-23 16:35:41.141687
# Unit test for function unzip
def test_unzip():
    """Test for unzip."""
    unzip(
        zip_uri="https://github.com/agakshat/django-project-template/archive/master.zip",
        is_url=True,
        clone_to_dir=".",
        no_input=True,
        password=None
    )

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-23 16:35:47.400869
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    from cookiecutter.compat import TemporaryDirectory
    from cookiecutter.utils import unzip
    from zipfile import ZipFile

    with TemporaryDirectory() as tempdir:
        # Create test zip file
        with ZipFile('./tests/files/test-repo.zip', 'r') as zip:
            # Create temporary directory
            tmpdir = tempdir + '/' + zip.namelist()[0][:-1]
            os.makedirs(tmpdir)

            # Extract zip file
            zip.extractall(path=tempdir)

        # Test that the zip file was extracted to the desired location
        assert 'test.txt' in os.listdir(tmpdir)

        # Test that the zip file was unpacked properly
        random_directory = './tests/files/bogus'


# Generated at 2022-06-23 16:35:58.174941
# Unit test for function unzip
def test_unzip():
    import pytest
    import shutil
    import pathlib

    repo_folder = pathlib.Path(os.path.dirname(__file__)).parent.parent
    zip_path = os.path.join(repo_folder,"cookiecutter-xblock","cookiecutter-xblock.zip")
    clone_to_dir = os.path.join(repo_folder,"cookiecutter-xblock")
    unzip_path = unzip(zip_uri=zip_path,is_url=False,clone_to_dir=clone_to_dir,no_input=True)

    assert unzip_path == os.path.join(clone_to_dir,"cookiecutter-xblock-master","cookiecutter-xblock-master")


# Generated at 2022-06-23 16:36:04.449847
# Unit test for function unzip
def test_unzip():
    assert len(unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", True).split("/")) == 6
    assert len(unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", True, "abc").split("/")) == 7

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-23 16:36:07.562842
# Unit test for function unzip
def test_unzip():
    from tests.test_repo_scaffolds import zip_repo

    zip_path = zip_repo('.')
    unzip_path = unzip(zip_path, False, no_input=True)

    assert os.path.exists(unzip_path)

# Generated at 2022-06-23 16:36:17.435322
# Unit test for function unzip
def test_unzip():
    """ test_unzip
    A test to ensure that we can unzip an archive at the required URL.
    """
    import shutil
    import random
    import datetime

    # Create a temporary directory to hold the repository,
    # and ensure that it doesn't already exist.
    tmpdir_base = os.path.expanduser('~/.cookiecutters')
    make_sure_path_exists(tmpdir_base)

    tmpdir = tempfile.mkdtemp(dir=tmpdir_base)
    tmpdir_name = os.path.split(tmpdir)[1]


# Generated at 2022-06-23 16:36:27.548096
# Unit test for function unzip
def test_unzip():
    import shutil
    from requests_mock import Mocker
    import pytest
    from cookiecutter.utils import rmtree
    from cookiecutter.exceptions import InvalidZipRepository
    from utils import make_mock_zip

    def cleanup():
        # Cleanup temp files
        mock_file = os.path.join(clone_to_dir, mock_identifier)
        if os.path.exists(mock_file):
            os.remove(mock_file)
        rmtree(unzip_base)

    # Clean up previous test runs
    clone_to_dir = os.path.join(
        os.getcwd(), 'tests/test-data/test-repos/fake-repo-tmpl'
    )

# Generated at 2022-06-23 16:36:37.981059
# Unit test for function unzip
def test_unzip():
    # Test the unzip function with a test case zip file.
    # This zip file was created with the following command:
    #   zip -r --password passw test.zip test
    # where test is a directory with a single file in it.
    test_file = os.path.join(os.getcwd(), 'test.zip')
    unzip_path = unzip(test_file, False)
    assert os.path.exists(unzip_path)
    assert os.path.isdir(unzip_path)
    assert os.path.exists(os.path.join(unzip_path, 'test/test.txt'))
    os.rmdir(unzip_path)

# Generated at 2022-06-23 16:36:44.177923
# Unit test for function unzip

# Generated at 2022-06-23 16:36:50.143867
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(zip_uri, is_url=True, clone_to_dir='.', no_input=False, password=None)
    # Check that unzip_path is the real path to the source code of cookiecutter-pypackage
    assert unzip_path == os.path.join(os.getcwd(), 'cookiecutter-pypackage-master')

# Generated at 2022-06-23 16:36:54.800389
# Unit test for function unzip
def test_unzip():
    import shutil

    clone_to_dir = tempfile.mkdtemp()
    unzip_path = unzip('tests/test-repo-tmpl/test-repo.zip', False, clone_to_dir=clone_to_dir)

    assert os.path.isdir(unzip_path)

    shutil.rmtree(clone_to_dir)

# Generated at 2022-06-23 16:36:57.516433
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/0.5.2/'
    unzip(zip_uri, True)
    assert True

# Generated at 2022-06-23 16:37:02.930852
# Unit test for function unzip
def test_unzip():
    assert unzip(
        "https://github.com/danielhnyk/cookiecutter-matlab/archive/master.zip",
        True,
        clone_to_dir='.',
        no_input=True,
        password='password'
    )


# Generated at 2022-06-23 16:37:03.669593
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:37:14.084538
# Unit test for function unzip
def test_unzip():
    import logging
    import sys
    import os

    logger = logging.getLogger(__name__)
    log_handler = logging.StreamHandler(sys.stderr) # Write the log to StdErr
    logger.addHandler(log_handler)
    logger.setLevel(logging.DEBUG) # Log everything
    log_handler.setLevel(logging.DEBUG) # Log everything

    import sandbox
    import sandbox.util

    # Tests with a local zipfile
    test_local_zip = get_test_local_zip()
    zip_path = unzip(test_local_zip, False, '.')

    logger.debug("  zip_path=%s", zip_path)
    assert os.path.isdir(zip_path)    # The unzipped file is a directory

# Generated at 2022-06-23 16:37:19.429607
# Unit test for function unzip
def test_unzip():
    # unzip returns the unzip_path which is a valid directory
    assert os.path.isdir(unzip("sklearn.zip", False))
    assert os.path.isdir(unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", True))



# Generated at 2022-06-23 16:37:26.593884
# Unit test for function unzip
def test_unzip():
    """Test unzip function"""
    from cookiecutter.tests.test_replay import test_dir
    unzip_function = os.path.join(test_dir, "unzip_function")

    # Create a zip file
    import zipfile
    with zipfile.ZipFile("test_unzip.zip", "w") as zip_archive:
        zip_archive.write("zip_function_test.txt")

    filename = "test_unzip.zip"
    unzip("test_unzip.zip", False, unzip_function)

    # Cleanup previous zip archive
    os.remove("test_unzip.zip")

if __name__=="__main__":
    test_unzip()

# Generated at 2022-06-23 16:37:33.614025
# Unit test for function unzip
def test_unzip():
    import time
    url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.2.5.zip'
    is_url = True
    clone_to_dir = '.'
    no_input = True
    start_time = time.time()
    unzip(url, is_url, clone_to_dir, no_input)
    print("--- %s seconds ---" % (time.time() - start_time))

# Generated at 2022-06-23 16:37:40.617794
# Unit test for function unzip
def test_unzip():
    """Basic function test for unzip."""
    import pytest
    from cookiecutter import utils
    from cookiecutter.exceptions import CookiecutterException

    # Test the basic functionality of unzip
    test_uri = "https://github.com/audreyr/cookiecutter-pypackage/archive/0.3.zip"
    unzip_path = unzip(test_uri, True)

    assert os.path.exists(unzip_path)

    # The unzipped path should be a directory
    assert os.path.isdir(unzip_path)

    # Cleanup
    utils.rmtree(unzip_path)

    # Test with a password. The zip file at
    # https://github.com/cookiecutter/cookiecutter-django/archive/master.zip
    #

# Generated at 2022-06-23 16:37:43.717890
# Unit test for function unzip
def test_unzip():
    """
    Unit test for function unzip.

    This test needs a valid zip file to proceed.
    """
    pass

# Generated at 2022-06-23 16:37:51.137509
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True )
    unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True, '.', no_input=True )
    unzip('https://github.com/audreyr/cookiecutter-pypackage/zipball/master', True, '.', password='password')
test_unzip()

# Generated at 2022-06-23 16:37:56.888572
# Unit test for function unzip
def test_unzip():
    import shutil
    from cookiecutter.main import cookiecutter

    # Unzip repository
    unzip_path = unzip(
        zip_uri='https://github.com/pydanny/cookiecutter-djangopackage/archive/master.zip',
        is_url=True,
        clone_to_dir='.',
        no_input=False
    )
    assert os.path.exists(unzip_path) is True

    # Ensure that cookiecutter can work with an unziped repository:
    # (it shouldn't raise an exception if it can)

# Generated at 2022-06-23 16:38:00.479743
# Unit test for function unzip
def test_unzip():
    # TODO: This is a weak test. It needs to be
    # improved.
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/0.0.4'
    unzip(zip_uri, is_url=True)

# Generated at 2022-06-23 16:38:01.337769
# Unit test for function unzip
def test_unzip():
    assert 1==1

# Generated at 2022-06-23 16:38:10.730802
# Unit test for function unzip
def test_unzip():
    """Test for cookiecutter.utils.unzip"""
    from zipfile import is_zipfile
    from shutil import rmtree
    from cookiecutter import main
    from cookiecutter.prompt import read_repo_password
    from cookiecutter.utils import make_sure_path_exists
    from tempfile import mkdtemp

    prompt_and_delete = read_repo_password

    # define a temporary directory where to put the zip file
    clone_to_dir = mkdtemp()

    # download a zip file
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    identifier = zip_uri.rsplit('/', 1)[1]
    zip_path = os.path.join(clone_to_dir, identifier)


# Generated at 2022-06-23 16:38:17.348814
# Unit test for function unzip
def test_unzip():
    is_url = True
    no_input = False
    clone_to_dir = '/home/user/git/cookiecutter-simple-python-package'
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    password = None
    unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    assert True

# Generated at 2022-06-23 16:38:18.236015
# Unit test for function unzip
def test_unzip():
  pass

# Generated at 2022-06-23 16:38:28.769359
# Unit test for function unzip
def test_unzip():
    """Test to get a github template and unzip it"""
    import os
    import shutil
    import tempfile
    import zipfile
    zip_uri = 'https://codeload.github.com/cookiecutter-django/cookiecutter-django/zip/master'
    is_url = True
    clone_to_dir = tempfile.mkdtemp()
    no_input = False
    password = None
    # Ensure that clone_to_dir exists
    clone_to_dir = os.path.expanduser(clone_to_dir)
    make_sure_path_exists(clone_to_dir)

# Generated at 2022-06-23 16:38:31.975620
# Unit test for function unzip
def test_unzip():
    zf = unzip("https://github.com/jacebrowning/template-flask/archive/0.1.1.zip", True)
    assert os.path.isdir(zf)
    assert os.path.exists(os.path.join(zf, 'README.md'))

# Generated at 2022-06-23 16:38:36.026120
# Unit test for function unzip
def test_unzip():
    """Test unzip function."""
    my_zip_file = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(my_zip_file, is_url=True)
    assert 'cookiecutter-pypackage-master' in unzip_path

# Generated at 2022-06-23 16:38:46.736836
# Unit test for function unzip
def test_unzip():
    import requests
    import shutil
    import tempfile
    import os

    # create a password protected zip
    temp_dir = tempfile.gettempdir()
    os.chdir(temp_dir)
    zip_dir = 'tests/files/cookiecutter-oXyz'
    zip_path = os.path.join(zip_dir, 'cookiecutter-foobar.zip')
    zip_file_path = os.path.join(temp_dir, 'cookiecutter-foobar.zip')
    zip_file = open(zip_file_path, 'wb')
    r = requests.get(
        'https://github.com/audreyr/cookiecutter-foobar/archive/master.zip',
        stream=True
    )

# Generated at 2022-06-23 16:38:54.934638
# Unit test for function unzip
def test_unzip():
    import pytest
    import requests_mock
    import shutil

    with requests_mock.Mocker() as m:
        m.get('http://github.com/repo/download.zip', content=b'dummy')
        tempdir = tempfile.mkdtemp()
        try:
            assert unzip(
                zip_uri='http://github.com/repo/download.zip', is_url=True,
                clone_to_dir=tempdir, no_input=True) is not None
        finally:
            shutil.rmtree(tempdir)

# Generated at 2022-06-23 16:39:02.880246
# Unit test for function unzip
def test_unzip():
    try:
        import zipfile
    except ImportError:
        import nose
        raise nose.SkipTest
    from cookiecutter.utils import rmtree
    from cookiecutter import main

    fd, zip_path = tempfile.mkstemp(prefix='cookiecutter-', suffix='.zip')
    os.close(fd)
    make_zip = zipfile.ZipFile(zip_path, 'w')
    make_zip.writestr("cookiecutter.json", '{"repo": "https://github.com/audreyr/cookiecutter-pypackage.git"}')
    make_zip.writestr("foo.txt", "Hi there!")
    make_zip.close()

    unzip_path = unzip(zip_path, is_url=False)

# Generated at 2022-06-23 16:39:09.710173
# Unit test for function unzip
def test_unzip():
    test_zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    test_is_url = True
    test_clone_to_dir = '.'
    test_no_input = False
    test_password = None
    unzip(test_zip_uri,
          test_is_url,
          test_clone_to_dir,
          test_no_input,
          test_password)

# Generated at 2022-06-23 16:39:18.128951
# Unit test for function unzip
def test_unzip():
    """Test unzip function is correct."""
    import shutil
    import time
    backup_cwd = os.getcwd()
    try:
        tmp_dir = tempfile.mkdtemp()
        os.chdir(tmp_dir)
        unzip('https://github.com/pydanny/cookiecutter-django/archive/2.0.0.zip', True, '.', True)
        assert os.listdir(tmp_dir) == ['cookiecutter-django-2.0.0']
        shutil.rmtree(tmp_dir)
    finally:
        os.chdir(backup_cwd)

# Generated at 2022-06-23 16:39:19.513671
# Unit test for function unzip
def test_unzip():
    assert unzip("cookiecutter.zip", True, ".")

# Generated at 2022-06-23 16:39:26.561708
# Unit test for function unzip
def test_unzip():
    import tempfile
    import zipfile
    import shutil

    password = "Test12345"

    unzip_dir = tempfile.mkdtemp()
    test_dir = tempfile.mkdtemp()
    test_zip = tempfile.mkstemp(suffix=".zip")[1]
    test_dir_name = 'test_dir'
    test_file_name = 'test_file.txt'
    test_text = "Test"

    # Create temporary source directory
    source_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(source_dir, test_dir_name))
    test_file = open(os.path.join(source_dir, test_dir_name, test_file_name), 'w')
    test_file.write(test_text)


# Generated at 2022-06-23 16:39:30.655317
# Unit test for function unzip
def test_unzip():
    zip_uri = 'zip+https://github.com/davidbrochart/cookiecutter-pypackage-minimal/archive/master.zip#cookiecutter-pypackage-minimal-master'
    is_url = True
    clone_to_dir = '~/cookiecutter-repos'
    unzip(zip_uri, is_url, clone_to_dir)

# Generated at 2022-06-23 16:39:35.848704
# Unit test for function unzip
def test_unzip():
    unzip('https://api.github.com/repos/audreyr/cookiecutter-pypackage/zipball', True)
    unzip('zipfile.zip', False)
    unzip('https://github.com/Robpol86/cookiecutter-readthedocs/archive/master.zip', True, password='cookiecutter')

# Generated at 2022-06-23 16:39:37.376021
# Unit test for function unzip
def test_unzip():
    # test unzip function
    pass

# Generated at 2022-06-23 16:39:39.245871
# Unit test for function unzip
def test_unzip():
    """Test utility function unzip()."""
    unzip('.')
    assert 1 == 2

# Generated at 2022-06-23 16:39:52.417528
# Unit test for function unzip
def test_unzip():
    import pytest
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.prompt import read_user_yes_no

    DEFAULT_CONFIG.clear()
    # Clearing the cache to avoid making this test run
    # too slow by fetching templates each time.
    CACHE_DIR = os.path.join(utils.WORKING_DIR, DEFAULT_CONFIG['cookiecutters_dir'])
    if os.path.exists(CACHE_DIR):
        shutil.rmtree(CACHE_DIR)
    cookiecutter('tests/test-cookiecutters/foobar-zip')

    # Create our own copy of the 'foobar-zip' template
    # so we'll have something

# Generated at 2022-06-23 16:39:54.628197
# Unit test for function unzip
def test_unzip():
    pass
    # TODO: Write a unit test for function unzip

# Generated at 2022-06-23 16:40:04.788553
# Unit test for function unzip
def test_unzip():
    response = unzip("https://github.com/bcarrelli/cookiecutter-py-package/archive/v1.0.0.zip", True)
    assert os.path.exists(response) is True
    assert os.path.isdir(response) is True
    assert len(os.listdir(response)) > 0

    response = unzip("https://github.com/bcarrelli/cookiecutter-py-package/archive/v1.0.0.zip", True, password="12345")
    assert os.path.exists(response) is True
    assert os.path.isdir(response) is True
    assert len(os.listdir(response)) > 0

    response = tempfile.mkdtemp()

# Generated at 2022-06-23 16:40:15.844938
# Unit test for function unzip
def test_unzip():
    import pytest
    from zipfile import ZIP_DEFLATED, ZipFile
    from datetime import datetime
    from tempfile import mkstemp, mkdtemp

    # Create a test zip file
    (zip_fd, zip_path) = mkstemp()
    zip_file = ZipFile(zip_path, "w", ZIP_DEFLATED)

    # Contents of test directory

# Generated at 2022-06-23 16:40:23.268493
# Unit test for function unzip
def test_unzip():
    import shutil
    import stat

    # Prepare test environment
    zip_uri = 'https://github.com/bborbe/cookiecutter-debian/archive/master.zip'
    clone_to_dir = 'tmp'
    make_sure_path_exists(clone_to_dir)
    zip_path = os.path.join(clone_to_dir, 'bborbe-cookiecutter-debian-master.zip')
    if os.path.exists(zip_path):
        download = True
    else:
        download = True

    # Download bborbe/cookiecutter-debian
    if download:
            # (Re) download the zipfile
        r = requests.get(zip_uri, stream=True)

# Generated at 2022-06-23 16:40:33.710297
# Unit test for function unzip
def test_unzip():
    import xml.etree.ElementTree as ET
    import shutil
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    zip_file = shutil.make_archive(base_dir + '/test_zip_package', 'zip', base_dir + '/test/repo')
    unzip_path = unzip(zip_file, False, base_dir)
    filelist = os.listdir(unzip_path)
    assert len(filelist) != 0 and len(filelist) != 1
    tree = ET.parse(unzip_path + '/test_repo.txt')
    root = tree.getroot()
    assert root.text == 'test repo'

# Generated at 2022-06-23 16:40:42.663605
# Unit test for function unzip
def test_unzip():
    import mock
    import requests_mock
    import shutil
    import tempfile

    # Create a dummy zip file
    temp_dir = tempfile.mkdtemp()
    temp_zip = tempfile.NamedTemporaryFile(suffix='.zip', delete=False)
    temp_zip.close()
    # Create a dummy zip file
    with ZipFile(temp_zip.name, 'w') as temp_zip_file:
        temp_zip_file.writestr('test/', '')
    with mock.patch('cookiecutter.utils.ZipFile.extractall') as foo:
        foo.return_value = None
        unzip(temp_zip.name, is_url=False, clone_to_dir=temp_dir)
        assert foo.called
    shutil.rmtree(temp_dir)

# Generated at 2022-06-23 16:40:54.167703
# Unit test for function unzip
def test_unzip():
    """
    Test unzip function
    """
    import sh
    import shutil
    # Create a temporary git repository
    repo_base = tempfile.mkdtemp()
    shutil.copytree(test_repo_dir, os.path.join(repo_base, 'test-repo'))
    sh.git('init', cwd=os.path.join(repo_base, 'test-repo'), _tty_out=False)
    sh.git('add', '.', cwd=os.path.join(repo_base, 'test-repo'), _tty_out=False)
    sh.git('commit', '-m', '"Initial commit"',
           cwd=os.path.join(repo_base, 'test-repo'), _tty_out=False)
    # Create zip

# Generated at 2022-06-23 16:40:55.028385
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:41:04.501199
# Unit test for function unzip
def test_unzip():
    from tests.test_utils import get_default_repo

    repo_dir = os.path.dirname(get_default_repo())
    zip_file = os.path.join(repo_dir, 'cookiecutter-pypackage.zip')
    is_url = False
    tmp_dir = os.path.join(repo_dir, 'cookiecutter-pypackage-zip-test')

    unzip_path = unzip(zip_file, is_url, clone_to_dir=tmp_dir, no_input=True)
    # print(os.listdir(unzip_path))
    assert os.path.exists(unzip_path)

# Generated at 2022-06-23 16:41:06.659318
# Unit test for function unzip
def test_unzip():
    pass
    #TODO: create a test showing that the function unzip returns the
    # path to the directory where the file was extracted.

# Generated at 2022-06-23 16:41:07.586419
# Unit test for function unzip
def test_unzip():
    assert unzip("no-repo",False)

# Generated at 2022-06-23 16:41:14.318579
# Unit test for function unzip
def test_unzip():
    clone_to_dir = 'repo_cache'
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.3.zip'
    unzip_path = unzip(zip_uri, True, clone_to_dir)

    subdir = os.path.join(unzip_path, 'tests')
    assert os.path.isdir(subdir)
    assert os.path.exists(os.path.join(subdir, 'test_cookiecutter.py'))


# Generated at 2022-06-23 16:41:24.379602
# Unit test for function unzip
def test_unzip():
    # Setup
    clone_to_dir = tempfile.mkdtemp()
    zip_uri = os.path.join(os.path.dirname(__file__), 'test_data/zip_test/test.zip')

    # Execution
    unzip_path = unzip(zip_uri, clone_to_dir, False)

    # Assertion
    assert os.path.exists(unzip_path) is True, "Zip archive failed to extract!"
    assert os.path.isfile(unzip_path + '/cookiecutter.json') is True, \
        "Zip archive's top directory failed to extract contents!"

    # Teardown
    os.remove(clone_to_dir + '/test.zip')
    os.rmdir(clone_to_dir)

# Generated at 2022-06-23 16:41:33.833711
# Unit test for function unzip
def test_unzip():
    from pathlib import Path
    from .test_utils import TEST_COOKIECUTTER
    from shutil import rmtree

    repo_zip_file = os.path.join(TEST_COOKIECUTTER, "repo_zips",
                                 "test_repo_1_zip.zip")
    if Path(repo_zip_file).exists():
        repo_zip_file = Path(repo_zip_file)
    else:
        raise Exception(repo_zip_file + " not found.")

    unziped_repo_path = unzip(repo_zip_file, False)
    assert Path(unziped_repo_path).exists()
    rmtree(unziped_repo_path)

# Generated at 2022-06-23 16:41:34.677020
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:41:45.722734
# Unit test for function unzip
def test_unzip():
    # assert the function unzip at least works
    assert(isinstance(unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", is_url = 1), str))

    # assert an exception is raised when the url is invalid
    try:
        unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip", is_url = 0)
        assert(False)
    except InvalidZipRepository:
        assert(True)
        
    # assert an exception is raised when the url is empty

# Generated at 2022-06-23 16:41:54.315231
# Unit test for function unzip

# Generated at 2022-06-23 16:42:00.237780
# Unit test for function unzip
def test_unzip():
    zip_uri = zip_path = os.path.join(os.path.dirname(__file__), 'repo_with_nested_dir.zip')
    project_name = 'repo_with_nested_dir'
    assert unzip(zip_uri, is_url=False) == os.path.join(tempfile.mkdtemp(), project_name)

# Generated at 2022-06-23 16:42:10.542463
# Unit test for function unzip
def test_unzip():
    # Set up a fake zip file, but don't write it to disk.
    # This is because the test might fail if the user is on Windows,
    # and password protected files can't be created on Windows.
    # (See http://bugs.python.org/issue8851)
    zip_file = tempfile.SpooledTemporaryFile()
    zip_file.name = 'Archive.zip'
    zip_file.write(b'PK\x03\x04\x14\x00\x00\x00\x00\x00\x14\x00\x00\x00\x08\x00\x00\x00test_dir/')

# Generated at 2022-06-23 16:42:15.660662
# Unit test for function unzip
def test_unzip():
    # Test if function works
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', is_url=True)
    # Test if pack is too small
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', is_url=True, password='COOKIECUTTER')

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-23 16:42:25.976905
# Unit test for function unzip
def test_unzip():
    # _unzip_is_here = _get_unzip_here()
    is_url = True
    clone_to_dir = '.'
    no_input = False

    # URL containing a zip archive of https://github.com/hhatto/cookiecutter-pypackage
    zip_uri = 'https://github.com/hhatto/cookiecutter-pypackage/archive/master.zip'
    unpack = unzip(zip_uri, is_url, clone_to_dir, no_input)
    assert unpack is not None

    # URL containing a zip archive of https://github.com/audreyr/cookiecutter-pypackage
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'

# Generated at 2022-06-23 16:42:29.026416
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)

# Generated at 2022-06-23 16:42:29.655418
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:42:39.048871
# Unit test for function unzip
def test_unzip():
    from zipfile import ZipFile
    from tempfile import mkdtemp
    from cookiecutter.repository import paths_equal

    test_zip_content = ['test_folder/', 'test_folder/test.txt']
    tmp_dir = mkdtemp()
    tmp_zipfile = os.path.join(tmp_dir, 'temp_file.zip')
    zipfile = ZipFile(tmp_zipfile, 'w')
    zipfile.writestr(test_zip_content[1], b'test')
    zipfile.close()


# Generated at 2022-06-23 16:42:45.883217
# Unit test for function unzip
def test_unzip():
    # Workaround make_sure_path_exists method
    def make_sure_path_exists(path):
        pass
    unzip('/Users/emvaos/Projects/cookiecutter-python/tests/test-data/fake-repo'
          '-tmpl/templates/fake-repo/',
          'is_url=False')
# End of unit test for function unzip

# Generated at 2022-06-23 16:42:52.365059
# Unit test for function unzip
def test_unzip():
    import shutil
    try:
        zip_dir = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
        assert os.path.isdir(zip_dir) == True
    finally:
        shutil.rmtree(zip_dir)

# Generated at 2022-06-23 16:42:59.741841
# Unit test for function unzip
def test_unzip():
    """
    Unit test to validate unzip functionality
    """
    import contextlib
    import sys
    import zipfile

    @contextlib.contextmanager
    def captured_output():
        """
        Capturing the standard output while running unzip.
        """
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-23 16:43:00.950097
# Unit test for function unzip
def test_unzip():
    # Not needed for now.
    pass

# Generated at 2022-06-23 16:43:03.213301
# Unit test for function unzip
def test_unzip():
    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)

# Generated at 2022-06-23 16:43:07.752433
# Unit test for function unzip
def test_unzip():
    #unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',True)
    unzip('/home/user/Projects/ccott-core/cookiecutter-django/cookiecutter-django.zip',False)

test_unzip()

# Generated at 2022-06-23 16:43:13.906457
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url = True
    clone_to_dir='.'
    no_input = False
    password = None
    try:
        tmp_dir = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
        print(tmp_dir)
    except Exception as e:
        print(e)
    else:
        print("SUCCESS")

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-23 16:43:20.720533
# Unit test for function unzip
def test_unzip():
    import base64
    import json

    def zipfile_info(zip_uri, password=None):
        r = requests.get(zip_uri)
        data = json.loads(r.text)
        zip_path = base64.b64decode(data['zip'])
        zip_file = ZipFile(zip_path)
        return zip_file.namelist(), data['dir']

    zip_uri = 'http://localhost/zipfile'
    zlist, zdir = zipfile_info(zip_uri)
    unzip_path = unzip(zip_uri, True)
    zlist_test = os.listdir(unzip_path)
    assert zlist == zlist_test
    assert 'myproj' == zdir

    zip_uri = 'http://localhost/zipfile_passwd'
    password

# Generated at 2022-06-23 16:43:26.240138
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import zipfile
    import logging
    import requests

    # Create a file which will be packed in the test zipfile archive
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    tempdir = "/tmp/test_unzip/"
    if os.path.exists(tempdir):
        shutil.rmtree(tempdir)
    os.makedirs(tempdir)
    test_filename = os.path.join(tempdir, "main.py")
    with open(test_filename, "w+") as f:
        f.write("#!/usr/bin/python\n")
        f.write("print('Hello world')\n")

    # Create a local zipfile; we will download it later
    # Then un

# Generated at 2022-06-23 16:43:33.515726
# Unit test for function unzip
def test_unzip():
    # testing function with valid input
    path = unzip("https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip",True)
    assert os.path.exists(path)
    # testing function with invalid input
    # testing function with valid input and using password
    path = unzip("https://github.com/Saumitra-Shukla/Protected-Repository/archive/master.zip",True,".","",'Password')
    assert os.path.exists(path)

# Generated at 2022-06-23 16:43:44.471609
# Unit test for function unzip
def test_unzip():
    from cookiecutter.main import cookiecutter
    import os.path
    import shutil
    import zipfile
    repo_name = 'gh:audreyr/cookiecutter-pypackage'
    temp_repo_path = 'tests/test-repos/cookiecutter-pypackage'
    clone_to_dir = 'tests/test-downloads'
    zip_path = os.path.join(clone_to_dir, 'cookiecutter-pypackage.zip')
    if os.path.isdir(temp_repo_path):
        shutil.rmtree(temp_repo_path)
    if not os.path.isdir(clone_to_dir):
        os.makedirs(clone_to_dir)

# Generated at 2022-06-23 16:43:50.994606
# Unit test for function unzip
def test_unzip():
    # create a zip file to test
    #
    # we are not testing the request.get path so we will just make an empty
    # one of these
    zip_uri = ""
    is_url = False
    clone_to_dir = "."
    no_input = False
    password = None

    unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    pass

# Generated at 2022-06-23 16:44:02.420258
# Unit test for function unzip
def test_unzip():
    import requests_mock

    # Mock a zipfile that includes a password-protected file

# Generated at 2022-06-23 16:44:09.853548
# Unit test for function unzip
def test_unzip():
    """Make sure the unzip function works"""
    import os
    import shutil
    import tempfile

    from zipfile import ZipFile

    # Where is the function?
    function_dir = os.path.dirname(os.path.abspath(__file__))

    # Create a temporary directory where this function can unzip to
    unzip_base = tempfile.mkdtemp()

    # Build the path to the zipfile
    zip_path = os.path.join(function_dir, '../tests/test-repo')

    # Unzip the archive (in this case into the temporary directory)
    unzip_path = unzip(zip_path, False, clone_to_dir=unzip_base)

    # Make sure the function returns a correct path to the unzipped directory

# Generated at 2022-06-23 16:44:14.945611
# Unit test for function unzip
def test_unzip():
    import requests.exceptions
    import zipfile
    import os
    import shutil
    import tempfile

    SUCCESS_URL = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    FAILURE_URL = "https://github.com/audreyr/not-a-zipfile/archive/master.zip"
    FAILURE_URL_ZIP = "https://github.com/audreyr/not-a-zipfile/archive/master.zip.zip"
    FAILURE_URL_TEXT = "https://raw.githubusercontent.com/audreyr/cookiecutter/master/README.rst"
    TESTFILE_NAME = "cookiecutter-pypackage-master.zip"

# Generated at 2022-06-23 16:44:24.938764
# Unit test for function unzip
def test_unzip():
    """
    test_unzip
    """
    import shutil # Used to create a new directory 
    import zipfile # Used to create zip archive

    # Create temporary directory to store a zip archive, and a temporary project directory
    test_repo_dir = tempfile.mkdtemp()
    test_project_dir = tempfile.mkdtemp()

    # Define a test directory structure
    test_repo_name = 'test_repo'
    test_repo_path = os.path.join(test_repo_dir, test_repo_name)
    os.makedirs(test_repo_path)
    os.makedirs(os.path.join(test_repo_path, "subdir"))