

# Generated at 2022-06-23 16:34:30.525151
# Unit test for function unzip
def test_unzip():
    """
    Test that unzip function is working properly
    """
    import subprocess
    import shutil

    # create a zip repo and put it in the temp_path
    temp_path = os.path.join(os.path.dirname(__file__), 'temp')
    if not os.path.isdir(temp_path):
        os.makedirs(temp_path)

    cookiecutter_path = os.path.abspath(os.path.dirname(__file__))
    cookiecutter_path = os.path.join(cookiecutter_path, os.pardir)
    cookiecutter_path = os.path.join(cookiecutter_path, 'tests')

    source_path = os.path.join(cookiecutter_path, 'fake-repo-tmpl')
    subprocess

# Generated at 2022-06-23 16:34:37.808820
# Unit test for function unzip
def test_unzip():
    import glob
    import zipfile
    myzip = zipfile.ZipFile("test.zip", "w")
    myzip.write("test_dir/test.txt", "test.txt", zipfile.ZIP_DEFLATED)
    for i in glob.glob("*"):
        myzip.write(i, os.path.basename(i), zipfile.ZIP_DEFLATED)
    myzip.close()
    unzip("test.zip", False)


# Generated at 2022-06-23 16:34:48.239379
# Unit test for function unzip
def test_unzip():
    try:
        import git
    except ImportError:
        import nose
        raise nose.SkipTest("GitPython not installed")
    else:
        git_repo_url = 'https://github.com/hackebrot/cookiecutter-pypackage.git'
        repo_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:34:49.010439
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:34:49.574623
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:34:50.077553
# Unit test for function unzip
def test_unzip():
    assert 0 == 0

# Generated at 2022-06-23 16:34:56.928384
# Unit test for function unzip
def test_unzip():
    import tempfile
    from .unicode_literals import utf8
    from .zipfile import _as_zipfile_or_bytes

    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b'')
    f.close()
    assert os.path.isfile(f.name)

    z = _as_zipfile_or_bytes(f.name)
    assert isinstance(z, ZipFile)
    with open(z.filename, 'rb') as fh:
        assert fh.read() == b''
    os.unlink(z.filename)

    _as_zipfile_or_bytes(f.name)

    f = tempfile.NamedTemporaryFile(delete=False, suffix=utf8(".zip"))
    f.write(b'')
    f

# Generated at 2022-06-23 16:35:04.902341
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile
    import unittest
    import sys

    class TestUnzip(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.zip_path = os.path.join(self.tmpdir, 'test.zip')
            with ZipFile(self.zip_path, 'w') as test_zip:
                test_zip.writestr('testfile', b'This is a test')
                test_zip.writestr('testdir/testfile2', b'This is another test')
                test_zip.writestr('testdir/testfile3', b'This is a third test')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-23 16:35:14.223748
# Unit test for function unzip
def test_unzip():
    import shutil
    import pytest

    # Create a temporary directory for the tests
    tmp_dir = tempfile.mkdtemp()
    # Define a test zip file
    test_zip_file = os.path.join(tmp_dir, 'test.zip')

    # Create the test zipfile
    import zipfile
    zf = zipfile.ZipFile(test_zip_file, mode='w')
    try:
        test_contents = 'Hello world!\n'
        zf.writestr('test.txt', test_contents)
    finally:
        zf.close()

    # Unzip the test zipfile into a temporary directory
    unzip_dir = unzip(test_zip_file, False)

    # Check to make sure the file was unzipped

# Generated at 2022-06-23 16:35:17.579795
# Unit test for function unzip
def test_unzip():
    """ Unit test for function unzip """
    import pytest

    with pytest.raises(TypeError):
        unzip(1, False, '.', True)     # non-string input should cause TypeError


# Generated at 2022-06-23 16:35:18.111242
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:35:25.120527
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip."""

    import requests
    import shutil
    import tempfile
    import unittest

    class MockResponse(object):
        def __init__(self):
            with open('tests/test-data/good_zip.zip', 'rb') as f:
                self.content = f.read()

        def iter_content(self, chunk_size):
            yield self.content

    class MockRequestsModule(object):
        def get(self, url, stream=True):
            return MockResponse()

    class TestCase(unittest.TestCase):
        """Unit test for function unzip."""

        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.clone_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:35:30.936371
# Unit test for function unzip
def test_unzip():
    function_to_test = unzip(
        zip_uri = '/rhevm-automation/projects/vsphere_project/vsphere_project.zip',
        is_url = False,
        clone_to_dir = '.',
        no_input = True,
        password = None
    )
    expected_result = 'C:\\Users\\vyas.shantaram\\AppData\\Local\\Temp\\tmpz2m6bv_d\\vsphere_project'
    assert function_to_test == expected_result

# Generated at 2022-06-23 16:35:33.184061
# Unit test for function unzip
def test_unzip():
    test_zip = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    assert unzip(test_zip, is_url=True)

# Generated at 2022-06-23 16:35:39.855412
# Unit test for function unzip
def test_unzip():
    """Test the unzip function"""
    temp_dir = tempfile.mkdtemp()
    unzip_path = unzip(zip_uri='https://github.com/hackebrot/cookiecutter-pytest-plugin/archive/master.zip',
                       is_url=True,
                       clone_to_dir=temp_dir)
    assert 'cookiecutter.json' in os.listdir(unzip_path)

# Generated at 2022-06-23 16:35:45.940470
# Unit test for function unzip
def test_unzip():
    from cookiecutter import main

    # test unzip with URL
    unzip_path = unzip(
        zip_uri='https://github.com/audreyr/cookiecutter-pypackage/zipball/a3d3e4/',
        is_url=True,
        clone_to_dir=main.DEFAULT_REPO_DIR)

    # test unzip with file
    unzip_path = unzip(
        zip_uri=unzip_path,
        is_url=False,
        clone_to_dir=main.DEFAULT_REPO_DIR)

    pass

# Generated at 2022-06-23 16:35:57.080982
# Unit test for function unzip
def test_unzip():
    assert unzip('http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True) == os.path.join(os.path.dirname(os.path.dirname(__file__)), 'tests', 'fake-repo-tmpl')
    assert unzip('tests/fake-repo-tmpl/cookiecutter-pypackage-master.zip', False) == os.path.join(os.path.dirname(os.path.dirname(__file__)), 'tests', 'fake-repo-tmpl')

# Generated at 2022-06-23 16:36:02.784411
# Unit test for function unzip
def test_unzip():
    """Test the unzip function."""
    assert unzip(
        zip_uri='https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
        is_url='True',
        clone_to_dir='.',
        no_input='False',
        password=None
        )

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-23 16:36:11.269201
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '~')
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '~', True)
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '~', True, 'password')
    unzip('~/cookiecutter-pypackage-master', False)
    unzip('~/cookiecutter-pypackage-master', False, '~')

# Generated at 2022-06-23 16:36:20.412641
# Unit test for function unzip
def test_unzip():
    unzip("/root/cookiecutter/test.zip",True)
    # zip_path = "/root/cookiecutter/test.zip"
    # # Now unpack the repository. The zipfile will be unpacked
    # # into a temporary directory
    # try:
    #     zip_file = ZipFile(zip_path)
    #     print("3")
    #     # if len(zip_file.namelist()) == 0:
    #     #     raise InvalidZipRepository("Zip repository {} is empty".format(zip_uri))
    #
    #     # # The first record in the zipfile should be the directory entry for
    #     # # the archive. If it isn't a directory, there's a problem.
    #     # first_filename = zip_file.namelist()[0]
    #     # if not

# Generated at 2022-06-23 16:36:29.669010
# Unit test for function unzip
def test_unzip():
    from zipfile import ZipFile
    from cookiecutter.prompt import read_repo_password
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter import utils
    # Prepare a test zipfile
    zip_base = tempfile.mkdtemp()
    repo_dir = os.path.join(zip_base, DEFAULT_CONFIG['default_context'])
    utils.make_sure_path_exists(repo_dir)
    template_data = "{{ cookiecutter }}"
    template_file = os.path.join(repo_dir, 'test_template.txt')
    with open(template_file, 'w') as f:
        f.write(template_data)
    zip_file = os.path.join(zip_base, 'test_repo.zip')

# Generated at 2022-06-23 16:36:32.031860
# Unit test for function unzip
def test_unzip():
    assert os.path.exists('https://github.com/asamalik/cookiecutter-pyramid')

# Generated at 2022-06-23 16:36:40.739063
# Unit test for function unzip
def test_unzip():
    """ Test unzip function"""
    import pytest
    from cookiecutter import main

    with pytest.raises(InvalidZipRepository):
        unzip('tests/test-repo-tmpl/', False)

    result = unzip('tests/test-repo-tmpl-master.zip', False)

    assert os.path.exists(os.path.expanduser('~/.cookiecutters'))
    assert os.path.exists(result)
    assert os.path.isdir(result)
    assert main.cookiecutter(result) == 0

    os.remove('tests/test-repo-tmpl-master.zip')
    os.remove(result)

# Generated at 2022-06-23 16:36:48.389677
# Unit test for function unzip
def test_unzip():
    import shutil

    test_zip_path = os.path.join('tests', 'test-unzip-repo.zip')
    workdir = tempfile.mkdtemp()
    unzip_path = unzip(test_zip_path, is_url=False, clone_to_dir=workdir)
    test_files = ['example.file', 'example.file1']
    assert os.listdir(unzip_path) == test_files
    shutil.rmtree(workdir)
    assert not os.path.exists(workdir)


# Generated at 2022-06-23 16:36:57.511761
# Unit test for function unzip
def test_unzip():
    # create a zip file under tmp dir
    test_data_path= 'C:\\Users\\tran\\AppData\\Local\\Temp\\tmpeoacw_r5\\test_data'
    test_file_path = 'C:\\Users\\tran\\AppData\\Local\\Temp\\tmpeoacw_r5\\test_data\\cookiecutter.json'
    test_zip_path = 'C:\\Users\\tran\\AppData\\Local\\Temp\\test.zip'
    import zipfile
    from shutil import copyfile
    copyfile(test_file_path, test_zip_path)
    z = zipfile.ZipFile(test_zip_path, 'a')

# Generated at 2022-06-23 16:37:00.760989
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)

# Generated at 2022-06-23 16:37:12.215483
# Unit test for function unzip
def test_unzip():
    import tempfile
    import zipfile
    import shutil
    import subprocess
    import os
    import time
    import requests

    test_base_dir = tempfile.mkdtemp()

    #Create dummy zip file with a directory within it.
    create_test_zip_path = os.path.join(test_base_dir, 'repo.zip')
    create_test_zip_path = create_test_zip_path.encode()
    create_test_zip = zipfile.ZipFile(
        create_test_zip_path,
        'w'
    )

    create_test_zip.writestr(
        'test_tmp/test_tmp/test_tmp/test.txt',
        'test'
    )
    create_test_zip.close()

    # This will test the unzip function

# Generated at 2022-06-23 16:37:18.906324
# Unit test for function unzip
def test_unzip():
    import shutil
    # create a dummy repo
    def create_zip_repo(zip_file_path):
        from zipfile import ZipFile
        from tempfile import mkdtemp
        from shutil import rmtree
        repo = mkdtemp()
        with open(os.path.join(repo, 'README.md'), 'w') as f:
            f.write('project_dir')
        with ZipFile(zip_file_path, 'w') as zip:
            zip.write(repo, arcname='project_dir')
        rmtree(repo)
    # create zip repo
    repo_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'

# Generated at 2022-06-23 16:37:25.642851
# Unit test for function unzip
def test_unzip():
    """Test that the unzip function works properly
    """
    # Note: this will just test that the function is runable
    # but further test will be needed to ensure validity of the output
    unzip('http://networkx.lanl.gov/download/networkx/networkx-1.9.1.zip', is_url=True)
    unzip('https://github.com/RPDataScience/cookiecutter-r-project.git', is_url=False)
    unzip('https://github.com/nvie/cookiecutter-pypackage.git', is_url=False)

# Generated at 2022-06-23 16:37:36.592285
# Unit test for function unzip
def test_unzip():
    """
    I'm just checking that running this function doesn't raise and error
    """
    from cookiecutter import prompt

    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
          is_url=True,
          clone_to_dir='.',
          no_input=False,
          password=None)

    unzip('tests/fake-repo-tmpl/',
          is_url=False,
          clone_to_dir='.',
          no_input=False,
          password=None)

    unzip('tests/fake-repo-tmpl-password/',
          is_url=False,
          clone_to_dir='.',
          no_input=False,
          password='secret')


# Generated at 2022-06-23 16:37:46.988933
# Unit test for function unzip
def test_unzip():
    # Unit tests for function unzip
    import unittest
    import shutil
    import zipfile

    def _create_zip_file(password=None):
        zip_file = tempfile.NamedTemporaryFile(delete=False)
        zip_file.close()

        with open('test_zip_file.txt', 'w') as f:
            f.write('This is a test zip file')

        with zipfile.ZipFile(zip_file.name, 'w', zipfile.ZIP_DEFLATED) as myzip:
            myzip.write('test_zip_file.txt')

        if password is None:
            return zip_file.name
        else:
            zip_file = ZipFile(zip_file.name, 'a')

# Generated at 2022-06-23 16:37:48.063939
# Unit test for function unzip
def test_unzip():
    assert unzip('f', False) is not None

# Generated at 2022-06-23 16:37:54.330862
# Unit test for function unzip
def test_unzip():
    # Test with invalid zip file
    file_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tests/test-data/test-zip/test_zip.invalid.zip'
    )
    try:
        unzip(zip_uri=file_path, is_url=False, clone_to_dir='.', no_input=True, password='password')
    except InvalidZipRepository:
        pass



# Generated at 2022-06-23 16:38:01.699738
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    clone_to_dir = '/tmp/cookiecutter'

    unzip_path = unzip(zip_uri, True, clone_to_dir, False)

    assert os.path.exists(unzip_path) is True
    assert unzip_path.startswith(clone_to_dir) is False
    assert unzip_path.startswith('/tmp') is True

# Generated at 2022-06-23 16:38:02.432698
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:38:08.587036
# Unit test for function unzip
def test_unzip():
    import tempfile
    import shutil
    import os
    import zipfile
    from cookiecutter.utils import work_in
    from cookiecutter import utils
    from cookiecutter.utils import make_sure_path_exists
    from cookiecutter.zipfile import unzip

    tmpdir = tempfile.mkdtemp()
    make_sure_path_exists(tmpdir)
    with work_in(tmpdir):

        def make_zip(zipname, dirname='.', password=None):
            with zipfile.ZipFile(zipname, 'w') as zipf:
                zipf.write(dirname, arcname=os.path.basename(dirname))
                zipf.setpassword(password)

        make_zip('zip_repo.zip', dirname='repo', password='foobar')

# Generated at 2022-06-23 16:38:20.088655
# Unit test for function unzip
def test_unzip():
    """Test the unzip function"""
    import shutil
    import tempfile
    import requests
    # Create zip file in temp directory
    tempdir = tempfile.mkdtemp()
    zip_path = os.path.join(tempdir, '{}_test.zip'.format('cookiecutter'))
    zip_uri = 'http://github.com/audreyr/cookiecutter/archive/master.zip'
    r = requests.get(zip_uri, stream=True)
    with open(zip_path, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:  # filter out keep-alive new chunks
                f.write(chunk)

    # Unzip and test

# Generated at 2022-06-23 16:38:30.111479
# Unit test for function unzip
def test_unzip():
    """Test unzip archive created with a password."""
    password = 'secret'

    # Create archive
    path = os.path.dirname(os.path.abspath(__file__))
    zip_file = os.path.join(path, 'test.zip')
    import shutil
    shutil.make_archive(path + '/test', 'zip', path + '/test_folder', False)
    import zipfile
    zip_file1 = zipfile.ZipFile(path + '/test.zip', 'w')
    zip_file1.setpassword('secret'.encode('utf-8'))
    zip_file1.write(path + '/test_folder/data.txt', 'data.txt')
    zip_file1.close()

    # Unzip archive

# Generated at 2022-06-23 16:38:39.469858
# Unit test for function unzip
def test_unzip():
    import requests_mock
    import inspect
    from contextlib import contextmanager
    from . import test
    from cookiecutter import utils
    from cookiecutter.utils import (
        work_in, rmtree as cookiecutter_rmtree)

    # The zipfile to unpack.
    # The zipfile contains:
    # - a text file,
    # - a password protected text file,
    # - a folder containing two text files.
    # This is the unzip archive:
    # cookiecutter_unzip_test
    # |
    # |-cookiecutter_unzip_test
    # |  |-file.txt
    # |
    # |-protected_file.txt

    zip_uri = 'https://github.com/cookiecutter-testing/cookiecutter_unzip_test'


# Generated at 2022-06-23 16:38:49.154098
# Unit test for function unzip
def test_unzip():
    import pytest
    from zipfile import ZipFile

    from cookiecutter.main import cookiecutter

    import shutil
    import os
    import logging

    logging.getLogger('cookiecutter').setLevel(logging.INFO)

    # Delete the existing cookiecutters directory
    if os.path.exists(os.path.expanduser('~/.cookiecutters')):
        shutil.rmtree(os.path.expanduser('~/.cookiecutters'))

    # Zip up the test repository
    zip_fname = 'tests/test-repo-pre/README.rst.zip'

# Generated at 2022-06-23 16:38:54.679421
# Unit test for function unzip
def test_unzip():
    """
    Test Function that tests the unzip function which downloads and unpacks a zipfile.
    :return: None
    """
    # Create temp directory to test in
    import tempfile
    from os import path
    from cookiecutter.utils import make_sure_path_exists
    from cookiecutter.repository import find_template
    from cookiecutter.config import get_user_config

    root_temp_dir = tempfile.mkdtemp()
    temp_dir = os.path.join(root_temp_dir, 'cookiecutter-unzip-test')
    make_sure_path_exists(temp_dir)

    template_url = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'

# Generated at 2022-06-23 16:39:03.952068
# Unit test for function unzip
def test_unzip():
    permission_error = False
    repo_with_password = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    clone_to_dir = os.path.join('tests', '_unzip', 'unzip_test')
    make_sure_path_exists(clone_to_dir)
    
    try:
        unzip(repo_with_password, True, clone_to_dir, password='Test1234')
    except InvalidZipRepository:
        permission_error = True
    
    assert permission_error is True
    permission_error = False
    
    try:
        unzip(repo_with_password, True, clone_to_dir, password='Test12345')
    except InvalidZipRepository:
        permission_error = True
    
   

# Generated at 2022-06-23 16:39:10.687738
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/gforsyth/cookiecutter-pypackage/archive/0.2.7.zip'
    is_url = True
    clone_to_dir = '.'
    no_input = True
    password = None
    unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    print(unzip_path)


if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-23 16:39:11.714434
# Unit test for function unzip
def test_unzip():
    assert unzip.func_code is not None

# Generated at 2022-06-23 16:39:22.105054
# Unit test for function unzip
def test_unzip():
    """Test function unzip for regression."""
    zip_uri = 'tests/files/invalid_zipfile'
    is_url = False
    clone_to_dir = 'tests/files/'
    no_input = True
    password = None
    try:
        unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    except InvalidZipRepository:
        pass
    else:
        raise AssertionError('unzip did not raise InvalidZipRepository')

    zip_uri = 'tests/files/test_zipfile.zip'
    is_url = False
    clone_to_dir = 'tests/files/'
    no_input = True
    password = None

# Generated at 2022-06-23 16:39:30.625521
# Unit test for function unzip
def test_unzip():
    def run_test(uri, is_url, no_input=False, password=None):
        print()
        print('Testing unzip function with uri={}, is_url={}, no_input={}, password={}'.format(
            uri, is_url, no_input, password))
        unzip(uri, is_url, no_input=no_input, password=password)

    # Test unzip with a local file that is not a zip file
    local_zip_file = 'tests/files/fake_repo.zip'
    try:
        unzip(local_zip_file, is_url=False, no_input=True)
    except InvalidZipRepository as e:
        assert(e.args[0] == 'Zip repository tests/files/fake_repo.zip is not a valid zip archive')
   

# Generated at 2022-06-23 16:39:41.604555
# Unit test for function unzip
def test_unzip():
    """Ensure that unzip function works as expected. """

    import shutil
    from cookiecutter.utils import rmtree

    # Download a file and unzip it
    test_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    test_folder = tempfile.mkdtemp()
    try:
        unzip_path = unzip(test_url, True, test_folder)
    except:
        print("Unable to test unzip function")
        raise

    # Test if unzip_path is valid
    if not os.path.isdir(unzip_path):
        raise
        print("Invalid unzip path: " + unzip_path)

    # Remove unzipped directory
    rmtree(unzip_path)
    # Remove test folder

# Generated at 2022-06-23 16:39:53.425099
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import tempfile
    import unittest
    from zipfile import ZipFile, ZIP_DEFLATED
    from cookiecutter.prompt import read_repo_password

    class TestUnzip(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.zip')
            self.test_dir_unzip = os.path.join(self.test_dir, 'test_unzip')
            self.data_dir = os.path.join(self.test_dir, 'data')
            self.z = ZipFile(self.test_file, mode='w')
            self.z.debug = 1
            self.z.pwd

# Generated at 2022-06-23 16:40:02.292069
# Unit test for function unzip
def test_unzip():
    import tempfile
    from zipfile import   ZipFile
    from contextlib import contextmanager
    from cookiecutter.repository import unzip
    # Prepare
    @contextmanager
    def make_temp_file(data, is_zipfile=False):
        import tempfile
        handle, filename = tempfile.mkstemp(suffix='.zip' if is_zipfile else '')
        os.write(handle, data)
        os.close(handle)
        try:
            yield filename
        finally:
            os.unlink(filename)
    with make_temp_file(b'abc') as txt_filename:
        pass
    with make_temp_file(b'abc', is_zipfile=True):
        pass

# Generated at 2022-06-23 16:40:07.915468
# Unit test for function unzip
def test_unzip():
    """Unit test for function unzip."""
    import shutil

    temp_directory = tempfile.mkdtemp()
    repo_with_password = 'https://github.com/audreyr/cookiecutter-pypackage/archive/password.zip'

    # URL which is protected by password
    # GitHub does not let the file be downloaded
    # locally for testing for now.
    unzip_path = unzip(repo_with_password, True, clone_to_dir=temp_directory, no_input=False, password=None)
    assert os.path.isfile('/'.join([unzip_path, 'setup.py']))

    shutil.rmtree(temp_directory)

# Generated at 2022-06-23 16:40:17.188112
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile

    # create a temporary directory and temporary file.
    zip_path = tempfile.NamedTemporaryFile()
    clone_to_dir = tempfile.mkdtemp(suffix='cookiecutter')

    # create a zip archive with a single file.
    import zipfile
    with zipfile.ZipFile(zip_path.name, 'w') as zip_file:
        zip_file.writestr('index.txt', 'test')


# Generated at 2022-06-23 16:40:23.828506
# Unit test for function unzip
def test_unzip():
    from cookiecutter.repository import unzip
    import os

    optional_delim = '\\' if os.name == 'nt' else '/'
    relative_repo_dir = 'tests{}files{}test-zip.zip'.format(
        optional_delim, optional_delim
    )

    project_dir = unzip(
        relative_repo_dir,
        no_input=True,
        is_url=False,
    )

    assert os.path.exists(project_dir)
    assert os.path.exists(os.path.join(project_dir, 'cookiecutter.json'))
    assert os.path.exists(os.path.join(project_dir, '{{cookiecutter.project_slug}}'))


# Generated at 2022-06-23 16:40:34.077479
# Unit test for function unzip
def test_unzip():
    import shutil
    import tempfile
    from cookiecutter.exceptions import InvalidZipRepository

    valid_zip_uri = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    invalid_zip_uri = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip-invalid"
    local_zip_uri = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    local_zip_file = 'master.zip'


# Generated at 2022-06-23 16:40:41.951970
# Unit test for function unzip
def test_unzip():
    zip_uri = "https://github.com/cookiecutter/cookiecutter/archive/master.zip"
    unzip_path = unzip(zip_uri, True, clone_to_dir='tests/test-output/repo-templates')
    assert os.path.exists(unzip_path)
    assert unzip_path.startswith(tempfile.gettempdir())
    assert os.path.exists(os.path.join(unzip_path, 'README.rst'))
    assert os.path.exists(os.path.join(unzip_path, 'cookiecutter.json'))

# Generated at 2022-06-23 16:40:53.992720
# Unit test for function unzip
def test_unzip():
    import requests_mock
    from shutil import rmtree
    from tempfile import mkdtemp
    from tempfile import mktemp

    # Create the test data in a temporary directory.
    temp_dir = mkdtemp()

    # Simulate a zipfile that contains a directory, with a "real" file inside it.
    original_dir = os.path.join(temp_dir, 'original')
    os.mkdir(original_dir)
    os.mkdir(os.path.join(temp_dir, 'original', 'nested'))
    with open(os.path.join(temp_dir, 'original', 'nested', 'test.txt'), 'w') as f:
        f.write('data test')

    # Now write the original directory to a zipfile.

# Generated at 2022-06-23 16:40:55.328190
# Unit test for function unzip
def test_unzip():

    assert(unzip is not None)


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-23 16:41:00.741688
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(zip_uri)
    assert os.path.isdir(unzip_path)


# Generated at 2022-06-23 16:41:06.353433
# Unit test for function unzip
def test_unzip():
    assert unzip('./tests/files/cookiecutter-django.zip', False)
    assert unzip('./tests/files/cookiecutter-django.zip', False, './tests/files/')

# Generated at 2022-06-23 16:41:09.605537
# Unit test for function unzip
def test_unzip():
    path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
    assert path.endswith('cookiecutter-pypackage-master')

# Generated at 2022-06-23 16:41:17.964649
# Unit test for function unzip
def test_unzip():
    import json
    import shutil
    import signal
    import subprocess
    import time
    import zipfile

    unzip_tests_dir = os.path.join(os.path.dirname(__file__), 'tests/unzip-tests')

    def make_zip(zip_path, data):
        """Helper function to create a zip file from a JSON string.

        :param zip_path: path of zip file to create
        :param data: list of tuples with two elements.  The first element is a
            file path, the second element is the file content.
        """
        with open(zip_path, 'wb') as zipf:
            z = zipfile.ZipFile(zipf, 'w', compression=zipfile.ZIP_DEFLATED)

# Generated at 2022-06-23 16:41:24.768735
# Unit test for function unzip
def test_unzip():
    import pytest
    from datetime import datetime
    from zipfile import ZipFile
    from . import temp_build

    def test_missing_file():
        with pytest.raises(UserWarning):
            unzip('tests/files/does-not-exist', is_url=False)

    def test_bad_zipfile():
        with pytest.raises(InvalidZipRepository):
            unzip('tests/files/bad-zip.zip', is_url=False)

    def test_empty_zipfile():
        with pytest.raises(InvalidZipRepository):
            unzip('tests/files/empty-zip.zip', is_url=False)

    def test_non_empty_zipfile():
        with open('tests/files/non-empty-zip.zip', 'w') as f:
            zip_

# Generated at 2022-06-23 16:41:25.305898
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:41:34.724278
# Unit test for function unzip
def test_unzip():
    import os
    import tempfile
    from zipfile import ZipFile, ZIP_DEFLATED

    _, local_zip_path = tempfile.mkstemp(suffix='.zip')

    with ZipFile(local_zip_path, mode='w', compression=ZIP_DEFLATED) as f:
        f.writestr('README.md', '# test repository')
        f.writestr('fake_ppt', '# test repository')
    local_zip_url = 'file://' + local_zip_path

    _, unzip_path = tempfile.mkdtemp()

    # test unzip a local zip file
    cookiecutter_path = unzip(
        zip_uri=local_zip_path,
        is_url=False,
        clone_to_dir=unzip_path
    )

# Generated at 2022-06-23 16:41:36.687509
# Unit test for function unzip
def test_unzip():
    """Function unzip is unit tested within the test_archive.py
    """
    pass

# Generated at 2022-06-23 16:41:46.995864
# Unit test for function unzip
def test_unzip():

    test_path = os.path.join(os.path.expanduser('~'), 'cookiecutter_test_unzip')
    make_sure_path_exists(test_path)
    make_sure_path_exists(os.path.join(test_path, 'cookiecutters-unzip'))

    test_zip_file_id = 'cookiecutter-pypackage'
    test_zip_file = os.path.join(
        test_path, 'cookiecutters-unzip',
        '%s.zip' % test_zip_file_id
    )
    test_url = 'https://codeload.github.com/audreyr/' + \
        'cookiecutter-pypackage/zip/master'

# Generated at 2022-06-23 16:41:55.365750
# Unit test for function unzip
def test_unzip():
    # Prepare cookiecutter repository
    from pathlib import Path
    from shutil import copy
    from shutil import copytree
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    from cookiecutter.generate import generate_files
    from cookiecutter.main import cookiecutter

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create compressed file
        test_dir = Path("tests") / "test-data" / "foobar-cookiecutter"
        cookiecutter_dir = tmpdir / "cookiecutter"
        copytree(test_dir, cookiecutter_dir)

        password = "test"
        py_version = "python3.6"

# Generated at 2022-06-23 16:42:06.684320
# Unit test for function unzip
def test_unzip():
    """
    Test function unzip.
    """
    import shutil
    
    # Build a temporary cookiecutter repository, and download a zip archive into it
    temp_dir = tempfile.mkdtemp()
    unzip_path = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, temp_dir)
    # Unzip the archive
    zip_file = ZipFile(os.path.join(temp_dir, 'cookiecutter-pypackage-master.zip'))
    unzip_base = tempfile.mkdtemp()
    unzip_path_ref = os.path.join(unzip_base, 'cookiecutter-pypackage-master')
    zip_file.extractall(path=unzip_base)
    # Check

# Generated at 2022-06-23 16:42:09.619517
# Unit test for function unzip
def test_unzip():
    unzip("https://github.com/audreyr/cookiecutter-pypackage/zipball/master", True)
    unzip("/home/user/temp/cookiecutter-example-master.zip", False)

# Generated at 2022-06-23 16:42:17.560629
# Unit test for function unzip
def test_unzip():
    import shutil
    import time

    from . import utils
    from .compat import is_py2

    clone_to_dir = os.path.abspath('tests/test-extract')
    cookiecutter_json_path = os.path.abspath('tests/test-extract/cookiecutter.json')

    ############
    # Create test zip archive
    make_sure_path_exists(clone_to_dir)
    # Create test files
    utils.make_files(
        {
            'tests/test-extract/cookiecutter.json': '{"cookiecutter":{"name": "test-extract"}}'
        }
    )
    # Create zip file
    utils.create_test_zip_project(clone_to_dir)
    ############

    #########

# Generated at 2022-06-23 16:42:26.732401
# Unit test for function unzip
def test_unzip():
    import shutil
    import subprocess
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class UnzipTestCase(unittest.TestCase):
        def setUp(self):
            self.cookiecutter_repo = 'tests/test-repos/cookiecuttr-zip'
            self.cookiecutter_repo_path = os.path.normcase(
                os.path.join(
                    os.path.dirname(__file__),
                    self.cookiecutter_repo
                )
            )

            self.repo_dir = 'tests'

# Generated at 2022-06-23 16:42:31.691795
# Unit test for function unzip
def test_unzip():
    zip_uri = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    is_url = True
    clone_to_dir = "/tmp"
    unzip(zip_uri, is_url, clone_to_dir)
    assert True

# Generated at 2022-06-23 16:42:40.281538
# Unit test for function unzip
def test_unzip():
    """test_unzip"""
    import shutil
    import webbrowser
    from cookiecutter.main import cookiecutter
    temp_dir = tempfile.mkdtemp()
    zip_url = 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.3.zip'
    expected_dir = os.path.join(temp_dir, 'cookiecutter-pypackage-0.3')
    zip_path = unzip(zip_url, True, temp_dir)
    assert zip_path == expected_dir
    project_dir = os.path.join(zip_path, '{{ cookiecutter.repo_name }}')
    # test project generation
    cookiecutter(project_dir)

# Generated at 2022-06-23 16:42:46.205261
# Unit test for function unzip
def test_unzip():
    pass
    
    # Check that unzip works when passing password on the command line
    # Check that unzip works when NOT passing password on the command line
    # Check that unzip works when passing the url
    # Check that unzip works when passing the local file name
    # Check that unzip works correctly with and without the directory structure
    # Check that unzip works correctly with and without the password

# Generated at 2022-06-23 16:42:56.063760
# Unit test for function unzip
def test_unzip():
    from .compat import mock

    with mock.patch('cookiecutter.utils.make_sure_path_exists') as mocked_make:
        with mock.patch('cookiecutter.utils.prompt_and_delete') as mocked_prompt:
            with mock.patch('zipfile.ZipFile') as mocked_zipfile:
                zip_uri = 'https://api.github.com/repos/dummy/cookiecutter-dummy/zipball/master'
                unzip(zip_uri, True)

    assert mocked_make.called
    assert mocked_prompt.called
    assert mocked_zipfile.called

# Generated at 2022-06-23 16:42:56.581275
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:43:06.044788
# Unit test for function unzip
def test_unzip():
    target_file='/tmp/zip.zip'
    url='https://github.com/cookiecutter/cookiecutter/archive/master.zip'
    r = requests.get(url, stream=True)
    with open(target_file, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024):
            if chunk:  # filter out keep-alive new chunks
                f.write(chunk)
    unzip_path=unzip(target_file, False)
    assert os.path.exists(unzip_path)
    os.remove(target_file)

# Generated at 2022-06-23 16:43:10.472108
# Unit test for function unzip
def test_unzip():
    from test_files.test_archive_files import mock_zip_uri
    from test_files.test_archive_files import mock_zip_path
    assert unzip(mock_zip_uri, True) == unzip(mock_zip_path, False)

# Generated at 2022-06-23 16:43:19.553267
# Unit test for function unzip
def test_unzip():
    import os
    import errno
    from cookiecutter.utils import rmtree
    from cookiecutter.zipfile.zipfile import unzip

    TEST_DIR = os.path.dirname(__file__)
    path_to_zip = os.path.join(TEST_DIR, 'files', 'test-zip.zip')
    temp_dir = tempfile.mkdtemp()
    unzipped_path = unzip(path_to_zip, is_url=False, clone_to_dir=temp_dir)
    # set up expected template paths
    expected_path = os.path.join(temp_dir, 'test-zip')
    expected_file = os.path.join(expected_path, 'boop.txt')
    expected_dir = os.path.join(expected_path, 'dir1')


# Generated at 2022-06-23 16:43:26.264136
# Unit test for function unzip
def test_unzip():
    assert os.path.exists("tests/test-cookiecutters/test-for-unzip/")
    assert os.path.isfile("tests/test-cookiecutters/test-for-unzip/"
                          "Cookiecutter.json")

    new_unzip = unzip("tests/test-cookiecutters/test-for-unzip.zip",
                      is_url=False,
                      clone_to_dir="./tests/test-cookiecutters/")

    assert os.path.exists(new_unzip)
    assert os.path.exists("{0}/Cookiecutter.json".format(new_unzip))

# Generated at 2022-06-23 16:43:26.807882
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:43:27.427171
# Unit test for function unzip
def test_unzip():
    assert True

# Generated at 2022-06-23 16:43:37.000169
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    from zipfile import ZipFile

    def test_unzip_file(is_url, password=None):
        tempdir = os.path.dirname(os.path.dirname(__file__))
        tempdir = os.path.abspath(tempdir)
        zip_uri = os.path.join(tempdir, 'tests', 'fake-repo.zip')
        clone_to_dir = os.path.join(tempdir, 'tests', 'downloads')

        # Ensure that clone_to_dir exists
        make_sure_path_exists(clone_to_dir)

        unzip_path = unzip(zip_uri, is_url, clone_to_dir, password=password)
        assert os.path.exists(unzip_path)
        contents = os

# Generated at 2022-06-23 16:43:41.412097
# Unit test for function unzip
def test_unzip():
    name = 'cookiecutter-django'
    version = '0.0.1'
    url = 'https://codeload.github.com/pydanny/cookiecutter-django/zip/v{version}'.format(
        version=version
    )
    unzip(url, is_url=True)

# Generated at 2022-06-23 16:43:49.696746
# Unit test for function unzip
def test_unzip():
    import os
    import shutil
    import zipfile

    # Create a dummy test zipfile
    test_zip_path = os.path.join(clone_to_dir, 'test.zip')
    test_zip_file = zipfile.ZipFile(test_zip_path, 'w')

    # Create a few files to put in the zipfile
    for filename in ('__init__.py', 'foo.py'):
        with open(filename, 'w') as f:
            f.write('# Dummy Module\n')
        test_zip_file.write(filename)

    # Put the files in a directory named "test"
    test_zip_file.write('__init__.py', 'test/__init__.py')
    test_zip_file.write('foo.py', 'test/foo.py')



# Generated at 2022-06-23 16:43:50.431473
# Unit test for function unzip
def test_unzip():
    from .test_utils import test_unzip as test_unzip
    test_unzip('git')

# Generated at 2022-06-23 16:43:53.034697
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip(zip_uri, True)

# Generated at 2022-06-23 16:44:04.307685
# Unit test for function unzip
def test_unzip():
    import shutil
    import sys
    import pwd
    import grp

    # Create a temporary directory and add it to the path
    # so that unzip doesn't complain about the downloaded
    # zipfile not being present in the original path
    tmp_dir = tempfile.mkdtemp()
    sys.path.insert(0, tmp_dir)

    # Create a test repo
    temp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(temp_dir, 'test_repo')
    os.mkdir(test_dir)
    with open(os.path.join(test_dir, 'file1.txt'), 'w') as f:
        f.write('file1\n')

# Generated at 2022-06-23 16:44:04.836856
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-23 16:44:12.655529
# Unit test for function unzip

# Generated at 2022-06-23 16:44:20.860598
# Unit test for function unzip
def test_unzip():
    import shutil
    unzip_test_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'unzip-test-dir'
    )
    try:
        shutil.rmtree(unzip_test_dir)
    except OSError:
        pass
    try:
        os.mkdir(unzip_test_dir)
    except OSError:
        pass
    # Test unzipping from file
    assert unzip('tests/test-repo.zip', is_url=False, clone_to_dir=unzip_test_dir)
    # Test unzipping from URL