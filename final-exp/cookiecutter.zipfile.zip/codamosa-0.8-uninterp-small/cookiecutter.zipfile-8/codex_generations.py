

# Generated at 2022-06-25 15:44:50.556330
# Unit test for function unzip
def test_unzip():
    float_0 = -1821.2
    str_0 = '\x0c9#\n1.x((ftP6nuYG'
    var_0 = unzip(float_0, float_0, str_0, float_0)
    assert False

# Generated at 2022-06-25 15:44:53.455711
# Unit test for function unzip
def test_unzip():
    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0] is True: # raised by sys.exit(True) when tests failed
            raise

# Generated at 2022-06-25 15:44:58.555996
# Unit test for function unzip
def test_unzip():
    str_0 = '&'
    bool_0 = unzip(str_0, str_0, str_0, str_0)
    bool_1 = unzip(str_0, str_0, str_0, str_0)
    assert bool_0 == bool_1

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:45:04.359258
# Unit test for function unzip
def test_unzip():
    float_0 = -1821.2
    str_0 = '\x0c9#\n1.x((ftP6nuYG'
    var_0 = unzip(float_0, float_0, str_0)


if __name__ == "__main__":
    test_case_0()
    #test_unzip()

# Generated at 2022-06-25 15:45:07.907070
# Unit test for function unzip
def test_unzip():
    # There's not a lot we can test here, as the tempfile.mkdtemp() call
    # will produce a different temporary directory each time.
    # So this at least shows that we can call the function without errors
    assert test_case_0() is None

# Generated at 2022-06-25 15:45:19.530707
# Unit test for function unzip
def test_unzip():
    assert_equal(unzip('\x1aJ\x0b\x15', -673.4895, 'o\x1f\x1e+\\[c%\x1b\x1d'), False)
    assert_equal(unzip('\x1aJ\x0b\x15', -673.4895, 'o\x1f\x1e+\\[c%\x1b\x1d'), False)
    assert_equal(unzip('\x1aJ\x0b\x15', -673.4895, 'o\x1f\x1e+\\[c%\x1b\x1d'), False)

# Generated at 2022-06-25 15:45:23.003047
# Unit test for function unzip
def test_unzip():
    try:
        test_case_0()
    except:
        print('Failed to call function.')
    
if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-25 15:45:24.538264
# Unit test for function unzip
def test_unzip():
    test_case_0()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:45:26.553442
# Unit test for function unzip
def test_unzip():
    try:
        test_case_0()
    except (SystemExit, KeyboardInterrupt):
        pass

# Generated at 2022-06-25 15:45:31.358216
# Unit test for function unzip
def test_unzip():
    str_0 = 'rvZC{gU6Qd*hCC.H0=v'
    zip_uri = 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    var_2 = unzip(zip_uri, str_0)
    assert var_2.return_code == 0

# Generated at 2022-06-25 15:45:45.933915
# Unit test for function unzip
def test_unzip():
    str_1 = r'C:\Users\Administrator\Downloads\django-project-template-master.zip'
    str_2 = r'C:\Users\Administrator\Downloads\django-project-template-master'
    var_1 = unzip(str_1, str_1)
    if var_1 != str_2:
        raise Exception('Return value does not match expected value.')
    print('Test passed.')
    print(var_1)
#
#

# Generated at 2022-06-25 15:45:46.683893
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Test cases end

# Generated at 2022-06-25 15:45:50.781216
# Unit test for function unzip
def test_unzip():
    try:
        str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
        unzip(str_0)
        #assert True
    except InvalidZipRepository:
        pass

# Generated at 2022-06-25 15:45:51.361462
# Unit test for function unzip
def test_unzip():
    assert True == False

# Generated at 2022-06-25 15:45:52.148562
# Unit test for function unzip
def test_unzip():
    case_0()


# Generated at 2022-06-25 15:45:52.975252
# Unit test for function unzip
def test_unzip():
    test_case_0()



# Generated at 2022-06-25 15:45:53.923150
# Unit test for function unzip
def test_unzip():
    assert callable(unzip)

# Generated at 2022-06-25 15:45:55.746772
# Unit test for function unzip
def test_unzip():
    assert(True)


if __name__ == "__main__":
    test_unzip()
    print("Test run successfully")

# Generated at 2022-06-25 15:46:01.279887
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, True)
    var_1 = unzip(str_0, True, True)
    var_2 = unzip(str_0, False)
    var_3 = unzip(str_0, False, True)


# Generated at 2022-06-25 15:46:03.829211
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, str_0)

# Generated at 2022-06-25 15:46:14.549402
# Unit test for function unzip
def test_unzip():
    from cookiecutter.utils import cleanup_and_exit
    import StringIO
    try:
        assert test_case_0() is None
    except SystemExit as e:
        if e.code == 0:
            return 0
        if e.code == 1:
            print('InvalidZipRepository encountered')
        if e.code == 2:
            print('InvalidZipRepository encountered')
        if e.code == 3:
            print('InvalidZipRepository encountered')
        if e.code == 4:
            print('InvalidZipRepository encountered')
        return 1
    except InvalidZipRepository as e:
        print('InvalidZipRepository encountered')
        cleanup_and_exit()
        return 1


# Generated at 2022-06-25 15:46:19.654996
# Unit test for function unzip
def test_unzip():
    assert 'str_0' in globals() and 'var_0' in globals()

# Generated at 2022-06-25 15:46:24.709022
# Unit test for function unzip
def test_unzip():
    """Test the unzip function with a cookiecutter repository."""
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    var_0 = unzip(str_0, str_0)
    var_1 = os.path.exists(var_0)
    var_1 = not(var_1)
    assert var_1 == 0


# Generated at 2022-06-25 15:46:27.963432
# Unit test for function unzip
def test_unzip():
    # The URI of the sample repo
    test_uri = (
        'https://github.com/audreyr/'
        'cookiecutter-pypackage/archive/master.zip'
    )

    # Download, unpack and return the repo
    unzip(test_uri, is_url=True)



# Generated at 2022-06-25 15:46:32.606567
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    str_1 = '..'

    try:
        var_0 = unzip(str_0, False, str_1)
    except IndexError:
        pass
    else:
        print(var_0)


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:46:39.318127
# Unit test for function unzip
def test_unzip():
    # Test cases
    test_case_0()
    # Syntax errors
    # Value errors
    # Type errors
    # ...
    # Stop here if we fail
    raise Exception

# Call main() only if this module is being run at the command line.
if __name__ == '__main__':
    # Call unittest.main instead of the unittest.main function
    # because function needs to be called in a unittest.main
    # test suite for the code coverage percentage to be calculated
    # correctly.
    unittest.main()

# Generated at 2022-06-25 15:46:40.108478
# Unit test for function unzip
def test_unzip():
    assert unzip is not None


# Generated at 2022-06-25 15:46:42.777326
# Unit test for function unzip
def test_unzip():
    repo_url = 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    download_path = unzip(repo_url, is_url=True)
    assert os.path.isdir(download_path)

# Generated at 2022-06-25 15:46:43.865937
# Unit test for function unzip
def test_unzip():
    try:
        test_case_0()
    except:
        assert 0 == 1
    else:
        assert 0 == 1


# Generated at 2022-06-25 15:46:46.181456
# Unit test for function unzip
def test_unzip():
    assert unzip is not None

if __name__ == '__main__':
    test_case_0()
    test_unzip()

# Generated at 2022-06-25 15:47:02.581983
# Unit test for function unzip
def test_unzip():
    assert False

if __name__ == '__main__':
    unzip('http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip', 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip')

# Generated at 2022-06-25 15:47:03.672273
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Generated at 2022-06-25 15:47:05.947260
# Unit test for function unzip
def test_unzip():
    print('Testing function unzip')

    test_case_0()

    print('Function unzip OK!')

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:47:08.800284
# Unit test for function unzip
def test_unzip():
    print("Testing unzip...")
    if test_case_0():
        print("Unzip tests complete.")
    else:
        print("Unzip test FAILED!")

# Generated at 2022-06-25 15:47:09.882130
# Unit test for function unzip
def test_unzip():
    # test case 0
    test_case_0()



# Generated at 2022-06-25 15:47:15.644210
# Unit test for function unzip
def test_unzip():
    result = unzip('www.sample.com', 'www.sample.com')
    assert result == None


# Generated at 2022-06-25 15:47:17.628089
# Unit test for function unzip
def test_unzip():
    if __name__ == "__main__":
        test_case_0()
    pass

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-25 15:47:22.235534
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, True)
    str_1 = '../cookiecutter-pypackage/'
    var_1 = unzip(str_1, False)
    assert var_0 is not None
    assert var_1 is not None

# Generated at 2022-06-25 15:47:29.256775
# Unit test for function unzip
def test_unzip():

    # Case 0
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/archive/master.zip'
    var_0 = unzip(str_0, str_0)

    # Case 1
    str_1 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/archive/master.zip'
    var_1 = unzip(str_1, str_1, str_1)

    # Case 2
    str_2 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/archive/master.zip'
    var_2 = unzip(str_2, str_2, str_2, str_2)

    # Case 3

# Generated at 2022-06-25 15:47:36.558696
# Unit test for function unzip
def test_unzip():
    str_1 = 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    str_2 = '.'
    zip_0 = unzip(str_1, str_1, str_2)
    str_3 = os.path.join(os.path.sep, 'tmp', 'tmp0ukidt8x')
    str_4 = os.path.join(os.path.sep, 'tmp', 'tmp0ukidt8x', 'cookiecutter-pypackage-master')
    assert zip_0 == str_4

# Generated at 2022-06-25 15:47:56.819322
# Unit test for function unzip
def test_unzip():
    # Test when zip file is an URL
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    var_0 = unzip(str_0, True)
    # Test when zip file is not an URL
    str_1 = '../master.zip'
    var_1 = unzip(str_1, os.path.exists(str_1))
    # Test when zip file cannot be found
    str_2 = '../temp.zip'
    var_2 = unzip(str_2, os.path.exists(str_2))

if __name__ == '__main__':
    test_case_0()
    test_unzip()

# Generated at 2022-06-25 15:48:08.562364
# Unit test for function unzip
def test_unzip():
    uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip_path = unzip(uri, True)
    with open(unzip_path) as f:
        assert 'cookiecutter-pypackage-master' in f.read()

    # Test unzipping a local file
    uri = 'tests/files/files.zip'
    unzip_path = unzip(uri, False)
    with open(unzip_path) as f:
        assert 'files/small-project-1.0' in f.read()

    # Test unzipping a file that is password protected
    uri = 'https://github.com/audreyr/cookiecutter-securefile/archive/master.zip'

# Generated at 2022-06-25 15:48:11.260219
# Unit test for function unzip
def test_unzip():
    print("Testing unzip...")
    try:
        test_case_0()
        print("Test case 0: pass")
    except:
        print("Test case 0: fail")
    print("Test complete\n")

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-25 15:48:12.997106
# Unit test for function unzip
def test_unzip():
    print(unzip.__doc__)

# Unit tests for unzip
if __name__ == '__main__':
    test_unzip()
    test_case_0()

# Generated at 2022-06-25 15:48:18.936170
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, True, '.')
    assert isinstance(var_0, str)
    assert var_0 == '/tmp/cookiecutter-pypackagearchive-master'
    with open('/tmp/cookiecutter-pypackagearchive-master/README.rst', 'r') as var_1:
        str_1 = var_1.read()
        assert str_1 == '\n\nCookiecutter template for a Python package.\n\nSee <https://github.com/audreyr/cookiecutter> for more info.\n'

# Generated at 2022-06-25 15:48:20.166641
# Unit test for function unzip
def test_unzip():
    # Do something here to test unzip
    print('unzip not tested')
    pass

# Generated at 2022-06-25 15:48:25.968503
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, 1)
    var_1 = unzip(str_1, 1)
    if var_0 != var_1:
        raise ValueError('unzip failed')


# Generated at 2022-06-25 15:48:27.854364
# Unit test for function unzip
def test_unzip():
    # Provided by cookiecutter.tests.test_utils
    return None

# Debugging
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 15:48:32.871977
# Unit test for function unzip
def test_unzip():
    case_0_param = {'zip_uri': 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip', 'is_url': 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip', 'clone_to_dir': '.', }
    assert test_case_0() == case_0_param


# Generated at 2022-06-25 15:48:36.027631
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackage/master.zip'
    var_0 = unzip(str_0, str_0)

if __name__ == "__main__":
    test_unzip()
    test_case_0()

# Generated at 2022-06-25 15:49:06.842325
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    var_0 = unzip(str_0, str_0)
    bool_0 = os.path.exists(var_0)
    assert bool_0 is True


# Generated at 2022-06-25 15:49:09.472550
# Unit test for function unzip
def test_unzip():
    # Test_case_0
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    test_case_0()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:49:11.722634
# Unit test for function unzip
def test_unzip():
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    result = unzip(zip_uri, True)
    assert os.path.exists(result)


# Generated at 2022-06-25 15:49:15.314624
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, str_0)


str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
var_0 = unzip(str_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_unzip()

# Generated at 2022-06-25 15:49:16.590683
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Generated at 2022-06-25 15:49:23.729023
# Unit test for function unzip
def test_unzip():
    assert unzip(
        'http://github.com/audreyr/cookiecutter-pypackagearchive.zip',
        True,
        '.',
        False,
        None
    ) == '/tmp/tmp4a97agbi/cookiecutter-pypackagearchive'
    # assert unzip(
    #     'http://github.com/audreyr/cookiecutter-pypackagearchive.zip',
    #     True,
    #     '.',
    #     False,
    #     None
    # ) == '/tmp/tmp5x5p5z6j/cookiecutter-pypackagearchive'
    # assert unzip(
    #     'http://github.com/audreyr/cookiecutter-pypackagearchive.zip',
    #    

# Generated at 2022-06-25 15:49:24.975421
# Unit test for function unzip
def test_unzip():
    print("Testing function unzip")
    test_case_0()


# Utility function for running unit tests

# Generated at 2022-06-25 15:49:27.032545
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Run unit tests for function unzip
if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:49:36.941389
# Unit test for function unzip
def test_unzip():
    assert unzip("http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip", "http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip")
    # (Re) download the zipfile

# Generated at 2022-06-25 15:49:39.785741
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, str_0)
test_case_0()
#test_unzip()

# Generated at 2022-06-25 15:50:21.029029
# Unit test for function unzip
def test_unzip():
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    var_0 = unzip(str_0, 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', clone_to_dir='.', no_input=False, password=None)
    assert os.path.exists(var_0)

# Generated at 2022-06-25 15:50:30.521624
# Unit test for function unzip
def test_unzip():
    # Assert that it returns None
    assert unzip(str, bool) is None
    assert unzip(str, bool, str) is None
    assert unzip(str, bool, str, bool) is None
    assert unzip(str, bool, str, bool, str) is None
    assert unzip(str, bool, str, bool, str, str) is None
    assert unzip(str, bool, str, bool, str, str, bool) is None
    assert unzip(str, bool, str, bool, str, str, bool, bool) is None
    assert unzip(str, bool, str, bool, str, str, bool, bool, str) is None
    assert unzip(str, bool, str, bool, str, str, bool, bool, str, bool) is None
    # Assert that it raises a TypeError

# Generated at 2022-06-25 15:50:32.310517
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/pydanny/cookiecutter-djangopackage/archive/master.zip', True, '.')

# Generated at 2022-06-25 15:50:40.126620
# Unit test for function unzip
def test_unzip():
    # Invalid URL
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    try:
        var_0 = unzip(str_0, str_0)
    except InvalidZipRepository as exp_err:
        assert exp_err.__str__() == str(exp_err)
    else:
        raise Exception('Unreachable')
    # Invalid file
    str_1 = './cookiecutter-pypackagearchive-master.zip'
    try:
        var_1 = unzip(str_1, str_1)
    except InvalidZipRepository as exp_err:
        assert exp_err.__str__() == str(exp_err)
    else:
        raise Exception('Unreachable')
    # Invalid path

# Generated at 2022-06-25 15:50:46.956781
# Unit test for function unzip
def test_unzip():
    test_case_0()
    # print var_0


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:50:48.921208
# Unit test for function unzip
def test_unzip():
    str_0 = 'https://codeload.github.com/audreyr/cookiecutter-pypackage/zip/master'
    var_0 = unzip(str_0, str_0)


# Generated at 2022-06-25 15:50:50.917539
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    var_0 = unzip(str_0, str_0)
    if __name__ == '__main__':
        test_unzip()

# Generated at 2022-06-25 15:50:51.336023
# Unit test for function unzip
def test_unzip():
    pass

# Generated at 2022-06-25 15:50:52.503597
# Unit test for function unzip
def test_unzip():
    assert unzip(str, is_url, clone_to_dir, no_input, password) == result, "Wrong result"


# Generated at 2022-06-25 15:51:01.125797
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    var_0 = unzip(str_0, str_0)
    assert type(var_0) is str

    str_1 = 'https://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    var_1 = unzip(str_1, str_1)
    assert type(var_1) is str

    str_2 = 'https://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    var_2 = unzip(str_2, str_2)
    assert type(var_2) is str


# Generated at 2022-06-25 15:51:27.801730
# Unit test for function unzip
def test_unzip():
    print(unzip(None, None))



# Generated at 2022-06-25 15:51:34.087599
# Unit test for function unzip
def test_unzip():
    """
    Test unzipping a file or resource.
    """
    assert unzip(
        'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip',
        'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip',
    )

    assert unzip(
        'https://github.com/audreyr/cookiecutter-pypackagearchive/master/:.zip',
        'https://github.com/audreyr/cookiecutter-pypackagearchive/master/:.zip',
    )


# Generated at 2022-06-25 15:51:37.384362
# Unit test for function unzip
def test_unzip():

    # Case 0
    test_case_0()


if __name__ == '__main__':

    # Test cases
    test_unzip()

# Generated at 2022-06-25 15:51:39.036964
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    var_0 = unzip(str_0, str_0)



# Generated at 2022-06-25 15:51:40.272739
# Unit test for function unzip
def test_unzip():
    print('Running test for function unzip')
    test_case_0()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:51:45.185638
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_0 = unzip(str_0, str_0)

    str_1 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_1 = unzip(str_1, str_1)

    str_2 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_2 = unzip(str_2, str_2)

    str_3 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    var_3 = unzip(str_3, str_3)

    str_

# Generated at 2022-06-25 15:51:48.151331
# Unit test for function unzip
def test_unzip():
    try:
        test_case_0()
    except SystemExit:
        pass

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:51:49.775057
# Unit test for function unzip
def test_unzip():
    zip_uri = 'http://github.com/audreyr/cookiecutter-pypackage.git'
    #test_case_0()
    assert True


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:51:52.816359
# Unit test for function unzip
def test_unzip():
    """Test function unzip"""
    str_0 = "http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip"
    bool_0 = True
    str_1 = "."
    bool_1 = True
    test_unzip_0(str_0, bool_0, str_1, bool_1)

# Regenerate expected results for test_unzip

# Generated at 2022-06-25 15:52:02.443786
# Unit test for function unzip
def test_unzip():
    # Test case 0.
    str_1 = 'http://github.com/audreyr/cookiecutter-pypackagearchivemaster.zip'
    var_1 = unzip(str_1, False)

    # Test case 1.
    str_2 = 'http://github.com/audreyr/cookiecutter-pypackagearchivemaster.zip'
    var_2 = unzip(str_2, True)

    # Test case 2
    str_3 = 'http://github.com/audreyr/cookiecutter-pypackagearchivemaster.zip'
    var_3 = unzip(
        str_3,
        True,
        '~/Library/Application Support/Cookiecutter',
        True
    )

    # Test case 3.

# Generated at 2022-06-25 15:53:20.784255
# Unit test for function unzip
def test_unzip():
    test_case_0()
# test_unzip()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:53:21.464134
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Generated at 2022-06-25 15:53:24.079570
# Unit test for function unzip
def test_unzip():
    str_0 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    var_0 = unzip(str_0, str_0)


test_case_0()
test_unzip()

# Generated at 2022-06-25 15:53:33.392575
# Unit test for function unzip
def test_unzip():
    str_0 = '/private/var/folders/1v/t1wq0q0n3nb3p57dgv9f03j80000gn/T/tmpG7cq3B'
    str_1 = 'http://github.com/audreyr/cookiecutter-pypackagearchive/maste:.zip'
    str_2 = '/private/var/folders/1v/t1wq0q0n3nb3p57dgv9f03j80000gn/T/tmp1Xc3qb'
    assert unzip(str_1) == str_0
    assert unzip('/Users/audreyr/src/cookiecutter/tests/test-repo-pre/', True) == str_2

test_unzip()

# Generated at 2022-06-25 15:53:40.727893
# Unit test for function unzip
def test_unzip():
    try:
        unzip(str, bool)
    except NameError:
        assert True

if __name__ == "__main__":
    import sys
    import logging
    logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
    test_unzip()

# Generated at 2022-06-25 15:53:45.785493
# Unit test for function unzip
def test_unzip():
    # Test 1
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    var_1 = unzip(str_1)

    # Test 2
    # TODO

    # Test 3
    # TODO

# Generated at 2022-06-25 15:53:50.542579
# Unit test for function unzip
def test_unzip():
    try:
        assert unzip
    except NameError:
        return
    bad_urls = [
        'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip',
        'http://github.com/audreyr/cookiecutter-pypackagearchive/master.zip'
    ]
    for bad_url in bad_urls:
        result = unzip(bad_url, True)
        assert result == (
            "Zip repository {} is not a valid zip archive:".format(bad_url)
        )


# Generated at 2022-06-25 15:53:58.080821
# Unit test for function unzip
def test_unzip():
    try:
        print('\n*** test case 0 ***')
        test_case_0()
    except SystemExit:
        pass
    except Exception as inst:
        print('Unexpected exception:',  type(inst), ':', inst)
        raise Exception(inst)

# Install dependencies for this package.

# Generated at 2022-06-25 15:54:02.952483
# Unit test for function unzip
def test_unzip():
    str_0 = '/temp/python/cookiecutter-pypackagearchive-f6a4b6d.zip'
    var_0 = unzip(str_0, False, '.')
    print(var_0)

# Run test function
if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:54:13.878511
# Unit test for function unzip
def test_unzip():
    test_case_0()

if __name__ == '__main__':
    import sys
    import argparse
    
    arg_parser = argparse.ArgumentParser(
        description='Test zip file extraction'
    )
    arg_parser.add_argument(
        '-v',
        '--verbose',
        action='count',
        default=0,
        help='increase output verbosity'
    )
    arg_parser.add_argument(
        '-f',
        '--failfast',
        dest='failfast',
        action='store_true',
        default=False,
        help='stop the test suite after first failure'
    )