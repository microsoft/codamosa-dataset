

# Generated at 2022-06-25 15:44:57.019145
# Unit test for function unzip
def test_unzip():
    try:
        assert unzip(bytes_0, float_0) == None
    except (TypeError, AssertionError) as e:
        print(e)

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))

# Generated at 2022-06-25 15:44:58.069566
# Unit test for function unzip
def test_unzip():
    assert unzip() == 0

# Generated at 2022-06-25 15:44:58.559318
# Unit test for function unzip
def test_unzip():
    assert True

# Generated at 2022-06-25 15:45:03.725587
# Unit test for function unzip
def test_unzip():
    try:
        print('Testing function unzip')

        test_case_0()

    except Exception as e:
        print('Error:', e)

# Boilerplate support for running the script from the command-line
if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:45:08.117219
# Unit test for function unzip
def test_unzip():
    bytes_0 = b'\xc9'
    float_0 = None
    var_0 = unzip(bytes_0, float_0)


if __name__ == '__main__':
    bytes_0 = b'\xc9'
    float_0 = None
    var_0 = unzip(bytes_0, float_0)

# Generated at 2022-06-25 15:45:12.180785
# Unit test for function unzip
def test_unzip():
    # Test case 0
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-25 15:45:22.059323
# Unit test for function unzip
def test_unzip():
    assert callable(unzip) and callable(unzip)

# Built-in test cases
for (func_name, case_desc, case_args, expected) in (
    ('test_case_0', '', (b'\xc9', None), None),
):
    if callable(globals()[func_name]) and globals()[func_name].__doc__ == '':
        # Case has a test body
        result = globals()[func_name](*case_args)
        assert result == expected, f'{func_name}({case_args!r})\nExpected: {expected!r}\nActual:   {result!r}'

# Generated at 2022-06-25 15:45:32.166295
# Unit test for function unzip
def test_unzip():
    # Try to unzip an empty repository
    with pytest.raises(InvalidZipRepository) as excinfo:
        unzip(
            'tests/files/empty.zip',
            False,
            no_input=True,
            clone_to_dir='tests/files/repos'
        )

    # Try to unzip a repository without a top-level directory
    with pytest.raises(InvalidZipRepository) as excinfo:
        unzip(
            'tests/files/no-top-level.zip',
            False,
            no_input=True,
            clone_to_dir='tests/files/repos'
        )

    # Try to unzip a password-protected repository without a password

# Generated at 2022-06-25 15:45:33.942208
# Unit test for function unzip
def test_unzip():
    # Test case 0
    bytes_0 = b'\xc9'
    float_0 = None
    var_0 = unzip(bytes_0, float_0)

# Generated at 2022-06-25 15:45:41.702508
# Unit test for function unzip
def test_unzip():
    from cookiecutter.utils import temp_chdir

    project_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-repo-templates', 'cookiecutter-pypackage')
    )
    with temp_chdir(project_dir):
        if os.path.exists('tests/test-repo-templates/cookiecutter-pypackage.zip'):
            os.remove('tests/test-repo-templates/cookiecutter-pypackage.zip')
        os.system('zip -r tests/test-repo-templates/cookiecutter-pypackage.zip .')

# Generated at 2022-06-25 15:45:47.776155
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Generated at 2022-06-25 15:45:52.149311
# Unit test for function unzip
def test_unzip():
    # Default arguments are a float
    base_float = 3133.257
    result = unzip(base_float, base_float)
    assert result is None

if __name__ == '__main__':
    test_case_0(
        float_0=3133.257,
        )

# Generated at 2022-06-25 15:45:56.158994
# Unit test for function unzip
def test_unzip():
    float_0 = 0.0
    try:
        # Uncomment the next line to see the test fail; the float
        # should not be a valid URL.
        # unzip(float_0, float_0)
        unzip(float_0, False)
    except InvalidZipRepository as e:
        pass



# Generated at 2022-06-25 15:45:58.788871
# Unit test for function unzip
def test_unzip():
    unzip('test', True)

if __name__ == '__main__':
    unzip('test', True)
    test_case_0()

# Generated at 2022-06-25 15:46:01.575408
# Unit test for function unzip
def test_unzip():
    float_0 = 3133.257
    var_0 = unzip(float_0, float_0)

if __name__ == "__main__":
    test_case_0()
    test_unzip()

# Generated at 2022-06-25 15:46:03.679434
# Unit test for function unzip
def test_unzip():
    assert unzip(3133.25, 3133.25) == None
    return

# Main function call
if __name__ == "__main__":
    # Call the test function
    test_unzip()

    # Call the main function
    unzip(3133.25, 3133.25)

# Generated at 2022-06-25 15:46:05.075905
# Unit test for function unzip
def test_unzip():
    print('Testing function unzip')
    test_case_0()


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:46:06.265014
# Unit test for function unzip
def test_unzip():
    right_0 = unzip(3133.257, 3133.257)


# Generated at 2022-06-25 15:46:08.518205
# Unit test for function unzip
def test_unzip():
    float_0 = 3133.257
    var_0 = unzip(float_0, float_0)

    return int(var_0)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 15:46:18.452606
# Unit test for function unzip
def test_unzip():
    # Remove the first line of the function
    function_code = unzip.__code__
    first_line = 'def {}('.format(unzip.__name__)
    assert function_code.co_code.startswith(first_line.encode())
    # Remove the last line of the function

# Generated at 2022-06-25 15:46:26.109696
# Unit test for function unzip
def test_unzip():
    try:
        assert unzip(None, None) == 'result'
    except AssertionError as e:
        raise(e)
    return 1

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-25 15:46:32.883597
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)

# Uncomment to test function test_case_0
#test_case_0()
# Uncomment to test function test_unzip
#test_unzip()

# Generated at 2022-06-25 15:46:33.714377
# Unit test for function unzip
def test_unzip():
    assert True

# Function test for function unzip

# Generated at 2022-06-25 15:46:42.606251
# Unit test for function unzip
def test_unzip():
    dest_dir = tempfile.mkdtemp()


# Generated at 2022-06-25 15:46:43.497124
# Unit test for function unzip
def test_unzip():
    test_case_0()


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:46:54.336969
# Unit test for function unzip
def test_unzip():
    template_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 15:47:04.182781
# Unit test for function unzip
def test_unzip():
    try:
        unzip('foo', 'bar')
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

    try:
        unzip(('abc', 123, 'abc'), 'bar')
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

    try:
        unzip('foo', 123)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

    try:
        unzip('foo', 'bar', 'baz')
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

    try:
        unzip('foo', 'bar', None, None)
    except TypeError:
        pass

# Generated at 2022-06-25 15:47:06.033516
# Unit test for function unzip
def test_unzip():
    """Test unzip function."""
    float_0 = 3133.257
    var_0 = unzip(float_0, float_0)
    assert var_0 != None


# Generated at 2022-06-25 15:47:07.736415
# Unit test for function unzip
def test_unzip():
    assert 1 == 1



# Generated at 2022-06-25 15:47:09.548074
# Unit test for function unzip
def test_unzip():
    var_0 = unzip()
    var_1 = unzip(float_0, float_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:47:18.710350
# Unit test for function unzip
def test_unzip():
    float_0 = 3133.257
    # AssertionError: 3133.257 != 3133.257
    assert float_0 == float_0

# Generated at 2022-06-25 15:47:23.069954
# Unit test for function unzip
def test_unzip():
    zip_uri = 'foo'
    is_url = 'bar'
    clone_to_dir = 'baz'
    no_input = 'foobar'
    password = 'spam'
    test_case_0()
    unzip(zip_uri, is_url, clone_to_dir, no_input, password)

# Generated at 2022-06-25 15:47:29.738471
# Unit test for function unzip
def test_unzip():
    float_0 = 2468.0
    float_1 = float_0
    float_2 = 775736.10
    float_3 = float_2
    var_0 = unzip(float_1, float_3)
    float_4 = float_3
    float_3 = float_2
    float_2 = float_0
    float_1 = float_0
    float_5 = unzip(float_2, float_4)
    float_6 = float_0
    float_5 = unzip(float_6, float_2)
    float_7 = float_0
    float_5 = unzip(float_7, float_7)
    float_8 = float_0
    float_5 = unzip(float_3, float_8)
    float_9 = float_0
    float_

# Generated at 2022-06-25 15:47:32.911543
# Unit test for function unzip
def test_unzip():
    float_0 = 4.86839e+08
    float_1 = float_0
    with pytest.raises(TypeError):
        unzip(float_0, float_1)


# Generated at 2022-06-25 15:47:33.752313
# Unit test for function unzip
def test_unzip():
    var_0 = unzip(float, bool)


# Generated at 2022-06-25 15:47:35.992159
# Unit test for function unzip
def test_unzip():
    assert True

# Main test for function unzip
if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:47:36.410343
# Unit test for function unzip
def test_unzip():
    assert True == True

# Generated at 2022-06-25 15:47:40.274591
# Unit test for function unzip
def test_unzip():
    # Test 1
    float_0 = 1589.51656
    var_0 = unzip(float_0, float_0)
    assert var_0 is not None

    # Test 2
    float_0 = 1589.51656
    var_0 = unzip(float_0, float_0)
    assert var_0 is not None

# Generated at 2022-06-25 15:47:46.146708
# Unit test for function unzip
def test_unzip():
    try:
        var_0 = test_case_0()
        assert 'tests/test-data/test-repo.zip' in var_0
    except IOError as e:
        if e.errno != 2:
            raise e
    except:
        raise

# Generated at 2022-06-25 15:47:47.011553
# Unit test for function unzip
def test_unzip():
    assert True == True

if __name__ == "__main__":
    test_unzip()

# Generated at 2022-06-25 15:48:06.910773
# Unit test for function unzip
def test_unzip():
    var_1 = unzip(float, bool)
    assert var_1 is None


# Generated at 2022-06-25 15:48:11.086842
# Unit test for function unzip
def test_unzip():

    # NOTE: Auto-generated by generate_test_code.py (refs #984)
    from cookiecutter.utils import unzip

    # Call function with args
    result = unzip('test_0', 'test_1')

    # Check for correct result
    assert result == 'test_2'


if __name__ == '__main__':
    import pytest

    pytest.main(['-x', __file__])

# Generated at 2022-06-25 15:48:17.666513
# Unit test for function unzip
def test_unzip():
    # Check that the unzip raises the exception with the expected message,
    # when passed an invalid argument with message 'Invalid argument'.
    try:
        try:
            # The arguments that will be passed to the function
            float_0 = 3133.257
            var_0 = unzip(float_0, float_0)
        except Exception as var_1:
            assert type(var_1).__name__ == "InvalidZipRepository"
    except AssertionError as var_2:
        print("AssertionError raised by  test_unzip", var_2)
    # Check that the unzip raises the exception with the expected message,
    # when passed an invalid argument with message 'Invalid argument'.

# Generated at 2022-06-25 15:48:18.689156
# Unit test for function unzip
def test_unzip():
    test_case_0()


# Class for holding test data for unzip

# Generated at 2022-06-25 15:48:20.136275
# Unit test for function unzip
def test_unzip():
    assert 5 == 5

if __name__ == '__main__':
    unzip()

# Generated at 2022-06-25 15:48:28.521271
# Unit test for function unzip
def test_unzip():
    assert (
        unzip(
            (
                "https://bitbucket.org/pokoli/cookiecutter-pylons/get/default.zip"
            ),
            True,
            '~/.cookiecutters',
        )
        == '~/.cookiecutters/cookiecutter-pylons/cookiecutter-pylons'
    )
    assert (
        unzip(
            (
                'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
            ),
            True,
            '~/Repo/Distribution',
        )
        == '~/Repo/Distribution/cookiecutter-pypackage/cookiecutter-pypackage'
    )

# Generated at 2022-06-25 15:48:29.427519
# Unit test for function unzip
def test_unzip():
    assert unzip(None, None) == None



# Generated at 2022-06-25 15:48:37.189086
# Unit test for function unzip
def test_unzip():
    try:
        unzip('junk_dir', 0.588)
    except TypeError:
        pass
    else:
        assert False

    try:
        unzip('junk_dir', 0.588, '../tests/files/fake-repo-tmpl')
    except InvalidZipRepository:
        pass
    else:
        assert False

    try:
        unzip(
            '../tests/files/invalid-zip/test.zip',
            0.188,
            '../tests/files/fake-repo-tmpl'
        )
    except InvalidZipRepository:
        pass
    else:
        assert False


# Generated at 2022-06-25 15:48:39.330478
# Unit test for function unzip
def test_unzip():
    print("Running unzip function test")
    try:
        test_case_0()
    except Exception as e:
        print("Function unzip failed at test case 0 with error: {}".format(e))


if __name__ == '__main__':

    test_unzip()

# Generated at 2022-06-25 15:48:40.077401
# Unit test for function unzip
def test_unzip():
    assert callable(unzip)



# Generated at 2022-06-25 15:49:24.170914
# Unit test for function unzip
def test_unzip():
    zip_uri = 3133.257
    is_url = 3133.257
    clone_to_dir = '.'
    no_input = False
    password = None
    assert unzip(zip_uri, is_url, clone_to_dir, no_input, password) == '.'

# Generated at 2022-06-25 15:49:27.032721
# Unit test for function unzip
def test_unzip():
    float_0 = 44.17
    dict_0 = dict()
    dict_0[64] = float_0
    dict_0[91] = float_0
    var_0 = unzip(dict_0, float_0)


# Generated at 2022-06-25 15:49:28.518086
# Unit test for function unzip
def test_unzip():
    unzip(0, 0)

# Generated at 2022-06-25 15:49:37.890156
# Unit test for function unzip
def test_unzip():
    try:
        # Test case 1
        # Construct valid input
        float_0 = 3133.257
        var_1 = unzip(float_0, float_0)
        # Validate the output
        if var_1 is None:
            raise AssertionError('unzip() returned None')
    except AssertionError:
        print('[-] Test case 1 failed')
        return

    try:
        # Test case 2
        # Construct valid input
        float_2 = 3133.257
        var_3 = unzip(float_2, float_2)
        # Validate the output
        if var_3 is not None:
            raise AssertionError('unzip() did not return None')
    except AssertionError:
        print('[-] Test case 2 failed')
        return


# Generated at 2022-06-25 15:49:47.944984
# Unit test for function unzip
def test_unzip():
    f = open("unittests/ut_unzip.tmp", "w")

    float_0 = 3133.257
    var_0 = unzip(float_0, float_0)
    assert os.path.isdir(var_0) == True
    f.write(var_0)

    float_0 = 3133.257
    float_1 = float_0
    var_0 = unzip(float_0, float_1)
    assert os.path.isdir(var_0) == True
    f.write(var_0)

    float_0 = 3133.257
    float_1 = float_0
    var_0 = unzip(float_0, float_1, float_0)
    assert os.path.isdir(var_0) == True

# Generated at 2022-06-25 15:49:49.302150
# Unit test for function unzip
def test_unzip():
    assert callable(unzip)

if __name__ == '__main__':
    test_unzip()
    print('Test finished successfully')

# Generated at 2022-06-25 15:49:51.251242
# Unit test for function unzip
def test_unzip():
    assert callable(unzip)



# Generated at 2022-06-25 15:49:52.682967
# Unit test for function unzip
def test_unzip():
    """
    Test for unzip
    """
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 15:50:00.616791
# Unit test for function unzip
def test_unzip():
    # Test the case where unzip uses the default value for clone_to_dir
    # unzip uses the default value for clone_to_dir
    var_0 = 'http://example.com/unique_1.zip'
    var_1 = True
    var_2 = '.'
    var_3 = False
    try:
        unzip(var_0, var_1, no_input=var_3)
    except InvalidZipRepository:
        assert True

    # Test the case where unzip uses the default value for password
    # unzip uses the default value for password
    var_0 = 'http://example.com/unique_2.zip'
    var_1 = True
    var_3 = False

# Generated at 2022-06-25 15:50:04.524190
# Unit test for function unzip
def test_unzip():
    test_stim_0 = unzip('https://github.com/audreyr/cookiecutter-pypackage.git', 'https://github.com/audreyr/cookiecutter-pypackage.git')
    test_stim_1 = unzip('C:\\Users\\Becky\\Documents\\cookiecutter_example.zip', 'C:\\Users\\Becky\\Documents\\cookiecutter_example.zip')


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:52:10.449833
# Unit test for function unzip
def test_unzip():
    #
    # Initialization of test variables
    #
    zip_uri = "http://github.com/audreyr/cookiecutter/archive/master.zip"
    # is_url = ?
    clone_to_dir = "~/cookiecutters"
    # no_input = ?
    # password = ?
    #
    # Test the function
    #
    test_case_0()


# Generated at 2022-06-25 15:52:12.145532
# Unit test for function unzip
def test_unzip():
    print("start test")
    test_case_0()
    #test_case_1()
    print("end test")

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:52:16.800262
# Unit test for function unzip
def test_unzip():
    # Setup test fixtures
    float_0 = 'https://github.com/nvie/cookiecutter-pypackage/zipball/master'
    float_1 = 'tests/fake-repo-tmpl'

    # Invoke test target
    var_0 = unzip(float_0, True)
    var_1 = unzip(float_1, False)

    # Verify state after test target
    assert var_0 == None
    assert var_1 == None

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:52:18.465778
# Unit test for function unzip
def test_unzip():
    float_0 = 3133.257
    var_0 = unzip(float_0, float_0)
    assert isinstance(var_0, str)


# Generated at 2022-06-25 15:52:21.480382
# Unit test for function unzip
def test_unzip():
    print("Testing file: " + __file__)
    print("Function: unzip")
    test_case_0()

# Generated at 2022-06-25 15:52:26.174505
# Unit test for function unzip
def test_unzip():
    # Test case 0
    # Setup input example
    float_0 = 3133.257

    # Setup expected result
    float_1 = 3133.257

    # Execute the function
    var_0 = unzip(float_0, float_0)

    # Verify the results
    assert var_0 == float_1

# Generated at 2022-06-25 15:52:31.694670
# Unit test for function unzip
def test_unzip():
    A = [0,1,2,3,4]
    B = [0,2,4,6,8]

    A_prime = []
    B_prime = []
    for a,b in zip(A, B):
        A_prime.append(a)
        B_prime.append(b)

# Test cases for test_unzip

# Generated at 2022-06-25 15:52:35.710637
# Unit test for function unzip
def test_unzip():
    # The value for float_0 was found using the
    # text fixture
    float_0 = 3133.257
    var_0 = unzip(float_0, float_0)
    assert (var_0 >= -3857.083 and var_0 <= -3857.083)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 15:52:36.928158
# Unit test for function unzip
def test_unzip():
    test_case_0()


if __name__ == "__main__":
    # Test the function unzip
    test_unzip()

# Generated at 2022-06-25 15:52:41.526857
# Unit test for function unzip
def test_unzip():
    assert test_case_0()