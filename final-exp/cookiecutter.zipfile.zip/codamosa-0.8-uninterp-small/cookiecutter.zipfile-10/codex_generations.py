

# Generated at 2022-06-25 15:44:52.892225
# Unit test for function unzip
def test_unzip():
    print('Test')
    test_case_0()
    assert True

# Generated at 2022-06-25 15:44:59.364982
# Unit test for function unzip
def test_unzip():
    int_0 = 2098
    bytes_0 = b'bX\x8f\xb9\x84\xbb9'
    var_0 = unzip(int_0, int_0, bytes_0)
    var_1 = unzip(int_0, int_0, bytes_0)
    var_2 = unzip(int_0, int_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    # Unit test for function unzip
    test_unzip()

# Generated at 2022-06-25 15:45:10.358165
# Unit test for function unzip
def test_unzip():
    assert(unzip('A_input_string', False, 'A_input_string') is not None)
    assert(unzip(2098, 2098, b'bX\x8f\xb9\x84\xbb9') is not None)
    assert(unzip(-208, False, b'bX\x8f\xb9\x84\xbb9') is not None)
    assert(unzip(2098, 2098, b'bX\x8f\xb9\x84\xbb9') is not None)
    assert(unzip(2098, 2098, b'bX\x8f\xb9\x84\xbb9') is not None)

# Generated at 2022-06-25 15:45:12.909253
# Unit test for function unzip
def test_unzip():
    test_case_0()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:45:17.824834
# Unit test for function unzip
def test_unzip():
    int_0 = 2524
    double_0 = -14.364976819432475
    float_0 = -20.0
    long_long_0 = -4116021091743415892
    bool_0 = bool(1)
    unzip(int_0, float_0, float_0, bool_0, float_0)
    unzip(int_0, double_0, float_0, float_0, float_0)
    unzip(int_0, double_0, float_0, bool_0, float_0)
    unzip(double_0, float_0, float_0, float_0, float_0)
    unzip(int_0, double_0, float_0, float_0, double_0)

# Generated at 2022-06-25 15:45:20.859005
# Unit test for function unzip
def test_unzip():
    assert func_name_0() == func_name_1()

# Run test for function unzip
if __name__=="__main__":
    test_unzip()

# Generated at 2022-06-25 15:45:24.414612
# Unit test for function unzip
def test_unzip():
    input_0 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    expected_0 = 'Not implemented'
    actual = unzip(input_0, input_0)
    assert actual == expected_0

# Generated at 2022-06-25 15:45:25.407108
# Unit test for function unzip
def test_unzip():
    assert True



# Generated at 2022-06-25 15:45:28.213494
# Unit test for function unzip
def test_unzip():
    input_0 = ['9qzyn6p', True, '.']
    return_0 = unzip(*input_0)
    assert return_0 == '9qzyn6p'

# Generated at 2022-06-25 15:45:35.974905
# Unit test for function unzip
def test_unzip():
    int_0 = 2098
    bytes_0 = b'bX\x8f\xb9\x84\xbb9'
    var_1 = unzip(int_0, int_0, bytes_0)
    int_1 = 9496
    bytes_1 = b'\x15\xe3\x0e\xcc\xeb\x1e\xa9\xbf'
    var_2 = unzip(int_1, int_1, bytes_1)
    int_2 = 1869
    bytes_2 = b'^\xe0\xaf\x94\x07\xbc\x85\x9b\x86'
    var_3 = unzip(int_2, int_2, bytes_2)
    int_3 = 6518

# Generated at 2022-06-25 15:45:48.707247
# Unit test for function unzip
def test_unzip():
    # delete var_0, var_1, var_2
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    var_0 = unzip(zip_uri, is_url=True)
    assert os.path.exists(var_0)
    zip_uri = './tests/files/cookiecutter-pypackage-master-with-empty-dir.zip'
    var_1 = unzip(zip_uri, is_url=False, clone_to_dir='/tmp')
    assert os.path.exists(var_1)
    zip_uri = './tests/files/password-protected.zip'

# Generated at 2022-06-25 15:45:58.823025
# Unit test for function unzip
def test_unzip():
    # test 1
    string_0 = '2,wRC[HLM0/<'
    string_1 = '2,wRC[HLM0/<'
    string_2 = 'vD)F;W8Vu1'
    var_0 = unzip(string_0, string_1, string_2)

    # test 2
    string_0 = '2,wRC[HLM0/<'
    string_1 = '2,wRC[HLM0/<'
    string_2 = 'vD)F;W8Vu1'
    int_0 = 3
    var_1 = unzip(string_0, string_1, string_2, int_0)

    # test 3
    string_3 = '2,wRC[HLM0/<'

# Generated at 2022-06-25 15:46:06.972088
# Unit test for function unzip
def test_unzip():
    assert unzip('1', '1') == "test_value_0"
    assert unzip('2', '2') == "test_value_1"
    assert unzip('3', '3') == "test_value_2"
    assert unzip('4', '4') == "test_value_3"
    assert unzip('5', '5') == "test_value_4"
    assert unzip('6', '6') == "test_value_5"
    assert unzip('7', '7') == "test_value_6"
    assert unzip('8', '8') == "test_value_7"
    assert unzip('9', '9') == "test_value_8"
    assert unzip('10', '10') == "test_value_9"

# Generated at 2022-06-25 15:46:10.195628
# Unit test for function unzip
def test_unzip():
    test_case_0()

if __name__ == '__main__':
    if test_unzip():
        print("SUCCESS: Function unzip has passed unit tests\n")
    else:
        print("FAILURE: Function unzip has not passed unit tests\n")

# Generated at 2022-06-25 15:46:12.927657
# Unit test for function unzip
def test_unzip():
    var_0 = 'wRC[HLM0/<'
    assert unzip(var_1, var_0) == '2,wRC[HLM0/</'


test_unzip()

# Generated at 2022-06-25 15:46:17.901427
# Unit test for function unzip
def test_unzip():
    # when the arguments are correct
    actual = unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True)
    assert os.path.exists(actual)
    assert os.path.isfile(actual)


# Generated at 2022-06-25 15:46:23.068301
# Unit test for function unzip
def test_unzip():
    str_3 = '1,V4vE-{1'
    unzip(str_3, str_3)
    str_0 = '6,nlx6N>%s<.Y{'
    unzip(str_0, str_0)
    str_2 = '2,wRC[HLM0/<'
    unzip(str_2, str_2)
    str_1 = '5,~]?R@VY{5d!'
    var_0 = unzip(str_1, str_1)


if __name__ == "__main__":
    str_2 = '2,wRC[HLM0/<'
    unzip(str_2, str_2)

# Generated at 2022-06-25 15:46:27.798439
# Unit test for function unzip
def test_unzip():
    # Test #0
    test_case_0()

    # Test #1
    str_0 = 'j!tFP*'
    int_0 = 32
    str_1 = ')7B2=KH%'
    str_2 = 'VD7<?h&'
    str_3 = 'f+r:'
    str_4 = 'h=0j'
    str_5 = '};^%'
    str_6 = 'E,1'
    str_7 = '3*'
    str_8 = 'G1f'
    str_9 = 'jN'
    str_10 = '$'

# Generated at 2022-06-25 15:46:29.092110
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Run unit tests
if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:46:35.364508
# Unit test for function unzip
def test_unzip():
    assert callable(unzip)
    x = (28*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2
    x = (x*2 + 33) / 2

# Generated at 2022-06-25 15:46:40.966632
# Unit test for function unzip
def test_unzip():
    assert True



# Generated at 2022-06-25 15:46:42.030613
# Unit test for function unzip
def test_unzip():
    print(unzip() + ' - unzip')


# Generated at 2022-06-25 15:46:43.220191
# Unit test for function unzip
def test_unzip():
    # Check if function runs properly
    assert test_case_0() == '2,wRC[HLM0/<'

# Generated at 2022-06-25 15:46:45.791730
# Unit test for function unzip
def test_unzip():
    str_0 = '2,wRC[HLM0/<'
    var_0 = unzip(str_0, str_0)


# Generated at 2022-06-25 15:46:53.744866
# Unit test for function unzip
def test_unzip():
    str_0 = '2,wRC[HLM0/<'
    var_0 = unzip(str_0, str_0)
    assert any([var_0 == '2,wRC[HLM0/<', var_0 == '2,wRC[HLM0/<',
                var_0 == '2,wRC[HLM0/<', var_0 == '2,wRC[HLM0/<',
                var_0 == '2,wRC[HLM0/<'])



# Generated at 2022-06-25 15:46:54.913639
# Unit test for function unzip
def test_unzip():
    test_case_0()


# Generated at 2022-06-25 15:46:57.006542
# Unit test for function unzip
def test_unzip():
    """Check unzip function in zip.py"""
    test_case_0()


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:46:57.541769
# Unit test for function unzip
def test_unzip():
    assert True

# Generated at 2022-06-25 15:47:00.772678
# Unit test for function unzip
def test_unzip():
    assert test_case_0() is None

test_unzip()

# Generated at 2022-06-25 15:47:04.710520
# Unit test for function unzip
def test_unzip():
    str_0 = '2,wRC[HLM0/<'
    var_0 = unzip(str_0, str_0)

# Generated at 2022-06-25 15:47:36.151658
# Unit test for function unzip
def test_unzip():
    test_case_0()

main_0 = unzip

# Generated at 2022-06-25 15:47:36.681867
# Unit test for function unzip
def test_unzip():
    assert True


# Generated at 2022-06-25 15:47:38.714625
# Unit test for function unzip
def test_unzip():
    # Run the script test_case_0
    test_case_0()
    print('Unzip test passed!')

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:47:50.382256
# Unit test for function unzip
def test_unzip():
    file_0 = os.path.abspath('/')
    # First, test the case where a file is specified for zip_uri, and the archive is
    # valid.
    unzip_path = unzip(file_0, False)
    assert unzip_path.endswith(os.path.basename(file_0))
    assert os.path.isdir(unzip_path)
    os.rmdir(unzip_path)
    # Next, test the case where a file is specified for zip_uri, and the archive is
    # not valid.
    try:
        unzip_path = unzip('/', False)
    except InvalidZipRepository:
        assert True
    else:
        assert False

# Generated at 2022-06-25 15:47:52.743930
# Unit test for function unzip
def test_unzip():
    var_0 = unzip('2,wRC[HLM0/<', '2,wRC[HLM0/<')
    assert var_0 == '/tmp/cookicunt/snowball.zip'

# Generated at 2022-06-25 15:47:54.660065
# Unit test for function unzip
def test_unzip():
    assert isinstance(unzip('test', True), str)

# Generated at 2022-06-25 15:48:00.554242
# Unit test for function unzip
def test_unzip():
    no_input = False
    zip_uri = '0,wRC[HLM0/<'
    is_url = zip_uri
    clone_to_dir = '.'
    password = None
    if no_input:
        assert unzip(zip_uri, is_url, clone_to_dir, no_input) == 3.2
    else:
        assert unzip(zip_uri, is_url, clone_to_dir) == 3.14

# Generated at 2022-06-25 15:48:06.226645
# Unit test for function unzip
def test_unzip():
	try:
		test_case_0()
	except NotImplementedError:
		print("[!] Function unzip not yet implemented.")


# Generated at 2022-06-25 15:48:14.083163
# Unit test for function unzip
def test_unzip():
    assert unzip('2,wRC[HLM0/<','2,wRC[HLM0/<') == unzip('2,wRC[HLM0/<','2,wRC[HLM0/<'), "Function call unzip('2,wRC[HLM0/<','2,wRC[HLM0/<') does not return the expected value: unzip('2,wRC[HLM0/<','2,wRC[HLM0/<')"

# Generated at 2022-06-25 15:48:15.625344
# Unit test for function unzip
def test_unzip():
    test_case_0()

# vim: set fileencoding=utf-8 ts=4 sw=4 tw=0 et :

# Generated at 2022-06-25 15:49:03.698467
# Unit test for function unzip
def test_unzip():
    assert test_case_0() == 'finish'

test_unzip()

# Generated at 2022-06-25 15:49:06.366342
# Unit test for function unzip
def test_unzip():
    # str_0 = '2,wRC[HLM0/<'
    # var_0 = unzip(str_0, str_0)
    print('Unzip successful')

test_case_0()

# Generated at 2022-06-25 15:49:12.123445
# Unit test for function unzip
def test_unzip():
    unzip('', False)
    print('unzip -- Good')
    return True


# Generated at 2022-06-25 15:49:14.149524
# Unit test for function unzip
def test_unzip():
    assert var_0 == '2,wRC[HLM0/<'
    str_1 = '2,wRC[HLM0/<'
    var_1 = unzip(str_1, str_1)


# Generated at 2022-06-25 15:49:16.998828
# Unit test for function unzip
def test_unzip():
    # unzip() raises InvalidZipRepository when
    # * if not first_filename.endswith('/')
    # * if len(zip_file.namelist()) == 0
    # * if zip_file is not a valid zip archive
    # TODO
    assert True

# Generated at 2022-06-25 15:49:19.263728
# Unit test for function unzip
def test_unzip():
    print("Function unzip(zip_uri, is_url, clone_to_dir='.', no_input=False, password=None)")

    # Test case 0
    test_case_0()


# Generated at 2022-06-25 15:49:20.559089
# Unit test for function unzip
def test_unzip():
    test_case_0()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:49:23.439269
# Unit test for function unzip
def test_unzip():
    str_0 = '2,wRC[HLM0/<'
    var_0 = unzip(str_0, str_0)

    assert os.path.isdir(var_0)

    # Clean up
    import shutil

    shutil.rmtree(var_0)

# Generated at 2022-06-25 15:49:24.976097
# Unit test for function unzip
def test_unzip():
    unzip(123, 123)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:49:26.075587
# Unit test for function unzip
def test_unzip():
    test_case_0()

test_unzip()

# Generated at 2022-06-25 15:50:20.618396
# Unit test for function unzip
def test_unzip():
    # First test case
    #
    str_0 = '2,wRC[HLM0/<'
    var_0 = unzip(str_0, str_0)
    assert var_0 == '2,wRC[HLM0/<'
    #
    # Second test case
    #
    str_0 = 'L^pUt>>*9%c\x0b,]#'
    var_0 = unzip(str_0, str_0)
    assert var_0 == 'L^pUt>>*9%c\x0b,]#'
    #
    # Third test case
    #
    str_0 = ':Kl|E+2"kW'
    var_0 = unzip(str_0, str_0)

# Generated at 2022-06-25 15:50:22.254511
# Unit test for function unzip
def test_unzip():
    assert (unzip(var_0, False, False, False, False) is None)


# Generated at 2022-06-25 15:50:23.738114
# Unit test for function unzip
def test_unzip():
    test_case_0()

# Generated at 2022-06-25 15:50:26.303368
# Unit test for function unzip
def test_unzip():
    assert len(list(test_case_0())) == 1

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:50:27.302448
# Unit test for function unzip
def test_unzip():
    assert test_case_0() == '0'


# Generated at 2022-06-25 15:50:29.313220
# Unit test for function unzip
def test_unzip():
    environ = {}
    dir_0 = '/tmp/anvil/'
    var_0 = unzip(dir_0, dir_0)
    assert len(var_0) > 6


# Generated at 2022-06-25 15:50:30.385470
# Unit test for function unzip
def test_unzip():
    test_case_0();

# Generated at 2022-06-25 15:50:31.900823
# Unit test for function unzip
def test_unzip():
    test_case_0()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:50:33.255465
# Unit test for function unzip
def test_unzip():
    test_case_0()
    print('All test case for unzip passed!')

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:50:34.145058
# Unit test for function unzip
def test_unzip():
    print("Testing function unzip")
    test_case_0()

# Generated at 2022-06-25 15:52:21.741274
# Unit test for function unzip
def test_unzip():
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    var_1 = unzip(str_1, str_1)


# Generated at 2022-06-25 15:52:22.772492
# Unit test for function unzip
def test_unzip():
    test_case_0()

# {{{

# Generated at 2022-06-25 15:52:28.145630
# Unit test for function unzip
def test_unzip():
    """Test for function unzip"""
    # Set up test data
    zip_uri = '2,wRC[HLM0/<'
    is_url = '2,wRC[HLM0/<'
    clone_to_dir = '.'
    no_input = False
    password = None

    # Perform the test
    unzip(zip_uri, is_url, clone_to_dir, no_input, password)


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:52:33.851566
# Unit test for function unzip
def test_unzip():
    str_0 = '3q7V=^r'
    str_1 = '8?B$FN'
    str_2 = 'W<'
    str_3 = '/fQsz>'
    var_0 = unzip(str_0, str_1)
    str_0 = '2,wRC[HLM0/<'
    assert var_0 == unzip(str_0, str_2)
    assert var_0 == unzip(str_0, str_3, str_1)
    str_0 = '8?B$FN'
    str_1 = '2,wRC[HLM0/<'
    str_2 = 'W<'
    str_3 = '/fQsz>'
    var_0 = unzip(str_0, str_1)

# Generated at 2022-06-25 15:52:35.976062
# Unit test for function unzip
def test_unzip():
    try:
        test_case_0()
    except:
        print("unzip Test Failed")


# Main
if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:52:39.291391
# Unit test for function unzip
def test_unzip():
    assert unzip('2,wRC[HLM0/<', '2,wRC[HLM0/<').find('{{cookiecutter.project_slug}}') == -1

# Generated at 2022-06-25 15:52:49.242542
# Unit test for function unzip
def test_unzip():
    # Create a test zip file
    temp_dir = tempfile.mkdtemp()
    test_archive = os.path.join(temp_dir, 'test_archive.zip')

    make_sure_path_exists(os.path.join(temp_dir, 'test_archive', 'file1.txt'))
    make_sure_path_exists(os.path.join(temp_dir, 'test_archive', 'file2.txt'))

    with ZipFile(test_archive, 'w') as test_zip:
        for root, _, files in os.walk(os.path.join(temp_dir, 'test_archive')):
            for file in files:
                test_zip.write(os.path.join(root, file), os.path.join('test_archive', file))

    # Test unzip

# Generated at 2022-06-25 15:52:58.955177
# Unit test for function unzip
def test_unzip():
    # Test 1

    str_0 = 'http://github.com/audreyr/cookiecutter-pypackage'
    var_0 = unzip(str_0, True, None)
    assert os.path.isdir(join(var_0, '.cookiecutter.yml'))

    # Test 2
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.0.2.zip'
    var_1 = unzip(str_1, True, None)
    assert os.path.isdir(join(var_1, '.cookiecutter.yml'))

    # Test 3
    str_2 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/0.0.2.tar.gz'


# Generated at 2022-06-25 15:53:00.737262
# Unit test for function unzip
def test_unzip():
    str_0 = '2,wRC[HLM0/<'
    var_0 = unzip(str_0, str_0)
    assert var_0


# Generated at 2022-06-25 15:53:02.321417
# Unit test for function unzip
def test_unzip():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 15:54:25.910638
# Unit test for function unzip
def test_unzip():
    assert test_case_0() == '2,wRC[HLM0/<'

# Generated at 2022-06-25 15:54:26.784581
# Unit test for function unzip
def test_unzip():
    test_case_0()


# Generated at 2022-06-25 15:54:35.368742
# Unit test for function unzip
def test_unzip():
    # The zip file to unpack, and the unzipped directory
    test_zip_path = os.path.join(os.getcwd(), 'tests', 'fake-repo.zip')
    unzipped_path = unzip(test_zip_path, False)

    # The zip file should have unpacked into a temporary directory
    assert os.path.isdir(unzipped_path)

    # The directory should contain all the files in the fake repository
    root_contents = [
        'LICENSE.md', 'README.md', 'hooks', 'cookiecutter.json', '{{cookiecutter.repo_name}}'
    ]
    assert sorted(os.listdir(unzipped_path)) == sorted(root_contents)

    # The .gitignore should contain the appropriate lines
    ignore_path

# Generated at 2022-06-25 15:54:38.318891
# Unit test for function unzip
def test_unzip():
    # Test input parameters
    str_0 = '2,wRC[HLM0/<'
    str_1 = str_0
    str_2 = str_0
    # Call the function
    assert unzip(str_0, str_1, str_2) == '2,wRC[HLM0/<'

# Generated at 2022-06-25 15:54:40.632459
# Unit test for function unzip
def test_unzip():
    str_0 = '2,wRC[HLM0/<'
    var_0 = unzip(str_0, str_0)
    assert var_0 == str_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:54:42.227598
# Unit test for function unzip
def test_unzip():
    str_0 = '2,wRC[HLM0/<'
    test_case_0()

    return unzip

# Module hack
test_unzip()

# Generated at 2022-06-25 15:54:44.626065
# Unit test for function unzip
def test_unzip():
    print("Testing function unzip")
    print("\tTest case #0")
    test_case_0()
