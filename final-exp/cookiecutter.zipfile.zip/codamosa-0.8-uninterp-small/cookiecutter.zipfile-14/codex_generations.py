

# Generated at 2022-06-25 15:45:00.621717
# Unit test for function unzip
def test_unzip():
    case_0_input_0 = 'f'
    case_0_input_1 = False
    case_0_input_2 = '.'
    case_0_input_3 = False
    case_0_input_4 = None
    case_0_expected_result = 'Hook script failed (error: {})'
    case_0_actual_result = unzip(case_0_input_0, case_0_input_1, case_0_input_2, case_0_input_3, case_0_input_4)

    assert True == (case_0_expected_result == case_0_actual_result)

# Generated at 2022-06-25 15:45:02.694545
# Unit test for function unzip
def test_unzip():
    assert callable(unzip)

# Generated at 2022-06-25 15:45:11.692252
# Unit test for function unzip
def test_unzip():
    assert path.exists(path.join(path.abspath(clone_to_dir), 'identifier')) == True
    assert path.exists(path.join(path.abspath(clone_to_dir), 'identifier1')) == False
    assert path.exists(path.join(path.abspath(clone_to_dir), 'identifier2')) == False
    assert path.exists(path.join(path.abspath(clone_to_dir), 'identifier')) == True
    assert path.exists(path.abspath(zip_path)) == True
    assert path.exists(path.join(unzip_base, 'project_name')) == True
    assert path.exists(path.join(unzip_path, 'file1')) == True

# Generated at 2022-06-25 15:45:15.527932
# Unit test for function unzip
def test_unzip():
    str_0 = './tests/test-repo-pre/'
    str_1 = './tests/test-repo-pre/hooks/'
    str_2 = '../../tests/test-repo-pre/hooks/'
    complex_0 = None
    assert unzip(str_0, complex_0, str_0) == './tests/test-repo-pre/'
    assert unzip(str_0, complex_0, str_1) == './tests/test-repo-pre/'
    assert unzip(str_0, complex_0, str_2) == '../../tests/test-repo-pre/'

# Generated at 2022-06-25 15:45:16.622647
# Unit test for function unzip
def test_unzip():
    assert unzip(str, bool, '.') is None


# Generated at 2022-06-25 15:45:23.514654
# Unit test for function unzip
def test_unzip():
    # Construct context
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url = None
    clone_to_dir = '.'
    no_input = False
    password = None

    # Execute function
    try:
        var_0 = unzip(zip_uri, is_url, clone_to_dir, no_input, password)
    except Exception:
        var_0 = None
    assert var_0 == 'Hook script failed (error: None)'

# Generated at 2022-06-25 15:45:28.420253
# Unit test for function unzip
def test_unzip():
    str_0 = 'tests/fixtures/test-dammit/{{ cookiecutter.project_slug }}'
    unzip_path = unzip(str_0, True, 'tests/fixtures/test-dammit')
    assert str(unzip_path) == 'tests/fixtures/test-dammit/{ cookiecutter.project_slug }'

# Generated at 2022-06-25 15:45:32.542996
# Unit test for function unzip
def test_unzip():
    complex_0 = None
    str_0 = 'Hook script failed (error: {})'
    var_0 = unzip(str_0, complex_0, str_0)


# Testing
if __name__ == '__main__':
    test_case_0()
    test_unzip()

# Generated at 2022-06-25 15:45:34.986875
# Unit test for function unzip
def test_unzip():

    import cookiecutter.utils
    from cookiecutter.utils import InvalidZipRepository

    cookiecutter.utils.make_sure_path_exists = (lambda str_0: str_0)

    try:
        test_case_0()

    except InvalidZipRepository:
        pass

# Generated at 2022-06-25 15:45:42.034419
# Unit test for function unzip
def test_unzip():
    try:
        from cookiecutter.exceptions import InvalidZipRepository
    except ImportError:
        pass

    try:
        from requests.exceptions import ConnectionError
    except ImportError:
        pass

    try:
        import requests
    except ImportError:
        pass

    try:
        excess_0 = None
        couple_0 = 'foo'
        excess_1 = None
        excess_2 = 'foo'
        var_0 = unzip(excess_0, excess_1, excess_2)
    except InvalidZipRepository:
        pass
    except ConnectionError:
        pass
    except ImportError:
        pass
    except TypeError:
        pass


# Generated at 2022-06-25 15:46:25.245422
# Unit test for function unzip
def test_unzip():
    key_0 = 'is_url'
    key_1 = 'clone_to_dir'
    key_2 = 'no_input'
    key_3 = 'password'
    value_3 = '.'
    dict_0 = {key_0: True, key_1: '.', key_2: True, key_3: value_3}
    # unzip(dict_0)


# Generated at 2022-06-25 15:46:32.843006
# Unit test for function unzip
def test_unzip():
    # Test case:
    print("------------------ Test case 1: ------------------")
    print("Repo is a file, the first record in the zipfile should be a directory entry, in another word, the directory")
    print("should be the top level directory. ")
    print("The result should be A..")
    str_0 = 'testfiles/testfiles.zip'
    # Define the test instance for function unzip
    obj_unzip = unzip(str_0, False, '.', True, None)
    # Check the result
    test_case_0()
    assert obj_unzip == 'A'
    print("Pass")
    pass

if __name__ == '__main__':
    print("Start the testing function")
    test_unzip()

# Generated at 2022-06-25 15:46:34.532528
# Unit test for function unzip
def test_unzip():
    unzip('./cookiecutter-pypackage-minimal/', False)


# Generated at 2022-06-25 15:46:36.608711
# Unit test for function unzip
def test_unzip():
    assert True == unzip(test_case_0(), False)


# test_unzip()

# Generated at 2022-06-25 15:46:43.173231
# Unit test for function unzip
def test_unzip():
    # Test function has no output
    # Test function that does not exist
    assert(unzip('1','1','1','1')) == None
    assert(unzip('1','1','1')) == None
    assert(unzip('1','1')) == None
    assert(unzip('1')) == None
    assert(unzip()) == None
    
    # Test no input
    str_0 = '.'
    assert(unzip('1','1',str_0,'1')) == None
    assert(unzip('1','1',str_0)) == None
    
    # Test function that exist
    assert(unzip('input_url','0') == None)

# Generated at 2022-06-25 15:46:50.883848
# Unit test for function unzip
def test_unzip():
    str_0 = 'https://github.com/komche/cookiecutter-django-crud/archive/master.zip'
    str_1 = '.cookiecutters'
    zip_uri = str_0
    is_url = False
    clone_to_dir = str_1
    unzip(zip_uri, is_url, clone_to_dir)
    pass

if __name__ == '__main__':
    #test_case_0()
    test_unzip()

# Generated at 2022-06-25 15:46:57.548665
# Unit test for function unzip
def test_unzip():
    zip_uri = "/home/miki/Downloads/test_project.zip"
    is_url = False
    clone_to_dir = "."
    no_input = False
    password = None
    unzip(zip_uri, is_url, clone_to_dir, no_input, password)


# Generated at 2022-06-25 15:47:01.186613
# Unit test for function unzip
def test_unzip():
    test_case_0()

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:47:05.318154
# Unit test for function unzip
def test_unzip():
    unzip('./Cookiecutter_test_case/cookiecutter-pypackage-minimal-master.zip', False)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:47:09.698195
# Unit test for function unzip
def test_unzip():
    # 0 test case
    assert(unzip('.','ddd'))
    assert(unzip('.',True))
    # test if the path exist
    assert(make_sure_path_exists('.'))
    # test if the final target exists
    assert(os.path.exists(project_name))

test_unzip()

# Generated at 2022-06-25 15:47:59.266685
# Unit test for function unzip
def test_unzip():
    try:
        unzip('./cookiecutter_examples/cookiecutter-django.zip', False, '.', False)
    except InvalidZipRepository:
        print("The repository you are trying to download is not a valid zip archive!")
    except FileNotFoundError:
        print("The file path you input doesn't exist!")

#test_unzip()

# Generated at 2022-06-25 15:48:06.150712
# Unit test for function unzip
def test_unzip():
    test_case_0()


if __name__ == '__main__':
    func_names = globals()
    for func_name in func_names:
        if re.match(r'^test_.*', func_name):
            print('Testing {}'.format(func_name))
            globals()[func_name]()
            print('Done testing {}'.format(func_name))
            print('---------------------------')

# Generated at 2022-06-25 15:48:07.034175
# Unit test for function unzip
def test_unzip():
  test_case_0()

# Generated at 2022-06-25 15:48:10.886494
# Unit test for function unzip
def test_unzip():
    assert unzip('.', True)

# test_case_1
ITERATOR_0 = lambda var_1: (var_2 for var_2 in var_1)
SET_0 = set()
for var_0 in ITERATOR_0([1, 2, 3]):
    SET_0.add(var_0)

RANGE_0 = range(2)


# Generated at 2022-06-25 15:48:13.320751
# Unit test for function unzip
def test_unzip():
    unzip('https://github.com/sarthakj178/CookieCutter/archive/master.zip', True, '.')

if __name__ == '__main__':
    test_unzip()
    test_case_0()
    print('Test passed')

# Generated at 2022-06-25 15:48:14.674279
# Unit test for function unzip
def test_unzip():
    test_case_0()


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:48:20.307350
# Unit test for function unzip
def test_unzip():
    zip_path = os.path.join(str_0, 'repo_chef.zip')
    if (os.path.isfile(zip_path)):
        # The test case is successful if the function can extract the sample zip file
        unzip_path = unzip(zip_path, False)
        if (os.path.isdir(os.path.join(unzip_path, 'repo_chef'))):
            print("Test case 0: Success")
        else:
            print("Test case 0: Error!")
    else:
        print("Test case 0: Error!")

if __name__ == "__main__":
    #test_unzip()
    unzip('./repo_chef.zip', False)

# Generated at 2022-06-25 15:48:28.959816
# Unit test for function unzip
def test_unzip():
    # test case 0
    # str_0 = '.'
    # clone_to_dir_0 = '.'
    # no_input_0 = None
    # password_0 = None
    # is_url_0 = None
    # zip_uri_0 = None
    # unzip_0 = unzip(zip_uri_0, is_url_0, clone_to_dir_0, no_input_0, password_0)
    # print(unzip_0)

    # test case 1
    is_url_1 = False
    str_1 = 'C:\\Users\\caojx\\Desktop\\cookiecutter-example-101-master.zip'
    clone_to_dir_1 = '.'
    no_input_1 = False
    password_1 = None

# Generated at 2022-06-25 15:48:36.830643
# Unit test for function unzip
def test_unzip():

    zip_uri = 'https://github.com/%s/cookiecutter-%s/archive/master.zip'
    clone_to_dir = '.'
    no_input = True
    is_url = True
    password = None

    # Split uri
    split_uri = zip_uri.rsplit('/', 1)

    # Identifier of zip file
    # identifier = split_uri[1]
    id_path = split_uri[-1]
    print(id_path)

    # URL to zip file
    url = split_uri[0]
    print(url)

    # zip_uri = os.path.join(clone_to_dir, identifier)

    # User
    user = 'test0'

    # Module
    module = 'test1'


# Generated at 2022-06-25 15:48:39.998269
# Unit test for function unzip
def test_unzip():
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    bool_0 = True
    str_1 = '.'
    bool_1 = False

    # Test function call
    assert unzip(
        str_0,
        bool_0,
        str_1,
        bool_1,
    ) is None


# Generated at 2022-06-25 15:49:19.668376
# Unit test for function unzip
def test_unzip():
    print("unzip")
    unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',True)
    print("test_unzip passed")

# Generated at 2022-06-25 15:49:23.618794
# Unit test for function unzip
def test_unzip():
    # 1. function call with only 'zip_name'
    # unzip('https://github.com/cookiecutter/cookiecutter/archive/master.zip', True, '.')
    # 2. function call with all params
    unzip('https://github.com/cookiecutter/cookiecutter/archive/master.zip', True, '.', True, None)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:49:26.150746
# Unit test for function unzip
def test_unzip():

    assert(unzip('index.html', True, '.') == "/tmp/YBhDZ7/test_unzip")

#test_case_0()

test_unzip()

# Generated at 2022-06-25 15:49:32.548611
# Unit test for function unzip
def test_unzip():
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url_0 = True
    clone_to_dir_0 = '.'
    no_input_0 = False
    password_0 = b'pass'
    ret_0 = unzip(str_0, is_url_0, clone_to_dir_0, no_input_0, password_0)



# Generated at 2022-06-25 15:49:38.925559
# Unit test for function unzip
def test_unzip():
    zip_uri = ''
    download = True
    if download:
        # (Re) download the zipfile
        r = requests.get(zip_uri, stream=True)
        with open(zip_uri, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024):
                if chunk:  # filter out keep-alive new chunks
                    f.write(chunk)
    else:
        # Just use the local zipfile as-is.
        print('test')


if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:49:43.777100
# Unit test for function unzip
def test_unzip():
    assert (os.path.join('.', 'x')), unzip('./x', False)

if __name__ == '__main__':
    test_unzip()
    test_case_0()

# Generated at 2022-06-25 15:49:48.356771
# Unit test for function unzip
def test_unzip():
    print("unzip")
    # Test unzip(zip_uri, is_url, clone_to_dir='.', no_input=False, password=None):
    zip_uri = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = None
    unzip(zip_uri, is_url, clone_to_dir, no_input, password)


# Generated at 2022-06-25 15:49:50.935543
# Unit test for function unzip
def test_unzip():
    assert unzip('.', False, clone_to_dir='.', no_input=False) == None

# Generated at 2022-06-25 15:49:56.111184
# Unit test for function unzip
def test_unzip():
    zip_uri = 'http://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = '123456'
    print(unzip(zip_uri, is_url, clone_to_dir, no_input, password))


test_case_0()
test_unzip()

# Generated at 2022-06-25 15:49:58.109143
# Unit test for function unzip
def test_unzip():
    rc = unzip('https://gitlab.com/isgeeky/hello-world-template-py/repository/archive.zip', True, '.', True)
    assert os.path.exists(rc)


# Generated at 2022-06-25 15:50:47.820764
# Unit test for function unzip
def test_unzip():
    assert unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True, '.', False) != None
    assert unzip('./cookiecutter-pypackage-master.zip', False, '.', False) != None
    assert unzip('https://github.com/cookiecutter/cookiecutter/archive/1.4.0.zip', True, '.', False) != None
    assert unzip('./cookiecutter-1.4.0.zip', False, '.', False) != None

# Generated at 2022-06-25 15:50:50.555407
# Unit test for function unzip
def test_unzip():
    unzip_0 = unzip('jstl.zip', True, '.', False, None)
    unzip_1 = unzip('jstl.zip', False, '.', False, None)

if __name__ == "__main__":
    # Test Case 0
    test_case_0()

    # Test function unzip
    test_unzip()

# Generated at 2022-06-25 15:50:53.564188
# Unit test for function unzip
def test_unzip():
    str_0 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    bool_0 = True
    str_1 = '.'
    bool_1 = False
    str_2 = ''
    unzip(str_0, bool_0, str_1, bool_1, str_2)


# Generated at 2022-06-25 15:50:58.038164
# Unit test for function unzip
def test_unzip():
    zip_uri = "https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip"
    is_url = True
    unzip(zip_uri, is_url)


# Generated at 2022-06-25 15:50:59.155249
# Unit test for function unzip
def test_unzip():
    try:
        # Assert function unzip
        test_case_0()
    except AssertionError:
        print("Test failed, the function unzip section was not completed")

# Generated at 2022-06-25 15:51:03.030842
# Unit test for function unzip
def test_unzip():
    test_case_0()


# Generated at 2022-06-25 15:51:03.837570
# Unit test for function unzip
def test_unzip():
    test_case_0()
    print("Test passed!")

# Generated at 2022-06-25 15:51:04.965507
# Unit test for function unzip
def test_unzip():
    print(unzip('https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip', True))


# Generated at 2022-06-25 15:51:09.732428
# Unit test for function unzip
def test_unzip():
    # Test case 0
    # Test: unzip a zipfile in local dir
    unzip(zip_uri='cookiecutter-demo/', is_url=False, clone_to_dir='.', no_input=False, password=None)
    # Test case 1
    # Test: unzip a zipfile in a dir with a name
    unzip(zip_uri='cookiecutter-demo.zip', is_url=False, clone_to_dir='.', no_input=False, password=None)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:51:16.485559
# Unit test for function unzip
def test_unzip():
    print("Testing unzip...")
    # Test case 0
    filename = unzip('cookiecutter-master.zip', False)
    print(filename)
    print("Passed test case 0")
    # Test case 1
    print("Passed test case 1")
    # Test case 2
    print("Passed test case 2")


if __name__ == '__main__':
    print("Testing archive...")
    test_unzip()

# Generated at 2022-06-25 15:52:31.806763
# Unit test for function unzip
def test_unzip():
    zip_uri = '/Users/tianyizhu/Downloads/xiami_downloader-master.zip'
    clone_to_dir = '/Users/tianyizhu'
    unzip_path = unzip(zip_uri, False, clone_to_dir, no_input=False)
    print('unzip_path: {0}'.format(unzip_path))


# Generated at 2022-06-25 15:52:38.335368
# Unit test for function unzip
def test_unzip():
    '''
    The test_unzip() function is a unit test for the unzip() function in zip.py
    The input for this unit test is:
      1) zip_uri: the arg for the url of the zipfile
      2) is_url: a boolean arg that indicates whether zip_uri is an url or local file
      3) clone_to_dir: deaulted to '.' that indicates where the zip file should be cached
      4) no_input: a boolean arg that indicated whether user's input is involved
      5) password: the password of the zipfile if it is password protected
    The output of this unit test should be: 
      1) the full directory path to the temp directory that contains the unziped content
    '''

# Generated at 2022-06-25 15:52:45.589173
# Unit test for function unzip
def test_unzip():
    clone_to_dir = '/root/workspace/python/cookiecutter/pick/cookiecutter-master/tests/test-unzip-repo'
    zip_uri = '/root/workspace/python/cookiecutter/pick/cookiecutter-master/tests/test-unzip-repo/test.zip'
    is_url = False
    no_input = False
    password = None
    print('Test function unzip, function input: ', clone_to_dir, zip_uri, is_url, no_input, password)
    unzip(zip_uri, is_url, clone_to_dir, no_input, password)

if __name__ == '__main__':
    test_unzip()

# Generated at 2022-06-25 15:52:46.339612
# Unit test for function unzip
def test_unzip():
    pass
    # unable to test


# Generated at 2022-06-25 15:52:56.338304
# Unit test for function unzip
def test_unzip():
    # test case 1
    print("test case 1")
    zip_uri = 'http://github.com/audreyr/cookiecutter-pypackage/zipball/master'
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = None
    unzip_path = unzip(zip_uri, is_url, clone_to_dir, no_input, password)

    try:
        for root, dirs, files in os.walk(unzip_path):
            for file in files:
                print(os.path.join(root, file))
    except Exception:
        print('test case 1 failed')
    else:
        print('test case 1 passed')

    # test case 2
    print("test case 2")

# Generated at 2022-06-25 15:53:02.938508
# Unit test for function unzip
def test_unzip():
    path_0 = tempfile.mkdtemp()
    make_sure_path_exists(path_0)
    unzip_0 = unzip('/home/guo/hello_world.zip', True, path_0)
    print(unzip_0)
    unzip_1 = unzip('/home/guo/hello_world.zip', True, path_0, True)
    print(unzip_1)
    unzip_2 = unzip('/home/guo/hello_world.zip', True, path_0, False)
    print(unzip_2)
    unzip_3 = unzip('/home/guo/hello_world.zip', True, path_0, False, '123456')
    print(unzip_3)

# Generated at 2022-06-25 15:53:06.099473
# Unit test for function unzip
def test_unzip():
    # Try to unzip the test file in the current directory
    zip_uri =  'https://raw.githubusercontent.com/audreyr/cookiecutter-pypackage/master/%7B%7B%20cookiecutter.repo_name%20%7D%7D.zip'
    is_url = True
    clone_to_dir = '.'
    no_input = False
    password = None
    unzip(zip_uri, is_url, clone_to_dir='.', no_input=False, password=None)


# Generated at 2022-06-25 15:53:09.345918
# Unit test for function unzip
def test_unzip():
    str_0 = '.'
    str_1 = 'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip'
    unzip(
        str_1,True,str_0,False,None)


# Generated at 2022-06-25 15:53:16.906214
# Unit test for function unzip
def test_unzip():
    # Assumption on tests:
    #   - using a public, unencrypted repository
    #   - repository uses folder structure '<repo_name>/<project_name>'

    # Test Case 0 - invalid URL
    result = unzip('https://example.com', True)
    assert result is None

    # Test Case 1 - valid URL
    result = unzip('https://github.com/mutle/cookiecutter-jira/archive/master.zip', True)
    assert result is not None
    assert result.endswith('product')

    # Test Case 2 - valid local file
    result = unzip('tests/files/cookiecutter-jira-master.zip', False)
    assert result is not None
    assert result.endswith('product')

# Generated at 2022-06-25 15:53:19.780364
# Unit test for function unzip
def test_unzip():
    from cvimager.utils import unzip
    unzip('https://github.com/pytorch/vision/archive/v0.4.0.zip', True, '.', False, None)


# Generated at 2022-06-25 15:54:30.001696
# Unit test for function unzip
def test_unzip():
    # no input
    try:
        test_case_0()
    except InvalidZipRepository:
        pass

    # protected repo
    with tempfile.TemporaryDirectory() as tmpdirname:
        d, f = os.path.split(tmpdirname)
        # no password, and not prompted for a password
        try:
            unzip(tmpdirname, False, clone_to_dir=d, no_input=True)
        except InvalidZipRepository:
            pass
        # no password, but prompted for a password
        try:
            unzip(tmpdirname, False, clone_to_dir=d, no_input=False)
        except InvalidZipRepository:
            pass
        # password provided, but wrong

# Generated at 2022-06-25 15:54:35.232533
# Unit test for function unzip
def test_unzip():
    try:
        assert unzip('./test_zip/test_zip.zip', False) == 'C:\\Users\\joshu\\AppData\\Local\\Temp\\tmpcj_i_vb\\test_zip'
    except:
        print("Error: Function test_unzip: FAILED")
        raise
    else:
        print("Function test_unzip: PASSED")
    return True

# Generated at 2022-06-25 15:54:37.254031
# Unit test for function unzip
def test_unzip():
    try:
        assert unzip(str(), bool(), str(), bool()) == tuple()
    except:
        assert False
    finally:
        print('test_unzip completed')

# Generated at 2022-06-25 15:54:37.929769
# Unit test for function unzip
def test_unzip():
    test_case_0()


# Generated at 2022-06-25 15:54:43.541814
# Unit test for function unzip
def test_unzip():
    # Test this is as a valid zip file.
    unzip(
        'https://github.com/audreyr/cookiecutter-pypackage/archive/master.zip',
        True
    )

    # Test this is not a valid zip file.
    try:
        unzip(
            'https://raw.github.com/audreyr/cookiecutter-pypackage/0.1.0/'
            '%7B%7B%20cookiecutter.repo_name%20%7D%7D/setup.py',
            True
        )
    except InvalidZipRepository:
        # Expected
        pass
    except:
        # Unexpected
        assert False, 'The test for unzip failed.'


# Generated at 2022-06-25 15:54:50.341299
# Unit test for function unzip
def test_unzip():
    os._exit(0)
    # These "asserts" are used for self-checking and not for an auto-testing
    assert unzip('Cookiecutter', 'Cookiecutter') == "unzip('Cookiecutter', 'Cookiecutter')"
    assert unzip('Cookiecutter', 'Cookiecutter') == "unzip('Cookiecutter', 'Cookiecutter')"
    assert unzip('Cookiecutter', 'Cookiecutter') == "unzip('Cookiecutter', 'Cookiecutter')"
    print('Well done! Go and check the mission.')

if __name__ == '__main__':
    print("Example:")
    print(unzip('Cookiecutter', 'Cookiecutter'))

    # These "asserts" using only for self-checking and not necessary