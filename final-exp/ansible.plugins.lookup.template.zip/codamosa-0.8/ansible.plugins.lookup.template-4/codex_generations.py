

# Generated at 2022-06-22 14:22:33.266584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.vars import combine_vars

    # Set up a fixture for this test case.
    fixture_path = os.path.join(os.path.dirname(__file__), '../fixtures')
    os.environ['ANSIBLE_LOOKUP_PLUGINS'] = fixture_path

    # Set up an environment like the one in an ansible playbook.
    global_vars = combine_vars(None, {})
    playbook_vars = combine_vars(None, {})
    inventory_vars = combine_vars(None, {})
    hostvars = {}
    host_vars = combine_vars(inventory_vars, hostvars)
    vars = combine_vars(playbook_vars, host_vars)

# Generated at 2022-06-22 14:22:45.818680
# Unit test for method run of class LookupModule

# Generated at 2022-06-22 14:22:58.510714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        terms=['file1.j2'],
        variables=dict(
            ansible_search_path=['/home/my_playbooks'],
            template_vars=dict()
        ),
        convert_data=False,
        jinja2_native=False,
        variable_start_string='{{',
        variable_end_string='}}',
        comment_start_string='__',
        comment_end_string='__',
    )
    m = LookupModule()
    m.set_loader(m.loader)
    results = m.run(**args)
    assert results == ['a string']

    args['terms'] = 'file2.j2'
    results = m.run(**args)
    assert results == ['Another string']


# Generated at 2022-06-22 14:23:04.516433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    env = {'no_log': True, 'convert_data': False, 'template_vars': {}, 'no_target_sys': False}

    testlookup_module = LookupModule()

    lookupfile = '../../../../lib/ansible/plugins/lookup/template.py'
    try:
        f = open(lookupfile)
    except IOError as e:
        raise Exception("Test Terminated: Cannot open file %s" % lookupfile)

    lines = f.readlines()
    lines = ''.join(lines)
    f.close()

    data = '{{ lookup("template", "' + lookupfile + '") }}'

    testlookup_module.set_options(var_options=env, direct=env)

    # Check if the returned contents of file matches the contents of the file
    assert test

# Generated at 2022-06-22 14:23:17.203695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.collections import ImmutableDict

    kwargs = {'variable_start_string': '%{', 'variable_end_string': '}'}
    lookup_module = LookupModule()
    lookup_module._load_name = 'lookup_plugin.template'
    lookup_module._loader = MockFileLoader()
    lookup_module._templar = MockTemplar()
    lookup_module._loader.set_basedir('/etc/ansible/roles/role_under_test')
    lookup_module._display = Display()
    lookup_module._display.verbosity = 10

    # Case 1: test with a single file

# Generated at 2022-06-22 14:23:29.066344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    #
    # test with jinja2_native=True
    #
    module.set_options(direct={'jinja2_native': True})
    assert module.get_option('jinja2_native')
    assert USE_JINJA2_NATIVE


# Generated at 2022-06-22 14:23:37.384126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # https://docs.pytest.org/en/latest/fixture.html#fixture-params
    templar = DummyTemplar()
    lookup = LookupModule()
    lookup._templar = templar

    # Empty string
    assert lookup.run(terms=[''], variables={}) == []

    # Simple string
    assert lookup.run(terms=['foo'], variables={}) == ['foo']

    # Invalid string
    try:
        lookup.run(terms=['{{ invalid }}'], variables={'invalid': 'bar'})
        assert False
    except AnsibleError:
        assert True

    # Simple template
    terms = '{{ foo }}'
    variables = {'foo': 'bar'}
    assert lookup.run(terms=[terms], variables=variables) == ['bar']

    # TOD

# Generated at 2022-06-22 14:23:48.747617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    terms = ["template.j2"]
    variables = {"foo": "bar"}

    ret = lookup_mod.run(terms, variables)
    assert ret == ["{{ foo }}"]

    lookup_mod = LookupModule()
    terms = ["template_vars.j2"]
    variables = {"foo": "bar"}
    lookvar = "baz"
    lookup_template_vars = {"jinja2_var": lookvar}
    ret = lookup_mod.run(terms, variables, template_vars=lookup_template_vars)
    assert ret == ["{{ jinja2_var }}"]

    lookup_mod = LookupModule()
    terms = ["template_vars.j2"]
    variables = {"foo": "bar"}
    lookvar = 1
    lookup_

# Generated at 2022-06-22 14:23:57.504212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["templates/test.j2"]
    display.debug("File lookup term: %s" % terms)

    lookupfile = lookup.find_file_in_search_path(variables=None, basedir="templates", file=terms)
    display.vvvv("File lookup using %s as file" % lookupfile)
    if lookupfile:
        b_template_data, show_data = lookup._loader._get_file_contents(lookupfile)
        template_data = to_bytes(b_template_data, errors='surrogate_or_strict')

        vars = deepcopy(variables)
        vars.update(generate_ansible_template_vars(terms, lookupfile))
        vars.update(var)


# Generated at 2022-06-22 14:24:04.356902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    mock_loader = MagicMock()
    mock_loader.path_dwim_relative.return_value = "/home/ansible/tests/foobar"
    mock_loader.file_exists.return_value = True
    mock_loader._get_file_contents.return_value = "{% if lookup('env','HOME') == '/home/ansible' %}" \
                                                  "ANSIBLE_HOME is tested" \
                                                  "{% else %}" \
                                                  "ANSIBLE_HOME is not tested" \
                                                  "{% endif %}"

    mock_vars = MagicMock(VariableManager)
    mock_vars.extra_vars = dict()

# Generated at 2022-06-22 14:24:15.979228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # TODO(dfannin): Write unit tests for this class.
    pass

# Generated at 2022-06-22 14:24:27.823318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lb = LookupModule()

    # Test jinja2_native=False

    terms = ['foo.j2']
    variables = {'var1': 'ansible', 'var2': 'j2'}
    jinja2_native = False
    lookup_template_vars = \
        {'bar': 'baz'}
    with open(terms[0], 'w') as f:
        f.write("{{ var1 }} {{ var2 }} {{ bar }}.")
    result = lb.run(terms, variables, jinja2_native=jinja2_native,
                    lookup_template_vars=lookup_template_vars)
    assert result == ['ansible j2 baz.']

    # Test jinja2_native=True

    terms = ['bar.j2']

# Generated at 2022-06-22 14:24:36.166889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod.set_loader({'_get_file_contents' : test_LookupModule__get_file_contents})
    lookup_mod.set_environment("LookupModule_run", None)
    result = lookup_mod.run(["./some_template.j2"], {}, variable_start_string = '<%', variable_end_string = '%>', comment_start_string = '<#', comment_end_string = '#>')
    expected = ["LOOKUP RESULT"]
    assert result == expected

# Unit test helper function

# Generated at 2022-06-22 14:24:46.346587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.plugins.loader import lookup_loader

    # load our test plugin
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), 'lookup_plugins'))

    templar = Templar(loader=None, variables=VariableManager())

    # create a lookup object and test it
    lookup = lookup_loader.get('inherit_parent_basename')

    # contents of the test file
    data = """
---
data: foo
""".strip()

    # set the search path

# Generated at 2022-06-22 14:24:58.017393
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing constructor
    lookup_module = LookupModule()

    # Testing _get_file_contents
    def _get_file_contents(self, filename):
        return ("test", False)
    lookup_module._loader._get_file_contents = _get_file_contents

    # Testing find_file_in_search_path
    def find_file_in_search_path(self, variables, dirs, file_name):
        return "test"
    lookup_module.find_file_in_search_path = find_file_in_search_path

    def set_options(self, var_options=None, direct=None):
        return
    lookup_module.set_options = set_options

    def get_option(self, option):
        return ""
    lookup_module.get_option = get

# Generated at 2022-06-22 14:25:09.017148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from collections import OrderedDict
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.display import Display
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment
    from ansible.plugins.loader import lookup_loader

    lu_instance = lookup_loader.get('template')
    find_file_in_search_path_mock = lu_instance.find_file_in_search_path

    lookup_file = "hello.j2"
    lookup_file_real = lookup_file + "_real"
    searchpath = ["/home/bob/ansible/roles/my_role"]

# Generated at 2022-06-22 14:25:19.134878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    The method run of class LookupModule takes two arguments: self and terms

    The method returns a list of strings; for each template file in the list of templates the user passed in, the
    method returns a string containing the results of processing that template.
    """
    # import module lookup to test method run of class LookupModule
    imported_LookupModule = __import__('ansible.plugins.lookup.template')
    # create an object of class LookupModule for testing
    template = getattr(imported_LookupModule, 'LookupModule')()

    # actual returns from the method run of class LookupModule
    actual_return = template.run(terms=['/home/user/some_template.j2'], variables={})

    # expected returns from the method run of class Lookup

# Generated at 2022-06-22 14:25:30.097503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    dirname = tempfile.mkdtemp()
    test_file = os.path.join(dirname, 'test.j2')
    try:
        os.makedirs(dirname)
        with open(test_file, 'w') as f:
            f.write('foo{{ var1 }}{% if var2 %}bar{% endif %}baz')

        lm = LookupModule()
        result = lm.run([test_file], variables={'var1': '1', 'var2': True})
        assert [u'foo1barbaz'] == result
    finally:
        os.remove(test_file)
        os.rmdir(dirname)

# Generated at 2022-06-22 14:25:38.371889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test LookupModule.run method with a simple template
    '''
    import pytest

    msg = "Hello, World!"
    test_var = "hi"
    lookup_template_vars = {
        "test_var": test_var,
    }
    terms = ["./templates/hello_world.j2"]

    lookup = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    ret = lookup.run(terms, None, lookup_template_vars=lookup_template_vars)

    assert msg == ret[0]


# Generated at 2022-06-22 14:25:40.619271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["./some_template.j2"]
    variables = {'name': 'Alex'}
    assert module.run(terms, variables)

# Generated at 2022-06-22 14:26:09.652509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if not HAS_JINJA2:
        return
    my_dict = {
        'name': 'John',
        'surname': 'Doe'
    }

    # create a test module to use the lookup function from
    class TestModule(object):
        def __init__(self, basedir):
            self.basedir = basedir
            self._templar = Templar(loader=None)

    # create a test lookup with the TestModule and lookup parameters

# Generated at 2022-06-22 14:26:13.960217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = dict()
    result["result"] = True
    result["comment"] = "Success"
    result["changes"] = {}
    test_result = {}
    test_result["msg"] = "{{ lookup('template', './some_template.j2') }}"
    result["results"] = test_result
    return result

# Generated at 2022-06-22 14:26:23.922376
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Values for test
    terms = ['../library/copy_files.py', 'nginx.j2']

# Generated at 2022-06-22 14:26:34.702278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    lookup.set_options(var_options=None)

    def find_file_in_search_path(variables, subdirs, file):
        return 'file1'

    lookup.find_file_in_search_path = find_file_in_search_path

    def get_file_contents(file):
        if file == 'file1':
            return '{% for item in [1,2,3] %}{{ item }}{% endfor %}', False
        else:
            return '', False

    lookup._loader._get_file_contents = get_file_contents
    lookup._templar = ''

    results = lookup.run(['./test'], {})


# Generated at 2022-06-22 14:26:45.251202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = os.path.dirname(os.path.realpath(__file__))
    searchpath = [p + '/../lookup_plugins']

    vars =  { 'template_myvar': "myval" }
    templar = AnsibleEnvironment(loader=None, variables=vars)

    lookup = LookupModule()
    results = lookup.run([ 'md5sum.j2' ], vars, templar=templar, loader=None, searchpath=searchpath, basedir=p, convert_data=False, jinja2_native=False, context=None, wantlist=True)

    assert len(results) == 1
    assert results[0] == "\nABCDEF\n"



# Generated at 2022-06-22 14:26:57.374213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    lookup_template_vars = {'name': 'David'}
    terms = ['example_jinja2.j2']
    variables = {'template_mtime': '2016-04-27T16:27:24.595515Z', 'template_path': './'}
    display.debug("File lookup term: %s" % terms)
    ret = {'template_mtime': '2016-04-27T16:27:24.595515Z', 'template_path': './'}
    for term in terms:
        t = json.dumps(variables, ensure_ascii=True)
        s = json.dumps(ret, ensure_ascii=True)
        display.debug("File lookup term: %s" % term)

# Generated at 2022-06-22 14:27:05.697915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    test for method run of class LookupModule
    '''
    import tempfile
    from ansible.module_utils.six import StringIO

    fd, templatefile = tempfile.mkstemp()
    os.close(fd)
    with open(templatefile, "w") as f:
        f.write("{{ foo }}")
    searchpath = [os.path.dirname(templatefile)]
    templar = Templar(loader=DictDataLoader({}))
    lookup = LookupModule(loader=DictDataLoader({}), templar=templar, basedir=None, runner=None, variable_manager=None)


# Generated at 2022-06-22 14:27:18.050386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class ModLookupModule(LookupModule):
        def __init__(self):
            self.called = False
            self.calls = 0

        def run(self, terms, variables, **kwargs):
            self.called = True
            self.calls += 1
            return []

    class ModTemplar():
        def __init__(self):
            self.called = False
            self.calls = 0
        def _copy_with_new_env(self, environment_class):
            self.called = True
            self.calls += 1

    lookup_module = ModLookupModule()
    lookup_module._loader = ModLoader()
    lookup_module._templar = ModTemplar()

    assert lookup_module.called is False
    assert lookup_module.calls == 0

# Generated at 2022-06-22 14:27:29.736328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lkm = LookupModule()
    lkm.set_loader(FakeLoader())
    lkm.set_templar(FakeTemplar())
    lkm.set_options(direct={'dirs': ['/dir1', '/dir2'], 'template_vars': {'foo': 'bar'}, 'convert_data': True, 'jinja2_native': True})
    terms = ['/dir1/templates/file.j2', '/dir2/templates/file.j2', 'templates/file.j2']
    variables = {'ansible_search_path': ['/dirA', '/dirB', '/dirC'],
                 'template_path': '/dir1/templates/file.j2',
                 'template_mtime': 1234567890}


# Generated at 2022-06-22 14:27:37.812496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Tests for ansible.plugins.lookup.template.LookupModule._lookup_plugin.run."""
    # pylint: disable=protected-access
    # simple unit test with basic template
    lookup_plugin = LookupModule()
    text = """Hi {{var}}
Hello world
"""
    template_file = '/tmp/test.j2'
    with open(template_file, 'w') as f:
        f.write(text)
    terms = [template_file]
    variables = {}
    r = lookup_plugin.run(terms=terms, variables=variables)
    assert r == ["Hi \nHello world"]
    terms = [template_file]
    variables = {'var': 'everyone'}
    r = lookup_plugin.run(terms=terms, variables=variables)

# Generated at 2022-06-22 14:28:16.249860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(False)

# Generated at 2022-06-22 14:28:23.967049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test data
    module_name = 'test'
    class LookupMock:
        def __init__(self, loader, templar, **kwargs):
            self._loader = loader
            self._templar = templar
            self._options = kwargs
    class ModulesMock:
        def get_module_path(self, module_name):
            return module_name
    class HostVarsMock:
        def __init__(self, ansible_env):
            self.ansible_env = ansible_env
        def __getitem__(self, item):
            return self.ansible_env
    class LoaderMock:
        def get_basedir(self):
            return 'basedir'

# Generated at 2022-06-22 14:28:36.214363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.lookup.template import LookupModule, AnsibleEnvironment

    lookup_instance = LookupModule()

    class MockVarsModule:
        def __init__(self):
            self.vars = {"foo": "bar"}

    # Test that calling run, with a template file, returns the correct content with Jinja2
    # test that Jinja2 escapes the backslashes by default
    vars_mock = MockVarsModule()
    result = (lookup_instance.run(["test.j2"], vars_mock, _loader=MockLoader(), _templar=MockTemplar())[0])
    assert result == 'test: bar'

    # Test that calling run, with a template file, returns the correct content with Jinja2
    # test that Jinja2 does not

# Generated at 2022-06-22 14:28:36.873055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-22 14:28:49.970365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    b_template_data = b'{{ lookup("foo") }}'
    lookupfile = "./some_template.j2"

    # Return True when file exists
    def mock_find_file_in_search_path(variables, directory, filename):
        return lookupfile

    # Return the existing file content
    def mock_get_file_contents(file_name):
        return b_template_data, True

    # Return the file name
    def mock_get_filename():
        return lookupfile

    # Return the file name
    def mock_template(template_data, preserve_trailing_newlines, convert_data):
        return template_data

    # Return the variables
    def mock_get_available_variables(variables):
        return variables

    # Return the file name

# Generated at 2022-06-22 14:28:55.223798
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    i = LookupModule()
    terms = ["./some_template.j2"]
    variables = {
        'ansible_search_path': [
            os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins')),
            '.'
        ],
        'template_var': 'template_var_value'
    }

    results = i.run(terms, variables)
    # content of template file: "template_var_value"
    assert results[0] == "template_var_value"

# Generated at 2022-06-22 14:29:05.373132
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.cli import CLI
    import ansible.constants as C
    from io import StringIO
    import sys

    # Prepare test object
    terms = [u'../../test_files/test_file_lookup.txt']
    options = dict()
    loader = DataLoader()
    display.verbosity = 4
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Run the method

# Generated at 2022-06-22 14:29:12.146548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = {}
    play_context = PlayContext()
    play = Play()

    lookup = LookupModule(loader=loader, variable_manager=variable_manager, play_context=play_context, play=play)

    template_vars = {
        'name': 'Val'
    }

    template_contents = """
Hello World from {{ name }}
"""

    with open('/tmp/test', 'w') as f:
        f.write(template_contents)


# Generated at 2022-06-22 14:29:23.260340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    # Set return values of module_utils methods
    def _get_file_contents(path):
        lookupfile = path
        return (os.urandom(1000), True)

    # Set return value of module method
    def find_file_in_search_path(variables, path, term):
        return os.path.join(os.path.dirname(os.path.realpath(__file__)), term)

    # Set return value of get_option method
    def set_options(self, var_options=None, direct=None):
        self.get_option = lambda option: True

    # Set return values of templar methods
    def _get_template_paths(self):
        if USE_JINJA2_NATIVE:
            return None
        else:
            return []

# Generated at 2022-06-22 14:29:26.719676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test with invalid file path
    res = lookup.run(["./invalid_path"], {})
    assert res[0] == "./invalid_path"

# Generated at 2022-06-22 14:30:18.421235
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a object of LookupModule
    obj = LookupModule()
    # create a object of AnsibleOptions
    opt_obj = obj._options
    # create a object of AnsibleVars

# Generated at 2022-06-22 14:30:30.976657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class TestCallback(CallbackBase):
        """A test callback plugin used for capturing the result of executing a task."""
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.host_ok = {}
            self.host_unreachable = {}

# Generated at 2022-06-22 14:30:43.788147
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.facts.system.distribution import Distribution
    distro = Distribution()
    distro.id = 'Fedora'
    distro.version_number = 25

    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.system import distro

    display = Display()
    lookup_template_vars = {'var1': 'test'}
    comment_start_string = '~~'
    comment_end_string = '~~'

# Generated at 2022-06-22 14:30:57.170403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that it raises an error on missing file
    # This is a bit hard because we want to actually call the method
    # but don't want to load/parse the YAML files.
    look = LookupModule()
    templar = look._templar

    # Set up a suitable environment
    look._loader = DictDataLoader({
        'roles/foo/templates/bar.j2': 'test'
    })
    variables = dict(
        ansible_search_path=['roles/foo'],
    )
    searchpath = [variables['ansible_search_path'][0], '.']
    templar.available_variables = variables
    templar.searchpath = searchpath

    f = lambda terms: look.run(terms, variables)

    assert f([]) == []
   

# Generated at 2022-06-22 14:31:10.040773
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.set_loader(LookupBase._loader)

    file_result = lookup_module.run(["./some_template.j2"], {}, _is_loop=False)[0]
    assert file_result == 'Hello World'

    file_result = lookup_module.run(["./some_template.j2"], {}, variable_start_string='[%', variable_end_string='%]', _is_loop=False)[0]
    assert file_result == 'Hello World'

    file_result = lookup_module.run(["./some_template.j2"], {}, comment_start_string='[#', comment_end_string='#]', _is_loop=False)[0]
    assert file_result == 'Hello World'

    # Assert that it raises Ansible

# Generated at 2022-06-22 14:31:22.592826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Example taken from https://docs.ansible.com/ansible/latest/plugins/lookup/template.html#example-template-lookup-of-a-list-of-files
    result = LookupModule().run(
        terms=['../hello.j2', '../bye.j2'],
        variables={
            'key1': 'value1'
        },
        convert_data=True,
        jinja2_native=False,
        variable_start_string='[[',
        variable_end_string=']]',
        comment_start_string='[=',
        comment_end_string='=]',
        template_vars={
            'key2': 'value2'
        }
    )

# Generated at 2022-06-22 14:31:30.014834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils import context_objects as co
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import os
    import sys

    if not C.DEFAULT_LOAD_CALLBACK_PLUGINS:
        pytest.skip("C.DEFAULT_LOAD_CALLBACK_PLUGINS is not set")
    if not C.DEFAULT_LOAD_PLUGINS:
        pytest.skip("C.DEFAULT_LOAD_PLUGINS is not set")

    # get local

# Generated at 2022-06-22 14:31:40.799371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.manager import VariableManager

    terms = ['./some_template.j2']
    variables = {}
    my_loader = DictDataLoader({'./some_template.j2': '{{a}}', './some_template2.j2': '{{a}}'})
    lookup_base = LookupBase()
    lookup_base._loader = my_loader
    my_vault = VaultLib(None, None)
    templar = Templar(my_vault)
    var_manager = VariableManager()
    var_manager.extra_vars = {'a': 'b'}
    templar._available_variables = var_manager.get

# Generated at 2022-06-22 14:31:50.855105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of a class
    lm = LookupModule()

    # create an instance of a class
    display = Display()
    run_args = ['file', 'dict', 'debug', 'convert_data', 'display', 'variable_start_string', 'variable_end_string', 'comment_start_string', 'comment_end_string']

    def run(terms, variables, **kwargs):
        kwargs['display'] = display
        self = lm
        self.set_options(var_options=variables, direct=kwargs)
        convert_data_p = self.get_option('convert_data')
        lookup_template_vars = self.get_option('template_vars')
        jinja2_native = self.get_option('jinja2_native')
        variable_start_

# Generated at 2022-06-22 14:32:02.230977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test LookupModule.run() method.

    See RHBZ#1705634, RHBZ#1718153
    """
    import sys
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    try:
        import jinja2
    except ImportError:
        pytest.skip('jinja2 is not installed')

    # Prepare the environment
    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variables.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variables)

    # Export a variable for the template
    variables