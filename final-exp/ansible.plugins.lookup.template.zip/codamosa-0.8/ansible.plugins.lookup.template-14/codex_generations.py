

# Generated at 2022-06-22 14:22:35.198595
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six.moves import StringIO
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    class DummyVarsModule:

        def __init__(self):
            self.params = None

        def fail_json(self, **kwargs):
            raise Exception('fail_json: %s' % kwargs)

    class MockTemplar:

        def __init__(self):
            self.env = None
            self.use_native = False
            self.parent = None

        def set_available_variables(self, variables):
            if variables.get('ansible_search_path'):
                searchpath = variables['ansible_search_path']

# Generated at 2022-06-22 14:22:40.710768
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test of the LookupModule class, method run

    obj = LookupModule()
    terms = [
        './some_template.j2'
    ]
    variables = {
        'some_var': 'some_value'
    }
    obj.run(terms, variables, convert_data=True)

    obj.run(terms, variables, convert_data=True,
            variable_start_string='[%',
            variable_end_string='%]')

    obj.run(terms, variables, convert_data=True,
            comment_start_string='[#',
            comment_end_string='#]')

# Generated at 2022-06-22 14:22:52.841455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-22 14:23:06.809011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    if sys.hexversion < 0x2060000:
        return

    # In Python 2.6 and earlier, to run tests we must execute the module containing the test
    # as __main__. In Python 2.7 and later, the test module must be imported by a higher-level
    # module.

    # Import the modules containing the 'lookup' plugin and the 'template' lookup function.
    import ansible.plugins.lookup.template

    # Import the 'unit test' library
    import unittest

    # Since the 'lookup' plugins are in a directory (subdirectory) named 'lookup_plugins', in
    # order to load the 'template' lookup function, the 'ansible' directory containing the
    # 'plugins' directory must be on the module search path.
    # Don't put the 'ansible' directory on the search

# Generated at 2022-06-22 14:23:18.839006
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['test_file']

    # We need to mock some objects
    class Loader():
        def get_basedir(self, path):
            return 'path'
        def _get_file_contents(self, path):
            return 'template_data', True

    class Templar():
        def copy_with_new_env(self, environment_class=None):
            class Templar_obj():
                def set_temporary_context(self, variable_start_string=None, variable_end_string=None,
                                          comment_start_string=None, comment_end_string=None,
                                          available_variables=None, searchpath=None):
                    return Templar_obj()

# Generated at 2022-06-22 14:23:26.221101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([
        ''.join([
            '{{ ',
            'ansible_managed',
            '| ',
            'comment',
            ' }}',
        ]),
    ], {
        'ansible_managed': 'This file is managed by Ansible.',
    },)

    assert [
        ''.join([
            '# This file is managed by Ansible.',
        ]),
    ] == result

# Generated at 2022-06-22 14:23:35.166965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = [
        """
        # comment
        [targets]
        # comment
        localhost

        [dbservers]
        # comment
        db0 db1 db2

        [webservers]
        # comment
        web1 web2
        """,
        """
        # comment
        [targets]
        # comment
        localhost

        [dbservers]
        # comment
        db0 db1 db2

        [webservers]
        # comment
        web1 web2
        """,
    ]

    terms = [
        "./_test_templates/ini.j2",
        "./_test_templates/ini_comment_strings.j2",
    ]

    # Check if method run of class LookupModule returns results as expected

# Generated at 2022-06-22 14:23:43.496063
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    result = lookup.run(terms=['/tmp/test.j2'], variables={'name': 'bob'})

    # If a variable is not in template file, Jinja2 returns a empty string
    assert result == ['Hello bob']

    result = lookup.run(terms=['/tmp/wrong.j2'], variables={'name': 'bob'})
    assert result == []

    # Jinja2 native is not set
    assert USE_JINJA2_NATIVE == False


# Generated at 2022-06-22 14:23:55.242030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    if sys.version_info[0] == 2:
        from ansible.compat.tests import unittest
    else:
        import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            # Set up vault secret
            secret = "some_not_so_secret_secret"
            vault_password = VaultLib(password=secret).encrypt("my super secret data")

            # Ansible config
            loader = DataLoader()

# Generated at 2022-06-22 14:24:05.840294
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # define input parameters                                                                                                                                                                                                                                              
    terms = ['./some_template.j2', './some_template1.j2']
    variables = {'hostvars': {'localhost': {'ansible_facts': {'os_family': 'RedHat'}}}}
    parameters = {'host_list': 'test_hosts'}
    display.verbosity = 4

    # set up test object
    lookup_module = LookupModule()
    lookup_module._templar = Templar(loader=DataLoader(), variables=variables)
    lookup_module._loader = DataLoader()

    # run tested method
    lookup_module.run(terms, variables, parameters)


# Generated at 2022-06-22 14:24:18.031323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'template_vars': {'test_var': 'test_value'}, 'convert_data': False})
    lookup_plugin._templar = TO(loader=DictDataLoader())
    result = lookup_plugin.run([
        "lookup_fixtures/test_template_01.j2",
        "lookup_fixtures/test_template_02.j2",
    ])
    assert result[0] == "Test template 01\n"
    assert result[1] == "Test template 02\n"

# Generated at 2022-06-22 14:24:29.756317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.module_utils.six.moves import builtins

    class FakeTemplar:
        def set_temporary_context(self, variable_start_string, variable_end_string,
                                  comment_start_string, comment_end_string, available_variables, searchpath):
            return None

        def template(self, template_data, preserve_trailing_newlines, convert_data):
            return 'template'

        def copy_with_new_env(self, environment_class):
            return self

    class FakeLoader:
        @staticmethod
        def _get_file_contents(lookupfile):
            return b'file contents', True

    class FakeVars:
        def __init__(self):
            self.ansible_search_path = []


# Generated at 2022-06-22 14:24:39.721819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inputfile = 'test_jinja_vars.yml'
    input_string = b'{{ testvars.ansible_managed }}.{{ jinja_comment_vars[0] }}.{{ testvars.not_a_comment_var }}'
    expected_output = 'Ansible managed: Do not edit this file manually! #123.abc.def'
    module = LookupModule()
    output = module.run([inputfile], {'lookup_file': inputfile, 'lookup_file_contents': input_string})
    assert output[0] == expected_output


# Generated at 2022-06-22 14:24:48.341103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = dict(
        ansible_search_path=["/usr/local/tmp", "/etc/foo", "/tmp", "/etc/bar"],
        some_variable_foo='bar', another_variable_bar='foo',
        convert_data=True, template_vars=dict(template_var_foo='bar'),
        variable_start_string='[%', variable_end_string='%]',
        jinja2_native=True
    )
    fpath = './test_lookup_template.j2'
    terms = [fpath]

# Generated at 2022-06-22 14:24:59.033791
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test class variable __metaclass__ with type
    assert(hasattr(LookupModule, '__metaclass__') and type(LookupModule.__metaclass__) is type)

    # test class variable run with type
    assert(hasattr(LookupModule.run, 'im_class') and type(LookupModule.run.im_class) is type)

    # test class variable run without arguments
    try:
        LookupModule.run()
    except Exception as exp:
        assert(type(exp) is TypeError)
    else:
        raise Exception('ExpectedTypeError not raised')

    # test class variable run with arguments
    try:
        LookupModule.run(arg1=1, arg2=2)
    except Exception as exp:
        assert(type(exp) is TypeError)

# Generated at 2022-06-22 14:25:07.048596
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # A fake environment variable "ANSIBLE_JINJA2_NATIVE" is defined in order to test
    # the case where jinja2_native lookup option is False while jinja2_native global variable
    # is True.
    os.environ["ANSIBLE_JINJA2_NATIVE"] = "yes"

    # Setup a lookup object to test
    lookup_obj = LookupModule()

    # Setup the input parameters required by lookup to test its run method

# Generated at 2022-06-22 14:25:09.384192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader   # noqa: F401
    from ansible.vars import VariableManager   # noqa: F401
    from ansible.inventory import Inventory   # noqa: F401
    from ansible.playbook.play import Play   # noqa: F401

    lookup_module = LookupModule()

# Generated at 2022-06-22 14:25:18.308755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # AnsibleError = type("AnsibleError", (Exception,), dict())
    # os.path.exists = lambda x: True

    lookup = LookupModule()
    # Test exception
    # try:
    #     lookup.run("/path/to/file", {})
    # except AnsibleError as e:
    #     assert "could not be found for the lookup" in to_text(e)

    # Test return
    # lookup._loader._get_file_contents = lambda x: ({}, True)
    # res = lookup.run("/path/to/file", {})
    # assert res == []
    pass

# Generated at 2022-06-22 14:25:22.564171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(direct={'variable_start_string': '{{', 'variable_end_string': '}}'})
    assert lookup.run(['no_spaces'], {'hostname': 'host'}) == ['host']

# Generated at 2022-06-22 14:25:34.716856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.template import template as template_module

    # Setup
    lookup_module = LookupModule()
    # The string 'lookup_module' is the filename of the file containing the class LookupModule
    lookup_module._templar = template_module.Templar(loader=template_module.AnsibleLoader(None),
                                                     variables={'gid': 1000, 'group': 'ansible'})
    # Usage of _templar:
    # _templar is a placeholder for a class that is defined in template.py and that is used by the lookup plugin.
    # This class is called Templar, and the placeholder stores an object of this class. The object has a method
    # called template, which is called in the method run. In this test, it is done in the assert.
    # The Templar object

# Generated at 2022-06-22 14:25:54.920393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from ansible.template import AnsibleEnvironment, USE_JINJA2_NATIVE
    import os
    import tempfile
    display = Display()
    test_lookup = LookupModule()
    test_env = AnsibleEnvironment(loader=None, variables=None, trim_blocks=True)
    test_vars = {'foo': 'FOO', 'bar': 'BAR'}

    test_dir = tempfile.mkdtemp()
    test_vars_file = os.path.join(test_dir, 'vars')
    with open(test_vars_file, 'w') as f:
        f.write('{{ foo }} and {{ bar }}')
    test_lookup._templar = test_env

# Generated at 2022-06-22 14:26:05.999159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # testcase: test_LookupModule_run_unsupported_templar_native_type
    # test
    test_module = LookupModule()
    test_module._templar = AnsibleEnvironment(loader=None, variables={})
    test_module.set_options(var_options={}, direct={})
    if USE_JINJA2_NATIVE:
        # has to raise exception
        try:
            test_module.run(terms=[], variables={})
        except AnsibleError as e:
            assert "Error while templating with jinja2_native enabled: The templar native type is not supported" in to_text(e)
        else:
            assert False
    else:
        # should not raise exception
        test_module.run(terms=[], variables={})

# Generated at 2022-06-22 14:26:16.927280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We use a real lookup class to implement the mock.
    def mock_get_option(self, option):
        return {
            'variable_start_string': '[[',
            'variable_end_string': ']]',
        }.get(option, None)


    def mock_copy_with_new_env(self, environment_class):
        return self


    def mock_set_temporary_context(self,
                                   available_variables,
                                   variable_start_string,
                                   variable_end_string,
                                   comment_start_string,
                                   comment_end_string,
                                   searchpath):
        self.available_variables = available_variables
        self.variable_start_string = variable_start_string
        self.variable_end_string = variable_end_string
        self

# Generated at 2022-06-22 14:26:23.644270
# Unit test for method run of class LookupModule

# Generated at 2022-06-22 14:26:34.557077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class OptionsModule(object):
        def __init__(self, options):
            self.options = options
        def get_option(self, option_name):
            return self.options[option_name]

    class VarManager(object):
        def __init__(self, get_vars):
            self._get_vars = get_vars
        def get_vars(self, loader=None, path=None, entities=None, include_hostvars=False, include_delegate_to=False):
            return self._get_vars()
    class Loader(object):
        def __init__(self, _get_file_contents):
            self._get_file_

# Generated at 2022-06-22 14:26:45.887412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TEST CASE 1:
    #
    # If a file is not found in the lookup, an AnsibleError is raised
    #
    # Answer:
    # Yes, it is

    # set up mocks
    mock_LModule_obj = LookupModule()
    mock_LModule_obj.set_options = lambda var_options, direct: None
    mock_LModule_obj.get_option = lambda name: ''
    mock_LModule_obj.find_file_in_search_path = lambda variables, search_path, file_name: ''
    mock_LModule_obj._loader = type('obj', (object,), {'_get_file_contents': lambda a, b: ('', '')})

# Generated at 2022-06-22 14:26:57.936515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.template.safe_eval import safe_eval

    class FakeVaultLib(VaultLib):
        def decrypt(self, blob):
            class FakeBlob(object):
                def __init__(self, _blob):
                    self._blob = _blob

                def get_decrypted_bytes(self):
                    return self._blob
            return FakeBlob(blob)

        def encrypt(self, _blob):
            return _blob

    class FakeVAultEditor(VaultEditor):
        def __init__(self, _blob, _vault_password=None):
            self._blob = _blob
            self._vault_password = _vault_

# Generated at 2022-06-22 14:27:04.212866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LUM = LookupModule()

    terms = ["path/to/test.j2"]
    variables = {"test_var": "test_val"}
    options = {"template_vars": {"test_tvar": "test_tval"}}

    class TM:
        def get_option(self, option):
            return options[option]

    tm = TM()
    LUM._templar = tm
    LUM.set_options(var_options=variables, direct=options)
    LUM.run(terms, variables, **options)


# Generated at 2022-06-22 14:27:16.531713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['./test_template.j2']
    terms2 = ['./test_template.j2', './test_template2.j2']
    terms_path = ['./path/to/test_template.j2']
    terms_env = ['/tmp/template']
    env_vars = {
        'ANSIBLE_TEMPLATE_INCLUDE_TEMPLATE': './env_vars_template.j2',
        'ANSIBLE_TEMPLATE_OVERRIDE': './test_template_override.j2'
    }
    temp_env = ['/tmp/template']

# Generated at 2022-06-22 14:27:26.773137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Jinja2 native types are disabled, normal lookup
    def test_LookupModule_run_disabled():
        # Setup some arguments for the test
        terms=['tests/lookup/templates/test_template']

# Generated at 2022-06-22 14:27:56.775520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import unittest

    class TestLookupModule_run(unittest.TestCase):

        def setUp(self):
            class MockVars(object):
                pass

            class MockTemplar(object):
                def __init__(self):
                    self.template_data = None

                def template(self, template_data, preserve_trailing_newlines=False, convert_bare=True,
                             fail_on_undefined=True, escape_backslashes=False, disable_lookups=False,
                             available_variables=None, searchpath=None):
                    self.template_data = template_data
                    return template_data

            self.variables = MockVars()


# Generated at 2022-06-22 14:28:01.352944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['test-template-file.j2']
    variables = {}
    obj = LookupModule()
    res = obj.run(terms, variables)
    assert(res[0] == '\nHello World\n')

# Generated at 2022-06-22 14:28:09.971460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import pytest

    lookup = lookup_loader.get('template')

    basedir = os.path.join(os.path.dirname(__file__), '../../')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variables = VariableManager(loader=loader, inventory=inventory)

    this_dir = os.path.dirname(__file__)
    lookupfile = os.path.join(this_dir, './templates/j2_t1.j2')

# Generated at 2022-06-22 14:28:21.800827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing the default behavior of the run method with both convert_data=True and convert_data=False
    # The behavior of the run method is not modified by the global setting of jinja2_native (which is False)
    # For convert_data=False and convert_data=True, the lookup module can be used both with a value set
    # in template_vars and with no value set in template_vars

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template.vars import AnsibleVars
    from ansible.template import Templar
    from ansible.plugins import lookup_loader

    display = Display()
    display.verbosity = 5


# Generated at 2022-06-22 14:28:34.475597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    def test_file_lookup(loader, template, variables, **kwargs):
        lookup = LookupModule()
        lookup.set_loader(loader)

        return lookup.run(template, variables, **kwargs)[0]

    def run_test(loader, template, variables, expected, **kwargs):
        actual = test_file_lookup(loader, template, variables, **kwargs)

        assert actual == expected, \
            "test_template_file_lookup failed! Expected: %s, Actual: %s" % (expected, actual)

    loader = DataLoader()

    # test comment behavior
    run_test(loader, "comment.j2", dict(inputs=dict(a="A")), "{{ inputs['a'] }}")

    #

# Generated at 2022-06-22 14:28:35.757631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "TODO"

# Generated at 2022-06-22 14:28:48.947798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import jinja2
    # We don't have a lookup plugin 'template', but it is ok because we are going to mock it.
    sys.modules['ansible.plugins.lookup.template'] = sys.modules[__name__]
    sys.modules['ansible.module_utils.template'] = sys.modules[__name__]

    # As it is not the real lookup plugin, and thus does not have the
    # _templar attribute, we need to mock it.
    # As _templar is a Jinja2 environment, it can be initialized safely
    templar = jinja2.Environment()

    lookup = LookupModule()
    # The run method expects a LookupBase object as parameter
    # We actually don't need it, so replace it with a mock
    lookup.set_loader(None)


# Generated at 2022-06-22 14:28:51.786062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_t = 'input test'
    expected = 'input test'
    output = LookupModule().run(input_t, None)
    assert output == expected


# Generated at 2022-06-22 14:29:03.521407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()

    data = LookupModule.run(['test_data.yml'], {}, _loader=fake_loader, _templar=fake_templar, _find_file_in_search_path=fake_find_file_in_search_path)
    assert data == ['test']

    data = LookupModule.run(['test_data.yml'], {'ansible_search_path': ['/tmp']}, _loader=fake_loader, _templar=fake_templar, _find_file_in_search_path=fake_find_file_in_search_path)
    assert data == ['test']


# Generated at 2022-06-22 14:29:13.291978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.quiet(True)
    lu = LookupModule()
    assert lu.run([], dict()) == []
    assert ''.join(lu.run(['tests/lookup_plugins/test.template'], dict())) == "from tests/lookup_plugins\nfrom tests/lookup_plugins\n"
    assert ''.join(lu.run(['tests/lookup_plugins/test.template'], dict(var='hi'))) == "hi\nhi\nfrom tests/lookup_plugins\n"
    assert ''.join(lu.run(['tests/lookup_plugins/test.template'], dict(env='from env'))) == "from env\nfrom env\nfrom tests/lookup_plugins\n"

# Generated at 2022-06-22 14:30:01.109350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import AnsibleEnvironment

    templar = AnsibleEnvironment(loader=None, variable_start_string='[%', variable_end_string='%]').get_template_class()()

    result = LookupModule(loader=None, templar=templar).run(
        terms=['test/templates/test.j2'],
        variables=dict(n1=1, n2=2, s1='hello', s2='world'),
        jinja2_native=False,
    )

    assert result == ['Hello world!', 'Hello world!', 'Hello world!']



# Generated at 2022-06-22 14:30:06.797215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    lookup = LookupModule()

    run_dir = os.path.dirname(__file__)
    testfile = os.path.join(run_dir, 'test.j2')

    expected = 'test string\n'

    results = lookup.run([testfile], {}, convert_data=True)
    assert results[0] == expected

# Generated at 2022-06-22 14:30:18.624069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # term = './my_template' => lookupfile = ./my_template
    # searchpath = ['/home/user/.ansible']
    # => lookupfile = /home/user/.ansible/templates/my_template
    lookup_obj = LookupModule()
    terms = ['./my_template']

# Generated at 2022-06-22 14:30:21.225118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass

# Generated at 2022-06-22 14:30:32.683610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    assert pytest.raises(AnsibleError, LookupModule, None, None, "", {}, {}, {}, {}).run(["not_existing"], {}) == []
    assert LookupModule(None, None, "", {}, {}, {}, {}).run(["template_lookup_plugin/test.j2"], {}) == ["foo\nbar\nbaz\n"]
    assert LookupModule(None, None, "", {}, {}, {}, {}).run(["template_lookup_plugin/test_vars.j2"], {"foo": "bar"}) == ["bar\n"]
    assert LookupModule(None, None, "", {}, {}, {}, {}).run(["template_lookup_plugin/test_vars.j2"], {"foo": 1}) == ["1\n"]

# Generated at 2022-06-22 14:30:44.681652
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    # Tests if the base class is correctly initialized
    assert(lookup_module != None)

    # Tests if method find_file_in_search_path works as expected
    assert(lookup_module.find_file_in_search_path({}, 'templates', './some_template.j2') == './some_template.j2')

    class AnsibleFileLoader_SUT():

        def __init__(self):
            self.file_contents = ''

        def _get_file_contents(self, path):
            return (self.file_contents, 'show_data')

    class AnsibleTemplar_SU():

        def __init__(self):
            self.context = {}
            self.environment_class = None


# Generated at 2022-06-22 14:30:48.220705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # below should not raise an exception
    lm.run(terms=["../lib/ansible/playbook/templates/j2_env.j2"], variables={})

# Generated at 2022-06-22 14:30:59.616437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms=[{
        '_terms': 'dictionary.j2',
        'lookup_template_vars': {
            'name': 'John',
            'address': 'Yours'
        },
        'variable_start_string': '[[',
        'variable_end_string': ']]',
        'comment_start_string': '[',
        'comment_end_string': ']',
        '_ansible_vars': {
            'ansible_search_path': ['/etc/ansible/templates']
        },
        '_ansible_tmpdir': '/tmp'
    }]
    variables={
        'searchpath': ['/etc/ansible/templates']
    }


# Generated at 2022-06-22 14:31:11.461758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestOptions(object):
        def __init__(self):
            self._options = None
        def get_option(self, option):
            return self._options.get(option)
        def set_options(self, value=None, direct=None):
            if direct:
                self._options = direct
            elif value:
                self._options = value
            else:
                self._options = None
        def _templar(self):
            return None

    class TestDisplay(object):
        def __init__(self):
            self._messages = []
        def debug(self, msg):
            self._messages.append(msg)

    loader_mock = Mock()
    dummy_file_contents = '{{ lookup_template_var }}'
    loader_mock.get_real_file.return_

# Generated at 2022-06-22 14:31:18.134155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Import modules that are required to run the tests.
    import ansible.plugins.lookup.template
    import ansible.template

    # Create a list of testcases.
    test_cases = [
        {
            "terms": ['https://bitbucket.org/ansible/ansilib/raw/tip/plugins/lookup/template.py'],
            "variables": {"ansible_search_path": ["/etc/ansible/playbooks"]}
        }
    ]

    for i, test_case in enumerate(test_cases):
        lm = ansible.plugins.lookup.template.LookupModule()
        lm.set_options()

        if not test_case["variables"]["ansible_search_path"][0] in ansible.template.__file__:
            result = lm