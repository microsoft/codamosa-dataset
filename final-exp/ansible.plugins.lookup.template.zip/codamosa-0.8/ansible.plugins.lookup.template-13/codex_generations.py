

# Generated at 2022-06-22 14:22:20.240925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    unittest.TestCase.assertEqual(LookupModule.run(terms=['template'], variables='var1', convet_data='data'), 'file path')


# Generated at 2022-06-22 14:22:33.115300
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import iteritems

    from ansible.plugins.loader import lookup_loader

    from ansible.parsing.vault import VaultLib

    vault_keys = {}

    def my_load_file(path, vault_password=None):
        if vault_password is not None:
            path += ".vault"
        with open(path, 'rb') as f:
            data = f.read()
        return data

    def my_get_file_vault_secret(path):
        if vault_keys.get(path, None) is None:
            vault_keys[path] = VaultLib(password_file=path)
        return vault_keys[path]


# Generated at 2022-06-22 14:22:34.150394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No test for LookupModule.run"

# Generated at 2022-06-22 14:22:38.596811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get the class LookupModule
    cls = LookupModule()
    # Mock class AnsibleFileLoader
    AnsiFileLoader = mock.Mock()
    # Set the return value of _get_file_contents
    AnsiFileLoader._get_file_contents.return_value = "Hi, I'm the result of the template"
    # Mock class AnsibleFileLoader
    AnsiOptions = mock.Mock()
    # Set the return value of get_option
    AnsiOptions.get_option.return_value = False
    # Define terms
    terms = ["terms"]
    # Define variables
    variables = dict(v1="v1", v2="v2")
    # Define path
    path = "path"
    # Define searchpath
    searchpath = ["searchpath"]
    # Set path

# Generated at 2022-06-22 14:22:43.393543
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # What follows is a mock object for object loader of class LookupModule which is required by
    # the method run.
    class TestLoader:
        def __init__(self):
            self._basedir = '/'

        def load_from_file(self, filename):
            f = open(filename, 'rb')
            data = f.read()
            f.close()
            return data.decode('utf-8')

        def _get_file_contents(self, filename):
            f = open(filename, 'rb')
            data = f.read()
            f.close()
            return data, True

    # What follows is a mock object for object templar of class LookupModule which is required by
    # the method run.
    class TestTemplar:
        def __init__(self):
            self._available

# Generated at 2022-06-22 14:22:55.819034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a test object
    from ansible.module_utils.six import PY2
    test_obj = LookupModule()
    # Create a test template file
    import tempfile
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write("Hello {{ test_var }}!")
    # Create a test terms list
    terms = [path]
    # Create a test variables dictionary
    variables = dict(
        test_var = "Ansible"
    )
    # Create a test jinja2_native bool
    jinja2_native = True
    # Run the run method
    test_obj.run(terms, variables, jinja2_native=jinja2_native)
    # Test the result

# Generated at 2022-06-22 14:23:04.682821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module=LookupModule()
    lookup_module.run(terms=['php.j2'],
        variables= {'hostvars': {'foo': {'ansible_host': '10.20.0.4', 'ansible_port': '1234'}, 'bar': {'ansible_host': '10.20.0.5'}, 'localhost': {'ansible_host': '127.0.0.1', 'ansible_port': '2121'}}})

test_LookupModule_run()

# Generated at 2022-06-22 14:23:17.348451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with an existing template "./test/test_module_utils.py/test_module_utils.Facts.yaml"
    # test_module_utils.Facts is a class of test_module_utils.py
    lookup_module = LookupModule()
    test_templates = [ "./test/test_module_utils.py/test_module_utils.Facts.yaml" ]
    # Create a objects "template_vars" to pass
    template_vars = {}
    # Create a object "variable" to pass
    test_variable = {}
    test_variable.update(lookup_module.run(test_templates, test_variable))

    # Testing with a non-existing template
    lookup_module = LookupModule()

# Generated at 2022-06-22 14:23:18.891476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: This function is not tested
    pass

# Generated at 2022-06-22 14:23:30.371517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of class LookupModule
    """

    class LoaderMock(object):
        def _get_file_contents(self, name):
            return "{{ item }}", False

    class TemplarMock(object):
        def template(self, data, preserve_trailing_newlines, convert_data, escape_backslashes):
            return data

        def copy_with_new_env(self, environment_class):
            return TemplarMock()

        def set_temporary_context(self, **kwargs):
            return

    class DisplayMock(object):
        def debug(self, msg):
            return

        def vvvv(self, msg):
            return

    class LookupBaseMock(LookupBase):
        def set_options(self, var_options, direct):
            return



# Generated at 2022-06-22 14:23:41.561633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy object to store data for lookup
    test_obj = {
        'ansible_search_path': [],
        'template_host': 'hostname',
        'template_uid': '1000',
        'template_path': '/home/user',
        'template_mtime': '1.0'
    }

    # Dummy string to store data of template file
    data = '{{ lookup_test_obj[host] }} {{ lookup_test_obj[me] }}'

    lm = LookupModule()
    # Return the type of lookup_test_obj
    assert type(lm.run(['test_file'], lookup_test_obj=test_obj)) == list
    # Return the type of lookup_test_obj for each data

# Generated at 2022-06-22 14:23:53.822791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import os

    # Initialise the class LookupModule
    class Options(object):
        def __init__(self, variable_start_string="{{", variable_end_string="}}", jinja2_native=False, convert_data=True):
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string
            self.jinja2_native = jinja2_native
            self.convert_data = convert_data


# Generated at 2022-06-22 14:23:54.375262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-22 14:24:06.093209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    self_tempdir = os.path.dirname(__file__)

# Generated at 2022-06-22 14:24:17.301497
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    lookup_module = LookupModule()
    lookup_module._loader.set_basedir("/my-path_to_playbook/playbooks/")
    lookup_module._templar.basedir = '/my-path_to_playbook/playbooks/'
    lookup_module._templar.template = "template-name"
    lookup_module.set_options()
    lookup_module.run(["var_path"])

    # Test 2
    lookup_module = LookupModule()
    lookup_module._loader.set_basedir("/my-path_to_playbook/playbooks/")
    lookup_module._templar.basedir = '/my-path_to_playbook/playbooks/'
    lookup_module._templar.template = "template-name"
    lookup_

# Generated at 2022-06-22 14:24:29.180974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # check simple YAML data
    terms = ['key1=value1,key2=value2']
    variables = {}
    assert lookup.run(terms, variables, jinja2_native=False, convert_data=True) == [{u'key1': u'value1', u'key2': u'value2'}]
    assert lookup.run(terms, variables, jinja2_native=False, convert_data=False) == [u'key1=value1,key2=value2']

    # check YAML data with nested lists and dict
    terms = ['key1=value1,key2=value2,key3=[value3,value4],key4={key41:value41,key42:value42}']

# Generated at 2022-06-22 14:24:41.557798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    t = LookupModule()
    t.set_options(var_options={'ansible_search_path': ['.']})

    ###########################################################################
    #
    # tests of template_vars=
    #
    ###########################################################################

    terms0 = ['./test_templates/simple.j2']

    lookup_template_vars0 = {'name': 'bob'}


# Generated at 2022-06-22 14:24:49.166554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import mock

    class LookupModuleTestCase(unittest.TestCase):
        """
        Unit Tests for run method of class LookupModule
        """
        def runTest(self):
            terms = ['foo.yml']
            variables = dict()
            variables['template_dir'] = 'dirs'
            lookup_file = 'dirs/foo.yml'
            data = "---\n- hosts: all\n  tasks:\n  - template: src={{ src }} dest={{ dest }}"
            res = "---\n- hosts: all\n  tasks:\n  - template: src={{ src }} dest={{ dest }}"

# Generated at 2022-06-22 14:24:59.352206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_data = {
        'terms': ['/etc/example.yml'],
        'variables': {
            'template_vars': {
                'some_var': 'some value',
            },
            'ansible_search_path': ['/etc', '/usr/local/etc'],
        },
    }
    lookup_plugin = LookupModule()
    lookup_plugin._templar = DummyTemplar()
    lookup_plugin._loader = DummyLoader("""\
# file: /etc/example.yml
# This is a sample file
{% for i in range(1, 4) %}{{ some_var }}\n{% endfor %}\
""")
    expected_result = "some value\nsome value\nsome value\n"

# Generated at 2022-06-22 14:25:07.251737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule._templar = templar()

# Generated at 2022-06-22 14:25:29.501258
# Unit test for method run of class LookupModule

# Generated at 2022-06-22 14:25:37.454201
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.template import LookupModule
    from ansible.template import AnsibleEnvironment
    import ansible
    import pprint

    pl = LookupModule()
    # create AnsibleEnvironment with default jinja2 settings
    env = Environment(
        loader=BaseLoader(),
        trim_blocks=False,
        lstrip_blocks=True,
        keep_trailing_newline=False,
        extensions=None,
        undefined=StrictUndefined,
        finalize=None,
        autoescape=True,
    )
    pl.set_templar(AnsibleEnvironment(loader=BaseLoader(), undefined=StrictUndefined).from_env(env))


# Generated at 2022-06-22 14:25:43.159243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.utils.data import md5s

    lookup_module = LookupModule()
    lookup_module.get_config.return_value = dict()
    lookup_module._templar = DummyTemplar()

    f, fn = tempfile.mkstemp(dir=os.getcwd())
    f = os.fdopen(f, 'w')
    f.write("1")
    f.close()

    ret = lookup_module.run(terms=[fn], variables={'var': 'value'},
                            convert_data=False, lookup_template_vars={},
                            variable_start_string='{{', variable_end_string='}}',
                            comment_start_string='{#', comment_end_string='#}')


# Generated at 2022-06-22 14:25:54.345750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    def getLinesFromFile(filename):
        with open(filename) as f:
            return f.readlines()

    class Options(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    variable_manager = VariableManager()
    loader = DataLoader()

    terms = './test/test_jinja2_template.j2'
    variables = {}

    lm = LookupModule()
    lm.set_options(var_options=variables, direct=options())
    j2_env = Templar(loader=loader, variables=variable_manager)
    lm

# Generated at 2022-06-22 14:25:55.727750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    assert x.run('file', '') == 'file'

# Generated at 2022-06-22 14:26:07.539477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil
    import sys

    # Store a reference to the current module
    current_module = sys.modules[__name__]

    # Store a reference to the current dir
    current_dir = os.path.dirname(__file__)

    # Create a temporary directory to store test files
    tmpdir = tempfile.mkdtemp()

    # Create a file as 'file.txt'
    with open(os.path.join(tmpdir, 'file.txt'), 'wt') as f:
        f.write('{{lookup_var}}')

    # Create a file as 'file.j2'
    with open(os.path.join(tmpdir, 'file.j2'), 'wt') as f:
        f.write('{{lookup_var}}')

    # Create a file

# Generated at 2022-06-22 14:26:17.686999
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a string instead of a list for terms
    terms_string = './some_template.j2'
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule.run(terms_string, {}, {}, [])
    assert "the template file %s could not be found for the lookup" % terms_string in to_text(excinfo.value)

    # Test with a list for terms
    # First, test with a file that does not exist
    terms_list = ['./some_template.j2']
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule.run(terms_list, {}, {}, [])

# Generated at 2022-06-22 14:26:30.211235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.DEBUG = True
    lookup = LookupModule()
    template_dir = os.path.join(os.path.dirname(__file__), 'test_templates')
    assert os.path.exists(template_dir)
    assert os.path.isdir(template_dir)
    os.environ['ANSIBLE_TEMPLATE_DIR'] = template_dir
    lookup._loader = DictDataLoader()
    # Add fake file in DictDataLoader
    lookup._loader._data = {'test_templates/unittest_template.j2': '',
                            'test_templates/unittest_template2.j2': '',
                            'test_templates/unittest_template3.j2': ''}
    lookup._templar = Templar()


# Generated at 2022-06-22 14:26:42.221284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("")
    print("Run unit tests")
    print("")

    basedir = os.path.dirname(__file__)
    basedir = os.path.abspath(os.path.join(basedir, os.path.pardir))


# Generated at 2022-06-22 14:26:53.544404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    templar = DummyTemplar()
    assert lookup.run(terms=['does_not_exist.j2'], variables={}, **{'_templar': templar}) == []
    # test for convert_data being set to False
    templar.results['fake.j2'] = {'mtime': 1111, 'data': '{"test": "{{test_var}}"}'}
    result = lookup.run(terms=['fake.j2'], variables={'test_var': 'test'}, **{'_templar': templar})
    assert result[0] == '{"test": "test"}'
    # test for convert_data being set to True

# Generated at 2022-06-22 14:27:18.352276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockModuleBase:
        def find_file_in_search_path(self, variables, subdir, file_name):
            return lookupfile

        def _get_file_contents(self, lookupfile):
            return b_template_data, True

    class MockTemplar:
        def copy_with_new_env(self, environment_class):
            return templar

        def template(self, template_data, preserve_trailing_newlines, convert_data, escape_backslashes):
            return "returned data"

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string,
                                  comment_end_string, available_variables, searchpath):
            return None

    expected_lookupfile = "./some_template.j2"
   

# Generated at 2022-06-22 14:27:23.531233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    results = lookup.run(terms=['test.j2'], variables={'ansible_search_path': ['.']}, **{'convert_data': True})
    assert results == [to_text('a: hello world\n')]


# Generated at 2022-06-22 14:27:28.331824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    
    lookup_module = LookupModule()
    result_run = lookup_module.run(terms=['base_redhat.j2'], variables='')
    assert result_run == [u'[users]\nadmin  ALL=(ALL)    ALL']

# Generated at 2022-06-22 14:27:36.804067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # ansible-local-sample/facts
    # - ansible/facts
    # - ansible/facts-d
    # - /home/user/ansible/facts
    # - /home/user/ansible-local-sample/facts
    lookup._loader._search_paths = [os.path.abspath('./'), os.path.abspath('.'), os.path.expanduser('/home/user/')]
    lookup._loader.path_finder = lambda x: lookup._loader._search_paths
    lookup._loader._basedir = os.path.abspath('.')

    # ansible-local-sample/templates/test_template.j2
    # - ansible/templates/test_template.j2
    # - ansible/templates/

# Generated at 2022-06-22 14:27:44.946100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .unit_test_runner import test_lookup_module_as_a_class
    from ansible.compat.tests import unittest

    class TestLookupModule(unittest.TestCase):
        def test(self, *args, **kwargs):
            return test_lookup_module_as_a_class(LookupModule, *args, **kwargs)

    return TestLookupModule().test(dict(
        _loader=None,
        _templar=None,
        _loader_class=None,
        _templar_class=None,
    ))

# Generated at 2022-06-22 14:27:52.810363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.dataloader
    import ansible.vars

    templar = ansible.parsing.dataloader.DataLoader(None).load_from_file()
    templar._available_variables = ansible.vars.VariableManager()

    terms = ['test_test_test']
    lookup = LookupModule(templar = templar)
    result = lookup.run(terms = terms, variables = {})
    return result

# Generated at 2022-06-22 14:27:56.968079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_params = {'terms': ['dummy_path'], 'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': '#', 'comment_end_string': '#', 'convert_data': True}
    assert LookupModule(**lookup_params).run() == []


# Generated at 2022-06-22 14:28:08.294190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test data
    lookup_string = "{{ lookup('template', './some_template.j2') }}"
    file_encoding = 'utf-8'
    yaml_data = 'a: 1'
    yaml_data_parsed = {'a': 1}
    yaml_data_native = to_bytes(str({'a': 1}))

    # Create MockTemplar
    mock_templar = ansible_mock.MockTemplar()

    # Create MockVars
    mock_vars = ansible_mock.MockVars()

    # Create MockLoader
    mock_loader = ansible_mock.MockLoader()
    mock_loader._get_file_contents.return_value = (yaml_data, None)

    # Create MockDisplay
    mock_

# Generated at 2022-06-22 14:28:18.294177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ["testdir/test_template.j2"]
    test_vars = dict(
        another_var="Another variable",
        test_var="This is a variable",
        with_underscore="This variable name has underscore",
        ANSIBLE_SEARCH_PATH=[],
    )
    lm = LookupModule()
    result = lm.run(terms=test_terms, variables=test_vars)
    #print(result)
    assert result[0] == "This is a variable with underscore\nAnother variable"

# Generated at 2022-06-22 14:28:30.885598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the code of LookupModule
    lookup = LookupModule()
    fake_loader_obj = LookupBase()
    fake_env_obj = LookupBase()
    lookup._loader = fake_loader_obj
    lookup._templar = fake_env_obj
    lookup._display = Display()

    # _handle_template_path method will call _add_unknown_plugin_path method.
    # _add_unknown_plugin_path method will call _get_plugin_path_filter method.
    # _get_plugin_path_filter method will call _load_plugins method.
    # Therefore, we need to mock _load_plugins method.
    def _loaded_plugins(self, class_name, add_directory, module_path, package_name, plugins, config):
        pass
    lookup._loader._load_plugins = _loaded

# Generated at 2022-06-22 14:29:16.760539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = ["/home/user/game_of_thrones.j2"]

# Generated at 2022-06-22 14:29:28.627529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader

    lm = lookup_loader.get('template')
    lm.set_options(var_options=ImmutableDict())

    # Test normal (single value)
    terms = ['ansible/test/test_lookup_plugins/test_template_value.j2']
    assert lm.run(terms, ImmutableDict()) == [b'{ "var": "int: 1; bool: True; string: string" }\n']

    # Test normal (multiple values)
    terms = ['ansible/test/test_lookup_plugins/test_template_value.j2', 'ansible/test/test_lookup_plugins/test_template_value.j2']
    assert lm

# Generated at 2022-06-22 14:29:39.589749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # This tests the return value of LookupModule.run
  # First, test the templating of a valid file
    file_contents = "# This is the template for a valid file.\n" \
                    "Hello, {{ lookup('Template', 'world') }}!"
    term = "file_for_test"
    terms = [term]
    lookup_template_vars = {'world': 'world'}
    variables = {}

    display = Display()

    lookup = LookupModule()

# Generated at 2022-06-22 14:29:50.624356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(DictDataLoader({
        'tst_lookup_template.j2': b'lookup_result',
        'test_template.j2': b'Hello World',
    }))
    display.verbosity = 2

    # execute the lookup
    try:
        res = lookup.run(['tst_lookup_template.j2'], DictVars(dict()))
    except AnsibleError as e:  # noqa
        raise AssertionError(e)

    assert res == ['lookup_result']

    res = lookup.run(['test_template.j2'], DictVars(dict()))
    assert res == ['Hello World']



# Generated at 2022-06-22 14:30:02.112231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simple test for a lookup where you want to return a string
    # This test does not handle the self.set_options() call for the jinja
    # environment variables. This test does handle the self.set_options() call
    # for the convert_data flag for the jinja environment.

    # The test does not handle the self.get_option() calls.

    # The find_file_in_search_path method is overridden in the test class
    # The load_template method is overridden in the test class
    # The __init__ of the test class sets self._templar to a loaded object
    # The _get_file_contents method is overridden in the test class
    # The set_temporary_context is used to set the lookup_template_vars variable.

    my_vars = dict()
    my_v

# Generated at 2022-06-22 14:30:13.764796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        terms=['template_file.j2'],
        variables={'name': 'Mike', 'server': 'awesome.example.com'},
        convert_data=True,
        jinja2_native=True,
        template_vars={'foo': 'bar'},
    )
    assert ret == [to_bytes('Hello my name is Mike and I am SSHing to awesome.example.com')]

    ret = LookupModule().run(
        terms=['template_file.j2'],
        variables={'name': 'Mike', 'server': 'awesome.example.com'},
        convert_data=False,
        jinja2_native=True,
        template_vars={'foo': 'bar'},
    )

# Generated at 2022-06-22 14:30:23.405573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    res = lookup.run(['./tests/inventory/two_hosts.yaml'], {})

# Generated at 2022-06-22 14:30:34.178090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  ############################################################################
  # Ugly test code based on the current state of the class used to test
  # this method runs as expected.
  #
  # The approach should change when other development will be done around
  # this code.
  ############################################################################
  lookup_module = LookupModule()    
  lookup_module._templar.environment.variable_start_string = '{{'
  lookup_module._templar.environment.variable_end_string = '}}'
  lookup_module._templar.environment.block_start_string = '{%'
  lookup_module._templar.environment.block_end_string = '%}'
  lookup_module._templar.environment.comment_start_string = '{#'
  lookup_module._templar.environment.comment_end_string

# Generated at 2022-06-22 14:30:34.850155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-22 14:30:41.693650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    env = dict(
        ansible_search_path=[os.path.dirname(__file__)]
    )
    vars = dict()
    terms = ['test_template.j2']

    result = lookup.run(terms, vars, variables=env)

    assert result == ['This is a test template.\n']


# Generated at 2022-06-22 14:32:08.541302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import cStringIO as StringIO


# Generated at 2022-06-22 14:32:17.882425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Patch the lookup module in order to avoid actually reading files
    def mock_get_file_contents(self, path):
        return "{% if test == 'some_value' %}OK{% else %}KO{% endif %}\n", None

    mock_loader = LookupBase()
    mock_loader._get_file_contents = mock_get_file_contents

    lookup_module = LookupModule()
    lookup_module._loader = mock_loader

    assert lookup_module.run(terms=['some_template'], variables={'test': 'some_value'}) == ['OK\n']
    assert lookup_module.run(terms=['some_template'], variables={'test': 'other_value'}) == ['KO\n']