

# Generated at 2022-06-22 14:22:31.018602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.errors import AnsibleError
    module = LookupModule()
    # No error is expected as test_template.j2 is a valid template file
    res = module.run([''], {'variable': 'value'},
                     _original_file='',
                     _ansible_check_mode=False,
                     _ansible_debug=False,
                     _ansible_diff=True,
                     _ansible_posix_special_vars=False,
                     _ansible_selinux_special_fs=False,
                     _ansible_supports_check_mode=True,
                     _ansible_verbosity=0)
    assert len(res) == 1
    assert res[0] == 'Hello from template variable value'

    # No error is expected as

# Generated at 2022-06-22 14:22:41.233653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader()
    lookup._templar = lookup.loader.get_shared_jinja2_environment()
    lookup_template_vars = {"yay":"wow"}
    terms = ["dummy"]
    variables = {"ansible_search_path":["tests/unit/modules/utils/data/templates"]}
    options = {
                "_terms": terms,
                "template_vars": lookup_template_vars
              }
    lookup.set_options(var_options=variables, direct=options)
    result = lookup.run(terms, variables)
    assert result[0] == "wow"

# Generated at 2022-06-22 14:22:53.475015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils import context_objects as co
    from ansible.vars import VariableManager

    vm = VariableManager()
    test_loader = co.DataLoader()
    test_templar = co.Templar(loader=test_loader)

    # test with convert_data=False
    test_lookup = LookupModule(loader=test_loader, variable_manager=vm, templar=test_templar)
    assert test_lookup.run(['./templates/test_template.j2'], {}, convert_data=False) == [u'{{ test_var }}']

# Generated at 2022-06-22 14:23:07.017267
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MyModule(object):
        LOOKUP_FILTERS = {
            'test_filter': lambda value: value,
            'test_filter2': lambda value: str(value)
        }

    class MyTemplar(object):
        def template(self, a, preserve_trailing_newlines=False, convert_data=False, escape_backslashes=False):
            return a

    import os
    import shutil

    module = MyModule()
    templar = MyTemplar()


# Generated at 2022-06-22 14:23:18.996125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    module = LookupModule()
    terms = ['1.txt']
    display = Display()
    display.debug = True
    display.verbosity = 4
    my_vars = {}
    my_vars = AnsibleLoader(my_vars, variable_start_string='[', variable_end_string=']').get_single_data()
    my_vars['ansible_debug'] = True
    my_vars['ansible_verbosity'] = 4
    my_vars['my_is_just_a_str'] = AnsibleUnsafeText("my_is_just_a_str")
    lookup_template_vars = {}
    jinja2_

# Generated at 2022-06-22 14:23:30.450835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    path = os.path.dirname(__file__)
    context = {
        'ansible_search_path': [path],
    }

# Generated at 2022-06-22 14:23:42.981087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    search_path_list = ['./files']
    template_vars = dict(template_var1="a", b="bb")
    variable_start_string = '[[ '
    variable_end_string = ' ]]'
    comment_start_string = '{{ '
    comment_end_string = ' }}'
    # Test step #1
    args = {'terms': [], 'variable_start_string': variable_start_string, 'variable_end_string': variable_end_string, 'comment_start_string': comment_start_string, 'comment_end_string': comment_end_string, 'template_vars': template_vars, 'convert_data': False}
    return_value = lookup.run(**args)
    assert return_value == []
    # Test step #

# Generated at 2022-06-22 14:23:54.668149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock out lookup_plugins
    class Mock_loader():
        def _get_file_contents(self, file):
            return (b"data", True)

    # mock out find_file_in_search_path
    class Mock_lookup():
        def find_file_in_search_path(self, variables, subdir, file):
            return file

    class Mock_templar():
        def copy_with_new_env(self, environment_class):
            return self

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables, searchpath):
            return self

        ansible_env = None


# Generated at 2022-06-22 14:24:06.591381
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupModule = LookupModule()

    # Check input term is string
    # Create a file with a string.
    # Check run method retrieves the same string
    terms = "testString"
    variables = {}
    kwargs = {}
    # Create temprary file
    _,tmp_file_name = tempfile.mkstemp()
    file = open(tmp_file_name, 'w')
    file.write(terms)
    file.close()
    # Check run method with just a filename
    lookupModule.runTests = True
    result = lookupModule.run(terms, variables, **kwargs)
    assert terms in result, "run method did not retrieve the string from the file."
    # Check run method with full path to file
    lookupModule.runTests = True

# Generated at 2022-06-22 14:24:17.481592
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.template import LookupModule
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Set necessary directories for playbook lookup
    playbook_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'examples', 'ansible.cfg')
    current_dir = os.getcwd()

    os.chdir(os.path.dirname(playbook_path))

# Generated at 2022-06-22 14:24:32.673159
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = []
    terms.append("./some_template.j2")
    terms.append("./some_template.j2")

    variables = {}
    variables["ansible_search_path"] = ["./"]
    lookup_template_vars = {}
    lookup_template_vars["ansible_eth0"] = {}
    lookup_template_vars["ansible_eth0"]["ipv4"] = {}
    lookup_template_vars["ansible_eth0"]["ipv4"]["address"] = "10.0.0.2"
    lookup_template_vars["ansible_eth0"]["ipv4"]["netmask"] = "255.255.255.0"

# Generated at 2022-06-22 14:24:43.827263
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    class MockAnsibleModule:

        def __init__(self):
            self.params = {'frobnicate': 'id'}

    terms = ['arg1/file1.j2', 'arg2/file2.j2']
    variables = {'foo': 'bar'}
    args = {}
    env = {'TEST_VAR': 't3st'}

    # Act
    self = LookupModule()
    self._templar = MockAnsibleModule()
    result = list(self.run(terms, variables, env=env, **args))

    # Assert
    # Return result
    assert result == ['arg1/file1', 'arg2/file2']


# Generated at 2022-06-22 14:24:56.971086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize fixture
    spec = dict(
        _terms=list,
        convert_data=bool,
        jinja2_native=bool,
        variable_start_string=str,
        variable_end_string=str,
        template_vars=dict,
        comment_start_string=str,
        comment_end_string=str,
    )
    fixture = type('LookupModule', (object,), spec)()

    # Initialize mock objects

# Generated at 2022-06-22 14:25:06.412388
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock class for a loader
    class LookupModule_loader:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def _get_file_contents(self, filename):
            return "", True

    # create a mock class for a templar
    class LookupModule_templar:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string,
                                  comment_end_string, available_variables, searchpath):
            pass


# Generated at 2022-06-22 14:25:15.931077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('template')

    #from ansible.module_utils.template import AnsibleEnvironment
    from ansible.template import AnsibleTemplate
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_text

    assert hasattr(lookup, 'run')
    assert callable(lookup.run)

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    test_module.no_log = True

    test_loader = None

# Generated at 2022-06-22 14:25:21.002085
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from units.mock.loader import DictDataLoader

    display = Display()
    lookup = LookupModule(loader=DictDataLoader({}), display=display)
    result = lookup.run(terms=['test.j2'], variables={'a': 123, 'b': 456})
    assert result == ['123 456']



# Generated at 2022-06-22 14:25:32.984560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

# Generated at 2022-06-22 14:25:42.166447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["./test_lookup_plugins/test_jinja2.j2"], {"a": "1", "b": "2"}, convert_data=True, template_vars={}, jinja2_native=False) == ["{'a': 1, 'b': 2}"]
    assert lookup.run(["./test_lookup_plugins/test_jinja2.j2"], {"a": "1", "b": "2"}, convert_data=False, template_vars={}, jinja2_native=False) == ['\'{"a": "1", "b": "2"}\'']

# Generated at 2022-06-22 14:25:53.803842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader()
    lookup_module._templar.set_environment(environment_class=AnsibleEnvironment)
    lookup_module._templar.environment.variable_start_string = '{/'
    lookup_module._templar.environment.variable_end_string = '/}'
    lookup_module._templar.environment.trim_blocks = True
    lookup_module._templar.environment.lstrip_blocks = True
    lookup_module._templar.environment.comment_start_string = '{#'
    lookup_module._templar.environment.comment_end_string = '#}'
    lookup_module._templar.environment.keep_trailing_newline = True
    lookup_module._templar.environment.native

# Generated at 2022-06-22 14:26:05.109716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for method run of class LookupModule with jinja2_native,
    convert_data, variable_start_string, variable_end_string,
    comment_start_string, comment_end_string both true and false
    """
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.plugins.lookup.template as templatemodule
    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.lookup_module = templatemodule.LookupModule()


# Generated at 2022-06-22 14:26:22.019670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    mylookup = LookupModule()
    mylookup.set_options(var_options={'fakedir': '/home/user/ansible/src/ansible/plugins/lookup',
                                      'fakename': 'template.py'}, direct={})
    template_data = """
{{foo}}
"""
    with open('/home/user/bar.tmp', 'w') as f:
        f.write(template_data)
    searchpath = ['/home/user']
    result = mylookup.run(["bar.tmp"],
                          {"foo": "bar",
                           "ansible_search_path": searchpath,
                           "template_vars": {"foo": "foo", }},
                          )
    assert result[0] == "foo\n"


# Generated at 2022-06-22 14:26:33.550839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar = AnsibleEnvironment()
    b_template_data, show_data = lm._loader._get_file_contents("/home/debian/workspace/ansible-builder/sync/library/template.py")
    template_data = to_text(b_template_data, errors='surrogate_or_strict')
    vars = {}
    vars.update(generate_ansible_template_vars("test.j2", "/home/debian/workspace/ansible-builder/sync/library/template.py"))

# Generated at 2022-06-22 14:26:45.105914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    import pytest

    loader = DictDataLoader({
        'files/nested/test.j2': '{{lookup("env", "HOME")}}/{{foo}}'
    })
    variables = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variables, host_list=[])
    host = inventory.get_host('')  # localhost
    variables.set_host_variable(host, 'foo', 'bar')

# Generated at 2022-06-22 14:26:52.054891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization
    lookup_instance = LookupModule()

    # Input
    terms = './my_template.j2'
    variables = dict()
    options = dict()

    # Result expected
    result_expected = ['abc']

    # Run method run of class LookupModule
    result_returned = lookup_instance.run(terms, variables, **options)

    # Assertion
    assert result_returned == result_expected

# Generated at 2022-06-22 14:27:02.671912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run_test(args, expected, fail=False):
        result = True

        l = LookupModule()
        l.set_loader(DictDataLoader())

        try:
            if fail:
                l.run(args, variables=dict())
            else:
                output = l.run(args, variables=dict())
                assert expected == output
        except AssertionError as e:
            display.display("expected: %s" % pprint.pformat(expected))
            display.display("actual  : %s" % pprint.pformat(e))
            result = False
        finally:
            return result

    test_data = [{
        "args": ["template_test.py"],
        "expected": ["test_data"]
    }]

    # Initialize the test environment

# Generated at 2022-06-22 14:27:03.861419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([], []) == []

# Generated at 2022-06-22 14:27:16.148102
# Unit test for method run of class LookupModule

# Generated at 2022-06-22 14:27:19.472586
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.set_basedir("/var/lib/awx")
    lookup.set_vars({"inventory_file": "hosts_all"})

    result = lookup.run(terms=['test/web.j2'],
                        variables={"inventory_file": "hosts_all"})

    assert result == ['some value']

# Generated at 2022-06-22 14:27:23.101182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test lookup(template)
    # Test calling lookup(template) with a directory
    # Test calling lookup(template) with a nonexistent file
    # Test calling lookup(template) with a nonexistent directory
    pass

# Generated at 2022-06-22 14:27:33.661476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager

    lm = LookupModule()

    lm.set_options(direct={
        'convert_data': False,
        'template_vars': {},
    })

    # helper to encrypt Vault
    def encrypt_vault(text, secret, vault_id='0123456789abc'):
        vl = VaultLib([secret])
        vl.reverse_order = True
        return vl.encrypt(text, vault_id)

    # helper to render Jinja2 templates
    def render_jinja2(text, context):
        env = AnsibleEnvironment(variable_start_string='[%', variable_end_string='%]')

# Generated at 2022-06-22 14:27:48.281350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    terms = [ './some_template.j2' ]
    variables = { 'name': 'John' }
    lookup_base = LookupModule()
    result = lookup_base.run(terms, variables)
    assert result == [ 'Hello, John!' ]

# Generated at 2022-06-22 14:27:57.859512
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Test 1
    #Test with valid template file
    #Expected result:
    #   No error, return a string of 'Hello, World!'
    lookup_module = LookupModule()
    terms = ["hello.j2"]
    variables = {}
    result = lookup_module.run(terms, variables)
    assert isinstance(result[0], str)
    assert result[0] == 'Hello, World!'

    #Test 2
    #Test with invalid file
    #Expected result:
    #   Raise an AnsibleError exception
    lookup_module = LookupModule()
    terms = ["invalid_file.j2"]
    variables = {}
    failed = False
    try:
        lookup_module.run(terms, variables)
    except AnsibleError:
        failed = True
    assert failed

# Generated at 2022-06-22 14:28:04.190614
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    assert lookup_module is not None

    terms = [{"lookup_options": {"first_only": True, "template_vars": {"now": datetime.utcnow()}}}]
    variables = {}
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result is not None

# Generated at 2022-06-22 14:28:10.998069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import ansible.plugins.lookup.template

    ansible.plugins.lookup.template.USE_JINJA2_NATIVE = True

    templar = Templar(loader=DictDataLoader({'roles/role1/templates/main.j2': b'This is a template\n'}))
    lookup_instance = LookupModule(loader=DictDataLoader({}), templar=templar)

    terms = ['roles/role1/templates/main.j2']
    variables = dict(foo='bar', ansible_search_path=['/tmp/roles/roles'])


# Generated at 2022-06-22 14:28:22.326929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Build a lookupplugin to test with
    lookup_plugin = LookupModule()

    # Build a mock loader
    class LoaderModule:
        def _get_file_contents(self, filename):
            return "content from " + filename, True
    loader = LoaderModule()

    # Build a mock templar
    class TemplarModule:
        def __init__(self, environment_class):
            self._environment_class = environment_class
        def copy_with_new_env(self, environment_class):
            return TemplarModule(environment_class)
        def set_temporary_context(self, available_variables, **kwargs):
            return self
        def template(self, template_data, convert_data=False, **kwargs):
            return "template " + template_data

    # Build a mock display

# Generated at 2022-06-22 14:28:34.983103
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a mock class instead of a dict to be able to track how many time the
    # functions are called and what are the args sent.

    class VariablesMockClass:
        def __init__(self):
            self.set_var_called = 0
            self.set_var_args = []
            self.get_called = 0
            self.get_args = []

        def __setitem__(self, key, value):
            self.set_var_called += 1
            self.set_var_args.append((key, value))

        def __getitem__(self, key):
            self.get_called += 1
            self.get_args.append(key)
            return "value"

        def get(self, key, value):
            self.get_called += 1
            self.get_args.append

# Generated at 2022-06-22 14:28:47.113445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = AnsibleEnvironment()
    lookup._loader = DictDataLoader({
        'a/b/c.j2': """
foo
{{ baz.bat }}
bar
{{ baz.bat }}
baz
{{ baz }}
""",
    })
    lookup._loader.set_basedir('a')
    assert lookup.run([
        'c.j2',
    ], {
        'baz':  {'bat': 'moo'},
    }) == [
        """
foo
moo
bar
moo
baz
{'bat': 'moo'}
""",
    ]


# Dummy DataLoader that can load data from a python dict in memory

# Generated at 2022-06-22 14:28:47.805990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for method run of class LookupModule"""
    # TODO
    pass

# Generated at 2022-06-22 14:29:00.336850
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input data
    self = None
    terms = [
        './some_template.j2',
        './some_template2.j2',
    ]
    variables = {
        'ansible_search_path': [
            './search_path_1',
            './search_path_2',
        ],
        'template_vars': {
            'some_var': 'some_val',
        },
        'convert_data': False,
        'jinja2_native': True,
        'variable_end_string': ']]',
        'variable_start_string': '[[',
        'comment_end_string': '##',
        'comment_start_string': '#',
    }

    # Expected result

# Generated at 2022-06-22 14:29:08.419203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the run method of class LookupModule.
    """
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Inventory
    loader = ansible.parsing.dataloader.DataLoader()
    inventory = InventoryManager(loader=loader, variables=VariableManager(), host_list='localhost')

    # Playbook
    playbook_path = 'test/integration/lookup_plugins/template/test_data'
    pbex = PlaybookExecutor(playbooks=[playbook_path],
                            inventory=inventory,
                            loader=loader,
                            variable_manager=VariableManager(),
                            passwords={})

# Generated at 2022-06-22 14:29:42.031326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    res = lookup_module.run([], {}, convert_data=True, template_vars={'test': 'successful'},
                            variable_start_string='[test]', variable_end_string='[/test]')
    assert res == []
    terms = ['test']
    res = lookup_module.run(terms, {}, convert_data=True, template_vars={'test': 'successful'},
                            variable_start_string='[test]', variable_end_string='[/test]')
    assert res == [u'[test]successful[/test]\n']

# Generated at 2022-06-22 14:29:45.778780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.template import template
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    from .test_plugin_lookup import inventory_setup
    from .test_plugin_lookup import test_lookup_plugin_loader_setup
    from .test_plugin_lookup import test_lookup_plugin_setup

    # Set some vauled variables which need to be made available to the
    # template modules
    context.CLIARGS = {'vault_password_files': ['/foo/bar']}
    vault_secret = VaultLib(['/foo/bar'])
    lookup_plugin_setup(vault_secret)
    variables = VariableManager()
    lookup_plugin_loader_setup

# Generated at 2022-06-22 14:29:57.251157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    fake_loader = object()

    # Templar always return whatever is passed to them
    templar = object()

    # The first and last item are added to `vars` by this method
    test_vars = {'foo': 'bar', 'baz': 'qux'}

    # Setup generator for test_vars
    vars_list = []

    for key in test_vars:
        vars_list.append('%s=%s' % (key, test_vars[key]))

    # Add first and last items to vars_list
    vars_list = [','.join(vars_list)] + vars_list + [','.join(vars_list)]

    # Constructor of class LookupBase
    # Match it with the following
    # https://github.

# Generated at 2022-06-22 14:30:09.473936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import AnsibleVars
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager as IM

    terms = ['/etc/group']
    variables = AnsibleVars(all_vars={'gid': '100'})
    templar = Templar(loader=None)
    variables.add_nonpersistent_vars(templar._available_variables)
    inventory = IM([Group('all')], host_list=[Host('127.0.0.1')])
    host = inventory.get_host(inventory.get_host('').name)
    variables.add_host_vars(host)

    lookup = LookupModule()

# Generated at 2022-06-22 14:30:20.519493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        _terms=['lookup_fixtures.template'],
        _is_conditional=False,
        _is_role_meta=False,
        _templar=None,
        _loader=None,
        _task_vars=dict(
            ansible_facts=dict(
                date_time=dict(
                    epoch=dict(
                        foo=1480246953,
                        bar=1480246953
                    )
                )
            )
        ),
        template_vars=dict(
            testvar1='TESTVAR1',
            testvar2='TESTVAR2'
        )
    )
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(**args)

# Generated at 2022-06-22 14:30:31.648557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('template')

    assert lookup.run(['./some_template.j2'], {'tags': ['t1']}) == ['using {{ tags }}']

    lookup = lookup_loader.get('template')

    assert lookup.run(['native.j2'], {'foo': 'bar'},
                      jinja2_native=True, convert_data=False) == [u'bar']

    assert lookup.run(['native.j2'], {'foo': 'bar'}, jinja2_native=False, convert_data=False) == [u'{{ foo }}']

# Generated at 2022-06-22 14:30:44.126838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {}

    # We don't set the inventory to anything, but we still need this to get the
    # data_context to work properly, so we set a fake one, and override it later
    host = Host(name='localhost')
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')

# Generated at 2022-06-22 14:30:45.742893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO: add tests
    pass

# Generated at 2022-06-22 14:30:58.088864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Verify that the templating works
    """

    lookup_module = LookupModule()

    class Env:
        _data = None

    env = Env()

    variables = {
        'foo': 'Hello world',
        'ansible_search_path': [],
        '_ansible_templar': env,
        '_ansible_lookup_plugin': lookup_module,
        '_ansible_no_log': True
    }

    class FakeTerm:
        _data = None
        def __init__(self,file_name):
            self._data = file_name

    file_name = FakeTerm('/home/ansible/temp/test_template.j2')

    class FakeLoader:
        _data = None
        def __init__(self):
            self._data = b

# Generated at 2022-06-22 14:31:11.047193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test the LookupModule.run method"""
    import pytest
    import os.path
    import sys
    # Ansible Galaxy module dir
    galaxy_dir = os.path.dirname(os.path.abspath(__file__))
    # Ansible module project dir
    project_dir = os.path.dirname(galaxy_dir)

    # setup
    lm = LookupModule()
    if sys.version_info >= (3, 0):
        # in Python3, this is new type 'junk'
        assert (type(lm) is not type)
    # set the module options
    # - convert_data=False
    # - template_vars={"var1":"value1","var2":"value2"}
    # - jinja2_native=False
    # - variable_start_string

# Generated at 2022-06-22 14:32:06.280351
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-22 14:32:17.106120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    module = LookupModule()

    def mock_set_options(var_options, direct):
        #
        # Test for different types of module options
        #
        assert isinstance(var_options, dict)
        assert isinstance(direct, dict)

        assert '_uses_shell' in direct

    def mock_get_option(option):
        """
        Mock for the method get_option of class LookupModule
        """
        if option == 'convert_data':
            return True
        if option == 'template_vars':
            return {'a': 1}
        if option == 'jinja2_native':
            return True
        if option == 'variable_start_string':
            return '{{'