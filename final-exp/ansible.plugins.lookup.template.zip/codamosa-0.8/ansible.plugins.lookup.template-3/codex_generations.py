

# Generated at 2022-06-22 14:22:21.889899
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # tests with jinja2_native
    global USE_JINJA2_NATIVE
    USE_JINJA2_NATIVE = True
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.template import NativeJinja2Template

    class MockLoader(object):
        def _get_file_contents(self, lookupfile):
            if lookupfile.endswith('/tmp.j2'):
                return '"""\n{{"{{foo}}} hello {{ world }}"}}\n"""\n'.encode(), True
            elif lookupfile.endswith('/tmp_no.j2'):
                return '"""\n{{"{{foo}}"}} hello {{ world }}\n"""\n'.encode(), True

# Generated at 2022-06-22 14:22:34.301326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    test_vars = {}
    test_terms = ['show_path_1.j2']
    test_options = {
        "convert_data": False,
        "template_vars": {},
        "jinja2_native": False,
        "variable_start_string": '{{',
        "variable_end_string": '}}',
        "_output_prefix": '',
        "comment_start_string": '{#',
        "comment_end_string": '#}',
    }
    test_result = "{{ lookup('template', 'show_path_1.j2') }}"
    assert test_object.run(test_terms, test_vars, **test_options)[0] == test_result

# Generated at 2022-06-22 14:22:41.709110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    lookupModule = LookupModule()
    lookupModule.set_loader(DummyLoader())
    lookupModule.set_environment(DummyEnvironment())
    find_file_in_search_path = lookupModule.find_file_in_search_path
    find_file_in_search_path = lookupModule.find_file_in_search_path
    lookupModule.get_option = lambda opt: None
    os.path.dirname = lambda path: path
    lookupModule.run = lambda terms, variables, **kwargs: [
        {
            "msg": terms[0] + " content"
        }
    ]
    result = lookupModule.run([
        "test.j2"
    ], {
        "template_vars": {}
    })

# Generated at 2022-06-22 14:22:48.825107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    show_data = b'#abc\ndef\nghi\n'
    b_content = b'#abc\n{{ a }}\n{{ b }}\n'
    lookup_template_vars = {
        'a': 'def',
        'b': 'ghi',
    }

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    variable_manager = VariableManager()
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inv_manager)

# Generated at 2022-06-22 14:23:01.974352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with file with standard quotes and double quotes
    result = lookup_module.run([r'../../test/templates/test1.j2'], {}, convert_data=True)
    assert result == ['test_value']

    # Test with file with standard quotes and single quotes
    result = lookup_module.run([r'../../test/templates/test1_singlequotes.j2'], {}, convert_data=True)
    assert result == ['test_value']

    # Test with file with standard quotes and no quotes
    result = lookup_module.run([r'../../test/templates/test1_noquotes.j2'], {}, convert_data=True)
    assert result == ['test_value']

    # Test with file with alternative quotes and double quotes
   

# Generated at 2022-06-22 14:23:13.989611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager


    class Options(object):
        verbosity = 0
        inventory = None
        listhosts = None
        subset = None
        module_paths = None
        extra_vars = ['role_name=common','config_templates_yaml_file=/etc/ansible/templates/templates.yaml']
        forks = 10
        ask_vault_pass = False
        vault_password_files = None
        new_vault_password_file = None
        output_file = None
        tags = 'all'


# Generated at 2022-06-22 14:23:20.378622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    lookup_options = {}
    setattr(lookup_obj, '_templar', None)

    fake_variables = {'foo': 'bar', 'bing': 'bong'}
    #TODO: create file to test and fake loader._get_file_contents()

# Generated at 2022-06-22 14:23:30.329785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # noinspection PyTypeChecker
    lookup_module.run(
        terms=["{{ '123' }}"],
        variables={
            "ansible_search_path": [
                "./test/test_search_path/first",
                 "./test/test_search_path/second"
            ]
        },
        **{
            "convert_data": True,
            "lookup_template_vars": {},
            "jinja2_native": False,
            "variable_start_string": "{{",
            "variable_end_string": "}}",
            "comment_start_string": None,
            "comment_end_string": None
        }
    )

# Generated at 2022-06-22 14:23:42.871179
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    args = dict(
        terms=['/tmp/foo.j2'],
        convert_data=True,
        variable_start_string='[%',
        variable_end_string='%]',
        comment_start_string='[#',
        comment_end_string='#]',
    )

    kwargs = dict(
        _connection=None,
        _loader=None,
        _templar=None,
        _shared_loader_obj=None,
        psr=dict(),
    )

    test_class = LookupModule(**kwargs)

    test_class.set_options(var_options=dict(), direct=args)

    b_template_data = to_bytes("{{ test_var }}", errors='surrogate_or_strict')

# Generated at 2022-06-22 14:23:45.174797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add unit tests, this was copied from the old ansible-1.x code

    assert False

# Generated at 2022-06-22 14:24:03.123254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # creating MockTemplar to be used for testing
    class MockTemplar:
        # method to create mock self.env
        def _create_env(self):
            # creating class for self.env
            class SelfEnv:
                # creating method for self.env.globals
                def get(self):
                    return {}
                # creating method for self.env.loader
                def get_loader(self):
                    class MockLoader:
                        # creating method for self.env.loader.searchpath
                        def get_searchpath(self):
                            return []
                    # returning MockLoader object
                    return MockLoader()
            # returning SelfEnv object
            return SelfEnv()
        # method to create mock self.env.get_template

# Generated at 2022-06-22 14:24:15.107520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    from ansible.template import generate_ansible_template_vars,USE_JINJA2_NATIVE
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import AnsibleEnvironment

    display = Display()

    class LookupModule(LookupBase):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar

        def run(self, terms, variables, **kwargs):

            ret = []
            self.set_options(var_options=variables, direct=kwargs)

            # capture options
            convert_

# Generated at 2022-06-22 14:24:26.910945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class OptionsModule(object):

        def get_option(self, option):
            if option == 'convert_data':
                return True
            if option == 'template_vars':
                return {}
            if option == 'jinja2_native':
                return False
            if option == 'variable_start_string':
                return '{{'
            if option == 'variable_end_string':
                return '}}'
            if option == 'comment_start_string':
                return '{#'
            if option == 'comment_end_string':
                return '#}'

    terms = ['index.html.j2', 'index.html.j2']
    variables = '{"foo": "bar"}'
    options = OptionsModule()

    test_lookup = LookupModule()

# Generated at 2022-06-22 14:24:34.329924
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use reflection to access the private attribute _loader of class
    # LookupModule to avoid the need for creating a fake object for the test.
    # save the original value
    _loader_orig = LookupModule._loader
    # initialize it with a fake object
    try:
        LookupModule._loader = FakeLoader()
        # setup the expected return value
        expected = [to_bytes('foo\nbar\n', encoding='utf-8')]
        # do the test
        actual = LookupModule().run(["test.txt"], dict(ansible_search_path=['/some/fake/path']))
        # assertion
        assert actual == expected
    finally:
        # restore original value
        LookupModule._loader = _loader_orig



# Generated at 2022-06-22 14:24:39.193486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy arguments for LookupModule.run
    terms = ['some_template.j2']
    variables = {'somedict': {'somesubdict': 'somesubvalue'}}
    lookup_file = './some_template.j2'

    # Create a dummy class which contains the method run
    class DummyClass(LookupModule):
        def __init__(self):
            self.results = None

        def run(self, terms, variables, **kwargs):
            # Dummy method to test the LookupModule.run method
            self.results = super(DummyClass, self).run(terms, variables, **kwargs)

        def find_file_in_search_path(self, variables, dirname, filename):
            # Dummy method to test the LookupModule.run method
            return lookup_file



# Generated at 2022-06-22 14:24:48.072309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(dict(variable_start_string='[%', variable_end_string='%]'))
    l._loader = DictDataLoader({
        'test/test_templating.j2': '[% 2 + 3 %]',
        'test/test_templating2.j2': '[% ansible_managed %]',
        'test/test_templating3.j2': '{{',
    })

# Generated at 2022-06-22 14:24:56.781127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ({'key1': 'value1', 'key2': 'value2'},
             {'key11': 'value11', 'key12': 'value12'})
    variables = {'simple': 'variable'}
    result = lookup_module.run(terms, variables)
    assert result[0]['key1'] == 'value1'
    assert result[0]['key2'] == 'value2'
    assert result[1]['key11'] == 'value11'
    assert result[1]['key12'] == 'value12'

# Generated at 2022-06-22 14:25:06.376846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.vars as vars_mod
    # This is a test stub
    (par1, par2, par3, par4) = ('par1', 'par2', 'par3', 'par4')

    mod = vars_mod
    mod.VariableManager = vars_mod.VariableManager
    class obj1(mod.VariableManager):
        def __init__(self):
            self.extra_vars = {}
            self.options = type('obj', (), {})()
            self.options.tags = []
            self.options.skip_tags = []
            self.options.forks = 5
            self.options.timeout = 10
            self.options.remote_user = 'me'
            self.options.ask_pass = True

    # Testing conditions
    # 1. lookup_file_name is

# Generated at 2022-06-22 14:25:16.208168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    lookup = LookupModule()
    lookup.set_loader(DataLoader())
    lookup.set_basedir('.')
    lookup._templar.available_variables = {}

    # test with a simple template file
    assert lookup.run(['./../tests/files/templates/ansible.j2'], {}) == [u"\nHello World,\n\nThis is a test template in Ansible.\n"]

    # test with a simple template file and vars

# Generated at 2022-06-22 14:25:28.221836
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: this test uses "magic" variable "ansible_current_date" to simulate input variable.
    #       Thus, it only works with 'convert_data=False' and jinja2_native=True

    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    test_terms = [ '../lookup_plugins/test_template.j2' ]
    test_variables = { 'ansible_current_date': '2016-11-22' }

    # TODO: test multiple terms in a list
    # TODO: test more than one file in a list: test_terms = ['../lookup_plugins/test_template.j2','../lookup_plugins/test_template2.j2']


# Generated at 2022-06-22 14:25:50.904647
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import tempfile
    import textwrap
    import unittest

    from ansible.errors import AnsibleError
    from ansible.plugins.loader import lookup_loader
    from ansible.template import generate_ansible_template_vars
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    display = Display()
    display.verbosity = 4

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.variable_manager = VariableManager()
            self.loader = lookup_loader
            self.loader.set_variable_manager(self.variable_manager)
            self.loader.set_basedir(os.path.dirname(__file__))

# Generated at 2022-06-22 14:26:03.018515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule - run - simple test"""

    import os
    import shutil
    import tempfile
    import unittest
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    module_utils_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "..")
    sys.path.append(module_utils_path)

    class TestLookupModule_run(unittest.TestCase):

        def setUp(self):
            self.workdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.workdir)


# Generated at 2022-06-22 14:26:14.880803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vault_secrets_file = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'unit', 'common', 'vault_password.txt')
    vault_password = open(vault_secrets_file).read().rstrip('\r\n')
    vault_secrets = {'vault_password': vault_password}

    my_vars = dict(var1="value1", var2="value2")
    my_vars['vault'] = VaultLib(vault_secrets)

    templar = Templar(my_vars)

    lookup = LookupModule()

# Generated at 2022-06-22 14:26:21.120727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ('foo',)
    variables = {'ansible_search_path': ('/bar/baz', '/bar/qux')}

    # setup mocks for module
    module.find_file_in_search_path = lambda variables, subdir, term: '/bar/qux/templates/foo'
    module._loader = create_mock_loader()
    module._templar = create_mock_templar()
    
    # run method
    ret = module.run(terms, variables)
    assert ret == ['abc']


# Mock class

# Generated at 2022-06-22 14:26:21.713255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-22 14:26:23.037180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tested inside test_lookup_plugins.py
    pass

# Generated at 2022-06-22 14:26:34.225985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.template import AnsibleEnvironment

    terms = ['does-not-exist']
    variables = {}
    kwargs = {}
    lookup = LookupModule()
    assert isinstance(lookup.run(terms, variables, **kwargs), list)

    # test custom templating
    lookup = LookupModule()
    lookup._templar = lookup._templar.copy_with_new_env(environment_class=AnsibleEnvironment)
    lookup.set_options(var_options=variables, direct=kwargs)
    lookupfile = './test/unit/lookup_plugins/'
    lookupfile += 'test.custom_variable_delimiters'

# Generated at 2022-06-22 14:26:41.185958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Uncomment following line to test the test below:
    #raise ValueError('This error is on purpose')
    template_file = './tests/templates/test_template.j2'
    lookup_result = lookup.run([template_file], dict(key='value of variable'))
    assert to_text(lookup_result[0]) == to_text("Variable value is: value of variable")

# Generated at 2022-06-22 14:26:46.814123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create LookupModule for testing
    lookup_module = LookupModule()

    # Test the case that lookup is successful
    lookup_module.run(["test_template.j2"],
                      {"template_file1": "test_template.j2"})

    # Test the case that lookup is not successful
    lookup_module.run(["test_invalid_template.j2"],
                      {"template_file1": "test_template.j2"})

# Generated at 2022-06-22 14:26:59.034844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def Mock_loader__get_file_contents():
        return ("", True)

    # Make sure we always get an instance of AnsibleEnvironment as a jinja2 environment from a lookup
    # This is not the case if USE_JINJA2_NATIVE is True
    def Mock_templar_copy_with_new_env():
        return ("", True)

    def Mock_find_file_in_search_path():
        return True

    def Mock_debug():
        return True

    def Mock_get_option():
        return ("", True)

    def Mock_set_options():
        return True

    class TestVars:
        pass

    lookup = LookupModule()
    lookup._loader._get_file_contents = Mock_loader__get_file_contents
    lookup._templar.copy_with

# Generated at 2022-06-22 14:27:30.118830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Importing modules that are not importable in 2.4
    import jinja2
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from jinja2.environment import Environment as JinjaEnv
    from ansible.template import AnsibleEnvironment
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Create a dict of all the var's this lookup uses
    all_vars = {}
    all_vars.update(vars(combine_vars))
    all_vars.update(vars(merge_hash))

    # Add in AnsibleEnvironment into the dict
    all_vars.update(vars(AnsibleEnvironment))


# Generated at 2022-06-22 14:27:37.814352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # this is not a real unit test, we just check the example in the documentation works with
    # the current values of the variables
    lookup_template_vars = {
        'foo': 'bar',
    }
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_end_string = '#}'
    terms = [
        './some_template.j2',
    ]
    variables = {
        'ansible_search_path': [
            '/path/to/first/template_dir',
            '/path/to/second/template_dir',
        ],
    }

# Generated at 2022-06-22 14:27:47.385719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Testing the LookupModule run method
    """
    templar = Templar(loader=DictDataLoader())
    display = Display()
    lookup_obj = LookupModule(templar=templar, loader=DictDataLoader(), display=display)

    # Testing when template file is not present in lookup path
    term = 'some_template'
    variables = dict(one="1", two="2", three="3", four="4", ansible_search_path=["/my/path1", "/my/path2"])
    lookup_obj.set_options(var_options=variables)
    assert 'some_template' in lookup_obj.run([term], variables)
    assert '/my/path1' in lookup_obj.run([term], variables)

# Generated at 2022-06-22 14:27:52.513605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    given_terms = ['some_template.j2']
    given_variables = {}
    given_kwargs = {}

    # When
    lookup_module = LookupModule()
    returned_value = lookup_module.run(given_terms, given_variables, **given_kwargs)

    # Then
    assert returned_value == []

# Generated at 2022-06-22 14:27:59.974389
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run with options ( jinja2_native=False convert_data=False ) and global variables.
    # No lookup_template_vars is given.
    # No values in searchpath

    # TODO: create an example of template_vars

    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import PY3

    from ansible import constants as C
    from ansible.template import generate_ansible_template_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from io import BytesIO
    from ansible.plugins.loader import lookup_loader

    lookup_plugin, lookup_basedir = lookup_loader._get_lookup_plugins('template')

    # Given options and variables
    options = {}

# Generated at 2022-06-22 14:28:09.383593
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with comment_start_string and comment_end_string
    class MockLookupBase:
        def __init__(self, base_class):
            self._templar = base_class
        def get_option(self, x):
            if x == 'comment_end_string':
                return '#}'
            if x == 'comment_start_string':
                return '{#'
            return None

        def find_file_in_search_path(self, *args, **kwargs):
            return 'z'
    class MockTemplar:
        class Environment:
            def __init__(self):
                self.filters = {}
                self.tests = {}
                self.globals = {}
                self.finalize = None
            def from_string(self, string):
                return string
       

# Generated at 2022-06-22 14:28:21.564593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with jinja2_native = False
    lookup_module = LookupModule()

    plugin_loader = DummyPluginLoader()
    plugin_loader._get_file_contents = get_file_contents
    plugin_loader._get_file_vars = get_file_vars
    plugin_loader.decrypt = decrypt

    templar = DummyTemplar(loader=plugin_loader)
    lookup_module._templar = templar

    # Test with convert_data = False
    lookup_module.set_options(var_options=dict(), direct={"convert_data": False})
    assert lookup_module.run(["file_with_vars.yaml"], variables=dict()) == ['{{ some_var }}\n']

    # Test with convert_data = True
    lookup_module.set

# Generated at 2022-06-22 14:28:34.285422
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    # Assert method lookup_template raises a TypeError when called with
    # the incorrect number of arguments.
    with pytest.raises(TypeError):
        module.run()

    # Assert method lookup_template raises an AnsibleError when called with
    # terms which would be rendered by the template.
    with pytest.raises(AnsibleError):
        module.run(terms=[])

    # Assert method lookup_template raises an AnsibleError when called with
    # template_vars which would be rendered by the template.
    with pytest.raises(AnsibleError):
        module.run(terms=['t'], template_vars=[])

    # Assert method lookup_template returns an array with the rendered template.
    template_vars = {'msg': 'aaa'}


# Generated at 2022-06-22 14:28:47.457332
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from six import StringIO
    from yaml import safe_load

    # input data for test_LookupModule_run
    terms = [to_bytes('var2 var3')]
    variables = dict(
        var1 = 1,
        var2 = 2,
        var3 = {'a': 'b'}
    )

    # test execution
    lu = LookupModule()

# Generated at 2022-06-22 14:28:59.981234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l.set_loader({'paths': ['lookup_plugins/tests/files']})
    l.set_environment([{'path': 'lookup_plugins/tests/files/templates'}])

    # the default variable_start_string and variable_end_string are used
    result = l.run(terms=['mydict'], variables={'mydict': {'key': 'value'}})
    assert result == [u'value']

    # the default variable_start_string and variable_end_string are used again
    # as we don't specify variable_start_string or variable_end_string
    result = l.run(terms=['comment'], variables={'mydict': {'key': 'value'}})
    assert result == [u'']

    # we use different variable_

# Generated at 2022-06-22 14:29:52.631955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test args for method run
    class Args:
        def __init__(self, terms, variables):
            self.terms = terms
            self.variables = variables
        def __repr__(self):
            return "Args(%r, %r)" % (self.terms, self.variables)
    args = Args(terms=["some_template.j2"], variables={"hostvars": {"hostvars": {"ansible_host": "127.0.0.1"}}})

    # Stub class AnsibleEnvironment
    class StubClassA:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

# Generated at 2022-06-22 14:30:04.246630
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test template lookup
    options_template = {
        'convert_data': None,
        'template_vars': {'var1': 'val1', 'var2': 'val2'},
        'variable_start_string': None,
        'variable_end_string': None,
        'comment_start_string': None,
        'comment_end_string': None,
        'jinja2_native': None,
    }
    terms_template = ['test_template']
    variables_template = {'ansible_search_path': ['/'.join(os.path.dirname(__file__).split('/')[:-1])]}

    lookup = LookupModule()
    res = lookup.run(terms_template, variables=variables_template, **options_template)

# Generated at 2022-06-22 14:30:10.344662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from ansible.constants import DEFAULT_TEMPLATE_CACHE

    display = Display()
    display.columns = 80

    class TestLookupModule(LookupModule):
        def get_option(self, name):
            if name == 'template_dirs' or name == 'template_cache':
                return ['t']
            return None
        def find_file_in_search_path(self, variables, paths, filename):
            return filename
        def check_conditional(self, condition, variables):
            return True
        def _get_file_contents(self, filename):
            if filename == 't/f1.j2':
                return 'The {{ value1 }} is {{ value2 }}.', False

# Generated at 2022-06-22 14:30:20.846814
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleLookupError
    from ansible.template import Templar

    # Create an instance of LookupModule
    my_lm = LookupModule()

    # Create an instance of AnsibleTemplate
    my_templar = Templar(variables=dict())

    # Set templar
    my_lm._templar = my_templar

    # Set loader
    my_lm._loader = my_lm._loader

    # Set find_file_in_search_path (to avoid its use in LookupModule.run)
    def my_find_file_in_search_path(my_variables=None, my_subdir=None, my_filename=None):
        return False
    my_lm.find_file_in_search_path = my_find_file_in_

# Generated at 2022-06-22 14:30:28.542286
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create the object
    lm = LookupModule()

    # Test when no content, no options
    assert len(lm.run([], {})) == 0

    # Test when no option
    assert len(lm.run(['file1'], {})) == 1

    # Test when file missing
    try:
        lm.run(['file2'], {})
        assert False
    except AnsibleError:
        assert True

    # Test with options
    assert len(lm.run(['file1'], {'template_vars': {'key1': 'value1'}})) == 1



# Generated at 2022-06-22 14:30:36.335516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Testing initialize
    instance = lookup.run(terms=['instance'],
                          variables={'a': 'b'},
                          convert_data=None,
                          template_vars=None,
                          jinja2_native=None,
                          variable_start_string=None,
                          variable_end_string=None,
                          comment_start_string=None,
                          comment_end_string=None)

    assert instance == [u'instance']


# Generated at 2022-06-22 14:30:46.777964
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    # test_LookupModule_run_1
    vars = {'ansible_search_path': ['/home/robert/projects/ansible/test/integration/targets/nameservers'],
            'missing_required_var': 'jinja2.exceptions.UndefinedError: "missing_required_var" is undefined'}
    terms = ['/home/robert/projects/ansible/test/integration/targets/nameservers/templates/named.conf.j2']

# Generated at 2022-06-22 14:30:56.880336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    example_terms = [
        './some_template.j2',
        './some_other_template.j2',
    ]
    example_variables = {
        'favorite_fruit': 'kiwi',
        'lookup_test': {
            'test_item_1': 'value 1',
            'test_item_2': 'value 2',
        }
    }
    lookup_module = LookupModule()
    assert lookup_module.run(example_terms, example_variables) == [
        "{{ test_item_1 }}",
        "{{ test_item_2 }}"
    ]

# Generated at 2022-06-22 14:31:09.788756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    from units.compat.mock import patch

    from ansible.template import _AnsibleJ2Vars
    from ansible.template import generate_ansible_template_vars
    from ansible.template import AnsibleEnvironment
    from ansible.plugins.lookup import LookupBase
    from ansible.vars.clean import strip_internal_keys

    from ansible.module_utils._text import to_text

    # LookupModule.run() sets self._loader which is used by find_file_in_search_path()
    # so we need a valid loader
    loader_mock = patch('ansible.plugins.lookup.LookupBase._loader')
    loader_mock.start()

# Generated at 2022-06-22 14:31:22.297123
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from unittest import TestCase, mock
    from ansible.parsing.vault import VaultLib

    class TestLookupModule(TestCase):

        def setUp(self):
            self.display = mock.patch('ansible.plugins.lookup.template.display').start()

        def tearDown(self):
            mock.patch.stopall()

        @mock.patch('ansible.plugins.lookup.template.AnsibleEnvironment')
        @mock.patch('ansible.plugins.lookup.template.AnsibleLoader')
        def test_LookupModule_run_1(self, mock_loader, mock_environment):

            mock_loader.get_basedir.return_value = '/a/b'
            mock_loader.path_dwim.return_value = '/c/d'
            mock_