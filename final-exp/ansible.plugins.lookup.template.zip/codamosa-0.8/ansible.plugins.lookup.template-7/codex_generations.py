

# Generated at 2022-06-22 14:22:26.008774
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test environment and a temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp(prefix='ansible-tmp')

    # Create a test file test_file.j2 in the temporary directory
    lookupfile = 'test_file.j2'
    test_file = tempfile.NamedTemporaryFile(delete=False,
                                            dir=tmpdir,
                                            prefix=lookupfile,
                                            suffix='.j2',
                                            mode="wb")
    test_file.write(b'test')
    test_file.close()

    # Create an instance of LookupModule
    from ansible.plugins.loader import lookup_loader
    test_lookup = lookup_loader.get('template')

    # Invoke the run method of the LookupModule instance with the test file
    result

# Generated at 2022-06-22 14:22:38.212317
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Create mock object to pass to LookupModule
    mock = LookupModule()

    # Create fake template in templates dir
    template_dir = C.DEFAULT_LOCAL_TMP + "/ansible_template_test"
    open(template_dir + "/template.j2", "w").close()

# Generated at 2022-06-22 14:22:47.309511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    templar = lookup_module._templar
    display = lookup_module._display
    terms = lookup_module.run(terms=['template_test.j2'], variables={'name': 'john'})[0]
    assert terms == 'Hello john!'
    templar.options['jinja2_native'] = True
    display.verbosity = 4
    terms = lookup_module.run(terms=['template_test.j2'], variables={'name': 'john'})[0]
    assert terms == 'Hello john!'

# Generated at 2022-06-22 14:22:58.823028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    j2_data = 'First line.\nThis is {{ lookup("env", "PWD") }}/test.\nLast line.'
    j2_file = './test.j2'
    with open(j2_file, 'w') as f:
        f.write(j2_data)
    terms = [j2_file]
    result = module.run(terms, dict(convert_data=False, jinja2_native=False, AnsibleVars={}))
    os.remove(j2_file)
    assert result[0] == 'First line.\nThis is {}/test.\nLast line.'.format(os.getcwd())

# Generated at 2022-06-22 14:23:11.155437
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import context

    terms = ['some_template.j2']
    variables = {
        'some_var': 'some_value',
        'some_other_var': 'some_other_value',
        'ansible_search_path': ['some_path', 'some_other_path']
    }

    direct = {}

    lookup_template_vars = {
        'lookup_var': 'lookup_val',
        'lookup_other_var': 'lookup_other_val'
    }

    display_mock = mock.create_autospec(Display)
    display_mock.debug.return_value = None
    display_mock.vvvv.return_value = None

    class DummyClass(object):
        def __init__(self):
            self.vars = variables



# Generated at 2022-06-22 14:23:24.242953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest
    from ansible.module_utils.six.moves import builtins

    print = builtins.print
    original_print = print


# Generated at 2022-06-22 14:23:32.833897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar.environment.loader.searchpath = [os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins')]
    lookup_module.set_options(direct={'convert_data': False})
    assert lookup_module.run(['./test_template.j2'], {'iam': 'iamvalue'}) == [u'<html>iamvalue</html>']
    lookup_module.set_options(direct={'convert_data': True})
    assert lookup_module.run(['./test_template.j2'], {'iam': 'iamvalue'}) == [{u'html': u'iamvalue'}]

# Generated at 2022-06-22 14:23:40.180292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    data = dict(
        template_vars={'key1': 'value1'},
        my_host='localhost'
    )
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    var_manager = VariableManager(loader=loader, inventory=inv_manager)
    var_manager.extra_vars = data
    tmplar = lookup_loader.get('template', loader=loader, templar=None, shared_loader_obj=None, variable_manager=var_manager)

# Generated at 2022-06-22 14:23:51.600990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class AnsibleUnsafeText:
        pass

    class AnsibleModuleUnsafeText:
        pass

    templar = mock.Mock()
    assert LookupModule(loader=None, templar=templar, **dict()).run([], dict()) == []

    terms = ['file.txt']
    loader = mock.Mock()
    loader.get_basedir.return_value = '/path/to/basedir'
    loader.path_dwim.return_value = '/path/to/basedir/templates/file.txt'
    loader._get_file_contents.return_value = (b'this {{ foo }}', '<file.txt>')
    expected_template_data = 'this {{ foo }}'

# Generated at 2022-06-22 14:24:04.374432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    env = {'ANSIBLE_LOADER': '{}'}
    lookup_module._templar.environment = AnsibleEnvironment(**env)
    lookup_module._templar.loader = None
    lookup_module._loader = lookup_module._templar.loader
    terms = ['/dir/dir2/test_template.j2']
    lookup_module._templar.template_class = lookup_module._templar.environment.get_template_class(class_name='Jinja2')
    lookup_module._templar._available_variables = dict()
    lookup_module._templar._lookup_loader = '{}'
    variables = dict()
    variables['ansible_var'] = 'var_value'

# Generated at 2022-06-22 14:24:25.719894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    lookup = LookupModule()

    # check for lookup values for variable_start_string and variable_end_string
    result = lookup.run(["tests/test.j2"], dict(variable_start_string='[%', variable_end_string='%]'), loader=DataLoader(), play_context=PlayContext())

# Generated at 2022-06-22 14:24:34.243819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is an example of a template which contains '({{' and it is
    # loaded as the first entry of 'terms' input to run().
    # This is to test whether '{{' is properly handled by Jinja2.
    terms = ['{{ foo }}']
    lookup = LookupModule()
    result = lookup.run(terms)
    assert result == [u'{{ foo }}']
    # This is an example of a template which contains `['` and `']` and there
    # is a single quote inside the template.
    # This is to test whether the single quote or `['` or `']` is properly
    # handled by Jinja2.
    terms = [u"{{ foo }}['bar']"]
    lookup = LookupModule()
    result = lookup.run(terms)

# Generated at 2022-06-22 14:24:44.382723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = ['test.yaml']
    variables = {'answer': 42}
    ret = lookup.run(terms, variables, jinja2_native=False, convert_data=False)
    assert ret == ['test: 42']

    ret = lookup.run(terms, variables, jinja2_native=True, convert_data=True)
    assert ret == [{'test': 42}]

    # Test if the error message is correct when template file cannot be found
    terms = ['unknown.yaml']
    try:
        lookup.run(terms, variables)
    except AnsibleError as e:
        assert str(e) == "the template file unknown.yaml could not be found for the lookup"

# Generated at 2022-06-22 14:24:57.366168
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FauxAnsibleFile:

        def __init__(self, path, contents, mode=None):
            "Class initializer"

            self.path = path
            self.contents = contents
            self.mode = mode

        def __eq__(self, other):
            "Equality operator"

            return (self.path == other.path and
                    self.contents == other.contents and
                    self.mode == other.mode)

        def __repr__(self):
            "Representation of object"

            return "%s (path: %s, mode: %s, contents: %s)" % (self.__class__.__name__,
                                                              self.path,
                                                              self.mode,
                                                              self.contents)

        # Mimic AnsibleFile class for testing

       

# Generated at 2022-06-22 14:25:00.529388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    assert lookupModule.run(['dummy.j2'], {'magic': 'magic'}, convert_data=False) == ['hello world']

# Generated at 2022-06-22 14:25:11.879000
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader

    loader = lookup_loader._create_loader(None, '.')
    lookup_cls = lookup_loader._get_lookup_class('template')
    returning_strings_cls = lookup_cls(loader)

    # Test a valid template
    test_string_1 = "{{ lookup_test_var_1 }}"
    test_variables_1 = dict(
        lookup_test_var_1="Hello World",
    )
    test_template_vars_1 = {}

# Generated at 2022-06-22 14:25:21.153735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    path_list=[]
    play = Play().load({'name': 'test_play', 'hosts': 'localhost'}, loader=loader,variable_manager=None, loader_cache=path_list)

# Generated at 2022-06-22 14:25:33.203334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup.
    from ansible.template import  AnsibleEnvironment

    class MockTemplar:
        def __init__(self):
            self.env = AnsibleEnvironment()
            self.variable_start_string = '{{'
            self.variable_end_string = '}}'

        def copy_with_new_env(self, environment_class):
            return self

        def set_temporary_context(self, **kwargs):
            #return
            for key in kwargs:
                setattr(self.env, str(key), kwargs[key])


# Generated at 2022-06-22 14:25:34.102990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-22 14:25:42.616034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from jinja2 import DictLoader, Environment

    display = Display()
    module = LookupModule()
    module._display = display
    dictloader = DictLoader({'test.j2': '{% if a < b %}1{% else %}0{% endif %}'})
    jinja2_env = Environment(loader=dictloader, undefined=AnsibleUnsafeText, autoescape=True)
    module._templar = jinja2_env.from_string('template info: ansible_template_mtime={{ ansible_template_mtime }}')
    lookup_lookupfile = {'template_vars': {'a': 1, 'b': 2}}

# Generated at 2022-06-22 14:25:55.327740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    display.verbosity = 5
    display.debug("this is a test")
    display.vv("hello world")


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-22 14:26:06.522828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json, os
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment
    from ansible.utils.vars import combine_vars, combine_hash

    basepath = os.path.dirname(__file__)
    if basepath != '':
        basepath = basepath + '/'
    display = Display()

    # load plugin
    lookup = lookup_loader.get('template')
    display.debug("loaded plugin %r" % lookup)

    display.debug("creating plugin object")
    lookup = lookup()
    display.debug("creating plugin object %r" % lookup)

# Generated at 2022-06-22 14:26:14.835892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    class MyLookupModule(LookupModule):
        def _find_file_in_search_path(self, env, dirname, filename):
            return os.path.join(dirname, filename)

        def _get_file_contents(self, filename):
            return ('foo: bar', True)

    # make sure our _get_file_contents() is called with the right arguments
    l = MyLookupModule()
    assert l.run(['./some_template'], dict(foo='bar')) == ['foo: bar']

# Generated at 2022-06-22 14:26:22.978686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes

    from ansible.template import generate_ansible_template_vars
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.vars import AnsibleVars

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import MalformedVaultSecret

    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError

    import _fixtures

    lookup_module = LookupModule()
    lookup_module.set_loader(_fixtures.Loader())
    lookup_module.set_templar(_fixtures.MockTemplar())

    # Note: the following test overwrites the VaultLib's _decrypt_text() to return the input

# Generated at 2022-06-22 14:26:34.167281
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.set_options({
        'convert_data': True,
        'comment_start_string': '',
        'comment_end_string': '',
        'variable_start_string': '{',
        'variable_end_string': '}',
        'jinja2_native': False,
        'template_vars': {},
    })

    found_file = 'found.txt'
    lookup._loader.module_finder.module_finder.module_utils_loader.module_loader.path_finder._paths.append(os.path.abspath('.'))

# Generated at 2022-06-22 14:26:45.685712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    from ansible.module_utils.facts.virtual.base import BaseVirtual
    import ansible.plugins.lookup.template
    from ansible.plugins.lookup.template import LookupModule
    from ansible.template import Templar
    from ansible.template.template import AnsibleJ2Vars

    templar = Templar(variables={})
    lookup = LookupModule(loader=None, templar=templar, shared_loader_obj=None, basedir=None)
    lookup._loader._fact_cache = {}
    lookup._templar = templar

    # Test empty template.
    terms = []
    response = lookup.run(terms, variables={}, convert_data=False)
    assert response == []

    # Test valid template with ansible_facts variable.

# Generated at 2022-06-22 14:26:57.737701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # class displayed below is a mock of the LookupModule class.
    class LookupModule():
        def set_options(self, var_options, direct):
            return 0

        def get_option(self, option):
            option_dict = {
                "convert_data": False,
                "template_vars": {},
                "jinja2_native": False,
                "variable_start_string": "{{",
                "variable_end_string": "}}",
                "comment_start_string": None,
                "comment_end_string": None,
            }
            return option_dict[option]


# Generated at 2022-06-22 14:27:01.425955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check if the first element of run method's return is same as expected result
    lookup_obj = LookupModule()
    assert lookup_obj.run(["Hello {{ ansible_hostname }}"], {"ansible_hostname": "localhost"})[0] == "Hello localhost"

# Generated at 2022-06-22 14:27:12.268535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string_return = "Hallo Welt"
    filename = "file.tmp"
    environment_new = {'ansible_search_path': ['/'], 'variable_end_string': '}}', 'variable_start_string': '{{'}

    # creates a LookupModule object
    lookupModule = LookupModule()

    # create file
    f = open(filename, "w")
    f.write(string_return)
    f.close()

    # run method with file.tmp
    result = lookupModule.run(['file.tmp'], environment_new)
    os.remove(filename)

    # checks if the file was templated and the result is correct
    assert result[0] == "Hallo Welt"

# Generated at 2022-06-22 14:27:17.167164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    lookup_plugin = lookup_loader.get('template')
    assert lookup_plugin is not None

    terms = ['test_template.j2']
    variables = {u'name': u'Fred'}
    lookup_plugin.run(terms, variables)



# Generated at 2022-06-22 14:27:46.854665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    Test the loading of an existing template.
    """
    import os
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    test_data_loader = DataLoader()
    test_variable_manager = VariableManager()

# Generated at 2022-06-22 14:27:57.264603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __builtin__ as builtins
    import pytest
    from ansible.module_utils.six import PY2

    if PY2:
        builtin_open = '__builtin__.open'
    else:
        builtin_open = 'builtins.open'

    m = LookupModule()

    # Test if file not found
    with pytest.raises(AnsibleError):
        m.run([None], dict(foo=None))

    # Test if file found
    with pytest.raises(AnsibleError):
        m.run([None], dict(foo=None), templates=['__test_file_not_found__'])

    # Test loading
#     with pytest.raises(AnsibleError):
#         m.run([None], dict(foo=None), templates=['

# Generated at 2022-06-22 14:28:07.973771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None
    # Test 1
    result = lookup.run([], [])
    assert result == []

    # Test 2
    result = lookup.run(["{{", "}}"], [])
    expected_result = ["{{", "}}"]
    assert result == expected_result

    # Test 3

# Generated at 2022-06-22 14:28:09.320891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-22 14:28:21.512275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager.set_inventory(inventory)

    playbook = Play().load(dict(
        name="An empty play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=''))
        ]
    ), variable_manager=variable_manager, loader=loader)

    task = playbook.get_tasks()[0]

    lookup_plugin

# Generated at 2022-06-22 14:28:34.232656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import tempfile

    test_dir = tempfile.mkdtemp(prefix="tmp-test_LookupModule_run")
    os.chdir(test_dir)
    fd, p1 = tempfile.mkstemp(dir=test_dir)
    with open(p1, "w") as f:
        f.write("print('hello'+' world')")
    fd, p2 = tempfile.mkstemp(dir=test_dir)
    with open(p2, "w") as f:
        f.write("foobar")

    loader = None

# Generated at 2022-06-22 14:28:47.457477
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #######################################################
    # This test case assumes that the following files exist in ./templates subdir
    # 1. file1.j2.tmpl
    # 2. file2.j2.tmpl
    # 3. file3.j2.tmpl
    # 4. file4.j2.tmpl
    # 5. file5.j2.tmpl
    #
    # Note that we are using j2.tmpl extension as opposed to j2 extension
    # so that the Ansible documentation system doesn't try to process the
    # template files.
    #######################################################

    # Case 1: read single file
    test1 = ['file1.j2.tmpl']
    variables = dict(
        str_var = 'abc'
    )
    lookup_obj = LookupModule()
    out = lookup_

# Generated at 2022-06-22 14:28:59.980867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    import sys
    if sys.version_info[0] > 2:
        import builtins
        builtins.__dict__['_'] = lambda x: x
    else:
        import __builtin__
        __builtin__.__dict__['_'] = lambda x: x

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import configparser

    def MockConfigParserGet(self, section, key):
        return {
            'vars': {
                'foo': 'bar'
            }
        }[section][key]
    configparser.ConfigParser.get = MockConfigParserGet

    class MockVarsModule():
        def __init__(self):
            self

# Generated at 2022-06-22 14:29:08.301438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init LookupModule
    lm = LookupModule()
    # init Display
    display = Display()
    # init Display.debug
    def mdebug(self, msg):
        return msg
    display.debug = mdebug
    # init LookupBase
    lookup_base = LookupBase()
    # init LookupBase.set_options
    def set_options(self, var_options=None, direct=None):
        return
    lookup_base.set_options = set_options
    # init LookupBase.get_option
    def get_option(self, term=None):
        if term == "convert_data":
            return True
        if term == "jinja2_native":
            return False
        return None
    lookup_base.get_option = get_option

    # init AnsibleModule
   

# Generated at 2022-06-22 14:29:16.153790
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test the method run with invalid args
    lookup = LookupModule()
    try:
        lookup.run([], {})
    except AnsibleError as e:
        assert "the template file {0} could not be found for the lookup".format('') in str(e)

    # test the method run with a valid args
    lookup = LookupModule()
    lookup.set_options(None, { 'template_vars': {} })
    lookup.find_file_in_search_path = lambda x, y, z: os.path.join(os.getcwd(), 'tests', 'fixtures', 'lookup_plugins', 'template.j2')

# Generated at 2022-06-22 14:29:59.906978
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.parsing.vault import VaultEditor
    from ansible.utils.sentinel import Sentinel
    from ansible.vars.manager import VariableManager

    lookup = lookup_loader.get('template')

    # Test with empty options
    options = {
        '_restrict_to_collections': True,
        '_ansible_check_mode': False,
        '_ansible_no_log': False,
        '_ansible_debug': False,
    }
    terms = ['some_template.j2']
    variables = dict()
    result = lookup.run(terms, variables, **options)
    assert result == []

    # Test with an empty template_vars in options

# Generated at 2022-06-22 14:30:11.851611
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        from __main__ import display
    except ImportError:
        # lookups are supposed to operate without display, but for testing purposes we may need it, so create an instance
        display = Display()

    # create a lookup
    lookup = LookupModule()
    lookup._templar = AnsibleEnvironment(loader=None, variables={})

    # lookup a file that does not exist
    lookup.set_options(direct={'template_vars': {'var1': 'value1'}})
    display = Display()
    display.verbosity = 4
    display.debug("Verbosity set to 4")

# Generated at 2022-06-22 14:30:22.215140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_module = AnsibleModuleMock()
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = DictDataLoader({'ansible/templates/test_template.txt':
                                            to_bytes(u'Hello {{ my_var }}!')})
    lookup_module.set_options(direct={'_original_file': 'ansible/templates/test_template.txt'})

    assert lookup_module.run(terms=['./test_template.txt'],
                             variables={'my_var': 'world'},
                             convert_data=False,
                             jinja2_native=True,
                             ansible_module=ansible_module)[0] == u'Hello world!'


# Generated at 2022-06-22 14:30:33.430004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    # Load the class
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'plugins'))
    LookupModule = LookupModule()

    # Load other stuff we need
    class FakeVars(dict):
        def get(self, varname):
            return self[varname]

    # Make a fake environment to test with

# Generated at 2022-06-22 14:30:45.287996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_dir = os.path.dirname(__file__)
    lookup = LookupModule()
    term = 'test_template.j2'
    variables = {'foo': 'bar'}
    result = lookup.run(term, variables, basedir=test_dir)
    assert result[0] == u"bar"

    # test with explicit current working directory
    term = 'test_template.j2'
    variables = {'foo': 'bar'}
    result = lookup.run(term, variables, basedir=os.getcwd())
    assert result[0] == u"bar"

    # test with invalid path
    term = 'invalid_file.j2'
    variables = {'foo': 'bar'}
    result = lookup.run(term, variables, basedir=test_dir)
    #

# Generated at 2022-06-22 14:30:56.275384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["./some_template.j2", "./some_other_template.j2", "./a_third_template.j2"]
    variables = {
        "variable_start_string": "[%",
        "variable_end_string": "%]"
    }
    options = {
        "convert_data": False,
        "template_vars": {},
        "jinja2_native": False,
        "comment_start_string": "[#",
        "comment_end_string": "#]"
    }
    test_lookup_module = LookupModule()
    test_lookup_module.run(terms, variables, **options)

# Generated at 2022-06-22 14:31:02.670262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar = DummyTemplar()
    module = DummyModule(templar=templar, loader=DummyLoader())

    templar.env.available_variables['some_variable'] = 'some_value'
    templar.env.available_variables['dict_var'] = {'key': 'dict_value'}
    templar.env.available_variables['list_var'] = ['list_value']

    module.template_vars = {}
    module.args = {}

    value = ['tests/templates/test.j2', 'tests/templates/arg-test.j2']
    lookup = LookupModule(loader=module._loader, templar=templar)
    lookup.set_options(var_options=templar.env.available_variables)

   

# Generated at 2022-06-22 14:31:08.627834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialization
    terms = ['some_template.j2']
    variables = {'ansible_search_path':['.']}
    # test code
    lookup_mod = LookupModule()
    lookup_mod.set_options(var_options=variables, direct=None)
    ret = lookup_mod.run(terms, variables)
    assert isinstance(ret, list)
    assert len(ret) == 1

# Generated at 2022-06-22 14:31:20.717419
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class OptionsModule:
        def __init__(self):
            self.convert_data = False
            self.template_vars = {}

    class OptionsVariable:
        def __init__(self):
            self.variable_start_string = '{{'
            self.variable_end_string = '}}'
            self.comment_start_string = '/*'
            self.comment_end_string = '*/'

    class DataLoaderClass:
        def __init__(self):
            self.template_path = None

        def _get_file_contents(self, filename, show_content=False):
            if filename == "./some_template.j2":
                return "{{ var }}", False
            raise AnsibleError("the template file %s could not be found for the lookup" % filename)


# Generated at 2022-06-22 14:31:28.739097
# Unit test for method run of class LookupModule