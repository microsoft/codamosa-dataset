

# Generated at 2022-06-22 14:22:34.449965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""

    from ansible.utils import context_objects as co

    _variables = co.AnsibleContext()
    _variables.add_hash('vars', {'foo': 'bar'})

    # test with jinja2_native=False, convert_data=False
    _ = LookupModule()\
        .run(terms=['test_template.j2'], variables=_variables, jinja2_native=False, convert_data=False)

    # test with jinja2_native=True, convert_data=False
    _ = LookupModule()\
        .run(terms=['test_template.j2'], variables=_variables, jinja2_native=True, convert_data=False)

    # test with jinja

# Generated at 2022-06-22 14:22:41.726998
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a class to bypass the abstract base class
    class LookupModule_for_test(LookupModule):
        def __init__(self, basedir=None, **kwargs):
            self.basedir = basedir
        def get_basedir(self, variables):
            return self.basedir

    lookup = LookupModule_for_test(basedir='/home/user/.ansible/my_plugins/lookup_plugins')
    # Create a class to mock the Templar class
    class Templar_for_test:
        def __init__(self, searchpath):
            self.searchpath = searchpath
        def set_temporary_context(self, **kwargs):
            self.kwargs = kwargs
            return self

# Generated at 2022-06-22 14:22:54.354991
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_terms = ['./some_template.j2']
    test_variables = {'template_path': '/path/to/the/ansible/module/templates/file'}
    jinja2_native = True
    test_data = 'Some template data'

    mock_lookup_base = MockLookupBase()
    mock_lookup_base.set_options = Mock()
    mock_lookup_base.get_option = Mock()
    mock_lookup_base.get_option.return_value = jinja2_native
    mock_lookup_base._loader = Mock()
    mock_lookup_base._loader.get_basedir = Mock()
    mock_lookup_base.find_file_in_search_path = Mock()
    mock_lookup_base.find_file_

# Generated at 2022-06-22 14:23:01.222063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    mod = LookupModule(loader=lookup_loader,
                       templar=None,
                       shared_loader_obj=None)
    terms = ['./some_template.j2']
    variables = {}
    ret = mod.run(terms, variables)
    assert isinstance(ret, list)
    assert isinstance(ret[0], to_text)

# Generated at 2022-06-22 14:23:07.112891
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template.template import convert_data
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class MockTemplar(object):

        template_data = None
        preserve_trailing_newlines = None
        convert_data = None
        escape_backslashes = None
        set_temporary_context = None
        set_available_variables = None

        def copy_with_new_env(self, environment_class):
            pass

        def template(self, template_data, preserve_trailing_newlines=False,
                     convert_data=True, escape_backslashes=True):
            self.template_data = template_data
            self.preserve_trailing_newlines = preserve_trailing_newlines
            self.convert_data = convert_data
            self.escape

# Generated at 2022-06-22 14:23:17.783480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()

    lookup = LookupModule()
    lookup.set_options(direct={'_ansible_verbosity': 3})
    lookup._templar._available_variables = {}
    lookup._loader.set_basedir('/some/cwd')

    ############################################################################
    # Test 1
    ############################################################################
    terms = [u'test_template.j2']
    variables = {}
    kwargs = {}
    ret = lookup.run(terms=terms, variables=variables, **kwargs)
    assert isinstance(ret[0], to_text)


# Unit test
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-22 14:23:29.493275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_loader(None)
    l.set_templar(None)

    # Testing 3rd case (case3) with comment_start_string
    terms = ['case3.j2']
    variables = {}
    kwargs = {}

    kwargs['comment_start_string'] = '##'
    results = l.run(terms, variables, **kwargs)
    assert(results[0] == '## this is a comment.\nthis is not a comment.')

    # Testing 3rd case (case3) with comment_start_string (a different string)
    terms = ['case3.j2']
    variables = {}
    kwargs = {}

    kwargs['comment_start_string'] = '#'

# Generated at 2022-06-22 14:23:41.889394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.test_utils import AnsibleExitJson
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.test_utils import AnsibleFailJson
    from ansible_collections.notstdlib.moveitallout.plugins.lookup import LookupModule
    import ansible.plugins.loader as plugin_loader

    # test case 1 - success case
    # The goal of this test is to test the case where the lookup module returns a valid value
    # The environment variable ANSIBLE_LOOKUP_PLUGINS is used in order to load the module if the module is not loaded
    # by default by Ansible.
    # The values of the variables existing in the environment variable ANSIBLE_LOOKUP_

# Generated at 2022-06-22 14:23:54.156986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import jinja2
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    test_lookup_plugin = LookupModule()
    test_loader = DictDataLoader({})
    test_vault_secrets = None

    test_variable_manager = VariableManager()
    test_inventory = InventoryManager(loader=test_loader, sources='localhost,')

# Generated at 2022-06-22 14:24:05.492716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['test', 'test2']
    variables = {'ansible_lookup_plugin_roles': [], 'ansible_lookup_plugin_search_path': [], 'ansible_search_path': []}
    kwargs = {'variable_start_string': '', 'variable_end_string': '', 'comment_start_string': '', 'comment_end_string': '', 'convert_data': False, 'template_vars': {}, 'jinja2_native': False}

    try:
        result = module.run(terms, variables, **kwargs)
    except Exception as error:
        assert False, error

    if __name__ == '__main__':
        module.run(terms, variables, **kwargs)

# Generated at 2022-06-22 14:24:12.656936
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    # tests need to be written
    pytest.skip("Tests need to be written")

# Generated at 2022-06-22 14:24:18.963273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    arg = "/etc/passwd"
    arg2 = "/etc/shadow"
    arg3 = "/etc/group"
    result = module._load_plugins()
    result = module.run(arg, arg2, arg3, convert_data=True, template_vars={}, jinja2_native=False, variable_start_string='{{', variable_end_string='}}', comment_start_string='[#', comment_end_string='#]')
    if result:
        pass
    else:
        print("method run of class LookupModule failed.")


# Generated at 2022-06-22 14:24:22.806043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    out = module.run('tests/templates/template_test.j2',{'foo':'bar'})
    assert out == ['templates work foo']



# Generated at 2022-06-22 14:24:32.377482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create fake lookup class
    class LookupModule_Test(object):
        def __init__(self, basedir=None, runner=None, inventory=None, loader=None, variable_manager=None, all_vars=None):
            self._templar = variable_manager

    # Create fake runner class
    class Runner_Test(object):
        def __init__(self):
            self.sudo = False
            self.sudo_user = None
            self.connection = 'local'
            self.become = False
            self.become_method = None
            self.become_user = None
            self.remote_avoids_forks = False
            self.run_as_root = False
            self.no_log = False
            self.private_key_file = None
            self.remote_pass = None



# Generated at 2022-06-22 14:24:44.383005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a lookup module
    lookup_module = LookupModule()

    # Create a dict from the YAML in the module docstring
    lookup_module_docstring_dict = yaml.load(
        lookup_module.__class__.__doc__,
        Loader=yaml.BaseLoader
    )

    # Create a dict of the described parameters to pass to the run method
    parameters_dict = {
        'terms': './some_template.j2',
        'variable_start_string': '{%',
        'variable_end_string': '%}',
        'comment_start_string': '{#',
        'comment_end_string': '#}',
        'template_vars': {
            'var': 'value'
        }
    }

    # Extract the options from the docstring
   

# Generated at 2022-06-22 14:24:50.572586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   # Arrange
   module = LookupModule()
   # Act
   variables = { }
   terms = [ "test.j2"]
   ret = module.run(terms,variables)
   # Assert
   assert ret[0] == "test\n"

# Generated at 2022-06-22 14:25:00.502340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(['./some_template.j2'],[{'hostvars': {}, 'playbook_dir': '/'}]) == ["{{ lookup('template', './some_template.j2') }}"]
    assert lm.run(['./some_template.j2'],[{'hostvars': {}, 'playbook_dir': '/'}]) == ["{{ lookup('template', './some_template.j2') }}"]

# Generated at 2022-06-22 14:25:06.949843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    # test case #1, testing if the method is able to handle conditions without
    # raising any exceptions
    lookup_instance._templar = ansible_jinja2.environment.Environment()
    terms = [u'html/message.html.j2']
    variables = {}
    kwargs = {}

    lookup_instance.run(terms, variables, **kwargs)

# Generated at 2022-06-22 14:25:11.714287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    terms = ['fake_template.j2']
    variables = {'ansible_search_path': ['../myplay', '../myplay']}
    kwargs = {}
    lookupModule = LookupModule()

    # When
    result = lookupModule.run(terms, variables, **kwargs)

    # Then
    assert result == []

# Generated at 2022-06-22 14:25:21.033089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.template import generate_ansible_template_vars
    from ansible.plugins.loader import LookupModule as base_lookup
    from ansible.plugins.loader import LookupModule
    import pytest

    # new object of class LookupModule
    lkwargs = dict(
        basedir=None,
        runner=None,
        variables={},
        convert_data=False,
        template_vars={},
        jinja2_native=False,
        variable_start_string='{{',
        variable_end_string='}}',
        comment_start_string='{#',
        comment_end_string='#}',
    )
    lookup_instance = LookupModule(**lkwargs)

    # result
    results = []

    # test

# Generated at 2022-06-22 14:25:37.280430
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with a single letter in the file (no variables)
    terms = ['a.tmpl']
    variables = {}
    kwargs = {}
    module = LookupModule()
    ret = module.run(terms, variables, **kwargs)
    assert ret == ['a']

    # test with a single letter in the file and var_start_string and var_end_string changed
    terms = ['a.tmpl']
    variables = {}
    kwargs = {}
    kwargs['variable_start_string'] = '[['
    kwargs['variable_end_string'] = ']]'
    module = LookupModule()
    ret = module.run(terms, variables, **kwargs)
    assert ret == ['a']

    # test with a single letter in the file and comment_start_string and comment_end_

# Generated at 2022-06-22 14:25:41.967410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup fixture
    lookup = LookupModule()

    # test parameters
    terms = ['test_template.yml', 'test_template.yml']
    variables = {'ansible_search_path': ['.', './lookup_plugins']}
    kwargs = {'variable_start_string': '{{', 'variable_end_string': '}}'}

    # run test
    ret = lookup.run(terms, variables, **kwargs)
    # compare results
    assert ret[0] == 'first: first\nsecond: first'
    assert ret[1] == 'first: second\nsecond: second'

# Generated at 2022-06-22 14:25:53.679500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    display.verbosity = 4
    # Storing current stdout and stdin
    stdout_orig = sys.stdout
    stdin_orig = sys.stdin

    import io
    # Opening a file for reading and writing
    f = io.StringIO()
    # Set stdout to this file
    sys.stdout = f
    # Expected output
    msg = "the template file ./known_location.j2 could not be found for the lookup"
    # Calling method of class LookupModule
    terms = ['./known_location.j2']

# Generated at 2022-06-22 14:25:59.909192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init test object
    lookupModule = LookupModule()
    lookupModule._templar = None
    lookupModule._loader = None
    lookupModule.set_options = object
    lookupModule.get_option = object
    lookupModule.find_file_in_search_path = object
    lookupModule._loader._get_file_contents = object
    lookupModule._loader._get_file_contents = object
    lookupModule._loader.get_basedir = object
    lookupModule._loader._get_file_realpath = object

    # Test two elements
    terms = [1, 2]
    variables = {'ansible_search_path': '/tmp'}

# Generated at 2022-06-22 14:26:10.130238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test with deprecated options convert_data and jinja2_native
    convert_data = False
    jinja2_native = True
    terms = ['/path/to/template']
    lookup_template_vars = {}
    variables = {'ansible_search_path': ['/path/to/search']}
    options = dict(convert_data=convert_data,
                   jinja2_native=jinja2_native,
                   template_vars=lookup_template_vars)
    template_data = '{{ foo }}'
    with open(terms[0], 'w+') as f:
        f.write(template_data)
    searchpath = variables.get('ansible_search_path', [])

# Generated at 2022-06-22 14:26:12.754150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run(terms=['/etc/hosts'], variables=dict()) == [u'127.0.0.1\tlocalhost\n']

# Generated at 2022-06-22 14:26:21.298190
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    # Hack to load lookup plugin, it is usually done by Ansible during load
    from ansible.plugins import lookup_loader
    lookup_loader.get('template')

    # Create Host object
    host = Host('localhost')
    host.vars = dict()

    # Create VariableManager object
    variable_manager = VariableManager(loader=None, hosts=host)

    # Create LookupModule object
    my_lookup = LookupModule()
    my_lookup.set_loader(None)
    my_lookup._templar = variable_manager.get_loader()

    # Test normal call

# Generated at 2022-06-22 14:26:33.022146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = None # Dummy value
    templar = DummyTemplar()
    lookup = LookupModule(loader=DummyLoader(), basedir='/', templar=templar)

    assert lookup.run(terms=['test.j2'], variables=dict(a='A', b='B', c='C')) == ['A + B = C']
    assert lookup.run(terms=['test.j2'], variables=dict(a='A', b='B', c='C'), convert_data=False) == ['A + B = C']
    assert lookup.run(terms=['test.j2'], variables=dict(a='A', b='B', c='C'), convert_data=False,
                      jinja2_native=False) == ['A + B = C']

# Generated at 2022-06-22 14:26:43.780683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global display

    L = LookupModule()
    L.set_options(direct={'comment_start_string': '~[', 'comment_end_string': ']~'})

    assert L.run(['whoami.j2'],
                 dict(ansible_play_batch=['dummy'], ansible_play_hosts=['dummy'], group_names=['dummy']),
                 convert_data=False,
                 comment_start_string='~[',
                 comment_end_string=']~',
                 jinja2_native=False,
                 template_vars={},
                 variable_start_string='[[',
                 variable_end_string=']]') == ["dummy"]

    return True

# Generated at 2022-06-22 14:26:49.655756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """  test_LookupModule_run computes the list of free ports by looking at the content of /proc/sys/net/ipv4/ip_local_port_range file. """
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module.set_environment(None)
    lookup_module.set_vars(dict())

    terms = []
    terms.append("/proc/sys/net/ipv4/ip_local_port_range")
    variables = {}
    lookup_module.run(terms, variables)

# Generated at 2022-06-22 14:27:19.462226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["test_terms1", "test_terms2"]
    # Input variables
    variables = dict()
    variables['ansible_search_path'] = ["/my/search/path"]
    # Output variables
    output_variables = dict()
    # Test metadata
    metadata = dict()
    metadata['comment_end_string'] = None
    metadata['comment_start_string'] = None
    metadata['jinja2_native'] = False
    metadata['variable_end_string'] = None
    metadata['variable_start_string'] = None

    # Test 1: Case true
    try:
        lookup = LookupModule()
        lookup.set_loader()
        lookup.set_templar()
        result = lookup.run(terms, variables, **metadata)
    except AnsibleError as e:
        result = None



# Generated at 2022-06-22 14:27:30.825304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    class TestLookupModule(LookupModule):
        def get_option(self, option):
            if option == 'convert_data':
                return False
            if option == 'template_vars':
                return {}
            if option == 'jinja2_native':
                return False
            if option == 'variable_start_string':
                return '{{'
            if option == 'variable_end_string':
                return '}}'
            if option == 'comment_start_string':
                return '{#'
            if option == 'comment_end_string':
                return '#}'

    # Generate

# Generated at 2022-06-22 14:27:37.139996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = [{
      "_terms": [
        "{{inventory_hostname}}-{{inventory_hostname}}"
      ],
      "comment_end_string": "'''",
      "comment_start_string": "'''",
      "variable_end_string": "}}",
      "variable_start_string": "{{"
    }]
    loader = DictDataLoader({})
    env = Environment(loader=loader)
    lookup_plugin = LookupModule()
    for item in data:
        result = lookup_plugin.run(item['_terms'], TemplateVars(item))
        print(result)


# Generated at 2022-06-22 14:27:47.124518
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for run
    import pytest

    # Test case 1
    # pass a term to lookup

    terms = {
        'term': 'some_template.j2'
    }
    assert LookupModule().run(terms, variables={}, convert_data=False, comment_start_string=None, comment_end_string=None,
                              jinja2_native=False, template_vars={}, variable_start_string=None, variable_end_string=None) == range(0, 0)

    # Test case 2
    # pass a term to lookup

    terms = {
        'term': 'some_template.j2'
    }

# Generated at 2022-06-22 14:27:57.228848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar object
    templar = mock.MagicMock()
    # Create an object of LookupModule
    lookup_obj = LookupModule()
    # Mock the object
    lookup_obj._templar = templar
    # Define the value of parameter lookup_template_vars
    lookup_template_vars = dict()
    # Define the value of parameter convert_data
    convert_data_p = False
    # Define the value of parameter jinja2_native
    jinja2_native = False
    # Define the value of parameter variable_start_string
    variable_start_string = '{{'
    # Define the value of parameter variable_end_string
    variable_end_string = '}}'
    # Define the value of parameter comment_start_string
    comment

# Generated at 2022-06-22 14:28:08.499022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the deprecated convert_data option
    lookup = LookupModule()
    # This could fail if the file has a different content in the future.
    # We test the content of the file, not the name.
    assert lookup.run(["./test/test_lookup_template.j2"],
                      {'env': {'PATH': '.'},
                       'convert_data': False},
                      loader=None, templar=None, shared_loader_obj=None) == \
        ['CONVERT_DATA=False\n']

    # Test convert_data=False with jinja2_native=False
    lookup = LookupModule()

# Generated at 2022-06-22 14:28:21.362075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First create the module.
    lookup = LookupModule()
    # Create a variable dictionary with all the variables we want to test.
    variable_dict = dict()
    variable_dict["template_dir"] = 'templates'
    variable_dict["template_path"] = 'templates'
    variable_dict["ansible_search_path"] = 'templates'
    variable_dict["ansible_managed"] = 'Ansible managed'
    variable_dict["template_fullpath"] = '/tmp/some_template.j2'
    variable_dict["template_mtime"] = 'some time'
    variable_dict["template_uid"] = 'some user'
    variable_dict["template_hostname"] = 'some host'

# Generated at 2022-06-22 14:28:34.065424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    import tempfile
    import pytest
    from ansible.errors import AnsibleError
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    lookup_module = LookupModule()

    # Negative test for existence of requested file
    def mock_get_file_contents(file):
        raise AnsibleError('File does not exist')
    lookup_module._loader._get_file_contents = mock_get_file_contents
    with pytest.raises(AnsibleError) as exc:
        lookup_module.run(['/some/file'])
    assert exc.match('File does not exist')

    # Positive test - valid file exists
    fd, fd_name = tempfile.mk

# Generated at 2022-06-22 14:28:43.289133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import compile_template
    # 1. Create object:
    obj = LookupModule()

    # 2. Create arguments:
    terms = "./some_template.j2"
    lookups = {'timeout': 3}
    variables = {'_ansible_lookup_plugin': lookups}
    # 3. Call method:
    ret = obj.run(terms, variables)
    assert ret == [to_bytes((compile_template(terms, lookup_template_vars=lookups, escape_backslashes=False), True))]

# Generated at 2022-06-22 14:28:50.648837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(None, terms=["test.j2"],
                            variables={"var": "unittest_var", "var2": "unittest_var2"},
                            _templar=None, convert_data=True,
                            jinja2_native=False,
                            template_vars={"it_works": "yes"}) == \
           ['testing Jinja2 unittest_var {{ var2 }}\n']

# Generated at 2022-06-22 14:29:39.335897
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lu = LookupModule()
    class TempClass(object):

        def __init__(self):
            self.input = {
                'convert_data': True,
                'template_vars': {
                    "env": "test",
                    "version": "1.0"
                }
            }

        def get_option(self, option_name):
            return self.input[option_name]

    lu.set_options(var_options=TempClass())
    terms = ['test.j2']
    variables = {
        'lookup_file': 'lookup_plugin.py'
    }
    try:
        lu.run(terms, variables)
    except AnsibleError as e:
        assert "the template file test.j2 could not be found" in str(e)

# Generated at 2022-06-22 14:29:46.903382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    import sys
    import pytest

    try:
        from __main__ import display
    except ImportError:
        display = basic.AnsibleModule(argument_spec={})

    # Setup mock objects
    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    class MockAnsibleTemplar:
        def __init__(self):
            self.environment = 'foo'
            self.new_context = None
            self._available_variables = None
            self.vars = {}

        def set_available_variables(self, available_variables):
            self._available_variables = available_variables


# Generated at 2022-06-22 14:29:57.882377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types

    # Test the difference between using jinja templates and the lookup module.
    # A jinja template will convert to unicode YAML, while the lookup module
    # will leave the data alone unless convert_data=True is set.
    # Also, if the data is a string, it is assumed it is a path to a file
    # that contains the Jinja2 template.

# Generated at 2022-06-22 14:30:05.153154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test with jinja2_native=False , convert_data=False
    assert module.run(['/tmp/test.txt'], {},
                        variable_start_string='{{',
                        variable_end_string='}}',
                        convert_data=False,
                        jinja2_native=False
    ) == [to_bytes('\nstuff 1\nstuff 2\n')]



# Generated at 2022-06-22 14:30:17.195301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # define unit test data
    item1_path = '/path/to/item1'
    item2_path = '/path/to/item2'
    item1_content = 'my text is {{ foo }}\n'
    item2_content = "\nmy text is {{ bar }}"
    search_path = ['/path/to/search/path1', '/path/to/search/path2']

# Generated at 2022-06-22 14:30:18.705997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # TODO
    assert False

# Generated at 2022-06-22 14:30:31.099577
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test setup: create test data.
    test_name = 'lookup_plugin_template.j2'
    test_data = '''{
    "lookup_plugin_template": {
        "var1": "{{ var1 }}",
        "var2": [
            "{{ var2 }}",
            "{{ var2 }}"
        ],
        "var3": "{{ var3 }}"
    }
}'''

    # Test setup: create dummy class instance.
    class DummyClass:
        def __init__(self, test_name, test_data):
            self.test_name = test_name
            self.test_data = test_data
            self.test_data_bytes = to_bytes(test_data)
            self._data = {}
            self._data[test_name] = test_data

# Generated at 2022-06-22 14:30:43.960394
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test that checks that the templating works.
    # Create a jinja2 template, and process is with the lookup module.
    # Make sure that the templating works correctly.

    # Create the template
    template = 'This is a test: {{test}}'
    template_path = 'test_template.j2'
    template_file = open(template_path, 'w')
    template_file.write(template)
    template_file.close()

    task_vars = {'test': 'working'}
    # Create a LookupModule object
    lookup_module = LookupModule()
    # Call the run method of the LookupModule object
    results = lookup_module.run([template_path], task_vars)

    # Check that the results are as expected, ie: the template has been processed

# Generated at 2022-06-22 14:30:57.170193
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock classes needed by LookupModule method run
    class MyOptions(object):
        pass

    class MyVars(object):
        pass

    # first case:
    # jinja2_native is False and convert_data is False
    # nothing must be changed
    options1 = {"variable_start_string": '{{', "variable_end_string": '}}',
                "comment_start_string": '###', "comment_end_string": '###',
                "jinja2_native": False, "convert_data": False}

    vars1 = {"ansible_search_path": ['.']}

    terms1 = ["./test_files/test_data.j2"]

    lookup_template_vars1 = {}

    display1 = Display()
    templar1 = MyVars()
    templ

# Generated at 2022-06-22 14:31:10.039953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    import pytest

    # load dummy variables
    loader = DataLoader()
    variables = VariableManager()
    loader.set_basedir("")
    variables.set_vault_password("dummy_pass")
    variables.extra_vars = {'ansible_search_path': ['.']}

    # create lookup object
    lookup = LookupModule()
    lookup._loader = loader
    lookup._templar = loader.load_from_file('./plugins/lookup/templates/dummy_template.j2')

    # create lookup data
    lookup_data = ['./plugins/lookup/templates/dummy_template.j2']

    # test