

# Generated at 2022-06-22 14:22:27.455421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.vars import combine_vars

    lookup_module = LookupModule()
    res = lookup_module.run('foo', combine_vars(dict(), dict()), convert_data=True, jinja2_native=False)
    assert isinstance(res[0], str)

# Generated at 2022-06-22 14:22:33.983182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for below parameters:
    # terms="sometemplate.j2",
    # variables={},
    # convert_data=True,lookup_template_vars=dict(),
    # jinja2_native=True,variable_start_string='{{',
    # variable_end_string='}}',comment_start_string='{#',
    # comment_end_string='#}')
    import unittest
    import tempfile
    from ansible.constants import DEFAULT_TEMPLATE_FILE_ERRORS_STRATEGY
    from ansible.errors import AnsibleParserError, AnsibleUndefinedVariable, AnsibleLookupError
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from unit_tests.lookup_plugins.test_base import Lookup

# Generated at 2022-06-22 14:22:38.438877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms="./some_template.j2", variables={}, convert_data=False, jinja2_native=False,
                      variable_start_string="{{", variable_end_string="}}", template_vars={}) == ""
    assert lookup.run(terms="./some_template.j2", variables={}, convert_data=True, jinja2_native=False,
                      variable_start_string="{{", variable_end_string="}}", template_vars={}) == ""
    assert lookup.run(terms="./some_template.j2", variables={}, convert_data=False, jinja2_native=True,
                      variable_start_string="{{", variable_end_string="}}", template_vars={}) == ""
    assert lookup.run

# Generated at 2022-06-22 14:22:46.622896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ['./some_template.j2']
    variables = {'hostvars': 'hostvars'}
    lookup_base = LookupModule()
    lookup_base.set_loader('sample loader')
    lookup_base.set_templar('sample templar')
    lookup_base.set_environment('sample env')

    # Act
    actual_output = lookup_base.run(terms, variables)

    # Assert
    assert actual_output == ['Some template template']

# Generated at 2022-06-22 14:22:59.374094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader

    fixture_path = os.path.join(os.path.dirname(__file__), '../fixtures/lookup_plugins')
    # Load data into local DataLoader.
    loader = DataLoader()
    loader.set_basedir(fixture_path)

    # Load inventory into local InventoryManager.
    inventory = InventoryManager(loader=loader, sources='localhost')

    # Load Play context into local Play.

# Generated at 2022-06-22 14:23:06.808772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LUM = LookupModule()
    LUM.set_loader_context(dict(basedir='/does/not/matter'))
    LUM.set_templar(AnsibleEnvironment())
    # run returns a list -> first element
    res = LUM.run(terms=['test_template.j2'], variables=dict())[0]
    assert res == 'foo=1\nbar=2\n'

# Generated at 2022-06-22 14:23:18.838761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # test method run with arguments
    module.run(terms=['{{ ansible_system }}'], variables={'ansible_system': 'Linux'})
    # test method run without arguments
    module.run()
    # test method run with unexpected keyword argument
    with pytest.raises(AnsibleParserError) as excinfo:
        module.run(unexpected_keyword_arg='unexpected_keyword_arg')
    assert 'unexpected keyword argument \"unexpected_keyword_arg\" to lookup plugin' in str(excinfo.value)
    # test method run with _templar
    module._templar = Templar(variables = dict(ansible_system='Linux'), loader=DictDataLoader({}))
    module.run(terms=['{{ ansible_system }}'])

# Generated at 2022-06-22 14:23:30.330256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    display = Display()
    templar = Templar(loader=DataLoader(), variables=VariableManager(),
                      shared_loader_obj=None, fail_on_undefined=True)

    terms = ['./some_template.j2']

    # vars

# Generated at 2022-06-22 14:23:42.871222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    import tempfile

    from ansible.plugins.lookup import LookupModule
    from ansible.template import AnsibleEnvironment

    # Create temporary files and folders for testing
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    temp_file.write('''
{% for i in range(5) %}
- {{ i }}
{% endfor %}
''')
    temp_file.close()

    # Create ansible variables
    ansible_search_path = [temp_dir]

# Generated at 2022-06-22 14:23:54.585551
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule_run = LookupModule()

    # Setup variables

# Generated at 2022-06-22 14:24:11.756012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # -- class LookupModule:
    # create instance
    args = dict()
    lm = LookupModule(**args)

    # test method: run
    ############################################################################
    # test example one
    ############################################################################
    # test data
    td1 = dict(
        terms='./some_template.j2',
        variables={"key1": "value1"},
        kwargs={},
        expected=[],
    )
    td1["expected"].append("{{ lookup('template', './some_template.j2') }}")
    
    # run method
    res1 = lm.run(**td1)

    # assert
    assert res1 == td1["expected"]

    ############################################################################
    # test example two
    ############################################################################
    # test data
   

# Generated at 2022-06-22 14:24:19.788850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleUnicode

    lookup_module = LookupModule()
    lookup_module.set_loader()
    lookup_module.set_environment(environment=None, variables=ImmutableDict({"test0": "test1"}))

    with pytest.raises(AnsibleError) as error:
        lookup_module.run(["test1"], {})

    assert error.match("the template file test1 could not be found for the lookup")

    with pytest.raises(AnsibleError) as error:
        lookup_module.run(["unittest_template.j2"], {})


# Generated at 2022-06-22 14:24:30.884846
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock object for the templar object
    mock_jinja2_templar = MagicMock()
    mock_jinja2_templar.template.return_value = 'This is a test message'

    # create a mock object for the _loader object
    mock_loader = MagicMock()
    mock_loader._get_file_contents.return_value = ('', b'/tmp/test')

    # create a mock object for the display object
    mock_display = MagicMock()
    mock_display.debug = MagicMock()
    mock_display.vvvv = MagicMock()

    # create a mock object for the find_file_in_search_path object
    mock_find_file_in_search_path = MagicMock()
    mock_find_file_in_search_path.return_

# Generated at 2022-06-22 14:24:43.873467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    import mock
    import sys
    import yaml
    from ansible.vars.unsafe_proxy import AnsibleVars
    from ansible.vars.unsafe_proxy import wrap_var

    lookup_base = LookupBase()
    lookup_base._templar = mock.MagicMock()
    lookup_base._loader = mock.MagicMock()
    lookup_base._loader._get_file_contents = mock.MagicMock(return_value=('{{ test1 }}', ''))
    templar = mock.MagicMock()
    templar.template.return_value = 'Test'
    lookup_base._templar.copy_with_new_env().set_available_variables.return_value.__enter__.return_value = templar
    lookup_base.find_

# Generated at 2022-06-22 14:24:57.013184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run() takes a single argument, the name of the YAML file with the test definition.
    import pytest
    import yaml
    # Load test parameters from YAML file
    test_data = None
    with open(__file__+'.yaml') as yaml_file:
        # pytest will throw an exception in the yaml.load() method if the file content is invalid.
        test_data = yaml.load(yaml_file)
    if test_data is None:
        raise Exception("test_data is None")
    # Iterate over the test cases
    for test_case_name, test_case in test_data['test_cases'].items():
        # Create a LookupModule object
        lookup_module = LookupModule()
        # Create an empty variables dictionary

# Generated at 2022-06-22 14:25:03.634489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(
        ['./templates/notfound.j2', 1, './templates/found.j2', './templates/found.j2'],
        {}
    )
    assert isinstance(result, list)
    assert result[0] == "hello world"
    assert result[1] == "hello world"
    assert result[2] == "hello world"
    assert result[3] == "hello world"

# Generated at 2022-06-22 14:25:08.447453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    # Initialise object
    l = LookupModule()
    l._templar = AnsibleEnvironment()
    l.set_loader(None)
    # Set test input
    run_test_input = {'_raw': ["./some_template.j2"]}
    # Expected result
    run_test_output = ["./some_template.j2"]
    # Actual result
    actual_result = l.run(["./some_template.j2"], None)
    # Unit Test assertion
    assert actual_result == run_test_output

# Generated at 2022-06-22 14:25:11.878515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = ['tests/lookup_plugins/templates/foo.j2']
    variables = dict()

    result = lookup.run(terms, variables)

    assert result[0] == "foo!"

# Generated at 2022-06-22 14:25:21.151140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # We don't need to run these tests repeatedly.
    if os.path.exists('/tmp/lookup_test'):
        return

    os.makedirs('/tmp/lookup_test')
    os.makedirs('/tmp/lookup_test/templates')
    with open('/tmp/lookup_test/templates/foo.j2', 'w') as f:
        f.write('foobar\n')
    with open('/tmp/lookup_test/templates/bar.j2', 'w') as f:
        f.write('{{ var }}\n')
    with open('/tmp/lookup_test/templates/baz.j2', 'w') as f:
        f.write('{{ var }}\n')

# Generated at 2022-06-22 14:25:26.189825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   ret = LookupModule.run(None, ['/home/ansible/ansible-examples/files/ansible.cfg'], variable_start_string='[%', variable_end_string='%]')
   assert(ret[0] == '''[% foo %]''')


# Generated at 2022-06-22 14:25:43.052749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["../../plugins/lookup/test/data/test_template.j2"]
    variables = {"ansible_search_path": ["../../plugins/lookup/test/data"]}
    lookup_template_vars = {"character": "Kilroy", "place": "was here"}
    try:
        content = LookupModule().run(terms, variables, template_vars=lookup_template_vars)
    except AnsibleError as e:
        raise AssertionError("Unexpected AnsibleError: {0}".format(e))
    assert content == ['Kilroy was here', '\n'], (
        "Result: {0}".format(content)
    )

# Generated at 2022-06-22 14:25:54.230764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy class for unit test case
    class DummyLoader(object):
        def get_basedir(self, *args, **kwargs):
            return os.path.dirname(__file__)

    # Dummy class for unit test case
    class DummyVars(object):
        variables = {
            "template_path": os.path.join(os.path.dirname(__file__), 'test_templates')
        }

        def get(self, *args, **kwargs):
            return self.variables.get(*args, **kwargs)

    # Dummy class for unit test case
    class DummyTemplar(object):
        def copy_with_new_env(self, *args, **kwargs):
            return DummyTemplar()


# Generated at 2022-06-22 14:26:05.647620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # path_of_this_file would be the path of this file, i.e.,
    # ansible/plugins/lookup/template.py.
    path_of_this_file = os.path.realpath(__file__)
    # dir_of_this_file would be the directory containing this file, i.e.,
    # ansible/plugins/lookup.
    dir_of_this_file = os.path.dirname(path_of_this_file)
    test_file = os.path.join(dir_of_this_file, "test_template.py")

# Generated at 2022-06-22 14:26:08.658725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert LookupModule.run("f", "v", _templar=None, loader=None) == []

# Generated at 2022-06-22 14:26:09.715455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-22 14:26:19.247765
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.constants import DEFAULT_TEMPLATE_ENGINE
    from ansible.template import Templar

    # This will only work if DEFAULT_TEMPLATE_ENGINE is set to 'jinja2'
    if not USE_JINJA2_NATIVE:
        return

    templar = Templar(loader=None, variables=dict())

    display = Display()

    l = LookupModule(templar=templar, loader=None, display=display)
    l._templar = templar
    l.set_options(var_options=dict(), direct=dict())

    # General
    assert type(l.run(terms=['test'], variables=dict())) is list
    assert len(l.run(terms=['test'], variables=dict())) == 1
    assert 'test'

# Generated at 2022-06-22 14:26:31.326605
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # initialize test class
    ansible_options = {'module_path': os.path.join(os.path.dirname(__file__), '../../'),
                       'connection': 'local',
                       'forks': 10,
                       'become': None,
                       'become_method': None,
                       'become_user': None,
                       'check': False,
                       'diff': False}

    display_options = {'verbosity': 0}

    # initialize test class
    lookupbase = LookupModule(display=Display(options=display_options))

    # set some variables
    variables_mock = {'testvar': 'testval'}
    lookupbase._templar.available_variables = variables_mock
    lookupbase._display = Display(options=display_options)
    lookupbase.set_options

# Generated at 2022-06-22 14:26:33.823906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([], {}) == []

# Generated at 2022-06-22 14:26:45.365846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.template import generate_ansible_template_vars
    from ansible.utils.native_jinja import NativeJinjaText

    class Options(object):
        convert_data = False
        jinja2_native = False
        lookup_template_vars = {}
        comment_start_string = '#'
        comment_end_string = '#'
        variable_start_string = '{{'
        variable_end_string = '}}'

    searchpath_dir = os.path.dirname(os.path.abspath(__file__))
    if not os.path.exists(os.path.join(searchpath_dir, "templates")):
        os.makedirs(os.path.join(searchpath_dir, "templates"))

# Generated at 2022-06-22 14:26:57.373713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_vars = dict()
    ansible_vars['my_var'] = {
        'a_string': 'this is a string',
        'a_integer': 1337,
        'a_float': 3.14159265,
        'a_boolean': True
    }
    ansible_vars['null_var'] = None
    ansible_vars['a_list'] = [
        'this is a string',
        1337,
        3.14159265,
        True,
        None
    ]

# Generated at 2022-06-22 14:27:29.451713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First test: fail to find the template file
    lookup = LookupModule()
    terms = ['non_existent_file.txt']
    variables = {}
    try:
        result = lookup.run(terms, variables)
    except AnsibleError as e:
        if 'missing' in str(e):
            print("Test 1 passed.")
        else:
            print("Test 1 failed.")
    else:
        print("Test 1 failed.")

    # Second test: simple template file
    test_dir = os.path.dirname(__file__)
    lookup = LookupModule()
    terms = ['simple_template.txt']
    variables = {'var': 'value'}
    result = lookup.run(terms, variables)
    if result == [u'value']:
        print("Test 2 passed.")

# Generated at 2022-06-22 14:27:37.439455
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test LookupModule.run(terms, variables, **kwargs)
    # We do not test all possible variants of this method,
    # it would be too much work and it is covered by Ansible itself.

    # Test the method run with invalid parameters
    assert LookupModule(basedir='.', runner=None, templar=None).run(
        terms=None, variables=dict(), convert_data=None,
        lookup_template_vars=None, jinja2_native=None,
        variable_start_string=None, variable_end_string=None,
        comment_start_string=None, comment_end_string=None) == []

    # Test the method run with a valid parameter,
    # but for a template file which does not exist

# Generated at 2022-06-22 14:27:47.212185
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    templar = VariableManager()

    lookupModule = LookupModule()
    lookupModule._templar = templar
    lookupModule._loader = loader

    # we use the file list module as a template
    terms = [
        '../../../lookup_plugins/file_list.py'
    ]
    result = lookupModule.run(terms=terms, variables={"template_dir":""})

    assert type(result) == list

# Generated at 2022-06-22 14:27:57.334247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup for testing
    import sys

    # test with non-exist j2 file
    non_exist_j2_file_path = 'non_exist_j2_file.j2'
    display.debug("File lookup term: %s" % non_exist_j2_file_path)

    terms = [non_exist_j2_file_path]
    variables = {}

    lookup = LookupModule()
    lookup.set_loader()
    try:
        result = lookup.run(terms, variables, convert_data=True)
        # test failed if no exception raised
        assert False
    except AnsibleError:
        # test passed
        pass


    # test with exist j2 file
    terms = ['test.j2']
    lookup = LookupModule()
    lookup.set_loader()
    result = lookup

# Generated at 2022-06-22 14:28:08.596730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    # Tests for method run of class LookupModule when lookup_template_vars is 'None'
    #
    # This is the only code path tested here because the other code paths in the method
    # either call system code or raise errors.  If the changes to the other code paths
    # need to be tested, then additional parameters for the run method will need to be
    # added to the test fixture and other tests will need to be added.
    #
    # Some of these tests will raise errors within the lookup plugin itself.  In those
    # cases, they will be caught and re-raised as an ansible.errors.AnsibleError.  This
    # happens because the lookup plugins are not designed to be called directly.  Instead,
    # they are called indirectly through the template plugin which is the plugin that

# Generated at 2022-06-22 14:28:21.360530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os, shutil, sys
    import jinja2

    cur_dir_path = os.path.dirname(os.path.abspath(__file__))
    # Create a tmp dir for testing
    tmp_dir_path = os.path.join(cur_dir_path, '..', 'tmp')
    try:
        shutil.rmtree(tmp_dir_path)
    except Exception as e:
        print(e)
    os.makedirs(tmp_dir_path)

    # inject variables for test_data

# Generated at 2022-06-22 14:28:32.364878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Lookup term should not be found
    terms = ['./NotHere']
    variables = {}
    result = lookup.run(terms, variables, convert_data=False)
    assert result[0] == './NotHere'

    # Lookup term should be found.
    # TODO: Need a way to get fixtures path here, or need to move this test file into a
    #       test directory and create a test file there.
    #terms = ['./files/template.j2']
    #variables = {}
    #result = lookup.run(terms, variables, convert_data=False)
    #assert result[0] == 'I am a lookup result.\n'

# Generated at 2022-06-22 14:28:38.355627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_class = LookupModule
    templar = None
    loader = None
    basedir = None
    adapter = None

    lookup_instance = lookup_class()
    lookup_instance._templar = templar
    lookup_instance._loader = loader
    lookup_instance.basedir = basedir
    lookup_instance.adapter = adapter

    # Test
    terms = []
    variables = {}
    kwargs = {}
    res = lookup_instance.run(terms, variables, **kwargs)
    assert res == []

    # Test
    terms = ['../']
    variables = {}
    kwargs = {}
    res = lookup_instance.run(terms, variables, **kwargs)
    assert res == []

    # Test
    terms = ['../', '../']
    variables = {}

# Generated at 2022-06-22 14:28:51.256394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test simple term
    terms = ['test.j2']
    task_vars = dict(
        test_var_1='test-value-1',
        test_var_2='test-value-2',
        test_var_3='test-value-3'
    )
    # test jinja2_native=True
    assert LookupModule.run(LookupModule(), terms, task_vars, variable_start_string='[%', variable_end_string='%]',
                            jinja2_native=True, convert_data=False)[0].strip() == '[% test_var_1 %]'
    # test jinja2_native=False

# Generated at 2022-06-22 14:29:03.374452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils._text import to_bytes, to_text

    class FakeVars(object):
        def __init__(self, vars):
            self.vars = vars
        def get(self, var, default=None):
            return self.vars.get(var, default)

    class FakeTemplate(object):
        def __init__(self, template_data, template_vars, variable_start_string, variable_end_string,
                     searchpath, convert_data_p):
            self.template_data = template_data
            self.template_vars = template_vars
            self.variable_start_string = variable_start_string

# Generated at 2022-06-22 14:29:55.990830
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.set_options(_direct={'template_vars': {'foo': 1}})

    search_path = ['tests/test_lookup_plugins/templates']
    templar = DummyTemplar(searchpath=search_path)
    lookup._templar = templar

    # the templar needs to have the ansible_search_path variable set or else the lookup will fail
    templar.available_variables['ansible_search_path'] = search_path

    # the templar needs to have the template_path variable set or else the lookup will fail
    templar.available_variables['template_path'] = 'dummy_template_path'

    # the lookup_file will not actually be read
    file_contents = b'This is a test'



# Generated at 2022-06-22 14:30:00.522919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule = LookupModule()
    terms = ['foo']
    variables = {'ansible_search_path': ['a', 'b']}
    options = {}
    result = lookupmodule.run(terms, variables, **options)
    print(result)

# Generated at 2022-06-22 14:30:12.208919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    from jinja2 import Template
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.utils.display import Display
    import pytest

    lookup_module = LookupModule()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'sample_var': 'sample_value',
    }

    display = Display()
    lookup_module._display = display

    inventory = Inventory(
        loader=DataLoader(),
        variable_manager=variable_manager,
        host_list=['localhost']
    )
    variable_manager.set_inventory(inventory)

    # make a temp directory to be used for the template
    # make sure it will be removed after the test

# Generated at 2022-06-22 14:30:22.503512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.compat import json

    # In order to use the lookup module 'template', we need to emulate the
    # Ansible environment

    # Create a new instance of LookupModule
    module = lookup_loader.get('template', class_only=True)()

    # Create a mock templar
    template_variable_start_string = '{{'
    template_variable_end_string = '}}'
    templar = mock.MagicMock()
    templar.environment.variable_start_string = template_variable_start_string
    templar.environment.variable_end_string = template_variable_end_string

# Generated at 2022-06-22 14:30:33.538214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Needed to create a templar object
    import jinja2
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup_templar = jinja2.Environment(variable_start_string="{",
                                        variable_end_string="}",
                                        loader=jinja2.FileSystemLoader(os.path.dirname(__file__)))

    test_loader = DataLoader()

    test_variable_manager = VariableManager(loader=test_loader, templar=lookup_templar)

    test_lookup = LookupModule()
    test_lookup._loader = test_loader
    test_lookup._templar = lookup_templar
    template_vars = {}
    convert_data = False
   

# Generated at 2022-06-22 14:30:43.142990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import BytesIO
    from ansible.config.manager import ConfigManager
    from ansible.template import Templar

    ConfigManager()

    lookup = LookupModule()
    lookup.set_loader(InMemoryVault())

    lookup_result = lookup.run(['test.j2'], {'lookup_file': 'lookup_fixture.yml'}, variable_start_string='[', variable_end_string=']')

    assert lookup_result[0] == BytesIO(b'hi\n')



# Generated at 2022-06-22 14:30:57.081159
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing with a simple template
    module = LookupModule()
    lookupfile = '/home/ansible/playbook/vars/var1.j2'
    template_data = '{{ filename }}'
    vars = {}
    vars['filename'] = lookupfile
    res = module.run(terms=[lookupfile], variables=vars)
    assert res == ['var1.j2']

    # Testing with a basic jinja-style comment (sanity check)
    #module = LookupModule()
    #lookupfile = '/home/ansible/playbook/vars/var1.j2'
    #template_data = '{{ filename }} {# this is a comment #}'
    #vars = {}
    #vars['filename'] = lookupfile
    #res = module.run(terms=[lookup

# Generated at 2022-06-22 14:31:09.958852
# Unit test for method run of class LookupModule
def test_LookupModule_run():  # pylint: disable=invalid-name
    """
    Unit test for method run of class LookupModule.

    Returns:
      None

    Raises:
      AssertionError if any of the tests fail
    """
    from ansible.plugins.lookup.__init__ import LookupModule, LookupBase
    import os
    import io

    module_name = 'template'  # pylint: disable=invalid-name
    args = [os.path.join(os.path.dirname(os.path.abspath(__file__)), 'testfile_jinja_vars.j2')]

    display = Display()
    display.verbosity = 4

    # Create a temporary copy of add_host.yml so that we can use it in the
    # tests.

# Generated at 2022-06-22 14:31:12.280320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([], {}, {}) == []

# Generated at 2022-06-22 14:31:20.086351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the return value of run method of LookupModule
    template_data = 'hello {{ lookup_var_name }}'
    lookup_var_name = 'world'
    res = LookupModule().run(terms=['test.txt'],
            variables={'lookup_var_name': lookup_var_name, 'ansible_search_path': [os.getcwd()]},
            convert_data=True)
    assert res == ['hello world']