

# Generated at 2022-06-22 14:22:26.112371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock variables to be used
    class MockVars:
        ansible_search_path = ["/some/ansible/search/path"]

    def mock_method(a):
        return "/some/ansible/search/path/templates"

    # Create mock items to be used
    class MockItem:
        _loader_mock = Mock()
        _loader_mock.get_basedir.return_value = "./test/path"
        _loader_mock._get_file_contents = mock_method

        def __init__(self, loader, *a, **kw):
            self._loader = loader

    # Create mock templar to be used
    class MockTemplar:
        def __init__(self, *a, **kw):
            pass


# Generated at 2022-06-22 14:22:38.303359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # A test case to test the run() method of the LookupModule class
    test_cases = [
        {
            'desc': 'Test the method run()',
            'terms': ['./some_template.j2'],
            'variables': {'file_lookup_paths': ['/home/user/files/']},
            'kwargs': {},
            'result': ['This is a test string for the template']
        }
    ]
    for test_case in test_cases:
        description = test_case.get('desc')
        result = test_case.get('result')
        kwargs = test_case.get('kwargs')
        variables = test_case.get('variables')
        terms = test_case.get('terms')

# Generated at 2022-06-22 14:22:50.953179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_self = LookupModule()

    # 1st call, terms = ['some_template.j2']
    mock_self.set_options = MagicMock()
    mock_self.get_option = MagicMock(return_value='{{filename}}')
    mock_self.find_file_in_search_path = MagicMock(return_value='/home/user/some_template.j2')
    mock_self._loader = MagicMock()
    mock_self._loader._get_file_contents = MagicMock(return_value=('some_template.j2', True))
    mock_self._templar = MagicMock()
    mock_self._templar.copy_with_new_env = MagicMock()

# Generated at 2022-06-22 14:23:03.835969
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Regression test for Issue #25762
    try:
        from __main__ import display
    except ImportError:
        display = None

    class MockTemplar:
        def __init__(self):
            self._available_variables = {}
            self._search_path = []
            self._template_path = []
            self._data = None
            self.converted_data = None
            self._variable_start_string = '{{'
            self._variable_end_string = '}}'

        def copy_with_new_env(self, environment_class):
            pass


# Generated at 2022-06-22 14:23:05.684802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tester = LookupModule()

# Generated at 2022-06-22 14:23:11.830004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    # Test the basic run-method functionality
    terms = ['test1']
    variables = {}
    ret = lu.run(terms, variables, **{})
    assert ret == ['test1']

    # Test the run method functionality with a random search_path
    terms = ['test1']
    variables = {'ansible_search_path': ['test2', 'test3', 'test4']}
    ret = lu.run(terms, variables, **{})
    assert ret == ['test1']

    # Test the run method functionality with non-existing file
    terms = ['non_existent_file.j2']
    variables = {}
    try:
        lu.run(terms, variables, **{})
    except:
        ret = True
    assert ret == True

# Generated at 2022-06-22 14:23:25.223681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    import os

    # Test 1
    # When the template is not found raise AnsibleError
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = Mapping()
    variable_manager.options_vars = Mapping()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-22 14:23:37.698876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Suggestion: integrate similar unit tests into test/units/plugins/lookup/test_template.py.
    display = Display()

    # Prepare argument "terms".
    term = 'this_is_a_template_file.j2'
    terms = [term]

    # Prepare argument "variables".
    variables = {'root': '/', 'nested': {'a': '1', 'b': '2'}, 'ansible_search_path': './ansible_search_path',
                 'template_path': './ansible_search_path', 'template_mtime': '2019-11-29T15:02:27.170000Z'}

    # Prepare argument "kwargs".

# Generated at 2022-06-22 14:23:49.065510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # text_for_test_jinja2 contains Jinja2 reserved chars and python reserved chars.
    text_for_test_jinja2 = "{{'{()}'}}"
    text_for_test_jinja2_utf8 = text_for_test_jinja2.encode('utf-8')
    mock_file_contents = text_for_test_jinja2_utf8
    mock_file_loader = MockFileLoader(mock_file_contents)
    module = LookupModule()

    converted_result_bytes = b"{'{()}'}"
    converted_result_text = converted_result_bytes.decode('utf-8')

    # test native_jinja2 is True
    module.set_loader(mock_file_loader)

# Generated at 2022-06-22 14:23:57.603685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    hostvars = dict()
    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory, host_vars=hostvars)
    play_context = dict(
        become=False, become_method='sudo', become_user='root', check_mode=False, diff=False
    )


# Generated at 2022-06-22 14:24:08.359023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-22 14:24:18.166768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup = LookupModule()
    class Options(dict):
        """
        Dummy class for options
        """
        def __getattr__(self, attr):
            """
            Make sure attribute access works
            """
            return self[attr]
    templar = Options()
    templar.environment = Options()
    templar.environment.native_vars = Options()
    templar.environment.searchpath = Options()
    templar.opts = Options()
    templar.opts.jinja2_native = True
    lookup._templar = templar
    lookup.set_loader()

    data = "{{ '{{ test' }} }}"

    # test jinja2_native is false and convert_data

# Generated at 2022-06-22 14:24:29.755818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: The tests for module_utils.template.AnsibleEnvironment.from_module_vars and
    # from_module_vars_to_template_vars are in test_template

    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.template import generate_ansible_template_vars, USE_JINJA2_NATIVE

    if USE_JINJA2_NATIVE and not pytest.config.option.jinja2_native:
        pytest.skip('Test only relevant with jinja2_native')

    # test that all the variables passed into the template are available when Jinja2 is in native mode

# Generated at 2022-06-22 14:24:36.522253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = './some_template.j2'
    variables = {}
    lookup_module = LookupModule()
    lookup_module.set_loader(0)
    lookup_module.set_templar(0)
    lookup_module.set_environment_aware(0)
    assert lookup_module.run(terms, variables) == [u'\n']

# Generated at 2022-06-22 14:24:38.655701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['./some_template.j2']) == []

# Generated at 2022-06-22 14:24:47.747694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Load data for the run method of LookupModule
    display = Display()
    terms = ['term1', 'term2']
    variables = {'ansible_search_path': ['/home/user/ansible']}
    kwargs = {'convert_data': False, 'template_vars': {}, 'jinja2_native': False, 'variable_start_string': '{{',
              'variable_end_string': '}}', 'comment_start_string': None, 'direct': {}}
    # ToDo: Create an instance of the target class
    obj = LookupModule()
    # ToDo: Create and return the result of the unit test
    ret = obj.run(terms, variables, **kwargs)
    # ToDo: Assert that the result is correct
    assert ret == []

# Generated at 2022-06-22 14:24:51.350019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    # TODO: add tests

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-22 14:25:00.903288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Setup test environment
    lookup = LookupModule()
    variables = {u'ansible_lookup_plugins': ['/tmp/ansible_lookup_plugins', u'/home/user/.ansible/plugins/lookup'],
                 u'ansible_playbook_python': u'/usr/bin/python', u'ansible_syslog_facility': u'LOG_USER',
                 u'ansible_verbosity': u'1'}
    templar = Templar(variables=variables)
    lookup._templar = templar

    # Test execution
    terms = ['test.j2']
    kwargs = {}

# Generated at 2022-06-22 14:25:12.584868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # test when the file could not be found
    try:
        lm.run(['/path/to/non-existent/file'],{})
        assert False
    except AnsibleError as e:
        assert "could not be found" in str(e)
    # test jinja2_native=false
    lm = LookupModule()
    output = lm.run(['./test_data/hello.j2'],
            {'name': 'Mr. Smith', 'num_guests': 10, 'greeting': 'Hello'},
            jinja2_native=False)
    assert output == ['Hello Mr. Smith, you have 10 guests coming.']
    # test jinja2_native=true
    lm = LookupModule()

# Generated at 2022-06-22 14:25:20.510093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.template import LookupModule
    lookup_template = LookupModule()
    template_dir = os.path.dirname(os.path.realpath(__file__))
    variables = {'template_dir': template_dir, 'test_var': 'test_value'}
    template_file = os.path.join(template_dir, 'test_template.j2')
    ret = lookup_template.run([template_file], variables, convert_data=False,
                              template_vars={'template_data_var1': 'template_data_value1'})
    assert ret == ['template_data_value1 test_value']

# Generated at 2022-06-22 14:25:40.635195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import PY3

    env = {
        'TMPDIR': '/tmp',
        'TMP': '/tmp',
        'TEMP': '/tmp',
    }


# Generated at 2022-06-22 14:25:53.201470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def check_result(lookup_mod, expected_result):
        import os
        import sys
        import tempfile

        if not os.path.exists(expected_result):
            raise AssertionError('file %s does not exist' % expected_result)

        fd, tmpfile = tempfile.mkstemp(suffix='.j2', text=True)
        with os.fdopen(fd, 'w') as f:
            f.write(expected_result)

        src = tmpfile
        expected_result = open(src, 'r').read()
        result = lookup_mod.run([src], dict(VAR1='A', VAR2='B', VAR3='C'))[0]
        assert result == expected_result

        os.remove(tmpfile)

    # Check that template file is being processed

# Generated at 2022-06-22 14:26:03.105933
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.lookup.template

    # Create LookupModule object
    lm = ansible.plugins.lookup.template.LookupModule()

    # generate string
    t = "{{ fake }}"
    # add to terms
    terms = [t]
    # generate dictionary
    d = {"lookup_template_vars": ""}
    # add to variables
    variables = d
    # generate dictionary
    k = {"convert_data": "False"}
    # add to kwargs
    kwargs = k

    # call method run
    lm.run(terms, variables, **kwargs)



# Generated at 2022-06-22 14:26:14.968698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init module config and lookup
    lookup = LookupModule()
    lookup._load_name = 'template'

    # Init config and templar for lookup
    variables = dict(
        foo = 'bar',
        bar = dict(
            baz = 'foo',
            bas = dict(
                foobar = 'barfoo',
            ),
        ),
    )
    config = dict(
        variable_start_string = '{{',
        variable_end_string = '}}',
    )
    templar = Templar(loader=None, variables=variables, **config)
    lookup._templar = templar

    # Template file with vars

# Generated at 2022-06-22 14:26:22.559855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from jinja2.environment import Environment as JinjaEnvironment
    from jinja2 import Undefined as JinjaUndefined

    # Jinja2 native types, jinja2_native=True
    jinja2_native_p = True
    lookup_options = {}
    lookup_options['jinja2_native'] = jinja2_native_p

    # Template data (the file content)
    template_data = """
    {% if x is defined %}
{{x}}
{% else %}
{{ y }}
{% endif %}
    """

    # Jinja2 environment
    jinja2_env = JinjaEnvironment()

    # Jinja2 undefined object
    jinja2_undefined = JinjaUndefined()

    # Ansible variables
    ansible_vars = {}

# Generated at 2022-06-22 14:26:33.923898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    from ansible.template import AnsibleEnvironment
    #lookup = LookupModule(None)
    #assert False
    try:
        lookup = LookupModule(None)
        assert lookup
        result = lookup.run(['invalid_file'], {}, convert_data=False, template_vars={}, jinja2_native=False)
        result = lookup.run([], {}, convert_data=False, template_vars={}, jinja2_native=False)
        assert False
    except AnsibleError as ex:
        assert str(ex) == 'the template file invalid_file could not be found for the lookup'

# Generated at 2022-06-22 14:26:45.464236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test as it was before refactoring
    terms = ["file1","file2","file3"]
    variables = {}
    lup = LookupModule()

    def mock_find_file_in_search_path(v, dirname, term):
        return term

    def mock_template(template_data, convert_data, preserve_trailing_newlines, escape_backslashes):
        return template_data

    def mock_set_temporary_context(variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables, searchpath):
        return None


# Generated at 2022-06-22 14:26:57.484063
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock variables
    _loader = None
    _templar = None
    _display = None
    _options = None

    # Mock methods
    def get_option(option_name, default=None):
        if option_name == 'convert_data':
            return True
        return default

    terms = ['foo.bar']

    variables = {
        'ansible_los': [
            'Linux',
            'Mio',
            'Fish'
        ],
        'search_path': [
            '.',
            'local',
            'other'
        ]
    }

    # Mock and patch class LookupModule
    lookup_module = LookupModule(_loader=_loader, _templar=_templar, _display=_display)

# Generated at 2022-06-22 14:27:00.521473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    terms = ['/some/file.j2']
    variables = {}

    result = lookup.run(terms, variables)

    assert result == ['/some/file.j2']

# Generated at 2022-06-22 14:27:07.380562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_loader(DictDataLoader({
        "test.yml": "key: {{ lookup('env', 'HOME') }}",
        "test.j2": "key: {{ lookup('env', 'HOME') }}",
        "test.txt": "key: {{ lookup('env', 'HOME') }}",
    }))
    assert l.run(["test.txt"], {"home": "/home/test"}) == [u"key: /home/test"]
    assert l.run(["test.txt"], {"ansible_search_path": ["."]}) == [u"key: /home/test"]

# Generated at 2022-06-22 14:27:35.419747
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeVars(object):
        def __init__(self):
            self.module_name = "FakeVars"

        def get(self, key, default=None):
            if key == 'ansible_search_path':
                return ['/test/', '/test/test/']

    class FakeLoader(object):
        def __init__(self):
            self.module_name = "FakeLoader"

        def _get_file_contents(self, path):
            if path == '/test/templates/fakefile':
                return to_bytes('{{ searchpath }}'), None
            elif path == '/test/test/templates/fakefile':
                return to_bytes('{{ lookup("template", "templatefile") }}'), None

# Generated at 2022-06-22 14:27:44.946159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    test_terms = ['test_subclass.j2']
    test_variables = {'env': {'region': 'us-east-1'}}
    test_options = {'variable_start_string': '{{', 'variable_end_string': '}}',
                    'comment_start_string': '{#', 'comment_end_string': '#}'}
    test_expected_result = '[region = us-east-1]\n'
    assert test_expected_result == lm.run(test_terms, test_variables, **test_options)[0]

# Generated at 2022-06-22 14:27:46.623157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-22 14:27:57.265129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.template import AnsibleTemplate

    module = LookupModule()

    class DummyVars(object):
        def __init__(self):
            self.data = {
                "ansible_search_path": [
                    "/etc/ansible/roles/role1",
                    "/etc/ansible/roles/role2"
                ]
            }
        def get(self, key, default):
            return self.data[key] if key in self.data else default

    class DummyTemplar(object):
        def __init__(self):
            self.variables = {}
        def push_scope(self):
            self.variables.update({})
        def pop_scope(self):
            self.variables.pop()

# Generated at 2022-06-22 14:28:08.532904
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    display = Display()
    display.verbosity = 2

    # Test lookup
    lookup_obj = LookupModule()

    # Test 1: no file
    result = lookup_obj.run([], {}, **{})
    assert result == [], "Lookup template with no file returns incorrect value"

    # Test 2: one file
    result = lookup_obj.run(["file.j2"], {}, **{})
    assert result == ["file.j2"], "Lookup template with one file returns incorrect value: %s" % result

    # Test 3: one file with searchpath
    result = lookup_obj.run(["file.j2"], {"ansible_search_path": ["path/to/dir"]}, **{})

# Generated at 2022-06-22 14:28:16.589672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.display
    ansible.utils.display.LOOKUP_DEBUG = True
    import ansible.context
    ansible.context.CLIARGS = {}

    lookup_obj = LookupModule()
    result = lookup_obj.run([ './test/files/file_lookup_plugin_1.txt' ], {})
    assert result[0] == 'Hello World!'

# Generated at 2022-06-22 14:28:24.101906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.utils.path import unfrackpath
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    lookup = LookupModule()
    templar = Templar(loader=None, variables=VariableManager(loader=None, host_vars=HostVars(loader=None, searchpath=None)))
    lookup._loader = None
    lookup._templar = templar

    # Test run with a simple template file
    templar.environment.loader.module_paths = [os.path.dirname(unfrackpath("$file"))]
    templar.set_available_variables(dict(zip(['var_'+str(i) for i in range(10)], range(10))))

# Generated at 2022-06-22 14:28:36.265168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('template')
    lookup = lookup.copy_with_new_context({'templates': './templates'}, {'ansible_search_path': ':'.join([os.getcwd(), '.'])})

# Generated at 2022-06-22 14:28:49.373670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible import context
    from ansible.utils.vars import combine_vars

    term = 'test.j2'

    test_dir = os.path.dirname(os.path.abspath(__file__))
    lookup_dir = os.path.join(test_dir, 'lookup_plugins')
    lookupfile = os.path.join(lookup_dir, 'template.py')

    # Try to load lookup module
    lookup = lookup_loader.get(term, basedir=lookup_dir, class_only=True)

    # Get options for this lookup module
    options = context.CLIARGS.get('options', None)

    # Get variables for this lookup module

# Generated at 2022-06-22 14:29:01.857305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment(loader=None)
    lookup_module_run_test_vars = dict(
        ansible_search_path=["/", "/etc", "/var"],
        template_path="my_template",
        template_mtime=0,
        template_uid=0,
        template_size=0,
    )
    lookup_module_run_test_vars2 = dict(
        ansible_search_path=["/", "/etc", "/var"],
        template_path="my_template2",
        template_mtime=0,
        template_uid=0,
        template_size=0,
    )

# Generated at 2022-06-22 14:29:48.491631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
     Test run() method of LookupModule.
    """
    # This test fails with a big error:
    #
    #    Traceback (most recent call last):
    #    File "./test/units/modules/utils/test_lookup_plugins/test_template.py", line 37, in test_LookupModule_run
    #    items = lookup_mod.run(['./test/units/modules/utils/fixtures/template.j2'], variables={'bar': 'buzz'})
    #    File "/usr/share/ansible/ansible/plugins/lookup/template.py", line 66, in run
    #    lookupfile = self.find_file_in_search_path(variables, 'templates', term)
    #    File "/usr/share/ansible/ansible/plugins/loader

# Generated at 2022-06-22 14:29:54.033031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test basic functionality
    terms = ["/home/yannik/file.j2"]
    variable_options = {'foo': 'bar', 'baz': 'bam'}
    result = module.run(terms=terms, variables=variable_options)
    assert result == [b'bar bam']

    # Test variable start and end strings
    terms = ["/home/yannik/file2.j2"]
    variable_options = {'foo': 'bar', 'baz': 'bam'}
    result = module.run(terms=terms, variables=variable_options, variable_start_string='[[', variable_end_string=']]')
    assert result == [b'bar bam']

    # Test comment start and end strings

# Generated at 2022-06-22 14:30:05.955583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests
    module = FakeModule()
    lookup = LookupModule(module)

    # Cases
    # case 1
    lookup_options = {
        "convert_data": "convert_data",
        "template_vars": "template_vars",
        "jinja2_native": "jinja2_native",
        "variable_start_string": "variable_start_string",
        "variable_end_string": "variable_end_string",
        "comment_start_string": "comment_start_string",
        "comment_end_string": "comment_end_string"
    }
    variables = {
        "ansible_search_path": "ansible_search_path"
    }
    terms = [
        "term1",
        "term2"
    ]

# Generated at 2022-06-22 14:30:07.273354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-22 14:30:18.990152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # A note on AnsibleModule: AnsibleModule is like a map that contains all
    # the parameters of the current step. The constructor requires a dictionary
    # of key and value pairs.
    #
    # The right way to test this method is to use AnsibleModule to set up a
    # working environment within the test not using AnsibleModule.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Helper method for printing output
    def print_output(module, result):
        if module.params['debug']:
            print(result)

    # Helper methods for initializing parameters

# Generated at 2022-06-22 14:30:31.181384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test method run of class LookupModule'''

    # Unit test for the method run of class LookupModule using the following data.
    # Generated using:
    #     ansible localhost -m ansible.builtin.debug -a "msg={{ lookup('template', './some_template.j2') }}"
    # from a template file that contains the following text.
    #
    # {% if ansible_distribution_version in ('14.04', '16.04') %}
    # apt:
    #   name: '{{item}}'
    #   state: latest
    # with_items:
    #   - python
    #   - python-apt
    # {% endif %}
    #
    # In order to test this method we need to generate the following data.
    # {'variables':

# Generated at 2022-06-22 14:30:42.015829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #test_terms
    test_terms = ['check.html']

    #test_variables
    test_variables = {
        'ansible_search_path': [
            './tests/templates',
            './'
        ]
    }

    #test_kwargs
    test_kwargs = {
        'convert_data': True,
        'variable_start_string': '{{',
        'variable_end_string': '}}'
    }

    lookup_module = LookupModule()
    result = lookup_module.run(test_terms, test_variables, **test_kwargs)

    print(result)

# Generated at 2022-06-22 14:30:50.334154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup = LookupModule()

    # Create a dict
    test_dict = {}
    test_dict["a"] = "a_value"
    test_dict["b"] = "b_value"

    # Test function run
    result = lookup.run(['./some_template.j2'], test_dict)

    # Compare the value of the result
    assert result == ['']

# Generated at 2022-06-22 14:31:00.217834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(dict(mock=dict(lookup_plugins=dict(templates='/ansible/lookup_plugins/templates'))))
    lookup.set_environment(Environment({'ANSIBLE_TEMPLATE_INTERPRETER_NATIVE': True}))
    lookup.set_basedir('/ansible/playbooks')
    assert '{"changed": false, "msg": "Hi, I am a jinja2 template"}' == lookup.run(
        ['/ansible/playbooks/roles/test/vars/main.yml.j2'],
        dict(a=1, b=2),
        _ansible_check_special_parameters=False
    )[0]

# Generated at 2022-06-22 14:31:06.199983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    assert x.run([], {}) == []
    assert x.run(['comment'], {}) == ['# Ansible managed: Do not edit this file manually!\n#\n# Template File: roles/common/templates/comment.j2\n#\n\n']