

# Generated at 2022-06-23 12:10:17.186147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Set up a test for LookupModule with a mock AnsibleModule
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 12:10:25.638330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup.template as lookup_template
    import ansible.template as template
    import ansible.utils.native_jinja as native_jinja
    import ansible.parsing.vault as vault
    import jinja2
    import yaml
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    class Display():
        def __init__(self):
            pass

        def debug(self, msg):
            print("DEBUG: ", msg)

        def vvvv(self, msg):
            print("VERBOSE: ", msg)
    display = Display()

# Generated at 2022-06-23 12:10:29.781962
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tells display what level of verbosity is required so that debug
    # messages are printed when -vvv is passed.
    display.verbosity = 3

    lookup = LookupModule()
    lookup._loader = DummyLoader()

    # Fail if there's no file in our fake file lookup path
    try:
        lookup.run(['dummy_file'], variables={}, convert_data=False)
    except AnsibleError:
        pass
    else:
        raise AssertionError("No file in lookup path did not throw an exception.")

    # Make sure we can get a file out of our fake file lookup path
    terms = ['dummy_file']
    variables = {}
    result = lookup.run(terms, variables, convert_data=False)

# Generated at 2022-06-23 12:10:38.053987
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import __main__
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # create Fake objects
    loader = DataLoader()
    list_of_hosts = ['localhost']
    inventory = InventoryManager(loader=loader, sources=list_of_hosts)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 12:10:44.802854
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class TestTemplar(object):
        def __init__(self):
            self.env = 'dne'
        def set_environment(self, env):
            self.env = env
        def copy_with_new_env(self, environment_class=None):
            return self
        def set_temporary_context(self, *args, **kwargs):
            self.context = dict(key=1)

    templar = TestTemplar()
    lookup = LookupModule(templar)

    assert lookup.templar == templar

# Generated at 2022-06-23 12:10:50.561210
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ["./some_template.j2"]
    variables = {'template_vars': 'test'}
    lookup.run(terms, variables, variable_start_string='[%', variable_end_string='%]')

# Generated at 2022-06-23 12:10:59.311270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Unit test: test module returns an AnsibleError exception
    #
    # Arrange
    # Create LookupModule object
    l = LookupModule()
    # Create a temparary file and assign the file name to term
    import tempfile, os
    fd, name = tempfile.mkstemp()
    os.close(fd)
    term = name
    # fake content for term
    terms = [term]
    variables = {'ansible_variable_1':1}
    kwargs = {}
    #
    # Act and assert
    #
    with pytest.raises(AnsibleError) as excinfo:
        l.run(terms, variables, **kwargs)
    # Check that the exception raised is of type AnsibleError
    assert isinstance(excinfo.value, AnsibleError)

# Generated at 2022-06-23 12:11:03.502162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    terms = ['term']
    variables = {'var_options': 'variables'}
    kwargs = {'kwarg1': 'value1', 'kwarg2': 'value2'}
    L.run(terms, variables, **kwargs)

# Generated at 2022-06-23 12:11:13.269523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.vars.hostvars import HostVars

    lookup_plugin = LookupModule()
    _templar = lookup_plugin._templar
    # _loader = lookup_plugin._loader

    my_vars = HostVars()
    my_vars['trump_name'] = 'Donald'
    my_vars['user_shell'] = '/bin/bash'
    my_vars['env'] = {'PATH': '/bin/dummy'}
    my_vars.update(generate_ansible_template_vars('', ''))

    # test with 'convert_data' option
    lookup_plugin.set_options(var_options=my_vars, direct={'convert_data': True})
    assert lookup_plugin.get_option

# Generated at 2022-06-23 12:11:14.756294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    Term = ["test_file.j2"]
    Variables = {}
    LookupModule(None, Term, Variables)

# Generated at 2022-06-23 12:11:15.567474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:11:21.468530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test case is tightly coupled to the "./test/unit/module_utils/test_templar.py::test_template_module_fallbacks"
    unit test. If the latter breaks, it is most likely due to a change in the templated content generated by this
    unit test.
    """

    # Instantiate a LookupModule object.
    lookup_module = LookupModule()

    # Inject a mock _loader option.
    from ansible.utils.collection_loader import AnsibleCollectionRef
    class _loader:
        class_name = AnsibleCollectionRef
    lookup_module._loader = _loader

    # Inject a mock _templar option.
    from ansible.template import Templar
    lookup_module._templar = Templar(loader=None, variables={})

    # Prepare the arguments and options for the

# Generated at 2022-06-23 12:11:22.027254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-23 12:11:27.349103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert not hasattr(lookup, '_templar')
    assert not hasattr(lookup, '_loader')
    assert not hasattr(lookup, '_templar')
    assert not hasattr(lookup, '_basedir')
    assert not hasattr(lookup, '_loader')
    assert not hasattr(lookup, '_display')

# Generated at 2022-06-23 12:11:28.009889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise NotImplementedError

# Generated at 2022-06-23 12:11:39.335339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test keys:
    # 1. convert_data is False and jinja2_native is False
    # 2. convert_data is False and jinja2_native is True
    # 3. convert_data is True and jinja2_native is False
    # 4. convert_data is True and jinja2_native is True

    with open('test_LookupModule_run.yaml', 'w') as f:
        f.write('foo: 123\n')
        f.write('bar: true\n')
        f.write('baz: False\n')
        f.write('qux: "qux"\n')
        f.write('quux: []\n')
        f.write('quuux: {}\n')


# Generated at 2022-06-23 12:11:44.609516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a few instances of class LookupModule
    lookupModule = LookupModule()

    # Check LookupModule.run method
    # TODO: check if results are as expected

    print("LookupModule.run() passed all tests !")

# Unit test
if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:11:46.949845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for class LookupModule's constructor"""
    lookup_plugin = LookupModule()
    assert True


# Generated at 2022-06-23 12:11:54.156105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test valid case
    lookup_obj = LookupModule()
    terms = ['test.txt']
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'template_vars': {'foo': 'bar'}}
    variables = variable_manager.get_vars(loader=None, play=None)
    res = lookup_obj.run(terms=terms, variables=variables, convert_data=False, jinja2_native=False)
    assert res[0] == 'bar\n'

    # Test invalid case
    terms = ['not-found.txt']

# Generated at 2022-06-23 12:11:55.613043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert isinstance(lookupModule, LookupModule)

# Generated at 2022-06-23 12:11:57.379527
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Method run of class LookupModule is tested as part of unit testing of module_utils/command.py
    pass

# Generated at 2022-06-23 12:12:00.425076
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_module = LookupModule()
        assert(lookup_module is not None)
    except:
        assert(False)


# Generated at 2022-06-23 12:12:02.752628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule().run([], dict(template_vars={}), _terms=[], convert_data=False)

# Generated at 2022-06-23 12:12:10.875193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test case will be removed in Ansible 2.13.
    """
    # initialize a LookupModule object
    lookup_module = LookupModule()
    lookup_module._display = Display()
    lookup_module._templar = Templar(loader=DictDataLoader({'a': b'{{value}}'}))
    lookup_module._loader = DictDataLoader({'a': b'{{value}}'})
    lookup_module._templar.available_variables = {'value': 'test variable'}

    # test terms, terms = ['a']
    terms = ['a']
    result = lookup_module.run(terms=terms, variables={})
    assert [to_text(b'{{value}}')] == result

# Generated at 2022-06-23 12:12:15.721739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The following test case is to verify lookup module template.
    # The test case only verify the return value,
    # and can not check the content of the return value.
    # So the test case can only verify the correctness of the data type of the return value.

    # Arrange
    terms = ['./some_template.j2']

    # Act
    lookup_result = LookupModule.run(terms)

    # Assert
    try:
        assert isinstance(lookup_result, list)
    except AssertionError as e:
        print(e)
    else:
        print("lookup module template is correct.")

# Generated at 2022-06-23 12:12:25.896535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()

# Generated at 2022-06-23 12:12:26.877998
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 12:12:29.781659
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._templar is not None
    assert lookup_module._loader is not None

# Generated at 2022-06-23 12:12:31.494250
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:12:35.608629
# Unit test for constructor of class LookupModule
def test_LookupModule():

    """
    Unit test for constructor of class LookupModule
    """

    lookup_module = LookupModule()

    # Assert that the attributes have been set correctly.
    assert lookup_module.name == 'template'

# Generated at 2022-06-23 12:12:36.645395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-23 12:12:47.333428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.verbosity = 5

    import os
    import tempfile

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    #
    # test run() with the convert_data option
    #

    templar = Templar(loader=None, shared_loader_obj=None, variables={})
    lookup_class = lookup_loader.get('template')
    lookup_obj = lookup_class(templar=templar, loader=None, templar_environment=None)

    # create a temporary directory to hold a couple of temporary files
    tmpdir = tempfile.mkdtemp()

    # create a file for the template, with content:
    #
    # test:
    #   - var
    #   - var2
    # var: hello
    #


# Generated at 2022-06-23 12:12:58.981272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Sample:
        def __init__(self):
            self.data = None

        def get(self, k, d=None):
            return self.data.get(k, d)

    class FakeVars:
        def __init__(self):
            self.vars = {'test_var1': 'test_value1',
                         'test_var2': 'test_value2'}

        def get(self, k, d=None):
            return self.vars.get(k, d)

        def merge(self, newvars):
            self.vars.update(newvars)

    class AnsibleModuleFake:
        def __init__(self, params):
            self.params = params

    class FakeTemplar:
        def __init__(self, testcase):
            self.test

# Generated at 2022-06-23 12:13:10.539977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test class method run
    """
    # initialize LookupModule
    lm = LookupModule()
    
    # definition of variables to be used in lookup
    my_var_name = 'my_var'

    # definition of the lookup variables to be used in lookup
    var_options = dict()
    var_options[my_var_name] = os.path.abspath(__file__)

    # definition of kwargs for lookup
    kwargs = dict()
    kwargs['default_encoding'] = 'utf-8'

    # run without parameters
    terms = [os.path.abspath(__file__)]
    result = lm.run(terms, variables=var_options, **kwargs)

    # the result should be a list of strings
    assert type(result) == list


# Generated at 2022-06-23 12:13:22.535723
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #To instantiate LookupModule, we need AnsibleModule,
    #which requires AnsibleLoader.
    #AnsibleLoader requires the paths.data[ansible_config]
    path_data = {}
    path_data['ansible_config'] = None
    #AnsibleLoader requires AnsibleModule
    #AnsibleModule requires the paths.cache[ansible_config]
    #We will use a dummy config file.
    path_data['ansible_config'] = 'ansible.cfg'
    #AnsibleLoader and AnsibleModule also require AnsibleOptions
    #AnsibleOptions require the paths.data[ansible_managed]
    #We will use a dummy managed file.
    path_data['ansible_managed'] = 'ansible_managed'
    #AnsibleLoader and AnsibleModule also require AnsibleOptions

# Generated at 2022-06-23 12:13:31.746631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input and expected result
    expected_result = [u"#\n# This file is managed by ansible, DO NOT EDIT\n#\n#\nhosts:\n  - 192.168.1.1\n  - 192.168.1.2\n"]
    terms = [['./hosts.j2']]
    variables = dict(
        ansible_search_path = '/path/to/something',
        )

# Generated at 2022-06-23 12:13:33.277696
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:13:34.136553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1, 'test error'

# Generated at 2022-06-23 12:13:35.931848
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)
    assert isinstance(lm._display, Display)

# Generated at 2022-06-23 12:13:37.920234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This can throw errors on import if the lookup cannot be found, which
    # is why it has its own function.
    LookupModule()

# Generated at 2022-06-23 12:13:47.301751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if loading the module works
    my_module_args = { 
        '_terms': [ './some_template.j2' ],
        'convert_data': False,
        'variable_start_string': '[[',
        'variable_end_string': ']]',
        'jinja2_native': False,
        'template_vars': {'test': 'success'},
        'comment_start_string': '%%',
        'comment_end_string': '%%'
    }
    lookup = LookupModule(loader = DictDataLoader())
    lookup.set_options(my_module_args)

    result = lookup.run(terms=[], variables={})

    assert(type(result) == list)
    assert(len(result) == 0)

# Generated at 2022-06-23 12:13:55.389670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_exec(terms, variables, expected_results):
        lookup = LookupModule()
        results = lookup.run(terms, variables)
        assert expected_results == results

    test_exec.unittest = {'setup': '', 'teardown': ''}

    # with convert_data=True (default) and jinja2_native=False
    terms = ['./discovered_facts.yml']
    variables = dict(
        ansible_facts=dict(
            eth0=dict(
                device='eth0',
                ipv4=dict(
                    address='192.0.2.1',
                    netmask='255.255.255.0',
                    network='192.0.2.0'),
                macaddress='5254.0012.3456',
                type='ether')))
    expected

# Generated at 2022-06-23 12:14:07.231083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict

    # DEV: This unit test for this class is tested within the integration test `test/integration/lookup_plugins/test_template.py:test_template_module`
    #     This unit test is separate from the integration test because it is not possible to mock the `self._loader._get_file_contents` method
    #     without making drastic changes to the code (i.e. making `self._loader` an attribute that is initialized in the `run` method)
    #     The integration test also tests the `self._loader._get_file_contents` method along with this method
    template_1 = '''
    foo = {{ foo }}
    bar = {{ bar|default('foobar', true) }}
    '''


# Generated at 2022-06-23 12:14:17.699750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fake_loader = object()
    fake_templar = object()

    lookup_obj = LookupModule(loader=fake_loader, templar=fake_templar)

    # one template, empty vars, empty env.
    assert [b'foo\n'] == lookup_obj.run(['test_template.j2'], {}, convert_data=False, jinja2_native=False)

    # one template, empty vars, custom env.
    assert [b'foo\n'] == lookup_obj.run(['test_template.j2'], {'a': 1}, convert_data=False, jinja2_native=False)

    # one template, empty vars, custom env, jinja2_native=True,

# Generated at 2022-06-23 12:14:29.856553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import builtins
    myArgs = dict(
        terms=['/a/b/c/d/card.j2'],
        variables=dict(
            ansible_search_path=['/a/b/c'],
            ansible_facts=dict(os_version='Ubuntu16.04'),
            ansible_env=dict(PATH='/bin:/usr/bin'),
            ansible_hostname='host1'
            ),
        convert_data=None,
        template_vars=dict(
            dict1=dict(
                key1='value1', key2='value2'
                ),
            key1='value1'
            )
    )
    with open('/a/b/c/card.j2') as f:
        templateData = f.read().encode('utf8')


# Generated at 2022-06-23 12:14:30.721364
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert module != None

# Generated at 2022-06-23 12:14:42.300515
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = []
    vari = {}
    testObj = LookupModule(terms, vari)

    # Get the objects of instance variables
    lookupfile = testObj.find_file_in_search_path(vari, 'templates', terms)
    templar = testObj._templar
    var_options = testObj._options['var_options']
    display.debug("File lookup term: %s" % terms)
    display.vvvv("File lookup using %s as file" % lookupfile)

    # Get the objects of instance methods
    res = testObj.run(terms, vari)
    testObj.get_option('comments')
    testObj.get_option('convert_data')

    # Check whether all above objects are not-null or not
    assert isinstance(lookupfile, str)

# Generated at 2022-06-23 12:14:52.584978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    b_var_start = to_bytes('{{', errors='surrogate_or_strict')
    b_var_end = to_bytes('}}', errors='surrogate_or_strict')
    b_comment_start = to_bytes('{#', errors='surrogate_or_strict')
    b_comment_end = to_bytes('#}', errors='surrogate_or_strict')
    b_var_data = to_bytes('alpha', errors='surrogate_or_strict')
    b_comments = to_bytes('{#beta{#gamma#}zeta#}', errors='surrogate_or_strict')

# Generated at 2022-06-23 12:14:55.630823
# Unit test for constructor of class LookupModule
def test_LookupModule():

    templar = None
    terms = "/tmp/some_file.j2"
    variables = {}
    kwargs = {}
    result = LookupModule().run(terms, variables, **kwargs)
    assert isinstance(result, list)

# Generated at 2022-06-23 12:15:05.667278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # testing without convert_data and jinja2_native options
    results = lookup.run(['./test/test_templates/jinja2.j2'])
    assert results == [u'{{ "hello" }}']  # jinja2.j2 contains '{{ "hello" }}' so it should be not processed
    # testing with convert_data True and jinja2_native False
    results = lookup.run(['./test/test_templates/jinja2.j2'], convert_data=True, jinja2_native=False)
    assert results == [u'hello']  # jinja2.j2 contains '{{ "hello" }}' so it should be processed as data
    # testing with convert_data False and jinja2_native True

# Generated at 2022-06-23 12:15:15.566624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    my_dir = os.path.dirname(os.path.abspath(__file__))
    lookup_file = my_dir + '/test_template.j2'

    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventories = Inventory(loader=loader, variable_manager=variable_manager,  host_list=[])

    variable_manager.set_inventory(inventories)

    cls = lookup_loader.get('template', basedir=my_dir)


# Generated at 2022-06-23 12:15:21.454608
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    terms = dict(
        _terms = ['test'],
        convert_data = True,
        jinja2_native = None,
        template_vars = None,
        variable_start_string = None,
        variable_end_string = None,
        comment_start_string = None,
        comment_end_string = None
    )
    variables = dict()
    module.run(terms, variables)

# Generated at 2022-06-23 12:15:22.296867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:15:26.085644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
        Unit test for constructor of class LookupModule
    """
    lu = LookupModule()

# Generated at 2022-06-23 12:15:27.390199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-23 12:15:35.513382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    _loader = DictDataLoader({
        "/etc/passwd": """{{ foo }}
{{ bar }}
{{ baz }}
""",
        "/etc/group": """{{ foo }}
{{ bar }}
"""
    })

    lookup = LookupModule()
    lookup._loader = _loader

    templar = Templar(_loader=lookup._loader, variables={'foo': '1', 'bar': '2', 'baz': '3'})
    lookup._templar = templar

    assert lookup.run(["/etc/passwd", "/etc/group"], variables={'bar': '3', 'foo': '2'}, convert_data=True) == [
        """2
3
3
""", """2
3
"""
    ]


# Unit test helper

# Generated at 2022-06-23 12:15:38.611716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 12:15:40.080597
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Empty lookup arguments
    l = LookupModule()
    assert l

# Generated at 2022-06-23 12:15:43.229676
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ntpath

    assert ntpath.basename(LookupModule.__name__) == 'LookupModule', 'LookupModule not defined correctly'


# Generated at 2022-06-23 12:15:47.467464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO: more tests
    dut = LookupModule()
    dut.set_loader(None)
    dut._templar = None
    ret = dut.run(['not_a_file'], {})
    assert ret == []

# Generated at 2022-06-23 12:15:58.864667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()

    terms = ['test_file.j2']

    # test mixed case variables
    variables = dict(
        Bob = dict(
            age = 24,
            children = ['Mary', 'Joe', 'John'],
            mood = 'Happy',
            favorite_things = dict(
                games = ['football', 'chess'],
                colors = ['blue', 'green'],
            ),
        ),
    )

    answer = obj.run(terms, variables, variable_start_string='[[', variable_end_string=']]', comment_start_string='[[[', comment_end_string=']]')

    print(answer)

# test_LookupModule_run()

# Generated at 2022-06-23 12:16:04.576409
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #check if the lenght of return is 1
    assert len(LookupModule().run(['index.html'], {},
        convert_data = False,
        jinja2_native = False,
        lookup_template_vars = {},)) == 1
    #check if the content of return is "Hello"
    assert LookupModule().run(['index.html'], {},
        convert_data = False,
        jinja2_native = False,
        lookup_template_vars = {},)[0] == "Hello"

# Generated at 2022-06-23 12:16:13.059130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    templar = Templar(loader=DataLoader(), variables=VariableManager(inventory=Inventory()))
    lookup = LookupModule(templar=templar)

    # - jinja2_native: false, convert_data: false
    # File lookup term: a_template.j2
    # File lookup using /project/tests/files/a_template.j2 as file
    # a_template.j2: "foo={{ foo }}"
    result = lookup.run([to_bytes('a_template.j2')], dict(foo='bar'))
    assert result == ["foo=bar"]

    # - jinja2

# Generated at 2022-06-23 12:16:15.429309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupBase)
    print("OK")

# Generated at 2022-06-23 12:16:24.029860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test that the constructor of LookupModule works. It is here for
    some functionality that the pytest module does not support.
    For example, the pytest module does not support pytest.raises.
    """
    from ansible.compat.tests.mock import patch
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    variable_manager._extra_vars = {'inventory_dir': 'a/b/c/'}
    variable_manager.options_vars = {'ansible_search_path': ['/some/path']}

    inventory = InventoryManager(loader=None, sources='localhost,')


# Generated at 2022-06-23 12:16:26.407478
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create object of class LookupModule and
    # Verify that the id of the object is not NULL
    assert id(LookupModule) != NULL

# Generated at 2022-06-23 12:16:37.568549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # value of "terms" need not be used by method run
    terms = 'Not_Used'
    # value of "variables" need not be used by method run
    variables = dict()

    try:
        # method run should raise error if file is not present
        lookup_module.run(terms, variables, convert_data=True, template_vars=dict(), jinja2_native=False,
                          variable_start_string='{{', variable_end_string='}}', comment_start_string='{#',
                          comment_end_string='#}')
    except AnsibleError as e:
        assert str(e) == "the template file  could not be found for the lookup"
    except Exception as e:
        assert False



# Generated at 2022-06-23 12:16:46.901913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # make a test class that implements a fake loader for the lookup module to use
    # alternative would be to use setUpModule, but this requires working with unittest-2.7
    class FakeAnsibleFileLoader:
        class FakeAnsibleFile:
            def __init__(self, path, data):
                self._path = path
                self._data = data
            def get_path(self):
                return self._path
            def get_data(self):
                return self._data

        def __init__(self):
            self._fake_files = {}

        def add_fake_file(self, path, data):
            self._fake_files[path] = FakeAnsibleFileLoader.FakeAnsibleFile(path, data)

        def _get_file_contents(self, path):
            return self._fake

# Generated at 2022-06-23 12:16:47.863273
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:16:49.329272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is intentionally skipped until we have a good way to mock Loader error messages
    pass

# Generated at 2022-06-23 12:16:57.206724
# Unit test for constructor of class LookupModule
def test_LookupModule():

   '''Test constructor of class LookupModule'''

   lookup = LookupModule()
   #args => terms, variables, **kwargs
   #kwargs => task_vars, loader, templar, shared_loader_obj
   terms = ['template_file.j2']
   variables = {}
   kwargs = {'task_vars': {}, 'loader': None, 'templar': None, 'shared_loader_obj': None}
   lookup.run(terms, variables, **kwargs)

# Generated at 2022-06-23 12:17:09.295614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test if LookupModule.run() works"""

    # Mock _templar and create its instance
    mock_templar = mock.create_autospec(Templar)
    lookup_mod = LookupModule(loader=None, templar=mock_templar, runner=None)

    # Mock terms
    terms = [
        './some_template.j2',
        './another_template.j2'
    ]

    # Mock variables
    variables = {
        'ansible_search_path': [
            '/some/search/path'
        ]
    }

    # Mock _loader
    loader = mock.create_autospec(DataLoader)
    lookup_mod._loader = loader

    # Mock _get_file_contents()
    loader._get_file_contents.side_

# Generated at 2022-06-23 12:17:19.414296
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class VarManager:
        def __init__(self):
            self.vars = dict()

        def get(key, default=None):
            return self.vars.get(key)

        def __getitem__(self, key):
            return self.vars.get(key)

        def __setitem__(self, key, val):
            self.vars[key] = val

    class Options:
        def __init__(self):
            self.variable_start_string = '{{'
            self.variable_end_string = '}}'
            self.comment_start_string = '/*'
            self.comment_end_string = '*/'

    class Environment:
        def get_template(self, name, globals, locals):
            pass


# Generated at 2022-06-23 12:17:29.686727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    try:
        from __main__ import display
    except ImportError:
        display = Display()

    l = LookupModule()
    l.set_options()
    l._display = display
    l._loader = DummyLoader()

    l.set_runner()
    l._templar = l._runner.templar

    variables = VariableManager()

    terms = ['./some_template.j2']
    variables = {}

    result = l.run(terms, variables, convert_data=False)
    assert result == [['{{ test }}\n']]

    result = l.run(terms, variables, convert_data=True)
    assert result == [[{'test': 'bar'}]]


# Generated at 2022-06-23 12:17:36.232343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    # FIXME: Think how to use Spy to verify render_template_from_file
    # in unit tests.
    # FIXME: Add other cases to test
    assert plugin.run(['./templates/some_template.j2'], load_vars=[]) == [u"{{foo}} {{bar}}"]

# Generated at 2022-06-23 12:17:37.314988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:17:39.307696
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup is not None)

# Generated at 2022-06-23 12:17:45.360959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # test with normal template file
    assert module.run(['tests/unittests/data/sample.j2'], dict(template_host='localhost'))[0].strip() == 'this is a test'
    # test with non-existent template file
    try:
        module.run(['nonexistent.j2'], {})
    except AnsibleError:
        assert True


# Generated at 2022-06-23 12:17:46.944870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:17:49.023265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:17:51.278178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.template
    lookup = ansible.plugins.lookup.template.LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:17:53.944427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' test instantiation of LookupModule class '''

    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:18:01.524502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options=dict(), direct=dict())
    assert lookup._loader is None
    assert lookup._templar is None
    assert lookup._loader_path is None
    assert lookup._variable_manager is None
    assert lookup._loader_backup is None
    assert lookup.get_option('convert_data') is True
    assert lookup.get_option('template_vars') == {}
    assert lookup.get_option('variable_start_string') == '{{'
    assert lookup.get_option('variable_end_string') == '}}'
    assert lookup.get_option('comment_start_string') == '{#'
    assert lookup.get_option('comment_end_string') == '#}'

    lookup.set_loader(None)
    lookup.set

# Generated at 2022-06-23 12:18:09.934386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule class
    lookup = LookupModule()
    # Use from_yaml filter to load YAML file
    yaml_data = lookup.from_yaml('tests/fixtures/lookup_plugins/lookup_templates/lookup_templates.yml')
    # Parse the data
    for term, result in yaml_data.items():
        terms = result['terms']
        variables = result['variables']
        kwargs = result['kwargs']
        # Call the run function and check the output
        assert lookup.run(terms, variables, **kwargs) == result['output']

# Generated at 2022-06-23 12:18:21.104636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Import the class locally
    from ansible.plugins.lookup import template
    # Create an instance of the class
    t = template.LookupModule()
    # Create a mock environment
    vars = {
        'ansible_search_path': [
            './templates',
            './plugins/lookup/templates'
        ]
    }
    # Create a mock term and call the run method
    ret = t.run(['test'],vars,variable_start_string="&",variable_end_string="&",comment_start_string="?",comment_end_string="?")
    # Do assertion
    assert to_text(ret[0]) == to_text("Oh, hi! I'm a template!\n")

# Generated at 2022-06-23 12:18:27.341153
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Ensure that if we have native types enabled globally and on the lookup that we use the native
    # AnsibleEnvironment
    if USE_JINJA2_NATIVE:
        ansible_environment = AnsibleEnvironment
    else:
        ansible_environment = None

    templar = LookupModule(loader=None, basedir='/tmp', variables={})._templar
    assert isinstance(templar, ansible_environment)

# Generated at 2022-06-23 12:18:40.253835
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This is only for unit test purposes, DO NOT USE IN REAL CODE
    # !!! YOU HAVE BEEN WARNED !!!
    class Display:
        def display(self, msg, level=0):
            print(msg)
        display.verbosity = 2

    display = Display()

    # Create an object of class LookupModule
    lookup_module = LookupModule()

    # Lookup terms
    terms = ['./test_template.j2']

    # Variables

# Generated at 2022-06-23 12:18:41.677505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-23 12:18:53.351771
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""

    import __main__ as main
    # set up fake main module
    main.__file__ = "asdf"
    main.__loader__ = None
    main.__package__ = "."
    main.__name__ = "."

    # create instance of Ansible class to be used as a parent class
    my_ansible = type('Ansible', (object,), {'env': {'basedir': '.', 'use_jinja2_native': True}})
    my_ansible.__file__ = "asdf"
    my_ansible.__loader__ = None
    my_ansible.__package__ = "."
    my_ansible.__name__ = "."

    # create instance of AnsibleOptions class to be used as a parent class
    my

# Generated at 2022-06-23 12:19:00.148324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test of method run of class LookupModule."""
    # Without parameter
    print('Without parameter')
    lookup_module = LookupModule()
    print(lookup_module.run())

    # With a parameter
    print('\nWith a parameter')
    lookup_module = LookupModule()
    print(lookup_module.run(terms={'foo': '/bar'}, variables={'bar': '123'}))

    # With two parameters
    print('\nWith two parameters')
    lookup_module = LookupModule()
    print(lookup_module.run(terms=['/bar', '/foo'], variables={'bar': '123'}))



# Generated at 2022-06-23 12:19:11.997534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule.
    """
    display.verbosity = 4
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.template import Templar
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.parsing.dataloader import DataLoader

    variables = {}
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variables, shared_loader_obj=True)
    templar._available_variables = variables
    strategy_module = StrategyModule(loader=loader, variable_manager=None)
    templar.set_available_variables(variables)

    lookup = LookupModule(strategy_module)
    lookup

# Generated at 2022-06-23 12:19:13.221722
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:19:25.652566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['/home/pi/template/file/path.j2']
    variables = {'ansible_search_path': ['/home/pi/playbook/roles/common/templates', '/home/pi/playbook/roles/portmap/templates', '/home/pi/playbook/roles/mysql/templates', '/home/pi/playbook/roles/couchpotato/templates']}

# Generated at 2022-06-23 12:19:26.683037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 12:19:34.389950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['./some_template.j2']
    variables = {'a':'b'}
    jinja2_native = False
    convert_data = False
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_end_string = '#}'
    lookup_template_vars = dict()
    lookup_template_vars['a'] = 'b'

    test_object = LookupModule()
    test_object.set_loader('insert loader here')
    test_object.set_templar('insert templar here')


# Generated at 2022-06-23 12:19:37.793901
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError, match='please supply an absolute path'):
        lookup_module.run('', dict())

# Generated at 2022-06-23 12:19:45.230219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({})
    lookup.set_loader({})
    lookup._templar = AnsibleEnvironment()

    assert lookup._templar is not None

    # TODO: This test should not depend on an existing template file...
    result = lookup.run(["./test/ansible/templates/basic.j2"], variables={})
    assert result == [
        to_bytes('''---
# This is a Jinja template
{
    "some_key": "some_value"
}
''')]

# Generated at 2022-06-23 12:19:53.467983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    lookup: template
    """
    from ansible.plugins.lookup.template import LookupModule
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    # Ansible internal module.
    class TestingModule(object):
        def __init__(self):
            self.params = None

    # Mock Ansible internal variables.
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    # Create play.

# Generated at 2022-06-23 12:20:02.735482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    # We don't care about the actual data in the test_file, so empty file is fine
    with patch("ansible.plugins.lookup.template.open", create=True) as mock_open:
        mock_open.return_value = unittest.mock.MagicMock(spec=file)
        file_handle = mock_open.return_value.__enter__.return_value
        file_handle.read.return_value = ""
        module = AnsibleModule(argument_spec={})
        template = LookupModule(basedir='.', runner=None, templar=module._templar)
        # test passing a single string as

# Generated at 2022-06-23 12:20:03.365197
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:20:04.758325
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 12:20:08.117009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # plugin will raise exception if terms is not an array
    LookupModule(None, dict(one=1, two=2, three=3)).run("wrong_terms", dict(four=4, five=5, six=6))


# Generated at 2022-06-23 12:20:15.308892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ [TemplateLookup] """

    option_list = {
        'convert_data': True,
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'comment_start_string': '{#',
        'comment_end_string': '#}',
        'template_vars': {},
    }
    ut = LookupModule(
        loader=None,
        templar=None,
        shared_loader_obj=None,
        **option_list
    )
    print(ut)