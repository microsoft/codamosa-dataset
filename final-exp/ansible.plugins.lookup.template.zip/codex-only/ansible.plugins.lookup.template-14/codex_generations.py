

# Generated at 2022-06-23 12:10:15.601036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    Check = LookupModule().run
    assert Check(["../../plugins/lookup/../lookup_plugins/template.py"], {}, **dict(template_vars=dict(X=1))) == [to_bytes('class LookupModule(LookupBase):\n', errors='surrogate_or_strict')]
    assert Check(["../../plugins/lookup/../lookup_plugins/template.py"], {}, **dict(template_vars=dict(X=2))) == [to_bytes('class LookupModule(LookupBase):\n', errors='surrogate_or_strict')]

# Generated at 2022-06-23 12:10:16.896221
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module


# Generated at 2022-06-23 12:10:17.894801
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 12:10:22.863382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('comment_start_string') == '{{'
    assert lookup.get_option('variable_start_string') == '{{'
    assert lookup.get_option('variable_end_string') == '}}'
    assert not lookup.get_option('convert_data')

# Generated at 2022-06-23 12:10:32.042071
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test that run() can handle missing variable_start_string and variable_end_string
    # See https://github.com/ansible/ansible/issues/17007
    templar = AnsibleEnvironment(loader=None, shared_loader_obj=None, variables={})
    lookup = LookupModule(loader=None, templar=templar, basedir=None)
    terms = './some_template.j2'
    variables = None
    test_kwargs = {'convert_data': False, 'template_vars': {}}
    template_data = '{{ hello_world }}'
    result = lookup.run(terms, variables, **test_kwargs)
    assert result == [template_data]

    # Test that run() can handle missing comment_start_string and comment_end_string
    # See https

# Generated at 2022-06-23 12:10:42.686073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test for a non-existing file
    terms = ['non_existing_file.j2']
    variables = {
        'ansible_search_path': ['./test/test_lookup/data'],
    }
    try:
        res = lookup.run(terms, variables, convert_data=True)
    except AnsibleError as e:
        assert "the template file non_existing_file.j2 could not be found for the lookup" in e.message
    else:
        assert False, "the template file non_existing_file.j2 could not be found for the lookup"

    # test for a variable that is not present
    terms = ['template.j2']

# Generated at 2022-06-23 12:10:54.203058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import tempfile
    import shutil
    import yaml

    if not sys.version_info >= (2, 7):
        sys.stderr.write("SKIP: lookups/template (not supported on python2.6)\n")
        return

    tmpdir = tempfile.mkdtemp()
    dest = os.path.join(tmpdir, 'source')
    shutil.copyfile(os.path.join(os.path.dirname(__file__), 'source'), dest)


# Generated at 2022-06-23 12:10:58.171199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    terms = ['test.txt']
    variables = {'template_host': 'hostname'}
    kwargs = {'convert_data_p': 'True'}
    result = look.run(terms, variables, **kwargs)
    assert result == [u'The hostname is: hostname']

# Generated at 2022-06-23 12:11:07.374633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    lookup = lookup_loader.get('template')

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'item': 'value'}
    variable_manager.options_vars = {'lookup_template_vars': {'another_item': 'something else'}}

    lookup._templar = Templar(loader=None, variables=variable_manager)
    lookup.set_loader(None)

    data = lookup.run(['./template_file'], variable_manager.get_vars())

    assert len(data) == 1
    assert data[0] == 'this is a test\n'

# Generated at 2022-06-23 12:11:08.021602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    Mod = LookupModule()

# Generated at 2022-06-23 12:11:18.146577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_object = LookupModule() # type: ignore

    # Testing case where file exists and file contains a Jinja2 string
    templar = lookup_object._templar
    variables = {"ansible_search_path": ["/ansible/lookup_plugins/test/test_data/templates"]}
    lookupfile = "/ansible/lookup_plugins/test/test_data/templates/router.txt"
    b_template_data, show_data = lookup_object._loader._get_file_contents(lookupfile)
    template_data = to_text(b_template_data, errors='surrogate_or_strict')
    searchpath = variables.get('ansible_search_path', [])

# Generated at 2022-06-23 12:11:19.655138
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert callable(lookup_module)

# Generated at 2022-06-23 12:11:21.489433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-23 12:11:27.701873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.template import generate_ansible_template_vars

    lu = LookupModule()

    assert lu.run(["{{ lookup('template', './some_template.j2') }}"], dict()) == []

    searchpath = ['.']
    term = './some_template.j2'
    lookupfile = './some_template.j2'
    result = dict()
    result.update(generate_ansible_template_vars(term, lookupfile))

    assert lu.run([term], {'ansible_search_path': searchpath}) == [to_bytes(result)]

# Generated at 2022-06-23 12:11:32.741110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    module = LookupModule()
    assert 'msg' == module.run(['./some_template.j2'], {'msg': 'hello world'})[0]

# Generated at 2022-06-23 12:11:41.059089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Obj(object):
        def __init__(self):
            self.cur_dir = 'ansible/plugins/lookup'

    from ansible.module_utils._text import to_bytes

    lookup = LookupModule(loader=Obj())

    # simple test
    lookup.set_options(var_options={'ansible_search_path':['/']})
    assert(lookup.run(['./test/files/hello_world.j2'], {}) ==
           [to_bytes('hello world\n')])

    # test with template_vars
    lookup.set_options(var_options={'ansible_search_path':['/']})

# Generated at 2022-06-23 12:11:51.241539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError

    # Parameterized test for method run of class LookupModule
    @pytest.mark.parametrize("terms, variables", [
        (
            ["./some_template.j2"],
            {},
        ),
        (
            ["./some_template.j2"],
            {'variable_start_string': '[[', 'variable_end_string': ']]'},
        ),
    ])
    def test_method_run(terms, variables):
        # Unit test for method run of class LookupModule
        ansible_module = MockAnsibleModule()
        result = LookupModule(ansible_module).run(terms, variables)
        # Test successful result
        assert result
        # Test result content

# Generated at 2022-06-23 12:12:02.042743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.templating import from_yaml
    from ansible.template import Templar
    from ansible.vars import VariableManager

    lookup_obj = LookupModule()
    variable_manager = VariableManager()
    variable_manager._fact_cache = {
        'a': 'bar', 'b': 'foo',
        'c': 'foobar', 'd': {'e': 'foo'},
        'e': '123456', 'f': 123456,
        'g': 'bar123', 'h': {'i': 'bar'},
    }

# Generated at 2022-06-23 12:12:11.133745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    src = "{{ lookup('template', 'myplugin/mytemplates/mytemplate.j2') }}"
    template_data = "hello world"

    class Inventory:
        def __init__(self):
            self.hosts = ['host']

        def get_hosts(self, pattern):
            return self.hosts

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 12:12:12.496286
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run([], {}) # this is a method of LookupBase

# Generated at 2022-06-23 12:12:18.041695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'template_vars':{'var1':3, 'var2':4}})
    l.set_options({'convert_data': True})
    l.set_options({'jinja2_native': True})
    l.run(["../lookup_plugins/test/data/templates/test.j2"])

# Generated at 2022-06-23 12:12:21.200000
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run'), "LookupModule class needs a run method"
    test = LookupModule()
    assert hasattr(test, 'run'), "LookupModule class needs a run method"

# Generated at 2022-06-23 12:12:23.096497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm
    assert lm is not None

# Generated at 2022-06-23 12:12:29.364128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()
    ret = L.run(['/some/templated/file.txt'], dict(
        ansible_search_path = ['/some/place/'],
        year = 2017,
        month = 7,
        day = 6,
        hour = 11
    ))
    assert ret[0] == 'Hello!\nThe time is currently 2017-07-06 11'

# Generated at 2022-06-23 12:12:31.126557
# Unit test for constructor of class LookupModule
def test_LookupModule():
    templar = LookupModule()
    assert templar is not None

# Generated at 2022-06-23 12:12:33.979167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_plugin = LookupModule()
    except:
        lookup_plugin = None

    assert lookup_plugin is not None

# Generated at 2022-06-23 12:12:35.295626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:12:44.625910
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create a LookupModule object
    lookup_module = LookupModule()

    # variables are passed to the constructor as a dict containing
    # key/value pairs
    variables = {
        'greeting':'hello'
    }

    # create a list of terms
    terms = ['the_template.j2']

    from ansible.parsing.plugin_docs import read_docstring
    if not read_docstring(__file__.replace('.pyc', '.py'), verbose=False):
        print("Failed to parse docstring in %s" % __file__)
        sys.exit(1)

    # run the lookup
    lookup_module.run(terms, variables)

# Generated at 2022-06-23 12:12:55.710869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_variables = {'formatter': 'json', 'p': [1, 2, 3, 4], 'q': {'q1': 9, 'q2': 19}}
    direc = {'convert_data': False, 'template_vars': {}, 'jinja2_native': True, 'variable_start_string': '{{', 'variable_end_string': '}}',
             'comment_start_string': '{#', 'comment_end_string': '#}'}
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=global_variables)
    lookup_module.set_options(var_options=global_variables, direct=direc)
    terms = []
    terms.append("../../../../../../../../etc/passwd")


# Generated at 2022-06-23 12:12:56.983560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    return obj

# Generated at 2022-06-23 12:12:58.188790
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupBase, object)

# Generated at 2022-06-23 12:13:09.846264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.template.safe_eval import unsafe_eval
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    lookup_module = LookupModule()
    ansible_search_path = ["/some/test/dir1", "/some/test/dir2"]
    test_template = "test_template.j2"
    test_template_contents = "some contents"
    test_template_path = "/some/test/dir1/templates/test_template.j2"
   

# Generated at 2022-06-23 12:13:11.197009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:13:23.066328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeEnv:
        class FakeLoader:
            def __init__(self, contents):
                self.contents = contents

            def _get_file_contents(self, path):
                return self.contents
    #
    #  Template module
    #
    #  return a string that is the contents of the named file,
    #  after being templated by the all availble variables.
    #
    #  Example:
    #  contents of /etc/foo.conf.j2:
    #  [foo]
    #  bar={{ record_type }}
    #
    #  given variables:
    #  record_type=A
    #
    #  result:
    #  [foo]
    #  bar=A
    #

    env = FakeEnv()
    env.FakeLoader

# Generated at 2022-06-23 12:13:28.201457
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize the module
    module = LookupModule()
    assert module != None

    # Example without template
    result = module.run(['not_existing.j2'], dict(templates='templates'))

    # Example without existing file
    try:
        result = module.run(['test.j2'], dict(templates='templates'))
    except AnsibleError:
        pass

# Generated at 2022-06-23 12:13:33.010006
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import ansible.plugins
    sys.modules['ansible.plugins.lookup.template'] = sys.modules['ansible.plugins.lookup.file']
    del sys.modules['ansible.plugins.lookup.file']
    from ansible.plugins.lookup import template
    return template.LookupModule()

# Generated at 2022-06-23 12:13:42.904087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate a LookupModule
    lookupModule = LookupModule()
    # Execute method run

# Generated at 2022-06-23 12:13:53.108353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    def get_data_loader():
        '''Create a data loader'''
        data_loader = DataLoader()
        data_loader.set_vault_secrets(['testsecret'])
        return data_loader

    def get_variable_manager():
        '''Create a variable manager'''
        variable_manager = VariableManager()
        variable_manager.extra_vars = {'myvar': 'myvalue'}
        return variable_manager

    def get_inventory():
        '''Create an inventory'''

# Generated at 2022-06-23 12:14:05.676728
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initializing LookupModule
    lookup = LookupModule()

    # This test is to check if wordpress is returned when the template_vars is given to lookup module

# Generated at 2022-06-23 12:14:16.459817
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create a lookup module
    lookup = LookupModule()

    # Module options
    opts = {'convert_data': True, 'template_vars': {},
            'variable_start_string': '{{', 'variable_end_string': '}}',
            'comment_start_string': '{#', 'comment_end_string': '#}'}

    lookup.set_options(var_options=None, direct=opts)

    # Test module options
    assert lookup.get_option('convert_data') == True
    assert lookup.get_option('template_vars') == {}
    assert lookup.get_option('variable_start_string') == '{{'
    assert lookup.get_option('variable_end_string') == '}}'

# Generated at 2022-06-23 12:14:17.043447
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:14:19.681935
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO:  Add unit test for method run of class LookupModule
    # No unit tests possible for lookup, as it needs an inventory
    pass

# Generated at 2022-06-23 12:14:22.650910
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:14:29.776705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    Check that the class can render a template
    """

    lookup = LookupModule()
    lookup.set_options({'variable_start_string': '[%', 'variable_end_string': '%]'})
    test_template = lookup.run(['./lib/ansible/plugins/lookup/data/test_template.j2'], {'name': 'Ansible'})
    assert test_template[0] == 'Hello Ansible!'

# Generated at 2022-06-23 12:14:30.652208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:14:33.267235
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert len(lookup.run([[]])) == 0
    assert len(lookup.run([""])) == 0


# Generated at 2022-06-23 12:14:44.665222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    module = LookupModule()

    # Test using variable_start_string and variable_end_string
    terms = ['./some_template.j2']
    variable_start_string = '${'
    variable_end_string = '}'
    res = module.run(terms, variable_start_string=variable_start_string, variable_end_string=variable_end_string)

    assert ('this is a test string: ${some_string}' in res)

    # Test using comment_start_string and comment_end_string
    terms = ['./some_template.j2']
    comment_start_string = '{#'
    comment_end_string = '#}'

# Generated at 2022-06-23 12:14:46.392145
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 12:14:56.946669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a template module object
    template_test = LookupModule()
    
    # create a test variables object
    test_variables = dict()
    test_variables['test_variable'] = 'test'
    test_variables['test_variable_1'] = 'test1'
    test_variables['test_variable_2'] = 'test2'
    
    # create a dictionary of parameters to pass to the run method
    test_params = dict()
    test_params['variable_start_string'] = '['
    test_params['variable_end_string'] = ']'
    test_params['comment_start_string'] = '#'
    test_params['comment_end_string'] = '$'
    test_params['convert_data'] = False

# Generated at 2022-06-23 12:15:06.679454
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # before creating a lookup object we have to setup some variables in the
    # Ansible context
    import ansible.context
    from ansible.vars.manager import VariableManager

    playbook_basedir = os.getcwd()
    lookup_basedir = os.path.join(playbook_basedir, 'lookup_plugins')
    ansible.context.CLIARGS = {}
    ansible_connection = 'local'

    variable_manager = VariableManager()
    variable_manager.set_inventory(ansible.inventory.Inventory(host_list='/dev/null'))
    loader = ansible.parsing.dataloader.DataLoader()

# Generated at 2022-06-23 12:15:13.763868
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Exercise the constructor of LookupModule"""
    
    # Create test tuple
    test_tuple = ({}, {}, {
       'convert_data': True,
       'variable_end_string': '}}',
       'variable_start_string': '{{',
       'template_vars': {}
    })
    test_LookupModule = LookupModule(*test_tuple)
    
    # Check that object was created correctly
    assert test_LookupModule is not None
    assert test_LookupModule._templar is not None

# Generated at 2022-06-23 12:15:20.145498
# Unit test for constructor of class LookupModule
def test_LookupModule():
    args = dict(variable_start_string="[[", variable_end_string="]]",
                jinja2_native=False, convert_data=True)

    terms = ["./some_template.j2"]
    template_vars = {}
    lookup_obj = LookupModule()
    lookup_obj.run(terms, template_vars, **args)

# Generated at 2022-06-23 12:15:21.452425
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module


# Generated at 2022-06-23 12:15:24.309659
# Unit test for constructor of class LookupModule
def test_LookupModule():

  # Test create new object of lookup module
  lookupModule = LookupModule(loader=None, templar=None, shared_loader_obj=None)

  assert lookupModule is not None
  assert isinstance(lookupModule,LookupBase)

# Generated at 2022-06-23 12:15:26.331361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:15:34.969397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit tests for template_from_file lookup, for a list of parameters

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    import os
    import pytest
    from units.mock.loader import DictDataLoader

    lookup_plugin = LookupModule()

    # Test 1: simple template
    #inventory_hostname = 'hostname'
    #vars_dict = {'inventory_hostname': inventory_hostname}

    # Test 1: simple template
    inventory = Inventory(loader=DictDataLoader({}))
    inventory.set_variable_manager(VariableManager(loader=DictDataLoader({})))
    play_context

# Generated at 2022-06-23 12:15:38.321501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(hasattr(lookup_module, 'run'))

# Generated at 2022-06-23 12:15:48.260863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # No error for empty terms
    assert lookup.run([], dict()) == []
    assert lookup.run([], dict(role_path=["./roles/role1"])) == []
    # Role path is part of the search path
    role_path = "./roles/role1"
    lookup.run(["test1.j2"], dict(role_path=[role_path]))
    assert lookup.run(["test1.j2"], dict(role_path=[role_path])) == ['TEST:  role path: ./roles/role1\n']
    # Paths are part of the search path
    lookup.run(["test1.j2"], dict(paths=[role_path]))

# Generated at 2022-06-23 12:15:52.239296
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__) != 0
    assert len(LookupModule.run.__doc__) != 0
    assert len(LookupModule.run.__doc__) != 0

# Generated at 2022-06-23 12:15:53.776310
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:16:00.073803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = None
    ansible_config = {}
    ansible_env = {}
    ansible_search_path = []
    loader = None
    templar = None
    use_jinja2_native = False
    lm = LookupModule(display, loader, templar, ansible_config, ansible_env, ansible_search_path, use_jinja2_native)

    # Test case: ansible_search_path is not defined
    ansible_search_path.append("")
    lookup_file = "../../../../playbooks/files/test_template_lookup_files/test_template_lookup_data_in_ansible_search_path"
    lookup_template_vars = {}
    convert_data_p = True
    variable_start_string = '{{'
    variable_

# Generated at 2022-06-23 12:16:04.100552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Error case: lookup_type is not supported
    lookup = LookupModule()
    lookup._lookup_type = "foo"
    assert lookup.run([], {}) == []

# Generated at 2022-06-23 12:16:12.867099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import ansible.plugins.lookup.template
    from ansible.module_utils._text import to_bytes
    import ansible.template
    class FakeVars(dict):
        pass
    fakeVars = FakeVars()
    fakeVars['template_mtime'] = os.path.getmtime('/tmp/test1.j2')
    fakeVars['template_uid'] = os.getuid()
    fakeVars['template_path'] = '/tmp'
    fakeVars['template_gid'] = os.getgid()
    fakeVars['template_stat'] = os.stat('/tmp/test1.j2')
    lu = ansible.plugins.lookup.template.LookupModule()
    assert lu.run(['test1.j2'], fakeVars)

# Generated at 2022-06-23 12:16:15.854662
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupBase' in str(type(LookupModule.__bases__[0]))

# Generated at 2022-06-23 12:16:24.216060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #test valid variable_start_string and variable_end_string

# Generated at 2022-06-23 12:16:29.410145
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)
    lookup_plugin = LookupModule(templar=templar, basedir=".", playcontext=[])
    assert lookup_plugin

# Generated at 2022-06-23 12:16:38.222116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('template', loader=None, templar=None)

    assert 'template' in lookup_loader._lookup_fragments
    assert 'template' in lookup_loader._lookup_terms
    assert 'template' in lookup_loader._templar_plugins
    assert 'template' in lookup_loader._filters

    lookup = lookup_loader.get('template', loader=None, templar=None)
    assert hasattr(lookup, '_templar')

    lookup.run([''], variables={})



# Generated at 2022-06-23 12:16:47.675998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["./some_template.j2"]
    variables = {"search_path": "./_files", "a": "foo", "b": "bar"}
    kwargs = {"convert_data": True, "variable_start_string": "{{", "variable_end_string": "}}",
              "comment_start_string": "{#", "comment_end_string": "#}", "template_vars": {"c": "baz", "d": "qux"},
              "jinja2_native": False}
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar()
    lookup_module._loader = FakeLoader()
    assert lookup_module.run(terms, variables, **kwargs) == [b'Hello, world!']

# Generated at 2022-06-23 12:16:54.309891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar = AnsibleEnvironment()
    terms = [
        'test-template.j2',
    ]
    variables = {}
    results = LookupModule(
        loader=None,
        templar=templar,
        **kwargs
    ).run(terms, variables, **kwargs)
    assert len(results) == 1
    assert results[0] == "OK"


# Generated at 2022-06-23 12:17:02.554577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeModule(object):
        def __init__(self, return_val):
            self.params = {}
            self.return_val = return_val

        def fail_json(self, msg):
            self.msg = msg
            raise Exception(self.msg)

    options = {'convert_data': False, 'template_vars': {}, 'jinja2_native': True}

    # test_template_lookup_without_search_path
    # Make sure lookup properly uses ansible_search_path
    lookup_template_file = 'test.j2'

# Generated at 2022-06-23 12:17:03.377070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:17:03.826184
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:17:12.569647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.template
    lookup = ansible.plugins.lookup.template.LookupModule()
    # mock out the templar object...
    class TestTemplar:
        def __init__(self):
            self.template_data = ''
            self.searchpath = None
            self.vars = None
            self.convert_data = False
            self.escape_backslashes = True
            self.result = ''

        def copy_with_new_env(self, environment_class):
            return TestTemplar()

        def set_temporary_context(self, **kwargs):
            self.searchpath = kwargs['searchpath']
            self.vars = kwargs['available_variables']
            return self


# Generated at 2022-06-23 12:17:15.599535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')
    assert hasattr(lookup_module, 'find_file_in_search_path')

# Generated at 2022-06-23 12:17:26.733901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tested with a real template file, with global jinja2_native, with and without convert_data,
    # with and without jinja2_native, with and without template_vars, with and without comments,
    # in python 2 and in python 3.

    #import pdb; pdb.set_trace()

    from ansible.template import Templar
    from ansible.module_utils.six import PY3

    def run_lookup(variables, lookup_template_vars, jinja2_native, convert_data, lookup_file_path):
        lookup_module = LookupModule()
        display = lookup_module._templar._display
        lookup_module.set_options(var_options=variables, direct=dict(display=display))

# Generated at 2022-06-23 12:17:27.311729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:17:28.648441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:17:34.093861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    terms = ["./some_template.j2"]
    variables = {"ANSIBLE_NET_USERNAME": "test_username", "ANSIBLE_NET_PASSWORD": "test_password"}
    kwargs = {"wantlist": True}

    builtins.open = lambda x, y: StringIO("{{test}}")

    obj = LookupModule()
    assert obj.run(terms=terms, variables=variables, **kwargs) == ["test"]

# Generated at 2022-06-23 12:17:40.726780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_templar(None)
    lookup.set_fs(None)

    # Test with a valid template file name
    lookup.run(['test_lookup_template.j2'], dict(foo='bar'))
    # Test with an invalid template file name, the test should have an exception
    lookup.run(['test_lookup_template_invalid.j2'], dict(foo='bar'))

# Generated at 2022-06-23 12:17:41.950575
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule) == True

# Generated at 2022-06-23 12:17:45.563578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert isinstance(lookup_module, LookupBase)
    assert not hasattr(lookup_module, '_templar')



# Generated at 2022-06-23 12:17:46.272306
# Unit test for constructor of class LookupModule
def test_LookupModule():
    impl = LookupModule()
    assert isinstance(impl, LookupBase)

# Generated at 2022-06-23 12:17:46.952420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:17:57.919983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# -*- coding: utf-8 -*-
#
# (c) 2017, Peter Sprygada, <psprygada@ansible.com>
# Copyright: (c) 2017, Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type


# Generated at 2022-06-23 12:18:00.371680
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    test LookupModule constructor
    '''
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:18:10.290191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def my_find_file_in_search_path(templar, variables, subdir, file):
        return file

    # We want to test one of the lookup functions which is a class,
    # so we patch the lookup plugin class itself to inject our
    # replacement method.
    LookupModule.find_file_in_search_path = my_find_file_in_search_path
    lookup = LookupModule()

    terms = [ 'foo' ]
    variables = { 'bar': 'baz' }
    kwargs = { 'convert_data': False, 'template_vars': {}, '_templar': None }
    result = lookup.run(terms, variables, **kwargs)
    assert result[0] == "foo"

# Generated at 2022-06-23 12:18:15.045706
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(var_options=dict(), direct=dict())
    assert l.get_option('variable_start_string') == '{{'
    assert l.get_option('variable_end_string') == '}}'

# Generated at 2022-06-23 12:18:26.498196
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with a non-existing file
    l = LookupModule()
    l._templar = DummyTemplar()
    l._loader = DummyLoader(None)
    try:
        l.run([''], dict())
        assert False
    except AnsibleError as e:
        assert "could not be found for the lookup" in to_text(e)

    # Test with an existing file
    l = LookupModule()
    l._templar = DummyTemplar()
    l._loader = DummyLoader('content1')
    term = 'existing_file'
    lookupfile = l.find_file_in_search_path({}, 'templates', term)
    assert term == lookupfile

# Generated at 2022-06-23 12:18:29.590941
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert 'jinja2' == lookup._templar._environment.__class__.__name__

# Generated at 2022-06-23 12:18:30.316631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    con = LookupModule()
    assert con is not None

# Generated at 2022-06-23 12:18:42.027901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # these tests exercise the template lookup in a very basic way
    # some of this code is used by other lookups and needs to be
    # kept in sync as well
    class TestObj:
        def __init__(self, value):
            self.value = value

    class TestObj2:
        def __init__(self, value):
            self.value = value

    import os

    terms = [os.path.dirname(__file__) + '/../../lib/ansible/plugins/lookup/templates/test1.j2']
    lookup = LookupModule()

# Generated at 2022-06-23 12:18:53.818724
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    options = {
        "convert_data": True,
        "template_vars": {},
        "jinja2_native": False,
        "variable_start_string": "{{",
        "variable_end_string" : "}}",
        "comment_start_string" : "{{",
        "comment_end_string" : "}}"
    }
    terms = ["unittest.j2"]
    variables = {}

    expected_result = ["unit test {{ lookup ('template', 'unittest.j2') }}"]

    class MockLoader:
        def _get_file_contents(self, filename):
            """Mock _get_file_contents to return known data"""


# Generated at 2022-06-23 12:19:02.501296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    loader_mock = MagicMock()
    _loader_mock = PropertyMock(return_value=loader_mock)
    loader_mock.get_basedir.return_value = '/path/to/a/file'
    templar_mock = MagicMock()
    display_mock = MagicMock()
    variables = {'ansible_search_path': ['/path/to/a/file', '/path/to/another/file']}


# Generated at 2022-06-23 12:19:13.484411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    import pytest
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.safe_eval import Undefined


    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 12:19:25.958761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars.unsafe_proxy import UnsafeProxy

    display = Display()
    lookup_plugin = lookup_loader.get('template', basedir='./test/units/lookup/data')

    lookup_plugin.set_loader(lookup_plugin._loader)

    terms='testlookup.j2'
    variables = dict(
        testvar1='one',
        testvar2='two',
    )
    jinja2_native = False
    display.verbosity = 4
    lookup_plugin._templar = Templar(loader=lookup_plugin._loader, variables=variables)

# Generated at 2022-06-23 12:19:26.600395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:19:34.334385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _terms = './some_template.j2'
    _kwargs = {'variable_start_string': '[%', 'variable_end_string': '%]', 'convert_data': False}
    _result = [u'name=Hello ansible']
    _result_type = type(to_text(u''))

    _loader_mock = MockLoader()
    _loader_mock.get_file_content.return_value = to_bytes(u'name=[% name|string %]')

    _templar_mock = MockTemplar()
    _templar_mock.template.return_value = u'name=Hello ansible'

    lu = LookupModule(_loader_mock, _templar_mock, _dict())


# Generated at 2022-06-23 12:19:38.612123
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import inspect
    from ansible.utils.display import Display
    lookup_module = LookupModule(None, display)
    assert lookup_module is not None
    assert lookup_module.run is not None
    assert inspect.ismethod(lookup_module.run)

# Generated at 2022-06-23 12:19:49.473836
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import AnsibleTemplar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    yaml_loader = DataLoader()
    vm = VariableManager(loader=yaml_loader, inventory=InventoryManager(loader=yaml_loader, sources=[]))
    templar = AnsibleTemplar(loader=yaml_loader, variables=vm.get_vars(play=None))

    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(yaml_loader)
    lookup_plugin.set_templar(templar)


# Generated at 2022-06-23 12:19:59.041182
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:20:08.939214
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class Options:
        def __init__(self, var_options, direct):
            self.var_options = var_options
            self.direct = direct

    class VariableManager:
        def __init__(self, host_vars=dict(), group_vars=dict(), extra_vars=dict()):
            self.host_vars = host_vars
            self.group_vars = group_vars
            self.extra_vars = extra_vars

        def get_vars(self, loader=None, play=None, task=None, host=None):
            return dict()

    class DataLoader:
        def __init__(self):
            self.basedir = os.getcwd()

        def path_dwim(self, given):
            return given
