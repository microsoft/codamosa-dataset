

# Generated at 2022-06-23 12:10:17.545520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['first.j2', 'second.j2']
    variables = {'a': '1', 'b': '2'}
    native_jinja = True
    convert_data = False
    template_vars = {'c': '3', 'd': '4'}
    variable_start_string = '<%'
    variable_end_string = '%>'
    comment_start_string = '<#'
    comment_end_string = '#>'

    lookup = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    lookup._loader = None
    lookup._templar = None

    # call set_options with direct=True to avoid calling the LookupBase method
    # set_options calls get_option without direct=True, so the private option_cache

# Generated at 2022-06-23 12:10:18.981465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Since the constructor of class LookupModule has no arguments
    # there is nothing that we could test.
    pass

# Generated at 2022-06-23 12:10:20.214559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:10:26.329904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    # load the cat plugin
    lookup = lookup_loader.get('template', class_only=True)

    lookup._loader = DictDataLoader({'a': '1 {{ a }} 3'})
    lookup._templar = MockTemplar({'a': '2'})

    res = lookup.run(['./a'], {'a': '0'})

    assert res == ['1 2 3']


# Generated at 2022-06-23 12:10:28.214717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test to see if object is created
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:10:29.693547
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 12:10:32.909784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['../../LICENSE.txt']
    variables = {'www_location': 'http://www.ansible.com'}
    lookup = LookupModule()
    content = lookup.run(terms, variables)
    # the content should contain Copyright
    assert "Copyright" in content[0]

# Generated at 2022-06-23 12:10:33.691618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 12:10:36.243274
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_plugin = LookupModule()
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-23 12:10:45.561766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(dict(variable_start_string='<<', variable_end_string='>>', convert_data=True))
    terms = [
        'my_config.j2',
        'my_config.yaml',
        'my_config.yml',
    ]

# Generated at 2022-06-23 12:10:48.356128
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)
    assert lookup.run(terms=[], variables={}, **{}) == []

# Generated at 2022-06-23 12:10:49.315629
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:10:50.665864
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:10:59.359319
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor for LookupModule class is called by the ansible engine
    # implicitly.
    #
    # Here we directly invoke the constructor of the LookupModule class
    # manually to test it. Because LookupModule class has the following
    # attributes:
    #
    #    self._templar
    #      Set by the ansible engine implicitly
    #
    #    self._loader
    #      Set by the ansible engine implicitly
    #
    #    self._templar
    #      Set by the ansible engine implicitly
    #
    #    self._basedir
    #      Set by the ansible engine implicitly
    #
    # we have to mock these attributes to run the test.

    # Construct an instance of LookupBase to be used as a mock
    LookupBase_mock = LookupBase()

    # Create

# Generated at 2022-06-23 12:11:08.005815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #TODO finish unit tests for method run
    #TODO test case where variable variable_start_string = '[%'"
    #TODO test case where variable variable_end_string = '%]'
    #TODO test case where variable comment_start_string = '[#'"
    #TODO test case where variable comment_end_string = '#]'
    #TODO test case where variable convert_data is set to True
    #TODO test case where variable convert_data is set to False
    #TODO test case where variable jinja2_native is set to True
    #TODO test case where variable jinja2_native is set to False
    print("ran tests for method run of class LookupModule")

# Generated at 2022-06-23 12:11:09.345330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a temporary filename from the term
    t = LookupModule()

# Generated at 2022-06-23 12:11:18.924465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We can't assert exactly the same output because it includes some random
    # stuff retrieved here and there.
    # We don't have a good way to mock these variables for the unit tests so
    # we just test that the output is a string, and that it contains what we
    # expect.
    from ansible.module_utils.six import PY3
    from ansible.vars.manager import VariableManager

    lookup_module = LookupModule()
    lookup_module.set_loader(lookup_module._loader)
    lookup_module.set_templar(lookup_module._templar)

    mock_loader = MockLoader()
    mock_loader._file_cache = {"/home/mock_user/hello.j2": "Hello {{ foo }}!"}
    lookup_module.set_loader(mock_loader)



# Generated at 2022-06-23 12:11:28.863380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # parameters
    variables = {}
    terms = ['test.j2']
    kwargs = {}

    # function
    lookup = LookupModule()

    # exception tests
    terms_exception = ['']
    kwargs_exception = {'convert_data': 'not_a_bool'}

    # call function
    try:
        lookup.run(terms_exception, variables, **kwargs_exception)
    except AnsibleError as e:
        pass
    else:
        print('Test of LookupModule._get_file_contents function failed.')

    # successful tests
    try:
        lookup.run(terms, variables)
    except AnsibleError as e:
        print('Test of LookupModule._get_file_contents function failed.')

# Generated at 2022-06-23 12:11:39.839475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cStringIO
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils import basic
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import MagicMock, patch, call
    import ansible.constants as C

    # Mocking the data, which will be returned by the read method
    # of the file object once read
    # This data will be used to create a fake_open content object,
    # which will be returned by the fake_open method
    fake_open_data = "this is a test line in the file"

    # Mocking the open method

# Generated at 2022-06-23 12:11:42.131414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # empty terms
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert lookup_module

# Generated at 2022-06-23 12:11:44.146205
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 12:11:45.206748
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 12:11:50.523130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule._templar = None
    lookupModule._loader = None
    lookupModule.set_options({'variable_start_string':'[%', 'variable_end_string':'%]'})
    lookupModule.run(terms=['roles/base/files/test.txt'],variables={'lorem':'ipsum', 'foo':'bar'})

# Generated at 2022-06-23 12:11:52.039358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:11:53.946742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:12:03.373836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.collections import is_sequence
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('template', class_only=True)

    # invalid arguments
    with pytest.raises(AnsibleError) as e_info:
        lookup.run('invalid_file_name')
    assert "the template file invalid_file_name could not be found for the lookup" in to_text(e_info.value)

    # too few arguments
    with pytest.raises(AnsibleError) as e_info:
        lookup.run()
    assert "Missing required terms argument" in to_text(e_info.value)

    # invalid option

# Generated at 2022-06-23 12:12:11.962330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.template import AnsibleEnvironment
    from ansible.template._utils import combine_vars
    from ansible.plugins.loader import lookup_loader

    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', required=True),
            jinja2_native=dict(type='bool', required=False),
            template_vars=dict(type='dict', required=False),
        )
    )
    lookup_name = 'template'
    lookup_base_class = lookup_loader.get(lookup_name, class_only=True)

# Generated at 2022-06-23 12:12:12.693739
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:12:23.682730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import MutableMapping
    module_mock = MutableMapping()
    module_mock.params = {'_original_file': '/path/to/template.j2'}
    module_mock.run_command = lambda x, check_rc=True: (0, 'output', None)
    module_mock.add_cleanup_file=lambda x: None
    templar_mock = Templar(loader=None, variables={'var': 'val'})
    lookup_module_mock = LookupModule(loader=None, templar=templar_mock, runner=None)
    lookup_module_mock.set_options = lambda var_options=None, direct=None: None
    lookup

# Generated at 2022-06-23 12:12:28.137205
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ['./template.j2']
    variables = {}

    # Instantiate a LookupModule object
    lm = LookupModule()

    # Call run() to generate the result
    result = lm.run(terms, variables)

    # Print the result
    print(result)

# Generated at 2022-06-23 12:12:32.942397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    import json

    yaml_str = """
    ---
    name: "{{ item }}"
    """
    yaml_str_json_out = json.dumps({"name": "{{ item }}"})
    yaml_str_json = """
    ---
    name: "\\u007b\\u007b item \\u007d\\u007d"
    """

    yaml_str_native = to_bytes(yaml_str_json)

    yaml_str_native_json = """
    ---
    name: "{{"
    item: "}}"
    """

    from ansible.errors import AnsibleError
    from ansible.template import AnsibleEnvironment


# Generated at 2022-06-23 12:12:33.594508
# Unit test for constructor of class LookupModule
def test_LookupModule():
  pass

# Generated at 2022-06-23 12:12:45.154880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list'),
            convert_data=dict(type='bool'),
            template_vars=dict(type='dict', default={}),
            jinja2_native=dict(type='bool'),
            variable_start_string=dict(type='str', default='{{'),
            variable_end_string=dict(type='str', default='}}'),
            comment_start_string=dict(type='str'),
            comment_end_string=dict(type='str'),
        ),
    )
    templar = Templar(loader=DictDataLoader({}))
    templar._available_variables = dict()

    lookup_plugin = LookupModule()
    lookup_plugin._templar = templar


# Generated at 2022-06-23 12:12:56.429497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing needed variables
    template_file = 'file_to_template'
    template_vars = {'var1': 'my_var1_value'}
    result = 'my_template_result'
    converted_data = 'data'

    # Preparing test data
    terms = [template_file]
    variables = {'lookup_template_vars': template_vars}
    kwargs = {'variable_start_string': '', 'variable_end_string': ''}
    expected_template_data = "%s%s%s" % (to_bytes(result), os.linesep, to_bytes(converted_data))

    # Preparing mocks
    mock_ansible_environment = Mock()

# Generated at 2022-06-23 12:12:59.123586
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:13:00.232350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert 1 == 1

# Generated at 2022-06-23 12:13:03.610212
# Unit test for constructor of class LookupModule
def test_LookupModule():

    #LOOKUP_module = LookupModule()

    #assert LOOKUP_module is not None
    #assert LOOKUP_module._loader is not None
    #assert LOOKUP_module._templar is not None
    pass

# Generated at 2022-06-23 12:13:13.674817
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms

    import jinja2.exceptions

    # The unit tests for the template module directly test for template
    # processing. Precisely testing for sanitization is not feasible
    # without access to the templar object from the templating engine,
    # thus it is not tested here. When possible, the method
    # _templar.is_safe_text() should be used.

    # To use the test_LookupModule_run method, place it in the ansible.plugins.lookup.template
    # module file and rename it to test_run(). The unit tests can then be run with the following
    # command: ansible-test units --python 2.7 --python 3.6 --allow-disabled -v --test entities

# Generated at 2022-06-23 12:13:15.735218
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Init test
    my_lookup_module = LookupModule()
    assert my_lookup_module is not None, "Unable to instantiate LookupModule"

# Generated at 2022-06-23 12:13:25.686262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', required=True),
            _terms=dict(type='list', elements='str', required=False),
            template_vars=dict(type='dict', required=False, default=dict()),
        ),
        supports_check_mode=True,
        add_file_common_args=True,
    )
    lookup_module = LookupModule()
    lookup_module.set_options(module._display, variables=dict(template_vars=dict(foo='bar')))
    lookup_module.run([module.params['_raw_params']], module.params['template_vars'])


# Generated at 2022-06-23 12:13:26.733819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass


# Generated at 2022-06-23 12:13:37.560419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import jinja2
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # The lookup_template_vars parameter should be optional
    lookup_options = dict(lookup_template_vars = None)

    # Test params
    terms = ['./test/test_lookup_plugin/test_template.j2']
    loader = './test/test_lookup_plugin/'
    variables = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variables, host_list=['localhost'])
    variables.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-23 12:13:39.210981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 12:13:40.478238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run

# Generated at 2022-06-23 12:13:42.433543
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:13:43.474482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test constructor of class LookupModule
    assert True

# Generated at 2022-06-23 12:13:44.619970
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:13:46.410611
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:13:54.906634
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # All unit test variables come from https://github.com/ansible/ansible/blob/v2.2.0.0-1/tests/unit/plugins/lookup/test_lookup.py

    # create the testing object
    my_lookup = LookupModule()

    # This tests the ability to lookup a template
    class LookupModuleTest(unittest.TestCase):

        def test_lookup_no_template_vars(self):

            # all unit test variables needed
            terms_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
            lookupfile = os.path.join(terms_dir, 'unit', 'plugins', 'lookup', 'test', 'test.template')
           

# Generated at 2022-06-23 12:14:06.874598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This function unit test the run method of class LookupModule
    :return:
    """
    from ansible.module_utils.common.collections import ImmutableDict

    # Parameters for the test
    display.verbosity = True
    test_file = "test_file.j2"
    test_file_with_vars = "test_file_with_vars.j2"
    test_file_with_vars_var_end_string = "test_file_with_vars_var_end_string.j2"
    test_file_with_vars_var_start_string = "test_file_with_vars_var_start_string.j2"

# Generated at 2022-06-23 12:14:14.792053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_template_path must be hardcoded; ansible vars don't exist in test environment
    module = LookupModule("/usr/local/share/ansible/test/units/mock_templates")

    # test_template_data must be hardcoded; ansible vars don't exist in test environment
    result_str = module.run(['./test_template.j2'], variables=None, **{'_terms': ['./test_template.j2']})[0]
    assert result_str == "value from test_template.j2"

# Generated at 2022-06-23 12:14:15.947005
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-23 12:14:25.268865
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    vars = dict(
        ansible_search_path=[
            os.sep + 'home' + os.sep + 'test_user' + os.sep + 'ansible',
            os.sep + 'home' + os.sep + 'test_user' + os.sep + 'ansible_1',
        ]
    )

    result = lookup_module.run(terms=['test_template.jinja2'], variables=vars)

    assert result[0] == 'My name is Hovorka'

# Generated at 2022-06-23 12:14:26.303929
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _ = LookupModule()


# Generated at 2022-06-23 12:14:32.293056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = __import__('ansible.plugins.lookup.template', fromlist=['LookupModule']).LookupModule()
    terms = ["invalid_file_name.j2"]
    variables = {"ansible_search_path": ["/home/travis/build/ansible/ansible/lib/ansible/plugins/lookup/templates"]}
    # with pytest.raises(Exception):
    result = module.run(terms, variables)
    assert result == []

# Generated at 2022-06-23 12:14:35.673835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    assert isinstance(lm, LookupModule)
    assert lm._templar is not None
    assert lm._loader is not None

# Generated at 2022-06-23 12:14:37.721114
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:14:39.606529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("test")

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:14:49.471465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LUM = LookupModule()

    #Test __init_
    assert LUM._templar.environment == 'ansible'
    assert LUM._templar.convert_data is False
    assert LUM._templar.unsafe_proxy is False

    #Test set_options
    class FakeTemplar(object):
        def copy_with_new_env(self):
            return FakeTemplar()

    class FakeVars(dict):
        def copy(self):
            return FakeVars(self)

    class FakeLoader(object):
        def _get_file_contents(self, path):
            return (b'', True)

    class FakePluginLoader(object):
        def get(self, name, *args, **kwargs):
            return FakeLoader()


# Generated at 2022-06-23 12:15:00.603731
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 12:15:01.529925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule(None)


# Generated at 2022-06-23 12:15:02.520053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:15:12.851827
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    class TestTemplar(Templar):
        searchpath = [os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils'), '.']
    templar = TestTemplar([])

    lookup_run = LookupModule(templar=templar, loader=None).run

    # Make sure that it works with strings
    assert lookup_run(terms=['ansible_env.py'], variables={})[0].strip().startswith('#')

    # Make sure that it works with lists, too
    assert lookup_run(terms=[['ansible_env.py']], variables={})[0].strip().startswith('#')

    convert_data_p = False

    # Test that it raises an error if the template

# Generated at 2022-06-23 12:15:19.732703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_helper(loader, path_to_terms, lookup_options, expectations):
        lookup_module = LookupModule(loader=loader)
        lookup_module._templar = None
        lookup_module._loader = loader
        lookup_module._templar = None
        terms, variables = path_to_terms
        results = lookup_module.run(terms, variables, **lookup_options)
        assert results == expectations

    # TODO: LookupModule.run should have unit tests.
    # test_helper(dict(), ['', ''], {}, '')

# Generated at 2022-06-23 12:15:21.050571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._templar
    assert lookup._loader

# Generated at 2022-06-23 12:15:27.545821
# Unit test for method run of class LookupModule
def test_LookupModule_run():  # Just an example.
    terms = ['/templates/some_template.j2', '/templates/another_template.j2']
    variables = {'variable1':'value1', 'variable2':'value2', 'variable3':'value3'}
    # Make sure to not use the actual module.run() as this will not work as expected
    # since it is not actually fully "run"
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms, variables) == ['/templates/some_template.j2', '/templates/another_template.j2']

# Generated at 2022-06-23 12:15:35.419943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Module(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

    fake_loader = DictDataLoader({'lookup_fixtures/foo.j2': '# this is a comment\nbar: {{ test_param }}\n'})

    # no template file found
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({'_templar': Templar(loader=fake_loader, variables={'ansible_search_path': ['lookup_fixtures']})})

# Generated at 2022-06-23 12:15:42.105549
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert(lookup_plugin._templar is not None)
    assert(lookup_plugin._loader is not None)
    #assert(lookup_plugin._loader.get_basedir() is not None)
    #assert(lookup_plugin._loader.path_exists(to_bytes(lookup_plugin._loader.get_basedir())))

# Generated at 2022-06-23 12:15:47.347010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the template lookup module
    lookup_module = LookupModule()

    # Create a list of terms
    terms = ["file1.j2","file2.j2"]

    # Define empty variables
    variables = {}

    # Define empty kwargs
    kwargs = {}

    # Execute the run method
    print(lookup_module.run(terms, variables, **kwargs))

# Generated at 2022-06-23 12:15:52.759672
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule._get_text('something', None) == 'something'
    assert LookupModule._get_text('something', 'utf-8') == 'something'
    assert LookupModule._get_text(to_bytes('something', 'utf-8'), 'utf-8') == 'something'



# Generated at 2022-06-23 12:15:54.242704
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run

# Generated at 2022-06-23 12:15:59.128371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Test lookup module construction
    '''
    # Reference: https://docs.python.org/2/library/unittest.html#unittest.TestCase.assertFalse
    #
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:16:04.473608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['./some_template.j2'], {}, convert_data=False, variable_start_string='[%', variable_end_string='%]', comment_start_string='[#', comment_end_string='#]') == '{{ some_var }}'

# Generated at 2022-06-23 12:16:06.112915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:16:13.675443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create object of class LookupModule
    lm = LookupModule()
    # Terms to be templated
    terms = ['./testing_templates/test1.j2', './testing_templates/test2.j2']
    # Variables defined for template
    variables = {'Var1' : 'The Cat', 'Var2' : 'The Dog'}
    result = lm.run(terms, variables)
    assert result == ['Hello World,\n', 'Hello World,\n']

# Generated at 2022-06-23 12:16:20.187680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module=LookupModule()
    assert isinstance(module.run(['toto'], dict()), list)
    assert module.run([], dict()) == []
    assert module.run(["toto"], dict()) == ["toto"]
    assert module.run(["/toto"], dict()) == []
    assert module.run(["/toto", "/tata"], dict()) == []

test_LookupModule_run()

# Generated at 2022-06-23 12:16:29.819796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.collection.ansible_collections.myns.mycoll.plugins.modules import needtemplate

    module = needtemplate.MyTemplate()
    variables = {
        'var1': 'value1',
        'var2': 'value2',
        'var3': 'value3',
    }

    ########################################################
    # Test without any option for jinja2
    lm = LookupModule()
    terms = ['./file.j2']
    result = lm.run(terms, variables, **{})
    assert result == ['{{var1}} {{var2}} {{var3}} \n']

    ########################################################
    # Test with variable_start_string and variable_end_string

# Generated at 2022-06-23 12:16:38.539904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    Display.verbosity = 4
    terms = ['../../test/files/hello.j2']
    handle = LookupModule()
    variable_start_string = handle.get_option('variable_start_string')
    variable_end_string = handle.get_option('variable_end_string')
    variables = dict()
    variables['template_host'] = 'somehostname'
    response = handle.run(terms, variables, variable_start_string=variable_start_string, variable_end_string=variable_end_string)
    assert isinstance(response, list)
    assert response[0] == 'Hello somehostname!'

# Generated at 2022-06-23 12:16:44.648444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar, AnsibleEnvironment

    # Uncomment the following line for debugging
    # import logging; logging.basicConfig(level=logging.DEBUG)
    results = None

    test_cases = load_fixtures('template')
    for test_case in test_cases:
        if test_case.get('mock_templar'):
            templar = Templar(loader=None, variables={}, env=AnsibleEnvironment())
            lookup_module = Looku

# Generated at 2022-06-23 12:16:45.632560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:16:47.395667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    assert hasattr(lookup_class, 'run')

# Generated at 2022-06-23 12:16:58.575140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    lu._templar = MockTemplar()
    lu._loader = MockDataLoader()

    def find_file_in_search_path(variables, dir_name, file_name):
        return '/etc/ansible/%s/%s' % (dir_name, file_name)

    def get_file_contents(path):
        return b'{{ ansible_managed }}'

    lu.find_file_in_search_path = find_file_in_search_path
    lu._loader._get_file_contents = get_file_contents

    data = lu.run(['test.j2'], dict(ansible_managed='Ansible managed'))
    assert data[0] == 'Ansible managed'

# Generated at 2022-06-23 12:17:05.723989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    assert not lm.run(['file'], {'var': 'variable'}, test=True)

    # Set values in LookupModule
    lm.set_options(var_options={'test': 'variable'}, direct={'test2': 'variable2'})

    # Test get_option with defaults
    assert lm.get_option('test') == 'variable'
    assert lm.get_option('test2') == 'variable2'
    assert lm.get_option('test3') == None
    assert lm.get_option('test3', 'default') == 'default'

    # Test get_option without defaults

# Generated at 2022-06-23 12:17:09.173858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(LookupModule, ['../../test/testdata/ansible/test.tmpl'], {'testvar':'testvalue'})

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:17:10.671109
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 12:17:18.452674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class AnsibleVars(object):
        ansible_search_path = ['~/.ansible']

    lookup_base = LookupBase()
    lookup_module = LookupModule()

    lookup_base.set_options(var_options=AnsibleVars())
    lookup_module.set_loader(lookup_base._loader)
    lookup_module.set_templar(lookup_base._templar)

    terms = ['./some_template.j2']
    variables = {}
    kwargs = {}

    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-23 12:17:29.238450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import AnsibleEnvironment
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError
    import jinja2
    import os

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 12:17:40.690109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule.set_loader(dict())

    assert lookupModule.run(['does_not_exists'], dict()) == [], "Should not be able to find file"

    terms = ["test.j2", "test2.j2"]
    variables = dict()

    variables.update(generate_ansible_template_vars(terms[0], "templates/test.j2"))
    variables.update(generate_ansible_template_vars(terms[1], "templates/test2.j2"))

    def _get_file_contents(self, path):
        content = dict()
        content["templates/test.j2"] = "This is a test"
        content["templates/test2.j2"] = "This is a test2"
        b_

# Generated at 2022-06-23 12:17:51.690522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import textwrap
    import tempfile

    lookup = LookupModule()
    # Tests that require other ansible materials have been moved
    # to test/units/plugins/lookup/template_test.py

    # test that the correct exception is raised when the lookupfile cannot be found
    try:
        lookup.run([u"nosuchfile"], is_playbook=False, ansible_vars={})
        assert False
    except AnsibleError as e:
        assert u"could not be found for the lookup" in e.message

    # test that the correct exception is raised when the lookupfile cannot be found
    # in the templatedir but can be found elsewhere

# Generated at 2022-06-23 12:18:00.743369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _loader = 'ansible.parsing.dataloader.DataLoader'
    _templar = 'ansible.parsing.vault.VaultLib'

    # TODO: use setUp, setUpClass ans tearDown, tearDownClass to define
    #       params for the test
    # TODO: add params for all parameters of run
    loader_mock = Mock(_loader)
    templar_mock = Mock(_templar)
    templar_mock.copy_with_new_env.return_value = templar_mock

    terms = ['some_template.j2']
    variables = dict(variable1='value1', variable2='value2')

# Generated at 2022-06-23 12:18:05.422134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = {'msg': 'Hi!'}
    result = LookupModule().run(["../lookup_plugins/test/test_template.j2"], data)
    assert result == ['Hi!']

# Generated at 2022-06-23 12:18:07.087425
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod is not None

# Generated at 2022-06-23 12:18:17.862103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    lookupfile = '/path/to/the/template'

    # Successful case
    content = to_bytes('{{foo}} {# comment #}')
    files = [{'path': lookupfile, 'contents': content}]
    with plugin._loader.load_from_files(files):
        ret = plugin.run(
            terms=[lookupfile],
            variables={'foo': 'ok'},
            convert_data=True,
            jinja2_native=False,
            template_vars={},
            comment_start_string='{#',
            comment_end_string='#}',
        )
        assert ret == ['ok']

    # Returns empty list as ansible.template.AnsibleEnvironment raises AnsibleError
    # for convert_data=False

# Generated at 2022-06-23 12:18:28.730952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test with single file
    assert lookup.run(terms=['/tmp/template_file'], variables={}, **{'convert_data': False}) == \
        [u'{{ hostvars[inventory_hostname].ansible_distribution }}']

    assert lookup.run(terms=['/tmp/template_file'], variables={}, **{'convert_data': True}) == \
        [u'{{ hostvars[inventory_hostname].ansible_distribution }}']

    assert lookup.run(terms=['/tmp/template_file'], variables={'ansible_distribution': 'Ubuntu'}, **{'convert_data': True}) == \
        [u'Ubuntu']


# Generated at 2022-06-23 12:18:34.624626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    Term = 'tests/unit/fixtures/templates/foo.j2'
    Lookup = LookupModule()
    #  test empty args
    Lookup.run(Term, {})
    #  test with options
    Lookup.run(Term, {}, template_vars={'bar': 'baz'})

# Generated at 2022-06-23 12:18:36.538857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Verify creation of object.
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:18:45.961965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.template as template_utils
    from ansible.plugins import lookup_loader
    from ansible.template import generate_ansible_template_vars

    class BlankTemplate:
        def __init__(self, searchpath):
            self.searchpath = searchpath

    templar = BlankTemplate(searchpath=[])
    env = LookupBase()
    loader = lookup_loader.LookupModuleLoader()
    env._loader = loader
    env._templar = templar

    # Testing behavior of 'convert_data' option w/o any jinja2_native option

    # Setting convert_data option to True
    convert_data_p = True
    jinja2_native = None
    lookup_template_vars = {}
    variable_start_string = '{{'
    variable_end_

# Generated at 2022-06-23 12:18:57.411030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.facts.system.distribution import Distribution as SystemDistribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector as SystemDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution as SystemLinuxDistribution

    from ansible.module_utils.facts.system.distribution import DarwinDistribution as SystemDarwinDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDefaultDistribution as SystemLinuxDefaultDistribution
    from ansible.module_utils.facts.system.distribution import LinuxLsbDistribution as SystemLinuxLsbDistribution
    from ansible.module_utils.facts.system.distribution import LinuxRedhatDistribution as SystemLinuxRedhatDistribution

# Generated at 2022-06-23 12:19:01.624604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    template = """
        example_string: "{{ example_var }}"
        example_list:
        - first_item
        - second_item
    """
    terms = ['./lookup_test_template.yml']
    variables = {'example_var': 'example_value'}
    results = lookup.run(terms, variables)
    assert results == [template]

# Generated at 2022-06-23 12:19:10.950511
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_options(var_options=dict(), direct=dict())
    assert mod.get_option('template_vars') == {}
    assert mod.get_option('jinja2_native') == USE_JINJA2_NATIVE
    assert mod.get_option('variable_start_string') == '{{'
    assert mod.get_option('variable_end_string') == '}}'
    assert mod.get_option('comment_start_string') == '{#'
    assert mod.get_option('comment_end_string') == '#}'

# Generated at 2022-06-23 12:19:23.006754
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # No input
    terms = []
    variables={}
    lm = LookupModule()
    assert lm.run(terms, variables) == []

    # An empty lookupfile
    terms = ["/tmp/empty_file"]
    variables={}
    empty_file = open("/tmp/empty_file", "w")
    empty_file.close()
    lm = LookupModule()
    assert lm.run(terms, variables) == [u'']
    os.remove("/tmp/empty_file")

    # A lookupfile with just the word 'test' in it
    terms = ["/tmp/test_file"]
    variables={'var1': 'test'}
    test_file = open("/tmp/test_file", "w")
    test_file.write("test")

# Generated at 2022-06-23 12:19:32.680650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.executor.task_queue_manager import TaskQueueManager
    import tempfile
    tmpdir = tempfile.mkdtemp()
    datadir = os.path.join(tmpdir, 'data')
    template_dir = os.path.join(datadir, 'templates')
    os.makedirs(template_dir)
    file_path = os.path.join(template_dir, 'test.j2')

# Generated at 2022-06-23 12:19:43.848216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Defines function here so it can be mocked
    def get_option(self, opt):
        return self.options.get(opt, None)

    # Mock class
    my_mock = type(
        'LookupModule',
        (object,),
        {
            'options': {
                'template_vars': None,
                'convert_data': None,
                'jinja2_native': None,
                'variable_start_string': None,
                'variable_end_string': None,
                'comment_start_string': None,
                'comment_end_string': None,
            },
            'get_option': get_option,
        }
    )

    # Mock _templar

# Generated at 2022-06-23 12:19:50.954952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager

    # variables setup
    secret_vault_pw = 'my_secret_vault_pass'
    vault_fixture = 'lookup_plugins/fixtures/template.vault'
    vault_fixture_pw = 'lookup_plugins/fixtures/template.pw'
    template_fixture = 'lookup_plugins/fixtures/template.j2'
    # put the vault_password_file generated by the fixture vault_fixture_pw
    #  into a temporary directory because the path cannot contain a colon (:)
    _, vault_pw_file = tempfile.mkstemp()

# Generated at 2022-06-23 12:19:58.070836
# Unit test for constructor of class LookupModule
def test_LookupModule():

    options = {"_terms": ["./some_template.j2"]}
    assert LookupModule().run(**options) == []

    options = {"_terms": ["./some_template.j2"], "convert_data": False,
               "variable_start_string": "{{", "variable_end_string": "}}",
               "comment_start_string": "{#", "comment_end_string": "#}",
               "jinja2_native": False, "template_vars": {}}
    assert LookupModule().run(**options) == []

# Generated at 2022-06-23 12:19:58.617297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:20:08.621015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for lookup template

    # Create a temporary file for unit test
    from tempfile import mkstemp
    from shutil import copyfileobj, move
    from os import fdopen, remove

    fh, abs_path = mkstemp()
    with fdopen(fh,'w') as new_file:
        with open("/etc/ansible/roles/test/templates/template.j2") as old_file:
            new_file.write(old_file.read())

    # Instantiate class LookupModule
    lookup_mod = LookupModule()

    # Create a mock of ansible options

# Generated at 2022-06-23 12:20:17.735292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''
    lookup_module = LookupModule()

    # Find first file on the 'templates' subdirectory, on the search path,
    #  whose name is 'basic.j2' and return its content
    assert lookup_module.run(['./basic.j2'],
                             dict(ansible_search_path=['/home/myuser/myproject'])) \
           == [to_bytes('Hello world', encoding='utf-8')]

    # Same as above, but using the optional parameters 'jinja2_native' and
    # 'convert_data'