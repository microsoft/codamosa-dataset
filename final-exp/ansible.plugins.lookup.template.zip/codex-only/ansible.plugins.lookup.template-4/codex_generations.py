

# Generated at 2022-06-23 12:10:05.789805
# Unit test for constructor of class LookupModule
def test_LookupModule():

    L = LookupModule()
    assert L

# Generated at 2022-06-23 12:10:08.410781
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:10:17.209781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test data (file content)
    testname = "test_LookupModule_run"
    testvars = dict()
    testvars['env'] = dict()
    testvars['env']['PATH'] = "/bin:/usr/bin:/usr/local/bin"
    testvars['env']['HOME'] = "/Users/foobar"
    testvars['env']['LOGNAME'] = "foobar"
    testvars['env']['USER'] = "foobar"
    testvars['inventory_hostname'] = "localhost"
    testvars['template_host'] = "localhost"
    testvars['template_uid'] = 0
    testvars['template_path'] = None
    testvars['template_mtime'] = None

# Generated at 2022-06-23 12:10:25.637793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create Mocked Objects
    class MockLoader:
        def __init__(self, return_val):
            self.return_val = return_val

        def _get_file_contents(self, path):
            return self.return_val

    class MockTemplar:
        def __init__(self, return_val):
            self.return_val = return_val

        def template(self, template_data, preserve_trailing_newlines, convert_data):
            return self.return_val

    class MockSearchPath:
        def __init__(self, return_val):
            self.return_val = return_val
        def search(self, variable, directory, paths, data=None):
            return self.return_val

    # Call function test
    # Create LookupModule instance for test and set its attributes


# Generated at 2022-06-23 12:10:26.593468
# Unit test for constructor of class LookupModule
def test_LookupModule():
    templar = LookupModule()

# Generated at 2022-06-23 12:10:29.963096
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the constructor with a valid value, then an invalid value
    lookup_module = LookupModule()
    assert lookup_module is not None
    try:
        lookup_module = LookupModule(1)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 12:10:30.730467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-23 12:10:39.700985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyDiff():
        context = 7
    class DummyLoader():
        def _get_file_contents(self, path):
            return path + ": Contents", DummyDiff()

    class DummyTemplar():
        def set_available_variables(self, variables):
            self.variables = variables

        def set_environment(self, env):
            self.env = env

        def template(self, content, preserve_trailing_newlines=False, escape_backslashes=True, convert_data=True, fail_on_undefined=True):
            return content

        def copy_with_new_env(self, environment_class=None):
            return self


# Generated at 2022-06-23 12:10:45.384387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    terms = ['etc/passwd']
    variables = {'test': 'test', 'test2': 2}
    plugin.run(terms, variables, __loader__=None, __template__=None, convert_data=False, variable_start_string='[%',
               variable_end_string='%]', template_vars={}, jinja2_native=False, comment_start_string='[#',
               comment_end_string='#]')

# Generated at 2022-06-23 12:10:48.814911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l_instance = isinstance(l, LookupModule)
    assert l_instance, "the object should be a instance of LookupModule"


# Generated at 2022-06-23 12:10:58.669281
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instances of necessary classes
    class AnsibleModule():

        def __init__(self):
            self.params = {
                'template_vars': [
                    {'key1': 'value1'}, {'key2': 'value2'}
                ]
            }

    class AnsibleOptions():

        def __init__(self, params):
            self.verbosity = 4
            self.connection = 'local'
            self.module_name = 'debug'
            self.forks = 10
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.diff = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False

# Generated at 2022-06-23 12:11:07.873005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins

    # Create a mock "builtins.open" function, used inside lookup module:
    def mock_open(self, filename, mode='r'):
        # Return a file-like object, but just for the test.
        return mock_open.file_obj

    mock_open.file_obj = None

    # Create a mock "file object", returned by mock_open:
    class MockFileObj:
        def __init__(self, name, mode='r'):
            pass

        def read(self):
            return '{{ NAME }} is {{ NUMBER }}'

        def close(self):
            pass

    # Stub out open:
    mock_open.file_obj = MockFileObj('/tmp/doesnt_matter')
    builtins.open = mock_open

# Generated at 2022-06-23 12:11:09.499062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:11:11.808472
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-23 12:11:12.647470
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj is not None

# Generated at 2022-06-23 12:11:15.278425
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables = dict()
    lookup = LookupModule()
    lookup.run(terms = ['ansible/test/unit/templates/template.j2'], variables = variables, convert_data=True)

"""
TODO
- support vars option to pass in as variables
- allow alternate extension? and other argument parsing
- maybe check for recursion
- support templates in searched dirs?
"""

# Generated at 2022-06-23 12:11:21.363455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    # create a loaded_templated to be able to create template
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    options = PlayContext()
    variables = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variables, host_list=[])
    template = LookupModule(loader=loader, variables=variables, templar=None, shared_loader_obj=inventory)
    # create a test_template that will be templated
    test_template = "{{ test_template }}"
    # create a test_term that will replace test_template
    test_term = "event"
   

# Generated at 2022-06-23 12:11:24.551447
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    with pytest.raises(AnsibleError):
        l.run(terms=['/tmp/doesnotexist'], variables=dict(), convert_data=False, jinja2_native=False,
              variable_start_string='%{', variable_end_string='}', comment_start_string='%#',
              comment_end_string='#%'
              )

# Generated at 2022-06-23 12:11:36.025891
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests the run method with a jinja2_native=True argument. The only way to make this method testable is
    # to mock out everything but the native template engine.
    def test_LookupModule_run_with_jinja2_native():

        import jinja2
        from ansible.template import jinja2_native_vars

        # These fake functions simulate the function calls during the execution of the lookup module
        def fake_load_module(args):
            return None
        def fake_template(template, preserve_trailing_newlines=False, convert_data=True, escape_backslashes=True,
                          templatevars=None):
            # The templates will be empty because we do not need the actual data in the test
            return ""
        def fake_convert_data(template):
            return ""
       

# Generated at 2022-06-23 12:11:47.444907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        convert_data=False,
        variable_start_string='{{',
        variable_end_string='}}',
        jinja2_native=False,
        template_vars={},
        comment_start_string='{#',
        comment_end_string='#}'
    )
    lookup_module = LookupModule()

    # test with dict as vars
    var_input = dict(hello='world')
    result = lookup_module._run_terms(terms=['{{ hello }}'], variables=var_input, **args)
    assert result == ['world']

    # test with dict inside dict as vars
    var_input = dict(a=dict(hello='world'), b=dict(something=33))

# Generated at 2022-06-23 12:11:48.493872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:11:55.095065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.verbosity = 0

    # A simple lookup test
    assert LookupModule().run(["/dev/null"], dict()) == [b'']

    # Check the native mode processing (issue #25752)
    assert isinstance(LookupModule().run(["/dev/null"], dict(), jinja2_native=True)[0], NativeJinjaText)



# Generated at 2022-06-23 12:11:56.597775
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:12:03.857277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_templates = ["a.j2", "b.j2", "c.j2"]
    test_vars = dict(foo="bar")
    import __main__
    __main__.__dict__.update(dict(vars=test_vars))
    test_results = lookup_module.run(terms=test_templates, variables=test_vars)
    assert test_results == ["a", "b", "c"]

# Generated at 2022-06-23 12:12:04.935712
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:12:15.868892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for method run of class LookupModule
    # FROM: https://github.com/ansible/ansible/blob/devel/test/units/plugins/lookup/test_template.py
    # This test does not have a has_run test because it would clutter up the test output.
    # Instead, review the Jenkins test results for changes to the output of this test.
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    def setUp(self):
        self.lookup = LookupModule()

    def tearDown(self):
        pass

    def test_origin_template(self):
        # Test origin of the template in a Windows path.
        terms = ['test/test_lookup_plugins/template/origin.j2']

# Generated at 2022-06-23 12:12:17.233671
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()

# Generated at 2022-06-23 12:12:26.482361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    # Prepare test data
    lookup_plugin = LookupModule()
    valid_path = 'tests/testplaybook/templates/test_jinja2.conf'
    invalid_path = 'tests/testplaybook/templates/nonexistent.conf'
    terms = [valid_path]
    variables = {
        'ansible_search_path': ['/etc/ansible'],
        'veggies': ['carrots', 'kale', 'spinach'],
        'main_course': 'lamb chops',
    }

    # Run the test
    result = lookup_plugin.run(terms, variables)

    # Ensure the proper result was returned
    assert result == ['# invalid jinja2 syntax: {{ foo }\n']

# Generated at 2022-06-23 12:12:38.929087
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import os
    myclass = LookupModule()
    myclass.run(["test"], { "ansible_search_path": ["./test/unit/lookup_plugins", "./test/unit/lib/ansible/modules/test"] }, convert_data=True)
    myclass.run(["undefined"], { "ansible_search_path": ["./test/unit/lookup_plugins", "./test/unit/lib/ansible/modules/test"] }, convert_data=True)
    myclass.run(["test2"], { "ansible_search_path": ["./test/unit/lookup_plugins", "./test/unit/lib/ansible/modules/test"] }, convert_data=True)

# Generated at 2022-06-23 12:12:44.987145
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['./some_template.j2']
    variables = {'name': 'Ansible'}
    kwargs = {'variable_start_string': '[%', 'variable_end_string': '%]'}

    class Test_LookupModule(LookupBase):
        def __init__(self, terms, variables, **kwargs):
            self._terms = terms
            self._variables = variables
            self._options = kwargs

    lookup_module = Test_LookupModule(terms, variables, **kwargs)

    result = lookup_module.run(terms, variables, **kwargs)

    assert result == [to_bytes('Hello, World from Ansible', errors='surrogate_or_strict')]

# Generated at 2022-06-23 12:12:56.086324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    if PY3:
        # This is a lookup plugin, which can only be tested with a strategy plugin
        # We simply trigger an exception here as a reminder that a test is missing
        raise Exception('Test not implemented')

    lookup = LookupModule()


# Generated at 2022-06-23 12:13:08.144597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test simple template
    result = LookupModule().run(['./single_j2_template'], {}, convert_data=False, jinja2_native=False)
    assert result == ["Hello World!\n"]
    result2 = LookupModule().run(['./single_j2_template'], {}, convert_data=True, jinja2_native=False)
    assert result2 == ["Hello World!\n"]
    result3 = LookupModule().run(['./single_j2_template'], {}, convert_data=False, jinja2_native=True)
    assert result3 == ["Hello World!\n"]
    result4 = LookupModule().run(['./single_j2_template'], {}, convert_data=True, jinja2_native=True)
    assert result4

# Generated at 2022-06-23 12:13:16.387932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleUndefinedVariable, AnsibleLookupError
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six.moves import StringIO
    from ansible.template import generate_ansible_template_vars
    from ansible.plugins.loader import LookupModule as LookupModule_loader
    from ansible.plugins.lookup import LookupModule as LookupModule_lookup
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    class Options:
        def __init__(self, var_options=None, direct=None):
            pass


# Generated at 2022-06-23 12:13:27.176155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with jinja2_native disabled both in Ansible and for the lookup
    lookup = LookupModule()
    terms = ['test.txt']
    variables = {'var': 'test'}
    assert lookup.run(terms, variables, variable_start_string='[%', variable_end_string='%]', comment_start_string='[#', comment_end_string='#]') == ['[% var %]']

    # test with jinja2_native globally enabled and for the lookup
    lookup = LookupModule()
    terms = ['test.txt']
    variables = {'var': 'test'}

# Generated at 2022-06-23 12:13:30.393193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(direct={'key': 'value'})
    assert lookup.get_option('key') == 'value'

# Generated at 2022-06-23 12:13:39.169890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests.mock import patch
    from ansible.plugins.loader import lookup_loader, LookupModule
    import ansible.plugins
    # setup context
    lookup_plugin = LookupModule()
    mock_loader = lookup_loader._create_loader_for_path(
        os.path.join(os.path.dirname(ansible.plugins.__file__), 'lookup')
    )
    lookup_loader.set_loader(mock_loader)

    test_template_path = os.path.join(os.path.dirname(ansible.plugins.__file__), 'lookup_plugins', 'template.j2')
    test_template_data = "{{lookup_parameter}}"
    test_vari

# Generated at 2022-06-23 12:13:47.858820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    cwd = os.path.dirname(__file__)

# Generated at 2022-06-23 12:13:50.970104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["test_template.j2"]
    variables = {"ansible_search_path": ["/home/xzhang/temp/ansible/testcase/template"]}
    module.run(terms=terms, variables=variables)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:14:02.681878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class env:
        def __init__(self, var_list):
            self.variable_manager = var_list

    input_variables = {u'role_name': u'my-role',
                       u'gid': 1000,
                       u'username': u'alice',
                       u'uid': 1000,
                       u'home': u'/home/alice',
                       u'groupname': u'users',
                       u'shell': u'/bin/bash',
                       u'repo_url': u'https://github.com/alice/ansible-role-my-role.git'}
    input_variables = env(input_variables)
    terms = u'/home/alice/ansible-role-my-role/tests/test_templates/test_template.j2'

# Generated at 2022-06-23 12:14:04.772974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')
    assert hasattr(lookup, 'find_file_in_search_path')

# Generated at 2022-06-23 12:14:13.327492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Import needed module
    import ansible.plugins.loader as ploader

    # Init plugins loader
    ploader.load_plugins()

    # Init lookup module
    lookup_module = LookupModule()

    # Init fake loader
    fake_loader = FakerLoader()

    # Init fake variables
    fake_variables = dict(template_dir='/usr/share/ansible/templates',
                          template_path='/usr/share/ansible/templates:/etc/ansible/templates',
                          template_hostvars=dict(my_host=dict(ansible_interfaces=["eth0", "eth1"])),
                          template_uid=0,
                          template_user='root',
                          template_path_type='unix')

    # Register fake loader to lookup
    lookup_module.set

# Generated at 2022-06-23 12:14:14.740168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:14:27.180677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Some environment variables for the unit test
    os.environ["ANSIBLE_LOOKUP_PLUGIN_CONVERT_DATA"] = "True"
    os.environ["ANSIBLE_LOOKUP_PLUGIN_TEMPLATE_VARS"] = "{}"
    os.environ["ANSIBLE_LOOKUP_PLUGIN_JINJA2_NATIVE"] = "False"
    os.environ["ANSIBLE_LOOKUP_PLUGIN_VARIABLE_START_STRING"] = "{{"
    os.environ["ANSIBLE_LOOKUP_PLUGIN_VARIABLE_END_STRING"] = "}}"


# Generated at 2022-06-23 12:14:28.920647
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:14:39.819434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup a test environment and create a class instance
    import os
    import sys
    import json
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_environment = os.path.join(test_dir, 'test_environment')
    test_path = os.path.join(test_environment, 'roles', 'role1', 'tasks')
    sys.path.append(test_path)
    from test_lookup_plugin import TestLookupModule
    tlm = TestLookupModule()

    # Test template with 'convert_data' option not specified
    ret_expected = ["{{ foo }}\n"]
    ret = tlm.run(['./test_template.j2'], variables={'foo': 'bar'})

# Generated at 2022-06-23 12:14:41.269893
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:14:42.736337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:14:52.950537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    import ansible.plugins.loader
    ansible.plugins.loader._lookup_plugins = {}

    from ansible.plugins.lookup import LookupModule
    from ansible.template import template

    template_data = '''
    {% for i in range(5) %}
    {{i}}
    {% endfor %}
    '''

    results = template(template_data,
        convert_data=None,
        preserve_trailing_newlines=True,
        escape_backslashes=False,
        templar=None,
        variables=dict(range=range)
    )

    print(results)

    lookup_module = LookupModule()


# Generated at 2022-06-23 12:14:56.226672
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # assign values for test
    lookup = LookupModule()

    assert lookup is not None

    # test return of ansibledocgen
    def test():
        return "test"

    lookup._templar = test

    result = lookup.run(["test"], ["test2"])

    assert result == "test"

# Generated at 2022-06-23 12:14:58.320734
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    lm.run([], dict())

# Generated at 2022-06-23 12:14:59.897089
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:15:02.671926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my = LookupModule()
    assert my._options == {}
    assert my._display == Display()
    assert 'ansible_search_path' in my._templar._available_variables



# Generated at 2022-06-23 12:15:12.969160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    def _get_file_contents(path):
        # TODO: use mock_open
        if not os.path.exists(path):
            raise AnsibleError("missing template file %s" % path)
        data = to_bytes(u'{{ foo }}', errors='surrogate_or_strict')
        show_data = None
        return data, show_data

    plugin = LookupModule()

    class MockLoader(object):
        def __init__(self, path):
            self._path = path

        def _get_file_contents(self, path):
            return _get_file_contents(self._path)

    # Success case
    templar = plugin._templar

# Generated at 2022-06-23 12:15:20.451514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for constructor of class LookupModule'''

    def dummy_loader(*args):
        """dummy_loader."""
        return ["The name of this lookup plugin is lookup_plugin.py"]

    test_obj = LookupModule()

    # read_data() called by __init__()
    # We can not test read_data() here, because it requires fs and the
    # test doesn't have it.
    test_obj.set_loader(dummy_loader)

# Generated at 2022-06-23 12:15:29.297854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.verbosity = 4
    import os
    import shutil
    import pytest

    # Empty file for templating test
    test_template_file = 'test_template.j2'
    test_template_content = 'test_template_content'
    with open(test_template_file, 'w') as f:
        f.write(test_template_content)

    # Empty file for templating test
    test_template_file = 'test_template_convert_data_true.j2'
    test_template_content = '{{ {1: {2: {3}}} }}'
    with open(test_template_file, 'w') as f:
        f.write(test_template_content)

    # Empty file for templating test

# Generated at 2022-06-23 12:15:30.502970
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_instance = LookupModule()
    print(lookup_instance)

# Generated at 2022-06-23 12:15:36.017725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # args
    display = Display()
    data = {'lookup_file': './some_template.j2'}
    terms = ['../terms-file']
    variables = {}
    kwargs = {}

    # test
    lookup_obj = LookupModule(display=display)
    lookup_obj.run(terms, variables, **kwargs)

    for term in terms:
        assert term in lookup_obj._loader.path_dwim(to_bytes('./some_template.j2'))



# Generated at 2022-06-23 12:15:47.416802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run method of LookupModule Class
    """

    # Test 1: test newsearchpath functionality
    ############################################
    # Test variables
    basedir = '/home/redhat'
    templatedir = 'templates'
    terms = '/templates/file'
    lookupfile = '/home/redhat/templates/file'
    searchpath = ['/home/redhat']
    newsearchpath = ['/home/redhat/templates', '/home/redhat']
    jinja2_native = False

    # Test setup
    test_LookupModule = LookupModule()
    test_LookupModule._templar = Template()
    test_LookupModule._loader = DictDataLoader({
        lookupfile: b'some text',
    })
    test_LookupModule.set_options

# Generated at 2022-06-23 12:16:00.040662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    show_data = """---
    - debug:
       var: lookup('template', './some_template.j2')
"""
    b_template_data = """{{ foo }}"""
    lookupfile = 'some_template.j2'

    class AnsibleModuleFake(object):
        def __init__(self,*args, **kwargs):
            self.params = {}

    lm = LookupModule(AnsibleModuleFake())
    variables = {'foo': 'bar'}
    terms = [lookupfile]
    ret = lm.run(terms,variables,convert_data=True)
    assert(ret == [variables['foo']])

    lm = LookupModule(AnsibleModuleFake())
    variables = {'foo': 'bar'}

# Generated at 2022-06-23 12:16:02.484511
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:16:12.010134
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Instance of LookupModule with default values
    template_lookup = LookupModule()
    # data_files/templates/templates.yml, data_files/templates/templates.j2, data_files/templates/templates_no_convert_data.yml, data_files/templates/templates_no_convert_data.j2, data_files/templates/templates_native.yml, data_files/templates/templates_native.j2
    data_files_path = "test/unit/plugins/lookup/data_files/template_lookup/"
    jinja2_native = False
    convert_data = True
    lookup_template_vars = {"var1": "value1", "var2": "value2"}

# Generated at 2022-06-23 12:16:22.475875
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a new class object
    LookupModule_obj = LookupModule()

    # Create a new variable object
    variable_obj = {'ansible_search_path': ['.']}

    # Create a new terms object
    terms_obj = ['test.j2']

    # Create a new kwargs object
    kwargs_obj = {}

    # Call method run with arguments and check the return has the correct value
    assert LookupModule_obj.run(terms_obj, variable_obj, **kwargs_obj) == [u'This is a test']

    # Call method run with arguments and check the return has the correct value
    assert LookupModule_obj.run(terms_obj, variable_obj, **kwargs_obj) == [u'This is a test']

    # Call method run with arguments and check the return has the correct

# Generated at 2022-06-23 12:16:32.206830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    if sys.version_info[0] < 3:
        module_path = 'ansible.plugins.lookup.template'
    else:
        module_path = 'ansible.plugins.lookup.template.LookupModule'

    sys.modules['ansible.plugins.lookup.template'] = sys.modules[__name__]
    import ansible.plugins.lookup.template as lookup_template_module

# Generated at 2022-06-23 12:16:33.130300
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup)

# Generated at 2022-06-23 12:16:41.611877
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import io
    import sys
    from collections import namedtuple
    from ansible.errors import AnsibleError

    # Mock objects
    class MockEnv:
        def get_snippet_paths(self):
            return []

    class MockOptions(namedtuple('MockOptions', ('variable_start_string', 'variable_end_string', 'searchpath'))):
        @property
        def finalize(self):
            return True

    class MockVariables:
        searchpath = []
        ansible_search_path = []

    class MockTemplate:
        def __init__(self):
            self.took_kwarg_convert_data = None
            self.took_kwarg_searchpath = None
            self.took_kwarg_variable_start_string = None
            self.took_kw

# Generated at 2022-06-23 12:16:52.876275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run([], {}) == []

    # we are intentionally not asserting about the environment here
    # we are asserting that the string we put in comes out unchanged
    # and that the environment not change from a blank state to
    # a populated one.
    terms = ["{{ 'test_value' }}"]
    assert lookup.run(terms, {}) == terms

    assert lookup.run(["/path/to/nowhere"], {}) == []

    assert lookup.run(["{{ 'test_value' }}"], {'template_vars': {'my_var': 'my_value'}}) == \
           ["my_value"]

# Generated at 2022-06-23 12:16:54.308655
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 12:16:54.940876
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None

# Generated at 2022-06-23 12:16:56.730080
# Unit test for constructor of class LookupModule
def test_LookupModule():

    #instantiate the LookupModule class
    obj = LookupModule()

# Generated at 2022-06-23 12:17:01.463286
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Dummy arguments
    terms = ["arg"]
    variables = {"vars": "vars"}
    ansible_lookup = LookupModule(terms, variables)
    assert ansible_lookup is not None

# Generated at 2022-06-23 12:17:11.090486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self):
            self.convert_data = False
            self.template_vars = {}
            self.jinja2_native = False
            self.variable_start_string = '{{'
            self.variable_end_string = '}}'
            self.comment_start_string = '#'
            self.comment_end_string = '#'

    class DummyModule(object):
        def __init__(self):
            self.templar = None
            self.params = {}
            self.args = ()
            self.warnings = []

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise AnsibleExitJson



# Generated at 2022-06-23 12:17:12.266046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule() != None)

# Generated at 2022-06-23 12:17:21.397046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    lookup = LookupModule()

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager.get_vars())
    lookup._templar = templar

    search_paths = ['/home/username/templates', '/etc/ansible/templates']
    inventory.set_variable_manager(variable_manager)
    variable_manager.extra_v

# Generated at 2022-06-23 12:17:26.807238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import tempfile
    tf = tempfile.mktemp()
    with open(tf, "w") as f:
        f.write("{{ ansible_managed }}")

    l = LookupModule()
    data = l.run([tf], dict(
        ansible_managed="Ansible managed: {file} modified on %s" % "TBD"),
        variable_start_string="${",
        variable_end_string="}",)
    assert data[0] == "Ansible managed: {file} modified on TBD"

# Generated at 2022-06-23 12:17:28.582395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:17:34.937821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 12:17:42.452464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import textwrap
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock, Mock, call
    from ansible.plugins.lookup.template import LookupModule

    jinja2_native = os.environ.get('ANSIBLE_JINJA2_NATIVE')
    os.environ['ANSIBLE_JINJA2_NATIVE'] = 'True'

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.lookup_class = LookupModule()
            self.lookup_class._templar = MagicMock()
            self.lookup_class.set_loader = Mock()


# Generated at 2022-06-23 12:17:43.768030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert True

# Generated at 2022-06-23 12:17:45.563243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:17:48.921708
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ["test_terms"]
    variables = ["test_variables"]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)

    assert result == [u'']

# Generated at 2022-06-23 12:17:59.132330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    lookup_obj.set_loader({
        '_get_file_contents': lambda x: ('test', False)
    })
    lookup_obj.set_options({
    })

    class FakeTemplar:
        def set_temporary_context(self, **kwargs):
            return kwargs
        def copy_with_new_env(self, **kwargs):
            return self
        def template(self, *args, **kwargs):
            return 'this is template'

    lookup_obj._templar = FakeTemplar()
    assert lookup_obj.run(['test.j2'], {'ansible_search_path': ['/tmp'], 'a': 'b'}) == ['this is template']

    # no args

# Generated at 2022-06-23 12:18:10.106932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self):
            self.convert_data = False
            self.variable_start_string = '{{'
            self.variable_end_string = '}}'
            self.comment_start_string = '{#'
            self.comment_end_string = '#}'
            self.jinja2_native = False

    class TaskVars(object):
        def __init__(self):
            self.templates = './templates'
            self.ansible_search_path = ['.']
            self.ansible_hidden_variable = 'ansible_hidden_variable'
            self.ansible_variable = 'ansible_variable'

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 12:18:11.754070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:18:12.636002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    TestLookupModule = LookupModule()
    assert TestLookupModule

# Generated at 2022-06-23 12:18:14.021152
# Unit test for constructor of class LookupModule
def test_LookupModule():

    ret = LookupModule()
    assert(ret != None)


# Generated at 2022-06-23 12:18:15.385874
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm

# Generated at 2022-06-23 12:18:26.767301
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # run_module - specific parameters
    params = dict(
        terms = ['./some_template.j2'],
        variable_start_string = '[%',
        variable_end_string = '%]',
        comment_start_string = '[#',
        comment_end_string = '#]',
    )

    # initialising the LookupModule class
    lookup_plugin = LookupModule()

    # initialising the arguments
    lookup_plugin.set_options(direct=params)

    assert lookup_plugin._templar._available_variables.get('variable_start_string') == '[%'
    assert lookup_plugin._templar._available_variables.get('variable_end_string') == '%]'

# Generated at 2022-06-23 12:18:38.037167
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import pytest

    from ansible.plugins.lookup.template import LookupModule

    terms = ['some_template.j2']
    variables = {'some_var': 'some_value'}
    options = {'some_option': 'some_value'}

    # Test basic instantiation
    lookup_module = LookupModule()
    assert lookup_module

    # Test basic instantiation
    lookup_module.run(terms=terms, variables=variables, **options)
    assert lookup_module

    # Test basic instantiation
    with pytest.raises(AnsibleError):
        lookup_module.run(terms=[''], variables=variables, **options)

# Generated at 2022-06-23 12:18:46.885752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test raw text with Jinja2 native types usage
    with open(os.path.join(os.path.dirname(__file__), '../../templates/test_template.txt')) as f:
        test_template = f.read()

    test_vars = {
        'atest': [u'one', u'two', u'three'],
        'btest': u'hello',
        'ctest': {u'a': 1, u'b': 2, u'c': 3},
        'dtest': u'goodbye',
    }

    # Use native types
    result = module.run([test_template], test_vars)


# Generated at 2022-06-23 12:18:51.630158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # it returns a list of strings
    assert isinstance(lookup.run(terms=['/template'], variables={}), list)
    assert isinstance(lookup.run(terms=['/template'], variables={})[0], to_text)

# Generated at 2022-06-23 12:18:59.242660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    from ansible.compat.tests import unittest

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import text_type

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.template import Templar


# Generated at 2022-06-23 12:19:11.242419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Desired output for each test

# Generated at 2022-06-23 12:19:16.975169
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Generate lookup class object
    lookup = LookupModule()

    # run generates a result which is a list
    result = lookup.run(terms=[], variables={})
    assert type(result) == list
    assert result == []

    result = lookup.run(terms=['/tmp'], variables={})
    assert type(result) == list
    assert result == []

# Generated at 2022-06-23 12:19:28.736299
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing with old style options
    test_tmpl = '{{ lookup("template", "foo.j2") }}'
    test_env = dict(template_host = "localhost",
                    template_uid = 0,
                    template_user = "someone",
                    template_path = "/foo/bar/baz.j2")
    test_loader = DictDataLoader({
        "/foo/bar/baz.j2": "Hello World",
    })
    test_loader.mock_add_directory("/foo/bar")
    test_templar = Templar(loader=test_loader, variables=test_env)

    opts = dict(
        _raw_params="foo.j2",
        _terms=["foo.j2"],
    )

# Generated at 2022-06-23 12:19:29.617053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 12:19:37.120939
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    lookup.set_options(var_options={'var_options': 'var_options'}, direct={'direct': 'direct'})

    test_var_options = {'var_options': {'var_options': 'var_options'}}
    test_direct = {'direct': {'direct': 'direct'}}

    assert lookup._options == test_direct, "_options error"
    assert lookup._templar._available_variables == test_var_options, "_templar._available_variables error"

# Generated at 2022-06-23 12:19:47.830673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader())

    terms = ['./test_lookup_module.j2']
    variables = {'tax': 12.5}

    assert lookup_module.run(terms, deepcopy(variables), convert_data=True) == ['The tax is 15.0\n']
    assert lookup_module.run(terms, deepcopy(variables), convert_data=True, jinja2_native=True) == ['The tax is 15.0\n']
    assert lookup_module.run(terms, deepcopy(variables), convert_data=False, jinja2_native=False) == ['The tax is {{ tax * 1.2 }}\n']

# Generated at 2022-06-23 12:19:49.072852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No unit tests for this class yet"

# Generated at 2022-06-23 12:19:50.688271
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ansible = __import__('ansible')
    l = LookupModule(DummyVarsModule(), Loader())
    assert isinstance(l, LookupBase)


# Generated at 2022-06-23 12:19:59.812792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of lookup module LookupModule.
    """
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    # Initialize objects
    vault_pass = 'testpass'
    vault = VaultLib(vault_pass)
    loader = DataLoader()
    variable_manager = VariableManager()
    display = Display()

    # Get path of directory of this script
    test_dir_path = os.path.dirname(os.path.realpath(__file__))

    # Define test files
    lookup_file = 'lookup_fixtures/template_input.j2'

# Generated at 2022-06-23 12:20:09.361043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    def test_lookup(terms, variables, expected, kwargs):
        lmod = LookupModule()
        lmod.set_options(var_options=variables, direct=kwargs)
        ret = lmod.run(terms=terms, variables=variables, **kwargs)
        assert ret == expected

    # a simple jinja2 template
    test_lookup(
        terms=['test_jinja2.j2'],
        variables={'name': 'John'},
        expected=['Hello John!'],
        kwargs={}
    )

    # a simple jinja2 template, with several jinja2 statements in input