

# Generated at 2022-06-23 12:10:10.472058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_for_run = lookup_module.run
    mock_loader = MagicMock()
    mock_loader.get_basedir.return_value = '/path/to/playbooks'
    mock_loader.path_dwim.return_value = 'file_path'
    lookup_module.set_loader(mock_loader)
    assert lookup_module_for_run(['file'], {}) == ["file_contents"]


# Generated at 2022-06-23 12:10:21.442951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import unittest

    class LookupModuleTester(unittest.TestCase):

        def setUp(self):
            sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

        def test_run_passes(self):
            # Setup
            config_data = {'ansible_templating_plugin': 'AnsibleEnvironment'}
            self.mock_loader = mock_loader_builder(config_data)
            self.mock_templar = mock_templar_builder()
            self.mock_display = Mock()
            self.mock_tmp = Mock()
            self.lookup_base = LookupBase()

            lookup_module = LookupModule()

# Generated at 2022-06-23 12:10:22.822935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._loader is not None

# Generated at 2022-06-23 12:10:29.780655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup object
    lm = LookupModule()

    # Get environment
    var_options = {}
    path = os.path.join(os.getcwd(), '../../lookup_plugins/tests/')
    var_options['lookup_dirs'] = [path]
    var_options['_original_basename'] = 'foo'
    lm.set_options(var_options)

    # Test to see if exists and if it is the right file
    assert lm.run(['test.j2'], var_options) == ['this is a test']

# Generated at 2022-06-23 12:10:38.060410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = []

# Generated at 2022-06-23 12:10:43.426324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader
    lookup_plugin = ansible.plugins.loader.lookup_loader.get("template")
    file_path = "/etc/ansible/roles/common/templates/sshd_config"
    terms = [ file_path ]
    variables = {}
    display = Display()
    display.verbosity = 5
    res = lookup_plugin.run(terms, variables, display, file_path)
    print("Template file %s was processed successfully" % file_path)
    print("Result:")
    print(str(res))

# test_LookupModule_run()

# Generated at 2022-06-23 12:10:55.817574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    results = []

    def _get_file_contents(path):
        assert(path)

        if path.endswith('/template1.j2'):
            data = to_bytes('hello_world', errors='surrogate_or_strict')
            show_data = '[template1.j2]\nhello_world'
        elif path.endswith('/template2.j2'):
            data = to_bytes('{{ template1 }}', errors='surrogate_or_strict')
            show_data = '[template2.j2]\n{template1}'

# Generated at 2022-06-23 12:11:06.761784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up mock
    class MockJinja2Templar:
        def __init__(self):
            self.data = ""
            self.variables = {}

        def copy_with_new_env(self, environment_class):
            return self

        def set_temporary_context(self, **kwargs):
            return self

        def template(self, data, preserve_trailing_newlines, convert_data, escape_backslashes):
            self.data = data
            return data

    class MockAnsibleEnvironment:
        def __init__(self, loader=None, variables=None):
            self.loader = loader
            self.variables = variables

    class MockAnsibleLoader:
        def __init__(self):
            self.path_cache = {}


# Generated at 2022-06-23 12:11:15.526110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = _get_templar()
    lookup_module._loader = _get_loader()
    lookup_module.set_options(direct={
        'variable_start_string': '{{',
        'variable_end_string': '}}',
    })
    assert lookup_module.run(
            terms=['config.j2'],
            variables={'author': 'Fred'}
        ) == ['config file test author is Fred']
    lookup_module.set_options(direct={
        'variable_start_string': '[%',
        'variable_end_string': '%]',
        'comment_start_string': '[#',
        'comment_end_string': '#]',
    })

# Generated at 2022-06-23 12:11:16.939668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance=LookupModule()
    assert isinstance(test_instance,LookupModule)

# Generated at 2022-06-23 12:11:27.964274
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:11:39.278694
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class JinjaEnv(AnsibleEnvironment):

        def _get_undefined_variables(self, item, environment):
            return [], []

    # -- Setup for testing
    lookup = LookupModule()
    lookup._templar = JinjaEnv(loader=None).get_template_class()
    lookup.set_options(direct={})

    # -- Test with a simple template file
    term = 'test.j2'
    lookupfile = '/path/to/' + term
    lookup._loader = {}
    lookup._loader._get_file_contents = lambda *a: (to_bytes('This is {{ test }}'), None)

    # -- Run the test and evaluate the result
    result = lookup.run(terms=[term], variables={'test':'a test'})
    assert type(result[0]) == str

# Generated at 2022-06-23 12:11:50.178569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    lookup = LookupModule(display)

    # load template files
    template_one = """
    [file]
    {% set files = ['foo.conf'] %}
    {% for file in files %}
    {{ file }}
    {% endfor %}
    """

    template_two = """
    [file]
    {% set files = ['bar.conf'] %}
    {% for file in files %}
    {{ file }}
    {% endfor %}
    """

    # basic template test
    lookup_file_one = "/tmp/lookup_test_one.j2"
    with open(lookup_file_one, 'w') as f:
        f.write(template_one)

# Generated at 2022-06-23 12:11:56.699159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import lookup module
    lookup_result = LookupModule().run(terms=["test_with.j2"], variables={"test_data": "ok"}, convert_data=True)
    assert lookup_result == ["ok"]

    lookup_result = LookupModule().run(terms=["test_no_data.j2"], variables={}, convert_data=True)
    assert lookup_result == [""]

# Generated at 2022-06-23 12:11:58.078530
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    assert(lm._templar is not None)

# Generated at 2022-06-23 12:12:08.310014
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # tests for loading YAML fragments and converting them into data structures
    # when convert_data is True
    # This data was originally generated with:
    #
    #    - debug:
    #        msg: "{{ lookup('template', './templates/test1.j2', convert_data=True) }}"
    #
    # ansible-playbook --syntax-check -e var1=v1 -e var2=v2 -e var3=v3 -e var4=v4 -e var5=v5 -e var6=v6 -e var7=v7 -e var8=v8 -e var9=v9 -e var10=v10 -e var11=v11 -e var12=v12 -e var13=v13 \
    #                  -e

# Generated at 2022-06-23 12:12:10.258397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 12:12:21.060303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # _templar is part of the _loader.py
    _templar = None
    # _loader is part of the ansible.plugins.loader.py
    _loader = None
    # terms is part of the lookupbase.py
    terms = "./some_template.j2"
    # variables is part of the ansible-playbook
    variables = { "var_one": "one", "var_two": "two" }
    # argspec is part of the constructor of class LookupBase
    argspec = "None"
    # loader is part of the constructor of class LookupBase
    loader = None

    # get an instance of the class LookupBase
    base = LookupBase()
    # set attributes
    base._templar = _templar
    base._loader = _loader
    base.set_options

# Generated at 2022-06-23 12:12:22.157504
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test LookupModule()"""
    assert True

# Generated at 2022-06-23 12:12:26.739611
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    return_value = ["{{ name }}"]

    # setup the class object
    lm = LookupModule()
    templar = lm._templar
    templar.available_variables["name"] = ["Jeff"]

    # call the method
    result = lm.run(["/Users/jeff"], {}, {})

    # verify the results
    assert result == return_value, "result is not the same as the return value"

# Generated at 2022-06-23 12:12:39.234061
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule """

    input_data = [u'../defaults/main.yml']
    variables = dict()
    variables['hostvars'] = dict()
    variables['hostvars']['localhost'] = dict()
    variables['hostvars']['localhost']['ansible_python_interpreter'] = '/usr/bin/python'
    variables['hostvars']['localhost']['ansible_connection'] = 'local'
    variables['hostvars']['localhost']['ansible_host'] = 'localhost'
    variables['group_names'] = dict()
    variables['group_names']['all'] = list()
    variables['group_names']['all'].append('localhost')
    variables['group_names']['all_hosts'] = list

# Generated at 2022-06-23 12:12:39.749989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:12:41.398375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()
    assert test_obj.__class__.__name__ == 'LookupModule'

# Generated at 2022-06-23 12:12:49.362422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Setup
    lookup_module = LookupModule()
    dir_name = "tests/test_lookup_plugins/files"

    #Exercise
    ret = lookup_module.run([dir_name + "/lookup_template.j2", dir_name + "/lookup_template.jinja"],
                            {"template_vars": {"foo": "bar"}},
                            variable_start_string="[[",
                            variable_end_string="]]",
                            jinja2_native=True)

    #Verify
    assert ret == ["buz\n", "buz\n"], "The rendered template should be as expected 'buz\\n'"

# Generated at 2022-06-23 12:13:01.272231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_module = LookupModule()

    src_file_path = os.path.dirname(os.path.dirname(__file__))
    test_file_path = os.path.join(src_file_path, '_data', 'test_args.yml')
    test_file_path = os.path.normpath(test_file_path)
    test_file_data = open(test_file_path, 'rb').read().decode('utf-8')
    expected_file_data = test_file_data % {'var_foo': 'var_foo', 'var_bar': 'var_bar'}

    # run test

# Generated at 2022-06-23 12:13:07.685178
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_test = LookupModule()
    import ansible.plugins
    plugins.lookup_loader.set_class(LookupModule)

    terms = ['/etc/motd']
    variables = {'inventory_hostname': 'localhost'}

    m = plugins.lookup_loader.get('template')
    result = m.run(terms, variables)

    assert result



# Generated at 2022-06-23 12:13:09.947243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, '_templar')
    return


# Generated at 2022-06-23 12:13:21.939899
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup import LookupModule
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=["/dev/null"])

    variable_manager.set_inventory(inventory)

    constants = C.load_config_file()

    def my_abspath(path):
        return "/fake/%s" % path


# Generated at 2022-06-23 12:13:30.184270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare the test data
    terms = ['../lookups/debug.yml']
    variables = {'ansible_verbosity': 0,
                 'lookup_debug_var': 'lookup_debug_value'}
    args = {}

    # Execute the module code with the test data
    lm = LookupModule()
    lm.set_loader(None)
    lm.set_templar(None)
    results = lm.run(terms=terms, variables=variables, **args)

    # Verify the results
    assert isinstance(results, list)
    assert len(results) == 1
    assert isinstance(results[0], to_text)

# Generated at 2022-06-23 12:13:35.405615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # FIXME: This is required until we can properly mock builtin open()
    #       See: https://github.com/ansible/ansible/issues/10341
    from __main__ import display
    display = Display()

    terms = ['some_template.j2']

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=terms, variables=dict())

    # Assert statement in order to verify the result of the test
    assert result == []

# Generated at 2022-06-23 12:13:44.923047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources='localhost,')

    variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory, version_info=mock_loader.version_info)


# Generated at 2022-06-23 12:13:54.102804
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #
    #   Each key represents the name of the temporary variable to be created and the value is the argument
    #   to be passed.
    #
    test_fixture = {
        'convert_data': True,
        'template_vars': {},
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'comment_start_string': '{#',
        'comment_end_string': '#}',
    }

    test_args = {}
    lookup = LookupModule(**test_args)
    assert lookup.__dict__.get('_options') is None

    lookup.set_options(**test_args)
    assert lookup.__dict__.get('_options') is None


# Generated at 2022-06-23 12:14:06.413573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = [u'file-for-testing.j2']
    variables = dict(arg1=dict(key1=u'value1', key2=u'value2'), arg2=u'value3')
    print("Type of arg1: %s" % type(variables['arg1']))
    print("Type of arg2: %s" % type(variables['arg2']))
    res = module.run(terms, variables, comment_start_string="[%", comment_end_string="%]")
    print("Result: %s" % res)
    #assert res == 'value1 = value1, value2 = value2, value3 = value3, value4 = value4'

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:14:17.240227
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Test with a valid file
    lookup_module._templar = "myTemplar"
    lookup_module._loader = "myLoader"
    lookup_module._loader.path_searcher = "mySearcher"
    lookup_module._loader.path_searcher.find_file = lambda x, y: "myfile"
    lookup_module._loader._get_file_contents = lambda x: ("myContent", "myShowData")
    lookup_module.get_option = lambda x: None
    lookup_module.set_options(var_options={'ansible_search_path': 'mySearchPath'}, direct={})
    terms = 'myfile'
    variables = {'ansible_search_path': 'mySearchPath'}

    result = lookup_module.run

# Generated at 2022-06-23 12:14:21.237675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-23 12:14:31.958694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule instance
    lookupModule = LookupModule()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Assign mock templar, display and loader to the lookupModule instance
    lookupModule._templar = templar
    lookupModule.display = display
    lookupModule._loader = loader

    # Create mock variables
    variables = dict(
        a_variable="aValue",
        lookup_a_file= "{{lookup('template', 'a_template.j2')}}",
        lookup_another_file= "{{lookup('template', 'another_template.j2')}}",
        )

    # Create mock options

# Generated at 2022-06-23 12:14:37.254185
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_option('convert_data')
    assert not l.get_option('jinja2_native')
    assert not l.get_option('comment_start_string')
    assert not l.get_option('comment_end_string')

# Generated at 2022-06-23 12:14:46.909377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup some initial variables
    my_template    = '{{ foo }}'
    my_template_vars = {}
    my_variables   = {}
    my_args        = []

    # Create an instance of LookupModule
    my_lookup_module = LookupModule()

    # Call run with an empty term, which should throw an AnsibleError
    try:
        my_lookup_module.run([], variables=my_variables, convert_data=False,
                             jinja2_native=False, template_vars=my_template_vars,
                             variable_start_string='{{', variable_end_string='}}')
        raise AssertionError("Calling run with an empty term should have thrown AnsibleError")
    except AnsibleError:
        pass
    except Exception as e:
        raise Ass

# Generated at 2022-06-23 12:14:48.619244
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert len(LookupModule().run("", {})) == 0

# Generated at 2022-06-23 12:14:54.675421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    template_0 = [
        "Hello World!",
        "{{name}}"
    ]
    terms = [
        "../tests/unittests/templates/test.j2",
        "../tests/unittests/templates/test.j2"
    ]
    variables = dict(name="Ansible")
    results = module.run(terms, variables)
    assert results == template_0

# Generated at 2022-06-23 12:14:56.137901
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)

# Generated at 2022-06-23 12:15:06.097511
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        import __builtin__ as builtins  # python2
    except ImportError:
        import builtins  # python3
    import types

    assert isinstance(LookupModule, types.TypeType)
    assert LookupModule.__module__ == 'ansible.plugins.lookup.template'
    assert LookupModule.__name__ == 'LookupModule'
    assert LookupModule.__doc__ == 'Values contain jinja2 templating.'
    assert type(LookupModule.run) is types.MethodType
    assert LookupModule.run.__module__ == 'ansible.plugins.lookup.template'
    assert LookupModule.run.__name__ == 'run'
    assert LookupModule.run.__doc__ == 'Main plugin method called by Ansible core.'

# Generated at 2022-06-23 12:15:15.981499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    ################################################################################################
    # [UNSUPPORTED] creating a mock for class AnsibleFile for test_LookupModule_run()
    # This class does not seem to be used in LookupModule.run()
    #class AnsibleFile:
    #    def __init__(self, filename):
    #        self.filename = filename
    #    def read(self):
    #        return "template content"

    #import __builtin__
    #__builtin__.open = AnsibleFile
    ################################################################################################

    ################################################################################################
    # [UNSUPPORTED] creating a mock for class AnsibleFile for test_LookupModule_run()
    # This class does not seem to be used in LookupModule.run()
   

# Generated at 2022-06-23 12:15:25.071975
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test error handling
    #
    # 1. lookupfile is None
    #
    # - find_file_in_search_path is expected to raise an error
    # - that error is catched
    # - an error should be returned
    #
    lookup = LookupModule()
    def mock_find_file_in_search_path(var, direct, term):
        raise AnsibleError("Test error handling")

    lookup.find_file_in_search_path = mock_find_file_in_search_path
    try:
        lookup.run(["filename"], variable_start_string='[', variable_end_string=']')
    except AnsibleError:
        pass

    # Test error handling
    #
    # 1. lookupfile is not None
    # 2. lookupfile is not None but is not found
   

# Generated at 2022-06-23 12:15:33.824718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    lu._loader = DictDataLoader({'template_file': 'data',
                                 'template_file_with_vars': 'data',
                                 'template_file_with_vars_and_convert_data': 'yaml_data'})
    lu._templar = DummyTemplar()

    # Test single template file without additional template vars usage.
    for term in ["template_file"]:
        result = lu.run([term], DummyVars())
        assert len(result) == 1, result
        assert result[0] == 'data', result

    # Test single template file with additional template vars usage.
    # Test comment start and end string
    term = "template_file_with_vars"

# Generated at 2022-06-23 12:15:46.211248
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockTemplar(object):
        def __init__(self):
            self._templar = 'templar'
        def copy_with_new_env(self, environment_class=None):
            return self._templar
    class MockEnv(object):
        def set_temporary_context(self, variable_start_string=None,
                                  variable_end_string=None,
                                  comment_start_string=None,
                                  comment_end_string=None,
                                  available_variables=None,
                                  searchpath=None):
            return

    class MockOptions(object):
        def __init__(self):
            self.env = MockEnv()
            self.convert_data = True
            self.template_vars = 'template_vars'
            self.jinja

# Generated at 2022-06-23 12:15:47.888347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # assert isinstance(lookup_module._templar, Templar)

# Generated at 2022-06-23 12:16:00.410947
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    display = Display()
    display.verbosity = 4

    from ansible.template import Templar

    class Options(object):

        def __init__(self, options):
            self.__dict__ = options

    class LookupBaseImpl(LookupBase):

        def __init__(self, templar, loader, variables):
            self._loader = loader
            self._templar = templar
            self._options = Options({})
            self._display = display
            self._use_contains = None
            self.basedir = "."

        def run(self, terms, variables=None, **kwargs):
            return [self.get_file_contents(term, variables=variables, **kwargs) for term in terms]


# Generated at 2022-06-23 12:16:02.571568
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-23 12:16:05.776520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_loader('/tmp')
    assert mod.loader == '/tmp'
    mod.set_templar('/tmp')
    assert mod.templar == '/tmp'

# Generated at 2022-06-23 12:16:07.627441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupModule)


# Generated at 2022-06-23 12:16:19.708032
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar as templar
    from ansible.utils.context_objects import AnsibleContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Search PATH for template file

# Generated at 2022-06-23 12:16:20.593534
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:16:21.173552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:16:22.137983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-23 12:16:24.564120
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Unit tests for method find_file_in_search_path

# Generated at 2022-06-23 12:16:28.502840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(None, None, None, None, terms=['test', 'passed'], convert_data=True,
                              template_vars={'test': {'foo': 'bar'}})
    assert result == ['test passed\n'], result


# Generated at 2022-06-23 12:16:30.889648
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:16:33.785415
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test constructor of class LookupModule"""
    # Test with no arguments
    l = LookupModule()

    # Test with arguments
    l = LookupModule(loader=None, variables=None)



# Generated at 2022-06-23 12:16:44.017635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ############################################################################
    # 1. Test with a simple template that has no variable and no
    # ansible_variable
    ############################################################################
    lookup_plugin = LookupModule()

    def _loader_mock(self, path):
        return 'Hello {{ ansible_hostname }}', False
    lookup_plugin._loader._get_file_contents = _loader_mock

    def _templar_mock(template_data, convert_bare=False, fail_on_undefined=False, override=None, preserve_trailing_newlines=True, escape_backslashes=True, **kwargs):
        return template_data
    lookup_plugin._templar.template_from_file = _templar_mock


# Generated at 2022-06-23 12:16:45.393827
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # tests that the object is created correctly
    assert LookupModule()

# Generated at 2022-06-23 12:16:56.606188
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    valid_input_output_map = {
        # simple jinja2 file
        'test1.j2': 'Hello world!',
        # simple jinja2 file with ansible context variables
        'test2.j2': 'ansible_0_hostname',
        # simple jinja2 file with ansible context variables (jinja2_native=False)
        'test2.j2': 'ansible_0_hostname'
    }

    for test, expected in valid_input_output_map.items():
        module = LookupModule()
        display = Display()
        variables = {
            'ansible_0_hostname': 'test_host'
        }
        results = module.run([test], variables, None)
        assert results[0] == expected


# Generated at 2022-06-23 12:16:59.695932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)



# Generated at 2022-06-23 12:17:01.546723
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:17:03.215991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  """Unit test for method run of class LookupModule"""
  LookupModule().run(['file'], {}, {})

# Generated at 2022-06-23 12:17:04.863437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:17:13.071968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for run method of class LookupModule"""

    class MyTemplar:
        def __init__(self):
            self.my_environment_class = None
        def copy_with_new_env(self, environment_class):
            self.my_environment_class = environment_class
            return self
        def set_temporary_context(self, available_variables, searchpath, variable_start_string,
                                  variable_end_string, comment_start_string, comment_end_string):
            return self
        def template(self, template_data, preserve_trailing_newlines, escape_backslashes,
                     convert_data):
            if template_data == 'content':
                return 'result'

    class MyLoader:
        def _get_file_contents(self, lookupfile):
            return b

# Generated at 2022-06-23 12:17:13.524683
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:17:21.886624
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    valid_terms = [
        '../../templates/file_lookup_plugin.py',
        'file_lookup_plugin.py'
    ]

    valid_variables = [
        {
            'ansible_search_path': ['../../']
        }
    ]

    lookup_module._loader = DummyLoader()

    # Test with valid term and valid variables
    for term, variables in zip(valid_terms, valid_variables):
        results = lookup_module.run([term], variables)
        assert len(results) == 1
        assert results[0] == '# Unit test for method run of class LookupModule\n'

    # Test with invalid term and valid variables

# Generated at 2022-06-23 12:17:23.350655
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-23 12:17:29.718336
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for exceptional case
    try:
        LookupModule().run([], {}, convert_data=True, template_vars={}, jinja2_native=True, variable_start_string='{{', variable_end_string='}}',
                              comment_start_string='{#', comment_end_string='#}')
        assert(False)
    except TypeError:
        pass

    # Test for normal case
    result = LookupModule().run(["file_exists_in_file_system"], {}, convert_data=True, template_vars={}, jinja2_native=True, variable_start_string='{{', variable_end_string='}}',
                                comment_start_string='{#', comment_end_string='#}')
    assert(result == [u'true'])

# Generated at 2022-06-23 12:17:39.966390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    d = {}
    d.update(generate_ansible_template_vars("some_template.j2", "/path/to/some_template.j2"))
    d["template_host"] = "hostname"
    template_data = "{{ hostname }} {{ template_host }}"
    t = AnsibleEnvironment(loader=None, variable_start_string="{{", variable_end_string="}}")
    res = t.template(template_data, preserve_trailing_newlines=True, convert_data=True, escape_backslashes=False, available_variables = d, searchpath = [])

    assert res == "hostname hostname\n"


# Generated at 2022-06-23 12:17:40.898484
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:17:42.855955
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing constructor of class LookupModule")
    lookup = LookupModule()
    assert lookup is not None, "lookup is empty"


# Generated at 2022-06-23 12:17:54.902285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile
    import unittest
    from ansible import constants, errors

    # Write a temporary file on disk
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b"This is a test template file")
        temp_file_name = f.name

    # Create the lookup module
    lm = LookupModule()

    # Create variables to be passed to the lookup module
    variables = {}

    # Call run to evaluate the template
    try:
        lookup_result = lm.run([temp_file_name], variables, convert_data=True, jinja2_native=False)
    finally:
        # Remove the temporary file from disk
        os.remove(temp_file_name)

    # Test that template was evaluated correctly

# Generated at 2022-06-23 12:17:56.622170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # this is here since the module is needed by the test code
    from ansible.plugins.loader import lookup_loader
    lookup_loader.get('template')

# Generated at 2022-06-23 12:18:08.449198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is a LookupModule object.
    lookup_module = LookupModule()
    # This is a LookupBase object.
    lookup_base = lookup_module.get_base()
    # This is an object of class Jinja2Templar, ansible.template
    templar = lookup_base._templar

    # This is a list of strings containing the name of files
    terms = ['test.json']
    # This is a dict containing ansible variables
    variables = {}
    # This is a dict containing ansible options, the type for 'convert_data' is bool, the type for 'template_vars' is dict
    kwargs = {'convert_data': 'True', 'template_vars': '{}'}

    # This is a list of strings containing the name of files in './files/data

# Generated at 2022-06-23 12:18:10.063703
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 12:18:19.592831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # Dummy env variable as Ansible does not load env variable for tests
    lookup_plugin.set_options(direct={'_ansible_check_mode': False,
                                      '_ansible_no_log': False,
                                      '_ansible_debug': False,
                                      '_ansible_verbosity': 2,
                                      '_ansible_version': '2.11'})
    assert(lookup_plugin._display.verbosity == 2)
    assert(lookup_plugin.get_option('convert_data') is True)
    assert("lookup_plugin.get_option('jinja2_native')" is str(False))

# Generated at 2022-06-23 12:18:23.440662
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# test that the lookup module asserts the use of jinja2_native if it's true globally

# Generated at 2022-06-23 12:18:25.423349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj is not None


# Generated at 2022-06-23 12:18:26.299116
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup is not None

# Generated at 2022-06-23 12:18:27.498139
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:18:40.457316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.verbosity = 4

    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from test_loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    terms = ['first.j2']
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    variable_manager.set_inventory(inventory)

    my_lookup = LookupModule()
    my_lookup.set_loader(DictDataLoader(dict()))
    my_lookup.set_inventory(inventory)
    my_lookup.set_

# Generated at 2022-06-23 12:18:48.179218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.content_type = 'json'
    display.warnings = []
    display.deprecations = []

    from ansible.plugins.loader import lookup_loader
    lm = lookup_loader.get('template', class_only=True)
    lm._display = display

    def _loader_read_file(path, mode='rb', vault_password=None):
        if path == './test_data.j2':
            return to_bytes('test {{ abc }}'), 'utf-8'
        raise AnsibleError("could not read file")

    def _loader_get_basedir(path):
        if path == './test_data.j2':
            return '.'
        raise AnsibleError("could not find basedir")


# Generated at 2022-06-23 12:18:59.146103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests method run of class LookupModule."""
    # make sure to not depend on jinja2 native ansible option
    # when creating the templar instance
    templar = AnsibleEnvironment(variable_start_string='{{',
                                 variable_end_string='}}').get_template_class()()
    lookup_plugin = LookupModule(loader=None, templar=templar)
    display = Display()
    templar.set_available_variables(variables={'bar': 'foo'})

    mocked_env = os.environ
    mocked_env['ANSIBLE_TEMPLATE_INTERPRETER'] = 'python'

# Generated at 2022-06-23 12:19:05.160039
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a class object
    # to save the function result
    class Obj(object):
        pass
    obj = Obj()

    # create a class object
    # for the function argument
    class Arguments(object):
        pass
    arguments = Arguments()
    arguments.template_vars = {}
    arguments.convert_data = None
    arguments.variable_start_string = None
    arguments.variable_end_string = None

    # run the function LookupModule.run
    obj.ret = TemplateModule().run(["/foo/template_one", "/bar/template_two", "/baz/template_three"], arguments)

    # compare the function result
    # with the expected result
    assert obj.ret == [u'foo\n', u'bar\n', u'baz\n']

# Generated at 2022-06-23 12:19:06.744407
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test if we can initialize with no argument
    assert LookupModule() is not None

# Generated at 2022-06-23 12:19:08.406011
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lm = LookupModule()
   assert lm is not None

# Generated at 2022-06-23 12:19:10.182818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-23 12:19:17.013112
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #construct a mock display object, which mocks the display.debug() method
    class mock_display:
        def __init__(self):
            self.string = "This is a mock display object"
            self.string2 = "This is a mock display object with one %s"

        def debug(self,v):
            if isinstance(v,str):
                print(v)
            elif isinstance(v,tuple):
                print(self.string2 % v)
            else:
                print("Can't do anything with %s" % v)

    mock_vars = dict(one_var="one value")

    mock_display = mock_display()
    #1st test with a standard string template lookup

# Generated at 2022-06-23 12:19:19.384956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    lm = LookupModule()

# Generated at 2022-06-23 12:19:21.874553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule(loader=DataLoader())
    assert(lookup)

# Generated at 2022-06-23 12:19:30.981836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # dummy class for unit testing
    class LookupModuleUnitTest(LookupModule):
        def __init__(self, **kwargs):
            self.run_args = kwargs
            self.run_called = False

        # dummy method for unit testing
        def run(self, **kwargs):
            self.run_called = True
            return []

    # unit test
    module = LookupModuleUnitTest()

    # check run method has been called with appropriate parameters
    term = 'unit_test'
    module.run_command(terms=[term], variables=dict())
    assert module.run_called

    # check run method has been called with appropriate parameters
    assert module.run_args['_terms'] == [term]

# Generated at 2022-06-23 12:19:32.792271
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._templar is not None

# Generated at 2022-06-23 12:19:43.848301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_get_file_contents(filename):
        if filename == "playbook_path/templates/test.j2":
            return (b'{"key": {{ my_val }} }', True)
        else:
            raise Exception("Mock get_file_content called with unexpected filename: %s" % filename)

    def mock_templar_template(template_data, convert_data):
        if convert_data:
            return {"key": 42}
        else:
            return '{"key": 42}'

    def mock_templar_copy_with_new_env(environment_class):
        return templar


# Generated at 2022-06-23 12:19:50.980120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import io

    # For this test, we will create a mock `templar` object which we will pass to the
    # lookup module and which will be responsible for the actual templating.
    mock_templar = mock.MagicMock()
    mock_templar.template.return_value = "hi"

    # We also need to mock the _loader object, so that the lookup plugin can call
    # the `_get_file_contents` method. We need to return a tuple, where the first
    # element is the content of the file, and the second element is an unimportant
    # boolean.
    mock_loader = mock.MagicMock()
    mock_loader._get_file_contents.return_value = (io.BytesIO(b"hi there {{hi}}"), True)

    # The find_

# Generated at 2022-06-23 12:19:52.426566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:19:53.026325
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:20:00.766323
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY2
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import os
    import sys

    sys.modules['__main__'].__file__ = os.path.dirname(__file__) + '/templatemodule_test.py'


# Generated at 2022-06-23 12:20:09.854897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    loader = DictDataLoader({
        "UnavailableSourceFile.j2": "This file is unavailable",
        "SourceFile.j2": "{{ var }}",
    })
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = {'var': 'ansible'}
    template_vars = {'var': 'template_vars'}
