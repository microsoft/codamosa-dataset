

# Generated at 2022-06-23 12:10:10.251111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:10:19.428617
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    variable_manager.options_vars = {
        'variable_start_string': '{{',
        'variable_end_string': '}}',
    }

    play_context = PlayContext()

    lookup_plugin = LookupModule(loader=loader, variable_manager=variable_manager, play_context=play_context)
    return lookup_plugin



# Generated at 2022-06-23 12:10:21.223426
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:10:22.615989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:10:31.828591
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a fake ansible
    class FakeAnsibleModule:
        class FakeAnsibleModuleArgs:
            def __init__(self):
                self.convert_data = True
        def __init__(self):
            self.params = self.FakeAnsibleModuleArgs()
    class FakeAnsibleModule:
        class FakeAnsibleModuleArgs:
            def __init__(self):
                self.convert_data = False
        def __init__(self):
            self.params = self.FakeAnsibleModuleArgs()

    # Create a fake loader
    import os
    import tempfile
    class FakeAnsibleFileLoader:
        def __init__(self, content):
            self.content = content
        def _get_file_contents(self, lookupfile):
            return self.content, True

# Generated at 2022-06-23 12:10:33.068183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 12:10:39.073414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for method run of class LookupModule
    file_contents = """
{% for i in range(5) %}
{{ i }}
{% endfor %}
"""

    lookup = LookupModule()
    terms = [file_contents]
    variables = {}
    results = lookup.run(terms, variables)
    assert results == ["0\n1\n2\n3\n4\n"]

# Generated at 2022-06-23 12:10:47.072043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import binary_type

    import jinja2

    class Environment:
        def __init__(self, *args, **kwargs):
            pass

    class Loader:
        def __init__(self, *args, **kwargs):
            pass

        def list_templates(self):
            return []

    class Templar:
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 12:10:49.307885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')



# Generated at 2022-06-23 12:10:58.864581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with a non-existing file
    try:
        lookup = LookupModule()
        lookup.run(terms=['ansible.cfg'], variables={}, **{})
        assert False, "Using a non-existing template file %s should throw an exception" % term
    except AnsibleError as e:
        assert 'could not be found' in to_text(e)

    # Testing with a existing file
    term = 'test_template.j2'
    current_path = os.path.dirname(os.path.abspath(__file__))
    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_path))))
    lookup = LookupModule()
    tpl_content = 'Hello {{ name }}!'
    lookup.set

# Generated at 2022-06-23 12:11:07.267703
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [ './some_template.j2' ]
    variables = { 'var1': '1', 'var2': '2' }
    options = {'convert_data': True, 'template_vars': {'var3': '3'}, 'jinja2_native': False}
    lookup = LookupModule()

    # The method run is invoked by the lookup function, which in turn is
    # invoked by the template function.  The template function calls
    # _load_lookup_plugin with the lookup function name (lookup in this case)
    # and the class of the plugin (LookupBase)
    ret = lookup.run(terms, variables, **options)
    assert ret == ['Hello World']

# Generated at 2022-06-23 12:11:08.329577
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:11:08.907445
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:11:17.696212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    m = LookupModule()
    fact_value = { "foo": "bar" }
    fact_value_as_text = to_text(fact_value)
    fact_value_as_unsafe = AnsibleUnsafeText(fact_value_as_text, encoding='utf-8')
    terms = [ '"{{ ansible_facts.foo }}"' ]
    variables = { "ansible_facts": fact_value }
    assert terms[0] == fact_value_as_text
    assert m.run(terms, variables, **{}) == [ fact_value_as_unsafe ]

# Generated at 2022-06-23 12:11:28.371492
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1

    lm = LookupModule()

    with open('test_template.j2') as f:
        test_template_file = f.read()

    lm._loader = FakeAnsibleLoader(template_str=test_template_file)
    lm._templar = FakeAnsibleTemplar()

    terms = ['test_template.j2']
    variables = {'var1': 'val1', 'var2': 'val2', 'var3': ['val4', 'val5']}

    assert lm.run(terms, variables) == ['file of test_template.j2 has content: val1\n']


# Generated at 2022-06-23 12:11:38.051605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._display = Display()
    lookup.set_options(direct={'variable_start_string': '{', 'variable_end_string': '}'})
    lookup._loader = DictDataLoader({'basedir/file.j2': b'name: {{ name }}'})
    lookup._templar = Templar(loader=lookup._loader, variables={'name': 'jack'})
    lookup._templar._available_variables = {}
    assert lookup._loader
    assert lookup._templar
    assert lookup._templar._available_variables == lookup._templar._available_variables

# Generated at 2022-06-23 12:11:49.491525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager

    test_loader = DictDataLoader({
        "./test_template.j2": """Hello {{ ansible_hostname }}!""",
    })

    test_vars = VariableManager(loader=test_loader)
    test_vars.set_fact(ansible_hostname="world")

    lookup_plugin = LookupModule(variable_manager=test_vars)
    lookup_plugin.set_loader(test_loader)

    res = lookup_plugin.run(["test_template.j2"], ImmutableDict())
    assert res == ["Hello world!"]


# Generated at 2022-06-23 12:12:00.566002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestLookupModule(unittest.TestCase):
        '''
        Test class LookupModule
        '''
        def test_init(self):
            '''
            Test function init
            '''
            import __main__
            setattr(__main__, '__file__', 'ansible')
            lu = LookupModule()
            assert isinstance(lu, LookupModule)
            lu = LookupModule(loader=None, templar=None, shared_loader_obj=None)
            assert isinstance(lu, LookupModule)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 12:12:07.307414
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.errors import AnsibleError
    from ansible.template import generate_ansible_template_vars
    import os

    terms = ['./some_template.j2']
    variables = {'my_variable_value': 'my_variable_value_value'}

    my_plugin = LookupModule()
    def my_find_file_in_search_path(variables, directory, filename):
        return './some_template.j2'
    my_plugin.find_file_in_search_path = my_find_file_in_search_path

    my_loader_get_file_contents = 'my_loader_get_file_contents'
    def my_loader_wrapper(filename):
        return (my_loader_get_file_contents, False)
    my

# Generated at 2022-06-23 12:12:18.586786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def assertDictEqual(dict1, dict2):
        assert len(dict1) == len(dict2)
        for key in dict1:
            assert key in dict2
            assert dict1[key] == dict2[key]

    lookup = LookupModule()
    lookup.set_loader(DummyLoader())
    lookup._templar = DummyTemplar()

    terms = ['file1']
    variables = {'ansible_search_path': ['path1', 'path2']}
    options = {'template_vars': {'hello': 'world'}}
    assertDictEqual(lookup.get_options(var_options=variables, direct=options), {'template_vars': {'hello': 'world'}})


# Generated at 2022-06-23 12:12:19.531160
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the constructor of class LookupModule
    """
    instance = LookupModule()
    assert instance



# Generated at 2022-06-23 12:12:20.204103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:12:24.889201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arrange
    module = LookupModule()
    terms = [b'./hello-world.conf']
    variables = {}
    expected_result = [b'hello world']
    # act
    actual_result = module.run(terms, variables)
    # assert
    assert actual_result == expected_result


# Generated at 2022-06-23 12:12:37.529152
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock_get_opt
    def mock_get_opt(self, option):
        if option == 'convert_data':
            return False
        elif option == 'template_vars':
            return {}
        elif option == 'jinja2_native':
            return True
        elif option == 'variable_start_string':
            return '{{'
        elif option == 'variable_end_string':
            return '}}'
        elif option == 'comment_start_string':
            return ''
        elif option == 'comment_end_string':
            return ''
        else:
            return 'test'

    # mock_show_data
    def mock_show_data(self, b_data, obj):
        return 'test'


# Generated at 2022-06-23 12:12:39.743866
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Use default parameters
    lookup = LookupModule()

    # Use provided parameters
    lookup = LookupModule(
        loader=None,
        templar=None,
        shared_loader_obj=None)


# Generated at 2022-06-23 12:12:41.062573
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookupModule = LookupModule()

    assert lookupModule != None

# Generated at 2022-06-23 12:12:50.592467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with 1 template file
    res = lookup_module.run(terms="test1.j2", variables={"key1":"value1", "key2":"value2"})
    assert res[0] == "{\
    'key1':'value1',\
    'key2':'value2'\
    }\n"
    # Test with 2 template files
    res = lookup_module.run(terms=["test1.j2", "test2.j2"], variables={"key1":"value1", "key2":"value2"})
    assert res[0] == "{\
    'key1':'value1',\
    'key2':'value2'\
    }\n"

# Generated at 2022-06-23 12:12:59.450934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(["tests/ansible/roles/my_role/vars/main.yml"],
                        {'ansible_search_path': [os.path.abspath('../../')]},
                        convert_data=False)
    # Check that result is a list of one element
    assert len(result) == 1
    # Check that the element of the list is a Non-native Jinja2 text
    assert USE_JINJA2_NATIVE and isinstance(result[0], NativeJinjaText)

# Generated at 2022-06-23 12:13:08.094204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    my_lookup_class = LookupModule()
    # Create some test variables
    my_variables = {'some_variables': "Hello World"}
    my_kwargs = {'convert_data': False, 'template_vars': {}}
    my_args = ['./some_template.j2']
    # Call method run
    ret = my_lookup_class.run(my_args, my_variables, **my_kwargs)
    # Check ret
    assert ret == ["Hello World"]

# Generated at 2022-06-23 12:13:09.531790
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert cls


# Generated at 2022-06-23 12:13:16.693244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock objects
    display = Display()
    loader = DictDataLoader({'template_file.j2': b'{{ var_a }}'})
    inventory = InventoryManager(loader=loader)

    # Populate lookup
    lookup = LookupModule()
    lookup.set_loader({'loader': loader})
    lookup.set_inventory({'inventory': inventory})

    # Run the test
    result = lookup.run([
        'template_file.j2',
        'template_file.j2',
    ], variables={
        'var_a': 'val_a',
        'var_b': 'val_b'
    })

    assert result == [
        'val_a',
        'val_a',
    ]

# Generated at 2022-06-23 12:13:18.305486
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False, 'TODO: Unit test method run of class LookupModule'

# Generated at 2022-06-23 12:13:20.109047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-23 12:13:30.069690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instructions:
    # Run with:
    # $ python lookup_plugins/template.py
    # Returns:
    # 0 - success
    # 1 - failure
    # None - error

    # LookupModule
    # def run(self, terms, variables, **kwargs):

    from ansible.plugins import lookup_loader

    lm = lookup_loader.get('template')
    if not lm:
        raise AnsibleError("The template lookup plugin was not found")

    variables = {'a': 1}
    terms = ['./tests/unit/ansible_collections/ansible_test/test_data/test_templating/test_templating_lookup_template.j2']

# Generated at 2022-06-23 12:13:39.774630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    lookup_plugin = LookupModule()

    assert isinstance(lookup_plugin, LookupBase)
    assert isinstance(lookup_plugin, LookupModule)
    assert lookup_plugin.get_option('variable_start_string') == '{{'
    assert lookup_plugin.get_option('variable_end_string') == '}}'

    # test with jinja2_native on, jinja2_native off in options
    ac_j2 = AnsibleEnvironment()

# Generated at 2022-06-23 12:13:48.311331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tm = LookupModule()
    tm.set_options(dict(var_options=dict(), direct=dict()))

# Generated at 2022-06-23 12:13:55.587128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys
    import types

    # Create an instance of LookupModule
    lm_o = LookupModule()

    # Dummy args, as if run from Ansible
    lm_o._templar = None
    lm_o._loader = None
    lm_o._display = None

    # Dummy options, as if passed from Ansible
    options = {}
    options['convert_data'] = None
    options['template_vars'] = {}
    options['jinja2_native'] = False
    options['variable_start_string'] = "{{ "
    options['variable_end_string'] = " }}"
    options['comment_start_string'] = None
    options['comment_end_string'] = None

    # Instantiate an empty AnsibleTemplate
    lm_o._tem

# Generated at 2022-06-23 12:13:56.826175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:13:58.468009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_test = LookupModule()
    assert lookup_test


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:13:59.665661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()

# Generated at 2022-06-23 12:14:02.000785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["test.j2"], {}) == []

# Generated at 2022-06-23 12:14:12.180541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    class FakeVars(object):
       def __init__(self):
          self.environment = "fake_env"
    import tests.data.lookup_fixtures.data.template
    lookup_module = LookupModule()
    lookup_module._templar = basic.AnsibleModule().load_shared_arg_spec()['_templar']
    lookup_module._loader = basic.AnsibleModule().load_shared_arg_spec()['_loader']
    lookup_module._display = basic.AnsibleModule().load_shared_arg_spec()['_display']
    lookup_module.set_options(var_options=FakeVars(), direct={})

# Generated at 2022-06-23 12:14:20.159416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({}))
    lookup_module._templar.environment.variable_start_string = '${'
    lookup_module._templar.environment.variable_end_string = '}'
    lookup_module._templar.environment.trim_blocks = True
    lookup_module._templar.environment.lstrip_blocks = True
    lookup_module._templar.available_variables = dict(a=1, yaml_string=dict(var1=1, var2=2))
    lookup_module._templar.environment.loader = DictTemplateLoader({})
    lookup_module._templar.environment.loader.searchpath = ['.']

# Generated at 2022-06-23 12:14:22.128960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:14:30.012402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible_collections.notstdlib.moveitallout.plugins.lookup.template import LookupModule
    from ansible.context import Context

    fake_loader_obj = FakeLoader()
    fake_plugins_obj = FakePlugins()
    context = Context(loader=fake_loader_obj, plugins=fake_plugins_obj)

    lookup_plugin = LookupModule()
    lookup_obj = lookup_plugin.run(('test_template.j2',), None, context=context)
    assert lookup_obj == ["Start\n    middle\nend\n"]


# Generated at 2022-06-23 12:14:36.851634
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import os
    import pytest
    from ansible.utils.path import unfrackpath
    from ansible.parsing.vault import VaultLib

    test_dir = os.path.dirname(unfrackpath(__file__, os.getcwd()))
    sys.path.append(test_dir)

    is_py3 = sys.version_info[0] == 3
    if is_py3:
        unicode = str
    cwd = os.getcwd()
    lookup_dir = os.path.join(test_dir, 'lookup_plugins', 'test_lookups')
    os.chdir(lookup_dir)
    fake_vault_secret = VaultLib('dummy')
    assert os.getcwd() == lookup_dir

# Generated at 2022-06-23 12:14:41.664337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins import module_loader

    def test_loader(path):
        if path == './some_template.j2':
            return 'foo {{ ansible_hostname }} bar'
        else:
            return None

    lookup_module = module_loader.get('lookup', 'template')
    test_lookup = lookup_module(LOADER=test_loader, GET_BINARY_CONTENTS_FROM_HOST=lambda x: None,
                                TEMPLATE_VARS={})
    result = test_lookup.run(['./some_template.j2'], {'ansible_hostname': 'abc'}, convert_data=True,
                             jinja2_native=False)
    assert result == ['foo abc bar']

# Generated at 2022-06-23 12:14:44.188622
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert os.path.exists(LookupModule.JINJA2_OVERRIDE_ENV_NAME) == LookupModule.JINJA2_OVERRIDE_ENV

# Generated at 2022-06-23 12:14:46.043479
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_module = LookupModule()
  assert lookup_module is not None

# Generated at 2022-06-23 12:14:49.197270
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_args = {}
    try:
        test = LookupModule(module_args, {})
    except Exception as e:
        assert False, "Failed to create instance of LookupModule - {}".format(e)

# Generated at 2022-06-23 12:15:00.301443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_option('convert_data') == False
    assert l.get_option('template_vars') == {}
    assert l.get_option('jinja2_native') == False
    assert l.get_option('variable_start_string') == '{{'
    assert l.get_option('variable_end_string') == '}}'
    assert l.get_option('comment_start_string') == ''
    assert l.get_option('comment_end_string') == ''

    ret = l.run(terms=['hello', 'world'], variables={})
    assert ret == ['hello', 'world']

    ret = l.run(terms=['hello', '{{world}}'], variables={'world': 'ansible'})

# Generated at 2022-06-23 12:15:01.322176
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 12:15:07.438137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get the base class
    import ansible.plugins.lookup.template
    LookupModuleTest = type("LookupModuleTest",(ansible.plugins.lookup.template.LookupModule,),{})
    lookup_module = LookupModuleTest()

    # get the methods to test
    import ansible.plugins.lookup.template
    run = ansible.plugins.lookup.template.LookupModule.run

    # setup the parameters
    terms = ['test_template']

    # execute the run method and test return value
    assert run(lookup_module, terms)

# Generated at 2022-06-23 12:15:11.169976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Make sure that we can create an instance of the LookupModule class.
    template = LookupModule()

    # Make sure that the variable 'display' is correctly initialized (it should be of type ansible.utils.Display).
    assert isinstance(template.display, Display)

# Generated at 2022-06-23 12:15:18.249227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test case
    display = Display()
    display.verbosity = 3
    plugin = LookupModule()
    plugin.set_options(direct={})
    plugin.run([to_bytes('../tests/templates/basic.j2', errors='surrogate_or_strict')], {'foo': 'bar'})
    ret = plugin.run([to_bytes('../tests/templates/basic.j2', errors='surrogate_or_strict')], {'foo': 'bar'})
    assert ret == ['bar']

# Generated at 2022-06-23 12:15:20.248453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert len(lm.run(["something"], dict())) == 0

# Generated at 2022-06-23 12:15:21.192680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write a test for this lookup module
    pass

# Generated at 2022-06-23 12:15:22.940397
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create an instance of LookupModule
    lookup_plugin = LookupModule()

    assert lookup_plugin is not None



# Generated at 2022-06-23 12:15:25.961728
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:15:34.694267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    import sys

    # Create a test directory with a file based on the test directory
    test_dir = os.path.join(os.path.dirname(__file__), 'test_LookupModule_run')
    file_name = os.path.join(test_dir, 'foo.txt')

    # Create the test directory and file
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    file_handle = open(file_name, 'wt')
    file_handle.write('This is a test')
    file_handle.close()

    module = sys.modules[__name__]
    m = module.LookupModule()

    # Gather args for the test run

# Generated at 2022-06-23 12:15:36.245471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:15:47.561948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import generate_ansible_template_vars
    terms = ['some_template.j2']
    variables = ImmutableDict({'ansible_search_path':["."]})
    kwargs = {}

    lookup_obj = LookupModule()
    results = lookup_obj.run(terms, variables, **kwargs)
    assert results == [u'hello world\n']
    assert generate_ansible_template_vars(terms[0], './some_template.j2') == {"template_mtime": 1502648176.19, "template_path": "./some_template.j2"}
    assert kwargs == {}


# Generated at 2022-06-23 12:15:49.867258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['test'], {}) == ["foo\n"]

# Generated at 2022-06-23 12:15:51.917694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    templar = LookupModule()
    assert templar is not None

# Generated at 2022-06-23 12:15:53.466260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-23 12:16:03.911226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options:
        def __init__(self, lookup_template_vars=None, variable_start_string='{{', variable_end_string='}}',
                     jinja2_native=None, convert_data=False, comment_start_string='{#', comment_end_string='#}'):
            self.lookup_template_vars = lookup_template_vars
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string
            self._jinja2_native = jinja2_native
            self.convert_data = convert_data
            self.comment_start_string = comment_start_string
            self.comment_end_string = comment_end_string

    lookup = LookupModule()

# Generated at 2022-06-23 12:16:12.775960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['plop.j2']
    variables = {}
    variables.update(generate_ansible_template_vars('', ''))
    variables['ansible_version'] = {"full": "v2.3.0.0", "major": 2, "minor": 3, "revision": 0, "string": "2.3.0.0"}
    variables['template_host'] = "localhost"
    variables['template_uid'] = "0"
    variables['template_path'] = "/Users/didoha/ansible_workspace/tacacs_deployment/roles/tacacs/tasks/plop.j2"

# Generated at 2022-06-23 12:16:17.051503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This test is supposed to throw an AnsibleError exception
    # Test for error condition for constructor
    try:
        lookup_plugin = LookupModule()
    except AnsibleError:
        pass
    except Exception as e:
        assert False, e

# Generated at 2022-06-23 12:16:26.005155
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_instance = LookupModule()

    # Test for empty templating
    assert lookup_module_instance.run(terms=['/some/path'], variables={}, loader=None) == []

    # Test for correct templating
    assert lookup_module_instance.run(terms=['./test_data/test_template.j2'], variables={'name': 'test'}, loader=None) == [to_bytes('Hello Ansible test!', errors='surrogate_or_strict')]

    # Test for wrong templating
    try:
        lookup_module_instance.run(terms=['./test_data/test_template.j2'], variables={}, loader=None)
    except Exception:
        assert True
    else:
        assert False

    # Test for wrong templating

# Generated at 2022-06-23 12:16:37.028812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import logging
    import ansible.plugins.loader as pluginloader
    import ansible.errors as errors
    import ansible.template as ans_template
    from ansible.parsing.dataloader import DataLoader

    class MockTemplar(object):
        def __init__(self, t_vars=None, template_file=None, lookup_file=None,
                     convert_data=False, search_path=None, jinja2_native=False):
            self.T_VARS = t_vars
            self.TEMPLATE_FILE = template_file
            self.LOOKUP_FILE = lookup_file
            self.CONVERT_DATA = convert_data
            self.SEARCH_PATH = search_path
            self.JINJA2_NATIVE = jinja2_native

# Generated at 2022-06-23 12:16:40.459869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['test_lookup_fixtures.template']
    variables = {'var': 'value'}
    expected_results = [u"\n# This is a comment\nfoo = value"]
    ret = lm.run(terms, variables)
    assert ret == expected_results

# Generated at 2022-06-23 12:16:41.796389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 12:16:42.348414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:16:43.947402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:16:44.929188
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:16:46.334638
# Unit test for constructor of class LookupModule
def test_LookupModule():

    t = LookupModule()
    assert t # unit test of constructor

# Generated at 2022-06-23 12:16:54.448267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make a temp file
    tempfile = tempfile = NamedTemporaryFile(delete=False)
    tempfile.write(b"{{val}}")
    tempfile.close()

    # Get a LookupModule
    temp_path = os.path.join(tempfile.name)
    lookup = LookupModule()

    # Test
    result = lookup.run([temp_path], dict(val=1337))
    assert result[0] == "1337"
    os.remove(tempfile.name)


# Generated at 2022-06-23 12:16:55.100847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:17:00.862497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    t = StringIO()
    l = LookupModule()
    l.run(terms=['test_template_file'],
          variables={'ansible_search_path': ['/home/foobar/ansible_module_test'],
                     'ansible_default_var': 'default var',
                     'template_var': 'template var',
                     'var': 'default var'},
          stdout=t)
    assert t.getvalue() == 'default var template var\n'

# Generated at 2022-06-23 12:17:06.429287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = [ './some_template.j2' ]
    test_variables = { 'some_variable': 'some_value' }
    test_direct = { 'variable_start_string': '{?' }
    test_obj = LookupModule()
    test_obj.set_options(var_options=test_variables, direct=test_direct)
    # check property values of test_obj
    assert test_obj._get_options()['var_options'] == test_variables
    assert test_obj._get_options()['direct'] == test_direct
    assert test_obj._templar == test_variables['_templar']

# Generated at 2022-06-23 12:17:13.841589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.quiet(True)
    display._verbosity = 3
    lookup = LookupModule()

    env = AnsibleEnvironment()
    templar = env.get_template_class()()
    j2env = env.jinja2.environment
    searchpath = list()
    #set jinja2 internal search path for includes
    for term in ('./../includes', './includes'):
        searchpath.append(os.path.abspath(term))
    j2env.loader = j2env.loader if j2env.loader is not None else j2env.UNDEFINED
    lookup._templar = templar.copy_with_new_env(j2env)
    lookup._templar._available_variables = dict()


# Generated at 2022-06-23 12:17:22.107953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    src_dir = os.path.join(base_dir, 'lib', 'ansible', 'plugins', 'lookup', 'template')
    test_dir = os.path.join(src_dir, os.path.basename(os.path.dirname(__file__)))
    test_file = os.path.join(test_dir, 'test_template_data.txt')

    assert os.path.exists(test_file)

    # Create an instance of LookupModule to be able to call method run()
    lm = LookupModule()

    # Invoke run() with various terms

# Generated at 2022-06-23 12:17:24.321179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The unit tests for this module are stored in the tests directory.
    # At a later time these tests will be moved to ansible-test.
    pass

# Generated at 2022-06-23 12:17:26.298110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert isinstance(test_lookup, LookupModule) is True

# Generated at 2022-06-23 12:17:30.188017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = ['test_file']
    test_options = {'test_options':'test options'}
    test_template_vars = {'test_var': 'test_value'}

    # test constructor
    test_lookup = LookupModule(**test_options)

    # test run
    result = test_lookup.run(test_terms, variables={}, template_vars=test_template_vars)
    assert result == [u'# Ansible managed:\n\n'], 'Test LookupModule failed, got %s' % result

# Generated at 2022-06-23 12:17:41.582080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.plugins import PluginLoader

    terms = ['../../test/units/lookup_plugins/template_tests/foo.j2']
    variables = {
        'name': 'John Doe'
    }

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['../../test/units/lookup_plugins/template_tests/hosts'])
    inv_manager._inventory.hosts['localhost'] = {'hostname': 'localhost'}

# Generated at 2022-06-23 12:17:53.537391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader as plugins_loader
    lookup_module = plugins_loader._load_lookup_plugin('template', terms=[])
    assert isinstance(lookup_module, LookupModule)
    # test convert_data option
    assert lookup_module.get_option('convert_data')
    lookup_module.set_options(var_options={'convert_data': False})
    assert not lookup_module.get_option('convert_data')
    # test variable_start_string option
    lookup_module.set_options(var_options={'variable_start_string': '{{'})
    assert lookup_module.get_option('variable_start_string') == '{{'
    # test variable_end_string option

# Generated at 2022-06-23 12:17:55.299252
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_loader = LookupModule()
    assert hasattr(test_loader, '_templar')

# Generated at 2022-06-23 12:18:07.270434
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:18:17.862105
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:18:24.990605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # test all methods
    assert isinstance(lookup.run, object)
    assert isinstance(lookup.set_options, object)
    assert isinstance(lookup.get_option, object)
    assert isinstance(lookup.template, object)
    assert isinstance(lookup.find_file_in_search_path, object)
    assert isinstance(lookup.write_file, object)

# Generated at 2022-06-23 12:18:28.260396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    # Given
    # no data
    # When
    # running the run method of class LookupModule
    # Then
    # the following exception should be thrown
    with pytest.raises(TypeError):
        LookupModule().run()


# Generated at 2022-06-23 12:18:30.229620
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert instance is not None

# Generated at 2022-06-23 12:18:41.985219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module.set_loader({'_get_file_contents': lambda x: ('', True)})


# Generated at 2022-06-23 12:18:45.673933
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Tests that no exception is raised when the constructor is run."""

    try:
        LookupModule()
    except Exception as e:
        raise Exception('Unable to create LookupModule object! Check the spec!') from e

# Generated at 2022-06-23 12:18:52.243487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Ansible Galaxy - https://galaxy.ansible.com/docs/contributing/testing.html
    # Test for construction
    # for now, ansible doesn't make use of this, so we'll just test that we can
    # create an instance and destruct an instance, and we'll also test the __call__
    # dunder method
    module = LookupModule("/tmp/bogus")
    assert module != None
    del module

# Generated at 2022-06-23 12:19:01.625076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    test_content = """
    {% if P1 %}
    abcdef
    {% else %}
    ghijkl
    {% endif %}
    """
    test_dir = tempfile.mkdtemp(prefix='ansible_test_template_plugin')
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write(test_content)

    # generate an inventory
    loader = DataLoader()

# Generated at 2022-06-23 12:19:13.006004
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class AnsibleVars(dict):
        def __init__(self, vars):
            self.vars = vars

        def __getattr__(self, name):
            return self.get(name)

    t = LookupModule()
    t.set_options(direct={
        'variable_start_string': '%%',
        'variable_end_string': '%%',
        'template_vars': {'var1': 'value1', 'var2': 'value2'},
    })

    with open('tests/unit/plugins/lookup/test_template.j2', 'r') as f:
        expected = f.read()


# Generated at 2022-06-23 12:19:25.402322
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    # test with simple template
    test_terms = ['test_template.j2']
    test_variables = {'testvar': 'testvalue'}
    test_direct = {'variable_start_string': '<<', 'variable_end_string': '>>'}
    module.set_options(var_options=test_variables, direct=test_direct)

    test_result = module.run(test_terms, test_variables, **test_direct)

    assert test_result[0] == '<< testvar >> = testvalue'

    # test with more complex template
    test_terms = ['test_template2.j2']
    test_variables = {'testvar2': 'testvalue2',
                      'testvar': 'testvalue'}

# Generated at 2022-06-23 12:19:27.902241
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = [
        {'foo': 'bar'}
    ]
    lookup_plugin = LookupModule()
    assert results == lookup_plugin.run([], {})

# Generated at 2022-06-23 12:19:28.767587
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:19:34.624371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO:
    # - Ensure that LookupModule.run() is tested with different option combinations
    # - LookupModule.run() should be called without the self argument.
    #   Related info: https://github.com/ansible/ansible/issues/30785
    #   Explaining this issue: https://github.com/ansible/ansible/issues/30785#issue-293950355
    pass

# Generated at 2022-06-23 12:19:45.606750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    validate the run method of class LookupModule
    """
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader({'path': '1'})

    # Case 1: Invalid file name to lookup
    terms = ['/tmp/abc.j2']
    variables = {}
    kwargs = {'convert_data': True}
    try:
        ret = lookup_plugin.run(terms, variables, **kwargs)
    except AnsibleError as ex:
        assert ex.message == "the template file /tmp/abc.j2 could not be found for the lookup"

    # Case 2: Valid file name to lookup
    terms = ['/etc/hosts']
    variables = {}
    kwargs = {'convert_data': True}

# Generated at 2022-06-23 12:19:56.330373
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.process import get_bin_path
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment, USE_JINJA2_NATIVE
    from ansible.template.template import Templar
    from ansible.vars.reserved import *

    lookup_plugin = LookupModule()

    # Use the LookupModule.get based on the `cwd` and the `env`.
    assert lookup_plugin.get_based_path(".") == '.'
    assert lookup_plugin.get_based_path("..") == '..'
    assert lookup_plugin.get_based_path("/") == '/'
    assert lookup_

# Generated at 2022-06-23 12:20:06.112136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test template file exists
    try:
        import __main__
        __main__.display = Display()
    except:
        pass
    test_term = './test_lookup_template.j2'
    test_file = file(test_term)
    data = test_file.read()
    test_file.close()
    test_template = data.splitlines()
    # Test template file does not exist
    test_term_not_exist = 'template_does_not_exist.j2'
    test_variables = {
        'hostvars': {'hostname': {'ansible_hostname': 'hostname'}}, 'inventory_hostname': 'hostname'
    }

# Generated at 2022-06-23 12:20:15.939033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, **kwargs):
            self.convert_data = kwargs.get('convert_data', False)
            self.variable_start_string = kwargs.get('variable_start_string', '{{')
            self.variable_end_string = kwargs.get('variable_end_string', '}}')
            self.comment_start_string = kwargs.get('comment_start_string', '/*')
            self.comment_end_string = kwargs.get('comment_end_string', '*/')
            self.jinja2_native = kwargs.get('jinja2_native', False)
            self.template_vars = kwargs.get('template_vars', {})