

# Generated at 2022-06-23 12:10:10.789724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()

    # test_object.run()

    return True


# Generated at 2022-06-23 12:10:13.778082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    if not isinstance(lm, LookupModule):
        raise AssertionError("LookupModule object creation failed")


# Generated at 2022-06-23 12:10:19.086767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test_terms = ['./doc_tests/examples/template_example.j2']
    test_variables = {'var1': 'Hello', 'var2': 'World'}
    test_result = [u'Hello World']
    assert test.run(terms=test_terms, variables=test_variables) == test_result, "ERROR test_LookupModule_run"

# Generated at 2022-06-23 12:10:29.216449
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json

    # Task: Lookup for template file
    lookup_task = 'template'

    # Options for lookup_task
    lookup_options = dict()

    # Check for IDEMPOTENCE
    for _ in range(2):
        lookup_obj = LookupModule()

        # Check if task is available
        assert lookup_obj.has_plugin(lookup_task)

        # Load options into Lookup module
        lookup_obj.set_options(**lookup_options)

        # Tests the run function in Lookup module
        result = lookup_obj.run([lookup_task], lookup_options)

        # Results should be a list
        assert isinstance(result, list)

        # Result of lookup is a string, which can be converted to
        # dictionary object
        result_dict = json.loads(result[0])

       

# Generated at 2022-06-23 12:10:36.128898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = ['/path/to/file1.j2']
    variables = {
        'env': {
            'templates': '/path/to/templates',
        },
        'ansible_search_path': [
            '/path/to/templates',
            '/path/to/roles',
        ],
    }
    kwargs = {
        'convert_data': False,
        'template_vars': {},
        'jinja2_native': False,
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'comment_start_string': None,
        'comment_end_string': None,
    }

    lookup_file_return_value = '/path/to/templates/file1.j2'

# Generated at 2022-06-23 12:10:45.456417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_name = 'lookup_plugin.template'
    globals()['__name__'] = module_name

    class MockTemplar:
        def __init__(self):
            self.template_data = None

        def set_temporary_context(self, **kwargs):
            return self

        def template(self, template_data, **kwargs):
            self.template_data = template_data
            return self.template_data

        def copy_with_new_env(self, **kwargs):
            return self

    class MockVarsModule:
        def __init__(self, dict):
            self.dict = dict

        def get(self, key, default=None):
            return self.dict.get(key, default)


# Generated at 2022-06-23 12:10:49.463691
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # construct LookupModule object
    lookup_plugin = LookupModule()

    # Check if object is of type LookupModule
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-23 12:10:58.942429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Testing jinja2_native variable. Use NativeJinjaText to compare result
    result = lookup.run(['/home/test/templates/foo.txt'], {'lookup_jinja2_native': True, 'lookup_jinja2_convert_data': False})
    assert result[0] == NativeJinjaText('foo')
    result = lookup.run(['/home/test/templates/foo.txt'], {'lookup_jinja2_native': False, 'lookup_jinja2_convert_data': False})
    assert result[0] == 'foo'

    # Testing convert_data variable

# Generated at 2022-06-23 12:11:03.764134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import tempfile
    import json
    import shutil
    from units.mock.loader import DictDataLoader

    # create a temporary search path directory
    tmpdir = tempfile.mkdtemp()
    lookupfile = os.path.join(tmpdir, 'lookupfile')
    with open(lookupfile, 'w') as f:
        # {{ lookup('extended_json', {'name': 'Mary Poppins', 'age': 26, 'hired': True}) }}
        f.write('{"name": "{{ name }}", "age": {{ age | int }}, "hired": {{ hired | to_json }}}')

    # create a mock loader module that returns a valid ansible search path

# Generated at 2022-06-23 12:11:07.869537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options()
    template_data = "Hello World"
    res = lookup_module.run(['test'], {}, lookup_file='test.j2')[0]
    assert res == template_data

# Generated at 2022-06-23 12:11:18.031788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{lookup("template", "../../files/hello_world.j2")}}')))
             ]
        )

# Generated at 2022-06-23 12:11:28.487155
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Instantiate LookupModule class
    lm = LookupModule()

    # Test with no terms
    terms = None
    variables = {}
    result = lm.run(terms, variables)
    assert result == [], 'returned %s' % result

    # Test with no variables
    terms = 'test.j2'
    variables = None
    result = lm.run(terms, variables)
    assert result == [], 'returned %s' % result

    # Test with a valid template and variables
    terms = 'test.j2'
    variables = {'var1': 'val1'}
    result = lm.run(terms, variables)
    assert result[0] == 'This is a test of the lookup module with var1=val1', 'returned %s' % result

    # Test with an invalid template

# Generated at 2022-06-23 12:11:34.915281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_path = "/home/user/git/ansible/lib/ansible/plugins/lookup/template"
    if not os.path.isfile(file_path):
        assert False, "This test is intended to run during unit testing inside of Ansible " \
                      "framework where is real file at path: %s" % file_path
    assert True

# Generated at 2022-06-23 12:11:36.514420
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # pylint: disable=unused-variable
  lookup = LookupModule()

# Generated at 2022-06-23 12:11:38.293232
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False, "Not implemented"


if __name__ == "__main__":

    test_LookupModule_run()

# Generated at 2022-06-23 12:11:45.827287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    # TODO: check instantiation
    lookup_module = LookupModule()

    # Create a term list
    terms = ['two', 'three']

    # Create a variables dictionary
    variables = {'one': 1, 'two': 2, 'three': 3}

    # Create a kwargs dictionary
    kwargs = {'one': 1}

    # Check call of run method
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-23 12:11:53.373808
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    display = Display()
    display.verbosity = 2
    terms = [ "./testlookup/testlookup.j2", "./testlookup/testlookup2.j2" ]

    jinja2_native = False
    lookup_template_vars = dict(var1=True, var5=5)
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '/*'
    comment_end_string = '*/'


# Generated at 2022-06-23 12:12:02.573688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    import sys
    import os
    import shutil
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment, USE_JINJA2_NATIVE
    from ansible.template.vars import AnsibleJ2Vars

    # We can't rely on __file__ here because we need to run the test on Windows too.
    this_dir = os.path.dirname(os.path.realpath(__file__))
    sandbox = os.path.join(this_dir, "test_template_lookup")
    shutil.rmtree(sandbox, ignore_errors=True)


# Generated at 2022-06-23 12:12:04.051996
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:12:12.328753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os
    import pytest

    """This unit test tests the run method of the LookupModule

    Args:
        No arguments

    Returns:
        No returns

    """
    # Create a test template file
    FILE_TEMPLATE = """
    {% if inventory_somestring is defined %}
        The variable inventory_somestring exists
    {% else %}
        The variable inventory_somestring does not exist
    {% endif %}
    """

    # Create a test variable file

# Generated at 2022-06-23 12:12:13.268432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:12:24.112488
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:12:30.076645
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as plugin_loader
    from ansible.parsing.dataloader import DataLoader

    terms = ['test_template.j2']
    template_vars = {}
    loader = DataLoader()
    variables = {}

    env_vars = {}
    env_vars['FOO'] = "foo"
    env_vars['BAR'] = "bar"

    lookup = plugin_loader.get("lookup", "template")
    lookup = lookup.LookupModule()

    results = lookup.run(terms = terms, variables = variables, loader = loader)
    assert 'foo: foo' in results[0]
    assert 'bar: bar' in results[0]

    results = lookup.run(terms = terms, variables = variables, loader = loader, template_vars = template_vars)

# Generated at 2022-06-23 12:12:31.551097
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # look at the top-level docstring for the user-visible documentation
    # and tests.  This is needed as LookupModule has a docstring but LookupBase
    # does not.
    pass

# Generated at 2022-06-23 12:12:43.314298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = '1.j2'
    variables = {
        'foo': 'Test',
        'bar': {'answer': 42},
        'empty': '',
        'nonesuch': None,
        'quoted': '"quoted"',
        'ansible_search_path': ['.']
    }

    res = lm.run(terms, variables,
                 convert_data=True,
        #         debug=True,
                 template_vars={'baz': 'lookup_plugin'},
                 variable_start_string="[[",
                 variable_end_string="]]",
                 comment_start_string="[//]: # ([",
                 comment_end_string="])",
                 )
    assert res == ["{{ 1 }}"]


# Generated at 2022-06-23 12:12:51.680240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.template import AnsibleEnvironment
    from ansible.template import generate_ansible_template_vars
    from ansible.template import to_unicode
    from ansible.template import USE_JINJA2_NATIVE
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_bytes

    # -- Variables -- #
    # Build a jinja2 environment
    jinja2_env = AnsibleEnvironment(loader=None, variable_start_string='{', variable_end_string='}')
    # Build a

# Generated at 2022-06-23 12:12:53.861840
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_x = LookupModule()
    assert isinstance(lookup_x, LookupModule)


# Generated at 2022-06-23 12:12:54.492906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:13:01.593383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # normal case
    terms = ['test.j2']
    variables = {'foo': 'bar'}
    assert module.run(terms, variables) == ['bar']
    # missing file
    terms = ['missing.j2']

# Generated at 2022-06-23 12:13:12.372934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import sys
    import os
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader

    # data for LookupModule class
    # namedtuple is not available in python 2.6. So use tuple instead.
    class LookupModuleData(tuple):
        __slots__ = ()
        _fields = ('name', 'directory', 'value')

        def __new__(cls, name, directory, value):
            return tuple.__new__(cls, (name, directory, value))

    lookup_module_data = {}


# Generated at 2022-06-23 12:13:22.957031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ UnitTest
    """
    # GIVEN
    template_path = "templates/test_template.j2"
    template_file = {
        'dict': {'key': 'value'},
        'files': '{{ lookup("files", "/etc/passwd") }}',
        'template': '{{ lookup("template", "{}") }}'.format(template_path)
    }
    variables = {'key': 'value', 'nested_key': {'nested_key': 'nested_value'}}

    # WHEN
    lookup = LookupModule()
    result = lookup.run([template_path], variables)

    # THEN
    assert result == [to_bytes(template_file)]

# Generated at 2022-06-23 12:13:28.115757
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class DummyVars(dict):
        def __getitem__(self, name):
            return {
                'vars': {
                    'foo': 'bar'
                },
                'template_result': 'foo'
            }[name]

    lookup = LookupModule()
    assert 'bar' == lookup.run(['{{ vars.foo }}'], DummyVars())[0]

# Generated at 2022-06-23 12:13:30.137802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:13:37.293335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test normal use
    assert LookupModule([], {}).run(terms=['test.j2'], variables={}) == [u'Hello Ansible!\n']

    # Test convert data is on by default
    assert LookupModule([], {}).run(terms=['data.j2'], variables={}) == [u'Hello Ansible!\n']

    # Test jinja2_native
    assert LookupModule([], {}).run(terms=['test.j2'], variables={}, jinja2_native=True) == [u'Hello Ansible!\n']

# Generated at 2022-06-23 12:13:38.613486
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # The only test here is if the class can be instantiated
    assert LookupModule()

# Generated at 2022-06-23 12:13:49.048580
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:13:55.873257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    lookup_module = LookupModule()

    # create a dict object that reprensents a host

# Generated at 2022-06-23 12:14:01.527615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    data = {'ansible_search_path': '/etc'}
    result = lm.run(['lookup_fixture.j2'], data)
    assert result == ['lookup_fixture\n']

# Generated at 2022-06-23 12:14:04.868249
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #import the class
    import ansible.plugins.lookup.template
    #create an object
    t = ansible.plugins.lookup.template.LookupModule()
    assert t

# Generated at 2022-06-23 12:14:07.231050
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the constructor of class LookupModule
    """

    lookup_obj = LookupModule()

    # Assert for the lookup_obj
    assert lookup_obj is not None

# Generated at 2022-06-23 12:14:12.489500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Create a mock variables
    # module.set_options() sets direct to False and var_options to None if the argument is not provided
    # The variable class has all attributes set to None or False, they are not needed in the test
    # The module find_file_in_search_path uses ansible_playbook_

# Generated at 2022-06-23 12:14:20.326705
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # find_file_in_search_path method of LookupBase
    #
    # searchpath is a list of directories, filename is the file name to find.
    #
    # Returns the filepath or None if not found
    def mock_find_file_in_search_path(*args, **kwargs):
        filename = args[2]
        if filename == 'test1.j2':
            return 'test1.j2'
        if filename == 'test2.j2':
            return 'test2.j2'
        return None

    # _get_file_contents method of DataLoader
    #
    # filename is the name of the file to load
    #
    # Returns a tuple containing the contents of the file, and whether the contents
    # should be shown during play.

# Generated at 2022-06-23 12:14:23.235594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:14:32.860158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import pytest

    current_directory = os.path.dirname(os.path.realpath(__file__))
    inventory_path = os.path.join(current_directory, "data", "inventory")
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=inventory_path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    lookup_module = lookup_loader.get('template')

    lookup_module.set_options(var_options=variable_manager, direct=dict())

    # Setup the proper search path
    variable_manager

# Generated at 2022-06-23 12:14:35.120871
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l1 = LookupModule()
    l2 = LookupModule()
    assert l1 != l2

# Generated at 2022-06-23 12:14:45.773954
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test lookup module instance
    lookup_module = LookupModule()

    # Create a test AnsibleVars instance
    from ansible.vars import AnsibleVars
    ansible_vars = AnsibleVars()

    # Create a test lookup_loader instance
    from ansible.parsing.dataloader import DataLoader
    lookup_loader = DataLoader()

    # Create a test simple_vars instance
    simple_vars = {}

    # Test empty terms input
    terms = []
    with pytest.raises(AnsibleError) as exec_info:
        lookup_module.run(terms, ansible_vars, loader=lookup_loader, templar=None, **simple_vars)

    # Test terms input contains a template file name
    terms = ['some_template.j2']

# Generated at 2022-06-23 12:14:46.326294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:14:46.836752
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:14:58.093445
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    display = Display()
    text = 'hello'

# Generated at 2022-06-23 12:15:00.898220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['file.j2'], variables={'template_vars':{}}) is not None

# Generated at 2022-06-23 12:15:02.211992
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:15:02.956940
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_obj = LookupModule()

# Generated at 2022-06-23 12:15:13.121429
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Mock the display class to be silent
    def displayMock(self):
        pass
    display.vvv = displayMock

    terms = ["./some_template.j2"]
    # Set up the variables to be used by the plugins

# Generated at 2022-06-23 12:15:23.335043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run is directly testing the run method, thus the class is explicitly instantiated
    # pylint: disable=no-member
    lookup_module = LookupModule()
    # pylint: disable=protected-access

    fake_loader_mock = FakeLoader({
        './some_template.j2': to_bytes(u"{{ lookup('pipe', 'echo '+ some_argument) }}")
    })
    lookup_module._loader = fake_loader_mock
    lookup_module._templar = AnsibleEnvironment()

    # Test single file

# Generated at 2022-06-23 12:15:27.310980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lobj = LookupModule()
    assert lobj._loader is not None
    assert lobj._templar is not None
    assert lobj._loader.get_basedir() is not None

# Generated at 2022-06-23 12:15:27.826391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:15:33.582443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['../test/test.j2']
    variables = {}
    result = lookup.run(terms, variables)
    assert result[0] == 'Test\n'
    assert len(result) == 1

    terms = ['../test/test_multiline.j2']
    variables = {
            'var1': 'Y'
            }
    result = lookup.run(terms, variables)
    assert result[0] == 'Test\nY\n'
    assert len(result) == 1

# Generated at 2022-06-23 12:15:43.177758
# Unit test for constructor of class LookupModule
def test_LookupModule():  # pylint: disable=dangerous-default-value
    ansible_native_types = USE_JINJA2_NATIVE
    jinja2_native = False
    convert_data = False

    assert isinstance(ansible_native_types, bool)
    assert isinstance(jinja2_native, bool)
    assert isinstance(convert_data, bool)

    if ansible_native_types:
        assert jinja2_native != convert_data
    else:
        assert not jinja2_native
        assert not convert_data

# Generated at 2022-06-23 12:15:55.204335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # '_loader' and '_templar' will be used in 'run' method of LookupModule 
    _loader = None
    _templar = None
    terms = ['../plugins/lookup/template/test_template.j2']
    variables = {'var1': 'I am var1', 'var2': 'I am var2'}
    # create a instance of LookupModule
    lookupmodule = LookupModule()
    # call run(self, terms, variables, **kwargs)
    result = lookupmodule.run(terms, variables)
    assert result == ['This is a template test, I am var1\n']
    # run(self, terms, variables, **kwargs) will access _loader, so we need initiate _loader
    # run(self, terms, variables, **kwargs) will access _templ

# Generated at 2022-06-23 12:16:04.882810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.template import AnsibleUndefinedVariable
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    template_module = LookupModule(loader=loader)

    # Test if fail when file not found
    try:
        template_module.run([".template_file_not_found"], variable_manager)
    except AnsibleError:
        pass
    else:
        assert False, "Expected error, but got none"

    template_path = os.path.join(os.path.dirname(__file__), "..", "module_utils", "basic.py")


# Generated at 2022-06-23 12:16:12.676808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # GIVEN
    module = LookupModule()
    display = Display()
    module._templar = AnsibleEnvironment().get_template_class()(loader=None).environment

    with open("./test/test_playbooks/lookup_data.yml") as data_file:
        test_data = yaml.load(data_file)

    # WHEN
    result = module.run(terms=test_data['terms'], variables=test_data['variables'], **test_data['kwargs'])

    # THEN
    assert result == test_data['expected_result'], 'Expected: %s, got %s' % (result, test_data['expected_result'])

# Generated at 2022-06-23 12:16:15.615334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(lookup_plugin_template.LookupModule(loader=None, templar=None, shared_loader_obj=None) is not None)

# Generated at 2022-06-23 12:16:20.392717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This is a unit test for constructor of LookupModule.
    """
    try:
        #create a new instance of LookupModule
        lookup_module = LookupModule()
        assert lookup_module.run(terms=['./some_template.j2'], variables={})
    except Exception:
        raise AssertionError

# Generated at 2022-06-23 12:16:22.054017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """This is how to construct a new LookupModule object"""
    l = LookupModule()
    print(l)

# Generated at 2022-06-23 12:16:31.842040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    import ansible.plugins.lookup.template

    context.CLIARGS = {}
    context.CLIARGS['inventory'] = None

    # -------------------------------------------------------------------------
    # First test with an invalid term, in this case an empty string
    # -------------------------------------------------------------------------
    lookup = ansible.plugins.lookup.template.LookupModule()

    try:
        lookup.run(terms='', variables={})
    except AnsibleError as e:
        assert isinstance(e, AnsibleError)
        assert e.message == ("the template file  could not be found for the lookup")

    # -------------------------------------------------------------------------
    # Second test with an term with an invalid wildcard. In this case the
    # file cannot exist
    # -------------------------------------------------------------------------
    lookup = ansible.plugins.lookup.template.LookupModule()


# Generated at 2022-06-23 12:16:33.099486
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert(isinstance(module, LookupModule))

# Generated at 2022-06-23 12:16:41.580315
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with fake dict containing entries for the variables used by template.py
    def _get_file_contents(path):
        return b"{{ item[0] }} - {{ item[1] }}", False


# Generated at 2022-06-23 12:16:46.148887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global templar
    jinja2_env = AnsibleEnvironment(loader=None, variables={})
    templar = Templar(loader=None, variables={}, environment=jinja2_env)
    lookupModule = LookupModule()
    lookupModuleTemplar = lookupModule._templar
    assert lookupModuleTemplar is templar

# Generated at 2022-06-23 12:16:47.861714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)



# Generated at 2022-06-23 12:16:58.864739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    perms = { 'mode': '0600' }
    template_data = 'file {{ item }}'
    terms = [ './some_template.j2', [ './some_template.j2', perms ] ]
    variables = {
      'ansible_search_path': [ 'search-path-1', 'search-path-2' ]
    }
    kwargs = {
      '_original_file': 'original file'
    }

    with LookupModule.get_loader_class().get_resource_path('') as search_path:
        for term in terms:
            if isinstance(term, list):
                term, perms = term
            lookupfile = os.path.join(search_path, term)

# Generated at 2022-06-23 12:17:06.453581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test.j2'], variables={'role_path': '/home/rolename/roles/rolename/'},
                             convert_data=True, template_vars={'test_var': 'test_value'}, jinja2_native=False,
                             variable_start_string='[%', variable_end_string='%]', comment_start_string='[#',
                             comment_end_string='#]') == 'test.j2 contents'

# Generated at 2022-06-23 12:17:07.619155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lm = LookupModule()
    except Exception as e:
        raise AnsibleError("Got an exception instantiating LookupModule: %s" % e)

# Generated at 2022-06-23 12:17:08.499199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:17:10.975544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Running Test: test_LookupModule")
    testlookup = LookupModule()
    assert testlookup is not None


# Generated at 2022-06-23 12:17:12.578893
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:17:21.571497
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestModule(object):

        def __init__(self, loader=None, templar=None, variables=None):
            self.templar = templar
            self.loader = loader
            self.variables = variables

        def get_option(self, option):
            if option == 'convert_data':
                return True
            elif option == 'template_vars':
                from collections import namedtuple
                MyDict = namedtuple('MyDict', ['items'])
                return MyDict({})
            elif option == 'variable_start_string':
                return '{{'
            elif option == 'variable_end_string':
                return '}}'
            elif option == 'jinja2_native':
                return False
            else:
                return None


# Generated at 2022-06-23 12:17:22.730640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Perform unit test of constructor of class LookupModule.
    """
    LookupModule()

# Generated at 2022-06-23 12:17:23.749193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()



# Generated at 2022-06-23 12:17:32.634847
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test all options
    def run_all_options(result_expected, lookup_plugin_options):
        # Remove unwanted options
        if 'lookup_template_vars' in lookup_plugin_options:
            del lookup_plugin_options['lookup_template_vars']
        # Initialize LookupPlugin class
        lookup_plugin = LookupModule()
        # Initialize AnsibleOptions class
        ansible_options = AnsibleOptions(defaults=DEFAULTS, lookups=None, parser=None)
        # Initialize self of class LookupModule
        lookup_plugin.set_options(var_options={}, direct=lookup_plugin_options)
        # Create a Jinja2 templar to use in the LookupPlugin class
        templar = Templar(loader=None, variables={})
        lookup_plugin._templar

# Generated at 2022-06-23 12:17:39.754377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    contText = '''
    content of the file
    '''
    lookup = LookupModule()
    lookup._loader = DummyLoader()
    lookup._loader._lines = [[to_bytes(contText)]]

    terms = ['../somepath/tofile/test.txt']
    variables = {}
    kwargs = {}

    results = lookup.run(terms, variables, **kwargs)

    assert(results == [contText])

# Generated at 2022-06-23 12:17:40.281019
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:17:51.225113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import json
    import yaml
    from ansible.module_utils.six import PY3

    # PY3 has an implicit unicode conversion, resulting in the
    # string 'b' below being converted to a unicode string.
    # The test asserts that the value is a str object
    #
    # To test the functionality, the value 'b' here must be a str
    # object. However, when running on PY3, the implicit unicode
    # conversion *converts* the str object to a unicode string
    #
    # Run the test twice, with sys.version returning a unicode
    # string, and with a str object. The absence of the implicit
    # unicode conversion will trigger the value to be a str
    # object.

# Generated at 2022-06-23 12:17:51.851210
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:17:54.809225
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=unused-variable
    x = LookupModule()
    # pylint: enable=unused-variable

# Generated at 2022-06-23 12:17:57.002349
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader._create_lookup_plugin('template')
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:18:08.798133
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test lookup without jinja2_native enabled
    lu = LookupModule()
    lookup_vars = dict()
    lookup_options = dict()
    lookup_vars['template_path'] = ['']
    # Here the file name is relative, hence we get the absolute path from os.path.abspath
    lookup_template_path = os.path.abspath('./test/files/jinja2.j2')
    lookup_term = './test/files/jinja2.j2'
    lookup_term_list = [lookup_term]
    results = lu.run(lookup_term_list, lookup_vars, **lookup_options)
    assert [lookup_template_path] == results

    # Test lookup with jinja2_native enabled
    lu = Lookup

# Generated at 2022-06-23 12:18:20.208468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    l = LookupModule()
    terms = []
    terms.append("../ansible-playbooks/roles/java_role/vars/main.yml")
    terms.append("../ansible-playbooks/roles/java_role/defaults/main.yml")
    terms.append("../ansible-playbooks/roles/zookeeper_role/defaults/main.yml")
    terms.append("../ansible-playbooks/roles/zookeeper_role/files/zookeeper-3.4.13.tar.gz")
    terms.append("../ansible-playbooks/roles/zookeeper_role/tasks/main.yml")
    #terms.append("../ansible-playbooks/roles/zookeeper_role/templates/zoo

# Generated at 2022-06-23 12:18:30.047531
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use a mock display for method debug
    display_mock = Display()
    display_mock.debug = Mock(return_value=None)

    # Test method run is called with the expected parameters
    lookup_module = LookupModule()
    lookup_module._display = display_mock
    lookup_module._templar = Mock()
    lookup_module._loader = Mock()
    lookup_module._loader.get_basedir = Mock(return_value="")
    lookup_module.find_file_in_search_path = Mock(return_value="")
    lookup_module.run(["file.template"], {"lookup_file": "file.template"})

    assert display_mock.debug.call_count == 1

# Generated at 2022-06-23 12:18:31.779159
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create LookupModule to work with, use special constructor for unit tests
    lookup = LookupModule.load(None, variables=dict(), **{'_templar': None})

    return lookup

# Generated at 2022-06-23 12:18:37.366586
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test LookupModule class."""

    # Create a mock environment
    env = {'ansible_search_path': ['playbook_dir'] + LookupBase._get_search_path()}
    # Instantiate a LookupModule object
    lm = LookupModule()
    # Call run method
    lm.run([], env)

# Generated at 2022-06-23 12:18:38.113507
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with None and other values
    lookup_moduleObject = LookupModule()

# Generated at 2022-06-23 12:18:40.455749
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    if hasattr(l, 'run'):
        assert True
    else:
        assert False

# Generated at 2022-06-23 12:18:45.484421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Capture the results of the run method
    # with the given input
    terms = "test.j2"
    variables = {'ansible_search_path': ['/test1', '/test2']}
    result = module.run(terms, variables)

    # Check if all the contents in the file are returned
    # as a list of strings
    assert result[0] == 'test\n'

# Generated at 2022-06-23 12:18:46.389418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:18:57.899086
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule
    lookup = LookupModule()

    # Create a fake templar to put in the LookupModule
    # This is a class and we will mock it's methods
    class Templar():

        def copy_with_new_env(self, **kwargs):
            return self

        def set_temporary_context(self, **kwargs):
            return self

        def template(self, data, preserve_trailing_newlines, convert_data, escape_backslashes):
            return data

    lookup._templar = Templar()

    # Create a fake loader to put in the LookupModule
    # This is a class and we will mock it's methods

# Generated at 2022-06-23 12:18:59.239234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-23 12:19:03.683676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == []
    coll_args = {'foo': 'bar'}
    assert lookup_module.run(list(coll_args.keys()), coll_args) == list(coll_args.values())

# Generated at 2022-06-23 12:19:14.196740
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    temp_loader = DictDataLoader({
        "/etc/ansible/roles/test/templates/test.j2": b"This is a test template {{ variable }}",
        "/etc/ansible/roles/test/files/test.txt": b"This is a test file",
    })
    templar = Templar(loader=temp_loader)
    lookup_module = LookupModule(templar=templar)

    # Verify that a lookup will return a list of strings

# Generated at 2022-06-23 12:19:14.792513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:19:27.264080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_ansible_vars = {'template_dir': './', 'template': '././example.j2', 'template_path': './'}
    test_ansible_options = {'convert_data': True, 'template_vars': {}, 'comment_start_string': None, 'comment_end_string': None, 'variable_start_string': '{', 'variable_end_string': '}'}
    test_ansible_env = AnsibleEnvironment({})
    lookup_module._loader = AnsibleLoader(None)
    lookup_module._templar = Templar(test_ansible_env)

# Generated at 2022-06-23 12:19:32.529062
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Init
    ######################################################################
    lookup = LookupModule()

    # Mock input parameters
    ######################################################################
    terms = ['lookup_fixture.j2']
    variables = {'myvar': 42}

    # Run test
    ######################################################################
    output = lookup.run(terms, variables)

    # Assertions
    ######################################################################
    assert [to_bytes('42')] == output

# Generated at 2022-06-23 12:19:43.661741
# Unit test for constructor of class LookupModule
def test_LookupModule():
    b = LookupModule()
    b.set_options({})
    assert not b.get_option('convert_data')
    assert not b.get_option('jinja2_native')
    # make sure jinja2_native has no effect if USE_JINJA2_NATIVE is not True
    b.set_options(jinja2_native=True)
    assert not b.get_option('convert_data')
    assert not b.get_option('jinja2_native')
    b.set_options(convert_data=True)
    assert b.get_option('convert_data')
    assert not b.get_option('jinja2_native')
    b.set_options(jinja2_native=True)
    assert not b.get_option('convert_data')
   

# Generated at 2022-06-23 12:19:44.709294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-23 12:19:52.233777
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert os.path.exists('/etc/hosts')
    lookup_instance = LookupModule()
    assert lookup_instance.run(
        terms=['/etc/hosts'],
        variables={},
        convert_data=True,
        template_vars={},
        jinja2_native=False,
        variable_start_string='{{',
        variable_end_string='}}',
        comment_start_string=None,
        comment_end_string=None)[0].startswith('#')

# Generated at 2022-06-23 12:19:53.045846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No test for LookupModule.run"

# Generated at 2022-06-23 12:19:54.281189
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule(), 'run')

# Generated at 2022-06-23 12:19:55.487910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod.run([])

# Generated at 2022-06-23 12:20:01.827008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import tempfile

    from io import StringIO

    # setup
    loader = DictDataLoader({})
    variables = VariableManager()
    variables.extra_vars = {'name': 'John', 'company': 'Ansible'}
    inventory = Inventory(loader=loader, variable_manager=variables, host_list=[])
    loader.set_basedir(tempfile.gettempdir())

    # test simple template
    lookup_template_vars = {'type': 'people'}
    templar = Templar(loader=loader, variables=variables, inventory=inventory)
    lookup = LookupModule(loader=loader, templar=templar, **lookup_template_vars)

# Generated at 2022-06-23 12:20:04.617427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Test for constructor of class LookupModule
    '''
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-23 12:20:09.493035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # build a mock 'templar' object
    templar = dict()

    # build a mock 'variables' object
    variables = dict()

    # build a list of terms
    terms = ['term1', 'term2']

    lookup_module = LookupModule(templar=templar, variables=variables)
    result = lookup_module.run(terms=terms)
    assert result == []