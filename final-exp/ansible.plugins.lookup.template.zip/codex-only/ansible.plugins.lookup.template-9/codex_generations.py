

# Generated at 2022-06-23 12:10:13.090258
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class TestException(Exception):
        pass

    test_dict = {
        '_terms': 'test_data',
        'convert_data': True,
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'jinja2_native': True,
        'template_vars': {'var1': 'value1'},
    }

    # Testing dict/dict-like objects
    test_obj = type('test_dict_obj', (object,), test_dict)

    # Testing object without __dict__ attribute
    class test_obj2:
        def __init__(self, term):
            for key, val in term.items():
                setattr(self, key, val)


# Generated at 2022-06-23 12:10:15.312205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert(lk != None)

# Unit Test for run of class LookupModule

# Generated at 2022-06-23 12:10:16.237911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-23 12:10:18.260976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([], [])

# Generated at 2022-06-23 12:10:21.940131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['template1.j2']
    variables = {}
    lookup_plugin = LookupModule()

    with pytest.raises(AnsibleError,match=r"the template file"):
        lookup_plugin.run(terms, variables)


# Generated at 2022-06-23 12:10:22.689262
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:10:31.897820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    mod = plugin_loader.lookup_loader.get('template', class_only=True)

    assert mod is not None, "Could not load the 'template' plugin"
    assert hasattr(mod, 'run'), "The 'template' plugin has no run() method"

    # test with a template that just returns the first item in a list with a single space in between, for example ['a', 'b', 'c'] will render 'a '
    assert mod.run(['./ansible/test/units/lookup/data/test.j2'], {})[0] == 'a ', "The template lookup did not correctly render the template"

# Generated at 2022-06-23 12:10:40.376631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    lookup = LookupModule()
    lookup._templar = Templar(variables={}, loader=None)
    lookup._loader = None

    from ansible.module_utils.six import PY3
    from ansible.template import CLEAR_FAILED_DICT
    if PY3:
        result = lookup.run([u'test.j2'], CLEAR_FAILED_DICT)
    else:
        result = lookup.run(['test.j2'], CLEAR_FAILED_DICT)
    assert result == ['Test\n']

# Generated at 2022-06-23 12:10:46.556346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert len(lm.run(None, None)) == 0

    terms = ['test_templates/foo.j2']
    terms += ['test_templates/foo.j2']
    terms += ['test_templates/foo.j2']
    terms += ['test_templates/foo.j2']
    template_vars = {'bar': 'baz'}
    display.verbosity = 2
    result = lm.run(terms=terms, variables={'role_path': ['test_templates'], 'template_vars': template_vars})
    display.verbosity = 0
    assert result[0] == 'foo baz\n'
    assert result[1] == 'foo baz\n'
    assert result[2] == 'foo baz\n'

# Generated at 2022-06-23 12:10:54.052693
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # LookupModule: __init__(self, loader=None, templar=None, **kwargs)
    # create a LookupModule instance
    lookup_module = LookupModule()

    assert lookup_module is not None, "Unable to create LookupModule instance"
    assert lookup_module._templar is not None, "Unable to get templar from LookupModule instance"
    assert lookup_module._loader is not None, "Unable to get loader from LookupModule instance"

# Generated at 2022-06-23 12:10:56.871840
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        lookup_module = LookupModule()
    except Exception as e:
        print("Exception raised when creating an instance of %s: %s" % (LookupModule, e))
        raise e

# Generated at 2022-06-23 12:11:06.910725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock Display, just to silence the absence of Display.display()
    class Display_mock:
        def __init__(self, Mod):
            self.Mod = Mod
        def vvvv(self, msg, host=None):
            pass
        def debug(self, msg, host=None):
            pass
        def deprecated(self, msg, version, removed=False):
            pass

    # Create a mock for class LookupBase
    class LookupBase_mock():
        def __init__(self, Mod, terms, variables, **kwargs):
            self.Mod = Mod
            self.terms = terms
            self.variables = variables
            self.kwargs = kwargs

# Generated at 2022-06-23 12:11:15.638131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import jinja2
    import os
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import lookup_loader, module_loader

    # Initialize data loader
    loader = DataLoader()

    # Initialize InventoryManager with empty sources file
    sources = ','.join(['localhost,'])
    inventory = InventoryManager(loader=loader, sources=sources)

    # Initialize variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Initialize play context
    play_context = PlayContext()

    # Get the lookup plugin
    lookup_plugin = lookup_loader

# Generated at 2022-06-23 12:11:20.831304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = AnsibleModule(
        argument_spec = dict(
            _raw_params = dict(type='str', required=True),
            _task_vars = dict(required=True, type='dict'),
            _templar = dict(required=True, type='object')
        )
    )

    # Call load_plugin directly to test the __init__ method
    path = os.path.join(os.path.dirname(__file__), '..', 'template.py')
    lookup_module = load_plugin('lookup', path)
    result = lookup_module(module._task.args.get('_raw_params'),
                           variables=module._task.args.get('_task_vars'),
                           templar=module._task.args.get('_templar'))
    assert result

# Generated at 2022-06-23 12:11:23.158069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['./some_template.j2'],{}) == []


# Generated at 2022-06-23 12:11:24.539602
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: implement the unit test for method LookupModule.run
    pass


# Generated at 2022-06-23 12:11:26.344077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu._display is not None
    assert lu._loader is not None

# Generated at 2022-06-23 12:11:33.222665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import get_template_class
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    def new_template(template_data, searchpath=[], variables=None, convert_data=True, fail_on_undefined=True, **kwargs):
        if variables:
            kwargs.update(variables)
        if searchpath:
            env = Environment(loader=DictLoader({"temp.j2": template_data}), extensions=["jinja2.ext.do"],
                              keep_trailing_newline=True,
                              trim_blocks=True)

# Generated at 2022-06-23 12:11:41.296136
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test option convert_data = True
    module = LookupModule()
    with pytest.raises(AnsibleError, match="the template file .* could not be found for the lookup"):
        assert list(module.run(['missing.j2'], dict(convert_data=True))) == ['']

    # Test option convert_data = False
    module = LookupModule()
    with pytest.raises(AnsibleError, match="the template file .* could not be found for the lookup"):
        assert list(module.run(['missing.j2'], dict(convert_data=False))) == ['']

    # Test with template_vars
    module = LookupModule()

# Generated at 2022-06-23 12:11:42.500126
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-23 12:11:50.373511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = LookupModule()
    r._templar = templar = _fake_templar()
    r._loader = _fake_loader()

    terms = ["{{ baz }}/{{ fizz }}"]
    variables = dict(
        foo = dict(
            bar = "baz",
        ),
        baz = "buzz",
        fizz = "fuzz",
    )
    result = r.run(terms=terms, variables=variables)

    assert len(result) == 1
    assert to_text(result[0]) == "buzz/fuzz"



# Generated at 2022-06-23 12:11:53.591388
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import pytest

    try:
        lookup_module = LookupModule()
        assert 1 == 1
    except Exception:
        assert 1 == 0

# Generated at 2022-06-23 12:11:55.842309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([], variables={}, templar=None, loader=None) is not None

# Generated at 2022-06-23 12:11:57.201078
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 12:12:04.736320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with file /etc/passwd
    terms = ['../../tests/utils/testdata/ansible.cfg']
    variables = {'ansible_search_path': ['../../tests']}

    r = LookupModule().run(terms, variables, convert_data=True, comment_start_string=None, comment_end_string=None, jinja2_native=True)
    assert len(r) == 1
    assert "#config_file = /etc/ansible/ansible.cfg" in r[0]

# Generated at 2022-06-23 12:12:10.741451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.run(terms=['../../../test/utils/test_template.j2'], variables={'blah': 'foo'})
    lm.run(terms=['../../../test/utils/test_template.j2', '../../../test/utils/test_template.j2'], variables={'blah': 'foo'})

# Generated at 2022-06-23 12:12:13.335969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('In test_LookupModule')
    lookup_plugin = LookupModule()
    # test for '_templar' attribute
    assert hasattr(lookup_plugin, '_templar') == True


# Generated at 2022-06-23 12:12:16.054252
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Run constructor of LookupModule
    lu = LookupModule()
    # Check if lu is an object of type LookupModule
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-23 12:12:26.169145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'_original_file': '/etc/ansible/test.yml',
                               '_search_path': './test/',
                               '_load_name': 'test.yml'})
    terms = ['test.j2']

    # When file test.j2 exists, run method returns the file content.
    variables = {'foo': 'bar'}
    results = lookup_module.run(terms, variables)
    assert results == ['bar\n', 'bar\n']

    # When file test.j2 does not exist, run method raises an error.
    terms = ['test.j2_does_not_exist']
    try:
        lookup_module.run(terms, variables)
    except AnsibleError:
        pass

# Generated at 2022-06-23 12:12:38.624946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This tests the run method of class LookupModule.
    """

    from ansible.template import AnsibleEnvironment
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    collection_loader = AnsibleCollectionLoader()
    env_loader = collection_loader.get_loader('ansible.builtin')

    display = Display()
    var_manager = VariableManager()

    e = env_loader.get('/', {}, var_manager)

    test_instance = LookupBase(inventory='', loader=collection_loader, templar=e, shared_loader_obj=None)

# Generated at 2022-06-23 12:12:45.842723
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a lookup module object
    lookup_module = LookupModule()
    # Create a dict containing the arguments to be passed to method run
    arguments = dict(
        terms=["/etc/ansible/example.j2"],
        variables=dict(
            templated_var="{{ some_value }}"
        )
    )
    result = lookup_module.run(**arguments)
    assert len(result) == 1
    assert result[0] == "Hello {{ templated_var }}"

# Generated at 2022-06-23 12:12:57.404678
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # args and kwargs
    args = [["foo.j2", "bar.j2", "baz.j2"]]
    kwargs = {'convert_data': False}

    # create instance
    lookup_instance = LookupModule()
    lookup_instance.set_loader(None)

    # return value
    ret = [u'{"foo_j2": {"foo": "bar", "baz": "qux"}}', u'{"bar_j2": {"foo": "bar", "baz": "qux"}}', u'{"baz_j2": {"foo": "bar", "baz": "qux"}}']

    # run method and test for exceptions

# Generated at 2022-06-23 12:12:59.305819
# Unit test for method run of class LookupModule
def test_LookupModule_run():

# Data for test LookupModule

     terms  = [ '../../../templates/t1.j2' ]
     variables = dict()
     kwargs=dict()
     result = ["ABC\n"]
     expected = result
     result1= LookupModule().run(terms, variables, **kwargs)
     assert result1 == expected

# Generated at 2022-06-23 12:13:10.809312
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar

    # define fixture
    module_utils_text = __import__("ansible.module_utils._text")
    lookup_base = __import__("ansible.plugins.lookup.lookup_base")
    ansible_template = __import__("ansible.template")
    ansible_errors = __import__("ansible.errors")
    ansible_utils_display = __import__("ansible.utils.display")

    module_utils_text.to_bytes = to_bytes
    lookup_base.LookupBase = LookupBase
    ansible_template.Templar = Templar
    ansible_errors.AnsibleError = AnsibleError
    ansible_utils_display.Display = Display

    # define test parameters
   

# Generated at 2022-06-23 12:13:13.173295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 12:13:19.023282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock to return results from method search_path
    def search_path(*args, **kwargs):
        return search_path_result

    # create a mock to return results from method template of class Templar
    def template(*args, **kwargs):
        template_result.append(args[0])
        return template_result

    # create a mock to return results from method set_temporary_context of class Templar
    def set_temporary_context(*args, **kwargs):
        return set_temporary_context_result

    # create a mock to return results from method generate_ansible_template_vars of module template
    def generate_ansible_template_vars(*args, **kwargs):
        return generate_ansible_template_vars_result

    # create a mock to return results from method _get_file_contents

# Generated at 2022-06-23 12:13:29.230178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    import os
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    def get_variable_manager(loader, inventory):
        variable_manager = VariableManager()
        variable_manager.set_inventory(inventory)
        play_context = PlayContext()
        variable_manager.set_loader(loader)
        variable_manager.set_play_context(play_context)
        return variable_manager

    vl = VaultLib(password_files=[os.path.join(os.path.dirname(os.path.abspath(__file__)), '../test/test_vault.txt')])
    loader = DataLoader()

# Generated at 2022-06-23 12:13:32.325548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    lm = LookupModule(loader=DataLoader(), templar=None, **dict())
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:13:42.389070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #https://github.com/ansible/ansible/issues/21427
    # Ensure that we can run this lookup with no args
    try:
        result = lookup.run([])
    except AnsibleError:
        result = None
    assert result == []

    #Test basic usage
    terms = ['test.txt']
    result = lookup.run(terms)
    assert result == ['hello, world\n'], 'Error when lookup basic file template'

    #Test with multiple templates
    terms = ['test.txt', 'test2.txt']
    result = lookup.run(terms)
    assert result == ['hello, world\n', 'goodbye, world\n'], 'Error when lookup multiple file templates'

    #Test with convert_data option
    terms = ['test_vars.yaml']

# Generated at 2022-06-23 12:13:52.800004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    from ansible.compat.tests.mock import patch
    from ansible import constants as C

    def _get_file_contents(self, path):
        with open(path, 'rb') as f:
            return f.read(), True

    mock_list = [
        ('tests/fixtures/templates/sourcedir/subdir/foo.j2', 'templates/sourcedir', 'foo.j2'),
        ('templates/sourcedir', 'templates/sourcedir', 'templates/sourcedir')
    ]

    def mock_find_file_in_search_path(self, variables, dirname, filename):
        return next((path for path, dir, file in mock_list if dir == dirname and file == filename), None)

    _loader_m

# Generated at 2022-06-23 12:14:05.390535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: With very limited testing (os-specific) this line allows for testing here
    # and does not impact testing elsewhere (no change in ansible-test)
    # ansible.module_utils.basic.MODULE_COMPLEX_ARGS is only used by ansible.module_utils.basic.AnsibleModule()
    # and not used by ansible.template.AnsibleEnvironment() that is used in Ansible modules
    ansible.module_utils.basic.MODULE_COMPLEX_ARGS['template_vars'] = dict
    lm = LookupModule()

    # test with default options and a single term
    test_file = 'test_template.j2'
    test_content = 'test'
    lm.set_options(var_options={}, direct={})
    terms = [test_file]

# Generated at 2022-06-23 12:14:10.701302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_inst = LookupModule()

    # Check if LookupModule is a subclass of LookupBase.
    assert issubclass(type(lookup_inst), LookupBase)
    # Drop into the object's doc-string.
    assert 'returns a string containing the results' in lookup_inst.run.__doc__



# Generated at 2022-06-23 12:14:19.372633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader

    # Make a fake ansible.parsing.dataloader.DataLoader with a fake
    # config dictionary so we can call the lookup plugin LookupModule's method
    # run.
    loader = DataLoader()
    # Make a fake config dictionary.

# Generated at 2022-06-23 12:14:22.339127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.run(["test_templates/message.txt"], {})

# Generated at 2022-06-23 12:14:31.547438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Example dictionary containing facts about system
    variables = {'hostname': 'north',
                 'username': 'johndoe',
                 'ansible_path': '/etc/ansible'}

    # Execute lookup to get data from file
    ret = LookupModule('').run(["/test_templates/tt.j2"],
                               variables,
                               _ansible_tmpdir='/root')[0]
    assert ret == 'north'

    # Test with search path
    ret = LookupModule('').run(["/test_templates/tt2.j2"],
                               variables,
                               _ansible_tmpdir='/root')[0]
    assert ret == 'north'

# Generated at 2022-06-23 12:14:32.208250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-23 12:14:44.058962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    display = Display()
    assert isinstance(display, Display) # Verify successful creation of display object
    
    # Initialize variables for testing
    terms = ['lookup_test_variable.j2']
    variables = {
        'lookup_test_variable': 'lookup_test_variable'
    }

    # Create class object and execute run method
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **{'convert_data': False, 'template_vars': {}})

    # Verify class object was successfully created
    assert isinstance(lookup_module, LookupModule)
    
    # Verify that result variable is a list object
    assert isinstance(result, list)
    
    # Verify that the first element in the list result is a string object

# Generated at 2022-06-23 12:14:47.519839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fm = LookupModule()
    terms = ['/path/to/template']
    variables = {'variable_start_string': '[%', 'variable_end_string': '%]'}
    result = fm.run(terms, variables)
    assert result == ['tpl /path/to/template']



# Generated at 2022-06-23 12:14:53.433656
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm=LookupModule()
  lm.set_loader(20)
  lm.set_basedir(20)
  lm.run(terms='', variables=10, convert_data='', jinja2_native='', template_vars='', variable_start_string='', variable_end_string='', comment_start_string='', comment_end_string='')

# Generated at 2022-06-23 12:14:56.514196
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import_module = __import__('ansible.plugins.lookup.template', fromlist=['ansible'])
    lookup_module = getattr(import_module, 'LookupModule')()
    lookup_module.set_loader(loader=None)
    assert lookup_module is not None

# Generated at 2022-06-23 12:14:58.480673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor
    obj = LookupModule()
    print(obj)

# Generated at 2022-06-23 12:15:07.511436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    lookup_base_class_mock = Mock()
    lookup_base_class_mock.loader = Mock()
    lookup_base_class_mock.loader._get_file_contents.return_value = (b'{{ x }}', b'...')
    lookup_base_class_mock.loader.path_dwim.return_value = 'some_template.j2'
    lookup_base_class_mock.set_options = Mock()
    lookup_base_class_mock.get_option = Mock()
    lookup_base_class_mock.get_option.return_value = True
    lookup_base_class_mock.get_option.side_effect = ['y']
    lookup_base_class_mock.find_file_in

# Generated at 2022-06-23 12:15:09.267608
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj

# Generated at 2022-06-23 12:15:12.426342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    result = l.run(["some_template.j2"], {})
    assert(result == [])

# Generated at 2022-06-23 12:15:13.801802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 12:15:17.481765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert lu.run(terms=['template.j2'], variables={'_terms': ['template.j2']}, convert_data=False, template_vars={})

# Generated at 2022-06-23 12:15:26.875402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import text_type
    import pytest
    PLUGINPARAMS = {
        "basedir": "somepath",
        "no_log": False,
        "file_encoding": "utf-8",
        "templar": "templar",
        "_original_file": "/path/to/file",
        "template_vars": {},
        "plugin": "plugin",
    }
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    data_loader = DataLoader()
    variable_manager

# Generated at 2022-06-23 12:15:34.027188
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    plugin = LookupModule()

    terms = ['./some_template.j2']
    variables = dict()
    kwargs = dict()
    kwargs['convert_data'] = False
    kwargs['template_vars'] = dict()
    kwargs['jinja2_native'] = False
    kwargs['variable_start_string'] = '{{'
    kwargs['variable_end_string'] = '}}'

    # Act
    result = plugin.run(terms, variables, **kwargs)

    # Assert
    assert result == []



# Generated at 2022-06-23 12:15:35.092106
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert hasattr(LookupModule(), 'run')

# Generated at 2022-06-23 12:15:36.304955
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:15:45.296701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('<test_LookupModule()>')
    lm = LookupModule()
    #test_1 = lm.run(terms='/path/to/test.j2')
    test_1 = lm.run(terms=['../templates/debug.j2'])
    print('<test_1>')
    print(test_1)
    print('</test_1>')
    print('</test_LookupModule()>')

if __name__ == '__main__':
    test_LookupModule()
    print('Done.')

# Generated at 2022-06-23 12:15:57.208684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_object = LookupModule()

    # test_case_1
    # test simple usage of lookup 'template'
    terms = ['tests/test.j2']
    environment_variables = {'ansible_show_content_in_debug': True}
    show_data = True

    ret = lookup_module_object.run(terms, environment_variables)

    assert(ret[0] == 'hello world'
    and show_data == False)

    # test_case_2
    # test usage of lookup 'template' with comment_start_string option
    terms = ['tests/test.j2']
    environment_variables = {'ansible_show_content_in_debug': True, 'ansible_comment_start_string': '\\'}
    show_data = True

    ret = lookup_module

# Generated at 2022-06-23 12:16:00.501688
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Testing with empty terms
    terms = []
    variables = {}
    my_obj = LookupModule()
    result = my_obj.run(terms, variables, **dict())
    assert result == []

# Generated at 2022-06-23 12:16:11.198648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from __main__ import display
    except ImportError:
        import sys
        sys.path.insert(0, '../../')
        from __main__ import display

    path = LookupModule.run(['..name'], {})
    assert path[0] == 'this'
    path = LookupModule.run(['..name'], {'template_vars': {'foo': 'bar'}})
    assert path[0] == 'bar'
    path = LookupModule.run(['..name', '..name'], {})
    assert path[0] == 'this'
    assert path[1] == 'this'
    path = LookupModule.run(['..name'], display)
    assert path[0] == 'this'

# Generated at 2022-06-23 12:16:21.902551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy class for LookupModule, will be replaced by a mock object
    class DummyClassLookupModule(LookupModule):
        def __init__(self, **kwargs):
            self.test_attr = 'test'

    # Create a mock object for the templar class, then replace the
    # run method of LookupModule by a mock object, since we do not
    # want to test this method here
    templar = MockTemplar()
    lookup_module = MockLookupModule(**{'_templar': templar})
    lookup_module.run = Mock(return_value=['test'])
    dummy_class = DummyClassLookupModule(**{'_templar': templar})
    dummy_class.run = lookup_module.run

# Generated at 2022-06-23 12:16:23.362097
# Unit test for constructor of class LookupModule
def test_LookupModule():
  obj = LookupModule()
  assert isinstance(obj, LookupModule)

# Generated at 2022-06-23 12:16:25.568079
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # LookupModule inherits from LookupBase
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 12:16:26.731527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 12:16:37.967003
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    # parameters:
    # terms = ['./some_template.j2']
    # variables = [{'template_mtime': 1557978600.0,
    #               'template_path': './some_template.j2'}]
    # returns: ['./some_template.j2']
    terms = ['./some_template.j2']

    variables = {'template_mtime': 1557978600.0,
                 'template_path': './some_template.j2'}

    lookup = LookupModule()
    res = lookup.run(terms = terms, variables = variables)
    assert res == ['./some_template.j2']




if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 12:16:39.096265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.set_options(direct={}) == None

# Generated at 2022-06-23 12:16:43.276989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.template import Templar
    from ansible import context

    templar = Templar(None, variables={})
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_templar(templar)

    context.CLIARGS = {}
    terms = ['test_template.j2']

    # Create a file for testing
    with open('test_template.j2', 'w') as f:
        f.write("""{{ lookup('env', 'USER') }}\n""")
    with open('test_template.j2', 'r') as f:
        template_data = f.read()
    content_list = []


# Generated at 2022-06-23 12:16:45.023071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:16:56.601722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment
    from ansible.utils.display import Display

    from ansible.plugins.lookup import LookupBase

    from ansible.parsing.vault import VaultLib

    # display.verbosity = 4

    # class LookupModule(LookupBase):
    #    def run(self, terms, variables=None, **kwargs):

    lookup_instance = LookupModule()
    # display.verbosity = 4

    # def test_terns_is_not_list():
    #    terms = 'test_terms'
    #    lookup_

# Generated at 2022-06-23 12:16:57.722642
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert a != None

# Generated at 2022-06-23 12:17:02.034962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._loader._only_if_root is False
    assert lookup_plugin._loader._templar is None
    assert lookup_plugin._loader._basedir is None

# Generated at 2022-06-23 12:17:11.553943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test with valid case
    from ansible.plugins.loader import LookupModule
    from ansible.errors import AnsibleError
    from ansible.template import generate_ansible_template_vars
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types
    from ansible.utils.display import Display
    from ansible.template import AnsibleEnvironment
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.template import USE_JINJA2_NATIVE
    display = Display()
    templar = AnsibleEnvironment(loader=None, variables={'template_path':'/etc/ansible/templates'}).get_template_class()()
    convert_data_p =  False
    lookup_template_

# Generated at 2022-06-23 12:17:13.536143
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:17:24.839191
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # No dummy vars
    no_vars = None

    # Created a dummy variable with empty variable
    dummy_variable = {'key1': ''}

    # Create a dummy variable with non-empty variable
    dummy_var = {'key1': 'value1'}

    # Create a dummy variable and test for a variable accessed by the lookup
    dummy_var_access = {'key1': 'value1', 'key2': 'value2'}

    # Create a dummy variable and test for an option variable set
    dummy_var_option = {'key1': 'value1', 'key2': 'value2'}
    option_var = {'options': {'key1': 'value1', 'key2': 'value2'}}

    # Create a dummy variable and test for an option variable reset

# Generated at 2022-06-23 12:17:29.280228
# Unit test for constructor of class LookupModule
def test_LookupModule():

    variables = dict()
    test_tmpl = LookupModule()
    test_tmpl._templar = None
    test_tmpl._loader = None
    assert isinstance(test_tmpl, LookupBase)
    assert test_tmpl.run(['template_file.j2'], variables) == []

# Generated at 2022-06-23 12:17:36.904852
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test if the constructor of class LookupModule sets up all the parameters correctly
    lookup_module = LookupModule()
    assert lookup_module.basedir_root == None
    assert lookup_module._basedirs == None
    assert lookup_module.plugin_basedir == None
    assert lookup_module.plugin_name == 'lookup_plugin'
    assert lookup_module._templar == None
    assert lookup_module._loader == None

# Generated at 2022-06-23 12:17:47.743103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create lookup object
    lm = LookupModule()
    # Create arg variables
    term_data_1 = "./some_template.j2"
    variable_start_string = '###['
    variable_end_string = ']###'
    convert_data_p = True
    lookup_template_vars = {'some_var': "some_val"}
    jinja2_native = False
    dict_variables = dict()
    dict_kwargs = dict(convert_data = convert_data_p, lookup_template_vars = lookup_template_vars, jinja2_native = jinja2_native, variable_start_string = variable_start_string, variable_end_string = variable_end_string)
    # Create list of terms
    terms = [term_data_1]


# Generated at 2022-06-23 12:17:49.779550
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of class LookupModule
    lookupModule = LookupModule()
    return lookupModule

# Generated at 2022-06-23 12:17:51.278414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup is not None)

# Generated at 2022-06-23 12:18:00.528221
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LoaderMock(object):

        def _get_file_contents(self, path):
            return '{{a}}', False

    class TemplarMock(object):

        def set_temporary_context(self, *args, **kwargs):
            return None

        def template(self, *args, **kwargs):
            return 'abc'

        def copy_with_new_env(self, *args, **kwargs):
            return TemplarMock()

    env = {'a':'b'}
    lookup = LookupModule(loader=LoaderMock(), templar=TemplarMock(), basedir='/')
    result = lookup.run(['./some_template.j2'], variables=env)
    assert result == ['abc'], "result must be ['abc']"

# Generated at 2022-06-23 12:18:03.513391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run([], dict())


# Generated at 2022-06-23 12:18:06.558024
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert lookup_module is not None
    return True

# Generated at 2022-06-23 12:18:16.195174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_loader(None)
    mod.set_options(var_options={}, direct={})
    assert mod._templar == None
    assert mod.get_option('convert_data') == False
    assert mod.get_option('template_vars') == {}
    assert mod.get_option('jinja2_native') == False
    assert mod.get_option('variable_start_string') == u'{{'
    assert mod.get_option('variable_end_string') == u'}}'
    assert mod.get_option('comment_start_string') == None
    assert mod.get_option('comment_end_string') == None

# Generated at 2022-06-23 12:18:21.776864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()

    term_path = './test/test_lookup_templates/simple.j2'
    term = [term_path]
    term_full_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), term_path)

    variables = {}
    x._templar.available_variables = variables
    variables['hostname'] = 'myhost'
    variables['domain'] = 'mydomain'

    # no file in search path
    assert x._loader.path_dwim_relative(None, './test') == './test'
    assert x.find_file_in_search_path(variables, 'templates', term) is None

    # simple.j2 file in search path './test/test_lookup_tem

# Generated at 2022-06-23 12:18:26.125671
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This is a simple test to verify that the class is constructed properly,
    and will fail in case if it won't.

    Use nosetests -s -v --nologcapture
    """
    assert True == isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:18:26.838690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert not l is None

# Generated at 2022-06-23 12:18:39.744964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arguments
    terms = {'test_template.j2', 'test_template2.j2'}
    variables = {
        'ansible_search_path': [
            'test/ansible/plugins/lookup/tests/templates'
        ],
        'hostvars': {
            "host1": {}
        },
        'groupvars': {
            'all': {
                'group_var': 'group_var_value'
            }
        },
        'vars': {
            'var': 'var_value'
        }
    }

    # mocks
    class MockTemplar:
        def __init__(self):
            self.template_data = ''


# Generated at 2022-06-23 12:18:47.842286
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        import jinja2
    except ImportError as e:
        print('SKIPPING check_jinja2_native: jinja2 is not installed (%s)' % to_native(e))
        return 0

    # check USE_JINJA2_NATIVE
    assert USE_JINJA2_NATIVE == jinja2.__version__.startswith('2.9') or USE_JINJA2_NATIVE == jinja2.__version__.startswith('2.10')

    # check class LookupModule
    #
    # test_jinja2_native_is_true:
    # - jinja2_native is True
    # - convert_data should be False
    # - the result is not processed by literal_eval anywhere in Ansible
    lookup_module = LookupModule

# Generated at 2022-06-23 12:18:50.175835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule(loader=None, variables=None)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-23 12:18:50.850329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:19:00.772608
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup vars for tests
    test_env = dict(
        ansible_os_family='Debian',
        ansible_distribution='Debian',
        ansible_distribution_release='jessie',
        ansible_distribution_version='8.6.0',
    )
    test_template_vars = dict(
        foobar='test_foobar',
        baz='test_baz',
    )

    # Test 1
    # Setup basic test and test vars
    test = dict(
        _templar=DummyTemplar(),
        _loader=DummyLoader({'test.j2': to_bytes(u'test template: {{foobar}} and {{baz}}')}),
        _display=Display(),
    )
    lookup = LookupModule(**test)
    terms

# Generated at 2022-06-23 12:19:03.386473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(str(LookupModule) == "<class 'ansible.plugins.lookup.template.LookupModule'>")

# Generated at 2022-06-23 12:19:14.009792
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY2
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var

    if PY2:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.template import Templar as ansibleTemplar
    else:
        from ansible_collections.ansible.general.plugins.module_utils.basic import AnsibleModule
        from ansible_collections.ansible.general.plugins.template import Templar as ansibleTemplar

    UnsafeBytes = AnsibleUnsafeText
    if PY2:
        UnsafeBytes = AnsibleUnicode
        Unsafe

# Generated at 2022-06-23 12:19:19.658392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'variable_start_string':'[[', 'variable_end_string':']]'})
    ret = lookup_plugin.run(['./some_template.j2'], {'user': 'admin'})
    assert ret == [b"\nHello admin!\n"]

# Generated at 2022-06-23 12:19:21.662057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add(LookupModule, 'template')

# Generated at 2022-06-23 12:19:23.162962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tm = LookupModule()
    assert tm is not None

# Generated at 2022-06-23 12:19:31.288704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test instantiation
    lookup = LookupModule()

    # Test with a single term
    result = lookup.run(['foo.j2'], {})
    assert result == ['foo.j2']

    # Test with 2 terms
    result = lookup.run(['foo.j2', 'bar.j2'], {})
    assert result == ['foo.j2', 'bar.j2']

    # Test with 2 terms and a custom variable start string
    result = lookup.run(['foo.j2', 'bar.j2'], {}, variable_start_string='[%')
    assert result == ['foo.j2', 'bar.j2']

# Generated at 2022-06-23 12:19:33.888229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert 'test' == module.run(['test.j2'], { 'test' : 'test' })[0]

# Generated at 2022-06-23 12:19:38.961284
# Unit test for constructor of class LookupModule
def test_LookupModule():

     # a concrete instance of base plugin class 
     lu = LookupModule()
     # assert that the said instance is an instance of the base class LookupModule
     assert isinstance(lu,LookupModule)
     # assert that the said instance is an instance of the base class LookupBase
     assert isinstance(lu,LookupBase)

# Generated at 2022-06-23 12:19:40.145949
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:19:45.308186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    # return value of get_option(keyword) for the keywords 'distribution', 'template_vars', 'string_conversion'
    #    and any other keyword
    mock_config_value = {'template_vars': {},
                         'string_conversion': False}
    # return value of _get_file_contents(filename)
    mock_file_contents = ('Name: {{ name }}\n'
                          'Release: {{ release }}\n'
                          'Codename: {{ codename }}\n'
                          )

    # return values of key word arguments passed to __init__ method
    mock__loader = {'_loader': Mock()}
    mock__templar = {'_templar': Mock()}

    # return value of find_file_in_search_path(vari

# Generated at 2022-06-23 12:19:45.888246
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:19:46.941008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 12:19:49.023305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None, 'The test constructor of class LookupModule failed!'

# Generated at 2022-06-23 12:19:50.417329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)


# Generated at 2022-06-23 12:19:59.632613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_templates = '''
        var1 = {{ var1 }}
        var2 = {{ var2 }}
        var3 = {{ var3 }}
        var4 = {{ var4 }}'''

    test_file1 = '''
        {% set var1 = 1 %}
        {% for var4 in [var3] %}
        {% endfor %}'''
    test_file2 = '''
        {% set var2 = 2 %}'''


# Generated at 2022-06-23 12:20:05.895807
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class env(object):
      def __init__(self):
          self.is_template = True
          self.template_vars = {'a': 'testvar'}
          self.environment_class = AnsibleEnvironment

    class templar(object):
        def __init__(self):
            self.environment = env()

    lookup = LookupModule(templar())

    assert lookup._templar.environment.is_template

# Generated at 2022-06-23 12:20:13.064861
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()

    from ansible.template import Templar

    def _create_templar():
        class fake_loader():
            def __init__(self):
                self.searchpath = []

            def _get_file_contents(self, file):
                return b'Hello World!', None

        return Templar(fake_loader(), variables={})

    lm._create_templar = _create_templar
    ret = lm.run(['template_file'], {})
    assert ret[0] == 'Hello World!'

