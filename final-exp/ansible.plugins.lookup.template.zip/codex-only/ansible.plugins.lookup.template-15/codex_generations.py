

# Generated at 2022-06-23 12:10:15.330775
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    templar = AnsibleEnvironment(loader=None)

    data = to_bytes('{{ foo }} and {{ bar }}', errors='surrogate_or_strict')

    assert templar.template(data, preserve_trailing_newlines=True,
                            convert_data=True, escape_backslashes=False,
                            available_variables={
                                'foo': to_bytes('one', errors='surrogate_or_strict'),
                                'bar': to_bytes('two', errors='surrogate_or_strict')}) == to_bytes("one and two", errors='surrogate_or_strict')

# Generated at 2022-06-23 12:10:17.332388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['myfile']

    variables = {}

    kwargs = {}

    values = lookup_module.run(terms, variables, **kwargs)

    assert values is None

# Generated at 2022-06-23 12:10:27.588423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    # pylint: disable=no-self-use
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module.set_options(var_options={}, direct={})
    ret = lookup_module.run(
        terms=[],
        variables={},
        convert_data=True,
        variable_start_string='{{',
        variable_end_string='}}',
        jinja2_native=True,
        template_vars={},
        comment_start_string='{{',
        comment_end_string='}}',
    )
    assert ret == []

# Generated at 2022-06-23 12:10:28.443575
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:10:34.402390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    class MockVars(object):

        def get(self, name, default):
            if name == 'ansible_search_path':
                return [os.path.dirname(__file__)]
            return default

    class MockLoader(object):

        def _get_file_contents(self, filename):
            return 'Hello {{ foo }}', False

    lookup._loader = MockLoader()
    lookup._templar = MockVars()
    # no exception if the template exists
    lookup.run(['templates.j2'], MockVars())



# Generated at 2022-06-23 12:10:44.465220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _mock_loader = MagicMock()
    _loader_get_file_contents_side_effect = [
        [to_bytes(u"{{ lookup('dummy') }}\n"), True],
        [to_bytes(u"{{ foo }}\n"), False],
    ]
    _mock_loader._get_file_contents = Mock(side_effect=_loader_get_file_contents_side_effect)

    _mock_finder = MagicMock()
    _finder_find_file_in_search_path_side_effect = [
        './test',
        './test2',
        None,
        './test3',
    ]

# Generated at 2022-06-23 12:10:56.668174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a dummy lookup that returns the terms that were passed in.
    class DummyLookup(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    # Create a dummy loader that returns a fixed set of content.
    class DummyLoader(object):
        @staticmethod
        def _get_file_contents(path):
            content = {
                "/etc/ansible/roles/dummy/templates/a.j2": "{{ testvar }}\n",
                "/etc/ansible/roles/dummy/templates/b.j2": "{{ testvar }}\n",
            }
            return content[path], False

    # Create a dummy variables.

# Generated at 2022-06-23 12:10:58.899774
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:11:00.085974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-23 12:11:01.379104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule([])
    assert obj != None

# Generated at 2022-06-23 12:11:03.146916
# Unit test for constructor of class LookupModule
def test_LookupModule():

  # Test for valid instantiation of class LookupModule
  lookup_plugin = LookupModule()
  assert lookup_plugin

# Generated at 2022-06-23 12:11:12.879976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Values used for run
    terms = ['some_template.j2']
    variables = {}
    kwargs = {}
    # Values used for LookupBase._templar
    test_loader = MockLoader()
    test_templar = Templar(
        loader=test_loader,
        variables={},
    )
    # Mock for self.set_options
    LookupBase.set_options = Mock(
        return_value=None,
    )
    # Mock for self.get_option
    LookupBase.get_option = Mock(
        side_effect=[False, {}, False, '{{', '}}', None, None],
        return_value=None,
    )
    # Mock for self.find_file_in_search_path
    LookupBase.find_file_in_search_path = Mock

# Generated at 2022-06-23 12:11:14.676974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # Test idempotent constructor
    assert lookup_module is not None
    assert lookup_module.run is not None

# Generated at 2022-06-23 12:11:25.111156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pickle
    l = LookupModule()
    options = {'extensions': ['jinja2.ext.do', 'jinja2.ext.loopcontrols'],
               'tags': ['foo', 'bar', 'baz'],
               'trim_blocks': True,
               'lstrip_blocks': True,
               'newline_sequence': '\r\n',
               'keep_trailing_newline': False,
               'undefined': 'strict'}
    l._templar = AnsibleEnvironment(loader=None).from_yaml('''---
        foo: 'bar'
        baz: 'asdf'
        ''', '<string>', options=options, shared=False )
    print(l._templar)

# Generated at 2022-06-23 12:11:32.594402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    module = LookupModule()
    fake_loader = FakeLoader({'test': 'some-data', 'test2': 'another-data'})
    module._loader = fake_loader

    # a search path with no templates subdir
    path = [os.path.join(os.getcwd(), 'library')]
    result = list(module.run(['template1', 'template2'], dict(ansible_search_path=path), {}))

    assert result == []

    # a search path with a templates subdir
    path = [os.path.join(os.getcwd(), 'templates')]
    result = list(module.run(['template1', 'template2'], dict(ansible_search_path=path), {}))

    assert result == ['some-data', 'another-data']



# Generated at 2022-06-23 12:11:33.684680
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:11:36.320057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    try:
        from __pypy__ import jit
        jit.promote(test_LookupModule)
    except:
        pass

# Generated at 2022-06-23 12:11:37.280234
# Unit test for constructor of class LookupModule
def test_LookupModule():
   print("testing LookupModule")

# Generated at 2022-06-23 12:11:42.752255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = dict()
    lookup = LookupModule()
    templates = ['name.j2','name1.j2']
    lookup.set_options(var_options=variables)
    lookup.set_environment(environment='production')
    data = lookup.run(templates, variables)
    assert data is not None

# Generated at 2022-06-23 12:11:51.974969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import constants as C
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    import os
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.inventory = Inventory(host_list=[])
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.variable_manager.set_inventory(self.inventory)
            self.proxy_handler = ProxyHandler(self.inventory, self.variable_manager)
            self

# Generated at 2022-06-23 12:11:54.303201
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module
    assert lookup_module._templar

# Generated at 2022-06-23 12:12:03.368770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None, **kwargs)
    lookup_module = LookupModule()
    #ret = lookup_module.run(terms=["/root/ansible_test/testfiles/test_template.j2"], variables=None, **kwargs)
    ret = lookup_module.run(terms=["/root/ansible_test/testfiles/test_template.j2"], variables=None)
    assert ret == [u'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST']
    assert ret[0] == u'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'

# Generated at 2022-06-23 12:12:07.148975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    result = lookup_module.run(["/etc/resolv.conf"], {})
    assert result == [to_bytes("nameserver 8.8.8.8\nnameserver 8.8.4.4\n")], \
        "result was: %s" % result

# Generated at 2022-06-23 12:12:12.273913
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing with empty terms and no variables (defaults)
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert l._loader is not None
    assert l._templar is not None
    assert l._shared_loader_obj is not None
    assert l._templar._available_variables is not None

# Generated at 2022-06-23 12:12:23.311197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyVars(object):
        def __init__(self):
            self._data = dict()

        def __getitem__(self, key):
            return self._data.get(key)

        def __setitem__(self, key, value):
            self._data[key] = value

    templar = object()
    display = Display()
    ilookup = LookupModule(templar, display)

    # Test 1
    _terms = ["./some_template.j2"]
    _options = dict(template_vars={})
    _loader = object()
    _var_templar = object()
    _environment = object()
    _templar = object()
    _finder = object()
    ilookup._templar = _templar

# Generated at 2022-06-23 12:12:24.123484
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:12:25.250967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj


# Generated at 2022-06-23 12:12:33.536708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Call run method of class LookupModule with valid arguments.
    # Return value should be a list.
    terms = ['test.j2']
    variables = {'some_var':'some_val'}
    test_lookup = LookupModule()
    ret = test_lookup.run(terms, variables)
    assert isinstance(ret, list)
    # Check for values in returned list
    assert ret[0] == 'This is a test of the emergency broadcast system.'


# Generated at 2022-06-23 12:12:45.103764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test for method run defined inside class LookupModule
    lookup_module = LookupModule()
    lookup_module._loader = DummyLoader()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar.environment.ansible_search_path = ['some_playbooks_dir']
    lookup_module._templar.template = lambda x, preserve_trailing_newlines=True, convert_data=False, escape_backslashes=False: x
    lookup_module.basedir = 'some_playbooks_dir'

    # Expected success testcase

# Generated at 2022-06-23 12:12:46.426491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #assert isinstance(LookupModule(), LookupBase)
    assert True

# Generated at 2022-06-23 12:12:57.817399
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # this is where the run method is defined
    dir_path = os.path.dirname(os.path.realpath(__file__))
    module_path = os.path.join(dir_path, '..', '..', 'ansible', 'plugins', 'lookup', 'template')
    module_path_name = 'ansible.plugins.lookup.template'
    module_name = 'ansible.plugins.lookup.template.LookupModule'
    c_lookup = lookup_loader.get(module_name, class_only=True)
    lm = c_lookup()

    # retrieving the contents of the file
    dir_path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-23 12:13:02.175133
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('TESTING LOOKUP MODULE')
    lookup = LookupModule()
    
    terms = ['echo' , 'echo1', 'echo2']
    variables = 'hello'
    
    print(lookup.run(terms=terms, variables=variables))

# Generated at 2022-06-23 12:13:03.250200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tester = LookupModule()
    assert tester

# Generated at 2022-06-23 12:13:11.024979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    import os
    import sys
    import six
    import codecs
    file_name = os.path.realpath(__file__).replace(".pyc", ".py")
    m = LookupModule()
    if six.PY3:
        open_func = open
    else:
        open_func = codecs.open
    with open_func(file_name, encoding="utf-8") as f:
        code = f.read()
    assert code == m.run([file_name], dict())[0]

# Generated at 2022-06-23 12:13:23.066328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing fake variables
    variables = {
        u'inventory_hostname': u'host1',
        u'group_names': [u'ungrouped'],
        u'play_hosts': [u'host1'],
    }
    templar = DictVarsTemplate()

    # Initializing fake terms
    terms = [
        u'test_lookup_j2.j2'
    ]

    # Initializing fake display.debug
    def debug(msg):
        print(msg)

    display.debug = debug

    # Initializing fake os.path.join
    join = os.path.join
    orig_path_join = os.path.join

    def patched_path_join(*args, **kwargs):
        args = list(args)
        args = map(to_bytes, args)

# Generated at 2022-06-23 12:13:34.200289
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    zzz = dict()

    zzz['ANSIBLE_JINJA2_NATIVE'] = True
    zzz['ANSIBLE_CONVERT_DATA'] = False
    zzz['ANSIBLE_JINJA2_NATIVE'] = False

    # Do not fail when no templates are passed
    lookup_module = LookupModule()
    assert lookup_module.run(terms=[], variables=zzz) == []

    # One template passed
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['templates/hello.j2'], variables=zzz) == [
        'Hello world!\n'
    ]

    # One template passed (strict mode)
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:13:35.152726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:13:44.666142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.path import unfrackpath
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    import os

    host_vars_file = unfrackpath("/tmp/host_vars")
    group_vars_file = unfrackpath("/tmp/group_vars")
    inventory_file = unfrackpath("/tmp/inventory")

# Generated at 2022-06-23 12:13:51.698942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar = DummyTemplar()
    loader = DummyLoader()
    lookup = LookupModule(loader=loader, templar=templar)
    search_paths = ('/path/to/some/file')
    ret = lookup.run(terms=['/some/file'], variables={'ansible_search_path': search_paths, 'template_vars': {'key': 'value'}})
    assert ret == [b'somevarskeyvaluemorevars']



# Generated at 2022-06-23 12:13:59.357781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We can't use the template module here because the template module
    # uses this lookup, so we'd get into an import loop between the
    # template and lookup plugins
    #
    # So we mock it here and hard code a bunch of values provided by
    # the template module
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None
    lookup._templar = None
    lookup._loader = None
    lookup._options = {}

    # We need the following values to be defined in the options dictionary
    # before we can run the lookup

# Generated at 2022-06-23 12:14:10.489503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global templar
    templar = None
    global display
    display = Display()

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['test/test_lookup_plugins/inventory/hosts'])

# Generated at 2022-06-23 12:14:12.230612
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor without parameters
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:14:16.401335
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_self = Mock()
    mock_self._loader = Mock()
    mock_self._loader.path_dwim = Mock(return_value = 'path_dwim')
    mock_self._templar = Mock()

    lm = LookupModule()
    lm.set_options = Mock()
    lm.get_option = Mock(return_value = False)
    lm.find_file_in_search_path = Mock(return_value = 'search_path')

    terms = ['term_1']
    variables = 'variables'

    assert lm.run(terms, variables) == ['search_path']


# Generated at 2022-06-23 12:14:28.920713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for function run of class LookupModule"""

    # #Set up some mock data and a mock templar to run the tests
    options = { 'convert_data': True,
                'template_vars': {},
                'jinja2_native': False,
                'variable_start_string': '{{',
                'variable_end_string': '}}',
                'comment_start_string': '{#',
                'comment_end_string': '#}'}

    templar_mock = None
    loader_mock = None
    display_mock = None
    lookup_base_mock = None


# Generated at 2022-06-23 12:14:34.769279
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate class LookupModule with an empty argument
    module = LookupModule()
    # method run() returns a list
    assert isinstance(module.run(terms=["ansible.cfg"], variables={}), list)
    # method run() returns a list
    assert isinstance(module.run(terms=None, variables={}), list)
    # method run() returns a list
    assert isinstance(module.run(terms=[], variables={}), list)

# Generated at 2022-06-23 12:14:38.808960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    with pytest.raises(AnsibleError, match='the template file some_template.j2 could not be found for the lookup'):
        lookup.run(['./some_template.j2'], {})

# Generated at 2022-06-23 12:14:41.709279
# Unit test for constructor of class LookupModule
def test_LookupModule():

    x = LookupModule()
    assert x._templar == None
    assert x._loader == None
    assert x._options == None
    assert x._display == None

# Generated at 2022-06-23 12:14:47.882758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with bad term
    terms = [ "bad_file.j2" ]
    variables = {}
    result = lookup_module.run(terms, variables)
    assert result == []

    # Test with good term
    terms = [ "just_a_file.j2" ]
    variables = { "ansible_search_path": [ os.path.join(os.path.dirname(__file__), "testdata") ] }
    result = lookup_module.run(terms, variables)
    assert result == [ "just a line" ]

# Generated at 2022-06-23 12:14:59.263024
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock class for vars
    class Vars:
        def __init__(self):
            self.ansible_managed = "Ansible managed"
            self.template_path = os.path.abspath("test_LookupModule_run.j2")
            self.template_mtime = "mtime"
            self.template_host = "host"
            self.template_uid = "uid"
            self.template_user = "user"
            self.template_run_date = "run_date"
            self.template_path_relative = "path_relative"

    # Mock class for templar
    class Templar:
        def copy_with_new_env(self, environment_class):
            return self


# Generated at 2022-06-23 12:15:01.823887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing creation of an instance of the LookupModule class")
    lookupModule = LookupModule()
    print("An instance of the LookupModule class is created")


# Generated at 2022-06-23 12:15:09.581155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test using template_vars
    test_lookup_module = LookupModule()
    test_template_vars = {
        'ntpserver': 'my-ntpserver',
        'key': 'value'
    }
    ret = test_lookup_module.run(
        ['./tests/files/template_vars1.j2'],
        variables={},
        lookup_template_vars=test_template_vars
    )
    assert ret == ["server {{ ntpserver }} iburst"]

    # test using jinja2_native
    test_lookup_module = LookupModule()

# Generated at 2022-06-23 12:15:20.137652
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_native
    from ansible.template import Templar

    # We must do this manually since we don't have a valid self for invoke
    display.verbosity = 3
    templar = Templar(loader=None, variables=None)
    lookup_module = LookupModule()

    lookup_module.set_loader(None)
    lookup_module.set_templar(templar)

    jinja2_native = False
    convert_data = True
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_end_string = '#}'

    # Jinja2 native is off, convert_data must be true

# Generated at 2022-06-23 12:15:26.253310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for method run of class LookupModule"""

    # Test 1

# Generated at 2022-06-23 12:15:27.769969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of LookupModule."""
    pass

# Generated at 2022-06-23 12:15:35.828927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First we create an instance of LookupModule class
    lookup_plugin = LookupModule()
    lookup_plugin._templar = None
    lookup_plugin._loader = None
    loop_item = "../../../../../../../etc/hosts"
    lookup_plugin._loader = None
    # This is a incorrect template path which shows that
    # the method run will not find the file and causes Exception
    terms_path = 'some_template.j2'
    # Perform lookup
    results = {}
    try:
        results = lookup_plugin.run([terms_path], {}, convert_data=True)
    except Exception as e:
        results['msg'] = str(e)

# Generated at 2022-06-23 12:15:47.312469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Module must be imported inside this function to set self.assertTrue and self.assertEqual
    # to the correct implementation (unittest.TestCase.assertTrue and unittest.TestCase.assertEqual)

    import unittest
    import ansible.plugins.loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-23 12:15:59.896668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm._templar.environment.undefined == 'strict'
    lm.set_options(dict(variable_start_string='[%', variable_end_string='%]'))
    assert lm._templar.environment.variable_start_string == '[%'
    assert lm._templar.environment.variable_end_string == '%]'
    lm.set_options(dict(comment_start_string='[#', comment_end_string='#]'))
    assert lm._templar.environment.comment_start_string == '[#'
    assert lm._templar.environment.comment_end_string == '#]'
    # ToDo: I have no idea how to test this
    #lm._templar.environment.searchpath



# Generated at 2022-06-23 12:16:08.215073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_params = dict(
        _templar = '',
        basedir = '',
        runner_supported_filters = '',
        loader = '',
        environment = '',
        __name__ = '',
        )
    lookup_obj = LookupModule(**lookup_params)
    # test whether the object is of class LookupModule
    assert isinstance(lookup_obj, LookupModule)
    # test whether the object is of class LookupBase
    assert isinstance(lookup_obj, LookupBase)


# Generated at 2022-06-23 12:16:20.019034
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # initialize an instance of the LookupModule class
    lm = LookupModule()

    # call the set_options method with options set in the main function
    options = dict()
    options['variable_start_string'] = '{{'
    options['variable_end_string'] = '}}'
    options['comment_start_string'] = '{#'
    options['comment_end_string'] = '#}'
    options['extensions'] = ['jinja2.ext.do']
    options['template_vars'] = dict(a_var='value')
    options['jinja2_native'] = False
    options['convert_data'] = True
    options['_ansible_verbosity'] = 4
    options['_ansible_syslog_facility'] = 'LOG_USER'

# Generated at 2022-06-23 12:16:29.670347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil
    import json

    def write_config_file(fp, data):
        with open(fp, 'w') as config_file:
            json.dump(data, config_file, indent=4)

    test_dir = tempfile.mkdtemp()
    template_dir = os.path.join(test_dir, 'templates')
    os.makedirs(template_dir)

    template_name = 'lookup_template'
    template_file = os.path.join(template_dir, template_name)
    with open(template_file, 'w') as template_file:
        template_file.write('{{ lookup_var }}')

    config_dir = os.path.join(test_dir, 'config')

# Generated at 2022-06-23 12:16:32.661770
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check whether the constructor creates an object of class LookupModule
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:16:42.516851
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestLoader(object):

        def __init__(self):
            self.path = [os.path.dirname(__file__)]

        def _get_file_contents(self, filename):
            data = open(filename).read()
            return to_bytes(data, errors='surrogate_or_strict'), False

    class TestTemplar(object):

        def __init__(self, *args, **kwargs):
            self.environment_class = kwargs.get('environment_class', AnsibleEnvironment)

        def copy_with_new_env(self, environment_class=AnsibleEnvironment):
            return self

        def copy(self):
            return TestTemplar()

        def set_temporary_context(self, **kwargs):
            return DummyContext()


# Generated at 2022-06-23 12:16:43.794251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:16:54.953197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given an instance of this class
    module = LookupModule()

    # And a file test_template.j2
    terms = [u'test_template.j2']

    # When the run method is called with a template to be created
    variables = dict(
        foo=u'foo',
        bar=u'bar',
        baz=u'baz',
        template_name=u'test_template.j2',
        template_path=u'./test_template.j2',
        template_mtime=u'2016-10-21 00:00:00',
        template_uid=u'0',
        template_gid=u'0'
    )

    module._templar.available_variables = variables
    results = module.run(terms, variables, convert_data=True)

    #

# Generated at 2022-06-23 12:17:02.957400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    lookup_module = LookupModule()

    # create an instance of ansible.template.AnsibleEnvironment and pass it to set_temporary_context
    # of the _templar attribute of lookup_module
    environment = AnsibleEnvironment()
    lookup_module._templar.set_temporary_context(environment=environment)

    # create a dictionary definition for the AnsibleOptionsClass object passed to the __init__
    # of the LookupModule class
    ansible_opts = dict()

    # create an instance of AnsibleOptionsClass and add it to the ansible_opts dictionary
    from ansible.config.manager import AnsibleOptions
    ansible_opts['options'] = AnsibleOptions()

    # create an instance of AnsibleVaultEncryptedUnicode and add it to the ans

# Generated at 2022-06-23 12:17:05.359014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Minimal values to avoid failures
    module = LookupModule(None,  None, None)
    assert module



# Generated at 2022-06-23 12:17:13.317822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_lookup_file_in_search_path(self, variables, subdir, term):
        return 'lookupfile'

    lookup_mock = LookupModule()
    lookup_mock.find_file_in_search_path = test_lookup_file_in_search_path

    lookup_mock.set_options({'template_vars': {'foo': 'bar'},
                             'convert_data': False,
                             'jinja2_native': False})

    lookup_mock._loader = Mock()
    lookup_mock._loader._get_file_contents = Mock(return_value=('baz: {{ foo }}', False))
    lookup_mock.set_loader(lookup_mock._loader)

    templar_mock = Mock()
    templar_

# Generated at 2022-06-23 12:17:14.811103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests if constructor works without parameters
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:17:16.709622
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:17:17.657772
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:17:28.888781
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as plugin_loader
    import ansible.template as template
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import pytest
    from textwrap import dedent

    test_dir = pytest.helpers.test_dir
    template_dir = os.path.dirname(template.__file__)

# Generated at 2022-06-23 12:17:34.043424
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with deprecated convert_data option
    assert LookupModule().run(['./some_template.j2'], {}, convert_data=True) == ["{}"]

    # Test with jinja2_native option
    assert LookupModule().run(['./some_template.j2'], {}, jinja2_native=True) == ["{}"]

    # Test with jinja2_native option and deprecated convert_data option
    assert LookupModule().run(['./some_template.j2'], {}, convert_data=True, jinja2_native=True) == ["{}"]

# Generated at 2022-06-23 12:17:43.262301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import BytesIO
    from ansible.parsing import DataLoader

    loader = DataLoader()
    def find_file_in_search_path(self, variables, path, file):
        return './template.j2'
    LookupModule.find_file_in_search_path = find_file_in_search_path

    term = 'template.j2'
    options = {'_ansible_lookup_file_input': 'yes'}
    templar = DictVarsLookup()
    templar.set_available_variables(dict(a=1,b=2))
    lookup = LookupModule(loader=loader, templar=templar)
    lookup.set_

# Generated at 2022-06-23 12:17:54.992945
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class A:
        def __init__(self):
            self.options = {
                '_terms': [],
                'variable_start_string': '',
                'variable_end_string': '',
                'comment_start_string': '',
                'comment_end_string': '',
                'jinja2_native': False
            }
        def get_option(self, x):
            return self.options[x]
        def set_options(self, **kwargs):
            self.options.update(**kwargs)
        def find_file_in_search_path(self, variables, subdir, term):
            if term == './some_template.j2':
                return '/some_template.j2'
            else:
                return None

# Generated at 2022-06-23 12:17:56.415378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None, 'constructor of LookupModule failed'

# Generated at 2022-06-23 12:18:02.014323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=dict(a=1))
    lookup_mod = LookupModule()
    lookup_mod._loader = loader
    lookup_mod._templar = templar

    assert lookup_mod.run(["./some_template.j2"], dict(ansible_search_path=["/path1/", "/path2/"])) == []

# Generated at 2022-06-23 12:18:04.133980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    for param in ['lookup_template_vars', 'jinja2_native', 'variable_start_string', 'variable_end_string',
                  'comment_start_string', 'comment_end_string']:
        assert my_lookup.get_option(param) is None

# Generated at 2022-06-23 12:18:06.068287
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-23 12:18:07.924798
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:18:17.626063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # class is not directly instantiable
    # lm = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    lookup_config = {}
    terms = ["", "../../../../../../../etc/passwd", "./../../../../../../../etc/passwd", "./../../../../../../../etc/passwd", 
             "./blah/../../../../../../../etc/passwd", "./blah/./../../../../../../../etc/passwd"]
    ret = lm.run(terms, lookup_config)
    print('ret: %s' % ret)
# test_LookupModule_run()

# Generated at 2022-06-23 12:18:18.661964
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 12:18:21.659936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    test_obj = LookupModule()
    assert test_obj.run() == []

# Generated at 2022-06-23 12:18:30.570299
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    _LookupBase = LookupBase()
    _LookupBase.set_options(var_options=dict(), direct=dict())
    _LookupBase.get_option = lambda a: None
    _LookupBase.find_file_in_search_path = lambda a, b, c: 'test_file'

    test_data = 'Hello, {{ lookup("template", "my_template.j2") }}'
    test_data_result = 'Hello, world'
    test_result = 'test_template_file_content'

    _LookupBase._loader = _loader = object()
    _loader._get_file_contents = lambda x: (test_data.encode('utf-8'), True)


# Generated at 2022-06-23 12:18:37.369207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # list of templates to test
    templates = ["./some_template.j2"]
    # list of vars
    variables = {}
    # options passed to the lookup
    options = {'variable_start_string': '{{', 'variable_end_string': '}}'}
    # test result
    assert LookupModule().run(templates, variables, **options) == "{{foobar}}"

# Generated at 2022-06-23 12:18:45.926380
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup mock object for class LookupBase
    class LookupBase_mock():

        def set_options(self, var_options, direct):
            pass

        def get_option(self, name):
            pass

        def find_file_in_search_path(self, variables, dir_name, file_name):
            pass

    # Setup mock object for class DataLoader
    class DataLoader_mock():

        def _get_file_contents(self, file_name):
            pass

    # Setup mock object for class Template
    class Template_mock():

        def copy_with_new_env(self, environment_class):
            pass

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string):
            pass


# Generated at 2022-06-23 12:18:47.902572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert l

# Generated at 2022-06-23 12:18:58.941943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # input variables
    templar = Templar(loader=DataLoader(), variables=VariableManager())
    terms = ['../../lib/ansible/modules/system/setup.py']
    variables = {'ansible_ssh_pass': 'pass', 'ansible_python_interpreter': '/usr/bin/python', 'ansible_user': 'vagrant'}

# Generated at 2022-06-23 12:19:11.053635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-23 12:19:12.624230
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x

# Generated at 2022-06-23 12:19:17.731973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['template1.j2', 'template2.j2']
    variables = {'foo': 'bar'}
    
    lookupModule = LookupModule()
    assert lookupModule.run(terms=terms, variables=variables) is not None

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:19:19.172127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()



# Generated at 2022-06-23 12:19:20.837218
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance._templar is not None

# Generated at 2022-06-23 12:19:22.742814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:19:32.473133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Retrieve contents of file after templating with Jinja2'''

    # instantiate class
    lookup = LookupModule()

    # add options
    options = {
        'convert_data': False,
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'jinja2_native': False,
        'template_vars': { 'hostname': 'localhost' },
        'comment_start_string': '/*',
        'comment_end_string': '*/'
    }
    lookup._options = options

    # terms parameter
    terms = [
        './dummy1.j2',
        './dummy2.j2',
    ]

    # variables parameter

# Generated at 2022-06-23 12:19:43.592759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _loader_mock = mock.MagicMock()
    _loader_mock.get_basedir.return_value = "/opt/ansible"
    _loader_mock.path_dwim_relative.return_value = "/opt/ansible/my_template.j2"
    _loader_mock.get_real_file.return_value = "/opt/ansible/templates/my_template.j2"
    _loader_mock._get_file_contents.return_value = (b'{ "key": "{{fake_variable_from_lookup}}" }', True)
    _mock_templar = mock.MagicMock()
    _mock_templar.template.return_value = "{ 'key': 'fake value' }"

# Generated at 2022-06-23 12:19:49.323841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run(terms = [], variables = {}, **{'convert_data': 'no', 'comment_end_string': ']#',
    'comment_start_string': '[#', 'jinja2_native': 'no',
    'template_vars': {}, 'variable_end_string': ']',
    'variable_start_string': '['})
    assert type(result) is list

# Generated at 2022-06-23 12:19:58.693326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    test_lookup.set_options(var_options=None, direct={"convert_data":True,"jinja2_native":False,"template_vars":{},"comment_start_string":'#',"comment_end_string":''})
    test_lookup.set_loader(None)
    test_terms = ""
    test_ret_run = test_lookup.run(test_terms, {})
    assert test_ret_run == []
    test_terms = "./plugins/lookup/test/test_jinja2_templates/output_format_yaml.j2"
    test_ret_run = test_lookup.run(test_terms, {})
    assert test_ret_run == [{}]

# Generated at 2022-06-23 12:19:59.309824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-23 12:20:09.132533
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile
    from ansible.utils.display import Display
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    display = Display()
    loader = DataLoader()
    vars_manager = VariableManager()
    templar = Templar(loader=loader, variables=vars_manager)

    lookup = LookupModule(loader=loader, templar=templar, display=display)

    # Make a temporary directory, and add it to the search path
    # This is the default search path
    # FIXME: use some other directory, and don't use the running directory
    # FIXME: use SearchPath object
    cwd = os.path.dirname(os.path.realpath(__file__))