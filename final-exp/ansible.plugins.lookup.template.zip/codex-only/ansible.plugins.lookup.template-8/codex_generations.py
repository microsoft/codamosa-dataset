

# Generated at 2022-06-23 12:10:16.853751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils import context_objects as co
    from ansible.template import Templar

    templar = Templar(co.LookupContext())

    lookup = LookupModule()
    lookup._templar = templar

    variable_start_string = '{{'
    variable_end_string = '}}'

    lookup._templar.environment.variable_start_string = variable_start_string
    lookup._templar.environment.variable_end_string = variable_end_string

    comment_start_string = '{#'
    comment_end_string = '#}'

    lookup._templar.environment.comment_start_string = comment_start_string
    lookup._templar.environment.comment_end_string = comment_end_string


# Generated at 2022-06-23 12:10:18.642124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert isinstance(mod._templar, AnsibleEnvironment)

# Generated at 2022-06-23 12:10:19.079003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:10:28.980260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testlookup = LookupModule()
    display.verbosity = 4
    assert testlookup.run(terms='foo', variables={}, **[]) == []
    assert testlookup.run(terms='foo', variables={}, **{'convert_data': True}) == []
    assert testlookup.run(terms='foo', variables={}, **{'variable_start_string': '<<'}) == []
    assert testlookup.run(terms='foo', variables={}, **{'variable_end_string': '>>'}) == []
    assert testlookup.run(terms='foo', variables={}, **{'comment_start_string': '##'}) == []
    assert testlookup.run(terms='foo', variables={}, **{'comment_end_string': '##'}) == []

# Generated at 2022-06-23 12:10:31.315639
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    assert lookup._terms is None
    assert lookup._loader is not None
    assert lookup._templar is not None
    assert lookup._display is not None

# Generated at 2022-06-23 12:10:33.290737
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:10:43.804228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list=[])
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("template", "templates/file.j2") }}')))
         ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 12:10:55.996177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup = LookupModule()
    mock_templar = MagicMock()
    lookup._templar = mock_templar
    default_path = "/usr/share/ansible"
    search_path = ["/etc/ansible", default_path]
    variables = {'template_dir' : '/etc/ansible'}
    terms = ['main.yml']

    # Act
    lookup.run(terms, variables, search_path=search_path, variable_start_string='{', variable_end_string='}')

    # Assert
    mock_templar.template.assert_called_once()
    call_args = mock_templar.template.call_args
    assert call_args[1]['variable_start_string'] == '{'

# Generated at 2022-06-23 12:11:02.871582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Starting test of method run of class LookupModule")
    term = './some_template.j2'
    variables = {}

# Generated at 2022-06-23 12:11:12.640723
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_terms = [{'test_string': 'This is a test template.'}]

    # test with empty searchpaths
    test_variables = {'ansible_search_path': None}
    test_jinja2_native = False
    test_convert_data = True
    test_lookup_template_vars = {'test_lookup_template_vars': 'test'}

    l = LookupModule()
    l.set_options(var_options=test_variables, direct=None)

    env = AnsibleEnvironment(loader=None)
    templar = l._templar.copy_with_new_env(environment=env)
    test_result = []

# Generated at 2022-06-23 12:11:13.490996
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None


# Generated at 2022-06-23 12:11:15.261931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_display = Display()
    global_display.verbosity = 2
    lm = LookupModule(global_display)
    return lm

# Generated at 2022-06-23 12:11:16.677026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:11:27.619986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = __import__('ansible.plugins.lookup.template')
    p = getattr(m, 'LookupModule')
    pp = p()
    terms = ['/etc/ansible/ansible.cfg']

# Generated at 2022-06-23 12:11:28.788555
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:11:34.540831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # The test below is essentially a copy of the test in ansible/test/unit/template.py
    # We have to replicate it here because template.py is also a lookup plugin and we
    # must be able to call each function in isolation.
    # The reason we have to test this is because the test in template.py uses the templar
    # that the tests create to render a template and yet the templar it uses is not the
    # same as the lookup templar it creates because it is overwritten later by the
    # template.py test. This is a limitation of the test architecture of the template
    # module.

    loader = Data

# Generated at 2022-06-23 12:11:35.977306
# Unit test for constructor of class LookupModule
def test_LookupModule():
    templar = LookupModule()
    assert templar.name == 'template'

# Generated at 2022-06-23 12:11:36.457128
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:11:39.278588
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module,LookupBase), "constructor of class LookupModule failed"

# Generated at 2022-06-23 12:11:50.218750
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockVars(dict):
        def get(self, key, default=None):
            """Get the value for key if it exists, else default"""
            return super(MockVars, self).get(key, default)

    class MockLoader(object):
        def __init__(self):
            self.vars = MockVars()

        def _get_file_contents(self, lookupfile):
            """Get the value for lookupfile if it exists, else default"""
            return self.vars.get(lookupfile, (None, None))

    class MockRunner(object):
        def __init__(self):
            self.loader = MockLoader()

        def get_option(self, term):
            """Get the value for term if it exists, else default"""

# Generated at 2022-06-23 12:11:51.436098
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None

# Generated at 2022-06-23 12:12:02.155432
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # From php_template.py
    #  Copyright: (c) 2017, Ansible Project
    #  GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

    import copy
    import errno
    import os
    import shutil
    import tempfile
    import textwrap

    from ansible import context
    from ansible.errors import AnsibleAssertionError, AnsibleError
    from ansible.plugins.loader import lookup_loader

    class TestLookupModule(object):
        ''' Test lookup module '''


# Generated at 2022-06-23 12:12:03.259467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None
    return lookup_module

# Generated at 2022-06-23 12:12:11.890759
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import sys
    import os
    import pytest

    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.host import Host
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.errors import AnsibleError
    from units.mock.loader import DictDataLoader

    original_stdin = sys.stdin
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    sys.stdin = open(os.devnull, 'r')
    sys.stdout = open(os.devnull, 'w')

# Generated at 2022-06-23 12:12:23.012772
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ansible_environment = AnsibleEnvironment

    display = Display()

    lookup_base = LookupBase()

    lookup_module = LookupModule()

    #############################################################
    # Unit test for checking the Jinja2 native types
    #############################################################

    # Set value of jinja2_native to False
    jinja2_native = False
    # Set value of convert_data to True
    convert_data = True

    # Create template
    template_data = "{{ key }}"
    # Create template_vars
    template_vars = dict()
    # Define key
    key = "Valid"
    # Set the value of key to template_vars
    template_vars['key'] = key
    # Define terms
    terms = ["template.j2"]
    # Set the value of terms to

# Generated at 2022-06-23 12:12:24.457867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:12:37.010079
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def run_lookup_module(terms, module_args, ret_expected):
        # Make up a mock set of variables
        variables = {'var1': [1, 2, 3], 'var2': 'foobar'}

        # Create the lookup module and call it
        lm = LookupModule()
        ret = lm.run(terms, variables, **module_args)

        # Compare the return value of the lookup module with the expected one
        # we may need to convert the native types first
        if USE_JINJA2_NATIVE:
            for k, v in enumerate(ret):
                if isinstance(v, NativeJinjaText):
                    ret[k] = to_text(v, errors='surrogate_or_strict')
        assert ret == ret_expected


# Generated at 2022-06-23 12:12:47.625595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    # Test with jinja2_native disabled globally
    from ansible.template import USE_JINJA2_NATIVE as global_jinja2_native
    USE_JINJA2_NATIVE = False

# Generated at 2022-06-23 12:12:52.206674
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ["./some_template.j2"]
    variables = { "fruit": "apple" }
    kwargs = { "template_vars" : { "vegetable" : "potato" } }

    lookup_module = LookupModule()

    lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-23 12:13:04.633812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule = LookupModule()

    terms = [
        '', 
        'a', 
        'b', 
        'c'
    ]

    variables = {
        'ansible_search_path': [
            '/Users/xx/Desktop/ansible/git-files/ansible-repo/lookup_plugins',
            '/Users/xx/Desktop/ansible/git-files/ansible-repo/library',
            '/Users/xx/Desktop/ansible/git-files/ansible-repo/module_utils',
            '/Users/xx/Desktop/ansible/git-files/ansible-repo/playbooks',
            '/Users/xx/Desktop/ansible/git-files/ansible-repo/roles'
        ]
    }


# Generated at 2022-06-23 12:13:06.607887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:13:12.335400
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(['ntp.conf.j2'], {}) == [b'{{ ansible_managed }}\n# This file is managed by Ansible - CHANGES WILL BE OVERWRITTEN\nserver 0.pool.ntp.org\nserver 1.pool.ntp.org\nserver 2.pool.ntp.org\nserver 3.pool.ntp.org']

# Generated at 2022-06-23 12:13:24.458021
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule
    class MyDisplay(object):
        verbosity = 3

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass

        def vvv(self, msg, host=None):
            msg = to_text(msg, errors='surrogate_or_strict')
            print('vvv: %s' % msg)

        def vvvv(self, msg, host=None):
            msg = to_text(msg, errors='surrogate_or_strict')
            print('vvvv: %s' % msg)

        def debug(self, msg):
            msg = to_text(msg, errors='surrogate_or_strict')
            print('debug: %s' % msg)

# Generated at 2022-06-23 12:13:30.547255
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test method run of class LookupModule
    # with simple term and variables
    term = "./test_term.j2"
    variables = {
        "test_variable": 1,
        "test_variable_2": "moo"
    }
    returned = LookupModule.run(term, variables)
    expected = [u"test term result"]
    assert returned == expected

# Generated at 2022-06-23 12:13:34.102617
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # test constructor of class LookupModule
    assert isinstance(lookup_plugin, LookupModule)
    # test method 'run' of class LookupModule
    assert lookup_plugin.run([], {}) == []

# Generated at 2022-06-23 12:13:35.721841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:13:36.673569
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 12:13:40.334319
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MyLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            super(MyLookupModule, self).__init__(*args, **kwargs)

    mylookup = MyLookupModule()
    assert(isinstance(mylookup, LookupModule))

# Generated at 2022-06-23 12:13:45.958299
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    lookup_plugin = LookupModule()
    lookup_plugin.set_options()
    assert isinstance(lookup_plugin, LookupModule)
    #The environment variable "HOME" must be set.
    assert os.path.isdir(os.getenv("HOME"))
    assert len(lookup_plugin.run(['.bashrc'], dict(ansible_env=dict(HOME='/')))) == 1

if __name__ == "__main__":
    test_LookupModule()

# Generated at 2022-06-23 12:13:47.614107
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.template import LookupModule
    lup = LookupModule()


# Generated at 2022-06-23 12:13:53.896480
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.vars == {}
    assert lookup_plugin.convert_data_p == True
    assert lookup_plugin.lookup_template_vars == {}
    assert lookup_plugin.jinja2_native == False
    assert lookup_plugin.variable_start_string == '{{'
    assert lookup_plugin.variable_end_string == '}}'
    assert lookup_plugin.comment_start_string == '/*'
    assert lookup_plugin.comment_end_string == '*/'

# Generated at 2022-06-23 12:14:02.686551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.quiet(True)

    module = LookupModule(**{})
    assert module._templar.environment.variable_start_string == '{{'
    assert module._templar.environment.variable_end_string == '}}'
    assert module._templar.environment.comment_start_string == '{#'
    assert module._templar.environment.comment_end_string == '#}'

    assert module.run(**{
        'templates': ['test-template'],
        'variables': {},
        'variable_start_string': '[%',
        'variable_end_string': '%]',
        'comment_start_string': '[#',
        'comment_end_string': '#]',
    }) == ['[% value %]']

# Generated at 2022-06-23 12:14:05.234515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global lookup_instance
    lookup_instance = LookupModule()
session_fixtures = {}


# Generated at 2022-06-23 12:14:09.910392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # test for _do_template() and _loader_contents()
    lookup_plugin.run(['./test/ansible/testdata/templates/hosts.j2'], dict(inventory_hostname="localhost--"), force_search=True)

# Generated at 2022-06-23 12:14:11.316265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:14:19.666974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.dataloader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    # set up needed objects
    dataloader = ansible.parsing.dataloader.DataLoader()
    inventory = InventoryManager(loader=dataloader, sources='localhost,')
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

# Generated at 2022-06-23 12:14:22.234623
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance._templar is not None

# Generated at 2022-06-23 12:14:31.155601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing ansible.plugins.lookup.template.LookupModule")
    lookup_module = LookupModule()
    print("LookupModule object will be accepted if the exception is not raised.")
    print("The exception should be raised if the arg 'loader' is passed "
          "as an arg of __init__()")
    try:
        LookupModule(loader=object)
        raise Exception("exception should be raised")
    except TypeError:
        print("TypeError was raised as expected")
    LookupModule()
    print("LookupModule object will be accepted if the exception is not raised.")
    print("If there are no exceptions the test passed")


# Generated at 2022-06-23 12:14:33.224385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_loader(DictDataLoader({}))
    return l

# Generated at 2022-06-23 12:14:44.623521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert None is lookup_plugin.run([], {})

    # Mock display as it's not needed in this test
    display_backup = display
    display = None

    # Configure the global environment to use Jinja2 native types
    from ansible.utils.native_jinja import USE_JINJA2_NATIVE
    original_jinja2_native = USE_JINJA2_NATIVE
    USE_JINJA2_NATIVE = True

    # Create a fake environment and variables for the tests
    import jinja2
    from ansible.utils.jinja_filters import AnsibleJ2Filters
    from ansible.template import AnsibleEnvironment
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 12:14:46.677888
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:14:57.783011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # Create instance of LookupModule passing in a copy of the _templar,
        # which is a shared resource. The _templar is reset before each test,
        # so we don't get it back in the same state as before.
        # This is in case _templar is modified by any test.
        lm = LookupModule(loader=None, templar=deepcopy(_templar), variables={})
    except Exception as e:
        # Fail fast if object can't be instantiated
        raise AssertionError(e)

    # Test with string
    result = lm.run(terms=["string"], variables={})
    assert result == ["string"]

    # Test with number
    result = lm.run(terms=[42], variables={})
    assert result == [42]

# Generated at 2022-06-23 12:15:05.425639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        variable_start_string = '{{'
        variable_end_string = '}}'

    class Variables(object):
        ansible_search_path = [u'.']

    terms = [u'test_lookup_module_run.j2']
    variables = Variables()
    options = Options()
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **vars(options))

    assert result == [u"VARIABLE: present\nVARIABLE: present"], "Run with template_vars should override variable"


# Generated at 2022-06-23 12:15:06.182109
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:15:08.337480
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run([], {}) == []

# Generated at 2022-06-23 12:15:13.044288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import codecs
    import __builtin__
    import os
    import sys
    import sys
    import unittest
    import six

    # This unit test was moved to the file lookup_plugins/test/test_template.py.
    # Please update the test there.
    raise unittest.SkipTest('This unit test was moved to the file lookup_plugins/test/test_template.py.')

# Generated at 2022-06-23 12:15:23.308652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1 - no conversion
    loaders = [LookupModule, LookupModule]
    results = [u"myfile.txt\n", u"myfile.txt\n"]
    templatedir = "tests/support/templates/lookup"
    lookup_options =["convert_data=False"]
    templaterun = LookupModule().run(terms=['default.txt'], variables={}, term_type='yamls', loader=loaders, templatedir=templatedir, lookup_options=lookup_options)
    assert templaterun[0] == results[0]

    # Test case 2 - conversion
    loaders = [LookupModule, LookupModule]
    results = [u"myfile.txt\n"]

# Generated at 2022-06-23 12:15:26.002433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    assert lookup_module._templar == None

# Generated at 2022-06-23 12:15:34.756720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    try:
        from __main__ import display
    except ImportError:
        display = Display()

    lookup = LookupModule()

    # test empty template
    template_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_data/lookup_contrib/templates/empty.j2')
    assert lookup._loader.path_exists(template_path)

    b_template_data, show_data = lookup._loader._get_file_contents(template_path)
    template_data = to_text(b_template_data, errors='surrogate_or_strict')
    assert template_data == ''

    # test empty template with vars
    template_path = os.path.join

# Generated at 2022-06-23 12:15:40.182177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables={'var' : 'value'}
    result = lookup_module._templar.template('var is {{var}}')
    assert result == 'var is value'

    # TODO(retr0h): Add more tests

# Generated at 2022-06-23 12:15:48.133748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_loader(path):
        return True
    ansible_template_vars = generate_ansible_template_vars('test.j2', '/home/test/template.j2')
    templar = LookupBase._create_template_env()
    terms = ['test.j2']
    with templar.set_temporary_context(available_variables=ansible_template_vars):
        res = LookupModule(loader=test_loader, templar=templar, variables={}).run(terms=terms, variables={})
    assert res == ['template.j2: /home/test/template.j2\n']

# Generated at 2022-06-23 12:15:54.294594
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()

    # Test the run method of class LookupModule
    # the return values are of type str and must be converted to bytes
    # to use assertEqual
    assertEqual(b"hello there world", lm.run(terms=['test_template.ini'], variable_start_string='[', variable_end_string=']')[0])



# Generated at 2022-06-23 12:16:04.120080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("TESTING LOOKUPS")
    lookup = LookupModule()
    data = lookup.run(["{{lookup_test}}"], {"lookup_test": "test"})
    assert data == ["test"]

    data = lookup.run(["{{lookup_test1}}", "{{lookup_test2}}"], {"lookup_test1": "test1", "lookup_test2": "test2"})
    assert data == ["test1", "test2"]

    data = lookup.run(["{{lookup_test}}", "{{lookup_test}}"], {"lookup_test": "test1"})
    assert data == ["test1", "test1"]


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:16:09.531177
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = []
    for term in ['test.j2', 'test2.j2']:
        results.append(term)
    terms = []
    terms.append('test.j2')
    terms.append('test2.j2')
    assert terms == results
    assert True  # TODO: Add some tests later.


# Generated at 2022-06-23 12:16:13.737759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader()

    lookup_module._templar._available_variables = {'place': 'Somewhere'}
    terms = ['example', 'template']

    lookup_module.run(terms, {})

# Generated at 2022-06-23 12:16:20.554493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test with convert_data option
    result1 = lookup.run(terms=["test.j2"], variables={"name": "lookup"}, convert_data=True)
    assert result1 == ["Hello: lookup"]
    # test without convert_data option
    result2 = lookup.run(terms=["test.j2"], variables={"name": "lookup"}, convert_data=False)
    assert result2 == ["Hello: {{ name }}"]

# Generated at 2022-06-23 12:16:27.648550
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_name = "run"

    l = LookupModule()

    term = "../../templates/test.j2"
    kwargs = dict(convert_data=True, jinja2_native=False,
                  template_vars={"asd": 23})
    variables = dict(ansible_search_path=["."])

    res = l.run(terms=[term], variables=variables, **kwargs)

    assert len(res) == 1
    assert res[0] == "hello 23\n"


# Generated at 2022-06-23 12:16:34.709308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup_module = LookupModule()
    lookup_module._loader = loader
    lookup_module._templar = loader.load_basedir('.')

    terms = [ 'tests/foo.j2' ]
    variables = { 'value' : 'foo' }

    results = lookup_module.run(terms, variables)
    assert results == [ to_bytes('value = foo\n') ]

# Generated at 2022-06-23 12:16:36.945041
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_obj = LookupModule()

    assert lookup_obj._loader is not None

# Generated at 2022-06-23 12:16:37.491083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  
  pass

# Generated at 2022-06-23 12:16:46.807837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate a class to test (LookupModule)
    lookup_module = LookupModule()

    # Create variable to store test data (test_data)
    test_data = {}

    # Assign value to variable test_data
    test_data['test_variable_start_string'] = '{{'
    test_data['test_variable_end_string'] = '}}'
    test_data['test_comment_start_string'] = '{#'
    test_data['test_comment_end_string'] = '#}'

    # Create variable to store test result (test_result)
    test_result = []

    # Get test result from the prepared method of LookupModule
    test_result = lookup_module.run(['/etc/hosts'], test_data)

    # Verify test result
    assert test_

# Generated at 2022-06-23 12:16:47.402225
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:16:58.534804
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='list', required=True),
            convert_data=dict(type='bool', default=False),
            template_vars=dict(type='dict', default={}),
            jinja2_native=dict(type='bool', default=False),
            variable_start_string=dict(type='str', default='{{'),
            variable_end_string=dict(type='str', default='}}'),
            comment_start_string=dict(type='str', default='{#'),
            comment_end_string=dict(type='str', default='#}'),
        )
    )



# Generated at 2022-06-23 12:16:59.820967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myclass = LookupModule()
    return myclass

# Generated at 2022-06-23 12:17:01.545421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Simply check that the class can be instantiated
    assert LookupModule()

# Generated at 2022-06-23 12:17:02.404879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, {})

# Generated at 2022-06-23 12:17:03.429523
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert True

# Generated at 2022-06-23 12:17:07.349694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('convert_data') is True
    assert lookup.get_option('jinja2_native') is False
    assert lookup.get_option('template_vars') == {}

# Generated at 2022-06-23 12:17:08.605402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:17:16.699941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run the method run of class LookupModule with
    # a specific argument list for testing.
    terms = ['ansible/test/unit/lookup_plugins/lookup_fixtures/template1.j2']
    variables = {'ansible_search_path':
                 ['/home/john/ansible/test/unit/lookup_plugins/lookup_fixtures']}
    test_result = LookupModule().run(terms, variables, convert_data=True)
    assert test_result == ['1']
    # Failed test if test_result == ['1']

# Generated at 2022-06-23 12:17:21.583360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

    lookup_module = LookupModule()

    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:17:31.303373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-argument,unused-variable,redefined-outer-name,line-too-long
    # Tests always use a global config and the common config directory
    global_config_file = os.path.join(os.path.dirname(__file__), "../../../filter/plugins/test/unit/ansible.cfg")
    global_config = configparser.ConfigParser()
    assert global_config.read(global_config_file)

    # Unit test for method run() of class LookupModule
    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = TestLoader()
            self._templar = TestTemplar(loader=None, variables={'a': 1})


# Generated at 2022-06-23 12:17:36.393601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    lookup_plugin = LookupModule()
    lookup_plugin._templar = None  # Avoid errors about templar not being an
                                   # attribute during the test.
    assert len(lookup_plugin._get_options_keywords()) == 8

# Generated at 2022-06-23 12:17:44.471549
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of LookupModule
    test = LookupModule()

    # Add function to the lookUp class
    test.set_options = lambda x, y : None

    # Test invalid file
    terms = ["fake_file.txt"]
    variables = dict(ansible_search_path=["/etc/ansible/roles/test.test/tasks/"])
    test.find_file_in_search_path = lambda x, y, z : None
    try:
        test.run(terms, variables)
    except:
        pass
    else:
        raise Exception("Error - when testing invalid file")

    # Test valid file
    terms = ["fake_file.txt"]
    variables = dict(ansible_search_path=["/etc/ansible/roles/test.test/tasks/"])
   

# Generated at 2022-06-23 12:17:47.795681
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert hasattr(test_class, 'run')
    assert hasattr(test_class, 'run')

# Generated at 2022-06-23 12:17:58.510775
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    if sys.version_info.major >= 3:
        unicode = str
    # Test with convert_data = False
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)
    assert isinstance(lookup_instance._get_options, object)
    assert isinstance(lookup_instance.run(terms=['test_template.j2'], variables={'foo': 'bar'}, convert_data=False), list)
    # Test with convert_data = True
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)
    assert isinstance(lookup_instance._get_options, object)

# Generated at 2022-06-23 12:18:09.715553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create LookupModule object
    lookup = LookupModule()

    # Create a dict with required parameters
    options = {}
    options.update({
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'comment_start_string': '{#',
        'comment_end_string': '#}',
    })

    # Create a template variable
    template_vars = '''
    dest_dir: /etc/somewhere
    '''

    # Create a dict from the string
    lookup_template_vars = dict([[i.strip() for i in line.split(':')] for line in template_vars.splitlines() if line.strip()])

    # Set options

# Generated at 2022-06-23 12:18:21.717869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import os

    lookup = LookupModule()
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    variable_manager.extra_vars = {'foo': 'bar'}
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    tmplar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 12:18:23.440616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run

# Generated at 2022-06-23 12:18:29.323984
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    from jinja2 import UndefinedError

    # Set up
    lookup = LookupModule()

    # Run method
    assert lookup._templar is None
    lookup.run(['fake_file'], {})
    assert isinstance(lookup._templar, Templar)

    # Test exception handling
    try:
        lookup.run(['fake_file'], {})
    except AnsibleError:
        pass
    except Exception:
        assert False

# Generated at 2022-06-23 12:18:30.584988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # use setUp() and tearDown() to init/deinit
    raise ImportError

# Generated at 2022-06-23 12:18:39.499077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    plugin_name = 'template'
    plugin_args = ['test_lookup_plugin.j2']
    options = {'name': 'TestLookupPlugin'}
    term = None
    output_list = []
    output_string = ''

    # When
    lu = LookupModule()
    output_list = lu.run(terms=plugin_args, variables=options, **term)

    # Then
    if len(output_list) > 0:
        output_string = output_list[0]
    assert output_string == 'TestLookupPlugin'

# Generated at 2022-06-23 12:18:47.712133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import jinja2
    from ansible.module_utils.six import PY2
    from ansible.utils import context_objects as co

    # Create a fake lookup plugin
    lookup_plugin = LookupModule()

    # Create a fake environment
    env = jinja2.Environment()
    env.filters.update(co.AnsibleJ2Vars(hostvars=dict()).get_filters())
    env.globals.update(co.AnsibleJ2Vars(hostvars=dict()).get_all())
    env.finalize = lambda: None

    # Create a fake loader
    class FakeLoader(object):
        def get_basedir(self, *args, **kwargs):
            return '/path/to'


# Generated at 2022-06-23 12:18:50.067247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-23 12:18:58.941809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dummy_module = type('', (), {})()
    dummy_module.params = {'variable_start_string': '{{', 'variable_end_string': '}}'}
    dummy_module.params = {'comment_start_string': '{#', 'comment_end_string': '#}'}

    class DummyPlugin(object):
        def __init__(self):
            self.name = 'test_plugin'
            self.path = ['test_path']

    display.verbosity = 4
    lookup_module = LookupModule(
        loader=DummyPlugin(),
        templar=dummy_module,
        shared_loader_obj=None,
    )

# Generated at 2022-06-23 12:19:10.639751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    # empty test case
    tdict = {}
    tdict['template_vars'] = {}
    assert LookupModule([], tdict).run(['foo.j2']) == []

    # test with a single template
    tdict = {}
    tdict['template_vars'] = {}
    ret = LookupModule([], tdict).run(['foo.j2'])
    assert len(ret) == 1

    # test with a list of templates
    tdict = {}
    tdict['template_vars'] = {}
    ret = LookupModule([], tdict).run(['foo.j2', 'bar.j2'])
    assert len(ret) == 2


# Generated at 2022-06-23 12:19:12.724918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 12:19:25.099141
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os.path
    import tempfile

    from ansible.template import template
    from ansible.parsing.yaml.objects import AnsibleUnicode

    lookup_module = LookupModule()

    search_path = [os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'templates')]
    term1 = '../test/templates/basic.j2'
    term2 = '../test/templates/with_includes.j2'

    expected1 = 'foo'
    expected2 = 'bar\n\n'

    (fd, f) = tempfile.mkstemp()
    os.close(fd)

    # Create a config object to pass in kwargs
    config = {}

# Generated at 2022-06-23 12:19:26.592458
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """unit tests for lookup_plugin.LookupModule"""
    assert LookupModule is not None

# Generated at 2022-06-23 12:19:27.862414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Just an instantiation test
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:19:35.123230
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declare some constants including some template files
    # that would normally be created in a temporary file
    # directory within the standard ansible tree.
    #
    # The content of the template files are derived from examples
    # provided in the ansible documentation.
    #
    ansible_search_path = ['/usr/share/ansible/']
    lookup_file = 'my_template.j2'
    lookup_file_path = '/usr/share/ansible/templates/my_template.j2'
    lookup_file_content = 'IP addresses: {% for i in ansible_all_ipv4_addresses %}{{ i }} {% endfor %}\n'
    lookup_file2 = 'my_template2.j2'

# Generated at 2022-06-23 12:19:46.010294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.reserved import Reserved, DEFAULT_VAULTS_ENCRYPT_STRATEGY
    from ansible.vars.hostvars import HostVarsVars

    package = {
        Reserved: {
            'ansible_vault_password': 'password',
            'ansible_vault_encrypt_string': {
                'vault_key': 'password',
                'encrypt_string': 'hello'
            }
        },
        HostVarsVars: {
            'ansible_vault_password': 'password',
            'ansible_vault_encrypt_string': {
                'vault_key': 'password',
                'encrypt_string': 'hello'
            }
        }
    }

    lookup_module

# Generated at 2022-06-23 12:19:47.153344
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:19:57.527317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    import os
    import jinja2

    display = Display()
    templar = Templar(loader=None, variables={})
    basedir = os.path.abspath(os.path.dirname(__file__))
    lookup = LookupModule()
    lookup._templar = templar
    lookup.set_options(direct=dict(template_vars=dict(foo='bar')))

    # Test if simple string replacement works
    terms = ['test_template.j2']
    template_data = lookup.run(terms, variables={}, convet_data=False)[0]
    assert template_data == "bar"

    # Test if loop over dictionary works
    terms = ['loop_dict.j2']

# Generated at 2022-06-23 12:19:58.780653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-23 12:20:08.764908
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test when convert_data is not specified, then global convert_data should be used
    lookup = LookupModule()
    _config = {'convert_data': False, 'jinja2_native': False}
    _plugin_options = {}
    lookup._display = display
    lookup._loader = None
    lookup._templar = None
    lookup.set_options(direct={'convert_data': False}, var_options={})
    lookup._get_option = lookup._get_option_with_fallback
    _var_options = {'convert_data': False}
    _options_hash = lookup._get_options_hash(_var_options, _config, _plugin_options)
    assert lookup.get_option('convert_data') == _config['convert_data']