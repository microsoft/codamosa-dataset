

# Generated at 2022-06-25 11:17:12.224443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    data = dict(
        ansible_search_path = [os.path.dirname(__file__)],
        ansible_managed = 'da',
        template_dir = os.path.dirname(__file__),
        template_file = 'yaml_jinja.j2',
        template_host = 'localhost'
    )

    result = lookup_module.run(terms=['yaml_jinja.j2'], variables=data)

    assert(result[0] == "\npass: \n  key0: value0\n  key1: value1\n")


# Generated at 2022-06-25 11:17:24.265653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Setup
    lookup_module = LookupModule()
    terms = ["LOOKUP_TEST.txt"]
    variables = {"Foo":"Bar"}
    kwargs = {"convert_data":"True"}
    lookup_module.term = None
    lookup_module.run = "True"
    lookup_module.get_option = "True"
    lookup_module.get_option = lambda x: "True"
    lookup_module._loader = "True"
    lookup_module._loader._get_file_contents = lambda x: (b"{{Foo}}", "True")
    lookup_module.to_bytes = lambda x: b"{{Foo}}"
    lookup_module.to_text = lambda x: "{{Foo}}"
    lookup_module.to_text = lambda x: "True"
    lookup_

# Generated at 2022-06-25 11:17:31.263232
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # run with empty terms
    lookup_module = LookupModule()
    lookup_module.set_loader({'paths': []})
    assert lookup_module.run(terms=[], variables={}) == []

    # run with terms
    lookup_module = LookupModule()
    lookup_module.set_loader({'paths': []})
    assert lookup_module.run(terms=["file"], variables={}) == []

# Generated at 2022-06-25 11:17:33.977264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = Mock()



# Generated at 2022-06-25 11:17:38.155579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['./some_template.j2'] 
    variables = {"hostvars": {},
                "vars": {}}

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables) == [u'Results of processing that template.\n']

# Generated at 2022-06-25 11:17:46.720989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['dummy_value_0', 'dummy_value_1']
    variables = {'ansible_search_path': ['/tmp/ansible/'], 'ansible_vault_password_file': './dummy_path', 'ansible_playbook_python': 'python'}
    kwargs = {'convert_data': False, 'jinja2_native': True}
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret == ['dummy_value_0', 'dummy_value_1']

# Generated at 2022-06-25 11:17:56.024373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['./some_template.j2']
    variables_1 = {}
    result = lookup_module_1.run(terms_1, variables_1)
    assert result == ['some_template.j2']

    lookup_module_2 = LookupModule()
    terms_2 = ['./some_template.j2']
    variables_2 = {'ansible_search_path': ['path/to/dir']}
    result = lookup_module_2.run(terms_2, variables_2)
    assert result == ['some_template.j2']

# Generated at 2022-06-25 11:17:59.044623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0() # Create test case


# Generated at 2022-06-25 11:18:05.564953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = None
    terms_1 = 'template.j2'
    vars_1 = None
    kwargs_1 = None
    lookup_module_1 = LookupModule()
    try:
        result_1 = lookup_module_1.run(terms_1,vars_1,**kwargs_1)
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:18:11.313328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = list()
    terms_0.append("test_ls_0")
    terms_0.append("test_ls_1")
    variables_0 = dict()
    variables_0['test_var_0'] = "test_ls_1"
    variables_0['test_var_1'] = "test_ls_0"
    ret_val_0 = lookup_module_0.run(terms_0, variables_0)
    for line in ret_val_0:
        assert line == "test_ls_0\ntest_ls_1\n"

# Generated at 2022-06-25 11:18:27.896990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['test_key'], {}) == [{u'_raw': u'{{test_key}}'}]

# Generated at 2022-06-25 11:18:34.288596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_terms = ["../../lookup_plugins/template/tests/test.j2"]
    test_variables = dict(a='2', b='')
    test_options = dict(convert_data='True',
                        jinja2_native='False',
                        template_vars='dict(a=2, b=None)',
                        variable_start_string="'{{'",
                        variable_end_string="'}}'",
                        comment_start_string="'{#'",
                        comment_end_string="'#}'")
    lookup_module.run(test_terms, test_variables, **test_options)


# Generated at 2022-06-25 11:18:38.357221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_run_0_terms = ['some_file.j2']
    test_run_0_variables = {'some_file':{}}
    result_0 = lookup_module_0.run(test_run_0_terms, test_run_0_variables)
    print(result_0)

# Generated at 2022-06-25 11:18:41.936766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['./some_template.j2']
    variables_0 = {}
    kwargs = {'convert_data': False, 'variable_start_string': '{{', 'variable_end_string': '}}', 'jinja2_native': False, 'template_vars': {}, 'comment_start_string': None, 'comment_end_string': None}
    ret_val = lookup_module_0.run(terms_0, variables_0, **kwargs)

# Generated at 2022-06-25 11:18:44.827248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [['../../test/test1.conf']]
    variables_0 = dict()
    lookup_module_0._templar.environment = AnsibleEnvironment()
    lookup_module_0.set_options(var_options=variables_0, direct=dict())
    lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:18:51.195952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError, match="the template file ./some_template.j2 could not be found for the lookup"):
        lookup_module_0 = LookupModule()
        terms_0 = ['./some_template.j2']
        variables_0 = {}
        ret_0 = lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:19:01.034477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Initialize the instance of LookupModule
    lookup_module = LookupModule()

    # Create a new Mock object
    mocker = Mocker()

    # Create a new instance of the AnsibleModule to generate the conf obj
    ansible_module = AnsibleModule(argument_spec={})

    # Setup return value of ansible_module.checkmode() as false
    mock_ansible_module = mocker.replace(ansible_module)
    mock_ansible_module.check_mode = PropertyMock(return_value=False)


    # Setup the return value for ansible_module.params with a given config
    mock_ansible_params = mocker.replace(ansible_module.params)
    mock_ansible_params = {'var': [{'key': 'value'}]}

# Generated at 2022-06-25 11:19:01.734709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 11:19:08.807244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Returns a list of strings; for each template in the list of templates you pass in, returns a string containing the results of processing that template.
    with pytest.raises(AnsibleError) as excinfo:
        test_case_0.run(terms=['./some_template.j2'], variables={})
    assert "the template file ./some_template.j2 could not be found for the lookup" in str(excinfo.value)

# Generated at 2022-06-25 11:19:19.748871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["test_terms.txt"]
    variables_1 = {"ansible_verbosity": 3}
    result_1 = lookup_module_1.run(terms_1, variables_1)
    assert len(result_1) > 0
    assert result_1[0] == "This is a test"
    # Test with extra options
    lookup_module_2 = LookupModule()
    terms_2 = ["test_terms.txt"]
    variables_2 = {"ansible_verbosity": 3}
    result_2 = lookup_module_2.run(terms_2, variables_2, convert_data=True)
    assert len(result_2) > 0
    assert result_2[0] == "This is a test"
    # Test with extra options
   

# Generated at 2022-06-25 11:19:37.460639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = var_0 = lookup_module_0.run()
    var_1 = [var_0[0]]
    var_2 = var_2 = lookup_module_0.run()
    var_3 = [var_2[0]]
    var_4 = var_4 = lookup_module_0.run()
    var_5 = [var_4[0]]
    var_6 = var_6 = lookup_module_0.run()
    var_7 = [var_6[0]]
    var_8 = var_8 = lookup_module_0.run()
    var_9 = [var_8[0]]
    var_10 = var_10 = lookup_module_0.run()
    var_11 = [var_10[0]]
   

# Generated at 2022-06-25 11:19:44.941075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '54e35b1.py'
    variables_0 = {}
    lookup_module_0.run(term_0, variables_0)
    term_1 = '54e35b1.py'
    lookup_module_0.run(term_1, variables_0)
    term_2 = '54e35b1.py'
    lookup_module_0.run(term_2, variables_0)
    term_3 = '54e35b1.py'
    lookup_module_0.run(term_3, variables_0)
    term_4 = '54e35b1.py'
    lookup_module_0.run(term_4, variables_0)
    term_5 = '54e35b1.py'


# Generated at 2022-06-25 11:19:53.713601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'(\xa8\xed\xd6)\xbd'
    bool_0 = True
    lookup_module_0 = LookupModule()
    str_0 = '}b\x1a\xe9\x19\x85\x0bC\x12\x08\xd6\xc1\x1b\x94\xbb\xca'
    lookup_module_0.set_options(var_options=str_0, direct=bool_0)
    var_0 = lookup_module_0.run(bytes_0, bool_0)


# Generated at 2022-06-25 11:19:54.632720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:19:56.865902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:20:00.885223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'BK'
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.run(str_0, bool_0)

# Generated at 2022-06-25 11:20:07.702180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test an empty file
    test_file = 'empty_file.txt'
    with open(test_file, 'w') as f:
        f.write('')
    # Check the result of rendering an empty file.
    # The result should be empty.
    lu = LookupModule()
    assert lu.run([test_file]) == [""]

    # Test a file with one blank line
    test_file = 'one_blank_line.txt'
    with open(test_file, 'w') as f:
        f.write('\n')
    # Check the result of rendering a blank line.
    # The result should be a single newline char.
    lu = LookupModule()
    assert lu.run([test_file]) == ["\n"]

    os.remove(test_file)

   

# Generated at 2022-06-25 11:20:15.383840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'hello'
    variables_0 = 'hello'
    lookup_module_0 = LookupModule()
    lookup_module_0.run(term_0, variables_0)

# Generated at 2022-06-25 11:20:20.750695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:20:21.387204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True



# Generated at 2022-06-25 11:20:42.214338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:20:54.127940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'Jn'

# Generated at 2022-06-25 11:20:56.991103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\u0000'
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0, bool_0)
    assert(var_0 == None)



# Generated at 2022-06-25 11:21:02.069227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Implement test_LookupModule_run here
    assert True # TODO: Implement test body here


# Generated at 2022-06-25 11:21:11.373347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    search_recursive_0 = {"a": 8, "e": 42, "f": 18, "q": "rN\x7f\x03\xf7\xb0", "j": "m", "i": "D^\x05\xcc\x16"}
    dict_0 = {"a": 8, "e": 42, "f": 18, "q": "rN\x7f\x03\xf7\xb0", "j": "m", "i": "D^\x05\xcc\x16"}

# Generated at 2022-06-25 11:21:16.191038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'(\xa8\xed\xd6)\xbd'
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, bool_0)


# Generated at 2022-06-25 11:21:22.790138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options="", direct="")
    lookup_module_0.set_loader(var_loader="")
    lookup_module_0.set_templar(var_templar="")
    bytes_0 = b'(\xa8\xed\xd6)\xbd'
    bool_0 = True
    try:
        lookup_module_0.run(terms=bytes_0, variables=bool_0)
    except AnsibleError:
        pass

# Generated at 2022-06-25 11:21:32.844519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run([b'\xe8\xc3\xedB\xa5\xaf\xb6U\xe3\xbd\x94\xea\xc5\x95\xf5\x98\xedr\x1e\x91\xa0\x0bH\xf8\x05'], [b'\xd6\xbc\x81\xc3\xf6\x84\xc5\xbe\x8f\xb5\xe0\xac\xf2\xc8\xb2\xec\x87\xae\xf8\xe5'])
    assert var_0 == []



# Generated at 2022-06-25 11:21:42.583665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '1|u8tYwzdlZu\t4o4t$'
    str_1 = '|bpBx^|q3'
    str_2 = '%-5n]hmR\x10\x03'
    str_3 = '7|u8tYwzdlZu\t4o4t$'
    str_4 = 'y|bpBx^|q3'
    str_5 = 'o%-5n]hmR\x10\x03'
    str_6 = 'K!Og_Pw|'
    str_7 = 'U\to3)q_'
    str_8 = 'gfK!Og_Pw|'

# Generated at 2022-06-25 11:21:49.982340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters
    terms = [b'(\xa8\xed\xd6)\xbd', b'(\xa8\xed\xd6)\xbd', b'(\xa8\xed\xd6)\xbd', b'(\xa8\xed\xd6)\xbd', b'(\xa8\xed\xd6)\xbd', b'(\xa8\xed\xd6)\xbd', b'(\xa8\xed\xd6)\xbd', b'(\xa8\xed\xd6)\xbd']

# Generated at 2022-06-25 11:22:42.272923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define a string and a boolean to initialize the variables
    bytes_0 = b'(\xa8\xed\xd6)\xbd'
    bool_0 = True
    # Create an instance of the LookupModule class
    lookup_module_0 = LookupModule()
    # Call the run method from this instance
    var_0 = lookup_module_0.run(bytes_0, bool_0)


# Generated at 2022-06-25 11:22:43.343024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()

# Generated at 2022-06-25 11:22:46.391658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'2\xdc\xfc\x1b\xf7\x80\xa5'
    bool_0 = True
    lookup_module_0 = LookupModule()
    lookup_module_0.run(bytes_0, bool_0)


# Generated at 2022-06-25 11:22:49.839750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(  )) == 2

# Generated at 2022-06-25 11:22:52.836810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_run(["/Usr/share/ansible/my_vars.yml", "/etc/ansible/my_vars.yml"], False, lookup_module_0)

# Generated at 2022-06-25 11:22:55.367218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[], variables=dict(), **dict())


# Generated at 2022-06-25 11:23:07.393985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'(\xa8\xed\xd6)\xbd'

    # Test with string term
    terms = ["template_test_case.txt"]
    # Test with boolean for jinja2_native
    jinja2_native = False
    # Test with variables from AnsibleTemplateVars
    variables = {"template_change_occurred": False, "template_checksum": "fe1f720b7a733a2110c2507c6ad8a2c7", "template_hostname": "localhost", "template_path": "/etc/hosts", "template_uid": 0}
    lookup_module_0.run(terms, variables, jinja2_native=jinja2_native)

# Generated at 2022-06-25 11:23:13.705966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'(\xa8\xed\xd6)\xbd'
    bool_0 = True
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0 = lookup_run(bytes_0, bool_0)
    lookup_terms_0 = ()
    lookup_module_1 = lookup_run(lookup_terms_0, bool_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:20.659802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    lookup_module_0 = LookupModule()
    lookup_module_0._templar = Templar()

    terms = list()
    variables = dict()

    # test with valid args
    try:
        lookup_module_0.run(terms, variables)
    except Exception as exception:
        assert False

    # test with invalid args
    invalid_terms = list()
    invalid_variables = list()
    try:
        lookup_module_0.run(invalid_terms, variables)
        assert False
    except:
        pass

    try:
        lookup_module_0.run(terms, invalid_variables)
        assert False
    except:
        pass

# Generated at 2022-06-25 11:23:28.728862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xeb\x82\x1a\x1a\xa7\xfc\x88'
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, bool_0)
    assert var_0



# Generated at 2022-06-25 11:25:12.401201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [True, 'dummy data']
    variables = {'true': False, 'false': False}
    kwargs = {'false': False, 'true': True}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:25:21.350475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = b'(B\x9c'
    variables = b'(\xc4\x7f'
    convert_data = True

# Generated at 2022-06-25 11:25:31.256167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0 != None
    dict_0 = dict()
    dict_0['ansible_env'] = dict()
    dict_0['ansible_play_hosts'] = 'None'
    dict_0['ansible_play_batch'] = 'None'
    dict_0['ansible_play_hosts_all'] = list()
    dict_0['ansible_play_hosts_all'] = dict_0['ansible_play_hosts_all'] + ['10.0.0.1', 'localhost']
    dict_0['ansible_play_hosts_all'] = dict_0['ansible_play_hosts_all'] + ['None']

# Generated at 2022-06-25 11:25:37.353521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x61'
    bool_0 = True
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = MockLoader()
    lookup_module_0._templar = MockTemplar()
    lookup_module_0.run(bytes_0, bool_0)


# Generated at 2022-06-25 11:25:45.709149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'(\xa8\xed\xd6)\xbd'
    bool_0 = True
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(loader_0)

# Generated at 2022-06-25 11:25:48.109784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Test AnsibleException is propagated

# Generated at 2022-06-25 11:25:58.968701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0 = lookup_module_0
    dict_0 = dict()
    list_0 = [ dict_0 ]
    dict_1 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_1 = dict()
    dict_0 = dict()
    dict_0 = dict()

# Generated at 2022-06-25 11:26:07.951035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_mock = ["terms_mock", "terms_mock", "terms_mock", "terms_mock"]
    variables_mock = {"variables_mock": "variables_mock"}
    lookup_module_0 = LookupModule()
    lookup_module_run_0 = lookup_module_0.run(terms_mock, variables_mock)
    assert lookup_module_run_0 == ["template", "template", "template", "template"]

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:26:10.275999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # For now, we just test coverage
    # TODO check the value returned by run()
    #test_case_0()
    pass


# Generated at 2022-06-25 11:26:15.000483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    name_0 = '123'
    vars_0 = set()
    result_0 = lookup_module_0.run(name_0, vars_0)
    assert result_0 is not None
