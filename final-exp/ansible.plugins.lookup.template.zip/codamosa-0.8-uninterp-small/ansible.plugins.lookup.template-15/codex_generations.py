

# Generated at 2022-06-25 11:17:04.457371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 0
    test_case_0()

# Generated at 2022-06-25 11:17:14.273562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Input value:
    terms = ['logstash-fwd-1.conf.j2', 'logstash-fwd-2.conf.j2']
    variables = {'inventory_dir': './roles/logstash-forwarder/tests/inventory', 'template_dir': './roles/logstash-forwarder/tests/templates'}

    lookup_module_1 = LookupModule()
    res = lookup_module_1.run(terms=terms, variables=variables)

# Generated at 2022-06-25 11:17:24.984227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import json
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/home/arijit/ansible/ansible-python-api/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-25 11:17:27.413196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module.run(terms=[],variables={})

# Generated at 2022-06-25 11:17:37.486836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text

    lookup_module_0 = LookupModule()

    # Convert Jinja2 vars to Ansible JSON
    # Replace jinja2 variables with valid JSON equivalents
    # When jinja2_native is set to True, we’ll be using literal_eval to
    # convert the data to Python datatypes. As such, our data needs to be
    # valid Python expressions.

    # Set convert_data to True
    # Convert the values to Ansible's internal data representation.
    # This is mostly what you want.

    # True is converted to True
    # False is converted to False
    # None is converted to None
    # integers and strings are passed through as-is
    # lists and tuples are converted to lists
    # dicts and OrderedDicts are converted to dicts

# Generated at 2022-06-25 11:17:48.136245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms=[u'file1', u'file2', u'file3']
    variables={"ansible_search_path_2": "/path/to/ansible/dummy/directory/"
,"ansible_search_path_1": "/path/to/ansible/dummy/directory/"
,"ansible_search_path_0": "/path/to/ansible/dummy/directory/"
}

# Generated at 2022-06-25 11:17:55.156032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = ['var/test/test.shell']
    variables_0 = {}
    kwargs_0 = {}

    # TEST CASE: Run method of LookupModule with parameter terms_0
    # and parameter variables_0 and parameter kwargs_0.
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

    # Test if result_0 refers to an instance of list.
    assert(isinstance(result_0, list))
    # Test if result_0 is an instance of list and there are 2 items in this list.
    assert(isinstance(result_0, list) and len(result_0) == 1)
    # Test if result_0 is an instance of list and all items in this list are instances of str

# Generated at 2022-06-25 11:18:00.439854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_1 = './some_template.j2'
    variable_end_string_1 = '}}'
    variable_start_string_1 = '{{'
    lookup_module_1.run(term_1, variable_end_string_1, variable_start_string_1)


# Generated at 2022-06-25 11:18:05.681843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'run.py')
    with open(fixture_path, 'rb') as fixture_file:
        fixture_data = fixture_file.read()

    lookup_module_0 = LookupModule()
    setattr(lookup_module_0, '_templar', )
    lookup_module_0.run()

# Generated at 2022-06-25 11:18:11.372624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({'convert_data': 1, 'template_vars': {}, 'jinja2_native': 0, 'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': '{#', 'comment_end_string': '#}'})
    lookup_module_1._loader = DummyLoader()
    lookup_module_1._templar = DummyTemplar()
    assert [u'foo\n'] == lookup_module_1.run(['foo.j2'], {})


# Generated at 2022-06-25 11:18:30.273412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assertion error when trying to load file that does not exist
    lookup_module_1 = LookupModule()
    terms = ["nonexistent.tpl"]
    variables = {}
    with pytest.raises(AnsibleError) as error:
        lookup_module_1.run(terms, variables, convert_data=True, variable_start_string='{{', variable_end_string="}}")
    assert "could not be found for the lookup" in to_text(error.value)

# Generated at 2022-06-25 11:18:32.699304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.debug("Test case 0 started")
    test_case_0()
    display.debug("Test case 0 ended")

if __name__ == '__main__':
    print("Processing tests for Ansible Lookup Module for Template")
    test_LookupModule_run()
    print("All tests completed")

# Generated at 2022-06-25 11:18:43.755139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test function return types and correct param types

# Generated at 2022-06-25 11:18:47.236478
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import StringIO

    lookup_module = LookupModule()

    lookup_module.set_loader(dict())
    lookup_module.set_templar(dict())

    lookup_module.set_options(direct=dict())

    lookup_module.run(['./some_template.j2'], dict(), direct={})


# Generated at 2022-06-25 11:18:58.448013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  foo = LookupModule()

# Generated at 2022-06-25 11:19:07.962464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_terms_0 = ['/home/sean/repo/src/ansible/test/lib/ansible/modules/network/nxos/nxos_template.j2']

# Generated at 2022-06-25 11:19:19.294633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()


# Generated at 2022-06-25 11:19:25.203512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.display("Testing Ansible lookup mechanism", color='blue')
    display.display("Today is: ", dt.datetime.now(), " ", color='blue')
    display.display("Testing the Template lookup mechanism", color='blue')
    test_get_template_path = LookupModule()
    actual_result = test_get_template_path.run(['test.j2'],{})
    expected_result = ['Hello World']
    assert expected_result == actual_result, "Expected {0}, but got {1}" .format(expected_result,actual_result)

# Generated at 2022-06-25 11:19:29.387269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup_module_varargs = {}
    lookup_module_varargs['_templar'] = AnsibleEnvironment()
    lookup_module_varargs['_loader'] = AnsibleEnvironment()
    lookup_module_instance = LookupModule(**lookup_module_varargs)
    # Setting up arguments and keywords for function run
    # Calling function run
    result = lookup_module_instance.run(terms, variables, **kwargs)
    assert result == expected



# Generated at 2022-06-25 11:19:31.287392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'./some_template.j2']
    variables = {}
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) == []

# Generated at 2022-06-25 11:19:54.288986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # t = ansible.template.Template(None, None)
    # l = ansible.plugins.lookup.template.LookupModule()
    # l.set_environment(t)
    # l.run(["../../tests/templates/template.j2"], dict())
    test_case_0()

# Generated at 2022-06-25 11:20:04.801048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check with 0 arguments
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run()
        assert False
    except:
        assert True

    # check with 1 arguments
    try:
        lookup_module_2 = LookupModule()
        lookup_module_2.run([])
        assert False
    except:
        assert True

    # check with 2 arguments
    try:
        lookup_module_3 = LookupModule()
        lookup_module_3.run([], {}, _ansible_no_log=False)
        assert False
    except:
        assert True

    # check with 3 arguments

# Generated at 2022-06-25 11:20:09.998012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module.set_available_variables({})
    lookup_module._templar = AnsibleEnvironment(loader=None, variables={})
    assert lookup_module.run(["./some_template.j2"], {})

# Generated at 2022-06-25 11:20:19.411573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = 'plugins/lookup/template.py'
    lookup_module = LookupModule()
    terms = ['test.yml']
    variables = {'ansible_search_path': ['/etc/ansible']}
    kwargs = {'convert_data':['False'], 'jinja2_native':'False', 'variable_end_string':['}}'], 'variable_start_string':['{{'], 'comment_start_string':[''], 'comment_end_string':[''], 'template_vars':{}}
    assert lookup_module.run(terms, variables, **kwargs) == [u'Some\ntext\n']

# Generated at 2022-06-25 11:20:27.814706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    run(self, terms, variables=None, **kwargs)
    Parameters:
		param1 (str): Description of param1
		param2 (str): Description of param2
		**kwargs: Description of **kwargs

    Returns:
        return_type: Description of return value

    Raises:
        exception_type: Description of exception
    """
    lookup_module = LookupModule()
    lookup_module_0 = LookupModule()
    terms = "./some_template.j2"
    variables = None
    kwargs = {"some": "kw"}
    lookup_module_0.set_options(var_options={"some": "var"})
    lookup_module_0.find_file_in_search_path(variables, 'templates', terms)

# Generated at 2022-06-25 11:20:33.415356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = './some_template.j2'
    variables_0 = {}
    arguments_0 = {}
    try:
        lookup_module_0.run(terms_0, variables_0, **arguments_0)
    except Exception as e:
        assert 0, 'AnsibleException: the template file ./some_template.j2 could not be found for the lookup'

# Generated at 2022-06-25 11:20:43.124532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for terms that are not a list
    for terms in [1, None, 'a']:
        lookup_module = LookupModule()
        try:
            lookup_module.run(terms, dict())
            assert False
        except TypeError:
            pass
        except Exception:
            assert False
        else:
            assert False
    # Test for terms that are not a list of strings
    for terms in [[1, {}], ['a', object()]]:
        lookup_module = LookupModule()
        try:
            lookup_module.run(terms, dict())
            assert False
        except ValueError:
            pass
        except Exception:
            assert False
        else:
            assert False

# Generated at 2022-06-25 11:20:51.377696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_obj = LookupModule()
  terms = ["my_template.j2"]
  variables = {"hostvars":{"host1":{"hostvars_key1":"hostvars_value1"}}}
  kwargs = {"_terms":terms, "hostvars":variables["hostvars"]["host1"]["hostvars_key1"], "variable_start_string":"{{"}
  lookup_module_obj.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:21:00.135810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    options = {'jinja2_native': False, 'variable_start_string': '{{', 'comment_start_string': '*#', 'variable_end_string': '}}', 'convert_data': False, 'comment_end_string': '#*', 'template_vars': {}}
    terms = ['../../example_tmpl.j2', '../../example_tpl']

# Generated at 2022-06-25 11:21:02.965068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:21:49.014755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # No Error
    term = './some_template.j2'
    variables = {}
    lookup_weird_chars = {}
    lookup_weird_chars['template_vars'] = {'a': 'ansible', 'b': 'ansible'}
    lookup_weird_chars['convert_data'] = False
    lookup_weird_chars['variable_start_string'] = '{{'
    lookup_weird_chars['variable_end_string'] = '}}'
    lookup_weird_chars['comment_start_string'] = '{#'
    lookup_weird_chars['comment_end_string'] = '#}'

# Generated at 2022-06-25 11:21:55.290505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(['./test.j2'], {})

    assert len(ret) == 1
    assert ret[0] == 'foobar'


# Generated at 2022-06-25 11:21:57.544223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['./some_template.j2']
    variables = {}
    kwargs = {}
    lookup_module_0.run(terms,variables,**kwargs)

# Generated at 2022-06-25 11:22:04.717733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = None
    lookup_module_1._loader = None

# Generated at 2022-06-25 11:22:10.775081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    globals()['display'].current_display = Display(verbosity=3)
    test_case = dict(terms=['./some_template.j2'])
    globals()['use_jinja2_native'] = True
    lookup_module = LookupModule()
    lookup_module.run(**test_case)

# Generated at 2022-06-25 11:22:22.708576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    arguments_1 = {
        "terms": [
            "./some_template.yml"
        ],
        "variables": {
            "ansible_search_path": [
                "/Library/Frameworks/Python.framework/Versions/3.5/lib/python3.5/site-packages/ansible/plugins/lookup"
            ]
        },
        "direct": {
            "variable_start_string": "{{",
            "variable_end_string": "}}",
            "jinja2_native": False,
            "comment_start_string": "",
            "comment_end_string": "",
            "template_vars": {},
            "convert_data": False
        }
    }

# Generated at 2022-06-25 11:22:31.274786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['./some_template.j2']
    variables = dict()
    kwargs = {'convert_data': True, 'template_vars': {}, 'jinja2_native': False, 'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': '[#', 'comment_end_string': '#]'}

    try:
        result = lookup_module_0.run(terms, variables, **kwargs)
    except Exception:
        pass

# Generated at 2022-06-25 11:22:37.823221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # single terms
    terms = ['test_single_term.j2']

    # create Lookup module object
    lookup_module_1 = LookupModule()

    # run the test
    try:
        result = lookup_module_1.run(terms, {}, plugin_dir_vars=dir(LookupModule))
    except Exception as e:
        print('Error %s' % repr(e))
        return False

    # validate the result
    if result[0] == 'This is a test template for lookup module'\
        and len(result) == 1:
        return True
    else:
        return False


# Generated at 2022-06-25 11:22:43.575618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = {'_terms':['foo.j2'], 'variable_end_string':'}}', 'variable_start_string':'{{', 'template_vars':{}, 'comment_start_string':None, 'comment_end_string':None, 'convert_data':True}
    lookup_module_0 = LookupModule()
    res_0 = lookup_module_0.run(**args_0)
    assert res_0 == None


# Generated at 2022-06-25 11:22:47.092291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:23:34.154090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    bool_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, bool_0)
    byte_str_0 = ''
    byte_str_1 = ''
    byte_str_2 = ''
    byte_str_3 = ''
    byte_str_4 = ''
    byte_str_5 = ''
    byte_str_6 = ''
    byte_str_7 = ''
    byte_str_8 = ''
    byte_str_9 = ''
    byte_str_10 = ''
    byte_str_11 = ''
    byte_str_12 = ''
    byte_str_13 = ''
    byte_str_14 = ''
    byte_str_15 = ''

# Generated at 2022-06-25 11:23:41.294084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'8\x9d\xb6\x9e\xf6\x82#\x8e \xc7\x9c\x0b4f'
    bytes_1 = b"\xea\xbb\x17\xa8\xae\xbe\x9b\x04\x92\xa1\x1d\xdc\x14\x80\xf2\x93\x95\xf9\xd8\x95\x13\xf0~\x90\x00\xe7\x1a\xda\xc9\xd8\x0b\xd6\xb6\xfd\xae\x12\xe6\xdb\xd5h\xc4\x06\x07\x0b\xa3\x14j"

# Generated at 2022-06-25 11:23:48.023496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b"\n`^\x13\xb7\x85\xcb\x9a\x1a\xf2\xc1"
    bool_0 = False
    str_0 = 'd\x9b\xbf\xfb\xc0\xca\xf8\x17\x16'
    bytes_1 = b"\xdf\x90\xd4\xc2+\xc8\x96\xe1\x15|\x0c\x9e0\x17\xb5\x1d\xec\xe5\x8f\xfe"
    bytes_2 = b'\xcc\x1c\x93\xd0\x87$\x96"\x91\xfa\xfe'

# Generated at 2022-06-25 11:23:50.645047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = list()
    variables = dict()
    bool_0 = bool()
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms, variables, _boolean_0=bool_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:57.004475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'8\x9d\xb6\x9e\xf6\x82#\x8e \xc7\x9c\x0b4f'
    bytes_1 = b'\x10x\x05\x1a\xe8\x9d\xcf\xd0_\x94\x03\xaf'
    lookup_module_0 = LookupModule()
    bool_0 = False
    result = lookup_module_0.run(bytes_0, bytes_1, bool_0)
    assert result is not None


# Generated at 2022-06-25 11:24:02.797019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False

# Generated at 2022-06-25 11:24:10.812988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    terms_0 = None
    variables_0 = None
    kwargs_0 = {str(): None}
    ret = lookup_module_run_0.run(terms_0, variables_0, **kwargs_0)
    assert type(ret) == list
    assert ret is not None


if __name__ == "__main__":
    import unit
    import sys
    unit.run_tests(globals())
    if len(sys.argv) > 1:
        exec(sys.argv[1])

# Generated at 2022-06-25 11:24:19.407014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with boolean var_0 as input
    var_0 = False
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    assert not var_1
    
    # Test with list var_0 as input
    var_0 = [4, 5, 1, 7]
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == [4, 5, 1, 7]


# Generated at 2022-06-25 11:24:24.480023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = os.walk()
    var_1 = os.walk()
    var_2 = os.walk()
    var_3 = os.walk()
    var_4 = os.walk()
    var_5 = os.walk()
    var_6 = os.walk()
    var_7 = os.walk()
    var_8 = os.walk()
    var_9 = os.walk()
    var_10 = os.walk()
    var_11 = os.walk()
    var_12 = os.walk()
    var_13 = os.walk()
    var_14 = os.walk()
    var_15 = os.walk()
    var_16 = os.walk()
    var_17 = os.walk()
    var_18 = os.walk()
    var_19 = os.walk()

# Generated at 2022-06-25 11:24:34.991561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bool_1 = True
    float_0 = float(0.675)
    float_1 = float(0.675)
    float_2 = float(0.675)
    float_3 = float(0.675)
    float_4 = float(0.675)
    int_0 = int(22)
    int_1 = int(22)
    int_2 = int(22)
    int_3 = int(22)
    int_4 = int(22)
    int_5 = int(22)

# Generated at 2022-06-25 11:26:35.655313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

'''
    # Perform all tests
    result = True
    for test in tests:
        print("--------------------------")
        print("Running test: %s" % test.__name__)
        print("--------------------------")
        if test():
            print("Test '%s' OK" % test.__name__)
        else:
            print("Test '%s' FAILED" % test.__name__)
            result = False
    print("==========================")
    print("Result: %s" % ("OK" if result else "FAILED"))
    print("==========================")
'''

# Generated at 2022-06-25 11:26:37.174296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True

# Generated at 2022-06-25 11:26:41.512684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # bytes_0 is test case for method run of class LookupModule
    bytes_0 = b'8\x9d\xb6\x9e\xf6\x82#\x8e \xc7\x9c\x0b4f'
    bool_0 = False
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bytes_0, bool_0)

# Generated at 2022-06-25 11:26:49.305461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar_0 = Templar()
    terms_0 = list_generate(str, 'bWV0YS5kYXRh', 'ZGVmYXVsdA==')
    kwargs_0 = dict_generate(str, str, 'YXV0aG9y', 'TWljaGFlbCBEZWhhYW4=', 'ZGVzY3JpcHRpb24=', 'cmV0dXJuIGxpc3Qgb2Ygc3RyaW5ncw==')
    var_0 = templar_0.run(terms_0, kwargs_0)
    assert isinstance(var_0, list)

# unit test for method set_options of class LookupModule

# Generated at 2022-06-25 11:26:56.404123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'8\x9d\xb6\x9e\xf6\x82#\x8e \xc7\x9c\x0b4f'
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.run(bytes_0, bool_0)
