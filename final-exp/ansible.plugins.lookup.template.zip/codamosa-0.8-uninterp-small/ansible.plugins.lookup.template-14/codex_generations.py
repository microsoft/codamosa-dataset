

# Generated at 2022-06-25 11:17:08.804602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test cases for the run method of class LookupModule"""

    lookup_module_0 = LookupModule()

    # Case 0:
    #  ('data/ansible/plugins/lookup/template.j2',
    #   {'ansible_search_path':
    #       [u'/home/user/code/ansible/ansible/test/integration/targets/template']},
    #   {'convert_data': False, 'template_vars': {'name': 'Peter'}})
    # Expected Result:
    #  [u'Hello Peter!\n']
    test_case_0_terms_0 = 'data/ansible/plugins/lookup/template.j2'

# Generated at 2022-06-25 11:17:16.808395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils._text import to_bytes, to_text

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)


# Generated at 2022-06-25 11:17:22.172558
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    assert type(lookup_module_1) == ansible.plugins.lookup.LookupModule


# Generated at 2022-06-25 11:17:26.916435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  # your test methods
  assert lookup_module_0.run("./some_template.j2", variables, None) == ret
  # assert lookup_module_0.run("./some_template.j2", variables, None) != ret

# Generated at 2022-06-25 11:17:35.764604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Init vars
    terms_0 = ['4.4.4.4']
    variables_0 = dict()
    kwargs_0 = {'convert_data': False, 'template_vars': {}, 'jinja2_native': False, 'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': None, 'comment_end_string': None}
    # Run test
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:17:36.640541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:17:44.649939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(object())
    empty_list_0 = []
    empty_list_1 = []
    template_data_0 = "{{ var_name0 }}"
    empty_str_0 = ""
    empty_dict_0 = {}
    lookup_module_0.set_options(var_options=empty_dict_0, direct=empty_dict_0)
    result = lookup_module_0.run(empty_list_0, empty_dict_0)
    assert result == empty_list_1

# Generated at 2022-06-25 11:17:45.731271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    isinstance(test_LookupModule_run, str)


# Generated at 2022-06-25 11:17:57.290336
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    '''
    Test function for method lookup_module.run
    '''

    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)

    terms = [u'../../../../../../../etc/passwd']


# Generated at 2022-06-25 11:18:07.790560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module_0 = LookupModule()
    terms = ['123', '456']
    variables = {
        'wanted': 'wanted',
        'password': 'password'
    }
    kwargs = {
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'comment_start_string': '#',
        'comment_end_string': '#',
        'convert_data': True,
        'template_vars': {
            'wanted': 'wanted'
        },
        'jinja2_native': False
    }

    # Act
    lookup_module_0.run(terms, variables, **kwargs)

    # Assert

# Generated at 2022-06-25 11:18:19.490239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = { }
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    template_vars_0 = { }
    var_0 = lookup_module_0.run(str_0, float_0,
                                template_vars=template_vars_0)
    assert var_0 is None


# Generated at 2022-06-25 11:18:28.296787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'm'
    float_0 = 0.0001
    lookup_module_0 = LookupModule(**dict_0)
    var_0 = lookup_run(str_0, float_0)
    assert var_0 is None
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'u'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    assert var_0 is None
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 't'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    assert var_0 is not None
   

# Generated at 2022-06-25 11:18:32.958299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)

    # It is believed that there is a bug in the implementation for this function
    # (as of Ansible 2.5.5).
    # It is believed that the following line should not be here and instead it
    # should return None as there is no return statement within the function.
    #   return None
    #   ^^^^^^^^^^^

    # Adapted from Ansible 2.5.5:ansible/plugins/lookup/template.py:LookupModule.run
    if False:
        pass
    else:
        None

    assert False, "An error occurred while attempting to run the unit test."

# Generated at 2022-06-25 11:18:44.009044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test params
    terms = [
        "./some_template.j2"
    ]
    variables = {}
    kwargs = {
        "convert_data": False,
        "variable_start_string": '[%',
        "variable_end_string": '%]',
        "comment_start_string": '[#',
        "comment_end_string": '#]',
        "jinja2_native": False,
        "template_vars": {}
    }

    # Test routine
    LookupModule.run(terms, variables, **kwargs)


if __name__ == '__main__':
    # test_LookupModule_run()
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_

# Generated at 2022-06-25 11:18:46.009222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = lookup_run()
# Test with /home/atom/ansible/lib/ansible/plugins/lookup/template.py

# Generated at 2022-06-25 11:18:47.854277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)

# Generated at 2022-06-25 11:18:58.528883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = ModuleStub(**{'params': {'lookup_values': 'lookup_values', 'lookup_vars': {'lookup_vars': 'lookup_vars'}}, 'fail_json': 'fail_json', 'vars': {'vars': 'vars'}, '_load_params': '_load_params'})
    list_0 = ['list_0', 'list_0']

    # Invoke method
    result = module_0._run(list_0)
    assert (result != None)


# Generated at 2022-06-25 11:19:07.016225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)

    # Run method of class LookupModule and check for expected results
    str_0 = 'o;'
    float_0 = 0.0001
    ret = lookup_module_0.run(str_0, float_0)
    assert "lookup module" in ret[0].lower()


if __name__ == '__main__':
    import os
    import pytest
    pytest.main([os.path.join(os.path.dirname(__file__), '../lib/ansible/modules/utilities/logic/template.py'), '-s'])

# Generated at 2022-06-25 11:19:17.704663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment, USE_JINJA2_NATIVE
    from ansible.utils.display import Display
    display = Display()
    ret = []
    convert_data_p = self.get_option('convert_data')
    lookup_template_vars = self.get_option('template_vars')
    jinja2_native = self.get_option('jinja2_native')
    variable_start_string = self.get_option('variable_start_string')
    variable_end_string = self.get_option('variable_end_string')
    term = 't_value'
    display.debug("File lookup term: %s" % term)
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module

# Generated at 2022-06-25 11:19:22.114667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    list_0 = lookup_run(str_0, float_0)

# Generated at 2022-06-25 11:19:36.400968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'o;' in test_case_0()

# Unit test

# Generated at 2022-06-25 11:19:44.340735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'debug': False,
        'ok': True,
        'no_log': False,
        '_diff': False,
        '_ansible_check_mode': False,
        '_ansible_diff': True,
        'remote_addr': '',
        '_ansible_verbosity': 2,
        '_ansible_no_log': False,
        '_ansible_debug': False,
        'action': 'debug',
        '_ansible_module_name': 'debug',
        'msg': '',
        '_ansible_module_created': True,
        'invocation': {
            'module_args': ''
        }
    }
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float

# Generated at 2022-06-25 11:19:51.697859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    dict_0 = {}
    dict_0 = {}
    bool_0 = False
    dict_0 = {'template_vars': dict_0, 'convert_data': bool_0}
    var_0 = lookup_module_run(dict_0, str_0, float_0)

# Generated at 2022-06-25 11:19:56.500808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = []
    dict_1 = {}
    var_0 = lookup_module_0.run(list_0, dict_1)
    assert len(var_0) == 0

# Generated at 2022-06-25 11:20:01.792211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    assert var_0 == 'o;'


# Generated at 2022-06-25 11:20:05.435608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_module_run(str_0, float_0)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:20:09.759452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        try:
            lookup_module_0.run(None, None)
        except AnsibleError:
            pass
    except LookupError:
        return False
    return True


# Generated at 2022-06-25 11:20:16.904375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    result_0 = lookup_module_0.run(str_0, float_0)
    assert result_0 == []


# Generated at 2022-06-25 11:20:23.885110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    # AssertionError: run returned:
    #              []
    #        but expected:
    #              ['o']
    assert var_0 == ['o']

# Generated at 2022-06-25 11:20:27.785584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  dict_0 = {}
  lookup_module_0 = LookupModule(**dict_0)
  str_0 = 'o;'
  float_0 = 0.0001
  var_0 = lookup_run(str_0, float_0)
  assert len(var_0) == 1
  assert var_0[0] == 'o;'


# Generated at 2022-06-25 11:20:47.857408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Nothing to do here!
    return None

# Generated at 2022-06-25 11:20:49.506414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arg0 = 'o;'
    arg1 = 0.0001
    with pytest.raises(AnsibleError):
        result = LookupModule.run(arg0, arg1)

# Generated at 2022-06-25 11:20:56.202385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = []
    dict_1 = {}
    str_0 = lookup_module_0.run(list_0, dict_1)
    assert str_0 == None

# Generated at 2022-06-25 11:21:02.889861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_module_run(str_0, float_0)

# Generated at 2022-06-25 11:21:06.546757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)

# Generated at 2022-06-25 11:21:09.533670
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_module_0.run(str_0, float_0)

# Generated at 2022-06-25 11:21:17.389874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    var_1 = 1.5
    lookup_module_0 = LookupModule(var_0, var_1)
    var_2 = 'j'
    var_3 = 1.31
    var_4 = {}
    var_5 = lookup_module_0.run(var_2, var_3, var_4)

# Generated at 2022-06-25 11:21:22.215335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    assert var_0[0] == '{{\n  lookup_file.files(files=\'o;\', first_file=True) \n  }}'
    # '['hello']'

# Generated at 2022-06-25 11:21:27.824258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 0
    # Test case 0
    lookup_module_0 = test_case_0()
    # Set up Dummy
    lookup_module_0.run()


# Generated at 2022-06-25 11:21:30.442674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)

test_case_0()

# Generated at 2022-06-25 11:22:20.581588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:22:21.989559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    assert x.run('', '') is None

# Generated at 2022-06-25 11:22:27.909398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # In 0.0, no attribute ansible_host_vars_from_group_vars
    lookup_module_1 = LookupModule(**dict_0)
    str_1 = 'o;'
    float_1 = 0.0001
    assert lookup_module_1.run(str_1, float_1) == var_0


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:22:37.479226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    temp_0 = (('', 0),)
    temp_1 = (('', 0),)
    temp_2 = (('', 0),)
    temp_3 = (('', 0),)
    temp_4 = (('', 0),)
    temp_5 = (('', 0),)
    temp_6 = (('', 0),)
    temp_7 = (('', 0),)
    temp_8 = (('', 0),)
    temp_9 = (('', 0),)
    temp_10 = (('', 0),)

# Generated at 2022-06-25 11:22:46.420642
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = lookup_module_0.run()

    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    variables_0 = lookup_module_0.run()

    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = lookup_module_0.run()

    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    variables_0 = lookup_module_0.run()

    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = lookup_module_0.run()

    dict_0 = {}
    lookup

# Generated at 2022-06-25 11:22:55.918295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = './h_0.txt'
    list_0 = [str_0]
    dict_1 = {}
    list_1 = lookup_module_0.run(list_0, dict_1)
    str_1 = 'File lookup term: ./h_0.txt'
    str_2 = 'o;'
    str_3 = 'File lookup using ./h_0.txt as file'
    __tracebackhide__ = True
    str_4 = './h_0.txt could not be found for the lookup'
    assert list_1 == [str_2], "assertion 'list_1 == [str_2]' failed"
    #assert list_0 == [str_1], "assertion 'list

# Generated at 2022-06-25 11:23:02.894549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    assert lookup_module_0.run(str_0, float_0) == [None]

# Generated at 2022-06-25 11:23:14.205225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    str_0 = 'o;'
    float_0 = 0.0001
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    str_1 = 'o;'
    float_1 = 0.0001

    # Method run called as lookup_run(terms, variables)
    # 1st parameter is an str
    # 2nd parameter is a float
    # re_0 = re.search('^{{', lookup_module_0._templar.environment.variable_start_string, re.I)

    # Test for return type
    assert isinstance(lookup_module_0.run(str_0, float_0), list)



# Generated at 2022-06-25 11:23:21.593000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_path = os.path.realpath(__file__)
    file_dir = os.path.dirname(file_path)
    lookup_module = LookupModule()
    results = lookup_module.run(["test_assets/file0.txt"], {"playbook_dir": file_dir})
    assert(results == ['First file\n'])
    results = lookup_module.run(["test_assets/nonexistent.txt"], {"playbook_dir": file_dir})
    assert(results == [])
    lookup_module = LookupModule(**{"_context": {"variable_start_string": "{%", "variable_end_string": "%}"}})
    results = lookup_module.run(["test_assets/file1.txt"], {"playbook_dir": file_dir})

# Generated at 2022-06-25 11:23:32.105702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_module_0.run(str_0, float_0)
    str_1 = 'a'
    var_1 = lookup_module_0.run(str_1, float_0, convert_data=bool_0)
    dict_1 = {'template_vars': dict_0}
    var_2 = lookup_module_0.run(str_1, float_0, **dict_1)
    dict_2 = {'convert_data': bool_0, 'template_vars': dict_0}

# Generated at 2022-06-25 11:25:30.129355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'h_9ehHW.q#`T[TkDw_'
    float_0 = 0.009106201103355573
    list_0 = ['l7R_J/`>+7|', '{{password}}']
    dict_1 = {'N(^dav': '{{credentials}}'}
    str_1 = lookup_module_0.run(list_0, dict_1)
    print(str_1)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:25:34.385127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_2['lookup_template_vars'] = dict_5
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_9['_terms'] = dict_8
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_16['ansible_job_id'] = dict_0
    dict_16['ansible_pid'] = dict_0


# Generated at 2022-06-25 11:25:42.088055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list'),
            convert_data=dict(type='bool', default=True),
            variable_start_string=dict(type='str', default='{{'),
            variable_end_string=dict(type='str', default='}}'),
        ),
        supports_check_mode=True,
    )

    lookup_instance = LookupModule()
    lookup_instance.set_loader(module._loader)
    lookup_instance._templar = Templar(loader=module._loader, variables=module.params)
    lookup_instance.set_options(var_options=module.params, direct=module.params)

    # sample data
    term_0 = 'template_dir/private_data.j2'

# Generated at 2022-06-25 11:25:52.081254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'a;'
    str_1 = 'template'
    var_0 = {
        'ansible_search_path': 'ansible_search_path',
        'template_mtime': 'template_mtime',
        'template_host': 'template_host',
        'template_uid': 'template_uid',
        'template_path': 'template_path',
        'template_fullpath': 'template_fullpath',
        'template_run_date': 'template_run_date',
        'template_encoding': 'template_encoding'
    }
    var_0 = lookup_module_0.run(str_0, str_1, var_0)
    print(var_0)


# Generated at 2022-06-25 11:25:53.736549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()



# Generated at 2022-06-25 11:25:57.608639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'LookupBase': {
            'run': '<function test_LookupModule_run.<locals>.<lambda> at 0x1010fc2f0>',
        },
    }
    lookup_module_0 = LookupModule(**dict_0)
    float_0 = 0.00031

# Generated at 2022-06-25 11:26:01.163448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    #assert lookup_module_0.run(str_0, float_0) == var_0
    assert True


# Generated at 2022-06-25 11:26:03.589181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'o;'
    float_0 = 0.0001
    var_0 = lookup_run(str_0, float_0)
    assert var_0 == []

# Generated at 2022-06-25 11:26:06.335201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'l;'
    float_0 = 0.0001
    var_0 = LookupModule.run(str_0, float_0)


# Generated at 2022-06-25 11:26:10.061190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if True:
        lookup_module_0 = LookupModule(**{})
        str_0 = 'o;'
        float_0 = 0.0001
        var_0 = lookup_module_0.run(str_0, float_0)

if __name__ == '__main__':
    test_LookupModule_run()