

# Generated at 2022-06-25 11:17:04.424457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	assert True

# Generated at 2022-06-25 11:17:06.990222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert 1 == 1


# Generated at 2022-06-25 11:17:15.235917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '/usr/share/ansible/docs/docsite/rst/lookup_plugins/template.rst'
    variables_0 = {'ansible_check_mode': False, 'ansible_module_generated': True, 'ansible_version': {'full': '2.9.11', 'version': '2.9', 'date': '2019-08-13', 'revision': 0}, 'module_setup': True, 'group_names': u'all', 'ansible_fact_distribution_version': u'14.04', 'ansible_module_name': u'setup', 'ansible_module_args': {u'foo': u'bar'}, 'ansible_distribution_major_version': u'14.04'}

# Generated at 2022-06-25 11:17:21.636735
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:17:28.504638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['../templates/test_template.j2']
    variables_0 = {'ansible_search_path': ['../templates']}
    res = lookup_module_0.run(terms_0, variables_0, convert_data=False, jinja2_native=True)
    assert res[0] == "{{ test }}\n"
    assert res[0] is not None

# Generated at 2022-06-25 11:17:41.204557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # print(lookup_module_0.run(['./some_template.j2'], but very little content is detected as such.  For example, a variable name such as C(foo_port) will be considered to be a variable instead of a hash entry with key C(port).  For anything beyond trivial usage, it is recommended that the template be stored in a file and the `template` lookup be used instead.
#      required: False
#      default: None
#      aliases: []
#    jinja2_native:
#      description:
#      - Controls whether to use Jinja2 native types.
#      - It is off by default even if global jinja2_native is True.
#      - Has no effect if global jinja2_native is False.
#      - This offers more flexibility

# Generated at 2022-06-25 11:17:42.985833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=None, variables=None, **kwargs) == None


# Generated at 2022-06-25 11:17:50.072653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    h = open('LookupModule_run_expected_result')
    expected_result = h.read()
    lookup_module_0 = LookupModule()
    args = ['/path/to/file1.j2', '/path/to/file2.j2']
    args_kwargs_idx_1 = dict()
    result = lookup_module_0.run(args, args_kwargs_idx_1)
    assert result == expected_result

# Generated at 2022-06-25 11:17:58.724913
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    yaml_data = '''
    data:
      - name: one
      - name: two
      - name: three
    '''
    yaml_data_text = to_text(yaml_data)

    lookup_module = LookupModule()

    search_path_data = '''
    common_data:
      - name: one
    '''
    search_path_data_text = to_text(search_path_data)

    search_path = ['/data']

    templar = lookup_module._templar

    ret = lookup_module.run(terms=['test_template.j2'], variables={'search_path': search_path})

# Generated at 2022-06-25 11:18:07.637324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module.set_loader(None)
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module.set_options({})

    search_paths = ['/project/templates', '/project', '/']
    variables = {'ansible_search_path': search_paths, 'key1': 'val1', 'key2': 'val2'}
    terms = ['/project/templates/service1.j2']
    ret = lookup_module.run(terms, variables, convert_data=True)
    assert ret == ['\nservice1 val1\n']

# Generated at 2022-06-25 11:18:13.761519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:18:22.765712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    int_0 = len(set_0)
    dict_0 = dict()
    dict_0['convert_data'] = False
    dict_0['jinja2_native'] = False
    dict_0['variable_start_string'] = '{{'
    dict_0['variable_end_string'] = '}}'
    dict_0['comment_start_string'] = None
    dict_0['comment_end_string'] = None
    dict_0['template_vars'] = dict()
    dict_0['_terms'] = [1,11]
    dict_0['template_vars']['hostvars'] = dict()
    dict_0['template_vars']['hostvars']['inventory_hostname']

# Generated at 2022-06-25 11:18:33.306005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'y0gac2tD5'
    str_1 = '\aV'
    str_2 = '`^(>y\tV|o'
    str_3 = '$|D'
    str_4 = '{l'
    str_5 = 'e'
    str_6 = ':I}8-6c%'
    str_7 = '9X'
    str_8 = 'l'
    str_9 = '_<'
    str_10 = 'f'
    str_11 = '1TJN'
    str_12 = '@!|'
    str_13 = '#'
    str_14 = '%F'
    str_15 = '=&'
    str_16 = '*'
    str_17 = 'a'


# Generated at 2022-06-25 11:18:44.360559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0()


# from ansible.template import generate_ansible_template_vars
# from ansible.utils.display import Display
# from ansible.plugins.lookup import LookupBase
#
# display = Display()
#
# class LookupModule(LookupBase):
#
#     def run(self, terms, variables=None, **kwargs):
#         self.set_options(direct=kwargs)
#         return [generate_ansible_template_vars(term, terms[0]) for term in terms]
#
#     def test(self, terms, variables=None, **kwargs):
#         self.set_options(direct=kwargs)
#         return True
#
#     def __getitem__(self, key):
#         return key
#
#     def __

# Generated at 2022-06-25 11:18:49.190746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'limit'
    str_1 = 'mf6A*W\x0c'
    str_2 = '&/`qh<i!Ip{Mb'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_1}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0, str_1)

# Test case for method find_file_in_search_path of class LookupModule

# Generated at 2022-06-25 11:18:51.868200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'a': 'a', 'b': 'b', }
    lookup_module_0 = LookupModule()
    str_0 = 'b'
    var_0 = lookup_run(dict_0, str_0)

# Generated at 2022-06-25 11:18:58.685567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'limit'
    str_1 = 'mf6A*W\x0c'
    str_2 = '&/`qh<i!Ip{Mb'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_1}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0, str_1)


# Generated at 2022-06-25 11:19:05.043608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    terms = [
        './file_0.tpl',
        './file_1.tpl'
    ]
    variables = {
        'file_0.1': 'file_0.1',
        'file_1.1': 'file_1.1',
        'file_1.2': 'file_1.2',
        'file_1.3': 'file_1.3'
    }
    _loader = None
    _templar = None
    lookup_module_0 = LookupModule(_loader=_loader, _templar=_templar)

# Generated at 2022-06-25 11:19:08.025972
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # key is the 'terms' argument, value is the expected result
    test_cases = {
        'limit': 'mf6A*W\x0c',
        'mf6A*W\x0c': 'limit',
        '&/`qh<i!Ip{Mb': 'mf6A*W\x0c',
    }

    for key, expected_value in test_cases.items():
        lookup_module = LookupModule()
        assert lookup_module.run({'lookup_test_key': key}, 'lookup_test_key') == expected_value

# Generated at 2022-06-25 11:19:16.210265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'limit'
    str_1 = 'mf6A*W\x0c'
    str_2 = '&/`qh<i!Ip{Mb'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_1}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0, str_1)
    assert var_0 == [], "run returned unexpected output"



# Generated at 2022-06-25 11:19:32.988872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["ansible.cfg"]
    variables = {}
    lookup_module_0 = LookupModule()
    lookup_module_1 = lookup_module_0.run(terms, variables, convert_data=False, comment_end_string='"')

# Generated at 2022-06-25 11:19:43.529682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    str_0 = ''
    str_1 = '8x'
    str_2 = '}b0iu'
    str_3 = '7'
    str_4 = 'Y,L'
    str_5 = 'N9~'
    str_6 = 'd'
    str_7 = 'jKL'
    str_8 = 'fXQK'
    str_9 = '1~'
    str_10 = '>`'
    str_11 = '\x1c'
    str_12 = '|'
    str_13 = '!'
    list_0 = [str_11, str_12, str_13, str_4, str_0, str_10, str_2, str_8, str_9]

# Generated at 2022-06-25 11:19:50.788117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 1:
    str_0 = 'limit'
    str_1 = 'mf6A*W\x0c'
    str_2 = '&/`qh<i!Ip{Mb'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_1}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0, str_1)

# Generated at 2022-06-25 11:20:02.054660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'p-\x14\x1dd>'
    str_1 = '\x03TM'
    dict_1 = {str_0: str_0, str_1: str_1}
    str_2 = 'Y#'
    str_3 = '\x7f'
    dict_0 = {str_3: str_3, str_2: str_1}
    lookupModule_0 = LookupModule()
    lookupModule_0.set_loader(dict_1)
    lookupModule_0.set_basedir(dict_1)
    lookupModule_0.set_templar(dict_1)
    lookupModule_0.run(dict_1, dict_0)
    dict_2 = dict_0
    dict_2['variable_start_string'] = dict_1


# Generated at 2022-06-25 11:20:10.874077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 'template'
    str_0 = ''
    str_1 = '|&KQWJe'
    str_2 = 'G#_\x13n'
    str_3 = 'exR]vNj|Sz8'
    str_4 = 'eY}/'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: dict_0, str_1: dict_0, str_2: dict_0, str_3: dict_0, str_4: dict_0}
    dict_1 = {str_0: dict_0, str_1: dict_0, str_2: dict_1, str_3: dict_0, str_4: dict_0}

# Generated at 2022-06-25 11:20:20.311670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    fname = 'file_0.txt'
    var_0 = open(fname, 'w')
    var_0.write('the content')
    var_0.close()
    var_1 = open(fname, 'w')
    var_1.write('the content')
    var_1.close()
    var_2 = open(fname, 'w')
    var_2.write('the content')
    var_2.close()
    dict_0 = {'file0': var_0, 'file1': var_1, 'file2': var_2}
    var_3 = lookup_run(dict_0, 'file0')
    os.remove(fname)
    os.remove(fname)
    os.remove(fname)


# Generated at 2022-06-25 11:20:25.879706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:20:35.278559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'limit'
    str_1 = 'mf6A*W\x0c'
    str_2 = '&/`qh<i!Ip{Mb'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_1}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:20:35.931832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True


# Generated at 2022-06-25 11:20:43.419118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'limit'
    str_1 = 'mf6A*W\x0c'
    str_2 = '&/`qh<i!Ip{Mb'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_1}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(dict_0, str_1)
    print("var_0: " + str(var_0))



# Generated at 2022-06-25 11:21:09.643706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = to_bytes("f_o_o", errors="surrogate_or_strict")
    dict_0 = {'foo': str_0}
    var_0 = lookup_run(dict_0, to_bytes("myvar={{ foo }}"))
    assert var_0 == "myvar={}".format(str_0)
    var_1 = lookup_run(dict_0, to_bytes("myvar={{ foo }"))
    assert var_1 == "myvar={{ foo }}"



# Generated at 2022-06-25 11:21:17.081212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    str_0 = '4:+zXm'
    str_1 = 'yL}v/'
    list_0 = [str_0, str_1]
    # assert lookup_module_0.run(list_0, dict_0, ) == list_0


# Generated at 2022-06-25 11:21:28.592956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Run tests for module template
    variable_start_string_0 = '{{'
    variable_start_string_1 = '{{'
    variable_end_string_0 = '}}'
    variable_end_string_1 = '}}'
    terms_0 = '__a'
    terms_1 = '__a'
    convert_data_p_0 = None
    convert_data_p_1 = None
    template_vars_0 = {}
    template_vars_1 = {}
    comment_start_string_0 = '{#'
    comment_start_string_1 = '{#'
    comment_end_string_0 = '#}'
    comment_end_string_1 = '#}'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_

# Generated at 2022-06-25 11:21:30.019419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0



# Generated at 2022-06-25 11:21:39.233241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_data = 'EaZk"N'
    test_variable_data = 'Y/w^.i\r'
    test_variable_data_0 = 'u}Gp^*>'
    test_variable_data_1 = '@jF&h\x0e'
    test_variable_data_2 = ':_hT|1=T'
    test_variable_data_3 = '7f@M^\x7f|'
    test_variable_data_4 = 'gxnk\x1c%'
    test_variable_data_5 = '\x15:b)Tl'
    test_variable_data_6 = 'Z-d)a2?'
    test_variable_data_7 = 'Y`E`0o.'
    test_variable_data_8

# Generated at 2022-06-25 11:21:48.993228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.template import generate_ansible_template_vars
  from ansible.template import USE_JINJA2_NATIVE
  from ansible.module_utils._text import to_text
  from ansible.plugins.lookup import LookupBase
  from ansible.template import AnsibleEnvironment
  from ansible.module_utils._text import to_bytes
  import os
  import copy
  import ansible.utils.native_jinja
  import ansible.utils.display
  import ansible.template
  import ansible.errors
  import ansible.utils.native_jinja
  import ansible.utils.display
  import ansible.template
  import ansible.errors
  str_0 = 'limit'
  str_1 = 'mf6A*W\x0c'

# Generated at 2022-06-25 11:22:00.043879
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    str_0 = 'Nq\x14"V'
    str_1 = '&znu\x1c@\x0f?I'
    str_2 = 'U^2\x17\x06\x1b5'
    str_3 = '\x14\x13\x0b\x16\x1c\x05'
    str_4 = 'P\x15\x06\x1c'
    str_5 = 'C\x11\x05\x12\x1d'
    str_6 = '|\x1f\x03\x01\x1c\x12\x1d\x1a\x1a\x0e'

# Generated at 2022-06-25 11:22:09.966260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '2\x15\x0b\x0c\x1dH\x14\x0e'
    dict_0 = {str_0: '3\x1f\x1f\x0c\x06\x1c\x12\x0e'}
    str_1 = 'Z"\x1d8W\x1f\x18\x0f\x13\x12\x14\x10\t'
    str_2 = '*>X\x11\x1e'
    dict_1 = {str_1: '\x04\x0f\x0c\x1c\x1f)\x13\x0e', str_2: str_2}
    str_3 = 'h3X&%'

# Generated at 2022-06-25 11:22:17.264159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['_terms'] = './files/test_fixtures/b.j2'
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(dict_0, dict())
    assert result == ['baz']


# Generated at 2022-06-25 11:22:25.425275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_options = [{'_terms': ['ansible']}]

# Generated at 2022-06-25 11:23:11.409414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    sub_class_jM5J = LookupModule()
    # Variables for test_LookupModulerun_0
    str_1 = '#K`l5;hS5_7$'
    sub_class_jM5J.run(terms=[str_1])


# Generated at 2022-06-25 11:23:17.250329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    param_0 = 'limit'
    param_1 = 'mf6A*W\x0c'
    param_2 = '&/`qh<i!Ip{Mb'
    param_3 = {param_0: param_0, param_1: param_0, param_2: param_1}
    var_0 = lookup_module_0.run(param_3, param_1)



# Generated at 2022-06-25 11:23:27.185399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Python 2.7.15
    from ansible.plugins.lookup import LookupModule
    lookup_module_0 = LookupModule()
    arr_0 = []
    str_0 = 'XJ)O>N%'
    arr_0.append(str_0)
    str_1 = 'H]95r'
    str_2 = 'uT'
    str_3 = 'aU1)6'
    str_4 = 'I'
    dict_0 = {str_1: str_2, str_3: str_4}
    var_0 = lookup_run(dict_0, arr_0)

# Generated at 2022-06-25 11:23:35.659726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # str_0 is an argument of lookup_run
    str_0 = 'V8lKx5i5Q7'
    # str_1 is an argument of lookup_run
    str_1 = '6H>m,%(g.\x0bRW\x0b'
    # str_2 is an argument of lookup_run
    str_2 = '&/`qh<i!Ip{Mb'
    # dict_0 is an argument of lookup_run
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_1}
    # lookup_module_0 is an argument of lookup_run
    lookup_module_0 = LookupModule()
    # var_0 is a lookup result from lookup_run
    
    
    
    
    


# Generated at 2022-06-25 11:23:43.053458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'M7p0'
    str_1 = '\x16'
    str_2 = 'u\x1c\x1b8B\x1e'
    str_3 = 't\x7f\x1d\x7f'
    str_4 = '\x1d\x7f'
    str_5 = '`*-x'
    str_6 = '\x7f\x1d\x7f'
    str_7 = '=n\n'
    str_8 = '\x7f\x1d\x7f'
    str_9 = '\x7f\x1d\x7f'
    str_10 = 'O\x7f\x1d\x7f'

# Generated at 2022-06-25 11:23:48.184707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock the lookup base class
    result = LookupModule().run(["1", "2"], ["3", "4"])
    assert result == ["1", "2"]


# Generated at 2022-06-25 11:23:50.183223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-25 11:23:54.959629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'S\t'
    str_1 = 'y\x16'
    str_2 = '\x19\r'
    str_3 = '\x1d\\'
    str_4 = '\x1f3'
    str_5 = '@\x1a'
    str_6 = '~0'
    str_7 = 'q\n'
    str_8 = '\t'
    str_9 = '\x1c'
    str_10 = '\x17'
    str_11 = '\r\x0b'
    str_12 = '\x19'
    str_13 = '\x1a'
    str_14 = '}'
    str_15 = 'C\x1a'

# Generated at 2022-06-25 11:23:56.859826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()
    # No return value expected
    # call run with params
    module_0.run('A[i\x19P|\x08', None)


# Generated at 2022-06-25 11:24:01.449617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'qleI&c0'
    str_1 = 'B\x7f'
    str_2 = 'ZJY'
    str_3 = '=x'
    str_4 = '}'
    str_5 = 'D2'
    str_6 = 'J'
    str_7 = '>1'
    list_0 = [str_4, str_5, str_6, str_7]
    str_8 = '%\x7f'
    str_9 = 'C'

# Generated at 2022-06-25 11:26:10.702024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_0 = 'lG5&2'
    str_1 = '\x0b'
    str_2 = 'z+x;0IDL'
    str_3 = '!dd[Q/k'
    str_4 = '`'
    str_5 = '}N{4$~q'
    str_6 = '!g\x1eVu.\x0b'
    str_7 = '\x0b\x0f'
    str_8 = '2!P\x0cp'
    str_9 = 'zZv@\x0f'
    str_10 = 'Y\r|'
    str_11 = 'hc%'

# Generated at 2022-06-25 11:26:20.959997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = {}
    var_5 = []
    var_6 = []
    var_7 = []
    var_8 = []
    var_9 = {}
    var_10 = []
    var_11 = {}
    var_12 = []
    var_13 = []
    var_14 = []
    var_15 = []
    var_16 = []
    var_17 = []
    var_18 = []
    var_19 = []
    var_20 = {}
    var_21 = {}
    var_22 = {}
    var_23 = {}
    var_24 = {}
    var_25 = {}

# Generated at 2022-06-25 11:26:27.346295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '/}i8]\x0c'
    var_0 = variables(term_0, 'w1;\x0b')
    var_1 = lookup_module_0.run(var_0, term_0, 'test_case_0')


# Generated at 2022-06-25 11:26:32.368623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'GMcK\x0b'
    var_5 = 0
    var_6 = 0
    str_1 = 'w,n&>\x0b'
    int_0 = 0
    str_2 = '6j\x0b'
    var_7 = 0
    var_8 = 0
    list_0 = [var_8, str_2, var_7, var_6, var_5]
    dict_0 = {str_0: int_0, str_1: list_0}
    lookup_module_0 = LookupModule()
    int_1 = lookup_module_0.run(dict_0, int_0)


# Generated at 2022-06-25 11:26:38.450225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule()
    # print 'Unit test for method run of class LookupModule'
    var_0 = lookup_module_0.run(keywords, dict_0)


# Generated at 2022-06-25 11:26:49.487489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'lookup_template_vars': {}, 'variable_start_string': '{{', 'template_vars': {}, 'convert_data': True, 'jinja2_native': False, 'comment_start_string': '{#', 'variable_end_string': '}}', 'comment_end_string': '#}'}
    str_0 = 'limit'
    str_1 = 'mf6A*W\x0c'
    str_2 = '&/`qh<i!Ip{Mb'
    list_0 = [str_0, str_0, str_0]
    list_1 = [str_0, str_1, str_2]

# Generated at 2022-06-25 11:26:57.223824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '~+vBV@0'
    str_1 = 'uIX^Dy\x0b'
    str_2 = 'fA?`\x0c,xh;'
    str_3 = ')m'
    assert lookup_module_0.run(str_1, str_3, variable_start_string=str_0, variable_end_string=str_2)