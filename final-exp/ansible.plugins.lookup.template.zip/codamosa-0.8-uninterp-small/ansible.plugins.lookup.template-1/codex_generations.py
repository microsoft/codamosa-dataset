

# Generated at 2022-06-25 11:17:07.074786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of class LookupModule
    """
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([], {}) == []

# Generated at 2022-06-25 11:17:15.298105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # case 0:
    # unknown option
    options_0 = dict(
        _ansible_check_mode=False,
        _ansible_debug=False,
        _ansible_diff=False,
        _ansible_keep_remote_files=False,
        _ansible_no_log=False,
        _ansible_remote_tmp='',
        _ansible_search_path=None,
        _ansible_shell=None,
        _ansible_shell_executable=None,
        _ansible_verbosity=0,
        invoice_file='invoice_file_0'
    )
    terms_0 = ['terms_0_0']
    # var_options = None

# Generated at 2022-06-25 11:17:25.895657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    lookup_module_obj.set_options(direct={'variables':{'a': 1}, 'j0': '','j1': 2,
                                          'j2': False, 'j3': True, 'v': 'some_value'})
    exit_code, res = lookup_module_obj.run(['{{a}}'])
    assert exit_code == 0
    assert res == '1'

    exit_code, res = lookup_module_obj.run(['{{a}}', '{{b}}'])
    assert exit_code == 0
    assert res == '1'

    exit_code, res = lookup_module_obj.run(['{{a}}', '{{b}}', '{{c}}'])
    assert exit_code == 0

# Generated at 2022-06-25 11:17:36.605098
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 0
    lookup_module_0 = LookupModule()
    b_exception = False
    try:
        lookup_module_0.run([], {})
    except Exception as e:
        b_exception = True
    assert b_exception is False

    # test case 1
    lookup_module_1 = LookupModule()
    b_exception = False
    try:
        lookup_module_1.run([], 0)
    except Exception as e:
        b_exception = True
    assert b_exception is False

    # test case 2
    lookup_module_2 = LookupModule()
    b_exception = False
    try:
        lookup_module_2.run([], 0)
    except Exception as e:
        b_exception = True

# Generated at 2022-06-25 11:17:47.696920
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize a file handle to the path where the test cases
    # are stored
    test_case_path = os.path.split(os.path.realpath(__file__))[0] + "/../../../lib/ansible/plugins/lookup/test_cases/";
    test_case_file_path = test_case_path + "test_LookupModule_run";

    with open(test_case_file_path) as test_case_file:
        for line in test_case_file:
            # Read the first parameter from the test case file
            # This parameter is the filename of the test case
            terms = [line.split()[0]]

            # Read the second parameter in test case file
            # This is the destination of the file
            variables = {"template_dir": line.split()[1]}

            #

# Generated at 2022-06-25 11:17:58.833163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Use this to override variables defined by the user
    lookup_module_0._options = { 'convert_data': True, 'template_vars': {}, 'jinja2_native': True}
    lookup_module_0._display = { 'verbosity': 3 }
    lookup_module_0._templar = { 'no_type_regex': '', 'block_end_string': '%}', 'block_start_string': '{%', 'variable_end_string': '}}', 'variable_start_string': '{{'}
    lookup_module_0._loader = { }

    terms_0 = ['test_template.j2']
    variables_0 = { 'ansible_search_path': ['/home/michal/tmp/test_module']}


# Generated at 2022-06-25 11:18:02.936421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert len(lookup_module_1.run(['test_file'], [])) == 1

# Generated at 2022-06-25 11:18:10.581350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._find_file_in_search_path = LookupModule._find_file_in_search_path_test
    lookup_module_0._loader = LookupModule._loader_test
    lookup_module_0.set_options = LookupModule.set_options_test
    lookup_module_0.get_option = LookupModule.get_option_test
    lookup_module_0._templar = LookupModule._templar_test
    lookup_module_0._templar.copy_with_new_env = LookupModule._templar_copy_with_new_env_test
    lookup_module_0._templar.set_temporary_context = LookupModule._templar_set_temporary_context_test
    lookup

# Generated at 2022-06-25 11:18:22.360452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_plugin = LookupModule()
    test_lookup_plugin._loader.module_loader = None
    test_lookup_plugin._loader._templar = None
    test_lookup_plugin._loader.path_finder = None
    test_lookup_plugin._loader._module_cache = None
    test_lookup_plugin._loader._module_cache_time = None
    test_lookup_plugin._loader._module_cache_max_size = None
    test_lookup_plugin._loader._plugin_cache = None
    test_lookup_plugin._loader._plugin_cache_time = None
    test_lookup_plugin._loader._plugin_cache_max_size = None
    test_lookup_plugin._loader._aliases = None
    test_lookup_plugin._loader._filter_loader = None

# Generated at 2022-06-25 11:18:28.009498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = './file.txt'
    variables = {'var1': 'val1'}
    lookup_module.run(term, variables)


# Generated at 2022-06-25 11:18:45.919091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'convert_data': False})
    lookup_module_0.set_options({'jinja2_native': False})
    lookup_module_0.set_options({'variable_start_string': '{{'})
    lookup_module_0.set_options({'variable_end_string': '}}'})
    lookup_module_0.set_options({'comment_start_string': '{#'})
    lookup_module_0.set_options({'comment_end_string': '#}'})

# Generated at 2022-06-25 11:18:56.849148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Assert if first argument types are not string or list of strings
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([1,2,3], [1,2,3,4,5,6])
    assert "the template file 1 could not be found for the lookup" in str(excinfo)

    # Assert if variable_start_string or variable_end_string is not a string
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run(['template1'], [1,2], variable_start_string=['sdfsdfs'])
    assert "variable_start_string must be a string." in str(excinfo)


# Generated at 2022-06-25 11:19:04.260653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import yaml
    yaml_dict = yaml.load('''
x: "1"
y: "2"
''')
    assert list(yaml_dict.keys()) == ['x', 'y']
    assert list(yaml_dict.values()) == ["1", "2"]
    assert list(yaml_dict.items()) == [('x', "1"), ('y', "2")]

    import jinja2
    templar = jinja2.Template("""
{{ lookup_1 }}
{{ lookup_2 }}
""")

    ansible_search_path = ['some_path']
    lookup_module = LookupModule(loader=None, templar=templar)
    assert lookup_module._loader == None
    assert lookup_module._templar == templar

    lookup_module

# Generated at 2022-06-25 11:19:05.020488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    print("Testing run")

# Generated at 2022-06-25 11:19:13.355197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run of class LookupModule"""
    # Unit test for ansible.plugins.lookup.template.LookupModule.run()
    # Example values for args
    lookup_module_0 = LookupModule()
    # Test run() with all valid inputs.
    terms = ['terraform.tf']
    variables = {}
    kwargs = {}
    # Test run() with all valid inputs with one missing parameter.
    terms = ['terraform.tf']
    variables = {}
    kwargs = {}
    # Test run() with all valid inputs with one missing parameter.
    terms = ['terraform.tf']
    variables = {}
    kwargs = {}
    # Test run() with all valid inputs with one missing parameter.
    terms = ['terraform.tf']
    variables = {}

# Generated at 2022-06-25 11:19:21.144294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={})
    lookup_module_0.set_options(var_options={}, direct={'convert_data': True})
    lookup_module_0.set_options(var_options={}, direct={'jinja2_native': False})
    lookup_module_0.set_options(var_options={}, direct={'template_vars': {}})
    lookup_module_0.set_options(var_options={}, direct={'variable_start_string': '{{'})
    lookup_module_0.set_options(var_options={}, direct={'variable_end_string': '}}'})

# Generated at 2022-06-25 11:19:31.484552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_1 = dict()
    set_0 = set()
    dict_2 = dict()
    list_0 = list()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    str_0 = str()
    list_1 = list()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    # Validate the params
    # Setup the call to the method
    lookup_module_0 = LookupModule()
    str_1 = str()
    str_2 = str()
    dict_14 = dict()
    str_

# Generated at 2022-06-25 11:19:36.592871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # call run and assert stuff about its output
    pass



# Generated at 2022-06-25 11:19:37.504604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:19:44.965097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {}
    terms = ['my_path/my_file.j2']
    variables = {}
    options = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct=options)
    x = lookup_module_0.run(terms, variables, **options)
    assert x == ['# This is a template']
    assert lookup_module_0._templar.template("""{{ foo }}""", preserve_trailing_newlines=True, convert_data=False, escape_backslashes=False) == 'bar'
    assert lookup_module_0._templar.template("""{{ foo|string }}""", preserve_trailing_newlines=True, convert_data=False, escape_backslashes=False) == 'bar'
   

# Generated at 2022-06-25 11:20:05.501905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_1)


# Generated at 2022-06-25 11:20:09.606281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(terms=int_0, variables=str_0)
    assert var_0 == 648
    assert lookup_module_0._templar is not None

if __name__ == '__main__':
    import cProfile
    cProfile.run('test_case_0()')

# Generated at 2022-06-25 11:20:14.501685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:20:17.943736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(int_0, str_0)



# Generated at 2022-06-25 11:20:25.914003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    lookup_module_0._templar = MockTemplar(None)
    lookup_module_0._loader = MockLoader(None)
    lookup_module_0.template_vars = {}
    result_0 = lookup_module_0.run(['x8'], '', convert_data=True)
    assert result_0 == ['Rl\rC@A\x0cl|\x1a%\x0b?i\x1d\x1b(]\x17']


# Generated at 2022-06-25 11:20:31.809221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 953455508
    str_0 = 'YzY=0\n3wG'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_term(int_0, str_0)


# Generated at 2022-06-25 11:20:38.189847
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:20:41.266796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(int_0, str_0)


# Generated at 2022-06-25 11:20:42.977942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(int_0, str_1)


# Generated at 2022-06-25 11:20:54.171944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    var_1 = {}
    var_1['mX:r+[c'] = '/ytk0h"', 'H}RmW\x0b+u'
    var_1['u^\x0b7~'] = 'e}I'
    var_1['qnJ\t|G,'] = 'thJW_e'
    str_0 = '\x07JlW]$vOY.G'
    str_1 = 'hn=goF-f'
    str_2 = 'N8Wgr$dMvBC<'
    var_1['l>b5Z7V'] = 'bFojf'
    var_1['mq6$-U6'] = 'r:)p.c3\x0c'

# Generated at 2022-06-25 11:21:17.486452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(int_0, str_0)

# Generated at 2022-06-25 11:21:28.074709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(int_0, str_0)

if __name__ == '__main__':
    import sys
    print(sys.version)
    print(sys.version_info)
    for i in dir(sys):
        print("{} = {}".format(i, getattr(sys, i)))
    print(test_LookupModule_run())
    print('Tests Successful...')

# Generated at 2022-06-25 11:21:35.653761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 8262
    str_0 = '?H4<bUiUr.O\rh0h'
    str_1 = 'HT`"i\x0c}.|jK{y'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(int_0, str_0)



# Generated at 2022-06-25 11:21:38.626072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 4472
    str_0 = '9#7<geI!o^a'
    str_1 = 'I|@aA'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(int_0, str_0)


# Generated at 2022-06-25 11:21:42.263695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'm\r+c9FU&Xvqa$'
    str_1 = '#'
    lookup_module_0.run(str_0, str_1)


# Generated at 2022-06-25 11:21:43.672266
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert lookup_module_0.run(str_0, str_1, int_0) == [str_1]

# Generated at 2022-06-25 11:21:48.018946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run({'0': '0', '1': '1'})
    assert var_0 == '1'


# Generated at 2022-06-25 11:21:49.141227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:21:51.653150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule_obj = LookupModule
    terms = list()
    variables = dict()
    kwargs = dict()
    assert lookupmodule_obj.run(terms, variables, **kwargs) == ret

# vim: ai et ts=4 sw=4 sts=4 ft=python

# Generated at 2022-06-25 11:21:54.314457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(int_0, str_0)

# Generated at 2022-06-25 11:22:39.909408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, "run"))


# Generated at 2022-06-25 11:22:44.128359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1313
    str_0 = 'C-L\\m\x7f'
    str_1 = '[KPrX'
    var_0 = lookup_run(int_0, str_0)

# Generated at 2022-06-25 11:22:51.934915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule
    var_0 = lookup_module_0(str)
    if (var_0 == lookup_module_0):
        print('FAIL')
    else:
        print('PASS')

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:22:56.099371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    

# Generated at 2022-06-25 11:23:03.940708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(int_0, str_0)


# Generated at 2022-06-25 11:23:06.797517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = './some_template.j2'
    variables = {'ansible_search_path':['ansible']}
    res = self.lookup_module_0.run(term, variables)
    assert self.lookup_module_0.run(term, variables) != None

# Generated at 2022-06-25 11:23:17.503773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 'zsrl*K\x7fC0Wj\\OLt-='
    lookup_module_0 = LookupModule(var_0)
    terms_0 = (var_0, '<9I_jGQFptD>x\x7f')

# Generated at 2022-06-25 11:23:19.230799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:23:26.357896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(int_0, str_0)
    assert '\\X_1ct\r}K`wh.ns' == lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:23:29.939901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1581
    str_0 = 'h{G~YsR; +sOa/pI'
    str_1 = 'Cq3L}T_OvN8W!c'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(int_0, str_0)

# Generated at 2022-06-25 11:25:15.628800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    int_1 = 2182
    str_1 = '\\X_1ct\r}K`wh.ns'
    var_0 = lookup_run(int_1, str_1)

# Generated at 2022-06-25 11:25:20.612979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from pkg_resources import Requirement, resource_filename
    file_name = resource_filename(Requirement.parse("ansible"), "ansible/plugins/lookup/template.py")
    ansible_spec = open(file_name, "r")

    dict_var = {}
    dict_var["lookup_plugins"] = ("/tmp/ansible_99koxY/ansible_lookup_plugins")
    dict_var["lookup_plugin_count"] = 0

    str_0 = 'ansible_vars'
    str_0 = 'action_plugins'
    str_0 = 'lookup_plugins'
    str_0 = 'lookup_plugin_count'
    str_0 = 'lookup_plugin_count'
    int_0 = 0

# Generated at 2022-06-25 11:25:28.436932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'template'
    str_1 = 'z+)wG?oUBP(>2{i`'
    str_2 = './tests/test_lookup_plugins/files/lookup_template_test.txt'
    lookup_module_0 = LookupModule(str_1)
    int_0 = lookup_module_0.get_option(str_0)
    str_3 = lookup_run(int_0, str_2)


# Generated at 2022-06-25 11:25:30.645275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'wU;O8W^\x0bi`p9`'
    str_1 = '*'
    lookup_module_0 = LookupModule(str_1)
    str_2 = 'C^0*`|'
    var_0 = lookup_module_0.run(str_2, str_0)
    assert (var_0 == None)


# Generated at 2022-06-25 11:25:32.703729
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    assert lookup_module_0.run(int_0, str_0) == None


# Generated at 2022-06-25 11:25:39.632721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2494
    str_0 = 'l\x0b!xD4$_nYi~'
    lookup_module_0 = LookupModule('i`T}T$j]U&\nU@a')
    var_1 = lookup_module_0.run(int_0, str_0)


# Generated at 2022-06-25 11:25:44.174316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic test
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(int_0, str_0)

# Generated at 2022-06-25 11:25:49.258251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    str_0 = 'g'
    str_1 = 'M'
    lookup_module_0 = LookupModule(str_1)  # Type LookupModule
    def lookup_run(v_0: int, v_1: str) -> list:
        return lookup_module_0.run(v_0, v_1)
    str_2 = 'c%/'
    str_3 = '*'
    str_4 = 'X'
    str_5 = '5'
    int_0 = 2182
    str_6 = 'S%PcmO^_2,+Acd>='
    str_7 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_7)

# Generated at 2022-06-25 11:25:53.337278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2182
    str_0 = 'S%PcmO^_2,+Acd>='
    str_1 = '\\X_1ct\r}K`wh.ns'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_run(str_0)
    assert var_0 == test_case_0()
    assert len(var_0) == test_case_1()
    assert len(var_0) == test_case_2()



# Generated at 2022-06-25 11:25:55.752797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)
    assert isinstance(LookupModule.run(None, None, **None), list)