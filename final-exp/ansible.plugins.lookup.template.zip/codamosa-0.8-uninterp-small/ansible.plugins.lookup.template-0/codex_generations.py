

# Generated at 2022-06-25 11:17:08.693474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(loader=None)

    lookup_module._templar = None
    lookup_module._loader = None

    args = ['This is my template',]
    kwargs = {
        'template_vars': {'test': 'testvalue'},
        'variable_start_string': '{=',
        'variable_end_string': '=}',
        'comment_start_string': '{:',
        'comment_end_string': ':}',
        'convert_data': True,
        'jinja2_native': True,
    }
    result = lookup_module.run(terms=args, variables={}, **kwargs)

    assert result[0] == 'This is my template'



# Generated at 2022-06-25 11:17:16.806325
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_filepath = "lookup_filepath"
    lookup_filepath_2 = "lookup_filepath/templates"
    lookup_filepath_3 = "lookup_filepath/templates/"
    lookup_filepath_4 = "lookup_filepath/templates/test"

    ret_lookup_filepath = lookup_module_0.find_file_in_search_path(lookup_filepath, 'templates', 'templates_test')
    assert ret_lookup_filepath == lookup_filepath_4

    ret_lookup_filepath_2 = lookup_module_0.find_file_in_search_path(lookup_filepath_2, 'templates', 'templates_test')
    assert ret_lookup_filepath_2 == lookup_filepath_4

    ret

# Generated at 2022-06-25 11:17:26.389294
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    # Test for variables_option which is missing (variables_option=None)
    # Test for terms which is present
    terms = ['docker.ini.j2']
    variables_option = None
    assert len(terms) == 1
    assert terms[0] == 'docker.ini.j2'

    # Test 2
    # Test for jinja2_native which is enabled globally and disabled for this lookup (jinja2_native=False)
    # Test for convert_data which is enabled (convert_data=True)
    # Test for template_vars
    # Test for lookup_file which is present
    jinja2_native = True
    convert_data = True
    template_vars = {'HOST': '127.0.0.1'}

# Generated at 2022-06-25 11:17:30.354063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["./some_template.j2"]
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:17:41.385338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: this test fails with jinja2.exceptions.TemplateSyntaxError: Encountered unknown tag 'foo'.
    # because test_LookupModule_run uses the native jinja2.  I need to figure out how to get a non-native environment
    # set up for this test.

    # method run of class LookupModule takes arguments terms, variables and kwargs
    # mock the argument variables
    lookup_module_0 = LookupModule()

    lookup_module_0.set_loader(None)
    lookup_module_0._templar = None

    lookup_module_0._loader.get_basedir = lambda: "/home/david/git/ansible-modules-core/test/integration/files"

# Generated at 2022-06-25 11:17:44.115436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Fail case
    with pytest.raises(AnsibleError):
        lookup.run(terms=None, variables=None)

    lookup.run(terms=['somefile'], variables=None)

# Generated at 2022-06-25 11:17:46.375449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(None)
    lookup_module_0.run(terms=[], variables={'gather_subset': 'all'})

# Generated at 2022-06-25 11:17:57.392683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init a LookupModule object
    lookup_module_obj = LookupModule()

    # there is no file to lookup in our mock
    lookup_module_obj._loader.path_exists = mock.Mock(spec=lookup_module_obj._loader.path_exists, return_value=False)
    lookup_module_obj._loader._get_file_contents = mock.Mock(spec=lookup_module_obj._loader._get_file_contents, return_value=["ansible"])
    lookup_module_obj._loader._get_file_contents_if_exists = mock.Mock(spec=lookup_module_obj._loader._get_file_contents_if_exists, return_value=["ansible"])
    lookup_module_obj._find_needle = mock.Mock

# Generated at 2022-06-25 11:18:03.792259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['']
    variables = {}
    kwargs = {
        '_templar': '_templar'
    }
    assert lookup_module_0.run(terms, variables, **kwargs) == ['\n']

# Generated at 2022-06-25 11:18:08.121391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = {"environment_class": AnsibleEnvironment}
    lookup_module._loader = {"get_basedir": "",
                             "get_file_contents": "",
                             "path_dwim": "",
                             "_get_file_contents":""}
    lookup_module.run(["", ""], ["", ""], ['', ''])

# Generated at 2022-06-25 11:18:23.940110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "set_fact"
    variables_0 = {'ansible_check_mode': False, 'ansible_verbosity': 0}

    # Workaround because templar is not initialized as expected
    lookup_module_0._templar = variables_0['_templar']
    lookup_module_0._loader = variables_0['_loader']


# Generated at 2022-06-25 11:18:31.952713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Filter content = '{{ item }}'
    # Filter lookups = 'h', 'e', 'l', 'l', 'o'
    # Filter terms = ['./some_template.j2']
    # Filter variables = ''
    test_run_result = lookup_module_0.run(terms = ['some_template.j2'], variables = {})
    #assert test_run_result == [u'h', u'e', u'l', u'l', u'o'] # TODO implement tests for Ansible lookup
    assert test_run_result == [] # TODO implement tests for Ansible lookup

# Generated at 2022-06-25 11:18:42.920214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    str_0 = "./some_template.j2"
    str_1 = "{{ lookup('template', './some_template.j2') }}"

    dict_0 = {}
    str_2 = "msg"
    str_3 = "./some_template.j2"
    str_4 = "{{ lookup('template', './some_template.j2', variable_start_string='[%', variable_end_string='%]') }}"
    str_5 = "<%-"
    str_6 = " %>"
    str_7 = "{{ lookup('template', './some_template.j2', comment_start_string='[#', comment_end_string='#]') }}"

    lookup_module_0.run(str_0, dict_0)
   

# Generated at 2022-06-25 11:18:47.824896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for the case where we require to load the contents of the file
    # For this test case, we assume that the /etc/hosts file is present on
    # the system and we will load the contents of this file. Also assume that
    # the file is present in atleast one of the search paths. The test case
    # will be successful if the response will be a list containing the contents
    # of the file.
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(loader=None)
    lookup_module_0.set_environment(environment=None)
    lookup_module_0.set_options(var_options=None, direct=None)
    terms_0 = ["/etc/hosts"]
    variables = {}

# Generated at 2022-06-25 11:18:49.844051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, 'run'))


# Generated at 2022-06-25 11:18:54.943932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['test']
    variables = {}
    assert lookup_module_1.run(terms, variables) == None  # No template file is found, thus returns None

# Generated at 2022-06-25 11:18:59.462388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/path/to/file.j2']
    variables_0 = {}
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(terms, variables_0)
    except TypeError as err:
        print('TypeError : {0}'.format(err))


# Generated at 2022-06-25 11:19:04.019207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader([])
    lookup_module_0.set_basedir([])

    # Test 1
    try:
        lookup_module_0.run([], dict())
    except AnsibleError as exc:
        if exc.message != "the template file ./some_template.j2 could not be found for the lookup":
            raise AssertionError()
        else:
            pass
    else:
        raise AssertionError()


# Generated at 2022-06-25 11:19:12.772253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(MagicMock())
    lookup_module_0.set_loader().get_basedir.return_value = ''
    lookup_module_0.set_loader().path_dwim.return_value = 'tests/templates/test_lookup.j2'
    lookup_module_0._templar = MagicMock()
    lookup_module_0._templar.template.return_value = 'Hello from template'
    lookup_module_0.run(['test_lookup.j2'], {})

    lookup_module_0.set_loader().path_dwim.assert_called_with('', 'tests/templates/test_lookup.j2')

# Generated at 2022-06-25 11:19:15.479242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run(self, terms, variables, **kwargs)
    with pytest.raises(TypeError):
        lookup_module_0.run()

# Generated at 2022-06-25 11:19:31.452444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None  # Mock
    lookup_module_0._loader = None  # Mock
    lookup_module_0.set_options = None  # Mock
    lookup_module_0.get_option = None  # Mock
    lookup_module_0.find_file_in_search_path = None  # Mock
    lookup_module_0._templar.set_temporary_context = None  # Mock
    lookup_module_0._templar.template = None  # Mock
    lookup_module_0._templar.copy_with_new_env = None  # Mock
    lookup_module_0._loader._get_file_contents = None  # Mock
    terms_0 = './some_template.j2'
    variables

# Generated at 2022-06-25 11:19:32.953309
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Call test_case_0
    test_case_0()

# Generated at 2022-06-25 11:19:41.550052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    options = {'variable_start_string':'<%', 'variable_end_string':'%>'}
    lookup_module.set_options(options)
    assert lookup_module.get_option('variable_start_string') == '<%'
    assert lookup_module.get_option('variable_end_string') == '%>'
    assert lookup_module.get_option('comment_start_string') == '{#'
    assert lookup_module.get_option('comment_end_string') == '#}'

# Generated at 2022-06-25 11:19:45.413355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader({'paths':['my_path']})
    assert lookup.run(["lookup_template.j2"], {"foo_bar_baz":"bar"}) is not None

# Generated at 2022-06-25 11:19:56.909303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:20:01.266072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['./some_template.j2']
    variables = dict()

    lookup_module.run(terms, variables)

    return


# Generated at 2022-06-25 11:20:02.249166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the method `run` of class `LookupModule`
    """
    lookup_module = LookupModule()
    test_te

# Generated at 2022-06-25 11:20:10.617601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    type(varible) of terms is hashable list
    """
    lookup_module_0 = LookupModule()
    terms_0 = ['./some_template.j2']
    variables_0 = {'item': 'test_item'}
    kwargs_0 = {'variable_start_string': '{{'}
    try:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except Exception:
        assert False



# Generated at 2022-06-25 11:20:18.141937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #From ansibot (https://github.com/ansible/ansibullbot/blob/d6129f9e67849685d2e1f00a5169e3c2720919f8/ansibullbot/triagers/plugins/lookup.py)
    terms, variables, _direct = [], {}, {}
    lookup_module_0 = LookupModule()
    result = lookup_module_0._run(terms, variables, _direct)
    assert result == None

# Generated at 2022-06-25 11:20:24.067022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_string = 'test_string'
    test_dict = {'template_vars': {'var1': 'val1'}}
    ret = lookup_module.run([test_string], test_dict, convert_data=True)
    assert(ret == ['test_string'])

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:20:45.015425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement test_LookupModule_run
    assert False

# Generated at 2022-06-25 11:20:50.450446
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    from ansible.plugins.loader import lookup_loader

    lookup_obj = lookup_loader.get('template', basedir='/etc/ansible')
    assert lookup_obj.run([], {})

# Generated at 2022-06-25 11:20:57.080625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = dict()
    with pytest.raises(AnsibleError) as excinfo:
    	lookup_module_0.run(terms, variables, **kwargs)
    assert "the template file  could not be found for the lookup" in str(excinfo.value)

# Generated at 2022-06-25 11:21:07.527389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader._basedir = "test_LookupModule_run_base_dir"
    os.mkdir("test_LookupModule_run_base_dir")
    os.mkdir("test_LookupModule_run_base_dir/templates")
    os.mkdir("test_LookupModule_run_base_dir/files")

    lookup_module._loader.set_basedir("test_LookupModule_run_base_dir")

    f = open("test_LookupModule_run_base_dir/templates/test_LookupModule_run.j2", "w")
    f.write("Testing {{ ansible_managed }}")
    f.close()


# Generated at 2022-06-25 11:21:15.550911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testfile = "/tmp/lookup_test_file"
    lookup_module = LookupModule()
    lookup_module._loader = mock_loader
    # set jinja2 internal search path for includes
    searchpath = ['/path/to/templates']
    with lookup_module._templar.set_temporary_context(searchpath=searchpath):
        actual_result = lookup_module.run(['greeting.j2'], {}, convert_data=True)
        expected_result = 'hello world'
        assert actual_result[0] == expected_result
        os.remove(testfile)


# Generated at 2022-06-25 11:21:21.612795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['./src/template_test.j2']
    variables = {}
    kwargs = {'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': '{#', 'comment_end_string': '#}'}
    res = lookup_module.run(terms, variables, **kwargs)
    assert res == ["Test 0\n"]


# Generated at 2022-06-25 11:21:32.239866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader(None)
    terms_1 = ['./some_template.j2']
    variables_1 = {}
    kwargs_1 = {}
    lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader('some_loader')
    lookup_module_1.set_basedir('some_basedir')
    lookup_module_1.set_templar(None)
    terms_1 = ['./some_template.j2']
    variables_1 = {}
    kwargs_1 = {}
    lookup_module_1.run(terms_1, variables_1, **kwargs_1)

# Generated at 2022-06-25 11:21:37.963828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar.loader = None
    lookup_module_0._loader = None
    lookup_module_0._find_needle = None
    lookup_module_0._find_file_in_search_path = None
    lookup_module_0.run(terms=None, variables=None)

# Generated at 2022-06-25 11:21:39.413791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()

# Generated at 2022-06-25 11:21:43.155524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None]
    variables_0 = dict()
    # Check lookup_module_0.run(terms=terms_0, variables=variables_0)
    assert lookup_module_0.run(terms=terms_0, variables=variables_0) == []


# Generated at 2022-06-25 11:22:14.476586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(int_0, lookup_module_1)

# Generated at 2022-06-25 11:22:19.377025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(int_0, lookup_module_1)


# Generated at 2022-06-25 11:22:26.594227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = -854253417
    int_1 = 0
    int_2 = 176581937
    int_3 = -1923354115
    int_4 = 1417032080
    int_5 = 1694133840
    list_0 = []
    str_0 = 'J1Zmd.'
    str_1 = ',|N/N'
    str_2 = 'b/J_Y'
    str_3 = 'qC^!\x0bF&a'
    str_4 = ';\x12\r0:G'
    str_5 = '4'

# Generated at 2022-06-25 11:22:31.680539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None

    variables = None

    lookup_module = LookupModule()

    # Test exception raised for unsupported argument
    with pytest.raises(TypeError) as excinfo:
        __ = lookup_module.run(terms, variables)
    assert "run() got an unexpected keyword argument 'kwargs'" in str(excinfo)


# Generated at 2022-06-25 11:22:41.220201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 0
    str_0 = None
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule(lookup_module_1)
    lookup_module_3 = LookupModule(lookup_module_2)
    lookup_module_4 = LookupModule(lookup_module_3)
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule(lookup_module_5)
    lookup_module_7 = LookupModule(lookup_module_6)
    lookup_module_8 = LookupModule(lookup_module_7)
    lookup_module_9 = LookupModule(lookup_module_8)
    lookup_module_10 = Lookup

# Generated at 2022-06-25 11:22:45.680716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(int_0, lookup_module_1)
    assert var_0 == None

# Component tests for method run of class LookupModule
# TODO: Add tests for edge cases
# TODO: Add tests for failure conditions

# Generated at 2022-06-25 11:22:54.010034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    param_terms = './some_template.j2'
    param_variables = './some_template.j2'
    param_kwargs = './some_template.j2'
    lookup_module_0 = LookupModule(param_terms)
    lookup_module_0.file_root = './some_template.j2'
    lookup_module_0.run(param_terms, param_variables, **param_kwargs)

    # Verify
    assert False # FIXME


# Generated at 2022-06-25 11:22:59.221526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    lookup_module_0._display = None
    lookup_module_0._result_cache = None
    lookup_module_0._options_cache = None
    lookup_module_0._validate_options(None, None)
    lookup_module_0._get_search_paths(None)
    lookup_module_0._get_file_contents(None)
    var_0 = lookup_module_0.run(None, None, None)


# Generated at 2022-06-25 11:23:08.004078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('')
    print('=========================')
    print('start unit test for method run of class LookupModule')
    print('=========================')
    print('')

    # Unit: test unit test precondition
    # Method: test_case_0
    # Error: AnsibleLookupError: expected a list of items for lookup
    try:
        test_case_0()
    except Exception as e:
        if 'expected a list of items for lookup' in to_text(e):
            print('Expected and got expected exception for test_case_0: {}'.format(to_text(e)))
        else:
            print('Expected and did not get expected exception for test_case_0.  Got: {}'.format(to_text(e)))
            raise

# Generated at 2022-06-25 11:23:17.605619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    str_0 = 'Test'
    tuple_0 = (int_0, str_0)
    str_1 = 'Term'
    tuple_1 = (int_0, str_1)
    str_2 = 'Loo'
    tuple_2 = (int_0, str_2)
    str_3 = 'Static'
    tuple_3 = (int_0, str_3)
    str_4 = 'method'
    tuple_4 = (int_0, str_4)
    str_5 = 'Filter'
    tuple_5 = (int_0, str_5)
    str_6 = 'modules'
    tuple_6 = (int_0, str_6)
    str_7 = '_'
    tuple_7 = (str_2, str_7)

# Generated at 2022-06-25 11:24:05.817383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = None
    # test case 0
    var_0 = None
    var_2 = {}
    lookup_module_0 = LookupModule(var_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    result = lookup_module_2.run(var_0, lookup_module_1)
    assert result == None

# Generated at 2022-06-25 11:24:07.596271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 11:24:17.886145
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:24:19.248559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_0.run(int_0, lookup_module_1)

# Generated at 2022-06-25 11:24:19.972161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert(callable(getattr(LookupModule, "run")))


# Generated at 2022-06-25 11:24:22.394110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('unit test for method run of class LookupModule')
    var_0 = None
    var_1 = {}
    lookup_module_0 = LookupModule(var_1)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run(var_0, lookup_module_1)

# Generated at 2022-06-25 11:24:26.782422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test cases from the original Ansible.
    int_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(int_0, lookup_module_1)

# Generated at 2022-06-25 11:24:33.081555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(int_0, lookup_module_1)

# Generated at 2022-06-25 11:24:36.188495
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(None, lookup_module_1)



# Generated at 2022-06-25 11:24:42.745368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = None
    dict_0 = {}
    lookup_module_4 = LookupModule(dict_0)
    lookup_module_5 = LookupModule(lookup_module_4)
    lookup_module_6 = LookupModule()
    var_0 = lookup_module_6.run(int_0, lookup_module_5)
    assert var_0 == [], "Incorrect type returned. Expected: %s. Got: %s" % (type([]), type(var_0))

# Generated at 2022-06-25 11:26:48.914006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Example 0
    assert isinstance(lookup_module_0.run(None, None), list)

    # Example 1
    try:
        assert isinstance(lookup_module_0.run(None, None), list)
    except Exception as exc_0:
        assert isinstance(exc_0, AnsibleError)

    # Example 2
    assert isinstance(lookup_module_0.run(None, None), list)

    # Example 3
    try:
        assert isinstance(lookup_module_0.run(None, None), list)
    except Exception as exc_1:
        assert isinstance(exc_1, AnsibleError)

# Generated at 2022-06-25 11:26:52.131723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    this_is_the_first_term = None

    foo = {}

    lookup_module__instance_0 = LookupModule(foo)
    lookup_module__instance_1 = LookupModule(lookup_module__instance_0)
    lookup_module__instance_2 = LookupModule()

    var_0 = lookup_module__instance_2.run(this_is_the_first_term, lookup_module__instance_1)

