

# Generated at 2022-06-25 11:17:08.881344
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Imports
    import os
    import sys
    import pytest
    import ansible.module_utils._text as to_bytes

    # All arguments to lookup module
    arguments = {
        "_raw_params": "template1.j2",
        "_terms": "template1.j2",
        "convert_data": False,
        "display_args_expanded": False,
        "variable_start_string": "{{",
        "variable_end_string": "}}",
        "jinja2_native": False,
        "template_vars": {},
        "comment_start_string": "{{",
        "comment_end_string": "}}",
    }

    # Initialize AnsibleVariables object with data
    AnsibleVariables = ansible.parsing.vault.VaultLib.V

# Generated at 2022-06-25 11:17:18.399773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_os_0 = os.environ
    test_variables_0 = {u'ansible_ssh_host': u'192.168.1.1', u'ansible_ssh_common_args': u'-o StrictHostKeyChecking=no', u'ansible_ssh_pass': None, u'ansible_ssh_port': 22, u'ansible_connection': u'ssh', u'ansible_ssh_user': u'root', u'ansible_python_interpreter': u'/usr/bin/python', u'ansible_user_id': u'root', u'ansible_all_ipv4_addresses': [u'192.168.1.1'], u'ansible_playbook_python': u'/usr/bin/python'}


# Generated at 2022-06-25 11:17:30.353754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Check the method run of class LookupModule,
    """
    lookup_module = LookupModule()
    lookup_module.set_loader({'paths': ['/etc/ansible/roles/'], '_basedir_': '/etc/ansible/roles/'})
    assert lookup_module.run(['./some_template.j2'], {'template_vars': {}}, variable_start_string='{{', variable_end_string='}}', comment_start_string='{#', comment_end_string='#}', convert_data=True) == ['This is a template for a test.\n']

# Generated at 2022-06-25 11:17:38.849054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['gigi']
    variables = {'gigi':'gigigigigigigigi'}
    kwargs = {'variable_start_string': '[%', 'variable_end_string': '%]'}
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(terms, variables, **kwargs)
    except AnsibleError as result:
        ansible_error_msg = str(result)
    assert 'could not be found for the lookup' in ansible_error_msg

# Generated at 2022-06-25 11:17:48.222003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # first test
    text_template_1 = "Hi, this is {{ name }} example."
    text_template_2 = "Hi, I'm {{ name }}. I'm {{ age }} years old."

    fake_variables = {'name': 'John', 'age': '30'}
    template_terms = [text_template_1, text_template_2]

    result = lookup_module.run(template_terms, fake_variables)
    assert result[0] == "Hi, this is John example."
    assert result[1] == "Hi, I'm John. I'm 30 years old."

    # second test
    path_template = "./tests/files_for_tests/test_template.txt"

    result = lookup_module.run(path_template, fake_variables)

# Generated at 2022-06-25 11:17:56.715786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    args = 1
    kwargs = {'variable_start_string': '{{{', 'variable_end_string': '}}}'}

    # Test with the first argument as a string
    terms = 'Dummy'

    # Test with the second argument as a non-empty dictionary
    variables = {'foo': 'bar'}

    # The expected result of the run method
    expected_output = []
    expected_output.append('bar')

    result = lookup_module.run(terms, variables, **kwargs)

    # Fail if the result of the output of the run method is not equal to the expected output
    assert result == expected_output



# Generated at 2022-06-25 11:18:00.964079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["ansible/test/unit/data/test_lookup_plugin/a.txt" ]
    vars_1 = dict(
        ansible_env={"HOME": "/home/michael"}
    )
    kwargs_1 = dict(
        template_vars={
            "foo": "bar"
        },
        convert_data=False,
        jinja2_native=False,
        variable_start_string="{%",
        variable_end_string="%}",
        comment_start_string="%{",
        comment_end_string="}%"
    )
    exp_result_1 = [
        "foobar"
    ]

# Generated at 2022-06-25 11:18:09.407177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Variable `terms` is not a list while it should be

# Generated at 2022-06-25 11:18:13.131248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a dummy file
    dummy = open('/tmp/dummy.txt.j2', 'w')
    dummy.write('{{test1}}')
    dummy.close()

    lookup_module_0 = LookupModule()
    print(lookup_module_0.run(['/tmp/dummy.txt.j2'], {'test1': 'test1'}))


if __name__ == '__main__':
    # test_case_0()

    test_LookupModule_run()

# Generated at 2022-06-25 11:18:15.146046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=["./fake_file.j2"], variables={}) is None
    assert lookup_module_1.run(terms=["./fake_file.j2"], variables={'fake_var': 'fake_val'}) is None

# Generated at 2022-06-25 11:18:28.174338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(loader=None, variables=None)

    with pytest.raises(AnsibleError) as exec_info:
        lookup_module_0.run(terms=None, variables=None)

    assert 'the template file None could not be found for the lookup' in to_text(exec_info.value)

# Generated at 2022-06-25 11:18:33.464022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_options = {"variable_start_string": "{{",
                             "variable_end_string": "}}",
                             "comment_end_string": "#}",
                             "comment_start_string": "#{",
                             "convert_data": True,
                             "template_vars": {"hostvars": {"host1": "host1"}},
                             "jinja2_native": False}
    lookup_module_terms = ["./test_dir/VARS.template"]
    lookup_module_variables = {"hostvars": {"host1": "host1"}, "hostvars.host1": "host1"}
    lookup_module_kwargs = {}
    test_case_context = {}

# Generated at 2022-06-25 11:18:44.462087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    try:
        import runpy
        if sys.version_info >= (3, 0):
            from importlib.machinery import SourceFileLoader
            module = SourceFileLoader('ansible.plugins.lookup.template', 'ansible/plugins/lookup/template.py').load_module()
        else:
            runpy._run_module_as_main('ansible.plugins.lookup.template', alter_sys=True)
            module = sys.modules.get('ansible.plugins.lookup.template')
    except ImportError:
        import imp
        module = imp.load_source('ansible.plugins.lookup.template', 'ansible/plugins/lookup/template.py')
        module.sys = sys
        sys.modules['ansible.plugins.lookup.template'] = module

    lookup_

# Generated at 2022-06-25 11:18:46.470635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Params
    terms = ['./some_template.j2']
    variables = ["var1", "var2"]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == ["tempalte contents"]

# Generated at 2022-06-25 11:18:52.534725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['../../../tests/templates/test1.j2']
    variables_0 = {}
    # Variable of type dict
    kwargs_0 = {}
    x = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert isinstance(x, list) == True
    assert x == ['foo\n']

# Generated at 2022-06-25 11:19:02.169447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup_module_0 = LookupModule()
    terms_0 = ['etc/hosts']
    variables_0 = { 'ansible_search_path': ["/etc/hosts"] }
    lookup_module_0.set_options(var_options=variables_0, direct={})
    # action
    ret = lookup_module_0.run(terms_0, variables_0, convert_data=None, template_vars=None, comment_start_string=None, comment_end_string=None, jinja2_native=None, variable_start_string=None, variable_end_string=None)
    # verify expectations

# Generated at 2022-06-25 11:19:12.567876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [u'../templates/foo.j2']
    variables_1 = {u'foo': [u'fooooo', u'bar', u'baz']}
    kwargs_1 = {u'direct': {}}
    ret = [u'fooooo']
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == ret

    lookup_module_2 = LookupModule()
    terms_2 = [u'../templates/foo.j2']
    variables_2 = {u'foo': {u'fooooo': None, u'bar': u'baz'}}
    kwargs_2 = {u'direct': {}}
    ret = [u'fooooo']

# Generated at 2022-06-25 11:19:17.893890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["foo"]
    variables = {}
    lookup_template_vars = {}
    kwargs = {}
    # test normal run
    ret = []
    try:
        ret = lookup_module_0.run(terms, variables, lookup_template_vars=lookup_template_vars, **kwargs)
    except Exception as e:
        pass
    assert ret == []

# Generated at 2022-06-25 11:19:22.492886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Call method run
    term = "../../plugins/lookup/file.py"
    variables = {}
    result = lookup_module.run(term, variables)
    # Test method run
    assert result is not None

# Generated at 2022-06-25 11:19:26.053319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(terms=None, variables=None)
    assert res == []

# Generated at 2022-06-25 11:19:48.339543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    x = lookup_module.run(terms=['./some_template.j2'], variables={})

# Generated at 2022-06-25 11:20:00.034368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tests = [
        # This test checks the call of deprecated lookup run
        # I do not know yet how to do it better
        # dict(
        #     terms=[dict(
        #         value="{{ item.value}}",
        #         start="{{",
        #         end="}}"
        #     )],
        #     variables=dict(
        #         ansible_search_path=["/home/fred"],
        #         item=dict(
        #             value="my_var"
        #         )
        #     ),
        #     expected=[]
        # )
    ]

    lookup_module_0 = LookupModule()

    for test in tests:
        # results = lookup_module_0.run(**test)
        results = lookup_module_0.run(test)

# Generated at 2022-06-25 11:20:04.397641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = []

    variables_0 = {}

    kwargs_0 = {}

    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []


# Generated at 2022-06-25 11:20:09.896981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  data_0 = ['test']
  data_1 = {'test': 'test'}
  data_2 = 'test'
  data_3 = 20
  data_4 = 'test'
  data_5 = None
  data_6 = 'test'
  data_7 = None
  data_8 = 'test'
  data_9 = None
  data_10 = 'test'
  data_11 = None
  data_12 = 'test'
  data_13 = None
  data_14 = 'test'
  data_15 = None
  result_0 = lookup_module_0.run(terms=data_0, variables=data_1)
  result_1 = lookup_module_0.run(terms=data_2, variables=data_3)


# Generated at 2022-06-25 11:20:17.855069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.set_options(direct={u'variable_start_string': u'{{', u'variable_end_string': u'}}', u'comment_start_string': u'{#', u'comment_end_string': u'#}'})
    lookup_module_run_0.run([u'user1.yaml'], {})

# Generated at 2022-06-25 11:20:26.757314
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:20:28.399637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:20:30.822888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([], {}) == []

# Generated at 2022-06-25 11:20:35.875081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader( mock_loader_1 )
    variables_1 = dict()
    terms_1 = [ './some_template.j2' ]
    result_1 = lookup_module_1.run( terms_1, variables_1 )

# Generated at 2022-06-25 11:20:37.015109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('', '') == 1
    assert lookup_module.run(['', ''], '') == 1


# Generated at 2022-06-25 11:21:02.851626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        print("Test running")
        test_case_0()
    except Exception as e:
        print("Test failed", str(e))

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:21:11.431099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    str_0 = 'Z$[w%34%1\rn\\Kr:C\r<'
    str_1 = 'T`W,9<U6'
    dict_1 = {str_0: dict_0, str_1: dict_0}
    bool_0 = True
    dict_2 = {str_0: bool_0, str_1: bool_0}
    str_2 = 'Hy-%6i'
    str_3 = 'zDf1G2Q]R'
    dict_3 = {str_3: dict_0, str_1: dict_0}
    str_4 = 'CJ\t+wiQ;C'
    dict_4 = {str_4: dict_0, str_1: dict_0}
    bool_1

# Generated at 2022-06-25 11:21:18.135343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    str_0 = 'Z$[w%34%1\rn\\Kr:C\r<'
    bool_0 = True
    dict_1 = {str_0: dict_0, str_0: bool_0}
    str_1 = '!5[5K'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(dict_0, dict_1)
    assert var_0 == dict_0


# Generated at 2022-06-25 11:21:21.682770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    dict_1 = {u'rP!': dict_0, u'rP!': True}
    lookup_module_0 = LookupModule('5$5c%')
    var_0 = lookup_module_0.run(dict_0, dict_1)


# Generated at 2022-06-25 11:21:32.298472
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:21:34.372471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:21:36.337472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

test_LookupModule_run()

# Generated at 2022-06-25 11:21:38.674279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = None
    variables = None
    lookup_module_0 = LookupModule(None)
    lookup_module_0.run(term, variables)


# Generated at 2022-06-25 11:21:47.362327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    dict_1 = {}
    str_0 = 'example.yml'
    dict_1[str_0] = dict_0
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_3['some_key'] = dict_6
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_9['foor'] = dict_11
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}

# Generated at 2022-06-25 11:21:51.278757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    str_0 = 'Z$[w%34%1\rn\\Kr:C\r<'
    bool_0 = True
    dict_1 = {str_0: dict_0, str_0: bool_0}
    str_1 = 'Hy-%6i'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(dict_0, dict_1)


# Generated at 2022-06-25 11:22:38.870703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Unit test for method run of class LookupModule")
    test_case_0()


# Generated at 2022-06-25 11:22:45.026757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {'ansible_search_path': ['path_0', 'path_1']}
    lookup_module_0 = LookupModule('str_0')
    lookup_module_0.set_options(var_options=dict_1, direct=dict_0)
    lookup_module_0.run(('str_1', 'str_2'), dict_1)


# Generated at 2022-06-25 11:22:53.413138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    str_0 = "template"
    int_0 = 20000
    str_1 = '+:|'
    dict_1 = {str_1: dict_0, str_1: int_0}
    str_2 = '"t,@!\r!+t\r'
    lookup_module_0 = LookupModule(str_2)
    var_0 = lookup_run(dict_0, dict_1)


# Generated at 2022-06-25 11:22:57.931363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    str_0 = 'Z$[w%34%1\rn\\Kr:C\r<'
    bool_0 = True
    dict_1 = {str_0: dict_0, str_0: bool_0}
    str_1 = 'Hy-%6i'
    lookup_module_0 = LookupModule(str_1)
    var_2 = lookup_module_0.run(dict_0, dict_1)


# Generated at 2022-06-25 11:23:05.000476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'E:J|#+tV': '_QhIsx*#~', 'Y"\x0b`g<v': {}}
    str_0 = ')XaJ|vn+'
    lookup_module_0 = LookupModule(str_0)
    res_0 = lookup_module_0.run(dict_0, dict_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:15.904611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    str_0 = '8$k9+tI'
    bool_0 = True
    dict_1 = {str_0: dict_0, str_0: bool_0}
    dict_2 = {str_0: dict_1, str_0: bool_0}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(dict_2, dict_1)
    dict_3 = None
    str_1 = 'N'
    bool_1 = True
    dict_4 = {str_1: dict_3, str_1: bool_1}
    dict_5 = {str_1: dict_4, str_1: bool_1}
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:23:22.232335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(str_0)
    assert lookup_module_1.run(list_0, dict_1) == list_0


# Generated at 2022-06-25 11:23:30.695574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {"template_vars": {"some_var": "some_val"}}
    str_0 = 'Z$[w%34%1\rn\\Kr:C\r<'
    bool_0 = True
    dict_1 = {str_0: dict_0, str_0: bool_0}
    str_1 = 'Hy-%6i'
    lookup_module_0 = LookupModule(str_1)
    var_0 = lookup_module_0.run(dict_0, dict_1)

# Generated at 2022-06-25 11:23:38.525266
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:23:46.584661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    str_0 = '9p>I}o3'
    list_0 = [str_0]
    str_1 = 'NaFV7h'
    dict_0 = {str_1: list_0}
    str_2 = 'E|s`}8'
    dict_1 = {str_2: dict_0}
    str_3 = '$lN1@|s'
    bool_0 = False
    str_4 = 'n8<%_u'
    lookup_module_0 = LookupModule(str_1)
    str_5 = 'Dv+R'
    list_1 = [str_5]
    str_6 = 'jiyD'
    int_0 = 1
    str_7 = ']'


# Generated at 2022-06-25 11:25:43.743980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    integer_0 = 0
    integer_1 = -58
    integer_2 = 52
    integer_3 = -95
    integer_4 = 50
    integer_5 = -89
    integer_6 = -39
    integer_7 = 11
    integer_8 = -63
    integer_9 = -68
    integer_10 = 100
    integer_11 = -65

    dict_0 = None
    str_0 = '!B|U%c'
    str_1 = str_0
    str_2 = '{'
    str_3 = '-;'
    str_4 = 'J'
    str_5 = 'T'
    str_6 = '$'
    str_7 = 'Y-]|E'
    str_8 = '\t~0#7'

# Generated at 2022-06-25 11:25:48.716109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'$z^': None}
    dict_1 = {'Ij%1': True}
    str_0 = '^;OI'
    lookup_module_0 = LookupModule(str_0)
    lookup_module_0.run(None, dict_0, convert_data=dict_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:25:54.397671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #try:
        str_0 = 'i'
        str_1 = '5'
        list_0 = [str_1, str_1, str_0, str_0, str_1, str_1]
        list_1 = []
        list_1.append(str_1)
        list_1.append(str_0)
        int_0 = 1
        str_2 = 'r'
        str_3 = '2A-Tg'
        list_2 = [str_3, str_3, str_2, str_2, str_2, str_2, str_2]
        list_2.append(str_2)
        str_4 = 'D7v'
        list_2.append(str_4)
        list_2.append(str_4)
        str_

# Generated at 2022-06-25 11:26:01.501360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = 'i[?{-FvD'
    dict_1 = '6U]M6!sR6'
    dict_2 = 'i[?{-FvD'
    list_0 = ['sv3', '~:?', 'i[?{-FvD', '~:?', 'i[?{-FvD', 'i[?{-FvD', 'i[?{-FvD', 'i[?{-FvD', '#', 'qmB', '%cMj']
    str_0 = "9u/'Oc<"
    str_1 = ''
    str_2 = 'Y7rj'
    str_3 = 'L*%'
    bool_0 = True
    str_4 = 'g_]Z['
    dict

# Generated at 2022-06-25 11:26:03.118896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:26:07.183770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_1 = dict()
    lookup_module_0 = LookupModule(dict_0, dict_1)
    try:
        lookup_module_0.run()
    except Exception:
        lookup_module_0 = LookupModule(dict_0, dict_1)
        lookup_module_0.run()

# Generated at 2022-06-25 11:26:13.778835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    dict_1 = dict_0
    dict_2 = {dict_1: dict_0}
    str_0 = 'N]c;I'
    lookup_module_0 = LookupModule(dict_2)
    var_0 = lookup_module_0.run(dict_0, dict_1)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:26:23.371476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Called via ansible-playbook with extra vars
    # ansible-playbook playbooks/debug_me.yml -vvvv -e @vars.yml
    # python3 -m pytest test/units/plugins/lookup/test_template.py -s -v
    import pytest
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-25 11:26:24.024181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

# Generated at 2022-06-25 11:26:31.049822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = [{}, {}, {}, {}, {}]
    dict_0[0]['M/:@:`1.g7'] = test_LookupModule_run_argv_0_argv_0()
    dict_0[0]['hNJb\\8"|r'] = 'k'
    dict_0[1]['M/:@:`1.g7'] = test_LookupModule_run_argv_0_argv_0()
    dict_0[1]['hNJb\\8"|r'] = 'k'
    dict_0[2]['M/:@:`1.g7'] = test_LookupModule_run_argv_0_argv_0()
    dict_0[2]['hNJb\\8"|r'] = test_Look