

# Generated at 2022-06-25 11:17:09.602655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Tests on class LookupModule
    if lookup_module is not None:
        pass

    # Tests on method run of class LookupModule
    terms = []
    variables = {}
    ret = lookup_module.run(terms, variables)
    if ret is None:
        raise AssertionError("lookup_module.run returned None.")



# Generated at 2022-06-25 11:17:10.102451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:17:15.421200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=["dummy"], variables={"some": "dummy", "dummy": "var"}, comment_end_string="comment_end_string", variable_end_string="variable_end_string", template_vars={}, jinja2_native=False, comment_start_string="comment_start_string", convert_data=True, variable_start_string="variable_start_string"), "Failed to run lookup module"

# Generated at 2022-06-25 11:17:19.890760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = None
    kwargs_0 = {'convert_data': True, 'variable_end_string': '}}', 'jinja2_native': False, 'comment_start_string': '#', 'variable_start_string': '{{', 'comment_end_string': '#'}
    assert LookupModule.run(lookup_module_0, terms_0, variables_0, **kwargs_0) is None

# Generated at 2022-06-25 11:17:26.335960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms_0 = [""]
    test_variables_0 = [{u'lookup_file_0': u'/home/vagrant/ansible/test/test_module/test.txt', u'lookup_file_1': u'/etc/ansible/test.txt'}]
    test_kwargs_0 = {'variable_start_string': '{{', 'variable_end_string': '}}'}
    lookup_module_0.run(terms=test_terms_0, variables=test_variables_0, **test_kwargs_0)

    assert lookup_module_0 is not None



if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-25 11:17:36.829518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # all the template files are in the ./test/unit/data/ directory

    # Testing with string as the term, should return list containing the content
    # of the file at that path
    def test_run_0(self):
        term = "./test/unit/data/test_template_file"
        vars = {"some_var": "some_value"}
        result = [u'test string']
        self.assertEqual(lookup_module_0.run(terms=term,
                                             variable=vars),
                         result)

    # Testing with a list as the term, should return list containing content of
    # each file
    def test_run_1(self):
        term = ["./test/unit/data/test_template_file",
                "./test/unit/data/test_template_file1"]

# Generated at 2022-06-25 11:17:39.050037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:17:42.623351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('/control_file', '/control_file')


# Generated at 2022-06-25 11:17:48.117513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Should raise an error, no argument given (no terms, no variables)
    try:
        lookup_module_0.run(None, None)
    except Exception as e:
        assert isinstance(e, AnsibleError)


# Generated at 2022-06-25 11:17:51.719303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test_data/test_template.j2']
    assert lookup_module_0.run(terms_0, {}) == ['success']
    print('test_LookupModule_run passed')



# Generated at 2022-06-25 11:18:02.627117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_contents = 'Key: {{ key }}'
    variables = dict(key='foo')
    lookup = LookupModule()
    ret = lookup.run(terms=[file_contents], variables=variables)
    assert ret == ['Key: foo']

# Generated at 2022-06-25 11:18:09.485955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '7;!1$'
    list_0 = [str_0, lookup_module_0]
    str_1 = 's,sx;$"p'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_module_0.run(list_0, **dict_0)


# Generated at 2022-06-25 11:18:12.606013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fp = open('/tmp/test_LookupModule_run.log', 'a')
    fp.write('\n########################## INICIO ##########################\n')
    for i in range(10000):
        test_case_0()
        fp.write('\n########################## FIM ##########################\n')
        fp.close()
###################################################################################################

# Generated at 2022-06-25 11:18:22.406607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 100
    int_1 = 25
    int_2 = 31
    int_3 = 121
    int_4 = 20
    str_0 = 'cO]H\n6'
    str_1 = 'pWx{F\n%'
    str_2 = 'j}!_?i'
    str_3 = 'cv>I;IQAh6d#r/"mA;'
    str_4 = '\'n\'"u#'
    str_5 = '?g\x7fsize=%i hH\x7f'
    str_6 = '.*>k'
    str_7 = '0'
    int_5 = 180
    str_8 = './some_template.j2'

# Generated at 2022-06-25 11:18:30.726184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)
    assert isinstance(var_0, list) == True

# Generated at 2022-06-25 11:18:41.347852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(test_LookupModule_run, object)
    # test with no arguments, let it fail
    try:
        exc_0 = None
        lookup_module_0 = LookupModule()
        lookup_run(lookup_module_0)
    except Exception as exc_0:
        pass
    dict_0 = {'a': exc_0}
    str_0 = 'a'
    assert dict_0[str_0] == None
    # test with no arguments
    try:
        exc_0 = None
        lookup_module_0 = LookupModule()
        lookup_run(lookup_module_0)
    except Exception as exc_0:
        pass
    dict_0 = {'a': exc_0}
    str_0 = 'a'
    assert dict_0[str_0]

# Generated at 2022-06-25 11:18:49.779625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'rbA>c%`sUi'
    str_1 = '\x1cO\x1e?z'
    list_0 = [str_0, str_1, lookup_module_0]
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_module_0.run(str_1, str_0, **dict_0)
    lookup_module_0 = LookupModule()
    str_0 = '\x1cO\x1e?z'
    str_1 = 'rbA>c%`sUi'
    list_0 = [str_0, str_1, lookup_module_0]

# Generated at 2022-06-25 11:18:59.055402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_module.run(list_0, dict_0)

    # assert isinstance(var_0,list), "lookup_module.run returned an unexpected type"
    assert var_0 == ['cv>I;IQAh6d#r/"mA;'], "lookup_module.run returned an unexpected value"



# Generated at 2022-06-25 11:19:08.015627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\x10]*\x0b\x16\x06\x1c\x0f\x0b\x10Ht"\x0bv\x07\x0f\x1a'

# Generated at 2022-06-25 11:19:09.898440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = lookup_module_0.run()
    assert int_0 == 0

# Generated at 2022-06-25 11:19:25.239473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)
    assert (str_1 == var_0)

# Util function to run the test cases

# Generated at 2022-06-25 11:19:31.525795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = create_test_LookupModule_instance()
    list_0 = lookup_module_0.run(['root', 'etc'], 'o^')
    assert type(list_0[0]) == str
    assert list_0[0] == 'abc'
    assert type(list_0[1]) == str
    assert len(list_0[1]) == 3
    assert type(list_0[2]) == str
    assert list_0[2] == '123'
    assert type(list_0[3]) == str
    assert len(list_0[3]) == 3
    assert type(list_0[4]) == str
    assert list_0[4] == '123'
    assert type(list_0[5]) == str
    assert len(list_0[5]) == 3


# Generated at 2022-06-25 11:19:40.800732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '8c%[=\x0c^X3q+IX8>'
    list_0 = [str_0, lookup_module_0]
    str_1 = 'X>g:N8>ZhJ\r^r]'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)

# Generated at 2022-06-25 11:19:44.727520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 's;n64,Z'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)


# Generated at 2022-06-25 11:19:51.321769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import lookup_template
        lookup_template.test_case_0()

        # Unit tests for lookup-template:run - assertEqual
        assertEqual(lookup_template.var_0[0], '# This is a template file for use with the "template" lookup.')

    # Unit tests for lookup-template:run - catch exception
    except Exception as exception_0:
        return exception_0

# Generated at 2022-06-25 11:19:52.678531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = test_case_0()
    assert len(var_0) == 0

# Generated at 2022-06-25 11:19:53.625539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:20:03.124640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate an instance of the object
    lookup_module = LookupModule()

    # Declare variables to use in testing
    lookup_module_dict = {"_ansible_no_log": False, "convert_data": False, "comment_end_string": "}}",
                          "comment_start_string": "{#", "jinja2_native": False, "template_vars": {},
                          "variable_end_string": "}}", "variable_start_string": "{{"}
    lookup_module_list = ["{{ lookup('foo', bar='baz') }}"]

    # Test
    assert lookup_module.run(lookup_module_list, lookup_module_dict)

# Generated at 2022-06-25 11:20:08.091323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == 'cv>I;IQAh6d#r/"mA;'

# Generated at 2022-06-25 11:20:17.439494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = 'unittest_term_0'
    variables = 'unittest_variables_0'
    convert_data = 'unittest_convert_data_0'
    lookup_template_vars = 'unittest_lookup_template_vars_0'
    jinja2_native = 'unittest_jinja2_native_0'
    variable_start_string = 'unittest_variable_start_string_0'
    variable_end_string = 'unittest_variable_end_string_0'
    comment_start_string = 'unittest_comment_start_string_0'
    comment_end_string = 'unittest_comment_end_string_0'

    # Test with assert of the string: 'The string marking the

# Generated at 2022-06-25 11:20:43.360754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameter setup
    terms = ["./some_template.j2"]
    variables = {}

    # Init
    lookup_module = LookupModule()

    # Execution
    run_output = lookup_module.run(terms, variables)

    # Validation
    assert run_output == "<!-- this is a template -->\nHello {{ ansible_managed }}\n"


# Generated at 2022-06-25 11:20:50.789061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '7Vw1/'
    list_0 = [str_0]
    str_1 = 'VYuN\x7f'
    dict_0 = {str_1: lookup_module_0, str_0: str_1}
    var_0 = lookup_module_0.run(list_0, **dict_0)

# Generated at 2022-06-25 11:20:55.199992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    b_0 = test_case_0()
    assert b_0


# Function to run a test case

# Generated at 2022-06-25 11:20:57.712820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'S'
    list_0 = [str_0]
    var_0 = lookup_module_0.run(list_0, None)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 11:21:05.322932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'O}Ud^y\n<#C~Am0'
    list_0 = [str_0, lookup_module_0]
    str_1 = 'k*b'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_module_0.run(list_0, **dict_0)
    assert var_0 != None, 'Method run of class LookupModule failed'

# Generated at 2022-06-25 11:21:10.573583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_module_0.run(list_0, list_0, **dict_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:21:21.573529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n# Unit test for method run of class LookupModule")
    var_0 = 'cv>I;IQAh6d#r/"mA;'
    var_1 = ['cv>I;IQAh6d#r/"mA;', LookupModule()]
    dict_0 = {'\nZU}\nS': ['cv>I;IQAh6d#r/"mA;', LookupModule()], 'cv>I;IQAh6d#r/"mA;': '\nZU}\nS'}
    var_2 = LookupModule.run(var_0, var_1, **dict_0)
    var_3 = ['\nZU}\nS']
    assert var_2 == var_3


# Generated at 2022-06-25 11:21:23.508935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test 1
    # TODO: Improve this test.
    # lookup_module.set_options(None, **{'var_options': None, 'direct': None})
    # expected = None
    # actual = lookup_module.run(**{'_terms': None, 'variables': None})
    # assert expected == actual



# Generated at 2022-06-25 11:21:33.421226
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:21:38.923592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '8wbe\x1d)\x7f%>*(y\t'
    list_0 = [str_0, lookup_module_0]
    str_1 = 'o\n8W\n'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)

# Generated at 2022-06-25 11:22:30.947112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'g>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)

# Generated at 2022-06-25 11:22:38.379798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    # In the current version of Ansible, templating will convert a string
    # of the form "False" to boolean False. This test checks that the raw
    # string form is preserved.
    lookup_module = LookupModule()
    str_0 = 'HI_h9`m$4=^s@8+v(2&{]E'
    list_0 = [str_0, lookup_module]
    str_1 = 'HI_h9`m$4=^s@8+v(2&{]'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)
    assert var_0 == 'False'


# Generated at 2022-06-25 11:22:45.316746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = 'szKGI\x19]V)_S'
    var_2 = ['dT!7g,(4', var_1, var_0]
    var_3 = '<8&j{'
    var_4 = '\x1e'
    var_5 = {var_3: var_4}
    var_6 = [var_2, var_1, var_5]
    var_7 = var_0.run(var_1, var_2, **var_5)

test_LookupModule_run()

# Generated at 2022-06-25 11:22:56.546030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=[], direct={'convert_data': True})
    lookup_module_0._loader = MockLoader()
    lookup_module_0._templar = MockTemplar()
    str_0 = '%c/N'
    list_1 = [str_0, lookup_module_0]
    str_1 = 'template_host'
    dict_1 = {str_1: list_1, str_0: str_1}
    var_0 = lookup_module_0.run(str_0, list_1, **dict_1)
    var_1 = lookup_run(str_0, list_1, **dict_1)
    assert var_0 == var_1


# Generated at 2022-06-25 11:23:07.782639
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:23:17.576077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '[R'
    list_0 = [str_0, lookup_module_0]
    str_1 = 'N\x7f'
    dict_0 = {str_1: list_0, str_0: str_1}
    str_2 = '\x0cT>'
    list_1 = [str_2, lookup_module_0]
    str_3 = 't2'
    dict_1 = {str_3: list_1, str_2: str_3}
    str_4 = '\x1a\x1b'
    list_2 = [str_4, lookup_module_0]
    str_5 = '!D'

# Generated at 2022-06-25 11:23:26.766357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)
#
# This is the block for test case for test_run of class test_lookup_plugins_template
#

# Generated at 2022-06-25 11:23:28.428884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check if the result from method run is equal to the expected result
    assert test_case_0() == expected_result


# Generated at 2022-06-25 11:23:33.898915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_module_0.run(str_0, list_0, **dict_0)


# Generated at 2022-06-25 11:23:39.034110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:25:37.868302
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:25:43.829233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = './some_template.j2'
    list_0 = [str_0]
    str_1 = 'param'
    str_2 = 'value'
    dict_0 = {str_1: str_2}
    str_3 = 'msg'
    var_0 = lookup_run(str_0, list_0, **dict_0)



# Generated at 2022-06-25 11:25:49.767207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)

# Generated at 2022-06-25 11:25:55.023916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'F '
    str_1 = 'J:aG<`"B$'
    str_2 = '\\nu'
    str_3 = 'B\\)%c'
    str_4 = 'iMPl'
    str_5 = 'Nc%'
    list_0 = [str_2, str_1, str_4]
    dict_0 = {str_4: str_4, str_5: str_4, str_1: str_1, str_2: str_4, str_0: list_0, str_3: str_4}
    var_0 = lookup_module_0.run('x<I,b', **dict_0)


# Generated at 2022-06-25 11:25:56.660271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = '{0}'
    terms = [data]
    variables = {'template_path': 'templates'}
    lookup_module = LookupModule()
    lookup_module.run(terms, variables, convert_data=True)
    lookup_module.run(terms, variables)


# Generated at 2022-06-25 11:26:01.034761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)


# Generated at 2022-06-25 11:26:05.488574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    lookup_module_0 = LookupModule()
    str_0 = 'cv>I;IQAh6d#r/"mA;'
    list_0 = [str_0, lookup_module_0]
    str_1 = '\nZU}\nS'
    dict_0 = {str_1: list_0, str_0: str_1}
    var_0 = lookup_run(str_0, list_0, **dict_0)

# 
# Tests for private method _clean_value() of class LookupModule
# 


# Generated at 2022-06-25 11:26:09.842359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert callable(getattr(lookup_module_0, 'run'))


# Generated at 2022-06-25 11:26:10.556089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == None



# Generated at 2022-06-25 11:26:15.104572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ";r>^p"
    str_1 = "^B\x02\x0f\x08"
    list_0 = [str_0, str_1]
    str_2 = "`FV4"
    dict_0 = {str_1: str_2, str_0: list_0}
    var_0 = LookupModule()
    test_case_0(var_0, str_0, list_0, **dict_0)