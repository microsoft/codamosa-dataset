

# Generated at 2022-06-25 11:17:06.158502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'z\n{#.x+4<1\t'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:17:16.650567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = {'mvn': '3qQ', 'b': 'wbyc%L)Y'}
    lookup_module_0 = LookupModule(terms_0)
    lookup_base_0 = LookupBase(terms_0)
    jinja2_native_0 = lookup_base_0.get_option('jinja2_native')
    convert_data_p_0 = lookup_base_0.get_option('convert_data')
    lookup_template_vars_0 = lookup_base_0.get_option('template_vars')
    variable_start_string_0 = lookup_base_0.get_option('variable_start_string')
    variable_end_string_0 = lookup_base_0.get_option('variable_end_string')
    searchpath_0 = lookup

# Generated at 2022-06-25 11:17:22.282988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = (1, 2)
    variables_0 = {}
    LookupModule_0 = LookupModule(variables_0)
    # Test exception raised
    try:
        LookupModule_0.run(term_0, variables_0, convert_data=true, jinja2_native=true)
    except SystemExit:
        pass
    # Test exception raised
    try:
        LookupModule_0.run(term_0, variables_0, comment_end_string=true, jinja2_native=true)
    except SystemExit:
        pass
    # Test exception raised
    try:
        LookupModule_0.run(term_0, variables_0, template_vars=true, jinja2_native=true)
    except SystemExit:
        pass
    # Test exception raised

# Generated at 2022-06-25 11:17:33.130151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '_raw'
    var_0 = [str_0]
    str_1 = 'T_bs|:kb~6?{c'
    dict_0 = {str_1: var_0, str_1: var_0, str_1: var_0}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(var_0, dict_0)

if __name__ == '__main__':
    dict_0 = {'__doc__': 'Returns a list of strings; for each template in the list of templates you pass in, returns a string containing the results of processing that template.\n'}
    str_0 = '- +ZDT%T)s\rrz\th'

# Generated at 2022-06-25 11:17:43.335134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = []

    # capture options
    convert_data_p = lookup_module_0.get_option('convert_data')
    lookup_template_vars = lookup_module_0.get_option('template_vars')
    jinja2_native = lookup_module_0.get_option('jinja2_native')
    variable_start_string = lookup_module_0.get_option('variable_start_string')
    variable_end_string = lookup_module_0.get_option('variable_end_string')
    comment_start_string = lookup_module_0.get_option('comment_start_string')
    comment_end_string = lookup_module_0.get_option('comment_end_string')


# Generated at 2022-06-25 11:17:44.207519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run()


# Generated at 2022-06-25 11:17:48.963021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'e+3q=whLm*%#6fhmrB'
    str_1 = 'hX8<NuV1v_Dw.f~7(o'
    lookup_module_0 = LookupModule({str_0: str_0, str_1: str_1})
    
    # Test with unittest.mock.
    try:
        lookup_module_0.run('somewhere/somewhere/somewhere', 'somewhere')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 11:17:59.953252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    lookup_module_0._templar = AnsibleEnvironment({})
    lookup_module_0._loader = {'_basedir': 'test_value_3'}
    lookup_module_0._loader._get_file_contents = {'_basedir': 'test_value_3'}
    dict_0 = {'template_vars': {}, 'jinja2_native': 'test_value_3'}
    lookup_module_0.set_options(var_options={}, direct=dict_0)
    str_0 = 'test_value_4'

# Generated at 2022-06-25 11:18:09.576889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin_0 = LookupModule()
    str_0 = '*'
    str_1 = '*'
    str_2 = '*'
    lookup_plugin_0.run(str_0, str_1, str_2)
    str_0 = '*'
    str_1 = '*'
    int_0 = 1
    lookup_plugin_0.run(str_0, str_1, int_0)
    str_0 = '*'
    str_1 = '*'
    int_0 = 0
    lookup_plugin_0.run(str_0, str_1, int_0)
    str_0 = '*'
    str_1 = '*'
    tuple_0 = (int_0, int_0, int_0)

# Generated at 2022-06-25 11:18:14.235501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '- +ZDT%T)s\rrz\th'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule(dict_0)
    str_1 = ''
    list_0 = [str_1]
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    list_1 = lookup_module_0.run(list_0, dict_1)
    assert(len(list_1) == 1)
    assert(list_1[0] is str_1)

# Generated at 2022-06-25 11:18:23.350353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = ['./some_template.j2']
    variables = {}
    result = lookup_module_0.run(term, variables)
    assert result is not None

# Generated at 2022-06-25 11:18:24.713728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    print(lookup_module.run(['../..'], {}, {}))

# Generated at 2022-06-25 11:18:31.149731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test/test_file_0']
    variables_0 = {}
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == [b'foo']

    lookup_module_1 = LookupModule()
    terms_1 = ['test/test_file_1']
    variables_1 = {}
    result = lookup_module_1.run(terms_1, variables_1)
    assert result == [b'test/test_file_1']

    lookup_module_2 = LookupModule()
    terms_2 = ['missing/missing_file_2']
    variables_2 = {}
    result = lookup_module_2.run(terms_2, variables_2)

# Generated at 2022-06-25 11:18:32.592730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/hosts']
    variables = dict(hostvars=dict())
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 11:18:43.796600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # creating instance of class LookupModule
    lookup_module_obj = LookupModule()

    # getting the path of directory where this file is located
    lookup_module_dir = os.path.dirname(os.path.realpath(__file__))
    # getting path of directory where test_file_for_lookup_template_0 is located
    lookup_module_test_data_dir = os.path.join(lookup_module_dir, 'test_data_LookupModule')
    # getting the path of test_file_for_lookup_template_0
    lookup_module_test_file_path = os.path.join(lookup_module_test_data_dir, 'test_file_for_lookup_template_0')
    # getting the content of test_file_for_lookup_template_0
   

# Generated at 2022-06-25 11:18:50.367425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.set_options(var_options=dict(), direct=dict()) == None
    assert lookup_module_0.get_option('convert_data') == True
    assert lookup_module_0.get_option('template_vars') == {}
    assert lookup_module_0.get_option('jinja2_native') == False
    assert lookup_module_0.get_option('variable_start_string') == '{{'
    assert lookup_module_0.get_option('variable_end_string') == '}}'
    assert lookup_module_0.get_option('comment_start_string') == '{#'
    assert lookup_module_0.get_option('comment_end_string') == '#}'
    assert lookup_module_0

# Generated at 2022-06-25 11:18:52.858713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    print('output: ', lookup_module.run(['./sample.j2'], {}))

# Test to confirm whether run method is returning expected output or not.

# Generated at 2022-06-25 11:19:02.320089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = [
        'ansible_facts',
        'ansible_facts',
        'ansible_facts',
        'ansible_facts',
    ]


# Generated at 2022-06-25 11:19:05.846546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 1
    # Arrange
    # Act
    test_case_0()



# Generated at 2022-06-25 11:19:10.123242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["../../../../../var/lib/jenkins/workspace/ansible/test/units/../../lib/ansible/plugins/lookup/moo.j2"]
    variables_0 = {}
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == ['MOO\n']

# Generated at 2022-06-25 11:19:21.999021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Pass the needed parameters to the AnsibleModule
    pass  # LookupModule.run()

# Generated at 2022-06-25 11:19:30.583182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock search path
    search_path = ['/a/b/c', '/x/y/z', '/etc/ansible']
    mock_variables = {'ansible_search_path': search_path}

    lookup_module_run = LookupModule()
    lookup_module_run.set_loader()

    lookupfile_run_check = lookup_module_run.find_file_in_search_path(mock_variables, 'templates', 'some_template.j2')

    assert lookupfile_run_check == '/a/b/c/templates/some_template.j2'



# Generated at 2022-06-25 11:19:31.369953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True is True


# Generated at 2022-06-25 11:19:38.130072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test normal input
    _terms = "test_terms"
    _variables = None
    _kwargs = {}
    _kwargs["convert_data"] = None
    _kwargs["comment_end_string"] = None
    _kwargs["comment_start_string"] = None
    _kwargs["jinja2_native"] = None
    _kwargs["template_vars"] = None
    _kwargs["variable_end_string"] = None
    _kwargs["variable_start_string"] = None
    lookup_module_1 = LookupModule()
    res = lookup_module_1.run(_terms, _variables, **_kwargs)
    if res != None:
        res = "pass"
    else:
        res = "fail"
    print(res)


# Generated at 2022-06-25 11:19:45.275985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['tests/templates/template-0.2.j2']
    variables_0 = {u'foo': u'0.0.0.0', u'ansible_connection': u'local', u'ansible_host': u'0.0.0.0', u'ansible_user': u'root'}
    kwargs_0 = {u'convert_data': False, u'lookup_template_vars': {u'color': u'red'}, 
                u'jinja2_native': False, u'variable_start_string': u'{{', u'variable_end_string': u'}}',
                u'comment_start_string': u'{#', u'comment_end_string': u'#}'}
    lookup_module_0 = LookupModule()
   

# Generated at 2022-06-25 11:19:52.267251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    lookup_module = LookupModule()
    terms = [
        'test.j2',
        'test1.j2',
        'test2.j2'
        ]
    variables = dict()
    variables = ImmutableDict(variables, frozen=True)
    assert isinstance(lookup_module.run(terms,variables), list)

# Generated at 2022-06-25 11:19:55.611260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_check_type(False)
    terms = ['./some_template.j2']
    variables = {"foo": "bar"}
    lookup_module.run(terms, variables)


# Generated at 2022-06-25 11:20:05.808508
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 0
    # input dict
    terms_0 = [2]
    variables_0 = {u'var': {u'key': [u'value']}, u'hostvars': {u'localhost': {u'groups': [u'development'], u'ansible_host': u'127.0.0.1', u'var': {u'key': [u'value']}}}, u'group_names': [u'development'], u'groups': {u'development': {u'hosts': [u'localhost']}}, u'inventory_hostname': u'localhost', u'inventory_hostname_short': u'localhost'}

# Generated at 2022-06-25 11:20:12.951922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test LookupModule.run() with the following params
    # params = [['../../../../../../../../../../../../../../../../../../../../../../../../../../../etc/passwd'], {'ansible_app_type': 'noop', 'ansible_app_version': 'v2.8.4.0-1', 'ansible_check_mode': False, 'ansible_diff_mode': False, 'ansible_host': '127.0.0.1', 'ansible_inventory_sources': ['/root/ansible_test/test_Playbook/hosts'], 'ansible_playbook_python': '/usr/bin/python', 'ansible_playbook_dir': '/root/ansible_test/test_Playbook', 'ansible

# Generated at 2022-06-25 11:20:14.898494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:20:36.144213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_1 = lookup_run(float_0, str_0)
    lookup_module_2 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_2 = lookup_run(float_0, str_0)
    lookup_module_3 = LookupModule()
    float_0 = 0.

# Generated at 2022-06-25 11:20:44.405956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'v3q'
    str_1 = '/V7&uN'
    str_2 = 'd9X/7'
    str_3 = 'jK.y'
    dict_0 = dict()
    dict_0[str_0] = str_1
    dict_0[str_2] = str_3
    var_0 = lookup_module_0.run(dict_0)
    var_1 = lookup_module_0.run()
    var_2 = lookup_module_0.run()
    var_3 = lookup_module_0.run()


# Generated at 2022-06-25 11:20:54.874819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # If a parameter or variable is "None", the method returns no value.
    lookup_module_0 = LookupModule()
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
   

# Generated at 2022-06-25 11:20:55.743538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()



# Generated at 2022-06-25 11:21:03.147845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, "run", None)), "Method does not exist"
    assert isinstance(LookupModule.run(0.1, 'wV\tFO*Wa8? k}wx}'), list) == True, "Incorrect return type"


# Generated at 2022-06-25 11:21:08.153849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # test 1
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)

    assert var_0 == [None]

    # test 2
    lookup_module_1 = LookupModule()
    


# Generated at 2022-06-25 11:21:12.922139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()
    float_1 = 0.1
    str_1 = 'wV\tFO*Wa8? k}wx}'
    var_1 = lookup_module_0.run(float_1, str_1)
    assert var_1 == var_0


# Generated at 2022-06-25 11:21:19.536318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    lookup_module_0.run(float_0, str_0)
    float_1 = 0.1
    str_1 = 'wV\tFO*Wa8? k}wx}'
    lookup_module_1 = LookupModule()
    lookup_module_1.run(float_1, str_1)



# Generated at 2022-06-25 11:21:22.689884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj_LookupModule = LookupModule()
    str_term = 'a'
    dict_variables = dict()
    dict_kwargs = dict()
    getattr(obj_LookupModule, 'run', test_case_0)()


# Generated at 2022-06-25 11:21:28.814186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'QjK?R2i_w&'
    var_0 = lookup_run(float_0, str_0)
    assert var_0 == None


# Generated at 2022-06-25 11:21:56.509570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:22:04.616896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    term = 'test.txt'
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    test_dict_0 = dict()
    cache_0 = Cache()


# Generated at 2022-06-25 11:22:10.750051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()



# Generated at 2022-06-25 11:22:16.607217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)

# Generated at 2022-06-25 11:22:20.464066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:22:23.915962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:22:34.875971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['some_string'] = 'T$T'
    column_0 = -0.01
    str_0 = 'NmA'
    dict_0['some_integer'] = lookup_run(column_0)
    dict_0['some_float'] = lookup_run(str_0)
    dict_0['some_dict'] = dict()
    dict_0['some_dict']['test_key'] = 'test_value'
    dict_0['some_list'] = list()
    dict_0['some_list'].append('test_value')
    dict_0['some_list'].append(dict_0['some_string'])
    dict_0['some_list'].append(dict_0['some_float'])

# Generated at 2022-06-25 11:22:41.459788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:22:43.416901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 0.5
    str_0 = 'b\t'
    assert lookup_run(float_0, str_0) == None


# Generated at 2022-06-25 11:22:46.646524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_module_0.run(float_0, str_0)
    assert var_0 == 23


# Generated at 2022-06-25 11:23:32.276252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(var_0, str_0)


# Generated at 2022-06-25 11:23:40.031377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:23:43.433117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0, str_0)
    assert lookup_module_0 is not None


# Generated at 2022-06-25 11:23:48.956675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    float_1 = 0.1
    str_1 = 'wV\tFO*Wa8? k}wx}'
    var_1 = lookup_run(float_1, str_1)
    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 11:23:55.483753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:23:57.951106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0, str_0)
    lookup_module_1 = LookupModule()



# Generated at 2022-06-25 11:24:01.350555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    float_1 = 0.1
    str_1 = 'wV\tFO*Wa8? k}wx}'
    var_1 = lookup_run(float_1, str_1)
    var_2 = str_1.join(lookup_module_2.run(var_1, str_1))


# Generated at 2022-06-25 11:24:05.717813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'

    # Invocation
    var_0 = lookup_module_0.run(float_0, str_0)

    # Verification
    print(var_0)


# Generated at 2022-06-25 11:24:07.761077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)

# Generated at 2022-06-25 11:24:09.753851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)


# Generated at 2022-06-25 11:26:16.989625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = 1
    var_0 = lookup_run(int_1)
    regex_0 = re.compile('\n')
    regex_1 = re.compile('\x1b\[0;30m')
    regex_2 = re.compile('\x1b\[0;33m')
    regex_3 = re.compile('\x1b\[0;32m')
    regex_4 = re.compile('\x1b\[0;31m')
    regex_5 = re.compile('\x1b\[0;36m')
    regex_6 = re.compile('\x1b\[0;35m')
    regex_7 = re.compile('\x1b\[0;34m')

# Generated at 2022-06-25 11:26:22.619153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    lookup_run(float_0, str_0)
    str_1 = 'J/`y/X,I/3-; g+KT'
    lookup_run(float_0, str_1)
    str_2 = 'j'
    lookup_run(float_0, str_2)



# Generated at 2022-06-25 11:26:24.597949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module_run = lookup_module.run('/usr/bin/passwd')
  assert not lookup_module_run, "lookup_module_run is not false"


# Generated at 2022-06-25 11:26:31.401084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)
    lookup_module_1 = LookupModule()
    chr_0 = 'St6z#c%B1p;&=@-y18'
    dict_0 = dict()
    dict_0_0 = dict()
    dict_0_1 = dict()
    dict_0_1_0 = dict()
    dict_0_1_0_0 = dict()
    dict_0_1_0_0_0 = dict()
    dict_0_1_0_1 = dict()
    dict_0_1_0_1_0 = dict()
    dict

# Generated at 2022-06-25 11:26:36.009838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['XjJ\t.']
    dict_0 = {}
    instance_0 = LookupModule()
    instance_0.run(list_0, dict_0)
    int_0 = 0
    list_1 = ['JIV<\t', 'N[=}9']
    lookup_run(int_0, list_1)
    int_1 = 0
    list_2 = ['@.9;']
    lookup_module_2 = LookupModule()
    lookup_run(int_1, list_2)
    int_2 = 0
    list_3 = [':M`i:']
    lookup_run(int_2, list_3)


# Generated at 2022-06-25 11:26:37.198192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:26:40.431539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'D'
    variables_0 = dict()
    lookup_options_0 = dict()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(term_0, variables_0, **lookup_options_0)


# Generated at 2022-06-25 11:26:45.697704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)


# Generated at 2022-06-25 11:26:51.051845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 0.1
    str_0 = 'wV\tFO*Wa8? k}wx}'
    var_0 = lookup_run(float_0, str_0)

    template_vars_0 = {'template_vars': {}}
    str_1 = 'wV\tFO*Wa8? k}wx}'
    var_1 = lookup_run(str_0, str_1, template_vars=template_vars_0)
