

# Generated at 2022-06-25 11:17:03.994213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:17:07.907176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = []

    variables_0 = {}

    ret_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:17:16.063429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First test
    test_terms = ['a.txt', 'b.txt']
    test_variables = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    test_values_dict = {
        'convert_data': True,
        'comment_end_string': '#]'
    }
    test_values = [
        './a.txt',
        './b.txt'
    ]
    test_options = {
        '_raw_params': '{{ lookup(\'template\', \'./a.txt\') + lookup(\'template\', \'./b.txt\') }}',
        '_terms': test_terms,
        '_variables': test_variables,
        'comment_end_string': '#]'
    }
    lookup

# Generated at 2022-06-25 11:17:26.766285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    lookup_module_run = LookupModule()
    lookup_module_run.set_options(var_options={'ansible_search_path':[fixture_path]})
    lookup_module_run.set_options(direct={'convert_data':False,'template_vars':{},'jinja2_native':False,'variable_start_string':"{{",'variable_end_string':"}}"})
    list_of_templates = ['test_case_0_fixture.j2']

# Generated at 2022-06-25 11:17:27.369350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:17:30.815426
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['./some_template.j2']
    variables = ''
    __result = test_case_0.run(terms, variables)

    assert type(__result) is list

# Generated at 2022-06-25 11:17:41.422178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_module_obj = LookupModule()

    # Define arguments for method run of class LookupModule
    term_0 = './some_template.j2'
    variable_start_string_0 = ''
    comment_start_string_0 = ''
    comment_end_string_0 = ''
    lookup_template_vars_0 = {}
    convert_data_p_0 = False
    jinja2_native_0 = True
    terms_0 = [term_0]
    variables_0 = {'ansible_search_path': ['/home/szu/projects/target_machine'], 'ansible_play_hosts': ['x.x.x.x']}

    # Call method run of class LookupModule with arguments

# Generated at 2022-06-25 11:17:48.598612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get a test class
    lookup_module_1 = LookupModule()

    # set options for the test

# Generated at 2022-06-25 11:17:59.712321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    print('Start test for method run of class LookupModule')
    # Define input variables
    terms_0 = './ansible/plugins/lookup/template.py'
    variables_0 = {'hostvars': {}}
    # Define expected output
    expected_0 = []
    # Run method under test
    lookup_module_0 = LookupModule()
    actual_0 = lookup_module_0.run(terms_0, variables_0)
    # Assert expected output equals actual output
    assert expected_0 == actual_0, 'expected: %s actual: %s' % (expected_0, actual_0)
    print('Success: expected: %s actual: %s' % (expected_0, actual_0))

# Generated at 2022-06-25 11:18:08.581971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['./some_template.j2']
    variables_1 = {}
    kwargs_1 = {'convert_data': False, 'template_vars': {}, 'comment_start_string': '', 'comment_end_string': '', 'jinja2_native': False, 'variable_start_string': '{{', 'variable_end_string': '}}'}
    expected_1 = ['']
    returned_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert returned_1 == expected_1


# Generated at 2022-06-25 11:18:22.892493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    var_0 = dict(foo='bar')
    dict_0.update({'_original_variables': var_0})
    dict_0.update({'foo': 'bar'})
    dict_0.update({'ansible_play_name': 'test'})
    dict_0.update({'template_path': '/etc/ansible/playbooks/play.yaml'})
    dict_0.update({'template_mtime': '1440011178.27'})
    dict_0.update({'template_uid': '0'})
    dict_0.update({'template_fullpath': '/etc/ansible/playbooks/play.yaml'})

# Generated at 2022-06-25 11:18:33.305710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/home/test0/U1Nzd2p5K0tIU3Q3b1FkYg=='
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

    b_str_0 = to_bytes(str_0)
    b_str_0 = to_bytes(str_0)
    b_str_0 = to_bytes(str_0)
    b_str

# Generated at 2022-06-25 11:18:44.412175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('test_LookupModule_run')
    # Load the test data from a data file
    test_case_0_var_0 = load_test_data('test_case_0_var_0.pkl')
    test_case_0_var_1 = load_test_data('test_case_0_var_1.pkl')
    test_case_0_var_2 = load_test_data('test_case_0_var_2.pkl')
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, test_case_0_var_0, test_case_0_var_1, test_case_0_var_2)
    if (var_0 == None):
        raise Exception('AssertionError')

# Creating an

# Generated at 2022-06-25 11:18:46.591333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)


# Generated at 2022-06-25 11:18:57.416944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Generate inputs and outputs
    dict_0 = dict()
    dict_0['zh6p1'] = 'E'
    dict_0[''] = ''
    dict_0['(:'] = ''
    dict_0['z>6'] = '6'
    dict_0[':<q'] = 'e'
    dict_0['rj>2'] = '1'
    dict_0[''] = ''
    dict_0['R:)C'] = ''
    dict_0['JdK'] = '5+'
    dict_0[''] = ';'
    dict_0['@I'] = 'K'
    dict_0[''] = 'f'
    dict_0['^x(P'] = '>'
    dict_0['2.R'] = '<'


# Generated at 2022-06-25 11:19:07.876895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test run start')

    # Start with something simple, like a single template and a simple lookup.
    # First, create a lookup module.
    test_module = LookupModule()
    # Then here's the template:
    test_template = 'Hello, {{my_var}}'
    # and here are the variables it needs:
    test_variables = {'my_var': 'world!'}
    # and then, finally, here's the lookup:
    lookup_result = lookup_run(test_module, test_variables, template_vars={'test_var': 'world!'},
                               convert_data=False, jinja2_native=False)
    # The result should be a list of single string:
    assert type(lookup_result) == list
    assert len(lookup_result) == 1
   

# Generated at 2022-06-25 11:19:14.877768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '07GpNc'
    str_1 = 'kMtD'
    str_2 = 'QcF'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0._options
    var_1 = lookup_module_0._templar
    var_2 = lookup_module_0.run(var_0, var_1)
    var_3 = lookup_module_0._options
    var_4 = var_3[str_0]
    var_5 = var_3[str_1]
    var_6 = var_3[str_2]

# Generated at 2022-06-25 11:19:15.654243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:19:18.272628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "H'e{bu]"
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)

# Test from documentation

# Generated at 2022-06-25 11:19:23.121424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'http://www.google.com'
    str_1 = 'http://www.facebook.com'
    str_2 = str_1
    lookup_module_0 = LookupModule()
    dict_0 = {str_2: str_0}
    assert lookup_run(lookup_module_0, dict_0)

# Generated at 2022-06-25 11:19:41.588320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {'l_terms': ['./some_template.j2'], 'l_variables': {'l_start_string': '{{', 'l_end_string': '}}', 'l_comment_start_string': '{{', 'l_comment_end_string': '}}'}}
    var_0 = lookup_run(lookup_module_0, dict_0)
    print(var_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:19:46.336635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_module_0 = LookupModule()
    # test for function run where there are no terms passed in
    assert lookup_module_0.run(terms=None, variables=None) == [], 'tests for function run where there are no terms passed in'


# Generated at 2022-06-25 11:19:54.888939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.display = Mock()
    lookup_module_0.set_options(var_options={}, direct={})

    assert lookup_module_0.run(terms=[], variables={}) == []
    assert lookup_module_0.__getattribute__('display').method_calls == [call.debug('File lookup term: '), call.vvvv('File lookup using as file')]
    assert lookup_module_0.__getattribute__('_templar').__getattribute__('environment_class') == AnsibleEnvironment


# Generated at 2022-06-25 11:20:00.922195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)


# Generated at 2022-06-25 11:20:04.345587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for case 0
    test_case_0()
    # Test for case 1
    str_0 = '_zRZ5'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)

# Generated at 2022-06-25 11:20:06.800307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)

# Generated at 2022-06-25 11:20:14.015190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['7Swwjy+KHSt7oQdb', '7Swwjy+KHSt7oQdb']
    variables_0 = {'7Swwjy+KHSt7oQdb': '7Swwjy+KHSt7oQdb'}
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(terms_0, variables_0)
    assert var_1 == []

# Generated at 2022-06-25 11:20:20.655064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar = Templar()
    dict_0 = {'s': './s', 'o': 'o', 'd': 'd', 'u': 'u', 'm': 'm', 'y': 'y', 'w': 'w', 'j': 'j', 'H': 'H', 't': 't', 'K': 'K', 'S': 'S', '+': '+'}
    test_vars = {}
    test_vars['ansible_search_path'] = dict_0.get('S')
    terms_1 = test_vars.get('ansible_search_path') + dict_0.get('w') + test_vars.get('ansible_search_path') + dict_0.get('w') + dict_0.get('j') + dict_0.get('y') + dict_

# Generated at 2022-06-25 11:20:22.180968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Returned type
    assert isinstance(test_case_0(), list)
    # Returned element type
    assert isinstance(test_case_0()[0], str)

# Generated at 2022-06-25 11:20:24.993321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)
    assert var_0 == [str_0]

# Generated at 2022-06-25 11:20:45.224518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:20:55.075977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'xJ1V5Nw'
    lookup_module_0.set_loader(str_0)
    str_1 = 'r5eA'
    str_2 = 'Realizaci'
    str_3 = 'Qaampl'
    str_4 = str_1 + str_2 + 'n de un' + str_3
    list_0 = []
    list_0.append(str_4)
    dict_0 = {str_4: str_4}
    lookup_module_0.set_vars(dict_0)
    bool_0 = lookup_module_0.run(list_0)
    assert bool_0


# Generated at 2022-06-25 11:21:00.824804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, dict_0)
    var_1 = assert_equal(var_0, dict_0)
    dict_0 = {}
    var_0 = lookup_run(lookup_module_0, dict_0)
    var_1 = assert_equal(var_0, dict_0)
    dict_0 = {}
    var_0 = lookup_run(lookup_module_0, dict_0)
    var_1 = assert_equal(var_0, dict_0)
    dict_0 = {}
    var_0 = lookup_run(lookup_module_0, dict_0)
    var_1 = assert_equal(var_0, dict_0)


# Generated at 2022-06-25 11:21:11.286646
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:21:17.912103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    list_0 = [str_0]
    dict_0 = {str_0: str_0}
    var_0 = lookup_module_0.run(list_0, dict_0)
    assert var_0 == [str_0]

# Generated at 2022-06-25 11:21:29.327416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instance object of lookup module
    lookup_module = LookupModule()
    # define file path
    lookup_file = os.path.abspath(os.path.join(os.path.dirname(__file__), ".test_files/test_file_lookup.txt"))

    # define search path variable for the lookup module
    search_path = []
    search_path.append(os.path.dirname(lookup_file))

    # define variable dictionary
    variable_dict = {}
    variable_dict['ansible_search_path'] = search_path

    # call the run method of lookup module
    lookup_run = lookup_module.run(['test_file_lookup.txt'], variable_dict)

    # assert that the returned string is equal to the content of the file

# Generated at 2022-06-25 11:21:39.168788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {'some': 'data'}
    var_0 = lookup_run(lookup_module_0, dict_0)
    assert var_0 == dict_0

    dict_0 = {'some': 'data', 'template_vars': {'some': 'newdata'}, 'unique_id': 'unique_id'}
    var_0 = lookup_run(lookup_module_0, dict_0)
    assert var_0 == dict_0

    dict_0 = {'some': 'data', 'template_vars': {'some': 'newdata'}, 'unique_id': 'unique_id', 'variable_start_string': '{{', 'variable_end_string': '}}'}

# Generated at 2022-06-25 11:21:40.396802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:21:42.407115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(lookup_module_0, dict_0)

# Generated at 2022-06-25 11:21:49.831374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for run
    import ansible.module_utils.module_common
    global ansible_search_path
    global lookupfile
    global loader
    global templar
    global module_args
    global _
    global __
    global ___
    global convert_data_p
    global lookup_template_vars
    global jinja2_native
    global variable_start_string
    global variable_end_string
    global comment_start_string
    global comment_end_string
    global b_template_data
    global show_data
    global template_data
    global searchpath
    global p
    global newsearchpath
    global term
    global vars
    global res
    global ret
    global variables
    test_case_0__0 = 'ansible_search_path'
    test_case_

# Generated at 2022-06-25 11:22:41.225430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'C(7Swwjy+KHSt7oQdb)'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    lookup_module_0.run(dict_0)

# Generated at 2022-06-25 11:22:48.050082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    (str_0, str_1, str_2, str_3, str_4, str_5, str_6) = (to_bytes('y'), to_bytes('\''), to_bytes('<'), to_bytes('\x1c'), to_bytes('['), to_bytes('\x0f'), to_bytes('T'))
    (dict_0, dict_1, dict_2, dict_3) = ({str_1: str_2, str_3: str_4, str_5: str_6}, {str_1: str_2, str_3: str_4, str_5: str_6}, {str_1: str_2, str_3: str_4, str_5: str_6}, {})

# Generated at 2022-06-25 11:22:53.305577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''
    str_0 = 'test'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, dict_0)
    assert var_0 is not None


# Generated at 2022-06-25 11:22:56.039143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(lookup_module_0, dict_0)
    assert isinstance(var_0, list)
    assert not var_0


# Generated at 2022-06-25 11:23:03.632852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fname_0 = 'templates'
    term_0 = './some_template.j2'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, fname_0)
    var_1 = lookup_run(lookup_module_0, term_0)



# Generated at 2022-06-25 11:23:14.856192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['', 'tnQrmdlm0=', 'tnQrmdlm0=', 'tnQrmdlm0=', '', '', '', '', '', '', '']
    variables_0 = {'ansible_fqdn': 'DUMMY_VALUE'}
    direct_0 = {'_original_file': './ansible/test/sanity/code/src/ansible/plugins/lookup/template.py', '_module_name': 'template', '_terms': terms_0, 'variable_start_string': '{{', 'variable_end_string': '}}'}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables_0, direct=direct_0)
    result_0 = lookup_module

# Generated at 2022-06-25 11:23:20.734334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_1 = {'template_vars': {'key1': 'val1', 'key2': 'val2'}, '_terms': ['test.j2']}
    var_1 = lookup_run(lookup_module_0, dict_1)
    assert len(var_1) == 1
    assert var_1[0] == '\n# A comment\n\nkey1: {{ key1 }}\nkey2: {{ key2 }}\n\n'


# Utility function to call lookup module run method

# Generated at 2022-06-25 11:23:24.664141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()



# Generated at 2022-06-25 11:23:28.404220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)

# Unit testing for method run of class LookupModule

# Generated at 2022-06-25 11:23:30.699017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    var_0 = lookup_run(lookup_module_0, dict_0)


# Generated at 2022-06-25 11:25:31.231182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    env_0 = os.environ['HOME']
    template_0 = 'templates'
    os.environ[env_0] = template_0
    # Case 0 - Case with variables and template_vars
    str_0 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    lookup_module_0 = LookupModule()
    dict_0 = {}
    list_0 = lookup_run(lookup_module_0, dict_0)
    # assert looks ok

    # Case 1 - Case with variables and template_vars (use jinja2_native)
    str_0 = '6xk7iT0FayniZ7pD'
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:25:40.752819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)
    try:
        assert var_0 == ()
    except AssertionError:
        raise AssertionError('Unable to run test assert_equals(...)')

if __name__ == '__main__':
    str_0 = '7Swwjy+KHSt7oQdb'
    lookup_module_0 = LookupModule()
    test_case_0()
    dict_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, dict_0)
   

# Generated at 2022-06-25 11:25:48.383040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {'foo': 'foo'}
    res_0 = lookup_module_0.run(['foo'], dict_0)
    assert res_0 == ['foo']



# Generated at 2022-06-25 11:25:51.574459
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:25:55.652141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except AssertionError:
        raise AssertionError('test_LookupModule_run failed')


# Generated at 2022-06-25 11:26:02.460954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock object for LookupBase
    lookup_base_0 = LookupBase()
    lookup_base_0.set_loader = MagicMock()
    lookup_base_0.set_environment = MagicMock()
    lookup_base_0.get_basedir = MagicMock(return_value=str_0)
    lookup_base_0.get_option = MagicMock(return_value=str_0)
    lookup_base_0.find_file_in_search_path = MagicMock(return_value=str_0)
    # Create mock object for template
    template_0 = template()
    template_0.set_options = MagicMock()
    template_0.template = MagicMock(return_value=str_0)
    lookup_base_0._templar = template_0
   

# Generated at 2022-06-25 11:26:09.800223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_terms_0 = ['test/test_file']
    lookup_variables_0 = {'location': 'test/test_file'}
    lookup_kwargs_0 = {'convert_data': False, 'template_vars': {'value': 23}}
    jinja2_native = False
    USE_JINJA2_NATIVE = True
    lookup_ret_0 = lookup_module_0.run(lookup_terms_0, lookup_variables_0, lookup_kwargs_0)
    assert lookup_ret_0 == [u'test']


# Generated at 2022-06-25 11:26:13.247382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['7Swwjy+KHSt7oQdb']
    dict_0 = {'7Swwjy+KHSt7oQdb': '7Swwjy+KHSt7oQdb'}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 11:26:20.955453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    dict_0 = {list_0[0]: list_0[1], list_0[2]: list_0[3], list_0[4]: list_0[5]}
    result_0 = lookup_run(lookup_module_0, dict_0)


# Generated at 2022-06-25 11:26:27.346199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'uyat5K5uz5+NPyt/'
    variables_0 = {term_0: term_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, variables_0)
    assert isinstance(var_0, list)