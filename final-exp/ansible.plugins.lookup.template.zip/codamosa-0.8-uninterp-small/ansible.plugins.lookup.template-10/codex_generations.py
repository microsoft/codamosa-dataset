

# Generated at 2022-06-25 11:17:05.541820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    res = lookup_module_1.run()
    assert res == None

# Generated at 2022-06-25 11:17:16.623735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_1['_terms'] = list(range(0, 10))
    dict_2['_terms'] = list(range(0, 10))
    dict_3['_terms'] = list(range(0, 10))
    dict_1['template_vars'] = dict_2
    dict_1['convert_data'] = dict_3
    dict_4 = {}
    dict_4['msg'] = ' '.join([str(i) for i in lookup_module_0.run(dict_1, dict_4)])
    dict_5 = {}

# Generated at 2022-06-25 11:17:21.886028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = ['path/to/template.yaml']
    variables_0 = {}
    kwargs_0 = {
    }
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_0 == [

]

# Generated at 2022-06-25 11:17:23.478807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:17:35.800267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Purpose of this unit test is to ensure that the run method of
    LookupModule class is working without any problem

    Parameters
    ----------
    None

    Returns
    -------
    type: unittest.TestResult
    """
    loader_mock = unittest.mock.MagicMock()
    loader_mock.get_basedir.return_value = unittest.mock.sentinel.get_basedir_return_value
    templar_mock = unittest.mock.MagicMock()
    templar_mock.template.return_value = unittest.mock.sentinel.template_return_value
    templar_mock.set_temporary_context.return_value = unittest.mock.sentinel.set_temporary_context_return_value

# Generated at 2022-06-25 11:17:40.382062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_data = """\
{{ foo }}
{{ foo.bar }}
{{ foo[bar] }}
{{ foo["bar"] }}
{{ foo["bar"]["baz"] }}
{{ foo|default('bar') }}
{{ foo|default(None) }}
{{ foo|default("foo", bar) }}
{{ [1,2,3,4]|join("-") }}
{{ "a-b-c"|regex_search("a(.*?)b")|regex_replace("a(.*?)b", "b\\1a") }}
{{ bar|to_json }}
"""
    template_variables = {
        "foo": {
            "bar": {
                "baz": "Hello World"
            }
        },
        "bar": "foo"
    }

# Generated at 2022-06-25 11:17:44.630271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [str()]
    variables_0 = {}
    try:
        ret = lookup_module_0.run(terms_0, variables_0)
    except AnsibleError as exception_0:
        ret = exception_0.args[0]
    raise TypeError
    return ret

# Generated at 2022-06-25 11:17:47.063420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['./some_template.j2']
    variables = {}
    kwargs = {}
    lookup_module_0 = LookupModule(**kwargs)
    ret = lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:17:57.456863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = []
    variables_0 = {}

# Generated at 2022-06-25 11:18:04.824503
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a file that does not exist - exception
    with pytest.raises(AnsibleError):
        yaml.load(lookup_module_0.run(terms=['my_file.j2'], variables=dict_0))
    # Test with a file that exists
    lookup_module_0.run(terms=['my_file.j2'], variables=dict_0)

# Generated at 2022-06-25 11:18:18.504258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n    Purpose of this unit test is to ensure that the run method of\n    LookupModule class is working without any problem\n\n    Parameters\n    ----------\n    None\n\n    Returns\n    -------\n    type: unittest.TestResult\n    '


# Generated at 2022-06-25 11:18:22.091189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == str_0

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:18:24.734000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:18:33.696416
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:44.880331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    from ansible.module_utils._text import to_bytes, to_text

    class Environment0(object):

        no_log = None

    class Environment1(object):

        no_log = None

        def get_plugin_vars(self, play_context):
            ret = dict()
            ret['template_run_additional_vars'] = dict()
            return ret

    environments = [Environment0, Environment1]

    @contextmanager
    def set_environ(name, value):
        old_value = os.environ.get(name)
        if value is None:
            if name in os.environ:
                del os.environ[name]
        else:
           os.environ[name] = value

# Generated at 2022-06-25 11:18:51.489715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Redefine global variables for this unit test
    global display
    display = Display()

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    test_case = unittest.FunctionTestCase(test_case_0)
    suite = unittest.TestSuite()
    suite.addTest(test_case)
    unittest.TextTestRunner().run(suite)

# Generated at 2022-06-25 11:19:01.322396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n    Purpose of this unit test is to ensure that the run method of\n    LookupModule class is working without any problem\n\n    Parameters\n    ----------\n    None\n\n    Returns\n    -------\n    type: unittest.TestResult\n    '
    terms = '\n    Purpose of this unit test is to ensure that the run method of\n    LookupModule class is working without any problem\n\n    Parameters\n    ----------\n    None\n\n    Returns\n    -------\n    type: unittest.TestResult\n    '

# Generated at 2022-06-25 11:19:11.051591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_0 = './file_name_0.j2'
    converter_0 = LookupModule()
    converter_0.set_options(var_options={'ansible_search_path': []}, direct={'convert_data': False, 'template_vars': {}, 'jinja2_native': True, 'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': None, 'comment_end_string': None})
    result_0 = converter_0.run([template_0], {'ansible_search_path': []})
    assert result_0 == [str_0]

# Generated at 2022-06-25 11:19:20.631267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule.run(
        {'source_path': 'foo/bar'},
        {'ansible_search_path': [
            '/home/oleg/work/MEGAsync/ansibleproject/ansible-base/lib/ansible/modules/files',
            '/home/oleg/work/MEGAsync/ansibleproject/ansible-base/lib/ansible/modules/system'
        ]},
        _terms=['/home/oleg/.ansible/collections/ansible_collections/olegsh/test/tests/test_data/test_scenario/unit_test']
    )


# Generated at 2022-06-25 11:19:31.461666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n    Purpose of this unit test is to ensure that the run method of\n    LookupModule class is working without any problem\n\n    Parameters\n    ----------\n    None\n\n    Returns\n    -------\n    type: unittest.TestResult\n    '

# Generated at 2022-06-25 11:19:41.351615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0, )
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}

    lookup_module_0 = LookupModule(**dict_1)
    var_0 = lookup_module_0.run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:19:48.628774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwarg_template_vars = {u'var_0': u'test_run'}
    kwargs_0 = {'convert_data': False, 'template_vars': kwarg_template_vars}
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    var_0 = lookup_run(tuple_0, list_0, **kwargs_0)

# Generated at 2022-06-25 11:19:50.935106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except:
        import traceback
        print(traceback.format_exc())


# Generated at 2022-06-25 11:19:53.763388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_var_1 = []
    dict_var_1 = {}
    lookup_module_var_1 = LookupModule(**dict_var_1)
    result = lookup_module_var_1.run(list_var_1, dict_var_1)
    assert result == []



# Generated at 2022-06-25 11:20:04.537692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, 'run'))

    assert isinstance(LookupModule.run(LookupModule, *()), list)

    assert isinstance(LookupModule.run(LookupModule, *()), list)

    assert isinstance(LookupModule.run(LookupModule, *()), list)

    assert isinstance(LookupModule.run(LookupModule, *()), list)

    assert isinstance(LookupModule.run(LookupModule, *()), list)

    assert isinstance(LookupModule.run(LookupModule, *()), list)

    assert isinstance(LookupModule.run(LookupModule, *()), list)

    assert isinstance(LookupModule.run(LookupModule, *()), list)


# Generated at 2022-06-25 11:20:10.229258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (None,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    var_0 = lookup_run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:20:16.921893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #Test case0
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    var_0 = lookup_module_0.run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:20:22.647579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_mock_0 = lookups.LookupModule(**kwargs)
    lookup_run(terms, variables, **kwargs)
    lookup_module_mock_0.run.assert_called_once_with(terms, variables, **kwargs)

# Generated at 2022-06-25 11:20:31.379473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['templates']
    variables_0 = {}
    dict_0 = {}
    dict_1 = {}
    lookup_module_1 = LookupModule(**dict_0)
    str_0 = lookup_base_run(terms_0, variables_0, **dict_1)
    lookup_module_2 = LookupModule()
    terms_1 = ['templates']
    variables_1 = {'ansible_search_path': ['tmp', 'var/tmp', '/tmp', '/var/tmp'], 'role_path': '.', 'playbook_dir': '..'}
    dict_2 = {}
    dict_3 = {}
    lookup_module_3 = LookupModule(**dict_2)

# Generated at 2022-06-25 11:20:39.269040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**dict())
    assert isinstance(lookup_module_0.run(['', '', '', ''], ['', '', '']), list)


# Generated at 2022-06-25 11:20:55.451431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = generateLookupModule()
    str_0 = None
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 11:21:01.895422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: check results values
    ret = LookupModule.run(None, None, **None)
    assert ret == None

# Generated at 2022-06-25 11:21:04.243013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:21:08.568819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    var_0 = lookup_run(tuple_0, list_0, **dict_0)
    #assert var_0 == tuple_0

# Generated at 2022-06-25 11:21:12.591353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arguments = {'terms': ['./some_template.j2'], 'variables': {'template_vars': {}}}
    kwargs = {'convert_data': False, 'variable_end_string': '}}', 'variable_start_string': '{{', 'jinja2_native': False}
    obj = LookupModule(**kwargs)
    result = obj.run(**arguments)
    assert result == '<to be generated>'


# Generated at 2022-06-25 11:21:15.523900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    var_0 = lookup_module_0.run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:21:21.583900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    dict_1 = {}
    tuple_0 = (dict_0,)
    list_0 = [tuple_0, tuple_0]
    var_0 = lookup_module_0.run(list_0, dict_1)
    assert var_0 is not None
    assert var_0 == []
    # assert var_0 == [dict_0, dict_0]

# Generated at 2022-06-25 11:21:23.410653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_2 = {}

    lookup_module_1 = LookupModule(**dict_2)
    assert lookup_module_1.run() == None

# Generated at 2022-06-25 11:21:31.148024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('~/Desktop/automation/Ansible/ansible/modules/packaging/os/synchronize.py', '~/Desktop/automation/Ansible/ansible/modules/packaging/os/synchronize.py', **{'direct': '~/Desktop/automation/Ansible/ansible/modules/packaging/os/synchronize.py'})

# Generated at 2022-06-25 11:21:31.736428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True


# Generated at 2022-06-25 11:22:01.655936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuples_0 = (
        (1, 1, 1),
        (1, 2, 3)
    )
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    str_0 = lookup_module_0.run(tuples_0, dict_0)
    assert str_0 == ['abc']

# Generated at 2022-06-25 11:22:11.012784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    lookup_run(tuple_0, list_0, **dict_0)


# Generated at 2022-06-25 11:22:17.302948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**dict_1)
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    var_0 = lookup_module_0.run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:22:25.452774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  Terms = ( False, True, False, True, False, True, True, True, True, True )
  Variables = ( True, True, True, True, True, True, True, True, True, True )
  Kwargs = ( True, False, True, True, False, True, False, True, False, True )

  # Test 0
  Terms = ( None, True, True, True, None, None, True, True, True, True )
  Variables = ( None, False, True, False, True, None, True, True, None, True )
  Kwargs = ( True, True, None, True, False, True, False, True, False, True )
  test_case_0()

  # Test 1
  Terms = ( True, None, True, True, True, True, True, None, True, True )
  Vari

# Generated at 2022-06-25 11:22:35.820785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    lookup_module_0.run(list_0, list_0, convert_data=True, template_vars=dict_0, jinja2_native=True, variable_start_string='', variable_end_string='', comment_start_string='', comment_end_string='')

# Generated at 2022-06-25 11:22:37.773767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term0 = ()
    # Parameters: terms (list,), variables (dict,)
    lookup_module_var = LookupModule()
    lookup_module_var.run(term0, {})


# Generated at 2022-06-25 11:22:46.363885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = "./some_template.j2"
    terms = [term]
    variables = []
    lookup_module_0 = LookupModule()
    try:
        LookupModule.run()
        assert False # Should not reach this line
    except Exception:
        assert True
    try:
        LookupModule.run(lookup_module_0)
        assert False # Should not reach this line
    except Exception:
        assert True
    try:
        LookupModule.run(lookup_module_0, terms)
        assert False # Should not reach this line
    except Exception:
        assert True
    try:
        LookupModule.run(lookup_module_0, terms, variables)
        assert True # Should reach this line
    except Exception:
        assert False

# Generated at 2022-06-25 11:22:52.647668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    var_0 = lookup_run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:22:58.626493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case: "'foo': 'bar'"
    terms_0 = "'foo': 'bar'"
    variables_0 = None
    tuple_0 = (terms_0, variables_0, )
    tuple_1 = (None, )
    list_0 = [tuple_1, tuple_1]
    dict_0 = {"variable_start_string": "foo", "comment_start_string": "foo", "convert_data": True, "comment_end_string": "foo", "variable_end_string": "foo", "template_vars": "foo", "jinja2_native": True, }
    list_1 = [list_0, list_0]
    list_2 = [list_1, list_1]

# Generated at 2022-06-25 11:23:05.474322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    source_1 = "undefined_variable"
    source_2 = "/usr/share/ansible/plugins/lookup/template.py"
    source_3 = "kip5b5kno"
    tuple_1 = ("{{ ", " }}")
    str_0 = "kip5b5kno"
    str_1 = "{{ "
    str_2 = " }}"
    str_3 = "kip5b5kno"
    str_4 = "hdakjk7d0"
    str_5 = "hdakjk7d0"
    str_6 = "hdakjk7d0"
    bytes_0 = None
    tuple_2 = (bytes_0,)
    list_0 = [tuple_2, tuple_2]
    dict_0 = {}
    dict_

# Generated at 2022-06-25 11:23:54.406353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None
    variables = None
    kwargs = ()
    lookup_module_0 = LookupModule(**kwargs)
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
    assert var_0 == None



# Generated at 2022-06-25 11:24:00.424343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_1 = None
    tuple_1 = (bytes_1,)
    list_1 = [tuple_1, tuple_1]
    dict_2 = {}
    dict_3 = {}
    lookup_module_1 = LookupModule(**dict_3)
    var_1 = lookup_run(tuple_1, list_1, **dict_2)

# Generated at 2022-06-25 11:24:01.938438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:24:05.586338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    lookup_module_0.run(tuple_0, **dict_0)


# Generated at 2022-06-25 11:24:07.993012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:24:10.504008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    lookup_run(tuple_0, list_0, **dict_0)


# Generated at 2022-06-25 11:24:16.235844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _start_string = "[%"
    _end_string = "%]"
    _comment_start_string = "[#"
    _comment_end_string = "#]"
    _quote_template = '"%s"'
    _term = "{{ _start_string }}{{ _end_string }}{{ _comment_start_string }}{{ _comment_end_string }}"
    _terms = [_term]
    _vars = {"_start_string": _start_string, "_end_string": _end_string}
    _kwargs = {
        "variable_start_string": _start_string,
        "variable_end_string": _end_string,
        "comment_start_string": _comment_start_string,
        "comment_end_string": _comment_end_string
    }

    lookup_

# Generated at 2022-06-25 11:24:20.452800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    var_0 = lookup_run(tuple_0, list_0, **dict_0)
    lookup_module_0.run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:24:21.540257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run()
    assert result is None


# Generated at 2022-06-25 11:24:25.253465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=[], variables={}, direct={'lookup_opts': {'j2_inheritance': None}})
    assert ret == []
    ret = lookup_module_0.run(terms=[], variables={}, direct={})
    assert ret == []


# Generated at 2022-06-25 11:26:39.039908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**kwargs_0)
    with patch('ansible.plugins.lookup.template.LookupModule.set_options', new_callable=mock_set_options):
        with patch('ansible.utils.template.is_template_file', return_value=True):
            with patch.object(display, 'debug', autospec=True) as mock_debug:
                mock_debug.return_value = None
                with patch.object(display, 'vvvv', autospec=True) as mock_vvvv:
                    mock_vvvv.return_value = None

# Generated at 2022-06-25 11:26:45.609349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ('pytest',)
    list_0 = [(1, 'xyz'), ()]
    dict_0 = {}
    var_0 = lookup_run(tuple_0, list_0, **dict_0)

# Generated at 2022-06-25 11:26:51.689092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run of method run of class LookupModule')
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(**dict_1)
    var_0 = lookup_module_0.run(tuple_0, list_0, **dict_0)
    print('var_0: %s' % str(var_0))
    print('Finished testing run of method run of class LookupModule')
test_LookupModule_run()

# Generated at 2022-06-25 11:26:54.650449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        globals().clear()
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 11:27:01.029396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    list_0 = [tuple_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    int_0 = 0
    dict_6 = {}
    dict_5['ansible_search_path'] = list_0
    dict_6['magic'] = int_0
    dict_6['_remote_tmp'] = dict_5
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_12['jinja2_native'] = False