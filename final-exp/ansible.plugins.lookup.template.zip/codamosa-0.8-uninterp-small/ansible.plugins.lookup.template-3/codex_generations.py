

# Generated at 2022-06-25 11:17:03.736515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 11:17:12.579221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    kwargs = {'template_vars': {}, 'convert_data': False, 'jinja2_native': True, 'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': None, 'comment_end_string': None}
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run('', '', **kwargs)
    assert 'the template file  could not be found for the lookup' in str(excinfo.value)


test_case_0()

test_LookupModule_run()

test_AnsibleCollector_run()

# Generated at 2022-06-25 11:17:20.372285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = '"{{inventory_hostname}}"'
    variables_1 = { 'inventory_hostname' : '"test"' }
    kwargs_1 = { 'variable_start_string'  : '"{{"', 'variable_end_string' : '"}}"' }
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == ['"test"']


# Generated at 2022-06-25 11:17:25.380209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [u'some_template_with_end_format.j2']
    variables_0 = {}
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == ['Some text']


# Generated at 2022-06-25 11:17:26.647964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:17:32.463299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["./var_name.j2"]
    variables = {}
    kwargs = {'template_vars': {}, 'convert_data': True}
    template = lookup_module.run(terms=terms, variables=variables, **kwargs)
    print(template)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:17:41.951336
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:17:53.570210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(dict())
    lookup_module_0._templar = MagicMock()
    lookup_module_0._loader = MagicMock()
    lookup_module_0._loader.get_basedir = MagicMock(return_value='/home/derek/ansible/lib')
    lookup_module_0._loader._get_file_contents = MagicMock(return_value=('/home/derek/ansible/lib/ansible/modules/web_infrastructure/parsed/uri.py', True))

# Generated at 2022-06-25 11:18:00.562992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_file_0_var = [u'../templates/test.j2']
    variables_0_var = {u'lookup_file_search_path': [u'../templates'], u'foo': u'bar'}
    terms_0_var = [u'../templates/test.j2']

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=terms_0_var, variables=variables_0_var) == [u'bar\n']

# Generated at 2022-06-25 11:18:07.368735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tests_list = [(["test_file.yml"], ".", {}, "tests/test_file.yml", True, False)]
    test_results = []
    for test_data in tests_list:
        lookup_module_1 = LookupModule()
        test_result = lookup_module_1.run(test_data[0], test_data[1], test_data[2], test_data[3], test_data[4], test_data[5])
        test_results.append(test_result)
    return test_results


# Generated at 2022-06-25 11:18:19.195555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -0.91845
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    assert var_0 == int(-0.91845)


# Generated at 2022-06-25 11:18:24.253074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 0
    str_0 = 'X'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 11:18:29.339818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_3 = 4477.7
    var_4 = '6Z^Jk2"V/'
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule(lookup_module_3)
    var_5 = lookup_module_4.run(var_3, var_4)

# Generated at 2022-06-25 11:18:31.921640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(LookupModule())
    int_0 = -4152
    list_0 = []
    dict_0 = {}
    var_0 = lookup_module_1.run(int_0, list_0, dict_0)
    assert var_0 == float_0, var_0


# Generated at 2022-06-25 11:18:41.916545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global float_0, str_0, lookup_module_0, lookup_module_1, var_0, lookup_module_2
    try:
        global float_1
        float_1 = 4477.7
        str_0 = '6Z^Jk2"V/'
        lookup_module_0 = LookupModule()
        lookup_module_1 = LookupModule(lookup_module_0)
        var_0 = lookup_module_1.run(float_1, str_0)
        lookup_module_2 = LookupModule()
    except:
        pass
    else:
        raise Exception('Missing except block for setUp')

test_case_0()

# Generated at 2022-06-25 11:18:45.207166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 9989.3
    float_1 = 4294.1
    str_0 = 'MzCj+l"&5}5'
    str_1 = 'B%vNxOjW8/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    assert_equal(test_case_0(), lookup_module_0.run(str_1, str_0))


# Generated at 2022-06-25 11:18:55.956439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    assert_equal(lookup_module_1.run(float_0, str_0), None)
    lookup_module_2 = LookupModule()
    lookup_module_2.options = {}
    lookup_module_2.options['convert_data'] = 'convert_data'
    lookup_module_2.options['template_vars'] = {}
    lookup_module_2.options['jinja2_native'] = False
    lookup_module_2.options['variable_start_string'] = 'variable_start_string'

# Generated at 2022-06-25 11:19:00.484677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)

# Generated at 2022-06-25 11:19:05.833981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 2.8
    int_0 = 14
    str_0 = 'O3Gqe,]'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, int_0, str_0)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:19:10.123522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 6.48
    str_0 = 'R^w+'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    lookup_module_2 = LookupModule()
    assert (var_0 == None)

# Generated at 2022-06-25 11:19:23.894576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('9<]`v{8;aW', '', jinja2_native=False)
    assert var_0[0] == '9<]`v{8;aW'

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:19:27.858695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:19:31.585328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO : test this


# Generated at 2022-06-25 11:19:43.442733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3687.1
    str_0 = 'l'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()

# Generated at 2022-06-25 11:19:54.334130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  float_1 = 3395.2
  float_2 = 2750.0
  float_3 = 3726.7
  float_4 = 1107.9
  float_5 = 35.0
  lookup_module_11 = LookupModule()
  assert_int_equals(lookup_module_11.run(float_1, float_2, float_3, float_4, float_5),3633)
  float_6 = 671.5
  float_7 = 3795.2
  float_8 = 4183.3
  int_0 = 0
  dict_0 = dict(int_0=int_0)
  lookup_module_12 = LookupModule(dict_0)

# Generated at 2022-06-25 11:19:56.476120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run')
    test_case_0()

if __name__ == '__main__':
    # Unit test runner
    print('Testing', __file__)
    test_LookupModule_run()

# Generated at 2022-06-25 11:20:01.165806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run()
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:20:07.897000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = 'q3X9+1MSdS%'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)

# Generated at 2022-06-25 11:20:16.453097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)

# Generated at 2022-06-25 11:20:22.861258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_3 = LookupModule()
  float_1 = 3.6
  str_1 = '6Z^Jk2"V/'
  lookup_module_4 = LookupModule(lookup_module_3)
  lookup_module_5 = LookupModule()


# Generated at 2022-06-25 11:20:49.849621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 9445.68
    str_0 = '0~0'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)


# Generated at 2022-06-25 11:20:59.443502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    lookup_module_2 = LookupModule()
    lookup_module_2.run()
    lookup_module_3 = LookupModule()
    lookup_module_3.run(float_0)
    lookup_module_4 = LookupModule()
    lookup_module_4.run(float_0, str_0)
    return var_0


# Generated at 2022-06-25 11:21:05.927264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  file_test_case_0 = 'file_test_case_0'
  str_1 = '~&<oQM5-5HW'
  lookup_module_3 = LookupModule()
  lookup_module_4 = LookupModule(lookup_module_3)
  lookup_module_4.run(file_test_case_0, str_1)

# Generated at 2022-06-25 11:21:09.497177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)

# Generated at 2022-06-25 11:21:15.603904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_2 = LookupModule()
    try:
        var_0 = lookup_module_0.run(float_0, str_0)
    except:
        var_0 = None
    assert var_0 == None
    try:
        var_0 = lookup_module_2.run(float_0, str_0)
    except:
        var_0 = None
    assert var_0 == None

# Generated at 2022-06-25 11:21:21.353195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    # assert_equal(var_0, None, "Incorrect return value for run")


# Generated at 2022-06-25 11:21:29.403323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 555594871
    int_1 = -922419902
    float_1 = 978.09
    short_1 = 16162
    str_2 = 'M03"'
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule(lookup_module_3)
    var_1 = lookup_module_4.run(int_0, float_1, short_1, str_2)


# Generated at 2022-06-25 11:21:39.191637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    b_template_0 = to_bytes('e}_', errors='surrogate_or_strict')
    float_0 = 8793.5
    float_2 = 8958.37
    float_1 = 572.9
    float_3 = 9087.15
    lookup_module_0 = LookupModule()
    str_0 = '8WgOJc1Ck'
    b_template_1 = to_bytes('!a', errors='surrogate_or_strict')
    var_0 = lookup_module_0.run(b_template_0, float_0)
    var_1 = lookup_module_0.run(float_1, b_template_1)
    var_2 = lookup_module_0.run(float_2, str_0)
    var_3 = lookup

# Generated at 2022-06-25 11:21:47.055595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4741.4
    str_0 = 'lBsm^#'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    str_1 = 'test'
    float_1 = 543.1
    str_2 = 'test'
    lookup_module_2 = LookupModule()
    var_1 = lookup_module_2.run(float_1, str_2)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:21:51.106627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    lookup_module_2 = LookupModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:22:46.072745
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests
    lookup_module_0 = LookupModule()
    str_0 = '/[=O'
    str_1 = '^6{Fxl'
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(str_0, str_1)
    lookup_module_2 = LookupModule()
    str_2 = ']t%zZt'
    str_3 = ':F$fT|'
    lookup_module_3 = LookupModule(lookup_module_2)
    var_1 = lookup_module_3.run(str_2, str_3)
    lookup_module_4 = LookupModule()
    str_4 = '1'
    str_5 = '_'
    lookup_module_5

# Generated at 2022-06-25 11:22:53.763561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3127.93
    str_0 = 'r}3/|\n'
    lookup_module_0 = LookupModule(float_0)
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule(str_0)
    var_0 = lookup_module_2.run(lookup_module_1, lookup_module_0)
    var_1 = lookup_module_1.run(lookup_module_2,lookup_module_0)

# Generated at 2022-06-25 11:22:57.756006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 3.14159
    str_0 = 'iRVT%c}Mk{'
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:23:04.394832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    var_0 = lookup_module_1.run(float_0, str_0)
    var_1 = lookup_module_1.run(float_0, str_0)

# Generated at 2022-06-25 11:23:05.819281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:23:12.107212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '3v$7e'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0, str_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:23:14.012280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:21.465953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 0
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)

    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule(lookup_module_2)
    var_1 = lookup_module_3.run(float_0, str_0)

    assert var_0 == var_1

    # Test case 1
    double_0 = -1.0
    long_0 = -3
    lookup_module_4 = LookupModule()

# Generated at 2022-06-25 11:23:24.459111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:23:28.254711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = 1562.9
    str_1 = '`ayy'
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule(lookup_module_3)
    ret_0 = lookup_module_4.run(float_1, str_1)
    assert ret_0 == float_1

# Generated at 2022-06-25 11:25:22.382525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3.75
    str_0 = 'YYu'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_1.run(float_0, str_0)
    float_1 = 5.98
    lookup_module_1.run(float_1, str_0)
    float_2 = 3.15
    str_1 = '5'
    lookup_module_2 = LookupModule(lookup_module_1)
    lookup_module_1.run(float_2, str_1)

# Generated at 2022-06-25 11:25:28.112786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = ['C<xAa`f"', '\xa8zZHG']

# Generated at 2022-06-25 11:25:34.622144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    lookup_module_2 = LookupModule()
    lookup_module_2.run(lookup_module_1, lookup_module_0)
    lookup_module_3 = LookupModule(lookup_module_2)
    lookup_module_3.run(lookup_module_1, lookup_module_2)

# Generated at 2022-06-25 11:25:37.921609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 4477.7
    str_0 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:25:46.171408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, str_0)
    var_1 = lookup_module_1.run(float_0, str_0, ansible_search_path, ansible_data, ansible_env_vars, ansible_inventory)
    var_2 = lookup_module_1.run(float_0, str_0, ansible_search_path, ansible_data, ansible_env_vars, ansible_inventory, ansible_host)

# Generated at 2022-06-25 11:25:52.173913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment, USE_JINJA2_NATIVE

    if USE_JINJA2_NATIVE:
        from ansible.utils.native_jinja import NativeJinjaText

    display = Display()

    # capture options
    convert_data_p = True
    lookup_template_vars = {}
    jinja2_native = True
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_end_string = '#}'

    if USE_JINJA2_NATIVE and not jinja2_native:
        templar = self._templar.copy_with_new_env(environment_class=AnsibleEnvironment)
   

# Generated at 2022-06-25 11:25:56.444897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '/'
    arg_0 = {}
    var_1 = lookup_module_0.run(term_0, arg_0)
    print(var_1)

test_LookupModule_run()

# Generated at 2022-06-25 11:26:03.120358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = '/'
    variables = dict(a={'a': '0123456789'}, b='0', c=True, d=False, e=None)
    display_3 = Display()
    display_3.debug('/')
    lookup_module_4 = LookupModule()
    lookupfile = lookup_module_4.find_file_in_search_path(variables, 'templates', term)
    display_3.vvvv('File lookup using %s as file' % lookupfile)
    if lookupfile:
        b_template_data, show_data = lookup_module_4._loader._get_file_contents(lookupfile)
        template_data = to_text(b_template_data, errors='surrogate_or_strict')

        # set jinja2 internal search path for includes


# Generated at 2022-06-25 11:26:06.904202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 2418.1
    int_0 = 16810
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(float_0, int_0)


# Generated at 2022-06-25 11:26:09.829556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 4477.7
    var_1 = '6Z^Jk2"V/'
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run(var_0, var_1)