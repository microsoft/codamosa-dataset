

# Generated at 2022-06-25 11:17:08.917785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
# Input values for unit test
    terms_0 = ['file']
    variables_0 = {}
    kwargs_0 = {'convert_data': False, 'comment_end_string': u']', 'comment_start_string': u'[=', 'jinja2_native': False, 'template_vars': {}, 'variable_end_string': u'=}', 'variable_start_string': u'{='}
# Output values for unit test
    test_case_0_out_0 = {'_raw': ['string', 'string', 'string', 'string', 'string', 'string', 'string', 'string', 'string']}

# Generated at 2022-06-25 11:17:12.967004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module_0 = LookupModule()

    # Act
    # Assert raises
    with pytest.raises(AnsibleError) as exinfo:
        lookup_module_0.run(terms=None, variables=None)

# Generated at 2022-06-25 11:17:16.580562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    print(lookup_module.run())


# Generated at 2022-06-25 11:17:27.017634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['./some_template.j2']
    variables_0 = {}
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert isinstance(ret_0, list)
    assert ret_0 == []
    # TODO: fix this test
    #assert ret_0 == [u'# host   alias   address\n', u'{{ inventory_hostname }} {{ ansible_hostname }}  {{ ansible_default_ipv4.address }}']


if __name__ == "__main__":
    pytest.main(['-v', '-s', __file__])

# Generated at 2022-06-25 11:17:35.237808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_path = os.path.join(os.path.dirname(__file__), os.pardir)
    test_data_path = os.path.join(test_path, 'test_data')
    lookup_module = LookupModule()
    lookup_module.set_loader_path(test_data_path)

    result = lookup_module.run(terms=['invalid_lookup_file.txt'],
                               variables=dict(template_data='some_data_value'))
    assert result[0] == 'some_data_value'


# Generated at 2022-06-25 11:17:41.916036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variables = {}
    terms = []
    kwargs = {'convert_data': True, 'template_vars': {}, 'jinja2_native': False, 'variable_start_string': None, 'variable_end_string': None, 'comment_start_string': None, 'comment_end_string': None}
    actual = lookup_module_0.run(terms, variables, **kwargs)
    assert actual == [], actual
# unit test for class LookupModule



# Generated at 2022-06-25 11:17:50.799026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['lookup_test_case_0.txt']
    variables = {'ansible_search_path': ['/root']}
    lookup_module.run(terms, variables)
    # Test exception raised when no file found
    terms = ['lookup_test_case_0_not_found.txt']
    try:
        lookup_module.run(terms, variables)
        assert False, 'test exception not raised'
    except AnsibleError:
        pass

# Unit test of main function

# Generated at 2022-06-25 11:17:51.833623
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    assert lookup_module.run() == []

# Generated at 2022-06-25 11:17:53.914561
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_obj = lookup_module_0
    assert lookup_module_obj.run() == ""

# Generated at 2022-06-25 11:18:01.556716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    test_cases = ['test_case_0']

    for case in test_cases:
        if case == 'test_case_0':
            lookup_module_0 = LookupModule()
            # Run the run() method to test the Template lookup module
            lookup_module_0.run(terms = ['1.j2'], variables = {}, jinja2_native = False, template_vars = {}, variable_start_string = '{{', variable_end_string = '}}', convert_data = False)

# Generated at 2022-06-25 11:18:14.186328
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_run = LookupModule()

    lookup_module_run._templar = object()
    lookup_module_run._loader = object()

    variables = {}
    terms = []
    kwargs = {'convert_data': True}

    assert lookup_module_run.run(terms=terms, variables=variables, **kwargs) == []

# Generated at 2022-06-25 11:18:16.104933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    yaml_tech = LookupModule()

# Generated at 2022-06-25 11:18:20.154381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['list of terms'], variables = 'dictionary of variables') == ['string1', 'string2']

# Generated at 2022-06-25 11:18:25.253570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()
    template_vars = dict()
    lookup_module_0.set_loader(terms=[], variables={'ansible_variable': u'/path/to/directory'}, **{'convert_data': True, 'template_vars': {}, 'jinja2_native': True})

# Generated at 2022-06-25 11:18:31.513741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()

    terms_1 = ['/home/user/test_modules/Jinja2_0']
    variables = {'ansible_search_path': ['~/test_roles'], 'test_var': 'testing'}

    lookup_module_1.run(terms_1, variables)

    terms_2 = ['/home/user/test_modules/Jinja2_1']
    variables = {'ansible_search_path': ['~/test_roles']}
    lookup_module_2.run(terms_2, variables)




if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:18:35.443313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms_0 = [{'key': 'val'}]
  variables_0 = {'somekey': 'somevalue', 'somekey2': 'somevalue2'}
  with pytest.raises(AnsibleError):
    lookup_module_0.run(terms=terms_0, variables=variables_0)
  print('Test passed!')

if __name__ == "__main__":
  test_LookupModule_run()

# Generated at 2022-06-25 11:18:48.702923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock

    lookup = LookupModule()
    lookup._templar = mock.Mock()
    lookup._templar.template.return_value = "{{ ansible_managed }}"
    lookup._loader = mock.Mock()
    lookup._loader.get_basedir.return_value = "tmp/ansible_test_case"
    lookup.find_file_in_search_path = mock.Mock()
    lookup.find_file_in_search_path.return_value = "template_file"
    lookup._loader._get_file_contents = mock.Mock(return_value=("template_file", False))

    assert lookup.run("template_file", {}, {}) == ["{# ANSIBLE MANAGED BLOCK #}"]

# Generated at 2022-06-25 11:18:57.983060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['./some_template.j2']
    variables_0 = {}
    lookup_module_0._templar = None
    ret_0 = lookup_module_0.run(terms_0, variables_0, convert_data=None, template_vars=None, jinja2_native=None, comment_start_string=None, comment_end_string=None, variable_start_string=None, variable_end_string=None)
    assert ret_0 == []

# Generated at 2022-06-25 11:19:07.935362
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    assert lookup_module_0 != None


    # Test for value not having correct type

# Generated at 2022-06-25 11:19:11.050943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check whether assertion fails when 'variable_start_string' is not string
    # assert lookup_module_0.run('a',{'b':'c'},'d', variable_start_string=4) == AnsibleError
    pass


# Generated at 2022-06-25 11:19:28.268952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 843
    bytes_0 = b'\xf3\x11\x98\x9c\x1a\xdc#\x04\xc3'

# Generated at 2022-06-25 11:19:37.350211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}

    lookup_module_0 = LookupModule(terms, variables)
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # set jinja2 internal search path for includes
    # capture options
    # capture options
    # capture options
    # capture options
    # capture options
    # capture options
    # capture options
    # capture options
    # capture options
    # capture options
    # capture options
   

# Generated at 2022-06-25 11:19:44.225818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 743
    bytes_0 = b'*\xcc\xf5\x8c\xca\x1f\x14\xb6'
    bytes_1 = b'{;\xde\xab\x1c\xd6\x10\x01\xc5\x0b\x9b\xeb\xfa\xde\xcc\x85\x19\xcc'
    bool_0 = False
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    int_1 = 1771
    list_0 = [int_1]
    lookup_module_run(int_0, bytes_0, list_0)

# Generated at 2022-06-25 11:19:53.402399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2132
    bytes_0 = b'3\x8dm\x9d;\xf5\xd7J\xda\xcd\xdb\x15\x0eq\xf4\x17\x16'
    bytes_1 = b'\xc4\x11\x16\x15\xc3\x8a\x89\xd1\xb5\x15\xc2\xca\xe6'
    bool_0 = False
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_run(int_0, bytes_0)


# Generated at 2022-06-25 11:20:01.788185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 0
    bytes_0 = b'\x9d\xe11\xcc\xbe\xfb\x7f\x8b\x80'
    bytes_1 = b'\x123\xcd\x81\xe4\x15\xe2\xeb\xed\xec\x9b\x84\x1f'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_0, bool_0)
    lookup_module_0.run(bytes_0, bytes_1)


# Generated at 2022-06-25 11:20:09.232069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #self.assertEqual(self.lookup_module_0.run(), None)
    pass

if __name__ == '__main__':
    # The tests below will fail unless the _owner class is defined
    # A workaround for this is to
    # 1) Create a new class inside _owner.py
    # 2) Copy the lines from test_LookupModule_run into that new class
    # 3) Replace the variable lookup_module_0 with self
    #
    # This method is not ideal, but will work until LookupModule is refactored to
    # not rely on a class variable.
    test_case_0()

# Generated at 2022-06-25 11:20:14.492414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 11:20:20.695072
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ###
    # TODO: need to add tests for error cases?
    # TODO: look at module_utils/facts/system/distribution.py?
    # TODO: do we need to test results that include variables?
    # TODO: test cases should have a name
    ###

    # var_0 = lookup_run(int_0, bytes_0)
    # assert var_0 == '{}'

    # var_0 = lookup_run(int_0, bytes_1)
    # assert var_0 == '{{}'

    var_0 = lookup_run(int_0, bytes_2)
    assert var_0 == '{{ }}'

    var_0 = lookup_run(int_0, bytes_3)
    assert var_0 == '{{\n   }}'

    var_0 = lookup_

# Generated at 2022-06-25 11:20:25.220637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2217
    bytes_0 = b'\xdc\xecd\xcd\xc6{RX\x07\xe3;\xcf`\x8f18'
    bytes_1 = b'~\xfb\xeb\xde\xd1\x84\xaf\x8a\xd5\x82\xf5\x12\xf8'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    dict_0 = lookup_module_0.run(int_0, lookup_module_0.vars)




# Generated at 2022-06-25 11:20:34.770317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = 2229
    bytes_2 = b'\x9d\x81\xc5\xd6B\x1c\x02\xd5\x85\xac\xb6\x18\x8d'
    bytes_3 = b'\xae\xf4\xbe\x0fh08\x01\x8a\x06\x95\xed\xdc\xa8'
    bool_1 = True
    lookup_module_1 = LookupModule(bytes_3, bool_1)
    lookup_module_1.run(int_1, bytes_2)

# Generated at 2022-06-25 11:20:55.417524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Need to test with actual variables and terms
    assert True


# Generated at 2022-06-25 11:21:07.430441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup mock object(s)
    int_1 = 2575
    bytes_3 = b'\xd3\x99\xfc\xd6\xbb\xfe\xfb\xcf\xfe\xef\x03\xd2'
    bytes_4 = b'p\xf6$\xa0\x8b\xfb\xef\xf2\x87\x8b\xd2\xdf\x87'
    bool_1 = True
    lookup_module_1 = LookupModule(bytes_3, bool_1)

    # Setup int_0 and bytes_0
    int_0 = 1573
    bytes_0 = b'\x1d\xdc\xcc\xf8\xfa\xf9\xde\xd9\xfa\xdb\xfc\x87'

# Generated at 2022-06-25 11:21:08.903448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:21:19.067935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = -1984827048
    bytes_2 = b'\x0f\x1c\xe1\x1d\xde\x1b\x80&\x01\xec\xad\x06\x1cT\x05m\x9b\x94'
    bool_1 = False
    lookup_module_1 = LookupModule(bytes_2, bool_1)
    bytes_3 = b'\x0f\x1c\xe1\x1d\xde\x1b\x80&\x01\xec\xad\x06\x1cT\x05m\x9b\x94'

# Generated at 2022-06-25 11:21:22.464918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 135
    bytes_0 = b'\x8c\xde\x88\x99\xcc\x8b\\\x9c\x85\xdd';
    bytes_1 = b'\x81\x88\xcf\xcc\x9c\x88'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_module_0.run(int_0, bytes_0)
    assert var_0 == None, "test_LookupModule_run.py returned incorrect var_0 value"


# Generated at 2022-06-25 11:21:32.769516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 622
    bytes_0 = b'\xa4\x16\x18\x19\x1b\x1a\x08\x03\x1f\x1b\x0c'
    bytes_1 = b'\xe8\x1f\x85\x15\xa5\x8b\x98\x12\xb2\xc3\xdd\x96\xcf\xbd\xf6\xae\xca\x91\xea\xac\xd8\x1a\xab\xc6\xe5\x99\xfe\xaf\xa5\x9b\x12\xb5\x86\xaa\x0e\xa3\xbb\x01'
    bool_0 = False
    lookup_module_0 = Lookup

# Generated at 2022-06-25 11:21:40.215829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2217
    bytes_0 = b'\xdc\xecd\xcd\xc6{RX\x07\xe3;\xcf`\x8f18'
    bytes_1 = b'~\xfb\xeb\xde\xd1\x84\xaf\x8a\xd5\x82\xf5\x12\xf8'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    # assert?
    # assert?


# Generated at 2022-06-25 11:21:44.026817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule.run(
        bytes_0,
        bytes_1,
        bool_0=bool_0,
        variable_end_string=str_0,
        variable_start_string=str_0
    )
    var_0 = lookup_module_0.run()
    assert (var_0 > int_0)


# Generated at 2022-06-25 11:21:44.544516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:21:52.741657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = None
    variables = None
    lookup_module_2 = LookupModule(term, variables)
    t_1 = (None, None)
    t_2 = (None, None)
    t_3 = (None, None)
    t_4 = (None, None)
    t_5 = (None, None)
    t_6 = (None, None)
    t_7 = (None, None)
    t_8 = (None, None)
    t_9 = (None, None)
    t_10 = (None, None)
    t_11 = (None, None)
    t_12 = (None, None)
    t_13 = (None, None)
    t_14 = (None, None)
    t_15 = (None, None)

# Generated at 2022-06-25 11:22:46.279356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = -1034947403
    bytes_0 = b'\x04\xf9[\xb1\xfb\x89\xbd\x15c\xee\xcb\x96\xf00\x1a\xeb\xbc\xcc\x8d\xbc\xf2\x0b\x8d\x9e'
    bytes_1 = b'\xa8\xac\x83\xad\x0cf\xf6U\x9a\xde-\xc6\x8a\x0f\xd5\x11<\x9b\xb8\xba\x91^'
    bool_0 = False
    lookup_module_0 = LookupModule(bytes_1, bool_0)

# Generated at 2022-06-25 11:22:56.650017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1060
    bytes_0 = b'\x89\xf4\x11\x8e\xdc\x1c\xb4\x9a\xf8\xbe\xe4\xdb'
    bytes_1 = b'\x03\x1e\x9f\x8a\x16\xe6\xa1\x83\xbb\xe5\x81\x0b'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    terms_0 = {var_0: bytes_1}
    variables_0 = {var_1: int_0, var_2: bool_0}
    var_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:22:58.076868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (test_case_0()) is True

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:07.896469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2217
    bytes_0 = b'\xdc\xecd\xcd\xc6{RX\x07\xe3;\xcf`\x8f18'
    bytes_1 = b'~\xfb\xeb\xde\xd1\x84\xaf\x8a\xd5\x82\xf5\x12\xf8'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_run(int_0, bytes_0)
    test_class_0 = LookupModule(bytes_1, bool_0)
    var_1 = test_class_0.run(int_0, bytes_0)
    assert var_1 == var_0


# Generated at 2022-06-25 11:23:17.825303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Test case 01
  int_0 = 2
  bytes_0 = b'\x14\xec\xb1\x03\xd2\xa2\x8b0\x96\x89\x90\x15\x9f'
  bool_0 = True
  lookup_module_0 = LookupModule(bytes_0, bool_0)
  var_2 = lookup_run_0(int_0, bytes_0)
  assert var_2 == 1

  # Test case 02
  int_0 = 2
  bytes_0 = b'\x14\xec\xb1\x03\xd2\xa2\x8b0\x96\x89\x90\x15\x9f'
  bool_0 = False

# Generated at 2022-06-25 11:23:25.493700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 42
    bytes_0 = b'}\x8b\x80\x07?\x96\x05\x8b'
    bytes_1 = b'\x86\x8c\x80\xfb\xb7\xe8\xa8\x04\xaeL\xac\xdf\xde\xd3\x96'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_module_0.run(int_0, bytes_0)


# Generated at 2022-06-25 11:23:35.165655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2688
    bytes_0 = b'\xbc\xef\xa5\x9a\x92\xfe\x1d\x8a\xd6\xea&\x85\x93\x11\x9d\x11\x14\x1b8\xf3'
    bytes_1 = b'\xb7\xf6\x9f\x92\x1b\xe7\xe2\xbf\x1c\xdd\xc7\x0f'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_run(int_0, bytes_0)

# Generated at 2022-06-25 11:23:42.312344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = 62
    int_0 = 5302
    bytes_2 = b'\x80\xac'
    str_0 = '\x8d\xcd\xc6\xdb\xc5\xcf\x92\x87\\\x0f\xd2\xee\xa2\x9d\xdc\x80\x8f\xdb\xec\x97'
    bytes_0 = b'\x96\xcc\xd3\xc0\x8b\xde\x87\xca\xf4\xe8\xfa\x9d\xfc'
    bytes_1 = b'\x81\xad\xdc\x86\xd3\xc1\x9c\x91\xc0\xde\xa0\xdf\xce'


# Generated at 2022-06-25 11:23:50.181051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  int_0 = 2217
  bytes_0 = b'\xdc\xecd\xcd\xc6{RX\x07\xe3;\xcf`\x8f18'
  bytes_1 = b'~\xfb\xeb\xde\xd1\x84\xaf\x8a\xd5\x82\xf5\x12\xf8'
  bool_0 = True
  lookup_module_0 = LookupModule(bytes_1, bool_0)
  var_0 = lookup_run(int_0, bytes_0)

# Generated at 2022-06-25 11:23:57.199247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 4017
    bytes_0 = b'\xa2\x06\x08\xfb\x13\xa3\xc3\xbaD\x80x\x18\xb0\xfd'
    bytes_1 = b'\x87{\xbb\x1a\xff\x92\x07\xe9\x03\x99\x1d\x13\xcb'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    lookup_module_0.run(int_0, bytes_0)


# Generated at 2022-06-25 11:25:55.556631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 0
    bytes_0 = b'\xbd\xcd\xde\xd9\x85\xa2\xca\xd7\x8c\xfc\x0f\xf6'
    bytes_1 = b'\xbf\xcd;\xc5\x97\xb1\xcb\xc5\xd7\x8d\xee\x00\xfe'
    bool_0 = False
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_module_0.run(int_0, bytes_0)


# Generated at 2022-06-25 11:25:59.678574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = 1116
    bytes_2 = b'\x14\x15\x1f\x0f\x1c\x98\x9b\xbe\xf8\xed\x03\x0e\xa5\x8aA'
    bytes_3 = b'\xe1\x8b\x03\x12\xd7\xaf\x01\x18^\xa9\xfb\xc3\x0e\x1c\x01'
    bool_1 = True
    lookup_module_1 = LookupModule(bytes_2, bool_1)
    var_1 = lookup_run(int_1, bytes_3)


# Generated at 2022-06-25 11:26:05.789608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 0
    str_0 = '\x0d'
    lookup_module_0 = LookupModule(str_0, int_0)
    var_0 = lookup_run(int_0, str_0)


# Generated at 2022-06-25 11:26:15.407149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 5964
    bytes_0 = b'\xb6\x18\xa5[\x1d\x9b\x8b\xbe\xb0\xfb\xc2\x05\x8d\xde\xad\x9a\x91\xac\x1a'

# Generated at 2022-06-25 11:26:19.760991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2217
    bytes_0 = b'\xdc\xecd\xcd\xc6{RX\x07\xe3;\xcf`\x8f18'
    bytes_1 = b'~\xfb\xeb\xde\xd1\x84\xaf\x8a\xd5\x82\xf5\x12\xf8'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_module_0.run(int_0, bytes_0)

# Generated at 2022-06-25 11:26:22.349043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 0
    str_0 = 'plain'
    lookup_module_0 = LookupModule({'4(wI'}, dict())
    var_0 = lookup_module_0.run([str_0], {'4(wI'})
    print(var_0)


# Generated at 2022-06-25 11:26:25.887360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) is None
    pass


# Generated at 2022-06-25 11:26:31.833293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests.mock import mock_open, patch
    def side_effect(path, content):
        if path == './some_template.j2':
            content.return_value = "blah"
        else:
            content.return_value = "doh"
    lookup_module_0 = LookupBase()

# Generated at 2022-06-25 11:26:36.008151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2254
    bytes_0 = b'\x04\xbf\x0b\xb8\xdc\xa5\xbb\x18\x9a\xdb\xfe\xdd\x1b'
    bytes_1 = b'AW\x9d\x88\x12\xad\xde\xaf\x80\xa8\x1f\x9e\x16\xa9'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    var_0 = lookup_run(int_0, bytes_0)


# Generated at 2022-06-25 11:26:42.233930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1516
    bytes_0 = b'\xec\x1b\xec\xc1\xd2\xb9\x06\xcf\xdd\x91\x1c\xe8\x98\x86\x88\xe1\xd4A\xae\x99\x1a'
    bytes_1 = b'\xb3\xc3\x9d\x05\x99\x90'
    bool_0 = True
    lookup_module_0 = LookupModule(bytes_1, bool_0)
    lookup_module_0.run(int_0, bytes_0)