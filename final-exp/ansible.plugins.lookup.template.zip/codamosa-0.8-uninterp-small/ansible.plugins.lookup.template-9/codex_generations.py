

# Generated at 2022-06-25 11:17:08.739595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # An existing template
    lookup_module_0 = LookupModule()
    term_0 = './test/test.j2'
    variables_0 = { 'ansible_search_path': [ '.', './test' ] }
    ret_0 = lookup_module_0.run(terms = term_0,
                                variables = variables_0)
    assert ret_0 == [ '$ANSIBLE_CONFIG: $DEFAULT_VAULT_PASSWORD_FILE' ]

    # That does not exist
    lookup_module_1 = LookupModule()
    term_1 = './test/test.j2'
    variables_1 = { 'ansible_search_path': [ '.', './tests' ] }

# Generated at 2022-06-25 11:17:12.897489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(["http://localhost:5000/api/tasks/1"], {})
    assert len(result) == 1
    assert result[0].startswith('<200 ') or result[0].startswith('<301 ') or result[0].startswith('<302 ')

# Generated at 2022-06-25 11:17:19.528937
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:17:22.447058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    run_ret = lookup_module_1.run(terms=['file_name'], variables={'name':'value'}, )

# Generated at 2022-06-25 11:17:33.306337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=None, variables=None, **dict(convert_data=False, jinja2_native=False, var_templates=[])).__len__() == 0
    assert lookup_module.run(terms=[""], variables=None, **dict(convert_data=False, jinja2_native=False, var_templates=[])).__len__() == 0
    assert lookup_module.run(terms=["", ""], variables=None, **dict(convert_data=False, jinja2_native=False, var_templates=[])).__len__() == 0

# Generated at 2022-06-25 11:17:44.215199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with invalid argument type
    test_invalid_type = lambda: lookup_module_0.run(True, 'variables')
    try:
        test_invalid_type()
    except Exception as e:
        if isinstance(e, AssertionError) and "argument 'terms' must be an iterable" in str(e):
            pass
        else:
            assert False, "Got an unexpected exception"

    # Test with invalid argument type
    test_invalid_type = lambda: lookup_module_0.run('terms', True)
    try:
        test_invalid_type()
    except Exception as e:
        if isinstance(e, AssertionError) and "argument 'variables' must be a dictionary" in str(e):
            pass

# Generated at 2022-06-25 11:17:48.155876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    terms_0 = "./some_template.j2"
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_run_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:17:54.138472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    jinja2_native = False
    variable_start_string = "{{ "
    variable_end_string = " }}"
    comment_start_string = ""
    comment_end_string = ""
    convert_data = True
    lookup_template_vars = {}
    terms = ["./some_template.j2"]
    variables = {}
    kwargs = {}
    ret = lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:17:59.823308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    options = {'comment_start_string': '#'}
    assert lookup_module.run(['test/test.j2'], options) == \
        ['# This is a comment line.\n', '# This is a comment line.\n']

# Generated at 2022-06-25 11:18:01.178114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = './some_template.j2'
    variables = {}
    ret = lookup_module.run(terms, variables)

# Generated at 2022-06-25 11:18:22.338897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate template instance of class LookupModule
    # Insert data (lookup path)
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = AnsibleLoader()
    lookup_module_0._loader._search_path = ['.']
    lookup_module_0._templar = None
    lookup_module_0._templar = Templar(loader=lookup_module_0._loader)
    lookup_module_0._templar._available_variables = {}
    lookup_module_0._templar._display = Display()
    lookup_module_0._templar._basedir = os.path.dirname(os.path.abspath(__file__))  #base dir property
    lookup_module_0._templar._available_variables.update(os.environ)

# Generated at 2022-06-25 11:18:33.546167
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import string_types

    #####################################################################
    # Init
    #####################################################################
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    
    from ansible.plugins.loader import LookupModule as LookupModule_class
    if isinstance(lookup_module_0, LookupModule_class):
        lookup_module_0_instanceof_LookupModule_class = True
    else:
        lookup_module_0_instanceof_LookupModule_class = False
    assert lookup_module_0_instanceof_LookupModule_class == True

# Generated at 2022-06-25 11:18:44.334264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['./some_template.j2']
    variables_0 = dict()
    parameters_0 = dict()
    parameters_0['convert_data'] = False
    parameters_0['template_vars'] = dict()
    parameters_0['jinja2_native'] = False
    parameters_0['variable_start_string'] = '{{'
    parameters_0['variable_end_string'] = '}}'
    parameters_0['comment_start_string'] = ''
    parameters_0['comment_end_string'] = ''
    result_0 = lookup_module_0.run(terms=terms_0, variables=variables_0, **parameters_0)
    print(result_0)

# Generated at 2022-06-25 11:18:49.319887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #test 1 of search_path
    search_path_0 = ['/etc/ansible']
    #test 1 of _terms
    #test 1 of _loader
    _loader_1 = lookup_plugin_loader()
    #test 1 of my_env
    my_env_0 = os.environ
    #test 1 of jinja2_native
    jinja2_native_0 = False
    #test 1 of variable_start_string
    variable_start_string_0 = '{{'
    #test 1 of variable_end_string
    variable_end_string_0 = '}}'
    #test 1 of convert_data
    convert_data_0 = True
    #test 1 of comment_start_string

# Generated at 2022-06-25 11:18:56.043659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['./test_test_test.j2']
    variables = {"test": "test"}

    lookup_module = LookupModule()
    if not lookup_module.run(terms, variables):
        raise AssertionError()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:18:59.884864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0=LookupModule()
    lookup_module_0.set_loader('/tmp')
    lookup_module_0._templar=None
    lookup_module_0.run(terms=['/tmp/ansible_template_0'],variables={})

# Generated at 2022-06-25 11:19:03.469814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # run test with valid data
    terms = ['value1', 'value2']
    variables = {}
    lookup_module_0.set_loader(loader=None)
    lookup_module_0.set_templar(templar=None)
    result = lookup_module_0.run(terms=terms, variables=variables)
    assert result is not None

# Generated at 2022-06-25 11:19:08.023561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Example for method run
    # Note: Validation of method run is not yet implemented, test does not do anything
    lookup_module_1.run(terms=[], variables={}, **{u'convert_data': u'True', u'jinja2_native': u'True'})



# Generated at 2022-06-25 11:19:15.699632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    lookup_module_1.set_loader(dict(path = ['test/files/test_lookup_plugins/']))

    lookup_module_1.set_templar(dict(vars = dict(a='b')))

    (errcode_1, result_1) = lookup_module_1.run(['test_template.j2'],[])
    assert result_1 == ['Hello World']

    (errcode_2, result_2) = lookup_module_1.run(['test_template_with_vars.j2'],[])
    assert result_2 == ['Hello World a = b']

# Generated at 2022-06-25 11:19:26.222599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case for when an exception occurs
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = None
    # Test case for when an exception occurs
    lookup_module_2 = LookupModule()
    lookup_module_2._loader = None
    # Test case for when an exception occurs
    lookup_module_3 = LookupModule()
    lookup_module_3._loader = None
    lookup_module_3._templar = None
    # Test case for when an exception occurs
    lookup_module_4 = LookupModule()
    lookup_module_4._loader = None
    lookup_module_4._templar = None
    # Test case for when an exception occurs
    lookup_module_5 = LookupModule()
    lookup_module_5._loader = None
    lookup_module_5

# Generated at 2022-06-25 11:19:45.426035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-25 11:19:49.173826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run('j2') == 'foo\nbar\n'


# Generated at 2022-06-25 11:19:54.067320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookupfile = "lookup_foo.yaml"
    variables = {"ansible_search_path": ["/home/vagrant/ansible/modules"], "environment": "vagrant"}
    term = "lookup_foo.yaml"
    terms = [term]
    lookup_module_1.run(terms, variables)

# Generated at 2022-06-25 11:20:00.726132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    t = [
        "/usr/local/ansible/roles/marvin/templates/config.xml",
        "/usr/local/ansible/roles/marvin/templates/log4j.xml",
        "/usr/local/ansible/roles/marvin/templates/management-server-init.in"
    ]

    assert lookup_module.run(t, None) == []

# Generated at 2022-06-25 11:20:03.596367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    val = {}
    terms = ['b']
    variables = 'ansible'
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run(val, terms, variables)
    assert isinstance(lookup_module_run, list)

# Generated at 2022-06-25 11:20:11.979519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    terms_0 = "./some_template.j2"
    variables_0 = {"variable_end_string": "'}}'", "comment_end_string": "']'", "comment_start_string": "'[#'", "convert_data": False, "jinja2_native": False, "variable_start_string": "'{{'"}
    kwargs_0 = {}
    LookupModule.run(lookup_module_0, terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:20:15.875699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], {}) == []


# Generated at 2022-06-25 11:20:21.063547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "playbooks/testme.yml"
    variables_0 = {"lookup_test_vars": "test"}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert len(ret_0) == 1
    assert isinstance(ret_0[0], to_text)

    terms_1 = ["playbooks/testme.yml", "playbooks/testme.yml"]
    ret_1 = lookup_module_0.run(terms_1, variables_0)
    assert len(ret_1) == 2
    assert isinstance(ret_1[0], to_text)
    assert isinstance(ret_1[1], to_text)


# Generated at 2022-06-25 11:20:26.268082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a test object
    lookup_module_0 = LookupModule()
    # Create a set of test arguments
    terms_0 = './some_template.j2'
    variables_0 = 'ansible_check_mode'
    # Run the method with the given arguments and capture the result
    # We don't actually care what the result is and throw it away
    result_0 = lookup_module_0.run(terms=terms_0, variables=variables_0)
    # Assert that no exception was raised
    assert not result_0.exception
    # If this test fails, it means that exceptions were raised
    # during the test. So that's a failure.
    # We should assert that the expected result is equal to the real result
    # assert result_0 == expected_0

# Generated at 2022-06-25 11:20:36.196561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(0)
    lookup_module_0.set_templar(0)
    lookup_module_0.set_fs(0)
    lookup_module_0.set_basedir(0)

    terms = [ './some_template.j2', './some_other_template.j2' ]
    variables = {}

    kwargs = {}
    kwargs['convert_data'] = True
    kwargs['jinja2_native'] = False
    kwargs['variable_start_string'] = '{{'
    kwargs['variable_end_string'] = '}}'
    kwargs['comment_start_string'] = '{#'

# Generated at 2022-06-25 11:21:07.461849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'jKkzS!x'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'U6>dU6'
    str_2 = '#sW<vc'
    list_0 = [str_1, str_2]
    str_3 = 'DZ|A1R'
    str_4 = 'XTFHBU'
    str_5 = 'lK\x0eZ\x0bW]Q+'
    str_6 = 'G"+|Uz'
    str_7 = 'J_Tj"s'
    str_8 = 'X{y:]J'
    str_9 = 'S]AN~P'
    str_10 = 'J@vg4+'

# Generated at 2022-06-25 11:21:18.652424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'zS>G!^0\x18]P\x0b\x07\n'
    lookup_module_0 = LookupModule(str_0)
    str_1 = '\f^n4\x1f\x0c\x1c'
    list_0 = [str_1, str_0]
    str_2 = 'UZ\nzD\x19U;z\x12\x15'
    str_3 = '3v\x18\x0c\x1fu\x17x0\r'
    dict_0 = {str_2: list_0, str_3: list_0}
    str_4 = 'l\x1a\x19\x03\\'

# Generated at 2022-06-25 11:21:19.049524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:21:23.359439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('test_LookupModule_run')
    test_case_0()

# Generated at 2022-06-25 11:21:33.335538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    tests ansible.plugins.lookups.template.LookupModule.run
    """
    str_0 = "j@5Rw^5l5\x7f\x13c`"
    str_1 = "vM8b\x1cp'\x1b"
    str_2 = "Wf>X\rpD\x1c'I"
    lookup_module_0 = LookupModule(str_0)
    # vars 'str_0' must exist
    list_0 = [str_1, str_2]
    str_3 = "[X-n0I\rEc\x1fB"
    str_4 = "s!I\x01\x13n\x0e\x1f"

# Generated at 2022-06-25 11:21:34.482322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert callable(LookupModule.run)
  return

# Generated at 2022-06-25 11:21:41.035920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '`x'
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    str_1 = "fBG&6!'|9[6)T`|`"
    str_2 = 'j'
    dict_0 = {str_1: list_0, str_2: list_0}
    var_0 = lookup_module_0.run(list_0, dict_0)
    # AssertionError



# Generated at 2022-06-25 11:21:46.950415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'jwzq3M$n2($}et'
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    str_1 = 'b,c%y*\r{gCY[2Kj'
    str_2 = 'T@]#?\t.\x0by/<8,4W'
    dict_0 = {str_1: list_0, str_2: list_0}
    lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 11:21:49.252620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print ("Test for method run of class LookupModule")
    test_case_0()

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:22:00.072362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/dG'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'c*Y'
    str_2 = 'h,6Rz'
    str_3 = '^,[U'
    str_4 = '4&'
    str_5 = 'M|&'
    str_6 = ':*'
    str_7 = 'F?.?'
    str_8 = '\x7fzJ'
    str_9 = 'I0\t7'
    str_10 = '%c~'
    str_11 = 'W8_'
    str_12 = 'R@\x0bZ^'
    str_13 = 'l?~'
    str_14 = ':}j'

# Generated at 2022-06-25 11:22:49.886681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 's/o!wt'
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    str_1 = "fBG&6!'|9[6)T`|`"
    str_2 = 'uC&ADj\x0bO\th^13_>'
    dict_0 = {str_1: list_0, str_2: list_0}
    var_0 = lookup_module_0.run(list_0, dict_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:22:54.145712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "*R'h)"
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    str_1 = '^t1w$d[+mYq|o"9'
    str_2 = '"R.Q'
    dict_0 = {str_1: list_0, str_2: list_0}
    var_0 = lookup_module_0.run(list_0, dict_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:23:00.278454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['s/o!wt', 's/o!wt']
    str_0 = "fBG&6!'|9[6)T`|`"
    str_1 = 'uC&ADj\x0bO\th^13_>'
    dict_0 = {str_0: list_0, str_1: list_0}
    var_0 = lookup_module_0.run(list_0, dict_0)
    str_2 = '_raw'
    assert var_0[str_2].__class__.__name__ == 'list', "Expected type <class 'list'>, got: %s" % var_0[str_2].__class__.__name__


# Generated at 2022-06-25 11:23:02.731118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(type(test_case_0()) is list)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:09.967610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    some_utf8_string = 'some utf8 string'
    str_0 = 'a"a"a'
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    str_1 = "UU&F?!C|Q;=`nT|T}"
    str_2 = "B{-)\x18\x1b*^:&67#\x1b"
    dict_0 = {str_1: list_0, str_2: list_0}
    var_0 = lookup_run(list_0, dict_0)


# Generated at 2022-06-25 11:23:11.479241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    pass


# Generated at 2022-06-25 11:23:12.417037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert type(test_case_0) == type(None)



# Generated at 2022-06-25 11:23:19.993752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '|'
    list_0 = ['p|1?|NwJH(|2', '}U\x7fRPY\nJ/', '|', 'Dkml&2|s1mq']
    str_1 = '/>P}'
    str_2 = 'h-H:'
    dict_0 = {str_1: list_0, str_2: list_0}

# Generated at 2022-06-25 11:23:23.186089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:32.184497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        str_0 = "GJem`+'o^L[q$1`"
        lookup_module_0 = LookupModule(str_0)
        list_0 = [str_0, str_0]
        str_1 = 'e"\t5*Z\x0f\r`Od2Y'
        str_2 = "oL+:.`Q\n~b+8U6J"
        dict_0 = {str_1: list_0, str_2: list_0}
        var_0 = lookup_run(list_0, dict_0)
        assert_equal(var_0[0], 's/o!wt')
    except Exception as exception_0:
        print("Error occurred:  %s"%exception_0)


# Generated at 2022-06-25 11:25:29.425383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import LookupModule

    lookup_module_0 = LookupModule('y,cO!\x0cP\t*A)$')
    list_0 = ['X1"vQ8rq']
    str_0 = "_D~/v&8"
    str_1 = '|{XbJ\rj^3qGw'
    dict_0 = {str_0: list_0, str_1: list_0}
    assert lookup_module_0.run(list_0, dict_0) == list_0


# Generated at 2022-06-25 11:25:36.429974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_2 = 'uC&ADj\x0bO\th^13_>'
    str_3 = "fBG&6!'|9[6)T`|`"
    str_0 = 's/o!wt'
    list_0 = [str_0, str_0]
    lookup_module_0 = LookupModule(str_0)
    dict_0 = {str_3: list_0, str_2: list_0}
    var_0 = lookup_run(list_0, dict_0)
    #assert var_0 == list_0
if __name__ == '__main__': 
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:25:45.053665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'yqM3*_Q%c/'
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    str_1 = "Kj\x08&U|XdWSU}@b"
    str_2 = ")nPl|'5>H1~p5:R}"
    str_3 = '!'
    str_4 = 'u'
    str_5 = 'wE.3\\qJ)Q/E9'
    str_6 = 'm,x\x0c'
    str_7 = 's'
    str_8 = 'b'
    str_9 = '|kx\x0cj\x0b'
    str_10 = 'gHn'
    str_11

# Generated at 2022-06-25 11:25:52.466781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'Ktb?k(S8V,e&M'
    lookup_module_0 = LookupModule(str_0)
    str_1 = '+rBjrk%$|>oXh!0q'
    str_2 = 'U6)&.jKx0<\x7f'
    str_3 = 'G]zJ.Eb+A(.D@a'
    list_0 = [str_1, str_2, str_3]
    str_4 = 'w%&U6]$N*\x7f'
    list_1 = [str_1]
    list_2 = [str_3]
    dict_0 = {str_4: list_1, str_2: list_2}
    var_0 = lookup_module_

# Generated at 2022-06-25 11:26:01.007599
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var_2 = '_terms'
    str_0 = 's/o!wt'
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    str_1 = "fBG&6!'|9[6)T`|`"
    str_2 = 'uC&ADj\x0bO\th^13_>'
    dict_0 = {str_1: list_0, str_2: list_0}
    var_3 = lookup_module_0.run(list_0, dict_0)
    var_4 = lookup_module_0._lookup_args
    var_5 = {str_1: list_0, str_2: list_0, str_0: list_0}
    assert var_4 == var_

# Generated at 2022-06-25 11:26:10.775069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    # ansible/plugins/lookup/template.py:51:
    #   LookupModule.run(self, terms, variables, **kwargs):

    #   capture options
    #   ansible/plugins/lookup/template.py:58:
    #     self.set_options(var_options=variables, direct=kwargs)
    #     ansible/plugins/lookup/__init__.py:32:
    #       LookupBase.set_options(self, var_options=None, direct=None, **kwargs)

    #   capture options
    #   ansible/plugins/lookup/template.py:58:
    #     self.set_options(var_options=

# Generated at 2022-06-25 11:26:21.016641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '>ofW|d8'
    lookup_module_0 = LookupModule(str_0)
    list_0 = [str_0, str_0]
    dict_0 = dict()
    str_1 = 'k=ltPt]m?t'
    lookup_module_0._templar = str_1
    var_0 = lookup_module_0.run(list_0, dict_0)
    var_1 = lookup_module_0._templar
    str_2 = "6j>U6g!J2Ea"
    ASSERT.equal(var_1, str_2, 'Assertion failed')
    str_3 = 'MqaW0j?9pT'
    ASSERT.equal(len(var_0), 1, 'Assertion failed')

# Generated at 2022-06-25 11:26:30.549822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    com_0 = {'ANSIBLE_JINJA2_NATIVE': 'True'}

    # type: dict
    dict_0 = dict()

    # type: str
    str_0 = 'z>eAP*8WbJt'

    # type: str
    str_1 = ""

    # type: str
    str_2 = ")J;=h1;@e'@$Ya'"

    # type: str
    str_3 = '+z^+\x1a\n[`<c%\x10'

    str_4 = 't/-Qj*['
    str_5 = 'IL;+C'
    str_6 = '#'
    str_7 = 'J:'
    str_8 = ':$6j'

# Generated at 2022-06-25 11:26:32.393780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('B6T_T#u>>9XU')
    assert lookup_module_0.run([''], {}) == []

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:26:38.646244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule("%g2_<!")
    module_0.run("\n,_'YlVu")
    module_1 = LookupModule("a|Dy")
    module_1.run("`|nZ")
