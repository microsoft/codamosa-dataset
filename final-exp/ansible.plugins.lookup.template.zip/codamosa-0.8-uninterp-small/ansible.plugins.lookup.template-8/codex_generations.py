

# Generated at 2022-06-25 11:17:09.893459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(bytes_0, int_0)
    str_0 = lookup_module_0.run(list_0, dict_0, convert_data=bool_0, jinja2_native=bool_0, comment_start_string=None, template_vars=dict_1, comment_end_string=None, variable_end_string=None, variable_start_string=None)


# Generated at 2022-06-25 11:17:17.290925
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:17:26.413699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'%\x84\xda\xba\xb3\xef\xa8\x95\x01\x1a\xc1R\x0b\xba\x9e\xef\xbbRN'
    int_0 = 240

# Generated at 2022-06-25 11:17:36.883969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = (
        b'1', b'2', b'3', b'4', b'5', b'6', b'7', b'8', b'9', b'10', b'11', b'12', b'13', b'14', b'15', b'16', b'17', b'18',
        b'19', b'20', b'21', b'22', b'23', b'24', b'25', b'26')
    a_0, b_0, c_0, d_0, e_0, f_0, g_0, h_0, i_0

# Generated at 2022-06-25 11:17:39.342860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run parameter test
    terms_0 = [0, 1, 2]
    variables_0 = {0: 0, 1: 1, 2: 2}
    ret = LookupModule.run(terms_0, variables_0)
    assert ret == [0, 1, 2]


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:17:48.244588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xb6ote\x96n\x8e\xce'
    int_0 = 520
    lookup_module_0 = LookupModule(bytes_0, int_0)
    list_0 = []
    dict_0 = {}
    list_1 = lookup_module_0.run(list_0, dict_0)
    assert len(list_1) == 0
    list_2 = lookup_module_0.run(list_0, dict_0)
    assert len(list_2) == 0
    list_3 = lookup_module_0.run(list_0, dict_0)
    assert len(list_3) == 0
    list_4 = lookup_module_0.run(list_0, dict_0)
    assert len(list_4) == 0
    list

# Generated at 2022-06-25 11:17:54.505404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    import builtins

    # mock_templar.set_temporary_context().__enter__()
    mock_templar = Mock()
    attr_set_temporary_context = Mock(return_value=mock_templar)
    mock_templar.set_temporary_context = attr_set_temporary_context
    attr_set_temporary_context.return_value.__enter__ = Mock(return_value=mock_templar)
    builtins.templar = mock_templar

    res = LookupModule.run(AnsibleError("AnsibleError"), dict())
    assert res == []

# Generated at 2022-06-25 11:18:00.752765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
             [
               "./some_template.j2",
             ],
             {
               "foo": "bar",
             },
             {
               "convert_data": "False",
             },
           ]
    if len(args) == 2:
        LookupModule_run_0(*args)
    elif len(args) == 3:
        LookupModule_run_1(*args)


# Generated at 2022-06-25 11:18:09.410316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The following call is equivalent to
    # "echo ${{ansible_hostname}|upper} | tr -d ' '",
    # which should return the argument passed to the "template"
    # lookup plugin, in upper case and without spaces.
    # For this test to work, it is necessary to pass
    # "--extra-vars ansible_hostname=foo" as command-line argument.
    terms = ['{{ ansible_hostname|upper|regex_replace("\\s") }}']
    variables = {'ansible_hostname': 'foo'}
    res = LookupModule._run(terms, variables)
    assert res == ["FOO"]

# Generated at 2022-06-25 11:18:10.864767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests the run method of LookupModule
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 11:18:20.422549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_plugin = LookupModule()
    var_0 = None
    terms_1 = None
    variables_2 = None
    test_lookup_plugin.run(terms = terms_1, variables = variables_2)

# Generated at 2022-06-25 11:18:22.851595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_1()


# Generated at 2022-06-25 11:18:25.362337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = None
  variables = None
  lookup_module = LookupModule()
  try:
    ret = lookup_module.run(terms, variables)
  except SystemExit as e:
    return 0
  assert ret is None

# Generated at 2022-06-25 11:18:34.183305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes, to_text
    import os
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    import json
    import re
    import sys
    import shlex
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import StringIO
    import tempfile
    import time
    import datetime
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.parsing.convert_bool import boolean
    import types
    import yaml
    import platform

# Generated at 2022-06-25 11:18:37.455695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    terms = ["test"]
    variables = {}
    kwargs = {}
    test_obj = LookupModule(var_0)
    assert test_obj.run(terms, variables, **kwargs) == [None]

# Generated at 2022-06-25 11:18:45.829705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_loader_mock = None
    var_0 = None

    lookup_ins = LookupModule(loader=ansible_loader_mock, basedir=var_0, templar=var_0, shared_loader_obj=var_0)
    terms_1 = test_case_0()
    variables_1 = test_case_0()

    lookup_ins.run(terms_1, variables_1)

# Generated at 2022-06-25 11:18:52.571896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ##
    # Set up for test_case_0
    ##
    test_LookupModule_run_test_case_0()
    ##############################################################################
    ##
    # Run test cases
    ##
    test_cases = [test_case_0]
    for test_case in test_cases:
        test_case()
##############################################################################
# Local Variables:
# indent-tabs-mode: nil
# End:
# vim: ai et sw=4 ts=4

# Generated at 2022-06-25 11:18:56.700607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an object of the class
    lookup_obj = LookupModule()

    # Invoke the run method of the class
    result_obj = lookup_obj.run(None, None)

    # Test if the method run returns the correct values
    # The test results should be the same as the test results in test_case_0
    assert result_obj == var_0

# Generated at 2022-06-25 11:19:02.473559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = os.path.join(os.path.dirname(__file__), 'data_lookup_template_0')
    var_1 = os.path.join(os.path.dirname(__file__), 'data_lookup_template_1')
    var_2 = os.path.join(os.path.dirname(__file__), 'data_lookup_template_2')
    var_3 = os.path.join(os.path.dirname(__file__), 'data_lookup_template_3')
    var_4 = os.path.join(os.path.dirname(__file__), 'data_lookup_template_4')
    var_5 = os.path.join(os.path.dirname(__file__), 'data_lookup_template_5')
   

# Generated at 2022-06-25 11:19:12.603313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_template(*args, **kwargs):
        pass

    display = Display()
    with patch('ansible.plugins.lookup.template.AnsibleEnvironment') as mock_AnsibleEnvironment:
        with patch('ansible.plugins.lookup.template.AnsibleEnvironment.get_template') as mock_get_template:
            mock_get_template.side_effect = mock_template
            with patch('ansible.plugins.lookup.template.AnsibleEnvironment.list_templates') as mock_list_templates:
                mock_list_templates.return_value = None
                var_0 = LookupModule(loader=var_loader, templar=var_templar, shared_loader_obj=var_shared_loader_obj)

# Generated at 2022-06-25 11:19:27.140988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run")

    ##############################################################################################
    # Testcase 0
    ##############################################################################################

    test_case_0()

    ##############################################################################################
    # Testcase 1
    ##############################################################################################

    # with mock.patch('ansible.plugins.lookup.LookupBase.get_option', return_value=AnsibleError):
    #     with mock.patch(
    #             'ansible.plugins.lookup.LookupModule.find_file_in_search_path',
    #             return_value=AnsibleError):
    #         with mock.patch('ansible.plugins.loader._get_file_contents'):
    #             lookup_module_0 = mock.MagicMock()
    #             lookup_module_0.run.return_value

# Generated at 2022-06-25 11:19:37.262473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = None
    var_1 = deepcopy(var_0)
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    var_2 = deepcopy(var_1)
    var_3 = lookup_module_0.run(var_2, var_1, var_0)
    var_4 = to_text(var_3)
    var_5 = lookup_module_0.run(var_4, var_2, var_1, var_0)
    var_6 = to_text(var_5)
    var_7 = lookup_module_0.run(var_6, var_4, var_2, var_1, var_0)
    var_8 = to

# Generated at 2022-06-25 11:19:41.817093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:19:43.542168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:19:48.622536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    complex_0 = 2.0298927
    int_0 = -1906
    str_0 = 'e6v3UWQY8J'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(complex_0, int_0, str_0)

# Generated at 2022-06-25 11:19:55.627522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()

    # Exercise
    var_1 = lookup_module_2.run(var_0, lookup_module_0)
    # Verify
    assert var_1 == None


# Generated at 2022-06-25 11:19:58.878484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: make a better test case
    test_case_0()

# Generated at 2022-06-25 11:20:01.455154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    var_1 = "87"
    var_2 = lookup_module_3.run(var_1)
    assert var_2 == []

# Generated at 2022-06-25 11:20:07.701532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_0 = 2
    template_1 = 1
    json_0 = '-i'
    json_1 = 24
    float_0 = 0.7
    var_0 = None
    var_1 = None
    t_0 = None
    dict_0 = {var_0: var_1, t_0: json_0, t_0: json_1, t_0: float_0}
    tuple_0 = (template_0, template_1)
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(tuple_0)
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(dict_0, lookup_module_1)

# Generated at 2022-06-25 11:20:19.605691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    complex_1 = None
    int_1 = 2987
    tuple_1 = (complex_1, int_1)
    lookup_module_1 = LookupModule(tuple_1)
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()
    complex_2 = None
    tuple_2 = (complex_2, )
    int_2 = 2987
    lookup_module_3 = LookupModule(tuple_2)
    var_1 = lookup_module_3.run(int_2, lookup_module_2)
   

# Generated at 2022-06-25 11:20:35.278103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()
    lookup_module_2.run(int_0, lookup_module_0)


# Generated at 2022-06-25 11:20:42.213522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 4518
    lookup_module_0 = LookupModule()
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    var_0 = lookup_module_0.run(tuple_0, var_0)
    assert var_0 is not None


if __name__ == '__main__':

    # this is not working
    test_case_0()

# Generated at 2022-06-25 11:20:48.858834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule(tuple_0)
    str_0 = lookup_module_0.run(tuple_0, tuple_0)


# Generated at 2022-06-25 11:20:56.404956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 23842
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    # The function call lookup_module_1.run(int_0, lookup_module_0)
    # was expected to return any value.
    assert False


# Generated at 2022-06-25 11:21:05.156646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule(tuple_0)
    return var_0

# Generated at 2022-06-25 11:21:07.211138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for ansible.plugins.lookup.template.LookupModule.run

    # TODO: Implement unit test logic here and remove this
    raise Exception('Test not implemented')


# Generated at 2022-06-25 11:21:12.324173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (1, 2, 3)
    dict_0 = {'a' : 1, 'b' : 2, 'c' : 3}

    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_module_0.run(dict_0, dict_0)

    print(var_0)

if __name__ == '__main__':
    #test_LookupModule_run()
    #print(fib(7))
    #print(fib(10))
    test_case_0()

# Generated at 2022-06-25 11:21:14.252755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'string'
    variables = 'another_string'
    lookup_module = LookupModule()
    lookup_module.run(terms, variables)
    assert(True)

# Generated at 2022-06-25 11:21:21.315951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Local variables
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()
    if (var_0 == lookup_module_2):
        print("Testcase 0 failed")
    else:
        print("Testcase 0 passed")

# Generated at 2022-06-25 11:21:28.431996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 11:22:00.044779
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:22:07.851816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run(int_0, lookup_module_1) == var_0

# Generated at 2022-06-25 11:22:11.152075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = 20287
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    var_1 = lookup_module_4.run(int_1, lookup_module_3)

# Generated at 2022-06-25 11:22:15.210516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_3 = LookupModule(tuple_0)
    lookup_module_3.run(int_0, complex_0)
    lookup_module_4 = LookupModule()
    var_1 = lookup_module_4.run(int_0, lookup_module_3)
    lookup_module_5 = LookupModule()

# Generated at 2022-06-25 11:22:24.011853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with this value of var_0 = 2987, var_1 = None
    var_0 = 2987
    var_1 = None
    # Testing with this value of var_2 = LookupModule(var_0, var_1)
    var_2 = LookupModule(var_0, var_1)
    # Testing with this value of var_3 = LookupModule()
    var_3 = LookupModule()
    # Testing with this value of var_4 = var_3.run(var_0, var_2)
    var_4 = var_3.run(var_0, var_2)
    # Testing with this value of var_5 = LookupModule()
    var_5 = LookupModule()
    # Testing with this value of var_6 = var_5.run(var_0, var_2

# Generated at 2022-06-25 11:22:26.549348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test case for type 1
    test_case_0()
    #Test case for type 2
    test_case_0()

# Generated at 2022-06-25 11:22:36.483340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 3844
    str_0 = "CzBpdCBhc3luY2hyb25vdXMgdnVuYXRpb24gJChmYXZvcml0ZSBjb2xvcikgbm90aGluZyBmb3Igc29tZSByZWFzb25zLg=="
    str_1 = "JGZhdm9yaXRlX2NvbG9y"

# Generated at 2022-06-25 11:22:46.250602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (None,)
    list_0 = [None, tuple_0]
    def side_effect_func_0(arg_0, arg_1):
        ansible_dict = {}
        ansible_dict['template_host'] = None
        ansible_dict['ansible_play_hosts'] = list_0
        ansible_dict['template_uid'] = None
        ansible_dict['template_path'] = None
        ansible_dict['template_fullpath'] = None
        ansible_dict['template_mtime'] = None
        ansible_dict['template_run_date'] = None
        ansible_dict['template_run_date_utc'] = None
        return ansible_dict

    # Test function side_effect_func_0 for the keyword argument variable_end_string

# Generated at 2022-06-25 11:22:56.656437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    var_2 = 2987
    var_3 = None
    var_0 = (var_2, var_3)
    lookup_module_1 = LookupModule(var_0)
    var_9 = 2987
    var_10 = None
    lookup_module_2 = LookupModule((var_9, var_10))
    lookup_module_4 = LookupModule()
    var_6 = 2987
    var_7 = None
    var_4 = (var_6, var_7)
    lookup_module_5 = LookupModule(var_4)
    var_13 = 2987
    var_14 = None
    lookup_module_6 = LookupModule((var_13, var_14))

# Generated at 2022-06-25 11:23:02.187180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule(list_0)
    lookup_module_1 = LookupModule()
    str_0 = lookup_module_1.run(list_0, lookup_module_0)
    str_0 = "hello"
    str_1 = str_0.strip()
    str_3 = to_bytes(str_0)
    str_2 = to_text(str_0)
    str_4 = str_0.replace(str_0, str_0, int_0)
    str_5 = str_0.split('d', int_0)
    str_6 = str_0.ljust(int_0, str_0)

# Generated at 2022-06-25 11:23:45.490880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    int_1 = 10
    int_2 = 8
    complex_1 = complex_0
    complex_2 = lookup_module_3.run(int_1, int_2, int_1, int_2)
    assert complex_2 == complex_1


# Generated at 2022-06-25 11:23:50.700538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = None
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule(tuple_0)
    var_0 = lookup_module_1.run(tuple_0, tuple_0, convert_data=lookup_module_0, comment_start_string=tuple_0, comment_end_string=tuple_0, jinja2_native=lookup_module_0, template_vars=lookup_module_0, variable_end_string=tuple_0, variable_start_string=tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:52.615065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 11:24:02.384050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '68'
    str_1 = '0.'
    list_0 = []
    str_2 = '1'
    str_3 = '5f'
    str_4 = '2'
    list_1 = [str_0, str_1, str_2, str_3, str_4]
    int_0 = 1
    int_1 = 1
    list_2 = [int_0, int_1]
    list_3 = []
    list_4 = []
    str_5 = str(list_4)
    str_6 = '1'
    str_7 = '1.46'

# Generated at 2022-06-25 11:24:10.010295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2987
    complex_0 = None
    tuple_0 = (int_0, complex_0)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()
    print(var_0)
    print(lookup_module_2)

# Test case for LookupModule

# Generated at 2022-06-25 11:24:14.068522
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    int_0 = 4789
    list_0 = []
    dict_0 = {}
    lookup_module_0 = LookupModule(list_0, dict_0)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(int_0, lookup_module_0)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:24:15.757226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:24:21.539729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init a LookupModule object
    lookup_module_0 = LookupModule()

    # Provide a value for variable 'variable_start_string'
    lookup_module_0.set_options(var_options, direct=kwargs)
    # Provide a value for variable 'variable_end_string'
    lookup_module_0.set_options(var_options, direct=kwargs)
    # Provide a value for variable 'template_vars'
    lookup_module_0.set_options(var_options, direct=kwargs)
    # Provide a value for variable '_loader'
    lookup_module_0.set_options(var_options, direct=kwargs)
    # Provide a value for variable '_templar'
    lookup_module_0.set_options(var_options, direct=kwargs)
    # Inv

# Generated at 2022-06-25 11:24:25.478690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check global variable access
    assert LookupModule.run.__globals__ == globals()

# get methods from lookup module
for meth in dir(LookupModule):
    if meth.startswith('_'):
        continue
    globals()['test_case_%d' % i] = getattr(LookupModule, meth)
    i += 1

# Generated at 2022-06-25 11:24:34.071406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
#   int_0 = 2987
#
#   complex_0 = complex()
#
#   tuple_0 = (int_0, complex_0)
#
#   lookup_module_0 = LookupModule(tuple_0)
#
#   lookup_module_1 = LookupModule()
#
#   var_0 = lookup_module_1.run(int_0, lookup_module_0)
#
#   lookup_module_2 = LookupModule()
#
#   lookup_module_2.run(int_0, tuple_0)

# Generated at 2022-06-25 11:26:41.127284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if USE_JINJA2_NATIVE:
        # This test doesn't make sense when Jinja2 native types are available
        return

    # Setup a test file
    import tempfile
    fh, path = tempfile.mkstemp()
    os.write(fh, b'This is the test file')
    os.close(fh)

    terms = [path]
    variables = {
        'foo': 'bar',
        'ansible_search_path': [os.path.dirname(path)]
    }
    kwargs = {}

    # Create a new LookupModule instance
    lm = LookupModule()

    # Run the test
    result = lm.run(terms, variables, **kwargs)

    # Assert no error occurs
    assert(len(result) == 1)

# Generated at 2022-06-25 11:26:47.299909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ('property',)
    lookup_module_0 = LookupModule(tuple_0)
    arg_0 = None
    arg_1 = None
    arg_2 = None
    arg_3 = None
    arg_4 = None
    arg_5 = None
    return_value_0 = lookup_module_0.run(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    # @TODO: Add more tests!!


# Generated at 2022-06-25 11:26:50.518453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    param_0 = None
    param_1 = None

    try:
        lookup_module.run(param_0, param_1)
    except Exception as e:
        assert False, "Unable to run test for method run of class LookupModule: %s" % str(e)


# Generated at 2022-06-25 11:26:57.452938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import tests.test_utils as test_utils
    except ImportError:
        sys.exit("ERROR: tests/test_utils.py not found, please create it to run tests")
    try:
        import tests.test_lookups as test_lookups
    except ImportError:
        sys.exit("ERROR: tests/test_lookups.py not found, please create it to run tests")
    test_utils.run_method_unit_tests("LookupModule", "run", globals())

