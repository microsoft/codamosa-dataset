

# Generated at 2022-06-21 06:37:45.862413
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._templar is not None

# Generated at 2022-06-21 06:37:57.399547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import pprint
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.plugins.loader import lookup_loader

    def json_format(mylist):
        return json.dumps(mylist, indent=4).replace(r'"', r'\"')

    lookup = lookup_loader.get('template')

    # Set up paramters
    variables = VariableManager()

# Generated at 2022-06-21 06:37:59.777359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor test
    """
    lookup_module = LookupModule()
    assert lookup_module



# Generated at 2022-06-21 06:38:01.013405
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._loader == None
    assert lookup._templar == None

# Generated at 2022-06-21 06:38:02.372732
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:38:03.271427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:38:05.458284
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule

# Unit test specification for class LookupModule

# Generated at 2022-06-21 06:38:08.363574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    #lookup_module.run(terms, inject=None)

# Generated at 2022-06-21 06:38:13.225608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given

    # When
    lookup_module = LookupModule()
    ret = lookup_module.run(terms=[], variables={}, prompt=None, answer=None, encrypt=None, confirm=None, salt_size=None, salt=None)
    print(ret)
    # Then

# Generated at 2022-06-21 06:38:16.345355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Asserts that LookupModule object is created.
    """
    my_lookup = LookupModule()
    assert my_lookup is not None

# Generated at 2022-06-21 06:38:31.954270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init object under test
    lookupmod = LookupModule()
    lookupmod.set_loader({'_get_file_contents': lambda x: ('foo', False)})
    lookupmod.set_templar({
        'set_available_variables': lambda x: x,
        'template': lambda x, y=False, z=True, convert_bare=False: x,
        'copy_with_new_env': lambda env_class: lookupmod.set_templar({
            'set_available_variables': lambda x: x,
            'template': lambda x, y=False, z=True, convert_bare=False: x,
            'environment': env_class(),
        })
    })

    # Perform test
    result = lookupmod.run(['./some_template.j2'], {}, {})

# Generated at 2022-06-21 06:38:43.307162
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # verify that to_bytes is implemented correctly
    data = {'msg': 'This is my message'}
    result = to_bytes(data)
    if result != b'{msg: This is my message}':
        raise AnsibleError("to_bytes method needs to be fixed")

    # verify that the template can be found
    lookup = LookupModule()
    terms = './test_template_mock.txt'
    variables = {'ansible_search_path': ['./']}

# Generated at 2022-06-21 06:38:55.143938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    lookup = LookupModule()
    lookup.set_loader(DummyLoader())
    lookup._connection = DummyConnection()
    lookup._templar = DummyTemplar()

    lookupfile = os.path.realpath(__file__)
    with open(lookupfile, 'rb') as fs:
        f = fs.read()
    lookup._loader._file_contents_cache[lookupfile] = f, True
    template_data = to_text(f, errors='surrogate_or_strict')


# Generated at 2022-06-21 06:39:02.492781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test object creation
    lm = LookupModule()
    kwargs = {}
    terms = ['./some_template.j2']
    variables = {
        'test1': True,
        'test2': False,
        'test3': 0,
        'test4': 1,
        'test5': 2,
        'test6': '3',
        'test7': [],
        'test8': {},
        'test9': None
    }
    lm.run(terms, variables, **kwargs)

# Generated at 2022-06-21 06:39:09.138126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = ['/tmp/a.tmp']
    variables = {'ansible_search_path': ['/home/ubuntu/ansible/ansible/lib/ansible/modules']}

    kwargs = {'variable_end_string': ']]', 'variable_start_string': '[[', 'comment_end_string': '##',
              'comment_start_string': '#'}

    ret = l.run(terms, variables, **kwargs)
    assert terms == ret


# Generated at 2022-06-21 06:39:09.582775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:39:10.568282
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:39:13.330073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(my_loader())
    # no error happens
    lookup.run(terms=["/does/not/exist.tmp"], variables={})


# Generated at 2022-06-21 06:39:13.872186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:39:16.792975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    test_LookupModule: test constructor of class LookupModule
    """
    try:
        LookupModule()
    except Exception:
        assert False, 'unexpected exception raised'

# Generated at 2022-06-21 06:39:28.698206
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule  # avoid warning that LookupModule is unused
    # Instantiate a class
    lookup_module = LookupModule()

    # Assert that find_file_in_search_path returns a value
    terms = ['some/relative/path']
    variables = {'some_path': '/some/path'}
    lookup_module.run(terms, variables)

# Generated at 2022-06-21 06:39:32.631860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {'ansible_search_path': ['.'], 'variable_start_string': '{{', 'variable_end_string': '}}'}
    terms = ['./lookup_plugins/test/test_template.test']
    module = LookupModule()
    print(module.run(terms, variables))
    assert module.run(terms, variables) == ['Hello from template']

# Generated at 2022-06-21 06:39:42.451574
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        # attempt to retrieve the 'ini' lookup plugin
        lookup_plugin = LookupModule()
    except AnsibleError as e:
        # an error was raised, try to see the message
        try:
            error_message=str(e)
        except UnicodeEncodeError:
            error_message="<could not encode exception message>"
        # fail the test: print the error message and exit
        print('AnsibleError raised: %s' % error_message)
        sys.exit(1)
    # if no exception was raised, exit without error
    sys.exit(0)

# Generated at 2022-06-21 06:39:50.095939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create LookupModule instance
    terms = ['testtemplate.j2']
    variables = {}
    lookupmodule = LookupModule()
    lookupmodule.set_loader(None)
    lookupmodule.set_templar(None)
    # Ensure we are in the right directory
    cwd = os.getcwd()
    playbook_dir = os.path.dirname(cwd)
    os.chdir(playbook_dir)
    # Run test
    returned = lookupmodule.run(terms=terms, variables=variables)
    # Asserts
    assert returned == ['This is a test template.']

# Generated at 2022-06-21 06:39:51.787143
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()

# Generated at 2022-06-21 06:40:01.230508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test whether the method run returns the contents of the file when there is no error while executing the method
    # Input data for the method
    terms = ['./some_template.j2']
    variables = {'test_variable': 'test_value'}

    # Calling the method under test
    lookup_module = LookupModule()
    response = lookup_module.run(terms, variables)

    # Assertions
    # Check if the return value of the method is a list
    assert(isinstance(response, list))
    # Check if the list contains expected value
    assert(response[0] == "Hello, World! This is the template file with variable as test_value\n")


# Generated at 2022-06-21 06:40:01.826498
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:40:12.322030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3

    class MockVars(dict):
        """
        A simple mock of the AnsibleTaskVars class.
        """
        def __init__(self):
            super(MockVars, self).__init__()

    # Create a mock variable store
    variables = MockVars()
    variables['jinja2_native'] = True
    variables['ansible_search_path'] = ['/home/mock']
    variables['template_mtime'] = 1515692080.16

    # Create a mock template file path string
    template_file_path = './some_template.j2'

    # Create a mock lookup module
    lookup_module = LookupModule()

    # Create some content for the mock template file

# Generated at 2022-06-21 06:40:24.082793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup mock objects
    lookupModule = LookupModule()
    lookupModule.set_loader(MockLoader())
    lookupModule.set_templar(MockTemplar())

    # Test normal operation
    mock_variables = {
        'ansible_search_path': [
            './ansiballz/b_var_a',
            './ansiballz/b_var_b',
            './ansiballz/b_var_c',
            './ansiballz/b_var_d'
        ],
        'inventory_hostname': 'testhost'
    }
    test_terms = [
        './tests/fixtures/template.j2'
    ]

# Generated at 2022-06-21 06:40:29.814096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['./some_template.j2']
    variables = dict(a=1, b=2)
    kwargs = dict()
    lookup = LookupModule()
    ret = lookup.run(terms, variables, **kwargs)
    assert isinstance(ret, (list))
    for i in ret:
        assert isinstance(i, (str))
    pass

# Generated at 2022-06-21 06:40:53.016372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing class LookupModule')

    try:
        lookup_module = LookupModule()
    except Exception:
        print('FAILED: An unexpected error occurred during constructor of class LookupModule')
    else:
        print('SUCCESS: Class LookupModule successfully instantiated')


# Generated at 2022-06-21 06:40:54.004221
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:40:57.168769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert type(lookup_module) == LookupModule
    assert type(lookup_module) == LookupBase

# Generated at 2022-06-21 06:41:08.853499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display_mock = Display()
    display_mock.vvvv = lambda msg: None
    display_mock.debug = lambda msg: None
    display_mock.vvv = lambda msg: None

    def _get_file_contents(*args, **kwargs):
        read_mock = lambda filename: b'{{ foo }}'
        return read_mock(*args, **kwargs)

    def _templar_copy_with_new_env(*args, **kwargs):
        class AnsibleEnvironment_mock:
            environment_class = AnsibleEnvironment
            searchpath = []

            # Because no global vars were set, ansible will use the builtin lookup
            # plugin template_dirs value of ~/.ansible/plugins/lookup/template_dirs
            def get_basedir(self):
                return os

# Generated at 2022-06-21 06:41:11.826811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module)

'''
if __name__ == "__main__":
    test_LookupModule()
'''

# Generated at 2022-06-21 06:41:19.774345
# Unit test for constructor of class LookupModule
def test_LookupModule():

    display = Display()
    display.verbosity = 3

    # create a new instance of LookupModule
    lookup_plugin = LookupModule()

    # set test options
    _loader, _path_cache = lookup_plugin._loader._loader, lookup_plugin._loader._path_cache

# Generated at 2022-06-21 06:41:31.468435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    b_yml_lookup = b"""
      - name: "test name"
        age: "test age"
      - name: "test name 2"
        age: "test age 2"
    """

    yml_lookup = to_text(b_yml_lookup, errors='surrogate_or_strict')

    with open('/tmp/test.yml', 'w') as yml_file:
        yml_file.write(yml_lookup)

    # Jinja2 filters
    from ansible.module_utils.six.moves import builtins
    import pprint

    # Dummy module
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json

# Generated at 2022-06-21 06:41:40.856392
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    if not PY3:
        builtin_open = '__builtin__.open'
    else:
        builtin_open = 'builtins.open'
    from ansible.parsing.dataloader import DataLoader

    class DummyVarsModule(object):
        def __init__(self, data):
            self.data = data

        def get_vars(self, loader, path, entities):
            return self.data

    class DummyTemplar(object):
        def __init__(self):
            self.searchpath = None

        # AnsibleModule used to call this method whenever

# Generated at 2022-06-21 06:41:46.650785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader, lookup_loader_legacy
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))
    lookup_loader_legacy.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))
    lookup_loader.set_available_lookups(lookup_loader.all())
    lookup_loader_legacy.set_available_lookups(lookup_loader.all())
    l = LookupModule()
    l.set_loader(lookup_loader)
    l._templar = Templar(loader=lookup_loader)
    assert isinstance(lookup_loader, object)

# Generated at 2022-06-21 06:41:50.625185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = '{{ lookup(''template'', ''test_template.j2'') }}'
    terms = [term]
    result = LookupModule().run(terms, {})
    assert result == ['foobar']

# Generated at 2022-06-21 06:42:40.545077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    if sys.version_info[0] == 2 and sys.version_info[1] >= 7:
        import unittest
        import ansible.parsing.yaml.loader

        class TestLookupModule(unittest.TestCase):

            def test_options(self):
                runner = ansible.parsing.yaml.objects.AnsibleVars()
                runner._available_variables = dict()
                runner.set_variable("jinja2_native", True)
                lookup = LookupModule()
                lookup.set_options(var_options=runner, direct={'_original_file': '/foo/bar/test.yml', '_original_ds': 'foo'})

                # Should not raise an exception
                lookup._templar.template("{{ 0x11 }}")


# Generated at 2022-06-21 06:42:51.854736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({'some_template.j2': 'some_data'})
    lookup_module._templar = Templar(loader=lookup_module._loader)
    search_path = ['/some/path', '/other/path']
    lookup_module._loader.set_basedir('/some/path')

    # default option values
    jinja2_native = False
    convert_data = True

    # call tested method
    results = lookup_module.run(terms=['some_template.j2'], variables={'my_var': 'my_data', 'ansible_search_path': search_path})

    assert len(results) == 1
    assert results[0] == 'some_data'

# Generated at 2022-06-21 06:42:55.698533
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Testing ansible.plugins.lookup.template constructor"""
    lookup_plugin = LookupModule()

    assert lookup_plugin._templar._available_variables == {}
    assert lookup_plugin._templar._fail_on_undefined_errors == False



# Generated at 2022-06-21 06:43:08.133600
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import ansible.plugins.loader as plugin_loader
    import ansible.template
    # import ansible.utils.templating as templating
    import jinja2

    # Setup for unit test
    test_dir = os.path.dirname(__file__)
    template_dir = os.path.join(test_dir, 'template_plugin_templates')
    search_path = [template_dir]
    variables = dict(template_dir=template_dir)
    loader = plugin_loader.get(None, 'file')
    env = jinja2.Environment(loader=ansible.template.AnsibleBytecodeCacheLoader(searchpath=search_path))
    templar = ansible.template.Templar(loader=loader, variables=variables, env=env)
    lookup_

# Generated at 2022-06-21 06:43:09.886548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:43:13.879098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test init
    lookup = LookupModule()
    display.vvvv("New LookupModule: %s" % lookup.__dict__)

    # test run
    lookup.run([], dict(__file__='/home/devel/ansible/hacking/test/sanity/code-smell/roles/test_role/tasks/main.yml'))


# Generated at 2022-06-21 06:43:17.189067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for class constructor without any parameter
    LookupModule()
    # Test for class constructor with parameters (passing empty lists)
    LookupModule(Loader=None, basedir=None, run_once=True)

# Generated at 2022-06-21 06:43:29.127501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check the run method of lookup 'lookup_plugins.template'. """

    lookup_module = LookupModule()

    # Create mock objects for class LookupBase.
    class TestClass(object):
        """ Test class. """
        pass
    class MockClass(object):
        """ Mock class. """
        def __init__(self):
            self.test_class = TestClass()
            self.test_class.loader = MockClass()

        def get_basedir(self):
            return "/home/user"

    lookup_module._loader = MockClass()

    # Create mock objects for class LookupBase and Jinja2.Environment.
    class MockClass2(object):
        """ Mock class. """
        def __init__(self):
            self.tests = {}
            self.filters = {}

# Generated at 2022-06-21 06:43:34.150564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for default constructor.
    lookup_module = LookupModule()
    assert lookup_module, "lookup_module is null..."

    # Test for correct initialization.
    lookup_module = LookupModule()
    lookup_module.run(terms=['/tmp/file_1'], variables={'ansible_search_path': ['/tmp/']})

# Generated at 2022-06-21 06:43:41.624650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is for jinja2_native=True
    test = ansible.plugins.lookup.template.LookupModule
    # list of terms
    terms = ['./some_template.j2']
    # dictionary of variables
    variables = AnsibleVars()
    # dictionary of kwargs
    f = {'filename': './some_template.j2'}
    # set the loader_obj
    test.set_loader(mock_loader)
    # run the test
    results = test.run(terms, variables, **f)
    # test the results
    assert results[0] == 'Some content from a file'

# Generated at 2022-06-21 06:45:21.975296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:45:26.612962
# Unit test for constructor of class LookupModule
def test_LookupModule():

    display = Display()
    terms = "./some_template.j2"
    variables = {}
    args = {}
    lm = LookupModule(display, terms, variables, **args)

    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:45:36.756421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import AnsibleEnvironment
    from ansible.template.jinja2.environment import AnsibleSandboxedEnvironment

    lookup = LookupModule()
    options = {
        "convert_data": False,
        "template_vars": {},
        "jinja2_native": False,
        "variable_start_string": '{{',
        "variable_end_string": '}}',
        "comment_start_string": None,
        "comment_end_string": None
    }

    lookup.set_options(var_options=None, direct=options)

    terms = "./test_options.j2"

# Generated at 2022-06-21 06:45:46.346341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert '_raw' == LookupModule._raw_params['_terms']['type']
    assert 'bool' == LookupModule._raw_params['convert_data']['type']
    assert 'str' == LookupModule._raw_params['variable_start_string']['type']
    assert 'str' == LookupModule._raw_params['variable_end_string']['type']
    assert 'bool' == LookupModule._raw_params['jinja2_native']['type']
    assert 'dict' == LookupModule._raw_params['template_vars']['type']
    assert 'str' == LookupModule._raw_params['comment_start_string']['type']
    assert 'str' == LookupModule._raw_params['comment_end_string']['type']

# Generated at 2022-06-21 06:45:51.850590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # 1. test jinja2_native is False globally and lookup is also False
    jinja2_native = True
    templar = AnsibleEnvironment()
    test = LookupModule(templar._templar, jinja2_native=jinja2_native)
    assert isinstance(test._templar, AnsibleEnvironment)

    # 2. test jinja2_native is False globally and lookup is True
    jinja2_native = False
    templar = AnsibleEnvironment()
    test = LookupModule(templar._templar, jinja2_native=jinja2_native)
    assert isinstance(test._templar, AnsibleEnvironment)

    # 3. test jinja2_native is True globally and lookup is also True
    jinja2_native = True


# Generated at 2022-06-21 06:45:57.936360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instance construction
    lookupModule = LookupModule()
    assert lookupModule is not None

    # Find file in search path
    searchPath = ['/usr/share/ansible']
    fileName = 'some_file.j2'
    lookupModule.find_file_in_search_path(searchPath, 'templates', fileName)

# Generated at 2022-06-21 06:46:09.201771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.loader import LookupModule as L
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display

    LookupModule._display = Display(verbosity=0)
    LookupBase.set_loader(L())

# Generated at 2022-06-21 06:46:10.090653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:46:13.196183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup_result = lookup.run(['test_template.j2'], {'test_variable': 'test_value'})
    assert lookup_result == ['test_value']

# Generated at 2022-06-21 06:46:15.134624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('template')
    assert hasattr(lookup, 'run')