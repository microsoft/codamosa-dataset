

# Generated at 2022-06-21 06:37:52.943018
# Unit test for constructor of class LookupModule
def test_LookupModule():
 
    # test inputs and expected results
    test_input_terms = [
        {
            'terms': ['./some_template.j2'],
            'variables': {'test_var': 'test value'}
        }
    ]
    test_input_options = [
        {
            'options':
            {
                'convert_data': True,
                'template_vars': {'test': 'test'},
                'jinja2_native': False,
                'variable_start_string': '{{',
                'variable_end_string': '}}',
                'comment_start_string': '{#',
                'comment_end_string': '#}'
            }
        }
    ]


# Generated at 2022-06-21 06:38:00.643700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Case 1: Throw exception - term not found
    with pytest.raises(AnsibleError) as excinfo:
        module.run(terms='test_term', variables='test_variable')
    assert 'the template file test_term could not be found for the lookup' in str(excinfo.value)

    # Case 2: Return value
    assert 'test_value' == module.run(terms=[fixture_file('test.j2')], variables={'hello': 'test_value'})[0]

# Generated at 2022-06-21 06:38:01.992387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._templar is not None

# Generated at 2022-06-21 06:38:09.442757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # params is a class
    params = Parameters()
    params.debug = False
    params.jinja2_native = True

    # params is a class
    vars = Parameters()
    vars['inventory_dir'] = "/etc/ansible/hosts"
    vars['inventory_file'] = "/etc/ansible/hosts/localhost"

    # loader is an object
    loader = DataLoader()

    # templar is an object
    templar = Templar(loader=loader, variables=vars)

    # display is an object
    display = Display()

    # context is an object
    context = Context()

    # a is an object
    a = LookupModule(loader=loader, templar=templar, params=params, display=display)

    # terms is a list

# Generated at 2022-06-21 06:38:10.521088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:38:12.266743
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup



# Generated at 2022-06-21 06:38:14.532434
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)
    assert isinstance(instance, LookupBase)

# Generated at 2022-06-21 06:38:16.760355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test instantiation of LookupModule class object
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:38:28.144110
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:38:34.984144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['my_file.j2']
    variables = dict()
    returnvalue = LookupModule(None).run(terms, variables)
    assert(isinstance(returnvalue,list))
    assert(isinstance(returnvalue[0],str))


# Generated at 2022-06-21 06:38:56.055134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})
    test_module.params['convert_data'] = True
    test_module.params['variable_start_string'] = '%%('
    test_module.params['variable_end_string'] = ')%%'
    test_module.params['comment_start_string'] = '%%#'
    test_module.params['comment_end_string'] = '#%%'
    test_module.params['lookup_template_vars'] = {
        'foo': 'bar',
        'list': ['x', 'y'],
        'dict': {'one': '1', 'two': '2', 'three': '3'},
    }

    lookup_module = LookupModule()
    lookup_

# Generated at 2022-06-21 06:38:56.812515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # No tests yet
    pass

# Generated at 2022-06-21 06:38:59.608586
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_loader({'_get_file_contents': lambda x : (b'', False)})

# Generated at 2022-06-21 06:39:00.981545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module


# Generated at 2022-06-21 06:39:03.391357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_objct = LookupModule()
    assert lookup_objct is not None

# Generated at 2022-06-21 06:39:04.036762
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:39:11.534352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    datadir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'unit', 'utils', 'lookup_plugins', 'data')
    template_data = os.path.join(datadir, 'template_data')
    lookupfile = os.path.join(template_data, 'test_template.j2')
    fixture_data = dict(
        ansible_search_path=[template_data],
        s='hello',
        item='hello',
    )
    # this test just checks that the module can be run without raising an exception
    lookup_mod.run([lookupfile], fixture_data)

# Generated at 2022-06-21 06:39:22.797958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.verbosity = 2
    from ansible.plugins.loader import lookup_loader
    tm = lookup_loader.get('template', class_only=True)(None, display)

# Generated at 2022-06-21 06:39:31.977958
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert (LookupModule.run_ansible_module.__name__ == 'run_ansible_module'), "run_ansible_module of class LookupModule has an unexpected name"
    assert (LookupModule.run_ansible_module.__doc__ == 'Ansible module for the lookups'), "run_ansible_module of class LookupModule has an unexpected docstring"

    assert (LookupModule.run_ansible_lookup.__name__ == 'run_ansible_lookup'), "run_ansible_lookup of class LookupModule has an unexpected name"
    assert (LookupModule.run_ansible_lookup.__doc__ == 'Ansible lookup module'), "run_ansible_lookup of class LookupModule has an unexpected docstring"

# Generated at 2022-06-21 06:39:44.906828
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import io
    import sys
    import yaml

    # Capture stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = io.StringIO()

    from ansible.template import Templar
    from ansible.plugins.lookup import LookupBase

    # Create an example variable dictionary
    variables = {
        "somevar": "somevalue",
        "othervar": {
            "value": "someothervalue",
            "key": "value"
        }
    }

    # Create an example lookup object
    lookup = LookupBase()
    lookup._templar = Templar(loader=None, variables=variables)
    lookup.set_options(var_options=variables, direct={})

    # Create an example search path

# Generated at 2022-06-21 06:40:05.787213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader())))
    lookup = LookupModule()
    lookup.set_loader(DataLoader())
    lookup._templar = templar
    lookup.set_environment(VariableManager(), InventoryManager(), DataLoader())


# Generated at 2022-06-21 06:40:15.942587
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #create LookupModule object
    lookup_plugin = LookupModule()

    #create variables for unit test
    variables = {
        'role_path':
            ['/etc/ansible/roles/my-role'],
        'inventory_dir':
            '/etc/ansible/hosts',
        'playbook_dir':
            '/etc/ansible/playbooks',
        'ansible_version':
            '2.8.0',
        'group_names':
            ['ungrouped'],
        'run_once':
            'False'
    }

    #create terms for unit test
    terms = ["../../../../../../../../ReflectiveDLLInjection.cs.j2"]

    #run the unit test
    result = lookup_plugin.run(terms, variables)

    #assert that the

# Generated at 2022-06-21 06:40:27.550291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_dir = os.path.dirname(os.path.realpath(__file__)) + "/../lookup_plugins/"
    lookup = LookupModule()

    lookup.set_loader(loader=DictDataLoader())
    lookup.set_templar(AnsibleTemplar())
    lookup.set_basedir(test_dir)

    terms = ['simple.j2']
    ret = lookup.run(terms, {})
    assert "Hello from simple.j2\n" == ret[0]

    terms = ['complex.j2']
    ret = lookup.run(terms, {})
    assert "Hello from complex.j2\n" == ret[0]

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-21 06:40:37.679737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Loader:
        def __init__(self):
            self._templates = {
                './file1.j2': '{{key1}}',
                './file2.j2': '{{key2}}'}
        def get_basedir(self, *args, **kwargs):
            return './'
        def _get_file_contents(self, filename, *args, **kwargs):
            return self._templates[filename]
    class VariableManager:
        def __init__(self):
            self._vars = {
                'key1': 'value1',
                'key2': 'value2'}
        @property
        def extra_vars(self):
            return self._vars
    class Options:
        pass
    plugin = LookupModule(Loader(), VariableManager(), Options)


# Generated at 2022-06-21 06:40:49.162735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test LookupModule

    This test is used to know if the constructor of the LookupModule is
    working with the correct parameters.

    See also: https://stackoverflow.com/questions/2052390/manually-raising-throwing-an-exception-in-python
    """
    args = {
        '_templar': None,
        '_loader': None
    }


# Generated at 2022-06-21 06:40:50.002860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    #TODO: test with large number of paths in search path
    assert lookup

# Generated at 2022-06-21 06:41:02.862270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # simple test data
    lookup = "defaults/main.yml"
    terms = [
        "/path/to/base/ansible/roles/my_role/templates/{0}".format(lookup),
        "/path/to/base/ansible/roles/my_role/{0}".format(lookup)
    ]
    yaml_data = ("tls_version: tlsv1\n"
                 "timeout: 5\n"
                 )
    yaml_data_after_template = ("tls_version: tlsv1\n"
                                "timeout: 5\n"
                                )

    # prepare test data
    import jinja2
    from ansible.template import template_from_string
    from ansible.parsing.yaml.objects import AnsibleBase

# Generated at 2022-06-21 06:41:14.426850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Build inputs to the run method
    terms = ['test.j2']
    variables = dict()
    variables.update({'test1': 'test1'})
    variables.update({'test2': 'test2'})
    kwargs = {'convert_data': True}
    # Setup of the appropriate data structures to simulate a file lookup
    module_loader = MockModuleLoader()
    module_loader._files = dict()
    module_loader._files['templates/test.j2'] = '{{ test1 }} {{ test2 }}'
    # Execute the run method
    lookup_module = LookupModule()
    lookup_module._loader = module_loader
    # Check the returned data on success
    assert lookup_module.run(terms, variables, **kwargs) == ['test1 test2']
    # Check the returned data

# Generated at 2022-06-21 06:41:26.198780
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term = 'a'
    terms = [term]
    variables = {'a':'A'}
    terms_with_var = [term,variables]

    # Mock function _loader of class LookupModule
    class _loader:
        def _get_file_contents(*args,**kwargs):
            return 'a',None

    # Mock function find_file_in_search_path of class LookupModule
    class find_file_in_search_path:
        def return_true(*args,**kwargs):
            return True

    # Mock function _templar of class LookupModule
    class _templar:
        def copy_with_new_env(*args,**kwargs):
            return 'templar'

# Generated at 2022-06-21 06:41:31.641532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # Test args
    assert isinstance(lookup_module.args, dict)

    # Test basedir
    assert lookup_module.basedir == None
    
    # Test _templar
    assert isinstance(lookup_module._templar, AnsibleTemplate)
    
    # Test runner
    assert lookup_module.runner == None

# Generated at 2022-06-21 06:41:56.730834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test method run
    lookup_plugin = LookupModule()

    assert lookup_plugin.run([], dict()) == [], 'No template should return empty string'
    assert lookup_plugin.run(["test.j2"], dict()) == [], 'Doesn\'t find test.j2'

    assert lookup_plugin.run(["test.j2", "test.j2"], dict()) == [], 'Doesn\'t find test.j2'

# Generated at 2022-06-21 06:42:04.309847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    
    assert(l.get_option('convert_data') == True)
    assert(l.get_option('template_vars') == {})
    assert(l.get_option('jinja2_native') == True)
    assert(l.get_option('variable_start_string') == '{{')
    assert(l.get_option('variable_end_string') == '}}')
    assert(l.get_option('comment_start_string') == '{#')
    assert(l.get_option('comment_end_string') == '#}')

# Generated at 2022-06-21 06:42:05.959438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:42:07.105154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:42:09.129115
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:42:11.628522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 06:42:18.427866
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_lookup = LookupModule()
    test_lookup.set_loader({
        'path_sep': '/',
        '_get_file_contents': lambda x: ('{{ name }}', True)
    })
    result = test_lookup.run(
        ['/test/test/test.j2'],
        {'name': 'ansible'},
        convert_data=False,
        jinja2_native=False,
        variable_start_string='[%',
        variable_end_string='%]',
        comment_start_string='[#',
        comment_end_string='#]',
        **{'template_vars': {}}
    )

    assert result == ['{{ name }}']


# Generated at 2022-06-21 06:42:21.298810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:42:23.862160
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('--- Unit test start ---')
    print('Go to test/integration/targets/template for unit test of template module')
    print('--- Unit test end ---')

# Generated at 2022-06-21 06:42:32.316879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is not idempotent in that it changes the search path
    # being used.  If we ever change the test module to reset the search path
    # after each test, this test should become idempotent.

    tester = LookupModule()
    new_search_path = [os.path.dirname(os.path.realpath(__file__)) + "/../../.."]
    result = tester.run(terms=["ansible.cfg"],
                        variables=dict(ansible_search_path=new_search_path),
                        **dict(jinja2_native=True))

    assert to_bytes("[defaults]\n") in result

# Generated at 2022-06-21 06:43:17.912430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/utils/test/test_basic.py
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/utils/unsafe_proxy.py
    # https://github.com/ansible/ansible/issues/17908

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    """
    Requirements:
    - Password must be stored in a 'password.txt' file in the CWD
      The content should be 'ansible'
    - The 'password.txt' file must be readable by everyone

    If these requirements are not met, call the function 'test_LookupModule_run()'
    with the optional parameter 'skip_test=False' to execute the tests.
    """

# Generated at 2022-06-21 06:43:29.598558
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Important: For this unit test to work, we must ensure that
    # the directory containing the file "some_template.j2" is in ANSIBLE_TEMPLATE_DIRS
    # To do this,

    # 1. Copy lookup_plugins/template_tests to this directory (to ensure it is in the same directory
    #    as the lookup_plugins directory).
    #
    # 2. Add this directory (above) to ANSIBLE_TEMPLATE_DIRS
    #    Add this directory to ANSIBLE_TEMPLATE_DIRS in ansible.cfg

    import pytest

    # Create some test data
    common_template_data = "testing"
    lookup_template_vars = dict()
    searchpath = ['.']

# Generated at 2022-06-21 06:43:36.746892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    var_manager = VariableManager(loader=loader, inventory=inv_manager)

    module = LookupModule()
    module.set_loader(loader)
    module.set_inventory(inv_manager)
    module.set_vars(var_manager)

# Generated at 2022-06-21 06:43:47.673754
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Dummy class for tests
    class MyTQM(object):

        class _DummyOptions(object):
            def __init__(self):
                self.listhosts = False
                self.listtasks = False
                self.listtags = False
                self.syntax = False

        options = _DummyOptions()

        def __init__(self):
            self.inventory = None
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.shared_loader_obj = None

    mytqm = MyTQM()

    foo_content = b'{"key": "value"}'


# Generated at 2022-06-21 06:43:55.057612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import AnsibleEnvironment
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import Mapping
    import os

    TESTS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_DIR = os.path.join(TESTS_DIR, 'unit/plugins/lookup/data')

    # The following is needed to have display.debug output printed to stdout
    display = Display()
    display.verbosity = 3

    lookup_obj = LookupModule()

    # Setup data
    env = AnsibleEnvironment(loader=None, variables={'name': 'Joe'})
    lookup_obj._templ

# Generated at 2022-06-21 06:44:00.140322
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:44:09.668231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get the file path for the test templates.
    test_dir_path = os.path.dirname(os.path.abspath(__file__))
    test_templates_dir_path = os.path.join(test_dir_path, 'templates')

    # Set up arguments to pass to the run method.
    terms = [
        'nested_list.j2'
    ]
    variables = {
        'ansible_search_path': [
            test_templates_dir_path
        ],
        'test_lookup_value': [
            'item 1',
            'item 2',
            'item 3'
        ]
    }

    # Instantiate a LookupModule object.
    test_lookup_module = LookupModule()
    test_lookup_module._loader.path_d

# Generated at 2022-06-21 06:44:13.084793
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.lookup_type == 'template'
    assert lookup_plugin.templar._use_native_types

# Generated at 2022-06-21 06:44:14.843483
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj._loader is not None
    assert obj._templar is not None
    assert obj._display is not None

# Generated at 2022-06-21 06:44:21.481218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    # Simple lookup file
    lookup_file = LookupModule()
    lookup_file.set_options({'_ansible_check_mode': False, '_ansible_debug': True})
    ret = lookup_file.run(['file_does_not_exist'], {'ansible_search_path': ['.']})
    assert ret[0] == 'file_does_not_exist'

    # lookup file with variable_start_string and variable_end_string
    lookup_file_variable_start_end_string = LookupModule()

# Generated at 2022-06-21 06:46:00.099556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.template import LookupModule
    # Code to perform test on method run of class LookupModule
    lookup_template = LookupModule()
    lookup_template_terms = ['/home/repo/work/tests/unit/fixtures/template_file']
    lookup_template_variables = {'var1': 'var1'}
    lookup_template_run = lookup_template.run(lookup_template_terms, lookup_template_variables)
    assert lookup_template_run == ["{{lookup_template_terms}}"]

# Generated at 2022-06-21 06:46:06.989844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._loader = DictDataLoader({})
    l._templar = DictTemplate({'VAR1': 'VALUE1', 'VAR2': 'VALUE2'})
    terms = 'template.j2'
    variables = dict()
    assert l.run(terms, variables) == ['{{VAR1}} {{VAR2}}',]


# Generated at 2022-06-21 06:46:15.066467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.errors import AnsibleError

    # test init without params
    lookup_module = LookupModule()

    # test get_option() with a param which doesn't exist
    try:
        lookup_module.get_option('no_such_option')
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError not raised')

    # test find_file_in_search_path()
    try:
        lookup_module.find_file_in_search_path({}, 'templates', 'no_such_file')
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError not raised')

# Generated at 2022-06-21 06:46:22.300072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_loader = DictDataLoader({
        'test_template.j2': 'test string {{ test_var }}'
    })
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule()
    mock_module.params = {
        'test_var': 'bar'
    }

    mock_templar = Templar(mock_loader, variables=mock_module.params)

    # Test with jinja2_native off
    templar_env_class = AnsibleEnvironment
    templar = mock_templar.copy_with_new_env(environment_class=templar_env_class)
    expected = to_bytes('test string bar')
    lookup = LookupModule()

# Generated at 2022-06-21 06:46:24.580327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_loader({ })
    lookup.set_basedir('.')
    lookup.set_templar({ })
    assert lookup != None

# Generated at 2022-06-21 06:46:28.082345
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    lookup.set_loader("loader_mock")
    lookup._templar = "templar_mock"
    lookup._loader = "loader_mock"

    assert lookup.run(terms = ["file_path"], variables=[])

# Generated at 2022-06-21 06:46:29.584436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-21 06:46:32.562332
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-21 06:46:41.082400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager

    # test context

    # test empty term
    terms = []
    variables = ansible.vars.manager.VarsManager()
    obj = LookupModule(loader=ansible.parsing.dataloader.DataLoader(), inv_manager=ansible.inventory.manager.InventoryManager())
    assert obj.run(terms, variables) == []

    # test invalid term
    terms = ['not_existing_file.j2']
    with pytest.raises(AnsibleError):
        obj.run(terms, variables)

    # test term
    terms = ['test_template_file.j2']
    res = obj.run(terms, variables)

# Generated at 2022-06-21 06:46:52.970498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_opt(options, name, default=None):
        return options.get(name, default)

    from ansible.module_utils._text import to_text

    # For these tests we create a mock set of classes to replace the Ansible guts
    #  and then call the run method on the LookupModule directly.
    #  This lets us use the same validation code for testing unittests as well as
    #  the integration tests.  The main thing we need to mock is the actual file
    #  read, and we do that by manipulating the _loader.path_dwim method to return
    #  our own fake file path.

    class MockTemplateVars(object):
        def __init__(self, vars):
            self.vars = vars

        def __getitem__(self, name):
            return self.v