

# Generated at 2022-06-21 06:37:57.352808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    b_template_data = 'this is a test'
    show_data = ''

    def test_find_file_in_search_path(variables, basedir, file):
        return '/etc/ansible/' + file

    module._loader._get_file_contents = lambda lookupfile: (b_template_data, show_data)
    module._loader.get_basedir = lambda term: '/etc/ansible'
    module.find_file_in_search_path = test_find_file_in_search_path
    module._templar.template = lambda template_data, preserve_trailing_newlines, convert_data, escape_backslashes: template_data
    module._templar.template_from_file = lambda lookupfile, convert_data: lookupfile
    module

# Generated at 2022-06-21 06:38:06.285636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import datetime

    dt = datetime.datetime(2001, 1, 1, 0, 0, 0)
    terms = [
        "test_template"
        ]
    variables = {
        'a': 'b',
        'c': [1, 2, 3],
        'd': {'e': ['f', 'g', 'h'], 'i': True},
        'j': dt,
        'k': 1.2,
        'm': {'n': {'o': {'p': {'q': 'r'}}}, 's': 1, 't': 'u', 'v': False}
    }
    test_class_obj = LookupModule()
    test_class_obj.set_options(var_options=variables, direct={})

# Generated at 2022-06-21 06:38:18.508104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    module = LookupModule()
    dummy_loader = DummyLoader({
        'inventory': {
            'my/file.j2': 'Hello World'
        }
    })
    module._loader = dummy_loader

    # The templar object is needed to avoid running into the __init__ of AnsibleModule
    if PY3:
        module._templar = DummyTemplar({}, StringIO())
    else:
        module._templar = DummyTemplar({}, StringIO(), to_text=to_bytes)


# Generated at 2022-06-21 06:38:26.921575
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: Replace with parametrized tests
    lookup_module = LookupModule()
    lookup_module.run([], {})
    lookup_module.run([], {'convert_data': True})
    lookup_module.run([], {'convert_data': False})
    lookup_module.run([], {'jinja2_native': True})
    lookup_module.run([], {'jinja2_native': False})
    with pytest.raises(AnsibleError):
        lookup_module.run(['something.j2'], {})

# Generated at 2022-06-21 06:38:38.864967
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create instance of LookupModule
    look = LookupModule()

    # create mock of templar (AnsibleTemplar) to be used by LookupModule
    class MockAnsibleTemplar(object):
        class MockTemplate(object):
            def __init__(self, data, vars, search):
                self.data = data
                self.vars = vars
                self.search = search

            def render(self):
                return 'template content'

        def __init__(self):
            self.data = ''
            self.vars = {}
            self.search = []

        def copy_with_new_env(self, environment_class):
            return MockAnsibleTemplar()


# Generated at 2022-06-21 06:38:40.819157
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-21 06:38:42.124199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:38:47.461644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a instance of LookupModule for unit testing
    # Some of the properties can be tested, but some of the properties are not able to test.
    # For example, environment_class is a parameter of an internal function, so it is not able to test.
    lookupModule = LookupModule()
    assert lookupModule is not None



# Generated at 2022-06-21 06:38:58.593738
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Instantiate the lookup module
    lookup_templ = LookupModule()

    ret = []

    # Loop through the items in a list and return the items
    for term in ['test1', 'test2']:
        ret.append(term)

    assert ret == ['test1', 'test2']

    # Fetch the environment variables and return the variables
    lookup_templ.run('', {})

    # Fetch the dict data
    lookup_templ.run(['test1', 'test2'], {}, template_vars = {"env": os.environ})

    # Get the option
    lookup_templ.get_option("template_vars")

    # Set the options
    lookup_templ.set_options(var_options = {}, direct = {})

# Generated at 2022-06-21 06:39:00.214881
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup


# Generated at 2022-06-21 06:39:06.360096
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-21 06:39:15.322204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('template')

    assert lookup._templar.environment.variable_start_string == '{{'
    assert lookup._templar.environment.variable_end_string == '}}'
    assert 'convert_data' in lookup._options
    assert 'jinja2_native' in lookup._options
    assert 'template_vars' in lookup._options
    assert 'variable_start_string' in lookup._options
    assert 'variable_end_string' in lookup._options
    assert 'comment_start_string' in lookup._options
    assert 'comment_end_string' in lookup._options

# Generated at 2022-06-21 06:39:27.380726
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert lookup_module._templar.environment.variable_start_string == u'{{'
    assert lookup_module._templar.environment.variable_end_string == u'}}'

    lookup_module = LookupModule(variable_start_string='[%', variable_end_string='%]')
    assert isinstance(lookup_module, LookupModule)
    assert lookup_module._templar.environment.variable_start_string == u'[%'
    assert lookup_module._templar.environment.variable_end_string == u'%]'

    lookup_module = LookupModule(comment_start_string='[#', comment_end_string='#]')

# Generated at 2022-06-21 06:39:34.591136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup class
    lookup_plugin = LookupModule()
    # setup mocks for find_file_in_search_path and template
    lookup_plugin._loader = Mock()
    lookup_plugin.loader.get_basedir = Mock(return_value='/foo/bar')
    lookup_plugin._templar = Mock()
    lookup_plugin.templar.template = Mock(return_value='templated text')
    lookup_plugin.find_file_in_search_path = Mock(return_value='/foo/bar/templates/file1')
    lookup_plugin.loader._get_file_contents = Mock(return_value=('file contents', False))

    # test regular run

# Generated at 2022-06-21 06:39:47.281391
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup import LookupModule
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    B_TERMS = [
        b"file:foo:bar",
        b"file:long:path:more"
    ]

    TERMS = [to_text(x, encoding='utf-8') for x in B_TERMS]


# Generated at 2022-06-21 06:39:53.634931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_class = LookupModule()

    test_terms = ["./some_template.j2"]
    test_variables = {'template_vars':{}}
    result = lookup_class.run(test_terms,test_variables)
    assert result == []


# Generated at 2022-06-21 06:39:54.368497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert(mod is not None)

# Generated at 2022-06-21 06:40:00.010328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([], {'a': 'b'}) == []
    assert lookup.run(['/some/file'], {'a': 'b'}) == []
    assert lookup.run(['/some/file'], {'a': 'b'}) == []
    assert lookup.run(['/some/file'], {'a': 'b'}) == []

# Generated at 2022-06-21 06:40:01.350974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 06:40:11.929679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # initialize the test environment


# Generated at 2022-06-21 06:40:28.989017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the instance of LookupModule class
    foo = LookupModule()

    # Parameters of run method
    terms = [
        './some_template.j2',
        'bar.txt',
        './another_template.j2'
    ]

    variables = {
        'ansible_search_path': [
            '~/.ansible/lookups/files',
            '/etc/ansible/lookups/files'
        ],
        'template_path': '/etc/ansible/lookups/templates',
        'template_mtime': 1545093741.180432
    }

    # Expected result
    ret = [
        'something',
        'something else',
        'something'
    ]

    # Assert
    assert foo.run(terms, variables) == ret

# Generated at 2022-06-21 06:40:30.150838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_loader()

# Generated at 2022-06-21 06:40:33.758847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Let's test a simple lookup
    result = lookup.run([to_bytes("test.j2")], dict(testvar="testvalue", testlist=["testvaluelist"]), **dict(convert_data=True))
    assert result == [to_bytes("testvalue")]

# Generated at 2022-06-21 06:40:34.267975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:40:46.727691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = []
    terms.append("../../lib/ansible/plugins/lookup/confluence")
    terms.append("../../lib/ansible/plugins/lookup")
    variables = {}
    kwargs = {}
    kwargs['convert_data'] = True
    kwargs['template_vars'] = {}
    kwargs['jinja2_native'] = True
    kwargs['variable_start_string'] = '{{'
    kwargs['variable_end_string'] = '}}'
    kwargs['comment_start_string'] = '/*'
    kwargs['comment_end_string'] = '*/'
    result = module.run(terms, variables, **kwargs)
    assert type(result) is list
    assert result[0]

# Generated at 2022-06-21 06:40:48.078822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:40:55.528227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/test_lookup_plugins/inventory"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="no",
        tasks=[dict(action=dict(module="template", args=dict(src="foo.j2", dest="outfile")))]
    )

    outfile = StringIO()
    tqm = None
   

# Generated at 2022-06-21 06:40:56.829381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-21 06:41:08.543824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader()

    # instantiate the options
    convert_data = False
    lookup_template_vars = {}
    jinja2_native = False
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_end_string = '#}'

    terms = "test_string"
    ret = []

    ret.append({'test_string': 1})


# Generated at 2022-06-21 06:41:18.094775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a dummy env-var to store the ansible-cwd
    os.environ['ANSIBLE_LOOKUP_CWD'] = os.getcwd()

    # Create a dummy LookupModule object
    lookup = LookupModule()

    # Create a dummy loader to load a file from
    loader = DummyLoader({
        'test.j2': to_bytes('{{test_var}}'),
    })

    # Create a dummy Display
    display = Display()
    display.debug = lambda x: None

    # Create a dummy Options
    options = DummyOpts()

    # Create a dummy Templar
    env = AnsibleEnvironment(loader, options, None, variable_start_string='{{', variable_end_string='}}')
    env.filters = {}

# Generated at 2022-06-21 06:41:38.611216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVars(object):
        def __init__(self, search_path, template_data=None):
            self.search_path = search_path
            self.template_data = template_data

    class MockLoader(object):
        def _get_file_contents(self, path):
            if path == 'search_path_0/templates/some_template.j2':
                return MockVars(search_path=['search_path_0'], template_data='{{ username }}').template_data, True

        def path_dwim_relative(self, basedir, path, depth, check=True):
            if path == 'search_path_0':
                return 'search_path_0'

    class MockAnsibleEnv(AnsibleEnvironment):
        lookup_loader = MockLoader()


# Generated at 2022-06-21 06:41:45.574205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # what is presumably a dummy lookup term
    test_term = 'test_term'

    # what is presumably a dummy template string
    test_template = '''
    test_template
    '''
    # what is presumably a dummy options dictionary
    test_options = {'defaults': {'variable_start_string': '{{', 'variable_end_string': '}}'},
                    'var_options': {'var1': '1', 'var2': '2'},
                    'direct': {'var1': '1', 'var2': '2'}}

    # what is presumably a dummy variables dictionary
    test_variables = {'test_var1': '1', 'test_var2': '2'}

    # dummy return of method find_file_in_search_path

# Generated at 2022-06-21 06:41:46.190534
# Unit test for constructor of class LookupModule
def test_LookupModule():

    LookupModule()

# Generated at 2022-06-21 06:41:48.411547
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:41:50.111464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module


# Generated at 2022-06-21 06:41:50.784188
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 06:42:01.393627
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:42:02.600422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:42:06.205110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = {'a': 1, 'b': 2}
    lookup_module = LookupModule()
    res = lookup_module.run([], variables=d)
    assert res == []
    assert lookup_module._templar.environment.variable_start_string == u'{{'
    assert lookup_module._templar.environment.variable_end_string == u'}}'

# Generated at 2022-06-21 06:42:08.259795
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a lookup plugin
    lookup = LookupModule()
    assert lookup


# Generated at 2022-06-21 06:42:39.375416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import Always
    from ansible.executor.task_queue_manager import TaskQueueManager

    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "./some_template.j2": """
            Hello {{ lookup("env", "USER") }}
        """
    })

    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 06:42:51.625458
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # dummy file for testing
    lookup_file_name = 'template_test.j2'
    lookup_file = 'templates/' + lookup_file_name

    test_value = 'template_test_value'

    b_test_value = to_bytes(test_value, errors='surrogate_or_strict')
    lookup_file_data = b_test_value + b'\n'

    # the value for the 'search path' setting doesn't matter for the test
    lookup_paths = ['/tmp']
    lookup_paths.insert(0, os.path.dirname(lookup_file))

    # use a temporary file as a lookup file

# Generated at 2022-06-21 06:42:52.763368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:43:00.518560
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:43:11.542442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    def display_message(msg, *args, **kwargs):
        print(msg % args, **kwargs)

    display.display = display_message
    lookup_module = LookupModule()
    lookup_module._templar = {}
    lookup_module._loader = {}

    lookup_module._loader._get_file_contents = lambda self, path: ('{{ host_name }}', True)
    lookup_module.set_options()
    lookup_module.set_options(var_options={'host_name': 'test_host'})

    class TestClass(object):
        def find_file_in_search_path(self, variables, dirname, filename):
            return 'test_file'

    lookup_module.find_file_in_search_path = TestClass.find_file_in_

# Generated at 2022-06-21 06:43:15.974325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_file = './test_template.j2'
    lookup_template_vars = {'test_key': 'test_value'}

    # TODO: write unit tests
    assert 1 == 1

# Generated at 2022-06-21 06:43:28.251328
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Dict where keys are terms and values are the file paths returned
    # by find_file_in_search_path
    files_dict = {}

    display = Display()
    env_class = AnsibleEnvironment

    # Mock the display
    class DisplayMock:
        def debug(self, msg):
            print(msg)

        def vvvv(self, msg):
            print(msg)

    display = DisplayMock()

    # Mock the _get_file_contents method
    class LoaderMock:
        def _get_file_contents(self, filename):
            return "{{lookup}}", True

    loader = LoaderMock()

    # Copy the variables dict
    # to avoid altering the original one
    variables = deepcopy(env_class._ansible_default_vars)

    # Mock the find

# Generated at 2022-06-21 06:43:38.201534
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Fake module parameters
    class FakeArgs(object):

        def __init__(self, lookup_plugin_name, terms, preserve_trailing_newlines=True,
                     convert_data=True, jinja2_native=True):
            self.lookup_plugin_name = lookup_plugin_name
            self.terms = terms
            self.preserve_trailing_newlines = preserve_trailing_newlines
            self.convert_data = convert_data
            self.jinja2_native = jinja2_native

    # Set parameters
    args = FakeArgs("template", ["test_template.j2"])
    variables = {}

    # Init environment for Templar class
    def _get_file_contents(self, path):
        return "{{ var }}", True
    LookupBase._loader._get_

# Generated at 2022-06-21 06:43:43.409969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a mock ansible context.
    context = {
        '_templar': None,
        '_loader': None
    }

    # Instantiate the class.
    with open('./tests/unit/plugins/lookup/test_files/random') as f:
        result = LookupModule(**context).run([f], {})
        assert result[0].strip() == '42'


# Generated at 2022-06-21 06:43:45.230357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:44:42.951561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._options == None

# Generated at 2022-06-21 06:44:49.052503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    display = Display()
    templar = LookupModule(loader=None, variable_manager=None, loader_class=None, templar=None)
    templar.set_loader(loader=None)
    templar.set_templar(templar=None)
    templar.set_variable_manager(variable_manager=None)
    terms = ['/tmp/cct', 'cct.yml']
    variables = {}
    templar.run(terms, variables)

# Generated at 2022-06-21 06:44:52.765743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_with_type(type_name):
        return type_name in test.__dict__ and isinstance(test.__dict__[type_name], type)

    assert not test_with_type('test_LookupModule'), \
        "test_with_type(type_name) should return False when type name is not in test's namespace."

    class test(object):
        pass

    assert test_with_type('test'), \
        "test_with_type(type_name) should return True when type name is in test's namespace."

# Generated at 2022-06-21 06:44:53.674232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-21 06:45:00.534386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'template_vars': {}})
    lookup.set_loader({'_get_file_contents': lambda x: (b'value={{var1}}', False)})
    lookup.set_environment(AnsibleEnvironment({}, to_text=lambda x: x, convert_data=False, loader=None))
    assert lookup.run(['test.j2'], {'var1': 'a'})[0] == 'value=a'

# Generated at 2022-06-21 06:45:01.386034
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:45:03.426361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.get_option('_terms') is None

# Generated at 2022-06-21 06:45:14.779172
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import PY3

    # setup_class, lookup_base and lookup module to be used for testing
    class TestLookupBase(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupBase, self).run(terms, variables=variables, **kwargs)

    class TestLookupModule(LookupModule):
        def run(self, terms, variables, **kwargs):
            return super(TestLookupModule, self).run(terms, variables=variables, **kwargs)

    # create lookup_base object
    lookup_base = TestLookupBase()
    lookup_base.set_options()

    # valid vars
    variables

# Generated at 2022-06-21 06:45:15.930582
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:45:20.699355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["test_template_a.j2", "test_template_b.j2"]
    variables = {"testvar": "my value", "vars": {"var2": "value2"}}
    lookup_template_vars = {"var3": "value3", "var4": "value4"}

    plugin = LookupModule()
    plugin.set_options(var_options=variables, direct={'template_vars': lookup_template_vars})

    ret = plugin.run(terms, variables, **{})

    assert ret == ["a: foo\n\n", "b: foo\n\n"]

# Generated at 2022-06-21 06:47:11.501738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the method run of class LookupModule
    # Setup:
    from ansible.module_utils._text import to_text
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import lookup_loader

    import os
    import sys
    import __builtin__

    sys.modules['__builtin__'] = __builtin__

    import ansible.module_utils.basic


# Generated at 2022-06-21 06:47:12.244069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LU = LookupModule()
    assert LU is not None

# Generated at 2022-06-21 06:47:14.316701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    print(lm.run(terms='unittest.j2', variables={'a': 'A', 'b': 'B'}))

# Generated at 2022-06-21 06:47:19.926103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Purpose: Test that 'with' statement is saved properly by the templar.
    # Need to use a different variable_start_string and variable_end_string
    # to avoid colliding with the templating variables already set in the test
    # itself.

    lookup = LookupModule()
    terms = [
        'test_LookupModule_run.j2'
    ]
    variables = {
        'test_var_1': 'Test Var 1',
        'test_var_2': 'Test Var 2',
        'test_var_3': 'Test Var 3'
    }
    result = lookup.run(terms, variables, variable_start_string='<%', variable_end_string='%>')

# Generated at 2022-06-21 06:47:28.685171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import jinja2
    # This unit test will fail if jinja2_native is not set to False.
    # jinja2_native is set to True by default, but if the version of jinja2 is not 2.10+, this is set to False later.
    # You can modify ansible.cfg to set jinja2_native=False.
    lookup = LookupModule()
    lookup.set_options(direct={'jinja2_native': False})

    assert lookup.run(["./tests/testlookup/template1.j2"],{"lookup_file_test_var":"lookup_file_test_var_value"},) == [u"foobar\n"]


# Generated at 2022-06-21 06:47:37.504182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={'jinja2_native': {'type': 'bool', 'required': False}})
    l = LookupModule(m)
    terms = [['/file/path/to/some_template.j2'], ['/file/path/to/some_template_with_vars.j2'], ['/file/path/to/some_template_with_raw_var.j2']]
    extra = {'convert_data': False, 'template_vars': {'library_version': '1.2.3', 'library_raw_var': '{{ not_a_template }}'}}

# Generated at 2022-06-21 06:47:38.540504
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    The class LookupModule needs to be tested to demo its usage.
    """
    module = LookupModule()