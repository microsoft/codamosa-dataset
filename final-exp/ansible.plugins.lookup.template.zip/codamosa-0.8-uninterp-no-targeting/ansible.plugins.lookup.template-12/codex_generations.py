

# Generated at 2022-06-21 06:37:46.345572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest

    # Create an instance of the class LookupModule
    obj = LookupModule()


# Generated at 2022-06-21 06:37:47.419932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:37:59.036984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # need to create a data loader instance to test the _get_file_contents method
    class TestDataLoader(DataLoader):
        def __init__(self):
            pass
        def _get_file_contents(self, path):
            return b"""Hello, world!\n""", None

    # set sys args to have no args and have no silent flag
    # python 2.7.9 and up would error with args supplied
    sys.argv = ['ansible-playbook']

# Generated at 2022-06-21 06:38:02.540431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['test.conf.j2'], {'var1': 'ansible', 'var2': 'awesome'})[0] == """
ansible is awesome
ansible is easy
ansible is great
"""

# Generated at 2022-06-21 06:38:09.240576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    base_vars = dict(
         ansible_search_path=['common'],
         template_hosts='hosts.j2',
         template_vars=dict(app_name='app_name_in_vars'),
         app_name='app_name_in_facts'
    )

    # Create base objects
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager())
    variable_manager.extra_vars = base_vars
    loader = DataLoader()

    # Test with jinja2

# Generated at 2022-06-21 06:38:20.538238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Loader():
        def _get_file_contents(self, lookupfile):
            return ('', '')

    class AnsibleModuleFake():
        def __init__(self):
            self.params = {}
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    fake_templar = None
    fake_loader = Loader()
    fake_inventory = None
    fake_vm = None

    fake_variables = {
        "inventory_hostname": "test"
    }

    real_LookupBase = LookupBase()
    real_LookupBase.set_loader(fake_loader)
    real_LookupBase.set_inventory(fake_inventory)
    real_LookupBase.set_templar(fake_templar)
    real_LookupBase

# Generated at 2022-06-21 06:38:29.500957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    test_result = test_lookup.run(terms=['file1'],variables={})
    test_result_2 = test_lookup.run(terms=['file1', 'file2'],variables={})
    test_result_3 = test_lookup.run(terms=['file1', 'file2'],variables={}, convert_data=False)
    assert test_result == ['content of file1']
    assert test_result_2 == ['content of file1', 'content of file2']
    assert test_result_3 == ['content of file1', 'content of file2']

# Generated at 2022-06-21 06:38:41.217132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    v = dict()

    fake_file = '__fake_file'
    r = lu._loader._get_file_contents(fake_file)
    assert r[1] == fake_file
    b_data = r[0]
    assert isinstance(b_data, bytes)

    r = lu._loader._get_file_contents('')
    assert r[1] == ''
    b_data = r[0]
    assert isinstance(b_data, bytes)

    # method run
    terms = [fake_file]
    r = lu.run(terms, v)
    assert isinstance(r, list)
    assert isinstance(r[0], str)

# Generated at 2022-06-21 06:38:53.472283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import shutil
    import yaml
    import tempfile
    import json
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    print(lookup_loader.get("template"))
    print(loader._get_basedir("localhost"))

# Generated at 2022-06-21 06:38:54.500425
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:39:04.610036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    out = LookupModule()
    print(type(out))
    print(out.run(terms='some_template.j2', variables={'test': '1'}))
    """

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:39:10.704180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    import sys
    import os


    # prepare callback
    logfile = 'unit.test.log'

    class TestCallback(CallbackBase):
        CALLBACK_VERSION = 2.0

        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.logfile = open(logfile, 'w', encoding='utf-8')

        def v2_playbook_on_play_start(self, play):
            name = play.get_name().strip()


# Generated at 2022-06-21 06:39:12.831302
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ test_LookupModule: construct an instance of LookupModule """
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:39:24.118165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test basic lookup module
    module = LookupModule()
    # Test valid file
    terms = ['test.j2']
    kwargs = {
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'comment_start_string': '/*',
        'comment_end_string': '*/'
    }
    variables = {
        "var1": "value1",
        "var2": "value2"
    }
    data = module.run(terms, variables, **kwargs)
    assert len(data) == 1
    assert data[0] == "1\n10\n100\n"

    # Test invalid file
    # Invalid file lookup

# Generated at 2022-06-21 06:39:25.322642
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: implement
    pass


# Generated at 2022-06-21 06:39:27.912215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # FIXME TODO
    # test setup stuff
    # test lookup(self, terms, variables=None, **kwargs):
    assert False


# Generated at 2022-06-21 06:39:29.146769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module



# Generated at 2022-06-21 06:39:35.376743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a dummy ansible template file
    import tempfile
    (fd, dummy_ansible_template_file) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('TEST {{ ansible_variable }} \n')

    # Create a dummy lookup_file
    (fd, lookup_file) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('---\n')
        f.write('template_to_be_looked_up: ' + dummy_ansible_template_file + '\n')

    # Execute run method
    lm = LookupModule()
    lm._templar = AnsibleEnvironment()

# Generated at 2022-06-21 06:39:47.776941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    env = dict(
        usr='root',
        pwd='toor'
    )


# Generated at 2022-06-21 06:39:52.379250
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an instance of class LookupModule
    lookup_module = LookupModule(None, {}, None, None, None)
    # test __init function
    assert lookup_module is not None

# Generated at 2022-06-21 06:39:58.161354
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-21 06:40:02.565544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # class definition test
    lookup_plugin = LookupModule()

    # options test
    lookup_plugin.template_vars = {'foo': 'bar'}
    assert lookup_plugin.get_option('convert_data') == None
    assert lookup_plugin.get_option('jinja2_native') == None

# Generated at 2022-06-21 06:40:13.717844
# Unit test for constructor of class LookupModule
def test_LookupModule():

    display = Display()

    import set_loader
    import data_loader
    import path_finder
    import module_loader
    import template_vars
    import connection_loader

    # Create the modules
    set_loader_obj = set_loader.SetLoader()
    data_loader_obj = data_loader.DataLoader()
    path_finder_obj = path_finder.PathFinder()
    module_loader_obj = module_loader.ModuleLoader()
    connection_loader_obj = connection_loader.ConnectionLoader()

    # Create the template variables
    template_vars_obj = template_vars.VarsModule()

    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar_obj = Templar(loader=data_loader_obj, variables=VariableManager())

    lookup_obj = Look

# Generated at 2022-06-21 06:40:14.078709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:40:15.120915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:40:16.448503
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 06:40:28.539696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lm = LookupModule()

    # Create the terms input
    terms = ["./lookup_plugins/tests/templates/test1.j2", "./lookup_plugins/tests/templates/test2.j2"]

    # Create the variables input
    variables = {}
    variables["test_variable"] = "test"
    variables["test_variable2"] = False

    # Create the options

# Generated at 2022-06-21 06:40:30.651056
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the module constructor
    lm = LookupModule()
    assert isinstance(lm, LookupBase)



# Generated at 2022-06-21 06:40:32.294595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check initialization
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:40:43.700113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Check if method run of class LookupModule works correctly
    """

    from ansible.plugins.lookup.template import LookupModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import generate_ansible_template_vars
    from ansible.utils.display import Display
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.utils.vars import combine_vars

    display = Display()

# Generated at 2022-06-21 06:40:57.955430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.verbosity = 4

    # return type of LookupModule.run is list
    ret = LookupModule().run(terms=[""], variables={})
    assert isinstance(ret, list)

# Generated at 2022-06-21 06:41:01.905082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def __init__(self, *args, **kwargs):
        pass

    # set these to avoid errors
    __init__._loader = object()
    __init__._templar = object()

    lookup_module = LookupModule(__init__)
    assert lookup_module.run

# Generated at 2022-06-21 06:41:13.666426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # Vault secret 'my_secret' is: 'hello world'
    vault = VaultLib([])
    vault_secret = vault.encrypt('my_secret', b"hello world")
    variables = ImmutableDict({
        "vaulted_var": vault_secret,
        "myvar": "myvalue",
        "empty_var": None,
    })
    templar = Templar(loader=None, variables=variables)
    lookup = LookupModule(templar=templar, loader=None, templar_enable_legacy=False)
    lookup.set_loader(loader=None)

    # test default variables
    args

# Generated at 2022-06-21 06:41:20.696352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unit.plugins.lookup_plugins.file_common import TestLookupBase

    lookup = LookupModule()
    lookup.set_loader(TestLookupBase.get_fake_loader())
    template_path = os.path.join(lookup._loader._basedir, 'templates', 'test.j2')

    fd = open(template_path, 'w')
    fd.write('{% if blah %}blah{% else %}blas{% endif %}\n')
    fd.close()

    variables = {
        'blah': False,
        'ansible_env': {
            'HOME': '/',
            'PWD': '/foo',
        },
    }

    result = lookup.run([template_path], variables)
    assert result == ['blas\n']


# Generated at 2022-06-21 06:41:32.355229
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with vars
    terms = './{{ hello }}'
    variables = dict(hello="world", loc=22)
    lookup = LookupModule()
    ref = lookup._templar.template(terms, variables)
    assert ref == "./world"

    # test with vars
    terms = './{{ hello }}/{{ world }}'
    variables = dict(hello="world", world="hello", loc=22)
    lookup = LookupModule()
    ref = lookup._templar.template(terms, variables)
    assert ref == "./world/hello"

    # test conversion
    terms = ['/{{ hello }}/{{ world }}', '/{{ loc }}/{{ world }}']
    variables = dict(hello="world", world="hello", loc=22)
    lookup = LookupModule()

# Generated at 2022-06-21 06:41:32.951897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:41:39.161146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Function to test execution of run() method of LookupModule class
    """
    lookup_module_test = LookupModule()
    lookup_module_test.set_options()
    terms_test = ["./some_template.j2"]
    variables_test = {"ansible_search_path": "/home/user/ansible/templates"}
    lookup_module_test.run(terms_test, variables_test)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:41:45.880055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.errors import AnsibleError

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.env = None
            self.result = None
            self.fail_json = None

    class TestTemplar(object):
        def __init__(self, environment=None):
            self.environment = environment
            self.block_list = None
            self.available_variables = None
            self.template_data = None
            self.template_uid = None

        def set_available_variables(self, variables):
            self.available_variables = variables

        def set_environment(self, environment):
            self.environment = environment



# Generated at 2022-06-21 06:41:56.912080
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the API and implementation of the __init__ function.
    #
    # Create a class to test the LookupModule constructor.
    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            # Call the LookupModule constructor.
            super(TestLookupModule, self).__init__(loader=loader, templar=templar, **kwargs)

    # Invoke the constructor.
    #
    # The arguments are not actually used.
    test_object = TestLookupModule(
        loader=None,
        templar=None,
        # Dummy argument.
        test_argument='foo')

    # Test that the constructor sets the arguments correctly.

# Generated at 2022-06-21 06:42:06.093884
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupModule = LookupModule()

    # Return the content of file
    #-----------------------------------------------------
    assert lookupModule.run(['simple.txt'], dict()) == ['{{string}}\n']

    # Return the content of file
    #-----------------------------------------------------
    assert lookupModule.run(['simple.txt'], dict(),comment_start_string='<#', comment_end_string='#>') == ['<# This is a comment #>\n{{string}}\n']

    # Return the content of file
    #-----------------------------------------------------
    assert lookupModule.run(['simple.txt'], dict(),variable_start_string='[[', variable_end_string=']]') == ['[[string]]\n']

    # Return the content of file
    #-----------------------------------------------------

# Generated at 2022-06-21 06:42:36.042356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #args = [['lookup_file.yml']]
    args = ['lookup_file.yml']
    terms = args[:]
    variables = {'current_host': 'foreman.company.com', 'inventory_hostname': 'foreman.company.com', 'inventory_hostname_short': 'foreman'}
    kwargs = {'convert_data': True, 'template_vars': {}, 'variable_start_string': '{{', 'variable_end_string': '}}', 'jinja2_native': True}

    lookup_obj = LookupModule()
    #lookup_obj.run(terms, variables)
    result = lookup_obj.run(terms, variables)
    print(result)

# Generated at 2022-06-21 06:42:42.247234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import jinja2
        has_jinja2 = True
    except ImportError:
        has_jinja2 = False
    if not has_jinja2:
        return
    try:
        import __main__
        __main__.display = Display()
        __main__.display.verbosity = 3
    except ImportError:
        pass

    lookup_module = LookupModule()

    # Test terms normalization
    terms = ['', 'foo', 'foo.j2']
    assert lookup_module._get_terms(terms) == terms

# Generated at 2022-06-21 06:42:44.486522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """it must return True when LookupModule is instantiated with all correct params."""
    assert LookupModule()

# Generated at 2022-06-21 06:42:47.373208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This test case should pass in order to make sure that the constructor of class LookupModule can be called.
    """

    lookup_module = LookupModule()
    print("test_LookupModule has been passed!")

# Generated at 2022-06-21 06:42:49.143713
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    result = module.run(["test.txt"], {})
    print(result)
    assert len(result) == 0

# Generated at 2022-06-21 06:42:50.115336
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()


# Generated at 2022-06-21 06:42:59.576153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # SETUP
    import unittest
    import sys
    import os
    import tempfile
    import shutil
    import filecmp
    import ansible.plugins.lookup
    import ansible.plugins.loader
    import ansible.vars.manager
    import ansible.template
    import ansible.module_utils.six

    class TestConfig:
        def __init__(self):
            self.DEFAULT_VERBOSITY = 0
            self.DEFAULT_DEBUG = False
            self.DEFAULT_KEEP_REMOTE_FILES = False
            self.DEFAULT_HOST_KEY_CHECKING = False
            self.DEFAULT_HOST_KEY_CHECKING = False
            self.DEFAULT_SUDO = False
            self.DEFAULT_SUDO_EXE = None
            self.DE

# Generated at 2022-06-21 06:43:10.752620
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = {
        '_terms': './some_template.j2',
        'convert_data': True,
        'variable_start_string': '{',
        'variable_end_string': '}',
        'jinja2_native': False,
        'template_vars': {},
        'comment_start_string': '#',
        'comment_end_string': '#'
    }

    lookup_instance = LookupModule()
    ansible_options = {
        '_attributes': {
            'lookup_options': options
        }
    }
    lookup_instance.set_options(ansible_options)
    jinja2_native = lookup_instance.get_option('jinja2_native')
    assert jinja2_native == False


# Generated at 2022-06-21 06:43:22.561728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    A negative test
    """
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Initialize the arguments needed to call the run() method of class LookupModule
    terms = [
        './some_template.j2'
    ]
    variables = None
    kwargs = dict()

    # Call the run() method
    try:
        returned_value = lookup_module.run(terms, variables, **kwargs)
    except AnsibleError as exception_instance:
        # pylint: disable=unused-variable
        exception_message = exception_instance.message

    assert exception_message == "the template file ./some_template.j2 could not be found for the lookup"


# Generated at 2022-06-21 06:43:26.244028
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', elements='path'),
            convert_data=dict(type='bool', default=False),
            variable_start_string=dict(type='str', default='{{'),
            variable_end_string=dict(type='str', default='}}'),
            jinja2_native=dict(type='bool', default=USE_JINJA2_NATIVE),
            template_vars=dict(type='dict', default={}),
            comment_start_string=dict(type='str', default='/*'),
            comment_end_string=dict(type='str', default='*/')
        )
    )
    if not HAS_JINJA2:
        module.fail_json(msg='jinja2 is not installed')
    lookup

# Generated at 2022-06-21 06:44:20.669108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar()
    lookup_module._loader = FakeLoader()
    assert lookup_module.run(terms=['/the/template/file.j2'], variables={}, jinja2_native=False, convert_data=True) == ['the content of the template file with YAML data converted']
    assert lookup_module.run(terms=['/the/template/file.j2'], variables={}, jinja2_native=True, convert_data=True) == ['the content of the template file with YAML data converted']

# Generated at 2022-06-21 06:44:33.017119
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:44:33.797624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:44:34.195324
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:44:39.808742
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    terms = ['/Foo/Bar.j2']
    variables = dict()
    kwargs = dict()

    convert_data = True
    lookup_template_vars = dict()
    jinja2_native = False
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_end_string = '#}'

    module_return_values = ['content']

    # Make sure that the module runs with no exceptions

# Generated at 2022-06-21 06:44:40.578017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:44:50.293883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupModule(LookupModule):
        def find_file_in_search_path(self, variables, subdir, filename):
            return filename

    lookup = MockLookupModule()
    # All options are set to default values
    options = dict(
        convert_data=False,
        variable_start_string='{{',
        variable_end_string='}}',
        jinja2_native=False,
        template_vars={},
        comment_start_string='{#',
        comment_end_string='#}',
    )
    result = lookup.run(['./some_template.j2'], dict(), **options)
    assert result[0] == './some_template.j2'

    result = lookup.run(['../some_template.j2'], dict(), **options)
   

# Generated at 2022-06-21 06:44:54.529695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run([], {}, **{'plugin_args': '', '_original_file': '', '_original_path': '', 'is_playbook': False})

# Generated at 2022-06-21 06:45:04.699891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.utils.display.Display.verbosity = 4
    # os.environ['ANSIBLE_VERBOSITY'] = '4'

    # Given
    terms = '''
    test
    test2
    '''
    lookup_template_vars = {
        'test': 'this is a test'
    }
    jinja2_native = False
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '[[['
    comment_end_string = ']]]'

# Generated at 2022-06-21 06:45:15.929726
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # global
    global_variable = {
        'template_vars': {},
        'convert_data': True,
        'jinja2_native': False
    }
    global_variable['convert_data'] = True
    global_variable['jinja2_native'] = False


    # templar
    class Klass():
        def _do_template(self, data, preserve_trailing_newlines=False, escape_backslashes=False, convert_data=False, **kwargs):
            return data
        def copy_with_new_env(self, environment_class=AnsibleEnvironment):
            return Klass()
        def template(self, data, preserve_trailing_newlines=False, escape_backslashes=False, convert_data=False, **kwargs):
            return data
    tem

# Generated at 2022-06-21 06:46:50.159734
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    module = LookupModule()
    assert hasattr(module, '_templar')


# Generated at 2022-06-21 06:46:54.230825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vault_password = "vault.test"
    vault = VaultLib(vault_password)
    templar = Templar(loader=None, variables={}, vault_secrets=[vault])
    lookup = LookupModule(loader=None, templar=templar, vault=vault)

    # should not raise an exception if vault is passed in
    assert lookup is not None

# Generated at 2022-06-21 06:46:55.856983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert os.environ.get("ANSIBLE_DISPLAY_ARGS_TO_STDOUT") == "1"


# Generated at 2022-06-21 06:46:57.214760
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib

    mod = LookupModule()
    assert mod is not None

# Generated at 2022-06-21 06:47:03.798842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test data
    templar = None
    # No setup required
    test_object = LookupModule()

    # Setup expected result
    expected_result = []

    # Perform the test
    test_result = test_object.run('terms', 'variables', templar)
    print(test_result)
    print(expected_result)
    assert test_result == expected_result

# Generated at 2022-06-21 06:47:11.699464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert lu.run(terms=['test.j2'], variables={}, convert_data=True) == \
           [to_bytes('# Jinja2 template\n\n', encoding='utf-8')]
    # Test optional variables
    assert lu.run(terms=['test.j2'], variables={}, convert_data=True, template_vars={'foo': 'bar'}, jinja2_native=True) == \
           [to_bytes('# Jinja2 template\n\n', encoding='utf-8')]

# Generated at 2022-06-21 06:47:18.367244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar


# Generated at 2022-06-21 06:47:23.703888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import LookupModule

    l = LookupModule()
    terms = ['templates/template.j2']
    variables = {'ansible_search_path': ['/some/path'], 'template_path': '/some/path', 'template_mtime': '123'}
    l.run(terms=terms, variables=variables)

# Generated at 2022-06-21 06:47:32.460188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup:
    # AnsibleError is raised when template file cannot be found
    #
    # Test steps:
    # 1. Test whether AnsibleError is raised when template file cannot be found
    # Test teardown:
    # -

    test_variables = {'templates': 'path'}
    test_terms = ['not_found.j2']
    test_direct = {}
    test_obj = LookupModule()
    test_obj.set_options(var_options=test_variables, direct=test_direct)

    try:
        test_obj.run(test_terms, test_variables, **test_direct)
        assert False, "AnsibleError was not raised"
    except AnsibleError:
        assert True, "AnsibleError was raised"

# Generated at 2022-06-21 06:47:33.412093
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert ansible.plugins.lookup.template.LookupModule()