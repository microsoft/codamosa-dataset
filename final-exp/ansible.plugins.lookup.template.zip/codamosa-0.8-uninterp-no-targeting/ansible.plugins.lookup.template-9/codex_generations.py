

# Generated at 2022-06-21 06:37:48.468054
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1
    terms = ['test.j2']
    variables = {}
    kwargs = {'variable_start_string': '{{', 'variable_end_string': '}}'}
    l = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        l.run(terms, variables, **kwargs)

# Generated at 2022-06-21 06:37:59.783226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test with one term
    terms = [
        './some_template.j2',
    ]
    variables = dict()
    convert_data_p = None
    lookup_template_vars = dict()
    jinja2_native = None
    variable_start_string = None
    variable_end_string = None
    comment_start_string = None
    comment_end_string = None
    lookup = LookupModule(loader=None, templar=None, variables=variables)

# Generated at 2022-06-21 06:38:06.285789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the case where there are no left over vars
    m = LookupModule()
    assert m.run(['./some_template.j2'], dict()) == []
    assert m.run(['./some_template.j2'], dict(template_var_key='template_var_value')) == []

    # Test the case where there is a left over var
    test_file_contents = '{{foo}}'
    m = LookupModule()
    assert m.run(['./some_template.j2'], dict(foo='foo_value')) == [test_file_contents]

# Generated at 2022-06-21 06:38:09.956978
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        lu = LookupModule()
    except:
        pass
    else:
        assert False, " should throw an exception"

# Generated at 2022-06-21 06:38:10.970811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:38:22.886324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.verbosity = 4
    import ansible
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.template
    import ansible.template.template
    import ansible.vars.manager
    import ansible.utils.vars.module_loading
    import ansible.utils.vars.mapping
    import ansible.utils.unsafe_proxy

    class AnsibleTemplate:
        class AnsibleEnvironment:
            def __init__(self, variable_start_string, variable_end_string,
                         trim_blocks, lstrip_blocks, keep_trailing_newline):
                self.variable_start_string = variable_start_string
                self.variable_end_string = variable_end_string
                self.trim_blocks = trim_blocks

# Generated at 2022-06-21 06:38:32.242557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.display("Unit test for method run of class LookupModule")

    lookupModule = LookupModule()
    lookupModule._display = display
    lookupModule._templar.environment.globals['ansible_search_path'] = ['.']
    lookupModule._loader.path_dwim_relative = False

    print("Test1: test when the path is ".format(path))
    print("test when the path is not exist".format(path))
    print("test when the path is directory")
    print("test when the path is a file")
    print("test when the path is a file with no ansible dir")
    print("test when the path is a file with ansible dir")
    print("test when the path is a file with no file")

# Generated at 2022-06-21 06:38:43.445096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory import Inventory

    data_loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(data_loader, variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=data_loader, variables=variable_manager)

    term = './plugins/lookup/template_test.j2'
    terms = [term]
    template_vars = {'a': 123, 'b': 456}
    variables = {'template_vars': template_vars, 'a': 789}

# Generated at 2022-06-21 06:38:55.232353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json


# Generated at 2022-06-21 06:38:56.603922
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'


# Generated at 2022-06-21 06:39:11.164253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test whether the parameters are correctly determined
    lookup_module = LookupModule()
    # set variables
    test_terms = ["../../test_templates/test_template_01.j2", "../../test_templates/test_template_02.j2"]
    lookup_module._display = Display()
    lookup_module.set_options(direct={'_original_file': '/test/test_ansible_module.py'})
    # test whether the parameters are correctly determined

# Generated at 2022-06-21 06:39:13.995144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    args = {
        '_templar': MockTemplar(),
        '_loader': MockLoader()
    }
    lookup_module = LookupModule(**args)
    assert lookup_module


# Generated at 2022-06-21 06:39:25.789128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.template
    import jinja2.exceptions
    import yaml
    import os
    import sys

    # Note: Cannot set USE_JINJA2_NATIVE in the ansible.cfg file as it
    # prevents the regular Jinja2 template processing to be tested

    # -------------------------------------------------------------------
    # Test with jinja2_native=False (default)
    # -------------------------------------------------------------------

    # Initialize test environment

    # Jinja2 search path is not an empty list
    jinja2_search_path = ['./my_templates']

    # dict of lookup variables
    lookup_vars = {'template_version': 1,
                   'my_var': 'my_value'}

    # dict of plugin options

# Generated at 2022-06-21 06:39:29.155969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def fake_file_read(self, file_name, cache=True, expand=True, *args, **kwargs):
        return to_bytes("{{ foo }}{{ bar }}"), False

    PrefixLookup = None
    setattr(PrefixLookup, '_get_file_contents', fake_file_read)
    PrefixLookup.list_basedir = []

    test_class = LookupModule()
    test_class.set_loader(PrefixLookup())
    actual_result = test_class.run(terms=["test.j2"], variables={"foo": "foo", "bar": "bar"})
    assert actual_result == ["foobar"]

# Generated at 2022-06-21 06:39:32.251916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  class TestLookupModule(LookupModule):
    def __init__(self):
      super().__init__()

  obj = TestLookupModule()
  assert obj.run([], {}, direct = {}) == []

# Generated at 2022-06-21 06:39:45.230558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import sys
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a data loader
    loader = DataLoader()

    src_dir = os.path.dirname(__file__)
    if src_dir == "":
        src_dir = "."

    # Create a lookup module
    lookup_mod = lookup_loader.get("template", loader=loader, variable_manager=variable_manager)

   

# Generated at 2022-06-21 06:39:45.866948
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:39:53.077147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from unittest.mock import MagicMock
    from ansible.errors import AnsibleError

    class MockTemplar(object):
        def copy_with_new_env(self, environment_class):
            return MockTemplar()

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables, searchpath):
            assert variable_start_string == '{{'
            assert variable_end_string == '}}'
            assert comment_start_string == '{#'
            assert comment_end_string == '#}'
            assert available_variables == {}
            assert searchpath == ['/foo/bar', '/bar/foo']
            return MagicMock()


# Generated at 2022-06-21 06:39:55.160074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global display
    display = Display()
    ds = LookupModule()

# Generated at 2022-06-21 06:40:06.321001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.plugins.loader import lookup_loader

    def test(terms, variables, kwargs, expected):
        lookup = lookup_loader.get('template')
        if PY3:
            expected = expected.encode('ascii')
        else:
            expected = cStringIO(expected).read()
        assert lookup.run(terms, variables, **kwargs) == [expected]

    # mock _templar to use template_data instead of reading terms
    lookup_loader.get('template')._templar = MockTemplar()


# Generated at 2022-06-21 06:40:21.178812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    with pytest.raises(TypeError) as excinfo:
        LookupModule()
    assert 'missing 1 required positional argument' in str(excinfo.value)
    assert 'takes at least 2 arguments' in str(excinfo.value)


# Generated at 2022-06-21 06:40:31.850252
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup test data
    lookup_module = LookupModule()
    lookup_module._templar = '_templar'
    lookup_module._loader = '_loader'
    lookup_module.set_options = 'set_options'
    lookup_module.get_option = 'get_option'
    lookup_module.find_file_in_search_path = 'find_file_in_search_path'
    lookup_module._loader._get_file_contents = '_get_file_contents'
    lookup_module._loader._get_file_contents.return_value = ['b_template_data', 'show_data']
    lookup_module._templar.copy_with_new_env = 'copy_with_new_env'

# Generated at 2022-06-21 06:40:32.388129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

# Generated at 2022-06-21 06:40:38.594540
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    # try 'template' lookup
    lookup = lookup_loader.get('template')

    # create mock_obj for templar
    class mock_templar(object):
        def __init__(self):
            return

        def template(self, template_data, preserve_trailing_newlines=True,
                     convert_data=True, escape_backslashes=False):
            return template_data + '_templared'

    # create mock_obj for loader
    class mock_loader(object):
        def get_basedir(self, *args):
            return "tests/test_lookup"

        def path_dwim(self, *args):
            return "tests/test_lookup/" + args[0]


# Generated at 2022-06-21 06:40:50.000802
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule object
    lm = LookupModule()

    # Simulate the templates search path
    fake_search_path = [
        'roles/common/tasks/main.yml',
        'roles/common/tasks/template.j2'
    ]
    # Set the value of paths in the object of the class LookupBase
    lm.searchpaths = fake_search_path
    # Set the value of loader in the object of the class LookupBase
    lm._loader = AnsibleLoader(paths=fake_search_path)

    # Test for the case where the file does exist
    # Set the value of _templar in the object of the class LookupModule
    lm._templar = AnsibleTemplate(basedir=None)
    # Get the actual result of run by using

# Generated at 2022-06-21 06:40:51.641934
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert isinstance(cls, LookupModule)

# Generated at 2022-06-21 06:40:58.008204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init vars
    terms = ["res.j2"]
    variables = {
        "var": "value"
    }
    # Create object
    template = LookupModule()

    # Run method
    result = template.run(terms, variables)

    # Check
    assert result



# Generated at 2022-06-21 06:40:59.052093
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 06:41:01.752082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(None, ['/etc/passwd'], {'template_vars':{},
                                             'ansible_search_path':['.']})

# Generated at 2022-06-21 06:41:04.524733
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(var_options={})
    lookup.run(terms=['/path/to/file'], variables={})

# Generated at 2022-06-21 06:41:35.322223
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    import os.path
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule()

    # create a mock variables
    variables = dict(
        hostvars=dict(
            test_host=dict(
                ansible_host='127.0.0.1',
                ansible_port=2222,
            )
        )
    )

    # create a templar for using environment variable of template module
    templar = Templar(loader=DataLoader())

    # create a mock templar for using environment variable of template module
    class ActionModuleMock:
        _templar = templar

    # generate environment variable for template module with given action module mock
    lookup._templar._available_variables = templar

# Generated at 2022-06-21 06:41:43.685690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    
    # Set up the instance, simulating the playbook calling it
    # Remove the first argument, since that is the lookup name
    lookup_module.set_options(
        var_options = dict(
            ansible_search_path = ['.', './templates']
            ),
        direct = dict(
            template_vars = dict(
                    string_to_insert = 'INSERTED STRING'
                ),
            variable_start_string = '[%',
            variable_end_string = '%]',
            comment_start_string = '[#',
            comment_end_string = '#]'
            )
        )
    
    # Create the templar object

# Generated at 2022-06-21 06:41:55.758715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import PY3

    lookup = lookup_loader.get('template')

    # No such file
    assert lookup.run(["./lookup_plugin/templates/fake.j2"], variables=dict(), **dict()) == []

    # Template without comment
    result = lookup.run(["./lookup_plugin/templates/template_without_comment.j2"], variables=dict(), **dict())
    assert result[0] == u"This is a template\n"

    # Template with multilines

# Generated at 2022-06-21 06:42:05.258800
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:42:07.104802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-21 06:42:09.128672
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        l = LookupModule()
    except Exception as e:
        print(e)

# Generated at 2022-06-21 06:42:17.623221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global display
    # Mock display as otherwise display.debug is called (and fails)
    display = type('Display', (object,), {'debug':lambda *args, **kwargs: None})
    global USE_JINJA2_NATIVE
    USE_JINJA2_NATIVE = False
    # Mock _get_file_contents as _loader.get_basedir will fail
    global _loader
    _loader = type('_loader', (object,), {'_get_file_contents':lambda *args, **kwargs: ("{{ 1 + 1 }}", True)})
    # Mock find_file_in_search_path as jinja_templar is needed, which fails if no search_path is there
    global find_file_in_search_path

# Generated at 2022-06-21 06:42:22.854935
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mock_templar = MagicMock()
    mock_loader = MagicMock()

    lookup = LookupModule(loader=mock_loader, templar=mock_templar, basedir='.')

    assert lookup._templar == mock_templar
    assert lookup._loader == mock_loader

# Generated at 2022-06-21 06:42:26.806007
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import __main__
    __main__.display = Display()

    lookup_module = LookupModule()

    # run assertions

    # assert isinstance(lookup_module, LookupBase)
    # assert lookup_module.run([], {}) == []

# Generated at 2022-06-21 06:42:37.545135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os
    import tempfile
    import json

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play_source = dict(
            name = "Test Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='template', args=dict(src='foobar.j2'))),
                ]
            )

# Generated at 2022-06-21 06:43:28.682725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    ###################################################################################################################
    # Test data for scenario where Jinja2 native types are in use
    ###################################################################################################################

# Generated at 2022-06-21 06:43:35.501420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string_template = 'Hello, {{item}}!'
    dict_template_vars = {'item': 'World'}
    lookup_template_vars = dict_template_vars
    lookup_module = LookupModule()
    result, none = lookup_module.run([string_template], lookup_template_vars)
    expected_result = ['Hello, World!']
    assert result == expected_result

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:43:38.097286
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.get_option('comment_start_string') == None


# Generated at 2022-06-21 06:43:48.741863
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1: the term is a file
    # Create a LookupModule instance
    # assert that the plugin_name attribute is correct
    lookup = LookupModule()
    assert lookup.plugin_name == "template"

    # _templar is not a public attribute, we need to use a set_templar function to set it
    from ansible.template import Templar

    # Create a Templar instance
    templar_instance = Templar(loader=None, variables=None)

    # Set the _templar attribute with set_templar function
    lookup.set_templar(templar_instance)

    # Create a mock variables with a search_path attribute
    # The search_path attribute has a value of a list that contains a path

# Generated at 2022-06-21 06:43:51.112978
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    data = module.run(["templates/test.j2"], {"key1": "value1"})
    assert data[0] == "key1: value1"

# Generated at 2022-06-21 06:43:57.571426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options(object):
        connection = None
        module_path = None
        forks = 100
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None

    lookup_plugins = []

    options = Options()

    loader = DataLoader()
    passwords = dict(vault_pass='secret')

    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-21 06:44:08.392243
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create lookup_module instance to retrieve contents of test_file contents
    lookup_instance = LookupModule()

    # Set the variable ansible_search_path to the current user's home directory
    # which will be used to search for test_file
    variables = {u'ansible_search_path': [u'.']}

    # Create list of terms/files which need to be templated
    terms = [u'test_file']

    # kwargs is an empty dictionary
    kwargs = {}

    # Retrieve template from test_file and save it into a string
    template_as_string = lookup_instance.run(terms, variables, **kwargs)[0]

    # Create a new list to store each individual line of the test_file (after templating).

# Generated at 2022-06-21 06:44:10.125621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l



# Generated at 2022-06-21 06:44:12.140954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing LookupModule')
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:44:19.850718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['test.j2']
    vars = {'test': 'value1'}

    # Define the test class and method to mock
    class TestLookupModule_run():
        def find_file_in_search_path(self, variables, subdir, term):
            self.called_with_variables = variables
            self.called_with_subdir = subdir
            self.called_with_term = term
            return 'test.j2'

        def _get_file_contents(self, lookupfile):
            self.called_with_lookupfile = lookupfile
            return b'{{ test }}', True

    t = TestLookupModule_run()
    l = LookupModule(t)

    res = l.run(terms, vars)
    assert res == ['value1']

    # Check

# Generated at 2022-06-21 06:45:56.910704
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:45:58.386782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup is not None


# Generated at 2022-06-21 06:46:09.853132
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_look = LookupModule()

    # test terms
    terms = [
        './tests/lookup_plugins/test_template.j2',
        './tests/lookup_plugins/test_template.yaml.j2',
        './tests/lookup_plugins/test_template.yml.j2',
        './tests/lookup_plugins/test_template.json.j2',
    ]

    # test context
    context = {
        'my_name': 'bob',
        'my_dict': {
            'foo': 'bar'
        },
        'my_list': [
            {'name': 'John'},
            {'name': 'Julie'}
        ]
    }

    # LookupModule.run(self, terms, variables, **kwargs)
    #

# Generated at 2022-06-21 06:46:18.823858
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()
    lm._templar = None
    lm._loader = None

    # test with file exists
    lm._loader = {
        '_get_file_contents': lambda x: (to_bytes('value', 'utf-8'), False),
        'path_dwim': lambda x, y: '/path/to/file',
        'is_directory': lambda x: False
    }

    assert lm.run(['file'], dict()) == ['value']

    # test with dir exists
    lm._loader = {
        '_get_file_contents': None,
        'path_dwim': lambda x, y: '/path/to/file',
        'is_directory': lambda x: True
    }

    assert lm.run(['file'], dict())

# Generated at 2022-06-21 06:46:28.127119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        test = LookupModule()
        test.set_environment(
                variable_manager = MagicMock(),
                loader = MagicMock(),
                templar = MagicMock()
            )
        lookup_file = MagicMock()
        lookup_file.read.return_value = "Hello {{lookup_value}}"

        def find_file_in_search_path(variables, search_path, filename):
            return lookup_file

        test.find_file_in_search_path = find_file_in_search_path
        test_variables = {"lookup_value": "world"}
        test_args = []
        test_kwargs = {}
        expected_result = ["Hello world"]

        result = test.run(test_args, test_variables, test_kwargs)


# Generated at 2022-06-21 06:46:36.837897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    t = tempfile.NamedTemporaryFile(delete=False)
    fp = open(t.name, 'wb')
    fp.write(to_bytes('Hello', encoding='utf-8'))
    fp.close()

    l = LookupModule()
    l.set_options(direct={'_terms': [t.name]})
    results = l.run()
    os.unlink(t.name)
    assert(results == [u'Hello'])

# Generated at 2022-06-21 06:46:42.814265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    terms = [ './some_template.j2' ]
    variables = { 'ansible_search_path': [ './ansible/plugins/lookup' ] }
    kwargs = { '_terms': [ './some_template.j2' ], 'convert_data': False, 'template_vars': {}, '_original_file': './some_template.j2' }
    lookup = LookupModule()
    lookup.set_options(var_options=variables, direct=kwargs)

    # Test run
    result = lookup.run(terms, variables, **kwargs)
    # Test assert
    assert type(result) is list


# Generated at 2022-06-21 06:46:51.640774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.verbosity = 4
    lookup = LookupModule()
    test_template = """{{ ansible_play_hosts }}"""
    var_options = {'hostvars': {'hostname': 'hostname'}, 'group_names': [], 'groups': {'all': [], 'ungrouped': []}, 'parsed': True, 'playbook_dir': '/home/testuser/ansible'}
    terms = ['test_template']

    test_result = lookup.run(terms, var_options)
    correct_result = [u'hostname']
    assert test_result == correct_result

# Generated at 2022-06-21 06:47:01.775391
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term = 'test/fixtures/templates/test_jinja2.j2'
    terms = [term]

    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '/*'
    comment_end_string = '*/'

    variable_start_string1 = '/*{'
    variable_end_string1 = '}*/'
    comment_start_string1 = '/*'
    comment_end_string1 = '*/'

    lm = LookupModule()
    variables = {'templater': 'Jinja2', 'ansible_search_path': ['.']}

# Generated at 2022-06-21 06:47:04.762035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test using an extension that is not one of the valid_exts values in
    # the templar class. This should not raise an exception.
    LookupModule('filefail.xxx')