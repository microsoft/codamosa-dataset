

# Generated at 2022-06-21 06:37:57.149261
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create mock loader object
    class Loader(object):
        def __init__(self):
            pass
        def _get_file_contents(self, path):
            return open(path, 'rb').read(), 'dummy'
    loader = Loader()

    # create mock templar object
    class Templar(object):
        def __init__(self):
            pass
        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, searchpath, available_variables):
            return None
        def template(self, template_data, preserve_trailing_newlines, convert_data, escape_backslashes):
            return template_data
    templar = Templar()

    # create mock variables object

# Generated at 2022-06-21 06:38:06.146550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import copy

    lookup_plugin = LookupModule()
    lookup_plugin.set_options({'_ansible_remote_tmp': '/tmp',
                               '_ansible_check_mode': False,
                               '_ansible_debug': True,
                               '_ansible_keep_remote_files': False,
                               '_ansible_search_path': '/tmp',
                               '_ansible_no_log': False,
                               'template_vars': {'name': 'John'},
                               '_ansible_diff': True,
                               '_ansible_verbosity': 2,
                               '_ansible_version': '2.8',
                               'template_file': 'something'})

    templardir

# Generated at 2022-06-21 06:38:18.350675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # just some test data that will be passed to the LookupModule instance
    variables = dict(template_dir='/some/dir', template_file='some_file.txt')
    show_content = True
    display_skipped_hosts = False
    verbosity = 4
    terms = ['some_file.j2']
    variable_start_string = "{"
    variable_end_string = "}"
    comment_start_string = "{#"
    comment_end_string = "#}"

    # this is the expected result.
    # it's taken from the description of the return value for the method run
    # of class LookupModule
    expected = [b'Hi there!']

    # instantiate a LookupModule object and call method run with the test data
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:38:23.802123
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Test that the constructor of the LookupModule class works with good arguments
  lookup_module = LookupModule()
  # Test that the constructor of the LookupModule class fails with bad arguments
  try:
    lookup_module = LookupModule("bad argument")
  except TypeError:
    return True
  raise Exception("LookupModule constructor did not fail with bad arguments")

# Generated at 2022-06-21 06:38:26.595119
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['../../../my_templates/foo.html'], variables=dict()) == []

# Generated at 2022-06-21 06:38:32.676207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Test the case when convert_data is false
    variables = {'convert_data': False}
    terms = ['./convert_data_is_false.j2']
    assert lookup_plugin.run(terms, variables) == ['{ "a": 1 }']

    # Test the case when convert_data is true
    variables = {'convert_data': True}
    terms = ['./convert_data_is_true.j2']
    assert lookup_plugin.run(terms, variables) == [{u'a': 1}]

# Generated at 2022-06-21 06:38:36.352434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # testing terms with None value
    assert module.run(terms=None, variables={}) == []

    # testing template files with strings
    assert module.r

# Generated at 2022-06-21 06:38:36.984262
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:38:37.963403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:38:39.947091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:38:51.597168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 06:39:02.297154
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_LookupModule_run_basic
    lookup_module = LookupModule()
    assert lookup_module.run(['first_template.j2'], {'foo': 'bar'}) == ['This is my first template.\n']

    # test_LookupModule_run_with_blank_line
    lookup_module = LookupModule()
    assert lookup_module.run(['second_template.j2'], {'foo': 'bar'}) == ['This is my second template.\n\n']

    # test_LookupModule_run_with_multiple_templates
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:39:11.437174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a dummy environment
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=[])

    # Create a dummy plugin manager
    class TestLookup(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return []

    # Create a dummy template name
    template_name = 'test_template.j2'

    # Set the search path
    search_path = ['.']

    # Set the template content data
    template_data = """
{% if test %}
Hello
{% endif %}
"""

   

# Generated at 2022-06-21 06:39:12.912779
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 06:39:13.783906
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO
    return True

# Generated at 2022-06-21 06:39:25.532197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.constants import DEFAULT_TEMPLATE_ENGINE
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import _get_template_texts
    import io
    import jinja2

    display = Display()
    env = jinja2.Environment(loader=jinja2.DictLoader({
        u'myfile': u'static text with {{ var_text }}',
        u'foo/bar': u'{{ var_nested_text }}',
    }))

    # write some files and build test data
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write(u'static text with {{ var_text }}')
        path = f.name

# Generated at 2022-06-21 06:39:33.665017
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockEnvironment:
        def __init__(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables):
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string
            self.comment_start_string = comment_start_string
            self.comment_end_string = comment_end_string
            self.available_variables = available_variables

    class MockTemplar:
        def __init__(self):
            self.variable_start_string = ''
            self.variable_end_string = ''
            self.comment_start_string = ''
            self.comment_end_string = ''
            self.available_variables = {}


# Generated at 2022-06-21 06:39:46.884068
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        import jinja2
        HAS_JINJA2 = True
    except ImportError:
        HAS_JINJA2 = False

    import ansible.utils
    import ansible.plugins
    import ansible.errors
    import ansible.module_utils.six

    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment, USE_JINJA2_NATIVE

    from ansible.utils.display import Display
    from ansible.utils.unicode import to_bytes
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-21 06:39:59.105234
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        from test import support
        support.USE_NOSE = False
    except:
        pass

    # Instantiate LookupModule object
    lookupModule = LookupModule()

    # Create variable plugin options
    variable_options = {}

    # Create variable plugin arguments
    variable_cmnd_options = {}

    # Create variable arguments for find_file_in_search_path method

# Generated at 2022-06-21 06:40:03.388446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    # Save current environment variables
    # Load environment variables for unit testing
    # Restore environment variables at the end of the test run
    # Restore environment variables at the end of the test run
    import tempfile
    import os
    import stat
    import shutil
    oldenv = dict(os.environ)
    os.environ.clear()
    os.environ.update({'PYTHONPATH': os.path.join(os.getcwd(), 'test/units/module_utils/')})
    # Set up class object
    test_lookup = LookupModule()
    test_lookup._templar = 'foo'
    test_lookup._loader = 'bar'
    test_lookup.set_options('baz', 'baz', 'baz')
    # Verify method run raises exception when

# Generated at 2022-06-21 06:40:21.078849
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock class to simulate that the template exists
    class MockModule_run(LookupBase):
        def find_file_in_search_path(self, variables, dirs, file_name):
            return 'some_template.j2'

    try:
        my_obj = MockModule_run()
        assert isinstance(my_obj.run(['some_template.j2'], {}), list)
    except SystemExit:
        raise
    except Exception as err:
        print(err)

# Generated at 2022-06-21 06:40:31.768227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import PY3

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.module_utils.facts import FactCache
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.send_messaging import MessageCollector
    from ansible.playbook.role import Role

# Generated at 2022-06-21 06:40:33.247612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(None, ["lookupmodule_test_template.j2"], {})

# Generated at 2022-06-21 06:40:49.667197
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # create the necessary mocks
    class TestTemplar(Templar):
        # this class should provide a method or property named environment
        # that returns a Jinja2 Environment
        # TODO: use a mock here instead of a regular object
        class TestEnv:
            lstrip_blocks = True
            trim_blocks = True

            def get_template(self, template, globals=None):
                return TestTemplate()

        class TestTemplate:
            def render(self, **kwargs):
                return kwargs

        environment = TestEnv()


# Generated at 2022-06-21 06:41:01.446264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a simple test module
    class TestLookupModule(LookupModule):
        _single_file = "single_file.j2"

        def _get_file_contents(self, filename):
            if filename == self._single_file:
                return "{{ variable }}", True
            return super(TestLookupModule, self)._get_file_contents(filename)

    # Create a simple test case
    cm = TestLookupModule()

    # Set up the variables
    variables = dict(variable='test')

    # Run test
    returned = cm.run([], variables=variables)

    # Check that the test module returned the expected value.
    assert returned == ['test'], "Expected: 'test', Got: '{0}'".format(returned)

# Generated at 2022-06-21 06:41:13.257528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    import ansible.constants as C

    def test_ansible_module(terms, variable_manager, loader, **kwargs):
        my_vars = variable_manager.get_vars(loader=loader, play=play)
        variable_manager._extra_vars = kwargs.copy()
        variable_manager.extra_vars = my_vars.copy()
        variable_manager.options_vars = my_vars.copy()

        templar = Templar(loader=loader, variables=my_vars)
        res = []


# Generated at 2022-06-21 06:41:20.502358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import os

    env_vars = {
        'JINJA2_NATIVE': '1'
    }
    for k, v in env_vars.items():
        os.environ[k] = v


# Generated at 2022-06-21 06:41:22.503590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global display
    # not much of a test as this method is empty
    LookupModule()


# Generated at 2022-06-21 06:41:26.720355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.set_environment(Environment())
    lm._templar.environment.loader = DictLoader({'foo': '{{ lookup("template", "./some_template.j2") }}'})
    return lm

# Generated at 2022-06-21 06:41:31.468198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This test ensures that the Lookup Module class is created properly.
    """
    lookup_module_class = LookupModule('/usr/bin/ansible', None, 'action', 'role_path', True)
    assert LookupBase in lookup_module_class.__class__.__bases__

# Generated at 2022-06-21 06:41:53.646602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Do not run it, just import it
test_LookupModule()

# Generated at 2022-06-21 06:41:55.078613
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:42:04.751799
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:42:15.749580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The tests for this lookup plugin will only be ran when the following dependencies are installed.
    jinja2 = None
    try:
        from jinja2 import Environment, FileSystemLoader
    except ImportError as e:
        return

    if not jinja2:
        # Return to avoid errors when importing this module.
        return

    lookup_plugin = LookupModule()

    # Create the environment for the jinja2 templating engine
    jinja2_env = Environment(loader=FileSystemLoader("."), trim_blocks=True, lstrip_blocks=True)

    jinja2_template_path = "./test.j2"

# Generated at 2022-06-21 06:42:27.988006
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule without USE_JINJA2_NATIVE
    def test_LookupModule_run_without_USE_JINJA2_NATIVE():

        # Test with convert_data = False
        def test_LookupModule_run_without_USE_JINJA2_NATIVE_convert_data_false():

            # Test with convert_data = False and jinja2_native = False
            def test_LookupModule_run_without_USE_JINJA2_NATIVE_convert_data_false_jinja2_native_false():
                nonlocal test_lookup_template_vars
                nonlocal test_templar
                nonlocal test_variable_start_string
                nonlocal test_variable_end_string
                nonlocal test_comment_start_string
               

# Generated at 2022-06-21 06:42:38.646108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # With Ansible native jinja2 enabled
    loader = DataLoader()
    variable_manager = VariableManager()
    lm = LookupModule(loader=loader, variable_manager=variable_manager)
    assert lm.options is not None
    assert lm.options.get('variable_start_string') == '{{'
    assert lm.options.get('variable_end_string') == '}}'
    assert lm.options.get('comment_start_string') is None
    assert lm.options.get('comment_end_string') is None
    assert lm.options.get('jinja2_native') is True

    # With Ansible native jinja2 disabled

# Generated at 2022-06-21 06:42:42.280518
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = './some_template.j2'
    variables = ''

    kwargs = dict(
        _terms=terms,
        _raw_params=variables,
        _param_serializer=lambda x: x
    )

    lookup_plugin = LookupModule()
    assert lookup_plugin.run(**kwargs)

# Generated at 2022-06-21 06:42:52.266574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    template_data = """
        My password is '{{ password }}'
    """

    import jinja2

    # set up environment
    # search_path = ['/path/to/lookup_plugin/test']
    # search_path = [os.path.join('.', 'vars')]
    # loader = jinja2.FileSystemLoader(searchpath=search_path)
    # j2_env = jinja2.Environment(loader=loader, trim_blocks=True)
    #
    # # read in the file and render
    # # template_file = j2_env.get_template('test_template.j2')
    # # rendered_text = template_file.render(password='MySecretPassword')
    # # print("Rendered text: \n" + rendered_text)
    #
   

# Generated at 2022-06-21 06:43:00.303777
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a fake ArgumentSpec
    def get_argspec():
        return dict(
            lookup_template_vars=dict(type='dict', default={}),
            variable_start_string=dict(type='str', default='{{'),
            variable_end_string=dict(type='str', default='}}'),
            comment_start_string=dict(type='str', default='{#'),
            comment_end_string=dict(type='str', default='#}'),
        )
    argspec = get_argspec()
    # create a fake AnsibleOptions

# Generated at 2022-06-21 06:43:03.324238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a mock object using Mock in the unittest module
    L = LookupModule()
    # Assert the tests
    assert isinstance(L, LookupModule)

# Generated at 2022-06-21 06:43:47.074924
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:43:54.847008
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup import LookupModule
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'inventory_dir': 'tests/'}

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=None, variables=variable_manager)
    lookupModule = LookupModule()
    lookupModule._templar = templar
    lookupModule._loader = None

    testFile = 'tests/unit/lookup_plugins/template/test.txt'

# Generated at 2022-06-21 06:43:59.977105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __main__
    import os.path
    import tempfile
    import shutil
    import ansible.constants

    # Setup a simple json based configuration file
    templar = ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader())

    test_dir = tempfile.mkdtemp(prefix='ansible_lookup_template_test')
    config_file = os.path.join(test_dir, 'test.ini')
    test_ini = b"""\
[default]
other_var = variable_value
"""
    with open(config_file, 'wb') as f:
        f.write(test_ini)

    # Setup a simple jinja2 template

# Generated at 2022-06-21 06:44:09.513541
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule()
    templar = Templar(loader=DataLoader(), variables=VariableManager())
    lookup.set_loader(templar._loader)
    lookup.set_templar(templar)


# Generated at 2022-06-21 06:44:15.612592
# Unit test for constructor of class LookupModule
def test_LookupModule():
    loader_mock = Mock()
    templar_mock = Mock()
    display_mock = Mock()
    lookup_module = LookupModule(loader=loader_mock, templar=templar_mock, display=display_mock)

    assert lookup_module._loader is loader_mock
    assert lookup_module._templar is templar_mock
    assert lookup_module._display is display_mock

# Generated at 2022-06-21 06:44:21.924359
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader

    # f = open("/tmp/template_out", "w+")
    # f.close()
    # f = open("/tmp/template_out", "w+")

    # Test data
    terms1 = ["/tmp/template_out"]

    # expected_file1 = """---
    # - hosts: localhost
    #   tasks:
    #   - name: "First task"
    #     ping:
    # """

    expected_text1 = """
- hosts: localhost
  tasks:
  - name: "First task"
    ping:
"""

    # Test variables

# Generated at 2022-06-21 06:44:23.768104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Generated at 2022-06-21 06:44:26.323874
# Unit test for constructor of class LookupModule
def test_LookupModule():
    looker = LookupModule()
    assert looker is not None

# Generated at 2022-06-21 06:44:36.173615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    This method tests the run method of class LookupModule.
    '''
    import ansible.plugins.lookup.template

    ansible.plugins.lookup.template.Display.verbosity = 4
    lookup_template = ansible.plugins.lookup.template.LookupModule()

    # Test case: template used in jinja2_native mode and has jinja2 native types
    setattr(lookup_template,
            "_templar",
            ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader(),
                                     variables={'jinja2_native': True}))
    lookup_template.set_options({'variable_start_string': '{{',
                                 'variable_end_string': '}}'})


# Generated at 2022-06-21 06:44:36.903678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 06:46:09.926564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupBase(), 'config_options')
    assert hasattr(LookupBase(), 'set_options')
    assert hasattr(LookupBase(), 'run')
    assert hasattr(LookupBase(), '_flatten')

# Generated at 2022-06-21 06:46:18.896227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    l = LookupModule(inventory=inventory, loader=loader, variable_manager=variable_manager)
    l.set_options({'': 'a', 'convert_data': False})
    assert l.get_option('convert_data') is False
    l.set_options({'': 'a', 'template_vars': {'a': 'b'}})
    assert l.get_option('template_vars') == {'a': 'b'}

# Generated at 2022-06-21 06:46:24.489182
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Test(object):
        call_count = 0

        def find_file_in_search_path(self, variables, dir_name, file_name):
            return './OpenStack-Ansible/tests/unit/plugins/lookup/files/fake_template.j2'

        def _get_file_contents(self, path):
            assert path == './OpenStack-Ansible/tests/unit/plugins/lookup/files/fake_template.j2'
            return self.get_file_contents()

        def get_file_contents(self):
            self.call_count += 1
            if self.call_count == 1:
                return to_bytes('{{ somevar }}'), True
            return to_bytes('{{ somevar2 }}'), True

    test = Test()


# Generated at 2022-06-21 06:46:30.105888
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_vars = {'foo': 'bar'}
    jinja2_templar = LookupModule([], loader=loader, inv_vars=inv_vars)
    assert jinja2_templar._templar._available_variables == inv_vars
    assert jinja2_templar._loader is loader

# Generated at 2022-06-21 06:46:40.048221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    lookup_module = lookup_loader.get('template')
    lookup_module._display = Display()

    # Use a class to be able to modify jinja2_native
    class LookupModuleCopy(LookupModule):
        def __init__(self, jinja2_native):
            self.jinja2_native = jinja2_native

    # Create a class 'AnsibleTemplateVars' as a simple class with a 'template_host'
    # attribute. This is a simple way to generate a class for methods in ansible
    # that would have been generated by the generate_ansible_template

# Generated at 2022-06-21 06:46:52.880630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Bunch:
        def __init__(self, **kwds):
            self.__dict__.update(kwds)
    class Options(Bunch):
        def get(self, *args, **kwargs):
            return None
    class TestTemplar:
        def __init__(self):
            self.vars = {}
            self.option = Options()
        def set_vars(self, vars):
            self.vars = vars
        def template(self, data, **kwargs):
            for key, value in self.vars.items():
                data = data.replace('{{ %s }}' % key, value)
            return data
        def set_available_variables(self, vars):
            self.vars = vars

# Generated at 2022-06-21 06:47:03.417286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    class DummyLoader():
        def __init__(self,*args):
            self.templates = ['test_template.j2']
        def get_basedir(self,*args):
            return os.path.join(os.path.dirname(__file__),'file/lookup_plugins','test/test_templates')
    class DummyVars():
        def __init__(self):
            self.template_host = 'testhost'
        def get(self,*args):
            return 'testhost'
    class DummyTemplar():
        def __init__(self,*args):
            self.basedir = '.'
        def set_available_variables(self,*args):
            pass

# Generated at 2022-06-21 06:47:13.268022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup the arguments to be passed to the run method
    terms = ['./some_template.j2']
    variables = []

    # Instantiate the LookupModule object
    lm = LookupModule()

    # Invoke the run method of the LookupModule object with the above arguments
    results = lm.run(terms, variables)

    # Assert the result received using the module function run
    # is what we expect

# Generated at 2022-06-21 06:47:14.124415
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:47:15.125981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert isinstance(mod, LookupModule)