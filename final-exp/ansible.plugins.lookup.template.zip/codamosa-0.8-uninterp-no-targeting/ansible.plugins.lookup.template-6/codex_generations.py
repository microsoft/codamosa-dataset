

# Generated at 2022-06-21 06:37:45.553106
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:37:50.808008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test LookupModule run method """
    # simple test with no search path
    results = LookupModule().run(
            terms=['test.j2'],
            variables={
                'var1': 'foobar',
                },
            )
    assert results == ['{% if var1 == "foobar" %}true{% endif %}'], results

# Generated at 2022-06-21 06:37:56.773988
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import context, module_loader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    # Setup
    context.CLIARGS = {}
    context.CLIARGS['module_path'] = module_loader._get_paths()
    variables = {
        'a': 'b'
    }
    templar = Templar(loader=None, variables=variables)
    display = Display()
    my_tmpl = 'my_tmpl'
    my_vars = {'my_var': 'my_value'}
    my_comment_start_string = '<#'
    my_comment_end_string = '#>'
    my_var_start_string = '<'
    my_var_end_string = '>'
    my

# Generated at 2022-06-21 06:38:05.861816
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock

    # patch out the load files method
    # return the test_template variable in its place
    # the template is the text of test_template_template.j2
    patch("ansible.plugins.lookup.template.LookupBase._loader._get_file_contents",
          Mock(return_value=(to_bytes("Hello {{ test_var }}", errors='surrogate_or_strict'), True))).start()
    # create an instance of LookupModule
    lookup_plugin = LookupModule()

    # a test case

# Generated at 2022-06-21 06:38:08.372142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Validate LookupModule instantiation
    """
    lookup_plugin = LookupModule()
    assert lookup_plugin.env == None

# Generated at 2022-06-21 06:38:09.898775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = ['/template/file']
    variables = {'hostvars': {}}
    assert l.run(terms, variables) == [u'hello world']

# Generated at 2022-06-21 06:38:21.152362
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    fake_env = dict(
        template_host="fake_host_name",
        template_uid="501",
        template_user="fake_user_name",
        template_path="/fake/path/to/file",
        template_fullpath="/fake/path/to/file",
        template_realpath="/fake/path/to/file",
        template_mtime=123456789,
        template_uid="fake_uid_here",
        template_mode="0777",
        template_inventory_hostname="inventory_hostname_placeholder",
        template_inventory_hostname_short="inventory_hostname_short_placeholder",
        template_inventory_dir="/path/to/inventory",
        template_inventory_file="/and/its/file/name"
    )

    lookup_module = LookupModule()

   

# Generated at 2022-06-21 06:38:27.615860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    template = """
    this is a test
    """

    loader = LookupModule()
    lookupfile = "/tmp/ansible.template"
    with open(lookupfile, 'w') as f:
        f.write(template)

    r = loader.run([lookupfile], {}, variable_start_string='[%', variable_end_string='%]')
    assert r[0] == template, r[0]

# Generated at 2022-06-21 06:38:34.598433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: the only way to test the value is to use the native _templar from
    #       the lookup plugin instance.
    from ansible.template import Templar
    templar = Templar(loader=None)
    jinja2_native = templar.template_class.environment().jinja2_native

    vars = {'test': '{{1+1}}'}
    ret = []

    # should use native types for jinja
    # jinja2_native='yes' with convert_data='yes'
    lookup_module = LookupModule(loader=None)
    lookup_module.set_options(var_options=vars, direct={'convert_data': True, 'jinja2_native': True})
    ret.append(lookup_module.run([':data'], vars))
   

# Generated at 2022-06-21 06:38:45.194512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {'_templar': None, '_loader': None, '_use_unsafe_lookups': True}
    lookup_module = LookupModule(**args)
    # find_file_in_search_path
    # No value for varibles['ansible_search_path']
    args = {'variables': {}, 'subdir': 'templates', 'filename': './some_template.j2'}
    ret = lookup_module.find_file_in_search_path(**args)
    assert ret == './some_template.j2'
    # No value for varibles['ansible_search_path']

# Generated at 2022-06-21 06:39:04.584631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup._templar = None

# Generated at 2022-06-21 06:39:05.454894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()

# Generated at 2022-06-21 06:39:15.580585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import pytest
    import collections
    import ansible.module_utils.basic

    class DummyFileStore(collections.Mapping):
        def __init__(self, store_data):
            self.store_data = store_data

        def __getitem__(self, key):
            return self.store_data[key].encode()

        def __len__(self):
            return len(self.store_data)

        def __iter__(self):
            return self.store_data.__iter__()

    #Test_Term = collections.namedtuple('test_term', ['term_data'])
    Test_Term = object
    Test_Term.term_data = 'some_template.j2'

# Generated at 2022-06-21 06:39:16.944901
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 06:39:27.579452
# Unit test for constructor of class LookupModule
def test_LookupModule():
  f = open('test_file.txt', 'a')
  f.write('Hello World!')
  f.close()
  display = Display()

  lm = LookupModule({}, {}, [], [], display)
  assert "test_file.txt" in lm.run(["test_file.txt"], {})
  os.remove('test_file.txt')
  try:
    assert "test_file.txt" in lm.run(["test_file.txt"], {})
    assert "test_file.txt" in lm.run(["test_file.txt"], {}) # should not work
  except AnsibleError:
    assert True


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:39:34.699080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    looker = LookupModule()
    # can't just return terms since Ansible needs to perform templating on the paths
    terms = '/this/is/a/test.conf'
    variables = dict()

    # Currently no way to test with USE_JINJA2_NATIVE as the display.debug statements are not
    # set in the unit tests, which causes the tests to fail.
    if USE_JINJA2_NATIVE == False:
        result = looker.run(terms, variables)
        assert result[0] == '/this/is/a/test.conf\n'

        # Test passing multiple terms to lookup
        terms2 = ['/this/is/a/test2.conf', '/this/is/a/test3.conf']
        result = looker.run(terms2, variables)

# Generated at 2022-06-21 06:39:44.571815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  """Unit tests for method run of class LookupModule"""
  lookup = LookupModule()

  # Test for a good template
  # Test for a good template
  term = 'test_template.j2'
  terms = [term]
  lookup.find_file_in_search_path = MagicMock(return_value=lookup.get_basedir() + '/test_lookup_plugins/templates/' + term)
  lookup.run(terms=terms, variables = {'var1': True, 'var2': 1, 'var3': 'var3'})


# Generated at 2022-06-21 06:39:45.616397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test

# Generated at 2022-06-21 06:39:46.247602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:39:47.859068
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # LookupModule should validate parameters and not pass them to super constructor
    assert LookupModule({}) is not None

# Generated at 2022-06-21 06:39:58.486706
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:40:01.146965
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # required args
    terms = list()
    variables = dict()

    # instantiate LookupModule
    module = LookupModule(terms, variables)

# Generated at 2022-06-21 06:40:02.402971
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup,'run')

# Generated at 2022-06-21 06:40:13.616103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Test with empty terms
    assert lookup_plugin.run([], dict()) == []

    # Test with inexistent template
    with pytest.raises(AnsibleError, match="could not be found for the lookup"):
        lookup_plugin.run('template_inexistent.j2', dict())

    # Test with unreadable template
    os.makedirs('/tmp/ansible-template-lookup')
    open('/tmp/ansible-template-lookup/template_unreadable.j2', 'a').close()
    os.chmod('/tmp/ansible-template-lookup/template_unreadable.j2', 0o000)

    # Test with unreadable template

# Generated at 2022-06-21 06:40:16.411246
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module=LookupModule()
    assert lookup_module is not None, "Could not instantiate class LookupModule"
    assert lookup_module._templar is not None, "Could not instantiate class Templar"
    assert lookup_module._loader is not None, "Could not instantiate class DataLoader"
    assert lookup_module._loader.path_exists is not None, "Could not instantiate class Path"
    assert lookup_module._loader._get_file_contents is not None, "Could not instantiate class FileModule"

# Generated at 2022-06-21 06:40:18.921312
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None


# Generated at 2022-06-21 06:40:20.427239
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:40:21.478435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:40:32.131893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.utils.vars import combine_vars

    from ansible.parsing.vault import VaultLib

    # sample
    # module = basic.AnsibleModule(argument_spec={'convert_data': {'type': 'bool', 'required': False, 'default': True}})
    #
    #
    # #sample
    # lookup = LookupModule()
    # lookup.set_options(var_options={'template_dir': '...'})
    #
    # #sample
    # playbook_vars = combine_vars(loader=None, variables=None)
    #
    # vault_pass='123'
    # #sample
    # vault = VaultLib([vault_pass])
    #
    # #sample
    # inventory = None

# Generated at 2022-06-21 06:40:33.292045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:41:04.889007
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Instantiate class and set required variables
    l = LookupModule()

    l.set_loader({
        "_get_file_contents": lambda x: (b"{{ file_contents }}", True)
    })

    l.set_basedir(os.path.join(os.path.dirname(__file__), 'test_lookup_plugins'))

    # Create test vars
    test_vars = {
        "lookup_file_test": "lookup_file.txt"
    }

    # Create test terms
    test_terms = [
        "{{ lookup_file_test }}"
    ]

    # Run test against method run
    result = l.run(test_terms, test_vars)

    # Assert result of test
    assert result == ["lookup_file.txt\n"]

# Generated at 2022-06-21 06:41:16.204155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader

    import sys
    fake_stdout = StringIO()
    sys.stdout = fake_stdout
    lookup = lookup_loader.get('template', class_only=True)
    sys.stdout = sys.__stdout__

    # test_template_vars
    test_template_vars = {'test_template_vars': 'test_template_vars'}

    # assertion test_template_vars

# Generated at 2022-06-21 06:41:26.761335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    lookup_module = LookupModule()
    lookup_module.set_options(var_options=dict(), direct=dict())
    lookup_module._templar.set_available_variables(variable_manager.get_vars(loader=loader, play=None))

    # assert that the right object is returned
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-21 06:41:28.189658
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:41:36.081223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    templar = Templar(loader=loader)
    variable_manager = VariableManager()

    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module._loader = loader
    lookup_module._templar = templar
    lookup_module._variable_manager = variable_manager

    assert lookup_module is not None

# Generated at 2022-06-21 06:41:41.694586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_basedir(None)
    lookup._templar = None
    args = []
    kwargs = {}
    result = lookup.run(terms=args, variables=kwargs)
    assert type(result) == list
    assert result == []
    args = [None]
    result = lookup.run(terms=args, variables=kwargs)
    assert type(result) == list
    assert result == []


# Generated at 2022-06-21 06:41:53.893952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # use a file that is in the ansible-core tree
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules', 'file.py')
    assert os.path.exists(test_path)

    # create a lookup object to run against
    lu = LookupModule()
    # initialize it with the test_path in the lookup path, otherwise it will not find the test_path
    lu._loader.path_expected_to_exist = [test_path]

    # run the test template against the target file
    test_template = "{{ lookup('template', 'file.py.j2') }}"

# Generated at 2022-06-21 06:41:54.540615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:42:04.349083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit tests for method run of class LookupModule.
    """
    class Options(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class OptionsDict(dict):
        def __init__(self, *args, **kwargs):
            super(OptionsDict, self).__init__(*args, **kwargs)

        def __getitem__(self, name):
            return self.get(name)

        def get(self, name, default=None):
            if name in self:
                return self[name]
            return default

    class VarsModule(object):
        def __init__(self, args=None, **kwargs):
            self.args = args
            self.params = OptionsDict(self.args)

# Generated at 2022-06-21 06:42:07.784158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = None
    lookup = LookupModule()
    # value of 'data' should be unchanged
    assert data == None, 'value of data should be unchanged'

# Generated at 2022-06-21 06:42:48.880692
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:42:56.601764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # No terms.
    lookup = LookupModule()
    assert lookup.run([], dict()) == []

    # These are really primitive tests... 0:-)
    # The point is just to make sure the constructor works.

    # No variables.
    lookup = LookupModule()
    assert lookup.run(["/"], dict()) == []

    # Check that a real template file works.
    lookup = LookupModule()
    assert lookup.run(["tests/templates/lookup_plugins/template.j2"], dict()) == ["bar"]

# Generated at 2022-06-21 06:42:57.528807
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:42:58.673343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:43:10.383527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test method run of class LookupModule

    Method run of class LookupModule is tested.
    This is performed by an own unit test instead of an external one
    to avoid changing the filename of the unit test for the lookup module
    by renaming module_utils/lookup_plugins/template.py to
    module_utils/lookup_plugins/template_lookup.py.

    This test assumes that the template is written to a file
    with the filename term for error diagnosis.
    '''
    text_unit_test = '''
{% if ansible_os_family == "RedHat" -%}
redhat
{% elif ansible_os_family == "Debian" -%}
debian
{% else -%}
unknown
{% endif %}
'''

# Generated at 2022-06-21 06:43:15.567456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)
    assert getattr(lookup_module, '_display', None) is not None

# Generated at 2022-06-21 06:43:17.549678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:43:29.363254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test LookupModule._run()"""
    import tempfile
    import shutil
    import json
    import textwrap
    import os
    import time
    import sys

    from ansible.galaxy import Galaxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import LookupModule as LookupModuleBase
    from ansible.template import generate_ansible_template_vars

    from ansible.plugins.loader import lookup_loader

    # example of code to setup the test (this is the setup of our test, not the setup of your environment)
    # create a temporary directory to store the lookup plugin (and any other files needed by the lookup)

# Generated at 2022-06-21 06:43:34.066568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["term1","term2"])[0] == "File lookup term: term1\nFile lookup term: term2\n"
    assert lookup_module.run(terms=["term1"])[0] == "File lookup term: term1\n"

# Generated at 2022-06-21 06:43:43.659266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    # use a realy vault password in case we need to unencrypt a test file
    vault_password = '$6$r5Ixx1jgVzwJ.Pcb$C7IK.XjMc0J7rtEZ58DUMG7QFfsexg6U8w6jEDT6TlG6ypDvgY57sWZmADKjhkJmEJxdPl/8RzFh/WN4/j4N9.'
    vault = VaultLib(vault_password)

    # The fixture for this test is a lookup plugin which always returns
    # the path of the test file, which can be provided as an extra argument
    #

# Generated at 2022-06-21 06:45:32.648159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Method run of class LookupModule returns correct content of template file """
    # create method argument values
    terms = ['./lookup_plugins/testfiles/test_template', ]
    variables = dict(template_host='foo')

    # execute the method under test
    lu = LookupModule()
    templated_content = lu.run(terms, variables)

    # assert the method returned the correct value
    assert to_text(templated_content[0]) == "this is a test template, foo"

# Generated at 2022-06-21 06:45:33.972936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:45:35.170527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert isinstance(lk, LookupModule)

# Generated at 2022-06-21 06:45:36.017275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 06:45:45.680617
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None

    data = "<html><body><h1> {{ foo }} </h1></body></html>"
    ret = lookup.run([data], {"foo": "ansible"}, convert_data=True)
    assert ret == ["<html><body><h1> ansible </h1></body></html>"]

    ret = lookup.run([data], {"foo": "ansible"}, convert_data=False)
    assert ret == [data]

    data = '''foo: {{ foo }}
bar:
  - item1
  - item2

'''
    ret = lookup.run([data], {"foo": "ansible"}, convert_data=True)
    assert ret == [{'foo': 'ansible', 'bar': ['item1', 'item2']}]

    ret = lookup

# Generated at 2022-06-21 06:45:51.520492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({
        '/etc/ansible/template.j2': '{% for i in [1,2,3] %}{{ i }},{% endfor %}',
        '/etc/ansible/template_with_vars.j2': '{{ foo }},{{ bar }}'
    })
    output = to_text(lookup_module.run(terms=['template.j2'], variables={}, convert_data=False)[0])
    assert output == '1,2,3,'
    output = to_text(lookup_module.run(terms=['template.j2'], variables={}, convert_data=True)[0])
    assert output == '[1, 2, 3]'

# Generated at 2022-06-21 06:45:59.571385
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use class object to test static methods from LookupBase
    # Use class object to test static methods from LookupBase
    lookup = LookupModule()

    # LookupBase._get_file_contents
    assert lookup._get_file_contents('.') == (b'', False)

    # LookupBase.find_file_in_search_path
    assert lookup.find_file_in_search_path(dict(), '', '') == ''

    # LookupBase.get_option
    assert lookup.get_option('') == None

# Generated at 2022-06-21 06:46:03.214615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_test = LookupModule()
    ret = lookup_test.run(terms=['/home/ansible/some_template.j2'], variables={'ansible_search_path': []})
    assert ret[0] == to_bytes('some_template_content')

# Generated at 2022-06-21 06:46:04.141474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:46:07.447240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert isinstance(test, LookupModule) is True