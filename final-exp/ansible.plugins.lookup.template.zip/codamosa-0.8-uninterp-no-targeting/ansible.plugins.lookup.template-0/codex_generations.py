

# Generated at 2022-06-21 06:37:47.274244
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)


# Generated at 2022-06-21 06:37:49.704507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    assert module.run(["some_template.j2"],{}) == []

# Generated at 2022-06-21 06:38:00.643588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class VarManager:
        def __init__(self):
            self.vars = {'ansible_search_path': ['/path/to/playbook']}

    class Environment:
        def __init__(self):
            self.var_manager = VarManager()
            self.loader = None
            self.basedir = '/path/to/playbook'

    environment = Environment()
    templar = DummyTemplar(environment)
    lookup = LookupModule(templar)

    # no file, no lookupfile
    term = ['foo.j2']
    variables = {'ansible_search_path': []}
    with pytest.raises(AnsibleError) as execinfo:
        lookup.run(terms=term, variables=variables)

# Generated at 2022-06-21 06:38:01.914441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._loader is not None

# Generated at 2022-06-21 06:38:13.465887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'test'

        def __init__(self, display=None):
            super(TestCallbackModule, self).__init__(display)
            self.results = []


# Generated at 2022-06-21 06:38:19.115734
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # set up vars for constructor
    module_name = 'LookupModule'
    templar = None
    loader = None
    # test constructor
    lookupModule = LookupModule(loader=loader, templar=templar, shared_loader_obj=None,
                                basedir=None)
    assert lookupModule.__class__.__name__ == module_name

# Generated at 2022-06-21 06:38:21.897948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    print(lookup_module.run(["tests/test_lookup_template.j2"],{"foo":"bar"}))

# Generated at 2022-06-21 06:38:23.481082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:38:25.927039
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu._loader.package_hash[lu.__module__] == 'v2'

# Generated at 2022-06-21 06:38:30.642904
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an instance of LookupModule
    l = LookupModule()

    # check instance attributes
    assert l._templar is not None
    assert l._loader is not None
    assert l._display is not None
    assert l._options is None
    assert l._display.verbosity == 0
    assert l._display.debug == False
    assert l._display.deprecate_warnings == True
    assert l._display.deprecate_directives == True

# Generated at 2022-06-21 06:38:42.013691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert type(lm) == LookupModule

# Generated at 2022-06-21 06:38:51.749843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create dummy file for testing purposes
    f = open('templates/test_template.j2', 'w')
    f.write('{{ lookup("pipe", "echo test") }}')
    f.close()

    # Set up display object for testing
    display.verbosity = True

    # Create empty object for object we are testing
    lookup = LookupModule()

    # Create variables for testing method run
    terms = ['test_template.j2']
    variables = {}

    # Run the method we are testing
    res = lookup.run(terms=terms, variables=variables)

    # Check the correctness of the results
    assert res == ["test"]

# Generated at 2022-06-21 06:38:52.661032
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert module is not None


# Generated at 2022-06-21 06:38:58.773162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['test.j2', 'test2.j2']
    variables = {'test': 'This is a test'}
    opts = {'template_vars': {'test2': 'This is another test'}}
    result = lookup.run(terms, variables, **opts)
    assert result[0] == 'This is a test'
    assert result[1] == 'This is another test'

# Generated at 2022-06-21 06:39:01.977462
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert 'plugin' in my_lookup.__dict__

# Generated at 2022-06-21 06:39:04.243750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    variables = dict()
    variables['ansible_search_path'] = ['.']
    assert lookup_module.run(['test.j2'], variables) == ['hello world']

# Generated at 2022-06-21 06:39:14.717780
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t_vars = dict(zip(range(0, 10), range(1, 11)))
    t_args = dict(zip(range(1, 11), range(1, 11)))
    
    # args are used to alter class fields in the constructor
    # vars are used as template variables for template
    lm = LookupModule(loader=None, templar=None, shared_loader_obj=None, **t_args)
    lm.set_options(var_options=t_vars)
    assert lm.__dict__ == t_args
    
    # using a copy of a template variable dictionary is to prevent interference
    # in the original data with the modified copy
    assert lm.templar.template_data == t_vars.copy()

# Unit tests for the find_file_in_search_path

# Generated at 2022-06-21 06:39:26.685056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [u'../tests/templates/test.j2']
    # Mocking of the connection which is required from the Ansible API
    class ConnFake(object):
        def __init__(self):
            self.become_method = 'sudo'
            self._shell = None

    class TaskFake(object):
        def __init__(self):
            self._connection = ConnFake()
            self._play_context = PlayContext()
            self._loader = None
            self._templar = None

    class PlayContext(object):
        def __init__(self):
            self.become = False
            self.become_user = None
            self.directory = None
            self.environment = {}
            self.forks = 5
            self.remote_addr = None
            self.remote_user = None
           

# Generated at 2022-06-21 06:39:27.729587
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO - implement unit test
    assert False

# Generated at 2022-06-21 06:39:34.761576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up a dummy env
    class Options(object):
        """dummy class to replace the parser options"""
        extra_vars = {}
        vault_password = None
        tags = []
        listtags = False
        listtasks = False
        listhosts = None
        syntax = False
        connection = None
        module_path = None
        forks = 5
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = None
        become_user = None
        become_ask_pass = False
        verbosity = 0
        check = False
        start_at_task = None

    class DisplayOptions(object):
        verbosity = 0


# Generated at 2022-06-21 06:39:45.369483
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:39:52.804794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    # Creating objects for needed for test
    variables = dict(ansible_search_path=['.'])
    terms = ['../../../lib/ansible/plugins/lookup/../../templates/test.j2']
    lookup_base = LookupBase()
    lookup_base._templar = None
    lookup_base._loader = None
    lookup_base.set_options(var_options=variables, direct=dict())
    lookup_module = LookupModule()
    lookup_module._loader = None
    lookup_module._templar = None
    lookup_module.set_options(var_options=variables, direct=dict())

    # Assigning value to variable
    ansible_template_vars = dict()
    ansible_template_

# Generated at 2022-06-21 06:39:57.129570
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # params
    terms = ['./some_template.j2']
    variables = {'ansible_distribution': 'CentOS'}

    # run test
    lm = LookupModule()
    lm.run(terms=terms, variables=variables)

# Generated at 2022-06-21 06:39:59.792311
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # required args
    module = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 06:40:09.873467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test the template lookup plugin'''

    import sys
    from ansible.template import Templar
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes, to_text

    # Setup
    lookup_module = LookupModule()
    lookup_module.basedir = "tests/test_lookup_plugins/files"
    lookup_module._templar = Templar(loader=None, variables=ImmutableDict())
    class StructureForTestExtend:
        """Structure to test extend function"""
        class _ansible_test_extend:
            path = "tests/test_lookup_plugins/files/extend_test.j2"
    lookup_module._loader = StructureForTestExtend()

    # Run
    # Test the catch of

# Generated at 2022-06-21 06:40:21.928134
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Retrieve file from the module test directory
    from ansible import constants as C
    from ansible.test.unit.test_loader import TestLoader
    test_loader = TestLoader()
    data = test_loader._data()
    lookup = LookupModule(loader=test_loader)
    lookup._templar = data['templar']
    lookup._loader = data['loader']

    # Test run() method with invalid file
    terms = 'invalid'
    result = lookup.run(terms, [])
    assert result == [], "Result should be empty if file doesn't exit"

    # Test run() method with valid file
    terms = 'test_template.j2'
    result = lookup.run(terms, [])

# Generated at 2022-06-21 06:40:32.503348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock, mock_open

    # Mock AnsibleModule and AnsibleIncludeResolver
    lookup = LookupModule()
    lookup._loader = Mock()
    lookup._templar = Mock()
    class FakeAnsibleIncludeResolver():
        class FakeAnsibleIncludeEncoder():
            def __init__(self, pathname):
                self.pathname = pathname
                self.dirdepth = 5
                self.listitems = [ ('pathname', self.pathname), ('dirdepth', self.dirdepth) ]
            def __iter__(self):
                return iter(self.listitems)

# Generated at 2022-06-21 06:40:35.160414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that the correct search path is used, when the 'ansible_search_path' variable is set.
    test_base_path = '/test/path'
    test_template_name = 'test.j2'

# Generated at 2022-06-21 06:40:39.592875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create our fixture objects
    LookupModule()

    # TODO: This class is basically a pass-thru to AnsibleTemplate,
    #       so the unit test for that needs to be written.
    #       This test will be updated when that is done.
    pass

# Generated at 2022-06-21 06:40:40.710481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 06:41:12.194848
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    import ansible.plugins.lookup.template
    import ansible.template
    lm = ansible.plugins.lookup.template.LookupModule()

    # silence the debug output
    display.verbosity = 3

    # first test - non-existing file
    try:
        lm.run(["/doesnotexist.j2"], dict(), variables=dict())
    except AnsibleError as ae:
        assert type(ae) == AnsibleError
        assert ae.message == "the template file /doesnotexist.j2 could not be found for the lookup"
    else:
        assert False

    tmpl_var = "foo"

# Generated at 2022-06-21 06:41:14.294787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(terms=['tests/lookup/template.j2'], variables={})
    assert(result == [u'1'])

# Generated at 2022-06-21 06:41:26.197035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible
    import ansible.utils

    from ansible.constants import DEFAULT_TIMEOUT
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    from ansible.utils.jinja2_native import get_template_class

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Initialize needed objects
    variable_manager = VariableManager()
    loader = DataLoader()
    display = Display()

# Generated at 2022-06-21 06:41:28.365130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """"""
    assert LookupModule.run([],[],"")#, "Failed to run LookupModule.run")

# Generated at 2022-06-21 06:41:38.394101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Fake a module instance used for testing purpose to allow set_options
    # to be called in the LookupModule run method.
    class FakeModule(object):
        def __init__(self):
            self._templar = None

        def set_templar(self, templar):
            self._templar = templar

        @staticmethod
        def fail_json(msg=None, **kwargs):
            pass

    module = FakeModule()
    templar = 'templar'
    module.set_templar(templar)

    # Fake an ansible options used for testing purpose to allow set_options
    # to be called in the LookupModule run method.
    class FakeOptions(object):
        def __init__(self):
            self.jinja2_native = True

    fake_

# Generated at 2022-06-21 06:41:39.925773
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:41:42.643095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = './test/fixtures/templates/test.j2'
    ret = lookup.run([term], dict())
    assert ret[0] == 'test_jinja2_lookup'

# Generated at 2022-06-21 06:41:45.885956
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm.lookup_plugin_name == 'template'

# Generated at 2022-06-21 06:41:47.862841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert(mod._templar is not None)

# Generated at 2022-06-21 06:41:55.127821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    template_vars = {'foo': 'bar'}

    # test normal behaviour
    lookup_module._templar = None
    lookup_module._loader = None

    terms = ['./some_template.j2']
    res = [to_text(u'')]
    assert lookup_module.run(terms, template_vars) == res

    # test normal behaviour with list input
    template_vars = [template_vars]
    assert lookup_module.run(terms, template_vars) == res

# Generated at 2022-06-21 06:42:43.036026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import builtins
    from ansible.plugins.lookup.template import LookupModule
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    lookup_module = LookupModule()

    # building a dummy env
    class Options(object):
        def __init__(self):
            self.hashed_dun = False
            self.hash_verbosity = 2
            self.keep_remote_files = False
            self.module_regex = None
            self.module_path = None
            self.roles_path = None
            self.timeout = 10
            self.tree = None
            self.remote_tmp = '~/.ansible/tmp'
            self.remote_user = 'whoever'


# Generated at 2022-06-21 06:42:53.397016
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vault_secrets(['my_secret'])

    lookup_list = lookup_loader.get("lookup_plugins")
    LookupModule_class = lookup_list.get("template")

    LookupModule_obj = LookupModule_class([''], variable_manager, loader)

    assert isinstance(LookupModule_obj, LookupModule)

    assert LookupModule_obj.run([], {}) == []
    assert LookupModule_obj.run(['some_template.j2'], {}) == []

# Generated at 2022-06-21 06:42:54.806609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l


# Generated at 2022-06-21 06:42:55.583669
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False

# Generated at 2022-06-21 06:42:57.257897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:42:59.619985
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:43:08.615751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert cls.__doc__ == '''
template lookup
'''
    assert cls.lookup_type == 'template'

# Generated at 2022-06-21 06:43:16.886845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    play_context = PlayContext()
    l = LookupModule()

    l._fail_function = None
    l._search_paths = []
    l._loader = loader
    l._templar = None
    l._display = Display()
    l._options = None
    l._display.verbosity = 3


# Generated at 2022-06-21 06:43:28.847394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_contents = b'''{% if foo == 'foo_value' %}
FOO!
{% else %}
{{ bar }}
{% endif %}

'''
    foo_value = "foo_value"
    bar_value = "bar_value"
    lookup_vars = {'foo': foo_value, 'bar': bar_value}
    searchpath = ['foo_search_path']

    loader = FakeLoader(file_contents, lookup_vars)
    templar = FakeTemplar(loader)
    display = FakeDisplay()

    terms = ['foo_template_name']

    lookup_module = LookupModule()

    lookup_module._loader = loader
    lookup_module._templar = templar
    lookup_module.display = display


# Generated at 2022-06-21 06:43:39.152116
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create mock instances of ansible.module_utils._text.NativeJinjaText and ansible.template.AnsibleEnvironment
    class NativeJinjaText:
        def __init__(self, string):
            self.string = string

    class AnsibleEnvironment:
        def __init__(self, variable_start_string=None, variable_end_string=None, comment_start_string=None, comment_end_string=None):
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string
            self.comment_start_string = comment_start_string
            self.comment_end_string = comment_end_string

    # Create mock instances of ansible.plugins.lookup.LookupBase and ansible.template.AnsibleTemplate

# Generated at 2022-06-21 06:45:20.451912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test without jinja2_native option
    lm = LookupModule()
    lm.set_loader({'_get_file_contents': lambda file: (b'bar', True)})
    # test with variable defined in lookup_template_vars
    assert lm.run(['./some_template.j2'], {}, lookup_template_vars={'foo': 'bar'}) == ['bar']
    # test with variable defined in variables
    assert lm.run(['./some_template.j2'], {'foo': 'bar'}) == ['bar']



# Generated at 2022-06-21 06:45:32.870211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing term is "testfile.j2" because all tests assume this as the tested file
    # Testing lookup_template_vars is {"key": "value"} because this is referenced in the testfile
    # Testing convert_data is False because this will test literal_eval in the template is not called
    # Testing jinja2_native is False because this will test literal_eval in the template is called
    terms = ["testfile.j2"]
    variables = {"ansible_search_path" : ["test/resources/test_lookup_plugins/"]}
    kwargs = {"template_vars" : {"key" : "value"}, "convert_data" : False, "jinja2_native" : False}
    lm = LookupModule()
    result = lm.run(terms, variables, **kwargs)
    assert result

# Generated at 2022-06-21 06:45:36.125132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('template')
    print(lookup)
    print(lookup.__class__.__name__)


from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-21 06:45:45.794245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.template import AnsibleEnvironment
    from ansible.parsing.dataloader import DataLoader

    variables = {
        "foo": "bar",
        "blip": "blap",
    }

    my_lookup = LookupModule()
    my_lookup.set_loader(DataLoader())
    my_lookup.set_environment(AnsibleEnvironment())

    # Check overriding jinja2_native which should be enabled globally
    results = my_lookup.run(["./tests/unit/templates/jinja2_native_template.j2"], variables, jinja2_native=False)
    assert len(results) == 1
    assert 'bar' in results[0]
    assert 'blap' in results[0]

# Generated at 2022-06-21 06:45:51.586134
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.plugins.loader import LookupModule
    from ansible.module_utils._text import to_bytes, to_text

    class PluginOptions:

        def __init__(self, _variable_manager, _loader, _templar, _inventory, _basedir):
            self._variable_manager = _variable_manager
            self._loader = _loader
            self._templar = _templar
            self._inventory = _inventory
            self._basedir = _basedir

            self._convert_bare = True
            self._available_variables = None
            self._vars = None
            self._no_log = False


# Generated at 2022-06-21 06:46:02.614554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'variable_start_string': '{{', 'variable_end_string': '}}'})
    l.set_options({'jinja2_native': False})
    l.set_options({'convert_data': True})

    # Test all parameters
    res = l.run(['./test.j2'], {'a': 1, 'b': 2}, convert_data=False, comment_start_string='[#', comment_end_string='#]', template_vars={'a': 3}, variable_start_string='[%', variable_end_string='%]')
    assert res == ['{{ a }} 1\n{{ b }} 2\n']


# Generated at 2022-06-21 06:46:05.057738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Stub "term"
    terms = ['./test/test.j2']

    # Stub "variables"
    variables = {}

    # Stub "kwargs"
    kwargs = {}

    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ["Test template"]

# Generated at 2022-06-21 06:46:10.874632
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up the test
    test_instance = LookupModule()
    # Define the test cases
    successful_return = [123,]
    # Run the test
    result = test_instance.run(successful_return, '', '', '')

    # Assertions
    assert result == successful_return

# Generated at 2022-06-21 06:46:14.132871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DummyVarsModule(object):
        def __init__(self):
            self._templar = 'test'
        def set_options(self, *args, **kwargs):
            pass
    l = LookupModule(DummyVarsModule())
    assert l._templar == 'test'

# Generated at 2022-06-21 06:46:21.722183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  ### Test 1 - check that the file is correctly resolved with a relative path
  # Initialization
  lookup_instance = LookupModule()
  lookup_instance._templar = AnsibleEnvironment()
  display.verbosity = 4
  lookup_instance._loader = {}
  lookup_instance._loader.list_directory = mock_list_directory
  lookup_instance.find_file_in_search_path = mock_find_file_in_search_path
  lookup_instance.get_option = mock_get_option

  # Test
  result = lookup_instance.run(["some_template.j2"], {})

  # Assertions
  assert result[0] == "some content"
  assert result == ["some content"]

  ### Test 2
  # Initialization
  lookup_instance = LookupModule()
  lookup_instance._tem