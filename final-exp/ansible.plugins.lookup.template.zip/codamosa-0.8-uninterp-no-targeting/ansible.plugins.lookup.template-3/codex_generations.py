

# Generated at 2022-06-21 06:37:54.713284
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set class attribute
    LookupModule._templar = object()

    lookup = LookupModule()

    # Set method attribute
    lookup.find_file_in_search_path = classmethod(lambda cls, variables, directories, path: path)
    lookup._loader = object()

    # Test when the file exist, it gets read and processed
    LookupModule.run(lookup, ['./some_template.j2'], {'ansible_search_path': [os.getcwd()]})

    # Test when the file does not exist
    with pytest.raises(AnsibleError):
        LookupModule.run(lookup, ['./some_template.j2'], {})

# Generated at 2022-06-21 06:38:01.705054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule instance and call its run method
    lookup_instance = LookupModule()
    # Create a valid option for the run method
    opts = {'_terms': ['./test.j2']}
    # Create variables for the run method
    variables = {'list_var': ['test1', 'test2']}

    # Funcion to set options for the LookupModule instance
    def set_options(option, value):
        var = '_' + option
        setattr(lookup_instance, var, value)

    # Set the variable opts as options for the LookupModule instance
    lookup_instance.set_options = set_options
    # Call the run method and get the output
    result = lookup_instance.run(variables=variables, **opts)
    # Assert that the output is

# Generated at 2022-06-21 06:38:02.986780
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    assert lookup_plugin._templar

# Generated at 2022-06-21 06:38:03.435927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert None

# Generated at 2022-06-21 06:38:05.577902
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: write tests for the LookupModule class.
    return 1

# Generated at 2022-06-21 06:38:13.122278
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test with different variable start and end string
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['./some_template.j2'], {}, variable_start_string='[%', variable_end_string='%]')

    # test with different comment start and end string
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['./some_template.j2'], {}, comment_start_string='[#', comment_end_string='#]')

# Generated at 2022-06-21 06:38:24.820812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # the yaml data is "foobar"
    # the j2 data is "{{ lookup('pipe','echo {{ input }}' input='foo') }}bar"
    # the expected result is "foobar"
    yaml_data = "foobar"
    j2_data = "{{ lookup('pipe','echo {{ input }}', input='foo') }}bar"
    j2_data = to_bytes(j2_data)
    lm = LookupModule()
    # the plugin_dir is not none
    plugin_dir = "test"
    lm.set_loader(plugin_dir)
    variables = dict()
    # the jinja2_native is false
    variables["jinja2_native"] = False
    # the convert_data is false
    variables["convert_data"] = False


# Generated at 2022-06-21 06:38:28.785493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test constructor of class LookupModule"""
    t = LookupModule()
    assert t.run(terms=['path/to/test_file'],
                  variables={'a': {'b': 1, 'c': 2}}) == ['this is a template']

# Generated at 2022-06-21 06:38:31.219501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # _constructor is a private method of LookupBase class
    module = LookupModule()
    # test if module is instance of LookupBase class
    assert isinstance(module, LookupBase)

# Generated at 2022-06-21 06:38:43.206119
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create test only objects.
    class Environment():
        ansible_search_path = None
        ansible_env = None
        ansible_tmpdir = '/tmp/'
        template_host = None
        template_path = None
        template_uid = None
        template_gid = None
        template_mtime = None
        ansible_run_uid = None
        ansible_run_gid = None
        ansible_run_batch = None
        ansible_run_subset = None
        ansible_run_additional_variables = None
        ansible_run_tags = None
        ansible_run_skip_tags = None
        ansible_run_ignore_errors = []
        ansible_run_directory = None
        ansible_check = None
        ansible_verbosity = 0
        ans

# Generated at 2022-06-21 06:38:50.384042
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # check that the lookup class is present
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:38:51.698988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: port test from the template plugin
    pass

# Generated at 2022-06-21 06:39:02.377999
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock environment
    lookup = LookupModule()
    lookup._templar = AnsibleEnvironment()

    # test 1: convert_data=true
    template_string = '{{ 1 + 2 }}'
    template_string_expected = '3'
    terms = [template_string]
    variables = {}
    direct = {'convert_data': True}
    lookup.set_options(var_options=variables, direct=direct)
    result = lookup.run(terms, variables, **direct)
    assert result[0] == template_string_expected, 'test 1 failed'

    # test 2: convert_data=false
    template_string = '{{ 1 + 2 }}'
    template_string_expected = '{{ 1 + 2 }}'
    terms = [template_string]
    variables = {}

# Generated at 2022-06-21 06:39:04.289840
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance != None


# Generated at 2022-06-21 06:39:05.494352
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_instance = LookupModule()

    assert 1 == 1

# Generated at 2022-06-21 06:39:06.030111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:39:07.263358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-21 06:39:14.663095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    import ansible.constants as C
    import json

    lookup_plugin = LookupModule()
    var_manager = VariableManager()
    loader = DataLoader()

    with open('tests/fixtures/lookup_vars/lookup_default.json') as f:
        mock_vars = json.load(f)['variables']

    var_manager.data = mock_vars

    # test 1: no search path given
    lookup_plugin.set_options(var_manager)
    terms = ['inventory_hostname']
    result = lookup_plugin.run(terms, var_manager.data)[0]

# Generated at 2022-06-21 06:39:26.587988
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()

    data1 = b'''
- { role: common, tags: [ 'role::common' ] }
- { role: webserver, tags: [ 'role::webserver' ] }
- { role: dbserver, tags: [ 'role::dbserver' ] }
'''
    b_data2 = b"{{ foo }}"
    data2 = to_text(b_data2, errors='surrogate_or_strict')
    data3 = "{{ foo }}"
    data4 = "{{ foo }}bar"

    terms = [data1, data2, data3, data4]
    variables = {"foo": "Hello World"}
    results = lm.run(terms, variables)

    assert results[0].find("Hello World") == -1
    assert results[0]

# Generated at 2022-06-21 06:39:34.229444
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test the negative case
    lookupBase = LookupBase()
    lookupBase.set_loader(dict(get_basedir=lambda x: '/some/path'))
    lookupBase.set_environment(environment=dict(path='/bin:/usr/bin:/usr/local/bin'))

    with pytest.raises(AnsibleError):
        lookupBase.run(terms=['template_no_exist'], variables=dict(ansible_search_path=['/some/path']))

    # Test variable_start_string and variable_end_string
    lookupBase = LookupBase()
    lookupBase.set_loader(dict(get_basedir=lambda x: '/some/path'))
    lookupBase.set_environment(environment=dict(path='/bin:/usr/bin:/usr/local/bin'))

    result

# Generated at 2022-06-21 06:39:44.586917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:39:46.218855
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_plugin = LookupModule()

    # initializing argument passing
    terms = ""
    variables = ""
    kwargs = ""

    lookup_plugin.run(terms, variables, **kwargs)

# Generated at 2022-06-21 06:39:46.801097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 06:39:55.665701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible import context
    from ansible.context import CLIContext
    context._init_global_context(CLIContext())

    lookup = LookupModule()
    assert lookup.variable_start_string == '{{'
    assert lookup.variable_end_string == '}}'
    assert lookup.comment_start_string == ''
    assert lookup.comment_end_string == ''
    assert not USE_JINJA2_NATIVE or not lookup.jinja2_native
    assert not lookup.convert_data

# Generated at 2022-06-21 06:40:06.754077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    import jinja2
    display = Display()
    display.verbosity = 4
    # Test basic template lookup
    lookup_file = os.path.join(os.path.dirname(__file__), 'files', 'test_lookup_template_basic.j2')
    terms = [ 'test_lookup_template_basic.j2' ]
    variables = { 'a': 1, 'b': 2, 'ansible_inventory_sources': [ lookup_file ], 'ansible_verbosity': 4 }
    jinja_vars_template = jinja2.Template('a = {{ a }}; b = {{ b }}; ansible_verbosity = {{ ansible_verbosity }}')
    jinja_vars = jinja_vars_template.render(**variables)

# Generated at 2022-06-21 06:40:08.636581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin_obj = LookupModule()
    assert hasattr(lookup_plugin_obj, 'run')


# Generated at 2022-06-21 06:40:20.439568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _loader = 'AnsibleModuleLoader'
    _templar = 'Templar'
    _display = 'Display'

    lookupModule = LookupModule(_loader, _templar, _display)

    # terms = ['ansible.cfg']
    # variables = {'ansible_search_path': ['/etc/ansible']}
    # kwargs = {'convert_data': False, 'jinja2_native': False}
    # ret = [b'[defaults]\nhost_key_checking = False']

    terms = ['some_template.j2']
    variables = {'ansible_search_path': ['/etc/ansible']}
    kwargs = {'convert_data': False, 'jinja2_native': False}
    ret = []

    # result = lookupModule

# Generated at 2022-06-21 06:40:21.877499
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert hasattr(mod, 'run')

# Generated at 2022-06-21 06:40:23.730553
# Unit test for constructor of class LookupModule
def test_LookupModule():
     pass

if __name__ == '__main__':
    print(test_LookupModule())

# Generated at 2022-06-21 06:40:33.953776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_executor import TaskExecutor

    class TestStrategy(StrategyBase):
        def __init__(self, tqm):
            super(TestStrategy, self).__init__(tqm)

        def run(self, iterator, play_context):
            return iterator


# Generated at 2022-06-21 06:40:54.250023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:41:06.603884
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import io
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils import plugin_docs
    from ansible.plugins.loader import lookup_loader

    test_vars = VariableManager()
    test_vars.extra_vars = {'foo': 'bar'}

    test_tmpl = Templar(loader=None, variables=test_vars)
    lookup = LookupModule(loader=None, templar=test_tmpl)

    # Load previously-generated test data
    # Data was generated from a combination of the following:
    # ansible-doc -t lookup template
    # ansible-playbook tests/playbooks/test_lookup_template.yml --extra-vars="test_name=multiline_native"
    # ansible-

# Generated at 2022-06-21 06:41:12.974877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys

    class LookupMock:
        def __init__(self):
            self.__lookup = LookupModule()
            self.__lookup.set_loader(LookupMock())

    if sys.version_info < (3,):
        assert isinstance(LookupModule()._templar, to_bytes)
    assert isinstance(LookupMock.set_loader(None), LookupMock)

# Generated at 2022-06-21 06:41:20.160110
# Unit test for constructor of class LookupModule
def test_LookupModule():

    b_template_data = b"{{foo}}"
    lookupfile = u'template_file'

    templar = None
    searchpath = None
    variables = {}
    term = 'template file'

    lookup_plugin = LookupModule()

    lookup_plugin.run(terms=[term], variables=variables, convert_data=True)

    def _get_fakse_file_contents(self, path):
        return b_template_data, None

    lookup_plugin._loader._get_file_contents = _get_fakse_file_contents

    lookup_plugin.run(terms=[term], variables=variables, convert_data=True)
    lookup_plugin.run(terms=[term], variables=variables, convert_data=False)

# Generated at 2022-06-21 06:41:28.920137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    vars_manager = VariableManager()
    lookup_module = LookupModule()

    terms = ["../tests/unit/lookup_plugins/template/testfile.j2"]
    variables = "hostvars['localhost']['ansible_facts']"

    result = lookup_module.run(terms, variables, loader=loader, variables=vars_manager)

    assert result == ['tobeornotobe']



# Generated at 2022-06-21 06:41:38.901284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with use_jinja2_native off in all contexts
    USE_JINJA2_NATIVE_CLEANUP = USE_JINJA2_NATIVE
    USE_JINJA2_NATIVE = False
    # Test data
    lookups = ('template', )
    terms = ('foo.j2', 'bar.j2')
    an_dict = {'test': 'TEST'}
    an_vars = {'test': 'TEST'}
    jinja2_native = False
    # Create objects
    lookup = LookupModule()
    # Test run
    result = lookup.run(terms, an_vars, jinja2_native=jinja2_native, template_vars=an_dict)

# Generated at 2022-06-21 06:41:49.566128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule
    test_lookup = LookupModule()
    # Create instance of AnsibleFileLoader
    test_loader = AnsibleFileLoader()
    # Assign AnsibleFileLoader to test_lookup._loader
    test_lookup._loader = test_loader
    # Create instance of AnsibleTemplate
    test_templar = AnsibleTemplate()
    # Assign AnsibleTemplate to test_lookup._templar
    test_lookup._templar = test_templar

    # Create test term
    test_term = './some_template.j2'
    # Create test terms
    test_terms = [test_term]

    # Create test variables
    test_variables = {'var1': 'val1', 'var2': 'val2'}

    # Create test lookup_template

# Generated at 2022-06-21 06:41:55.756161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.template import LookupModule
    var_options = dict(foo='bar')
    direct = dict(baz='qux')
    lookup_module = LookupModule(var_options=var_options, direct=direct)
    assert var_options == lookup_module.get_option('var_options')
    assert direct == lookup_module.get_option('direct')
    assert 'bar' == lookup_module.get_option('foo')

# Generated at 2022-06-21 06:42:05.258400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    play_context = PlayContext()
    variable_manager = VariableManager()

    # Arrange
    module_name = 'template'
    lookup_module = LookupModule()
    terms = list()
    terms.append('template.j2')
    jinja2_native = False
    convert_data_p = False
    lookup_template_vars = {}
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_

# Generated at 2022-06-21 06:42:15.868656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy data for testing
    class DummyVars:
        def __init__(self):
            self.vars = {
                'template_path': "/tmp",
                'template_mtime': '1234',
            }

    class DummyEnv:
        def __init__(self):
            self.vars = {
                'ansible_search_path': ['/etc/ansible']
            }

    class DummyTerm:
        def __init__(self):
            self.terms = ['templates/some/template']

    # Test passing a template_vars dict
    def test_LookupModule_run1():
        lookup = LookupModule()
        terms = DummyTerm()
        variables = DummyVars()

# Generated at 2022-06-21 06:43:05.872657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # test with jinja2_native global option set to False
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'jinja2_native': False,
    })
    assert lookup.run(terms=['test.j2'], variables={'x': 42}) == ['x = 42']
    # test with jinja2_native global option set to True
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={
        'variable_start_string': '{{',
        'variable_end_string': '}}',
        'jinja2_native': True,
    })

# Generated at 2022-06-21 06:43:14.746483
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = dict(a='a', b='b', c='c')
    lm = LookupModule()
    assert lm._lookup_plugin.name == 'lookup'
    assert lm.run(terms=['test.j2'], variables=data) == []
    assert lm.run(terms=['test.j2'], variables=data, convert_data=True) == []
    assert lm.run(terms=['test.j2'], variables=data, variable_start_string='[%') == []
    assert lm.run(terms=['test.j2'], variables=data, variable_end_string='%]') == []
    assert lm.run(terms=['test.j2'], variables=data, jinja2_native=True) == []

# Generated at 2022-06-21 06:43:20.877840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.builtins import __builtin__
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.lookup.template import LookupModule
    from ansible.template import Templar
    from ansible.template.template import AnsibleEnvironment
    from ansible.vars import VariableManager


# Generated at 2022-06-21 06:43:22.530819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None, "failed to create LookupModule() instance"

# Generated at 2022-06-21 06:43:34.676329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile
    import filecmp

    # create temporary directory
    tmpdir = tempfile.mkdtemp()

    # create files in temporary directory
    with open(os.path.join(tmpdir, "test_file1"), "w") as f:
        f.write('{{ "1234" }}')
    with open(os.path.join(tmpdir, "test_file2"), "w") as f:
        f.write('{{ "{{ ')

    # create search path (temporary directory)
    searchpath = [tmpdir]

    # create variables
    variables = dict()

    # create terms
    terms = ['test_file1', 'test_file2']

    # create lookup template results
    lookup_template_results = ['1234', '{{ ']

    # define

# Generated at 2022-06-21 06:43:38.479308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import textwrap
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.template import Templar
    from ansible.plugins.lookup import LookupModule

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    sample_vars = {"foo": "bar", "baz": "qux"}
    templar = Templar()
    lookup_module = LookupModule()

    # create a file with a template in the temporary directory
    template = "{{foo}} is {{baz}}"
    template_path = os.path.join(tmpdir, "template")
    with open(template_path, 'w') as fh:
        fh.write(to_native(template, errors='surrogate_or_strict'))

# Generated at 2022-06-21 06:43:48.812869
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # ansible_search_path is set by default
    # https://github.com/ansible/ansible/blob/2c868a7713f1c6622c2b2d9489e7dcb07a81bc1a/lib/ansible/constants.py#L65
    ansible_search_path = ['/etc/ansible/ansible-test/1']

    # ansible_templar is set by default
    # https://github.com/ansible/ansible/blob/2c868a7713f1c6622c2b2d9489e7dcb07a81bc1a/lib/ansible/playbook/__init__.py#L256
    # https://github.com/ansible/ansible/blob/2c868a7713f1

# Generated at 2022-06-21 06:43:55.983189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: this test is not complete
    from ansible.module_utils.six.moves import StringIO
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    vault_pass = StringIO('password')
    def mock_find_file_in_search_path(*args, **kwargs):
        return './tests/lookup_plugins/template/template.j2'

    lu = LookupModule({})
    lu.find_file_in_search_path = mock_find_file_in_search_path
    lu._loader = DictDataLoader({'templates/file.j2': 'some_template'})

# Generated at 2022-06-21 06:44:09.471440
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleError
    from ansible.template import generate_ansible_template_vars, AnsibleEnvironment
    from ansible.plugins.loader import lookup_loader, LookupModule
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.jinja2_native import to_text

    display = Display()
    input_data = {
        'a': 'foo',
        'b': 'bar',
        'c': 'baz',
        'd': {
            1: 'foo',
            2: 'bar',
            3: 'baz'
        }
    }

    lookup_plugin = lookup_loader.get('template')

    orig_vars = combine_vars(input_data, {})
    lookup_

# Generated at 2022-06-21 06:44:17.277761
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test that constructor of the LookupModule class is working properly.
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    lookup_plugin = LookupModule() # constructor test
    assert lookup_plugin._templar

# Generated at 2022-06-21 06:45:50.581082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:45:57.151210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test LookupModule._run()
    """
    # load test data
    test_loader = unittest.TestLoader()
    test_suite = test_loader.loadTestsFromTestCase(LookupModuleTest)

    # run the test suite
    test_runner = unittest.TextTestRunner(verbosity=2)
    test_runner.run(test_suite)

# Generated at 2022-06-21 06:46:08.441104
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # create a fake lookup object (not using real ansible plugin system)
    lookup_obj = lookup_loader.get('template', class_only=True)()
    lookup_obj._templar = Templar(None, vault_secrets=VaultLib())

# Generated at 2022-06-21 06:46:09.325531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 06:46:10.867584
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check that the constructor of LookupModule is not throwing an exception
    assert LookupModule()

# Generated at 2022-06-21 06:46:11.413930
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:46:13.839877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test if constructor of LookupModule works."""
    lookup_module = LookupModule()
    assert(isinstance(lookup_module, LookupModule))


# Generated at 2022-06-21 06:46:15.402735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None, "lookup module object should not be None"

# Generated at 2022-06-21 06:46:22.510169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = '''['./test.j2']'''
    # since we do not mock the AnsibleOptions class and we are not actually
    # running a playbook/task/etc, we need to set the following var
    variables = dict(template_dir=["/home/ansible/playbooks/files/templates"])
    config = {}
    # the plugin is looking for a _templar to execute the templating
    lm._templar = AnsibleEnvironment()
    # since AnsibleOptions._get_vars() is a staticmethod we need to mock this
    # staticmethod
    lm.find_file_in_search_path = LookupBase.find_file_in_search_path
    lm._loader = AnsibleLoaderFake()

# Generated at 2022-06-21 06:46:33.056042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    #class attributes
    assert lookup_module._templar is not None
    assert lookup_module._loader is not None

    #options
    lookup_module.set_options(var_options={}, direct={})
    assert lookup_module.get_option('convert_data') is False
    assert lookup_module.get_option('template_vars') == {}
    assert lookup_module.get_option('jinja2_native') is False
    assert lookup_module.get_option('variable_start_string') == '{{'
    assert lookup_module.get_option('variable_end_string') == '}}'
    assert lookup_module.get_option('comment_start_string') == '{#'