

# Generated at 2022-06-21 06:37:47.419545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'password': dict(type='str', no_log=True)})

    module.exit_json(changed=False)

# Generated at 2022-06-21 06:37:56.891488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Creation of the object
    test_LookupModule = LookupModule()
    # Set the attributes we want to test
    test_LookupModule.set_options(var_options={}, direct={'convert_data': False, 'template_vars': {}, 'jinja2_native': False})
    # Testing
    test_terms = ['../../../../../../../../../../../../../../../etc/passwd', '../../../../../../../../../../../../../../../etc/shadow']
    test_variables = {}
    assert test_LookupModule.run(terms=test_terms, variables=test_variables) == []

# Generated at 2022-06-21 06:38:05.968192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test if class correctly interpretes the jinja2 template file
    '''

    class FakeTemplar():

        def __init__(self, base, **kwargs):
            self.base = base
            self.kwargs = kwargs

        def copy_with_new_env(self, environment_class):
            return FakeTemplar(self.base, environment_class=environment_class)

        def template(self, template_data, preserve_trailing_newlines=True, convert_data=False, escape_backslashes=False):
            # Test if base is a instance of AnsibleEnvironment
            # convert_data and escape_backslashes should be False
            assert(isinstance(self.base, AnsibleEnvironment) and convert_data == False and escape_backslashes == False)
            # Test if variable_

# Generated at 2022-06-21 06:38:18.082088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test setup
    import os
    import tempfile
    import shutil
    import contextlib
    import Hashids

    # get the path of the sample directory
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sample_dir = os.path.join(current_dir, "sample")

    # setup the formation of a temp dir
    temp_dir = tempfile.mkdtemp()
    @contextlib.contextmanager
    def temp_dir_cleanup():
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

    # copy the sample to the temp dir
    temp_src = os.path.join(temp_dir, "src")
    temp_dest = os.path.join(temp_dir, "dest")
   

# Generated at 2022-06-21 06:38:21.303891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import doctest
    from ansible.plugins.loader import lookup_loader
    results = doctest.testmod(lookup_loader._lookup_plugins['template'], verbose=False)
    assert results.failed == 0

# Generated at 2022-06-21 06:38:31.635809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    lookup = LookupModule()
    loader = DataLoader()
    variable_manager = VariableManager()
    filename = "./lookup_plugins/template/tests/test_template.j2"
    lookup.set_loader(loader)
    lookup.set_basedir(".")
    lookup._templar.set_available_variables({'test_variable': 'a_value'})
    lookup_template_vars = {}
    result = lookup.run([filename], variable_manager, convert_data=False, template_vars=lookup_template_vars)
    assert result == [u"This is a test for the lookup\n"]
    # enforce the use of the native jinja2 types as text


# Generated at 2022-06-21 06:38:34.454725
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:38:45.052469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['hostname']
    variables = {'hostvars': {'hostname': 'hostname-0', 'hostname-1': {'ip': '192.168.1.1'}}}
    plugin = LookupModule()
    plugin.set_options(var_options=variables)  # setup `self` in plugin
    assert plugin.run(terms, variables) is not None

    terms = ['hostname', 'hostname-1']
    assert plugin.run(terms, variables) is not None

    terms = ['hostname', 'hostname-1']
    variables = {'hostvars': {'hostname': 'hostname-0'}}

    try:
        plugin.run(terms, variables)
    except ValueError:
        pass
    except Exception:
        raise Exception("Should raises ValueError")

# Generated at 2022-06-21 06:38:52.964409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert not l._templar.environment.variable_start_string == '[[', 'variable_start_string should be the default value of "{{"'
    assert not l._templar.environment.variable_end_string == ']]', 'variable_end_string should be the default value of "}}"'
    assert not 'jinja2_native' in l.options or not l.options['jinja2_native'], "jinja2_native should be set to False by default"


# Generated at 2022-06-21 06:39:03.159340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the test
    lookup_module = LookupModule()

    # Test 'convert_data' option is True when global default is True
    args = {'terms': ['./path/to/template'], 'variables': {}, 'convert_data': True}
    result = lookup_module.run(**args)
    assert result is not None

    # Test 'convert_data' option is False when global default is True
    args = {'terms': ['./path/to/template'], 'variables': {}, 'convert_data': False}
    result = lookup_module.run(**args)
    assert result is not None

    # Test 'jinja2_native' option is False when global default is True

# Generated at 2022-06-21 06:39:11.617617
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test constructor of class LookupModule
    """
    import __main__
    import sys
    __main__.display = Display()
    lookup_plugin = LookupModule()
    lookup_plugin.run([], dict(variables=dict()), undefined_variable="foo")
    sys.exit(0)

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:39:22.896921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test of method run of class LookupModule')
    # Initialization
    display = Display()
    display.verbosity = 4
    lookup_module = LookupModule(loader=None, templar=None, **{})

    # First test: with one empty term
    # Expected result: error
    terms = []
    variables = {}
    kwargs = {}
    ret = lookup_module.run(terms, variables, **kwargs)
    if ret != TermsMissingError.message:
        print("Test of method run of class LookupModule: FAIL")
    else:
        print("Test of method run of class LookupModule: PASS")

    # Second test: with one non-existing term
    # Expected result: error
    terms = ['non_existing_file']
    variables = {}
    kwargs = {}

# Generated at 2022-06-21 06:39:32.326570
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with terms as a string
    lookup_module = LookupModule()
    lookup_module._templar = "Templar"

    mock_self_run = {
        "_loader": {
            "_get_file_contents": (b"file contents", "mock_file_name")
        },
        "find_file_in_search_path": lambda x, y, z: "/path/to/playbook/templates/test.yml"
    }


# Generated at 2022-06-21 06:39:33.525091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 06:39:46.704560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({
        'some_template.j2': 'Hello World!',
        'some_other_template.j2': 'Bye World!',
    })
    terms = ['some_template.j2', 'some_other_template.j2']

    # with dict of template_vars
    variables = {'var': 'value'}
    result = lookup_module.run(terms=terms, variables=variables, convert_data=True, template_vars={'var': 'value'})
    assert result == ['Hello World!', 'Bye World!']

    # with empty dict of template_vars
    variables = {'var': 'value'}

# Generated at 2022-06-21 06:39:47.939147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:39:54.735694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    term = 'test_term'
    terms = [term]

    # Test with normal arguments
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

    results = lookup.run(terms=terms, variables={})
    assert len(results) == 1
    assert results[0] is None

# Generated at 2022-06-21 06:39:56.136902
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj


# Generated at 2022-06-21 06:40:08.096068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    lm = LookupModule()

    terms = ['./my_template.j2']
    variables = dict()

    display = Display()
    display.debug = True
    display.vvvv = True
    display.verbosity = 4

    dummy_env_class = pytest.Mock()
    dummy_env_class.return_value = ""

    def import_module(name, *args, **kwargs):
        if name == 'ansible.template':
            class DummyModule:
                @staticmethod
                def generate_ansible_template_vars(term, lookupfile):
                    return {}
            return DummyModule

        return __import__(name, *args, **kwargs)

    dummy_tmplar = pytest.Mock()
    dummy_tmplar.copy_with_new

# Generated at 2022-06-21 06:40:13.703298
# Unit test for constructor of class LookupModule
def test_LookupModule():
  import os

  x = LookupModule()
  # Get the upper directory to the 'ansible' directory
  x.set_basedir(os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir)))
  y = x.run(['./lib/ansible/plugins/lookup/template.py'],
      variable_start_string='[%', variable_end_string='%]',
      comment_start_string='[#', comment_end_string='#]')

# Generated at 2022-06-21 06:40:28.794005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arguments
    lookup = LookupModule()
    lookup.set_loader(dict())
    lookup_options = {}
    template_vars = {}
    variables = {}
    templar = lookup._templar

    # test code
    # case 1 : check simple template
    terms = ['template1.j2']
    template_data = """
        # Jinja2 template for testing lookup plugin
        Case1 : simple template: {{ test_variable }}

    """

    variables['test_variable'] = 'hi'

    b_template_data = to_bytes(template_data)
    lookupfile = 'template1.j2'
    searchpath = ['/home/test']


# Generated at 2022-06-21 06:40:30.209335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 06:40:40.247589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.tm = LookupModule()
            self.tm._templar = Mock()
            self.tm._loader = Mock()

        @patch('ansible.plugins.lookup.LookupBase.get_option')
        @patch('ansible.template.generate_ansible_template_vars')
        def test_tm_run(self, mock_generate_ansible_template_vars, mock_get_option):
            mock_generate_ansible_template_vars.return_value = True
            mock_get_option.return_value = True
            self.tm._loader._get

# Generated at 2022-06-21 06:40:51.299001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import tempfile
    import shutil
    import os
    import json

    class LookupModuleTest(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.example_yaml = '{"test": "{{test_var}}"}'
            self.example_json = '{"test": "{{test_var}}"}'

        def tearDown(self):
            try:
                shutil.rmtree(self.test_dir)
            except OSError:
                pass

        def create_valid_lookup_file(self, filetype):
            if filetype == "yaml":
                lookup_file = os.path.join(self.test_dir, "lookup.yaml")

# Generated at 2022-06-21 06:40:55.092432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:40:56.555345
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup is not None

# Generated at 2022-06-21 06:41:01.133887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('convert_data') == False
    assert lookup.get_option('template_vars') == {}
    assert lookup.get_option('variable_start_string') == '{{'
    assert lookup.get_option('variable_end_string') == '}}'

# Generated at 2022-06-21 06:41:02.707540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    return lookup_module

# Generated at 2022-06-21 06:41:05.251914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(LookupBase(), ['test_template', 'no_template'], [''], _loader=None)[0]
    assert result == 'template_worked'

# Generated at 2022-06-21 06:41:11.643558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    print(module.run(['./whatever'], {},
                     convert_data=False,
                     lookup_template_vars={},
                     jinja2_native=False,
                     variable_start_string='{{',
                     variable_end_string='}}',
                     comment_start_string='{#',
                     comment_end_string='#}'))

# Generated at 2022-06-21 06:41:26.504983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(['ansible/test/lookup_plugins/termlist.j2'], {'a': 'b', 'c': 'd'})
    assert ret == [u'abcd']

# Generated at 2022-06-21 06:41:37.120851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    lookupModule = LookupModule()
    # create a dict to pass to the module
    term = './some_template.j2'
    kwargs = {'foo': 'bar'}
    # define the variable for the search path (normally defined in ansible.cfg)
    path = './'
    variables = {'ansible_search_path': [path]}
    display.debug("File lookup term: %s" % term)
    # execute the run method of LookupModule passing our term and path as arguments
    ret = lookupModule.run(terms = term, variables = variables, **kwargs)
    # ensure we got a match for our term
    assert ret.__len__() == 1
    # check to ensure that the item in the return matches our term

# Generated at 2022-06-21 06:41:44.512199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for template
    templar = Dict({'ansible_search_path': ['/home/ansible/', '/etc/ansible'], 'test': '1234'})
    loader = Dict()
    lookup = LookupModule(loader=loader, templar=templar)
    lookup._loader.file_find = lambda _1, _2, _3: '/etc/ansible/templates/test/test.conf'
    lookup._loader._get_file_contents = lambda _: (b'{{ test }}\n', False)
    variables = Dict()
    terms = ['test/test.conf']
    result = lookup.run(terms=terms, variables=variables, convert_data=True)
    assert result == ['1234\n']

# Generated at 2022-06-21 06:41:48.568911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None
    lookup.run(terms=[], variables={}, **{})


# Generated at 2022-06-21 06:41:49.204798
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup
    assert lookup.run

# Generated at 2022-06-21 06:41:59.853476
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Create a test stub for the Display class
    class DisplayStub:
        def __init__(self):
            self._display.verbosity = 3
        def debug(self, msg):
            assert msg == "File lookup term: ./some_template.j2"

    #Create a test stub for the to_text method
    def to_textStub(msg):
        if msg == b_template_data:
            return "a test stub"

    #Create a test stub for the jinja2.Environment class
    class EnvironmentStub:
        def __init__(self):
            self.variable_start_string = '{{'
            self.variable_end_string = '}}'
            self.comment_start_string = None
            self.comment_end_string = None

# Generated at 2022-06-21 06:42:05.289579
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'convert_data': True})
    lookupfile = lookup_module.find_file_in_search_path({}, 'templates', 'test.j2')
    assert lookupfile == '/usr/local/ansible/test.j2'
    lookup_module.run(['test.j2'], {'test': 'test'})
    assert lookup_module.run([], {}) == []

# Generated at 2022-06-21 06:42:12.769886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_args = dict(
        _terms=['/tmp/foo.j2'],
        convert_data=True,
        template_vars=dict(tag='molecule'),
        comment_start_string='[#',
        comment_end_string='#]',
        variable_start_string='[%',
        variable_end_string='%]'
    )
    lookup_plugin = LookupModule()
    lookup_plugin.options = module_args
    assert lookup_plugin

# Generated at 2022-06-21 06:42:19.012097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.plugin_docs import get_docstring, get_docstring_examples

    test_defaults = {
      'convert_data': True,
      'variable_start_string': '{{',
      'variable_end_string': '}}',
      'template_vars': None,
      'comment_start_string': None,
      'comment_end_string': None,
      'jinja2_native': True,
    }

# Generated at 2022-06-21 06:42:21.345166
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm #should not raise exception

# Generated at 2022-06-21 06:42:51.169962
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    #Simulate the internal states of LookupBase
    module._templar = None
    module._loader = None
    module._lookup_loader = None
    module._display = None
    module._options = None
    module._basedir = None
    module._main_parent_dir = None
    module._main_playbook_path = None
    module._loader_cache = None
    module._use_task_workdir = None
    module._playbook_workdir = None
    module._play_context = None

    #Simulate the internal states of LookupBase with method copy
    module.copy()

    results = module.run(terms=[], variables={})
    assert results == []

# Generated at 2022-06-21 06:42:59.836889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit tests for Ansible's lookup/template.py.
    """
    # Test loading of a template file that exists
    term = 'vars.j2'
    terms = [term]
    lookup_template_vars = {'name': 'Charlie', 'pets': ['Nemo', 'Dory']}
    variables = {'variable_start_string': '%%', 'variable_end_string': '%%'}
    test_module = LookupModule()
    result = test_module.run(terms=terms, variables=variables, template_vars=lookup_template_vars)
    assert result[0] == "Hello, %%name%%! Your pets are: %%pets.0%%, %%pets.1%%\n"

    # Test loading of a template file that does not exist

# Generated at 2022-06-21 06:43:00.731118
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()

# Generated at 2022-06-21 06:43:11.690541
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import constants as C

    # test normal run
    m = LookupModule()
    terms = [ './plugins/lookup/test_template.j2' ]
    assert m.run(terms, dict(a='a'), convert_data=True, jinja2_native=True)[0] == 'abc\n'
    assert m.run(terms, dict(a='a'), convert_data=True, jinja2_native=False)[0] == 'abc\n'
    assert m.run(terms, dict(a='a'), convert_data=False, jinja2_native=True)[0] == '{% raw %}\na\n{% endraw %}\n'

# Generated at 2022-06-21 06:43:15.359992
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        templar = LookupModule()
    except:
        assert False, 'Unable to create instance of LookupModule'



# Generated at 2022-06-21 06:43:16.907676
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # test constructor of class LookupModule

# Generated at 2022-06-21 06:43:28.889875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    items = [
        {
            'name': 'test',
            'connection': 'local',
            'hosts': 'all',
            'gather_facts': 'no',
            'tasks': [
                {
                    'template': 'test',
                    'with_items': ['test0.j2', 'test1.j2'],
                    'register': 'template_result',
                    'failed_when': False,
                },
            ]
        }
    ]

    variable_manager = VariableManager()
    loader = DataLoader()
   

# Generated at 2022-06-21 06:43:30.036402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupBase)

# Generated at 2022-06-21 06:43:40.349169
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule, initialize it and set its
    # jinja2_native option to True
    lookup_module = LookupModule()
    lookup_module.set_options({'jinja2_native': True})
    # Set templar to a jinja2.Environment with jinja2_native option to True
    # and a NativeJinjaText object as environment_class
    lookup_module._templar = lookup_module._templar.copy_with_new_env(environment_class=NativeJinjaText)
    # Initialize a variables dictionary
    variables = {
        'foo': 'bar',
        'ansible_lookup_plugin': 'lookup_defaults'
    }
    # Define a search path for the lookup module

# Generated at 2022-06-21 06:43:41.177033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add tests
    pass

# Generated at 2022-06-21 06:44:36.461619
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 06:44:37.195077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO
    assert True

# Generated at 2022-06-21 06:44:38.003279
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert True

# Generated at 2022-06-21 06:44:42.616758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    failed = False

# Generated at 2022-06-21 06:44:50.910487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing 'template' lookup
    #
    # Method: run
    #
    # Unit tests are not required to test private methods or methods
    # which are overridden.
    #
    # The 'template' lookup is intended to return an array of strings
    # which contain the template output.
    #

    lookup = LookupModule()
    lookup.set_loader({})
    lookup.set_templar({})

    # test handles valid input
    lookup._loader.get_basedir = lambda: ''
    lookup._loader._search_paths = lambda: ['']
    terms = [ 'test.j2' ]
    ret = lookup.run(terms,
                     dict(ansible_search_path=['./testdata']),
                     convert_data=False)
    assert ret[0] == '{{ foo }}'

   

# Generated at 2022-06-21 06:45:02.735725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for legacy YAML behaviour where lists are always returned
    # as lists and scalar values are both returned as str and unicode

    lookup_instance = LookupModule()

    # Set up environment variables

# Generated at 2022-06-21 06:45:14.039061
# Unit test for constructor of class LookupModule
def test_LookupModule():

    test_path = os.path.dirname(os.path.realpath(__file__))
    test_dir = "test_dir"
    test_dir_path = os.path.join(test_path, test_dir)
    os.mkdir(test_dir_path)
    test_file_path = os.path.join(test_dir_path, "test_file")
    test_file_data = "test data"
    with open(test_file_path, "w") as f:
        f.write(test_file_data)

    # Create a valid ansible options object
    options = {"basedir": ".", "fqcn": True, "module_path": "./modules"}

    # Create a valid ansible inventory object
    inventory = None

    # Create a valid ansible cache object
    cache

# Generated at 2022-06-21 06:45:25.024672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  import os
  import tempfile
  import ansible.module_utils.six as six
  from ansible.module_utils.six import StringIO, b
  from ansible.module_utils.six.moves import configparser
  from ansible.parsing.vault import VaultLib
  from ansible.parsing.vault import VaultSecret
  from ansible.parsing.vault import VaultPassword
  from ansible.parsing.vault import is_encrypted
  from ansible.plugins.lookup import LookupBase
  from ansible.template import generate_ansible_template_vars, AnsibleEnvironment, USE_JINJA2_NATIVE
  from ansible.module_utils._text import to_bytes, to_text
  from ansible.utils.hashing import md5s, checksum_s


# Generated at 2022-06-21 06:45:29.469188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['./some_template.j2']
    variables = {}
    l = LookupModule()
    l.set_loader(None)
    assert l.run(terms, variables, convert_data=False,
                 variable_start_string='[%', variable_end_string='%]') == ['some template']

# Generated at 2022-06-21 06:45:34.595071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    variables = dict()
    variables['hostvars'] = dict()
    terms = ['../../lib/ansible/plugins/lookup/template.py']
    result = plugin.run(terms, variables)
    assert '# (c) 2012-17, Ansible Project' in to_text(result)

# Generated at 2022-06-21 06:47:17.470770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # It's not a good idea to rely on indirect tests for the lookup modules.
    # Either write a direct test or a true functional test.
    raise NotImplementedError

# Generated at 2022-06-21 06:47:20.765675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """This function is used to test constructor of class LookupModule."""
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:47:21.873986
# Unit test for constructor of class LookupModule
def test_LookupModule():
  """Test constructor of LookupModule"""
  lookup_module = LookupModule()

# Generated at 2022-06-21 06:47:28.619159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    f = dict(lookup_template_vars=dict(foo="bar"),)
    display.verbosity = 4
    assert lookup.run(["/tmp/example.txt", ], dict(ansible_search_path=["/usr/local/ansible"]), **f) == [u'#template:jinja\nfoo=bar']
    #assert lookup.run(["/tmp/example.txt", ], dict(ansible_search_path=["/usr/local/ansible"]), allow_unsafe=False, **f) == [u'#template:jinja\nfoo=bar']

# Generated at 2022-06-21 06:47:36.728487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.errors
    import sys

    if sys.version_info < (2, 7):
        pytest.skip("Jinja2 native types is only supported on Python 2.7+")

    assert LookupModule(None, None).run(["./my/path/myfile"], dict(convert_data=False)) == [u'{{ foo }}']
    assert LookupModule(None, None).run(["./my/path/myfile"], dict(convert_data=False, jinja2_native=True)) == [None]

    with pytest.raises(ansible.errors.AnsibleError):
        assert LookupModule(None, None).run(["myfile"], dict())