

# Generated at 2022-06-21 06:37:57.091814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Handle both ansible.module_utils.py3compat and ansible.module_utils.six imports
    try:
        from ansible.module_utils.six import PY2
    except ImportError:
        import sys
        # ansible.module_utils.six could not be imported, look for python 2.7 as fallback
        if sys.version_info[0] == 2 and sys.version_info[1] == 7:
            PY2 = True
        else:
            PY2 = False
    if PY2:
        # ansible.module_utils.py3compat is not available on python 2.7, so import string and builtins
        import __builtin__ as builtins
        import string

# Generated at 2022-06-21 06:38:06.417832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the method run of class LookupModule
    # without the "convert_data".
    # The type of result is string
    # The template file simple.j2 is in the same directory as test_jinja2_lookup.py.
    lookup = LookupModule()
    result = lookup.run(terms=['simple.j2'], variables={'host': 'host1'})
    assert result == ["host1"]

    # Test the method run of class LookupModule
    # with the "convert_data" by setting the lookup_options.
    # The type of result is dict
    lookup.set_options(direct={'convert_data': True})
    result = lookup.run(terms=['convert.j2'], variables={'host': 'host1'})

# Generated at 2022-06-21 06:38:09.265895
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    constructor of LookupModule
    :return:
    """

    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 06:38:10.316347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:38:21.623559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test that the correct jinja2_native flag is passed to AnsibleEnvironment
    """

    import sys
    import tempfile
    import textwrap

    try:
        # python2
        import mock
    except ImportError:
        # python3
        from unittest import mock

    # This test asserts that the correct jinja2_native flag is passed to AnsibleEnvironment
    # for the lookup module.
    #
    # This can be tested by mocking the following calls:
    #
    # - `set_temporary_context` to capture the environment class
    # - `AnsibleEnvironment` constructor to capture the flag value
    #
    # Since `AnsibleEnvironment` is imported by the lookup, we cannot simply conditionally
    # import the mock library and patch it.
    #
    # Instead, work around this limitation

# Generated at 2022-06-21 06:38:23.695099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return True

# Generated at 2022-06-21 06:38:25.107913
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj._display == display

# Generated at 2022-06-21 06:38:26.735150
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: apply some unittest to this class
    pass

# Generated at 2022-06-21 06:38:29.250725
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    assert lm.run == LookupModule.run
    assert lm._loader._load_file == LookupBase._loader._load_file

# Generated at 2022-06-21 06:38:41.188975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #####################################################################
    #                                                                   #
    #   Test the main use case of this plugin, which is to simply       #
    #   read a text file and return its content.                        #
    #                                                                   #
    #####################################################################

    # Prepare the test and set up an array of terms to be used as parameters to the method.
    # The array contains the name of a text file that will be processed.
    test_obj = LookupModule()
    test_obj.set_loader(DictDataLoader({'test_template': '123'}))

# Generated at 2022-06-21 06:38:55.926589
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a template path to test
    import tempfile
    test_template_path = tempfile.mktemp(dir='/tmp')
    f = open(test_template_path, 'w')
    f.write("{{ myvar }}")
    f.close()

    # Create a lookup module
    lm = LookupModule()
    lm.set_options(direct={})

    # Try to find the template using the generated module
    assert(lm.find_file_in_search_path({}, 'templates', test_template_path))

    # Clean-up the test template
    os.remove(test_template_path)

# Generated at 2022-06-21 06:39:01.111758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native

    module = AnsibleModule(argument_spec={
        'template_vars': dict(type='dict'),
    })

    lookup_plugin = LookupModule()
    lookup_plugin.set_options(module.params)

# Generated at 2022-06-21 06:39:02.053267
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:39:04.836624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a object for the class
    obj = LookupModule()

    if USE_JINJA2_NATIVE:
        assert isinstance(obj._templar, NativeJinjaText)
    else:
        assert isinstance(obj._templar, str)

# Generated at 2022-06-21 06:39:08.237321
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print ("Running test_LookupModule...")
    ls = LookupModule()
    ls.set_options(var_options={}, direct={})
    ls.run(terms="some_template.j2")

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:39:16.899480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: This unittest needs to be converted to a unit test that actually
    #        runs L{lookup_file_for_template} in the context of a Task in a
    #        Play.
    #
    # This unittest was written to test the fix for issue #32859.  If you
    # modify this unittest, make sure the changes don't Re-introduce that bug.

    # Create a MockFsLoader object that returns a fake template file path for the template name
    # file_name_to_path is a dict of {'file_name': 'file_path'}
    def fake_loader_get_file_contents(file_name_to_path):
        class MockFsLoader:
            def get_basedir(self, task_vars):
                return '.'

# Generated at 2022-06-21 06:39:20.452936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['./some_template.j2']
    variables = {}
    kwargs = dict()
    lookup.run(terms,variables,**kwargs)

# Generated at 2022-06-21 06:39:30.811810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils import context_objects as co
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import lookup_loader, action_loader

    # set the 'ansible_search_path' variable to a known path
    options = {
        'variable_start_string': u'{{',
        'variable_end_string': u'}}',
        'convert_data': True,
        'jinja2_native': False,
    }
    options_plain = {
        'variable_start_string': u'{{',
        'variable_end_string': u'}}',
        'convert_data': False,
        'jinja2_native': False,
    }
    options_no

# Generated at 2022-06-21 06:39:31.585461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-21 06:39:34.222284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['./some_template.j2']
    variables = {}
    result = LookupModule().run(terms, variables)
    result = result
    assert (result == [''])


# Generated at 2022-06-21 06:39:47.111490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiation
    lm = LookupModule()
    # the following properties should be defined
    assert lm.run
    assert lm.set_options

# Generated at 2022-06-21 06:39:53.284006
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Start test_LookupModule')

    test_lookup = LookupModule()

# Generated at 2022-06-21 06:39:57.231117
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup = LookupModule()
    term = "test_term"

    # Act and Assert
    try:
        lookup.run([term], {})
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-21 06:39:58.205724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:39:59.514764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L is not None

# Generated at 2022-06-21 06:39:59.871146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:40:04.057414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a test environment
    env = dict()
    env['ANSIBLE_DEBUG'] = 'True'

    # Create a test loader
    loader = dict()

    # Create a test templar
    templar = dict()

    # Instantiate the lookup module class
    lm = LookupModule(loader=loader, templar=templar, env=env)

    # Check that the options have not been set
    assert lm.convert_data is None
    assert lm.template_vars is None
    assert lm.variable_start_string is None
    assert lm.variable_end_string is None
    assert lm.comment_start_string is None
    assert lm.comment_end_string is None

    # Create a var options dict
    var_options = dict()

    # Create a direct options

# Generated at 2022-06-21 06:40:10.461636
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['jinja2template.j2']
    variables = { 'var1': 'from_var' }
    kwargs = {}
    lookup_obj = LookupModule()
    result = lookup_obj.run(terms, variables, **kwargs)
    assert result[0] == 'template: jinja2template.j2\nlookup_file: jinja2template.j2\nvar1: from_var\n'

# Generated at 2022-06-21 06:40:14.561194
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        l = LookupModule()
    except Exception as e:
        pytest.fail(msg="""
        The LookupModule() class constructor raised an exception.
        The exception is: {}
        """.format(e))

# Generated at 2022-06-21 06:40:18.133951
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate an instance of LookupModule
    lookup_module_instance = LookupModule()
    # Test constructor of class LookupModule
    assert isinstance(lookup_module_instance, LookupModule)

# Generated at 2022-06-21 06:40:46.872118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ './my_template.j2' ]
    variables = {}
    variables['_raw_params'] = './my_template.j2'
    variables['_original_file'] = './my_template.j2'
    variables['template_dir'] = 'templates'
    variables['template'] = './my_template.j2'
    result = lookup_module.run(terms, variables)
    assert result == []

# Generated at 2022-06-21 06:40:54.853734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """
    import tempfile
    import os
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins as __builtin__
    from ansible.parsing.mod_args import ModuleArgsParser

    class FakeVarsModule(object):
        def __init__(self, ansible_args):
            self.params = ModuleArgsParser.get_module_args(ansible_args)

    orig_open = open

    class FakeOpen(object):
        def __init__(self):
            self.fd = -1
            self.name = ""

        def __call__(self, path, flag):
            self.fd

# Generated at 2022-06-21 06:41:07.117862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    I(a2_unit_test) to test method run implemented by LookupModule inherited class
    """
    # Below data is based on test/test_templating.py
    from ansible.template import Jinja2Template

    assert Jinja2Template.env.has_plugin('convert_yaml_to_data')
    assert Jinja2Template.env.has_plugin('convert_data_to_yaml')

    # set up env
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(dict(convert_data=True))
    templar = lookup_plugin._templar
    templar.set_available_variables({'foo': 'bar'})

    env = Jinja2Template.env.copy()
    env.variable_start_string = '@'


# Generated at 2022-06-21 06:41:09.002691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except AnsibleError:
        pass
    else:
        assert False

# Generated at 2022-06-21 06:41:18.373647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = FakeLoader()
    lookup_module._templar = FakeTemplar()
    lookup_module.set_options(var_options={}, direct={})
    display.debug = lambda msg: None

    # test not found
    lookupfile = './not_found.j2'
    lookupfile_found = lookup_module.find_file_in_search_path({}, 'templates', lookupfile)
    assert not lookupfile_found
    with pytest.raises(AnsibleError) as exec_info:
        lookup_module.run([lookupfile], {})
        assert "the template file ./not_found.j2 could not be found for the lookup" in str(exec_info.value)


# Generated at 2022-06-21 06:41:20.875838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:41:23.530031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == "LookupModule"
    assert LookupModule.__doc__ == LookupBase.__doc__

# Generated at 2022-06-21 06:41:24.898473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:41:25.962873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _ = LookupModule()


# Generated at 2022-06-21 06:41:36.566226
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    from ansible.plugins.lookup.lookup import LookupModule
    from ansible.template import Template
    from ansible.parsing.ajson import AnsibleJSONEncoder

    from ansible.module_utils.six import StringIO

    # variables, default to an empty dict
    vars = dict()

    # lookup_template_vars
    lookup_template_vars = dict()
    lookup_template_vars["greeting"] = "Hello"

    # template_data, with a placeholder for the greeting
    template_data = "in a galaxy far, far away: {{ greeting }}\n"

    b_template_data = to_bytes(template_data, errors='surrogate_or_strict')

    # test display class

# Generated at 2022-06-21 06:42:19.607487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO, implementation of test required
    assert False

# Generated at 2022-06-21 06:42:30.579181
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create a new LookupModule.
    lm = LookupModule()

    # Create the dummy opts object.
    class Options():
        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self, k, v)

    # Create the dummy args object.
    class Args():
        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self, k, v)

    # Create the dummy other object.
    class Other():
        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self, k, v)


# Generated at 2022-06-21 06:42:41.046534
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mocks
    class MockTemplar:
        pass

    class MockSearchPath:
        def __init__(self, lookup_path):
            self.lookup_path = lookup_path

        def __call__(self, *args, **kwargs):
            return self.lookup_path

    class MockLoader:
        def _get_file_contents(self, filepath):
            return ('sample data', True)

    class MockVariables:
        search_path = '/path/test'

    # test
    lookup_class = LookupModule()
    lookup_class._loader = MockLoader()
    lookup_class._templar = MockTemplar()
    lookup_class._get_search_paths = MockSearchPath('/path/test')

    # test

# Generated at 2022-06-21 06:42:43.775366
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:42:45.365846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm


# Generated at 2022-06-21 06:42:46.347510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:42:47.630937
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup


# Generated at 2022-06-21 06:42:58.345299
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible import context
    from ansible.template import Templar

    class Options(object):
        __slots__ = ('variable_start_string', 'variable_end_string', 'convert_data', 'jinja2_native',
                     'template_vars', 'comment_start_string', 'comment_end_string')
        def __init__(self):
            self.variable_start_string = None
            self.variable_end_string = None
            self.convert_data = None
            self.jinja2_native = None
            self.template_vars = None
            self.comment_start_string = None
            self.comment_end_string = None

    class FakeVars(object):
        def __init__(self):
            self._data = dict()

    # test that set_options() function works

# Generated at 2022-06-21 06:43:09.960435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Patch for get_option method
    def get_option(self, key):
        if key == 'convert_data':
            return True
        if key == 'template_vars':
            return {}
        if key == 'jinja2_native':
            return False
        if key == 'variable_start_string':
            return '{{'
        if key == 'variable_end_string':
            return '}}'
        if key == 'comment_start_string':
            return '{#'
        if key == 'comment_end_string':
            return '#}'
    LookupModule.get_option = get_option

    # Patch for find_file_in_search_path method

# Generated at 2022-06-21 06:43:13.027049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 06:45:02.736690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    options = {
        'variable_start_string': '[%',
        'variable_end_string': '%]',
        'return_native_value': True,
        'lookup_template_vars': {'key': 'value'}
    }
    variable_manager = VariableManager()
    loader = DataLoader()
    variables = variable_manager.get_vars(play=PlayContext(), loader=loader, options=options)
    templar = Templar(loader=loader, variables=variables)

# Generated at 2022-06-21 06:45:13.983269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display
    x = Display()
    x.verbosity = 4
    source = LookupBase()
    source.set_loader({})
    source.set_templar({})

    assert isinstance(source, LookupBase)

    templar = AnsibleEnvironment(loader=source._loader, variable_start_string="{{",
                                 variable_end_string="}}", block_start_string="{%",
                                 block_end_string="%}")
    ver = (2, 11)
    templar._jinja2_native = USE_JINJA2_NATIVE and templar._get_version() >= ver
    templar.searchpath = ['.']
    source = LookupModule()

# Generated at 2022-06-21 06:45:20.522987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test return of LookupModule.run method
    # expected return: list of file contents
    # create data structures to create test environment
    class OptionsModule:
        convert_data = False
        template_vars = {}
        jinja2_native = None
        variable_start_string = '{{'
        variable_end_string = '}}'
        comment_start_string = None
        comment_end_string = None

    class VarsModule:
        ansible_search_path = []

    class DisplayModule:
        verbosity = 5

    # Create a test class to sub in for the LookupBase class, which requires
    # an overridden load method, which is empty for our test.
    class TestLookupBase:
        def __init__(self):
            return None


# Generated at 2022-06-21 06:45:21.918604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:45:23.981370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # TODO: Test LookupModule.run()
    # lookup.run(terms=[], variables={}, **kwargs)

# Generated at 2022-06-21 06:45:35.650162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule
    '''

    from ansible.plugins.lookup import LookupModule
    import json
    
    lm = LookupModule()
    terms = ['unittest_template_data.json']


# Generated at 2022-06-21 06:45:38.150562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with the default constructor
    LookupModule()

    # Test with a specific basedir
    LookupModule(basedir='/tmp/test')

# Generated at 2022-06-21 06:45:39.178659
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:45:47.719985
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # All parameters are empty and no additional parameters were passed
    # The class should behave as if it was constructed like this:
    #   template = LookupModule()
    template = LookupModule(loader=None, templar=None, shared_loader_obj=None)

    # This is the normal return from the run() method
    # _terms, which is the first parameter for run(), is a list and contains
    # only one string:
    #   './some_template.j2'
    # variables is the second parameter for run() and is a dictionary:
    #   variables = '{{ lookup_opts }}'
    #   lookup_opts = '{ convert_data: True }'
    # The third parameter is an empty dictionary, no additional options
    # were passed.
    #
    # The return should be a list, containing one element

# Generated at 2022-06-21 06:45:56.748539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)
    assert instance.get_option('convert_data') is True
    assert instance.get_option('template_vars') == {}
    assert instance.get_option('jinja2_native') is False
    assert instance.get_option('variable_start_string') == '{{'
    assert instance.get_option('variable_end_string') == '}}'
    assert instance.get_option('comment_start_string') == ''
    assert instance.get_option('comment_end_string') == ''