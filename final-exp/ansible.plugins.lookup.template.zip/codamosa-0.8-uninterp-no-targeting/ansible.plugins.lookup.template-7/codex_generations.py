

# Generated at 2022-06-21 06:37:55.077365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.lookup import lookup_loader
    from ansible.utils.display import Display

    v = VariableManager()
    v.extra_vars = {'myvar': 'myvalue'}

    display = Display()
    display.verbosity = 4

    lookup = lookup_loader.get('template')

    myvar = {
        'a': 'b',
        'c': 'd'
    }

    assert lookup._loader is None

    # ansible/ansible#33991 - No vault secret available


# Generated at 2022-06-21 06:37:56.939221
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None



# Generated at 2022-06-21 06:37:57.504804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "TODO: Write unit tests"

# Generated at 2022-06-21 06:38:00.117724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the constructor of class LookupModule.
    """
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 06:38:10.870150
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # The constructor of ansible.plugins.lookup.LookupBase takes the following parameters:
    # basedir = os.getcwd()
    # loader = None
    # templar = None
    # variables = dict()

    # Mock the necessary variables
    mock_variables = {
        'ansible_search_path': ['../test/units/fixtures/lookup_plugins'],
        'inventory_dir': '../test/units/fixtures/lookup_plugins',
        'role_path': '../test/units/fixtures/lookup_plugins',
        'vars': dict()
    }
    mock_loader = None
    mock_templar = None

    # Create an object of LookupModule

# Generated at 2022-06-21 06:38:12.214300
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 06:38:23.855203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class Vars(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class Loader(object):
        def __init__(self, _get_file_contents_result):
            self._get_file_contents_result = _get_file_contents_result

        def _get_file_contents(self, path):
            return self._get_file_contents_result

    class LookupBase(object):
        def __init__(self, loader, template_data=None, jinja2_convert=False):
            self._loader = loader

# Generated at 2022-06-21 06:38:31.779276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test: Execute method run() of class LookupModule
    #  with following input:
    #    terms=['./file_not_found.j2'], variables={}
    #  expected result: exception AnsibleError with following message:
    #    'the template file ./file_not_found.j2 could not be found for the lookup'
    lookup = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        print(lookup.run(['./file_not_found.j2'], {}))

    assert excinfo.match("the template file ./file_not_found.j2 could not be found for the lookup")

# Generated at 2022-06-21 06:38:43.306869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['some_template.j2']

# Generated at 2022-06-21 06:38:46.947847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run') == True
    assert hasattr(lookup, 'set_options') == True
    assert hasattr(lookup, 'get_option') == True

# Generated at 2022-06-21 06:39:02.378180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with open('fixtures/file_lookup_plugin_fixture.j2', 'r') as f:
        template_file_data = f.read()

    with open('fixtures/file_lookup_plugin_test.yml', 'r') as f_yaml:
        test_yaml = f_yaml.read()

    with open('fixtures/file_lookup_plugin_test.xml', 'r') as f_xml:
        test_xml = f_xml.read()

    f_list = {'fixtures/file_lookup_plugin_fixture.j2': template_file_data,
              'fixtures/file_lookup_plugin_test.yml': test_yaml,
              'fixtures/file_lookup_plugin_test.xml': test_xml}


# Generated at 2022-06-21 06:39:04.242859
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    print(dir(result))

# Generated at 2022-06-21 06:39:14.717748
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for method run of class LookupModule with parameters: [{'src': './my_template.j2'}]
    j2_t = open('./my_template.j2', 'r')
    j2_t_content = j2_t.read()
    j2_t.close()
    terms = [{
                'src': './my_template.j2',
                'dest': './template.out'
            }]
    lu = LookupModule()
    variables = {'foo': 'bar'}

    result = lu.run(terms, variables, convert_data=False, template_dir='./')
    assert result[0] == j2_t_content
    assert result[0].find('{{') == -1

# Generated at 2022-06-21 06:39:15.277966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:39:16.945052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup is not None

# Generated at 2022-06-21 06:39:21.397038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule._plugins_lookup_class == 'template')
    assert(LookupModule._plugins_lookup_name == 'template')
    assert(LookupModule.__doc__ == DOCUMENTATION)
    assert(LookupModule.run.__doc__ == RETURN)

# Generated at 2022-06-21 06:39:22.028270
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:39:23.276290
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:39:31.707592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_LookupModule_run_ansible_vars(res, lookup_file, lookup_template_vars):
        assert res == "ansible-vars"

    # Note: we need to use deepcopy of context because of the module_utils._context()
    # function is not reentrant and will return the same object after the first call
    context_copy = deepcopy(module_utils._context)
    context_copy.ansible_vars = test_LookupModule_run_ansible_vars
    module_utils._context = context_copy

    res = LookupModule().run(["lookup_file"], dict(), template_vars=dict())
    assert res == ["ansible-vars"]

# Generated at 2022-06-21 06:39:44.213566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test empty constructor
    l = LookupModule()
    assert l._plugin_options is None
    assert l._plugin_name is None
    assert l._loader is None
    assert l._templar is None
    assert l._display is None

    # Test constructor setting options
    l = LookupModule(var_options={}, direct={})
    assert l._plugin_options == {}
    assert l._plugin_name == "template"
    assert l._loader is None
    assert l._templar is None
    assert l._display is None

    # Set loader and templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    l._loader = DataLoader()
    l._templar = Variable

# Generated at 2022-06-21 06:39:57.941798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
        This test runs the lookup method LookupModule(templating).
        The following points are tested:
            -AnsibleError is raised for non existing template file
            -template file is processed properly
        '''

    # Mock_loader --
    # In the real method "run" of class LookupModule, _loader is created from its method _create_loader.
    # _loader.
    # Here we would like to mock _loader. This can be done by creating a class Mock_loader
    # with the same methods as _loader.
    class Mock_loader(object):
        def __init__(self):
            pass


# Generated at 2022-06-21 06:39:59.832863
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-21 06:40:08.096429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = [
        "my_template.j2"
    ]
    variables = {
        'variable': 'value'
    }

    def find_file_in_search_path(a, b, c):
        return "my_template.j2"

    module._templar = "mock_templar"
    module._loader = "mock_loader"
    module.find_file_in_search_path = find_file_in_search_path

    result = module.run(terms, variables)

# Generated at 2022-06-21 06:40:19.745177
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test with an empty list of lookup parameters
    l = LookupModule()
    assert isinstance(l, LookupBase)
    result = l.run([], dict())
    assert result == [], 'empty list of template files returns an empty list of results'

    # test with a list of lookup parameters containing a single file name
    result = l.run(['./template_files/hello.j2'], dict())
    assert result == ['Hello, World!\n'], 'template file is processed'

    # test with a list of lookup parameters containing a single file name and a variable_start_string
    variable_start_string = '[%'
    variable_end_string = '%]'

# Generated at 2022-06-21 06:40:24.034992
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of LookupModule with default parameters
    test_lookup = LookupModule()
    # Create an instance of LookupModule with specific parameters
    test_lookup_1 = LookupModule(loader=None, templar=None, shared_loader_obj=None)



# Generated at 2022-06-21 06:40:26.788504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = LookupModule().run(terms=['{{ foo }}', 'foo'], variables={'foo': 'bar'})
    assert results == ['bar', 'foo']

# Generated at 2022-06-21 06:40:30.252473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This test is not a true unit test, but just a sanity check.
    """
    display.display("####### testing LookupModule constructor")
    assert type(LookupModule) is type

# Generated at 2022-06-21 06:40:32.541626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    lm = LookupModule(loader=DataLoader())
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-21 06:40:38.679002
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    from ansible.template import AnsibleEnvironment
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.lookup import LookupBase

    # Case: simple use
    # Prepare test environment
    # create an instance of AnsibleLoader and add a yaml string
    loader = AnsibleLoader('''---
a:
 - 123
 - '{{ lookup("default", "/doesnotexist") }}'
''', 'test.yaml', None, None)
    # create an instance of AnsibleEnvironment with an AnsibleLoader and define an environment 'a'
    ansible_env = AnsibleEnvironment(loader, 'a')
    # create an instance of LookupBase and add

# Generated at 2022-06-21 06:40:46.910954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    terms = [ 'test/test' ]
    variables = ImmutableDict(
        {'test': 'value'},
        ansible_search_path=['test'],
        ansible_managed='test')

    answer = [to_bytes("value\n")]
    lm = LookupModule()
    response = lm.run(terms, variables, __file__=[__file__])
    assert response == answer

# Generated at 2022-06-21 06:41:07.708557
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:41:12.730053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_template_vars = {"echo": "This is a message"}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={"template_vars": lookup_template_vars})
    assert lookup_module.get_option("template_vars") == {"echo": "This is a message"}

# Generated at 2022-06-21 06:41:20.237409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    import os
    import tempfile
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    display = Display()
    f, path = tempfile.mkstemp()
    f2, path2 = tempfile.mkstemp()
    f3, path3 = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write("---\n>{{ item }}\n")
    with open(path2, 'w') as f:
        f.write("###\n#{% for item in items %}\n{{ item }}\n#{% endfor %}\n")

# Generated at 2022-06-21 06:41:31.852946
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class OptionsModule():
        def __init__(self, verbosity=None, connection=None,
                timeout=10, remote_user=None, become=False, become_method=None,
                become_user=None, check=False, diff=False):
            self.verbosity = verbosity
            self.connection = connection
            self.timeout = timeout
            self.remote_user = remote_user
            self.become = become
            self.become_method = become_method
            self.become_user = become_user
            self.check = check
            self.diff = diff
            
    class VariableManager():
        def __init__(self):
            self.vars = dict(ansible_version=dict(string='2.6.2'), ansible_check_mode=False)
            

# Generated at 2022-06-21 06:41:41.180002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    import ansible.constants
    constants = ansible.constants
    constants._ANSIBLE_ARGS = None  # pylint: disable=protected-access
    module._templar.environment.loader.searchpath = ["./lib/ansible/plugins/lookup"]
    def get_file_contents(path):
        with open(path, "rb") as f:
            return f.read(), False
    module._loader._get_file_contents = get_file_contents
    module._loader.path_dwim = lambda x: os.path.abspath(x)

    terms = ["basic.j2"]
    variables = dict(var1='value1')
    constants._ANSIBLE_ARGS = None  # pylint: disable=protected-access


# Generated at 2022-06-21 06:41:46.085941
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('template')

    assert lookup is not None

    result = lookup.run(['does_not_exist'], dict(ansible_search_path=['templates', '../']))
    assert len(result) == 0

# Generated at 2022-06-21 06:41:47.170293
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-21 06:41:55.462019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    x.set_loader()

    # Simple test template file, content of file is {{ variable }}
    x._loader.set_basedir('tests/test_lookup_plugins/files')

    # variable is set to ansible
    variable = {'variable': 'ansible'}

    # results is a list of string, first and only element is 'ansible'
    results = x.run(terms = ['test_template.j2'], variables = variable)
    assert len(results) == 1
    assert results[0] == 'ansible'

# Generated at 2022-06-21 06:42:05.040600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib

    lookup_tmp = LookupModule()
    # Test if AnsibleError is raised for directories
    for path in ['/', '/etc']:
        try:
            assert isinstance(lookup_tmp.run([path], ''), AnsibleError)
        except AssertionError:
            raise AssertionError('AnsibleError is not raised for directory %s' % path)
    for path in ['', 'a']:
        try:
            assert isinstance(lookup_tmp.run([path], ''), AnsibleError)
        except AssertionError:
            raise AssertionError('AnsibleError is not raised for non-existing directory %s' % path)

    # Test if proper result is returned for a non-existing file

# Generated at 2022-06-21 06:42:15.749481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    # Setup needed objects
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=C.DEFAULT_LOADER, sources='')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.extra_vars = play_context.extra_vars = {}
    variable_manager.options_vars = play_context.options_vars = {}

    # Create new LookupModule
    lookup_module = LookupModule()

    # Create a template file with some jinja2 code

# Generated at 2022-06-21 06:42:57.376479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert isinstance(lookup_module.display, Display)

# Generated at 2022-06-21 06:43:08.966986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.inventory
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.vars.manager
    from units.mock.loader import DictDataLoader

    class Options(object):
        def __init__(self, values=None):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = False
            self.become_method = 'sudo'

# Generated at 2022-06-21 06:43:17.404600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Replace LookupBase._loader._get_file_contents with a dummy method
    original_loader_method = LookupBase._loader._get_file_contents
    def mock_loader_method(self, path, win_path=None, ignore_errors=False, must_exist=False, decrypt=None):
        return to_bytes("{{foo}} v1 {{bar}}"), True

    setattr(LookupBase._loader, "_get_file_contents", mock_loader_method)

    # Replace LookupBase._templar with a dummy class
    class FakeTemplar:
        # pylint: disable=attribute-defined-outside-init
        def __init__(self, env=None):
            self._environment = env
            self.environment_class = AnsibleEnvironment
            self._available_variables = {}

# Generated at 2022-06-21 06:43:29.256019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    src_1 = {
        'value': 9,
        'src2': {
            'value': 6
        }
    }

    src_2 = {
        'value': 2,
        'src2': {
            'value': "{{ src1.value }}"
        }
    }

    src_3 = {
        'value': 3,
        'src2': {
            'value': "{{ src1.src2.value }}"
        }
    }

    src_4 = {
        'value': 4,
        'src2': {
            'value': "{{ src2.src2.value }}"
        }
    }

    lookup_module = LookupModule()

# Generated at 2022-06-21 06:43:30.781629
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()   # Invokes __init__(self)



# Generated at 2022-06-21 06:43:41.070238
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import shutil
    import tempfile
    from ansible.plugins.loader import lookup_loader

    # Make a temporary directory and a file with some content
    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'some_template.j2')
    template_content = "Hello from {{my_var}}"
    with open(tmpfile, 'w') as f_in:
        f_in.write(template_content)

    # Initialize the lookup class
    lookup = lookup_loader.get('template')
    lookup_instance = lookup()

    # Perform the lookup
    lookup_result = lookup_instance.run([tmpfile], dict(my_var='world'))

    # Verify the results
    assert lookup_result == ["Hello from world"]

    # Clean up
   

# Generated at 2022-06-21 06:43:44.222870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance.__class__.__name__ == 'LookupModule'

# Unit tests for construction of the method run in the class LookupModule

# Generated at 2022-06-21 06:43:53.477513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    f1 = open(os.path.join(test_data_dir, 'testfile'), 'r')
    f2 = open(os.path.join(test_data_dir, 'testfile2'), 'r')
    test_result = [f1.read(), f2.read()]
    global LookupBase
    # When mocked_class is passed to run() method, the global variable LookupBase is mocked. This prevents
    # us from creating an instance of the TestLookupModule() class.
    LookupBase = LookupBase.LookupBase
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:44:05.083346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tem = LookupModule()
    tem.set_options(var_options=None, direct=None)
    # testcase 1
    tem._loader.file_exists.return_value = True
    tem._loader._get_file_contents.return_value = ["a", "b", "c"]
    tem._loader._get_file_contents.return_value = ["a", "c", "b"]
    tem._templar._available_variables = {"a": 1, "b": 2, "c": 3}
    tem._templar.template.return_value = "d"
    tem._templar._searchpath = ["/a/b/c/d/e/f/g/h", "/b/c/d/e/f/g/h/i"]
    tem._templar._environment

# Generated at 2022-06-21 06:44:09.895297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    vault_secrets_file = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../test/ansible_vault'))
    vault = VaultLib(['--vault-password-file', vault_secrets_file])
    inventory = InventoryManager(loader, vault.secrets, [])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = {}

# Generated at 2022-06-21 06:45:44.941055
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert getattr(LookupModule, "run")

# Test running class LookupModule

# Generated at 2022-06-21 06:45:45.466474
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False

# Generated at 2022-06-21 06:45:51.388175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import __main__
    import sys

    __main__.user_ns = {}
    __main__.user_ns['var'] = 'value'
    lookup_plugin = LookupModule()

    # Testing LookupModule.run()
    templar = __main__.__dict__['_templar']
    lookup_plugin._templar = templar
    templar._available_variables = __main__.__dict__
    lookup_plugin._loader = DictDataLoader({
        to_bytes("/path/to/ansible/test/loader.yml"): """
        #!yaml
        {% set var = 'value' %}
        - shell: this is a {{ var }}
          register: result
        """,
    })

# Generated at 2022-06-21 06:46:01.540622
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing with jinja2_native disabled globally
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin._templar, AnsibleEnvironment)

    # Testing with jinja2_native enabled globally
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin._templar, AnsibleEnvironment)

    # Testing with jinja2_native enabled globally and disabled for the lookup
    lookup_plugin = LookupModule(variable_start_string='[%', variable_end_string='%]',
                                 comment_start_string='[#', comment_end_string='#]',
                                 convert_data=True)
    assert isinstance(lookup_plugin._templar, AnsibleEnvironment)

# Generated at 2022-06-21 06:46:03.782439
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin
    assert isinstance(lookup_plugin, LookupBase)


# Generated at 2022-06-21 06:46:04.664560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj is not None

# Generated at 2022-06-21 06:46:08.440901
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()



# Generated at 2022-06-21 06:46:09.325045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-21 06:46:10.524564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:46:11.733989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule """
    return LookupModule([])