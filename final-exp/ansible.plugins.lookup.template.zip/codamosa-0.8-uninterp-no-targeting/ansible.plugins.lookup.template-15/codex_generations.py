

# Generated at 2022-06-21 06:37:52.489125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    class Host(object):
        def __init__(self):
            self.vars = {}
    class Play(object):
        def __init__(self):
            self.hosts = {'127.0.0.1': Host()}
    class Task(object):
        def __init__(self):
            self.environment = {'test': 'env'}
            self.play = Play()
    class PlayContext(object):
        def __init__(self):
            self.tasks = [Task()]

    pc = PlayContext()
    lookup.set_options({'convert_data': False, 'template_vars': {'test': 'vars'}})
    lookup.set_loader(None)
    lookup.set_environment(pc)

# Generated at 2022-06-21 06:37:58.599225
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.facts.system.distribution import Distribution
    # the Distribution class must be initialized to ensure create_cache() is called
    Distribution()
    lookup = LookupModule()

    # I don't know how to mock the methods of the LookupBase calls
    # so I am not testing this method at all. It will be tested later
    # when I know how to do it.

    pass


# Generated at 2022-06-21 06:38:06.964302
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test if any arguments are given
    # Test if the number of arguments given is not the expected
    # Test if _templar is of type ansible.parsing.vault.VaultLib
    # Test if _loader is of type ansible.parsing.dataloader.DataLoader
    # Test if _templar has the correct path_sep

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.path import path_dwim

    terms = ['', '/home/usr/ansible/template.j2']
    variables = {}

    lu1 = LookupModule(loader=DataLoader(), templar=VaultLib())

# Generated at 2022-06-21 06:38:19.270848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import json
    from ansible.plugins.lookup.template import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.sentinel import Sentinel

    # Ansible 2.4 backported
    class ResultCallback(CallbackBase):
        """A dummy callback plugin used to test the interface"""


# Generated at 2022-06-21 06:38:30.137161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    # Create fake display
    class FakeDisplay():
        def __init__(self):
            self.msgs = []

        def debug(self, msg):
            self.msgs.append(msg)

        def display(self, verbosity=0, *args, **kwargs):
            global msgs
            self.msgs.append("display called with verbosity=%d" % verbosity)
            return self.msgs

    # Create fake loader
    class FakeLoader():
        def _get_file_contents(self, path):
            # Return a dummy lookup result
            return ("xxx {{ lookup_var_1 }}, {{ lookup_var_2 }} yyy", False)

    fake_display = FakeDisplay()
    lookup_loader.display = fake_display

    # Create class

# Generated at 2022-06-21 06:38:34.350336
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule """
    dml = LookupModule()
    assert dml.run([], {}, **{}) == []

# Generated at 2022-06-21 06:38:42.950226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an instance of LookupModule
    lookup = LookupModule()

    # create a variable
    variable = {}
    variable['filename'] = './sample.yml'
    variable['_ansible_lookup_plugin'] = './lookup_plugins/template.py'

    # call LookupModule's run method
    terms = ['sample.j2']
    res = lookup.run(terms, variable)

    # check whether the result is expected
    expected = ['\n     -----\n    | 1.1 |\n     -----\n    \n']
    assert res == expected, 'Expected: %s, Actual: %s' % (expected, res)

# Generated at 2022-06-21 06:38:43.777313
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False

# Generated at 2022-06-21 06:38:54.598301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_plugin = LookupModule()

    # Create a template file
    template_file = "./my_template_file.j2"
    with open(template_file, "w") as f:
        f.write("abcd")

    # Create a list of terms
    terms = ["./my_template_file.j2"]

    # Create variables to pass to the lookup_plugin
    variables = {}

    # Create the results of executing the template using the template_plugin
    ret = lookup_plugin.run(terms, variables, convert_data=False)

    # Delete the template file
    os.remove(template_file)

    # Assert the result is expected
    assert ret[0] == "abcd"

# Generated at 2022-06-21 06:38:55.550829
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert isinstance(t, LookupBase)

# Generated at 2022-06-21 06:39:08.152983
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:39:09.023676
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup1 = LookupModule()
    assert lookup1


# Generated at 2022-06-21 06:39:18.253290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import base64
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import pytest

    load_call_count = 0

    class AnsibleModuleMock:
        def __init__(self, argument_spec, bypass_checks=False, no_log=True, check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False):
            pass

    class LoaderMock:
        def load_from_file(self, path, cache=True):
            global load_call_count
            load_call_count += 1



# Generated at 2022-06-21 06:39:26.916498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # LookupModule.run(terms, variables, **kwargs)
    # where terms is a list of terms (files) to be templated
    # and variables is a dict with variables to be used for templating
    # and jinja2_native is a bool variable
    terms = ['./my_template.j2']
    variables = {}
    jinja2_native = False
    res = module.run(terms, variables, jinja2_native=jinja2_native)
    assert res == ['templated_result']

# Generated at 2022-06-21 06:39:34.401396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule

    Test if the correct value is returned for different types of arguments,
    and for different types of variables in template files.
    '''

    ###
    ### Variables used in tests
    ###
    # Create mock object used as value for the 'loader' parameter in constructor of LookupModule
    class MockFileLoader:
        @staticmethod
        def _get_file_contents(filename):
            with open(filename, 'r') as f:
                return f.read(), False

    # Create mock object used as value for the 'templar' parameter in constructor of LookupModule
    class MockTemplate:
        def __init__(self):
            self.environment_class = AnsibleEnvironment
            self.searchpath = []


# Generated at 2022-06-21 06:39:35.807319
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:39:48.061589
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Define unit test object
    from ansible.plugins.lookup.template import LookupModule
    lookup = LookupModule()

    # Define unit test variables
    variables = {}

    # Define the path to the test file to use
    template_file_path = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '../../../../../lib/ansible/plugins/lookup/template_test_data/test_template.j2'))

    # Define test data
    terms = [template_file_path]

    # Run unit test
    result = lookup.run(terms, variables)

    # Ensure that the result is what we expect
    assert result[0] == "This is a test of the template module"



# Generated at 2022-06-21 06:40:00.816763
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Environment(object):
        def __init__(self, variables):
            self.vars = variables

        def get_template_vars(self):
            return self.vars

    class Template(object):
        def __init__(self, template_data, environment):
            self.template_data = template_data
            self.environment = environment

        def render(self, variables=None, convert_bare=True, **kwargs):
            if variables is not None:
                self.environment.vars.update(variables)
            return self.template_data

    class Templar(object):
        def __init__(self, variables):
            self.environment = Environment(variables)


# Generated at 2022-06-21 06:40:01.443534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:40:11.964045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError

    # Initialize variables and mocks which would exist at module initialization
    display = Display()
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        ansible_search_path = ['/path/to/search'],
        ansible_managed = 'template string',
    )

# Generated at 2022-06-21 06:40:23.115251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    fixture = LookupModule()
    assert fixture

# Generated at 2022-06-21 06:40:33.436336
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Load
    test_lookup_plugin = LookupModule()

    # Init vars
    terms = ['notexisting']
    display.verbosity = 2
    display.debug("test")
    variables = {u'ansible_search_path': [u'/home/vagrant/.ansible/plugins/lookup']}

    # Run test
    result = test_lookup_plugin.run(terms, variables)

    # Assertions
    assert result == [], 'There should never be a file in this directory'

    # Init vars
    terms = ['test_template.j2']
    display.verbosity = 2
    display.debug("test")
    variables = {u'ansible_search_path': [u'/home/vagrant/.ansible/plugins/lookup']}

    # Run test
    result = test_

# Generated at 2022-06-21 06:40:34.260917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:40:36.764433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert 'LookupModule' == l.__class__.__name__


# Generated at 2022-06-21 06:40:37.482049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:40:38.468468
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:40:49.877325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    def assert_lookup_return(terms, expected_ret, **kwargs):
        ret = module.run(terms, variables={}, **dict(kwargs))
        assert ret == expected_ret

    assert_lookup_return(['no_such_file'], [],
                         jinja2_native=True) # test early exit for missing file
    assert_lookup_return(['this_file_should_not_exist.j2'],
                         [],
                         jinja2_native=True,
                         template_vars={'var': 'no_such_file'}) # test early exit for missing file

# Generated at 2022-06-21 06:40:56.431118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    from ansible.module_utils.six import PY2

    try:
        from ansible.template import Templar
    except ImportError:
        from ansible.utils.template import Templar

    class DummyVarsModule:
        def __init__(self, dict):
            self.__dict__ = dict


# Generated at 2022-06-21 06:41:08.285353
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:41:17.879478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    import sys
    import jinja2

    # These two will be required by `run`
    class LookupBaseStub:
        def find_file_in_search_path(self, variables, searches, file):
            return 'find-file-in-search-path'

    class VariablesStub:
        ansible_search_path = ['ansible-search-path']

    class DisplayStub:
        def __init__(self):
            self.debug_calls = []
            self.vvvv_calls = []
        def debug(self, msg):
            self.debug_calls.append(msg)
        def vvvv(self, msg):
            self.vvvv_calls.append(msg)


# Generated at 2022-06-21 06:41:43.859009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class Term(object):
        def __init__(self, term, display):
            self.display = display
            self.term = term

    class Vars(object):
        def get(self, key, default):
            if key == 'ansible_search_path':
                return ['.']
            return default

    lookup_module = LookupModule()
    lookup_module._display = display
    lookup_module._templar  = Term("None", display)
    lookup_module._loader = Term("None", display)
    lookup_module.run(terms=['index.rst'], variables=Vars())

# Generated at 2022-06-21 06:41:55.945653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    # Not use '_ansible_tmpdir' variable
    old_ansible_tmpdir = os.environ.get('_ansible_tmpdir')
    if old_ansible_tmpdir:
        del os.environ['_ansible_tmpdir']

# Generated at 2022-06-21 06:41:57.201353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.run(None,None)

# Generated at 2022-06-21 06:42:06.260168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import pytest
    import ansible.plugins.loader as plugin_loader
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    from ansible.module_utils.six.moves import builtins
    import ansible.module_utils.six.moves.urllib.request as urllib_request
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import Call

# Generated at 2022-06-21 06:42:16.274801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lkm = LookupModule()

    # Create a list of terms.
    terms = [ "./sample_templates/test_template.j2" ]

    # Create a dictionary of variables.
    variables = { "my_var": "This is a variable." }

    # Initialize comments_start_string and comments_end_string
    comments_start_string = '/*'
    comments_end_string = '*/'

    kwargs = { 'variable_start_string': '{',
               'variable_end_string': '}',
               'comment_start_string': comments_start_string,
               'comment_end_string': comments_end_string }

    # Run the method.
    results = lkm.run( terms, variables, **kwargs )

# Generated at 2022-06-21 06:42:26.657526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.verbosity = 3
    test_lookup = LookupBase()
    test_lookup.set_loader(None)
    test_lookup._templar = None

    lookup_module = LookupModule()
    lookup_module.set_loader(test_lookup._loader)
    lookup_module._templar = test_lookup._templar

    lookup_module._display.verbosity = 4
    lookup_module.run(['./test/test_lookup_templates/test_template.j2'], {'val1': 'TEST', 'val2': 'PASS'}, convert_data=False)

# Generated at 2022-06-21 06:42:34.640219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test with default settings.
    result = module.run(["test.j2.yaml"], {"test": "TEST"}, convert_data=True, jinja2_native=True)
    assert len(result) == 1
    assert result[0] == {"test": "TEST"}

    # Test with conversion disabled.
    result = module.run(["test.j2.yaml"], {"test": "TEST"}, convert_data=False, jinja2_native=True)
    assert len(result) == 1
    assert result[0] == "test: TEST\n"

    # Test with jinja2_native disabled.

# Generated at 2022-06-21 06:42:43.261919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = "./some_template.j2"
    convert_data_p = False
    jinja2_native = False

    term = os.path.abspath(term)

    lookup_template_vars = dict()
    variable_start_string = '{{'
    variable_end_string = '}}'
    comment_start_string = '{#'
    comment_end_string = '#}'

    module = LookupModule()

    # create a mock class to mock the module's methods
    class MockClass(object):
        def __init__(self):
            pass

        # Mock the class' methods
        def set_options(self, var_options, direct):
            return

        def get_option(self, option):
            if option == 'convert_data':
                return convert_data_p

# Generated at 2022-06-21 06:42:46.862626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    src = 'tests/unit/lookup_plugins/template/template.yml'
    templar = {}
    template_vars = {}
    lookup = LookupModule(templar,src,template_vars)
    print(lookup)

# Generated at 2022-06-21 06:42:58.867327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockOptions(object):
        def __init__(self):
            self.variable_start_string = '{{'
            self.variable_end_string = '}}'
            self.comment_start_string = '{{#'
            self.comment_end_string = '#}}'
            self.trim_blocks = True
            self.lstrip_blocks = True
            self.keep_trailing_newline = False
            self.convert_data = False
            self.jinja2_native = False
            self.template_vars = {}
            self.environment = None

    class MockCollectionsLoader(object):
        def __init__(self):
            self.path_list = []

        def set_path_list(self, path_list):
            self.path_list = path_list


# Generated at 2022-06-21 06:43:49.212272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    mock_loader = MockDataLoader()
    mock_templar = MockTemplar(loader=mock_loader)
    module._templar = mock_templar
    module._loader = mock_loader

    # Case: template file found, contents contains output
    mock_loader.set_file_contents(file_name='/home/ansible/templates_dir/a.j2',
                                  file_contents="{{ var }}")
    result = module.run(terms=['a.j2'], variables={'var': 'value'})
    assert result == ['value']

    # Case: template file found, contents does not contain output

# Generated at 2022-06-21 06:43:54.130375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vault_secrets(('secret',))
    lookup_obj = LookupModule(loader=loader, variable_manager=variable_manager, inject={"vault_password": "secret"})

    assert isinstance(lookup_obj, LookupModule)

    assert hasattr(lookup_obj, 'run')

# Generated at 2022-06-21 06:43:55.094233
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:43:56.037192
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert lk != None

# Generated at 2022-06-21 06:44:00.429326
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""

    # Unimplemented
    return None

# Generated at 2022-06-21 06:44:10.691956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Usage of this test:
    python -m ansible.plugins.lookup.template
    """
    lookup_plugin_path = os.path.join(os.path.dirname(__file__), '..')
    assert lookup_plugin_path.endswith('lookup')
    lookup_plugin_path = os.path.dirname(lookup_plugin_path)
    assert lookup_plugin_path.endswith('plugins')
    lookup_plugin_path = os.path.dirname(lookup_plugin_path)
    assert lookup_plugin_path.endswith('ansible')
    lookup_plugin_path = os.path.dirname(lookup_plugin_path)

    # prefix the path with ANSIBLE_LOOKUP_PLUGINS=
    # we need to replace the space between '=' and

# Generated at 2022-06-21 06:44:12.670820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.plugin_type == 'lookup'
    assert lookup_plugin.display_name == 'template'

# Generated at 2022-06-21 06:44:20.229216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.path import unfrackpath
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.strategy import StrategyBase

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources=['localhost,'])
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    strategy = StrategyBase('linear')

# Generated at 2022-06-21 06:44:23.046715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert len(list(l.run([], [], convert_data=True))) == 0
    assert len(list(l.run([], [], convert_data=False))) == 0



# Generated at 2022-06-21 06:44:34.626110
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template.template import Templar

    # This is a bit of a cheat, but it lets us run this test in a standalone fashion
    # without requiring all the fake data that the actual plugin would have.
    sys.modules['ansible'] = type('ansible', (object,), {'__file__': 'ansible'})()
    sys.modules['ansible.plugins.lookup.template'] = type('ansible.plugins.lookup.template', (object,), {'__file__': 'ansible/plugins/lookup/template.py'})()

# Generated at 2022-06-21 06:46:03.387121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(False), "Not implemented"


# Generated at 2022-06-21 06:46:14.844099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.collection_loader._collection_finder import AnsibleCollectionConfig
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    LookupModule.set_vault_secrets(None)
    LookupModule.set_vault_password('V@ultPassword:1')


# Generated at 2022-06-21 06:46:21.456501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.set_loader(dict(path=['./lib']))
    txt = mod.run(['nested1.j2', 'nested2.j2'], dict(a={'b': 'c'}), convert_data=True, jinja2_native=True, variable_start_string='[%', variable_end_string='%]', comment_start_string='[#', comment_end_string='#]')
    print(txt)
    assert txt == ['a.b.c=c\n', 'a.b.c=c\n']

# Run the unit test
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:46:22.604487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:46:25.428640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:46:36.418206
# Unit test for constructor of class LookupModule
def test_LookupModule():
  from ansible.plugins.lookup import LookupBase
  from ansible.module_utils._text import to_bytes
  from ansible.template import generate_ansible_template_vars, AnsibleEnvironment

  FROM_YAML = """
    convert_data: False
    template_vars:
        key: value
    jinja2_native: False
    variable_start_string: "[%"
    variable_end_string: "%]"
    comment_start_string: "[#"
    comment_end_string: "#]"
"""

  LookupModule(from_yaml=FROM_YAML)
  #from ansible.plugins.lookup import LookupBase
  #from ansible.module_utils._text import to_bytes
  #from ansible.template import generate_ansible_template_vars, Ans

# Generated at 2022-06-21 06:46:37.177559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:46:42.270320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create SSHClient object
    client = ParamikoSSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect("localhost",22,"root","root")

    # Create ShellClient object
    shell = ShellClient(client)

    # Create LookupModule object
    module = LookupModule()
    module.set_shell(shell)

    # Set missing parameters
    terms = ["../../template.j2"]
    variables = dict()

    module.run(terms, variables)

test_LookupModule_run()

# Generated at 2022-06-21 06:46:45.372277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule.

    :return: 
    """
    pass

# Generated at 2022-06-21 06:46:53.635981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    templar = None  # do not pass templar
    lookup = LookupModule(templar=templar, loader=None, templar_vars=None, loader_vars=None)
    assert lookup.set_options(direct=dict()) == {}
    assert lookup.get_option('convert_data') is None
    assert lookup.get_option('jinja2_native') is None
    assert lookup.get_option('template_vars') == {}
    assert lookup.get_option('variable_start_string') == '{{'
    assert lookup.get_option('variable_end_string') == '}}'
