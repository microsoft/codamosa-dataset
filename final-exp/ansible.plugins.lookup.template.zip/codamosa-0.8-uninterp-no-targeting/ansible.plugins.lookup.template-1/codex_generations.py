

# Generated at 2022-06-21 06:37:52.584138
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    m_plugin_loader = mock.MagicMock()
    m_plugin_loader._get_file_contents = lambda x: (b"{{ test_variable }}", False)

    m_templar = mock.MagicMock()
    m_templar.environment = None
    m_templar.template = lambda x, y, z: x
    #m_templar._available_variables = dict()
    m_templar.copy_with_new_env = lambda x: m_templar

    lookup = LookupModule()
    lookup._templar = m_templar
    lookup._loader = m_plugin_loader

    m_ansible = mock.MagicMock()
    m_ansible.get_config = lambda: dict(template_dir = "foo")

    # patching as this

# Generated at 2022-06-21 06:37:58.693821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(terms=['./tests/test.j2'], variables={'var1': 'val1', 'var2': 'val2'}) == [to_bytes("{% if var1 == 'val1' %}{% if var2 == 'val2' %}ok{% else %}nok{% endif %}{% else %}nok{% endif %}")]

# Generated at 2022-06-21 06:38:00.076667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookupModule = LookupModule()
    assert myLookupModule != None

# Generated at 2022-06-21 06:38:01.054397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:38:12.656234
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a lookup module object
    LookupModule_object = LookupModule()

    # Create a mock display object to use in check
    display_object = Display()

    # Create a mock return object to use in check
    ret = []

    # Create a mock terms to use in check
    terms = ["./some_template.j2", "./some_template2.j2"]

    # Create a mock variables to use in check
    variables = {}

    # Create a mock b_template_data to use in check
    b_template_data = 'hola'

    # Create a mock template_data to use in check
    template_data = 'hola'

    # Create a mock lookupfile to use in check
    lookupfile = "./some_template.j2"

    # Create a mock show_data to use in check
    show

# Generated at 2022-06-21 06:38:18.709956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.template
    # the ansible.plugins.lookup.template.LookupModule class is created and returned by the load method
    # so create an empty object to avoid errors
    ansible.plugins.lookup.template.LookupModule = type('LookupModule', (), {})

    my_obj = ansible.plugins.lookup.template.LookupModule()
    assert my_obj

# Generated at 2022-06-21 06:38:20.590988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=unused-variable
    lookup_module = LookupModule(None)


# Generated at 2022-06-21 06:38:23.099632
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 06:38:24.159570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ignore all other code
    return LookupModule.run

# Generated at 2022-06-21 06:38:26.215389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(["./file1.j2"], {}, convert_data=False)

# Generated at 2022-06-21 06:38:36.876504
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    # Act, assert
    raise NotImplementedError()

# Generated at 2022-06-21 06:38:38.237368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([],dict())

# Generated at 2022-06-21 06:38:39.171260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 06:38:50.667746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVarsModule(object):
        def __init__(self,ansible_search_path):
            self.ansible_search_path = ansible_search_path
        def get(self,x,default=None):
            self.get_args = (x,default)
            return self.ansible_search_path

    class MockTemplar(object):
        def __init__(self,expected_template_data,expected_search_path,expected_vars):
            self.expected_template_data = expected_template_data
            self.expected_search_path = expected_search_path
            self.expected_vars = expected_vars
        def copy_with_new_env(self,environment_class):
            return self

# Generated at 2022-06-21 06:39:01.666467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # Create an instance of LookupModule
    lookup_module = LookupModule()
    # Create an instance of Ansible, for the load of plugins
    # We need to patch the class Ansible so that the config don't load
    # the configuration file.
    import ansible.constants as C
    C.DEFAULT_CONFIG_FILE = os.path.join(os.path.dirname(__file__), "../unittests/ansible.cfg")

    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=[])
    cli.options.verbosity = 99
    cli.options.quiet = True
    options = cli.parse()
    variables = cli

# Generated at 2022-06-21 06:39:10.952129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.plugins.lookup.template import LookupModule
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    vault_secret = 'hush'
    vault_password_file = 'my_vault_password_file'
    vault_password = 'hush_hush'
    environment = dict(PATH='/bin:/usr/bin')

    terms = ['/tmp/template.j2']
    variables = dict(foo='bar',
                     baz='buzz',
                     vault_password=VaultLib(vault_password))

# Generated at 2022-06-21 06:39:21.868088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    playbook_vars = {
        'foo': 'bar'
    }
    variable_manager = VariableManager()
    variable_manager.set_inventory(None)
    variable_manager.set_playbook_basedir('/home/user/testing')  # '.' in template_vars
    variable_manager.extra_vars = playbook_vars
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    templar = Templar(loader=None, variables=variable_manager,
                      shared_loader_obj=None,
                      disable_lookups=False)


# Generated at 2022-06-21 06:39:31.748081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Invalid path
    lookup_plugin = LookupModule()
    # Check error message
    try:
        lookup_plugin.run([], dict())
        assert False
    except AnsibleError as e:
        assert str(e) == "with_template: 'file' is undefined"

    # Wrong search directory
    lookup_plugin = LookupModule()
    # Check error message
    try:
        lookup_plugin.run([], dict(ansible_search_path=[os.path.join(to_bytes(os.getcwd()), b'xyz')]))
        assert False
    except AnsibleError as e:
        assert str(e) == "the template file  could not be found for the lookup"

    # Real file
    lookup_plugin = LookupModule()
    # Generate test file
    testfile = os.path

# Generated at 2022-06-21 06:39:34.040596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run(terms=['test_templates/basic.j2'], variables={'test_variable': 'success'}) == ['success']

# Generated at 2022-06-21 06:39:47.111156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from io import StringIO
    import pytest

    FauxInventory = type('FauxInventory', (object,), {'basedir': '/faux_path'})
    variables = VariableManager()
    variables.set_inventory(FauxInventory())
    templar = Templar(variables=variables, loader=DataLoader())

    # No test for cases when:
    # - convert_data == True && jinja2_native == False, because Templar() doesn't handle that case.
    # - convert_data == False && jinja2_native == True, because jinja2_native == True globally but off for the lookup.

    #

# Generated at 2022-06-21 06:39:57.626585
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 06:40:07.170769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = DummyLoader(
        _file_contents={'template': b'Hello {{ name }}\n',
                        'path/template': b'Hello {{ name }}\n'})
    lookup_module._templar = Templar(loader=lookup_module._loader)
    lookup_module._display = DummyDisplay()
    ret = lookup_module.run(terms=['template'], variables={'name': 'world'},
                            convert_data=True, template_vars={},
                            variable_start_string='{{', variable_end_string='}}')
    assert ret == ['Hello world\n']



# Generated at 2022-06-21 06:40:10.585513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with valid arguments
    module = LookupModule()
    assert module

    # Test with None value
    try:
        module = LookupModule(None)
    except ValueError as e:
        assert 'parameters are required: terms' in to_text(e)

# Generated at 2022-06-21 06:40:11.566259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None

# Generated at 2022-06-21 06:40:19.391676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    check the module run with a fake terms and variables
    '''
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(DictDataLoader())
    results = lookup_plugin.run(
        ['test'],
        {},
        variable_start_string='{',
        variable_end_string='}',
        comment_start_string='<#',
        comment_end_string='#>'
    )
    assert results == ["fake"]

# Generated at 2022-06-21 06:40:20.476351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 06:40:22.302335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance,LookupModule)
    instance.run('test')

# Generated at 2022-06-21 06:40:32.819301
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Only run tests if Jinja2 is available
    import jinja2

    # Test environment variables
    env_vars = {
        'test_var': 'test_val',
        'test_var2': 'test_val2',
        'test_var3': 'test_val3'
    }

    # Test configuration
    config = {
        'jinja2_native': False,
        'convert_data': False,
        'template_vars': {}
    }

    # Test lookup parameters
    terms = ['./tests/test.j2']

    # Test file to lookup
    lookupfile = './tests/test.j2'

    # Expected result
    expected_result = "test_val test_val test_val\n"

    # Object to mock _loader

# Generated at 2022-06-21 06:40:38.833737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible 2.4
    if LookupModule.run.__code__.co_argcount == 7:
        module_run_args_count = 7
        run_method_args = {'loader': None, 'templar': None, 'params': None}
    # ansible 2.5
    elif LookupModule.run.__code__.co_argcount == 4:
        module_run_args_count = 4
        run_method_args = {}
    else:
        raise Exception("Unexpected number of arguments in the run method of class LookupModule")

    # Create a class which only contains the run method defined above

# Generated at 2022-06-21 06:40:39.826684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    pass

# Generated at 2022-06-21 06:40:59.960746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:41:00.980505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:41:09.264961
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    # test 'run' method
    terms = ['./some_template.j2']
    variables = {
        'foo' : 'bar',
        'ansible_search_path': ['/path/to/first', '/path/to/second'],
        'template_host' : 'juju-host'
    }

    # test 'load_templates' method
    # FIXME: uncomment the following code
    #lm.load_templates(terms, variables, 'template_dir')

# Generated at 2022-06-21 06:41:14.882101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test jinja2_native = True global and local
    set_module_args({'_raw_params': "{{ lookup('template','../tests/testlookup.j2') }}",
                     'jinja2_native': True})
    result = lookup_base._exec_module()
    assert result['success'] == True
    assert result['_ansible_verbose_always'] == True
    assert result['ansible_facts']['lookup_value'] == 'nobody.example.com'

    # Test jinja2_native = False global but True local
    set_module_args({'_raw_params': "{{ lookup('template','../tests/testlookup.j2', jinja2_native=True) }}",
                     'jinja2_native': False})
    result = lookup_base._exec_module

# Generated at 2022-06-21 06:41:21.232586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    module_name = 'ansible.plugins.lookup.template'
    module_path = os.path.join(os.path.dirname(__file__), '../../../')
    sys.path.append(module_path)

    from ansible.plugins.loader import lookup_loader
    lookup_cls = lookup_loader.get('template')
    lookup_obj = lookup_cls()
    assert hasattr(lookup_obj, 'run')
    file = 'files/test.j2'
    terms = 'files/test.j2'
    variables = {'ansible_search_path': ['files']}
    kwargs = {}
    data = lookup_obj.run(terms, variables, **kwargs)
    assert len(data) == 1
    data_str = to

# Generated at 2022-06-21 06:41:23.839261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    display = Display()
    display.debug("test_LookupModule called")

    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-21 06:41:30.395992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.template import LookupModule

    # Check jinja2_native option
    result_data = []
    terms = ['data_1.yml']
    lookup_instance = LookupModule()
    result = lookup_instance.run(terms=terms, variables={'ansible_search_path': ['.']}, jinja2_native=True)
    assert result == result_data

# Generated at 2022-06-21 06:41:32.122388
# Unit test for constructor of class LookupModule
def test_LookupModule():
   # Test empty constructor
   foo = LookupModule()
   assert foo is not None


# Generated at 2022-06-21 06:41:41.384419
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test if the constructor of LookupModule() sets the correct object properties"""
    lookup = LookupModule()
    assert lookup._templar == None, 'Constructor of LookupModule() does not set templar'
    assert lookup.get_option('convert_data') == None, 'Constructor of LookupModule() does not convert_data'
    assert lookup.get_option('jinja2_native') == None, 'Constructor of LookupModule() does not set jinja2_native'
    assert lookup.get_option('template_vars') == None, 'Constructor of LookupModule() does not set template_vars'
    assert lookup.get_option('variable_end_string') == None, 'Constructor of LookupModule() does not set variable_end_string'

# Generated at 2022-06-21 06:41:42.663089
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test constructor for class LookupModule"""

    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:42:30.897579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule.
    '''
    arguments = [
        {
            'terms': [
                'lookup_file'
            ],
            'variables': {
                'template_name': 'first_template',
                'variable_start_string': '[[',
                'variable_end_string': ']]'
            },
            'use_jinja2_native': False
        },
        {
            'terms': [
                'lookup_file',
                'another_template'
            ],
            'variables': {
                'template_name': 'second_template',
                'variable_start_string': '[[',
                'variable_end_string': ']]'
            },
            'use_jinja2_native': False
        }
    ]

    number_

# Generated at 2022-06-21 06:42:31.414382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 06:42:41.829302
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock object for args
    class Object(object):
        pass

    # Mock object for search_path
    class Search_Path(object):
        pass

    # Mock object for variable_manager
    class Variable_Manager(object):
        pass

    # Mock object for variable_manager
    class Jinja2(object):
        pass

    # Mock object for _templar
    class Templar(object):
        pass

    # Mock object for loader
    class Loader(object):
        pass

    # Mock object for file_dictionary
    class File_Dictionary(object):
        def get(self, term, default=None):
            return default

    # Mock object for file_dictionary
    class File_List(object):
        pass

    # Test if the file lookup module instantiates correctly

# Generated at 2022-06-21 06:42:44.054251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Setup
    lookup_module = LookupModule()

    # Test
    assert lookup_module is not None



# Generated at 2022-06-21 06:42:51.971078
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert not lookup_module.get_option('convert_data')
    assert not lookup_module.get_option('jinja2_native')
    assert lookup_module.get_option('template_vars') == {}
    assert lookup_module.get_option('variable_start_string') == '{{'
    assert lookup_module.get_option('variable_end_string') == '}}'
    assert lookup_module.get_option('comment_start_string') is None
    assert lookup_module.get_option('comment_end_string') is None

# Generated at 2022-06-21 06:43:00.160438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types

    terms = ['testfile.j2']
    plugins = LookupBase()
    testobj = LookupModule()
    testobj.set_loader(plugins)

    assert isinstance(testobj.run(terms, {}), string_types)

    testobj.set_options({'variable_start_string':'<%', 'variable_end_string':'%>'})
    assert isinstance(testobj.run(terms, {}), string_types)

    testobj.set_options({'comment_start_string':'<#', 'comment_end_string':'#>'})
    assert isinstance(testobj.run(terms, {}), string_types)


# Generated at 2022-06-21 06:43:02.176001
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run(['./some_template.j2'], {}) == []

# Generated at 2022-06-21 06:43:12.938034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test will check if LookupModule.run() returns true for given cases.
    """
    lookup = LookupModule()
    #testing for empty terms list.
    assert lookup.run([], {}) == []
    #testing for a template file that exists
    lookup.run(["test.j2"],
               {"_ansible_directory": os.path.join(os.path.dirname(__file__), 'tests')})
    #testing for a template file that does not exist
    try:
        lookup.run(["test2.j2"],
                   {"_ansible_directory": os.path.join(os.path.dirname(__file__), 'tests')})
        assert False
    except AnsibleError as e:
        assert "the template file test2.j2 could not be found for the lookup" in to

# Generated at 2022-06-21 06:43:23.633230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for convert_data default
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module._templar = None
    result = lookup_module.run(['{{ foo }}'], {'foo': 'ok'})
    assert result == ['ok']

    # Test for convert_data and USE_JINJA2_NATIVE
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module._templar = None
    result = lookup_module.run(['{{ foo }}'], {'foo': 'ok'}, convert_data=False)
    assert result == ['{{ foo }}']

# Generated at 2022-06-21 06:43:25.372409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:45:09.039283
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    # test that an error is raised if the template can not be found
    got_error = False
    try:
        lookup.run([ "./some_template.j2" ], {}, convert_data=True)
    except AnsibleError:
        got_error = True
    assert got_error, "Expected error if template can't be found"

# Generated at 2022-06-21 06:45:17.611317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()

    # Setup
    class FakeTemplate:
        def __init__(self, template_data):
            self.template_data = template_data

        def __call__(self, data):
            return self.template_data + data

    L._templar = FakeTemplate("template_data")

    terms = ('/path/to/some/file',)
    variables = {
        'ansible_path': os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')),
        'ansible_search_path': [],
    }

# Generated at 2022-06-21 06:45:29.550853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test case is written to test method run of class LookupModule.
    Args: None
    Returns: None
    """
    #test case 1
    lookup_module = LookupModule()
    display.vvvv = True
    lookup_module.set_loader()
    lookup_module.set_environment()
    lookup_module._loader._connection.connection._shell.get_option.return_value = True
    assert lookup_module.run(terms=["ldap_entry.j2"], variables={"ansible_search_path": ['.']}) == \
           ["{% extends 'ldap_base.j2' %}\n{% block ldap_section %}\n\n{# ldap_entry.j2 #}\n{% endblock %}\n"]



# Generated at 2022-06-21 06:45:33.864016
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import string
    import tempfile

    def create_temporary_file(file_content):
        fd, temp_path = tempfile.mkstemp()
        with os.fdopen(fd, 'w') as temp_file:
            temp_file.write(file_content)
        return temp_path

    file_content = string.Template("""
        # this is a comment
        start=${start}
        middle=${middle}
        end=${end}
        """)

    # create the temporary file
    temp_path = create_temporary_file(file_content.substitute(start='foo', middle='bar', end='baz'))

    # the lookup module needs a loader
    class MyLoader:
        def get_basedir(self, *args):
            return os.getcwd()

    my

# Generated at 2022-06-21 06:45:34.444546
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:45:38.668977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes, to_text

    lookup = LookupModule()
    lookup.set_options(direct={'convert_data': False})
    assert lookup.run(['./some_template.j2'], variables=ImmutableDict()) == []
    assert lookup.run(['./some_template.j2'], variables=ImmutableDict(ansible_search_path=[])) == []

    assert lookup.run(['./some_template.j2'], variables=dict(ansible_search_path=['/nonexistent'])) == []


# Generated at 2022-06-21 06:45:47.331682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import pytest
    sys_module_mock = mock.MagicMock()
    ansible_module_mock = mock.MagicMock()
    ansible_module_mock.params = {
        "variable_start_string": '{{',
        "variable_end_string": '}}',
        "comment_start_string": '<!--',
        "comment_end_string": '-->',
        "convert_data": True,
        "jinja2_native": True,
        "template_vars": {
            "foo": True
        }
    }
    ansible_module_mock.run_command.return_value = 0, "command_output", ""
    fake_templar = mock.MagicMock()

# Generated at 2022-06-21 06:45:50.929643
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # AnsibleLookupModule("LookupModule", './filepath', 'args', 'dummy_loader', 'dummy_templar', 'dummy_shared_loader_obj')
    raise Exception("Not implemented yet")

# Generated at 2022-06-21 06:45:51.449994
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:46:02.429901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup_params = {
        'variable_start_string': '[',
        'variable_end_string': ']',
    }

    # Test template lookup with var_replace
    lookup_template_data = '''
# Test template
[% d = dict(a='A', b='B') %]
[% a = '    ' %]
[[ a ]]
[[ a ]]
[[ a | replace(' ', '-') ]]
[% '-' * 3 %]
[% c = 'C' * 3 %]
[% c[1:3] %]
[% '%s-%s' % (c[1:3], c[1:3]) %]
{{ c }}
{{ d.a }}, {{ d.b }}
'''
