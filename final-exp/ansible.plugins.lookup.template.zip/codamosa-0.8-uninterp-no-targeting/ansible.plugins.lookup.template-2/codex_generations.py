

# Generated at 2022-06-21 06:37:55.897533
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_input = {
                  "terms": ["TESTTEMPLATE.j2"],
                  "variables": {"some_variable": "foo"},
                  "convert_data": False,
                  "template_vars": {"some_template_variable": "bar"},
                  "jinja2_native": False,
                  "variable_start_string": "{{",
                  "variable_end_string": "}}",
                  "comment_start_string": "#",
                  "comment_end_string": "#"
                  }

    expected_output = ["Hello I am a template and my variable is foo and my template variable is bar\n"]

    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()

# Generated at 2022-06-21 06:37:57.042064
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:38:02.641021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Example of how to use method run of class LookupModule

    # Extract required args from the call stack
    _terms = './some_template.j2'
    _variables = { 'ansible_search_path': '/path/to/file'}

    # Instantiate instance of class LookupModule
    lm = LookupModule()

    # Call method run of class LookupModule
    lm.run(_terms, _variables)



# Generated at 2022-06-21 06:38:03.083820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:38:15.732954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.utils.path import unfrackpath
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('template')

    # this test assumes Jinja2 native is off
    assert USE_JINJA2_NATIVE is False

    # template has a file 'test.j2' with content {{ bar }}
    # we pass a dictionary to the lookup that adds a var 'bar'
    # the templated file should have the content of bar
    template = lookup.run(['test.j2'], {'bar': 'foo'}, **{'variable_start_string': '[%', 'variable_end_string': '%]'})

    assert template == ['foo\n']

    # same test as above, but now with jinja2_native=True at the lookup level


# Generated at 2022-06-21 06:38:27.303675
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with jinja2_native: False
    display = Display()
    variables = {}
    templar = AnsibleEnvironment()
    lookupmodule = LookupModule()
    terms = ['./file.txt']
    lookupmodule._templar = templar
    lookupmodule.set_options(var_options=variables, direct={'jinja2_native': False})
    result = lookupmodule.run(terms, variables)
    assert result == ['{{ test }}']

    # Test with jinja2_native: True
    display = Display()
    variables = {}
    templar = AnsibleEnvironment()
    lookupmodule = LookupModule()
    terms = ['./file.txt']
    lookupmodule._templar = templar

# Generated at 2022-06-21 06:38:28.077331
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(None, None, None, None), LookupModule)

# Generated at 2022-06-21 06:38:28.952213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:38:30.830838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:38:37.474035
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert isinstance(module, LookupModule)
    assert isinstance(module.options, dict)
    assert isinstance(module.options['convert_data'], bool)
    assert isinstance(module.options['template_vars'], dict)
    assert isinstance(module._templar, object)

# Generated at 2022-06-21 06:38:54.551158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # test if the result of function 'find_file_in_search_path' is a file
    terms = [os.path.join(os.path.dirname(__file__), '../templates/good.j2')]
    result = lookup_module.run(terms=terms, variables={})
    assert os.path.isfile(result[0])
    # test if the result of function 'find_file_in_search_path' is None
    terms = ['../templates/bad.j2']
    try:
        lookup_module.run(terms=terms, variables={})
    except AnsibleError as e:
        message = "the template file %s could not be found for the lookup" % terms[0]
        assert message in str(e)

# Generated at 2022-06-21 06:39:04.385574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 06:39:06.278879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None, 'ansible.plugins.lookup.template.LookupModule() failed'

# Generated at 2022-06-21 06:39:10.566646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance._templar = "templar"
    lookup_instance._loader = "loader"
    lookup_instance._display = display
    assert isinstance(lookup_instance, LookupBase)
    assert isinstance(lookup_instance.run(["1.2.3.4"], "variables", "kwargs"), list)

# Generated at 2022-06-21 06:39:21.222059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugins = LookupModule()
    dummy_env = dict(
        ansible_search_path = [
            '/etc/ansible/roles/role_under_test/vars',
            '/etc/ansible/roles/role_under_test/defaults',
            '/etc/ansible/roles/role_under_test/meta'
        ],
        ansible_local=dict(
            role_defaults=dict(
              role_under_test=dict(
                var1='myvar1',
                var2='myvar2'
              )
            )
        ),
        role_under_test_var1='value1'
    )

# Generated at 2022-06-21 06:39:22.282544
# Unit test for constructor of class LookupModule
def test_LookupModule():

   assert not LookupModule 


# Generated at 2022-06-21 06:39:25.149132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-21 06:39:33.020663
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleError
    from .fixtures import param_lookup_plugin_template_data as plugin_data

    terms = plugin_data['lookup_params']['terms']
    variables = plugin_data['lookup_params']['variables']
    kwargs = plugin_data['lookup_params']['kwargs']
    expected = plugin_data['expected_result']

    lm = LookupModule()

    results = lm.run(terms, variables, **kwargs)
    assert results == expected

    # test with option convert_data = False
    kwargs['convert_data'] = False

    results = lm.run(terms, variables, **kwargs)
    assert results == expected


# Generated at 2022-06-21 06:39:39.861131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data, terms, kwargs = None, None, None
    lookup = LookupModule()
    assert isinstance(lookup.run(terms, data, **kwargs), list)
    assert isinstance(lookup.run(terms, data, convert_data=True, **kwargs), list)
    assert isinstance(lookup.run(terms, data, jinja2_native=True, **kwargs), list)

# Generated at 2022-06-21 06:39:42.810397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor of class LookupModule
    """
    lookup_plugin = LookupModule()

    assert lookup_plugin is not None

# Generated at 2022-06-21 06:39:50.220391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:40:01.821364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import shutil

    # Setup
    # create a temporary folder
    path = './test_lookup_tmp'
    os.mkdir(path, 0o700)
    # create a temporary file
    name = 'test_lookup_tmp.yml'
    f = open(os.path.join(path, name), 'w')
    f.write('''
    - ansible_search_path:
        - '../test_lookup'
        - './test_lookup'
        - '../test_lookup/templates'
        - './test_lookup/templates'
    ''')
    f.close()
    # create a temporary file
    name = 'test_template.yml'

# Generated at 2022-06-21 06:40:09.637525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test with a simple template
    module.set_options(dict())
    terms = ['tests/test.j2']
    variables = dict()
    assert module.run(terms, variables) == ["test"]

    # now add a variable
    terms = ['tests/test.j2']
    variables = dict(myname="Andrew")
    assert module.run(terms, variables) == ["Hello Andrew"]

    # now add a variable using the extravars
    terms = ['tests/test.j2']
    extravars = dict(myname="Andrew")
    assert module.run(terms, variables, extravars) == ["Hello Andrew"]

    # now add a variable using the extravars takes precedence
    terms = ['tests/test.j2']
    variables = dict(myname="Paul")


# Generated at 2022-06-21 06:40:19.648142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' Unit test for constructor of class LookupModule '''
    print("Constructor of Class LookupModule")
    obj1 = LookupModule() 
    # Passing a mock object for ansible_playbook_python
    obj1.set_loader(loader=None)
    obj1.set_templar(templar=None)
    print ("obj1._templar ", obj1._templar)
    print ("obj1._loader ", obj1._loader)
    print ("obj1._options ", obj1._options)
    print ("obj1._display ", obj1._display)
    print ("obj1._ds", obj1._ds)

# Generated at 2022-06-21 06:40:27.804333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for method run of class LookupModule.
    """
    # Creation of expected result
    expected_result = [u'localhost ansible_connection=local']
    # Creation of instance
    LookupModule_instance = LookupModule()
    # Creation of argument terms
    terms = [u'./tests/templates/hosts']
    # Creation of argument variables
    variables = {u'template_hosts': u'localhost ansible_connection=local'}
    # Call of method
    result = LookupModule_instance.run(terms, variables)
    assert result == expected_result

# Generated at 2022-06-21 06:40:28.440576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 06:40:29.812786
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("constructor")
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:40:32.779740
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule
    """
    lookup_module_class = LookupModule
    lookup_plugin_class = LookupBase
    assert issubclass(lookup_module_class, lookup_plugin_class)

# Generated at 2022-06-21 06:40:44.657620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import AnsibleEnvironment
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # Make sure the tests are run in a directory containing the following files:
    #
    # templates/test_template.j2:
    #   Hello {{ name }}
    #
    # templates/Hello_World.j2:
    #   Hello world

    lookup_module = LookupModule()

    # These terms should be found and the results should be identical
    terms = ['./test_template.j2', 'Hello_World.j2']

# Generated at 2022-06-21 06:40:53.627073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    A unit test to ensure the run() code is working.

    """
    display = Display()
    display.v("Loaded test_LookupModule_run")

    assert LookupModule._get_template_class(AnsibleEnvironment()) == ansible.template.AnsibleJ2Template
    assert LookupModule._get_template_class(AnsibleEnvironment(variables={'ansible_use_jinja2_native': True})) == ansible.template.AnsibleNativeJ2Template
    assert LookupModule._get_template_class(AnsibleEnvironment(variables={'ansible_use_jinja2_native': False})) == ansible.template.AnsibleJ2Template

    # These tests also exercise some of the basic functionality of the templating engine and the
    # variable precedence rules.
    test_

# Generated at 2022-06-21 06:41:15.261165
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import Mapping
    from ansible.template import Templar
    from ansible.vars import VariableManager

    if USE_JINJA2_NATIVE:
        from ansible.utils.native_jinja import NativeJinjaText


# Generated at 2022-06-21 06:41:16.162101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Not implemented"

# Generated at 2022-06-21 06:41:28.319360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import pytest
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    from ansible.template import generate_ansible_template_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

    class TestLookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            if variables:
                self.set_options(var_options=variables, direct=kwargs)

            # capture options
            variable_start_string = self.get_option('variable_start_string')
            variable_end_string = self.get_option('variable_end_string')

# Generated at 2022-06-21 06:41:32.040298
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    class TestClass():
        def __init__(self, result):
            self._result = result

        def __call__(self, *args, **kwargs):
            return self._result

    terms = ['./some_template.j2']

    variables = {
        "ansible_search_path": [
            "./my/first/path",
            "./my/second/path"
        ]
    }

    kwargs = {
        "variable_start": '['
    }

    expected_args = [
        ['./some_template.j2'],
        None,
        {
            "variable_start_string": '['
        }
    ]


# Generated at 2022-06-21 06:41:37.666521
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    os.environ["ANSIBLE_LOOKUP_PLUGINS"] = os.path.join(os.path.dirname(__file__))
    test = LookupModule()
    test.run(terms = ["template_test.j2"], variables = {})
    os.environ["ANSIBLE_LOOKUP_PLUGINS"] = os.path.join(os.environ["ANSIBLE_HOSTS"], "lookup_plugins")

# Generated at 2022-06-21 06:41:45.057377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.template import LookupModule
    from ansible.vars.unsafe_proxy import AnsibleVars
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    vault_secrets = VaultLib([])
    host_vars = AnsibleVars(
        {
            'ansible_search_path': ['/etc/ansible/roles/role1/vars', '/etc/ansible/group_vars/group2'],
            'ansible_config': {'template_dir': '/etc/ansible/template_dir'},
            'ansible_host': 'host1'
        },
        vault_secrets=vault_secrets
    )
    templar = Templar(loader=None, variables=host_vars)


# Generated at 2022-06-21 06:41:45.944099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:41:48.568925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Hooray!')


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:41:58.603736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookupfile = lookup_module.find_file_in_search_path(dict(), 'templates', 'dir/file.j2')
    assert lookupfile == 'dir/file.j2'

    lookupfile = lookup_module.find_file_in_search_path(dict(), 'templates', 'file.j2')
    assert lookupfile == 'file.j2'

    lookupfile = lookup_module.find_file_in_search_path(dict(ansible_search_path=["/some/path"]), 'templates', 'file.j2')
    assert lookupfile == '/some/path/file.j2'


# Generated at 2022-06-21 06:42:00.312544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:42:31.213849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up our loader to load from the module directory
    test_loader = DictDataLoader({
        os.path.join(os.path.dirname(__file__), 'templates'): '../templates'})
    test_lookup = LookupModule()
    test_lookup._loader = test_loader  # pylint: disable=protected-access

    results = test_lookup.run([], {}, convert_data=True)
    assert results == []

    results = test_lookup.run(['test_template.j2'], {}, convert_data=True)
    assert results == ['Test template\n']

    # Test that passing kwargs that are not defined in DOCUMENTATION results in
    # an exception.

# Generated at 2022-06-21 06:42:32.155887
# Unit test for constructor of class LookupModule
def test_LookupModule():
  obj = LookupModule()
  assert obj != None

# Generated at 2022-06-21 06:42:34.561521
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')



# Generated at 2022-06-21 06:42:38.437498
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    test_name = "Theorem"
    test_variables = {}
    print(lookup_module.run(test_name, test_variables))

# Generated at 2022-06-21 06:42:39.113981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 06:42:44.632834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_text
    # test normal path
    assert LookupModule()

    # test error path
    assert not LookupModule(loader=None, templar=None)

# Generated at 2022-06-21 06:42:56.342762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock objects
    my_loader = MockLoader()
    my_loader.file_contents = {}
    my_loader._read_file.return_value = b"Hello world\n"
    my_loader.get_real_file.return_value = "./some_template.j2"
    my_loader.is_file.return_value = True

    my_env_class = MockEnvironment()
    my_env_class.get_template.return_value = "hello {{'world'}}!"
    my_env_class.from_string.return_value = "hello {{'world'}}!"

    my_templar = MockTemplar()

    # Inspected values
    # |test_LookupModule_run|>|my_module.run|>|my_module.find_file_in_search_path

# Generated at 2022-06-21 06:42:58.397391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.template import LookupModule
    LookupModule("dummy")


# Generated at 2022-06-21 06:43:01.506204
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._display == display

# Generated at 2022-06-21 06:43:09.012045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Create a mock object: a LookupBase object with
    # _templar field set to the given value.
    class MyLookupBase(LookupModule):
        def __init__(self, _templar):
            self._templar = _templar

    # Create a mock object: a Templar object with
    # method set_temporary_context, method template and
    # field searchpath

    class Templar:
        # Mock object: the context given to method template
        class Context:
            def __init__(self, searchpath):
                self.searchpath = searchpath

        # Mock object: the context given to method template
        def __init__(self, template_context):
            self._template_context = template_context


# Generated at 2022-06-21 06:43:55.566821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_buffer = LookupModule()
    assert lookup_module_buffer is not None

# Generated at 2022-06-21 06:43:59.985397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:44:05.597612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    # save original stdout value
    original_output = sys.stdout

    return_value = ['test_file_content']

    # create and use a temporary file as stdout
    with open(os.devnull, 'w') as f:
        sys.stdout = f
        lookup_module = LookupModule()
        assert lookup_module.run('test_file', None) == return_value

    # restore original stdout
    sys.stdout = original_output


# Generated at 2022-06-21 06:44:16.237726
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:44:25.944556
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestAnsibleModule():
        def __init__(self):
            self.params = {'debug': False}
        def fail_json(self, rc, msg):
            print("%d %s" % (rc, msg))

    class TestVariables():
        def __init__(self, dicts):
            self.dicts = dicts

        def __getitem__(self, index):
            return self.dicts[index]

        def __setitem__(self, index, value):
            self.dicts[index] = value

    class TestTemplar():
        def __init__(self, dicts):
            self.dicts = dicts

        def _get_new_context(self):
            return TestVariables(self.dicts)

    # Case 1:
    # Test Case with convert_

# Generated at 2022-06-21 06:44:28.094914
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('In test_LookupModule')
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(None)

# Generated at 2022-06-21 06:44:37.354971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit testing method run of class LookupModule """
    test_dir = os.path.dirname(__file__)

    # Test variable_start_string option
    variable_start_string_tests = [
        {'lookup_kwargs': {'variable_start_string': '[%'},
         'variable_start_string': '[%'},
    ]

    for test in variable_start_string_tests:
        lu = LookupModule()

# Generated at 2022-06-21 06:44:39.780877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _loader = 'ansible.parsing.dataloader.DataLoader'
    _templar = 'ansible.parsing.vault.VaultLib'
    lookup_m = LookupModule(_loader, _templar)
    assert lookup_m._templar == _templar
    assert lookup_m._loader == _loader

# Generated at 2022-06-21 06:44:40.339336
# Unit test for constructor of class LookupModule
def test_LookupModule():

    print(LookupModule)

# Generated at 2022-06-21 06:44:42.332327
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 06:46:18.969237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar, AnsibleEnvironment

    class LookupTestModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            return terms

    # https://github.com/ansible/ansible-modules-core/blob/devel/packaging/os/yum.py#L129-L237
    lookup_test_module = LookupTestModule()
    lookup_test_module.set_options(var_options=variables)

    # set jinja2 internal search path for includes
    searchpath = variables.get('ansible_search_path', [])

# Generated at 2022-06-21 06:46:24.528809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import StringIO
    from ansible.template import Templar

    orig_exists = os.path.exists
    orig_getmtime = os.path.getmtime
    orig_abspath = os.path.abspath
    orig_isdir = os.path.isdir
    orig_isfile = os.path.isfile
    orig_open = open

    exists_calls = []
    getmtime_calls = []
    abspath_calls = []
    isdir_calls = []
    isfile_calls = []
    open_calls = []

    def mock_exists(path):
        exists_calls.append(path)

# Generated at 2022-06-21 06:46:26.401944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:46:37.040622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-variable
    #
    # Input data
    test_terms = [ './some_template.j2' ]
    test_variables = { 'test_var': "Test variable" }
    test_options = { 'convert_data': True, 'template_vars': { 'test_opt': "Test option" },
                     'variable_start_string': '[%', 'variable_end_string': '%]',
                     'comment_start_string': '[#', 'comment_end_string': '#]' }

    # Set up the test object
    test_obj = LookupModule()

    # Test with an object that does not support _loader.
    from ansible.parsing.dataloader import DataLoader
    test_obj._loader = DataLoader()

# Generated at 2022-06-21 06:46:39.061645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(["./tests/lookup_plugins/template_test.j2"], {}, jinja2_native=True)

# Generated at 2022-06-21 06:46:39.686719
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:46:43.886641
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule != None

# Generated at 2022-06-21 06:46:48.217577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert LookupModule(templar=templar, loader=None).run(["/usr/bin"], {})[0] == '/usr/bin'

# Generated at 2022-06-21 06:46:49.164835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule())

# Generated at 2022-06-21 06:46:55.522177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    lookup_cls = lookup_loader.get('template')

    terms = ['plugins/lookup/templates/index.j2']
    variables = dict()

    ret = lookup_cls.run([terms], variables, convert_data=True, jinja2_native=False)
