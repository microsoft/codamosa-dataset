

# Generated at 2022-06-21 06:37:45.353208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-21 06:37:56.891708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test with no parameters
    assert isinstance(LookupModule(), LookupModule)

    # noinspection PyMethodMayBeStatic
    lookup = LookupModule()

    expected_options = {'_terms': None,
                        'variable_end_string': '}}',
                        'convert_data': False,
                        'jinja2_native': False,
                        'variable_start_string': '{{',
                        'template_vars': None,
                        'comment_end_string': None,
                        'comment_start_string': None}

    # test with different options
    for option, expected_value in expected_options.items():
        options = {option: expected_value}
        lookup.set_options(direct=options)
        assert lookup.get_option(option) == expected_value

    # test with options with invalid names


# Generated at 2022-06-21 06:37:57.906340
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 06:38:06.600429
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')
        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    class TestLookupBase(LookupBase):
        def __init__(self, *args, **kwargs):
            self._templar = kwargs.get('templar')
            self._loader = kwargs.get('loader')

    import jinja2

# Generated at 2022-06-21 06:38:18.863104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mocks
    # pylint: disable=import-error
    import ansible.plugins.loader
    # pylint: enable=import-error
    # pylint: disable=unused-argument
    def mock_get_file_contents(filename, metadata=False):
        template_data = "Hello World"
        return (to_bytes(template_data), metadata)
    # pylint: enable=unused-argument
    # pylint: disable=attribute-defined-outside-init

# Generated at 2022-06-21 06:38:29.822668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.hashing import md5s
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.compat.tests import unittest

    if not USE_JINJA2_NATIVE:
        # Test class is designed to test the native mode. As this
        # mode is now the default, we can omit the test.
        pass
    else:
        class TestLookupModule(unittest.TestCase):

            def setUp(self):
                self._loader = DataLoader()
                self._variable_manager = VariableManager()

            def tearDown(self):
                pass

            def test_int_value(self):
                test_template = """
{{myvar}}
"""
                lookupobj = LookupModule()
                lookupobj._

# Generated at 2022-06-21 06:38:35.714525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testobj = LookupModule()
    term_result = testobj.run(terms=["template_test.j2"], variables={}, convert_data=True, jinja2_native=False)
    assert "lookup_template" == term_result[0]

# Generated at 2022-06-21 06:38:36.746130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 06:38:46.153591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    filename = 'lookup_plugin.py'
    with open(filename, 'r') as f:
        data = f.read()

    lookup_module._loader = DictDataLoader({'lookup_plugin.py': data})
    lookup_module._templar = DummyTemplar()

    terms = [u'lookup_plugin.py']

    ret = lookup_module.run(terms=terms, variables={u'ansible_search_path': [u'.']}, convert_data=True)

    assert [data] == ret
    assert False == isinstance(ret[0], NativeJinjaText)


test_LookupModule_run()

# Generated at 2022-06-21 06:38:57.826695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # Should raise an error if the file does not exist
    try:
        lm.run(["missing_file"], dict())
    except AnsibleError as e:
        assert e.args[0] == "the template file missing_file could not be found for the lookup"
    else:
        assert False, "Should raise an error if the file does not exist"

    # Should return the contents of the file

# Generated at 2022-06-21 06:39:07.936915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    jinja2_native = True
    lookup_template_vars = {'ansible_facts': {'a': 'b'}, 'c': 'd'}
    lookup_options = {'jinja2_native': jinja2_native, 'template_vars': lookup_template_vars}
    lookup = LookupModule()
    lookup.set_options(lookup_options)
    lookup_options2 = lookup.get_options()
    assert jinja2_native == lookup_options2['jinja2_native']
    assert lookup_template_vars == lookup_options2['template_vars']

# Generated at 2022-06-21 06:39:09.771843
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global display
    display = Display()
    assert isinstance(display, Display)
    # Initialize class LookupModule
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:39:19.701850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Unused imports
    import ansible.modules.extras.web_infrastructure.template as tpl
    import ansible.parsing.dataloader as dl
    import ansible.vars.manager as vm
    import ansible.cli.adhoc as adhoc
    import ansible.cli.playbook as pb
    import ansible.parsing.splitter as splitter
    import ansible.playbook.play_context as pc
    import ansible.template as template
    import ansible.utils.vars as vars
    import ansible.inventory.manager as im
    import ansible.playbook.play as play
    import ansible.plugins.loader as pl
    import ansible.plugins.strategy.linear as linear
    import ansible.inventory.host as host

# Generated at 2022-06-21 06:39:27.729863
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar

    # Create a test object
    # Input is a list (of list of dict) as terms
    test_obj = LookupModule()
    test_list = [
        [{'key': 'value', 'key2': 'value2'}],
    ]
    test_obj.set_options({'_terms': test_list})

    # Assert that the run method has a return value
    assert test_obj.run(test_list, {}), "LookupModule must return a value"



# Generated at 2022-06-21 06:39:28.576868
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check that an object of class LookupModule can be created
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:39:35.147517
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test setup:
    # Ensure that the Jinja2 environment is in a consistent state
    # across all tests by starting each test from scratch.
    from ansible.template import AnsibleJ2
    AnsibleJ2.ENV = AnsibleJ2._get_new_environment(
        extensions=AnsibleJ2.ENV.extensions)

    import os
    import sys
    import shutil
    from datetime import datetime
    from ansible.module_utils.six import PY2

    if PY2:
        from StringIO import StringIO
    else:
        from io import StringIO

    import pytest

    def sysexit(orig_args):
        raise SystemExit()
    # Replace sys.exit with a function that raises an exception
    orig_sysexit = sys.exit
    sys.exit = sysex

# Generated at 2022-06-21 06:39:47.611976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def __init__(self):
        self.loader = 'test_loader'
        self._templar = 'test_templar'
        self.paths = ['c:/', 'd:/']
        self.basedir = None

        self.get_option = ('convert_data', False)

        self._display = Display()

    testlookup = LookupModule()
    assert testlookup.paths == ['c:/', 'd:/']
    assert testlookup.get_option == ('convert_data', False)
    assert testlookup.basedir == None
    assert testlookup.loader == 'test_loader'
    assert testlookup._templar == 'test_templar'
    assert testlookup._display.verbosity == 0
    testlookup.__init__()

# Generated at 2022-06-21 06:39:58.798406
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms = ['test_template.j2']

    variables = {
        'key1': 'val1',
        'key2': 'val2',
    }

    options = {
        'variable_start_string': '{{',
        'variable_end_string': '}}',
    }

    res = module.run(terms, variables, **options)

    assert res is not None, 'Test template lookup should not return None'
    assert len(res) == 1, 'Test template lookup should return a list with one element'
    assert res[0] == 'val1val2', 'Test template lookup should render the template with the given variables'

# Generated at 2022-06-21 06:39:59.463771
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run([], {})) == 0


# Generated at 2022-06-21 06:40:00.190351
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    pass

# Generated at 2022-06-21 06:40:19.110200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ut_terms = ['example.txt']
    ut_variables = dict(
        test_var='test value',
        unittest_var='unit test value',
    )
    lookup_obj = LookupModule()
    # assert the instantiation of LookupModule object
    assert lookup_obj is not None,\
        'Unable to create LookupModule object'
    # run the LookupModule run()
    result = lookup_obj.run(ut_terms, ut_variables)
    assert result == ['hello world\n'],\
        'template lookup failed'

# Generated at 2022-06-21 06:40:19.752690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pass
    return

# Generated at 2022-06-21 06:40:21.229099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert isinstance(mod, LookupModule)

# Generated at 2022-06-21 06:40:27.700134
# Unit test for constructor of class LookupModule
def test_LookupModule():
    arguments = {
        '_terms': './some_template.j2',
        'variable_start_string': '{',
        'variable_end_string': '}',
        'comment_start_string': '{#',
        'comment_end_string': '#}'
    }

    look = LookupModule()
    look.set_options(var_options = arguments, direct = {})

    return look


# Generated at 2022-06-21 06:40:29.910686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup != None)

# Unit test function for copy_with_new_env of class AnsibleEnvironment

# Generated at 2022-06-21 06:40:39.434809
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a mock class with the return values for the run() method
    class LookupModuleMock(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_module = LookupModuleMock()

    assert lookup_module.run(terms=['test_term1', 'test_term2'], variables=[], convert_data=True, template_vars={},
                        jinja2_native=False, variable_start_string='test_variable_start_sting',
                        variable_end_string='test_variable_end_sting', comment_start_string='test_comment_start_string',
                        comment_end_string='test_comment_end_string') == ['test_term1', 'test_term2']



# Generated at 2022-06-21 06:40:48.332262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the method run of class LookupModule

    :return:
    """
    # Create a object of class LookupModule
    templ = LookupModule()

    # Test the run function of class LookupModule
    # Expected result:
    #   A list with 'Hello' and 'World'
    terms = ['hello.j2', 'world.j2']
    vars = {'tst': 'tst content'}
    expected_result = ['Hello', 'World']
    assert templ.run(terms, vars) == expected_result

# Generated at 2022-06-21 06:40:53.091099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # use a bogus template path to trigger the error
    lookup_module = LookupModule()
    try:
        lookup_module.run(['./some_template.j2'], {'ansible_search_path': ['/some/path']})
    except AnsibleError as e:
        if 'the template file ./some_template.j2 could not be found for the lookup' in to_text(e):
            pass
        else:
            raise

# Generated at 2022-06-21 06:40:55.092233
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:41:07.326027
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    import os
    import yaml
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    # run

# Generated at 2022-06-21 06:41:36.616064
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = AnsibleModule(
        argument_spec = {
            '_terms': dict(required=True, type='list'),
            'convert_data': dict(default=False, type='bool'),
            'template_vars': dict(default=None, type='dict')
        },
        supports_check_mode=True
    )

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=module.params['_terms'],
                               convert_data=module.params['convert_data'],
                               template_vars=module.params['template_vars'],
                               variables={'playbook_dir': os.getcwd()}
                           )
    return result

# Generated at 2022-06-21 06:41:41.180971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    print(lookup_plugin.run(['*.j2'], {}, convert_data=True))

    # TODO: extend this unit test to also check for the .j2 file.
    # For example: create a .j2 file in the current working dir, add values for the
    # run method, you can delete the .j2 file in the end of the unit test

# Generated at 2022-06-21 06:41:41.854747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run()

# Generated at 2022-06-21 06:41:54.133446
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock object for templar
    class Templar:

        def __init__(self):

            self.env = None
            self.context = None

        def copy_with_new_env(self, environment_class):
            self.env = environment_class
            return self


# Generated at 2022-06-21 06:42:03.116951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    templar = AnsibleEnvironment(loader=None)
    lookup_plugin._templar = templar.copy()

    with pytest.raises(AnsibleError) as exec_info:
        lookup_plugin.run([], dict(path=['roles/common/files/']))

    assert 'the template file .*.j2 could not be found for the lookup' in to_text(exec_info.value)
    assert exec_info.value.obj is None
    assert exec_info.value.args == ([],)
    assert exec_info.value.kwargs == dict(problem="the template file .*.j2 could not be found for the lookup")

# Generated at 2022-06-21 06:42:08.922903
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    import os
    import tempfile

    # create a file to be used by the templating system
    testfile = tempfile.mkstemp()
    os.write(testfile[0], "{{value}}")
    os.close(testfile[0])

    # create a lookup module
    lookup = LookupModule()

    # set the templating engine to use the file created
    searchpath = [tempfile.mkdtemp()]
    lookup._loader.set_basedir(searchpath[0])
    os.symlink(os.path.realpath(testfile[1]), os.path.join(searchpath[0], 'file.j2'))

    # set the variable the template system need to use

# Generated at 2022-06-21 06:42:17.525804
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor test
    """
    terms = ["first.j2", "second.j2", "third.j2"]
    global_vars = dict(blabla="blabla")
    lookup_templ_vars = dict(bli="bli")

    assert 'template' == LookupModule.lookup_type
    assert {'_terms', '_raw'} == set(LookupModule.documentation_variables)

    lookup = LookupModule()


# Generated at 2022-06-21 06:42:29.132939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    lookup = LookupModule()
    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=('localhost,'))
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    lookup._loader = loader
    lookup._templar = templar

    path = os.path.dirname(__file__) + "/../../../examples/files"
    term = 'test-with-jinja2.j2'

# Generated at 2022-06-21 06:42:30.376389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup is not None)

# Generated at 2022-06-21 06:42:30.902009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(True)

# Generated at 2022-06-21 06:43:10.830739
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._templar == None

# Generated at 2022-06-21 06:43:23.234356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["some_template.j2"]

# Generated at 2022-06-21 06:43:28.805600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule() # Instantiated object of class LookupModule
    print ("Unit test for method run of class LookupModule")
    lookup.run()
    # lookup.run(terms, variables, **kwargs)
    #print ("\n")


test_LookupModule_run()

# Generated at 2022-06-21 06:43:30.622797
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor test
    """
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-21 06:43:32.901884
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:43:42.148296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no template_vars
    lookup_module = LookupModule()
    variable_manager = {}
    variable_manager['ansible_search_path'] = [os.path.join(os.path.expanduser('~'), 'ansible', 'test')]
    variable_manager['convert_data'] = [True]
    variable_manager['template_vars'] = {}
    variable_manager['variable_start_string'] = '{{'
    variable_manager['variable_end_string'] = '}}'
    variable_manager['comment_start_string'] = '{#'
    variable_manager['comment_end_string'] = '#}'

# Generated at 2022-06-21 06:43:52.246672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template.template import AnsibleTemplate
    from ansible.module_utils.six import PY3

    # Initializing instances for testing
    lookup = LookupModule()
    test_loader = DictDataLoader({
        "test/test_template.j2": b"{{test_variable}}"
    })
    test_templar = Templar(loader=test_loader)

    # Initializing test arguments
    terms = ["test/test_template.j2"]
    variables = dict(test_variable="test_value")

    # Run test
    res = lookup.run(terms, variables, _templar=test_templar, _loader=test_loader)

    # Assert results
    if PY3:
        assert(res == [u"test_value"])

# Generated at 2022-06-21 06:43:57.299267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test
    lookup_module = LookupModule()

    # Run test
    # File used for testing can be found in test_lookup_plugins
    terms = ['test_template.j2']
    variables = {'var_1': ['test1', 'test2', 'test3']}
    expected_result = ['This is a test with a list\n']
    result = lookup_module.run(terms, variables)
    assert result == expected_result, "Error testing template lookup plugin"
    # Reset test
    lookup_module = None
    result = None
    expected_result = None
    terms = None
    variables = None

# Generated at 2022-06-21 06:44:09.470123
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

    display.debug.assert_called_with("File lookup term: %s" % './some_template.j2')

    lookupfile = lm.find_file_in_search_path(variables, 'templates', './some_template.j2')
    display.vvvv.assert_called_with("File lookup using %s as file" % lookupfile)

    if lookupfile:
        b_template_data, show_data = lm._loader._get_file_contents(lookupfile)
        template_data = to_text(b_template_data, errors='surrogate_or_strict')

        searchpath = variables.get('ansible_search_path', [])
        if searchpath:
            newsearchpath = []
            for p in searchpath:
                new

# Generated at 2022-06-21 06:44:13.505423
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run is not None, 'LookupModule.run() is None'
    assert lm.run_terms is not None, 'LookupModule.run_terms() is None'

# Generated at 2022-06-21 06:45:49.969241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run(['templates/template_test.j2'], {}) is None

# Generated at 2022-06-21 06:46:00.653277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a file that does not contain any
    # jinja2 template variables
    foo = LookupModule()
    options = { 'template_vars': {} }
    terms = []
    terms.append('default/main.yml')
    terms.append('default/template.j2')
    variables = {}
    b_result = foo.run(terms, variables, **options)
    result = []
    for i in b_result:
        result.append(to_text(i))
    assert result == [u'---\n', u'{#\n', u'code\n', u'#}\n']

    # Test with a file that contains one jinja2
    # template variables
    foo = LookupModule()
    options = { 'template_vars': {} }
    terms = []
    terms

# Generated at 2022-06-21 06:46:02.524113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-21 06:46:13.995701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    import yaml
    import jinja2

    template_str = """
    {% for i in range(5) %}
    {{ lookup('pipe', 'echo {{i}}') }}
    {% endfor %}
    """

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager()

# Generated at 2022-06-21 06:46:21.665118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.facts_modules import FactsModule

    # Create a valid variables for the setup
    variables = dict()
    variables['ansible_facts'] = dict()
    variables['ansible_facts']['ansible_env'] = dict()
    variables['ansible_facts']['ansible_env']['LANGUAGE'] = 'en_US.UTF-8'
    variables['ansible_facts']['ansible_env']['LC_ALL'] = 'en_US.UTF-8'
    variables['ansible_facts']['ansible_env']['LC_LANG'] = 'en_US.UTF-8'
    variables['ansible_facts']['ansible_env']['LANG'] = 'en_US.UTF-8'

# Generated at 2022-06-21 06:46:26.170239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fd, path = tempfile.mkstemp()
    os.write(fd, b"Hello, world!")
    os.close(fd)
    term = path
    terms = [term]
    variables = dict()
    result = LookupModule.run(terms, variables)
    assert(result == ["Hello, world!"])

# Generated at 2022-06-21 06:46:36.838730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'foo.j2',
        'does_not_exist.j2'
    ]
    test_dir = os.path.dirname(os.path.realpath(__file__))
    std_templates_dir = os.path.join(test_dir, 'templates')
    variables = {
        'a': 'test-a',
        'b': 'test-b',
        'ansible_search_path': [std_templates_dir],
        'template_vars': {
            'test_var': 'test-var'
        }
    }
    kwargs = {}

    module_ob = LookupModule()
    module_ob.set_options(var_options=variables, direct=kwargs)

    module_ob.set_loader(None)


# Generated at 2022-06-21 06:46:40.506652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    lu.set_options(var_options=dict(), direct=dict())
    # Assert: content of file test_template_content is correctly replaced in the template
    assert lu.run(["./plugins/lookup/test_template_content"],dict()) == [to_text("This is a test file for the template lookup plugin.")]

# Generated at 2022-06-21 06:46:52.911816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import constants as C

    # Method run of class LookupModule
    #     def run(self, terms, variables=None, **kwargs):
    #
    #  (1) 'terms' argument
    #
    #       maybe_list() returns a list if the input is a string; otherwise, it is returned as is.
    #       lookup_loader_names() returns a list whose elements are:
    #
    #         lookup_loader_name, lookup_loader_class, lookup_loader_module, lookup_loader_package

    terms = LookupBase._make_terms('foo', None)
    print(terms)


    #  (2) 'variables' argument
    #
    #       A dict corresponding the variables in scope
    #
    #       It has at least the following keys:
    #         ansible_check

# Generated at 2022-06-21 06:46:55.885648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()
    terms = ['lookup_fixture.j2']
    variables = {}
    result = instance.run(terms, variables)
    assert result == ['lookup_fixture\n']
