

# Generated at 2022-06-22 16:49:01.755582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_playbook_vars

# Generated at 2022-06-22 16:49:13.221166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object for the templar class
    class MockTemplar:
        def __init__(self):
            self.template_data = None
            self.vars = None
            self.searchpath = None
            self.variable_start_string = None
            self.variable_end_string = None
            self.comment_start_string = None
            self.comment_end_string = None

        def copy_with_new_env(self, environment_class):
            return self

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables, searchpath):
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string
            self.comment_

# Generated at 2022-06-22 16:49:23.725933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a file that exists
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({'test.j2': b'{{ test }}'}))
    lookup_module._templar = Templar(loader=lookup_module._loader, variables={'test': 'success'})
    assert lookup_module.run(['test.j2'], {}, convert_data=True) == ['success']

    # Test with a file that does not exist
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({}))
    lookup_module._templar = Templar(loader=lookup_module._loader, variables={'test': 'success'})

# Generated at 2022-06-22 16:49:36.914817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({'test.j2': b'Hello {{ name }}'}))
    lookup_module.set_templar(DictTemplate({}))
    assert lookup_module.run(['test.j2'], {'name': 'world'}) == ['Hello world']

    # Test with a template containing a newline
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({'test.j2': b'Hello {{ name }}\n'}))
    lookup_module.set_templar(DictTemplate({}))
    assert lookup_module.run(['test.j2'], {'name': 'world'}) == ['Hello world\n']

    #

# Generated at 2022-06-22 16:49:46.075667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a class object
    lookup_module = LookupModule()

    # Create a dictionary
    terms = ['./some_template.j2']
    variables = {'ansible_search_path': ['/home/user/ansible/']}
    kwargs = {'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': '{#', 'comment_end_string': '#}'}

    # Call method run of class LookupModule
    result = lookup_module.run(terms, variables, **kwargs)

    # Assertion
    assert result == ['Hello World']

# Generated at 2022-06-22 16:49:56.215157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup = lookup_loader.get('template')

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    lookup._templar = templar

    lookup.set_options(direct={'template_vars': {'foo': 'bar'}})

    assert lookup.run(['test.j2'], variable_manager.get_vars()) == ['foo is bar']

# Generated at 2022-06-22 16:50:04.857734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of terms
    terms = ['./some_template.j2']

    # Create a dictionary of variables
    variables = {}

    # Create a dictionary of kwargs
    kwargs = {}

    # Call the run method of LookupModule object
    result = lookup_module.run(terms, variables, **kwargs)

    # Check the result
    assert result == ['{{ lookup(\'template\', \'./some_template.j2\') }}']

# Generated at 2022-06-22 16:50:15.368806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar object
    class MockTemplar:
        def __init__(self, template_data, vars):
            self.template_data = template_data
            self.vars = vars
            self.template_called = False
            self.set_temporary_context_called = False
            self.set_temporary_context_called_with = None

        def template(self, template_data, preserve_trailing_newlines=True, convert_data=False, escape_backslashes=False):
            self.template_called = True
            assert template_data == self.template_data
            assert preserve_trailing_newlines == True
            assert convert_data == False
            assert escape_backslashes == False
            return template_data


# Generated at 2022-06-22 16:50:27.424379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with jinja2_native=False
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()
    lookup_module._loader = DictDataLoader({'test.j2': b'{{ test_var }}'})
    lookup_module._display = Display()
    lookup_module._options = {'convert_data': False, 'template_vars': {'test_var': 'test_value'}}
    assert lookup_module.run(['test.j2'], {}) == ['test_value']

    # Test with jinja2_native=True
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()
    lookup_module._loader = DictDataLoader({'test.j2': b'{{ test_var }}'})


# Generated at 2022-06-22 16:50:40.331170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-22 16:50:55.948220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a file that exists
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({'test.j2': b'{{ foo }}'})
    lookup_module._templar = Templar(variables={'foo': 'bar'})
    assert lookup_module.run(['test.j2'], variables={'foo': 'bar'}) == ['bar']

    # Test with a file that doesn't exist
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({})
    lookup_module._templar = Templar(variables={'foo': 'bar'})
    try:
        lookup_module.run(['test.j2'], variables={'foo': 'bar'})
        assert False
    except AnsibleError:
        pass


# Unit test

# Generated at 2022-06-22 16:51:07.062069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({
        './some_template.j2': '{{ foo }}',
        './some_template_with_vars.j2': '{{ foo }}{{ bar }}',
    }))
    lookup_module.set_templar(DictTemplate())
    lookup_module.set_basedir('/some/path')
    lookup_module.set_vars({'foo': 'foo', 'bar': 'bar'})
    assert lookup_module.run(['some_template.j2'], {}) == ['foo']
    assert lookup_module.run(['some_template_with_vars.j2'], {'template_vars': {'bar': 'baz'}}) == ['foobaz']
    assert lookup

# Generated at 2022-06-22 16:51:18.052475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object for the templar
    class MockTemplar(object):
        def __init__(self):
            self.template_data = None
            self.vars = None
            self.searchpath = None
            self.variable_start_string = None
            self.variable_end_string = None
            self.comment_start_string = None
            self.comment_end_string = None
            self.convert_data = None
            self.escape_backslashes = None
            self.preserve_trailing_newlines = None

        def template(self, template_data, preserve_trailing_newlines=True, convert_data=False, escape_backslashes=False):
            self.template_data = template_data
            self.preserve_trailing_newlines = preserve_trailing_new

# Generated at 2022-06-22 16:51:31.037898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._loader = DummyLoader({'test.j2': '{{ test_var }}'})
    lookup_module._display = DummyDisplay()
    lookup_module.set_options(direct={'convert_data': False})
    result = lookup_module.run(['test.j2'], {'test_var': 'test_value'})
    assert result == ['test_value']

    # Test with a template containing a jinja2 native type
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._loader = DummyLoader({'test.j2': '{{ test_var }}'})
   

# Generated at 2022-06-22 16:51:44.200592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object of class LookupBase
    lookup_base = LookupBase()

    # Create a mock object of class LookupModule
    lookup_module = LookupModule()

    # Create a mock object of class AnsibleEnvironment
    ansible_environment = AnsibleEnvironment()

    # Create a mock object of class AnsibleEnvironment
    ansible_environment = AnsibleEnvironment()

    # Create a mock object of class AnsibleEnvironment
    ansible_environment = AnsibleEnvironment()

    # Create a mock object of class AnsibleEnvironment
    ansible_environment = AnsibleEnvironment()

    # Create a mock object of class AnsibleEnvironment
    ansible_environment = AnsibleEnvironment()

    # Create a mock object of class AnsibleEnvironment
    ansible_environment = AnsibleEnvironment()

    # Create a mock object of class AnsibleEnvironment
    ansible_environment

# Generated at 2022-06-22 16:51:56.469845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({
        'test.j2': '{{ foo }}',
    })
    lookup_module._templar = Templar(loader=lookup_module._loader)
    result = lookup_module.run(['test.j2'], dict(foo='bar'))
    assert result == ['bar']

    # Test with a template containing a loop
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({
        'test.j2': '{% for i in range(0, 3) %}{{ i }}{% endfor %}',
    })
    lookup_module._templar = Templar(loader=lookup_module._loader)

# Generated at 2022-06-22 16:52:08.454179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({
        'test_template.j2': b'Hello {{ name }}',
    }))
    lookup_module.set_templar(DictTemplate({
        'name': 'world',
    }))
    assert lookup_module.run(['test_template.j2'], {}) == ['Hello world']

    # Test with a template that uses a variable from the template_vars option
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({
        'test_template.j2': b'Hello {{ name }}',
    }))
    lookup_module.set_templar(DictTemplate({}))

# Generated at 2022-06-22 16:52:21.242732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()
    lookup_module._loader = DictDataLoader({'test.j2': '{{ foo }}'})
    lookup_module._display = Display()
    lookup_module._options = {'convert_data': False, 'template_vars': {'foo': 'bar'}}
    assert lookup_module.run(['test.j2'], {}) == ['bar']

    # Test with a template that uses a variable
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()
    lookup_module._loader = DictDataLoader({'test.j2': '{{ foo }}'})
    lookup_module._display = Display()

# Generated at 2022-06-22 16:52:27.316270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()
    lookup_module._loader = DictDataLoader({
        'test_template.j2': '{{ test_var }}',
    })
    lookup_module._display = Display()
    lookup_module._display.verbosity = 4
    lookup_module._display.debug = True

    # test with convert_data=True
    result = lookup_module.run([
        'test_template.j2',
    ], {
        'test_var': 'test_value',
    }, convert_data=True)
    assert result == ['test_value']

    # test with convert_data=False

# Generated at 2022-06-22 16:52:38.168872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object for the templar class
    class MockTemplar:
        def __init__(self):
            self.template_data = None
            self.vars = None
            self.searchpath = None
            self.variable_start_string = None
            self.variable_end_string = None
            self.comment_start_string = None
            self.comment_end_string = None

        def copy_with_new_env(self, environment_class):
            return self

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables, searchpath):
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string
            self.comment_

# Generated at 2022-06-22 16:53:00.730157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.urls import open_url

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-22 16:53:12.276270
# Unit test for method run of class LookupModule

# Generated at 2022-06-22 16:53:20.638202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no template_vars
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({
        'test_template.j2': 'Hello {{ lookup("env", "USER") }}',
    }))
    lookup_module.set_templar(DictTemplate())
    result = lookup_module.run(['test_template.j2'], {}, convert_data=False)
    assert result == ['Hello root']

    # Test with template_vars
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({
        'test_template.j2': 'Hello {{ lookup("env", "USER") }}',
    }))
    lookup_module.set_templar(DictTemplate())

# Generated at 2022-06-22 16:53:32.803024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.template import Templar

    # Create a mock environment
    class Environment:
        def __init__(self, variables):
            self.variables = variables

        def get_basedir(self):
            return '.'

        def get_vars(self):
            return self.variables

        def get_tmp_path(self):
            return '/tmp'

    # Create a mock loader
    class Loader:
        def __init__(self, basedir):
            self.basedir = basedir


# Generated at 2022-06-22 16:53:42.529220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create a template
    template = Templar(loader=loader, variables=variable_manager)

    # Create a lookup module
    lookup_module = LookupModule()

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create a template
    template = Templar(loader=loader, variables=variable_manager)

    # Create a lookup module
    lookup_module = LookupModule()

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()



# Generated at 2022-06-22 16:53:51.081279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a mock environment with a fake ansible.cfg

# Generated at 2022-06-22 16:53:52.598612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None
    lookup.set_options(var_options={}, direct={})
    assert lookup.run(terms=['test.j2'], variables={}) == []

# Generated at 2022-06-22 16:54:01.770738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    terms = ['test_template.j2']

# Generated at 2022-06-22 16:54:14.371151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a variable
    variable = {'ansible_search_path': ['/home/ansible/test/']}

    # Create a term
    term = 'test.j2'

    # Create a template
    template = '{{ ansible_managed }}'

    # Create a file
    file = open('/home/ansible/test/test.j2', 'w')
    file.write(template)
    file.close()

    # Test the run method
    assert lookup_module.run(terms=term, variables=variable) == [u'# Ansible managed: Do NOT edit this file manually!']

    # Remove the file

# Generated at 2022-06-22 16:54:22.030353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a template file that contains a variable
    # and a template file that contains a jinja2 include
    # and a template file that contains a jinja2 include
    # with a variable
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module.set_templar(None)
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.set_options(var_options={'ansible_search_path': ['.']}, direct={})
    assert lookup_module.run(['test_template_with_variable.j2'], {}) == ['test_template_with_variable']
    assert lookup_module.run(['test_template_with_include.j2'], {}) == ['test_template_with_include']


# Generated at 2022-06-22 16:54:51.156990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({
        'test.j2': b'{{ test }}',
    }))
    lookup_module.set_templar(DictTemplate())
    lookup_module.set_options(var_options={'test': 'test'})
    assert lookup_module.run(['test.j2'], {}) == ['test']

    # Test with a template that uses a variable
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({
        'test.j2': b'{{ test }}',
    }))
    lookup_module.set_templar(DictTemplate())

# Generated at 2022-06-22 16:55:01.188297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with jinja2_native=False
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()
    lookup_module._loader = DictDataLoader({'test_template.j2': '{{ test_var }}'})
    lookup_module._display = Display()
    lookup_module._display.verbosity = 2
    lookup_module._options = {'convert_data': False, 'template_vars': {'test_var': 'test_value'}}
    assert lookup_module.run(['test_template.j2'], {}) == ['test_value']

    # Test with jinja2_native=True
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()

# Generated at 2022-06-22 16:55:13.038322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({'test.j2': b'{{ foo }}'}))
    lookup_module.set_templar(DictTemplate())
    assert lookup_module.run(['test.j2'], {'foo': 'bar'}) == ['bar']

    # Test with a template that includes another template
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({'test.j2': b'{{ foo }}\n{% include "test2.j2" %}', 'test2.j2': b'{{ bar }}'}))
    lookup_module.set_templar(DictTemplate())

# Generated at 2022-06-22 16:55:23.409652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class TestCallbackModule(CallbackBase):
        """A sample callback module used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-22 16:55:36.285295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dict object
    terms = ['./some_template.j2']

# Generated at 2022-06-22 16:55:48.635484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'template_vars': {'var1': 'value1'}})
    lookup_module._templar.set_available_variables({'var2': 'value2'})
    lookup_module._loader.set_basedir('/tmp')
    lookup_module._loader.path_dwim_relative = lambda x, y: '/tmp/' + x
    lookup_module._loader._get_file_contents = lambda x: (b'{{ var1 }} {{ var2 }}', False)
    assert lookup_module.run(['test.j2'], {}) == ['value1 value2']

    # Test with a template containing a jinja2 comment
    lookup_module = LookupModule()
    lookup

# Generated at 2022-06-22 16:55:55.522245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple template
    # Test with a simple template
    lookup = LookupModule()
    lookup.set_loader(DictDataLoader({
        'test.j2': b'{{ foo }}',
    }))
    lookup.set_templar(DictTemplate())
    assert lookup.run(['test.j2'], {'foo': 'bar'}) == ['bar']

    # Test with a template that uses a variable start and end string
    lookup = LookupModule()
    lookup.set_loader(DictDataLoader({
        'test.j2': b'[% foo %]',
    }))
    lookup.set_templar(DictTemplate())

# Generated at 2022-06-22 16:56:07.682162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a template file that contains a variable
    # and a template file that contains a jinja2 expression
    # and a template file that contains a jinja2 expression
    # with a variable
    lookup_module = LookupModule()
    lookup_module._templar = AnsibleEnvironment()
    lookup_module._loader = DictDataLoader({
        'test_template_with_variable.j2': '{{ test_variable }}',
        'test_template_with_expression.j2': '{{ 1 + 1 }}',
        'test_template_with_variable_and_expression.j2': '{{ test_variable + 1 }}'
    })
    lookup_module._templar.environment.loader = lookup_module._loader

# Generated at 2022-06-22 16:56:14.911983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_inventory_

# Generated at 2022-06-22 16:56:25.555114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar
    class MockTemplar:
        def __init__(self):
            self.template_data = None
            self.vars = None
            self.searchpath = None
            self.variable_start_string = None
            self.variable_end_string = None
            self.comment_start_string = None
            self.comment_end_string = None

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables, searchpath):
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string
            self.comment_start_string = comment_start_string
            self.comment_end_string = comment_end_string


# Generated at 2022-06-22 16:57:18.556688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle

    # Test with a file containing a variable
    lookup_file = StringIO("{{ test_var }}")
    lookup_file.name = 'test_file'
    lookup_file.isatty = lambda: False
    lookup_file.close = lambda: None
    lookup_file.fileno = lambda: None
    lookup_file.flush = lambda: None
    lookup_file.mode = 'r'
    lookup_file.name = 'test_file'
    lookup_file.newlines = None

# Generated at 2022-06-22 16:57:30.963361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-22 16:57:42.865416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar
    class MockTemplar:
        def __init__(self):
            self.template_data = None
            self.vars = None
            self.searchpath = None
            self.variable_start_string = None
            self.variable_end_string = None
            self.comment_start_string = None
            self.comment_end_string = None

        def copy_with_new_env(self, environment_class):
            return self

        def set_temporary_context(self, variable_start_string, variable_end_string, comment_start_string, comment_end_string, available_variables, searchpath):
            self.variable_start_string = variable_start_string
            self.variable_end_string = variable_end_string

# Generated at 2022-06-22 16:57:54.319578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    # Create a temporary directory to store the lookup file
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # Create the lookup file
    lookup_file = tmpdir + "/test_lookup_file.j2"
    with open(lookup_file, 'w') as f:
        f.write("{{ lookup('env', 'HOME') }}")

    # Create the lookup file
    lookup_file2 = tmpdir + "/test_lookup_file2.j2"

# Generated at 2022-06-22 16:57:55.250578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-22 16:58:05.305775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with jinja2_native=False
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'jinja2_native': False})
    lookup_module._templar = FakeTemplar()
    lookup_module._loader = FakeLoader()
    lookup_module._loader.set_file_contents('/path/to/template.j2', '{{ foo }}')
    lookup_module._loader.set_file_contents('/path/to/template2.j2', '{{ foo }}{{ bar }}')
    lookup_module._loader.set_file_contents('/path/to/template3.j2', '{{ foo }}{{ bar }}{{ baz }}')

# Generated at 2022-06-22 16:58:15.359936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a variable
    variable = {'ansible_search_path': ['/home/user/ansible/']}

    # Create a term
    term = 'test.j2'

    # Create a list of terms
    terms = [term]

    # Create a dictionary
    kwargs = {'convert_data': False, 'template_vars': {}, 'jinja2_native': False, 'variable_start_string': '{{', 'variable_end_string': '}}', 'comment_start_string': None, 'comment_end_string': None}

    # Call the run method
    result = lookup_module.run(terms, variable, **kwargs)

    # Assert the result
    assert result == [u'Hello World']

# Generated at 2022-06-22 16:58:26.606186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-22 16:58:32.896274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil
    import ansible.plugins.loader as plugin_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar


# Generated at 2022-06-22 16:58:42.613428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(DictDataLoader({'test_template.j2': b'{{ test_var }}'}))
    lookup_module.set_templar(DictTemplate())
    assert lookup_module.run(['test_template.j2'], {'test_var': 'test_value'}) == ['test_value']
