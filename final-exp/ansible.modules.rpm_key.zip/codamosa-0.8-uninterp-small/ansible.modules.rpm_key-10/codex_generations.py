

# Generated at 2022-06-25 03:06:51.976783
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = RpmKey(module)


# Generated at 2022-06-25 03:06:53.056511
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_0 = RpmKey(main())


# Generated at 2022-06-25 03:06:58.521700
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_obj_0 = RpmKey(module)
    

# Generated at 2022-06-25 03:07:00.868868
# Unit test for constructor of class RpmKey
def test_RpmKey():
    test_case_0()


# Generated at 2022-06-25 03:07:02.970058
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_0 = RpmKey()
    var_0.drop_key('keyid')


# Generated at 2022-06-25 03:07:08.318075
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = to_native(var_0)
    var_1 = to_native(var_1)
    var_2 = to_native(var_2)
    var_3 = to_native(var_3)
    var_4 = to_native(var_4)
    var_5 = to_native(var_5)

# Generated at 2022-06-25 03:07:10.141579
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = RpmKey(1)
    var_2 = var_1.import_key()


# Generated at 2022-06-25 03:07:11.158963
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = main()


# Generated at 2022-06-25 03:07:13.176051
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = "myfile.txt"
    var_2 = "mykey"



# Generated at 2022-06-25 03:07:18.120132
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():

    # Instantiate an object gpg
    gpg = RpmKey()

    # Invoke method getfingerprint
    ret_0 = gpg.getfingerprint()

    var_0 = test_case_0()

    # Assert if the values are equal
    assert ret_0 == var_0



# Generated at 2022-06-25 03:07:48.605885
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # Initialise the class
    args = dict()
    kwargs = dict()
    obj_0 = RpmKey(**kwargs)

    # Set up paramaters
    # Return values
    # Execute the test function
    # Check the results


# Generated at 2022-06-25 03:07:54.375782
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import io
    import tempfile
    import sys
    import os.path
    import subprocess
    import shlex
    import ansible.module_utils.action_commands
    class Module(object):
        def __init__(self):
            self.useunsafeshell = True
            self.checkmode = True
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None
            self.get_bin_path = None
            self.add_cleanup_file = None
            self.cleanup = None
            self.run_command_environ_update = None
    module = Module()
    def run_command(cmd, useunsafeshell=False):
        if useunsafeshell:
            python = sys.executable
            return

# Generated at 2022-06-25 03:07:59.136067
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = RpmKey()
    var_1 = mock.patch.object(RpmKey, "execfile").start()
    var_2 = create_autospec(RpmKey.execfile, instance=True)
    var_2.exc_info.return_value.args.return_value = ['']
    var_2.return_value = (0, 'stdout', 'stderr')
    var_0.execfile = var_2
    var_0.import_key()
    var_2.assert_called_with([var_0.rpm, '--import', var_0])
    var_1.stop()


# Generated at 2022-06-25 03:08:03.140259
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = '  0xDEADB33F'
    rk = RpmKey(keyid)
    expected = 'DEADB33F'
    result = rk.normalize_keyid(keyid)
    assert result == expected, 'Expected "{0}", but got "{1}"'.format(expected, result)


# Generated at 2022-06-25 03:08:07.051342
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = main()
    var_1 = RpmKey(module)

# Generated at 2022-06-25 03:08:11.660331
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var1 = RpmKey()
    var2 = main()
    assert var1.import_key(var2)
    assert var2.import_key(var2)
    assert var1.import_key(var1)
    assert var2.import_key(var1)
    assert var1.import_key(var1)


# Generated at 2022-06-25 03:08:14.417400
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = RpmKey()
    var_2 = str()
    var_3 = var_1.is_key_imported(var_2)
    return var_3

# Generated at 2022-06-25 03:08:18.065646
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = '0xDEADB33F'
    obj_1 = RpmKey()
    obj_2 = obj_1.is_keyid(var_0)
    obj_3 = obj_1.is_keyid(var_0)
    return obj_3


# Generated at 2022-06-25 03:08:26.218468
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import sys
    import os
    import unittest
    import tempfile
    from StringIO import StringIO
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        """Mock of AnsibleModule class"""

        def __init__(self):
            self._cleanup_files = []

        def add_cleanup_file(self, tempfile):
            self._cleanup_files.append(tempfile)

        def cleanup(self, tempfile):
            self._cleanup_files.remove(tempfile)

    class FakeFetchURL(object):
        """Mock of fetch_url method"""


# Generated at 2022-06-25 03:08:29.171484
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey("present")
    var_1 = var_0.is_key_imported("present")
    if (var_1 == True):
        check_0 = var_1
    else:
        check_0 = False
    assert (check_0 == True)


# Generated at 2022-06-25 03:09:04.329203
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = RpmKey(var_0)
    keyfile = '/home/me/gpg_keys/key.gpg'
    var_1.getkeyid(keyfile)


# Generated at 2022-06-25 03:09:06.304188
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import mock
    import types
    
    a = RpmKey()
    assert a.fetch_key == None


# Generated at 2022-06-25 03:09:09.447171
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    print('Testing method execute_command')
    var_0 = RpmKey()
    var_1 = var_0.execute_command([])
    assert(not var_1)
    print('Successfully tested method execute_command')


# Generated at 2022-06-25 03:09:12.781428
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = RpmKey()
    var_2 = RpmKey()

# Generated at 2022-06-25 03:09:14.486249
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_1 = main()
    var_1.fetch_key()


# Generated at 2022-06-25 03:09:16.824491
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Fix the method test case
    var_0 = RpmKey(None)
    var_0.gpg = None
    var_0.getfingerprint(None)


# Generated at 2022-06-25 03:09:18.041003
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0


# Generated at 2022-06-25 03:09:20.716334
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    test = RpmKey.is_key_imported()
    assert test == False


# Generated at 2022-06-25 03:09:30.296443
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = RpmKey(test_case_0())
    var_2 = [ansible_builtin_rpm_key.gpg, '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', keyfile]
    assert test_case_0().run_command(var_2, use_unsafe_shell=True) == var_1.execute_command(var_2)


# Generated at 2022-06-25 03:09:31.520423
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = ""
    var_1 = RpmKey.normalize_keyid(keyid)


# Generated at 2022-06-25 03:10:38.794853
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    rpm_key = RpmKey(AnsibleModule(
         argument_spec = dict(
            state = dict(type = 'str', default = 'present', choices = ['absent', 'present']),
            key = dict(type = 'str', required = True, no_log = False),
            fingerprint = dict(type = 'str'),
            validate_certs = dict(type = 'bool', default = True),
        ),
        supports_check_mode = True,
    ))
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = rpm_key.module.run_command(cmd)
    if rc != 0: # No key is installed on system
        return False

# Generated at 2022-06-25 03:10:41.124179
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = { 'erase': False, '_ansible_check_mode': True }
    var_2 = RpmKey(var_1)
    var_3 = "FAKE"
    var_2.drop_key(var_3)


# Generated at 2022-06-25 03:10:49.005453
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_1 = RpmKey(None)
    assert var_1.is_keyid('0xdeadbeef') == True
    assert var_1.is_keyid('0XDEADBEEF') == True
    assert var_1.is_keyid('0xDEADBEEF') == True
    assert var_1.is_keyid('DEADBEEF') == True
    assert var_1.is_keyid('DEADBEE') == False
    assert var_1.is_keyid('deadbeef') == True
    assert var_1.is_keyid('http://some.url.com') == False


# Generated at 2022-06-25 03:10:55.002574
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    rpm_importer = RpmKey(AnsibleModule)
    rpm_importer.import_key()


# Generated at 2022-06-25 03:10:57.628269
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey("var_0")
    var_1 = var_0.getkeyid("var_1")


# Generated at 2022-06-25 03:11:00.761285
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var = RpmKey()
    key = "deadb33f"
    assert key, "This test failed"


# Generated at 2022-06-25 03:11:02.349799
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    key = RpmKey()
    assert key.drop_key() == False


# Generated at 2022-06-25 03:11:06.025750
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = main()
    var_1 = var_0.import_key()


# Generated at 2022-06-25 03:11:07.196069
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_0 = RpmKey(var_0)


# Generated at 2022-06-25 03:11:09.122272
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey()
    var_1 = "0xDEADBEEF"
    var_2 = var_0.getkeyid(var_1)
    assert var_2 == 'DEADBEEF'


# Generated at 2022-06-25 03:13:34.012666
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = __builtin__.__import__('tempfile')
    var_2 = __builtin__.__import__('os.path')
    var_3 = __builtin__.__import__('re')
    var_4 = __builtin__.__import__('os.path')
    var_5 = __builtin__.__import__('ansible.module_utils._text')
    var_6 = __builtin__.__import__('ansible.module_utils.urls')
    var_7 = __builtin__.__import__('ansible.module_utils.basic')
    class Obj_0():
        def __init__(self):
            pass
        def search(self, a_0, a_1, a_2):
            return None

# Generated at 2022-06-25 03:13:38.023337
# Unit test for constructor of class RpmKey
def test_RpmKey():
    main()

# Generated at 2022-06-25 03:13:41.123258
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_2 = RpmKey()
    var_1 = var_2.is_keyid("asdf")
    assert var_1 == 0


# Generated at 2022-06-25 03:13:41.745974
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_1 = main()


# Generated at 2022-06-25 03:13:43.329613
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = main()


# Generated at 2022-06-25 03:13:50.629066
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os.path
    file_name = 'key0.gpg'

# Generated at 2022-06-25 03:13:56.747714
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = RpmKey(
        module=AnsibleModule(
            argument_spec=dict(
                state=dict(type='str', default='present', choices=['absent', 'present']),
                key=dict(type='str', required=True, no_log=False),
                fingerprint=dict(type='str'),
                validate_certs=dict(type='bool', default=True),
            ),
            supports_check_mode=True,
        )
    )
    var_1 = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    var_2 = tmpfile()

# Generated at 2022-06-25 03:13:59.583725
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        raise AssertionError('main() failed.')


# Generated at 2022-06-25 03:14:07.327235
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    print("Testing fetch_key")

    # Setup
    var_1 = tempfile.NamedTemporaryFile()
    var_2 = tempfile.NamedTemporaryFile()

    try:
        # Setup test data
        var_1.write(b'0xDEADBEEF')
        var_1.flush()
        # Perform the method call
        var_0 = RpmKey.fetch_key(None, var_1.name)

        assert var_0 is not None
        # Perform teardown
    finally:
        if var_1 is not None:
            var_1.close()
        if var_2 is not None:
            var_2.close()


# Generated at 2022-06-25 03:14:10.527910
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_1 = RpmKey()
    var_3 = RpmKey.is_keyid(var_1)
