

# Generated at 2022-06-25 03:06:47.857833
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = '0xDEADB33F'
    rpm_key_0 = RpmKey(keyid)
    assert rpm_key_0.normalize_keyid(keyid) == 'DEADB33F'


# Generated at 2022-06-25 03:06:56.863045
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    #
    # Little test to make sure a non string argument would fail
    #

    # Parameters
    params = {
        'state': 'present',
        'key': { 'key1': 'value1', 'key2': 'value2' },
        'fingerprint': '',
        'validate_certs': True
    }

    obj = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present'),
            key=dict(type='str', required=False),
            fingerprint=dict(type='str', required=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key_1 = RpmKey(obj)


# Generated at 2022-06-25 03:06:59.262007
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-25 03:07:06.863272
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    str_0 = 'fMf\nyT<jhZ@s|]M_'
    rpm_key_0 = RpmKey(str_0)
    str_1 = 'p6NbUA6Uf=Gz!T9T'
    try:
        rpm_key_0.import_key(str_1)
    except Exception:
        assert False


# Generated at 2022-06-25 03:07:10.431454
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    arg_0 = 'b0x'
    arg_1 = '&\r'
    obj_0 = RpmKey(arg_0)
    assert obj_0.is_key_imported(arg_1)


# Generated at 2022-06-25 03:07:13.226560
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    str_0 = 'z3\ntd'
    rpm_key_0 = RpmKey(str_0)
    rpm_key_0.getkeyid()


# Generated at 2022-06-25 03:07:17.029427
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    str_0 = 'UUF,8qYfI'
    bool_0 = RpmKey(str_0).is_key_imported()
    assert bool_0 == True


# Generated at 2022-06-25 03:07:21.338251
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module_0 = AnsibleModule(argument_spec=dict())
    module_0.params.update({"key": ""})
    str_0 = 'fMf\nyT<jhZ@s|]M_'
    rpm_key_0 = RpmKey(module_0)
    rpm_key_0.getkeyid(str_0)


# Generated at 2022-06-25 03:07:30.283080
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    str_0 = '<F[@;8\x7fj'
    str_1 = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    rpm_key_0 = RpmKey(str_0)
    rpm_key_0.__dict__['gpg'] = '/usr/bin/gpg'
    rpm_key_0.__dict__['module'] = str_0
    rpm_key_0.__dict__['rpm'] = '/usr/bin/rpm'
    str_2 = '/home/qwerty/key.gpg'
    rpm_key_0.fetch_key(str_1)
    rpm_key_0.getfingerprint(str_2)


# Generated at 2022-06-25 03:07:38.512213
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    str_0 = '\x04\x89\xfd\x1a\xf7\xeb\x1c\xae\x03\x00\xfd\x01f\x9d?\xf8'
    rpm_key_0 = RpmKey(str_0)

# Generated at 2022-06-25 03:08:04.284900
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = '0x9d5ef5cf'
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    var_2 = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-25 03:08:11.050770
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = main()
    var_1 = var_0.fetch_key("key")
    assert var_1 == "key"


# Generated at 2022-06-25 03:08:11.955596
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    assert True


# Generated at 2022-06-25 03:08:14.974788
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_1 = RpmKey(None)
    var_2 = var_1.is_keyid("0x46f9a4b4")
    assert var_2


# Generated at 2022-06-25 03:08:16.212222
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var = main()
    var.normalize_keyid()


# Generated at 2022-06-25 03:08:18.817244
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = RpmKey

    var_1 = var_1()

    var_2 = ['rpm', '--import', var_1]

    var_1.execute_command(var_2)


# Generated at 2022-06-25 03:08:21.931400
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_1 = main()
    var_2 = var_1.normalize_keyid("0xDEADBEEF")
    if var_2 is not "DEADBEEF":
        raise Exception("Test case failed: keyids were not equal")


# Generated at 2022-06-25 03:08:23.197708
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    RpmKey_i = RpmKey(arg_0)
    var_0 = RpmKey_i.fetch_key(arg_1)


# Generated at 2022-06-25 03:08:24.634761
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey(module)
    var_1 = RpmKey(module)


# Generated at 2022-06-25 03:08:27.076413
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    # Arrange
    rpm_key = RpmKey(None)

    # Act

    # Assert
    assert False == rpm_key._RpmKey__is_key_imported(None)


# Generated at 2022-06-25 03:09:00.473492
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import __main__
    import os

    globals().update({'__name__': '__main__'})
    rpm_0 = RpmKey(RpmKey)
    var_0 = set(['rpm', '--erase', '--allmatches', 'gpg-pubkey-aaaaaaaa'])
    var_1 = set(['rpm', '--erase', '--allmatches', 'gpg-pubkey-aaaaaaaa'])
    if var_0 == var_1:
        return True
    else:
        print(os.strerror(errno))
        return False


# Generated at 2022-06-25 03:09:01.564782
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
	global var_0
	var_0 = main()


# Generated at 2022-06-25 03:09:08.813321
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(argument_spec=dict(state=dict(type='str', default='present', choices=['absent', 'present']), key=dict(type='str', required=True, no_log=False), fingerprint=dict(type='str'), validate_certs=dict(type='bool', default=True), ), supports_check_mode=True)
    obj = RpmKey(module)
    keyid = '0xE14901E3F26D5E35'
    obj.drop_key(keyid)


# Generated at 2022-06-25 03:09:11.908252
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    try:
        var_0 = RpmKey.is_keyid('DEADB33F')
        print(var_0)
    except Exception as exception:
        print('exception from unit test:', exception)


# Generated at 2022-06-25 03:09:13.448535
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = RpmKey()
    var_2 = var_1.drop_key(str,str)


# Generated at 2022-06-25 03:09:14.644490
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    assert not RpmKey.execute_command()


# Generated at 2022-06-25 03:09:16.664562
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():

    rpm_key_instance = RpmKey()

    # No assertion. Might throw exception.
    rpm_key_instance.getkeyid()


# Generated at 2022-06-25 03:09:22.300622
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class RpmKey:
        def __init__(self, variable_0, variable_1, variable_2, variable_3, variable_4, variable_5, variable_6, variable_7):
            self.keyid = variable_0
            self.rpm = variable_1
            self.execute_command = variable_2
            self.is_keyid = variable_3
            self.fail_json = variable_4
            self.execute_cmd = variable_5
            self.run_command = variable_6
            self.copy = variable_7
    var_0 = RpmKey(0x123456ABCDEFF, "system", None, None, None, None, None, None)
    var_0.execute_command = mock.Mock()
    var_0.run_command = mock.Mock()
    var_0

# Generated at 2022-06-25 03:09:24.892630
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    pass


# Generated at 2022-06-25 03:09:31.081184
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # Setup and Test Data
    var_0 = main()
    var_1 = main()
    var_1.gpg_cmd = ['gpg2']
    var_2 = main()
    var_2.gpg_cmd = ['gpg2']
    # Execute the test code
    var_3 = var_0.execute_command(var_2.rpm_cmd, var_1.gpg_cmd, var_1.file_keyfile)
    return var_3


# Generated at 2022-06-25 03:10:31.452287
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = object
    var_2 = "/tmp/ansible_rpm_key_payload_cx8dwW"
    var_1 = RpmKey(var_2)
    var_3 = "/tmp/ansible_rpm_key_payload_cx8dwW"
    var_4 = var_1.getkeyid(var_3)
    assert var_4 == '24A511079A9E91C8F62AA88A30B289B0E0B6C52E'


# Generated at 2022-06-25 03:10:36.728065
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey({'no_log': False, 'state': 'present', 'check_mode': False, 'fingerprint': None, 'validate_certs': True, 'key': 'DEADB33F'})
    var_0.is_key_imported('DEADB33F')


# Generated at 2022-06-25 03:10:39.497679
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    RpmKey_instance = RpmKey()
    var_1 = os.path
    var_2 = test_case_0()
    assert var_1 == var_2


# Generated at 2022-06-25 03:10:43.911635
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_0 = test_1()
    var_1 = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'deadbeef')
    var_2 = RpmKey(var_0)
    assert (var_2.getfingerprint(var_1) == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6')


# Generated at 2022-06-25 03:10:51.158261
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(argument_spec={'state': {'type': 'str', 'default': 'present', 'choices': ['absent', 'present']}, 'key': {'type': 'str', 'required': True, 'no_log': False}, 'fingerprint': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}}, supports_check_mode=True)
    RpmKey(module)


# Generated at 2022-06-25 03:10:59.095096
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os.path

    # Setup
    var_0 = module
    var_1 = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    var_2 = var_0.fetch_key(var_1)

    # Test
    assert os.path.isfile(var_2)



# Generated at 2022-06-25 03:11:01.623225
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rpm_key = RpmKey()
    var_0 = rpm_key.drop_key(keyid)


# Generated at 2022-06-25 03:11:04.807607
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = RpmKey()
    var_1 = var_0.is_keyid("0x00a0e4db")
    assert var_1


# Generated at 2022-06-25 03:11:07.255073
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = RpmKey()
    var_2 = var_1.getkeyid()
    if var_2 == False:
        return True


# Generated at 2022-06-25 03:11:19.355290
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    f = tempfile.NamedTemporaryFile()
    keyfile = f.name

# Generated at 2022-06-25 03:13:24.669282
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_1 = RpmKey('/root/ansible/ansible/lib/ansible/module_utils/basic.py')
    var_1.main()


# Generated at 2022-06-25 03:13:27.568520
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    """
        Calls normalize_keyid method of RpmKey class and returns the result.
    """
    r_key = RpmKey(main())
    return r_key.normalize_keyid()



# Generated at 2022-06-25 03:13:28.960301
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Test case 0
    test_0 = RpmKey()


# Generated at 2022-06-25 03:13:30.264889
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rk = RpmKey()
    assert not rk.is_keyid('notakeyid')


# Generated at 2022-06-25 03:13:30.967170
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    assert True


# Generated at 2022-06-25 03:13:36.390827
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_0 = RpmKey(module)


# Generated at 2022-06-25 03:13:40.202533
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = RpmKey()
    var_2 =  RpmKey.execute_command()
    var_3 = ['fail', 'fail', 'fail']
    var_4 = var_2[1].splitlines()
    var_5 =  RpmKey.module.run_command()
    var_6 = None
    var_3[0] = var_5[0]
    var_3[1] = var_5[1]
    var_3[2] = var_5[2]
    var_6 = var_1.is_key_imported(var_3)
    assert var_6 == False


# Generated at 2022-06-25 03:13:43.730993
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # instantiate obj of class RpmKey before calling drop_key
    var_0 = RpmKey(RpmKey)
    # calling drop_key with key id
    var_0.drop_key("deadb33f")


# Generated at 2022-06-25 03:13:44.529918
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    test_case_0()

# Generated at 2022-06-25 03:13:46.471345
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = main()
    var_1 = to_native(var_0, errors='surrogate_or_strict')
