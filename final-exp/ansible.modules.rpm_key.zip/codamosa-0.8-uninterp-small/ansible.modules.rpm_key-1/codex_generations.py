

# Generated at 2022-06-25 03:06:57.384296
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # test case 0
    var_0_0 = os.path.isfile(test_case_0())
    print(var_0_0)
    # test case 1
    var_1_0 = os.path.isfile(test_case_1())
    print(var_1_0)


# Generated at 2022-06-25 03:06:58.710446
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = main()
    var_0.execute_command()


# Generated at 2022-06-25 03:07:02.023054
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = RpmKey(object())
    var_1.import_key(var_1)


# Generated at 2022-06-25 03:07:04.336082
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    print('Testing method of class RpmKey')
    RpmKey.getfingerprint(param_0, param_1)


# Generated at 2022-06-25 03:07:06.753268
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = module()
    var_2 = RpmKey(var_1)



# Generated at 2022-06-25 03:07:09.510414
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = main()
    var_1.import_key('C:\\Users\\aalvarez\\Desktop\\NWQA\\')



# Generated at 2022-06-25 03:07:20.107048
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = RpmKey()
    var_1 = tempfile.mkdtemp()
    os.chdir(var_1)
    with open('var_0', 'w') as var_2:
        var_2.write('Hello World!')
    # This is a fake key, but it's a key, so, it's ok
    var_0.import_key(os.path.join(var_1, 'var_0'))
    var_0.drop_key(var_0.normalize_keyid(var_0.getkeyid(os.path.join(var_1, 'var_0'))))
    os.chdir(os.path.expanduser('~'))
    shutil.rmtree(var_1)



# Generated at 2022-06-25 03:07:28.356085
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from ansible_collections.ansible.builtin.plugins.modules.rpm_key import RpmKey
    var_5 = "keyid"
    var_6 = "string"
    var_7 = str(var_5)
    var_8 = "gpg-pubkey-%s" % var_7[-8:].lower()
    var_9 = "rpm"
    var_10 = "--erase"
    var_11 = "--allmatches"
    var_12 = var_9 + " " + var_10 + " " + var_11 + " " + var_8
    var_13 = "execute_command"
    var_14 = "self"
    var_15 = var_14 + "." + var_13
    var_16 = var_15 + "(var_12)"
    var

# Generated at 2022-06-25 03:07:31.445860
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    a = RpmKey({})
    b = a.getfingerprint("/home/A/.gnupg/D")
    assert  b == "ABCDEF1234567890"


# Generated at 2022-06-25 03:07:32.292480
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert True


# Generated at 2022-06-25 03:07:49.967623
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_1 = RpmKey()
    keystr = "0x"
    keyid = var_1.is_keyid(keystr)
    assert keyid == True


# Generated at 2022-06-25 03:07:53.107939
# Unit test for function main
def test_main():
    var_0 = RpmKey('0xE12C62B1C7')
    name = '-t -s'
    # Calls function main
    main()



# Generated at 2022-06-25 03:08:02.402973
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = RpmKey(main)
    var_1 = main()
    var_2 = ['rpm', '-q', 'gpg-pubkey']
    var_3 = main()
    var_4 = var_3()
    var_5 = var_4 + ' --qf "%{description}" | gpg --no-tty --batch --with-colons --fixed-list-mode -'
    var_6 = var_3()
    var_7 = var_6(var_5)
    var_8 = var_3.execute_command(var_5)
    var_9 = var_0.is_key_imported(var_7)
    var_10 = var_0.drop_key(var_8)
    var_11 = var_0.import_key(var_8)
    var

# Generated at 2022-06-25 03:08:05.438754
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = RpmKey()
    var_2 = RpmKey.drop_key(var_1, )
    var_1.check_mode = True
    var_2 = RpmKey.drop_key(var_1, )


# Generated at 2022-06-25 03:08:07.816545
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    RpmKey_instance = RpmKey("keyfile")
    fingerprint_0 = RpmKey_instance.getfingerprint("keyfile")



# Generated at 2022-06-25 03:08:10.202107
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_1 = RpmKey(module)
    var_2 = b'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    var_3 = var_1.fetch_key(var_2)
    print(var_3)


# Generated at 2022-06-25 03:08:11.071978
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = main()


# Generated at 2022-06-25 03:08:13.080696
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    rpm_key = RpmKey()
    var_1 = rpm_key.fetch_key()


# Generated at 2022-06-25 03:08:13.651256
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert False

# Generated at 2022-06-25 03:08:16.599080
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    a = RpmKey()
    assert a.is_key_imported("DE7BD9Aaaaa0A000") == True
    assert a.is_key_imported("DE7BD9Aaaa0A000") == True


# Generated at 2022-06-25 03:08:55.281249
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = RpmKey(main())
    var_2 = list()
    var_2.append("gpg")
    var_2.append("--no-tty")
    var_2.append("--batch")
    var_2.append("--with-colons")
    var_2.append("--fixed-list-mode")
    var_2.append("/path/to/RPM-GPG-KEY.dag.txt")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    var_3 = var_1.execute_command(var_2)
    print("var_3")

# Generated at 2022-06-25 03:08:56.764586
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = RpmKey()
    var_1 = var_0.import_key()


# Generated at 2022-06-25 03:09:02.865229
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import random
    import string
    random_instance = random.SystemRandom()
    random_alphabet = string.ascii_letters + ' ' + string.digits
    random_str = "".join([random_instance.choice(random_alphabet) for _ in range(random.randrange(len(random_alphabet)))])
    # Test empty string
    assert RpmKey.normalize_keyid(random_str) == random_str.strip().upper()
    # Test random string
    assert RpmKey.normalize_keyid(random_str) == random_str.strip().upper()


# Generated at 2022-06-25 03:09:07.251822
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    rpm_key_0 = RpmKey(module)
    str_0 = rpm_key_0.execute_command([self.gpg, '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', keyfile])
    assert str_0 == 'stdout/stderr'


# Generated at 2022-06-25 03:09:08.854843
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rpm_key = RpmKey()
    var_0 = rpm_key.drop_key()

# Generated at 2022-06-25 03:09:11.617669
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = str()
    var_2 = RpmKey(var_1)
    var_3 = str()
    var_2.is_key_imported(var_3)


# Generated at 2022-06-25 03:09:14.771980
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey()
    var_1 = RpmKey.getkeyid(var_0)
    var_1 = RpmKey.getfingerprint(var_0)


# Generated at 2022-06-25 03:09:20.952861
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_0 = RpmKey(main())
    var_0.drop_key("ABCDE")
    var_1 = RpmKey.drop_key("ABCDE")
    var_2 = var_1.module
    var_3 = var_0.module
    if var_2 == var_3:
        var_4 = "Equal"
    else:
        var_4 = "UnEqual"

# Generated at 2022-06-25 03:09:23.703180
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey(main())
    var_0.rpm
    var_0.is_key_imported('0xDEADB33F')


# Generated at 2022-06-25 03:09:28.852757
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_22 = 'keyid'
    var_23 = to_native(var_22)
    var_15 = RpmKey(var_23)
    var_16 = var_15.is_key_imported()
    assert var_16


# Generated at 2022-06-25 03:10:32.903433
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils._text import to_native
    var_1 = to_native(to_native(None))
    assert var_1 == None


# Generated at 2022-06-25 03:10:35.122855
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_1 = RpmKey()
    var_2 = var_1.is_keyid('DEADBEEF')
    assert var_2 == True


# Generated at 2022-06-25 03:10:40.619767
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    # Setup
    args = {'state': 'present', 'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'}
    module = AnsibleModule(supports_check_mode=True)
    module.params = args
    rpm = RpmKey(module)

    # Test
    rpm.drop_key('DEADB33F')

    # Assert
    assert True



# Generated at 2022-06-25 03:10:46.810663
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = dict()
    var_2 = dict()
    var_2['fingerprint'] = None
    var_2['state'] = 'present'
    var_2['validate_certs'] = True
    var_2['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    var_1 = RpmKey(var_2)
    var_3 = '@'
    var_1.is_key_imported(var_3)


# Generated at 2022-06-25 03:10:47.963789
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    main()


# Generated at 2022-06-25 03:10:56.522251
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    # Load config from YML
    config = yaml.safe_load(open("test_config.yml"))

    # Create a mock module
    mock_module = MagicMock()
    mock_module.check_mode = False
    mock_module.params = config['RpmKey']['RpmKey_fetch_key']['params']

    # Create a mock fetch_url
    mock_fetch_url = MagicMock()
    mock_fetch_url.return_value = config['RpmKey']['RpmKey_fetch_key']['fetch_url_return_value']

    with patch('ansible.module_utils.urls.fetch_url', mock_fetch_url):

        # Create a mock tempfile.mkstemp
        mock_mkstemp = MagicMock()


# Generated at 2022-06-25 03:10:57.996127
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert repr(RpmKey(main())) == "<RpmKey()>"

# Generated at 2022-06-25 03:11:06.444133
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    key_0 = '0xE9F844B22CA2B2C7'
    key_1 = 'E9F844B22CA2B2C7'
    key_2 = '0XE9F844B22CA2B2C7'
    key_3 = 'E9F8-44B22CA2B2C7'
    assert is_keyid(key_0) is True
    assert is_keyid(key_1) is True
    assert is_keyid(key_2) is True
    assert is_keyid(key_3) is False

# Generated at 2022-06-25 03:11:07.856719
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = main()
    var_2 = var_1.is_key_imported(var_1)


# Generated at 2022-06-25 03:11:19.514689
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = {}
    var_2 = Int()
    var_2.set('check_mode', 'full')
    var_1['check_mode']=var_2
    var_3 = Int()
    var_3.set('diff_mode', 'none')
    var_1['diff_mode']=var_3
    var_4 = Int()
    var_4.set('platform', 'rhel')
    var_1['platform']=var_4
    var_5 = Module()
    var_5.set('argument_spec', var_1)
    var_6 = Int()
    var_6.set('supports_check_mode', 'True')
    var_5.set('supports_check_mode', var_6)
    var_7 = Int()

# Generated at 2022-06-25 03:13:46.820322
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var = ansible_builtin.RpmKey(state='present', key='/path/to/RPM-GPG-KEY.dag.txt')
    var.rpm.run_command = MagicMock(return_value=(1, '', ''))
    var.execute_command = MagicMock(return_value=('', ''))
    var.is_key_imported('foo')
    var.rpm.run_command.assert_called_with('rpm -q  gpg-pubkey', use_unsafe_shell=True)
    var.execute_command.assert_called_with('rpm -q  gpg-pubkey  --qf "%{description}" | gpg --no-tty --batch --with-colons --fixed-list-mode -', use_unsafe_shell=True)



# Generated at 2022-06-25 03:13:48.022094
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = is_key_imported(self, keyid)


# Generated at 2022-06-25 03:13:48.455154
# Unit test for constructor of class RpmKey
def test_RpmKey():
    pass


# Generated at 2022-06-25 03:13:50.278141
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Unit test for RpmKey.getfingerprint()
    # TODO: implement your test here
    var_0 = RpmKey(None)
    var_0.getfingerprint()


# Generated at 2022-06-25 03:13:52.559868
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey()
    arg_0 = '0011110f'
    var_1 = var_0.is_key_imported(arg_0)


# Generated at 2022-06-25 03:13:59.216481
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = RpmKey(test_case_0())
    var_0.import_key("")


# Generated at 2022-06-25 03:14:00.808312
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_0 = RpmKey()
    var_0.getfingerprint()


# Generated at 2022-06-25 03:14:01.833800
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    rpm_key_0 = RpmKey()
    keyid = rpm_key_0.is_key_imported()


# Generated at 2022-06-25 03:14:04.684146
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey(object)
    var_2 = to_native(var_1.getfingerprint())

    assert var_2 is not None


# Generated at 2022-06-25 03:14:07.660358
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_keyfile = '/path/to/RPM-GPG-KEY.dag.txt'
    var_key = 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6'
