

# Generated at 2022-06-25 03:06:46.769690
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    print("test_RpmKey_execute_command()")

    # Instance of RpmKey
    p = RpmKey()

    # Access method 'execute_command'
    p.execute_command()



# Generated at 2022-06-25 03:06:52.595230
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Input parameters
    RpmKey_instance = RpmKey()
    keyfile = ''

    # Invoke method
    result = RpmKey_instance.getfingerprint(keyfile)


# Generated at 2022-06-25 03:06:59.812231
# Unit test for constructor of class RpmKey
def test_RpmKey():

    # Case 0 - Constructor of class RpmKey

    gpg = 'gpg'
    rpm = 'rpm'
    module = 'module'
    key = 'key'
    fingerprint = 'fingerprint'
    state = 'state'
    var_0 = RpmKey(module)
    var_0.getkeyid(key)
    var_0.getfingerprint(key)
    var_0.is_keyid(key)
    var_0.execute_command(gpg)
    var_0.is_key_imported(key)
    var_0.import_key(key)
    var_0.drop_key(key)

# Generated at 2022-06-25 03:07:02.573313
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    set_0 = set()
    var_0 = RpmKey(set_0)
    var_1 = var_0.is_keyid("0x0")


# Generated at 2022-06-25 03:07:13.677444
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    t0_keyid = 'DEADBEEF'
    module = magicmock()
    module.fail_json = mock()
    module.check_mode = mock()
    rpm = mock()
    gpg = mock()

    # test with no key installed
    mock_run_command = mock()
    mock_run_command.return_value = (1, '', '')
    mock_execute_command = mock()
    mock_execute_command.return_value = ('', '')
    module.run_command = mock_run_command
    rpm_key = RpmKey(module)
    rpm_key.rpm = rpm
    rpm_key.gpg = gpg
    rpm_key.execute_command = mock_execute_command
    assert not rpm_key.is_key_imported(t0_keyid)

# Generated at 2022-06-25 03:07:22.006075
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module_0 = AnsibleModule(argument_spec={'fingerprint': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}, 'key': {'required': True, 'no_log': False, 'type': 'str'}, 'state': {'choices': ['absent', 'present'], 'default': 'present', 'type': 'str'}}, supports_check_mode=True)
    instance_0 = RpmKey(module_0)
    var_1 = instance_0.drop_key(keyid='gpg-pubkey')


# Generated at 2022-06-25 03:07:22.880067
# Unit test for constructor of class RpmKey
def test_RpmKey():
    key = ''
    module = ''
    var_1 = RpmKey(module)

# Generated at 2022-06-25 03:07:28.726635
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    multiline_string_0 = "a\nb\nc"
    multiline_string_1 = "a\nb\nc"
    multiline_string_2 = "a\nb\nc"

    set_0 = set()
    var_0 = RpmKey(set_0)

    multiline_string_0 = "a\nb\nc"
    multiline_string_1 = "a\nb\nc"
    multiline_string_2 = "a\nb\nc"

    var_0.import_key(multiline_string_0)


# Generated at 2022-06-25 03:07:31.685312
# Unit test for constructor of class RpmKey
def test_RpmKey():
    set_0 = set(['http://apt.sw.be/RPM-GPG-KEY.dag.txt'])
    assert is_pubkey(set_0)


# Generated at 2022-06-25 03:07:33.947906
# Unit test for constructor of class RpmKey
def test_RpmKey():
    with pytest.raises(IOError):
        var = RpmKey(None)
    with pytest.raises(IOError):
        var = RpmKey(None)

# Generated at 2022-06-25 03:08:08.699885
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    class_RpmKey = RpmKey(module)
    assert class_RpmKey.normalize_keyid('0x12345678') == '12345678'
    assert class_RpmKey.normalize_keyid('0X12345678') == '12345678'
    assert class_RpmKey.normalize_keyid('12345678') == '12345678'
    assert class_RpmKey.normalize_keyid('0x12345678\n') == '12345678'
    assert class_RpmKey.normalize_keyid(' 0x12345678') == '12345678'
    assert class_RpmKey.normalize_keyid('0x12345678 ') == '12345678'
    assert class_RpmKey.normalize_keyid(' 0x12345678\n')

# Generated at 2022-06-25 03:08:17.329701
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key_obj = RpmKey(module)
    var_1 = "089e7bf9079ec914"
    var_2 = rpm_key_obj.is_key_imported(var_1)
    assert var_2 is False


# Generated at 2022-06-25 03:08:19.561829
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpmkey = RpmKey('')
    keyid = 'DEADB33F'
    ret = rpmkey.is_keyid(keyid)
    assert ret


# Generated at 2022-06-25 03:08:21.699131
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = RpmKey()
    var_1 = ['', '']
    var_2 = var_0.execute_command(var_1)


# Generated at 2022-06-25 03:08:29.259190
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey.is_keyid(0x1122334455667788)

# Generated at 2022-06-25 03:08:36.762870
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = RpmKey(main())
    var_2 = [var_1.gpg, u'--no-tty', u'--batch', u'--with-colons', u'--fixed-list-mode', u'/home/centos/key.gpg']
    var_3 = var_1.execute_command(var_2)

# Generated at 2022-06-25 03:08:40.481724
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = main()
    print("\nTestCase: fetch_key")
    var_1 = RpmKey.fetch_key(var_0, "0x0")


# Generated at 2022-06-25 03:08:41.139787
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = main()


# Generated at 2022-06-25 03:08:46.538189
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ),)
    # If a key is given, it should be one of these types
    assert isinstance(module.params.get('key'), str)
    # If a key is given, it should be one of these types
    assert isinstance(module.params.get('fingerprint'), str)
    obj_0 = RpmKey(module)

# Generated at 2022-06-25 03:08:55.869414
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_1 = '0xDEADB33F'
    var_2 = 'DEADB33F'
    var_3 = ' DEADB33F '
    var_4 = ' 0xDEADB33F '
    var_5 = ' 0XDEADB33F '
    var_6 = RpmKey(test_case_0())
    var_7 = var_6.normalize_keyid(var_1)
    var_8 = var_6.normalize_keyid(var_2)
    var_9 = var_6.normalize_keyid(var_3)
    var_10 = var_6.normalize_keyid(var_4)
    var_11 = var_6.normalize_keyid(var_5)
    assert var_7 == var_2
    assert var

# Generated at 2022-06-25 03:09:25.529589
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_0 = main()



# Generated at 2022-06-25 03:09:28.852122
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = RpmKey()
    var_1 = main()
    assert True


# Generated at 2022-06-25 03:09:33.200919
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKeyInst = RpmKey(module)
    output = RpmKeyInst.getkeyid()
    assert output == "output"

# Generated at 2022-06-25 03:09:35.852424
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey()
    var_1 = var_0.is_key_imported(str)


# Generated at 2022-06-25 03:09:39.171747
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = RpmKey(None)
    assert var_0.fetch_key(None) == None


# Generated at 2022-06-25 03:09:41.028059
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = is_pubkey()
    assert var_0 == None, 'var_0 != None'


# Generated at 2022-06-25 03:09:42.572373
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = RpmKey()
    var_2 = [var_3, var_3]
    free(var_3)


# Generated at 2022-06-25 03:09:43.764617
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_1 = RpmKey()
    return var_1.is_keyid()


# Generated at 2022-06-25 03:09:48.698940
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rpmkey_0 = RpmKey(main())
    rpmkey_0.drop_key("0xDEADB33F")


# Generated at 2022-06-25 03:09:49.465551
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    return


# Generated at 2022-06-25 03:10:34.386615
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey.is_keyid('N.B.L-C.0.0.2.0') == True


# Generated at 2022-06-25 03:10:42.833783
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    test_RpmKey = RpmKey(test_case_0)
    # test_cmd = ['rpm', '-q', 'gpg-pubkey']
    # test_cmd += [ '--qf "%{description}"', '|', 'gpg', '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '-' ]
    # result = test_RpmKey.execute_command(test_cmd)
    # assert "stdout" in result, "stdout in result"
    # assert "stderr" in result, "stderr in result"
    # assert result["stdout"] is not None, "stdout is not None"
    # assert result["stderr"] is not None, "stderr is not None"
    pass


# Generated at 2022-06-25 03:10:43.755610
# Unit test for constructor of class RpmKey
def test_RpmKey():
    RpmKey(var_0)

# Generated at 2022-06-25 03:10:48.495611
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Default setup
    var_1 = RpmKey(main())

    # Provided setup
    var_2 = '0x12345678'
    var_3 = var_1.normalize_keyid(var_2)
    var_4 = '12345678'
    assert var_3 == var_4



# Generated at 2022-06-25 03:10:52.251403
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var0 = RpmKey(get_from_stdin())
    var0.drop_key(get_from_stdin())


# Generated at 2022-06-25 03:10:58.749392
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Setup
    keystr = '0xDEADB33F'
    rpm_key = RpmKey()

    var_1 = rpm_key.is_keyid(keystr)

    # Assertion
    assert(var_1 == True)


# Generated at 2022-06-25 03:11:04.808915
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    cmd_0 = ['/usr/bin/rpm', '-q  gpg-pubkey', '--qf "%{description}" | /usr/bin/gpg --no-tty --batch --with-colons --fixed-list-mode -']
    var_0 = RpmKey()
    var_0.execute_command(cmd_0)


# Generated at 2022-06-25 03:11:06.402310
# Unit test for constructor of class RpmKey
def test_RpmKey():
    test_RpmKey = RpmKey()
    assert test_RpmKey != None


# Generated at 2022-06-25 03:11:09.466794
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    pass


# Generated at 2022-06-25 03:11:13.835701
# Unit test for constructor of class RpmKey
def test_RpmKey():
    print("Testing constructor for class RpmKey")
    result_0 = RpmKey()
    assert (result_0 is not None)


# Generated at 2022-06-25 03:12:32.617360
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    if var_0 == True:
        print(test_case_0)
    else:
        print("test_case_0 not passed")

# Generated at 2022-06-25 03:12:37.086581
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey()


# Generated at 2022-06-25 03:12:38.125754
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    assert False, "Not implemented"


# Generated at 2022-06-25 03:12:43.473438
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = AnsibleModule(argument_spec=dict(state=dict(type='str', default='present', choices=['absent', 'present']), key=dict(type='str', required=True), fingerprint=dict(type='str'), validate_certs=dict(type='bool', default=True)), supports_check_mode=True)

    var_2 = RpmKey(var_1)


# Generated at 2022-06-25 03:12:45.703095
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_RpmKey = RpmKey()
    var_0 = var_RpmKey.drop_key()


# Generated at 2022-06-25 03:12:50.072310
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    cmd = ['/bin/rpm', '-q', ' gpg-pubkey', '--qf', '"%{description}"', '|', '/bin/gpg', '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '-']
    var_0 = RpmKey(main())
    stdout, stderr = var_0.execute_command(cmd)

# Generated at 2022-06-25 03:12:58.896683
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    var_0 = RpmKey(module)


# Generated at 2022-06-25 03:13:04.985889
# Unit test for constructor of class RpmKey
def test_RpmKey():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    var_0 = RpmKey(module)
    assert var_0.module == module
    assert var_0.rpm == module.get_bin_path('rpm', True)
    assert var_0.g

# Generated at 2022-06-25 03:13:09.770639
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_0 = 'DUMMY_GPG_BIN_PATH'
    var_1 = 'DUMMY_RPM_BIN_PATH'
    var_2 = {'fingerprint': 'DUMMY_FINGERPRINT', 'state': 'present', 'key': 'DUMMY_KEY'}
    var_3 = {'check_mode': True, 'diff_mode': False, 'platform': ['linux']}
    var_4 = RpmKey(var_1)

# Generated at 2022-06-25 03:13:11.260774
# Unit test for method execute_command of class RpmKey

# Generated at 2022-06-25 03:16:13.906285
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    assert True


# Generated at 2022-06-25 03:16:15.530916
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey(main())
    # Call to getkeyid
    var_0._RpmKey__getkeyid(main())


# Generated at 2022-06-25 03:16:20.443076
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    tmpfilename = 'test_RpmKey_import_key.tmp'

# Generated at 2022-06-25 03:16:21.709223
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = main()

    # Get the public attribute 'rpm' from var_0
    var_1 = var_0.rpm
    assert(var_1)



# Generated at 2022-06-25 03:16:28.438817
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Generating expectations
    var_1 = 'DEADB33F'
    # Calling method
    var_3 = RpmKey.normalize_keyid(var_1)
    # Calling method
    var_4 = RpmKey.normalize_keyid(var_1)
    # Calling method
    var_5 = RpmKey.normalize_keyid(var_1)
    # Comparing expected value with actual value
    assert var_3 == var_4
    # Comparing expected value with actual value
    assert var_3 == var_5
