

# Generated at 2022-06-25 03:06:46.911704
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    float_0 = 100.0
    rpm_key_0 = RpmKey(float_0)
    string_0 = "abcdefgh"
    assert rpm_key_0.is_keyid(string_0)


# Generated at 2022-06-25 03:06:51.639449
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    float_0 = 100.0
    rpm_key_0 = RpmKey(float_0)


# Generated at 2022-06-25 03:06:57.693725
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    float_0 = 100.0
    rpm_key_0 = RpmKey(float_0)
    str_0 = rpm_key_0.is_key_imported()


# Generated at 2022-06-25 03:07:10.092116
# Unit test for method drop_key of class RpmKey

# Generated at 2022-06-25 03:07:13.678035
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    float_0 = 100.0
    rpm_key_0 = RpmKey(float_0)
    int_0 = 100
    string_0 = rpm_key_0.drop_key(int_0)


# Generated at 2022-06-25 03:07:24.146919
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    float_0 = 100.0
    rpm_key_0 = RpmKey(float_0)

# Generated at 2022-06-25 03:07:29.605008
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.removed import removed_module
    removed_module("The module rpm_key_0 has been removed in Ansible 2.9. The module documentation details page may explain more about this rationale.")

# Generated at 2022-06-25 03:07:34.735368
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    float_1 = 100.0
    rpm_key_1 = RpmKey(float_1)
    str_1 = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    var_0 = rpm_key_1.fetch_key(str_1)
    var_2 = "/"
    var_1 = var_0.startswith(var_2)
    assert var_1 == True


# Generated at 2022-06-25 03:07:35.832251
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert type(RpmKey(100.0)) == RpmKey


# Generated at 2022-06-25 03:07:38.932555
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Setup
    str_0 = 'f1'
    rpm_key_0 = RpmKey(str_0)
    str_0 = 'f2'
    # Assertions
    rpm_key_0.drop_key(str_0)


# Generated at 2022-06-25 03:07:56.091064
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import_key = import_key
    # Test for no arguments passed.
    # Check that the state is 'present'
    if state is 'present':
        if not module.check_mode:
            execute_command([rpm, '--import', keyfile])


# Generated at 2022-06-25 03:07:58.213501
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Globals
    global str_0

    obj = RpmKey(str_0)
    assert obj.normalize_keyid(str_0) == '0'


# Generated at 2022-06-25 03:08:03.937873
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # stub RpmKey(module) with stubs
    # __init__(self, module)
    if test_case_0.__name__ == 'test_case_0':
        test_case_0()
    else:
        print("Test case 0 failed: " + test_case_0.__name__)


# Generated at 2022-06-25 03:08:06.992416
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    RpmKey_fetch_key_0 = RpmKey(0)
    RpmKey_fetch_key_0.RpmKey_fetch_key_0 = 0
    assert RpmKey_fetch_key_0.RpmKey_fetch_key_0 == 0


# Generated at 2022-06-25 03:08:12.715755
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)


# Generated at 2022-06-25 03:08:13.979617
# Unit test for constructor of class RpmKey
def test_RpmKey():
    obj_RpmKey = RpmKey()


# Generated at 2022-06-25 03:08:19.309955
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    gpg_path = os.getenv('GPG_EXECUTABLE', '/usr/bin/gpg')
    rpm_path = os.getenv('RPM_EXECUTABLE', '/bin/rpm')
    rp = RpmKey(rpm_path, gpg_path)
    keyfile = rp.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    os.unlink(keyfile)


# Generated at 2022-06-25 03:08:19.859792
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    assert True


# Generated at 2022-06-25 03:08:21.069099
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 03:08:21.603656
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    pass


# Generated at 2022-06-25 03:08:42.240274
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    tmp = tempfile.mkstemp()

# Generated at 2022-06-25 03:08:46.305022
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    keyid = 'test'
    cmd = '-q  gpg-pubkey'
    rc, stdout, stderr = RpmKey.module(cmd)
    if rc != 0:  # No key is installed on system
        pass
    cmd += ' --qf "%{description}" | --no-tty --batch --with-colons --fixed-list-mode -'
    stdout, stderr = RpmKey.execute_command(cmd)
    for line in stdout.splitlines():
        if keyid in line.split(':')[4]:
            pass
    # return False


# Generated at 2022-06-25 03:08:47.742981
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    obj = RpmKey(AnsibleModule())
    var_0 = obj.getfingerprint()


# Generated at 2022-06-25 03:08:49.651507
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    obj = RpmKey(module)
    result = obj.execute_command(['', ''])


# Generated at 2022-06-25 03:08:53.767096
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    str_0 = ''
    str_1 = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    keyfile = RpmKey.fetch_key(str_0, str_1)
    assert is_pubkey(keyfile)


# Generated at 2022-06-25 03:08:59.019190
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_0 = '0F93715D'
    var_1 = '0x0F93715D'

    key_0 = RpmKey(None)
    var_2 = key_0.normalize_keyid(var_0)
    var_3 = key_0.normalize_keyid(var_1)

    assert var_2 == '0F93715D'
    assert var_3 == '0F93715D'


# Generated at 2022-06-25 03:09:00.772792
# Unit test for constructor of class RpmKey
def test_RpmKey():
    print('Testing %s' % (test_case_0.__name__))
    test_case_0()
    assert var_0 == False

# Generated at 2022-06-25 03:09:03.910637
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    str_0 = '#n;F[4N$?9~pF'
    var_0 = is_pubkey(str_0)


# Generated at 2022-06-25 03:09:04.784535
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    assert True


# Generated at 2022-06-25 03:09:05.746360
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # AssertionError
    pass


# Generated at 2022-06-25 03:09:33.519579
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    param_0 = 'RpmKey'
    param_0 = RpmKey()
    param_1 = RpmKey()
    param_1 = 'RpmKey'
    param_2 = 'keyid'
    var_0 = param_0.drop_key(param_2)
    var_1 = param_1.drop_key(param_1)


# Generated at 2022-06-25 03:09:36.119844
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = RpmKey(None)
    str_0 = '0x12345678'
    assert var_0.is_keyid(str_0)

# Generated at 2022-06-25 03:09:38.384972
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = './test_data/0CA22CBE.gpg'
    rpm_key_0 = RpmKey(None)
    var_0 = rpm_key_0.getkeyid(keyfile)
    assert var_0 == '0CA22CBE'


# Generated at 2022-06-25 03:09:43.447839
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    cmd = ['/usr/bin/rpm', '-q', 'gpg-pubkey', '--qf', '"%{description}"', '|', '/usr/bin/gpg', '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '-']
    rpm_key = RpmKey()
    stdout, stderr = rpm_key.execute_command(cmd)

    assert stdout == 'pub:c:2:2048:1:D4DE5ABDE2A7287644EAC7E36D1A9E5DB3ECB262:1615102305:::u:::scESC:::f:::23::0:', 'Expected output not found'
    assert stderr == '', 'Expected error output not found'

# Generated at 2022-06-25 03:09:50.950638
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    x = RpmKey(None)
    tests = [
      ( '0x4daba5d439a5bb8b', True ),
      ( '4daba5d439a5bb8b', True ),
      ( 'bad keyid', False ),
    ]
    for arg, ret_val in tests:
        result = x.is_keyid(arg)
        if result != ret_val:
            raise Exception("Unit test failure: expected {0} got {1}".format(ret_val, result))


# Generated at 2022-06-25 03:09:53.693710
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Initializing the class instance
    obj = RpmKey()
    # Testing if a correct value is return
    assertTrue(obj.getfingerprint())


# Generated at 2022-06-25 03:09:57.200029
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    str_0 = '*4nU:7sU4'
    str_1 = '0xBEaAC77A'
    RpmKey_0 = RpmKey(None)
    assert RpmKey_0.is_keyid(str_0)
    assert RpmKey_0.is_keyid(str_1)


# Generated at 2022-06-25 03:09:58.913100
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_0 = 'test_str'
    var_1 = RpmKey.normalize_keyid(var_0)


# Generated at 2022-06-25 03:10:03.929556
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    key = '   0xa8a019a6'
    assert RpmKey.normalize_keyid(key) == 'A8A019A6'


# Generated at 2022-06-25 03:10:06.050752
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    obj_0 = RpmKey(module)
    str_0 = "0xDEADB33F"
    var_0 = obj_0.is_keyid(str_0)
    assert var_0 == True


# Generated at 2022-06-25 03:11:11.036767
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    RpmKey_instance = RpmKey(None)
    RpmKey_instance.drop_key(var_0)


# Generated at 2022-06-25 03:11:20.977873
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    str_0 = 'H3'
    r_0 = RpmKey(str_0)
    str_1 = '0xabcd'
    str_2 = r_0.normalize_keyid(str_1)
    str_3 = 'abcDEEF'
    r_1 = RpmKey(str_3)
    str_4 = '0Xabcd123'
    str_5 = r_1.normalize_keyid(str_4)
    str_6 = '0xabcd456'
    str_7 = ' abcdef '
    r_2 = RpmKey(str_7)
    str_8 = r_2.normalize_keyid(str_6)


# Generated at 2022-06-25 03:11:22.995720
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    arg_0 = 'sYX_a4'
    # Call the method
    ret = RpmKey.fetch_key(arg_0)


# Generated at 2022-06-25 03:11:24.939987
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    rpm_key_0 = RpmKey()
    str_0 = rpm_key_0.getkeyid()


# Generated at 2022-06-25 03:11:35.949186
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    str_0 = '9*S6u|7MKU^Y\-!\n'

# Generated at 2022-06-25 03:11:41.760036
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid_0 = '0xDEADB33F'
    keyid_1 = '0XDEADB33F'
    keyid_2 = '0xDEADB33F '
    keyid0_expected = 'DEADB33F'
    keyid1_expected = 'DEADB33F'
    keyid2_expected = 'DEADB33F'
    # should not raise
    keyid0 = RpmKey.normalize_keyid(keyid_0)
    keyid1 = RpmKey.normalize_keyid(keyid_1)
    keyid2 = RpmKey.normalize_keyid(keyid_2)
    assert keyid0 == keyid0_expected
    assert keyid1 == keyid1_expected
    assert keyid2 == keyid2_expected

# Generated at 2022-06-25 03:11:51.769044
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey_instance = RpmKey(module)

    # Test with lower case 'true'
    cmd = dict(cmd='true')
    RpmKey_instance.execute_command(cmd)

    # Test with lower case 'false'
    cmd = dict(cmd='false')
    RpmKey_instance.execute_command(cmd)

# Generated at 2022-06-25 03:11:56.037968
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Some tests
    str_0 = '-Ey+`3UH%f=iL^qD-%(<'
    keyfile_0 = '~/v=Gn<R8~F'
    # Test case 1
    var_0 = is_pubkey(str_0)
    assert var_0 == False
    var_1 = RpmKey.getfingerprint(keyfile_0)

# Generated at 2022-06-25 03:11:59.909867
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid('HELLO') == 'HELLO'
    assert RpmKey.normalize_keyid('0xHELLO') == 'HELLO'
    assert RpmKey.normalize_keyid('\n0xHELLO ') == 'HELLO'


# Generated at 2022-06-25 03:12:02.006264
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    keyid = 'deadb33f'
    obj = RpmKey(module)
    bool_0 = obj.is_key_imported(keyid)
    assert(bool_0)


# Generated at 2022-06-25 03:14:46.245493
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    obj_0 = RpmKey(RpmKey())  # TODO: TypeError: __init__() takes exactly 2 arguments (1 given)
    var_0 = obj_0.is_keyid('0xB1E70D26')
    print(var_0)

# Generated at 2022-06-25 03:14:49.049739
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    str_0 = '*<1h'
    var_0 = str_0
    obj_0 = RpmKey(var_0)
    str_0 = '*<1h'

    assert obj_0.is_keyid(str_0)


# Generated at 2022-06-25 03:14:55.181529
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    str_0 = 'gpg-pubkey-a7412f2f-52f1325b'
    var_1 = RpmKey(str_0)
    assert var_1.normalize_keyid() == 'A7412F2F', 'Test 1 Failed'


# Generated at 2022-06-25 03:15:02.785407
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    RpmKey_0 = RpmKey(module)

    str_0 = '0xDEADB33F'
    str_1 = RpmKey_0.normalize_keyid(str_0)
    str_2 = 'DEADB33F'
    out_0 = str_1 == str_2
    assert out_0

# Generated at 2022-06-25 03:15:13.935578
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible_collections.ansible.builtin.plugins.module_utils import basic
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_native
    from ansible_collections.ansible.builtin.plugins.module_utils.urls import fetch_url
    import os.path
    import re
    import tempfile
    str_0 = 'http://ssl.homelinux.org/rpm-repo.key'
    var_0 = RpmKey(None)
    var_1 = str_0
    var_2 = var_0.fetch_key(var_1)
    var_3 = os.path.isfile(var_2)
    var_4 = os.path.isfile(var_2)

# Generated at 2022-06-25 03:15:17.076888
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Unit test for method is_key_imported of class RpmKey
    str_0 = '5e5c6d5e'
    var_0 = RpmKey.is_key_imported(str_0)


# Generated at 2022-06-25 03:15:18.704738
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import_key = RpmKey.import_key
    cmd = '--import $keyfile'
    assert import_key(cmd) == 'rpm --import $keyfile'

# Generated at 2022-06-25 03:15:22.098731
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    tester = RpmKey('keypath')
    assert tester.getkeyid() == "keyid"


# Generated at 2022-06-25 03:15:28.117757
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    instance = RpmKey(var_0)
    str_0 = '~s<M;;I(:=?y`3qV4'
    var_1 = instance.getkeyid(str_0)


# Generated at 2022-06-25 03:15:34.279827
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = '-----BEGIN PGP PUBLIC KEY BLOCK-----\nVersion: GnuPG v2\n\n'
    var_1 = '-----END PGP PUBLIC KEY BLOCK-----\n'
    var_0 = var_0 + var_1
    tmp_0 = tempfile.NamedTemporaryFile()
    var_0 = tmp_0.name
    arg_0 = var_0