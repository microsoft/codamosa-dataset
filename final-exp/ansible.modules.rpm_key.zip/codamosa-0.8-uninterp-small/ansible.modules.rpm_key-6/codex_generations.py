

# Generated at 2022-06-25 03:06:54.256046
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = RpmKey(main())
    var_2 = var_1.getkeyid()


# Generated at 2022-06-25 03:06:55.768461
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    pass


# Generated at 2022-06-25 03:06:58.345874
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    obj_RpmKey = RpmKey()
    keystr = ''
    return_value = obj_RpmKey.is_keyid(keystr)
    assert True == return_value


# Generated at 2022-06-25 03:07:07.992026
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = 0xA0B0C00D
    var_2 = 0xBADF00D
    var_3 = 0xDEADBEEF
    obj = RpmKey(None)
    res = obj.drop_key(var_1, var_2, var_3)
    var_1 = var_1 + 1
    var_2 = var_2 + 1
    var_3 = var_3 + 1
    return (var_1 ^ var_2 ^ var_3 ^ res) == 0xA0B0C00D


# Generated at 2022-06-25 03:07:09.898778
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    rpm_key = RpmKey(module)
    assert rpm_key.getfingerprint() == None


# Generated at 2022-06-25 03:07:13.875754
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = 0
    var_2 = "keyfile"
    var_0 = RpmKey(var_1)
    var_0.import_key(var_2)
    var_0.import_key(var_2)


# Generated at 2022-06-25 03:07:24.277868
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native
    import os.path
    import tempfile

    # create class object
    obj = RpmKey(None)

    # create test fixtures
    url = "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0xEEA14886"
    response, info = fetch_url(obj.module, url, force=True)
    assert 'status' in info
    assert info['status'] == 200
    assert 'content' in info
    assert is_pubkey(info['content'])

    # create tempfile
    tmpfd, tmpname = tempfile.mkstemp()

# Generated at 2022-06-25 03:07:27.257718
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    test_obj = RpmKey()
    test_obj.is_keyid(keyid)


# Generated at 2022-06-25 03:07:29.390163
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_RpmKey.normalize_keyid('0x12345678') == '12345678'

# Generated at 2022-06-25 03:07:30.962658
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    print("test_RpmKey_getfingerprint")
    assert (True)


# Generated at 2022-06-25 03:07:48.772362
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey()
    var_0.is_key_imported("")


# Generated at 2022-06-25 03:07:52.885934
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_1 = (os.path.isfile(tempfile.mkstemp()))
    var_2 = main()


# Generated at 2022-06-25 03:07:55.593180
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpm_key = RPM_KEY()
    return_value = rpm_key.normalize_keyid('0xDEADB33F')
    assert return_value == 'DEADB33F'


# Generated at 2022-06-25 03:07:57.808057
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import_key = RpmKey.import_key(test_case_0)


# Generated at 2022-06-25 03:08:02.975740
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    key_id = "0x7f835c64177439eb"
    assert RpmKey.normalize_keyid(RpmKey, key_id) == "7F835C64177439EB"
    key_id = "0X7f835c64177439eb"
    assert RpmKey.normalize_keyid(RpmKey, key_id) == "7F835C64177439EB"

# Generated at 2022-06-25 03:08:07.742359
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rpm_key = RpmKey(None)
    assert rpm_key.drop_key("test_key") is None


# Generated at 2022-06-25 03:08:13.141167
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import mock
    import os
    import sys
    import tempfile
    temp_file_name = tempfile.mkstemp()
    var_0 = RpmKey(module)
    var_0._RpmKey__module = mock.Mock()
    var_0._RpmKey__module.run_command = mock.Mock()
    var_0._RpmKey__module.run_command.return_value = 0, 'success', ''
    var_1 = var_0.normalize_keyid('abcabcabcabc')
    assert var_1 == 'ABCABCABCABC'
    var_2 = var_0.normalize_keyid('0xabcabcabcabc')
    assert var_2 == 'ABCABCABCABC'

# Generated at 2022-06-25 03:08:14.223457
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = main()
    gpg = var_1[0]
    return gpg[52]


# Generated at 2022-06-25 03:08:15.842665
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = None
    var_1 = main()

    fetch_key(var_0)


# Generated at 2022-06-25 03:08:18.447674
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_0 = RpmKey(None)
    var_1 = var_0.normalize_keyid('0xabcd1234')
    assert var_1 == 'ABCD1234'

# Generated at 2022-06-25 03:08:49.521235
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import mock
    RpmKey.__init__(mock.Mock())


# Generated at 2022-06-25 03:08:50.254346
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    assert False


# Generated at 2022-06-25 03:08:51.632412
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    auth = RpmKey()
    dest = auth.drop_key()


# Generated at 2022-06-25 03:08:54.971156
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = is_keyid("DEADBEEF")  # Pass hash
    assert var_0 == True
    var_1 = is_keyid(0)  # Pass number
    assert var_1 == False


# Generated at 2022-06-25 03:09:02.925871
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
  var_1 = RpmKey()
  var_2 = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
  try: int(var_1)
  except: pass
  try: str(var_1)
  except: pass
  try: var_1['']
  except: pass
  try:
    var_1.fetch_key(var_2)
  except: pass
  var_3 = RpmKey()
  try: int(var_3)
  except: pass
  try: str(var_3)
  except: pass
  try: var_3['']
  except: pass
  try:
    var_3.fetch_key(var_2)
  except: pass
  var_4 = RpmKey()

# Generated at 2022-06-25 03:09:10.610031
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpm_key_0 = RpmKey(module)
    assert rpm_key_0.normalize_keyid("DD7D3F0E") == "DD7D3F0E"
    assert rpm_key_0.normalize_keyid("0xDD7D3F0E") == "DD7D3F0E"
    assert rpm_key_0.normalize_keyid(" 0xDD7D3F0E ") == "DD7D3F0E"
    assert rpm_key_0.normalize_keyid(" 0xdd7d3f0e ") == "DD7D3F0E"


# Generated at 2022-06-25 03:09:13.298893
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_1 = RpmKey()
    var_2 = var_1.normalize_keyid()


# Generated at 2022-06-25 03:09:16.975658
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Parameters
    keyfile = None

    # Execution
    ret_val = RpmKey.getfingerprint(keyfile)

    # Verification
    assert ret_val is None


# Generated at 2022-06-25 03:09:18.404388
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey(None)
    var_0.is_key_imported(None)


# Generated at 2022-06-25 03:09:19.429684
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_0 = RpmKey()


# Generated at 2022-06-25 03:10:14.083607
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = main()


# Generated at 2022-06-25 03:10:16.676149
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = main()


# Generated at 2022-06-25 03:10:18.505659
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = '.'
    obj = RpmKey(keyfile)
    result = obj.getkeyid()
    assert isinstance(result, str)


# Generated at 2022-06-25 03:10:20.386826
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_0 = RpmKey.normalize_keyid(self, keyid)


# Generated at 2022-06-25 03:10:26.709484
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    main = RpmKey()
    main.execute_command = mock_execute_command
    main.import_key(main.keyfile)


# Generated at 2022-06-25 03:10:27.802099
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = main()
    var_1.getfingerprint()


# Generated at 2022-06-25 03:10:37.543128
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_0 = RpmKey(main())
    var_1 = '0xDEADB33F'
    ret_0 = var_0.normalize_keyid(var_1)
    assert ret_0 == 'DEADB33F'
    var_1 = 'DEADB33F'
    ret_0 = var_0.normalize_keyid(var_1)
    assert ret_0 == 'DEADB33F'
    var_1 = ' 0XDEADB33F '
    ret_0 = var_0.normalize_keyid(var_1)
    assert ret_0 == 'DEADB33F'

# Generated at 2022-06-25 03:10:38.438110
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert main() == None

# END.

# Generated at 2022-06-25 03:10:42.044253
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    rpmKey = RpmKey()
    cmd = ['/usr/bin/rpm', '-q', 'gpg-pubkey', '--qf', '%{description}', '|', '/usr/bin/gpg', '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '-']
    stdout, stderr = rpmKey.execute_command(cmd)


# Generated at 2022-06-25 03:10:44.955324
# Unit test for constructor of class RpmKey
def test_RpmKey():
    param_0 = dict( state='present', key='http://apt.sw.be/RPM-GPG-KEY.dag.txt' )
    assert len( RpmKey(param_0) ) >= 1


# Generated at 2022-06-25 03:12:45.456620
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = main()


# Generated at 2022-06-25 03:12:49.889529
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = create_RpmKey(False, False, False, '0xDB2F', 'DEADB33F', '/usr/bin/rpm', '/usr/bin/gpg2', 'ansible.module_utils.basic.AnsibleModule')
    var_2 = var_1.import_key("gpg-pubkey")
    assert var_2 is None


# Generated at 2022-06-25 03:12:57.370273
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = RpmKey()
    var_2 = "/path/to/RPM-GPG-KEY.dag.txt"
    var_3 = var_1.getkeyid(var_2)
    assert(var_3 == "DEADBEEF")


# Generated at 2022-06-25 03:13:00.843492
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_1 = RpmKey()
    var_2 = '0xDEADB33F'
    ret_1 = var_1.normalize_keyid(var_2)
    assert ret_1 == 'DEADB33F'


# Generated at 2022-06-25 03:13:08.795362
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = '/bin/rpm'
    var_2 = ['/bin/rpm', '-q', 'gpg-pubkey', '--qf', '%{description}', '|', '/bin/gpg', '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '-']
    var_3 = RpmKey(var_0)
    var_4 = var_3.execute_command(var_1, var_2)
    var_4 = main()


# Generated at 2022-06-25 03:13:15.368070
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = RpmKey()
    var_2 = ['command', '--option', 'arg1 arg2 arg3', 'another_arg']
    REQUIRED_MODULES = ['pexpect', 'pickle', 're', 'cryptography']
    var_3 = run_command(var_0, var_1)
    assert var_3 == var_2


# Generated at 2022-06-25 03:13:19.740982
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    keyid = "0xDEADB33F"
    rpmkey = RpmKey()
    actual_output = rpmkey.is_key_imported(keyid)
    expected_output = True
    assert actual_output == expected_output


# Generated at 2022-06-25 03:13:28.236012
# Unit test for constructor of class RpmKey
def test_RpmKey():
    Mock_AnsibleModule = MagicMock(return_value=None)
    mock_module = Mock_AnsibleModule()
    Mock_AnsibleModule.__new__.return_value = mock_module
    mock_module.params = {'state': 'present', 'key': 'DEADB33F', 'fingerprint': '', 'validate_certs': True}
    var_1 = RpmKey(mock_module)
    assert var_1.module == mock_module
    assert var_1.rpm == '/bin/rpm'
    assert var_1.gpg == '/usr/bin/gpg'

# Generated at 2022-06-25 03:13:28.989694
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    param_0 = main()


# Generated at 2022-06-25 03:13:30.791633
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey(0)
    assert var_1.getfingerprint("file_path") == "Fingerprint of file_path"
