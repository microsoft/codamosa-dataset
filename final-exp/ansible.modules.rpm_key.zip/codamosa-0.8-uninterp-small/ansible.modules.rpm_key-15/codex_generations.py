

# Generated at 2022-06-25 03:07:01.586341
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module= AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module).drop_key("06e857605c988c33")

# Generated at 2022-06-25 03:07:03.949915
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey({})
    var_2 = var_1.getfingerprint('keyfile')


# Generated at 2022-06-25 03:07:05.111286
# Unit test for constructor of class RpmKey
def test_RpmKey():

    test_case_0()

# Generated at 2022-06-25 03:07:16.829613
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = "/etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release"

# Generated at 2022-06-25 03:07:26.123989
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda msg: None
            self.exit_json = lambda changed: None

        def run_command(self, cmd, *args, **kwargs):
            return (0, '', '')

        def get_bin_path(self, arg, *args, **kwargs):
            return arg

    import tempfile
    import os.path
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native

    mock_module = MockModule()

# Generated at 2022-06-25 03:07:27.217525
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = main()


# Generated at 2022-06-25 03:07:28.242713
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    pass



# Generated at 2022-06-25 03:07:31.646733
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    obj = RpmKey(AnsibleModule())
    input = ' 0xDEADB33F'
    expected = 'DEADB33F'
    assert obj.normalize_keyid(input) == expected


# Generated at 2022-06-25 03:07:39.725220
# Unit test for method getfingerprint of class RpmKey

# Generated at 2022-06-25 03:07:41.582862
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = RpmKey('')
    var_0.fetch_key('https://dag.wieers.com/rpm/packages/RPM-GPG-KEY.dag.txt')
    var_0.fetch_key('http://copy.com/copy.gpg')


# Generated at 2022-06-25 03:07:59.222056
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey


# Generated at 2022-06-25 03:08:00.081744
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = RpmKey()


# Generated at 2022-06-25 03:08:05.990341
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    param_0 = tempfile.mkstemp
    param_1 = '--no-tty'
    param_2 = '--batch'
    param_3 = '--with-colons'
    param_4 = '--fixed-list-mode'
    param_5 = '--with-fingerprint'
    instance = RpmKey()
    try:
        instance.getfingerprint(param_0, param_1, param_2, param_3, param_4, param_5)
    except AttributeError:
        print('')


# Generated at 2022-06-25 03:08:07.978326
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Initialization of the test environment
    # test_RpmKey_import_key()
    # Actual class instantiation
    rc,var_0 = test_case_0()
    assert rc == 0

# Generated at 2022-06-25 03:08:09.301396
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    keyfile = "keyfile"
    obj = RpmKey(module)
    obj.import_key(keyfile)


# Generated at 2022-06-25 03:08:11.997421
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_key_instance = RpmKey()
    var_0 = rpm_key_instance.is_keyid("")
    assert var_0 == False


# Generated at 2022-06-25 03:08:14.984006
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_0 = RpmKey()
    var_1 = read_file('tests/data/input_gpg_pubkeys/input_gpg_pubkeys_1.txt')
    var_2 = read_file('tests/data/output_gpg_pubkeys/output_gpg_pubkeys_1.txt')
    var_3 = var_0.getfingerprint(var_1)
    assert var_3 == var_2

# Generated at 2022-06-25 03:08:17.343921
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    url = "https://verifier.portal.trustly.com/trusted.key"
    expected_output = "-----BEGIN PGP PUBLIC KEY BLOCK-----"
    var_0 = RpmKey.fetch_key(url)
    with open(var_0, "r") as f:
        actual_output = f.readline()

    assert actual_output == expected_output


# Generated at 2022-06-25 03:08:20.256828
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Instantiation of the class
    var_1 = RpmKey()

    # Call to method
    var_2 = var_1.is_key_imported()

    # Assertions
    assert var_2 == False


# Generated at 2022-06-25 03:08:21.119186
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = main()


# Generated at 2022-06-25 03:09:06.033980
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_0 = RpmKey(0)
    const_0 = 'E04F7BBE'
    var_1 = var_0.normalize_keyid('0xE04F7BBE')
    assert var_1 == const_0, 'Parameter 0 of method normalize_keyid is not equal to constant'
    const_0 = 'E04F7BBE'
    var_1 = var_0.normalize_keyid('E04F7BBE')
    assert var_1 == const_0, 'Parameter 0 of method normalize_keyid is not equal to constant'
    const_0 = 'E04F7BBE'
    var_1 = var_0.normalize_keyid('E04F7BBE ')

# Generated at 2022-06-25 03:09:08.812661
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var = main()
    RpmKey_fetch_key_0 = var.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-25 03:09:11.260825
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    rpm_key_obj = RpmKey()
    var_1 = rpm_key_obj.is_key_imported(keyid)
    return var_1


# Generated at 2022-06-25 03:09:22.001534
# Unit test for constructor of class RpmKey
def test_RpmKey():
    with mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path', return_value='/root/ansible/lib/ansible/module_utils/basic.py'), mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path', return_value='/root/ansible/lib/ansible/module_utils/basic.py'), mock.patch('ansible.module_utils.basic.AnsibleModule.execute_command', return_value=(0, '0', '')), mock.patch('ansible.module_utils.basic.AnsibleModule.fail_json', return_value=None):
        var_0 = RpmKey(mock.MagicMock)

# Generated at 2022-06-25 03:09:32.455602
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert_equal(RpmKey.normalize_keyid(' '), '')
    assert_equal(RpmKey.normalize_keyid('0'), '0')
    assert_equal(RpmKey.normalize_keyid('0x'), '')
    assert_equal(RpmKey.normalize_keyid('0x0'), '0')
    assert_equal(RpmKey.normalize_keyid('0x00'), '0')
    assert_equal(RpmKey.normalize_keyid('0x01'), '1')
    assert_equal(RpmKey.normalize_keyid('0xFE'), 'FE')
    assert_equal(RpmKey.normalize_keyid('0XFE'), 'FE')
    assert_equal(RpmKey.normalize_keyid('0xff'), 'FF')


# Generated at 2022-06-25 03:09:37.294425
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_5 = RpmKey(None)
    assert(var_5.is_key_imported('DEADBEEF') == False)


# Generated at 2022-06-25 03:09:39.432146
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert var_0.normalize_keyid('abcd1234') == 'ABCD1234'


# Generated at 2022-06-25 03:09:47.237041
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = RpmKey()
    var_1 = RpmKey()
    var_1.module = 'gpg'
    var_2 = RpmKey()
    var_2.module = 'gpg'
    var_3 = RpmKey()
    var_3.module = 'gpg'
    var_4 = RpmKey()
    var_4.module = 'gpg'
    var_5 = RpmKey()
    var_5.module = 'gpg'
    var_6 = RpmKey()
    var_6.module = 'gpg'
    var_7 = RpmKey()
    var_7.module = 'gpg'
    var_8 = RpmKey()
    var_8.module = 'gpg'
    var_9 = RpmKey()
    var_

# Generated at 2022-06-25 03:09:49.636150
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    var_0 = RpmKey()
    var_1 = var_0.fetch_key(url = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-25 03:09:55.299397
# Unit test for constructor of class RpmKey
def test_RpmKey():

    # Initializing class
    class_init = RpmKey.RpmKey()

    class_init.execute_command()
    class_init.is_key_imported()
    class_init.is_keyid()
    class_init.getkeyid()
    class_init.normalize_keyid()
    class_init.fetch_key()
    class_init.import_key()
    class_init.drop_key()

# Generated at 2022-06-25 03:11:15.998769
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = RpmKey("hacosta")
    var_1 = var_0.is_keyid("hacosta")
    assert var_1 == True


# Generated at 2022-06-25 03:11:17.050664
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = main()
    test_case_0()


# Generated at 2022-06-25 03:11:20.712903
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = RpmKey(main())
    var_2 = var_1.is_key_imported('0xDEADB33F')
    print(var_2)


# Generated at 2022-06-25 03:11:30.111327
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpmkey = RpmKey(AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    ))
    assert rpmkey.is_keyid("0xDEADB33F") == True
    assert rpmkey.is_keyid("DEADB33F") == True
    assert rpmkey.is_keyid("0xDEADB33FX") == False
    assert rpmkey.is_keyid("") == False

# Generated at 2022-06-25 03:11:33.267773
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey()
    var_1 = var_0.is_key_imported()


# Generated at 2022-06-25 03:11:36.425163
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = "DEADB33F"
    var_0 = RpmKey.normalize_keyid(self, keyid)

# Generated at 2022-06-25 03:11:40.460806
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Create a mock object
    rpm_key = RpmKey()

    # Ensure our str is normalized
    result = rpm_key.normalize_keyid("0xDEADB33F")
    assert result == "DEADB33F"
    result = rpm_key.normalize_keyid("DEADB33F")
    assert result == "DEADB33F"
    result = rpm_key.normalize_keyid("DEADB33F  ")
    assert result == "DEADB33F"



# Generated at 2022-06-25 03:11:42.291179
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_1 = main()
    var_2 = RpmKey.fetch_key(var_1)
    assert var_2 is None


# Generated at 2022-06-25 03:11:44.814294
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey()
    var_2 = var_1.getfingerprint('')


# Generated at 2022-06-25 03:11:46.801793
# Unit test for constructor of class RpmKey
def test_RpmKey():
    rpm_key_obj = RpmKey
    assert_equals(isinstance(rpm_key_obj, object), True)


# Generated at 2022-06-25 03:15:05.490141
# Unit test for constructor of class RpmKey

# Generated at 2022-06-25 03:15:08.076716
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    test = RpmKey(fetch_url = fetch_url)
    test.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-25 03:15:10.166618
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Implementation of test case 0
    main()

# Generated at 2022-06-25 03:15:15.360043
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    var_1 = RpmKey(module)


# Generated at 2022-06-25 03:15:17.736129
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rp = RpmKey()
    ret = rp.is_keyid("0x6b8d79e6")
    assert(ret)

#Unit test for method is_keyid_exception of class RpmKey

# Generated at 2022-06-25 03:15:22.545226
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Tests get_bin_path method
    var_2 = RpmKey()
    assert var_2.get_bin_path("ls") == True, "\nUnexpected is_key_imported output"



# Generated at 2022-06-25 03:15:27.598262
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    keyid = VAR_0
    assert is_key_imported(keyid) == VAR_1


# Generated at 2022-06-25 03:15:28.566932
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = RpmKey()
    var_2 = main()


# Generated at 2022-06-25 03:15:29.379229
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = main()
    var_1 = main()



# Generated at 2022-06-25 03:15:31.708329
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    key = "https://dl.google.com/linux/linux_signing_key.pub"
    assert (is_pubkey(key)) == False

