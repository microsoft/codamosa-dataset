

# Generated at 2022-06-25 03:06:48.533090
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
	main()

# Generated at 2022-06-25 03:06:53.468618
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpmkey_0 = RpmKey(module)
    str_0 = '0'
    # Call method is_keyid with argument str_0
    assert not rpmkey_0.is_keyid(str_0=str_0)


# Generated at 2022-06-25 03:07:01.976996
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create the argument list to call getfingerprint method of the class RpmKey
    var_0 = "test_string"

    # Create a class object of the class RpmKey
    var_1 = RpmKey(var_0)

    # Call method getfingerprint of the class RpmKey
    var_1.getfingerprint(var_0)

    # Check if the method getfingerprint of class RpmKey 
    # has called subprocess.Popen class to execute the command
    assert subprocess.Popen.called



# Generated at 2022-06-25 03:07:04.161837
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = RpmKey()
    var_1 = '/usr/bin/rpm'
    var_2 = '--import'
    var_3 = '/home/hector/pytest.gpg'
    var_0.import_key(var_1, var_2, var_3)


# Generated at 2022-06-25 03:07:07.696984
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert(rpm_key.module == module)
    assert(rpm_key.rpm == '/bin/rpm')
    assert(rpm_key.gpg == '/usr/bin/gpg2')



# Generated at 2022-06-25 03:07:09.609593
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var = RpmKey(module=main())
    var_0 = RpmKey(var)

# Generated at 2022-06-25 03:07:11.972792
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_RpmKey_instance = RpmKey(var_0)
    var_RpmKey_instance.drop_key()

# Generated at 2022-06-25 03:07:14.627106
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    #print 'is_keyid'
    # getter for method is_keyid of class RpmKey
    var_0 = RpmKey.is_keyid()


# Generated at 2022-06-25 03:07:24.944898
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    pm = mock.patch('ansible.module_utils.basic.AnsibleModule')
    pm.start()
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    params = {u'fingerprint': None, u'state': u'present', u'key': 'DEADB33F'}

    pm = mock.patch('ansible.module_utils.basic.AnsibleModule')
    pm.start()
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(**params)

    while True:
        if m._called_with == params:
            break

    m.check_mode = (False)


# Generated at 2022-06-25 03:07:34.930469
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
  from unittest import mock

  from ansible.module_utils.common._collections_compat import OrderedDict
  from ansible.module_utils._text import to_native
  from ansible.module_utils.six import string_types
  import ansible.constants

  # Mock the module, because we use the module.fail_json in the code
  module = mock.MagicMock()

  # Mock the argspec return value of execute_command
  argspec = mock.MagicMock()
  argspec.return_value = ["self", "cmd"]
  type(module).argspec = argspec

  # Create the RpmKey instance
  rpm_key = RpmKey(module)

  # Mock the run_command of the module, so it always returns a tuple of (0, "stdout", "stderr")


# Generated at 2022-06-25 03:07:56.166601
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = None
    var_2 = None

    # should set var_1 and var_2 to proper values
    var_1 = execute_command(var_1, var_2)
    assert var_1 == -1
    assert var_2 == -1


# Generated at 2022-06-25 03:08:04.161361
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    print('\nUnit test for method normalize_keyid of class RpmKey\n')

    # Test case 0

# Generated at 2022-06-25 03:08:14.432486
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    with mock.patch('RpmKey.RpmKey.execute_command') as mock_execute_command:
        var_12 = mock.Mock()
        var_12.run_command.return_value = ('', '', ())
        var_13 = mock.Mock()
        var_13.check_mode = False
        var_13.params = {'key': '0x726B8D79E6', 'fingerprint': '', 'state': 'present'}
        var_13.fail_json.side_effect = Exception()
        var_13.get_bin_path.return_value = '/usr/bin/rpm'
        var_13.get_bin_path.return_value = '/usr/bin/gpg'
        var_14 = RpmKey(var_13)
        var_7 = var_

# Generated at 2022-06-25 03:08:15.339463
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey()
    var_0.getkeyid()


# Generated at 2022-06-25 03:08:16.571733
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_1 = None
    var_2 = RpmKey()
    var_3 = None
    var_2.is_key_imported(var_3)


# Generated at 2022-06-25 03:08:20.133586
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    key = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    #call
    keyfile = RpmKey.fetch_key(key)
    #assert
    assert os.path.isfile(keyfile)
    assert is_pubkey(keyfile)


# Generated at 2022-06-25 03:08:20.990779
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_0 = main()


# Generated at 2022-06-25 03:08:28.718407
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test cases for method / function.
    # Each test case should raise an exception for the error case.
    var_0 = '0xDEADBEEF'
    var_1 = 'DEADBEEF'
    var_2 = '0xDEADBEEF8'
    var_3 = '0xDEADBEEF8'
    var_4 = '0xDEABBEEF8'
    var_5 = '0xDEABBEEF8'
    var_6 = 'DEABBEEF8'
    var_7 = 'DEABBEEF8'
    var_8 = 'DEADBEEF'
    var_9 = '0xDEADBEEF'
    var_10 = 'DEABBEEF'

    # Check if an exception is raised.

# Generated at 2022-06-25 03:08:31.614642
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_keystr = '0xACE1234F'
    var_expected = True
    var_actual = is_keyid(var_keystr)
    assert var_actual == var_expected


# Generated at 2022-06-25 03:08:33.289553
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
  # Setup test
  var_1 = main()
  keyfile = None
  var_1.import_key(keyfile)


# Generated at 2022-06-25 03:08:56.101362
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    import re

    re = re.compile('(0x)?[0-9a-f]{8}', re.IGNORECASE)
    pass


# Generated at 2022-06-25 03:08:59.178670
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey()
    var_1 = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'keys/', 'hacosta-sshnopass-pub.asc')
    pass

# Generated at 2022-06-25 03:09:01.396387
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Variables
    test_object = RpmKey.RpmKey(module)
    keyfile = ""

    # Define
    assert test_object != None
    assert keyfile != None
    # Execute
    test_object.import_key(keyfile)
    # Verify
    assert True


# Generated at 2022-06-25 03:09:07.046146
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_0 = main()
    var_1 = RpmKey(var_0)
    var_2 = "gpg-pubkey"
    var_3 = "%s" % var_2[-8:].lower()
    var_4 = var_1.drop_key(var_2)

#Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-25 03:09:11.876743
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class_0 = RpmKey(None)
    var_0 = [None, None]
    var_0 = ['echo', 'Hello']
    var_1 = class_0.execute_command(var_0)
    var_2 = 'Hello\n'
    var_3 = '\n'
    assert var_1[0] == var_2 and var_1[1] == var_3


# Generated at 2022-06-25 03:09:14.154174
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Get instance of class RpmKey
    var_0 = RpmKey(None)
    # Call method normalize_keyid of class RpmKey with arguments
    var_0.normalize_keyid('ABCD1234')


# Generated at 2022-06-25 03:09:15.114741
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    assert var_0.is_key_imported('')


# Generated at 2022-06-25 03:09:16.747198
# Unit test for function main
def test_main():
    try:
        assert True
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 03:09:18.403773
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_0 = RpmKey()
    var_1 = var_0.getfingerprint('var_1')
    assert var_1 == 78


# Generated at 2022-06-25 03:09:24.726896
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    print('Test for RpmKey.execute_command')
    var_0 = RpmKey(None)
    var_1 = ['rpm', '-q', 'gpg-pubkey']
    var_2 = 1, '', 'No key is installed on system'
    var_3 = var_0.execute_command(var_1)
    var_4 = var_2
    assert var_4 == var_3

# Generated at 2022-06-25 03:09:42.829179
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert 1 == 1


# Generated at 2022-06-25 03:09:44.817028
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Setup
    main()

    # Testing
    var_0 = main()

    assert var_0 is None, 'Test case failed: expected: %s actual: %s' % (None, var_0)


# Generated at 2022-06-25 03:09:48.975442
# Unit test for constructor of class RpmKey
def test_RpmKey():
    try:
        assert var_0 == None
    except AssertionError as e:
        print("test constructor of class RpmKey failed")
        print(e)


# Generated at 2022-06-25 03:09:51.760293
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey(main())
    res_0 = var_0.getkeyid('main()')
    assert(res_0 == 'main')
 

# Generated at 2022-06-25 03:09:53.207502
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    """Test is_key_imported of class RpmKey"""
    

# Generated at 2022-06-25 03:09:55.674550
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = main()
    class_instance = RpmKey(module)
    assert isinstance(class_instance.normalize_keyid('0x5571A235'), str)


# Generated at 2022-06-25 03:10:02.874811
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    obj_0 = RpmKey(None)
    var_0 = obj_0.is_keyid('0xDEADBEEF')
    assert var_0 == True
    var_1 = obj_0.is_keyid('0XDEADBEEF')
    assert var_1 == True
    var_2 = obj_0.is_keyid('DEADBEEF')
    assert var_2 == True
    var_3 = obj_0.is_keyid('Hector')
    assert var_3 == False
    var_4 = obj_0.is_keyid('hector')
    assert var_4 == False
    var_5 = obj_0.is_keyid('0xdeadbeef')
    assert var_5 == False


# Generated at 2022-06-25 03:10:04.325451
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_1 = RpmKey(1)
    var_2 = var_1.fetch_key(1)



# Generated at 2022-06-25 03:10:06.226046
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():

    # create an instance of class RpmKey with parameter arguments
    var_1 = RpmKey()

    # create an instance of class RpmKey with parameter arguments
    var_2 = RpmKey()

# Generated at 2022-06-25 03:10:07.625935
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    arg_0 = None
    var_0 = RpmKey.normalize_keyid(arg_0)


# Generated at 2022-06-25 03:11:01.146323
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Setup local variables for testing
    var_0 = 'tests/data/RPM-GPG-KEY-CentOS-7'
    var_1 = RpmKey(var_0)
    var_2 = var_1.getkeyid(var_0)
    assert var_2 == '0608b895'



# Generated at 2022-06-25 03:11:08.870064
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert "0xDEADB33F" == RpmKey.normalize_keyid("0xDEADB33F")
    assert "DEADB33F" == RpmKey.normalize_keyid("0XDEADB33F")
    assert "DEADB33F" == RpmKey.normalize_keyid("  DEADB33F")
    assert "DEADB33F" == RpmKey.normalize_keyid("DEADB33F ")


# Generated at 2022-06-25 03:11:16.673516
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = RpmKey(module)
    var_2 = '0xAB3A4B836722991E'
    var_3 = 'tests/files/gnupg-pub-key.txt'
    var_1.getkeyid(var_3)
    assert var_2 == var_1.getkeyid(var_3)



# Generated at 2022-06-25 03:11:19.507164
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    var_0 = RpmKey()
    var_0.is_keyid('keyid')


# Generated at 2022-06-25 03:11:26.710089
# Unit test for method is_key_imported of class RpmKey

# Generated at 2022-06-25 03:11:28.171445
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    rpmkey = RpmKey()
    rpmkey.import_key()


# Generated at 2022-06-25 03:11:33.467477
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # test with a \n delimited string
    t1 = RpmKey("module")
    t1.import_key("keyfile")


# Generated at 2022-06-25 03:11:36.032953
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_1 = main()
    print(var_1)


# Generated at 2022-06-25 03:11:37.739539
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_1 = RpmKey()
    assert var_1.execute_command(cmd=None) == None


# Generated at 2022-06-25 03:11:45.150870
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():

    # Instantiate object
    rpm_key_obj = RpmKey(AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ),
    supports_check_mode=True,
    ))

    # Test execute_command
    # TODO


# Generated at 2022-06-25 03:13:33.187467
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey()
    keyfile = var_1.getkeyid()
    var_1.getfingerprint(keyfile)

# Generated at 2022-06-25 03:13:38.471049
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_0 = main()

# Generated at 2022-06-25 03:13:40.885837
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_0 = RpmKey()
    var_0.drop_key('DEADB33F')


# Generated at 2022-06-25 03:13:44.569815
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    obj = RpmKey(test_case_0)
    var_1 = obj.getkeyid(test_case_0)
    assert var_1.__class__.__name__ == 'NoneType', 'Invalid return type for method getkeyid of class RpmKey'

# Generated at 2022-06-25 03:13:49.792856
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from ansible.module_utils.basic import *

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    unit = RpmKey(module)
    unit.drop_key("arg_0")

# Generated at 2022-06-25 03:13:52.318052
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    key_0 = RpmKey()
    url_0 = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    key_0.fetch_key(url=url_0)


# Generated at 2022-06-25 03:13:53.678828
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Simple, no arguments passed
    var_1 = RpmKey()
    print(var_1.is_key_imported())


# Generated at 2022-06-25 03:14:00.089956
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    class_RpmKey = RpmKey()
    keyid = test_case_0(var_0)
    function_return_value = class_RpmKey.drop_key(keyid)


# Generated at 2022-06-25 03:14:00.596979
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    pass

# Generated at 2022-06-25 03:14:01.905193
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Case 0

    var_0 = RpmKey()
    assert var_0 is not None
