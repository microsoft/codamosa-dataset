

# Generated at 2022-06-25 03:06:50.167679
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_0 = RpmKey()
    var_0.normalize_keyid("0x4bbb0adf")


# Generated at 2022-06-25 03:06:52.215834
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    assert callable(RpmKey.fetch_key)


# Generated at 2022-06-25 03:06:53.030911
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    test_case_0()

# Generated at 2022-06-25 03:07:03.615080
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    keyfile = tempfile.NamedTemporaryFile()
    keyfile.write(b'-----BEGIN PGP PUBLIC KEY BLOCK-----')
    keyfile.flush()
    module = mock.Mock()
    module.get_bin_path.return_value = True

# Generated at 2022-06-25 03:07:14.726396
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():

    pgp_key_file = 'pgp_key.txt'

# Generated at 2022-06-25 03:07:17.301626
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey()
    assert_equal(var_0, True)


# Generated at 2022-06-25 03:07:18.695484
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    var_1 = RpmKey()
    pass



# Generated at 2022-06-25 03:07:21.598331
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey(None)
    var_1 = var_0.is_key_imported("7F438280EF8D349F")
    assert var_1 == True


# Generated at 2022-06-25 03:07:22.289820
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 03:07:23.221084
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:07:39.545395
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_1 = ' 0x26a5fcf9 '
    var_2 = '26a5fcf9'
    var_0 = RpmKey.normalize_keyid(var_1)
    def test_eq():
        return var_0 == var_2
    assert test_eq()


# Generated at 2022-06-25 03:07:50.045774
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_441 = None
    var_442 = None
    var_443 = None
    var_444 = None
    var_445 = None
    var_446 = None
    var_447 = None
    var_448 = None
    var_449 = None
    var_450 = None
    var_451 = None
    var_452 = None
    var_453 = None
    var_454 = None
    var_455 = None
    var_456 = None
    var_457 = None
    var_458 = None
    var_459 = None
    var_460 = None
    var_461 = None
    var_462 = None
    var_463 = None
    var_464 = None
    var_465 = None
    var_466 = None
    var_467 = None
    var_468 = None
    var_

# Generated at 2022-06-25 03:07:55.373872
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    '''Check if the key is already imported'''
    # Test with key id present
    var_0 = is_key_imported('0xDEADBEEF')
    print(var_0)

    # Test with key id not present
    var_0 = is_key_imported('0xBEEFDEAD')
    print(var_0)



# Generated at 2022-06-25 03:07:58.084263
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    dummy_self = RpmKey("dummy")
    dummy_keyfile = "dummy"
    var_0 = dummy_self.getfingerprint(dummy_keyfile)
    assert var_0  is None


# Generated at 2022-06-25 03:08:00.134976
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    check_instance = RpmKey(param_0)
    check_instance.drop_key(arg_0)


# Generated at 2022-06-25 03:08:02.063986
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert var_0.normalize_keyid('0xAABBDDEE') == ('AABBDDEE')


# Generated at 2022-06-25 03:08:07.663098
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    var_1 = RpmKey()
    var_1 = var_1.normalize_keyid()


# Generated at 2022-06-25 03:08:14.451067
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    main_obj = main()
    var_1 = main_obj
    # If the key is a url, we need to check if it's present to be idempotent,
    # to do that, we need to check the keyid, which we can get from the armor.
    var_2 = None
    # If the key is a url, we need to check if it's present to be idempotent,
    # to do that, we need to check the keyid, which we can get from the armor.
    var_3 = False
    # If the key is a url, we need to check if it's present to be idempotent,
    # to do that, we need to check the keyid, which we can get from the armor.
    var_4 = main_obj
    # If the key is a url, we need to check if it

# Generated at 2022-06-25 03:08:15.756011
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    obj_RpmKey = RpmKey()
    keyid = 'Foo bar'
    assert_equal(obj_RpmKey.normalize_keyid(keyid), 'foo bar')

# Generated at 2022-06-25 03:08:24.094465
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey(AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    ))
    var_1 = var_0.is_key_imported('')
    assert var_1 == None
    assert 're.match(\'(0x)?[0-9a-f]{8}\', keystr, flags=re.IGNORECASE)' in var_0.is_keyid('').__code__.co_code

# Generated at 2022-06-25 03:09:04.240068
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Defining mock object
    class MockRpmModule:
        def __init__(self):
            self.check_mode = False

        def fail_json(self, msg):
            raise Exception(msg)


# Generated at 2022-06-25 03:09:06.585870
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey()
    param_0 = tempfile.mkstemp()
    var_1.getfingerprint(param_0)


# Generated at 2022-06-25 03:09:14.716672
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = main()
    var_1 = main()
    var_2 = main()
    var_3 = main()
    # Testing for 'fetch_key' method of class RpmKey:
    try:
        # var_0 -> var_1
        var_1 = var_0.fetch_key(var_1)
        assert False, "Exception was expected"
    except AssertionError as e:
        print(e)
    except Exception as e:
        pass
    else:
        assert False, "Exception was expected"
    var_5 = main()
    var_5 = main()
    var_5 = main()
    var_5 = main()
    # Testing for 'fetch_key' method of class RpmKey:
    # var_2 -> var_3
    var_3 = var

# Generated at 2022-06-25 03:09:23.783010
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = ["0x12345678", " 12345678 "]
    expected_result = "12345678"
    var_0 = RpmKey(keyid[0])
    assert var_0.normalize_keyid() == expected_result, \
        'Expected: "' + expected_result + '", but was: "' + var_0.normalize_keyid() + '"'
    var_1 = RpmKey(keyid[1])
    assert var_1.normalize_keyid() == expected_result, \
        'Expected: "' + expected_result + '", but was: "' + var_1.normalize_keyid() + '"'


# Generated at 2022-06-25 03:09:24.988272
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import_key(keyfile)

# Generated at 2022-06-25 03:09:25.676496
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    var_1 = 1


# Generated at 2022-06-25 03:09:30.119890
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import sys
    import os
    
    param_instance = main()
    param_keyid = None
    var_0 = param_instance.normalize_keyid(param_keyid)
    return var_0


# Generated at 2022-06-25 03:09:33.723263
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    # Define arguments and results
    keyid = str
    expected_result = None
    expected_result_0 = None
    expected_result_1 = None

    # Create object
    obj = RpmKey()

    # Test 1
    result = obj.drop_key(keyid)
    if result != expected_result and result != expected_result_0 and result != expected_result_1:
        raise Exception("Test 1: Failed")

    # Return results
    return result


# Generated at 2022-06-25 03:09:37.752877
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    print("import_key")
    # Call test_case_0
    test_case_0()

# Generated at 2022-06-25 03:09:39.906620
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    obj = RpmKey()
    obj.import_key()



# Generated at 2022-06-25 03:10:47.337391
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = RpmKey('/path/to/keyname.gpg')
    rc = keyfile.getkeyid('/path/to/keyname.gpg')
    assert rc == 'keyid'


# Generated at 2022-06-25 03:10:48.750771
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_0 = main()
    var_1 = RpmKey(var_0)

# Generated at 2022-06-25 03:10:50.804402
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = RpmKey()


# Generated at 2022-06-25 03:10:57.330937
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    has_keyid = "EBC6E12C62B1C734026B21222A20E52146B8D79E6"
    module_params = {
        'state': 'present',
        'key': 'https://apt.sw.be/RPM-GPG-KEY.dag.txt'
    }
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
        module_params=module_params
    )

# Generated at 2022-06-25 03:11:06.130328
# Unit test for constructor of class RpmKey
def test_RpmKey():
    test_parameters = {
        "key": "http://apt.sw.be/RPM-GPG-KEY.dag.txt",
        "state": "present"
    }
    module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),),
        supports_check_mode=True, params=test_parameters )
    RpmKey(module)

# Generated at 2022-06-25 03:11:12.787813
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    obj_0 = RpmKey(mock_AnsibleModule())
    mock_AnsibleModule.run_command = mock_run_command
    mock_AnsibleModule.get_bin_path = mock_get_bin_path
    mock_AnsibleModule.add_cleanup_file = mock_add_cleanup_file
    mock_AnsibleModule.cleanup = mock_cleanup
    mock_fetch_url.fetch_url = mock_fetch_url_fetch_url
    returned = obj_0.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt")
    assert returned == "returned"

# Generated at 2022-06-25 03:11:18.484903
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    keyid = '0xDADB33F'
    keyid = '0xDADB33F'
    if not self.module.check_mode:
        stdout, stderr = self.execute_command([self.rpm, '--erase', '--allmatches', "gpg-pubkey-%s" % keyid[-8:].lower()])

## Unit test for method execute_command of class RpmKey

# Generated at 2022-06-25 03:11:20.744177
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = RpmKey(test_case_0)
    var_1 = var_0.getkeyid("test", "test")
    expected = None
    assert var_1 == expected, 'RpmKey.getkeyid: Expected {} but received {}'.format(expected, var_1)


# Generated at 2022-06-25 03:11:23.588144
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = RpmKey()


# Generated at 2022-06-25 03:11:25.329160
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_1 = AnsibleModule()
    var_2 = module(var_1, to_native(var_0))



# Generated at 2022-06-25 03:13:51.465294
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    rpk = RpmKey(var_0)
    rpk.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-25 03:13:52.680363
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    keyid = main()
    main()


# Generated at 2022-06-25 03:13:58.734514
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    var_0 = test_RpmKey_getkeyid(var_0)


# Generated at 2022-06-25 03:14:00.773953
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = RpmKey_mock()
    var_1 = var_0.execute_command([])


# Generated at 2022-06-25 03:14:03.320922
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = RpmKey()
    var_2 = "test_value_3"
    var_1.getfingerprint(var_2)

# Generated at 2022-06-25 03:14:05.494743
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    var_0 = RpmKey()
    var_1 = "test"
    var_2 = var_0.fetch_key(var_1)



# Generated at 2022-06-25 03:14:10.839058
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    print("[+] Starting test case getfingerprint")

    # <Remainder of test case omitted>
    # Example of expected value
    # assert var_0 == [expected_val]


# Generated at 2022-06-25 03:14:15.180438
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    var_0 = RpmKey(Module())
    var_1 = var_0.is_key_imported(arg_0)
    assert isinstance(var_1, bool) == True


# Generated at 2022-06-25 03:14:18.569544
# Unit test for constructor of class RpmKey
def test_RpmKey():
    try:
        e = RpmKey("VF")
    except Exception as err:
        print("Exception: " + err.message)

# Generated at 2022-06-25 03:14:28.676941
# Unit test for constructor of class RpmKey