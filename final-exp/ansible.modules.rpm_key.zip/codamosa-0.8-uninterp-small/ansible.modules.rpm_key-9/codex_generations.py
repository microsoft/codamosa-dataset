

# Generated at 2022-06-25 03:06:48.702604
# Unit test for constructor of class RpmKey
def test_RpmKey():
    pass


# Generated at 2022-06-25 03:06:52.447409
# Unit test for function main
def test_main():
    print('Start test, Function main')
    main()
    print('End test, Function main')


# Generated at 2022-06-25 03:06:58.477349
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    assert isinstance(module.params['state'], str)
    assert isinstance(module.params['key'], str)
    RpmKey(module)

# Generated at 2022-06-25 03:07:08.156065
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmkey = RpmKey(module)
    assert isinstance(rpmkey.is_keyid('cac9ce32'), bool)


# Generated at 2022-06-25 03:07:11.149000
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    try:
        # call the method
        # No need to test this part
        pass
    except Exception as err:
        raise AssertionError("Error: {}".format(err))


# Generated at 2022-06-25 03:07:12.773391
# Unit test for function main
def test_main():
    RpmKey = Mock()
    assert main() == RpmKey

# Generated at 2022-06-25 03:07:20.055762
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module).normalize_keyid()

# Generated at 2022-06-25 03:07:28.331182
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    float_0 = 4967.696
    float_1 = float_0
    float_2 = float_1
    float_3 = float_2
    int_0 = 0
    float_4 = float_3
    float_5 = float_4
    float_6 = float_5
    float_7 = float_6
    float_8 = float_7
    float_9 = float_8
    float_10 = float_9
    float_11 = float_10
    float_12 = float_11
    float_13 = float_12
    float_14 = float_13
    float_15 = float_14
    float_16 = float_15
    float_17 = float_16
    float_18 = float_17
    float_19 = float_18
    float_20 = float_19
    float

# Generated at 2022-06-25 03:07:32.092391
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_key_0 = RpmKey(var_0)
    var_0 = 1.515869e+09
    var_1 = rpm_key_0.is_keyid(var_0)
    assert var_1 == True


# Generated at 2022-06-25 03:07:33.669673
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    r = RpmKey('foo', 'bar')
    assert r.getkeyid() == 'foo'

# Generated at 2022-06-25 03:07:53.577128
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    float_0 = 1648.72
    var_0 = os.path.isfile(float_0)
    int_0 = -7
    var_1 = getkeyid(int_0)


# Generated at 2022-06-25 03:08:02.647577
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    var_1 = to_native("86d")
    var_2 = to_native("rk")
    var_3 = to_native("ar")
    var_4 = to_native("n")
    var_5 = to_native("lu")
    var_6 = to_native("b")
    var_7 = to_native("6")
    var_8 = to_native("b")
    var_9 = to_native("3")
    var_10 = to_native("b")
    var_11 = to_native("4")
    var_12 = to_native("5")
    var_13 = to_native("e")
    var_14 = to_native("c")
    var_15 = to_native("b")
    var_16 = to_native("d")

# Generated at 2022-06-25 03:08:04.389795
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    float_0 = 1337.69
    # Parameter float_0 is not used
    float_1 = float_0


# Generated at 2022-06-25 03:08:09.689012
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Variables set up for test
    var_2 = '0xa1234567'
    class_obj = RpmKey()
    # Test if the method returns the correct result
    assert class_obj.normalize_keyid(var_2) == 'A1234567'


# Generated at 2022-06-25 03:08:11.278735
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    float_0 = is_pubkey(239.946)


# Generated at 2022-06-25 03:08:17.415884
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import random
    random.seed()

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-25 03:08:21.930996
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    try:
        assert isinstance(getkeyid(self, keyfile), str), "getkeyid of RpmKey instance should return str"
    except TypeError as err:
        print("TypeError, message: {0}: {1}".format(err, type(err)))
    except Exception as err:
        print("Exception, message: {0}: {1}".format(err, type(err)))


# Generated at 2022-06-25 03:08:27.996508
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    float_0 = 1648.72
    var_0 = is_pubkey(float_0)
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")
    tmpfile.write('HTTP/1.0 200 OK\n')
    tmpfile.close()
    var_1 = RpmKey(tmpname)
    var_2 = RpmKey.getkeyid(var_1, tmpname)
    var_3 = os.remove(tmpname)
    var_4 = is_pubkey(var_2)


# Generated at 2022-06-25 03:08:29.668303
# Unit test for constructor of class RpmKey

# Generated at 2022-06-25 03:08:32.380425
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    #
    # Initialization
    #
    rpmkey = RpmKey(var_0)

    #
    # Wrap execution and return
    #
    return rpmkey.drop_key()


# Generated at 2022-06-25 03:09:11.703882
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Test case for constructor
    obj = RpmKey(module)
    assert obj
    assert isinstance(obj, RpmKey)



# Generated at 2022-06-25 03:09:17.612541
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)


# Generated at 2022-06-25 03:09:23.258557
# Unit test for function main
def test_main():
    with patch('ansible_collections.ansible.community.plugins.modules.rpm_key.RpmKey') as mock_RpmKey:
        with patch('ansible_collections.ansible.community.plugins.modules.rpm_key.AnsibleModule', return_value=mock_RpmKey):
            main(['test'])



# Generated at 2022-06-25 03:09:28.232099
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    global float_0
    float_0 = 1648.72
    var_0 = test_case_0()
    if float_0 < 0:
        var_0 = - float_0
    return var_0


# Generated at 2022-06-25 03:09:30.603310
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    float_0 = 1648.72
    var_0 = RpmKey(float_0)
    float_1 = 1648.72
    var_1 = var_0.normalize_keyid(float_1)


# Generated at 2022-06-25 03:09:40.715560
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    float_0 = 1648.72
    var_0 = RpmKey(float_0)

# Generated at 2022-06-25 03:09:44.428459
# Unit test for constructor of class RpmKey
def test_RpmKey():
    global var_0
    var_0 = RpmKey(test_case_0)
    if abs(var_0.result - 0.5) < 0.01:
        return True
    else:
        return False

# Generated at 2022-06-25 03:09:48.499132
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    float_0 = 1648.72
    keyid = getkeyid(float_0)


# Generated at 2022-06-25 03:09:49.362785
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    pass


# Generated at 2022-06-25 03:09:52.155969
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    float_0 = 1386.72
    class_0 = RpmKey(float_0)
    var_0 = class_0.getfingerprint('/')

# Generated at 2022-06-25 03:10:48.191917
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    o_RpmKey = RpmKey()
    o_RpmKey.import_key()


# Generated at 2022-06-25 03:10:52.872226
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    float_0 = 1648.72
    var_0 = RpmKey(float_0)
    string_0 = "RpmKey"
    var_1 = var_0.is_keyid(string_0)


# Generated at 2022-06-25 03:10:58.399163
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    var_0 = RpmKey()
    var_1 = [215, -1758, var_0]
    var_2 = var_0.execute_command(var_1)


# Generated at 2022-06-25 03:11:03.776633
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():

	# Test for case 0
	# float_0 = 1648.72
	# var_0 = is_pubkey(float_0)

	# Test for case 1
	float_0 = 1648.72
	var_0 = is_pubkey(float_0)

# Generated at 2022-06-25 03:11:11.239504
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    float_0 = 589.9
    float_1 = float_0 + float_0
    if float_0 > float_1:
        float_0 = float_1 - float_1
    elif float_1 > float_0:
        float_0 = float_0 * float_1
    else:
        float_0 = float_1
    var_0 = float_0 * float_0


# Generated at 2022-06-25 03:11:15.200092
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    float_0 = RpmKey('')
    var_0 = ''
    var_1 = float_0.normalize_keyid(var_0)


# Generated at 2022-06-25 03:11:19.719271
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    # Call function to check if key is already imported
    key_exists = RpmKey.is_key_imported(keyid)

    # Check if key exists or not
    if key_exists:
        print("Key exists")
    else:
        print("Key doesn't exist")


# Generated at 2022-06-25 03:11:30.341486
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module_1 = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Populate the module with parameters passed to the module
    # This includes parameters defined above and any parameters that are part of the module definition
    params = dict()
    params['state'] = 'present'
    params['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    params['validate_certs'] = True
    params['fingerprint']

# Generated at 2022-06-25 03:11:31.267537
# Unit test for constructor of class RpmKey
def test_RpmKey():
    var_0 = RpmKey(None)


# Generated at 2022-06-25 03:11:38.400031
# Unit test for method execute_command of class RpmKey

# Generated at 2022-06-25 03:14:15.286192
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    float_0 = 1521.39
    float_1 = 1563.41
    var_0 = RpmKey(float_0)
    var_1 = var_0.getkeyid(float_1)


# Generated at 2022-06-25 03:14:23.186434
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    float_0 = 615.0
    float_1 = 137.9
    str_0 = 'J'
    str_1 = 'RpmKey.execute_command'
    int_0 = -98
    var_0 = RpmKey(str_0,str_1,int_0)
    str_2 = 'RpmKey.execute_command'
    list_0 = [str_0,str_1,int_0]
    var_0.execute_command(list_0,float_0,float_1)


# Generated at 2022-06-25 03:14:24.634384
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    float_0 = 1648.72
    var_0 = is_pubkey(float_0)


# Generated at 2022-06-25 03:14:25.684863
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    float_0 = 1648.72
    var_0 = is_pubkey(float_0)


# Generated at 2022-06-25 03:14:32.644878
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    arg_0 = {'fingerprint': 'C3D1 656E 1A7E 2E48 EB77  F0D8 8824 2D7E 956A 48E9', 'validate_certs': 'yes', 'state': 'present', 'key': '/path/to/key.gpg'}
    obj_0 = RpmKey(None)
    obj_0.drop_key('foobar')


# Generated at 2022-06-25 03:14:33.129588
# Unit test for constructor of class RpmKey
def test_RpmKey():
    main()

# Generated at 2022-06-25 03:14:34.597745
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    param_1 = is_pubkey(float_0)
    param_0 = RpmKey(is_pubkey(float_0))


# Generated at 2022-06-25 03:14:35.596967
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert test_case_0()

# Generated at 2022-06-25 03:14:40.712505
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    obj_RpmKey = RpmKey('')
    param_0 = '0x983B3C22'
    param_0 = obj_RpmKey.normalize_keyid(param_0)
    assert param_0 == '983B3C22'


# Generated at 2022-06-25 03:14:50.615992
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    float_0 = 12.7
    int_0 = 0
    float_1 = 17.7
    str_0 = '%c' % float_1
    str_1 = 'f'
    str_2 = 'K'
    str_3 = 'c'
    str_4 = '%'
    str_5 = 'o'
    str_6 = 'S'
    str_7 = 'T'
    str_8 = 'w'
    str_9 = 'l'
    str_10 = '+'
    str_11 = '5'
    str_12 = 'A'
    str_13 = '8'