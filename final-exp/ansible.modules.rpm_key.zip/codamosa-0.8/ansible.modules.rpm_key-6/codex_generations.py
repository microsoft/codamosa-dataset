

# Generated at 2022-06-11 07:46:51.827900
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-11 07:47:03.655985
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(argument_spec={})
    module.fail_json = Mock(return_value=None)
    module.run_command = Mock(return_value=(0, "", ""))
    rpm_key = RpmKey(module=module)

    # Key is present in rpm db
    assert rpm_key.is_key_imported("0xE12C62B1C7")
    module.run_command.assert_any_call("rpm -q  gpg-pubkey")

    # Key is not present in rpm db
    module.run_command.reset_mock()
    module.run_command = Mock(return_value=(1, "", ""))
    assert not rpm_key.is_key_imported("0xE12C62B1C7")
    module.run_command.assert_

# Generated at 2022-06-11 07:47:14.012410
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    # test unexpected output
    try:
        rpm_key.execute_command([rpm_key.rpm])
        assert False
    except Exception as e:
        assert e.args[0] == "Unexpected gpg output"
    # test non-zero rc

# Generated at 2022-06-11 07:47:16.818281
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert(RpmKey.is_keyid(RpmKey, 'DEADBEEF') is True)



# Generated at 2022-06-11 07:47:22.552353
# Unit test for method fetch_key of class RpmKey

# Generated at 2022-06-11 07:47:33.871286
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 07:47:43.778492
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os

    # If the user provides a key that is not a keyid, we need to get the keyid
    # from the public key, -qf "%{description}" shows the keyid on the rpm
    # database.
    def getKeyId(key):
        cmd = 'rpm -q  gpg-pubkey --qf "%{description}" | gpg --no-tty --batch --with-colons --fixed-list-mode -'
        rc,  stdout, stderr = module.run_command(cmd, input=key, use_unsafe_shell=True)
        if rc != 0:
            module.fail_json(msg="Error importing key %s" % stderr)

# Generated at 2022-06-11 07:47:51.570280
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    class AnsibleModuleMock(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    class AnsibleModule(object):
        def __init__(self, section):
            self.params = section['params']

        @staticmethod
        def fail_json(msg):
            raise RuntimeError('fail_json: {}'.format(msg))

        @staticmethod
        def get_bin_path(bin, required=False):
            return bin

        @staticmethod
        def exit_json(changed):
            assert changed

        @staticmethod
        def run_command(cmd):
            return 0, '', ''


# Generated at 2022-06-11 07:48:01.533945
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = MagicMock()

    import ansible.module_utils.rpm_utils
    ansible.module_utils.rpm_utils.RpmKey = RpmKey
    rpm_key = RpmKey(AnsibleModule(argument_spec={}))

    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert not rpm_key.is_keyid('0xDEADB33')
    assert not rpm_key.is_keyid('0XDEADB33')

# Generated at 2022-06-11 07:48:06.262781
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    keyfile = os.path.dirname(__file__) + '/files/RPM-GPG-KEY.dag.txt'
    rpm_key = RpmKey(AnsibleModule(argument_spec={}))
    assert rpm_key.getfingerprint(keyfile) == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'

# Generated at 2022-06-11 07:48:32.053806
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.params = dict(
                state='present',
                key='/path/to/key.gpg',
                fingerprint=None,
                validate_certs=True,
            )
            self.check_mode = False
            self.cleanup_files = []

        def add_cleanup_file(self, filename):
            self.cleanup_files.append(filename)

        def cleanup(self, filename):
            self.cleanup_files.remove(filename)
            os.remove(filename)

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

# Generated at 2022-06-11 07:48:34.819197
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(argument_spec=dict())
    test = RpmKey(module)
    assert test.rpm == "/bin/rpm"
    assert test.gpg == "/bin/gpg2"

# Generated at 2022-06-11 07:48:43.733903
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Using mock, simulate the run_command method of AnsibleModule
    # In this case, we are checking if the method calls run_command using
    # the right parameters and returns the stdout as expected
    stdout = "".join(['pub:r:1024:17:D76EDEB1:1122334455:1367332224::r:-:::scESC:', 'uid:r::::1122334455::70E1FCCEBE3F3E1D9B8EEA03B86D7AE3B3FC4A4A::testing key::', 'uid:r::::1122334455::8CE387BEC7F0F6A267CCD58B8AB14A87F87E21E1::Testing key 2'])
    # mock_run_command will be called in the place of module.run_

# Generated at 2022-06-11 07:48:55.370149
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create temp file
    tmpfd, tmpname = tempfile.mkstemp()

    # Instance of class RpmKey
    rpmkey = RpmKey({})

    # Test fetch key

    # With error: with non-valid key
    try:
        rpmkey.fetch_key("http://www.gazzang.com/key.gpg")
    except SystemExit:
        pass
    else:
        assert "Expected exception SystemExit" is False

    # Without error: with valid key
    try:
        rpmkey.fetch_key("http://repos.gazzang.com/key.gpg")
    except SystemExit:
        assert "Expected exception SystemExit" is False

    # Test if the file stored in the variable key already exists

# Generated at 2022-06-11 07:49:04.939313
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import __builtin__
    import unittest
    import __main__
    import os.path
    import tempfile

    def test_fetch_key(url):
        return '/tmp/key'

    tmpfd, tmpname = tempfile.mkstemp()
    __main__.__dict__.update({'__builtin__': __builtin__})
    __builtin__.__dict__.update({'open': open})
    __builtin__.__dict__.update({'os': os})
    __builtin__.__dict__.update({'os.path': os.path})
    __builtin__.__dict__.update({'tempfile': tempfile})
    __builtin__.__dict__.update({'tmpfd': tmpfd})

# Generated at 2022-06-11 07:49:16.753736
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs
    module.exit_json(changed=False, msg='')

    rpm_key = RpmKey(module)

    assert 'DEADBEEF' == rpm_key.normalize_keyid('0xDeadbeef')
    assert 'DEADBEEF' == rpm_key.normalize_keyid('0xDeadbeef   ')
    assert 'DEADBEEF' == rpm_key.normalize_keyid('0xDeadbeef\n')

# Generated at 2022-06-11 07:49:21.240370
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create an RpmKey object
    class ModuleStub:
        check_mode = False
        def execute_command(self, cmd):
            return None
    rpmkey = RpmKey(ModuleStub())
    # Create a keyfile
    tmpfd, tmpname = tempfile.mkstemp()

# Generated at 2022-06-11 07:49:31.559738
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os.path

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rp = RpmKey(module)
    tmpfd, tmpname = tempfile.mkstemp()
    open(tmpname,'w').close()
    os.environ['HOME'] = os.path.dirname(tmpname)
    os.environ['GNUPGHOME'] = os

# Generated at 2022-06-11 07:49:42.114222
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import sys
    try:
        import rpm
    except ImportError:
        sys.exit(unittest.SkipTest("rpm-python is missing"))

    import os
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.rpm_key import RpmKey


    class TestRpmKeyMethods(unittest.TestCase):

        def setUp(self):
            self.rpm_key = RpmKey(
                AnsibleModule(argument_spec={})
            )

        def tearDown(self):
            self.rpm_key = None


# Generated at 2022-06-11 07:49:51.585923
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os.path
    import tempfile
    keyfile = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 07:50:32.416426
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    f = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 07:50:39.655044
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    r = RpmKey()
    assert(r.is_keyid('0x12345678'))
    assert(r.is_keyid('0x1234abc'))
    assert(r.is_keyid('12345678'))
    assert(r.is_keyid('1234abc'))
    assert(not r.is_keyid('1234'))
    assert(not r.is_keyid('fffffffff'))
    assert(not r.is_keyid('0xfffffffff'))
    assert(not r.is_keyid('0xfffffff'))

# Generated at 2022-06-11 07:50:41.692936
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rpm_key = RpmKey()
    assert rpm_key.drop_key('some key') is None

# Generated at 2022-06-11 07:50:54.490155
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # for testing
    module.run_command = lambda x, **kwargs: ("", "", 0)
    module.add_cleanup_file = lambda x: x

    if not os.path.isfile(os.path.dirname(os.path.realpath(__file__)) + "/test_RpmKey_test.gpg"):
        import filecmp
        import shutil
        print

# Generated at 2022-06-11 07:51:05.933240
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class MockModule(object):
        def fail_json(*args, **kwargs):
            raise Exception(args)

    class MockCommand(object):
        def __init__(self, stdout, stderr):
            self.stdout = stdout
            self.stderr = stderr

        def communicate(self):
            return (self.stdout, self.stderr)

    def mock_run_command(cmd, **kwargs):
        return MockCommand(keyid_stdout, '')


# Generated at 2022-06-11 07:51:07.218970
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    print("Testing importing a key")

    RpmKey_instance = RpmKey(None)

# Generated at 2022-06-11 07:51:18.929186
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class fake_module:
        def __init__(self):
            self.params = dict(key='0xDEADB33F')
            self.exit_json = lambda changes, changed: changes or changed

    class fake_execute_command:
        def __init__(self):
            self.count = 0

# Generated at 2022-06-11 07:51:29.196089
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import platform
    from ansible.modules.packaging.package.rpm_key import RpmKey
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import io

    # create dummy module for testing
    module = AnsibleModule(argument_spec={
        'key': {'type': 'str', 'required': True, 'no_log': False},
        'state': {'type': 'str', 'default': 'present', 'choices': ['absent', 'present']},
        'fingerprint': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True},
    })

    rpm_key = RpmKey(module)


# Generated at 2022-06-11 07:51:35.009217
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    #Arrange
    '''
    this test sets up a fake module and defines the class variables
    that would be used in the function
    '''

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = exit
            self.add_cleanup_file = None
            self.exit_json = exit
            self.check_mode = False
            self.url_username = None
            self.url_password = None
            self.warnings = None
            self.stderr = None
            self.stdout = None
            self.run_command = None
            self.get_bin_path = None

    module = FakeModule()

    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native

# Generated at 2022-06-11 07:51:42.035622
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec={
            'state': dict(type='str', default='present', choices=['absent', 'present']),
            'key': dict(type='str', required=True),
            'fingerprint': dict(type='str'),
            'validate_certs': dict(type='bool', default=True),
        },
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key(keyid='')


# Generated at 2022-06-11 07:52:56.711494
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-11 07:53:08.655734
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create a mock module and set up a temp dir to write keys to
    module = Mock()
    module.mkdtemp_return = "tmp"
    module.mkdtemp.return_value = module.mkdtemp_return
    # Create a MockResponse with a status code of 200 and the signature key from
    # the Fedora project
    resp = Mock()
    resp.status = 200

# Generated at 2022-06-11 07:53:19.958043
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Class object instantiation
    rpm_key = RpmKey(None)

    # Test with uppercase keyid
    test_keyid = 'DEADBEEF'
    assert rpm_key.normalize_keyid(test_keyid) == test_keyid

    # Test with lowercase keyid
    test_keyid = 'deadbeef'
    assert rpm_key.normalize_keyid(test_keyid) == test_keyid.upper()

    # Test with uppercase keyid prefixed with 0x
    test_keyid = '0xDEADBEEF'
    assert rpm_key.normalize_keyid(test_keyid) == test_keyid[2:].upper()

    # Test with lowercase keyid prefixed with 0x

# Generated at 2022-06-11 07:53:26.492460
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-11 07:53:31.216122
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    keystr = "0x4e2c6e8793298290"
    r = RpmKey(keystr)
    assert r.is_keyid(keystr)
    keystr2 = "1e2c6e8793298290"
    assert not r.is_keyid(keystr2)


# Generated at 2022-06-11 07:53:41.134921
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    from ansible.module_utils.rpm_key import RpmKey
    from ansible.module_utils.common.collections import ImmutableDict
    import mock
    import pytest


# Generated at 2022-06-11 07:53:52.748462
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """
    _getkeyid(self, keyfile):
        """
    # Arrange
    import os
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    os.chdir(os.path.dirname(__file__))
    # Act
    keyid = rpm_key.getkeyid("rpm-gpg-key-dag.txt")
    # Assert

# Generated at 2022-06-11 07:53:58.099172
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)

# Generated at 2022-06-11 07:54:04.148077
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.actions.rpm_key import RpmKey
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 07:54:11.190141
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Setup the mocks
    with mock.patch.object(tempfile, 'mkstemp', return_value=(1, 'test_key')) as patched_mkstemp, \
            mock.patch.object(RpmKey, 'execute_command', return_value=(0, '', '')) as patched_exec_cmd, \
            mock.patch.object(os, 'fdopen', return_value=mock.MagicMock()) as patched_fdopen, \
            mock.patch.dict(os.environ, {'PATH': '/bin'}):
        mock_module = mock.Mock()
        mock_module.params = {'state': 'present', 'key': 'DEADB33F', 'fingerprint': ''}
        mock_module.check_mode = True

        # Get the class to test