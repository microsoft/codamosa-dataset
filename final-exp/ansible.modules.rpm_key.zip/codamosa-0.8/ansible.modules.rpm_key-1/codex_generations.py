

# Generated at 2022-06-11 07:46:46.163486
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(argument_spec=dict())
    RpmKey(module)

# Generated at 2022-06-11 07:46:53.357175
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # If the method under test executes a command which
    # is not installed on the test system we must skip the test
    if not os.path.exists('/usr/bin/false'):
        pytest.skip('Command /usr/bin/false does not exist')

    # Test with a command that returns 1
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    rpm_key = RpmKey(module)
    with pytest.raises(AnsibleFailJson) as exec_info:
        rpm_key.execute_command(['/usr/bin/false'])
    assert 'Unexpected gpg output' == str(exec_info.value)



# Generated at 2022-06-11 07:46:56.288820
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    assert RpmKey.getfingerprint() == "EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6"

# Generated at 2022-06-11 07:47:08.193396
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    test_file = '/tmp/key.gpg'
    # Create file that will be imported in the test
    with open(test_file, 'w') as f:
        f.write("testing 1 2 3")

    with open(test_file, 'r') as f:
        keyfile = f.read()

    # Mock module and RpmKey, so we can test the method without running the code
    from unittest.mock import patch
    module = patch('ansible.module_utils.basic.AnsibleModule').start()
    module.check_mode = False
    rpm_key = patch('ansible.modules.packaging.os.rpm_key.RpmKey').start()

    # Execute method to test
    rpm_key.import_key(keyfile)

    # Verify that the execute_command method was called,

# Generated at 2022-06-11 07:47:16.081299
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class Module(object):
        pass
    module = Module()
    module.get_bin_path = Mock(return_value = '/usr/bin/rpm')
    module.execute_command = Mock(return_value = (0, 'stdout', 'stderr'))
    module.params = {
            "key":"F17B4769",
            "fingerprint": "F17B4769",
            "state": "present",
        }
    RpmKey(module)
    assert "/usr/bin/rpm -q  gpg-pubkey --qf \"%{description}\" |" in module.execute_command.call_args_list[0][0][0]


# Generated at 2022-06-11 07:47:27.587572
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import fudge

    # (1,2) should pass
    module = fudge.Fake()
    module.run_command = lambda *args: (0, "pgp-pubkey-deadbeef-deadbeef\npgp-pubkey-deadbeef-deadbeef-deadbeef", "")
    module.check_mode = True
    rpmkey = RpmKey(module)
    assert rpmkey.is_key_imported('DEADBEEF')
    assert rpmkey.is_key_imported('0xdeadbeef')
    assert rpmkey.is_key_imported('0XDEADBEEF')

    # (3) should fail
    module = fudge.Fake()

# Generated at 2022-06-11 07:47:37.803219
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-11 07:47:44.198396
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Dummy variables to be set based on the test type
    state = 'absent'
    key = 'key-to-test'
    module = namedtuple('_test_RpmKey_drop_key', ['check_mode', 'fail_json', 'get_bin_path', 'run_command'])

    # Create an instance of RpmKey and call the drop_key method
    _tmp = RpmKey(module)
    _tmp.drop_key(key)

# Generated at 2022-06-11 07:47:47.280460
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Create a instance of class RpmKey
    rpm_key = RpmKey(None)

    # Set keyfile to a valid public key
    keyfile = '/path/to/key.gpg'

    # Given a keyfile generate a keyid
    keyid = rpm_key.getkeyid(keyfile)

    # force a failure, with a invalid keyfile
    try:
        rpm_key.getkeyid('/path/to/invalid.gpg')
    except Exception as e:
        pass
    else:
        # Should raise a exception because the keyfile is invalid
        assert False



# Generated at 2022-06-11 07:47:52.002320
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile
    import os
    class TestModule:
        def __init__(self):
            self.params = {}
            self.changed = False
        def get_bin_path(self, command, required=False):
            if command == 'gpg2':
                return '/usr/bin/gpg2'
        def add_cleanup_file(self, fname):
            return
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "", ""
        def fail_json(self, msg):
            raise Exception(msg)
        def exit_json(self, changed):
            return
        def cleanup(self, keyfile):
            if os.path.isfile(keyfile):
                os.unlink(keyfile)


# Generated at 2022-06-11 07:48:17.553792
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import sys
    import yaml
    from tempfile import NamedTemporaryFile

    class FakeModule:
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda err: print(err, file=sys.stderr)
            self.run_command = lambda cmd, shell=False: ('', '', 0)
            self.check_mode = False
            self.cleanup_files = []
            self.add_cleanup_file = lambda path: self.cleanup_files.append(path)
            self.cleanup = lambda path: None

        def get_bin_path(self, binary, required=False):
            if binary == 'gpg2':
                return '/usr/bin/gpg2'
            elif binary == 'rpm':
                return '/usr/bin/rpm'

# Generated at 2022-06-11 07:48:29.406569
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import sys

    # Mock the stdout
    stdout = sys.stdout
    sys.stdout = StringIO()

    # Call the constructor of the class
    import ansible.modules.extras.packaging.os.rpm_key as rpm_key
    args = dict(
        name='/etc/redhat-release',
        key='http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    )
    rpm_key.RpmKey(AnsibleModule(**args))

    # Test the stdout
    output = sys.stdout.getvalue().strip()

# Generated at 2022-06-11 07:48:41.849718
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    url = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        validate_certs=dict(type='bool', default=True),
    ))

    rpm_key = RpmKey(module)
    keyfile = rpm_key.fetch_key(url)
    with open(keyfile, 'r') as f:
        key_content = f.read()

    assert key_content.startswith('-----BEGIN PGP PUBLIC KEY BLOCK-----')
    assert key_content.endswith('-----END PGP PUBLIC KEY BLOCK-----')


# Generated at 2022-06-11 07:48:53.466301
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # setup test
    keyfile = tempfile.mkstemp()[1]
    module = AnsibleModule(argument_spec={'key': {"type": "str", "required": True}, 'state': {'type': 'str', 'required': True}})
    module.params['key'] = keyfile
    module.params['state'] = 'present'

    # create test keyfile

# Generated at 2022-06-11 07:49:01.024918
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    """RpmKey - Test getfingerprint method"""

    test_file_path = os.path.join(os.path.dirname(__file__), 'data', 'test_gpg_key')
    expected_fingerprint = 'EBC6E12C62B1C73411B2122A20E52146B8D79E6'
    rpm_key = RpmKey(None)
    fingerprint = rpm_key.getfingerprint(test_file_path)

    assert fingerprint == expected_fingerprint, 'Fingerprint does not match'

# Generated at 2022-06-11 07:49:12.010267
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rkey = RpmKey('')
    assert rkey.is_keyid('0xabebeb')
    assert rkey.is_keyid('0xAbebeb')
    assert rkey.is_keyid('0xabebeB')
    assert rkey.is_keyid('0xABEBEB')
    assert rkey.is_keyid('abebeb')
    assert rkey.is_keyid('Abebeb')
    assert rkey.is_keyid('abebeB')
    assert rkey.is_keyid('ABEBEB')

    assert not rkey.is_keyid('0xabebebe')
    assert not rkey.is_keyid('0xAbebebe')
    assert not rkey.is_keyid('0xabebeBe')
   

# Generated at 2022-06-11 07:49:19.551353
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rk = RpmKey(AnsibleModule(argument_spec={}))
    assert rk.is_keyid('BB7576AC')
    assert rk.is_keyid('0xBB7576AC')
    assert rk.is_keyid('0XBB7576AC')
    assert not rk.is_keyid('BB757')
    assert not rk.is_keyid('0xBB757')
    assert not rk.is_keyid('0XBB757')


# Generated at 2022-06-11 07:49:23.509037
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    rpm_key = RpmKey('gpg-pubkey-deadb33f-55498b7b')
    keyid = "DEADB33F"
    assert rpm_key.is_key_imported(keyid)

# Generated at 2022-06-11 07:49:32.968047
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    mock = MagicMock()
    def run_command(cmd, use_unsafe_shell=True):
        return 0, 'pub:u:1024:17:A20E52146B8D79E6:1325263370:::u:::scESC:', ''
    mock.run_command = run_command
    mock.get_bin_path.return_value = ''
    import tempfile, os
    tmpfd, tmpname = tempfile.mkstemp()
    os.write(tmpfd, b'unused')
    os.close(tmpfd)
    key_obj = RpmKey(mock)
    assert key_obj.getkeyid(tmpname) == 'A20E52146B8D79E6'
    os.unlink(tmpname)


# Generated at 2022-06-11 07:49:43.212795
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Arrange
    import base64
    module = MockAnsibleModule()
    module.params['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    # a valid key file
    module.params['fingerprint'] = base64.b64encode(b'fingerprint')
    # We need to patch the fetch_url module to make it return a successful response
    import ansible.module_utils.urls
    ansible.module_utils.urls.fetch_url = MockFetchUrl
    rpm_key = RpmKey(module)
    # Act
    path = rpm_key.fetch_key(module.params['key'])
    # Assert
    assert is_pubkey(path)


# Generated at 2022-06-11 07:50:22.381400
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Test setup
    import mock
    import ansible.module_utils.six.moves.urllib.error as urllib_error
    open_mock = mock.mock_open()
    os_path_isfile = mock.mock_open()
    with mock.patch('ansible.module_utils.urls.fetch_url', return_value=(open_mock, b'response')):
        with mock.patch('ansible.module_utils.six.moves.urllib.request.urlopen', side_effect=urllib_error.URLError('error')):
            with mock.patch('os.path.isfile', return_value=os_path_isfile):

                # Test execution
                from ansible.modules.system.rpm_key import RpmKey

# Generated at 2022-06-11 07:50:30.393799
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    from ansible.modules.packaging.os import rpm_key
    s = rpm_key.RpmKey()
    assert s.normalize_keyid("   0x1856F3EE") == "1856F3EE"
    assert s.normalize_keyid("1856F3EE") == "1856F3EE"
    assert s.normalize_keyid("1856F3EE ") == "1856F3EE"


# Generated at 2022-06-11 07:50:35.984870
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    obj = RpmKey(None)
    assert obj.normalize_keyid("0x1234") == "1234"
    assert obj.normalize_keyid("1234") == "1234"
    assert obj.normalize_keyid(" 0x1234 ") == "1234"
    assert obj.normalize_keyid(" 0X1234 ") == "1234"

# Generated at 2022-06-11 07:50:47.293283
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Mocked object to test with external dependencies
    class MockModule(object):
        def __init__(self):
            self.params = dict(
                fingerprint = 'fingerprint',
                keyid = 'D2E2B372',
                valid_keyfile = '/path/to/valid.gpg'
            )
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''

        def fail_json(self, msg):
            raise Exception(msg)


# Generated at 2022-06-11 07:50:58.956232
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = MockAnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Should call self.execute_command with [self.rpm, '--erase', '--allmatches', 'gpg-pubkey-%s' % keyid[-8:].lower()]
    rpmkey = RpmKey(module)
    rpmkey.drop_key('0x12345678')



# Generated at 2022-06-11 07:51:09.059776
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    """ Test for normalize_keyid """
    # Creating a class instance
    rp = RpmKey(None)
    # Testing without leading '0x'
    assert rp.normalize_keyid('64D69058') == '64D69058'
    # Testing with leading '0x'
    assert rp.normalize_keyid('0x6CBFBF50') == '6CBFBF50'
    # Testing with leading '0X'
    assert rp.normalize_keyid('0X6CBFBF50') == '6CBFBF50'
    # Testing with leading and trailing whitespace
    assert rp.normalize_keyid(' 64D69058 ') == '64D69058'
    # Testing with lower case

# Generated at 2022-06-11 07:51:19.579619
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import os
    from ansible.module_utils.basic import AnsibleModule

    def test_getkeyid(keyfile, expected_keyid):
        test_instance = RpmKey(AnsibleModule(
            argument_spec=dict()
        ))
        assert test_instance.getkeyid(keyfile) == expected_keyid

    # this keyid is intentionally touched to have lower case letters
    keyid = os.getenv('test_keyid', 'deadb33f')
    keyfile = os.getenv('test_keyfile', None)
    if keyfile is None:
        raise RuntimeError('Missing test_keyfile environment variable')

    test_getkeyid(keyfile, keyid)


# Generated at 2022-06-11 07:51:27.731945
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    normalize_keyid = RpmKey.normalize_keyid
    assert normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert normalize_keyid('DEADB33F') == 'DEADB33F'
    assert normalize_keyid('\nDEADB33F ') == 'DEADB33F'
    assert normalize_keyid('0x DEADB33F') == 'DEADB33F'


# Generated at 2022-06-11 07:51:34.268482
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import unittest

    from ansible.modules.security.gpgkey import RpmKey
    from ansible.modules.security.gpgkey import getkeyid
    from ansible.modules.security.gpgkey import normalize_keyid
    from ansible.modules.security.gpgkey import is_key_imported
    from ansible.modules.security.gpgkey import import_key
    from ansible.modules.security.gpgkey import drop_key
    from ansible.modules.security.gpgkey import fetch_key

    import types

    class MockModule(object):
        def jsonify(self, result):
            return result

        class CheckModeFailException(Exception):
            pass


# Generated at 2022-06-11 07:51:44.295763
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_RpmKey = RpmKey(module)
    # First test if rpm is installed in the system
    rpm = module.get_bin_path('rpm', True)
    if rpm == None:
        msg = "Error: rpm is not installed"
        module.fail_json(msg=msg)
    else:
        test_RpmKey.import_key(rpm)



# Generated at 2022-06-11 07:53:01.744636
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test = RpmKey(module)
    assert test.drop_key("DEADB33F") == None

# Generated at 2022-06-11 07:53:11.099018
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """
    Test if the method: getkeyid works as it should.
    """
    class FakeModule:
        def __init__(self):
            self.run_command = test_RpmKey_getkeyid.run_command
            self.fail_json = test_RpmKey_getkeyid.fail_json

    class FakeAnsibleModule:
        def __init__(self, module):
            self.params = {'fingerprint': None}
            self.check_mode = False
            self.module = module

    def run_command(cmd, use_unsafe_shell=True):
        import subprocess
        p = subprocess.Popen(cmd, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate

# Generated at 2022-06-11 07:53:21.350657
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    def new_module(**kwargs):
        """ Returns a mock module

        Will create or update the `params` attribute to whatever kwargs are
        supplied, and will create a unique id attribute.
        """
        module = MagicMock()
        module.params = {}
        module.unique_id = str(uuid.uuid4())
        module.check_mode = kwargs.pop('check_mode', False)
        module.params.update(kwargs)
        module.register_cleanup_file = MagicMock()
        return module

    def execute_command_mock(cmd):
        if cmd == ['/bin/rpm', '--erase', '--allmatches', 'gpg-pubkey-adadadad']:
            return 0, "stdout", "stderr"

# Generated at 2022-06-11 07:53:31.731746
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid(RpmKey, '0xAFACAFACAFACAFAC') == 'AFACAFACAFACAFAC'
    assert RpmKey.normalize_keyid(RpmKey, '0XAFACAFACAFACAFAC') == 'AFACAFACAFACAFAC'
    assert RpmKey.normalize_keyid(RpmKey, 'AFACAFACAFACAFAC') == 'AFACAFACAFACAFAC'
    assert RpmKey.normalize_keyid(RpmKey, '0xAfAcAfAcAfAcAfAc') == 'AFACAFACAFACAFAC'
    assert RpmKey.normalize_keyid(RpmKey, '0xAfAcAfAcAfAcAfAc ') == 'AFACAFACAFACAFAC'


# Generated at 2022-06-11 07:53:42.513892
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Exit with success if the regular expression used to identify keyids, matches keyids and doesn't match other strings.
    # This test is only meant to fail if the regular expression was updated to fix a bug, or it was modified to meet
    # a new requirement
    #
    # TODO: This is a very poor unit test, it should be replaced with something better, if possible

    rpm_key = RpmKey(None) # This test doesn't need a real module object

    # Test against different patterns of keyids
    assert rpm_key.is_keyid('0xfd413e95')
    assert rpm_key.is_keyid('fd413e95')
    assert rpm_key.is_keyid('0xFD413E95')  # Keyid can be uppercase too
    assert rpm_key.is_keyid('FD413E95')

# Generated at 2022-06-11 07:53:51.354192
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class AnsibleModule(object):
        class RunCommand(object):
            def __call__(self, *args, **kwargs):
                return 0, "pub:u:1024:17:F5F96C9E6D9881A8:1387057660:::u:::scESC:", ""

        def __init__(self):
            self.run_command = self.RunCommand()

    module = AnsibleModule()
    RpmKey = RpmKey(module)
    assert RpmKey.getkeyid("some_path/some_file.gpg") == "F5F96C9E6D9881A8"

# Generated at 2022-06-11 07:53:59.873544
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import ansible.module_utils.six
    module = ansible.module_utils.six.moves.mock.Mock()
    RpmKey = ansible.module_utils.rpm_key.RpmKey(module)

    import ansible.module_utils.urls
    ansible.module_utils.urls.fetch_url.return_value = (
        ansible.module_utils.six.moves.mock.Mock(),
        {
            'status': 200,
        }
    )

    import tempfile
    tempfile.mkstemp.return_value = (os.fdopen(os.open('/tmp/i', os.O_CREAT | os.O_RDWR), 'w+b'), '/tmp/i')


# Generated at 2022-06-11 07:54:05.976824
# Unit test for constructor of class RpmKey
def test_RpmKey():
    my_module = MockModule()
    my_module.params = {
        'state': 'present',
        'key': '/path/to/key.gpg',
        'fingerprint': 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6',
    }

    RpmKey(my_module)
    assert my_module.run_command.called, True
    assert my_module.run_command.call_count == 4, True

# Generated at 2022-06-11 07:54:10.503797
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Test instantiation
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(test_module)


# Generated at 2022-06-11 07:54:19.151551
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # Test argument passing to execute_command
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rp = RpmKey(module)
    # Should we execute this command?
    #cmd = ['false', '--fail']
    cmd = ['true', '--success']
    rc, out, err = rp.module.run_command(cmd)
    assert rc == 0