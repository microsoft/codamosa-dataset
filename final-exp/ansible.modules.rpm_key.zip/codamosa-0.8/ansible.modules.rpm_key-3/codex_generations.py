

# Generated at 2022-06-11 07:46:53.495969
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a RpmKey class
    rpm_key = RpmKey(module)
    from os.path import join, dirname, realpath
    keypath = join(dirname(realpath(__file__)), 'test_key')
    # Get expected fingerprint
    # The expected_fingerprint is the fingerprint of the key which is located in test/test_key.
    expected_fingerprint = 'FFB7 E944 5C48 AF81 7646  5F1B D0C0 126C 0E4F 9B9C'
    # Call the function with the keypath as the parameter.
    # This function returns the fingerprint of the key.
    actual_fingerprint = rpm_key.getfingerprint(keypath)
    # Assert that the expected fingerprint and the actual fingerprint are equal.
    assert expected_fingerprint == actual_fingerprint

# Generated at 2022-06-11 07:46:58.931991
# Unit test for constructor of class RpmKey
def test_RpmKey():
    try:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.ansible_release import __version__ as ansible_version
        assert ansible_version >= "2.5"
    except ImportError:
        return
    m = RpmKey(AnsibleModule())
    assert m != None

# Generated at 2022-06-11 07:47:06.601330
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = ansible_module_create()
    module.params['state'] = 'present'
    module.params['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'

    rpm_key = RpmKey(module)

    assert rpm_key.is_key_imported('0x0E8B6440') == True
    assert rpm_key.is_key_imported('0x0E8B6441') == False


# Generated at 2022-06-11 07:47:15.897617
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os

    # Create a test keyfile
    fd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(fd, 'w')

# Generated at 2022-06-11 07:47:24.768196
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    def execute_command(cmd):
        if cmd == ['/bin/rpm', '--erase', '--allmatches', 'gpg-pubkey-deadb33f']:
            return 0, "", ""
        else:
            raise Exception("Unexpected command: %s" % cmd)

    module = DummyAnsibleModule()
    RpmKey.RpmKey(module)
    key = RpmKey.RpmKey(module)
    key.rpm = '/bin/rpm'
    key.execute_command = execute_command
    key.drop_key('DEADB33F')



# Generated at 2022-06-11 07:47:35.678271
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Create RpmKey object for testing
    rpm_key = RpmKey(module)
    # Normalize keyid
    assert rpm_key.normalize_keyid('0xEA2A5F5D5BB5DB35') == 'EA2A5F5D5BB5DB35'

# Generated at 2022-06-11 07:47:39.059712
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """
    # Method: getkeyid
    # Description: Obtains the keyid from a given gpg key
    # Return: keyid
    """
    keyid = RpmKey.getkeyid(self, keyfile)
    assert keyid == 'DEADB33F'

# Generated at 2022-06-11 07:47:41.767334
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_key = RpmKey(None)
    keyid = "deadbeef"
    assert(rpm_key.is_keyid(keyid))


# Generated at 2022-06-11 07:47:50.437629
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    _RpmKey_drop_key_fixture_1 = {
        'check_mode': True,
        'keyid': 'ABCDEabc',
    }
    _RpmKey_drop_key_fixture_2 = {
        'check_mode': False,
        'keyid': 'ABCDEabc',
    }

    _RpmKey_drop_key_expected_1 = (
        b">rpm --erase --allmatches gpg-pubkey-abcdebc\n"
        b"[DRY-RUN] will run: rpm --erase --allmatches gpg-pubkey-abcdebc"
    )

# Generated at 2022-06-11 07:48:00.642195
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    assert is_pubkey(b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n -----END PGP PUBLIC KEY BLOCK-----\n') is True
    assert is_pubkey(b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n -----END PGP PUBLIC KEY BLOCK-----') is True
    assert is_pubkey(b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n') is False
    assert is_pubkey(b'-----BEGIN PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey(b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n -----END PGP PUBLIC KEY BLOCK-----\n') is True
    assert is_pubkey(b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n -----END PGP PUBLIC KEY BLOCK-----\n\n') is True

# Generated at 2022-06-11 07:48:20.749537
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    pass

# Generated at 2022-06-11 07:48:28.928733
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True)
    ))
    key = RpmKey(module)
    stdout, stderr = key.execute_command(['echo', 'hello world'])
    assert stdout == 'hello world\n'
    assert stderr == ''



# Generated at 2022-06-11 07:48:37.743857
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    """
    Tests the getfingerprint method of RpmKey.
    """
    # Create a RpmKey object, using a fake module
    rpmkey = RpmKey(AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    ))

    # A fake keyfile path, which doesn't really exist
    keyfile = '/path/to/key.gpg'

    # Create a mocked object of the gpg binary
    rpmkey.gpg = mock.Mock()

    # When

# Generated at 2022-06-11 07:48:43.810141
# Unit test for constructor of class RpmKey
def test_RpmKey():
  # create an instance of AnsibleModule
  module = AnsibleModule(
      argument_spec=dict(
          state=dict(type='str', default='present', choices=['absent', 'present']),
          key=dict(type='str', required=True, no_log=False),
          fingerprint=dict(type='str'),
          validate_certs=dict(type='bool', default=True),
      ),
      supports_check_mode=True,
  )
  RpmKey(module)

# Generated at 2022-06-11 07:48:55.368520
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Construct an ansible module object
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create an instance of class RpmKey
    rpmKey = RpmKey(module)

    # Test the execution of is_keyid
    assert rpmKey.is_keyid('1234abcd')
    assert rpmKey.is_keyid('0x1234abcd')
    assert not rpmKey.is_keyid('0x1234abcd ')


# Generated at 2022-06-11 07:49:01.878245
# Unit test for constructor of class RpmKey
def test_RpmKey():
  module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


  RpmKey(module)

# Generated at 2022-06-11 07:49:13.089814
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.exit_json = mock.Mock()
    module.fail_json = mock.Mock()
    module.run_command = mock.Mock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path = mock.Mock()
    module.get_bin_path.return_value = '/bin/rpm'
    module.add

# Generated at 2022-06-11 07:49:24.736202
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Test case 1
    temp_keyfile = tempfile.NamedTemporaryFile()
    keyfile = temp_keyfile.name
    temp_keyfile.close()

# Generated at 2022-06-11 07:49:33.188879
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_keyid = RpmKey(None)

    assert 'CA19E8B44568B0B0' == test_keyid.normalize_keyid('0xCA19E8B44568B0B0')
    assert 'CA19E8B44568B0B0' == test_keyid.normalize_keyid('0XCA19E8B44568B0B0')
    assert 'CA19E8B44568B0B0' == test_keyid.normalize_keyid('ca19e8b44568b0b0')
    assert 'CA19E8B44568B0B0' == test_keyid.normalize_keyid('  0xCA19E8B44568B0B0  ')

# Generated at 2022-06-11 07:49:37.752253
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    o = RpmKey(None)
    assert o.is_keyid('DEADB33F')
    assert not o.is_keyid('DEADB33FA')
    assert not o.is_keyid('DEADB33F ')
    assert not o.is_keyid('DEADB33F ')

# Generated at 2022-06-11 07:50:07.126531
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import os
    import tempfile

    # Initialize the Ansible module
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, 'w+b')
    tmp

# Generated at 2022-06-11 07:50:13.073159
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Instantiate a fake RpmKey object
    rpmMod = False
    rpmKey = RpmKey(rpmMod)

    # Test normalize_keyid
    test_keyid = " 720A8D45   \n"
    expected_keyid = "720A8D45"
    test_return = rpmKey.normalize_keyid(test_keyid)
    assert test_return == expected_keyid


# Generated at 2022-06-11 07:50:15.347039
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    r = RpmKey(None)
    r.rpm = "rpm"

    r.drop_key("0x5da5e527")


# Generated at 2022-06-11 07:50:21.950968
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    r = RpmKey(module)
    assert r.is_keyid('0x3ac3134f')
    assert r.is_keyid('3ac3134f')
    assert r.is_keyid('0x3AC3134F')
    assert r.is_keyid('3AC3134F')
    assert not r.is_keyid('3AC3134F0')


# Generated at 2022-06-11 07:50:33.016971
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
# The key we are importing has the following fingerprint
#
# pub   rsa4096 2018-09-07 [SC]
#       DBEB E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6
# uid           [ unknown] RPM Signing Key (RPM Signing Key) <rpm@altlinux.org>
# sub   rsa4096 2018-09-07 [E]
#
    fixture = RpmKey(None)
    fixture.getfingerprint('test/files/RPM-GPG-KEY-PVS-5.1') == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'

# Generated at 2022-06-11 07:50:41.518932
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.rpm_key import RpmKey

    with open('test/data/test_RpmKey.key', 'rb') as f:
        key = f.read()

    with open('test/data/test_RpmKey.good.fingerprint', 'r') as f:
        fingerprint = f.read().strip().replace(' ', '').upper()

    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")
    tmpfile.write(key)
    tmpfile.close()


# Generated at 2022-06-11 07:50:54.268373
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import *
    from ansible.module_utils._text import to_native
    from ansible.module_utils.action import AnsibleAction
    from ansible.module_utils.six import iteritems
    from ansible_collections.ansible.builtin.plugins.modules.rpm_key import RpmKey
    
    # Creation of the fake module

# Generated at 2022-06-11 07:51:05.773909
# Unit test for constructor of class RpmKey
def test_RpmKey():
    key = RpmKey(AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    ))


# Generated at 2022-06-11 07:51:17.123409
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    class MockModule(object):

        def __init__(self):
            self.run_command = self._run_command
            self.fail_json = self._fail_json
            self.check_mode = False
            self.params = dict()
            self.tmpdir = tempfile.mkdtemp()

        def _run_command(self, c):
            '''
            We expect:
            ['rpm', '--import', 'keyfile']
            ['rpm', '--erase', '--allmatches', 'gpg-pubkey-1234abcd']
            '''

            if self.check_mode:
                return 0, '', ''


# Generated at 2022-06-11 07:51:27.804790
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile, os

# Generated at 2022-06-11 07:52:24.893564
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # (failure, expected)
    test_data = [
        ('', None),
        ('gpg: keyring /root/.gnupg/pubring.gpg', None)
    ]

    for failure, expected in test_data:
        rk = RpmKey(None)
        rc, stdout, stderr = rk.execute_command(['gpg', '--no-tty', '--batch', '-k'])

        if failure in stderr:
            assert expected == expected



# Generated at 2022-06-11 07:52:35.569117
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils import basic
    import os
    import tempfile

    # Prepare the argument spec for the ansible.module_utils.basic.AnsibleModule
    module_args = dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    rp = RpmKey(module)

    # Get

# Generated at 2022-06-11 07:52:36.362586
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert RpmKey

# Generated at 2022-06-11 07:52:42.557413
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import sys
    import types
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    class RpmKey(object):
        def execute_command(self, cmd):
            return '', ''
    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.RpmKey = RpmKey()

# Generated at 2022-06-11 07:52:53.318836
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # setup
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.check_mode = True
    rpm_key = RpmKey(module)

    # Run method test
    rpm_key.drop_key('0x01234567')

# Generated at 2022-06-11 07:52:54.967097
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    assert RpmKey.is_key_imported('1234', 'deadbeef') == False

# Generated at 2022-06-11 07:53:07.044970
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    testModule = mock.MagicMock()
    testModule.check_mode = False

    # Test a successful call
    myRpmKey = RpmKey(testModule)
    myRpmKey.execute_command = mock.MagicMock(return_value=(None, None, None))
    myRpmKey.import_key('/tmp/test-id')
    myRpmKey.execute_command.assert_called_with(['rpm', '--import', '/tmp/test-id'])

    # Test a successful check mode call
    myRpmKey = RpmKey(testModule)
    myRpmKey.execute_command = mock.MagicMock()
    testModule.check_mode = True
    myRpmKey.import_key('/tmp/test-id')

# Generated at 2022-06-11 07:53:19.510575
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class MockModule(object):
        def __init__(self):
            self.params = {
                "key": "http://example.com/key.gpg"
            }
            self.cleanup_files = []

        def add_cleanup_file(self, path):
            self.cleanup_files.append(path)

        def run_command(self, cmd, use_unsafe_shell=True):
            self.lastcmd = cmd
            return (0, "", "")

        def exit_json(self, changed=True, msg="", **kwargs):
            self.exit_msg = msg
            self.exit_args = kwargs
            raise StopIteration

        def fail_json(self, msg="", **kwargs):
            self.fail_msg = msg
            self.fail_args = kw

# Generated at 2022-06-11 07:53:26.281950
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_native
    from ansible_collections.ansible.builtin.plugins.modules.rpm_key import RpmKey

    # Mocks
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda cmd, **kw: (0,'','')
    module.get_bin_path = lambda name, required: 'rpm'
    module.fail_json = lambda **kw: False
    instance = RpmKey(module)
    instance.execute_command = lambda cmd: ('','')

    class TestCase(object):
        def __init__(self, expected, stdout):
            self.expected = expected
            self.stdout

# Generated at 2022-06-11 07:53:32.121230
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-11 07:55:07.497923
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    path = os.path.realpath(os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '..', '..', 'files', 'lib_utils_validate_certs', 'ansible_test_key.pub'
    ))

    assert rpm_key.getfingerprint(path)

# Generated at 2022-06-11 07:55:15.259293
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # instantiate the mock module and the class being tested
    rpmmodule = mock.MagicMock()
    rpmkey = RpmKey(rpmmodule)

    # return value of get_bin_path is None
    rpmmodule.get_bin_path.return_value = None

    with pytest.raises(SystemExit):
        # class.method under test
        rpmkey.is_keyid('0x22222222')

    # return value of get_bin_path is ''
    rpmmodule.get_bin_path.return_value = ''

    # class.method under test
    assert rpmkey.is_keyid('0x22222222') == True


# Generated at 2022-06-11 07:55:18.645330
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    keyfile = tempfile.NamedTemporaryFile()
    keyfile.write(GPG_KEY)
    keyfile.flush()
    keyid = RpmKey.getkeyid(None, keyfile.name)
    assert keyid == 'CA684223'
    keyfile.close()


# Generated at 2022-06-11 07:55:22.506807
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Arrange
    module = AnsibleModule({
        'state': 'present',
        'key': 'DEADB33F'
    })
    rpmkey = RpmKey(module)

    # Act
    rpmkey.drop_key('DEADB33F')

    # Assert

# Generated at 2022-06-11 07:55:24.489159
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = MockModule()
    r = RpmKey(module)
    assert r.import_key('foo.txt') == 1


# Generated at 2022-06-11 07:55:33.084752
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    rpm_key = RpmKey(module)
    keyid = rpm_key.normalize_keyid('0x6B8D79E6')
    assert keyid == '6B8D79E6'
    keyid = rpm_key.normalize_keyid('0X6B8D79E6')
    assert keyid == '6B8D79E6'
    keyid = rpm_key.normalize_keyid(' 6B8D79E6')
    assert keyid == '6B8D79E6'
    keyid = rpm_key.normalize_keyid('6B8D79E6 ')
    assert keyid == '6B8D79E6'


# Generated at 2022-06-11 07:55:41.518742
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    test_key = "--some-key--"
    test_url = "some-url"
    test_key_url = test_url + "/" + test_key

    fetch_url_fixture = MagicMock()
    fetch_url_fixture.return_value = (test_key, {'status': 200})

    rpmmodule = MagicMock()
    rpmmodule.check_mode = False
    rpmmodule.add_cleanup_file = MagicMock()

    rpmmodule.get_bin_path = MagicMock(return_value=True)
    rpmmodule.run_command = MagicMock(return_value=(0,test_key,test_key))
    rpmmodule.fail_json = MagicMock()
    rpmmodule

# Generated at 2022-06-11 07:55:49.937821
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    key_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'files', 'RPM-GPG-KEY.dag.txt'))
    with open(key_path, 'r') as key_fh:
        key = key_fh.read()

    class MockedModule:
        def __init__(self):
            self.params = {
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
            }
            self.fail_json_was_called = False
            self.add_cleanup_file_was_called = False

        def fail_json(self, *args, **kwargs):
            self.fail_json_was_called = True



# Generated at 2022-06-11 07:55:53.347903
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class AnsibleModuleTest:
        def run_command(self, cmd):
            return 0, open('tests/unit/modules/files/gpg_output.txt').read(), ""

    module = AnsibleModuleTest()
    obj = RpmKey(module)

    result = obj.getkeyid('tests/unit/modules/files/RPM-GPG-KEY-dag')
    assert result == '24C6 A8A7 F4A8 0EB5'

# Generated at 2022-06-11 07:56:03.620129
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import pytest
    from ansible.module_utils.rpm_key import RpmKey

    rpmkey = RpmKey(None)

    normalized_keyid = rpmkey.normalize_keyid(' 0xDEADB33F ')
    assert normalized_keyid == 'DEADB33F'

    normalized_keyid = rpmkey.normalize_keyid(' 0XDEADB33F ')
    assert normalized_keyid == 'DEADB33F'

    normalized_keyid = rpmkey.normalize_keyid(' DEADB33F ')
    assert normalized_keyid == 'DEADB33F'

    with pytest.raises(AssertionError):
        rpmkey.normalize_keyid('DEADB33F ')

    with pytest.raises(AssertionError):
        rpmkey