

# Generated at 2022-06-11 07:46:52.085661
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import sys
    import mock

    # Test the case when is_key_imported returns true
    m = mock.Mock()
    RpmKey.execute_command(m, ['ls', '-l'])
    m.run_command.assert_called_with(['ls', '-l'], use_unsafe_shell=True)
    assert m.fail_json.called == False

    # Test the case when is_key_imported returns false
    m = mock.Mock()
    m.run_command.return_value = '1', 'stdout', 'stderr'
    RpmKey.execute_command(m, ['ls', '-l'])
    m.run_command.assert_called_with(['ls', '-l'], use_unsafe_shell=True)
    assert m.fail

# Generated at 2022-06-11 07:47:03.935215
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import io
    class mock_module:
        def __init__(self):
            self.fail_json = lambda msg: Exception(msg)
            self.run_command = self.mock_run_command

        def execute_command(self, cmd):
            return self.run_command(cmd)

        def mock_run_command(self, cmd):
            return (0, '', '')

    class mock_file:
        def __init__(self, content):
            self.content = content

        def readlines(self):
            return self.content.splitlines(True)

        def close(self):
            return None

    class mock_stdout:
        def __init__(self, file):
            self._file = file

        def __enter__(self):
            return self._file


# Generated at 2022-06-11 07:47:07.353588
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = "deadb33f"
    expected = "DEADB33F"
    actual = RpmKey(object()).normalize_keyid(keyid)
    assert expected == actual

# Generated at 2022-06-11 07:47:10.056253
# Unit test for constructor of class RpmKey
def test_RpmKey():
    args = dict(
        state='present',
        key='/path/to/file'
    )
    RpmKey(AnsibleModule(argument_spec={}) )

# Generated at 2022-06-11 07:47:10.702471
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    assert True

# Generated at 2022-06-11 07:47:13.389892
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    rp = RpmKey('')
    assert rp.getfingerprint('./test/keyfile/ansible_test.key') == '26C6E357E2B7C74F462F6B18B27B37E1F9A9B943'


# Generated at 2022-06-11 07:47:25.205130
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import uuid
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec={})
    module.no_log_values = set()

    tmpfd, tmpname = tempfile.mkstemp()
    module.add_cleanup_file(tmpname)
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-11 07:47:34.216876
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(argument_spec={})
    import_key_object = RpmKey(module)
    import_key_object.rpm = 'mock_rpm'
    import_key_object.gpg = 'mock_gpg'
    keyfile = 'mock_file'
    import_key_object.execute_command = Mock(return_value=('stdout', 'stderr'))
    import_key_object.import_key(keyfile)
    import_key_object.execute_command.assert_called_with(['mock_rpm', '--import', 'mock_file'])


# Generated at 2022-06-11 07:47:35.618609
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    assert drop_key('') == False


# Generated at 2022-06-11 07:47:45.646614
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import sys
    import os
    import shutil
    import tempfile
    import unittest
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key.rpm_key

    class DummyAnsibleModule(ansible.module_utils.basic.AnsibleModule):

        def __init__(self, argument_spec):
            super(DummyAnsibleModule, self).__init__(argument_spec=argument_spec)


# Generated at 2022-06-11 07:48:05.356373
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import unittest.mock as mock
    module_mock = mock.MagicMock()
    module_mock.get_bin_path.return_value = 'bin_path'
    module_mock.run_command.return_value = (0, 'stdout', 'stderr')
    module_mock.check_mode = False
    module_mock.fail_json = lambda **kwargs: kwargs['msg']
    module_mock.params = {}
    module_mock.cleanup = lambda x: None
    module_mock.add_cleanup_file = lambda x: None

    # test assert_failed_to_fetch_key exception
    module_mock.run_command = lambda **kwargs: (1, '', 'failed_to_fetch')

# Generated at 2022-06-11 07:48:11.021260
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module=None
    rpm_key = RpmKey(module)
    rpm_key.execute_command = MagicMock()
    rpm_key.execute_command.return_value = 0, None, None
    rpm_key.drop_key("1a8d552f")
    rpm_key.execute_command.assert_called_with(['rpm', '--erase', '--allmatches', 'gpg-pubkey-1a8d552f'])


# Generated at 2022-06-11 07:48:16.052099
# Unit test for constructor of class RpmKey
def test_RpmKey():
    key.url = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    with patch('ansible.module_utils.urls.fetch_url') as mock_fetch_url:
        mock_fetch_url.return_value = (mock.Mock(), {'status': 200})
        RpmKey(key, mock.Mock())

# Generated at 2022-06-11 07:48:24.224050
# Unit test for constructor of class RpmKey
def test_RpmKey():
    with AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    ) as module:

        # Check that calling with a valid keyfile
        # works
        RpmKey(module)

# Generated at 2022-06-11 07:48:34.788359
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    tmpfd, tmpname = tempfile.mkstemp()

# Generated at 2022-06-11 07:48:43.665194
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = None
    should_cleanup_keyfile = False
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    #TODO: print this class variables to use with upper tests
    #print(rpmkey.module)
    #print(rpmkey.rpm)
    #print(rpmkey.gpg)

    # test with a valid keyid

# Generated at 2022-06-11 07:48:55.367566
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Create a fake module
    class FakeModule(object):
        def __init__(self, **kwargs):
            """
            In this fake module you can set the value returned by get_bin_path to simulate
            a gpg or rpm installation in your managed node.
            Also you can set the return_value of the run_command method to simulate the output of the gpg or rpm commands.
            """
            self.params = kwargs
            self.fail_json_called = False
            self.fail_json_msg = ''
            self.run_command_output = (0, '', '')

        def get_bin_path(self, cmd, required=False):
            return self.params[cmd]

        def run_command(self, cmd, use_unsafe_shell=True):
            return self.run_command_output



# Generated at 2022-06-11 07:49:04.969661
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    class Module(object):
        def __init__(self):
            self.params = dict(key='https://gazzang.bintray.com/rpm/packages/centos/6/x86_64/repodata/repomd.xml.key')
            self.params['validate_certs'] = False
            self.params['state'] = 'present'

        def fail_json(self, msg):
            raise Exception(msg)


# Generated at 2022-06-11 07:49:16.752462
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Importation of unittest
    import unittest

    # Test for normalize_keyid method of class RpmKey
    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.from_keyid = RpmKey(None)

        def test_normalize_keyid(self):
            self.assertEqual(self.from_keyid.normalize_keyid("0x88B21E42"), "88B21E42")
            self.assertEqual(self.from_keyid.normalize_keyid("88B21E42"), "88B21E42")
            self.assertEqual(self.from_keyid.normalize_keyid(" 0x88B21E42 "), "88B21E42")

# Generated at 2022-06-11 07:49:19.114283
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    # The test for the execute_command function
    cmd = ['/bin/true']
    stdout, stderr = RpmKey.execute_command(RpmKey, cmd)
    assert stdout == ''
    assert stderr == ''

# Generated at 2022-06-11 07:49:50.393835
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from mock import Mock
    module = Mock()
    module.check_mode = True
    rpm_key = RpmKey(module)

    # Test Check mode is ON, i.e. don't call the command
    assert rpm_key.drop_key("") is None

    # Test Check mode is OFF, i.e. call the command
    module.check_mode = False
    rpm_key = RpmKey(module)
    module.run_command.return_value = (0, "", "")
    rpm_key.drop_key("")
    assert module.run_command.called


# Generated at 2022-06-11 07:49:54.467758
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-11 07:50:05.119591
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    # fetch key from URL
    file = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')

# Generated at 2022-06-11 07:50:14.884310
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import tempfile

    class FakeModule(object):
        def __init__(self):
            self.check_mode = False
            self.exit_json = None
            self.fail_json = None
            self.run_command = None

        def __call__(self, *args, **kwargs):
            return self

    class FakeProcess(object):
        """Used to simulate Popen"""
        def __init__(self, tc):
            self.tc = tc

        def __call__(self, *args, **kwargs):
            self.tc.assertEqual(args[0], ['/bin/rpm', '--import', '/tmp/incoming-key'])
            return (0, '', '')

    def fake_fail_json(*args, **kwargs):
        raise RuntimeError("fail_json called")

   

# Generated at 2022-06-11 07:50:27.350186
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 07:50:35.667442
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    mod = AnsibleModule(argument_spec={})
    rpm_key = RpmKey(mod)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert not rpm_key.is_keyid('DEADB33F0')
    assert not rpm_key.is_keyid('DEADB33')
    assert not rpm_key.is_keyid('')



# Generated at 2022-06-11 07:50:46.852231
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest

    test_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tzdata_pgp.asc')

    with tempfile.NamedTemporaryFile(dir='/tmp', delete=False) as tmp:
        with open(test_file, 'r') as key:
            tmp.write(key.read())
            tmp.flush()

    class TestRpmKey(unittest.TestCase):
        def test_getfingerprint(self):
            self.rpm_key = RpmKey({})

# Generated at 2022-06-11 07:50:57.621025
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    test_module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        validate_certs=dict(type='bool', default=True),
        fingerprint=dict(type='str'),
    ))

    rpm_key = RpmKey(test_module)
    result = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    with open(result, 'rb') as file_handler:
        assert(is_pubkey(file_handler.read()))



# Generated at 2022-06-11 07:51:08.263500
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    # Create a temporary file for this test
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)
    open(tmpname, 'w').write("some content")

    # Create a temporary module for this test
    module = AnsibleModule(argument_spec=dict(state=dict(type='str', default='present', choices=['absent', 'present']),
                                              key=dict(type='str', required=True, no_log=False),
                                              validate_certs=dict(type='bool', default=True)))

    # Create a RpmKey instance for this test
    # The rpm path is set to 'echo' for this test,
    # this way we can check if the process was called
    #

# Generated at 2022-06-11 07:51:20.118991
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import tempfile
    module_org = AnsibleModule
    changed = False
    results = {}
    exit_json = {}
    fail_json = {}
    class TestModule(object):
        def __init__(self, module_args,**kwargs):
            self.params = {}

        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_or_strict', data_strings=None):
            raise Exception("mocked")

        def check_mode(self):
            return True


# Generated at 2022-06-11 07:52:30.433720
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert False not in [RpmKey.is_keyid(key) for key in ['0xdeadb33f', 'deadb33f', '0xdeadb33f']]


# Generated at 2022-06-11 07:52:39.765505
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import os
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.action_common
    import ansible.module_utils._text

    class MockModule(object):
        params = {}
        check_mode = False
        run_command = os.system
        add_cleanup_file = lambda x: None
        fail_json = lambda x: None
        get_bin_path = lambda x: None

    MockModule.params['state'] = "present"
    MockModule.params['key'] = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"

    mock_urls = type('Mock', (), {})
    mock_urls.url_fetch = lambda x,y: None


# Generated at 2022-06-11 07:52:48.306248
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Set up mock
    class MockModule(object):
        def __init__(self):
            self.params = {'state': 'present', 'key': 'keyid'}
            self.fail_json = lambda msg: None
        def get_bin_path(self, name, required=False):
            return name
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "", ""
        def check_mode(self):
            return False
        def cleanup(self, keyfile):
            pass
        def add_cleanup_file(self, tmpfile):
            pass
    m = MockModule()
    RpmKey(m)

# Generated at 2022-06-11 07:52:55.945616
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    """test_RpmKey_import_key"""
    import copy
    import mock
    from ansible.module_utils.rpm_key import RpmKey

    module = "ansible.module_utils.rpm_key.AnsibleModule"
    with mock.patch(module):
        class TestObject(object):
            pass
        result = TestObject()
        result.check_mode = False
        def execute_command(cmd):
            return True
        result.run_command = execute_command
        rpm_key = RpmKey(result)
        assert(rpm_key.import_key('something') is True)


# Generated at 2022-06-11 07:53:07.935680
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-11 07:53:19.592204
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
  class AnsibleModuleStub(object):
    def __init__(self, check_mode=False):
      self.check_mode = check_mode

    def run_command(self, cmd, use_unsafe_shell=True):
      if cmd[0:3] == ['rpm', '--erase', '--allmatches']:
        return (0, '', '')
      else:
        return (0, '0xDEADBEEF', '')

    def fail_json(self, msg):
      raise AssertionError(msg)

  class RpmKeyStub(object):

    def execute_command(self, cmd):
      return '', ''

  rpmKey = RpmKeyStub()
  rpmKey.rpm = 'rpm'

# Generated at 2022-06-11 07:53:24.985299
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    # Initialize a test AnsibleModule object
    mod = MagicMock()
    mod.check_mode = False
    mod.fail_json = MagicMock()
    mod.run_command.return_value = (0, "", "")
    mod.get_bin_path.return_value = True
    # Initialize the test RpmKey object
    rpm = RpmKey(mod)
    # Test the module
    rpm.import_key('path/to/key.txt')

# Generated at 2022-06-11 07:53:28.224775
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = '/tmp/pgp-key'
    t = RpmKey(None)

    assert str(t.getkeyid(keyfile)) == 'DEADB33F'


# Generated at 2022-06-11 07:53:32.592403
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Creating function module
    module = None
    # Instance of class RpmKey
    rpm_key = RpmKey(module)
    # Creating arguments to send keyid
    args = [rpm_key, 'DEADB33F']
    # Calling drop_key method of RpmKey class
    rpm_key.drop_key(*args)

# Generated at 2022-06-11 07:53:37.904825
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    """
    Method: drop_key
    Description: test_RpmKey_drop_key()
    """
    key = RpmKey(AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    ))
    key.drop_key('123456')


# Generated at 2022-06-11 07:56:05.018474
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Mock class and objects
    class ObjMock:
        def __init__(self):
            self.fail_json = lambda x: None

    class ModuleMock:
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'fake',
                'fingerprint': 'fake fingerprint',
                'validate_certs': True,
            }
            self.check_mode = True
            self.cleanup = lambda x: None

    obj = ObjMock()
    module_mock = ModuleMock()
    rpm_key = RpmKey(module_mock)
    # Ensure that command (rpm --import fake) is not called by
    # aborting the execution if check_mode is False
    module_mock.check_mode = False

# Generated at 2022-06-11 07:56:13.840393
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Arrange
    class Module:
        check_mode = False
        class AnsibleModule:
            def run_command(self, cmd, use_unsafe_shell):
                assert cmd == ['rpm', '-q  gpg-pubkey', '--qf', '%{description}', '|', 'gpg', '--no-tty', '--batch', '--with-colons',
                               '--fixed-list-mode', '-']
                assert use_unsafe_shell == True

                return 0, 'pub:r:1024:17:D3C9 A9D3 04B0 ECBD 4EA9  B7B6 BE9B C8B3 EF27 5D09:2014-11-13:::', ''
            def fail_json(self, msg):
                assert msg == 'Unexpected gpg output'

# Generated at 2022-06-11 07:56:20.252253
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    rpmkey = RpmKey(AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    ))

    stdout, stderr = rpmkey.execute_command([
        "gpg", "--no-tty", "--batch", "--with-colons", "--fixed-list-mode", "--with-fingerprint", "/path/to/RPM-GPG-KEY.dag.txt"
    ])

    print(stdout)
    print(stderr)

# Generated at 2022-06-11 07:56:28.665324
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    def getkeyid(self, keyfile):
        return 'deadbeef'
    module = AnsibleModule(**dict(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    ))
    RpmKey.getkeyid = getkeyid
    rm = RpmKey(module)
    assert rm.getkeyid('foo') == 'deadbeef'