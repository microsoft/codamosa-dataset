

# Generated at 2022-06-11 07:46:52.766010
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from ansible.module_utils.basic import AnsibleModule
    import shutil
    import tempfile

    def execute_command(*args, **kwargs):
        if execute_command.has_been_called:
            execute_command.has_been_called = False
            return 1, '', ''
        else:
            execute_command.has_been_called = True
            return 0, '', ''
    execute_command.has_been_called = False

    def run_command(*args, **kwargs):
        if run_command.has_been_called:
            run_command.has_been_called = False
            return 1, '', ''
        else:
            run_command.has_been_called = True
            return 0, '', ''
    run_command.has_been_called = False


# Generated at 2022-06-11 07:47:04.599871
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    class MockModule(object):
        def __init__(self):
            self.params = {'key': '0xcc0c4d06749c9a906e5cdacf8c5b5ec5b09c3c3d'}

        def get_bin_path(self, cmd, required=False):
            return cmd

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        def run_command(self, cmd, use_unsafe_shell=True):
            cmd = ' '.join(cmd)
            if cmd == '/usr/bin/rpm -q  gpg-pubkey':
                return 0, 'gpg-pubkey-cc0c4d06-6957781a', ''

# Generated at 2022-06-11 07:47:12.346779
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict()
    )
    rpk = RpmKey(module)
    rpk.rpm = '/bin/rpm'
    rpk.gpg = '/bin/true'
    keyfile = '/etc/rhsm/ca/candlepin-local.pem'
    expected_fingerprint = '1899AC5E58BBC6E5C56D9F6D9AEACEDD60B3C3DF'

    assert expected_fingerprint == rpk.getfingerprint(keyfile)



# Generated at 2022-06-11 07:47:19.412438
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Initialization
    testkeyfile = "tests/test.key"
    expected_fingerprint = "7893AD6F369C8B0055C4BA4C181B4D3626C8EAE6"
    rpmkey = RpmKey(None)
    rpmkey.gpg = "tests/test_gpg"

    # Unit test
    returned_fingerprint = rpmkey.getfingerprint(testkeyfile)
    assert(returned_fingerprint == expected_fingerprint)


# Generated at 2022-06-11 07:47:30.914186
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import unittest

    class TmpClass:
        def __init__(self):
            pass

        def exit_json(self, changed=False, msg=""):
            pass

        def add_cleanup_file(self, path):
            pass

        def fail_json(self, msg=""):
            pass

        def clean_args(self):
            return dict(
                state="present",
                key="0xDEADBEEF",
                validate_certs=True
            )

        def get_bin_path(self, bin, required=False):
            return '/bin/foo'

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''


# Generated at 2022-06-11 07:47:39.643282
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import random
    import string
    import tempfile

    random_string = lambda length: ''.join([random.choice(string.ascii_letters + string.digits) for i in range(length)])

# Generated at 2022-06-11 07:47:47.169355
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Test for present state
    key_present = RpmKey(module)
    assert key_present.state == 'present'
    assert key_present.key == 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    assert key_present.fingerprint == ''

    # Test for absent state
    key_absent = RpmKey(module)
    assert key_absent.state == 'absent'
    assert key_absent.key == 'DEADB33F'
    assert key_absent.fingerprint == ''



# Generated at 2022-06-11 07:47:54.356757
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # pylint: disable=anomalous-backslash-in-string
    assert RpmKey.normalize_keyid(['', '0xDEADBEEF']) == 'DEADBEEF'
    assert RpmKey.normalize_keyid(['', 'DEADBEEF']) == 'DEADBEEF'
    assert RpmKey.normalize_keyid(['', '0xDEADBEEF   ']) == 'DEADBEEF'

# Generated at 2022-06-11 07:48:03.637744
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    import tempfile
    # In file tests/test_file.py
    #
    # with mock.patch('ansible.module_utils.common.run_command', return_value=None):
    #     with tempfile.NamedTemporaryFile('r+') as t:
    #         t.write('dummy data')
    #         t.seek(0)
    #         assert t.read() == 'dummy data'
    #         t.flush()
    #         RpmKey.import_key(['rpm', '--import', t.name])
    #
    # asserts that tempfile content was flushed and that
    # `ansible.module_utils.common.run_command` was called with
    # ['rpm', '--import', t.name]
    #
    # In our test we want to

# Generated at 2022-06-11 07:48:04.975865
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    assert RpmKey.fetch_key(None, "http://example.com/key")

# Generated at 2022-06-11 07:48:30.372657
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_key = RpmKey(test_module)
    assert test_key.getfingerprint('rpm_key/RPM-GPG-KEY-redhat-release') == 'EBC6E12C62B1C734026B21222A20E52146B8D79E6'


# Generated at 2022-06-11 07:48:41.893955
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import StringIO

    rm = RpmKey()

    # Testing getkeyid with a mocked class
    assert rm.getkeyid("/dev/null") == "DEADB33F"

    # Testing getfingerprint with a mocked class
    assert rm.getfingerprint("/dev/null") == "EBC6E12C62B1C734026B21222A20E52146B8D79E6"
    assert rm.getfingerprint("/dev/null") != "foo"

    # Testing is_keyid
    assert rm.is_keyid("0xDEADBEEF")

# Generated at 2022-06-11 07:48:53.538640
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    keyid_1 = 'DEADB33F'
    keyid_2 = '0xDEADBEEF'
    keyid_3 = 'BEEF'
    keyid_4 = '0xDEADBEEF'

    keyid_4 = '0xDEADBEEF'
    keyid_5 = '0xDEADBEEF'
    keyid_6 = '0xDEADBEEF'
    keyid_7 = '0xDEADBEEF'


# Generated at 2022-06-11 07:49:00.348805
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Test constructor
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-11 07:49:11.160696
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class DummyModule(object):

        def __init__(self):
            self.params = {'fingerprint': 'EBC6E12C62B1C734026B2122A20E52146B8D79E6', 'key': 'RPM-GPG-KEY-dag', 'state': 'present'}
            self.check_mode = False
            self.run_command_return_code = 0
            self.run_command_stdout = ''
            self.run_command_stdout_lines = []
            self.fail_json_msg = 'This should not be called'

        def get_bin_path(self, executable, required=False):
            if executable == 'gpg2':
                return '/usr/bin/gpg2'
            return None


# Generated at 2022-06-11 07:49:22.815257
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.basic import AnsibleModule
    import os


# Generated at 2022-06-11 07:49:30.296330
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Instantiation of the class
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    RpmKey_instance = RpmKey(module)
    # Test cases
    assert RpmKey_instance.is_keyid('0xdeadbeef') == True
    assert RpmKey_instance.is_keyid('deadbeef') == True
    assert RpmKey_instance.is_keyid('0xdeadbeefdeadbeef') == False
    assert RpmKey_instance.is_keyid('DEADBEEF') == True


# Generated at 2022-06-11 07:49:35.065819
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Call function with test values
    keyid = RpmKey.normalize_keyid(RpmKey, self='0x0E83EE8532C7B2FE')
    # Test if expected result is equal with the return of the function
    assert keyid == 'E83EE8532C7B2FE'


# Generated at 2022-06-11 07:49:45.426837
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
    argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ),
    supports_check_mode=True,
    )

    mock_gpg = "mock"
    mock_rpm = "mock"
    keyid = "0x00010001"
    mock_check = ""
    mock_check_stdout = "mock"
    mock_check_stderr = "mock"
    mock_command = [mock_rpm, '-q  gpg-pubkey']

# Generated at 2022-06-11 07:49:47.863111
# Unit test for function main
def test_main():
    with patch('ansible.plugins.action.rpm_key.AnsibleModule') as mo:
        module = mo.return_value
        main()
        assert mo.call_count == 1

# Generated at 2022-06-11 07:50:27.150195
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os
    import shutil
    import tempfile
    import unittest

    class RpmKeyMock(RpmKey):
        def __init__(self, module, rpm=None, gpg=None):
            self.module = module
            self.rpm = rpm
            self.gpg = gpg

            self.result = None
            self.cmd = None
            self.stdout = None
            self.stderr = None

        def execute_command(self, cmd):
            self.cmd = cmd

            return self.result

    class RpmKeyModuleMock:
        def __init__(self):
            self.run_command = self.run_command_mock

        def run_command_mock(self, cmd, use_unsafe_shell=True):
            return 0, rpm_key.stdout

# Generated at 2022-06-11 07:50:28.729585
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    assert RpmKey.import_key('test_key') == False

# Generated at 2022-06-11 07:50:34.620615
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    key = RpmKey(module)


# Generated at 2022-06-11 07:50:45.153874
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec = dict(
            state = dict(type = 'str', default = 'present', choices = ['absent', 'present']),
            key = dict(type = 'str', required = True, no_log = False),
            fingerprint = dict(type = 'str'),
            validate_certs = dict(type = 'bool', default = True),
        ),
        supports_check_mode = True
    )
    
    # Mocking module methods
    import tempfile
    tempfile.mkstemp = lambda: (1, 'keyfile')
    module.get_bin_path = lambda x, required=True: 'rpm'
    module.run_command = lambda cmd, use_unsafe_shell=True: (0, 'out', '')

    # Creating a RpmKey object
    rpm_

# Generated at 2022-06-11 07:50:57.405818
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_cases = [
        ('0xA981B500930A3E07', 'A981B500930A3E07'),
        ('0xA981B500930A3E07\n', 'A981B500930A3E07'),
        ('0xa981b500930a3e07', 'A981B500930A3E07'),
        ('0xa981b500930a3e07\n', 'A981B500930A3E07'),
        ('A981B500930A3E07', 'A981B500930A3E07'),
        ('A981B500930A3E07\n', 'A981B500930A3E07')
    ]


# Generated at 2022-06-11 07:51:08.149749
# Unit test for method getfingerprint of class RpmKey

# Generated at 2022-06-11 07:51:19.958952
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from mock import Mock, patch
    module = Mock()
    rpm_key = RpmKey(module)

    rpm_key.rpm = 'fake_rpm'
    rpm_key.module = Mock()
    rpm_key.module.run_command = Mock()

    keyto_drop = 'FAKEKEYID'

    # check mode
    rpm_key.drop_key(keyto_drop)
    rpm_key.module.run_command.assert_not_called()

    # real mode
    rpm_key.module.check_mode = False
    rpm_key.drop_key(keyto_drop)

# Generated at 2022-06-11 07:51:28.998601
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create an instance of class
    test_module = AnsibleModule(argument_spec={'state': {'type': 'str', 'default': 'present',
                                                           'choices': ['absent', 'present']},
                                               'key': {'type': 'str', 'required': True, 'no_log': False},
                                               'fingerprint': {'type': 'str'},
                                               'validate_certs': {'type': 'bool', 'default': True}},
                               supports_check_mode=True)
    rpm_key = RpmKey(test_module)

    # Import key
    rpm_key.import_key('/path/to/gpg_key')

# Generated at 2022-06-11 07:51:33.022371
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    mock_module = Mock()
    mock_module.check_mode = False
    mock_module.run_command.return_value = (0, '', '')
    rpmKey = RpmKey(mock_module)
    rpmKey.execute_command = Mock()
    keyfile = '/tmp/rpm.key'
    rpmKey.import_key(keyfile)
    rpmKey.execute_command.assert_called_once_with([rpmKey.rpm, '--import', keyfile])

# Generated at 2022-06-11 07:51:41.094983
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert is_pubkey(rpm_key.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt"))


# Generated at 2022-06-11 07:52:50.676401
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.modules.packaging.os import rpm_key
    import tempfile
    module = rpm_key.AnsibleModule(
        argument_spec={
            'state': dict(type='str', default='present', choices=['absent', 'present']),
            'key': dict(type='str', required=True),
            'fingerprint': dict(type='str'),
            'validate_certs': dict(type='bool', default=True),
        },
        supports_check_mode=True,
    )

    RpmKey(module).execute_command('ls')

# Generated at 2022-06-11 07:52:51.373397
# Unit test for constructor of class RpmKey
def test_RpmKey():
    pass

# Generated at 2022-06-11 07:53:02.818330
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    # Key is not a gpg key
    assert is_pubkey("This is not a gpg key") == False

    # Key is a gpg key

# Generated at 2022-06-11 07:53:03.495188
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    assert True

# Generated at 2022-06-11 07:53:12.009304
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os

    # Test for keys with a single UID
    for keyfile in test_keys:
        expected_id = key_ids[keyfile]
        tmpfd, tmpname = tempfile.mkstemp()
        os.write(tmpfd, key_samples[keyfile])
        os.close(tmpfd)
        key_id = RpmKey.getkeyid(None, tmpname)
        assert key_id == expected_id
        os.unlink(tmpname)
    # Test for keys with multiple UIDs
    for keyfile in test_keys:
        expected_id = key_ids[keyfile]
        tmpfd, tmpname = tempfile.mkstemp()
        os.write(tmpfd, key_samples[keyfile] * 3)
        os.close(tmpfd)


# Generated at 2022-06-11 07:53:20.728409
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    test_module = MockModule()
    test_rpm_key = RpmKey(test_module)

    test_file = '/path/to/file'
    test_fingerprint = 'BCDE 1234 5678 90AB CDEF  0123 4567 890A BCDE FEDC'

    def test_execute_command(cmd):
        assert cmd[-1] == test_file
        return test_fingerprint

    test_rpm_key.execute_command = test_execute_command

    assert test_rpm_key.getfingerprint(test_file) == test_fingerprint
    assert test_module.fail_json.call_count == 0


# Generated at 2022-06-11 07:53:25.910730
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    o = RpmKey(module)
    assert o.fetch_key('https://pgpkeys.uk/search/northpole') is not None
    assert is_pubkey(open(o.fetch_key('https://pgpkeys.uk/search/northpole'), 'r').read()) is True

# Generated at 2022-06-11 07:53:29.516319
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    test_object = RpmKey(None)
    ret = test_object.getkeyid('test/test_gpg_key.txt')
    assert ret == 'a20e52146b8d79e6'


# Generated at 2022-06-11 07:53:35.517325
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
            argument_spec=dict(
                state=dict(type='str', default='present', choices=['absent', 'present']),
                key=dict(type='str', required=True, no_log=False),
                fingerprint=dict(type='str'),
                validate_certs=dict(type='bool', default=True),
            ),
            supports_check_mode=True,
        )
    RpmKey.is_key_imported(module, "0x29b6f5d882fba909")

# Generated at 2022-06-11 07:53:41.181970
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test case 1 - when key is not installed on system
    key = RpmKey()
    result = key.is_key_imported("gpg-pubkey")
    assert result == False
    # Test case 2 - when key is installed on system
    key = RpmKey()
    result = key.is_key_imported("gpg-pubkey-db42a60e")
    assert result == True


# Generated at 2022-06-11 07:56:07.483007
# Unit test for constructor of class RpmKey
def test_RpmKey():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', default='EBC6E12C62B1C734026B2122A20E52146B8D79E6', no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-11 07:56:16.706079
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class FakeModule(object):
        def __init__(self, check_mode):
            self.check_mode = check_mode
            self.args = dict(key="test_file")

        def fail_json(self, *args, **kwargs):
            raise AssertionError(args, kwargs)

        def execute_command(self, cmd):
            return 0, "", ""

        def run_command(self, cmd, use_unsafe_shell):
            return 0, "", ""

    import_key_object = RpmKey(FakeModule(False))
    # Dry run
    assert import_key_object.import_key("test_file")

    class FakeModule(object):
        def __init__(self, check_mode):
            self.check_mode = check_mode

# Generated at 2022-06-11 07:56:26.646631
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile()