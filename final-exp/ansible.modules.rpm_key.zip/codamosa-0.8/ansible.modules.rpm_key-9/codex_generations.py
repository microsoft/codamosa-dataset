

# Generated at 2022-06-11 07:46:53.740157
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    # Test case when the key is imported on the system
    obj = RpmKey({'check_mode': False})
    assert obj.is_key_imported('8db03f9c6a2a6c34')
    assert obj.is_key_imported('0x8db03f9c6a2a6c34')

    # Test case when the key is not imported on the system
    obj = RpmKey({'check_mode': False})
    assert not obj.is_key_imported('CA86F2ABD1D0E5ED')
    assert not obj.is_key_imported('0xCA86F2ABD1D0E5ED')

    # Test case when the key contains leading 0 and upper case
    obj = RpmKey({'check_mode': False})

# Generated at 2022-06-11 07:47:05.656483
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rp = RpmKey(None)

    # Erase key present in rpm db
    keyid = 'DEADB33F'
    cmd = rp.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = rp.module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        pytest.fail("Key is not installed on system")
    cmd += ' --qf "%{description}" | ' + rp.gpg + ' --no-tty --batch --with-colons --fixed-list-mode -'
    stdout, stderr = rp.execute_command(cmd)
    for line in stdout.splitlines():
        if keyid in line.split(':')[4]:
            rp.drop_key(keyid)

# Generated at 2022-06-11 07:47:14.174311
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    key = RpmKey("DUMMY")
    key.rpm = "DUMMY"
    key.gpg = "DUMMY"

    # Key is not installed
    rc = 0
    stdout = ""
    stderr = ""
    key.module.run_command = lambda x, y: (rc, stdout, stderr)
    assert not key.is_key_imported("DUMMY")

    # Key is installed
    stdout = "DUMMY\n"
    key.module.run_command = lambda x, y: (rc, stdout, stderr)
    assert key.is_key_imported("DUMMY")



# Generated at 2022-06-11 07:47:20.300656
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import tempfile
    import os
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.rpm_key import drop_key
    from shutil import copyfile

    class TestModule(object):
        """Wrapper around AnsibleModule to make testing easier"""

        def __init__(self, *args, **kwargs):
            self.params = dict(*args, **kwargs)
            self.check_mode = False

        def fail_json(self, **args):
            """Mock function to raise exceptions. If the specified key is not in the message, the exception is raised"""
            keys = ['msg']

            for key in keys:
                if key not in args:
                    raise AnsibleModuleError(to_native(args))


# Generated at 2022-06-11 07:47:31.773483
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    import mock
    import os
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    from ansible.module_utils.basic import get_distribution
    from ansible.module_utils.six import PY3

    if PY3:
        import io
        StringIO = io.StringIO
    else:
        import StringIO

    class BaseOs(object):
        DISTRIBUTION = get_distribution()

    class RpmBased(BaseOs):
        PACKAGER = 'Rpm'

    def execute_command(self, cmd):
        if cmd == [self.rpm, '-q', 'gpg-pubkey', '--qf', '%{description}']:
            return 0, 'blah', ''
        else:
            return 1, 'blah', 'blah'

# Generated at 2022-06-11 07:47:36.343945
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-11 07:47:46.478132
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class MockModule(object):
        def __init__(self, key=None, fingerprint=None):
            self._key = key
            self._fingerprint = fingerprint

        @property
        def params(self):
            return {
                'state': 'present',
                'key': self._key,
                'fingerprint': self._fingerprint
            }

        def fail_json(self, msg):
            raise Exception(msg)

        def is_key_imported(self, keyid):
            return keyid == 'FAKE_KEYID'

        def get_bin_path(self, app, required=False):
            if app == 'rpm':
                return '/usr/bin/rpm'
            elif app == 'gpg' or app == 'gpg2':
                return '/usr/bin/gpg'

# Generated at 2022-06-11 07:47:49.425912
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    assert RpmKey.getkeyid(self) == True


# Generated at 2022-06-11 07:47:59.824182
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.is_keyid('0xDEADBEEF')
    assert rpmkey.is_keyid('0xDEADBEE') == False
    assert rpmkey.is_keyid('0XDEADBEEF')
    assert rpmkey.is_keyid('DEADBEEF')

# Generated at 2022-06-11 07:48:03.928832
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Test with a directory
    fake_module = AnsibleModule(argument_spec={'key': dict(type='str', required=True, no_log=False)})
    ansible_RpmKey = RpmKey(fake_module)
    fake_module.fail_json = lambda msg: assertFalse(msg)
    ansible_RpmKey.fetch_key('/some/path/file.txt')

# Generated at 2022-06-11 07:48:31.552064
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create mock for class AnsibleModule
    class AnsibleModuleMock():
        def __init__(self):
            self.exit_json_called = False
            self.fail_json_called = False
            self.check_mode = False
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': '',
            }
            self.add_cleanup_file_called = False
            self.cleanup_file_list = []
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''
            self.run_command_cmd = ''
            self.run_command_unsafe = False

# Generated at 2022-06-11 07:48:34.690840
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec={})
    keyid = "  0x01234567 "
    assert(RpmKey.normalize_keyid(RpmKey(module), keyid) == "01234567")

# Generated at 2022-06-11 07:48:42.540758
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    key = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    RpmKey(module)
    assert module.params['state'] == 'present'
    assert module.params['key'] == key

# Generated at 2022-06-11 07:48:54.239677
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class MockModule(object):
        def run_command(self, cmd):
            if cmd[0] == '/usr/bin/rpm':
                return (0, '1e2c945fd9c1829f6dc53b6d836c7e1a', '')

# Generated at 2022-06-11 07:49:04.249726
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_key = RpmKey(None)
    assert rpm_key.is_keyid('39a3a0833beb7a21')
    assert not rpm_key.is_keyid('A39a3a0833beb7a21')
    assert not rpm_key.is_keyid('39a3a0833beb7a21A')
    assert rpm_key.is_keyid('039a3a0833beb7a21')
    assert rpm_key.is_keyid('0x39a3a0833beb7a21')
    assert rpm_key.is_keyid('0x03b6f8007bb60bfb')
    assert not rpm_key.is_keyid('0x03b6f8007bb60bbb')
    assert not rpm_key.is_

# Generated at 2022-06-11 07:49:16.163846
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils import basic
    from ansible.module_utils import url
    from ansible.module_utils import _text
    from ansible.module_utils.six import string_types
    _mock_module = basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    _mock_module.get_bin_path = lambda *args, **kwargs: '/bin/rpm'

# Generated at 2022-06-11 07:49:16.824833
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert True

# Generated at 2022-06-11 07:49:28.149883
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import types
    import sys
    import unittest

    class MockModule(object):
        fail_json = types.MethodType(lambda self, msg: sys.exit(1), {})
        @staticmethod
        def get_bin_path(path, required=False):
            if path == "rpm":
                return path
            elif path == "gpg":
                return path
            return None
        @staticmethod
        def run_command(cmd, use_unsafe_shell=True):
            return 0, "", ""

    class MockModule_add_cleanup_file(object):
        def __init__(self, tmpname=""):
            self.tmpname = tmpname
            self.cleanup_files = []

# Generated at 2022-06-11 07:49:31.631724
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert normalize_keyid("deadb33f") == "DEADB33F"
    assert normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert normalize_keyid("  0xdeadb33f  ") == "DEADB33F"


# Generated at 2022-06-11 07:49:42.195343
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """Test case for getkeyid method of RpmKey class"""
    dummy_module = DummyModule()
    rpm_key = RpmKey(dummy_module)
    keyfile = rpm_key.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt")
    keyid = rpm_key.getkeyid(keyfile)
    assert keyid == "FEB9 6993 543B DC3E B4D4  C7BD 6F5D A05B 8F0B D9AD"
    # Test case with a bad keyfile
    dummy_module.fail_json = MagicMock(side_effect=Exception("Unexpected gpg output"))
    with pytest.raises(Exception) as excinfo:
       rpm_key.getkeyid("/")
    assert exc

# Generated at 2022-06-11 07:50:26.062078
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import shutil
    import tempfile
    import os.path

    # In python 3 tempfile.mkstemp() return a tuple where first element is the file descriptor,
    # so we need to unpack the variables
    tmpfd, tmpname = tempfile.mkstemp()
    # Closing the file descriptor
    os.close(tmpfd)
    # Removing the file
    os.remove(tmpname)
    # Making sure the file does not exist
    assert os.path.isfile(tmpname) == False

    key_path= tmpname + '.gpg'

# Generated at 2022-06-11 07:50:37.361321
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Import the class to avoid the module import from the task to run
    from ansible.modules.packaging.os.rpm_key import RpmKey
    # Create empty module for mocking
    module = AnsibleModule(argument_spec={})
    # Create an instance with no params because we don't execute the __init__ method
    rpm_key = RpmKey(module)
    # Create test keyfile

# Generated at 2022-06-11 07:50:44.169311
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Setup test arguments
    keystr = 'deadbeef'

    # Setup test object
    o = RpmKey(None)

    # Run method being tested and ensure expected result
    try:
        o.is_keyid(keystr)
    except Exception as e:
        # If an exception was raised, fail the test
        assert False, 'Exception thrown during execution of test case: %s' % e

    # If no exception was raised, pass the test
    assert True

# Generated at 2022-06-11 07:50:56.554453
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.urls import fetch_url
    import ansible.module_utils.action_plugins.rpm_key as rpm_key
    module = AnsibleModule(argument_spec={'key': {'type': 'str', 'required': True, 'no_log': False}},
                           supports_check_mode=True)
    path = module.params['key']
    if '://' in path:
        path = rpm_key.RpmKey(module).fetch_key(path)

# Generated at 2022-06-11 07:51:07.576760
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert(rpm_key.normalize_keyid("deadbeef") == "DEADBEEF")
    assert(rpm_key.normalize_keyid("0xDEADBEEF") == "DEADBEEF")

# Generated at 2022-06-11 07:51:08.186837
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    assert 1 == 1

# Generated at 2022-06-11 07:51:12.180317
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """Unit test for method getkeyid of class RpmKey"""
    assert RpmKey.getkeyid('0X08C9F05635AEEA2C') == '08C9F05635AEEA2C'



# Generated at 2022-06-11 07:51:23.954108
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpmkey = RpmKey(AnsibleModule)
    assert rpmkey.is_keyid('0xDEADB33F') == True
    assert rpmkey.is_keyid('DEADB33F') == True
    assert rpmkey.is_keyid('0x0FDBE') == False
    assert rpmkey.is_keyid('0xDEADB33G') == False
    assert rpmkey.is_keyid('FDBE') == False
    assert rpmkey.is_keyid('DEADB3') == False
    assert rpmkey.is_keyid('DEADB33FG') == False
    assert rpmkey.is_keyid('DEADB33F ') == False
    assert rpmkey.is_keyid(' DEADB33F') == False

# Generated at 2022-06-11 07:51:31.623891
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import unittest
    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.rpm_key = RpmKey('foo')
        def normalize_keyid_test_ok(self):
            self.assertEqual(self.rpm_key.normalize_keyid("deadb33f"), "DEADB33F")
        def normalize_keyid_test_ok_0x(self):
            self.assertEqual(self.rpm_key.normalize_keyid("0xDEADB33F"), "DEADB33F")
        def normalize_keyid_test_ok_0X(self):
            self.assertEqual(self.rpm_key.normalize_keyid("0XDEADB33F"), "DEADB33F")

# Generated at 2022-06-11 07:51:41.448430
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    class TestModule(object):

        def __init__(self):
            self.check_mode = False

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd.find('rpm') != -1:
                return 0, 'foo-bar', ''
            elif cmd.find('gpg') != -1:
                return 0, "pub:u:4096:1:0EBE1FC9D903B7AC:1517780840::c:::scaESCA:fpr:::::::::0EBE1FC9D903B7AC:\n", ''
            else:
                return -1, '', 'Unable to run command'

    rpmkey = RpmKey(TestModule())

# Generated at 2022-06-11 07:52:51.173199
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    pass


# Generated at 2022-06-11 07:53:00.281250
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    key = 'https://github.com/ansible/ansible/raw/devel/examples/scripts/Copy_id_file.pub'
    keyfile = RpmKey.fetch_key(key)
    assert is_pubkey(keyfile)

# Generated at 2022-06-11 07:53:10.597780
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    m = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rp = RpmKey(m)

    assert rp.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rp.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rp.normalize_keyid('dead b33f') == 'DEADB33F'
    assert rp

# Generated at 2022-06-11 07:53:13.934349
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = "  0xDEADB33F  "
    ret = RpmKey(keyid)
    assert ret.normalize_keyid(keyid) == "DEADB33F"

# Generated at 2022-06-11 07:53:23.001533
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    test_run = os.environ.get("TEST_RUN_ID")
    cmd = '/usr/bin/rpm' + ' -q  gpg-pubkey --qf "%{description}" | ' + '/usr/bin/gpg' + ' --no-tty --batch --with-colons --fixed-list-mode -'

    if test_run == "1":
        rc = 0

# Generated at 2022-06-11 07:53:33.145458
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.dict_transformations import _to_lines
    from ansible.module_utils.network.netcli.config import ConfigLine
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import find_plugin_filters
    from ansible.template import Templar
    from io import BytesIO
    from io import BufferedReader
    basic._ANSIBLE_ARGS = to_bytes('')
    loader = DataLoader()
    vault_secrets = Vault

# Generated at 2022-06-11 07:53:39.068904
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    """Test method drop_key of class RpmKey"""
    m = Mock()
    m.params = { 'state' : 'present', 'fingerprint' : None, 'key' : '434f8a6c', 'validate_certs' : True }
    r = RpmKey(m)
    r.drop_key('0x4b4fb343')
    assert(m.run_command.called)


# Generated at 2022-06-11 07:53:44.652912
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_key = RpmKey(AnsibleModule(argument_spec={}))
    assert rpm_key.is_keyid('0x12345678'),'Error on RpmKey.is_keyid'
    assert not rpm_key.is_keyid('0x1234abcd'),'Error on RpmKey.is_keyid'

# Generated at 2022-06-11 07:53:55.135708
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Tests if keyfile returns a valid fingerprint in format used by gpg --with-fingerprint option
    # Checks if keyfile is a valid gpg key
    assert is_pubkey(open('tests/test_key.gpg', 'r').read())
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")
    tmpfile.write(open('tests/test_key.gpg', 'r').read())
    tmpfile.close()
    keyfile = tmpname
    keyfingerprint = "A20E52146B8D79E6"
    rpm = RpmKey()
    # checks if proper fingerprint is returned
    rpm.getfingerprint(keyfile) == keyfingerprint


# Generated at 2022-06-11 07:54:03.539385
# Unit test for constructor of class RpmKey
def test_RpmKey():
    src_url = 'https://github.com/jupyter/notebook/blob/master/tests/data/' + \
              'notebook_sec/keys/gpg.txt'

    def my_run_command(module, cmd, use_unsafe_shell=True):
        return (0, '', '')

    def my_module_check_mode(self):
        return False

    def my_module_fail_json(self, msg=''):
        assert msg != '', 'module_exit_json called'

    def my_module_exit_json(self, changed=False):
        assert changed is False, 'module_exit_json called'
