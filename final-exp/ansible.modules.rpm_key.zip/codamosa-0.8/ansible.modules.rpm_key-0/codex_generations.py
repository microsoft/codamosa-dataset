

# Generated at 2022-06-11 07:46:54.052622
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import BytesIO
    import io
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

# Generated at 2022-06-11 07:47:05.927188
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    rpmkey = RpmKey()

# Generated at 2022-06-11 07:47:13.382805
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(argument_spec=dict())
    rpm_key = RpmKey(module)

    assert rpm_key.normalize_keyid("  DEADB33F ") == "DEADB33F"
    assert rpm_key.normalize_keyid("0XDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("deadb33f") == "DEADB33F"

# Generated at 2022-06-11 07:47:25.256858
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # import test.utils_ansible_module_runner
    from ansible.module_utils import action_common_attributes

    mock_module = action_common_attributes.ActionBase()
    mock_module.run_command = run_command_mock
    mock_module.cleanup = cleanup_mock
    mock_module.params = {'validate_certs': True}

    key = RpmKey(mock_module)
    key.fetch_key("http://test/test.gpg")

    assert mock_module.run_command.called_with(['gpg', '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '/tmp/tmpzcA9C9.gpg'])

# Generated at 2022-06-11 07:47:36.071758
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    rpmkey = RpmKey(module)

    # basic test
    keyid = rpmkey.is_keyid('0xDEADB33F')
    assert keyid is True, "0xDEADB33F is a valid keyid"

    # ignore case
    keyid = rpmkey.is_keyid('0xDeadB33F')
    assert keyid is True, "0xDeadB33F is a valid keyid"

    # leading 0x is optional
    keyid = rpmkey.is_keyid('deadb33f')
    assert keyid is True, "deadb33f is a valid keyid"

    # a too short keyid is not a keyid

# Generated at 2022-06-11 07:47:46.116790
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """Method getkeyid of class RpmKey should return the keyid of the key in the specified file"""

    class MockRpmKey(RpmKey):
        """Mocked class RpmKey"""

        def execute_command(self, cmd):
            if cmd == [self.gpg, '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', keyfile]:
                return 'pub:u:1:8B00B9E9C86D1B3F:2015-09-29:::sca:0:16:ADC1ED8B00B9E9C86D1B3F\nuid:u:0:Héctor Acosta <hector.acosta@gazzang.com>::\ntm&:u:0:1443403954:::', ''


# Generated at 2022-06-11 07:47:52.871687
# Unit test for constructor of class RpmKey
def test_RpmKey():
    fakemodule = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Import key
    fakemodule.params = {'state': 'present', 'key': 'https://gazzang.com/static/gpg/rpm-gpg-key-gazzang.txt'}
    fakemodule.run_command = fake_run_command
    fakemodule.check_mode = False
    RpmKey(fakemodule)

    # Import key with check mode

# Generated at 2022-06-11 07:48:02.553130
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_module = MagicMock()
    rpm_key_module = RpmKey(rpm_module)
    assert rpm_key_module.is_keyid('DEADB33F') == True
    assert rpm_key_module.is_keyid('0xDEADB33F') == True
    assert rpm_key_module.is_keyid('0xDEADB33F018F6E') == True
    assert rpm_key_module.is_keyid('0xDEADB33F18F6E') == True
    assert rpm_key_module.is_keyid('DEADB33F018F6E') == True
    assert rpm_key_module.is_keyid('DEADB33F18F6E') == True

# Generated at 2022-06-11 07:48:11.966881
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from units.modules.utils import set_module_args
    module = AnsibleModule(argument_spec={})
    set_module_args(
        dict(
            key='',
            state='present'
        ),
    )

    rpm_key = RpmKey(module)

    # Test success

# Generated at 2022-06-11 07:48:23.394860
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():

    import sys
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = boolean(params['check_mode'], strict=False)

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(0)


# Generated at 2022-06-11 07:48:40.202697
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    """Test the method getfingerprint."""
    assert rpm_key.RpmKey.getfingerprint('somekeyfile') == None

# Code to invoke unittest for this module
if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-11 07:48:46.593422
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    class FakeModule(object):

        def __init__(self):
            self.module = None
            self.params = dict(
                state='present',
                key='http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                validate_certs=True,
            )

        def get_bin_path(self, name, required=False):
            if name == 'gpg2':
                return '/bin/gpg2'
            else:
                return None

        def add_cleanup_file(self, path):
            pass

        def clean_up(self, path):
            pass


# Generated at 2022-06-11 07:48:58.174487
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    key_url = "https://server.com/rpm.key"
    key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\nVersion: GnuPG v1\n\nmQENBF",
    key += "AypvYwBCACyT2T6oH0jGkrUzfqb3qrZW1x8jQaGoueLYY1StHkWwdp8hhvBBjfmI\nXnZ9sxjnpdzc+HUYTKnT6TfUg8apU6k1ksH"

# Generated at 2022-06-11 07:49:07.714256
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class Module(object):
        def __init__(self):
            self.debug = False
            self.check_mode = False

        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

        def run_command(self, cmd, **kwargs):
            return 0, 'fpr:::::::::5B8C5D2E5F5305C9:', ''

    class ActionModule(object):
        def __init__(self):
            self.module = Module()

    with open('files/RPM-GPG-KEY-domain-1.gpg') as f:
        key = f.read()

    tempfile.tempdir = ''
    fd, tmpname = tempfile.mkstemp()

# Generated at 2022-06-11 07:49:19.281107
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.urls import fetch_url

    def mock_fetch(module, key):
        return tempfile.mkstemp()[1], {}

    # Add to system path
    import sys
    module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    sys.path.insert(0, module_path)
    from rpm_key import RpmKey


# Generated at 2022-06-11 07:49:30.127170
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class FakeModule:
        def run_command(cmd, use_unsafe_shell):
            return 0, "", ""

    class FakeAnsibleModule:
        def __init__(self, args):
            self.args = args

    class FakeRpmKey:
        def __init__(self, module):
            self.module = module

    rpm_key = FakeRpmKey(FakeAnsibleModule(FakeModule(dict(
        state='present',
        key='http://apt.sw.be/RPM-GPG-KEY.dag.txt',
        fingerprint=None,
        validate_certs=True,
    ))))
    assert rpm_key.module.args.module.run_command.called is False
    rpm_key.execute_command(['cmd', 'arg1'])

# Generated at 2022-06-11 07:49:40.737400
# Unit test for constructor of class RpmKey
def test_RpmKey():
    dummy_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_key_file = 'test_key.gpg'
    test_key_id = 'DEADB33F'
    test_key_fingerprint = 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6'


# Generated at 2022-06-11 07:49:41.680986
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    RpmKey.getkeyid()


# Generated at 2022-06-11 07:49:51.189880
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Test case 1: Key is contained in text
    # First we generate a temporary file with the key
    tmpfd, tmpname = tempfile.mkstemp()

# Generated at 2022-06-11 07:49:57.179499
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import shutil
    import tempfile

    tmp_file = tempfile.mkstemp()[1]
    test_url = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    module = AnsibleModule(argument_spec={
        'state': dict(type='str', default='present', choices=['absent', 'present']),
        'key': dict(type='str', required=True, no_log=False)
    },
        supports_check_mode=True,
    )
    with open(tmp_file, "w+b") as tmp_file_content:
        instance = RpmKey(module)
        tmp_file_content.write(instance.fetch_key(test_url))
        tmp_file_content.close()

# Generated at 2022-06-11 07:50:36.738245
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import shutil
    import pytest
    module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ))
    file = tempfile.mkdtemp()

# Generated at 2022-06-11 07:50:44.861157
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key("0D848F8D")


# Generated at 2022-06-11 07:50:47.122796
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert RpmKey.__doc__ is not None
    assert RpmKey.__init__.__doc__ is not None

# Generated at 2022-06-11 07:50:54.704380
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    t = RpmKey(None)
    assert t.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert t.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert t.normalize_keyid('DEADB33F') == 'DEADB33F'
    assert t.normalize_keyid(' DEADB33F ') == 'DEADB33F'

# Generated at 2022-06-11 07:51:00.410355
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = MockAnsibleModule()
    rpm_key = RpmKey(module)
    keyfile = "/tmp/key_file"
    rpm_key.import_key(keyfile)    
    module.run_command.assert_called_with(['rpm', '--import', keyfile], use_unsafe_shell=True)


# Generated at 2022-06-11 07:51:08.865204
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.six.moves.mock import Mock, patch
    module = Mock()
    module.params = {
        'fingerprint': None,
        'state': 'present',
        'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
        'validate_certs': True
    }
    module.get_bin_path.return_value = Mock()
    module.add_cleanup_file = Mock()
    module.cleanup = Mock()
    module.fail_json = Mock()
    module.exit_json = Mock()
    RpmKey(module)
    assert module.cleanup.called
    assert module.exit_json.called

# Generated at 2022-06-11 07:51:20.679588
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from ansible.module_utils.six import BytesIO


# Generated at 2022-06-11 07:51:30.445926
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )
    rp = RpmKey(module)
    fd, key_file = tempfile.mkstemp()
    with os.fdopen(fd, "w+b") as tmpfile:
        key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\n\nsomething\n-----END PGP PUBLIC KEY BLOCK-----\n\n"
        tmpfile.write(key)
    tmpfile.close()

# Generated at 2022-06-11 07:51:40.267320
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from unittest.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os.path

    class FakeResponse:
        def __init__(self, body):
            self.body = body

        def read(self):
            return self.body

    def fake_fetch_url(module, url):
        if url == 'http://example.com/get_key':
            response = FakeResponse(key)
            info = {
                "status": 200,
                "msg": "OK"
            }
        else:
            response = None
            info = {
                "status": 404,
                "msg": "Not Found"
            }

        return response, info


# Generated at 2022-06-11 07:51:49.207182
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.run_command = lambda cmd: (0, '', '')

# Generated at 2022-06-11 07:53:04.610424
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    modules_mock = MagicMock()
    modules_mock.get_bin_path.return_value = '/bin/rpm'
    modules_mock.check_mode = True
    module = type('', (), {'run_command': MagicMock()})()
    module.run_command.return_value = (0, '', '')
    setattr(module, 'get_bin_path', modules_mock.get_bin_path)
    setattr(module, 'check_mode', modules_mock.check_mode)
    rpm = type('', (), {'module': module})()
    rpm.gpg = '/bin/gpg'
    rpm.drop_key('0xDEADBEEF')

# Generated at 2022-06-11 07:53:11.071619
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    # setup
    keyid = 'DEADBEEF'
    stdout = 'foo:6::::::bar:gpg-pubkey-%s-foo:::bar:bar:bar:bar:bar:bar:bar:bar:bar:bar:bar:bar:bar::\n' % keyid[-8:]
    stderr = 'stderr'
    module = Mock(run_command=Mock(return_value=(0, stdout, stderr)))
    rpmkey = RpmKey(module)

    # test
    assert rpmkey.is_key_imported(keyid)



# Generated at 2022-06-11 07:53:16.092685
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    gpg_path = "/usr/bin/gpg"
    rpm_key = RpmKey(module)
    gpg = "mock"
    rpm_key.gpg = gpg
    rpm_key.module = module
    tmpfd, tmpname = tempfile.mkstemp()
    rpm_key.module

# Generated at 2022-06-11 07:53:24.842025
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Unit test to ensure that the method RpmKey.fetch_key is working correctly
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    key = RpmKey(module)
    my_key = key.fetch_key('https://fedoraproject.org/static/0608B895.txt')
    # We hardcode this string as it is a constant in the fedoraproject.org page

# Generated at 2022-06-11 07:53:34.563720
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    # Mock class object
    class MockModule(object):
        def __init__(self, rc, stdout, stderr):
            class MockRunCommand(object):
                def __init__(self, rc, stdout, stderr):
                    self.rc = rc
                    self.stdout = stdout
                    self.stderr = stderr
                def run_command(self, cmd, use_unsafe_shell):
                    return self.rc, self.stdout, self.stderr
            self.run_command = MockRunCommand(rc, stdout, stderr)

    # Case 1: No key installed on the system
    rpm_key = RpmKey(MockModule(1, "", "error"))
    assert rpm_key.is_key_imported("1234abcd")==False

    # Case

# Generated at 2022-06-11 07:53:40.985599
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create test RpmKey
    rpm_key = RpmKey(AnsibleModule({}))
    # Test run_command fails (sanity test)
    # since run_command() is mocked
    rpm_key.run_command = lambda cmd: (0, '', '')
    assert rpm_key.run_command(['rpm', '--import', '/keyfile/1']) == (0, '', '')
    assert rpm_key.import_key('/keyfile/1') is None


# Generated at 2022-06-11 07:53:52.548969
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # This unit test is only run when a test environment is specified in the
    # Makefile.

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.urls import ConnectionError


# Generated at 2022-06-11 07:53:57.958035
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)



# Generated at 2022-06-11 07:54:05.085008
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
    )
    module.run_command = run_command_mock
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported("01234567")
    assert not rpm_key.is_key_imported("01234568")

# Generated at 2022-06-11 07:54:09.429586
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)