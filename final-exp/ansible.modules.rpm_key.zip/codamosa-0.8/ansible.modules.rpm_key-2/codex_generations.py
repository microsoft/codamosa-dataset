

# Generated at 2022-06-11 07:46:54.293631
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    # Test 1
    # key = http://apt.sw.be/RPM-GPG-KEY.dag.txt
    # expected_key = RPM-GPG-KEY.dag.txt

    rpm_key = RpmKey(None)

    key = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'

    expected_key = 'RPM-GPG-KEY.dag.txt'

    key_id = 'ED5FDF8A'

    actual_key = rpm_key.fetch_key(key)
    actual_key_id = rpm_key.getkeyid(actual_key)

    assert(expected_key) in actual_key
    assert(key_id) == actual_key_id



# Generated at 2022-06-11 07:47:06.307119
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test that calling the method is_key_imported on an object of class RpmKey returns True if the key is imported
    test_keyid = 'deadb33f'
    test_file = False
    test_rpm_stdout = 'gpg-pubkey-deadb33f-52a52ba6'
    test_rpm_stderr = ''
    test_rpm_rc = 1
    test_gpg_stdout = 'pub:u:4096:1:deadb33f:132456789012345:132456789012345::::u:::scESC:fpr:::::::::deadb33f:::::::::'
    test_gpg_stderr = ''
    test_gpg_rc = 1

# Generated at 2022-06-11 07:47:08.174715
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    fake_module = AnsibleModule({})
    fake_RpmKey = RpmKey(fake_module)
    stdout, stderr = fake_RpmKey.execute_command(["printf", "HELLO WORLD"])
    assert stdout == "HELLO WORLD"

# Generated at 2022-06-11 07:47:16.805371
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import re

    # We want to patch the module class to test the method using an
    # exception. We need the module.fail_json function but we don't want
    # to execute any of its code. We define a new function in the same
    # module and mock it.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    # We want to do some string manipulation in this module, we don't
    # want to execute any code.
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 07:47:28.297225
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # TODO(hector): add a proper test for this module
    class FakeModule(object):
        params = {
            'state': 'present',
            'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
            'fingerprint': 'EBC6E12C62B1C734026B21222A20E52146B8D79E6',
        }

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/'

        def get_bin_path(self, *args, **kwargs):
            return '/bin/bash'

        def run_command(self, cmd):
            return 0, '', ''

        def fail_json(self, *args, **kwargs):
            raise Exception()


# Generated at 2022-06-11 07:47:33.358984
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():

    assert is_keyid("0xDEADB33F")
    assert is_keyid("0x0xDEADB33F")
    assert is_keyid("DEADB33F")
    assert is_keyid("0xDEADB33F0")
    assert is_keyid("0x0xDEADB33F0")
    assert is_keyid("DEADB33F0")

    assert not is_keyid("0xSOMETHING")
    assert not is_keyid("SOMETHING")
    assert not is_keyid("SOMETHING0")

# Generated at 2022-06-11 07:47:43.019174
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from ansible.compat.tests import unittest
    moduleHelper = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    class MockAnsibleModule():
        def __init__(self, moduleHelper):
            self.params = moduleHelper.params

        def fail_json(self, msg):
            self.fail = True
            self.message = msg

    module = MockAnsibleModule(moduleHelper)
    keyid = 'DEADB33F'



# Generated at 2022-06-11 07:47:51.183610
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Mock some stuff from the ansible module library
    # For this test, only the parameters object is needed
    # The parameters object simulates the argparse from the module
    class Parameters(dict):
        def __init__(self):
            self['state'] = 'present'
            self['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
            self['fingerprint'] = '7a47 ae09 e6ab 69ba cdba  4c13 c1a0 f58f 79e6'

    class MockModule(object):
        def __init__(self):
            self.params = Parameters()

    # Mock the function to return a fake GPG Key

# Generated at 2022-06-11 07:48:01.326160
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import unittest

    class FakeModule:
        class FakeModuleOptions:
            def __init__(self, state="present", key="test", fingerprint="test", validate_certs=False):
                self.state = state
                self.key = key
                self.fingerprint = fingerprint
                self.validate_certs = validate_certs

        def __init__(self, params):
            self.params = self.FakeModuleOptions(**params)

    testcase = unittest.TestCase('__init__')

    rpm_key = RpmKey(FakeModule({}))

    testcase.assertEqual(rpm_key.normalize_keyid("test"), "TEST")
    testcase.assertEqual(rpm_key.normalize_keyid(" 0xtest "), "TEST")
    testcase.assertE

# Generated at 2022-06-11 07:48:07.571947
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # empty command
    res = RpmKey(module).execute_command([])
    assert res == ('', '')
    # existing command
    res = RpmKey(module).execute_command(['/bin/true'])
    assert res == ('', '')
    # non existing command
    with pytest.raises(SystemExit):
        RpmKey(module).execute_command(['/asdf/not/existing'])



# Generated at 2022-06-11 07:48:34.902742
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class Module(object):

        def __init__(self):
            self.params = dict(
                state=dict(type='str', default='present', choices=['absent', 'present']),
                key=dict(type='str', required=True, no_log=False),
                validate_certs=dict(type='bool', default=True),
            )
            self.check_mode = True

        def fail_json(self, **kwargs):
            assert False

        def exit_json(self, **kwargs):
            pass

        def add_cleanup_file(self, **kwargs):
            pass

        def cleanup(self, **kwargs):
            pass


# Generated at 2022-06-11 07:48:41.804888
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    r = RpmKey(AnsibleModule(argument_spec={}))
    assert r.normalize_keyid('0x01234567') == '01234567'
    assert r.normalize_keyid('0X01234567') == '01234567'
    assert r.normalize_keyid(' 01234567 ') == '01234567'
    assert r.normalize_keyid('01234567') == '01234567'
    assert r.normalize_keyid('0x01234568') == '01234568'

# Generated at 2022-06-11 07:48:47.091497
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    rpmkey = RpmKey("fake module")

    keyfile = "tests/testdata/RPM-GPG-KEY-redhat-beta"
    fingerprint = "758C9E83B3D3E13F13C5D793B57B92B4497D824B"

    assert fingerprint == rpmkey.getfingerprint(keyfile)

# Generated at 2022-06-11 07:48:58.671636
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(m)
    assert rpm_key.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("0XDEADB33F") == "DEADB33F"

# Generated at 2022-06-11 07:49:06.172895
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import io
    import pytest
    from ansible.module_utils.six.moves import StringIO

    class MockModule:
        class RunResult:
            def __init__(self, returncode, stdout, stderr):
                self.returncode = returncode
                self.stdout = stdout
                self.stderr = stderr

        def __init__(self, options, checkmode=False):
            self.options = options
            self.checkmode = checkmode
            self.cleanup_file_datas = []

        def run_command(self, args, shell=True):
            assert args[0] == 'gpg'
            assert args[1] == '--no-tty'
            assert args[2] == '--batch'
            assert args[3] == '--with-colons'


# Generated at 2022-06-11 07:49:17.964378
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    class fake_module(object):
        def __init__(self):
            self.run_command_called = False
            self.cleanup_called = False
            self.add_cleanup_file_called = False
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''
            self.run_command_input = []
            self.cleanup_files = []

        def run_command(self, input, use_unsafe_shell=True):
            self.run_command_called = True
            self.run_command_input = input
            return self.run_command_rc, self.run_command_stdout, self.run_command_stderr

        def cleanup(self, path):
            self.cleanup_called = True

# Generated at 2022-06-11 07:49:29.073606
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():

    from ansible.modules.packaging.os.rpm_key import RpmKey
    import tempfile
    import os

    expected_fingerprint = "4D42 D984 C7B4 0F34 7E0A  1E3E 7AA2 51A9 5233 7A1A"

    # Create a test file and write the key in it
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-11 07:49:39.371290
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ))
    rpmkey = RpmKey(test_module)
    assert rpmkey.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert rpmkey.normalize_keyid("DEADB33F") == "DEADB33F"
    assert rpmkey.normalize_keyid("0xDEADB33F ") == "DEADB33F"

# Generated at 2022-06-11 07:49:47.004194
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = MockAnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.module == module
    assert rpmkey.rpm == 'rpm'
    assert rpmkey.gpg == 'gpg'


# Generated at 2022-06-11 07:49:54.786772
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a mock of class RpmKey
    rpm_key_class_mock = mock.Mock(spec=RpmKey)
    rpm_key_class_mock.module.check_mode = False
    # Give the mocked execute_command method a return value of 0
    rpm_key_class_mock.execute_command.return_value = (0, '', '')
    # Call the method drop_key with dummy parameters
    mock_drop_key = rpm_key_class_mock.drop_key('deadb33f')
    # Assert that the method execute_command has been called with the correct parameters
    rpm_key_class_mock.execute_command.assert_called_with(['rpm', '--erase', '--allmatches', 'gpg-pubkey-0b8d79e6'])

# Generated at 2022-06-11 07:50:36.345497
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)

    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid(' DEADBEEF ') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF ') == 'DEADBEEF'

# Generated at 2022-06-11 07:50:47.838699
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    from ansible.modules.packaging.os import rpm_key
    with mock.patch.object(rpm_key.AnsibleModule, "__init__", return_value=None) as module:
        rpmkey = rpm_key.RpmKey(module)
        assert rpmkey.normalize_keyid("0xdeadbeef") == "DEADBEEF"
        assert rpmkey.normalize_keyid(" 0xdeadbeef ") == "DEADBEEF"
        assert rpmkey.normalize_keyid("deadbeef") == "DEADBEEF"
        assert rpmkey.normalize_keyid(" DEADBEEF") == "DEADBEEF"
        assert rpmkey.normalize_keyid("0Xdeadbeef") == "DEADBEEF"
        assert rpmkey

# Generated at 2022-06-11 07:50:53.610063
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    key_file_path = 'tests/getkeyid_gpg_key'
    key_id = 'DEADB33F'

    rpm_key = RpmKey(None)
    rpm_key.gpg = 'gpg'
    assert rpm_key.getkeyid(key_file_path) == key_id
    del rpm_key

# Generated at 2022-06-11 07:51:04.104205
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    """
    Checks if the key is imported on the local rpm db
    """
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.is_key_imported(rpmkey.getkeyid("unit_tests/public-key.gpg"))



# Generated at 2022-06-11 07:51:11.212022
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

# Generated at 2022-06-11 07:51:23.307385
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import tempfile
    import os
    test = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/library/rpm_key'
    print(test)

    # Tests fetch_key with a valid url, returns a path and key is present in the file
    class FakeModule:
        def __init__(self):
            self.params = dict()
            self.params['key'] = 'https://kb.gazzang.com/kb/attachments/19/Gazzang-GPG-KEY'
            self.params['state'] = 'present'


# Generated at 2022-06-11 07:51:31.782777
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module_mock = AnsibleModule({})
    obj = RpmKey(module_mock)
    cases = (("0xDeadbeef", "DEADBEEF"),
             ("Deadbeef", "DEADBEEF"),
             ("0XDeadbeef", "DEADBEEF"),
             (" 0xDeadbeef", "DEADBEEF"),
             (" 0XDeadbeef", "DEADBEEF"),
             ("0xDeadbeef ", "DEADBEEF"),
             ("0XDeadbeef ", "DEADBEEF"),
             (" 0xDeadbeef ", "DEADBEEF"),
             (" 0XDeadbeef ", "DEADBEEF"))
    for c in cases:
        assert obj.normalize_keyid(c[0]) == c[1]

#

# Generated at 2022-06-11 07:51:41.639675
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule

    class MyAnsibleModule(AnsibleModule):
        def run_command(self, cmd):
            return "1", "success", ""

    my_ansible_module = MyAnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(my_ansible_module)
    result = rpm_key.execute_command([1, 2, 3])

# Generated at 2022-06-11 07:51:50.171915
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class DummyModule(object):
        def __init__(self):
            self.check_mode = False

        def run_command(self, cmd, use_unsafe_shell=True):
            # Check if execute_command is called with the right arguments
            assert cmd == ['rpm', '--import', 'keyfile']
            return 0, 'Success', None

    class DummyRpmKey(RpmKey):
        def __init__(self, module):
            self.module = module
            self.rpm = 'rpm'

    dummy_module = DummyModule()
    dummy_module.check_mode = False
    dummy_rpm_key = DummyRpmKey(dummy_module)
    dummy_rpm_key.import_key('keyfile')

    dummy_module.check_mode = True

# Generated at 2022-06-11 07:51:56.574310
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import inspect
    import module_utils.action_plugins.rpm_key as rpm_key
    a = rpm_key.RpmKey(None)
    assert a.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert a.normalize_keyid(' 0xDEADB33F  ') == 'DEADB33F'
    assert a.normalize_keyid('deadb33f') == 'DEADB33F'
    assert a.normalize_keyid(' 0xDEADB33F  ') == 'DEADB33F'

# Generated at 2022-06-11 07:53:08.957194
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    fake_module = Mock(name='fake_module')
    fake_module.run_command = Mock(return_value=(0, 'stdout', 'stderr'))
    gpg_obj = RpmKey(fake_module)
    cmd = ['gpg', '--batch', '--batch']
    assert gpg_obj.execute_command(cmd) == ('stdout', 'stderr')
    fake_module.run_command.assert_called_with(cmd)


# Generated at 2022-06-11 07:53:20.164193
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    python_code = None
    # If it is python 3, we need to get the python code from the module to test
    if PY3:
        from importlib.util import spec_from_loader, module_from_spec

        spec = spec_from_loader('rpm_key',
                                loader=RpmKey.__module__+'.'+RpmKey.__name__)
        module = module_from_spec(spec)
        spec.loader.exec_module(module)

# Generated at 2022-06-11 07:53:30.640380
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    """ Unit test for method import_key of class RpmKey """

    class AnsibleModuleMock(object):
        """ Mock class for ansible modules """

        def __init__(self):
            self.changed = False
            self.check_mode = False
        def execute_command(self, cmd):
            """ Mock method for executing a command """
            if cmd[0] == 'rpm':
                if cmd[3] == '--import':
                    self.changed = True
                    return (0, '', '')
        def fail_json(self, msg):
            """ Mock method for failing with msg """
            raise Exception(msg)
        def add_cleanup_file(self, file):
            """ Mock method for adding a cleanup file """
            pass


# Generated at 2022-06-11 07:53:40.270027
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    assert rpm_key.is_keyid("0xDEADB33F") == True
    assert rpm_key.is_keyid("DEADB33F") == True
    assert rpm_key.is_keyid("deadb33f") == True
    assert rpm_key.is_keyid("0XDEADB33F") == True



# Generated at 2022-06-11 07:53:50.619940
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    class MockModule(object):
        def add_cleanup_file(self, tmpname):
            pass
    class MockRsp(object):
        def read(self):
            return "-----BEGIN PGP PUBLIC KEY BLOCK-----"
    class MockInfo(object):
        def __init__(self):
            self.status = 200

    module = MockModule()
    rsp = MockRsp()
    info = MockInfo()

    rpmkey = RpmKey(module)

    rpmkey.fetch_key = rpmkey.fetch_key(url="http://apt.sw.be/RPM-GPG-KEY.dag.txt")
    assert is_pubkey(key=rpmkey.fetch_key())

# Generated at 2022-06-11 07:53:59.450008
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # setup
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    # Test case 1: Valid keyid
    assert rpm_key.normalize_keyid("0x604B946E") == "604B946E"
    # Test case 2: Valid keyid
    assert rpm_key.normalize_keyid("0x604B946E") == "604B946E"
    #

# Generated at 2022-06-11 07:54:08.345866
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm = RpmKey(module)
    assert rpm.normalize_keyid("0xDEADB33F") == "DEADB33F", \
        "Unexpected keyid returned"
    assert rpm.normalize_keyid(" DEADB33F") == "DEADB33F", \
        "Unexpected keyid returned"


# Generated at 2022-06-11 07:54:16.934795
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import textwrap

    # Arrow keys
    assert RpmKey._RpmKey__is_key_imported(None, '0x2e3e1c3b3d3f0e3e')

    # Home keys
    assert RpmKey._RpmKey__is_key_imported(None, '0x7a9f93903fd7201b')

    # End keys
    assert RpmKey._RpmKey__is_key_imported(None, '0x8e745d51b3d05b8a')

    # Pagedown key
    assert RpmKey._RpmKey__is_key_imported(None, '0x86cdd2d2c26587a3')

    # Pageup key

# Generated at 2022-06-11 07:54:23.749310
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    class Module(object):
        pass

    class Rpmmodule(object):
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    module = Module()
    module.run_command = run_command
    module.check_mode = False
    module.params = dict(
        state='present',
        key='_KEY_',
    )

    rpmmodule = Rpmmodule()
    module.get_bin_path = lambda x, y: 'rpm'
    setattr(module, 'rpm', rpmmodule)

    keyid = RpmKey(module)
    assert True == keyid.is_keyid('0xAE21A7C4')

# Generated at 2022-06-11 07:54:32.434096
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import ansible.module_utils.action
    mock_module = ansible.module_utils.action.AnsibleModule(argument_spec={})
    mock_module.get_bin_path = lambda x: ""

    # Method getfingerprint must return one of these values
    always_return = [
        'EBC6E12C62B1C734026B2122A20E52146B8D79E6',
        'EB6E12C62B1C734026B2122A20E52146B8D7A9E6'
    ]

    from ansible.modules.packaging.os import rpm_key
    # mock the gpg executable so we can control the output
    class MockPopen():
        def __init__(self, *args, **kwargs):
            self.args = args
           