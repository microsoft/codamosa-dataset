

# Generated at 2022-06-20 22:25:07.426772
# Unit test for function is_pubkey
def test_is_pubkey():
    assert True == is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n')
    assert False == is_pubkey('-----BEGIN PGP PRIVATE KEY BLOCK-----\n-----END PGP PRIVATE KEY BLOCK-----\n')
    assert False == is_pubkey('-----BEGIN PGP SIGNATURE-----\n-----END PGP SIGNATURE-----\n')
    assert False == is_pubkey('-----BEGIN PGP MESSAGE-----\n-----END PGP MESSAGE-----\n')
    assert False == is_pubkey('-----BEGIN PGP KEY BLOCK-----\n-----END PGP KEY BLOCK-----\n')

# Generated at 2022-06-20 22:25:15.448588
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    """Test that execute_command returns expected output."""
    module = ansible.builtin.rpm_key.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,)
    key = 'testkey'
    RpmKey.execute_command(key)

# Generated at 2022-06-20 22:25:24.980861
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # Create a dummy module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = self.fail

        def fail(self, msg):
            raise AssertionError(msg)

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, 'stdout', 'stderr'
    module = MockModule()

    # Check command is successful
    rpm_key = RpmKey(module)
    stdout, stderr = rpm_key.execute_command([rpm_key.rpm, '-q', 'gpg-pubkey'])
    assert stdout == 'stdout'
    assert stderr == 'stderr'
    assert stdout is not None
    assert stderr is not None

    # Command fails

# Generated at 2022-06-20 22:25:37.145464
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    key_id = 'DeadB33F'

# Generated at 2022-06-20 22:25:47.352639
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module_orig = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Test 1: Assert that the keyid is passed correctly
    def execute_command(*cmd):
        rc, stdout, stderr = module_orig.run_command(cmd, use_unsafe_shell=True)
        if rc != 0:
            module_orig.fail_json(msg=stderr)
        return stdout, stderr


# Generated at 2022-06-20 22:25:47.944699
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    assert True

# Generated at 2022-06-20 22:25:55.743600
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpm_key = RpmKey(None)
    # keyid 0xDEADB33F
    assert rpm_key.normalize_keyid("  0xDEADB33F     ") == "DEADB33F"
    assert rpm_key.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("0XDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("DEADB33F") == "DEADB33F"

# Generated at 2022-06-20 22:26:02.885800
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    x = RpmKey(module)
    print(x.drop_key(keyid='AAD6B9B6'))

# Generated at 2022-06-20 22:26:10.198342
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    ''' Unit test for method getkeyid of class RpmKey '''
    module = AnsibleModule(argument_spec={})
    rpm_key = RpmKey(module)

    ret = rpm_key.getkeyid('test/files/test_key.gpg')
    assert(ret == 'DEADB33F')

    ret = rpm_key.getkeyid('test/files/test_key2.gpg')
    assert(ret == '66D74B1B')


# Generated at 2022-06-20 22:26:17.880046
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from unittest.mock import patch
    import io
    import sys

    # Create a shell object
    class Shell:
        pass

    shell = Shell()
    shell.module = Shell()
    shell.module.run_command = Shell()

    # mock run_command so it returns something predictable
    def mock_run_command(shell, cmd):
        return (1, "stderr", "stdout")

    shell.module.run_command.side_effect = mock_run_command

    with patch.object(sys, 'exit') as exit:
        with patch.object(io, 'open') as open:
            open.side_effect = FileNotFoundError()
            shell.rpm = '/bin/rpm'
            shell.gpg = '/bin/gpg'
            # Catch the exception and make sure it's of the right

# Generated at 2022-06-20 22:26:37.931454
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    keyid = 'deadbeef'
    rpm_key.drop_key(keyid)

# Generated at 2022-06-20 22:26:45.766760
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-20 22:26:56.565660
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = tempfile.mkstemp()[1]
    print(keyfile)

# Generated at 2022-06-20 22:27:08.281997
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os.path
    import unittest
    import tempfile

    class MockModule:
        def __init__(self):
            self.params = {
                'key': 'https://www.gazzang.com/static/files/Gazzang-GPG-KEY',
                'validate_certs': 'yes'
            }
            self.add_cleanup_file_called = False
            self.add_cleanup_file_filename = ''

        def fail_json(self, msg):
            raise Exception(msg)

        def get_bin_path(self, binary, required=True):
            if binary == "gpg2":
                return "/usr/bin/gpg2"
            else:
                raise Exception("get_bin_path called with unexpected binary: %s" % binary)


# Generated at 2022-06-20 22:27:08.637006
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    assert true

# Generated at 2022-06-20 22:27:11.654628
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = '0xdeadb33f'
    expected = 'deadb33f'
    assert RpmKey(None).normalize_keyid(keyid) == expected

# Generated at 2022-06-20 22:27:19.477301
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a RpmKey object
    m = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        )
    )
    rpm_key = RpmKey(m)
    rpm_key.module.get_bin_path = mock_get_bin_path
    rpm_key.execute_command = mock_execute_command
    # Call method drop_key
    rpm_key.drop_key('deadbeef')
    assert rpm_key.execute_command.call_args[0][0][1] == '--erase'

# Generated at 2022-06-20 22:27:33.174481
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from io import BytesIO
    from ansible.module_utils.six import text_type


# Generated at 2022-06-20 22:27:44.093623
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    test_class = RpmKey(_AnsibleModuleMock())
    test_method_name = 'getkeyid'

    # Test with valid key
    fake_key = _create_fake_key()
    result = test_class.getkeyid(fake_key)
    assert result == 'D5E0583418F3E3E3'

    # Test with non valid key
    fake_key = _create_fake_key()
    fake_key += '\n' + 'garbage_data'
    result = test_class.getkeyid(fake_key)
    assert result == 'D5E0583418F3E3E3'



# Generated at 2022-06-20 22:27:53.593257
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    import os
    # Prepare tests
    fd1, temp1 = tempfile.mkstemp()
    temp1_fp = os.fdopen(fd1, 'w')
    temp1_fp.write('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n')

# Generated at 2022-06-20 22:28:33.694181
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    params = {'key': '0xDEADB33F', 'state': 'present'}

    m = basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    key = '0xDEADB33F'
    m.params = params
   

# Generated at 2022-06-20 22:28:42.778514
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = mock.MagicMock()
    module.check_mode=False

# Generated at 2022-06-20 22:28:46.072648
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    keystr = '0xDEADB33F'
    rpm_key = RpmKey('')
    assert rpm_key.is_keyid(keystr) is True

# Generated at 2022-06-20 22:28:55.433186
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    key_id = "DEADBEEF"
    rpm_key = RpmKey(module)
    key_file_path = os.path.join(tempfile.tempdir, "test_RpmKey_is_key_imported.gpg")
    with open(key_file_path, 'w') as key_file:
        key_file.write

# Generated at 2022-06-20 22:28:56.081295
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert True

# Generated at 2022-06-20 22:29:04.694670
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid("0x12345678")
    assert rpm_key.is_keyid("0X23456789")
    assert rpm_key.is_keyid("abcdef12")
    assert rpm_key.is_keyid("1234")

# Generated at 2022-06-20 22:29:17.158703
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module_mock = MagicMock()
    module_mock.check_mode = False
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.return_value = ''

    # If the key is a url, we need to check if it's present to be idempotent,
    # to do that, we need to check the keyid, which we can get from the armor.
    fake_key_id = '0x8CF730A0C4B4B3B3'
    fake_fingerprint = '1B65E0A13C8B8385'


# Generated at 2022-06-20 22:29:27.342774
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    import sys
    from types import ModuleType
    from io import StringIO

    # Capture output from print statements
    stdout = sys.stdout
    sys.stdout = StringIO()

    # CREATE AN INSTANCE OF THE CLASS
    import ansible.modules.packaging.os.rpm_key as rpm_key
    x = rpm_key.RpmKey(ModuleType('test'))

    # UNIT UNDER TEST
    func_ut = x.is_keyid

    # CHECK EXPECTED OUTPUT
    print(func_ut('0xDEADBEEF'))
    assert sys.stdout.getvalue().strip() == 'True'

    # CHECK EXPECTED OUTPUT
    print(func_ut('0x DEADBEEF'))
    assert sys.stdout.getvalue().strip() == 'False'

# Generated at 2022-06-20 22:29:34.266453
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile
    # Creating a temporary file to store a pubkey

# Generated at 2022-06-20 22:29:36.787399
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    test_object = RpmKey('')
    assert test_object.is_key_imported('A0E969B5') == False


# Generated at 2022-06-20 22:30:43.442276
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    class MockModule(object):
        def is_key_imported(self):
            return True

        def run_command(self, cmd):
            return (0, 0, 0)

    class MockModuleNew(object):
        def is_key_imported(self):
            return False

        def run_command(self, cmd):
            return (0, 0, 0)

    # call normalize_keyid with keyid having leading zeros
    module1 = MockModule()
    rpm1 = RpmKey(module1)
    assert rpm1.normalize_keyid('0x0001020') == '1020'

    # call normalize_keyid with keyid having leading zeroes and spaces and X
    module2 = MockModule()
    rpm2 = RpmKey(module2)
    assert rpm2.normalize_key

# Generated at 2022-06-20 22:30:44.704115
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert RpmKey != None

# Generated at 2022-06-20 22:30:47.027701
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    assert RpmKey.is_key_imported(0x6901bb4e) == True


# Generated at 2022-06-20 22:30:56.480869
# Unit test for method drop_key of class RpmKey

# Generated at 2022-06-20 22:31:07.066779
# Unit test for function is_pubkey
def test_is_pubkey():
    import ansible.module_utils.rpm_key
    assert ansible.module_utils.rpm_key.is_pubkey(u'-----BEGIN PGP PUBLIC KEY BLOCK-----\n') == False
    assert ansible.module_utils.rpm_key.is_pubkey(u'\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n') == False
    assert ansible.module_utils.rpm_key.is_pubkey(u'\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----') == True
    assert ansible.module_utils.rpm_key.is_pubkey(u'\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n') == True
    assert ansible.module_utils.rpm_key.is_pub

# Generated at 2022-06-20 22:31:10.560003
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = 'test_getkeyid.gpg'
    key = RpmKey(keyfile)
    keyid = key.getkeyid(keyfile)
    assert keyid == 'FAD3C9CC'



# Generated at 2022-06-20 22:31:22.660671
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import mock

    # Instantiate an instance of RpmKey
    rpm_key = RpmKey(mock.MagicMock)

    # Test the method normalize_keyid
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('deadbeef') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('deadbeef  ') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('  deadbeef') == 'DEADBEEF'

# Generated at 2022-06-20 22:31:26.000065
# Unit test for function main
def test_main():

    import mock

    # Unit test for function main
    @mock.patch('rpm_key.RpmKey')
    def test_main_1(mock_rpm_key):

        main()
        assert mock_rpm_key.called

# Generated at 2022-06-20 22:31:33.215897
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create test instance of AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create test instance of RpmKey
    rpmkey = RpmKey(module)

    # Test to cause RuntimeError because rpm is not installed on system and required is True
    def test_get_bin_path_missing_required():
        rpmkey.rpm = None
        rpmkey.gpg = None
        with pytest.raises(RuntimeError):
            rpm

# Generated at 2022-06-20 22:31:37.389355
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    """
    This method is unit tested by testing the underlying method execute_command.
    It is not possible to unit test method drop_key directly as it calls other methods.
    """
    pass

# Generated at 2022-06-20 22:34:03.921730
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module=AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    object = RpmKey(module)
    object.drop_key("deadb33f")
    print("test_RpmKey_drop_key complete")


# Generated at 2022-06-20 22:34:05.449775
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    test = RpmKey(None)
    assert test.getfingerprint("fingerprint") == "fingerprint"

# Generated at 2022-06-20 22:34:10.908588
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    # Using a fake url to obtain a test key
    url = "http://pastebin.com/raw/NsRU6n9M"
    tmpfile = '/tmp/tmpLIiOsA'

    # Create a test instance to use the method
    rpm_key = RpmKey(None)

    # Assert the file contain a valid key
    assert rpm_key.fetch_key(url) == tmpfile
    assert is_pubkey(open(tmpfile).read())

    # Cleanup
    os.unlink(tmpfile)


# Generated at 2022-06-20 22:34:19.450523
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\nSome key\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\nSome key\n-----END PGP PUBLIC KEY BLOCK---')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK\nSome key\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK Some key\n-----END PGP PUBLIC KEY BLOCK-----')

# Generated at 2022-06-20 22:34:31.416053
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    """ Unit test for the method RpmKey.execute_command """
    import sys
    import ansible.module_utils.basic as basic
    import ansible.module_utils.urls as urls
    import ansible.module_utils._text as text
    reload(basic)
    reload(urls)
    reload(text)
    import ansible.module_utils.basic as basic
    import ansible.module_utils.urls as urls
    import ansible.module_utils._text as text
    reload(basic)
    reload(urls)
    reload(text)
    import os.path
    import tempfile
    import re
    import json
    import os
    import distutils.spawn
    import sys
    package_dir = './'
    sys.path.append(package_dir)

# Generated at 2022-06-20 22:34:32.419755
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    pass

# Generated at 2022-06-20 22:34:39.334192
# Unit test for function main
def test_main():
    import ansible.utils.template as template
    module = AnsibleModule(argument_spec={
        'key': dict(type='str', required=True, no_log=False),
        'state': dict(type='str', default='present'),
    })
    template.template("{{ rpm_key(state='present', key='0x97148360') }}", module, source_file=None, source_template=None, source_encoding=None, destination_encoding=None)

