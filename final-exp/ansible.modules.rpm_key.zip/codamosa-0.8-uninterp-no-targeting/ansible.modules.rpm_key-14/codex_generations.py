

# Generated at 2022-06-20 22:25:09.980407
# Unit test for constructor of class RpmKey

# Generated at 2022-06-20 22:25:21.110725
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import os.path
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)
    key_file = tmpname

    os.remove(tmpname)
    module.params['state'] = 'absent'
    module.params['key'] = 'an_invalid_keyid'

# Generated at 2022-06-20 22:25:21.825675
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    pass

# Generated at 2022-06-20 22:25:24.854195
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:25:36.994884
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import url_utils
    from ansible.module_utils import action_common_attributes
    from ansible.module_utils._text import to_text
    import sys

    def test_url_fetch_url():
        r = url_utils.fetch_url(None, 'http://fakeurl')
        assert r[0].read() == 'This is a test'

    from ansible.module_utils.six import PY3
    if not PY3:
        test_url_fetch_url()

    # Replace the get_bin_path method with one that mocks it
    def test_get_bin_path(self, name, required=False):
        return 'rpm'

    real_get_bin_path = basic.AnsibleModule

# Generated at 2022-06-20 22:25:45.601023
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Test for normalize_keyid with arguments: 'DEADB33F'
    # This test does not run in systems where a gpg command is not installed
    if not os.path.exists('/usr/bin/gpg'):
        pytest.skip('Test not possible without gpg')
    class TestModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, msg=None):
            print(msg)
    rk = RpmKey(TestModule())
    assert rk.normalize_keyid('DEADB33F') == 'DEADB33F'



# Generated at 2022-06-20 22:25:49.738571
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Assign
    import ansible.modules.packaging.os.rpm_key as rpm_key
    module = rpm_key.AnsibleModule(argument_spec={})
    rpm = rpm_key.RpmKey(module)

    # Act
    actual = rpm.is_keyid('0x1234')

    # Assert
    assert actual == True


# Generated at 2022-06-20 22:25:57.764398
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    r = RpmKey(module)
    assert r.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-20 22:26:03.879521
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import shutil
    import tempfile
    from ansible.module_utils.urls import fetch_url

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)

    # Get a valid key
    url = "https://keys.gnupg.net/pks/lookup?op=get&search=0xD94AA3F0EFE21092"
    tmpfd, tmpname = tempfile.mk

# Generated at 2022-06-20 22:26:10.886105
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Fail if no module file
    if not os.path.isfile('/tmp/test_RpmKey_drop_key.py'):
        sys.stderr.write('Error: No module file found')
        sys.exit(1)

    # set up module args and import the module
    args = dict(
            state='absent',
            key='0xDEADBEEF',
            validate_certs=True,
            )
    module_name='/tmp/test_RpmKey_drop_key.py'
    sys.path.append(os.path.dirname(module_name))


# Generated at 2022-06-20 22:26:35.188337
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create an instance of the module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str', default=''),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )

    # Create an instance of the class
    rk = RpmKey(module)

    # Create an test key file

# Generated at 2022-06-20 22:26:44.234153
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import subprocess
    class MockModule(object):
        def __init__(self):
            self.check_mode = False
            self.debug = False
            self.params = {'task': {}}
            self.tmpdir = ''
            self.tmpdir = ''

        def run_command(self, cmd, use_unsafe_shell=False):
            with tempfile.TemporaryFile(buffering=1) as stdout:
                with tempfile.TemporaryFile(buffering=1) as stderr:
                    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, shell=use_unsafe_shell)
                    stdout.seek(0)
                    stderr.seek(0)
                    stdout_data = stdout.read

# Generated at 2022-06-20 22:26:54.962637
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict

    KEYID = '0xDEADBEEF'

    module = basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)
    assert(RpmKey.is_keyid(KEYID) == True)

# Generated at 2022-06-20 22:26:59.466146
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    m = AnsibleModuleStub()
    rk = RpmKey(m)

    assert_equal(rk.module.check_mode, True)
    rk.drop_key("12345678")
    assert_equal(m.run_command_called_args, [['rpm --erase --allmatches gpg-pubkey-12345678']])



# Generated at 2022-06-20 22:27:10.925730
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class FakeModule:
        params = {}
        def __init__(self):
            self.params = { "key": "DEADB33F", "fingerprint": "0123 4567 89AB CDEF 0123  4567 89AB CDEF 0123 4567"}
            self.check_mode = False
            self.gpg = "gpg"
            self.rpm = "rpm"

        def fail_json(self, msg):
            print(msg)
            raise Exception(msg)

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, use_unsafe_shell=True):
            return (0, "encontrado\n", "")

    key = RpmKey(FakeModule())

# Generated at 2022-06-20 22:27:12.826684
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
  keyfile = 'keys/RPM-GPG-KEY-dag'
  keyid = '8b77786d'
  rpmkey = RpmKey({})
  assert rpmkey.getkeyid(keyfile) == keyid


# Generated at 2022-06-20 22:27:20.009805
# Unit test for function main
def test_main():
    os.environ['_ANSIBLE_CHECK_MODE'] = '1'
    os.environ['_ANSIBLE_DIFF'] = '1'
    os.environ['_ANSIBLE_FORCE_COLOR'] = '1'
    os.environ['HOME'] = '/tmp/home'
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LC_ALL'] = 'en_US.UTF-8'
    os.environ['_TMP_ACTION_NAME'] = 'unit test'
    os.environ['_TMP_MODULE_ARGS'] = '{"key": "http://apt.sw.be/RPM-GPG-KEY.dag.txt", "state": "present"}'

    assert os.path.isfile(__file__) == True

# Generated at 2022-06-20 22:27:33.626330
# Unit test for function main
def test_main():
    import ansible.module_utils.ansible_release

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def exit_json(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, key, required=False):
            if key == 'rpm':
                return '/bin/rpm'
            elif key == 'gpg':
                return '/bin/gpg'

        def run_command(self, cmd, use_unsafe_shell=True):
            self.command = cmd

    class MockAnsibleModule(object):
        import_module = ansible.module_utils.ansible_release
        import_module.__get

# Generated at 2022-06-20 22:27:45.742072
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return 'test'

        def exit_json(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def is_key_imported(self, *args, **kwargs):
            pass

        def getkeyid(self, *args, **kwargs):
            pass

        def add_cleanup_file(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 22:27:54.570214
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_module = AnsibleModule(argument_spec={})
    rp = RpmKey(test_module)
    assert rp.normalize_keyid("0x1234ABCD") == "1234ABCD"
    assert rp.normalize_keyid("0x1234ABCD ") == "1234ABCD"
    assert rp.normalize_keyid(" 0x1234ABCD") == "1234ABCD"
    assert rp.normalize_keyid("1234ABCD") == "1234ABCD"
    assert rp.normalize_keyid("1234abcd") == "1234ABCD"
    assert rp.normalize_keyid("1234ABCD\n") == "1234ABCD"

# Generated at 2022-06-20 22:28:31.389095
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    #importing module
    def fail_json(self=None, **kwargs):
        assert False
    def exit_json(self=None, **kwargs):
        pass
    #imports
    class Module:
        pass
    module = Module()
    setattr(module, "fail_json", fail_json)
    setattr(module, "exit_json", exit_json)
    import re
    import os.path
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    #instance
    rpmkey = RpmKey(module)
    #mocker
    rpmkey.is_keyid = lambda x: rpmkey.is_keyid(x)
   

# Generated at 2022-06-20 22:28:41.909488
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    p = mock.patch.object(RpmKey, 'normalize_keyid')
    normalize_keyid = p.start()
    normalize_keyid.return_value = 'aaaaaaaa'

    p = mock.patch.object(RpmKey, 'execute_command')
    exc = p.start()

    module = mock.Mock()
    module.check_mode = False
    r = RpmKey(module)

    # Test 1:
    # Precondition: check_mode is False
    #               module.run_command returns 0
    #               no output generated
    # Postcondition: execute_command is called
    module.run_command.return_value = (0, '', '')
    r.drop_key('aaaaaaaa')

# Generated at 2022-06-20 22:28:53.344141
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key_obj = RpmKey(module)
    cmd = ['rpm', '--import', "DEADB33F"]
    stdout, stderr = rpm_key_obj.execute_command(cmd)
    assert stdout == 'key DEADB33F is not available\n'



# Generated at 2022-06-20 22:29:02.608599
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class ModuleMock(object):
        def __init__(self):
            pass
        def run_command(self, cmd):
            self.cmd = cmd
            ret = True

# Generated at 2022-06-20 22:29:05.744805
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("something -----BEGIN PGP PUBLIC KEY BLOCK-----\nfoo\n-----END PGP PUBLIC KEY BLOCK-----")
    assert is_pubkey("something -----BEGIN PGP PRIVATE KEY BLOCK-----\nfoo\n-----END PGP PRIVATE KEY BLOCK-----")
    assert not is_pubkey("something -----BEGIN PGP PRIVATE KEY BLOCK-----\nfoo\n-----END PGP PUBLIC KEY BLOCK-----")

# Generated at 2022-06-20 22:29:14.814825
# Unit test for constructor of class RpmKey
def test_RpmKey():
    keyfile = "/path/to/key.gpg" # given by the user
    keyid = "710110F5"
    key = "710110F5" # given by the user
    fingerprint = ""
    state = "present"
    changed = False
    # Module as output

# Generated at 2022-06-20 22:29:25.704780
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec = {})

    my_fetch_key = RpmKey.fetch_key(RpmKey(mod), 'http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    with open(my_fetch_key, 'r') as fd:
        my_fetch_key_content = fd.read()
        assert '-----BEGIN PGP PUBLIC KEY BLOCK-----' in my_fetch_key_content
        assert '-----END PGP PUBLIC KEY BLOCK-----' in my_fetch_key_content

    mod.cleanup(my_fetch_key)

# Generated at 2022-06-20 22:29:33.008772
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # test when there is a key installed
    stdout = 'gpg-pubkey-f4a80eb5-4ea0261b'
    stderr = ''
    rc = 0
    module = DummyModule()
    rpmkey = RpmKey(module)
    rpmkey.execute_command = mock_execute_command(stdout, stderr, rc)
    rpmkey.is_key_imported('0x4ea0261b')
    # test when no key is installed
    stdout = ''
    stderr = 'rpmdb: Thread/process 1313/140349535245696 failed: Thread died in Berkeley DB library'
    rc = 1
    module = DummyModule()
    rpmkey = RpmKey(module)

# Generated at 2022-06-20 22:29:34.865254
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert RpmKey("test")

# Generated at 2022-06-20 22:29:41.946391
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    key_file = tempfile.mkstemp()[1]
    os.remove(key_file)
    key_url = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    module = AnsibleModule(argument_spec={'key': key_url})
    rpm_key = RpmKey(module)

    keyfile = rpm_key.fetch_key(key_url)
    assert keyfile is not None

    # Verify keyfile file contents is the same as the url contents
    url_contents = module.run_command([rpm_key.gpg, '--no-tty', '--batch', '--with-fingerprint', '--with-colons', key_url])[1]

# Generated at 2022-06-20 22:30:52.389613
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    '''
    Test drop_key method of RpmKey class
    '''
    # Key input data
    state = 'absent'
    key = "gpg-pubkey-1d25a36f-4dfb8206"
    fingerprint = None
    validate_certs = True

    # Test module object
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the execute command method

# Generated at 2022-06-20 22:30:55.394575
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('asdfasdfasdfasdfasdf')
    assert not is_pubkey('asdfasdfasdfasdfasdfadsfasdf')

# Generated at 2022-06-20 22:31:00.132380
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = MockAnsibleModule()
    RpmKey(module)
    # TODO: What do I do with this?
    #keyfile = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'public-key.txt')

# Generated at 2022-06-20 22:31:09.068194
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class MockModule:
        class FailJson:
            def __init__(self, msg):
                self.msg = msg
            def __call__(self, **args):
                print(self.msg)

        check_mode = True
        def exit_json(self, changed):
            self.exit_json_called = True
            print('exit_json called')
            print('changed: ' + str(changed))

        def fail_json(self, msg):
            self.fail_json_called = True
            print('fail_json called')
            print('msg: ' + str(msg))

        def execute_command(self, cmd):
            self.rc, self.stdout, self.stderr = 0, '', ''
            return self.rc, self.stdout, self.stderr


# Generated at 2022-06-20 22:31:19.967201
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    keyid_test = "0xDEADB33F"
    keyid = RpmKey(module).normalize_keyid(keyid_test)
    assert keyid == "DEADB33F"

# Generated at 2022-06-20 22:31:30.307789
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import sys
    sys.path.append("/home/matt/ansible/lib/ansible/module_utils")
    from ansible.module_utils.action_plugins.rpm_key import RpmKey
    module = FakeModule()
    RpmKeyClass = RpmKey(module)

    # Non 200 returns, should fail
    #fetch_url = mock.patch.object(RpmKey, 'fetch_url', autospec=True, return_value=(None, (info_return, "msg")))
    #with fetch_url as fetch_url_call:
        # RpmKeyClass.fetch_key("http://test/test/test.txt")
        # fetch_url_call.assert_called_once_with("http://test/test/test.txt")

    # Proper key
    # fetch_url =

# Generated at 2022-06-20 22:31:31.394578
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    my_rpm_key = RpmKey()
    my_rpm_key.drop_key()

# Generated at 2022-06-20 22:31:40.886310
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create test cases for empty output (no key installed on system)
    test_cases = [("", False)]

    # Create test cases appending a line with a key id
    for key in ["C734", "deadb33f", "E12C62B1"]:
        test_cases.append("uid:u:1440:2:%s::\n" % key, True)

    # Create test cases appending a line with a key id with a leading 0x
    for key in ["0XE12C62B1", "0xC734"]:
        test_cases.append("uid:u:1440:2:%s::\n" % key, True)


# Generated at 2022-06-20 22:31:48.826200
# Unit test for method getfingerprint of class RpmKey

# Generated at 2022-06-20 22:31:57.518500
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(test_module)

    assert rpm_key.is_key_imported('0x093CA1223D8AE2D8') == True
    assert rpm_key.is_key_imported('0xD8AE2D8093CA1223') == True


# Generated at 2022-06-20 22:34:41.504517
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import urllib3
    import time
    import textwrap

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import string_types as basestring
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves import http_client as httplib