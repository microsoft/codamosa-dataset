

# Generated at 2022-06-20 22:25:12.659601
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule({})
    rpm_key = RpmKey(module)

    # Test the gpg wrapper by getting the key id
    key_id = rpm_key.getkeyid('./test/testkey.txt')
    if key_id != 'A20E52146B8D79E6':
        sys.stderr.write(
            'Wrong key id returned from gpg wrapper; expected "A20E52146B8D79E6", but got "{0}"\n'.format(key_id)
        )
        err_cnt += 1

    # Test the gpg wrapper by getting the key fingerprint
    key_fingerprint = rpm_key.getfingerprint('./test/testkey.txt')

# Generated at 2022-06-20 22:25:23.667816
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os

    class mock_module(object):
        def fail_json(self, msg):
            return msg

    # Create a temporary file for testing
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # The key that will be stored in the file

# Generated at 2022-06-20 22:25:25.507163
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    RpmKey('url')
    fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')

# Generated at 2022-06-20 22:25:37.963502
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import os
    import tempfile

    class ModuleStub:
        def __init__(self):
            pass

        def fail_json(self, msg):
            raise Exception(msg)

        def get_bin_path(self, name, required=False):
            return "/usr/bin/%s" % name

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "", ""

    class RpmKeyStub(RpmKey):
        def __init__(self, module):
            pass

    class StubKeyFetcher:
        def __init__(self, module):
            pass

        def fetch_key(self, url):
            tmpfd, tmpname = tempfile.mkstemp()

# Generated at 2022-06-20 22:25:48.003406
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    class ModuleMock(object):
        def __init__(self, params):
            self.params = params
        def get_bin_path(self, bin, required=True):
            return bin
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "", ""
        def fail_json(self, msg):
            raise Exception(msg)
    # Test 1
    keyid_input = "0xDEADB33F"
    keyid_expected = "DEADB33F"
    keyid_output = RpmKey(ModuleMock({"key": None, "fingerprint": None})).normalize_keyid(keyid_input)
    assert keyid_output == keyid_expected

    # Test 2
    keyid_input = "0XDEADB33F"

# Generated at 2022-06-20 22:25:54.689892
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.six.moves.mock import Mock
    module = Mock()
    module.run_command = Mock()
    module.run_command.return_value = (0, 'stdout', 'stderr')
    rpm_key = RpmKey(module)
    assert rpm_key.execute_command([]) == ('stdout', 'stderr')
    module.fail_json.assert_not_called()

# Generated at 2022-06-20 22:26:05.620628
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    import tempfile


# Generated at 2022-06-20 22:26:14.418163
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from mock import patch
    from ansible.module_utils.basic import AnsibleModule

    module_mock = AnsibleModule(argument_spec={}, supports_check_mode=True)
    with patch('rpm_key.RpmKey.execute_command', return_value=("pub:f:1024:17:EBC6E12C62B1C734026B21222A20E52146B8D79E6:1233231122::0:", '')):
        rpm_key = RpmKey(module_mock)
        assert rpm_key.getkeyid("") == 'EBC6E12C62B1C734026B21222A20E52146B8D79E6'


# Generated at 2022-06-20 22:26:25.351570
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(argument_spec={})
    mock_rpm_key = RpmKey(module)
    url = '/test/test_key'
    with patch.object(mock_rpm_key, 'fetch_key') as mock_fetch_key,\
         patch.object(mock_rpm_key, 'getkeyid') as mock_getkeyid:
        mock_fetch_key.return_value = 'test_key'
        mock_getkeyid.return_value = 'keyid'
        assert isinstance(mock_rpm_key.fetch_key(url), basestring)


# Generated at 2022-06-20 22:26:30.480261
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import sys
    # Some python 2.6 versions of Ubuntu does not include mock in stdlib
    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text

    basic._ANSIBLE_ARGS = os.environ.get('ANSIBLE_ARGS', None)

    def _setup_mock_module():
        sys.modules['ansible'] = Mock()
        sys.modules['ansible.module_utils'] = Mock()
        sys.modules['ansible.module_utils.basic'] = Mock()
        sys.modules['ansible.module_utils.urls'] = Mock()

# Generated at 2022-06-20 22:26:56.214820
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    args = dict(
        key='/path/to/RPM-GPG-KEY.dag.txt',
        fingerprint='EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6'
    )
    module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True
    )
    class MockExecuteCommand(object):
        def __init__(self, args):
            self.args = args

        def __call__(self, cmd):
            if cmd[0] == 'gpg' and cmd[-1] == 'RPM-GPG-KEY.dag.txt' and cmd[-2] == '--with-fingerprint':
                return self.make_gpg(self.args['fingerprint'])
           

# Generated at 2022-06-20 22:27:06.533097
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import unittest, sys
    import ansible
    import ansible.module_utils
    from ansible.module_utils import basic
    import tempfile
    import shutil

    #
    # Create a temporary directory
    #
    tmpdir = tempfile.mkdtemp()
    #
    # Create a temporary file with its contents
    #
    (fd, path) = tempfile.mkstemp(dir=tmpdir)
    fp = os.fdopen(fd, "w+b")
    #
    # Add some contents to the file
    #
    fp.write(b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n')
    fp.write(b'Version: GnuPG v2.0.22 (GNU/Linux)\n')
    fp.write(b'\n')
   

# Generated at 2022-06-20 22:27:16.434883
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # is_keyid test cases
    assert RpmKey.is_keyid("0xDEADB33F")
    assert RpmKey.is_keyid("DEADB33F")
    assert RpmKey.is_keyid("deadbeef")
    assert not RpmKey.is_keyid("deadbeefdeadbeef")
    assert not RpmKey.is_keyid("deadbeefdeadbeefdeadbeefdeadbeef")
    assert not RpmKey.is_keyid("deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef")
    assert not RpmKey.is_keyid("dead be eff")
    assert not RpmKey.is_keyid("0xDEADB33F 0xDEADB33F")

# Generated at 2022-06-20 22:27:26.798515
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    """
    Unit test for method fetch_key of class RpmKey.

    The method RpmKey.fetch_key() is used to download the key from the URL passed as argument and to
    return a valid path to a gpg key.

    Parameters
    ----------
    :param module : AnsibleModule object
    """

    # Creating the instance of class RpmKey, with arguments
    rpm_key = RpmKey(module)

    # Calling the instance of the class RpmKey
    assert rpm_key.fetch_key('https://github.com/ansible/ansible/raw/devel/keys/ansible-key.pub')



# Generated at 2022-06-20 22:27:37.396926
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible_collections.ansible.builtin.plugins.module_utils.rpm_gpg_key import RpmKey
    from ansible_collections.ansible.builtin.plugins.module_utils.common.collections import AnsibleModule
    import os
    import tempfile
    import re
    import shutil

    url = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    tmpdir = tempfile.mkdtemp()
    test_RpmKey = RpmKey(test_module)
    test_RpmKey.module.add_cleanup_dir(tmpdir)

    keyfile = test_RpmKey.fetch_key(url)

# Generated at 2022-06-20 22:27:48.832497
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():

    class MockModule(object):
        def run_command(self, cmd):
            return
        def fail_json(self):
            return
        def add_cleanup_file(self):
            return

    class MockCmd(object):
        def __init__(self, stdout, stderr, rc):
            self.stdout = stdout
            self.stderr = stderr
            self.rc = rc
            return

    module = MockModule()
    rpm_key = RpmKey(module)

# Generated at 2022-06-20 22:27:54.338979
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmkey = RpmKey(module)
    keyid = '0xDEADB33F'

    assert rpmkey.drop_key(keyid)


# Generated at 2022-06-20 22:28:00.783847
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey.is_keyid('0xDEADBEEF')
    assert RpmKey.is_keyid('0XDEADBEEF')
    assert not RpmKey.is_keyid('DEADBEEF')
    assert RpmKey.is_keyid('deadbeef')

# Generated at 2022-06-20 22:28:13.264031
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid(" 0xDEADB33F ") == "DEADB33F"
    assert rpm_key.normalize_keyid("0xDEADB33F ") == "DEADB33F"
    assert rpm_key.normalize_keyid(" 0XDEADB33F ") == "DEADB33F"
    assert rpm_

# Generated at 2022-06-20 22:28:22.455616
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import io
    import json
    import mock
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 22:29:02.279298
# Unit test for constructor of class RpmKey
def test_RpmKey():
    for t in ['present', 'absent']:
        for k in ['/etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release', 'http://apt.sw.be/RPM-GPG-KEY.dag.txt']:
            for v in ['yes', 'no']:
                for f in ['', 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6']:
                    module = AnsibleModule(dict(
                        action='/tmp/ansible_rpm_key_payload',
                        state=t,
                        key=k,
                        validate_certs=v,
                        fingerprint=f,
                        diff_mode=False
                    ))
                    RpmKey(module)
    return

# Generated at 2022-06-20 22:29:04.094567
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.rpm_key import main
    if main.__name__ == '__main__':
        raise Exception("The rpm_key module is not supposed to be run directly, use the rpm_key action plugin")

# Generated at 2022-06-20 22:29:07.578754
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----")
    assert not is_pubkey("NOT a pubkey")
    assert not is_pubkey("-----BEGIN PGP PUBLIC KEY BLK-----")

# Generated at 2022-06-20 22:29:13.370532
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_key = RpmKey(None)
    assert rpm_key.is_keyid('0xDEADB33F') is True
    assert rpm_key.is_keyid('DEADB33F') is True
    assert rpm_key.is_keyid('DEADB33FABC') is False
    assert rpm_key.is_keyid('z') is False

# Generated at 2022-06-20 22:29:25.276699
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    """
    Unit test for method is_key_imported of class RpmKey
    """
    # Create a dummy module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present'])
        ),
        supports_check_mode=True,
    )

    # Dummy keyid
    keyid = "DEADBEEF"

    # Create a dummy rpm_key instance
    rpm_key = RpmKey(module)

    # Create a list of keyids the method should return False
    rpm_key.keyids = list()
    assert rpm_key.is_key_imported(keyid) == False

    # Create a list of keyids the method should return True
    rpm_key.keyids.append(keyid)


# Generated at 2022-06-20 22:29:33.807027
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Module instance with mocked function execute_command
    # that returns a tuple given by the method run_command.
    # This tuple will be assigned to the variables 'stdout' and 'stderr'
    # that are used in the method drop_key.
    keyid = 'DEADBEEF'
    module = RpmKey(mock_module)
    module.execute_command = Mock()
    module.execute_command.return_value = ("", "")

    # Call to method drop_key of class RpmKey
    module.drop_key(keyid)

    # Assertion to verify that the command (given by the first argument of
    # the tuple that mock_module.run_command returns) contains the
    # parameters passed to method drop_key.

# Generated at 2022-06-20 22:29:36.284268
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    c = RpmKey()
    c.rpm = '/bin/rpm'
    c.module = MockModule()
    c.drop_key('DEADBEEF')

# Generated at 2022-06-20 22:29:47.010401
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid("0xDEADBEEF")
    assert rpm_key.is_keyid("0x1234")
    assert rpm_key.is_keyid("DEADBEEF")
    assert rpm_key.is_keyid("1234")
    assert not rpm_key.is_keyid("0xDEADBEEFG")
    assert not rpm_key.is_keyid("DEADBEEFG")
    assert not rpm_key.is_keyid("0xDEADBEEF0")
    assert not rpm_key.is_keyid("DEADBEEF0")
   

# Generated at 2022-06-20 22:29:54.125005
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    class DummyModule:
        def __init__(self):
            self.params = dict(state='present',key='http://apt.sw.be/RPM-GPG-KEY.dag.txt')
        def get_bin_path(self, executable, required=True):
            return executable
    rpmkey = RpmKey(DummyModule())
    assert rpmkey.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid(' 0xDEADBEEF ') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert rpm

# Generated at 2022-06-20 22:30:05.136631
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    r = RpmKey(module)
    tmpfd, tmpname = tempfile.mkstemp()
    module.add_cleanup_file(tmpname)
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-20 22:31:04.252679
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("""-----BEGIN PGP PUBLIC KEY BLOCK-----
dummy
-----END PGP PUBLIC KEY BLOCK-----
""")



# Generated at 2022-06-20 22:31:16.095965
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid = RpmKey.normalize_keyid
    assert keyid('deadb33f') == 'DEADB33F'
    assert keyid('0xDEADB33F') == 'DEADB33F'
    assert keyid('0xDEADB33F ') == 'DEADB33F'
    assert keyid(' 0xDEADB33F') == 'DEADB33F'
    assert keyid(' 0xDEADB33F ') == 'DEADB33F'
    assert keyid('0xDEADB33F') == 'DEADB33F'
    assert keyid('DEADB33F') == 'DEADB33F'
    assert keyid('DEADB33F ') == 'DEADB33F'

# Generated at 2022-06-20 22:31:25.612755
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # replace the execute_command method used in class RpmKey with a method
    # that provides the expected results for testing
    def mock_execute_command(self, cmd):
        stdout = '''pub:r:1024:17:DEADBEEF:1403550567:1575006467:::-:dSA key 1024 bits (1024 bits)
uid:r::::1403550567::05B3A6A3C611E7CEC83A6DBC076B2A6FCC7D07A5::User Name <username@example.com>:
sub:u:1024:16:898FDC531F64D6B5:1403550567:1575006467:::::sSA key 1024 bits (1024 bits):'''
        return stdout, ''
    RpmKey.execute_command = mock_

# Generated at 2022-06-20 22:31:34.022835
# Unit test for function is_pubkey

# Generated at 2022-06-20 22:31:45.346549
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import os
    import sys
    import unittest
    import mock
    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.module_utils'] = mock.Mock()
    sys.modules['ansible.module_utils.basic'] = mock.Mock()
    sys.modules['ansible.module_utils.urls'] = mock.Mock()
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.exit_json = mock.Mock()
            self.fail_json = mock.Mock()

# Generated at 2022-06-20 22:31:52.782928
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    mock_module = Mock(
        check_mode = False
    )
    mock_keyfile = 'path/to/keyfile'
    mock_execute_command = Mock()

    rpm_key = RpmKey(mock_module)
    rpm_key.execute_command = mock_execute_command

    rpm_key.import_key(mock_keyfile)

    mock_execute_command.assert_called_with([rpm_key.rpm, '--import', mock_keyfile])


# Generated at 2022-06-20 22:31:54.754458
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rpm_key_class = RpmKey(None)
    print(rpm_key_class.drop_key('0x11111111'))

# Generated at 2022-06-20 22:32:00.559005
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\nfoo\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----foo\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----foo\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----foo\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----foo\n-----END PGP PUBLIC KEY BLCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----foo\n-----END GPG PUBLIC KEY BLOCK-----')
    assert not is_

# Generated at 2022-06-20 22:32:08.511608
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Test case 001
    rpmKey = RpmKey(None)

    keyid = "0xabc123"
    expected_keyid = "ABC123"
    ret = rpmKey.normalize_keyid(keyid)

    assert ret == expected_keyid, "ERROR: (test_case_001) Test Failed. Expected(%s) Actual(%s)" % (expected_keyid, ret)

    # Test case 002
    keyid = "0Xabc123"
    expected_keyid = "ABC123"
    ret = rpmKey.normalize_keyid(keyid)

    assert ret == expected_keyid, "ERROR: (test_case_002) Test Failed. Expected(%s) Actual(%s)" % (expected_keyid, ret)

    # Test case 003

# Generated at 2022-06-20 22:32:13.848352
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('') == False
    assert is_pubkey(None) == False
    assert is_pubkey('sadfasdf') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('-----END PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----') == False


# Generated at 2022-06-20 22:34:48.372310
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import subprocess
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Unit test for method execute_command of class RpmKey
    r = RpmKey(module)
    cmd = 'ls /etc'
    r.execute_command(cmd)
    cmd = 'ls /etc/doesnotexist'
    r.execute_command(cmd)