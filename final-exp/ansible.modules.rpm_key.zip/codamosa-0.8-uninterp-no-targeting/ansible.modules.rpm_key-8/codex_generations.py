

# Generated at 2022-06-20 22:25:05.792015
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    RpmKey_instance = RpmKey(None)
    keyfile = 'test/fixtures/test.key'

    assert(RpmKey_instance.getfingerprint(keyfile) == '9F7D E1C5 8494 A044 E4C4  45AB B4CF DC98 09B7 39D9')

# Generated at 2022-06-20 22:25:16.928257
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from mock import patch, Mock

    with patch('ansible.module_utils.fetch_url.fetch_url') as fetch_url:
        fetch_url.return_value = Mock(info=dict(status=200)), 'test_output'
        module = Mock()
        module.run_command.return_value = 0, '', ''
        module.get_bin_path.return_value = '/usr/bin/gpg2'

        key = 'https://raw.githubusercontent.com/hector-vido/ansible-role-gazzang-repo/master/files/gpg/gazzang.key'
        rpm_key = RpmKey(module)
        keyfile = rpm_key.fetch_key(key)

        # Check that the key was fetched

# Generated at 2022-06-20 22:25:24.981148
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class MockedModule():
        def __init__(self):
            self.check_mode = False
            self.exit_json = exit
            self.fail_json = exit
            self.params = {}
            self.run_command = run_command

    class MockedOS():
        def __init__(self):
            self.environ = {}

        def popen(self, *args, **kwargs):
            if 'w+b' in args[0]:
                return MockedFileObject(args[1])


# Generated at 2022-06-20 22:25:38.197395
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from ansible.module_utils.common.collections import ImmutableDict
    import tempfile

    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)
    test_RpmKey = RpmKey(AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ),
    supports_check_mode=True,
    ))

    # In order to create a test file, we can't use the test_RpmKey
    # directly because it has a cleanup_file for the module, so we
    # need

# Generated at 2022-06-20 22:25:48.177221
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class module:
        def __init__(self):
            self.params = {'state': 'present'}
            self.check_mode = False

        def fail_json(self, **kwargs):
            raise ValueError(str(kwargs))

        def execute_command(self, cmd):
            return ( '', '' )

    rpkey = RpmKey(module)
    rpkey.rpm = '/usr/bin/rpm'
    rpkey.gpg = '/usr/bin/gpg'

    # Test if keyfile is not a valid filepath

# Generated at 2022-06-20 22:25:55.605882
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
  module = AnsibleModule(argument_spec=dict(state=dict(type='str', default='present', choices=['absent', 'present']),
                                            key=dict(type='str', required=True, no_log=False),
                                            validate_certs=dict(type='bool', default=True)
                                            ),
                          supports_check_mode=True)
  testobj = RpmKey(module)
  assert testobj.getkeyid('test/test.key') == '0DFF5326'


# Generated at 2022-06-20 22:26:04.269666
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpm = RpmKey(None)
    assert rpm.normalize_keyid('  0xDEADBEEF  ') == 'DEADBEEF'
    assert rpm.normalize_keyid('  0xDEADBEEF') == 'DEADBEEF'
    assert rpm.normalize_keyid('  DEADBEEF  ') == 'DEADBEEF'
    assert rpm.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm.normalize_keyid('DEADBEEF') == 'DEADBEEF'


# Generated at 2022-06-20 22:26:14.204649
# Unit test for constructor of class RpmKey

# Generated at 2022-06-20 22:26:16.847839
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n") == True

# Generated at 2022-06-20 22:26:29.348821
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    """Test the method fetch_key of the class RpmKey."""
    # Creation of the class and the mock environment
    response = MagicMock()
    response.body = 'a_key'
    module_parameters = {
        'state': 'present',
        'key': 'https://a_key.com',
        'fingerprint': '',
        'validate_certs': False
    }
    mod = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-20 22:26:50.169919
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import tempfile
    import shutil
    import os.path
    import os

    test_directory = tempfile.mkdtemp()


# Generated at 2022-06-20 22:26:51.178714
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 22:26:51.775408
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    assert True

# Generated at 2022-06-20 22:27:02.142713
# Unit test for function main
def test_main():
    # Testing with a missing required argument
    argument_spec = dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    )
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )
    assert module.fail_json.called

    # Testing with a missing required argument

# Generated at 2022-06-20 22:27:13.523670
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    class MockModule(object):
        def __init__(self, url, status):
            self.url = url
            self.status = status

        def fail_json(self, **kw):
            raise AssertionError(kw['msg'])

        def get_bin_path(self, bin, required=False):
            if bin == 'gpg':
                return 'gpg'
            if bin == 'gpg2':
                return 'gpg2'
            if bin == 'rpm':
                return 'rpm'

        def run_command(self, cmd, **kw):
            #print cmd
            import cStringIO

# Generated at 2022-06-20 22:27:23.650187
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import mock
    import __builtin__ as builtins
    if PY3:
        builtin_open = "builtins.open"
    else:
        builtin_open = "__builtin__.open"

    # create a mock and patch it
    rc = mock.Mock()
    rc.returncode = 0

    os_stat = mock.Mock()
    os_stat.return_value = mock.Mock(st_mode=33188)

    module = mock.Mock()

    module.run_command = mock.Mock(return_value=(rc, "stdout", "stderr"))
    module.run_command

# Generated at 2022-06-20 22:27:31.651976
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_key = RpmKey(module)
    assert test_key

# Generated at 2022-06-20 22:27:39.160150
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    # Test if key is in rpm database
    assert rpmkey.is_key_imported("1E9377A2") == True
    # Test if key is not in rpm database
    assert rpmkey.is_key_imported("TEST") == False

# Generated at 2022-06-20 22:27:48.124295
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.ansible_release import __version__ as version
    if version.startswith('2.'):
        import ansible.module_utils.six as six
    else:
        import six
    class module(object):
        def __init__(self):
            self.params = {'validate_certs': True}

        def fail_json(self, msg):
            raise AssertionError("fail_json was called")

        def add_cleanup_file(self, tmpfile):
            pass

    class fetch_url_mock(object):
        def __init__(self):
            self.count = 0

# Generated at 2022-06-20 22:27:54.740138
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.rpm == '/usr/bin/rpm'
    assert rpm_key.gpg == '/usr/bin/gpg'
    assert type(rpm_key.module) == AnsibleModule

# Generated at 2022-06-20 22:28:36.061138
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    # Create test key file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-20 22:28:46.316216
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.utils.unicode import to_bytes
    import codecs


# Generated at 2022-06-20 22:28:56.930696
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    test_RpmKey_drop_key.mock_RpmKey = create_autospec(RpmKey)
    test_RpmKey_drop_key.mock_RpmKey.check_mode = True
    test_RpmKey_drop_key.mock_RpmKey.return_value = None
    test_RpmKey_drop_key.mock_RpmKey.execute_command = Mock(return_value=0)
    test_RpmKey_drop_key.mock_RpmKey.drop_key('0xdeadbeef')
    test_RpmKey_drop_key.mock_RpmKey.execute_command.assert_called_with(['/bin/rpm --erase --allmatches gpg-pubkey-deadbeef'])
    test_RpmKey_drop_key

# Generated at 2022-06-20 22:29:05.295326
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    """Test fetch_key function of class RpmKey"""
    key = 'file:///'
    print("\nTesting fetch_key funtion of class RpmKey")
    print("\nTesting http")
    key = 'https://git.gnupg.org/cgi-bin/gitweb.cgi?p=gnupg.git;a=blob_plain;f=doc/DETAILS;hb=refs/heads/master'
    obj = RpmKey(key)
    assert(obj.fetch_key(key) is not None)
    print("\nTesting file")
    key = '/tmp/RPM-GPG-KEY-redhat-release'
    assert(obj.fetch_key(key) is not None)
    print("\nTest passed")



# Generated at 2022-06-20 22:29:18.596665
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Instantiate the class
    rpmkey = RpmKey("")
    # Check if method returns true for keyid with lowercase
    assert rpmkey.is_keyid("deadb33f") == True
    # Check if method returns true for keyid with uppercase
    assert rpmkey.is_keyid("DEADB33F") == True
    # Check if method returns true for keyid with 0x
    assert rpmkey.is_keyid("0xDEADB33F") == True
    assert rpmkey.is_keyid("0XDEADB33F") == True
    # Check if method returns true for keyid with 0x, lowercase and uppercase
    assert rpmkey.is_keyid("0xdeadb33f") == True

# Generated at 2022-06-20 22:29:27.790644
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Create an object of class RpmKey with a fake module object
    o = RpmKey(FakeModule())
    assert o.normalize_keyid("0xDEADBEEF") == "DEADBEEF"
    assert o.normalize_keyid("  0xDEADBEEF  ") == "DEADBEEF"
    assert o.normalize_keyid("  DEADBEEF  ") == "DEADBEEF"
    assert o.normalize_keyid("DEADBEEF") == "DEADBEEF"
    assert o.normalize_keyid("0XDEADBEEF") == "DEADBEEF"
    assert o.normalize_keyid("  0XDEADBEEF  ") == "DEADBEEF"
    assert o.normalize

# Generated at 2022-06-20 22:29:29.766256
# Unit test for constructor of class RpmKey
def test_RpmKey():
    rm = RpmKey('/key_url')
    rm = RpmKey('/key_file')
    rm = RpmKey('0xDEAD0XBEEF')

# Generated at 2022-06-20 22:29:36.004727
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url

    class FakeResponse(StringIO):
        """Fake a response from fetch_url"""
        def info(self):
            return {}

    class FakeModule(object):
        """Fake ansible.module_utils.basic.AnsibleModule"""
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.run_command_calls = []
            self.fail_json_calls = []

        def _debug_trap(self, var):
            pass

        def fail_json(self, msg):
            self.fail_json_calls.append(msg)
            raise Exception(msg)



# Generated at 2022-06-20 22:29:42.589668
# Unit test for constructor of class RpmKey
def test_RpmKey():
    key = '/tmp/RPM-GPG-KEY.dag.txt'
    args = dict(
        key = key,
        state = present,
        fingerprint = 'EBC6 E12C 62B1 C734 026B 2122 A20E 5214 6B8D 79E6',
        validate_certs = 'yes'
    )
    RpmKey(args)

# Generated at 2022-06-20 22:29:45.555577
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    key = RpmKey(AnsibleModule(argument_spec={}))
    stdout, stderr = key.execute_command(['echo', '-n', 'foo'])
    assert stdout == "foo"

# Generated at 2022-06-20 22:30:55.555828
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    myRpmKey = RpmKey()
    # Test 0xDEADB33F
    assert myRpmKey.is_keyid("0xDEADB33F")
    # Test DEADB33F
    assert myRpmKey.is_keyid("DEADB33F")
    # Test 0xDEADB33f
    assert myRpmKey.is_keyid("0xDEADB33f")
    # Test foo
    assert not myRpmKey.is_keyid("foo")
    # Test 0xDEADB33
    assert not myRpmKey.is_keyid("0xDEADB33")
    # Test 0xDEADB33FF
    assert not myRpmKey.is_keyid("0xDEADB33FF")
    # Test 0xDEADB33FX
   

# Generated at 2022-06-20 22:31:04.159852
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Mock module parameter variables
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
        bin_ansible_call = True,
    )

    # Create an instance of the RpmKey class
    r = rpm_key(module)

# Generated at 2022-06-20 22:31:14.354777
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from mock import Mock
    import tempfile

    # create temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    # mock module and arguments
    module = Mock()
    mod_args = dict()
    mod_args['module'] = module

    # create mock class
    rpm_key = RpmKey(module)

    # test a good key
    keyid = "deadbeef"
    result = rpm_key.is_keyid(keyid)
    assert result == True

    # test a bad key
    keyid = "deadbeefcafe"
    result = rpm_key.is_keyid(keyid)
    assert result == False

# Generated at 2022-06-20 22:31:23.809169
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test = RpmKey(module)
    assert test.getfingerprint("./test/resources/key1.pub") == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'

# Generated at 2022-06-20 22:31:27.661120
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    with open("rpm_key_gpg.py", "r") as fd:
        data = fd.read()

# Generated at 2022-06-20 22:31:34.167377
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    with tempfile.NamedTemporaryFile("w+") as f:
        key_file = f.name
        test_key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\n...\n-----END PGP PUBLIC KEY BLOCK-----"
        f.write(test_key)
        f.seek(0)
        assert is_pubkey(test_key), "Public key is correctly formatted"
        assert os.path.isfile(key_file), "Public key was written to a file in the temporary filesystem"
        assert "file://" + key_file == RpmKey.fetch_key(key_file), "Public key is returned in a URL format"


# Generated at 2022-06-20 22:31:38.860498
# Unit test for function is_pubkey
def test_is_pubkey():
    import ansible.modules.system.rpm_key as rpm
    assert rpm.is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\nVersion: GnuPG v2.0.19 (GNU/Linux)\n')

# Generated at 2022-06-20 22:31:46.788332
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = MockAnsibleModule()
    rpm_key = RpmKey(module)

    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('  DEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF   ') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('  DEADBEEF   ') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'



# Generated at 2022-06-20 22:31:56.986883
# Unit test for function is_pubkey

# Generated at 2022-06-20 22:32:07.096434
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class MockModule(object):
        def run_command(cmd, use_unsafe_shell=False):
            cmd = " ".join(cmd)
            if "gpg-pubkey" in cmd:
                # Key is installed
                return 0, "Key imported", ""
            else:
                return 1, "", "Key not installed"

    class MockModuleNoKey(object):
        def run_command(cmd, use_unsafe_shell=False):
            return 1, "", "Key not installed"

    class MockModuleBroken(object):
        def run_command(cmd, use_unsafe_shell=False):
            return 0, "", "Key not isntalled"

    mod = MockModule()
    mod2 = MockModuleNoKey()
    mod3 = MockModuleBroken()
    key = RpmKey(mod)

# Generated at 2022-06-20 22:34:37.168645
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.rpm_key import main

    main()

# Generated at 2022-06-20 22:34:45.073927
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class FakeModule(object):
        def __init__(self):
            self.exit_json = print

    class FakeSpecs(object):
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': '0xDEADB33F',
                'fingerprint': '',
            }
            self.check_mode = False
        def fail_json(self, *args, **kwargs):
            print(args, kwargs)
            raise ValueError()

    fake_module = FakeModule()
    fake_specs = FakeSpecs()
    fake_rpm_key = RpmKey(fake_specs)
    # test non existent gpg binary
    os.environ['PATH'] = os.path.expandvars('')
