

# Generated at 2022-06-20 22:25:09.331128
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    import os
    import unittest
    import unittest.mock # for Python 3.4 and earlier
    from ansible.module_utils import rpm_key

    # Create a test rpm_key module that returns a fixed value for check_mode
    class FakeRpmKeyModule:
        def __init__(self):
            self.check_mode = False

    # Create a mocke that simulates subprocess.run
    class FakeRun:
        def __init__(self, stdout, stderr, returncode):
            self.stdout = stdout
            self.stderr = stderr
            self.returncode = returncode

    # Create a mock that simulates os.path.isfile

# Generated at 2022-06-20 22:25:20.572241
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    cmd = ['ls']
    stdout, stderr = rpmkey.execute_command(cmd)
    assert len(stdout) > 0

    cmd = ['ls', '-l']
    stdout, stderr = rpmkey.execute_command(cmd)
    assert len(stdout) > 0

# Generated at 2022-06-20 22:25:25.506904
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    from ansible.modules.system.rpm_key import RpmKey
    keyid = RpmKey.normalize_keyid(RpmKey, '0xDEADB33F   ')
    assert keyid == 'DEADB33F'
    keyid = RpmKey.normalize_keyid(RpmKey, '  0XDEADB33F')
    assert keyid == 'DEADB33F'


# Generated at 2022-06-20 22:25:26.199943
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
	pass

# Generated at 2022-06-20 22:25:31.996513
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("not a pubkey") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n Version: GnuPG v1\n\n mI0EUcy6DgEEANiVj20XNfaAjzaB/L8GXTKlJB0aH/R3WzYPqYs4wo9iKsM6q3K+\n -----END PGP PUBLIC KEY BLOCK-----") == True

# Generated at 2022-06-20 22:25:43.683450
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class MockArgs(object):

        def __init__(self):
            self.check_mode = False
            self.key = "0xDEADB33F"

    class MockRpmKeysModule(object):

        def __init__(self):
            self.params = MockArgs()

        def fail_json(self, msg):
            raise Exception(msg)

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

        def cleanup(self, keyfile):
            pass

    def get_bin_path(self, name, required=False):
        return True

    rpm_key = RpmKey(MockRpmKeysModule())
    rpm_key.rpm = get_bin_path
    rpm_key.gpg = get_bin_path

    stdout, st

# Generated at 2022-06-20 22:25:56.215848
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class RpmKey_mock:
        def __init__(self):
            self.module = RpmKey_mock
            self.rpm = 'rpm -q  gpg-pubkey'
            self.gpg = 'gpg'

        def run_command(self, cmd, use_unsafe_shell=None):
            ret = ''

# Generated at 2022-06-20 22:25:59.188212
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import mock

    module = mock.MagicMock(name="module")
    import_key = RpmKey(module)

    assert import_key.getfingerprint("A") == "816E84EB"

# Generated at 2022-06-20 22:26:03.963549
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    key = " 0xABcdEfAB "
    expected_result = "ABCDEFAB"

    # Instantiate the module for testing
    rpmkey = RpmKey(None)

    actual_result = rpmkey.normalize_keyid(key)
    assert(actual_result == expected_result)


# Generated at 2022-06-20 22:26:10.959268
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmKey = RpmKey(module)

    #Test that method drop_key calls execute_command with proper arguments
    rpmKey.execute_command = MagicMock(return_value=True)
    rpmKey.drop_key("a1b2c3d4")

# Generated at 2022-06-20 22:26:34.110628
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # mock the module
    class RpmKeyMock():
        def __init__(self, RpmKeyMock):
            self.module = RpmKeyMock
            self.rpm = "rpm"
            self.gpg = "gpg"
            self.key = RpmKeyMock

    class ModuleMock():
        def __init__(self, check_mode=None, local_temp='', diff=False):
            self.check_mode = check_mode
            self.local_temp = local_temp
            self.diff = diff
        def get_bin_path(self, name, require=False):
            return name
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0,'',''
        def fail_json(self, msg):
            raise Exception(msg)
       

# Generated at 2022-06-20 22:26:40.641173
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpmkey = RpmKey(None)
    assert rpmkey.normalize_keyid('0x01234567') == '01234567'
    assert rpmkey.normalize_keyid('01234567') == '01234567'
    assert rpmkey.normalize_keyid('0x01234567    ') == '01234567'
    assert rpmkey.normalize_keyid(' 0x01234567') == '01234567'


# Generated at 2022-06-20 22:26:48.385361
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import mock

    def mock_run_command(cmd, use_unsafe_shell=None):
        import tempfile
        tmpfd, tmpname = tempfile.mkstemp()
        return 0, '1.0\n', ''

    class Mock_Module(object):
        def __init__(self, fail_json, params):
            self.fail_json = fail_json
            self.params = params
            self.run_command = mock_run_command

    def mock_fail_json(msg):
        raise ValueError(msg)

    # Test no parameters
    params = {}
    with mock.patch.object(RpmKey, '__init__') as mock_init:
        mock_init.return_value = None

# Generated at 2022-06-20 22:26:51.177566
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----')

# Generated at 2022-06-20 22:27:01.802267
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(argument_spec={
        "state": {"type":"str", "default":"present"},
        "key": {"type":"str", "required":True},
        "fingerprint": {"type":"str"},
        "validate_certs": {"type":"bool", "default":True}
    })

    class Rpm(object):
        def __init__(self):
            self.rpm = "rpm"

        def get_bin_path(self, rpm, required=False):
            return self.rpm

    class Gpg(object):
        def __init__(self):
            self.gpg = "gpg"

        def get_bin_path(self, gpg, required=False):
            return self.gpg

    module.get_bin_path = Gpg().get_bin_path

# Generated at 2022-06-20 22:27:13.307082
# Unit test for function main
def test_main():
    def mock_AnsibleModule(**kwargs):
        class MockAnsibleModule:
            def __init__(self):
                self.params = kwargs
            def exit_json(*args, **kwargs):
                pass
            def fail_json(*args, **kwargs):
                pass
            def get_bin_path(*args, **kwargs):
                return '/bin/rpm'
            def add_cleanup_file(*args, **kwargs):
                pass
            def run_command(*args, **kwargs):
                return 1, '', ''
            def check_mode(*args, **kwargs):
                pass
        return MockAnsibleModule()

    class MockOsPath:
        def isfile(*args, **kwargs):
            return True
    monkeypatch.setattr('os.path', MockOsPath)

# Generated at 2022-06-20 22:27:22.418340
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.basic import AnsibleModule, get_exception
    from ansible.module_utils.rpm_key import is_pubkey
    import tempfile
    import urlparse
    import os
    import os.path
    import shutil
    import sys
    import yaml
    import json
    import re

    # Path to the Content Directory
    content_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    # Add the directory to the path
    sys.path.insert(0, content_dir)
    from lib.common.utils import load_platform_subclass

    # Load the platform subclass

# Generated at 2022-06-20 22:27:30.091604
# Unit test for constructor of class RpmKey
def test_RpmKey():
    """
    Tests constructor of class RpmKey
    """
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-20 22:27:35.385247
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(argument_spec="", check_invalid_arguments=False)
    mock = MagicMock()
    module.run_command = mock
    mock.return_value = (0, "", "")
    mock_object = RpmKey(module)
    assert mock_object.import_key('test_key') is None


# Generated at 2022-06-20 22:27:43.601205
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    obj = RpmKey(module)
    assert obj.execute_command(['ls', '-la'])


# Generated at 2022-06-20 22:28:17.467567
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    print("Testing RpmKey.execute_command()")

    # ----------------------------------------------------------------
    # mock module and execute_command method, then call RpmKey
    # ----------------------------------------------------------------

    from unittest import mock
    import os

    mocked_module = mock.MagicMock()
    mocked_module.run_command.return_value = (0, 'stdout', 'stderr')

    # mock existing gpg executable
    rc, gpg_executable = os.system('which gpg > /dev/null 2>&1'), 0
    gpg_executable = '/usr/bin/gpg' if (rc == 0) else None

    # create new object
    obj = RpmKey(mocked_module)

    # set return values

# Generated at 2022-06-20 22:28:24.951657
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import tempfile, os, sys
    import rpm
    import shutil
    import subprocess

    # Setup, install a test key into the keyring
    # Create a temp directory with tempfile.TemporaryDirectory()
    with tempfile.TemporaryDirectory() as tmpdir:

        # Install a test key using rpm
        test_key_dir = os.path.join(tmpdir, ".gnupg")
        os.makedirs(test_key_dir)

# Generated at 2022-06-20 22:28:27.027292
# Unit test for function main
def test_main():
    args = dict(
        key='http://apt.sw.be/RPM-GPG-KEY.dag.txt',
        state='present',
    )

# Generated at 2022-06-20 22:28:30.805863
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    #Arrange
    err = False
    #Act
    try:
        RpmKey.drop_key(keyid)
    except ValueError:
        err = True
    #Assert
    assert err


# Generated at 2022-06-20 22:28:38.682572
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    """
    Tests for RpmKey.normalize_keyid()
    """
    assert RpmKey.normalize_keyid(' 0xdeadbeef ') == 'DEADBEEF'
    assert RpmKey.normalize_keyid('0xdeadbeef') == 'DEADBEEF'
    assert RpmKey.normalize_keyid('0Xdeadbeef') == 'DEADBEEF'
    assert RpmKey.normalize_keyid('deadbeef') == 'DEADBEEF'


# Generated at 2022-06-20 22:28:45.677491
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class Module(object):
        def __init__(self):
            self.run_command_results = (0,"gpg-pubkey-deadb33f-680d7fc8\ngpg-pubkey-fafefefe-ffeffefe","")
        def run_command(self, cmd, use_unsafe_shell=False):
            return self.run_command_results
    module = Module()
    rpm_key = RpmKey(module)

    # When there is a key installed
    assert rpm_key.is_key_imported("DEADB33F")

    # When there is no key installed
    module.run_command_results = (1,"","")
    assert not rpm_key.is_key_imported("DEADB33F")

    # When a key is installed, but not the one requested
   

# Generated at 2022-06-20 22:28:56.557811
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = tempfile.mkstemp()[1]
    f = open(keyfile, "w")

# Generated at 2022-06-20 22:28:57.541851
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = None
    RpmKey(module)

# Generated at 2022-06-20 22:29:05.704454
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm = RpmKey(module)
    assert rpm.is_keyid('0x12345678')
    assert rpm.is_keyid('12345678')
    assert not rpm.is_keyid('123456789')
    assert not rpm.is_keyid('0x1234567')
    assert not rpm.is_keyid('0x123456789')

# Generated at 2022-06-20 22:29:10.068411
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.mock import patch

    obj = RpmKey(AnsibleModule(argument_spec={}))

    # Test with arguments, with rc=0
    with patch.object(obj, 'execute_command') as m:
        m.return_value = ('foo', 'bar')
        assert obj.execute_command(['some', 'command']) == ('foo', 'bar')
        m.assert_called_with(['some', 'command'])

    # Test with arguments, with rc=1
    with patch.object(obj, 'execute_command') as m:
        m.return_value = ('foo', 'bar')
        with patch.object(obj.module, 'fail_json') as mfj:
            obj.execute_command(['some', 'command'])

# Generated at 2022-06-20 22:30:04.431403
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = './tests/gpg/public.gpg'
    keyid = '838F429E'
    rpm_key = RpmKey(None)
    assert rpm_key.getkeyid(keyfile) == keyid

# Generated at 2022-06-20 22:30:08.264505
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    keyfile = 'tests/RPM-GPG-KEY.dag.txt'
    r = RpmKey(AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    ))
    assert r.getfingerprint(keyfile) == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'


# Generated at 2022-06-20 22:30:15.091043
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    """Test if correct command is executed"""
    class MockModule(object):
        def __init__(self):
            self.check_mode = False
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            raise Exception(kwargs)

        def run_command(self, cmd, *args, **kwargs):
            args = list(args)
            self.params['rc'] = args.pop(0)
            self.params['stdout'] = args.pop(0)
            self.params['stderr'] = args.pop(0)
            return 0, '', ''

    class MockRpmKey(RpmKey):
        def __init__(self, module):
            RpmKey.__init__(self, module)


# Generated at 2022-06-20 22:30:27.385814
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    valid_key_url = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    invalid_key_url = "http://er.eee"
    mock_module = MagicMock()
    mock_module.params = {'state':'present' , 'key': valid_key_url, 'fingerprint': None}
    dag_key = RpmKey(mock_module)
    dag_key_file = dag_key.fetch_key(valid_key_url)
    with open(dag_key_file, 'r') as f:
        dag_key_content = f.read()
    # now test dag key is valid
    assert is_pubkey(dag_key_content) is True
    # now test an invalid key is fetched

# Generated at 2022-06-20 22:30:38.441147
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----#-----END PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----") == True
    assert is_pubkey("\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n") == True
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n(a lot of stuff)\n-----END PGP PUBLIC KEY BLOCK-----") == True

# Generated at 2022-06-20 22:30:50.260686
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test 1
    # When valid keyid is passed as argument, the method should return True
    my_rpm_key = RpmKey('test', 'present', 'test_key_id', None)
    my_rpm_key.execute_command = lambda x: ('', 0)
    valid_keyid = my_rpm_key.normalize_keyid('0x0ED8B3F7')
    assert valid_keyid == 'ED8B3F7'
    assert my_rpm_key.is_key_imported(valid_keyid)

    # Test 2
    # When invalid keyid is passed as argument, the method should return False
    invalid_keyid = '0x0ED8B3F7'
    assert not my_rpm_key.is_key_imported(invalid_keyid)


# Unit

# Generated at 2022-06-20 22:31:01.100517
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpmkey = RpmKey(None)
    assert rpmkey.is_keyid("0xDEADB33F")
    assert rpmkey.is_keyid("DEADB33F")
    assert not rpmkey.is_keyid("DEADB33F ")
    assert not rpmkey.is_keyid(" DEADB33F")
    assert not rpmkey.is_keyid("DEADB33")
    assert not rpmkey.is_keyid("0xDEADB33")
    assert not rpmkey.is_keyid("DEADB33F0")
    assert not rpmkey.is_keyid("0xDEADB33F0")
    assert not rpmkey.is_keyid("DEAD B33F")

# Generated at 2022-06-20 22:31:08.002361
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    cmd = 'echo "123"'
    r, _ = rpm_key.execute_command(cmd)
    assert r == '123\n'

# Generated at 2022-06-20 22:31:16.628535
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

# Generated at 2022-06-20 22:31:23.358360
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # Create a RpmKey module to execute
    module = AnsibleModule({'check_mode': False}, check_invalid_arguments=False)
    rpm = RpmKey(module)

    # Assert execute_command
    (stdout, stderr) = rpm.execute_command([rpm.gpg, '--version'])
    assert stdout == 'gpg (GnuPG) 2.0.29\nlibgcrypt 1.4.5\n'


# Generated at 2022-06-20 22:33:40.063130
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from unittest import TestCase
    from unittest.mock import patch
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(AnsibleModule):
        def __init__(self, **kwargs):
            self.params = kwargs
            super(MockModule, self).__init__()

        def fail_json(self, **kwargs):
            pass

    class MockAction(object):
        def __init__(self, **kwargs):
            self.module = MockModule(**kwargs)

    action = MockAction()

    rpmkey = RpmKey(action.module)

    assert rpmkey.is_keyid("0xDEADB33F")
    assert not rpmkey.is_keyid("ABADDEAD")

# Generated at 2022-06-20 22:33:51.534106
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    ret = RpmKey.normalize_keyid(None, "0xDEADBEEF")
    assert(ret == "DEADBEEF")
    ret = RpmKey.normalize_keyid(None, "DEADBEEF")
    assert(ret == "DEADBEEF")
    ret = RpmKey.normalize_keyid(None, "0XDEADBEEF")
    assert (ret == "DEADBEEF")
    ret = RpmKey.normalize_keyid(None, "0xDEADBEEF  ")
    assert (ret == "DEADBEEF")
    ret = RpmKey.normalize_keyid(None, "  DEADBEEF")
    assert (ret == "DEADBEEF")
    ret = RpmKey.normalize_key

# Generated at 2022-06-20 22:34:01.800970
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    from ansible.module_utils._text import to_bytes
    from io import BytesIO

    class Module:
        def __init__(self):
            self.check_mode = False
            self.run_command_calls = []
            self.rc = 0
            self.stdout = ""
            self.stderr = ""
            self.module_args = dict(
                state='present',
                key='1234',
            )

        def run_command(self, cmd, use_unsafe_shell=True):
            self.run_command_calls.append(cmd)
            return self.rc, self.stdout, self.stderr

    class FakeFile:
        def __init__(self):
            self.buffer = BytesIO(to_bytes(_PUBKEY))
            self.open = False

# Generated at 2022-06-20 22:34:10.110069
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.urls import fetch_url as mock_fetch_url
    from types import SimpleNamespace
    from os import path
    from shutil import rmtree
    from tempfile import mkdtemp
    import os

    key = '-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----'
    info = SimpleNamespace()
    info.status = 200
    info.msg = 'OK'
    test_url = "https://gazzang.com/keys/HECTOR/HECTOR-GPG-KEY"
    test_url2 = "https://gazzang.com/keys/HECTOR/HECTOR-GPG-KEY2"


# Generated at 2022-06-20 22:34:21.257018
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible.modules.packaging.os import rpm_key
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_bytes


# Generated at 2022-06-20 22:34:32.004097
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import unittest
    class TestRpmKey_is_key_imported(unittest.TestCase):

        def test_one_key_installed(self):
            ''' When a key is installed, is_key_imported() returns True '''
            module = AnsibleModule(argument_spec = dict())
            rpmkey = RpmKey(module)
            rpmkey.is_key_imported = mock.MagicMock(return_value=True)
            rpmkey.import_key = mock.MagicMock(return_value=None)
            rpmkey.drop_key = mock.MagicMock(return_value=None)

            self.assertTrue(rpmkey.is_key_imported('DEADB33F'))


# Generated at 2022-06-20 22:34:41.401142
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    ansible_module = AnsibleModule(argument_spec={})

    # test normalize_keyid
    if RpmKey.normalize_keyid(ansible_module, '0x6b8d79e6') != '6B8D79E6':
        raise