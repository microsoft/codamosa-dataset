

# Generated at 2022-06-20 22:25:08.266057
# Unit test for constructor of class RpmKey
def test_RpmKey():
    """Test constructor of class RpmKey"""
    import inspect
    # Importing module is important, else required functions will not be found
    from ansible.modules.packaging.os.rpm_key import RpmKey

    def function_to_mock(a):
        return a

    class MockModule():
        def __init__(self):
            pass
        def fail_json(self, msg):
            raise Exception(msg)
        def run_command(self, cmd):
            return 0, "", ""
        def get_bin_path(self, a, b=False, c=None):
            return '/bin/rpm'
        def add_cleanup_file(self, file_name):
            pass
        def cleanup(self, file_name):
            pass
        def check_mode(self):
            return False

    #

# Generated at 2022-06-20 22:25:14.779231
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(argument_spec=dict(state=dict(type='str', default='present', choices=['absent', 'present']), 
        key=dict(type='str', required=True, no_log=False), fingerprint=dict(type='str'), validate_certs=dict(type='bool', default=True), ))
    rpm_key = RpmKey(module)
    assert rpm_key.import_key('/path/to/file') == 0

# Generated at 2022-06-20 22:25:24.153152
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    """ Unit test for method is_key_imported of class RpmKey """

    # This is the example output of
    #
    # $ rpm -q gpg-pubkey --qf "%{description}" | gpg --no-tty --batch --with-colons --fixed-list-mode -
    #
    # pub:r:1024:17:6BD6B130:1560751003:::-:::scESC::::::23::0:
    # pub:r:1024:17:6B8D79E6:1339407568:::-:::scESC::::::23::0:
    # pub:r:1024:17:A20E5214:1339410371:::-:::scESC::::::23::0:
    # pub:r:1024:17:E12C62B1:1429

# Generated at 2022-06-20 22:25:30.792302
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible.module_utils.rpm_key import is_pubkey

    assert is_pubkey('') is False
    assert is_pubkey('123') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----'
                     '123'
                     '-----END PGP PUBLIC KEY BLOCK-----') is True
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----'
                     '-----END PGP PUBLIC KEY BLOCK-----') is True

# Generated at 2022-06-20 22:25:37.095570
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(argument_spec={'key': {'type': 'str', 'required': True, 'no_log': False}, 'state': {'type': 'str', 'default': 'present', 'choices': ['absent', 'present']}, 'fingerprint':{'type':'str'},'validate_certs': {'type': 'bool', 'default': True}})
    RpmKey(module)

# Generated at 2022-06-20 22:25:47.309540
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    test_str = ''
    keyid = ''
    expected = False
    rc, stdout, stderr = rpm_key.module.run_command('rpm -q gpg-pubkey')
    if rc == 0:
        test_str = stdout
    # The following test cases are executed only when an rpm key is present.

# Generated at 2022-06-20 22:25:57.867125
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Test with a valid key
    fetch_url_url = "/tmp/fetch_url_url"
    fetch_url_info = dict(status=200, msg="")
    fetch_url_info["msg"] = "a keyfile"
    fetch_url_rsp = "a keyfile"
    fetch_url_ret = (fetch_url_rsp, fetch_url_info)
    with patch("os.path.isfile", new=Mock(return_value=True)):
        with patch("tempfile.mkstemp", new=Mock(return_value=(1, "/tmp/keyfile"))):
            module = Mock(fetch_url=Mock(return_value=fetch_url_ret))
            module.check_mode = False

# Generated at 2022-06-20 22:26:08.340005
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Test if a common keyid is properly identified
    rpmkey = RpmKey(None)
    some_keyid = "deadbeef"
    assert rpmkey.is_keyid(some_keyid) == True
    # Test if a common keyid with a leading 0x is properly identified
    some_keyid = "0xDeadBeef"
    assert rpmkey.is_keyid(some_keyid) == True
    # Test if a common keyid with a leading 0X is properly identified
    some_keyid = "0XDeadBeef"
    assert rpmkey.is_keyid(some_keyid) == True
    # Test if a common keyid with a leading 0x and uppercase is properly identified
    some_keyid = "0XDEADBEEF"

# Generated at 2022-06-20 22:26:14.239817
# Unit test for function main
def test_main():
    """Test if main runs correctly"""
    # Assumptions:
    """
    - We can't test the rpm program
    - We can't test the gpg program
    - We need to generate a key with a known fingerprint
    - We have to figure out to the url where we can download this key
    - We need to generate a keyid for this key
    """
    import gpg
    import os
    import hashlib
    import pwd
    import grp
    import tempfile
    import shutil
    from datetime import datetime
    from ansible.module_utils.six.moves.urllib.parse import urlsplit

    # generate a gpg key, with a known fingerprint
    # generate a keyid for this key

# Generated at 2022-06-20 22:26:20.423613
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.urls import fetch_url
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_native


# Generated at 2022-06-20 22:26:38.009611
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(check_invalid_arguments=False)
    module.params['state'] = 'absent'
    module.params['key'] = 'DEADB33F'
    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')



# Generated at 2022-06-20 22:26:45.832638
# Unit test for function main
def test_main():
    '''Test that RpmKey class is working correctly'''
    from ansible.modules.packaging.os.rpm_key import RpmKey
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ), supports_check_mode=True)
    rpmkey = RpmKey(module)
    # Test normalize_keyid

# Generated at 2022-06-20 22:26:53.536451
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey(None).is_keyid('0xDEADB33F')
    assert RpmKey(None).is_keyid('DEADB33F')
    assert not RpmKey(None).is_keyid('deadb33f')
    assert not RpmKey(None).is_keyid('0x')
    assert not RpmKey(None).is_keyid('0xDEADB33Fx')
    assert not RpmKey(None).is_keyid('0xDEADB33Fx0')


# Generated at 2022-06-20 22:26:56.841540
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a RpmKey object
    obj_RpmKey = RpmKey()
    obj_RpmKey.drop_key("DEADB33F")
    assert obj_RpmKey.rpm == "rpm"


# Generated at 2022-06-20 22:27:07.004047
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Simple test to call the drop_key method
    keyid = "0xDEADB33F"
    expected_command = "rpm --erase --allmatches gpg-pubkey-deadb33f"

    class DummyModule():
        def __init__(self):
            self.params = dict()
            self.check_mode = False

        def run_command(self, cmd):
            if cmd != expected_command:
                raise Exception("'%s' command not executed" % expected_command)
            return 0, "", ""

        def fail_json(self, msg):
            raise Exception(msg)

    rpmkey = RpmKey(DummyModule())
    rpmkey.drop_key(keyid)

# Generated at 2022-06-20 22:27:15.143215
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    cmd = [rpmkey.rpm, '-q',  'gpg-pubkey']
    stdout, stderr = rpmkey.execute_command(cmd)

# Generated at 2022-06-20 22:27:26.633800
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class DummyArgs(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self.run_command = dummy_run_command
            self.fail_json = dummy_fail_json
            self.add_cleanup_file = dummy_add_cleanup_file

    def dummy_run_command(self, cmd, use_unsafe_shell=True):
        return '0', '', ''

    def dummy_fail_json(self, msg):
        pass

    def dummy_add_cleanup_file(self, filepath):
        pass

    class DummyModule(object):
        def __init__(self, args):
            self.args = args
            self.run_command = dummy_run_command
            self.fail_json = dummy_fail_

# Generated at 2022-06-20 22:27:36.966968
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    # Demo unit test to test the function is_key_imported in the class RpmKey,
    # the latter doesn't accept any parameter and returns True or False
    unit_test = RpmKey('module')
    result = unit_test.is_key_imported('keyid')

    # If result is true, the unit test pass with success,
    # otherwise it fails
    if result:

        print(unit_test.__class__.__name__ +': '+ unit_test.is_key_imported.__name__ + ': ' + 'SUCCESS')

    else:

        print(unit_test.__class__.__name__ +': '+ unit_test.is_key_imported.__name__ + ': ' + 'FAILURE')



# Generated at 2022-06-20 22:27:39.259494
# Unit test for function main
def test_main():
    RpmKey('')

# Generated at 2022-06-20 22:27:47.526713
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    rpm_key = RpmKey(None)
    # Test getkeyid(keyfile)
    # Test with not a valid public key
    keyfile = "not a valid key"
    ret = rpm_key.getkeyid(keyfile)
    assert ret == None
    # Test with valid public key
    keyfile = "/path/to/RPM-GPG-KEY.dag.txt"
    ret = rpm_key.getkeyid(keyfile)
    assert ret == 'A20E52146B8D79E6'


# Generated at 2022-06-20 22:28:23.337529
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    """
    Unit test of method ``execute_command`` of class ``RpmKey``
    """
    class FakeModule(object):
        """
        Fake object that we can use to mock ``RpmKey``
        """
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd, **kwargs):
            """
            We implement this so that we can mock ``RpmKey``
            """
            return (0, "", "")

    class FakeRpmKey(RpmKey):
        """
        This is a fake ``RpmKey`` class so we can mock its methods instead of testing them
        """
        def __init__(self, module):
            super(FakeRpmKey, self).__init__(module)

    # We create the fake module, it's

# Generated at 2022-06-20 22:28:29.094808
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-20 22:28:34.826451
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    rpmkey = RpmKey()
    # Testing with key and existing pubkey description
    assert rpmkey.is_key_imported('gpg-pubkey', 'gpg-pubkey-0608b895-4bd22942') == True


# Generated at 2022-06-20 22:28:43.438635
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from ansible.module_utils.six import StringIO
    import sys
    import unittest
    import ansible.module_utils.rpm_key

    class FakeModule(object):
        def __init__(self):
            self.fail_json = unittest.mock.MagicMock()
            self.check_mode = False
            self.run_command = unittest.mock.MagicMock(
                return_value=(1, '', ''))

    sys.modules["ansible.module_utils.rpm_key"] = ansible.module_utils.rpm_key
    from ansible.module_utils.rpm_key import RpmKey

    class RpmKey_drop_key(unittest.TestCase):
        """Tests for method drop_key of class RpmKey"""


# Generated at 2022-06-20 22:28:51.283527
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    test_key_file = '/home/travis/build/ansible/ansible/lib/ansible/modules/packaging/os/rpm_key.py'
    test_key_url = 'https://dl.fedoraproject.org/pub/epel/RPM-GPG-KEY-EPEL-7'
    test_RpmKey = RpmKey(test_key_file)
    test_RpmKey.fetch_key(test_key_url)

# Generated at 2022-06-20 22:28:53.590695
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    rpm_key = RpmKey(None)
    assert rpm_key.import_key(" ") == None

# Generated at 2022-06-20 22:29:01.851233
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # Changing args for unittest
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Changing args for unittest
    RpmKey(module)

    # Changing args for unittest
    rpm_key = RpmKey(module)

    # Executing test
    rpm_key.execute_command(rpm_key.rpm)

# Generated at 2022-06-20 22:29:09.283444
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n') == False
    assert is_pubkey('\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n') == True
    assert is_pubkey('\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----\n') == True
    assert is_pubkey('\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----') == True
    assert is_pubkey('\n-----BEGIN PGP PUBLIC KEY BLOCK----- \n\n-----END PGP PUBLIC KEY BLOCK-----\n') == True

# Generated at 2022-06-20 22:29:14.932560
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    class RpmKey_Mock(RpmKey):
        def fetch_key(self, key):
            return "https://example.com/key.gpg"
    mock = RpmKey_Mock(None)
    assert mock.fetch_key("https://example.com/key.gpg") == "https://example.com/key.gpg"


# Generated at 2022-06-20 22:29:26.431017
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('451E1A93426AA77BB0E7F8F76E115597D0AF58FC')
    assert rpm_key.is_keyid('451E1A93426AA77BB0E7F8F76E115597D0AF58FC')

# Generated at 2022-06-20 22:30:29.606555
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    """Tests the method fetch_key of the RpmKey class"""
    import tempfile
    import os
    import shutil
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_text
    import hashlib
    import os
    import pytest
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
   

# Generated at 2022-06-20 22:30:41.825534
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile


# Generated at 2022-06-20 22:30:51.324342
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    # module_args = {'key': '/etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release', 'state': 'present'}
    # rpm_key_obj = RpmKey(module_args)
    # cmd = [rpm_key_obj.gpg, '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', module_args['key']]
    # result = rpm_key_obj.execute_command(cmd)
    # print(result)
    pass

# Generated at 2022-06-20 22:31:01.041932
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule({
        'state': 'absent',
        'key': '0x0F93E35D',
    }, check_invalid_arguments=False)
    rpmkey = RpmKey(module)
    assert rpmkey.normalize_keyid('0x0F93E35D') == '0F93E35D'
    assert rpmkey.normalize_keyid('0F93E35D') == '0F93E35D'
    assert rpmkey.normalize_keyid(' 0F93E35D') == '0F93E35D'


# Generated at 2022-06-20 22:31:09.415611
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Test for keyfile is a valid pgp key
    tmpfd, tmpname = tempfile.mkstemp()
    key = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-20 22:31:20.266597
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = mock.MagicMock()
    module.check_mode = True
    keyfile = "mock_keyfile"
    rpm_key = RpmKey(module)

    def run_command(cmd):
        pass

    rpm_key.execute_command = run_command
    rpm_key.import_key(keyfile)
    assert not module.run_command.called

    module.check_mode = False
    rpm_key = RpmKey(module)
    rpm_key.execute_command = run_command
    rpm_key.import_key(keyfile)
    assert module.run_command.call_count == 1

# Generated at 2022-06-20 22:31:27.964742
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----")
    assert not is_pubkey("-----BEGIN PGP PRIVATE KEY BLOCK-----\n-----END PGP PRIVATE KEY BLOCK-----")
    assert not is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----BEGIN PGP PRIVATE KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----")
    assert not is_pubkey("-----BEGIN PGP PRIVATE KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----")

# Generated at 2022-06-20 22:31:34.376410
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('') is False
    assert is_pubkey('''
    -----BEGIN PGP PUBLIC KEY BLOCK-----
    Version: GnuPG v1.4.12 (GNU/Linux)
    Comment: GPGTools - https://gpgtools.org
    <snip>
    -----END PGP PUBLIC KEY BLOCK-----
    ''') is True
    assert is_pubkey('''
        -----BEGIN PGP PUBLIC KEY BLOCK-----
        Version: GnuPG v1.4.12 (GNU/Linux)
        Comment: GPGTools - https://gpgtools.org
        <snip>
        -----END PGP PUBLIC KEY BLOCK-----
        ''') is True

# Generated at 2022-06-20 22:31:45.381560
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module_args = dict(
        key='file:///tmp/key.txt',
        state='present'
    )

    # Creating a mock module to be used in the tests
    mM = mock.MagicMock()
    mM.params = module_args
    mM.check_mode = False
    mM.run_command.return_value = (0, 'stout', 'sterr')

    rpm_key = RpmKey(mM)
    rpm_key.import_key('file:///tmp/key.txt')
    assert mM.run_command.call_count == 1
    args, kwargs = mM.run_command.call_args
    assert args == (['rpm', '--import', 'file:///tmp/key.txt'],)
    assert kwargs == {'use_unsafe_shell': True}

# Generated at 2022-06-20 22:31:55.811282
# Unit test for method fetch_key of class RpmKey

# Generated at 2022-06-20 22:34:30.126973
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True,
    )

    class MockRpm:
        """Mocks the rpm binary"""
        def __init__(self, module):
            self.module = module
        def __call__(self, *args, **kwargs):
            return self.execute_command(*args, **kwargs)
        def execute_command(self, cmd):
            return self.module.run_command(cmd, use_unsafe_shell=True)
    module.get_bin_path = lambda *args, **kwargs: '/path/to/rpm'
    module.cleanup = lambda *args, **kwargs: True
    module.add_cleanup_file = lambda *args, **kwargs: True

# Generated at 2022-06-20 22:34:41.092905
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create an instance of RpmKey
    rpm_key = RpmKey()
    # Create a fake keyfile
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")