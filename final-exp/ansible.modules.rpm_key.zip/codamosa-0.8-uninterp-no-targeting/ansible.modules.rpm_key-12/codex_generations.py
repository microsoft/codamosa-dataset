

# Generated at 2022-06-20 22:25:12.351040
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


    class RpmKeyMock(RpmKey):
        def execute_command(self, cmd):
            return '', ''

    fd, path = tempfile.mkstemp()
    os.close(fd)

    rpm_key_obj = RpmKeyMock(module)
    assert rpm_key_obj

# Generated at 2022-06-20 22:25:19.921371
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class MockModule:
        def __init__(self):
            self.check_mode = True

        def fail_json(msg):
            print(msg)

    class MockRpmKey:
        def __init__(self, module):
            self.module = module

        def execute_command(self, cmd):
            return '', ''

    MockModule.fail_json = fail_json
    mockmodule = MockModule()
    mockrpmkey = MockRpmKey(mockmodule)
    mockrpmkey.import_key('/path/key')

# Generated at 2022-06-20 22:25:30.227192
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    """Given a RpmKey object, when a key is fetched, then a valid path should be returned, and file should exist and
    contain a pubkey."""
    import os
    import tempfile
    import requests
    import shutil
    import ansible.module_utils.action
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.basic

    if not os.path.isdir('/tmp/ansible_rpmkey_test'):
        os.makedirs('/tmp/ansible_rpmkey_test')

    test_file_path = '/tmp/ansible_rpmkey_test/RPM-GPG-KEY-EPEL.txt'

# Generated at 2022-06-20 22:25:42.265966
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import unittest
    import ansible.module_utils.rpm_key as rpm_key
    import ansible.module_utils.ansible_modlib as ansible_modlib
    class mock_module:
        def __init__(self, check_mode=True):
            self.check_mode = check_mode

        def fail_json(self, msg=None, **kwargs):
            pass

        def fail_json(self, msg=None, **kwargs):
            pass

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "", ""
        call_args = []

        def add_cleanup_file(self, tmpname):
            pass


# Generated at 2022-06-20 22:25:55.043903
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    testcase = dict(
        key="",
        expected=False,
        name=""
    )
    testcases = []

    testcase['key'] = "0xFFFFFF"
    testcase['expected'] = True
    testcase['name'] = "0xFFFFFF"
    testcases.append(testcase.copy())

    testcase['key'] = "0XFFFFFF"
    testcase['expected'] = True
    testcase['name'] = "0XFFFFFF"
    testcases.append(testcase.copy())

    testcase['key'] = "FFFFFF"
    testcase['expected'] = True
    testcase['name'] = "FFFFFF"
    testcases.append(testcase.copy())

    testcase['key'] = "deadb33f"
    testcase['expected'] = True
    test

# Generated at 2022-06-20 22:26:01.753145
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Create an object of class RpmKey
    rpmkey = RpmKey()

    # Test case where keystr is a valid keyid format
    assert rpmkey.is_keyid('0xDEADB33F')

    # Test case where keystr is an invalid keyid format
    assert not rpmkey.is_keyid('hello')

    # Test case where keystr is an valid keyid with whitespace
    assert rpmkey.is_keyid('   0xDEADB33F   ')



# Generated at 2022-06-20 22:26:12.429210
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a class instance
    module = AnsibleModule({
        'state': 'present',
        'key': 'DEADB33F',
    })
    rpm_key = RpmKey(module)

    rpm_key.rpm = 'magic_rpm'
    rpm_key.module.run_command = mock.Mock()
    rpm_key.module.run_command.return_value = [0, "", ""]

    rpm_key.module.check_mode = False
    rpm_key.drop_key('DEADB33F')
    rpm_key.module.run_command.assert_called_once_with(['magic_rpm', '--erase', '--allmatches', 'gpg-pubkey-deadb33f'], use_unsafe_shell=True)

    rpm_key.module.run_

# Generated at 2022-06-20 22:26:18.271738
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import builtins
    from ansible.module_utils.common.process import get_bin_path, check_pid

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)


# Generated at 2022-06-20 22:26:28.087290
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class Module(object):
        def __init__(self):
            self.params = dict(state='present', key='/path/to/key.gpg')
            self.args = dict()

        def get_bin_path(self, cmd, required=False):
            return 'rpm'

        def fail_json(self, msg):
            self.msg = msg
            return

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

        def exit_json(self, changed=False):
            self.changed = changed
            return

    rk = RpmKey(Module())

# Generated at 2022-06-20 22:26:33.237421
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create the object and fake the command
    obj = RpmKey()
    obj.rpm = "/bin/rpm"
    obj.module = MagicMock()
    obj.execute_command = MagicMock()
    obj.import_key("keyfile")
    assert obj.execute_command.called, "Method not called."
    assert obj.execute_command.call_count == 1, "Method called more than once."

# Generated at 2022-06-20 22:26:59.624000
# Unit test for method getfingerprint of class RpmKey

# Generated at 2022-06-20 22:27:11.894507
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import sys
    import subprocess

    # skip the test if we don't have python2 installed
    if not subprocess.call([sys.executable, '-c', 'import sys; sys.exit(sys.version_info[:2] != (2, 7))']):
        # We need to create a module object in order to create a RpmKey object, however we don't need the module object afterwards.
        # So, we use this line to create a module object, and then use the del statement to delete the module object immediately
        # after that.
        module = AnsibleModule(argument_spec={})
        test_key = RpmKey(module)
        del module

        test_key_normalize_keyid_correct_format = '12345678'
        test_key_normalize_keyid_incorrect_format_no_0x

# Generated at 2022-06-20 22:27:19.613548
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    # Invalid command
    try:
        rpm_key.execute_command(['invalidcommand'])
        assert False, "Exception not thrown on invalid command"
    except Exception:
        pass

    # Valid command

# Generated at 2022-06-20 22:27:24.730691
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = MockModule(dict(
        state='present',
        key='01234567',
    ))
    rpmkey = RpmKey(module)
    assert rpmkey is not None


# Generated at 2022-06-20 22:27:33.066679
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class MockModule():
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, 'pub:u:2048:1:42424242:1599110222::::\r\npub:u:2048:1:48484848:1599110222::::\r\n', ''
    mock = MockModule()
    keyfile = '/tmp/mock'
    rpm_key = RpmKey(mock)
    assert rpm_key.getkeyid(keyfile) == '42424242'



# Generated at 2022-06-20 22:27:45.650165
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import unittest

    class RpmModule(object):
        def add_cleanup_file(self, path):
            pass

        def fail_json(self, msg=''):
            self.failed = True
            self.msg = msg
            raise RuntimeError(msg)


    class RpmKey_TestCase(unittest.TestCase):
        def setUp(self):
            self.module = RpmModule()
            self.module.run_command = run_command_stub

        def test_getkeyid(self):
            self.module.gpg = 'gpg'
            key = RpmKey(self.module)
            key_file = 'tests/unit/modules/rpm_key/gpg-pubkey-ad132724.gpg'

            # Normal case
            keyid = key.getkey

# Generated at 2022-06-20 22:27:54.545351
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    from ansible.module_utils.six.moves import StringIO

    module_args = dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    rpm = RpmKey(module)
    url = "https://github.com/ansible/ansible/blob/devel/lib/ansible/test/test-modules/test_rpm_key/test_valid_key.gpg"
   

# Generated at 2022-06-20 22:28:04.992927
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Test for more than one fingerprint
    assert getfingerprint(keyfile) == 'CE1D2DED2D5F5F8C13DE5D5DE5C5DE5D5DE5D5D5'
    # Test for 1 fingerprint
    assert getfingerprint(keyfile) == '4F125D6F2B9E7B0B2C2AEF5D5DE5D5DE5D5DE5D5'
    # Test for no fingerpring
    assert getfingerprint(keyfile) == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'

# Generated at 2022-06-20 22:28:17.376212
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.fake_io import FakeIO

    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    class FakeAnsibleModule(object):
        class FakeAnsibleModule(object):
            class ArgumentSpec(object):
                def __init__(self):
                    self.state = 'present'
                    self.key = None
                    self.fingerprint = None
                    self.validate_certs = True

            def __init__(self):
                self.params = dict()
                self.check_mode = False
                self.argument_spec = self.ArgumentSpec()


# Generated at 2022-06-20 22:28:24.902718
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_key = "  0xDeadB33F"
    module_args = dict(
        state='present',
        key=test_key
    )
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
        module_args=module_args
    )
    test_key_object = RpmKey(test_module)
    assert test_key_object.normalize_keyid(test_key) == "DEADB33F"

# Unit

# Generated at 2022-06-20 22:28:52.311322
# Unit test for function main

# Generated at 2022-06-20 22:29:02.308867
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # The key import is not tested here, we are using the --qf option to check the description,
    # which is common for imported keys, and not present in rpm db.
    cmd = 'echo "This is a fake stdout" && echo "This is a fake stderr" >&2'
    # It should return true if the key exists in the rpm db
    module = AnsibleModule(argument_spec={
        'state': dict(type='str', default='present', choices=['absent', 'present']),
        'key': dict(type='str', required=True, no_log=False),
        'fingerprint': dict(type='str'),
        'validate_certs': dict(type='bool', default=True),
    },
        supports_check_mode=True,
    )
    module.run_command = get_

# Generated at 2022-06-20 22:29:14.102221
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    with patch('ansible.module_utils.urls.fetch_url') as m_fetch_url:
        m_fetch_url.return_value = (BytesIO(b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n'), None)

        tempfile_mock = Mock()
        tempfile_mock.mkstemp.return_value = (123, 'asdf')
        with patch('tempfile.mkstemp', tempfile_mock):

            with patch('ansible.module_utils._text.to_native') as m_to_native:
                m_to_native.return_value = b'-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n'


# Generated at 2022-06-20 22:29:25.834674
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class RpmKey():
        def execute_command(self, cmd):
            return """
pub:r:2048:1:0C46B5C81B5B61C5:1544980861:::u:::scESC:
fpr:::::::::EBC6E12C62B1C734:
uid:r::::1544980861::F3F3C73D8C6F2EAA5F5D5B5C81B5B61C5C7226C1::gpg-pubkey:::c:::
sub:r:2048:1:0C46B5C81B5B61C5:1544980861::::::e:::
fpr:::::::::EBC6E12C62B1C734:
"""
    rpm_key = RpmKey()
   

# Generated at 2022-06-20 22:29:32.308240
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm = RpmKey(module)

    # Calling drop_key with a non-existing keyID
    rpm.drop_key("1234ABCD")

# Generated at 2022-06-20 22:29:41.114091
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    m = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    r = RpmKey(m)
    assert r.is_keyid("0x12345678")
    assert r.is_keyid("12345678")
    assert not r.is_keyid("0xA2345678")
    assert not r.is_keyid("123456789")
    assert not r.is_keyid("")

# Generated at 2022-06-20 22:29:48.791384
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey.is_keyid('0xb33fb33f') is True
    assert RpmKey.is_keyid('0x1') is True
    assert RpmKey.is_keyid('b33fb33f') is True
    assert RpmKey.is_keyid('0x1') is True
    assert RpmKey.is_keyid('b33f') is True
    assert RpmKey.is_keyid('deadb33f') is True
    assert RpmKey.is_keyid('DEADB33F') is True
    assert RpmKey.is_keyid('DEADB33F') is True
    assert RpmKey.is_keyid('1234') is True
    assert RpmKey.is_keyid('0x1234') is True
    assert RpmKey.is_key

# Generated at 2022-06-20 22:29:52.412056
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = get_module()
    rpm_key = RpmKey(module)
    assert rpm_key.rpm is not None
    assert rpm_key.module is not None


# Generated at 2022-06-20 22:29:58.731801
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = "/path/to/keyfile"
    keyid = "keyid"
    rpmykey = RpmKey(object())
    rpmykey.gpg = "gpg"
    rpmykey.execute_command = mock.Mock(return_value=(keyid, ''))

    assert rpmykey.getkeyid(keyfile) == keyid



# Generated at 2022-06-20 22:30:04.801314
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\nrandom stuff here\n-----END PGP PUBLIC KEY BLOCK-----\n') == True

# Generated at 2022-06-20 22:30:42.763794
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    from ansible.module_utils.ansible_release import __version__
    module_args = {
        'state': 'present',
        'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    }
    module = AnsibleModule(
        argument_spec = module_args,
        supports_check_mode=True,
        bypass_checks=False
    )
    rpm_key = RpmKey(module)
    assert rpm_key.import_key() == 0

# Generated at 2022-06-20 22:30:54.446736
# Unit test for function is_pubkey
def test_is_pubkey():
    assert not is_pubkey(None)
    assert not is_pubkey('')

# Generated at 2022-06-20 22:31:05.656595
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():

    # Create an instance to test
    module = mock.Mock()
    setattr(module, 'check_mode', False)
    setattr(module, 'run_command', run_command)
    setattr(module, 'fail_json', fail_json)
    setattr(module, 'execute_command', execute_command)
    mod = RpmKey(module)

    # Make the key file just a regular file
    keyfile = tempfile.mkstemp()
    os.close(keyfile[0])

    # Import the key
    mod.import_key(keyfile[1])

    # Confirm it was run
    assert mod.module.run_command.call_count == 1
    command = mod.module.run_command.call_args[0][0]

# Generated at 2022-06-20 22:31:15.240113
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    keyid = "DEADB33F"
    x = RpmKey(module)
    out = x.is_key_imported(keyid)
    assert out == False

# Generated at 2022-06-20 22:31:24.390883
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible_collections.ansible.builtin.plugins.module_utils.ansible_module_common import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.exit_json = lambda *args, **kwargs: None

        def fail_json(self, **kwargs):
            pass

    module = FakeModule()

    class FakeRpmKey(RpmKey):
        def __init__(self, module):
            self.module = module

    from tempfile import mkstemp
    from os import fdopen, fdopen, close
    from shutil import copy
    from os.path import abspath
    from os.path import dirname
    fd, tmpfile = mkstemp()

# Generated at 2022-06-20 22:31:33.204574
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_rpm_key = RpmKey(test_module)

    assert test_rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert test_rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'

# Generated at 2022-06-20 22:31:44.203880
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_keyid = "DEADB33F"
    rpm_key = RpmKey(None)
    assert rpm_key.normalize_keyid(test_keyid) == test_keyid
    assert rpm_key.normalize_keyid(" 0x" + test_keyid + " ") == test_keyid
    assert rpm_key.normalize_keyid(" 0x" + test_keyid.lower() + " ") == test_keyid
    assert rpm_key.normalize_keyid(" 0x" + test_keyid.upper() + " ") == test_keyid
    assert rpm_key.normalize_keyid(" 0x" + test_keyid.swapcase() + " ") == test_keyid

# Generated at 2022-06-20 22:31:53.571128
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Since the unit test is not able to validate the results of the execute_command
    # method, instead we will test the import_key method
    # by using a mock of the execute_command method
    global module
    module = MockAnsibleModule()
    rpm_key = RpmKey(module)
    rpm_key.execute_command = Mock()
    rpm_key.import_key("/path/to/key.gpg")
    expected_cmd = [rpm_key.rpm, '--import', '/path/to/key.gpg']
    rpm_key.execute_command.assert_called_once_with(expected_cmd)

# Generated at 2022-06-20 22:31:55.319332
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = "tests/test_gpg_key.txt"
    assert RpmKey.getkeyid(keyfile) == "DEADB33F"


# Generated at 2022-06-20 22:32:00.854790
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    # Importing required modules
    import unittest.mock
    import os.path
    import tempfile
    from module_utils.urls import fetch_url
    from module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule


    class AnsibleModuleMock(object):

        def __init__(self, argument_spec):
            self.params = argument_spec

        def fail_json(self, msg):
            pass

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, "Success", ""

        def check_mode(self):
            return True

    class ModuleExitJsonMock(object):
        
        def __init__(self, changed):
            self.changed = changed

    file_path = os.path.dir

# Generated at 2022-06-20 22:33:40.080621
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    cmd = "/bin/true"
    expected_output = b''
    expected_error = b''
    actual_output, actual_error = rpm_key.execute_command(cmd)

    assert(actual_output == expected_output)
    assert(actual_error == expected_error)

    cmd = "/bin/false"
    expected_output = b

# Generated at 2022-06-20 22:33:44.141067
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    test_module = RpmKey()
    keyfile = test_module.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt")
    assert(os.path.isfile(keyfile))
    assert(is_pubkey(keyfile))


# Generated at 2022-06-20 22:33:54.985044
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    class AnsibleModuleFake(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(AnsibleModuleFake, self).__init__(*args, **kwargs)
            self.params = kwargs
            self.check_mode = True
            self.fail_json = lambda msg: self.fail(to_native(msg))

    module = AnsibleModuleFake(key='./test/testdata/pubkey',
                               # Fingerprint can be found using gpg2 --fingerprint
                               fingerprint='EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6')


# Generated at 2022-06-20 22:34:05.490713
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():

    # Test method RpmKey.normalize_keyid with keyid starting with 0x lowercase
    rpm_key = RpmKey(None)
    keyid = '0x12345678'
    normalized_keyid = rpm_key.normalize_keyid(keyid)
    assert normalized_keyid == '12345678', normalized_keyid

    # Test method RpmKey.normalize_keyid with keyid starting with 0X uppercase
    rpm_key = RpmKey(None)
    keyid = '0X12345678'
    normalized_keyid = rpm_key.normalize_keyid(keyid)
    assert normalized_keyid == '12345678', normalized_keyid

    # Test method RpmKey.normalize_keyid with keyid without 0x

# Generated at 2022-06-20 22:34:12.419687
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    keyid = "deadb33f"
    keyfile = "deadb33f.gpg"

    # return_value = keyid
    # @patch('RpmKey.getkeyid', return_value=return_value)

# Generated at 2022-06-20 22:34:20.847678
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpm_key = RpmKey(None)
    assert not rpm_key.is_keyid('8F08D2A7' * 8)
    assert not rpm_key.is_keyid('0x8F08D2A7')
    assert rpm_key.is_keyid('8F08D2A7')
    assert rpm_key.is_keyid('0x8F08D2A7' * 8)
    assert rpm_key.is_keyid('0x8F08D2A7' * 9)


# Generated at 2022-06-20 22:34:31.736539
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    rpm_key = RpmKey(None)

    # Check that a file without a gpg key returns an error
    with open("file_without_gpg_key.txt", "w+") as f:
        f.write("")

# Generated at 2022-06-20 22:34:37.258820
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    from mock import patch
    with patch.object(rpm_key, 'execute_command'):
        rpm_key.execute_command.return_value = "test_value", "test_value"
        rpm_key.import_key("test")

# Generated at 2022-06-20 22:34:46.628585
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils._text import to_bytes

    fd, tmpname = tempfile.mkstemp()
    os.close(fd)

    class DummyModule(object):
        def __init__(self):
            self.params = dict(key='https://example.org/key.gpg')
            self.fail_json = lambda **kwargs: 1/0
            self.cleanup = lambda *args: None
            self.check_mode = False

        def add_cleanup_file(self, path):
            os.unlink(path)

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''
