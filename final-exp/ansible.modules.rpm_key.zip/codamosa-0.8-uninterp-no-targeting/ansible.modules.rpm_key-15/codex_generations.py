

# Generated at 2022-06-20 22:25:08.184024
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    keyid = "DEADBEEF"
    mock_module = Mock(
        check_mode=False,
        run_command=MagicMock(return_value=(0, "", ""))
    )
    rpm_key = RpmKey(mock_module)
    rpm_key.drop_key(keyid)
    mock_module.run_command.assert_called_once_with(['rpm', '--erase', '--allmatches', "gpg-pubkey-%s" % keyid[-8:].lower()], use_unsafe_shell=True)


# Generated at 2022-06-20 22:25:18.466152
# Unit test for function is_pubkey
def test_is_pubkey():
    # True scenarios
    assert is_pubkey("I am a key\n-----BEGIN PGP PUBLIC KEY BLOCK-----\nfoo\n-----END PGP PUBLIC KEY BLOCK-----\nend of key")
    assert is_pubkey("I am a key\n-----BEGIN PGP PUBLIC KEY BLOCK-----")
    assert is_pubkey("\n-----END PGP PUBLIC KEY BLOCK-----\nend of key")
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\nfoo\n-----END PGP PUBLIC KEY BLOCK-----\n")

# Generated at 2022-06-20 22:25:27.877990
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class FakeModule(object):
        def fail_json(self, **kwargs):
            raise Exception('Test failed')

    class FakeFile(object):
        def __init__(self, stdout, stderr):
            self.stdout = stdout
            self.stderr = stderr

        def communicate(self):
            return self.stdout, self.stderr

    module = FakeModule()
    filename = 'my_file'

    with open(filename, 'w') as f:
        f.write('foo')
    try:
        rk = RpmKey(module)
        rk.execute_command = lambda cmd: ('fpr:foo', '')
        rk.getfingerprint(filename)
    finally:
        os.remove(filename)

    return_code = None

# Generated at 2022-06-20 22:25:38.609122
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----")
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----")
    assert is_pubkey("\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----")
    assert is_pubkey("\n-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----\n")
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----\n")

# Generated at 2022-06-20 22:25:48.447187
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class MyModule(object):
        def get_bin_path(self, name, required=True):
            if name == 'rpm':
                return '/usr/bin/rpm'
            elif name == 'gpg':
                return '/usr/bin/gpg'

        def fail_json(self, msg):
            raise AssertionError(msg)

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd[0] == '/usr/bin/rpm' and cmd[1] == '-q' and cmd[2] == 'gpg-pubkey' and cmd[3] == '--qf':
                return 0, 'gpg-pubkey-deadb33f', ''

# Generated at 2022-06-20 22:25:53.116122
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class ModuleStub(object):
        def run_command(self, cmd):
            return 0, 'stdout', 'stderr'

    rpm_key = RpmKey(ModuleStub())
    result = rpm_key.execute_command(['cat', '/etc/hosts'])
    assert result



# Generated at 2022-06-20 22:26:02.655272
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        )
    )

    rpmkey = RpmKey(test_module)
    fp = rpmkey.getfingerprint('/etc/pki/rpm-gpg/RPM-GPG-KEY-puppetlabs')
    assert fp == 'EBC6E12C62B1C734 026B2122A20E5214 6B8D79E6'


# Generated at 2022-06-20 22:26:13.209026
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)

    assert rpmkey.is_key_imported("deadbeef") == False
    assert rpmkey.is_key_imported("deadbeefdeadbeef") == False
    assert rpmkey.is_key_imported("deadb33f") == False
    assert rpmkey.is_key_imported("deadb33f") == True
    assert rpmkey

# Generated at 2022-06-20 22:26:18.966145
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import ansible.module_utils.basic
    import ansible.module_utils.urls

    import __builtin__ as builtins
    import imp

    def mock_AnsibleModule(*args, **kwargs):
        return ansible.module_utils.basic.AnsibleModule(*args, **kwargs)

    def mock_fetch_url(*args, **kwargs):
        from ansible.module_utils.urls import Response
        response = Response()
        response.info = {'status': 200, 'msg': ''}

# Generated at 2022-06-20 22:26:30.368103
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Create a fake module
    import io
    import tempfile

# Generated at 2022-06-20 22:26:48.805213
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    keyid = "BD15DA7D"
    # Test case with no key installed in local system
    assert rpm_key.is_key_imported(keyid) == False

# Generated at 2022-06-20 22:26:58.088812
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid_test_cases = [
        # input, expected
        ["DEADB33F", "DEADB33F"],
        ["deadb33f", "DEADB33F"],
        ["\t    DEADB33F", "DEADB33F"],
        ["0xDEADB33F", "DEADB33F"],
        ["0xdeadb33f", "DEADB33F"],
        ["\t    0xDEADB33F", "DEADB33F"],
    ]

    for input, expected in keyid_test_cases:
        assert RpmKey._normalize_keyid(input) == expected

# Generated at 2022-06-20 22:27:10.028891
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Test if cmd is correctly invoked when module is not in check_mode
    result.rc = 0
    result.stdout = b'Key successfully imported'
    result.stderr = b''
    module.check_mode = False
    rpm_key = RpmKey(module)
    rpm_key.import_key('/tmp/key.gpg')
    assert result.rc == 0
    assert result.stdout == b'Key successfully imported'
    assert result.stderr == b''
    # Test if cmd is not invoked when module is in check_mode
    result.rc = 0
    result.stdout = b'Key successfully imported'
    result.stderr = b''
    module.check_mode = True
    rpm_key = RpmKey(module)

# Generated at 2022-06-20 22:27:15.816947
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import ansible.module_utils.common.network as network
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3
    from ansible.module_utils.urls import fetch_url
    original_request = network.open_url  # save original open_url

# Generated at 2022-06-20 22:27:27.024825
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():

    # Create a class instance with a module mock
    rpm_key = RpmKey(MockModule())

    # Unit test for a invalid key
    setattr(rpm_key.module, 'fail_json', Mock(return_value=None))
    fetch_key = MagicMock(return_value="/tmp/mykey.gpg")
    setattr(rpm_key, 'fetch_key', fetch_key)

    # fetch_key fails on is_pubkey check
    rpm_key.fetch_key("http://bad_url.com")
    setattr(rpm_key.module, 'fail_json', Mock(return_value=None))

    assert rpm_key.fetch_key("http://bad_url.com") is None



# Generated at 2022-06-20 22:27:37.544494
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Import necessary modules
    from ansible.module_utils import basic
    from ansible.module_utils.urls import fetch_url

    class FakeModule(object):
        def __init__(self):
            self.check_mode = False
            self.fail_json = self.raise_fail_json
            self.run_command = self.run_command_fake
            self.get_bin_path = self.get_bin_path_fake
            self.cleanup = self.cleanup_fake

        def raise_fail_json(self, msg):
            raise AssertionError(msg)

        def run_command_fake(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

        def get_bin_path_fake(self, path, required=True):
            return path


# Generated at 2022-06-20 22:27:48.989292
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():

    import unittest
    import mock
    from ansible.module_utils._text import to_bytes

    class TestRpmKey(unittest.TestCase):

        def test_RpmKey_drop_key_not_found(self):

            module = mock.Mock()

            RpmKey = RpmKey(module)

            keyid = "FA47FA47"
            module.check_mode = False
            module.get_bin_path.return_value = "rpm"
            module.run_command.return_value = (
                1,  # rc
                "1 packages excluded due to repository priority protections",  # stdout
                ""  # stderr
            )

            RpmKey.drop_key(keyid)

            # Arguments are passed to run_command() as a string.
            # Checking them directly is

# Generated at 2022-06-20 22:27:55.688831
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import unittest

    class RpmKey:
        def __init__(self, module):
            self.module = module

        def execute_command(self, cmd):
            return '', ''

    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.check_mode = supports_check_mode

        def fail_json(self, msg, **kwargs):
            raise AssertionError(msg)

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    class TestModule(unittest.TestCase):

        def test_drop_key(self):
            rpm_key = RpmKey(AnsibleModule({"erase": True}, True))
           

# Generated at 2022-06-20 22:28:00.681908
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.params = dict(state='present', key='deadb33f')
            self.args = dict(key='deadb33f')
            self.run_command_args = []
            self.run_command_calls = 0
            self.fail_json_args = {}
            self.fail_json_calls = 0

        def run_command(self, args, **kwargs):
            self.run_command_args.append(args)
            self.run_command_calls += 1

# Generated at 2022-06-20 22:28:12.579710
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import random
    import string
    import tempfile
    import os.path

    class MockClass(object):

        check_mode = True

        def get_bin_path(self, bin, required=False):
            # import your own gpg binaries here
            return '/usr/bin/gpg'

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

        def fail_json(self, msg):
            raise Exception(msg)

        def add_cleanup_file(self, file):
            pass

    class MockModule(object):

        params = {
            'state': 'present',
            'key': '',
            'validate_certs': True,
        }

        def __init__(self, check_mode):
            self.check_mode = check_

# Generated at 2022-06-20 22:28:45.167933
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class RpmModule:
        def get_bin_path(self, arg, arg2 = None):
            return arg
        def add_cleanup_file(self, arg):
            pass
        def run_command(self, arg, use_unsafe_shell = None):
            if arg == [
                'gpg', '--no-tty', '--batch', '--with-colons',
                '--fixed-list-mode', '--with-fingerprint', '/path/to/key.gpg'
            ]:
                return 0, 'fpr:4B4C7F1C0C56B35A:A5FE5A6910962CCA:1520436784::\nfpr:::::::::B4C7F1C0C56B35A:', ''

# Generated at 2022-06-20 22:28:56.207491
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class test_module:
        params = {}
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "{} output".format(cmd[-1]), ""

        def fail_json(self, msg=None, **kwargs):
            raise Exception("{}".format(msg))

    class test_RpmKey(RpmKey):
        def __init__(self, module):
            pass
        def get_bin_path(self, binname, required=False):
            return "mock {}".format(binname)

    rpm_key = test_RpmKey(test_module)
    stdout, stderr = rpm_key.execute_command([rpm_key.gpg, '-v'])
    assert stdout == "gpg -v output"
    assert st

# Generated at 2022-06-20 22:29:04.792728
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    # Test for a valid keyid
    assert rpm_key.is_keyid('0xDEADBEEF'), "Is keyid: Failure"
    # Test for a valid keyid without 0x
    assert rpm_key.is_keyid('DEADBEEF'), "Is keyid: Failure"
    # Test for a valid keyid with trailing space
    assert rpm_key

# Generated at 2022-06-20 22:29:09.453645
# Unit test for function is_pubkey
def test_is_pubkey():
    is_pubkey("Testing")
    assert is_pubkey("Testing -----BEGIN PGP PUBLIC KEY BLOCK----- blabla -----END PGP PUBLIC KEY BLOCK-----") is False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK----- blabla -----END PGP PUBLIC KEY BLOCK-----") is True

# Generated at 2022-06-20 22:29:21.340692
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    def execute_command_mock(cmd):
        if cmd == ['rpm', '--import', 'test_keyfile']:
            return '', ''
        else:
            raise ValueError('Unexpected command: %s' % cmd)
    module = MockModule(
        dict(
            state='present',
            key='test_keyfile',
            fingerprint='test_fingerprint',
            validate_certs=False,
            gpg='test_gpg'
        ),
        dict(),
        dict()
    )

    rpm_key = RpmKey(module)
    rpm_key.execute_command = execute_command_mock
    rpm_key.import_key('test_keyfile')


# Generated at 2022-06-20 22:29:32.718118
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Setup
    """
    The drop_key() method is tested by the import_key() and is_key_imported(). The test
    class instance created is a stub that uses the call_count to determine if the method
    was called.

    """
    class RpmKeyStub(object):
        def __init__(self):
            self.call_count = 0
        def drop_key(self, keyid):
            self.call_count += 1
    args = {'key': '12345678', 'fingerprint': '', 'state': 'present'}
    rpm_key = RpmKeyStub()
    # Setup

    # Pre-Conditions
    assert rpm_key.call_count == 0
    # Pre-Conditions

    # Execute
    RpmKey(rpm_key, args)
    # Execute

# Generated at 2022-06-20 22:29:39.049145
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible.modules.packaging.os import rpm_key
    assert rpm_key.is_pubkey('key') is False
    assert rpm_key.is_pubkey('''
-----BEGIN PGP PUBLIC KEY BLOCK-----

mQENBE6+zDcBCACrDpWLE6CwE5p5U+trnUJ8quh6HZScxtGhfKbsVe2+h8xJ6ETc
-----END PGP PUBLIC KEY BLOCK-----
''') is True

# Generated at 2022-06-20 22:29:48.204974
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    """Unit test for method getfingerprint of class RpmKey"""
    TEST_KEY_FILE_PATH = "/tmp/test_key_file"
    TEST_KEY_FINGERPRINT = "EBC6E12C62B1C734026B2122A20E52146B8D79E6"
    with open(TEST_KEY_FILE_PATH, "w") as fh:
        fh.write(TEST_KEY_CONTENT)

    rpm_key = RpmKey(None)
    assert rpm_key.getfingerprint(TEST_KEY_FILE_PATH) == TEST_KEY_FINGERPRINT


# Generated at 2022-06-20 22:29:54.235192
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpmkey = RpmKey(None)
    assert rpmkey.is_keyid('0x12345678')
    assert rpmkey.is_keyid('0x1')
    assert rpmkey.is_keyid('12345678')
    assert not rpmkey.is_keyid('0x12345678a')
    assert not rpmkey.is_keyid('0x1234567g')
    assert not rpmkey.is_keyid('0x1234567')
    assert not rpmkey.is_keyid('0x123456789')
    assert not rpmkey.is_keyid('x12345678')
    assert not rpmkey.is_keyid('0x1234567A')

# Generated at 2022-06-20 22:30:01.846916
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    class RpmKeyClass(RpmKey):
        def getkeyid(self, keyfile):
            return '0x8D81803C0EBFCD88'


# Generated at 2022-06-20 22:31:06.953157
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    def mock_fetch_url(module, url):
        """Mock fetch_url, just return a good example."""

# Generated at 2022-06-20 22:31:14.523089
# Unit test for function main
def test_main():
    # test module parameters
    module_params = dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    )
    # test what main does
    main(module_params)

# Generated at 2022-06-20 22:31:21.282941
# Unit test for function main
def test_main():
    """Unit test for function main"""
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-20 22:31:27.132809
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    arg_keyfile = os.path.dirname(os.path.dirname(__file__)) + '/test_data/pgp_key.asc'
    arg_keyid = 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'
    rpm_key = RpmKey(None)
    assert rpm_key.getfingerprint(arg_keyfile) == arg_keyid

# Generated at 2022-06-20 22:31:29.379264
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Arrange
    rpm_key = RpmKey()
    # Act
    rpm_key.drop_key("deadb33f")
    # Assert
    assertEqual(rpm_key.execute_command.called, 1)


# Generated at 2022-06-20 22:31:35.840192
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.common._module_common import ModuleCommon
    module = basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = lambda x, y: (0, "", "")
    RpmKey(module)



# Generated at 2022-06-20 22:31:45.755372
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True)
        ),
        supports_check_mode=True,
    )

    # Test with normal keyid
    keyid = 'DEADB33F'
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid(keyid) == 'DEADB33F'

    # Test with normal keyid with leading 0x
    keyid = '0xDEADB33F'
    rpm_key = RpmKey(module)

# Generated at 2022-06-20 22:31:53.830329
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import pkg_resources

    # Verifies that long key is normalized to short key
    module = pkg_resources.load_entry_point('ansible.builtin', 'action', 'rpm_key')
    assert module.normalize_keyid('DAD17E4C') == 'DAD17E4C'
    assert module.normalize_keyid('0xDAD17E4C') == 'DAD17E4C'
    assert module.normalize_keyid('0x DAD17E4C ') == 'DAD17E4C'


# Generated at 2022-06-20 22:31:59.470713
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import unittest
    import urlparse
    import urllib2
    import shutil
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six.moves.urllib.parse import quote

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils._text import to_bytes, to_native

    class MockResponse():
        def __init__(self, content, status):
            self.content = content
            self.status = status
        def read(self):
            return self.content

    class MockFetchUrl():
        def __init__(self, responses):
            self.responses = responses

# Generated at 2022-06-20 22:32:04.657869
# Unit test for function is_pubkey

# Generated at 2022-06-20 22:34:34.274661
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    response = urllib.request.urlopen('https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/facts/virtual/test_facts.py')
    obj = RpmKey(None)
    tmpname = obj.fetch_key('https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/facts/virtual/test_facts.py')
    assert os.path.isfile(tmpname)
    tmpfile = open(tmpname, "r+b")
    assert tmpfile.read() == response.read()
    assert is_pubkey(response.read()) == False


# Generated at 2022-06-20 22:34:39.319927
# Unit test for function is_pubkey
def test_is_pubkey():
    tests = dict(
        yes='-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----',
        no='-----BEGIN PGP PRIVATE KEY BLOCK-----\n-----END PGP PRIVATE KEY BLOCK-----',
    )
    for test in tests:
        assert is_pubkey(tests[test]) == (test == 'yes')

# Generated at 2022-06-20 22:34:49.273174
# Unit test for function is_pubkey