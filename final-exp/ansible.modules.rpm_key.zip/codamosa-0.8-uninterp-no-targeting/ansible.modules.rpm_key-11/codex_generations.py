

# Generated at 2022-06-20 22:25:00.319857
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test for case when key is not imported
    assert RpmKey.is_key_imported(keyid='12345678') is False


# Generated at 2022-06-20 22:25:11.187122
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    class AnsibleModuleMock:
        def run_command(self, cmd, use_unsafe_shell):
            return 0
        def fail_json(self, msg):
            pass
        def get_bin_path(self, program, required=False, opt_dirs=[]):
            return ""
        def cleanup(self, path):
            pass
        def add_cleanup_file(self, path):
            pass
        def check_mode(self):
            return False

    module = AnsibleModuleMock()
    rpm_key = RpmKey(module)

    key = '12345678'
    assert rpm_key.is_keyid(key) is True

    key = '0x12345678'
    assert rpm_key.is_keyid(key) is True


# Generated at 2022-06-20 22:25:21.954722
# Unit test for function main
def test_main():

    class TestModule:

        def __init__(self, key, state, fingerprint, check_mode):
            self.params = {
                'key': key,
                'state': state,
                'fingerprint': fingerprint,
                'check_mode': check_mode,
            }

        def fail_json(self, msg):
            self.fail_json = msg

        def exit_json(self, changed):
            self.exit_json = changed

        def run_command(self, cmd):
            return 0, 'gpg-pubkey-deadb33f-5ce8a73e', ''

        def get_bin_path(self, cmd, required=False):
            if cmd in ['gpg2', 'rpm']:
                return cmd
            else:
                return None


# Generated at 2022-06-20 22:25:33.566981
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid(RpmKey, '0xDEADB33F') == "DEADB33F"
    assert RpmKey.normalize_keyid(RpmKey, '0XDEADB33F') == "DEADB33F"
    assert RpmKey.normalize_keyid(RpmKey, '0x DEADB33F') == "DEADB33F"
    assert RpmKey.normalize_keyid(RpmKey, ' 0x DEADB33F') == "DEADB33F"
    assert RpmKey.normalize_keyid(RpmKey, ' 0x DEADB33F ') == "DEADB33F"

# Generated at 2022-06-20 22:25:44.804709
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    """
    Test method drop_key of class RpmKey
    """
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    keyid = 'ABCDEF12'
    key_rpm = RpmKey(module)
    rpm_cmd = key_rpm.rpm + ' --erase --allmatches gpg-pubkey-%s' % keyid[-8:]
    setattr(key_rpm.module, 'check_mode', True)
    key

# Generated at 2022-06-20 22:25:51.448349
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    m = FakeModule()
    rm = RpmKey(m)

    assert True == rm.is_keyid('0xDEADB33F')
    assert True == rm.is_keyid('0XDEADB33F')
    assert True == rm.is_keyid('DEADB33F')
    assert False == rm.is_keyid('DEADB33')
    assert False == rm.is_keyid('DEADB33FF')
    assert False == rm.is_keyid('DEADB33F2')
    assert False == rm.is_keyid('deadbeef')
    assert False == rm.is_keyid('bedab33f')

# Generated at 2022-06-20 22:26:00.012516
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    keyfile = "tests/data/RPM-GPG-KEY.dag.txt"
    assert_equal(is_pubkey(rpm_key.fetch_key(keyfile)), True)

# Generated at 2022-06-20 22:26:08.559638
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import unittest
    import tempfile

    class TestRpmKey(unittest.TestCase):
        module = None
        rpmkey = None

        @classmethod
        def setUpClass(cls):
            cls.module = AnsibleModule({'state': 'present'})

            args = {'module': cls.module}
            cls.rpmkey = RpmKey(**args)

        def test_import_key_not_in_check_mode(self):
            """ Verifies that we can import a key in a non-check-mode scenario """
            # Use a tempfile
            tmpfd, tmpname = tempfile.mkstemp()
            self.module.cleanup_files.append(tmpname)
            tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-20 22:26:11.233816
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    keyfile = './test/fixtures/ansible_rpm_key/gpg-pubkey-deadb33fdeadb33f.pub'
    rpm_key = RpmKey(None)
    assert rpm_key.getkeyid(keyfile) == 'DEADB33FDEADB33F'


# Generated at 2022-06-20 22:26:15.943437
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Mock the AnsibleModule class
    mock_module = mock.Mock()

    # Mock the rpm module
    mocked_rpm = mock.Mock(return_value=0)

    # Instantiate RpmKey class with the mocked module
    rpk = RpmKey(mock_module)

    # Assign the mocked module
    rpk.module = mock_module

    # Assign the mocked rpm
    rpk.rpm = mocked_rpm

    # Import a key
    rpk.import_key('keyfile')

    # Assert that the rpm import command has been called
    assert mocked_rpm.called

# Generated at 2022-06-20 22:26:37.610740
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_key = RpmKey(module)

    good_key = [ '0xDEADB33F' , 'DEADB33F', 'DEADB33F ', ' DEADB33F ', '0xDEADB33F' ]

# Generated at 2022-06-20 22:26:44.011772
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test = RpmKey(module)

    assert test.is_key_imported('deadb33f') == False
    assert test.is_key_imported('9c800aca') == True

# Generated at 2022-06-20 22:26:50.373924
# Unit test for constructor of class RpmKey
def test_RpmKey():
    params = dict(
        state='present',
        key='http://apt.sw.be/RPM-GPG-KEY.dag.txt',
        fingerprint=None,
        validate_certs=True,
    )
    mod = AnsibleModule(argument_spec=params)
    inst = RpmKey(mod)
    assert isinstance(inst, RpmKey)

# Generated at 2022-06-20 22:27:00.417255
# Unit test for function is_pubkey
def test_is_pubkey():
    from .rpmkey import is_pubkey

    message = "Is a public key"
    response = is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\niQIcBAABCAAGBQJRYDttAAoJEH9Qoan6TeUTLpkP/0rMtnzjrvZJwKb+EI2e2/IX\n...\n-----END PGP PUBLIC KEY BLOCK-----')
    assert response == True, message
    message = "Is not a public key"

# Generated at 2022-06-20 22:27:12.698706
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    test_module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ),
        supports_check_mode=True,
    )
    test_module.params = {
        'state' : 'absent',
        'fingerprint': None,
        'validate_certs' : True,
        'key': 'this_is_a_test_key'
    }
    rpmKey = RpmKey(test_module)
    rpmKey.rpm = 'rpm'
    rpmKey.gpg = 'gpg'
    rpmKey

# Generated at 2022-06-20 22:27:18.023950
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    key_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    key_module.run_command = MagicMock()
    key = RpmKey(key_module)
    key.rpm = 'rpm'
    key_module.check_mode = False
    key.drop_key('key_id')
    key_module.run_command.assert_called_with('rpm --erase --allmatches gpg-pubkey-key_id', use_unsafe_shell=True)


# Generated at 2022-06-20 22:27:31.988468
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = mock.Mock()
    module.params = dict(state='present', key='http://apt.sw.be/RPM-GPG-KEY.dag.txt', fingerprint=None)
    module.get_bin_path.return_value = '/usr/bin/rpm'
    module.run_command.return_value = (0, "", "")

    real_fetch_url = fetch_url
    fetch_url_results = [(0, mock.Mock(), mock.Mock())]
    fetch_url_results[0][1].read.return_value = "pubkey"
    def mock_fetch_url(*args, **kwargs):
        return fetch_url_results.pop(0)


# Generated at 2022-06-20 22:27:40.022957
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    msg = "The specified fingerprint, 'EBC6E12C62B1C734026B2122A20E52146B8D79E6', does not match the key fingerprint '6B8D79E6'"
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey_instance = RpmKey(module)

# Generated at 2022-06-20 22:27:45.854233
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Unit test for method drop_key of class RpmKey
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_RpmKey = RpmKey(test_module)

    testcmd = test_RpmKey.rpm + ' -q  gpg-pubkey'
    test_RpmKey.module.run_command = MagicMock(return_value=(0, 'output', 'error'))

# Generated at 2022-06-20 22:27:54.596853
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.basic import AnsibleModule

    # Monkey patching to avoid actual import
    def execute_command(module, cmd):
        if cmd[-1] == 'E12C62B1C7':
            return (0, 'pub:r:2048:1:E12C62B1C7:1414141414141414', '')
        elif cmd[-1] == 'DEADBEEF':
            return (0, '', '')


# Generated at 2022-06-20 22:28:33.223458
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from ansible.module_utils.basic import AnsibleModule

    # Defined in the module
    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught to exit
        normal execution.

        This class is instantiated and raised with the key-values returned in
        the ``module.exit_json()`` dict.
        """

        def __init__(self, **kwargs):
            self.kwargs = kwargs
            super(AnsibleExitJson, self).__init__(self, **kwargs)


# Generated at 2022-06-20 22:28:43.153862
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule

    fingerprint = 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6'

    test_file = tempfile.mkstemp()[1]

# Generated at 2022-06-20 22:28:53.344214
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
  class TestObject:
    def run_command(cmd):
      if cmd[0] == 'echo':
        # return return code, stdout, stderr
        return (0, "1", "")
      else:
        return (1, "", "")

  rpm = RpmKey(TestObject)

  stdout, stderr = rpm.execute_command([rpm.rpm, '--version'])
  assert stdout == "1"
  assert stderr == ""


# Generated at 2022-06-20 22:29:02.571508
# Unit test for function main
def test_main():
    """
    Unit test for function main
    :return:
    """

    import json
    import os
    import sys

    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import StringIO

    from ansible_collections.ansible.builtin.tests.unit.modules.utils import set_module_args
    from ansible_collections.ansible.builtin.plugins.module_utils.rpm_key import RpmKey

    # Key with fingerprint
    key_id = '0xDEADB33F'
    key_fingerprint = 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6'

    # Fake 'rpm'

# Generated at 2022-06-20 22:29:14.411460
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm = RpmKey(module)

# Generated at 2022-06-20 22:29:26.092712
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    class Module():
        def __init__(self):
            pass

        def run_command(self, command):
            return 0, command, b''

        def fail_json(self, msg):
            raise Exception(msg)

        def exit_json(self, changed):
            pass

        def get_bin_path(self, *args):
            return 'true'

        def add_cleanup_file(self, path):
            pass

        def cleanup(self, tmp):
            pass

        def check_mode(self):
            pass

    class AnsibleModule():
        def __init__(self, dict, *args):
            self.params = dict

    module = Module()

# Generated at 2022-06-20 22:29:31.507163
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-20 22:29:39.401920
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible.module_utils.old_rpm_utils import is_pubkey
    from ansible.module_utils.six import b
    key = b('''-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: GnuPG v1.4.14 (GNU/Linux)

mI0ESDjuJgEEALWCjKZ2oxXZbN/Q2nPJN8NnkL1Nxz1N/pJfHG+/o9/IomlsdyQ2

-----END PGP PUBLIC KEY BLOCK-----''')
    assert is_pubkey(key) is True

# Generated at 2022-06-20 22:29:48.226790
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import mock
    module = mock.MagicMock()
    module.run_command = mock.MagicMock()

    rpm = RpmKey(module)
    rpm.rpm = "rpm"
    # Test command return value for key installed on system
    module.run_command.return_value = 0, "gpg-pubkey-7f3bd47e-49bdd428", ""
    stdout = "pub:u:1:7F3BD47E:1531326574:::u:7F3BD47E:1531326574::::::e\n"
    stderr = ""
    rpm.execute_command = mock.MagicMock(return_value=(stdout, stderr))
    assert rpm.is_key_imported("7F3BD47E")

    # Test command return value for key not installed on

# Generated at 2022-06-20 22:29:59.328733
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    data = {}

    class FakeAnsibleModule(object):
        def __init__(self):
            self.check_mode = False
            self.params = data
            self.exit_json = None

        def run_command(self, command, use_unsafe_shell=True):
            return 0, "Hello", ""

    class FakeRpmKey(object):
        def __init__(self, module):
            self.module = module
            self.rpm = "/bin/rpm"
            self.gpg = "/bin/gpg"

    data['key'] = ["Hello", "World"]
    rpm_key = FakeRpmKey(FakeAnsibleModule())
    assert rpm_key.execute_command(["ls"]) == (u"Hello", u"")

# Generated at 2022-06-20 22:30:57.721543
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    keyid_test1 = RpmKey.normalize_keyid('  0x5a5e3537')
    keyid_test2 = RpmKey.normalize_keyid('0XA0CBA695')
    keyid_test3 = RpmKey.normalize_keyid('a0cba695')

    assert keyid_test1 == keyid_test2 and keyid_test1 == keyid_test3 and keyid_test2 == keyid_test3

# Generated at 2022-06-20 22:31:07.709383
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    from ansible.module_utils import basic
    from ansible.modules.system.rpm_key import RpmKey
    from ansible.module_utils.urls import fetch_url
    import tempfile
    import os.path
    class MockedModule(basic.AnsibleModule):
        def __init__(self):
            self.argument_spec = dict(
                state=dict(type='str', default='present', choices=['absent', 'present']),
                key=dict(type='str', required=True, no_log=False),
                fingerprint=dict(type='str'),
                validate_certs=dict(type='bool', default=True),
            )

            self.run_command_calls = 0

# Generated at 2022-06-20 22:31:11.463172
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    a = RpmKey(object)
    a.module.run_command = mock_module_run_command
    a.execute_command = mock_execute_command
    a.drop_key("0xDEADBEEF")



# Generated at 2022-06-20 22:31:23.197754
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.rpm_key import RpmKey
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from contextlib import contextmanager
    import sys
    import os

    @contextmanager
    def mock_run_command(stdout, stderr):
        module = AnsibleModule(
            argument_spec=dict(
                state=dict(default='present', choices=['absent', 'present']),
                key=dict(required=True),
                validate_certs=dict(default=True, type='bool'),
                fingerprint=dict(type='str'),
            ),
            supports_check_mode=True,
        )

# Generated at 2022-06-20 22:31:32.514833
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class MockRpmKey:
        def __init__(*args, **kwargs):
            pass


# Generated at 2022-06-20 22:31:37.340642
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import tempfile

    tmpfd, tmpname = tempfile.mkstemp()
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd, use_unsafe_shell=False: (0, 'stdout', '')
    rpm_key = RpmKey(module)

    # Valid command
    cmd = [rpm_key.rpm, '-q', 'gpg-pubkey']
    expected_stdout = 'stdout'
    actual_stdout, actual_stderr = rpm_key.execute_command(cmd)
    assert actual_stdout == expected_stdout
    assert actual_stderr == ''

    # Command failure

# Generated at 2022-06-20 22:31:46.514581
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from ansible.module_utils._text import to_bytes
    class AnsibleModule:
        def fail_json(self, msg):
            raise ValueError(msg)

        @staticmethod
        def get_bin_path(binary, required=False):
            if binary == 'gpg':
                return '/bin/gpg'
            elif binary == 'rpm':
                return '/bin/rpm'
            raise ValueError("Unexpected %s" % binary)

        @staticmethod
        def add_cleanup_file(tmpname):
            pass

    rpmKey = RpmKey(AnsibleModule)
    tmpfd, tmpname = tempfile.mkstemp()
    with os.fdopen(tmpfd, "w+b") as tmpfile:
        tmpfile.write(to_bytes(TEST_GPG_KEY))



# Generated at 2022-06-20 22:31:54.226387
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    check_output_value = "Key imported"
    mock_module = MagicMock()
    mock_module.check_mode = False
    mock_self = MagicMock()
    mock_self.module = mock_module
    with patch('ansible.module_utils.rpm_key.RpmKey.execute_command', return_value=(check_output_value, "")) as mock_method:
        RpmKey.import_key(mock_self, "test_key_file")
        assert mock_method.call_count == 1


# Generated at 2022-06-20 22:32:05.322575
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = type('', (), {'run_command': lambda self, cmd, use_unsafe_shell=True: (0, '', ''), 'get_bin_path': lambda self, name, required=True: '/bin/'+name})()
    module.fail_json = lambda msg: __builtins__['assert'](False, msg)
    rpm_key = RpmKey(module)
    __builtins__['assert'](rpm_key.is_keyid("0xDEADB33F"))
    __builtins__['assert'](rpm_key.is_keyid("deadb33f"))
    __builtins__['assert'](not rpm_key.is_keyid("test"))
    __builtins__['assert'](not rpm_key.is_keyid("0xtest"))

# Generated at 2022-06-20 22:32:14.876094
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class RpmKey():
        def __init__(self, module):
            self.module = module

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    assert rpm_key.is_key_imported("0xA20E52146B8D79E6") is True
    assert rpm_key.is_key_imported("DEADB33F") is False


# Generated at 2022-06-20 22:34:37.880510
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import pytest
    module = pytest.Mock()
    module.check_mode = False
    rpm_key = RpmKey(module)
    rpm_key.rpm = 'rpm'
    rpm_key.drop_key('DEADBEEF')
    module.run_command.assert_called_with(['rpm', '--erase', '--allmatches', 'gpg-pubkey-deadbeef'], use_unsafe_shell=True)


# Generated at 2022-06-20 22:34:46.707164
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    from ansible_collections.ansible.builtin.plugins.modules.packaging.os.rpm_key import RpmKey

    tmpfd, tmpname = tempfile.mkstemp()
    os.fdopen(tmpfd, "w+b").write(b"-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----")
    os.remove(tmpname)

    r = RpmKey(AnsibleModule(argument_spec={}))
    r.gpg = 'gpg'
    assert r.getfingerprint(tmpname) == "EBC6E12C62B1C734F2F2C9AE52146B8D79E6"

# EOF