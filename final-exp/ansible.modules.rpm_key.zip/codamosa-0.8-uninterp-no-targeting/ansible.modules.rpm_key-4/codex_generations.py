

# Generated at 2022-06-20 22:25:06.209163
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert RpmKey.normalize_keyid("0XDEADB33F") == "DEADB33F"
    assert RpmKey.normalize_keyid(" DEADB33F ") == "DEADB33F"

# Generated at 2022-06-20 22:25:16.972636
# Unit test for constructor of class RpmKey
def test_RpmKey():

    # Key is url, but download fails
    url = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    def fail_fetch(module, *args, **kwargs):
        return None, {'status': 500, 'msg': 'Mocked error'}
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.fail_json = MagicMock()
    module.cleanup = MagicMock()
    module.get_bin_path = MagicMock(return_value=True)
    module.params = {
        'state': 'present',
        'key': url,
        'validate_certs': True,
    }

# Generated at 2022-06-20 22:25:23.668179
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpmkey = RpmKey(None)
    assert rpmkey.normalize_keyid("0xDEADBEEF") == "DEADBEEF"
    assert rpmkey.normalize_keyid(" 0xDEADBEEF ") == "DEADBEEF"
    assert rpmkey.normalize_keyid("DEADBEEF") == "DEADBEEF"
    assert rpmkey.normalize_keyid("0XDEADBEEF") == "DEADBEEF"


# Generated at 2022-06-20 22:25:34.575015
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class DummyModule(object):
        def fail_json(self, msg, **kwargs):
            print(msg)
    class DummyModuleRunCommand(object):
        def run_command(self, cmd, **kwargs):
            print(cmd)
            return 0, 'fpr:::::::::29D67F91E1A19FCF1E6A5D11A5DB8B5E6B72C2A2:', ''

    module = DummyModule()
    module.run_command = DummyModuleRunCommand().run_command
    keyfile = '/path/to/key.gpg'
    fingerprint = RpmKey(module).getfingerprint(keyfile)

# Generated at 2022-06-20 22:25:45.559428
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Testing method normalize_keyid of class RpmKey
    # Ensuring that a keyid, when given to the
    # normalize_keyid method, it returns a keyid
    # without leading zeroes, without whitespace
    # and in upper case format

    rpm_key = RpmKey(None)
    keyid = rpm_key.normalize_keyid("0xDEADBEEF")
    assert keyid == "DEADBEEF"
    keyid = rpm_key.normalize_keyid(" 0xDEADBEEF ")
    assert keyid == "DEADBEEF"
    keyid = rpm_key.normalize_keyid(" 0xDEADBeEF ")
    assert keyid == "DEADBEEF"

# Generated at 2022-06-20 22:25:53.262585
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Setup test data
    keyfile = "test_data/RPM-GPG-KEY.dag.txt"
    gpg2 = "/usr/bin/gpg2"
    # Execute test
    rpm_key_obj = RpmKey_Class(None, None)
    fingerprint = rpm_key_obj.getfingerprint(keyfile, gpg2)
    # Verify results
    assert fingerprint == "EBC6E12C62B1C734026B2122A20E52146B8D79E6"


# Generated at 2022-06-20 22:26:03.585575
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockCommand(object):
        def __init__(self, stdout, stderr, rc):
            self.stdout = stdout
            self.stderr = stderr
            self.rc = rc

        def run_command(self, cmd, use_unsafe_shell=False):
            return (self.rc, self.stdout, self.stderr)

    module = MockModule()

# Generated at 2022-06-20 22:26:13.952210
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible_collections.ansible.builtin.plugins.modules.rpm_key import is_pubkey

# Generated at 2022-06-20 22:26:18.758393
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
  # We create a fake keyfile, as we can't assume this test will have internet access
  tempfd, keyfile = tempfile.mkstemp()
  tmpfile = os.fdopen(tempfd, "w+")
  tmpfile.write(PUBKEY)
  tmpfile.close()

  # Create test class
  rpm = RpmKey(None)

  # Test true
  assert rpm.getkeyid(keyfile) == '2122A20E52146B8D79E6'

  # Cleanup
  os.unlink(keyfile)


# Generated at 2022-06-20 22:26:30.367755
# Unit test for function main
def test_main():
    import os
    import tempfile
    # Test the import of a key

# Generated at 2022-06-20 22:26:52.219702
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module_mock = AnsibleModule({})
    rpm_key = RpmKey(module_mock)
    module_mock.check_mode = False
    rpm_key.import_key("/path/to/key.gpg")
    module_mock.run_command.assert_called_once_with(['/bin/rpm', '--import', '/path/to/key.gpg'], use_unsafe_shell=True)


# Generated at 2022-06-20 22:27:02.486556
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Use:
    # pytest -s test_rpm_key.py::test_RpmKey_fetch_key
    #  or
    # python -m pytest test_rpm_key.py::test_RpmKey_fetch_key
    #  to run it
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_text
    from mock import patch
    class FakeModule(object):
        pass
    fake_module = FakeModule()
    fake_module.get_bin_path = lambda x, y: 'rpm'
    fake_module.run_command = lambda x, y: 'echo', 'stdout', 'stderr'
    fake_module.cleanup = lambda x: True

# Generated at 2022-06-20 22:27:13.823487
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey(u'-----BEGIN PGP PUBLIC KEY BLOCK-----\nXXX\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey(u'-----BEGIN PGP PUBLIC KEY BLOCK-----\nXXX\n')
    assert not is_pubkey(u'-----BEGIN PGP PUBLIC KEY BLOCK-----\nXXX')
    assert not is_pubkey(u'-----BEGIN PGP PUBLIC KEY BLOCK-----\nXXX\n-----END PGP PRIVATE KEY BLOCK-----')
    assert not is_pubkey(u'XXX\n-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey(u'-----BEGIN PGP PUBLIC KEY BLOCK-----\nXXX')

# Generated at 2022-06-20 22:27:23.252139
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = "some_rpm"
    mock_module.run_command.return_value = (0, "", "")
    mock_module.check_mode = False

    rpmkey = RpmKey(mock_module)
    rpmkey.drop_key("0xDEADBEEF")

    expected_calls = [
        call('some_rpm -q  gpg-pubkey'),
        call('some_rpm --erase --allmatches gpg-pubkey-deadbeef')
    ]

    assert mock_module.run_command.call_count == 2
    mock_module.run_command.assert_has_calls(expected_calls)


# Generated at 2022-06-20 22:27:28.023571
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    mod = AnsibleModule(argument_spec={})
    assert RpmKey(mod).normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert RpmKey(mod).normalize_keyid(' 0xDEADBEEF ') == 'DEADBEEF'
    assert RpmKey(mod).normalize_keyid('0xDEADBEEF ') == 'DEADBEEF'
    assert RpmKey(mod).normalize_keyid(' 0xDEADBEEF') == 'DEADBEEF'
    assert RpmKey(mod).normalize_keyid(' 0XDEADBEEF') == 'DEADBEEF'
    assert RpmKey(mod).normalize_keyid(' DEADBEEF') == 'DEADBEEF'
   

# Generated at 2022-06-20 22:27:35.682686
# Unit test for constructor of class RpmKey
def test_RpmKey():
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_RpmKey = RpmKey(test_module)

    assert test_RpmKey

# Unit tests for validate the different possibilities for key

# Generated at 2022-06-20 22:27:45.612618
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.getfingerprint(keyfile = 'file_path')
    if rpm_key.getfingerprint(keyfile = 'file_path') is not None:
        return True
    else:
        return False



# Generated at 2022-06-20 22:27:53.426455
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    key_id = "DEADB33F"

    # set needed args for RpmKey
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)

    # mock to return a key id
    exec_command_return = [""]
    exec_command_mock = MagicMock(return_value=exec_command_return)
    rpm_key.rpm = "rpm"
    rpm_key.gpg = "gpg"

# Generated at 2022-06-20 22:28:06.191084
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    m = mock.mock_open(read_data='test')


# Generated at 2022-06-20 22:28:16.705546
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    # make sure that no rpm keys are installed
    assert False == rpm_key.is_key_imported("deadb33f")
    # import a key
    keyfile = tempfile.mkstemp()[1]
    rpm_key.import_key(keyfile)
    # make sure that rpm key is installed after import
   

# Generated at 2022-06-20 22:28:48.394183
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six.moves import StringIO

    class RpmKeyMock(RpmKey):
        def __init__(self, module):
            pass

    module_mock = ImmutableDict()
    rpm_key_mock = RpmKeyMock(module_mock)

    assert rpm_key_mock.is_keyid('12345678') == True
    assert rpm_key_mock.is_keyid('0x12345678') == True
    assert rpm_key_mock.is_keyid('0x1234567') == False
    assert rpm_key_mock.is_keyid('0X12345678') == True

# Generated at 2022-06-20 22:28:58.726365
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    stdout, stderr = rpm_key.execute_command(['echo', 'test'])
    assert stdout == 'test\n'
    assert '' == stderr


# Generated at 2022-06-20 22:29:13.010712
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpmkey.normalize_keyid('0xDEADB33F ') == 'DEADB33F'
    assert rpmkey.normalize_keyid(' DEADB33F') == 'DEADB33F'
    assert rpm

# Generated at 2022-06-20 22:29:23.653346
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    mock_module = MagicMock()
    rpm_key = RpmKey(mock_module)

    mock_module.run_command = MagicMock(return_value=(0, '', ''))
    rpm_key.execute_command(['pwd'])

    mock_module.run_command.assert_called_with(['pwd'], use_unsafe_shell=True)

    mock_module.run_command = MagicMock(return_value=(1, 'test_stdout', 'test_stderr'))
    with pytest.raises(SystemExit):
        rpm_key.execute_command(['pwd'])


# Generated at 2022-06-20 22:29:33.354104
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import os.path
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native

    rsp, info = fetch_url('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    if info['status'] != 200:
        self.module.fail_json(msg="failed to fetch key at %s , error was: %s" % (url, info['msg']))
    key = rsp.read()
    if not is_pubkey(key):
        self.module.fail_json(msg="Not a public key: %s" % url)

    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fd

# Generated at 2022-06-20 22:29:39.370867
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_module.exit_json = exit_json
    test_module.fail_json = fail_json

    RpmKey(test_module)

# Generated at 2022-06-20 22:29:47.378515
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rk = RpmKey(None)
    assert rk.is_keyid('DEADB33F')
    assert rk.is_keyid('0xDEADB33F')
    assert rk.is_keyid('DEADB33') == False
    assert rk.is_keyid('0xDEADB33') == False
    assert rk.is_keyid('DEADB33F ') == False
    assert rk.is_keyid(' DEADB33F') == False
    assert rk.is_keyid('DEAD B33F') == False
    assert rk.is_keyid('DEADB333F') == False


# Generated at 2022-06-20 22:29:56.970089
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    if rpm_key.is_key_imported('99DB9E9E'):
        pass



# Generated at 2022-06-20 22:30:08.386889
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Given
    module = Mock()

    keyfile = 'my.key'
    stdout = '  fpr:::::::::20F556CD9D6B134E66C2A7B49C1B8089D5D2DFC0:'
    stderr = ''
    code = 0
    run_command = Mock(return_value=(code, stdout, stderr))
    module.run_command = run_command

    # When
    rpm_key = RpmKey(module)
    fingerprint = rpm_key.getfingerprint(keyfile)

    # Then
    assert '20F556CD9D6B134E66C2A7B49C1B8089D5D2DFC0' == fingerprint



# Generated at 2022-06-20 22:30:15.170890
# Unit test for function is_pubkey

# Generated at 2022-06-20 22:31:11.581313
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----") is False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----") is True

# Generated at 2022-06-20 22:31:22.153047
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import unittest.mock
    module = unittest.mock.MagicMock()
    module.run_command = unittest.mock.MagicMock()
    key = unittest.mock.MagicMock()
    key.__str__ = unittest.mock.MagicMock(return_value='test.txt')
    key.read = unittest.mock.MagicMock(return_value=b'key')
    rpm_key = RpmKey(module)
    rpm_key.import_key(key)
    module.run_command.assert_called_with([rpm_key.rpm, '--import', key.__str__()])

# Generated at 2022-06-20 22:31:28.311484
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    rpmkey = RpmKey()
    assert rpmkey.is_keyid("0xdeadbeef") == true
    assert rpmkey.is_keyid("deadbeef") == true
    assert rpmkey.is_keyid("deadbeefdeadbeef") == false
    assert rpmkey.is_keyid("deadbeef1") == false
    assert rpmkey.is_keyid("dead") == false
    assert rpmkey.is_keyid("0x") == false

# Generated at 2022-06-20 22:31:35.417146
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import unittest
    import mock
    import module_utils.urls

    def mocked_fetch_url(module, url):
        if url == 'https://testurl.com':
            return 0, 'TESTKEY'
        if url == 'https://testurl2.com':
            return 0, 'NOTAPUBKEY'
        if url == 'https://testurl3.com':
            return 1, 'Error'

    class AnsibleModule_mock(object):
        def __init__(self, argument_spec):
            pass

        def get_bin_path(self, executable, required=False):
            return executable

        def add_cleanup_file(self, filepath):
            pass

    class ModuleExitException(Exception):
        pass


# Generated at 2022-06-20 22:31:37.431949
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    RpmKey.fetch_key(key)



# Generated at 2022-06-20 22:31:46.580241
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Test keyid with 8 chars, uppercase and lowercase, with and without leading 0x
    assert RpmKey({}).is_keyid('DEADB33F')
    assert RpmKey({}).is_keyid('deadb33f')
    assert RpmKey({}).is_keyid('0xDEADB33F')
    assert RpmKey({}).is_keyid('0xdeadb33f')
    # Test keyid with 32 chars, uppercase and lowercase, with and without leading 0x
    assert RpmKey({}).is_keyid('DEADB33FDEADB33F')
    assert RpmKey({}).is_keyid('deadb33fdeadb33f')

# Generated at 2022-06-20 22:31:56.824391
# Unit test for constructor of class RpmKey
def test_RpmKey():
    p = {"state": "present",
         "key": "https://example.com/key.gpg",
         "fingerprint": "1234",
         "validate_certs": True}

    print(p)

    p1 = p.copy()
    p1["key"] = "https://exa/key.gpg"
    p1["validate_certs"] = False

    print(p1)

    p2 = p.copy()
    p2["state"] = "absent"

    print(p2)

    p3 = p2.copy()
    p3["key"] = "https://exa/key.gpg"
    print(p3)

    rpms = [RpmKey(p), RpmKey(p1), RpmKey(p2), RpmKey(p3)]

# Generated at 2022-06-20 22:31:59.841828
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    temp_obj = RpmKey()
    assert ('ABCD1234' == temp_obj.normalize_keyid('ABCD1234'))
    assert ('ABCD1234' == temp_obj.normalize_keyid('0xabcd1234'))
    assert ('ABCD1234' == temp_obj.normalize_keyid(' 0xabcd1234\n'))


# Generated at 2022-06-20 22:32:06.095483
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    obj = RpmKey(None)
    assert obj.normalize_keyid(' deadbeef ') == 'DEADBEEF'
    assert obj.normalize_keyid(' DEADBEEF ') == 'DEADBEEF'
    assert obj.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert obj.normalize_keyid('0xDEADBEEF ') == 'DEADBEEF'


# Generated at 2022-06-20 22:32:14.637007
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_class = RpmKey(module)
    output = test_class.getfingerprint('test')
    assert output == 'EBC6E12C62B1C734 026B2122A20E5214 6B8D79E6'


# Generated at 2022-06-20 22:34:47.444513
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = {}
    setattr(module, 'params', {
        'state': 'present',
        'key': 'http://ftp.disi.unitn.it/linux/fedora-epel/RPM-GPG-KEY-EPEL-6',
        'fingerprint': None,
        'validate_certs': True
    })
    setattr(module, 'run_command', my_mock_run_command)
    setattr(module, 'get_bin_path', my_mock_get_bin_path)
    setattr(module, 'add_cleanup_file', my_mock_add_cleanup_file)
    setattr(module, 'cleanup', my_mock_cleanup)
    setattr(module, 'fail_json', my_mock_fail_json)
   