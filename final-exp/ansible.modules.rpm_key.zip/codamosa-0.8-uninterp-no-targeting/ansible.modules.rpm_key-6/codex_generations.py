

# Generated at 2022-06-20 22:25:07.165558
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    r = RpmKey()
    assert r.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert r.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert r.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert r.normalize_keyid('0xDEADBEEF  ') == 'DEADBEEF'
    assert r.normalize_keyid(' 0xDEADBEEF') == 'DEADBEEF'
    assert r.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-20 22:25:17.391201
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import os
    RpmKey.is_keyid = lambda self, key: True
    RpmKey.is_key_imported = lambda self, key: False
    RpmKey.normalize_keyid('ABCD1234') == 'ABCD1234'
    RpmKey.normalize_keyid('0xABCD1234') == 'ABCD1234'
    RpmKey.getkeyid('/path/to/a/keyfile.gpg') == 'ABCD1234'
    RpmKey.import_key('/path/to/a/keyfile.gpg')
    RpmKey.drop_key('ABCD1234')
    RpmKey.fetch_key('file:///path/to/a/keyfile.gpg') == '/path/to/a/keyfile.gpg'
   

# Generated at 2022-06-20 22:25:20.316805
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    class RpmKey(object):
        @staticmethod
        def execute_command(cmd):
            return

    rpmkey = RpmKey(None)
    rpmkey.drop_key('DEADBEEF')

# Generated at 2022-06-20 22:25:30.702331
# Unit test for function main
def test_main():
    # Exit with error message when path to gpg binary is not found
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1
    # Test with key and state present
    from ansible.module_utils.actions import AnsibleModule
    m = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Set gpg binary

# Generated at 2022-06-20 22:25:33.204629
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import ansible.module_utils.rpm_key
    keyfile = ansible.module_utils.rpm_key.RpmKey("test_RpmKey")

# Generated at 2022-06-20 22:25:43.039215
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import os
    import unittest

    class TestModule(object):
        module = None

        def __init__(self, tmpdir):
            os.environ['HOME'] = str(tmpdir)
            self.module = AnsibleModule(
                argument_spec=dict(
                    state=dict(type='str', default='present', choices=['absent', 'present']),
                    key=dict(type='str', required=True, no_log=False),
                    fingerprint=dict(type='str'),
                    validate_certs=dict(type='bool', default=True),
                ),
                supports_check_mode=True,
            )

        def run_command(self, cmd):
            gpghome = os.path.join(self.module.env['HOME'], '.gnupg')
            keyid = self.module

# Generated at 2022-06-20 22:25:51.786937
# Unit test for method execute_command of class RpmKey

# Generated at 2022-06-20 22:25:57.084711
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import os
    import sys
    import unittest

    from ansible.module_utils.urls import fetch_url

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            from contextlib import contextmanager

            # If the gpg module is loaded using an alias (like rpm_key),
            # the module name is not "ansible.builtin.rpm_key" as we expect.
            # Also, if the module is installed as a github plugin,
            # the name will be something like github/ansible/ansible#head/lib/ansible/modules/packaging/os/rpm_key.py
            if sys.modules['__main__'].__file__.endswith('rpm_key.py'):
                self.module_name = 'ansible.builtin.rpm_key'

# Generated at 2022-06-20 22:26:02.325181
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    """
    Unit test for method drop_key of class RpmKey
    """
    def test_fetch_key():
        """
       Unit test for method fetch_key of class RpmKey
        """

    def test_is_key_imported():
        """
       Unit test for method is_key_imported of class RpmKey
        """
    pass

# Generated at 2022-06-20 22:26:03.426941
# Unit test for constructor of class RpmKey
def test_RpmKey():
  # Test for constructor of class RpmKey
  assert RpmKey

# Generated at 2022-06-20 22:26:21.614607
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Unittest stub for method drop_key of class RpmKey
    keyfile = 'test_RpmKey_getkeyid'
    ret = RpmKey.getkeyid(keyfile)
    assert ret == ret


# Generated at 2022-06-20 22:26:28.664830
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_object = RpmKey(None)
    assert test_object.normalize_keyid('0x12345678') == '12345678'
    assert test_object.normalize_keyid('12345678') == '12345678'
    assert test_object.normalize_keyid('0X12345678') == '12345678'
    assert test_object.normalize_keyid('0x12345678 ') == '12345678'


# Generated at 2022-06-20 22:26:33.768444
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    filename = '/path/to/fake/file'
    rpm = 'rpm'
    gpg = 'gpg'

    rpm_key = RpmKey(module)

    with patch.object(rpm_key, 'execute_command') as mock_execute:
        rpm_key.import_key(filename)
        mock_execute.assert_called_once_with([rpm, '--import', filename])


# Generated at 2022-06-20 22:26:40.476107
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, 'fpr:::::::::F24F9E3F3C4D4C0E95EDD2F2BC8C07BA60C0335B:', ''
    rpm_key = RpmKey(MockModule())

    assert(rpm_key.getfingerprint('testfile') == 'F24F9E3F3C4D4C0E95EDD2F2BC8C07BA60C0335B')


# Generated at 2022-06-20 22:26:48.259500
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    import tempfile
    import os
    import shutil
    import sys
    test_dir = tempfile.mkdtemp()
    old_dir = os.getcwd()
    os.chdir(test_dir)
    sys.path.insert(0, test_dir)
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    module = type('AnsibleModule', (object,), dict(
        argument_spec=dict(),
        params=dict(key="22223333"),
        fail_json=lambda *args, **kwargs: sys.exit(1),
    ))()
    rpmkey = RpmKey(module)
    assert rpmkey.is_keyid("22223333")

# Generated at 2022-06-20 22:26:57.668471
# Unit test for function main
def test_main():
    # Mock RpmKey
    # Get file name of rpm_key module
    this_file = os.path.abspath(__file__)
    dir_name = os.path.dirname(this_file)
    rpm_key_file = os.path.join(dir_name, '../../../../module_utils/rpm_key.py')

    # Import module
    __mod = None
    exec('import ansible_collections.ansible.builtin.plugins.module_utils.rpm_key as rpm_key')
    exec('__mod = rpm_key')

    # Patch
    orig = __mod.RpmKey
    try:
        __mod.RpmKey = MockRpmKey
        # Call main()
        exec(open(rpm_key_file).read())
    except Exception as err:
        print

# Generated at 2022-06-20 22:27:09.672378
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import unittest
    from mock import MagicMock
    from ansible.module_utils.basic import AnsibleModule

    class UnitTestRpmKey(unittest.TestCase):
        def test_RpmKey_execute_command(self):
            # set up a mock module and mock module class
            module_class = AnsibleModule
            module_class.run_command = MagicMock()
            module_class.exit_json = MagicMock()
            module_class.fail_json = MagicMock()
            module = MagicMock()
            # setup RpmKey object to test
            rpm_key_object = RpmKey(module)
            # set up mocks
            # mock module with some random values
            module.get_bin_path.return_value = 'mock_bin_path'
            module.check_mode

# Generated at 2022-06-20 22:27:13.966266
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    rpms = RpmKey(None)
    assert os.path.isfile(rpms.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt"))
    assert not os.path.isfile(rpms.fetch_key("https://www.google.com"))
    assert not os.path.isfile(rpms.fetch_key("https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/system/rpm_key.py"))


# Generated at 2022-06-20 22:27:22.003390
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Run the execute_command method of the class
    rpm_key = RpmKey(module)
    output, error = rpm_key.execute_command([rpm_key.rpm, "--help"])
    assert "--import" in output
    assert "" == error

# Generated at 2022-06-20 22:27:34.259530
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import os.path
    import tempfile
    import ansible.module_utils.common.collections
    import ansible.module_utils.basic

    class BaseModule(object):
        """Mock class for backwards compat with Ansible 2.6."""
        @property
        def params(self):
            return self._params

        @params.setter
        def params(self, value):
            self._params = value

        @property
        def _ansible_version(self):
            return self.ansible_version

        def fail_json(self, *args, **kwargs):
            raise Exception
        def run_command(self, *args, **kwargs):
            return 0, '', ''
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/rpm'

# Generated at 2022-06-20 22:28:06.143339
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # If a url starts with http, it should be downloaded.
    assert is_pubkey(RpmKey_object.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt"))
    # If a url starts with https, it should be downloaded.
    assert is_pubkey(RpmKey_object.fetch_key("https://apt.sw.be/RPM-GPG-KEY.dag.txt"))



# Generated at 2022-06-20 22:28:15.102838
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    args = dict()
    args['fingerprint'] = 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6'
    args['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    args['validate_certs'] = True
    args['state'] = 'present'
    m = AnsibleModule(**args)
    r = RpmKey(m)
    assert r.getfingerprint('/path/to/RPM-GPG-KEY.dag.txt') == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'

# Generated at 2022-06-20 22:28:19.379887
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpm_key = RpmKey(None)
    assert rpm_key.normalize_keyid(" 0xDEADB33F ") == "DEADB33F"
    assert rpm_key.normalize_keyid(" DEADB33F ") == "DEADB33F"


# Generated at 2022-06-20 22:28:33.436331
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    print('-----Unit test for method drop_key of class RpmKey-----')
    class module():
        def fail_json(self, msg):
            print(msg)
        def run_command(self, cmd, use_unsafe_shell=True):
            return 1, '', ''
        def execute_command(self, cmd, use_unsafe_shell=True):
            return '', ''
        def check_mode(self):
            return False
    import os
    import sys
    import xmlrunner
    print('#'*100)
    if len(sys.argv)>1 and sys.argv[1]=='test':
        if not os.path.exists('reports'):
            os.makedirs('reports')

# Generated at 2022-06-20 22:28:39.572154
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    m = MockModule()
    r = RpmKey(m)
    assert r.execute_command([r.gpg, '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', 'data/public.gpg']) == (b"pub:u:1:2047:1:DEADB33F:1501786897:1450310197:1450310197:::-:::esca:::0:\\n", b"")


# Generated at 2022-06-20 22:28:51.284067
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    keyfile = 'tests/fixtures/test_RpmKey_getfingerprint.gpg'
    rpm_key = RpmKey(module)
    assert rpm_key.getfingerprint(keyfile) == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'


# Generated at 2022-06-20 22:29:01.298321
# Unit test for function is_pubkey

# Generated at 2022-06-20 22:29:02.518080
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    test = RpmKey(None)
    assert not test.is_key_imported('01234567')

# Generated at 2022-06-20 22:29:14.363481
# Unit test for function main
def test_main():
    from unittest import mock
    from contextlib import contextmanager

    @contextmanager
    def _make_mock_args(dict_):
        with mock.patch('ansible.module_utils.basic.AnsibleModule.argument_spec') as a:
            a.__getitem__.side_effect = lambda k: dict_[k]
            func = globals()['main']
            yield mock.patch.object(func, 'RpmKey')

    with mock.patch('ansible.module_utils.basic.AnsibleModule.supports_check_mode') as a:
        a.__getitem__.side_effect = lambda k: True

# Generated at 2022-06-20 22:29:24.348598
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    """
    Asserts that is_keyid returns True if the keyid is correct,
    and False if it is not.
    """

    # Instantiate the RpmKey class passing a dummy module
    rpm_key = RpmKey(dict())

    # Assert that is_keyid returns True if keyid is correct
    correct_keyid = "DEADB33F"
    assert rpm_key.is_keyid(correct_keyid)

    # Assert that is_keyid returns False if keyid is incorrect
    incorrect_keyid = "DEAD B33F"
    assert not rpm_key.is_keyid(incorrect_keyid)

# Generated at 2022-06-20 22:30:26.779156
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    keyid = 'deadb33f'
    assert(RpmKey.is_keyid(keyid))
    keyid = 'DEADB33F'
    assert(RpmKey.is_keyid(keyid))
    keyid = 'DEADB33FF'
    assert(RpmKey.is_keyid(keyid) is False)
    keyid = '0XDEADB33F'
    assert(RpmKey.is_keyid(keyid))
    keyid = '0xDEADB33F'
    assert(RpmKey.is_keyid(keyid))
    keyid = '0XDEADB33FF'
    assert(RpmKey.is_keyid(keyid) is False)


# Generated at 2022-06-20 22:30:38.921748
# Unit test for function main
def test_main():
    from ansible.module_utils.common.process import get_bin_path

    rpm_path = get_bin_path('rpm', True)
    rpm_path = rpm_path.replace('/', '\\/')
    # Temporary file to test key import
    test_key = tempfile.mkstemp()
    test_key_str = "-----BEGIN PGP PUBLIC KEY BLOCK-----"
    test_key_str += "\nmQENBE4CgukBCADWQ2ih0b0SxgFjR8YT6TZDAiUhsO6Q2T6b8aWUdvcijKx6f0c9"

# Generated at 2022-06-20 22:30:46.104332
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = FakeModule()

    rpm_key = RpmKey(module)

    # Test when module run_command succeeds
    module.run_command = lambda cmd, use_unsafe_shell=False: (0, '', '')
    assert rpm_key.import_key('test_file') is None
    module.fail_json.assert_called_once_with(msg='test_stdouttest_stderr')
    module.fail_json.reset_mock()

    # Test when module run_command fails
    module.run_command = lambda cmd, use_unsafe_shell=False: (1, 'test_stdout', 'test_stderr')
    assert rpm_key.import_key('test_file') is None

# Generated at 2022-06-20 22:30:53.344402
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)


# Generated at 2022-06-20 22:30:55.546194
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rpm_key = RpmKey(None)
    assert rpm_key.drop_key(None) is None


# Generated at 2022-06-20 22:31:04.113981
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\nfoo\n-----END PGP PUBLIC KEY BLOCK-----\n')
    assert is_pubkey('\n-----BEGIN PGP PUBLIC KEY BLOCK-----\nfoo\n-----END PGP PUBLIC KEY BLOCK-----')
    assert is_pubkey('\n\n-----BEGIN PGP PUBLIC KEY BLOCK-----\nfoo-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----'
                         '-----END PGP PUBLIC KEY BLOCK-----')

# Generated at 2022-06-20 22:31:15.990507
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Test a valid key id

# Generated at 2022-06-20 22:31:24.805251
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('thisisnotapubkey') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey('-----END PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n\n-----END PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n\n\n-----END PGP PUBLIC KEY BLOCK-----') is False

# Generated at 2022-06-20 22:31:32.411881
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpmkey = RpmKey(None)
    assert rpmkey.normalize_keyid('0x123') == '123'
    assert rpmkey.normalize_keyid('123') == '123'
    assert rpmkey.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpmkey.normalize_keyid('0xDEADB33F ') == 'DEADB33F'
    assert rpmkey.normalize_keyid(' DEADB33F') == 'DEADB33F'
    assert rpmkey.normalize_keyid('DEADB33F') == 'DEADB33F'


# Generated at 2022-06-20 22:31:35.773067
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = object()
    rpm_key_instance = RpmKey(module)
    # Case that the string is a valid api key
    key_file = "key_file.txt"
    assert rpm_key_instance.getkeyid(key_file) == "EBC6E12C62B1C734026B2122A20E52146B8D79E6"
    # Case that the string is not a valid api key

# Generated at 2022-06-20 22:33:57.820527
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # unit test of constructor of class RpmKey
    # test case:
    # 1. test key file is a url
    # 2. test key file is a absolute path
    # 3. test key file is a relative path
    # 4. test key file is a keyid
    # 5. test key is not exist, should raise an error
    # 6. test key is not valid, should raise an error

    from ansible.utils.contextmanager import temporary_path
    from ansible.module_utils.six.moves import StringIO


    class RpmKeyMock(RpmKey):

        def __init__(self, module):
            self.module = module
            self.rpm = self.module.get_bin_path('rpm', True)
            self.gpg = self.module.get_bin_path('gpg')
           

# Generated at 2022-06-20 22:34:04.180476
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)



# Generated at 2022-06-20 22:34:05.055862
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert RpmKey


test_RpmKey()

# Generated at 2022-06-20 22:34:12.258587
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid("b7cda085") == "B7CDA085"
    assert RpmKey.normalize_keyid("0xb7cda085") == "B7CDA085"
    assert RpmKey.normalize_keyid("0xB7CDA085") == "B7CDA085"
    assert RpmKey.normalize_keyid("   b7cda085") == "B7CDA085"
    assert RpmKey.normalize_keyid("b7cda085   ") == "B7CDA085"
    assert RpmKey.normalize_keyid("   b7cda085   ") == "B7CDA085"


# Generated at 2022-06-20 22:34:22.760698
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create test object with a mock module
    module = Mock()

    # Create a temp gpg key file
    data = 'Key: test'
    fp, path = tempfile.mkstemp()
    with os.fdopen(fp, 'w') as f:
        f.write(data)

    # Create a RpmKey object with the mock module, and the temp file as the key
    RpmKey(module, key=path)

    # Assert that the expected key was read from the temp file
    module.execute_command.assert_called_with(['gpg2', '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '--with-fingerprint', path])
    assert 'test' in module.execute_command.call_args[0][0]

# Generated at 2022-06-20 22:34:32.003063
# Unit test for function main
def test_main():
    t_rpm_key = RpmKey()
    assert t_rpm_key.is_keyid("ABCD1234")
    assert t_rpm_key.is_keyid("0xABCD1234")
    assert t_rpm_key.is_keyid("0xabcd1234")
    assert not t_rpm_key.is_keyid("DADB33F")
    assert not t_rpm_key.is_keyid("0xDADB33F")
    assert not t_rpm_key.is_keyid("file:///this/is/a/path")
    assert not t_rpm_key.is_keyid("https://this/is/a/path")

# Generated at 2022-06-20 22:34:41.400644
# Unit test for function is_pubkey
def test_is_pubkey():
    assert not is_pubkey('foo bar')
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----'
                     '\n'
                    'foo bar'
                     '\n'
                     '-----END PGP PUBLIC KEY BLOCK-----')
    assert is_pubkey('\n'
                     '-----BEGIN PGP PUBLIC KEY BLOCK-----'
                     '\n'
                     '\n'
                     'foo bar'
                     '\n'
                     '\n'
                     '-----END PGP PUBLIC KEY BLOCK-----')
    assert not is_pubkey('\n'
                     '-----BEGIN PGP PUBLIC KEY BLOCK-----'
                     '\n'
                     '\n'
                     'foo bar'
                     '\n'
                     '\n'
                     '-----END PGP PUBLIC KEY BLOCK')