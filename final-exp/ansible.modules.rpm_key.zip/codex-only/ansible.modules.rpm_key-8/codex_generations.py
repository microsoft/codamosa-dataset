

# Generated at 2022-06-23 04:08:51.065226
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Set up test data
    global module
    module = AnsibleModule(
      argument_spec=dict(
          state=dict(type='str', default='absent', choices=['absent', 'present']),
          key=dict(type='str', required=True, no_log=False),
          fingerprint=dict(type='str'),
          validate_certs=dict(type='bool', default=True),
      ),
      supports_check_mode=True,
    )

    class Global_Var:
        changed = False

    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec=argument_spec
            self.supports_check_mode=supports_check_mode

        def fail_json(self, msg):
            raise Exception(msg)



# Generated at 2022-06-23 04:08:55.809487
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey.is_keyid('0xDEADB33F')
    assert RpmKey.is_keyid('DEADB33F')


# Generated at 2022-06-23 04:09:05.983425
# Unit test for method normalize_keyid of class RpmKey

# Generated at 2022-06-23 04:09:11.535639
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    ''' test function is_key_imported of class RpmKey '''
    rpm_key = RpmKey(None)
    assert rpm_key.is_key_imported('0x0608B895') == False


# Generated at 2022-06-23 04:09:23.212596
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a temporary file with a fake key
    key_file_handle, key_file_name = tempfile.mkstemp()
    key_file = os.fdopen(key_file_handle, "w+b")
    key_file.write("Fake Key")
    key_file.close()

    # Create an empty "repo" file
    repo_file_handle, repo_file_name = tempfile.mkstemp()
    repo_file = os.fdopen(repo_file_handle, "w+b")
    repo_file.close()

    # Create an empty "gpg_key_list" file
    gpg_key_list_file_handle, gpg_key_list_file_name = tempfile.mkstemp()

# Generated at 2022-06-23 04:09:29.454992
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_keyid = '1F7D1DBD'  # example taken from ansible docs
    normalized_keyid = '1F7D1DBD'

    # test normalization of a lower case keyid
    keyid = RpmKey.normalize_keyid(normalized_keyid.lower())
    assert keyid == normalized_keyid

    # test normalization of a upper case keyid
    keyid = RpmKey.normalize_keyid(normalized_keyid.upper())
    assert keyid == normalized_keyid

# Generated at 2022-06-23 04:09:43.330216
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(object):
        def __init__(self, return_value):
            self.params = dict()
            self.return_value = return_value
            self.add_cleanup_file_calls = list()

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def cleanup(self, file):
            self.add_cleanup_file_calls.append(file)

    # Our test case

# Generated at 2022-06-23 04:09:56.104590
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class InvalidModule:
        pass
    class ValidModule:
        class ValidModuleResult:
            def __init__(self):
                self.stdout = 'Test output'
                self.msg = 'Module executed successfully'
            def __call__(self, *args, **kwargs):
                self.changed = True
                return self.stdout, self.msg

        def __init__(self):
            self.params = dict()
            self.run_command_results = []
            self.run_command_results.append(ValidModuleResult())
            self.run_command_results.append(ValidModuleResult())
            self.run_command_results.append(ValidModuleResult())

        def fail_json(self, *args, **kwargs):
            raise AssertionError('fail_json should not have been called')


# Generated at 2022-06-23 04:09:57.519391
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert isinstance(RpmKey(None), object)


# Generated at 2022-06-23 04:10:12.087278
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    from ansible.modules.packaging.os.rpm_key import RpmKey
    module = AnsibleModule({
        'state': 'present',
        'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
    }, check_mode=True)
    rp = RpmKey(module)

    assert rp.is_key_imported("3EE67F3D0FF405B2") is False
    rp.import_key("/tmp/RPM-GPG-KEY.dag.txt")
    assert rp.is_key_imported("3EE67F3D0FF405B2") is True
    rp.drop_key("3EE67F3D0FF405B2")

# Generated at 2022-06-23 04:10:26.869316
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-23 04:10:38.197421
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        def __init__(self, module_args, check_invalid_arguments=True,
                     supports_check_mode=True):
            self.params = module_args
            self.check_invalid_arguments = check_invalid_arguments
            self.supports_check_mode = supports_check_mode

        def fail_json(self, **kwargs):
            pass


# Generated at 2022-06-23 04:10:38.907123
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    pass

# Generated at 2022-06-23 04:10:48.047610
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class FakeModule:
        def __init__(self, dict, **kwargs):
            self.params = dict
            # Override set_check_mode since it tries to call os.getuid and this
            # doesn't work under travis
            self.check_mode = kwargs.get('check_mode')
        def get_bin_path(self, name, required=False):
            if name == 'rpm':
                return '/bin/rpm'
            else:
                return None
        def run_command(self, cmd, use_unsafe_shell=True):
            if cmd[:3] == ['/bin/rpm', '-q', 'gpg-pubkey'] and cmd[3:] == ['--qf', '"%{description}"']:
                return 0, "", ""

# Generated at 2022-06-23 04:11:00.537981
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import requests
    import datetime
    import os
    import tempfile
    http_mock = requests.Response()
    http_mock.url = "/key.gpg"
    http_mock.status_code = 200
    http_mock.headers = {
        'content-type': 'text/plain',
        'last-modified': datetime.datetime.now().strftime('%a, %d %b %Y %H:%M:%S %z'),
        'content-length': '76'
    }
    http_mock.raw = tempfile.TemporaryFile()

# Generated at 2022-06-23 04:11:08.397847
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create a mock module
    mock_module = Mock(name='AnsibleModule')
    mock_module.run_command = Mock(name='run_command')
    # Create a mock superclass
    mock_super = Mock(name='super')
    mock_super.run_command = Mock(name='run_command')
    # Create a mock rpm
    mock_rpm = Mock(name='rpm')
    # Create the object
    rpm_key = RpmKey(mock_module)
    # Set the rpm attribute
    rpm_key.rpm = mock_rpm
    # Create a list of keys not installed

# Generated at 2022-06-23 04:11:21.066600
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('some random string') == False
    assert is_pubkey('----BEGIN PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('-----END PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK----test\n') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK----test') == False
    assert is_pubkey('test-----BEGIN PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('test-----BEGIN PGP PRIVATE KEY BLOCK-----') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----test') == False

# Generated at 2022-06-23 04:11:24.274313
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    assert RpmKey.import_key(keyfile) == (
        [self.rpm, '--import', keyfile]
    )
    return True

# Generated at 2022-06-23 04:11:36.466789
# Unit test for function is_pubkey

# Generated at 2022-06-23 04:11:47.601067
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    key_path = '/path/to/key.gpg'
    rpm = '/bin/rpm'
    gpg = '/bin/gpg'

    m = mock.MagicMock(**{
        "get_bin_path.side_effect": [rpm, gpg],
        "check_mode": False,
        "run_command.return_value": (0, '', '')
    })
    r = RpmKey(m)
    r.import_key(key_path)

    m.run_command.assert_called_with([rpm, '--import', key_path], use_unsafe_shell=True)



# Generated at 2022-06-23 04:11:49.332469
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    rpm_key = RpmKey()
    rpm_key.import_key("/tmp/test.rpm")

# Generated at 2022-06-23 04:11:58.080860
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('') is False
    assert is_pubkey('DEADB33F') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----') is True
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n\n-----END PGP PUBLIC KEY BLOCK-----') is True


# Generated at 2022-06-23 04:12:09.653214
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----") == True
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----\n") == True

# Generated at 2022-06-23 04:12:23.650407
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import sys

    # Constructor of AnsibleModule requires an argument, sys.argv
    # We don't have to import all variables defined in our ansible playbook,
    # so we can mock them up here
    sys.argv = [
        'rpm_key',
        '',
        '{"state": "present", "key": "https://example.org/dir/key.gpg"}',
    ]

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native


# Generated at 2022-06-23 04:12:24.445828
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    pass

# Generated at 2022-06-23 04:12:30.876443
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # find rpm executable
    rpm = module.get_bin_path('rpm', True)
    # create an instance of RpmKey and call method is_key_imported with
    # a valid keyid as argument
    assert RpmKey(module).is_key_imported("1EBC6E12C62BC7")
    # create an instance of RpmKey and call method is_key_imported

# Generated at 2022-06-23 04:12:31.974273
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # test class constructor
    assert RpmKey is not None

# Generated at 2022-06-23 04:12:32.891238
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    pass

# Generated at 2022-06-23 04:12:43.179952
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    test_rpm_key = RpmKey(None)
    assert( test_rpm_key.is_keyid('0XF63510D') == True )
    assert( test_rpm_key.is_keyid('F63510D') == True )
    assert( test_rpm_key.is_keyid('0xF63510D') == True )
    assert( test_rpm_key.is_keyid('F63510D0') == False )
    assert( test_rpm_key.is_keyid('F63510D0X') == False )
    assert( test_rpm_key.is_keyid('0XF63510D0X') == True )

# Generated at 2022-06-23 04:12:51.693833
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec={
            'state': dict(type='str', default='present', choices=['absent', 'present']),
            'key': dict(type='str', required=True, no_log=False),
            'fingerprint': dict(type='str'),
            'validate_certs': dict(type='bool', default=True),
        }
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key("1234 1234 1234 1234")

# Generated at 2022-06-23 04:13:03.894523
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible.module_utils.rpm_key import is_pubkey
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') is True
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----') is True
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\nA\n-----END PGP PUBLIC KEY BLOCK-----') is True
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\n') is True
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----\nA') is True

# Generated at 2022-06-23 04:13:05.549680
# Unit test for function main
def test_main():
    raise NotImplementedError

# Generated at 2022-06-23 04:13:08.726151
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    rpmkey = RpmKey(AnsibleModule(argument_spec={}))
    assert rpmkey.getfingerprint('./test-data/public.key') == 'EBC6E12C62B1C734026B21222A20E52146B8D79E6'


# Generated at 2022-06-23 04:13:16.801869
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # This is the parameter to be tested
    input = 'dead B33F'
    expected = 'DEADB33F'
    # This is how you would normally import the class, but for the test
    # you have to use the relative import
    from ansible.modules.packaging.os import rpm_key
    rm = rpm_key.RpmKey()
    actual = rm.normalize_keyid(input)
    assert actual == expected
    return



# Generated at 2022-06-23 04:13:25.517140
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 04:13:29.473142
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():

    rpm_key = RpmKey()

    # Check if returns a tuple of strings
    command = ['echo', 'Hello World!'] 
    stdout, stderr = rpm_key.execute_command(command) 
    assert isinstance(stdout, str) and isinstance(stderr, str)



# Generated at 2022-06-23 04:13:30.664992
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    pass

# Generated at 2022-06-23 04:13:41.957732
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class MockModule(object):
        pass


# Generated at 2022-06-23 04:13:51.521812
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    """Test whether the normalize_keyid method is working properly for the different keyid provided.
    Here the expected is a keyid without the '0x' and with the keyid in upper case.
    """
    key = RpmKey(None)
    assert key.normalize_keyid("0x12345678") == "12345678"
    assert key.normalize_keyid("0x1AaBbCcD") == "1AABBCCD"
    assert key.normalize_keyid("1AbCdEfG") == "1ABCDEFG"

# Generated at 2022-06-23 04:14:02.008939
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    mod = basic.AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    mod.run_command = lambda cmd: (0, '', '')
    mod.get_bin_path = lambda bin, required: bin
    mod.add_cleanup_file = lambda x: None
    mod.exit_json = lambda x: None
    mod.fail_json

# Generated at 2022-06-23 04:14:11.189352
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    """ Tests for method RpmKey().import_key() """
    # import needed modules
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # create temp file and add cleanup
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.add_cleanup_file(tmpname)
    # populate temp file with some content
    open(tmpname, 'a').write('test_content')
    # create RpmKey object and call method
    rpmkey = RpmKey(module)
    rpmkey.import_key(tmpname)
    # verify file was removed
    assert not os.path.isfile(tmpname)

# Generated at 2022-06-23 04:14:23.965316
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    
    rpm_key_obj = RpmKey(module=module)
    res = rpm_key_obj.execute_command(['ls', '-l'])
    assert type(res) == tuple

# Generated at 2022-06-23 04:14:36.371812
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run_command = mock.MagicMock(return_value=(0,'',''))
    rpk = RpmKey(module)
    keyid = "1AAA1111"
    result = rpk.drop_key(keyid)
    assert module.run_command.call_count == 1

# Generated at 2022-06-23 04:14:48.084553
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # If a keyid is provided, it must be uppercase, leading 0x stripped
    module = MockModule('absent', '0x00012345', True)
    RpmKey(module)
    assert module.exit_json.call_args[0][1]['changed'] == False

    # If a keyid is provided, it must be uppercase, leading 0x stripped
    module = MockModule('present', '0X00012345', False)
    RpmKey(module)
    assert module.exit_json.call_args[0][1]['changed'] == True

    # If a keyid is provided, it must be uppercase, leading 0x stripped
    module = MockModule('absent', '0X00012345', False)
    RpmKey(module)

# Generated at 2022-06-23 04:14:50.929005
# Unit test for function main
def test_main():
    """ Unit test for function main """
    # Fails to import if import AnsibleModule fails (these are all fake arguments)
    main()

# Generated at 2022-06-23 04:15:01.704875
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class TestModule():
        def __init__(self):
            self.arguments = {
                'state' : 'present',
                'key' : 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint' : None,
                'validate_certs' : True,
            }
            self.check_mode = False
            self.cleanup_files = []

        def add_cleanup_file(self, keyfile):
            self.cleanup_files.append(keyfile)

    class TestRun():
        def __init__(self, return_code, stdout, stderr):
            self.return_code = return_code
            self.stdout = stdout
            self.stderr = stderr


# Generated at 2022-06-23 04:15:02.214987
# Unit test for function is_pubkey
def test_is_pubkey():
    pass

# Generated at 2022-06-23 04:15:12.930092
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(argument_spec=dict())
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid(' 0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0xDEADB33F ') == 'DEADB33F'
    assert rpm_key.normalize_keyid(' 0xDEADB33F ') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid(' DEADB33F') == 'DEADB33F'

# Generated at 2022-06-23 04:15:25.018355
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    from ansible.module_utils.basic import load_platform_subclass
    from ansible.module_utils.six import PY2

    module = load_platform_subclass(RpmKey)()

    from ansible.module_utils._text import to_bytes, to_native

    if not PY2:
        to_bytes = lambda x: x

    class TestFetchUrl():
        def __init__(self):
            pass


# Generated at 2022-06-23 04:15:34.020665
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Given
    module = Mock(check_mode=False)
    rpm_key = RpmKey(module)
    rpm_key.rpm = "rpm"
    rpm_key.execute_command = Mock()

    # When
    rpm_key.drop_key("0xDEADBEEF")

    # Then
    assert rpm_key.execute_command.call_count == 1


# Generated at 2022-06-23 04:15:36.849235
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    assert RpmKey.is_key_imported("400A0B9B")


# Generated at 2022-06-23 04:15:46.358829
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    rpm_af8cd95f = rpm_key.RpmKey(mock_rpm_key_module)

    keyfile = "/tmp/test_RpmKey_import_key"
    with open(keyfile, "w") as f:
        f.write("""
        this is a test
        """)

    mock_rpm_key_module.check_mode = False
    rpm_af8cd95f.import_key(keyfile)

    mock_rpm_key_module.run_command.assert_called_once_with(
        [rpm_af8cd95f.rpm, '--import', keyfile], use_unsafe_shell=True
    )

    os.remove(keyfile)



# Generated at 2022-06-23 04:15:56.285592
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    key = 'test_key'
    old_open = ansible.module_utils.rpm_key.open
    ansible.module_utils.rpm_key.open = open_mock
    try:
        mock_module = MockModule()
        mock_module.check_mode = True
        rpm_key = RpmKey(mock_module)
        rpm_key.import_key(key)
        assert mock_module.run_command.mock_calls == [call(['rpm', '--import', key])]
    finally:
        ansible.module_utils.rpm_key.open = old_open

# Generated at 2022-06-23 04:16:08.975568
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import urlparse
    from StringIO import StringIO
    from ansible.module_utils.urls import fetch_url

    # Set the environment to pretend we are testing the module at the shell
    os.environ['ANSIBLE_MODULE_TEST'] = 'True'

    # Import the module (this only happens when the test is called at the shell)
    module_to_test = __import__('ansible/modules/packaging/os/rpm_key.py', globals(), locals(), [], -1)

    # Create a string to mock the key

# Generated at 2022-06-23 04:16:10.665493
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # It doesn't need to be tested
    pass


# Generated at 2022-06-23 04:16:24.687439
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import unittest
    import warnings
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.module_utils.urls
    import ansible.module_utils.six


# Generated at 2022-06-23 04:16:31.731137
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    key_dict = {
        "key": "test",
        "state": "present",
    }
    module = AnsibleModule(argument_spec=key_dict, supports_check_mode=True)
    rpm = RpmKey(module)
    assert rpm.is_keyid('0x1234abcd') is True
    assert rpm.is_keyid('0x1234') is True
    assert rpm.is_keyid('0X1234') is True
    assert rpm.is_keyid('1234') is True
    assert rpm.is_keyid('1234abcd') is True
    assert rpm.is_keyid('0x1234567890') is True
    assert rpm.is_keyid('0x1234a') is False
    assert rpm.is_keyid('0x1234abcd ')

# Generated at 2022-06-23 04:16:37.074877
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    """Unit test for method fetch_key of class RpmKey"""
    url = "http://apt.sw.be/RPM-GPG-KEY.dag.txt"
    rsp, info = fetch_url(None, url)
    key = rsp.read()
    assert is_pubkey(key) == True



# Generated at 2022-06-23 04:16:49.270121
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import os
    from ansible.module_utils.basic import AnsibleModule

    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Mock the class attributes which are used by the execute_command method
    class RpmKey:
        module = module
        rpm = 'mocked_rpm'
        gpg = 'mocked_gpg'
        def execute_command(self, cmd):
            import os
            outstr = ''
           

# Generated at 2022-06-23 04:16:59.355712
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('deadb33f') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0xdeadb33f') == 'DEADB33F'
    assert rpm_key.normalize_keyid('deadb33f ') == 'DEADB33F'
    assert rpm_key.normalize_keyid(' 0xdeadb33f ') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'

# Generated at 2022-06-23 04:17:12.951117
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import os
    import shutil
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # This class is required to simulate the module used in Ansible
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def fail_json(self, msg):
            pass

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    # This class is required to simulate the execute command in Linux
    class MockExecuteCommand(object):
        def __init__(self, *args, **kwargs):
            self.state = args


# Generated at 2022-06-23 04:17:21.034665
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Setup
    module = AnsibleModule(argument_spec = {"key": "http://apt.sw.be/RPM-GPG-KEY.dag.txt"})
    rpm_key = RpmKey(module)

    # Exercise
    result = rpm_key.fetch_key(module.params['key'])

    # Verify
    assert isinstance(result, (str, unicode))
    assert os.path.isfile(result)


# Generated at 2022-06-23 04:17:26.840341
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey.is_keyid('aef01234')
    assert RpmKey.is_keyid('0x0001234')
    assert RpmKey.is_keyid('0X0001234')
    assert not RpmKey.is_keyid('0001234')
    assert not RpmKey.is_keyid('0X000123')

# Generated at 2022-06-23 04:17:36.858801
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class Test(object):
        def __init__(self):
            self.changed = False

        def fail_json(self, msg):
            print('fail_json', msg)

        def run_command(self, cmd, use_unsafe_shell=True):
            print('run_command', cmd, use_unsafe_shell)
            return 0, 'stdout', 'stderr'

        def get_bin_path(self, binname, required=False):
            print('get_bin_path', binname, required)
            return binname

        def cleanup(self, tmpname):
            print('cleanup', tmpname)
            return

        def add_cleanup_file(self, tmpname):
            print('add_cleanup_file', tmpname)
            return



# Generated at 2022-06-23 04:17:48.953705
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    keystr = "65D8CE1CB3C425E265CB30DE03E52B7FE08BBCE9"
    assert RpmKey.is_keyid(keystr) == True
    keystr = "0x65D8CE1CB3C425E265CB30DE03E52B7FE08BBCE9"
    assert RpmKey.is_keyid(keystr) == True
    keystr = "65D8CE1CB3C425E265CB30DE03E52B7FE08BBCE9.1"
    assert RpmKey.is_keyid(keystr) == False
    keystr = "0x65D8CE1CB3C425E265CB30DE03E52B7FE08BBCE9.1"
    assert RpmKey.is_keyid(keystr) == False

# Generated at 2022-06-23 04:17:57.359124
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule(
            argument_spec={},
            supports_check_mode=True
    )
    key = RpmKey(ansible_module)
    assert key.is_keyid("0x12345678")
    assert key.is_keyid("0X12345678")
    assert key.is_keyid("12345678")
    assert not key.is_keyid("0x1234567")
    assert not key.is_keyid("x12345678")



# Generated at 2022-06-23 04:18:06.273726
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # path = os.path.dirname(os.path.realpath(__file__)) + "/../../../test/units/modules/utils/fetch_url/test_data/"
    path = "/home/matt/g/ansible/test/units/modules/utils/fetch_url/test_data/"
    keyfile = RpmKey.fetch_key(path + "key_1.asc")
    if os.path.isfile(keyfile):
        os.remove(keyfile)
    else:
        raise AssertionError("keyfile does not exist")

# Generated at 2022-06-23 04:18:14.952816
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class RpmKeyDummy():
        def __init__(self, module):
            self.module = module

        def execute_command(self, cmd):
            return ('fpr:::::::::C0A89AD964F913E3CAC69C881DB272402F85E7E6:', '')

    module = AnsibleModule(argument_spec=dict())
    rpmmodule = RpmKeyDummy(module)

    test_keyfile = 'test_key.gpg'

    assert rpmmodule.getfingerprint(test_keyfile) == 'C0A89AD964F913E3CAC69C881DB272402F85E7E6'

# Generated at 2022-06-23 04:18:26.988450
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    class MockModule:
        class MockFailJson:
            def __init__(self, module):
                self.module = module

            def fail_json(self, msg):
                assert 'Unexpected gpg output' == msg

        fail_json = MockFailJson(None)

        def run_command(self, cmd, use_unsafe_shell=True):
            assert self.rpm + ' -q  gpg-pubkey' == cmd
            return 0, 'gpg-pubkey-deadb33f-56d4f4e4', ''

        def check_mode(self):
            return False

        def cleanup(self, keypath):
            self.cleanup_file = keypath
            return True

        def get_bin_path(self, bin, required=False):
            self.bin = bin
            return True



# Generated at 2022-06-23 04:18:39.937745
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import tempfile
    import os
    import filecmp
    import shutil
    import datetime
    from ansible.module_utils import basic

    # make a dir to put the test files
    td = tempfile.mkdtemp()
    # create the rpm db
    dirs = [td + '/var/lib/rpm/',  td + '/var/lib/rpm/Packages', td + '/var/lib/rpm/Packages/',
            td + '/var/lib/rpm/Name', td + '/var/lib/rpm/Pubkeys']
    for d in dirs:
        try:
           os.mkdir(d)
        except OSError:
           pass

    test_key = "0xE2C2DB55"

# Generated at 2022-06-23 04:18:53.609016
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import ansible.module_utils.common.json as module_json
    import ansible.module_utils.basic as module_basic
    import ansible.module_utils.action as module_action
    import ansible.module_utils._text as module_text
    import ansible.module_utils.resource_facts as module_resource_facts
    import ansible.module_utils.resource_management as module_resource_management
    import ansible.module_utils.facts as module_facts
    import ansible.module_utils.urls as module_urls
    import ansible.module_utils.helpers as module_helpers
    import ansible.module_utils.action as module_action
    import ansible.module_utils.action.core as module_core
    import ansible.module_utils.action.network as module_network
   