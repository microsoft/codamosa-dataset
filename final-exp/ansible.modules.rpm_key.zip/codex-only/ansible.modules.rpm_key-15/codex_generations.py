

# Generated at 2022-06-23 04:08:50.626388
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmkey = RpmKey(module)
    assert rpmkey.is_keyid('0x0608B895') == True
    assert rpmkey.is_keyid('0x0608 895') == False
    assert rpmkey.is_keyid('0608B895') == True
    assert rpmkey.is_keyid('608B895') == False
    assert rpmkey.is_

# Generated at 2022-06-23 04:09:03.746971
# Unit test for function is_pubkey

# Generated at 2022-06-23 04:09:17.727075
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class MockModule(object):
        def __init__(self):
            self.called = []
            self.run_command_results = []

        def run_command(self, cmd):
            self.called.append(cmd)
            return self.run_command_results.pop(0)

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def check_mode(self):
            return self.params.get('check_mode', False)

    # There is only one key installed
    rpm = RpmKey(MockAnsibleModule())
    rpm.rpm = '/bin/rpm'
    rpm.gpg = '/bin/gpg'
    rpm.module.run_command_results

# Generated at 2022-06-23 04:09:28.323248
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_object = RpmKey(test_module)
    test_id = "0xDeadbeef"
    test_id2 = "0xDeadBEEF"
    test_id3 = "DEADBEEF"
    test_id4 = "DeadBEEF"



# Generated at 2022-06-23 04:09:40.716081
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    cmd = 'rpm -q  gpg-pubkey --qf "%{description}" | gpg --no-tty --batch --with-colons --fixed-list-mode -'
    # Test case when there is no key in system
    stdout = ""
    stderr = ""
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm = RpmKey(module)

# Generated at 2022-06-23 04:09:49.164537
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    class Dummy_module:
        pass
    module = Dummy_module()
    module.fail_json = lambda x: sys.exit(1)

    rpmkey = RpmKey(module)
    if not rpmkey.is_keyid('0xFFFFFFFF'):
        print("is_keyid: 0xFFFFFFFF")
        sys.exit(1)
    if not rpmkey.is_keyid('FFFFFFFF'):
        print("is_keyid: FFFFFFFF")
        sys.exit(1)
    if not rpmkey.is_keyid('0XFFFFFFFF'):
        print("is_keyid: 0XFFFFFFFF")
        sys.exit(1)
    if not rpmkey.is_keyid('0x12345678'):
        print("is_keyid: 0x12345678")

# Generated at 2022-06-23 04:10:00.129186
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import sys
    import StringIO
    import tempfile
    import os

    class FakeModule():
        def __init__(self):
            self.params = {}
            self.run_command = self.run_command

        def fail_json(self, **kwargs):
            sys.stderr.write(kwargs['msg'])
            sys.exit(1)

        def get_bin_path(self, name, required=True):
            if required:
                return 'rpm'
            else:
                return None

        def run_command(self, command, use_unsafe_shell=True):
            if '--import' in command:
                return 0, '', ''
            elif '--erase' in command:
                return 0, '', ''

# Generated at 2022-06-23 04:10:14.268760
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    keyfile = '/path/to/key/file/RPM-GPG-KEY.dag.txt'
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
        gpg='gpg',
    )

    key = RpmKey(module)
    assert key.getfingerprint(keyfile) == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'

# Generated at 2022-06-23 04:10:22.845260
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    os.path.isfile = MagicMock(return_value=True)
    urlopen = mock_open(read_data="test")
    module.run_command = MagicMock(return_value=(0, "OUT", "ERR"))
    with patch('ansible.module_utils.urls.urlopen', urlopen):
        rpm = RpmKey(module)
        assert rpm.fetch_key("https://test.com") == "test"

# Generated at 2022-06-23 04:10:28.372403
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    test_RpmKey = RpmKey()
    keyfile = 'test_key.txt'
    test_RpmKey.import_key(keyfile)
    assert test_RpmKey.execute_command.call_args[0][0] == ['rpm', '--import', keyfile]


# Generated at 2022-06-23 04:10:35.458228
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid("b142f3ab") == "B142F3AB"
    assert RpmKey.normalize_keyid("0xb142f3ab") == "B142F3AB"
    assert RpmKey.normalize_keyid("0XB142F3AB") == "B142F3AB"
    assert RpmKey.normalize_keyid("  B142F3AB  ") == "B142F3AB"


# Generated at 2022-06-23 04:10:41.577549
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(argument_spec = dict())
    k = RpmKey(module)
    assert k.is_key_imported("0xD8A9D0D9A904E157")
    assert not k.is_key_imported("0x3E8D3C62F23C0940")


# Generated at 2022-06-23 04:10:54.998828
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class MockModule:
        def run_command(self, cmd):
            if cmd == 'rpm -q  gpg-pubkey':
                return 1, '', ''
            elif cmd == 'rpm -q  gpg-pubkey --qf "%{description}" | gpg --no-tty --batch --with-colons --fixed-list-mode -':
                return 0, 'pub:u:1024:17:DEADBEEF:1571101728:::u:::scESC::::::23::0:', ''
            else:
                raise Exception("unexpected")
        def fail_json(self, msg):
            raise Exception(msg)
        def check_mode(self):
            return False
    rpm_key = RpmKey(MockModule())

# Generated at 2022-06-23 04:11:05.107936
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import subprocess
    # Import a fake key
    p = subprocess.Popen(['rpm', '--import', 'test/data/gpg-pubkey-deadb33f.gpg'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    assert p.returncode == 0
    assert len(stdout) == 0
    assert len(stderr) == 0

    # Initialize RpmKey object
    module = {}
    module['path'] = {'rpm': '/bin/rpm'}
    module['run_command'] = RpmKey.execute_command
    module['check_mode'] = False
    module['fail_json'] = lambda **args: 1 / 0
    rpm_key = RpmKey(module)



# Generated at 2022-06-23 04:11:17.843309
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [[0, 'stdout message', ''], [1, '', 'error']]
            self.run_command_index = 0
            self.fail_json_msg = None

        def run_command(self, cmd, use_unsafe_shell=False):
            result = self.run_command_results[self.run_command_index]
            self.run_command_index += 1
            return result

        def fail_json(self, msg):
            self.fail_json_msg = msg

    rpm_key_obj = RpmKey(FakeModule())
    stdout, stderr = rpm_key_obj.execute_command('command')
    assert stdout == 'stdout message'
    assert not stderr


# Generated at 2022-06-23 04:11:29.886335
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    class ModuleTest(object):
        def fail_json(self, *args, **kwargs):
            raise Exception(args)

    test = RpmKey(ModuleTest())
    assert test.is_keyid('0xDEADBEEF')
    assert test.is_keyid('DEADBEEF')
    assert test.is_keyid('0xDEAD BEEF')
    assert test.is_keyid('DEAD BEEF')
    assert not test.is_keyid('0xDEADBEEF0')
    assert not test.is_keyid('0xDEADBEE')
    assert not test.is_keyid('DEADBEEF0')
    assert not test.is_keyid('DEADBEE')

# Generated at 2022-06-23 04:11:40.993106
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import b, u
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.RemoteFileModule import RemoteFileModule
    from ansible.module_utils.action import ActionBase
    from ansible.module_utils.common.text.converters import to_native, to_text
    from ansible.module_utils.common.parameters import _KW_IN

# Generated at 2022-06-23 04:11:51.496891
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():

    temp_file_path = tempfile.mkstemp()[1]
    with open(temp_file_path, 'w') as temp_file:
        temp_file.write('hello world')

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=False, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 04:12:02.302814
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    key = RpmKey(module)

    assert key.normalize_keyid("  0xDEADBEEF ") == "DEADBEEF"
    assert key.normalize_keyid("0XDEADBEEF") == "DEADBEEF"
    assert key.normalize_keyid("DEADBEEF") == "DEADBEEF"
    assert key.normalize_keyid("  0x 0Xd eAdBeEf   ") == "DEADBEEF"
    assert key.normalize_keyid("  0x  0Xd  eAdB eEf   ") != "DEADBEEF"

# Generated at 2022-06-23 04:12:11.648413
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class Modulify:
        def fail_json(self, message):
            pass

    test_RpmKey = RpmKey(Modulify)
    test_RpmKey.gpg = 'gpg'


# Generated at 2022-06-23 04:12:20.110780
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    rpms = RpmKey({"gpg": "..."})
    assert rpms.getfingerprint("tests/files/RPM-GPG-KEY-dag") == "D3CA3E7C2A360D6B"
    assert rpms.getfingerprint("tests/files/RPM-GPG-KEY-example") == "E80A63A5"

# Generated at 2022-06-23 04:12:28.586421
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----") == True
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----Something-----END PGP PUBLIC KEY BLOCK-----") == True
    assert is_pubkey("-----BEGIN PGP PRIVATE KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PRIVATE KEY BLOCK-----Something-----END PGP PRIVATE KEY BLOCK-----") == False
    assert is_pubkey("") == False
    assert is_pubkey("Something") == False
    assert is_pubkey(None) == False

# Generated at 2022-06-23 04:12:41.443339
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import textwrap
    import tempfile
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 04:12:42.731345
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:12:54.543749
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    import sys
    if sys.version_info[0] > 2:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'

    module = mock.Mock()
    module.check_mode = False
    exec(compile(open(__file__).read(), __file__, 'exec'))
    instance = RpmKey(module)
    instance.rpm = '/usr/bin/rpm'
    module.run_command = mock.Mock(return_value=(0, '', ''))

# Generated at 2022-06-23 04:12:55.157056
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    pass

# Generated at 2022-06-23 04:13:07.623329
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    # Test successful case
    rc, stdout, stderr = module.run_command('echo "hello"', use_unsafe_shell=True)
    assert rc == 0
    output = rpmkey.execute_command(['echo', 'hello'])
    assert output == (stdout, stderr)
    # Test failure case
    rc, stdout

# Generated at 2022-06-23 04:13:16.421515
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    rk = RpmKey({})
    rk.getkeyid = MagicMock(return_value='0x12345678')
    rk.execute_command = MagicMock(return_value=('stdout', 'stderr'))
    rk.drop_key('0x1234567')
    rk.execute_command.assert_called_with([
        'rpm', '--erase', '--allmatches', 'gpg-pubkey-12345678'
    ])

# Generated at 2022-06-23 04:13:25.343937
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    rpmkey = RpmKey(module)
    rpmkey.gpg = '/usr/bin/gpg'
    rpmkey.rpm = '/bin/rpm'
    assert rpmkey.execute_command([rpmkey.gpg, '--version']) == (b'/usr/bin/gpg (GnuPG) 2.2.5\nlibgcrypt 1.8.1\n', b'')
    assert rpmkey.execute_command([rpmkey.rpm, '--version']) == (b'RPM version 4.12.0.1\n', b'')

    # This is neither a command for gpg or rpm, so it should fail
    # module.fail_json is called with an object of type ErrorInfo

# Generated at 2022-06-23 04:13:38.332632
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-23 04:13:43.835282
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    obj = RpmKey(None)
    result = 'DEADB33F'
    assert obj.normalize_keyid('0xDEADB33F') == result
    assert obj.normalize_keyid('DEADB33F') == result
    assert obj.normalize_keyid('   DEADB33F    ') == result
    assert obj.normalize_keyid('0xDEADB33f') == result
    assert obj.normalize_keyid('0XDEADB33F') == result


# Generated at 2022-06-23 04:13:44.324037
# Unit test for constructor of class RpmKey
def test_RpmKey():
    pass

# Generated at 2022-06-23 04:13:49.827931
# Unit test for function is_pubkey

# Generated at 2022-06-23 04:13:59.458541
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils._text import to_bytes

    ArgumentSpec = basic.AnsibleModule.load_params(as_dict=False)

# Generated at 2022-06-23 04:14:02.930342
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible.module_utils.rpm_key import is_pubkey
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n foo\n-----END PGP PUBLIC KEY BLOCK-----')


# Generated at 2022-06-23 04:14:05.399499
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    rpmkey = RpmKey('test')
    assert rpmkey.execute_command is not None

# Generated at 2022-06-23 04:14:07.718635
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('hello') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK----- bla bla -----END PGP PUBLIC KEY BLOCK-----') is True

# Generated at 2022-06-23 04:14:19.839145
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    test_RpmKey = RpmKey(module)
    assert test_RpmKey.is_keyid('0xc7a20a') is True
    assert test_RpmKey.is_keyid('0x0xc7a20a') is True
    assert test_RpmKey.is_keyid('0Xc7a20a') is True
    assert test_RpmKey.is_

# Generated at 2022-06-23 04:14:31.162224
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test with a key in the rpm db
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            validate_certs=dict(type='bool', default=True),
        ))
    my_rpmkey = RpmKey(module)
    assert my_rpmkey.is_key_imported("6B8D79E6")

    # Test with a key not in the rpm db

# Generated at 2022-06-23 04:14:43.329953
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import os.path
    import tempfile
    from ansible.module_utils._text import to_bytes, to_native
    from io import BytesIO, StringIO
    from ansible.compat.tests import unittest

    class FakeModule(object):
        def __init__(self):
            self.check_mode = False

        def fail_json(self, **argv):
            raise Exception(argv)

        def run_command(*args, **kwargs):
            stdout = b'''
gpg: key DEADB33F: public key "CentOS-7 Key (CentOS 7 Official Signing Key) <security@centos.org>" imported
gpg: Total number processed: 1
gpg:               imported: 1
'''
            return 0, stdout, ''


# Generated at 2022-06-23 04:14:53.056319
# Unit test for function is_pubkey

# Generated at 2022-06-23 04:15:00.725476
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(argument_spec={'state': {'default': 'present', 'choices': ['absent', 'present']},
        'key': {'required': True, 'no_log': False},
        'validate_certs': {'default': True, 'type': 'bool'}},
        supports_check_mode=True)
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0x01234567') == '01234567'


# Generated at 2022-06-23 04:15:10.903428
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test_object = RpmKey(module)
    key_file = '../files/RPM-GPG-KEY-dag'
    expected_fingerprint = 'A20E52146B8D79E6'
    result = test_object.getfingerprint(key_file)
    assert result == expected_fingerprint

# Generated at 2022-06-23 04:15:20.449917
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    m = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    key = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    filename = RpmKey.fetch_key(RpmKey, m, key)
    assert(os.path.isfile(filename))

# Generated at 2022-06-23 04:15:29.985843
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    class Module():
        def __init__(self):
            self.exit_json = print
            self.fail_json = print
    class RpmKey():
        def __init__(self):
            self.module = Module()
            self.gpg = "/usr/bin/gpg"

# Generated at 2022-06-23 04:15:33.480386
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    obj = RpmKey(module)
    assert not obj.drop_key('11D69B3B')

# Generated at 2022-06-23 04:15:45.480926
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(argument_spec={})
    rpm = RpmKey(module)
    assert rpm.normalize_keyid('0xbebebebe') == 'BEBEBEBE'
    assert rpm.normalize_keyid('0Xbebebebe') == 'BEBEBEBE'
    assert rpm.normalize_keyid('bebebebe') == 'BEBEBEBE'
    assert rpm.normalize_keyid('   0Xbebebebe  ') == 'BEBEBEBE'
    assert rpm.normalize_keyid('   0Xbebebebe\n') == 'BEBEBEBE'
    assert rpm.normalize_keyid('   0Xbebebebe\t') == 'BEBEBEBE'


# Generated at 2022-06-23 04:15:51.419630
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    key = RpmKey(None)
    key_normal = key.getkeyid("./tests/gpg_key")
    assert key_normal == "EBC6E12C62B1C734026B2122A20E52146B8D79E6"


# Generated at 2022-06-23 04:15:57.285944
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-23 04:16:09.959830
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import gpg
    from mock import patch, Mock
    module = Mock()
    module.run_command = Mock(return_value=(0, 'a', 'b'))
    rpm = RpmKey(module)
    try:
        rpm.gpg = None
        rpm.execute_command(['ls'])
    except Exception:
        pass
    else:
        assert False
    rpm.gpg = 'not_a_real_binary'
    try:
        rpm.execute_command(['ls'])
    except Exception:
        pass
    else:
        assert False
    rpm.gpg = 'ls'
    try:
        rpm.execute_command(['not_a_valid_cmd'])
    except Exception:
        pass
    else:
        assert False
    rpm.execute_command(['ls'])

# Generated at 2022-06-23 04:16:22.830138
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import sys
    testRpmKey = RpmKey(sys)

    assert testRpmKey.normalize_keyid(u"0xDEADB33F") == u"DEADB33F"
    assert testRpmKey.normalize_keyid(u"0XDEADB33F") == u"DEADB33F"
    assert testRpmKey.normalize_keyid(u"0XDEADB33F ") == u"DEADB33F"
    assert testRpmKey.normalize_keyid(u"DEADB33F") == u"DEADB33F"
    assert testRpmKey.normalize_keyid(u"DEAD B33F") == u"DEADB33F"

# Generated at 2022-06-23 04:16:34.507018
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    lansible.builtin.rpm_key = RpmKey
    m = {}
    setattr(m, 'get_bin_path', lambda *args, **kwargs: 'gpg2')
    m.run_command = lambda *args, **kwargs: (0, 'pub:u:4096:1:3CDAF026B2122A20:1379152708::u:::sc:::+:::23::0:\nfpr:::::::::8371773BDEADB33F:', '')
    setattr(m, 'fail_json', lambda *args, **kwargs: None)
    RpmKey(m)
    assert m.getkeyid.call_args[0][1] == '/tmp/ansible_rpm_key_payload_qm3VQr'

# Generated at 2022-06-23 04:16:46.791175
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    """
    This method test is_key_imported method of class RpmKey
    """
    class RpmKey:
        def __init__(self, module):
            pass


# Generated at 2022-06-23 04:16:58.200669
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("") == False
    assert is_pubkey("some random other text") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK----- something") == False
    assert is_pubkey("something -----END PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK----- something -----END PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK----- something -----END PGP PUBLIC KEY BLOCK----- extra") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK----- something -----END PGP PUBLIC KEY BLOCK----- extra -----END PGP PUBLIC KEY BLOCK-----") == False

# Generated at 2022-06-23 04:17:11.835474
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO
    import sys


# Generated at 2022-06-23 04:17:18.572836
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey('') is False
    assert is_pubkey('hello world') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey('-----END PGP PUBLIC KEY BLOCK-----') is False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----') is True

# Generated at 2022-06-23 04:17:24.685420
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmkey = RpmKey(module)

    # Test for valid rpm command output
    stdout = "gpg: key BFCD28FE: public key \"RPM Package Manager <rpm@packages.debian.org>\" imported\ngpg: Total number processed: 1\ngpg:               imported: 1\n"
    stderr = ""

# Generated at 2022-06-23 04:17:35.287530
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    builtins.open = open
    x = StringIO()
    x.name = 'foo'
    y = StringIO()
    y.name = 'foo'
    z = StringIO()
    z.name = 'foo'

# Generated at 2022-06-23 04:17:47.236757
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    from ansible.module_utils._text import to_bytes

    keyfile = tempfile.mkstemp()[1]

# Generated at 2022-06-23 04:17:56.066844
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.basic import AnsibleModule

    test_url = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/rpm_utils.py'
    foo = RpmKey(dummy_module)
    tmpfilename = foo.fetch_key(test_url)
    with open(tmpfilename, 'r') as tmpfile:
        key = tmpfile.read()
    assert foo.is_pubkey(key)
    os.remove(tmpfilename)



# Generated at 2022-06-23 04:18:08.023841
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmkey = RpmKey(module)

# Generated at 2022-06-23 04:18:18.972549
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    from ansible.module_utils.action_plugins import get_platform_subclass
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 04:18:33.409184
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create instance of RpmKey with empty args
    test_rpm_key = RpmKey(None)

    # Chdir to the temp directory
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    # Get a tempfile
    tmpfd, tmpname = tempfile.mkstemp()
    # Create a test key, write it to tmpfile

# Generated at 2022-06-23 04:18:45.826369
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    helper = AnsibleModule(argument_spec={})
    module = RpmKey(helper)
    assert module.normalize_keyid('0x01234567') == '01234567'
    assert module.normalize_keyid('  0x01234567 ') == '01234567'
    assert module.normalize_keyid('  0X01234567 ') == '01234567'
    assert module.normalize_keyid('0x01234567') == '01234567'
    assert module.normalize_keyid('01234567') == '01234567'
    assert module.normalize_keyid(' 0x01234567') == '01234567'
    assert module.normalize_keyid('01234567 ') == '01234567'