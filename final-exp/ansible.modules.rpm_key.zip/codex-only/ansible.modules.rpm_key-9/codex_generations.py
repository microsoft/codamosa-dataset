

# Generated at 2022-06-23 04:08:47.981892
# Unit test for function is_pubkey
def test_is_pubkey():
    # Test false case
    assert not is_pubkey("Not a good pubkey")
    # Test true case

# Generated at 2022-06-23 04:08:55.406327
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import pytest
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    class MockModule(object):
        check_mode = False
        definition = dict()

        def __init__(self):
            self.params = dict()
            self.exit_args = dict()
            self.debug = False

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def fail_json(self, msg, **kwargs):
            self.exit_args = kwargs
            self.exit_args['msg'] = msg
            raise RuntimeError(msg)

       

# Generated at 2022-06-23 04:08:57.973174
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("BEGIN PGP PUBLIC KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----END PGP PUBLIC KEY BLOCK-----") == True

# Generated at 2022-06-23 04:09:05.041380
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():

    import os

    test_dir = os.path.dirname(os.path.abspath(__file__))
    key_file = os.path.join(test_dir, 'test-fixtures', 'RPM-GPG-KEY.dag.txt')

    rpm_key = RpmKey(None)
    fingerprint = rpm_key.getfingerprint(key_file)
    assert fingerprint.upper() == '0D87 E5A0 98B2 F7E8 FF52  E12C 62B1 C734 026B 2122'

# Generated at 2022-06-23 04:09:18.528685
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    rpm = RpmKey(None)
    # testing '0xDEADB33F'
    test_keyid = '0xDEADB33F'
    assert 'DEADB33F' == rpm.normalize_keyid(test_keyid)
    # testing '0XDEADB33F'
    test_keyid = '0XDEADB33F'
    assert 'DEADB33F' == rpm.normalize_keyid(test_keyid)
    # testing 'DEADB33F'
    test_keyid = 'DEADB33F'
    assert 'DEADB33F' == rpm.normalize_keyid(test_keyid)
    # testing 'DEADB33F '
    test_keyid = 'DEADB33F '
    assert 'DEADB33F'

# Generated at 2022-06-23 04:09:19.668649
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    pass


# Generated at 2022-06-23 04:09:26.770887
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Setup
    class module(object):
        def run_command(self, cmd):
            return 0, "gpg-pubkey-fedora-i386-20\n", ""

    # Run
    rpm_key = RpmKey(module())

    # Asserts
    assert rpm_key.is_key_imported("0xFEDORA-I386-20") == True
    assert rpm_key.is_key_imported("0xFEDORA-I386-21") == False

# Generated at 2022-06-23 04:09:30.638903
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(argument_spec={})
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0x1234abcd')
    assert rpm_key.is_keyid('1234abcd')
    assert not rpm_key.is_keyid('0x123q')
    assert not rpm_key.is_keyid('foo')

# Generated at 2022-06-23 04:09:44.478537
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = MockAnsibleModule()
    module.params = dict(
        key="/path/to/key.gpg",
        state="present"
    )
    rc = 1
    stdout = "gpg-pubkey-deadb33f-55255htf"
    stderr = ""
    rpm_key = RpmKey(module)


    # Expected result: the key is imported
    rpm_key.is_key_imported(keyid="deadb33f")

    # Expected result: the key is not imported
    rc = 0
    stdout = "gpg-pubkey-deadb33f-49303haf"
    rpm_key.is_key_imported(keyid="deadb33f")

    # Expected result: the key is imported

# Generated at 2022-06-23 04:09:57.287633
# Unit test for function is_pubkey

# Generated at 2022-06-23 04:10:09.916665
# Unit test for function is_pubkey
def test_is_pubkey():
    assert is_pubkey("") == False
    assert is_pubkey("-----BEGIN PGP PRIVATE KEY BLOCK-----") == False
    assert is_pubkey("-----BEGIN PGP PUBLIC KEY BLOCK-----") == False

    key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n" \
          "mQENBFHECyEBCACyPF/v75mWap2/rBYZdTPju/rv6mfWmR8j+z++d5H5F6q3W6X8\n" \
          "-----END PGP PUBLIC KEY BLOCK-----\n"

    assert is_pubkey(key) == True

# Generated at 2022-06-23 04:10:24.492556
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class Bunch():
        pass

    class MockModule():
        def __init__(self):
            self.params = Bunch()
            self.params.state = 'present'
            self.params.key = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
            self.params.fingerprint = 'EBC6 E12C 62B1 C734 026B 2122 A20E 5214 6B8D 79E6'
            self.exit_json = lambda a=None, b=None: None
            self.fail_json = lambda a=None, b=None: None
            self.cleanup = lambda x: None
            self.add_cleanup_file = lambda x: None

        def get_bin_path(self, arg, arg2):
            return arg


# Generated at 2022-06-23 04:10:38.041035
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    rpm = RpmKey(mod)

    # Suppress stdout and stderr
    import sys

# Generated at 2022-06-23 04:10:47.627897
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible_collections.ansible.builtin.plugins.module_utils.common.sys_info import get_distribution
    from ansible_collections.ansible.builtin.plugins.modules.rpm_key import RpmKey
    import re

    # Test the key is dropped
    def test_exec_command(cmd, tmpfile, use_unsafe_shell, executable):
        if cmd and cmd[0] == b'rpm':
            assert cmd[:4] == [b'rpm', b'--erase', b'--allmatches', b'gpg-pubkey-deadb33f']

# Generated at 2022-06-23 04:11:00.321718
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    try:
        from mock import MagicMock, patch
        from ansible.module_utils._text import to_bytes
    except Exception:
        mock = None  # No coverage

    module = MagicMock(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)

    # Test a key file with a long keyid
    # Test the error case, as well

# Generated at 2022-06-23 04:11:13.587449
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    key_name = 'test_key'
    key = RpmKey(module)
    cmd = 'rpm -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0: # No key is installed on system
        assert key.is_key_imported(key_name) is False

# Generated at 2022-06-23 04:11:27.489303
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Import the class
    global RpmKey
    from ansible.modules.packaging.os.rpm_key import RpmKey as RpmCmd
    # Create an instance of the class
    module = dict()
    rpmcommand = RpmCmd(module)
    keyid = "DEADB33F"
    assert rpmcommand.normalize_keyid(keyid) == "DEADB33F"
    keyid = "0xDEADB33F"
    assert rpmcommand.normalize_keyid(keyid) == "DEADB33F"
    keyid = " 0xDEADB33F "
    assert rpmcommand.normalize_keyid(keyid) == "DEADB33F"
    keyid = " 0xDEADB33F"
    assert rpmcommand.normalize_keyid(keyid)

# Generated at 2022-06-23 04:11:38.735786
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Given
    module = module_helper.module_helper()
    mocked_RpmKey = RpmKey(module)
    # Key used in test

# Generated at 2022-06-23 04:11:50.603401
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # No key is installed on system
    module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    ),
        supports_check_mode=True,
    )
    key_id = "03cf1ed2d4b3c0de2f742f7873d0db7b54d1e846"
    key_obj = RpmKey(module)
    assert key_obj.is_key_imported(key_id)  is False
    # Key is installed on system

# Generated at 2022-06-23 04:12:02.124837
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import os
    import subprocess
    # We run this test as root because the user running this test doesn't
    # have the necessary permissions to install keys on the rpm DB.
    # Note that if run_command() is changed in the future, this code
    # will have to be updated.
    if os.getuid() != 0:
        subprocess.call(['sudo', 'bash', __file__])
        return
    import shutil
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    dirs = []
    def fake_mkdtemp():
        d = tempfile.mkdtemp()
        dirs.append(d)
        return d
    tempfile.mkdtemp = fake_mkdtemp
    def cleanup_dirs():
        for d in dirs:
            shutil.rmt

# Generated at 2022-06-23 04:12:11.567205
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = dict()

    my_module = AnsibleModuleMock()

    # Test that is_keyid returns true for a valid keyid
    my_module.params['key'] = '0x12345678'
    my_rpm_key = RpmKey(my_module)
    assert my_rpm_key.is_keyid(my_module.params['key'])

    # Test that is_keyid returns true for a valid keyid without the 0x prefix
    my_module.params['key'] = '12345678'
    my_rpm_key = RpmKey(my_module)
    assert my_rpm_key.is_keyid(my_module.params['key'])

    # Test that is_keyid returns false

# Generated at 2022-06-23 04:12:17.035521
# Unit test for method is_keyid of class RpmKey

# Generated at 2022-06-23 04:12:28.707663
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    from ansible.module_utils.six.moves import StringIO
    from unittest.mock import patch

    # Reference key, clear-signed and with leading blanks

# Generated at 2022-06-23 04:12:33.089473
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    m = MockModule({'state': 'present', 'key': '/path/to/key.gpg'})
    rpm = RpmKey(m)
    rpm.import_key("/path/to/key.gpg")


# Generated at 2022-06-23 04:12:43.316311
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    """Verify that fetch_key works for a key url"""

    mock_module = type('', (), {'run_command': run_command, 'fail_json': fail_json, 'add_cleanup_file': add_cleanup_file})
    mock_module.check_mode = False
    key = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    rpm_key = RpmKey(mock_module)
    path_to_key = rpm_key.fetch_key(key)
    assert os.path.isfile(path_to_key)
    os.remove(path_to_key)

# Mock objects

# Generated at 2022-06-23 04:12:54.532868
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import RpmKey

    # Test fetch_key method with invalid url string
    with pytest.raises(Exception) as excinfo:
        RpmKey.fetch_key(mock.MagicMock(), "")
    assert 'msg' in str(excinfo.value)

    # Test fetch_key method with valid url string
    module = mock.MagicMock()
    rsp = mock.MagicMock()
    info = {}
    info['status'] = 200
    module.run_command = mock.MagicMock(return_value=(0, b'testkey', ''))
    module.get_bin_path = mock.MagicMock(return_value='/bin/gpg')
    module.check_mode = False
    module.add_cleanup_file = mock.MagicMock()

# Generated at 2022-06-23 04:13:07.126026
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile

    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")


# Generated at 2022-06-23 04:13:20.498505
# Unit test for function is_pubkey
def test_is_pubkey():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 04:13:31.212232
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid("0x607b15cc1f3d4c70") == '607B15CC1F3D4C70'
    assert RpmKey.normalize_keyid("0X607b15cc1f3d4c70") == '607B15CC1F3D4C70'
    assert RpmKey.normalize_keyid("607b15cc1f3d4c70") == '607B15CC1F3D4C70'
    assert RpmKey.normalize_keyid("607b15cc1f3d4c70 ") == '607B15CC1F3D4C70'

# Generated at 2022-06-23 04:13:35.360994
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    instance = RpmKey(None)
    # Actual code removed
    # expected = "expected code here"
    # assertEqual(instance.drop_key("keyid"), expected)

# Generated at 2022-06-23 04:13:48.088699
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile
    import os
    import sys
    import shutil
    import imp
    os.environ["LANG"] = "C"
    os.environ["LC_ALL"] = "C"
    os.environ["ANSIBLE_ROLES_PATH"] = os.path.join(tempfile.mkdtemp(), 'roles')
    work_dir = tempfile.mkdtemp()
    test_module_path = os.path.join(work_dir, 'test_rpm_key.py')
    shutil.copyfile(os.path.join('./library', 'rpm_key.py'), test_module_path)
    test_module = imp.load_source('rpm_key', test_module_path)


# Generated at 2022-06-23 04:13:54.938341
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    keyid = 'DEADB33F'
    module = {
        'check_mode': False,
        'run_command': fake_run_command
    }

    rpmkey = RpmKey(module)

    rpmkey.drop_key(keyid)

    assert(failed_commands[0] == [rpmkey.rpm, '--erase', '--allmatches', "gpg-pubkey-%s" % keyid[-8:].lower()])


# Generated at 2022-06-23 04:14:06.043177
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm = RpmKey(module)

    assert rpm.normalize_keyid('0x1') == '1'
    assert rpm.normalize_keyid('0X1') == '1'
    assert rpm.normalize_keyid('0x1F') == '1F'
    assert rpm.normalize_keyid('0x1F') == '1F'
    assert rpm.normalize

# Generated at 2022-06-23 04:14:19.073856
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    print("Testing method is_keyid")
    assert RpmKey(None).is_keyid('245906D7')
    assert RpmKey(None).is_keyid('0x245906D7')
    assert RpmKey(None).is_keyid('0X245906D7')
    assert RpmKey(None).is_keyid('245906D7 ')
    assert RpmKey(None).is_keyid(' 245906D7')
    assert RpmKey(None).is_keyid(' 0x245906D7')
    assert RpmKey(None).is_keyid(' 0X245906D7')
    assert RpmKey(None).is_keyid(' 0x245906D7 ')

# Generated at 2022-06-23 04:14:29.819981
# Unit test for function is_pubkey
def test_is_pubkey():
    from ansible.module_utils.helpers import _load_params
    from ansible.module_utils.connection import Connection
    from ansible.modules.packaging.os import rpm_key

    params = _load_params(dict(
      state='present',
      key='http://apt.sw.be/RPM-GPG-KEY.dag.txt',
      validate_certs=True
    ))

    assert rpm_key.is_pubkey('-----BEGIN PGP KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----') == False
    assert rpm_key.is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n-----END PGP PUBLIC KEY BLOCK-----') == True

# Generated at 2022-06-23 04:14:32.999820
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid == normalize_keyid

# Generated at 2022-06-23 04:14:44.042787
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Test parameters:
    module_params = {
        'state': 'present',
        'key': '/tmp/RPM-GPG-KEY-centosofficial',
        'fingerprint': None,
        'validate_certs': False,
    }

    # Test override parameters:

# Generated at 2022-06-23 04:14:55.751503
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Creating a class instance and creating a temp file
    RpmKey(module)
    tmpfd, tmpname = tempfile.mkstemp()

    # Creating a valid gpg key
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-23 04:15:07.668233
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    data = """
        pub:dsa:4096:1:F1E1C1CCACB8C35B:1300365852:::u:::::scESC::::
        fpr:::::::::0B89BC910C2E1A41F1E1C1CCACB8C35B0A031065:
    """
    with open('/tmp/key', 'w') as f:
        f.write(data)

    m = MockAnsibleModule({})
    r = RpmKey(m)
    assert r.getfingerprint('/tmp/key') == '0B89BC910C2E1A41F1E1C1CCACB8C35B0A031065', 'Fingerprint extracted incorrectly'

# Generated at 2022-06-23 04:15:08.343407
# Unit test for constructor of class RpmKey
def test_RpmKey():
    assert True

# Generated at 2022-06-23 04:15:15.598027
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # ==============
    # = normalize_keyid =
    # ==============
    # Tests the case when a keyid has a leading 0x
    keyid_0x = ' 0xdeadbeef'
    normalized_keyid_0x = 'DEADBEEF'
    assert normalized_keyid_0x == RpmKey.normalize_keyid(keyid_0x)

    # Tests the case when a keyid has a leading 0X
    keyid_0X = ' 0Xdeadbeef'
    normalized_keyid_0X = 'DEADBEEF'
    assert normalized_keyid_0X == RpmKey.normalize_keyid(keyid_0X)

    # Tests the case when a keyid doesn't have a leading 0x or 0X, but
    # has leading or trailing whites

# Generated at 2022-06-23 04:15:28.656486
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    """ Test verify if key exist in rpm database """
    import os
    os.environ['PATH'] = "/bin:/sbin:/usr/bin:/usr/sbin"
    import tempfile
    module = AnsibleModule(argument_spec=dict(
        state=dict(type='str', default='present', choices=['absent', 'present']),
        key=dict(type='str', required=True, no_log=False),
        fingerprint=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    key_test=RpmKey(module)

    t_keyid = 'B2322031'

# Generated at 2022-06-23 04:15:42.176999
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import tempfile
    import mock

    class Mod:
        def __init__(self):
            self.params = {}
            self.params['state'] = 'present'
            self.params['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
            self.params['validate_certs'] = True
            self.params['fingerprint'] = None
            self.result = {}
            self.result['changed'] = False

            self.tmpname = None
            self.fp = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 04:15:49.568991
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    url = 'https://fedoraproject.org/static/0608B895.txt'
    path = rpm_key.fetch_key(url)
    with open(path, 'r') as f:
        assert is_pubkey(f.read())

# Generated at 2022-06-23 04:15:58.486788
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
        ),
        supports_check_mode=True,
    )
    fixture = os.path.join(os.path.dirname(__file__),
                           'fixtures',
                           'rpm-key-test.gpg')
    key = RpmKey(module)
    assert key.getfingerprint(fixture) == '39E00E28C0AAC6DBC040124E9AEC1C6649758C35'

# Generated at 2022-06-23 04:16:07.929849
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    instance = RpmKey()
    assert isinstance(instance.is_keyid('0x1234abcd'), bool)
    assert instance.is_keyid('0x1234abcd')
    assert instance.is_keyid('1234abcd')
    assert not instance.is_keyid('1a345bcd')
    assert not instance.is_keyid('abcdefgh')
    assert not instance.is_keyid('12345678')


# Generated at 2022-06-23 04:16:15.236472
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True, nullable=False),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-23 04:16:26.327418
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():

    class ModuleMock(object):

        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': None,
            }

        def fail_json(self, **kwargs):
            raise RuntimeError("%s: %s" % (kwargs['msg'], kwargs))

        def run_command(self, cmd, use_unsafe_shell=True):
            if '-q  gpg-pubkey' in ''.join(cmd):
                return 0, "gpg-pubkey-deadbeef-deadbeef\ngpg-pubkey-deadbe1e-deadbeef\n", None

# Generated at 2022-06-23 04:16:35.213580
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """
    Testing of method that returns keyid from rpm key
    """
    from ansible.modules.packaging.os import rpm_key
    import os

    cur_path = os.path.dirname(os.path.realpath(__file__))
    with open(cur_path + '/test/keys/RPM-GPG-KEY-CentOS-7') as f:
        content = f.read()
        obj = rpm_key.RpmKey(content, None)
        keyid = obj.getkeyid(content)
        assert keyid == '3f10a45a', "Incorrect keyid returned"

# Generated at 2022-06-23 04:16:40.309591
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    gpg = RpmKey(None)
    keyfile = '/path/to/RPM-GPG-KEY.dag.txt'
    result = gpg.getfingerprint(keyfile)
    expected = 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'
    assert result == expected

# Generated at 2022-06-23 04:16:53.407604
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import unittest
    import unittest.mock
    from ansible.module_utils.basic import AnsibleModule

    from .rpm_key import RpmKey

    class MockAnsibleModule(AnsibleModule):
        """
        We do not want to execute any code, but the code does expect that those
        methods exist and are callable.
        """
        def __init__(self, *args, **kwargs):
            pass

        def run_command(self, cmd, use_unsafe_shell=True):
            pass

        def fail_json(self, msg):
            pass

        def get_bin_path(self, binary, required=True):
            pass

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.module = MockAnsibleModule()


# Generated at 2022-06-23 04:17:05.478388
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # This is a stub that could be expanded in the future to test the method properly.
    # Currently, only a few values are tested to see that they are not tested as non-keys.
    assert not RpmKey.is_keyid('99999999')
    assert not RpmKey.is_keyid('0x99999999')
    assert not RpmKey.is_keyid('0x')
    assert not RpmKey.is_keyid('abcdefabcdefabcdefabcdefabcdefa')
    assert not RpmKey.is_keyid('0xabcdefabcdefabcdefabcdefabcdefa')
    assert not RpmKey.is_keyid(' deadbeef ')
    assert not RpmKey.is_keyid('')
    assert RpmKey.is_keyid('deadbeef')
    assert RpmKey

# Generated at 2022-06-23 04:17:18.353393
# Unit test for function main
def test_main():
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text

    test_args = dict(
        state='present',
        key='http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    )
    test_args.update(dict(ANSIBLE_MODULE_ARGS=test_args))
    setattr(ansible.module_utils.basic, 'AnsibleModule', DummyAnsibleModule)
    setattr(ansible.module_utils.urls, 'fetch_url', DummyFetchUrl)
    setattr(ansible.module_utils._text, 'to_native', DummyToNative)
    sys.modules["rpm"] = DummyRpmModule()

# Generated at 2022-06-23 04:17:24.605144
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import cache
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    basic._ANSIBLE_ARGS = StringIO()
    cache.CACHE = StringIO()

    #

# Generated at 2022-06-23 04:17:35.549192
# Unit test for constructor of class RpmKey
def test_RpmKey():
    class Module(object):
        def __init__(self):
            self.params = dict(state='present',
                               key='http://apt.sw.be/RPM-GPG-KEY.dag.txt')
        def get_bin_path(self, command, required=False):
            return r'\usr\bin\%s' % command
        def fail_json(self, msg=""):
            raise Exception(msg)
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, 'stdout', 'stderr'
        def add_cleanup_file(self, filename):
            pass
        def cleanup(self, filename):
            pass
        def check_mode(self):
            pass
    RpmKey(Module())


# Generated at 2022-06-23 04:17:44.862198
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    is_keyid_cases = [
        # (keyid, expected_return_value)
        ('0x12345678', True),
        ('12345678', True),
        ('0X12345678', True),
        ('0x1234', False),
        ('123', False),
        ('123456789', False)
    ]

    module = DummyAnsibleModule()

    rpm_key = RpmKey(module)

    for key, expected_return_value in is_keyid_cases:
        assert expected_return_value == rpm_key.is_keyid(key)

# Generated at 2022-06-23 04:17:54.276743
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():

    class testRpmKey():
        def __init__(self):
            self.rpm = 'rpm'
            self.gpg = 'gpg'
            self.tmpfile = '/tmp/key.txt'
    testModule = testRpmKey()
    testKey = RpmKey(testModule)

    # Keyid from http://apt.sw.be/RPM-GPG-KEY.dag.txt
    if testKey.getkeyid(testModule.tmpfile) != '6B8D79E6':
        raise Exception('Invalid keyid returned')



# Generated at 2022-06-23 04:18:03.132685
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    """This method test getkeyid method of class RPMKey with valid keyfile and
    verify the return value,
      Args:
        keyfile: string, valid keyfile.
      Returns:
        Returns the keyid from keyfile,
    """
    with patch('rpm_key.RpmKey.execute_command'):
        rpm_key_object = RpmKey(None)
        assert rpm_key_object.getkeyid("Test keyfile") == "Unit Test"

# Generated at 2022-06-23 04:18:14.157342
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    from unittest.mock import Mock, call, patch
    import os

    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.rpm_key import (
        is_pubkey,
        is_keyid,
        normalize_keyid,
        RpmKey,
    )

    # When the key is not a valid openssh public key, is_pubkey returns false
    key = 'Not a valid key'
    assert is_pubkey(key) is False

    # When the key is a valid openssh public key, is_pubkey returns true

# Generated at 2022-06-23 04:18:27.148128
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    dummy_rpm = 'rpm'
    keyid = 'DEADB33F'

    #
    # Patching
    #
    import ansible.modules.packaging.os.rpm_key
    ansible.modules.packaging.os.rpm_key.RpmKey.execute_command = mock_execute_command

    #
    # Stubs
    #
    stub_module = DummyAnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    stub_

# Generated at 2022-06-23 04:18:37.101379
# Unit test for method getkeyid of class RpmKey