

# Generated at 2022-06-17 05:07:58.583265
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-17 05:08:10.182628
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    # Write some content to the file
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:08:15.373979
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key("0xDEADB33F")


# Generated at 2022-06-17 05:08:27.039573
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Test with a valid key
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

    # Test with an invalid key

# Generated at 2022-06-17 05:08:38.860803
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import unittest
    import ansible.module_utils.rpm_key as rpm_key
    import ansible.module_utils.basic as basic
    import ansible.module_utils.urls as urls
    import ansible.module_utils.action as action
    import ansible.module_utils.common.dict_transformations as dict_transformations
    import ansible.module_utils.common.text.converters as text_converters
    import ansible.module_utils.common.text.utils as text_utils
    import ansible.module_utils.common.text.formatters as text_formatters
    import ansible.module_utils.common.text.diff as text_diff
    import ansible.module_utils.common.text.regex as text_regex

# Generated at 2022-06-17 05:08:49.769246
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:09:01.187695
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:09:10.600204
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADBEEF')
    assert rpm_key.is_keyid('DEADBEEF')
    assert rpm_key.is_keyid('0xDEADBEE') is False
    assert rpm_key.is_keyid('DEADBEE') is False

# Generated at 2022-06-17 05:09:19.594500
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:09:31.569407
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock rpm command
    def mock_rpm_command(cmd, use_unsafe_shell=True):
        if cmd == ['/bin/rpm', '--erase', '--allmatches', 'gpg-pubkey-deadb33f']:
            return 0, '', ''
        else:
            return 1, '', 'Unexpected command'

    #

# Generated at 2022-06-17 05:09:55.329159
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')


# Generated at 2022-06-17 05:10:02.045210
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')


# Generated at 2022-06-17 05:10:16.099203
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    key = rpm_key.fetch_key('https://raw.githubusercontent.com/ansible/ansible/devel/examples/files/ansible-key.pub')
    assert is_pubkey(open(key, 'r').read())
    os.remove(key)


# Generated at 2022-06-17 05:10:27.018997
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import unittest
    import ansible.module_utils.rpm_key
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.action_common_attributes
    import ansible.module_utils.action_common_attributes.ActionModule
    import ansible.module_utils.action_common_attributes.ActionModule.ActionModule
    import ansible.module_utils.action_common_attributes.ActionModule.ActionModule.ActionModule
    import ansible.module_utils.action_common_attributes.ActionModule.ActionModule.ActionModule.ActionModule
    import ansible.module_utils.action_common_attributes.ActionModule.ActionModule.ActionModule.ActionModule.ActionModule

# Generated at 2022-06-17 05:10:36.503408
# Unit test for method is_key_imported of class RpmKey

# Generated at 2022-06-17 05:10:47.611766
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a temporary module

# Generated at 2022-06-17 05:10:56.135317
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported("0xDEADB33F") == False
    assert rpm_key.is_key_imported("0xDEADB33F") == False

# Generated at 2022-06-17 05:11:10.465134
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock class
    class RpmKeyMock(RpmKey):
        def __init__(self, module):
            self.module = module
            self.rpm = 'rpm'
            self.gpg = 'gpg'

        def execute_command(self, cmd):
            return '', ''

    # Create a mock object
    rpm_key_mock

# Generated at 2022-06-17 05:11:23.130474
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class MockModule(object):
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': None,
                'validate_certs': True,
            }

        def get_bin_path(self, name, required=False):
            if name == 'rpm':
                return '/bin/rpm'
            elif name == 'gpg':
                return '/bin/gpg'
            elif name == 'gpg2':
                return '/bin/gpg2'

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

        def fail_json(self, msg):
            raise Exception(msg)

# Generated at 2022-06-17 05:11:32.866667
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class MockModule(object):
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "stdout", "stderr"

        def fail_json(self, msg):
            raise Exception(msg)

    class MockRpmKey(RpmKey):
        def __init__(self, module):
            self.module = module

    rpm_key = MockRpmKey(MockModule())
    stdout, stderr = rpm_key.execute_command(['echo', 'hello'])
    assert stdout == "stdout"
    assert stderr == "stderr"


# Generated at 2022-06-17 05:12:14.517444
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    import tempfile
    import os.path
    import re
    import os

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self.cleanup_files = []

        def get_bin_path(self, name, required=False):
            if name == 'rpm':
                return '/bin/rpm'
            elif name == 'gpg':
                return '/bin/gpg'
            elif name == 'gpg2':
                return '/bin/gpg2'
            else:
                return None


# Generated at 2022-06-17 05:12:27.437771
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import mock
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    # Test 1: Test the case where the command is

# Generated at 2022-06-17 05:12:36.909026
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import subprocess
    import sys
    import unittest

    class RpmKeyTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:12:49.911279
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {'key': 'keyfile'}
            self.check_mode = False
            self.run_command_results = [0, 'stdout', 'stderr']
            self.fail_json_results = None
            self.add_cleanup_file_results = None

        def get_bin_path(self, *args, **kwargs):
            return 'gpg'

        def run_command(self, *args, **kwargs):
            return self.run_command_results

        def fail_json(self, *args, **kwargs):
            self.fail_json_results = args[0]

        def add_cleanup_file(self, *args, **kwargs):
            self.add

# Generated at 2022-06-17 05:13:04.108340
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['rpm', '--erase', '--allmatches', 'gpg-pubkey-deadb33f']

# Generated at 2022-06-17 05:13:10.876410
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    # Write some content to the temporary file
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:13:24.275558
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    import re
    import os.path
    import tempfile
    import pytest
    import os
    import sys
    import shutil
    import subprocess
    import tempfile
    import pytest
    import os
    import sys
    import shutil
    import subprocess
    import tempfile
    import pytest
    import os
    import sys
    import shutil
    import subprocess
    import tempfile
    import pytest
    import os
    import sys
    import shutil
    import subprocess
    import tempfile
    import pytest
    import os
    import sys
    import shutil
    import subprocess
    import temp

# Generated at 2022-06-17 05:13:30.029077
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create an instance of RpmKey
    rpm_key = RpmKey(module)

    # Test fetch_key with a valid url
    keyfile = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    assert is_pubkey(open(keyfile).read())

    # Test fetch_key

# Generated at 2022-06-17 05:13:39.655041
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:13:47.604287
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:14:59.463906
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    assert rpm_key.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("0XDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("DEADB33F") == "DEADB33F"

# Generated at 2022-06-17 05:15:10.997058
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    import ansible.module_utils.rpm_key
    module = mock.Mock()
    module.check_mode = False
    rpm_key = ansible.module_utils.rpm_key.RpmKey(module)
    rpm_key.rpm = 'rpm'
    rpm_key.import_key('/tmp/key.gpg')
    module.run_command.assert_called_with(['rpm', '--import', '/tmp/key.gpg'], use_unsafe_shell=True)
    module.check_mode = True
    rpm_key.import_key('/tmp/key.gpg')
    module.run_command.assert_called_with(['rpm', '--import', '/tmp/key.gpg'], use_unsafe_shell=True)


# Generated at 2022-06-17 05:15:24.990025
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native

    # Create a tempfile
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create

# Generated at 2022-06-17 05:15:29.930031
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:15:34.782651
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')


# Generated at 2022-06-17 05:15:46.420233
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADBEEF') == False

# Generated at 2022-06-17 05:16:00.787432
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.cleanup_files = []

        def fail_json(self, msg):
            raise Exception(msg)

        def get_bin_path(self, name, required=False):
            return name

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

        def add_cleanup_file(self, path):
            self.cleanup_files.append(path)

       

# Generated at 2022-06-17 05:16:05.595971
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert not rpm_key.is_keyid('DEADB33F0')
    assert not rpm_key

# Generated at 2022-06-17 05:16:14.917638
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 05:16:25.040333
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import mock
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import rpm
    import rpmUtils.miscutils
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary rpmdb
    rpmdb = os.path.join(tmpdir, 'rpmdb')
    os.mkdir(rpmdb)
    rpmUtils.miscutils.setup_locale('C', 'UTF-8')
    ts = rpm.TransactionSet(rpmdb)