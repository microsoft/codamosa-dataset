

# Generated at 2022-06-17 05:07:57.192460
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:08:05.956638
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:08:14.764501
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    import os
    import tempfile

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a mock module
    module = mock.MagicMock()
    module.check_mode = False
    module.run_command = mock.MagicMock()
    module.run_command.return_value = (0, '', '')

    # Create a mock module_utils
    module_utils = mock.MagicMock()
    module_utils.basic = mock.MagicMock()
    module_utils.basic.AnsibleModule = mock.MagicMock()
    module_utils.basic.AnsibleModule.return_value = module

    # Create a mock module_utils.urls
    module_utils.urls = mock.MagicM

# Generated at 2022-06-17 05:08:26.387755
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADB33F')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['rpm', '--erase', '--allmatches', 'gpg-pubkey-deadb33f']

# Generated at 2022-06-17 05:08:38.344344
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:08:49.441898
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import os
    import tempfile
    import shutil
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey
    from ansible.module_utils.rpm_key import is_pubkey
    from ansible.module_utils.rpm_key import normalize_keyid
    from ansible.module_utils.rpm_key import getkeyid
    from ansible.module_utils.rpm_key import getfingerprint
    from ansible.module_utils.rpm_key import is_keyid
    from ansible.module_utils.rpm_key import is_key_imported

# Generated at 2022-06-17 05:08:58.695885
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.getkeyid('/path/to/key.gpg') == '0xDEADB33F'


# Generated at 2022-06-17 05:09:08.892180
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest

    class RpmKeyTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)

        def test_getkeyid(self):
            keyfile = os.path.join(self.test_dir, 'keyfile')

# Generated at 2022-06-17 05:09:17.794048
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test with a key that is not installed
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('DEADBEEF') == False

# Generated at 2022-06-17 05:09:23.150212
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid(' DEADB33F ') == 'DEADB33F'


# Generated at 2022-06-17 05:09:45.895482
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    stdout, stderr = rpm_key.execute_command(['echo', 'test'])
    assert stdout == 'test\n'
    assert stderr == ''


# Generated at 2022-06-17 05:09:50.369883
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:10:00.644971
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('deadb33f')
    assert not rpm_key.is_

# Generated at 2022-06-17 05:10:14.947607
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tempdir)
            self.module = AnsibleModule(argument_spec={})
            self.module.params['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'

# Generated at 2022-06-17 05:10:22.337267
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:10:30.180101
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:10:36.414356
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.fetch_key('https://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-17 05:10:41.584059
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:10:54.928287
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock class
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    tmpfd, tmpname = tempfile.mkstemp()
    module.add_cleanup_file(tmpname)
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:11:01.059124
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert not rpm_key.is_keyid('0xDEADB33F0')
    assert not rpm_key.is_keyid('0xDEADB33F0x')
   

# Generated at 2022-06-17 05:11:41.308211
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native


# Generated at 2022-06-17 05:11:53.084602
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Create a mock keyid
    keyid = '0xDEADB33F'

    # Create a mock command
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'

    # Create a mock stdout

# Generated at 2022-06-17 05:12:07.141559
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Arrange
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    keyfile = 'tests/unit/modules/ansible_collections/ansible/builtin/files/test_key.gpg'

    # Act
    keyid = rpm_key.getkeyid(keyfile)

    # Assert
    assert keyid == '6B8D79E6'

# Generated at 2022-06-17 05:12:14.389744
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('deadb33f') == False

# Generated at 2022-06-17 05:12:24.032948
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')


# Generated at 2022-06-17 05:12:31.708393
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import os
    import tempfile
    import shutil
    import filecmp
    import rpm
    import rpmUtils.miscutils
    import rpmUtils.transaction
    import rpmUtils.updates
    import rpmUtils.miscutils
    import rpmUtils.arch
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils
    import rpmUtils.miscutils

# Generated at 2022-06-17 05:12:37.254474
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.getkeyid('/tmp/test_RpmKey_getkeyid.gpg') == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'


# Generated at 2022-06-17 05:12:50.236679
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.rpm = 'rpm'
    rpm_key.gpg = 'gpg'
    rpm_key.module.run_command = mock_run_command

    # Test
    assert rpm_key.is_key_imported('deadbeef') == True

# Generated at 2022-06-17 05:13:04.899423
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:13:08.711305
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:14:21.853087
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:14:35.381116
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Create a mock keyid
    keyid = 'DEADBEEF'

    # Create a mock execute_command method
    def mock_execute_command(cmd):
        return '', ''

    rpm_key.execute_command = mock_execute_command

    # Call the drop

# Generated at 2022-06-17 05:14:48.773473
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADBEEF')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['rpm', '--erase', '--allmatches', 'gpg-pubkey-deadbeef']

# Generated at 2022-06-17 05:14:58.204943
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADBEEF') == False

# Generated at 2022-06-17 05:15:02.340821
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADBEEF') == False

# Generated at 2022-06-17 05:15:11.857873
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self):
            self.params = {'fingerprint': 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6'}
            self.check_mode = False
            self.run_command_calls = []
            self.fail_json_calls = []
            self.add_cleanup_file_calls = []

        def run_command(self, cmd, use_unsafe_shell=True):
            self.run_command_calls.append(cmd)
            return 0, '', ''


# Generated at 2022-06-17 05:15:25.184740
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)

# Generated at 2022-06-17 05:15:30.285650
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:15:41.127110
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.execute_command(['echo', 'hello']) == ('hello\n', '')


# Generated at 2022-06-17 05:15:52.000835
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.action_common_attributes

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': None,
                'validate_certs': True,
            }
            self.check_mode = False
            self.cleanup_files = []
