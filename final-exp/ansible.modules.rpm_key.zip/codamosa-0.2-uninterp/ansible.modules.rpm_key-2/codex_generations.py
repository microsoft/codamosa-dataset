

# Generated at 2022-06-17 05:07:57.669114
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.is_keyid('0xDEADB33F')
    assert rpmkey.is_keyid('DEADB33F')
    assert rpmkey.is_keyid('0xDEADB33F ')
    assert rpmkey.is_keyid(' 0xDEADB33F')

# Generated at 2022-06-17 05:08:00.647438
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-17 05:08:11.328203
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    keyfile = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    keyid = rpm_key.getkeyid(keyfile)

# Generated at 2022-06-17 05:08:20.531082
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:08:34.261135
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:08:46.729502
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:08:55.225956
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    keyfile = 'tests/test_key.gpg'
    rpm_key = RpmKey(module)
    assert rpm_key.getfingerprint(keyfile) == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'


# Generated at 2022-06-17 05:09:03.155445
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:09:12.780228
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.is_keyid('0xDEADB33F')
    assert rpmkey.is_keyid('DEADB33F')
    assert rpmkey.is_keyid('0xDEADB33F ')
    assert rpmkey.is_keyid(' 0xDEADB33F')

# Generated at 2022-06-17 05:09:23.249107
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    # Create a temp file with a valid key
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")
   

# Generated at 2022-06-17 05:09:51.844436
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADB33F')

# Generated at 2022-06-17 05:10:02.632767
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    tmp_module = os.path.join(tmpdir, 'ansible_module.py')
    shutil.copyfile(ansible.module_utils.rpm_key.__file__, tmp_module)

    # Create a temporary file with a valid key
    tmp_key = os.path.join(tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:10:18.084919
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp(dir=tmpdir)
    # Write the key to the temporary file
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:10:24.148163
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temp dir
    tmpdir = tempfile.mkdtemp()
    # Create a temp file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")
    # Write the key to the temp file

# Generated at 2022-06-17 05:10:37.042106
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:10:44.184211
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    assert RpmKey.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert RpmKey.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert RpmKey.normalize_keyid('DEADB33F') == 'DEADB33F'
    assert RpmKey.normalize_keyid(' DEADB33F ') == 'DEADB33F'

# Generated at 2022-06-17 05:10:51.898166
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock object of class RpmKey
    rpm_key = RpmKey(module)

    # Create a mock object of class AnsibleModule

# Generated at 2022-06-17 05:10:58.750239
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')


# Generated at 2022-06-17 05:11:08.691308
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADB33F')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == [rpm_key.rpm, '--erase', '--allmatches', "gpg-pubkey-deadb33f"]

# Unit test

# Generated at 2022-06-17 05:11:22.694772
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('deadb33f')
    assert not rpm_key.is_

# Generated at 2022-06-17 05:12:13.690653
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:12:27.270969
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:12:37.150536
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:12:50.131940
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock rpm command
    rpm_command = 'rpm -q  gpg-pubkey'

    # Create a mock gpg command
    gpg_command = 'gpg --no-tty --batch --with-colons --fixed-list-mode -'

    # Create a mock rpm_key object
    rpm_key = RpmKey(module)

    # Create a

# Generated at 2022-06-17 05:13:04.791214
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADBEEF')
    assert rpm_key.module.run_command.call_count == 1
    assert rpm_key.module.run_command.call_args[0][0] == ['rpm', '--erase', '--allmatches', 'gpg-pubkey-deadbeef']



# Generated at 2022-06-17 05:13:10.694847
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    key = rpm_key.fetch_key('https://pgp.mit.edu/pks/lookup?op=get&search=0xF8C1CA08A57B9ED7')
    assert is_pubkey(key)


# Generated at 2022-06-17 05:13:23.604593
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    keyfile = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    keyid = rpm_key.getkeyid(keyfile)
    assert keyid == '0E1FAD0C'


# Generated at 2022-06-17 05:13:30.963205
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey


# Generated at 2022-06-17 05:13:40.022422
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')


# Generated at 2022-06-17 05:13:47.804142
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key

    class MockModule(object):
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': 'EBC6 E12C 62B1 C734 026B  2122 A20E 5214 6B8D 79E6',
                'validate_certs': True,
            }
            self.check_mode = False
            self.cleanup_files = []
            self.tmpdir = tempfile

# Generated at 2022-06-17 05:14:45.051807
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock rpm command
    rpm = Mock()
    rpm.return_value = 0

    # Create a mock gpg command
    gpg = Mock()
    gpg.return_value = 0

    # Create a mock execute_command method
    execute_command = Mock()
    execute_command.return_value = 0

    # Create a mock module.run_command method

# Generated at 2022-06-17 05:14:54.752976
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADBEEF') == False
    assert rpm_key.is_key_imported('0xDEADBEEF') == False
    assert rpm_key.is_key_imported('0xDEADBEEF') == False
    assert rpm_key.is_key_imported

# Generated at 2022-06-17 05:15:01.542859
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock class
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    keyfile = tempfile.mkstemp()[1]

    # Call the method
    rpm_key.import_key(keyfile)

    # Assert that the method called the module.run_command

# Generated at 2022-06-17 05:15:11.501250
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.urls
    import ansible.module_utils.basic
    import ansible.module_utils._text
    import ansible.module_utils.action_plugins.rpm_key

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': None,
                'validate_certs': True,
            }
            self.check_mode = False
            self.cleanup_files = []
            self.exit_args = {}
            self.fail_json_args = {}


# Generated at 2022-06-17 05:15:17.538104
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    # Write some content
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:15:27.488950
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = pytest.fail
            self.exit_json = pytest.fail
            self.run_command = pytest.fail
            self.add_cleanup_file = pytest.fail
            self.check_mode = False
            self.cleanup_files = []


# Generated at 2022-06-17 05:15:41.564000
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:15:49.288222
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.is_keyid('0x12345678')
    assert rpmkey.is_keyid('12345678')
    assert rpmkey.is_keyid('0X12345678')
    assert not rpmkey.is_keyid('0x1234567')
    assert not rpmkey.is_keyid('0x123456789')

# Generated at 2022-06-17 05:15:59.858159
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

# Generated at 2022-06-17 05:16:05.084204
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    key = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    assert is_pubkey(key)
