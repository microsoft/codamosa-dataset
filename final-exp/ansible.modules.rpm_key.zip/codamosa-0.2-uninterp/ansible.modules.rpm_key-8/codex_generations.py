

# Generated at 2022-06-17 05:07:58.714397
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import os
    import tempfile
    import shutil
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary key

# Generated at 2022-06-17 05:08:09.410945
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.execute_command([rpm_key.gpg, '--version']) == (b'gpg (GnuPG) 2.0.22\nlibgcrypt 1.4.5\n', b'')


# Generated at 2022-06-17 05:08:16.280753
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Create a mock key

# Generated at 2022-06-17 05:08:27.128879
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = [rpm_key.rpm, '-q', 'gpg-pubkey']
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:08:37.934058
# Unit test for method getkeyid of class RpmKey

# Generated at 2022-06-17 05:08:49.052470
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    assert rpm_key.fetch_key('https://apt.sw.be/RPM-GPG-KEY.dag.txt')

# Generated at 2022-06-17 05:08:56.742371
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:09:06.870095
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt")


# Generated at 2022-06-17 05:09:22.728375
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    # Create a new instance of RpmKey
    rpm_key = RpmKey(None)
    # Test if a keyid is a keyid
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    # Test if a non keyid is a keyid
    assert not rpm_key.is_keyid('0xDEADB33F0')
    assert not rpm_key.is_keyid('DEADB33F0')
    assert not rpm_key.is_keyid('0xDEADB33F0')
    assert not rpm_key.is_

# Generated at 2022-06-17 05:09:32.121048
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:09:52.984038
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    import tempfile
    import os
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temp dir
    tmpdir = tempfile.mkdtemp()
    # Create a temp file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:10:03.036029
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:10:06.317833
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:10:10.755789
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Test with a keyid with a leading 0x
    keyid = '0xDEADB33F'
    assert RpmKey.normalize_keyid(keyid) == 'DEADB33F'
    # Test with a keyid with a leading 0X
    keyid = '0XDEADB33F'
    assert RpmKey.normalize_keyid(keyid) == 'DEADB33F'
    # Test with a keyid with a leading 0x and trailing whitespace
    keyid = '0xDEADB33F '
    assert RpmKey.normalize_keyid(keyid) == 'DEADB33F'
    # Test with a keyid with a leading 0X and trailing whitespace
    keyid = '0XDEADB33F '
    assert RpmKey.normalize_keyid

# Generated at 2022-06-17 05:10:22.051963
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key("DEADBEEF")
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['rpm', '--erase', '--allmatches', "gpg-pubkey-deadbeef"]


# Generated at 2022-06-17 05:10:30.019458
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:10:38.324001
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmkey = RpmKey(module)
    rpmkey.drop_key("0xDEADB33F")


# Generated at 2022-06-17 05:10:52.669395
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import unittest
    import mock
    import os
    import sys
    import tempfile
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.module = mock.MagicMock()
            self.module.run_command = mock.MagicMock()
            self.rpm_key = ansible.module_utils.rpm_key.RpmKey.RpmKey(self.module)

# Generated at 2022-06-17 05:11:00.439919
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import shutil
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:11:13.447075
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey


# Generated at 2022-06-17 05:11:35.470108
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('deadb33f') == 'DEADB33F'


# Generated at 2022-06-17 05:11:44.512920
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    from ansible.module_utils._text import to_bytes

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.module = AnsibleModule(
                argument_spec=dict(
                    state=dict(type='str', default='present', choices=['absent', 'present']),
                    key=dict(type='str', required=True, no_log=False),
                    fingerprint=dict(type='str'),
                    validate_certs=dict(type='bool', default=True),
                ),
                supports_check_mode=True,
            )

# Generated at 2022-06-17 05:11:56.293291
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:12:09.087375
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    keyfile = 'tests/test_key.gpg'

    # Call the getfingerprint method
    fingerprint = rpm_key.getfingerprint(keyfile)

    # Assert that the fingerprint is correct

# Generated at 2022-06-17 05:12:16.908193
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert not rpm_key

# Generated at 2022-06-17 05:12:26.737500
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    key = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    assert is_pubkey(open(key).read())


# Generated at 2022-06-17 05:12:36.460112
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    # Test
    rpm_key.drop_key('DEADB33F')

    # Assert
    assert module.run_command.call_count == 1

# Generated at 2022-06-17 05:12:49.518605
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Create a mock module
    module = AnsibleModule(argument_spec={})
    # Create a mock class
    rpm_key = RpmKey(module)
    # Create a mock keyfile

# Generated at 2022-06-17 05:13:04.160692
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("0XDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("DEADB33F") == "DEADB33F"

# Generated at 2022-06-17 05:13:10.899767
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    url = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    keyfile = rpm_key.fetch_key(url)
    assert os.path.isfile(keyfile)
    assert is_pubkey(open(keyfile).read())
    os.remove(keyfile)


# Generated at 2022-06-17 05:14:01.741598
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey
    import os.path
    import tempfile
    import re

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self.cleanup_files = []

        def add_cleanup_file(self, path):
            self.cleanup_files.append(path)

        def cleanup(self, path):
            self.cleanup_files.remove(path)

        def fail_json(self, msg):
            raise Exception(msg)


# Generated at 2022-06-17 05:14:16.512745
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 05:14:28.682123
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getkeyid
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.is_keyid
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.normalize_keyid
    import ansible.module_utils.rpm

# Generated at 2022-06-17 05:14:36.907764
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    cmd = [rpm_key.gpg, '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '--with-fingerprint', '/path/to/RPM-GPG-KEY.dag.txt']
    stdout, stderr = rpm_key.execute_command(cmd)
    assert std

# Generated at 2022-06-17 05:14:44.005779
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')

# Generated at 2022-06-17 05:14:54.175962
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:15:07.250552
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Create a mock class
    rpm_key = RpmKey(module)
    # Create a mock keyfile
    keyfile = 'test_keyfile'
    # Create a mock execute_command method
    def mock_execute_command(cmd):
        return '', ''
    # Set the mock execute_command method
    rpm_key.execute_command = mock_execute_command

# Generated at 2022-06-17 05:15:14.647867
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpfd, self.tmpname = tempfile.mkstemp()
            self.tmpfile = os.fdopen(self.tmpfd, "w+b")

# Generated at 2022-06-17 05:15:25.060935
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    # Test with a keyid with a leading 0x
    keyid = '0xDEADB33F'
    assert RpmKey.normalize_keyid(RpmKey, keyid) == 'DEADB33F'

    # Test with a keyid with a leading 0X
    keyid = '0XDEADB33F'
    assert RpmKey.normalize_keyid(RpmKey, keyid) == 'DEADB33F'

    # Test with a keyid without a leading 0x
    keyid = 'DEADB33F'
    assert RpmKey.normalize_keyid(RpmKey, keyid) == 'DEADB33F'

    # Test with a keyid with a leading 0x and trailing whitespace
    keyid = '0xDEADB33F '
    assert RpmKey

# Generated at 2022-06-17 05:15:35.298361
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid("0xDEADB33F") == True
    assert rpm_key.is_keyid("DEADB33F") == True
    assert rpm_key.is_keyid("0xDEADB33") == False

# Generated at 2022-06-17 05:17:20.536601
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import filecmp
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import is_pubkey, RpmKey

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a fake module

# Generated at 2022-06-17 05:17:33.224610
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getkeyid
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.normalize_keyid
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.is_keyid
    import ansible.module