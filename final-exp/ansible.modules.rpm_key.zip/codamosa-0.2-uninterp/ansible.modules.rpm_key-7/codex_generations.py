

# Generated at 2022-06-17 05:07:59.271747
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    class MockModule(object):
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': None,
                'validate_certs': True
            }

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, 'pub:u:1024:17:DEADB33F:1398582423:::u:::scESC:', ''

        def fail_json(self, msg):
            raise Exception(msg)

        def add_cleanup_file(self, tmpname):
            pass

       

# Generated at 2022-06-17 05:08:10.755095
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey
    from ansible.module_utils.rpm_key import is_pubkey
    from ansible.module_utils.rpm_key import normalize_keyid
    from ansible.module_utils.rpm_key import is_keyid

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})
            self.module.exit_json = lambda x: x

# Generated at 2022-06-17 05:08:25.578206
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:08:37.302720
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    class RpmKeyTest(unittest.TestCase):
        def setUp(self):
            self.rpm_key = RpmKey(None)
            self.rpm_key.rpm = 'rpm'
            self.rpm_key.gpg = 'gpg'
            self.rpm_key.module = None
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, 'test.gpg')
            self.keyid = '0xDEADBEEF'
            self.keyid_lower = self.keyid.lower()
            self.keyid_short = self.keyid[-8:].lower()
            self.key

# Generated at 2022-06-17 05:08:48.118056
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:09:02.576656
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Create a mock keyid
    keyid = 'DEADB33F'

    # Create a mock execute_command method
    def mock_execute_command(cmd):
        return '', ''

    # Set the mock execute_command method
    rpm_key.execute_command = mock

# Generated at 2022-06-17 05:09:11.571848
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock class
    rpm_key = RpmKey(module)

    # Create a mock method
    rpm_key.execute_command = MagicMock(return_value=('', ''))

    # Call the method
    rpm_key.drop_key('DEADBEEF')

    # Assert that the method was called with the correct parameters

# Generated at 2022-06-17 05:09:21.861436
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:09:29.363205
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')

# Generated at 2022-06-17 05:09:35.405462
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported("0xDEADB33F") == False

# Generated at 2022-06-17 05:09:57.261006
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:10:05.600463
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:10:19.767760
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Create a mock rpm
    rpm = 'rpm'
    # Create a mock keyfile
    keyfile = '/path/to/keyfile'
    # Create a mock RpmKey object
    rpm_key = RpmKey(module)
    # Set the rpm attribute of the RpmKey object to the mock rpm
    rpm_key.rpm = rpm
    # Call the import_

# Generated at 2022-06-17 05:10:34.942981
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = [rpm_key.gpg, '--no-tty', '--batch', '--with-colons', '--fixed-list-mode', '--with-fingerprint', 'test_key.gpg']
    stdout, stderr = rpm_key.execute_command(cmd)

# Generated at 2022-06-17 05:10:45.811673
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})
            self.module.params['key'] = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/rpm_key.py'

# Generated at 2022-06-17 05:10:53.420003
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:11:00.124948
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}
            self.check_mode = False

        def fail_json(self, msg):
            raise Exception(msg)


# Generated at 2022-06-17 05:11:07.709215
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:11:22.183610
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import zip_longest
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import filterfalse
    from ansible.module_utils.six.moves import input

# Generated at 2022-06-17 05:11:33.863510
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    import tempfile
    import os
    import shutil
    import os.path
    import sys
    import subprocess
    import re
    import os
    import tempfile
    import shutil
    import os.path
    import sys
    import subprocess
    import re
    import os
    import tempfile
    import shutil
    import os.path
    import sys
    import subprocess
    import re
    import os
    import tempfile
    import shutil
    import os.path
    import sys
    import subprocess
    import re
    import os
    import tempfile
    import shutil
    import os.path
    import sys
    import subprocess
    import re
    import os
    import tempfile
    import shutil
    import os.path
    import sys
    import subprocess
    import re
   

# Generated at 2022-06-17 05:12:09.175352
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Create a RpmKey object
    rpm_key = RpmKey(None)
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    # Write the key to the temporary file
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:12:22.937802
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:12:33.578116
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey


# Generated at 2022-06-17 05:12:44.235664
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    class MockModule(object):
        def __init__(self):
            self.fail_json = lambda msg: None
            self.run_command = lambda cmd, use_unsafe_shell: (0, 'stdout', 'stderr')

    class MockRpmKey(RpmKey):
        def __init__(self, module):
            self.module = module

    rpm_key = MockRpmKey(MockModule())
    stdout, stderr = rpm_key.execute_command(['/bin/echo', 'hello'])
    assert stdout == 'stdout'
    assert stderr == 'stderr'

# Generated at 2022-06-17 05:12:56.134825
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey
    from ansible.module_utils.rpm_key import is_pubkey
    from ansible.module_utils.rpm_key import main
    from ansible.module_utils.rpm_key import test_main
    from ansible.module_utils.rpm_key import normalize_keyid
    from ansible.module_utils.rpm_key import is_keyid
    from ansible.module_utils.rpm_key import getkeyid


# Generated at 2022-06-17 05:13:05.506156
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock class
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    tmpfd, tmpname = tempfile.mkstemp()
    module.add_cleanup_file(tmpname)
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:13:11.738040
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey
    from ansible.module_utils.rpm_key import is_pubkey
    from ansible.module_utils.rpm_key import normalize_keyid
    from ansible.module_utils.rpm_key import getkeyid
    from ansible.module_utils.rpm_key import getfingerprint
    from ansible.module_utils.rpm_key import is_keyid
    from ansible.module_utils.rpm_key import execute_command
    from ansible.module_utils.rpm_key import is_

# Generated at 2022-06-17 05:13:23.610270
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = ['echo', 'hello']
    stdout, stderr = rpm_key.execute_command(cmd)
    assert stdout == 'hello\n'
    assert stderr == ''


# Generated at 2022-06-17 05:13:33.580789
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:13:43.955458
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    assert RpmKey.is_keyid('0xDEADB33F')
    assert RpmKey.is_keyid('DEADB33F')
    assert not RpmKey.is_keyid('0xDEADB33F0')
    assert not RpmKey.is_keyid('0xDEADB33')
    assert not RpmKey.is_keyid('0xDEADB33G')
    assert not RpmKey.is_keyid('DEADB33G')
    assert not RpmKey.is_keyid('DEADB33F0')
    assert not RpmKey.is_keyid('DEADB33')
    assert not RpmKey.is_keyid('DEADB33F0')
    assert not RpmKey.is_keyid('DEADB33')

# Generated at 2022-06-17 05:14:53.942294
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    r = RpmKey(None)
    assert r.is_keyid('0xDEADB33F')
    assert r.is_keyid('DEADB33F')
    assert r.is_keyid('0xDEADB33F')
    assert r.is_keyid('0XDEADB33F')
    assert not r.is_keyid('0xDEADB33F0')
    assert not r.is_keyid('0xDEADB33F0x')
    assert not r.is_keyid('DEADB33F0')
    assert not r.is_keyid('DEADB33F0x')
    assert not r.is_keyid('0xDEADB33F ')
    assert not r.is_keyid(' 0xDEADB33F')

# Generated at 2022-06-17 05:15:07.206171
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = os.path.join(tmpdir, 'tmpfile')

# Generated at 2022-06-17 05:15:13.908425
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADBEEF')
    assert rpm_key.module.run_command.call_args[0][0] == 'rpm --erase --allmatches gpg-pubkey-deadbeef'

# Generated at 2022-06-17 05:15:25.919231
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert not rpm_key

# Generated at 2022-06-17 05:15:38.062806
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:15:48.184870
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.execute_command(['echo', 'hello']) == ('hello\n', '')


# Generated at 2022-06-17 05:16:02.205488
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    class MockModule(object):
        def __init__(self):
            self.params = {
                'state': 'present',
                'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt',
                'fingerprint': None,
                'validate_certs': True
            }
            self.check_mode = False

        def get_bin_path(self, name, required=False):
            if name == 'rpm':
                return '/bin/rpm'

# Generated at 2022-06-17 05:16:05.633628
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    module = mock.Mock()
    module.check_mode = False
    rpm_key = RpmKey(module)
    rpm_key.execute_command = mock.Mock()
    rpm_key.import_key('/path/to/key.gpg')
    rpm_key.execute_command.assert_called_once_with([rpm_key.rpm, '--import', '/path/to/key.gpg'])


# Generated at 2022-06-17 05:16:14.917951
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert rpm

# Generated at 2022-06-17 05:16:24.243849
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    stdout, stderr = rpm_key.execute_command(['echo', 'test'])
    assert stdout == 'test\n'
    assert stderr == ''
