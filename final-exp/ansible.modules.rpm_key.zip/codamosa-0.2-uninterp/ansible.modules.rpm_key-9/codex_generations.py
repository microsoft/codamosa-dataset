

# Generated at 2022-06-17 05:07:54.883530
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Create a mock class
    rpm_key = RpmKey(module)
    # Create a mock keyfile
    keyfile = tempfile.mkstemp()[1]
    # Create a mock execute_command function
    def mock_execute_command(cmd):
        return None, None
    # Set the execute_command function to the mock
    rpm_key.execute_command

# Generated at 2022-06-17 05:08:01.484594
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADB33F') == False
    assert rpm_key.is_key_imported('DEADB33F') == False
    assert rpm_key.is_key_imported('0xD3ADB33F') == False

# Generated at 2022-06-17 05:08:09.651454
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADBEEF') == False

# Generated at 2022-06-17 05:08:15.373735
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-17 05:08:24.393048
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')


# Generated at 2022-06-17 05:08:36.076914
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:08:47.615326
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import mock
    import sys
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    # Mock the module
    module = mock.Mock(spec=AnsibleModule)
    module.run_command.return_value = (0, '', '')
    module.check_mode = False
    module.params = {'state': 'present', 'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt', 'fingerprint': None}
    module.get_bin_path.return_value = '/bin/rpm'
    module.fail_json

# Generated at 2022-06-17 05:09:02.522102
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.urls
    import ansible.module_utils.six
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.response
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.robotparser
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.parse


# Generated at 2022-06-17 05:09:11.570339
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)
            self.test_file = os.path.join(self.test_dir, 'test_key')

# Generated at 2022-06-17 05:09:21.861431
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Test if key is imported
    assert rpm_key.is_key_imported('0xDEADBEEF') == False

    # Test if key is not imported
    assert rpm_key.is_key_imported('0xDEADBEEF') == False

# Generated at 2022-06-17 05:09:42.903058
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADBEEF')

# Generated at 2022-06-17 05:09:52.402096
# Unit test for constructor of class RpmKey
def test_RpmKey():
    # Test case 1: key is a url
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params['key'] = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'
    RpmKey(module)

    # Test case 2: key is a file

# Generated at 2022-06-17 05:10:02.929690
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")
    tmpfile.write(b"-----BEGIN PGP PUBLIC KEY BLOCK-----\nVersion: GnuPG v1\n\n")

# Generated at 2022-06-17 05:10:18.085155
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    keyfile = 'test_keyfile'
    rpm_key = RpmKey(module)
    rpm_key.execute_command = MagicMock()

    # Test
    rpm_key.import_key(keyfile)

    # Assert
    rpm_key.execute_command.assert_called_once_with(['rpm', '--import', keyfile])



# Generated at 2022-06-17 05:10:24.165709
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:10:31.396808
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock object of class RpmKey
    rpm_key = RpmKey(module)

    # Test case 1: key is not installed
    # Mock the return value of method execute_command
    rpm_key.execute_command = MagicMock(return_value=(1, '', ''))

# Generated at 2022-06-17 05:10:40.238138
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.urls import fetch_url

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = self.fail
            self.run_command = self.run_cmd

        def fail(self, msg):
            raise Exception(msg)

        def run_cmd(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    class FakeAnsibleModule(AnsibleModule):
        def __init__(self, params):
            self.params = params
            self.fail_json = self.fail

# Generated at 2022-06-17 05:10:54.370569
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock rpm key object
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    keyfile = "/tmp/keyfile"

    # Create a mock execute_command method
    def mock_execute_command(cmd):
        return "", ""

    # Set the mock execute_command method
    rpm_key.execute_command = mock_execute

# Generated at 2022-06-17 05:11:01.257884
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.urls as urls
    import ansible.module_utils.basic as basic
    import ansible.module_utils._text as text
    import ansible.module_utils.rpm_key as rpm_key

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:11:13.953655
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest
    from unittest.mock import patch, Mock, MagicMock

    class RpmKeyTest(unittest.TestCase):
        def setUp(self):
            self.rpm_key = RpmKey(Mock())
            self.rpm_key.rpm = 'rpm'
            self.rpm_key.gpg = 'gpg'
            self.rpm_key.module = Mock()
            self.rpm_key.module.run_command = Mock()
            self.rpm_key.module.run_command.return_value = (0, '', '')

        def test_is_key_imported_no_key(self):
            self.rpm_key.module.run_command.return_value

# Generated at 2022-06-17 05:11:46.783484
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Test case 1
    # Test with a keyid that is not in the rpm db
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('DEADB33F') == False

    # Test case 2
    # Test with a keyid that is in the rpm db

# Generated at 2022-06-17 05:11:57.587679
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    tmp_module = os.path.join(tmpdir, 'ansible_module.py')
    shutil.copyfile(ansible.module_utils.rpm_key.__file__, tmp_module)

    # Create a temporary file with a valid key
    tmp_key = os.path.join(tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:12:10.744357
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    # Test with a valid key
    module = AnsibleModule(argument_spec={})
    rpmkey = RpmKey(module)
    keyfile = rpmkey.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    keyid = rpmkey.getkeyid(keyfile)
    assert keyid == 'EBC6E12C62B1C734026B2122A20E52146B8D79E6'

    # Test with an invalid key
    module = AnsibleModule(argument_spec={})
    rpmkey = RpmKey(module)
    keyfile = rpmkey.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    keyid = rpmkey.getkeyid(keyfile)

# Generated at 2022-06-17 05:12:23.311844
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert not rpm_key

# Generated at 2022-06-17 05:12:30.309308
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')


# Generated at 2022-06-17 05:12:44.979374
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    # Test 1: Test execute_command with a valid command

# Generated at 2022-06-17 05:12:56.194849
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert rpm

# Generated at 2022-06-17 05:13:04.474646
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Test with a key that is not present in the rpm db
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.drop_key('DEADB33F') == None


# Generated at 2022-06-17 05:13:10.900799
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import shutil
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp(dir=tmpdir)
    tmpfile = os.fdopen(tmpfd, "w+b")

    # Write content to the temporary file

# Generated at 2022-06-17 05:13:23.898061
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.urls
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.response

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp(dir=tmpdir)
    # Write content to the temporary file

# Generated at 2022-06-17 05:14:30.886174
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:14:36.128885
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')


# Generated at 2022-06-17 05:14:42.991125
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_results.append((0, 'gpg-pubkey-deadb33f-5a077d58', ''))
            self.run_command_results.append((0, 'pub:r:1024:17:DEADB33F:1398997801:::', ''))
            self.run_command_results.append((0, 'pub:r:1024:17:DEADB33F:1398997801:::', ''))
            self.run_command_results.append((0, 'pub:r:1024:17:DEADB33F:1398997801:::', ''))

# Generated at 2022-06-17 05:14:53.459008
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    keyfile = rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt')
    assert is_pubkey(open(keyfile).read())
    os.remove(keyfile)


# Generated at 2022-06-17 05:15:02.934648
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-17 05:15:09.083006
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-17 05:15:15.792630
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:15:26.256082
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:15:38.823197
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest

    class RpmKeyTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:15:45.149473
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp(dir=tmpdir)
    # Write content to the temporary file
    tmpfile = os.fdopen(tmpfd, "w+b")