

# Generated at 2022-06-17 05:07:56.841725
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.keyfile = os.path.join(self.tempdir, 'key.gpg')

# Generated at 2022-06-17 05:08:09.328579
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:08:14.302557
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.import_key("test")


# Generated at 2022-06-17 05:08:26.895134
# Unit test for constructor of class RpmKey
def test_RpmKey():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    import tempfile
    import os.path
    import re
    import os

    # Test is_pubkey()
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----') == False
    assert is_pubkey('-----BEGIN PGP PUBLIC KEY BLOCK-----\n\n-----END PGP PUBLIC KEY BLOCK-----') == True

    # Test normalize_keyid()
    assert RpmKey.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert RpmKey.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:08:36.317675
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')

# Generated at 2022-06-17 05:08:45.256051
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADBEEF') == False

# Generated at 2022-06-17 05:08:50.949589
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:08:58.766493
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    RpmKey(module)

# Generated at 2022-06-17 05:09:08.915467
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:09:14.381230
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(self.cleanup)
            self.module = AnsibleModule(argument_spec={})

        def cleanup(self):
            import shutil
            shutil.rmtree(self.tmpdir)

        def test_getfingerprint(self):
            keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:09:34.424074
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:09:45.145840
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import tempfile
    import os
    import shutil
    import sys
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.is_pubkey
    import ansible.module_utils.rpm_key.RpmKey.fetch_key
    import ansible.module_utils.rpm_key.RpmKey.normalize_keyid
    import ansible.module_utils.rpm_key.RpmKey.getkeyid
    import ansible.module_utils.rpm_key.RpmKey.getfingerprint

# Generated at 2022-06-17 05:09:57.487194
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('deadb33f')
    assert not rpm_key.is_

# Generated at 2022-06-17 05:10:08.259415
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tempdir)

# Generated at 2022-06-17 05:10:21.196953
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    keyfile = tempfile.mkstemp()[1]

    # Create a mock execute_command method
    def mock_execute_command(cmd):
        return '', ''

    # Set the mock execute_command method
    rpm_key.execute_

# Generated at 2022-06-17 05:10:29.682006
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:10:38.461580
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('DEADB33F')


# Generated at 2022-06-17 05:10:52.730925
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert not rpm_key

# Generated at 2022-06-17 05:10:59.456460
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key')
    assert rpm_key.module.run_command.call_count == 1
    assert rpm_key.module.run_command.call_args[0][0] == ['rpm', '--import', '/path/to/key']


# Generated at 2022-06-17 05:11:12.623146
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:11:50.705294
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    class MockModule(object):
        def __init__(self):
            self.params = {'state': 'present', 'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'}
            self.check_mode = False
            self.run_command_calls = []

        def run_command(self, cmd, use_unsafe_shell=True):
            self.run_command_calls.append(cmd)
            return 0, '', ''

        def fail_json(self, msg):
            raise Exception(msg)

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def add_cleanup_file(self, tmpname):
            pass

    rpm_key = RpmKey(MockModule())
    rpm_

# Generated at 2022-06-17 05:11:58.561973
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self):
            self.params = {'state': 'present', 'key': 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'}
            self.check_mode = False
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_stdouts = []

# Generated at 2022-06-17 05:12:02.806078
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADBEEF')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['rpm', '--erase', '--allmatches', 'gpg-pubkey-deadbeef']

# Generated at 2022-06-17 05:12:10.127852
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getfingerprint
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getfingerprint.test_RpmKey_getfingerprint
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getfingerprint

# Generated at 2022-06-17 05:12:16.702908
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.fetch_key('http://apt.sw.be/RPM-GPG-KEY.dag.txt') is not None


# Generated at 2022-06-17 05:12:27.605238
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert not rpm_key.is_keyid('0xDEADB33F0')
    assert not rpm

# Generated at 2022-06-17 05:12:36.988957
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert not rpm_key

# Generated at 2022-06-17 05:12:50.022773
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getfingerprint
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getfingerprint.RpmKeyTestCase

    class RpmKeyTestCase(unittest.TestCase):
        def setUp(self):
            self.tmp

# Generated at 2022-06-17 05:13:04.680406
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Create a temporary file in the temporary directory
    tmpfile2 = os.path.join(tmpdir, 'tmpfile2')

# Generated at 2022-06-17 05:13:11.006233
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpmkey = RpmKey(module)
    assert rpmkey.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert rpm

# Generated at 2022-06-17 05:14:28.681923
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    import mock
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Write a test key to the temporary file

# Generated at 2022-06-17 05:14:32.027121
# Unit test for constructor of class RpmKey
def test_RpmKey():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    RpmKey(module)

# Generated at 2022-06-17 05:14:45.399688
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock rpm_key object
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    keyfile = 'test_keyfile'

    # Create a mock execute_command method
    def mock_execute_command(cmd):
        return '', ''

    # Set the execute_command method to the mock

# Generated at 2022-06-17 05:14:58.397111
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os.path
    import os
    import shutil
    import sys
    import unittest

    class RpmKeyTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:15:10.288658
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock fetch_url

# Generated at 2022-06-17 05:15:23.481158
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    stdout, stderr = rpm_key.execute_command(['echo', 'test'])
    assert stdout == 'test\n'
    assert stderr == ''


# Generated at 2022-06-17 05:15:31.455030
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key

    # Create a temporary file to store the key
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a mock module

# Generated at 2022-06-17 05:15:37.384466
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    import mock
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temp dir
    temp_dir = tempfile.mkdtemp()
    # Create a temp file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)

# Generated at 2022-06-17 05:15:50.125968
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert not rpm_key.is_keyid('DEADB33F0')
    assert not rpm_key

# Generated at 2022-06-17 05:15:59.913575
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    # Write a valid gpg key to the temporary file
    tmpfile = os.fdopen(tmpfd, "w+b")