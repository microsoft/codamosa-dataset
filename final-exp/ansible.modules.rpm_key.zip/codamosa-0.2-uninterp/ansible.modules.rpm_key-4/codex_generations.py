

# Generated at 2022-06-17 05:07:56.604123
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.urls
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import urlunparse

# Generated at 2022-06-17 05:08:02.036445
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'
    rc, stdout, stderr = module.run_command(cmd)
    if rc != 0:  # No key is installed on system
        return False

# Generated at 2022-06-17 05:08:11.435826
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import is_pubkey, RpmKey

    # Create a temporary file to store the key
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a mock module to test the method

# Generated at 2022-06-17 05:08:17.494373
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock RpmKey object
    rpm_key = RpmKey(module)

    # Create a mock keyid
    keyid = 'DEADB33F'

    # Create a mock command
    cmd = rpm_key.rpm + ' -q  gpg-pubkey'

    # Create a mock stdout

# Generated at 2022-06-17 05:08:26.735724
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os.path
    import os

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:08:38.631469
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADBEEF')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == [rpm_key.rpm, '--erase', '--allmatches', "gpg-pubkey-deadbeef"]


# Generated at 2022-06-17 05:08:49.612321
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock rpm command
    rpm_cmd = 'rpm -q  gpg-pubkey --qf "%{description}" | gpg --no-tty --batch --with-colons --fixed-list-mode -'

    # Create a mock rpm command that returns a keyid

# Generated at 2022-06-17 05:08:57.211528
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = os.path.join(tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:09:08.502704
# Unit test for method is_key_imported of class RpmKey

# Generated at 2022-06-17 05:09:19.403080
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpmkey = RpmKey(module)
    assert rpmkey.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpmkey.normalize_keyid('DEADBEEF') == 'DEADBEEF'
    assert rpm

# Generated at 2022-06-17 05:09:44.072278
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock rpm_key object
    rpm_key = RpmKey(module)

    # Create a mock keyfile
    keyfile = "test_keyfile"

    # Create a mock execute_command method
    def mock_execute_command(cmd):
        return "", ""

    # Set the mock execute_command method to the rpm_key object

# Generated at 2022-06-17 05:09:53.225025
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADBEEF')

# Generated at 2022-06-17 05:10:03.532547
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('0XDEADB33F') == 'DEADB33F'
    assert rpm_key.normalize_keyid('DEADB33F') == 'DEADB33F'

# Generated at 2022-06-17 05:10:11.740404
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.keyfile = os.path.join(self.tmpdir, 'RPM-GPG-KEY-dag')
            with open(self.keyfile, 'wb') as f:
                f.write(to_bytes(RPM_GPG_KEY_DAG))

        def tearDown(self):
            import shutil
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-17 05:10:17.690461
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    import unittest
    class TestRpmKey(unittest.TestCase):
        def test_is_keyid(self):
            self.assertTrue(RpmKey.is_keyid('0x12345678'))
            self.assertTrue(RpmKey.is_keyid('12345678'))
            self.assertFalse(RpmKey.is_keyid('0x123456789'))
            self.assertFalse(RpmKey.is_keyid('0x1234567'))
            self.assertFalse(RpmKey.is_keyid('0x1234567g'))
            self.assertFalse(RpmKey.is_keyid('0x1234567G'))
            self.assertFalse(RpmKey.is_keyid('0x1234567 '))

# Generated at 2022-06-17 05:10:25.124089
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')

# Generated at 2022-06-17 05:10:34.705156
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.execute_command(['echo', 'hello']) == ('hello\n', '')


# Generated at 2022-06-17 05:10:46.657045
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    import tempfile
    import os
    import os.path
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    # Write some content to the temporary file
    tmpfile = os.fdopen(tmpfd, "w+b")

# Generated at 2022-06-17 05:10:57.166558
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    import tempfile
    import os
    import shutil
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.rpm_key import RpmKey

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module

# Generated at 2022-06-17 05:11:08.013133
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADB33F')


# Generated at 2022-06-17 05:11:41.790282
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock object of class RpmKey
    rpm_key = RpmKey(module)

    # Test fetch_key method
    # Test case 1: key is a valid url
    key_url = 'http://apt.sw.be/RPM-GPG-KEY.dag.txt'

# Generated at 2022-06-17 05:11:53.497516
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock class
    rpm_key = RpmKey(module)

    # Create a mock key

# Generated at 2022-06-17 05:12:03.458793
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key.gpg')


# Generated at 2022-06-17 05:12:15.413227
# Unit test for method fetch_key of class RpmKey
def test_RpmKey_fetch_key():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.rpm_key.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.fetch_key
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.is_pubkey
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.execute_command
    import ansible.module_utils.rpm_key.RpmKey.RpmKey.getkey

# Generated at 2022-06-17 05:12:26.914019
# Unit test for constructor of class RpmKey
def test_RpmKey():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3

    # Create a temporary file
    tmpfd, tmpname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a temporary file
    tmpfd2, tmpname2 = tempfile.mkstemp()
    os.close(tmpfd2)

    # Create a temporary file
    tmpfd3, tmpname3 = tempfile.mkstemp()
    os.close(tmpfd3)

    # Create a temporary file
    tmpfd4, tmpname4 = tempfile.mkstemp()

# Generated at 2022-06-17 05:12:33.349253
# Unit test for method execute_command of class RpmKey
def test_RpmKey_execute_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    rpm_key = RpmKey(module)
    stdout, stderr = rpm_key.execute_command(['/bin/true'])
    assert stdout == ''
    assert stderr == ''
    try:
        rpm_key.execute_command(['/bin/false'])
        assert False
    except SystemExit:
        pass


# Generated at 2022-06-17 05:12:45.518529
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:12:56.251413
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    rpm_key = RpmKey(module)

    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('0XDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('deadb33f')
    assert rpm_key.is_key

# Generated at 2022-06-17 05:13:02.506739
# Unit test for method getkeyid of class RpmKey
def test_RpmKey_getkeyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    keyfile = rpm_key.fetch_key("http://apt.sw.be/RPM-GPG-KEY.dag.txt")
    keyid = rpm_key.getkeyid(keyfile)
    assert keyid == "0E1FAD0C"


# Generated at 2022-06-17 05:13:10.532799
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils._text
    import ansible.module_utils.rpm_key
    import ansible.module_utils.action_common_attributes
    import ansible.module_utils.action_common_attributes.ActionCommonAttributes
    import ansible.module_utils.action_common_attributes.ActionCommonAttributes.ActionCommonAttributes
    import ansible.module_utils.action_common_attributes.ActionCommonAttributes.ActionCommonAttributes.ActionCommonAttributes
    import ansible.module_utils.action_common_attributes.ActionCommonAttributes.ActionCommonAttributes.ActionCommonAttributes.ActionCommonAttributes

# Generated at 2022-06-17 05:14:18.496147
# Unit test for method is_keyid of class RpmKey
def test_RpmKey_is_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_keyid('0xDEADB33F')
    assert rpm_key.is_keyid('DEADB33F')
    assert rpm_key.is_keyid('0xDEADB33F')
    assert not rpm_key.is_keyid('DEADB33F0')
    assert not rpm_key

# Generated at 2022-06-17 05:14:29.245903
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    # Create a mock module
    mock_module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    # Create a mock class
    mock_RpmKey = RpmKey(mock_module)

    # Create a mock keyid
    mock_keyid = 'DEADB33F'

    # Create a mock execute_command
    mock_execute_command = MagicMock(return_value=('', ''))
    mock_RpmKey.execute_command = mock

# Generated at 2022-06-17 05:14:39.548628
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'

# Generated at 2022-06-17 05:14:54.752913
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid("0xDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("0XDEADB33F") == "DEADB33F"
    assert rpm_key.normalize_keyid("DEADB33F") == "DEADB33F"

# Generated at 2022-06-17 05:14:59.699900
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    class TestRpmKey(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.keyfile = os.path.join(self.tmpdir, 'key.gpg')

# Generated at 2022-06-17 05:15:10.078504
# Unit test for method drop_key of class RpmKey
def test_RpmKey_drop_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.drop_key('0xDEADB33F')
    assert rpm_key.rpm == '/bin/rpm'
    assert rpm_key.gpg == '/usr/bin/gpg2'


# Generated at 2022-06-17 05:15:16.558990
# Unit test for method is_key_imported of class RpmKey
def test_RpmKey_is_key_imported():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.is_key_imported('0xDEADBEEF') == False
    assert rpm_key.is_key_imported('DEADBEEF') == False
    assert rpm_key.is_key_imported('0xdeadbeef') == False

# Generated at 2022-06-17 05:15:26.952676
# Unit test for method getfingerprint of class RpmKey
def test_RpmKey_getfingerprint():
    import os
    import tempfile
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.rpm_key import RpmKey


# Generated at 2022-06-17 05:15:32.475956
# Unit test for method import_key of class RpmKey
def test_RpmKey_import_key():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    rpm_key.import_key('/path/to/key')


# Generated at 2022-06-17 05:15:38.102711
# Unit test for method normalize_keyid of class RpmKey
def test_RpmKey_normalize_keyid():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['absent', 'present']),
            key=dict(type='str', required=True, no_log=False),
            fingerprint=dict(type='str'),
            validate_certs=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    rpm_key = RpmKey(module)
    assert rpm_key.normalize_keyid('0xDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('0XDEADBEEF') == 'DEADBEEF'
    assert rpm_key.normalize_keyid('DEADBEEF') == 'DEADBEEF'