

# Generated at 2022-06-11 15:01:39.721165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.loader import plugin_configuration_path
    import os
    config_base_dir = os.path.dirname(plugin_configuration_path())

    # Saving initial plugin config path
    initial_plugin_dirs = C.config.plugin_dirs
    # Saving initial plugin config path
    initial_settings = C.config.settings

    # Setting configuration path to test dir
    config_path = os.path.join(config_base_dir, 'test_config_dir')
    plugin_dirs = [config_path]
    plugin_loader.add_directory(config_path)
    C.config.plugin_dirs = config_path
    C.config.settings = dict()
    C.config.load_settings_file(config_path)



# Generated at 2022-06-11 15:01:43.753997
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['DEFAULT_BECOME_USER']
    module = LookupModule()

    # TODO: Add better exception handling
    result = module.run(terms, None, plugin_type = "become", plugin_name = "sudo")

    assert(result == ['root'])

# Generated at 2022-06-11 15:01:53.331556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    my_loader = DataLoader()
    my_vars = VariableManager()
    my_inventory = Inventory(loader=my_loader, variable_manager=my_vars, host_list='localhost')

    p = PlayContext()

    def _get_global_config(config):
        return 'global setting'

    def _get_plugin_config(pname, ptype, config, variables):
        return 'plugin setting'

    class LookupModule_class(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            pass

        def get_basedir(self, variables):
            return

# Generated at 2022-06-11 15:02:02.565820
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup two dicts to test plugin_type and plugin_name parameters
    ptest_dict = {"plugin_type": "connection",
                  "plugin_name": "paramiko"}
    ptest_dict2 = {"plugin_name": "local"}

    # Unit test for plugin_type and plugin_name parameters
    module = LookupModule()
    result = module.run("ssh_args", None, **ptest_dict)
    assert result == '-C -o ControlMaster=auto -o ControlPersist=60s'
    result2 = module.run("local_tmp", None, **ptest_dict2)
    assert result2 == '$HOME/.ansible/tmp'
    result3 = module.run("var_type", None, **ptest_dict)
    assert result3[0] == 'paramiko'

    # test to

# Generated at 2022-06-11 15:02:09.206498
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:02:19.104665
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # tests for on_missing settings
    # on_missing is 'error'
    # config doesnot exist
    # should raise AnsibleLookupError with message 'Unable to find setting %s'
    try:
        lookup_module.run(terms=['UNKNOWN'], variables={}, on_missing='error')
        assert False
    except AnsibleLookupError as e:
        assert to_native(e) == 'Unable to find setting UNKNOWN'

    # on_missing is 'warn'
    # config doesnot exist
    # should return missing settings and display warning
    lookup_module.run(terms=['UNKNOWN'], variables={}, on_missing='warn')

    # on_missing is 'skip'
    # config doesnot exist
    # should skip settings

# Generated at 2022-06-11 15:02:28.492166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = [
        'DEFAULT_ROLES_PATH',
        'RETRY_FILES_SAVE_PATH',
        'COLOR_OK',
        'COLOR_CHANGED',
        'COLOR_SKIP',
        'UNKNOWN',
        ]
    variables = {
        'config_in_var': 'UNKNOWN'
        }
    missing = 'skip'
    ptype = 'connection'
    pname = 'ssh'

    l = LookupModule()
    l.set_options(
        var_options = variables,
        direct = {
            'on_missing': missing,
            'plugin_type': ptype,
            'plugin_name': pname
            }
        )
    # Exercise
    result = l.run(terms, variables)

    # Verify

# Generated at 2022-06-11 15:02:36.396223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    variables = {}
    lookup_plugin = LookupModule()

    ret = lookup_plugin.run(terms, variables)
    assert len(ret) == 4
    assert ret[0] == 'root'
    assert ret[1] == 'green'
    assert ret[2] == 'changed'
    assert ret[3] == 'blue'

    terms = ['DEFAULT_BECOME_USER', 'COLOR_OK', 'COLOR_CHANGED', 'UNKNOWN']
    lookup_plugin = LookupModule()

    found_missing = False
    ret = lookup_plugin.run(terms, variables, on_missing='error')
    assert len(ret) == 3

# Generated at 2022-06-11 15:02:44.648009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    block_type = 'default_config'
    block = [{'name': 'type', 'value': 'ssh'},
             {'name': 'remote_user', 'value': 'jdoe'},
             {'name': 'private_key_file', 'value': '~/.ssh/id_rsa'},
             {'name': 'scp_if_ssh', 'value': True},
             {'name': 'timeout', 'value': '30'}]
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(dict(variables={'block_type': block_type, 'block': block}))

# Generated at 2022-06-11 15:02:53.735694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return [
        {'term': 'COLOR_OK', 'result': 'green'},
        {'term': 'DEFAULT_BECOME_USER', 'result': 'root'},
        {'term': 'UNKNOWN_VARIABLE', 'missing': 'error', 'exception': AnsibleLookupError},
        {'term': 'BASE_LOG_PATH', 'missing': 'warn', 'result': ''},
        {'term': 'ANSIBLE_LOG_PATH', 'missing': 'skip', 'result': ''},
        {'term': 'DEFAULT_JINJA2_NATIVE', 'result': True},
        {'term': ['COLOR_OK', 'DEFAULT_BECOME_USER'], 'result': ['green', 'root']},
        {'term': [], 'result': []},
    ]


# Generated at 2022-06-11 15:03:03.373942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:03:14.742969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat import json

    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.cli import CLI
    cli = CLI()
    cli.parse()
    loader = cli.loader

    conn = connection_loader.get('local', class_only=True)
    shell = shell_loader.get('sh', class_only=True)
    global_defaults = dict(DEFAULT_REMOTE_TMP='$HOME/${PLAYBOOK_NAME}',
                           DEFAULT_ROLES_PATH='/etc/ansible/roles',
                           REMOTE_USER='default_user')


# Generated at 2022-06-11 15:03:24.251037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms, None)
    assert result[0] == 'root'
    result = lookup_module.run(terms, None, on_missing='warn')
    assert result[0] == 'root'
    result = lookup_module.run(terms, None, on_missing='skip')
    assert result[0] == 'root'
    result = lookup_module.run(terms, None, on_missing='error')
    assert result[0] == 'root'
    terms = ['UNKNOWN']
    raised = False
    try:
        result = lookup_module.run(terms, None)
    except AnsibleOptionsErr:
        raised = True
    assert raised

# Generated at 2022-06-11 15:03:24.815209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:03:32.677700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup as lookup
    import ansible.plugins.loader as plugins
    plugins.module_loader = None
    from ansible.module_utils import basic

    # create a instance of LookupModule Class
    lookup_instance = lookup.LookupModule()
    lookup_instance.set_loader(plugins.LookupModule())
    lookup_instance._display = basic.AnsibleDisplay()

    # case 1: on_missing is not a string type or on_missing not in ['error', 'warn', 'skip']
    with pytest.raises(AnsibleOptionsError, message="Invalid option : on_missing"):
        lookup_instance.run(terms = ['configured_default_become_user'], variables = {'configured_default_become_user':'root'}, on_missing = 123)

    #

# Generated at 2022-06-11 15:03:37.423614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # get the instance of the class
    lookup_class = lookup_module.__class__
    # check if class attributes are not empty
    try:
        lookup_class.__module__.__getattribute__('run')
        lookup_class.__module__.__getattribute__('run_terms')
    except AttributeError as e:
        raise e
    lookup_module.run({}, {}, {}, {})

# Generated at 2022-06-11 15:03:46.647002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    lookup = LookupModule()
    term = 'DEFAULT_VAULT_PASSWORD_FILE'
    cwd = os.getcwd()
    os.chdir(tempfile.mkdtemp())
    vault_pass_file = os.path.abspath('vault_pass.txt')
    with open(vault_pass_file, 'w') as vpf:
        vpf.write("vault_password")
    os.chdir(cwd)
    try:
        os.remove(vault_pass_file)
    except OSError as e:
        if e.errno != 2:
            raise
    pe = None
    try:
        result = lookup.run([term])
    except Exception as e:
        pe = e
    assert pe

# Generated at 2022-06-11 15:03:53.398662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create config.lookup.LookupModule object
    lookup_module = LookupModule()

    # init options
    options = {'_terms': [''], 'on_missing': '', 'plugin_name': '', 'plugin_type': ''}
    lookup_module.set_options(direct=options)
    # run method
    result = lookup_module.run(terms=[], variables=None, **options)

    assert result is None

# Generated at 2022-06-11 15:04:03.869659
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # with good data
    lm = LookupModule()
    # get second term from default DEFAULT_ROLES_PATH list
    # format of results not important as long as they match, and there
    # are the right number of them
    ret = lm.run(['DEFAULT_ROLES_PATH', 'library'])
    assert ret[0] in C.DEFAULT_ROLES_PATH and ret[1] == 'library'

    # with missing setting
    try:
        lm.run(['BOGUS_SETTING'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting BOGUS_SETTING' in to_native(e)

    # with missing setting and on_missing=skip
    lm = LookupModule(runner=None, on_missing='skip')
   

# Generated at 2022-06-11 15:04:15.292336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # test run with valid plugin_type and plugin_name
    terms = ['connection', 'remote_tmp']
    l = LookupModule()
    l._display = DummyDisplay()
    result = l.run(terms=terms, variables={'ansible_connection':'local'}, plugin_type='connection', plugin_name='local')
    assert result is not None
    # test run with valid plugin_type and plugin_name
    terms = ['connection', 'remote_tmp']
    l = LookupModule()
    l._display = DummyDisplay()
    result = l.run(terms=terms, variables={'ansible_connection':'local'}, plugin_type='connection', plugin_name='local')
    assert result is not None
    # test run with invalid plugin_type and plugin_name

# Generated at 2022-06-11 15:04:33.049019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup_module = LookupModule()
    lookup_module.set_loader(loader)
    lookup_module.set_environment(
        environment=ImmutableDict(
            environ=dict(
                HOME=b'/home/anisble',
                PATH=b'/bin:/usr/bin',
            ),
            vars=dict(
                var1=b'value1',
                var2=b'value2',
            )
        )
    )

    # unit test for correct execution
    # with one term

# Generated at 2022-06-11 15:04:44.687291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()
    #The following tests are done in order
    #1. valid_terms: test when terms are not strings
    #Expected result: exception raised
    valid_terms = ['ansible_user', 'vault_password_file', 'remote_user']
    try:
        test_module.run(terms='valid_terms',variables=None,somearg='somevalue')
    except Exception as e:
        #assert error message raised when terms is not a list
        assert(str(e) == 'invalid type in raw terms argument')
    #2. invalid_terms: test when terms are not valid config settings
    #Expected result: exception raised
    invalid_terms = ['ansible_user_test', 'vault_password_file_test', 'remote_user_test']

# Generated at 2022-06-11 15:04:52.208746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={}, direct={'plugin_name': 'auto', 'plugin_type': 'shell'})
    assert l.run(["remote_tmp"])
    l.set_options(var_options={}, direct={'plugin_name': 'ssh', 'plugin_type': 'connection'})
    assert l.run(["port"])
    l.set_options(var_options={}, direct={'plugin_name': 'ssh', 'plugin_type': 'connection'})
    assert l.run(["remote_user"])
    l.set_options(var_options={}, direct={'plugin_name': 'nonexistentplugin', 'plugin_type': 'connection'})
    assert l.run(["remote_user"])

# Generated at 2022-06-11 15:05:03.029821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # To test import of modules
    import ansible.plugins.loader as loader
    import sys
    lookup_mod = sys.modules["ansible.plugins.lookup.config"]
    loader.find_plugin = lambda a, b: None
    loader.find_role = lambda a: None
    prev_mock_vars = getattr(loader, '_SERVER_VARS', None)
    loader._SERVER_VARS = "mock_server_vars"

    # setup for global config
    global_config_term = "DEFAULT_ROLES_PATH"
    global_config_return = C.DEFAULT_ROLES_PATH
    import ansible.constants as C
    C.DEFAULT_ROLES_PATH = global_config_return
    global_config_variables = global_config_return
   

# Generated at 2022-06-11 15:05:13.422301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    term = 'DEFAULT_BECOME_USER'
    terms = [term]
    kwargs = {}
    kwargs['plugin_type']='connection'
    kwargs['plugin_name']='ssh'
    results = module.run(terms, **kwargs)
    assert results[0] == 'root'
    kwargs['on_missing']='skip'
    results = module.run(terms, **kwargs)
    assert results[0] == 'root'
    kwargs['on_missing']='warn'
    results = module.run(terms, **kwargs)
    assert results[0] == 'root'
    kwargs['on_missing']='error'
    results = module.run(terms, **kwargs)

# Generated at 2022-06-11 15:05:20.182959
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModuleTest(LookupModule):
        def __init__(self, *args, **kwargs):
            self.testing = args[0]
            super(LookupModuleTest, self).__init__(*args[1:], **kwargs)

    # case that config value is set
    config_value = u'set'
    config_term = '__TEST_CONFIG_VALUE'
    setattr(C, config_term, config_value)
    lookup_mod = LookupModuleTest(config_term)
    ret = lookup_mod.run(terms=[config_term])
    delattr(C, config_term)
    assert ret == [config_value]

    # case that config value is a callable

# Generated at 2022-06-11 15:05:28.561280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    results = LookupModule().run(terms=['DEFAULT_BECOME_USER'], variables=variable_manager)

    assert results == [C.DEFAULT_BECOME_USER]

    results = LookupModule().run(terms=['DEFAULT_ROLES_PATH'], variables=variable_manager)

    assert results == [C.DEFAULT_ROLES_PATH]

    results = LookupModule().run(terms=['UNKNOWN'], variables=variable_manager)

    assert results == []

    results = LookupModule().run(terms=['UNKNOWN'], variables=variable_manager, on_missing='warn')

    assert results

# Generated at 2022-06-11 15:05:32.383326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([u"localhost"], dict(ansible_connection=u"local", ansible_python_interpreter="/usr/bin/python"))
    assert result == [u"localhost"]

    result = lookup.run([u"localhost"], dict(ansible_connection=u"local", ansible_python_interpreter="/usr/bin/python"), on_missing="skip")
    assert result == [u"localhost"]

    result = lookup.run([u"localhost"], dict(ansible_connection=u"local", ansible_python_interpreter="/usr/bin/python"), on_missing="warn")
    assert result == [u"localhost"]


# Generated at 2022-06-11 15:05:36.358510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']

    variables = dict()

    obj = LookupModule()
    result = obj.run(terms, variables)
    assert result == ['root', 'sudo']



# Generated at 2022-06-11 15:05:36.927101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:06:03.499585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Empty list on missing key
    assert lookup.run(['UNKNOWN_KEY'], {}, on_missing='skip') == []

    # The setting DEFAULT_CACHE_PLUGIN
    assert isinstance(lookup.run(['CACHE_PLUGIN'], {}, plugin_type='cache', plugin_name='memory', on_missing='warn'))

    # Default setting for DEFAULT_MEMCACHE_SERVER is None
    assert lookup.run(['MEMCACHE_SERVER'], {}, plugin_type='cache', plugin_name='memory', on_missing='warn') == [None]

    # Error on missing key

# Generated at 2022-06-11 15:06:11.398483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert __name__ == '__main__'

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import ansible.plugins.loader as plugin_loader
    from ansible.config.manager import ConfigManager

    if PY3:
        builtin_open = 'builtins.open'
    else:
        builtin_open = '__builtin__.open'

    open_mock = plugin_loader.load_plugin('open_mock', class_only=True, add_to_sys_path=False,
                                          basedir=os.path.join(os.path.dirname(__file__), 'lookup_plugins'))


# Generated at 2022-06-11 15:06:22.334694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile

    # create a temporary config file
    with tempfile.NamedTemporaryFile() as f:
        f.write(b'[defaults]\n')
        f.write(b'host_key_checking=False\n')
        f.flush()
        C.CONFIG_FILE = f.name

        # create a mock variables
        variables = dict(foo=True, bar=False)

        # create a mock self
        self = dict()
        self['set_options'] = dict()
        self['get_option'] = dict()
        self['run_command'] = dict()

        # create a mock terms
        terms = ['host_key_checking']

        # create a mock ret
        ret = False

        # run the method
        result = LookupModule.run(self, terms, variables)

       

# Generated at 2022-06-11 15:06:27.299874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Returned value must match global value C.ANSIBLE_LIBRARY"""
    from ansible.utils import plugin_docs
    from ansible.plugins.loader import lookup_loader
    lookup_plugin = lookup_loader.get("config")
    assert(lookup_plugin.run(terms=["ANSIBLE_LIBRARY"]) == [C.ANSIBLE_LIBRARY])

# Generated at 2022-06-11 15:06:28.847304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=["foo"]) == []

# Generated at 2022-06-11 15:06:39.450859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verify that run() method accepts the terms to look up
    lookup = LookupModule()
    assert lookup.run(terms=["DEFAULT_BECOME_USER"])

    # Verify that run() method accepts the on_missing option
    lookup = LookupModule()
    assert lookup.run(terms=["DEFAULT_BECOME_USER"], on_missing="warn")

    # Verify that run() method accepts the plugin_type option
    lookup = LookupModule()
    assert lookup.run(terms=["remote_tmp"], plugin_type="shell", plugin_name="sh")

    # Verify that run() method accepts the plugin_name option
    lookup = LookupModule()
    assert lookup.run(terms=["remote_user", "port"], plugin_type="connection", plugin_name="ssh", on_missing='skip')

    # Verify that run

# Generated at 2022-06-11 15:06:49.310191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    config_settings = ['DEFAULT_DEBUG', 'DEFAULT_BECOME_ASK_PASS', 'DEFAULT_BECOME_METHOD']
    ret_settings = lookup.run(config_settings, variables=None, on_missing='error', plugin_type=None, plugin_name=None)
    assert ret_settings == [False, False, 'sudo']
    plugin_settings = ['sudo', 'ansible_become_pass', 'ansible_become_exe']
    ret_settings = lookup.run(plugin_settings, variables=None, on_missing='error', plugin_type='become', plugin_name='sudo')
    assert ret_settings == ['sudo', 'ansible_become_pass', 'ansible_become_exe']

# Generated at 2022-06-11 15:07:01.060498
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Given
    mock_module_utils = MockModuleUtils()
    mock_plugins = MockPlugins()
    constants = MockConstants()
    constants.RETRY_FILES_SAVE_PATH = '/home/retry_files_save_path'

    config_lookup = LookupModule()
    config_lookup.set_loader(mock_module_utils)
    config_lookup.set_plugins(mock_plugins)
    config_lookup.set_constants(constants)

    # When
    res = config_lookup.run(terms=['RETRY_FILES_SAVE_PATH', 'DEFAULT_ROLES_PATH'], variables=None)
    # Then
    assert constants.RETRY_FILES_SAVE_PATH in res



# Generated at 2022-06-11 15:07:07.753822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test1 of method run: call run() with None for terms
    try:
        module.run(None)
    except AnsibleOptionsError as e:
        assert str(e) == "Missing required terms, '_terms' is a required field"

    # test2 of method run: call run() with a list of terms
    try:
        module.run(["ANSIBLE_ANSIBLE_SSH_PIPELINING", "ANSIBLE_DEFAULT_HASH_BEHAVIOUR"])
    except AnsibleLookupError as e:
        assert str(e) == "Unable to get configuration value for \'ANSIBLE_DEFAULT_HASH_BEHAVIOUR\'"


# Generated at 2022-06-11 15:07:09.385940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(['plugin_type', 'plugin_name'])
    assert result == ['become', 'become']

# Generated at 2022-06-11 15:07:43.288223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test to make sure color_changed lookup runs fine
    lookup = LookupModule()
    result = lookup.run([u'COLOR_CHANGED'], variables=None, on_missing='warn', plugin_type=None, plugin_name=None)
    assert result == [u'green']

# Generated at 2022-06-11 15:07:50.615447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    C.DEFAULT_JINJA2_NATIVE = True

    terms = ['DEFAULT_PRIVATE_KEY_FILE']
    result_run = LookupModule().run(terms)
    assert result_run[0] == C.DEFAULT_PRIVATE_KEY_FILE

    terms = ['DEFAULT_BECOME_METHOD']
    result_run = LookupModule().run(terms)
    assert result_run[0] == C.DEFAULT_BECOME_METHOD

    terms = ['DEFAULT_BECOME_METHOD', 'DEFAULT_PRIVATE_KEY_FILE']
    result_run = LookupModule().run(terms)
    assert result_run[0] == C.DEFAULT_BECOME_METHOD
    assert result_run[1] == C.DEFAULT_PRIVATE_KEY_FILE

   

# Generated at 2022-06-11 15:08:00.241209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.set_options(var_options=None, direct=None)

    t1 = [
        {'config': 'DEFAULT_BECOME_USER', 'actual': 'root'},
        {'config': 'DEFAULT_ROLES_PATH', 'actual': ['/etc/ansible/roles']},
        {'config': 'RETRY_FILES_SAVE_PATH', 'actual': '/root/.ansible/retry'},
        {'config': 'COLOR', 'actual': True},
        {'config': 'UNKNOWN', 'actual': 'skip'}
    ]

    for test in t1:
        config = test['config']
        actual = test['actual']
        result = mod.run([config], variables=None)

# Generated at 2022-06-11 15:08:09.678416
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    with pytest.raises(AnsibleOptionsError) as exc:
        LookupModule().run(terms=[1,2])
    assert 'Invalid setting identifier' in str(exc.value)

    with pytest.raises(AnsibleOptionsError) as exc:
        LookupModule().run(terms=['foo'], on_missing='bad')
    assert 'must be a string and one' in str(exc.value)

    with pytest.raises(AnsibleLookupError) as exc:
        LookupModule().run(terms=['foo'], on_missing='error')
    assert 'Unable to find setting foo' in str(exc.value)

    with pytest.raises(AnsibleLookupError) as exc:
        LookupModule().run(terms=['foo'], on_missing='warn')


# Generated at 2022-06-11 15:08:19.381505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    def _get_global_config(config):
        try:
            result = getattr(C, config)
            if callable(result):
                raise AnsibleLookupError('Invalid setting "%s" attempted' % config)
        except AttributeError as e:
            raise MissingSetting(to_native(e), orig_exc=e)

        return result

    lookup_plugin = lookup_loader.get('config', class_only=True)

    assert lookup_plugin.run(['DEFAULT_BECOME_USER']) == [u'root']
    assert lookup_plugin.run(['DEFAULT_ROLES_PATH']) == [u'~/.ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-11 15:08:30.912664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()

    variables = {'inventory_dir': 'inventory'}

    try:
        missing_invalid = 'fail'
        m.run(terms='DEFAULT_BECOME_USER', variables=variables, on_missing=missing_invalid)
        assert False
    except AnsibleOptionsError:
        pass

    missing_error = 'error'
    try:
        m.run(terms='unknown_setting', variables=variables, on_missing=missing_error)
        assert False
    except AnsibleLookupError:
        pass

    missing_warn = 'warn'
    m.run(terms='unknown_setting', variables=variables, on_missing=missing_warn)

    missing_skip = 'skip'

# Generated at 2022-06-11 15:08:33.129947
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule
    module = LookupModule()
    terms = ['C.HOST_KEY_CHECKING', 'C.DEFAULT_BECOME']
    result = module.run(terms, variables=None)

    return result

# Generated at 2022-06-11 15:08:33.717065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([], {}) == []

# Generated at 2022-06-11 15:08:39.850971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_plugin_config_side_effect(_1, _2, config, _3):
        return {'DEFAULT_ROLES_PATH':['/etc/ansible/roles/','/etc/ansible/roles2/']}[config]

    l = LookupModule()

    with pytest.raises(AnsibleOptionsError):
        l.run(terms=['test'], plugin_type="connections")

    # test with plugin_name and missing plugin_type
    with pytest.raises(AnsibleOptionsError):
        l.run(terms=['test'], plugin_name="ssh")

    # test with plugin_type and missing plugin_name
    with pytest.raises(AnsibleOptionsError):
        l.run(terms=['test'], plugin_type="connections")



# Generated at 2022-06-11 15:08:48.650205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_instance = LookupModule()
        lookup_instance.run('nonexistent', {'ansible_check_mode': True})
        assert False
    except AnsibleLookupError as e:
        assert(e.message.find('Unable to find setting nonexistent') != -1)

    try:
        lookup_instance = LookupModule()
        lookup_instance.run('nonexistent', {'ansible_check_mode': True}, on_missing='error')
        assert False
    except AnsibleLookupError as e:
        assert(e.message.find('Unable to find setting nonexistent') != -1)

    lookup_instance = LookupModule()
    result = lookup_instance.run('nonexistent', {'ansible_check_mode': True}, on_missing='warn')
    assert result == []


# Generated at 2022-06-11 15:09:56.423055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel

    args = dict(
        terms=[
            'DEFAULT_BECOME_USER',
            'DEFAULT_ROLES_PATH',
            'RETRY_FILES_SAVE_PATH',
            'COLOR_OK',
            'COLOR_CHANGED',
            'COLOR_SKIP',
            'UNKNOWN',
            'port',
            'remote_tmp',
        ],
        variables={},
        direct={
            'plugin_name': 'ssh',
            'plugin_type': 'connection',
            'on_missing': 'warn',
        },
    )
    result = list()
    l = LookupModule()
    l.run([], **args)
    assert result == []

    l = LookupModule()

# Generated at 2022-06-11 15:09:59.759270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    ret_list = module.run(terms, variables={}, on_missing='error')
    assert ret_list[0] == 'root'



# Generated at 2022-06-11 15:10:10.602524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader._module_cache = {}

    # test for parameters plugin_type and plugin_name
    result = LookupModule().run(['remote_tmp'], plugin_type='shell', plugin_name='sh')[0]
    assert result == u'~/.ansible/tmp'

    # test for function
    result = LookupModule().run(['configured_module_path'])[0]
    assert isinstance(result, list)

    # test for configuration setting
    result = LookupModule().run(['DEFAULT_BECOME_USER'])[0]
    assert result == u'root'

    # test for deprecated C.DEFAULT_PRIVILEGE_ESCALATION

# Generated at 2022-06-11 15:10:21.088379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    result = lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=dict(), plugin_type=None, plugin_name=None, on_missing='error')
    assert result[0] == "roles/"
    result = lookup_module.run(terms=['plugin_type', 'plugin_name'], variables=dict(), plugin_type='shell', plugin_name='sh', on_missing='error')
    assert result[0] == 'shell' and result[1] == 'sh'
    result = lookup_module.run(terms=['plugin_type', 'plugin_name'], variables=dict(), plugin_type='shell', plugin_name='sh', on_missing='warn')
    assert result

# Generated at 2022-06-11 15:10:31.992412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    try:
        terms = ["foo", "bar", 123]
        variables = {}
        kwargs = {}
        lookup_module.run(terms, variables, **kwargs)
    except AnsibleOptionsError:
        pass

    class FakeDisplay:
        def __init__(self):
            self.called = False

        def warning(self, msg):
            self.called = True

    try:
        terms = ["foo", "bar", 123]
        variables = {}
        kwargs = {}
        lookup_module.set_loader(None)
        lookup_module.set_env(None)
        lookup_module._display = FakeDisplay()
        lookup_module.run(terms, variables, on_missing='warn', **kwargs)
    except AnsibleOptionsError:
        pass



# Generated at 2022-06-11 15:10:32.875145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "NOT IMPLEMENTED"

# Generated at 2022-06-11 15:10:37.367988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = []
    lookup_inst = LookupModule()
    result = lookup_inst.run(terms=['DEFAULT_BECOME_USER'])
    assert result == ['root'], 'Expected DEFAULT_BECOME_USER=root, got %s' % result

# Generated at 2022-06-11 15:10:46.727583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_bytes

    class TestLookup(LookupBase):
        def __init__(self, basedir=None, runner=None, variables=None, all_vars=None, **kwargs):
            self.basedir = basedir
            self.runner = runner
            self.vars = variables if variables else {}
            self.all_vars = all_vars if all_vars else {}

        def _get_basedir(self, terms):
            return self.basedir

        def run(self, terms, variables=None, **kwargs):
            self.set_options(direct=kwargs)
            based

# Generated at 2022-06-11 15:10:48.848706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = 'DEFAULT_SUDO_USER'
    result = lookup.run([term])
    assert result[0] == 'root'

# Generated at 2022-06-11 15:10:58.061479
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case with plugin_type "connection" and plugin_name "ssh"
    # Expected Result: Successful execution
    # Please note that this will raise a warning "DeprecationWarning: CONNECTION_PLUGIN_PATH is deprecated"
    test_terms = ['remote_user', 'port']
    test_plugin_type = 'connection'
    test_plugin_name = 'ssh'
    test_on_missing = 'skip'
    lookup_mod = LookupModule()
    lookup_mod.set_options(direct=dict(plugin_type=test_plugin_type, plugin_name=test_plugin_name, on_missing=test_on_missing))