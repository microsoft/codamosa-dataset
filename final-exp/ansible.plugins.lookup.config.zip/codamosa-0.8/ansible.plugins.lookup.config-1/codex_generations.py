

# Generated at 2022-06-11 15:01:36.110355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.set_options({'plugin_type': 'vars'})
    ret = mod.run(['datadog_api_key'])
    assert ret == [None]
    mod.set_options({'plugin_type': 'vars', 'plugin_name': 'datadog'})
    ret = mod.run(['datadog_api_key'])
    assert ret == [None]
    mod.set_options({'plugin_type': 'vars', 'plugin_name': 'foo'})
    try:
        ret = mod.run(['foo'])
    except AnsibleLookupError as e:
        assert 'Unable to load' in str(e)

# Generated at 2022-06-11 15:01:39.334929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    lookup_module.run(terms)

    print("test_LookupModule_run(): All test cases completed")

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:01:49.394152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests in order of arguments
    global_config_value = 'non-default-path'
    global_config_key = 'HOST_KEY_CHECKING'
    plugin_type = 'shell'
    plugin_name = 'sh'
    plugin_config_key = 'remote_tmp'
    plugin_config_value = 'non-default-directory'

    options = {
        'on_missing': 'error',
        'plugin_type': plugin_type,
        'plugin_name': plugin_name,
    }

    # Test 4: missing plugin type
    options2 = options.copy()
    del options2['plugin_type']
    try:
        LookupModule(None, terms=['a'], variables=None, **options2).run('a')
    except AnsibleLookupError:
        pass

# Generated at 2022-06-11 15:01:56.894195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mocking vars used in method run of class LookupModule
    lookup_instance = LookupModule()

    # mock results of function _get_global_config
    func1_result = 'result'
    attr1 = 'C.REMOTE_USER'
    function_name1 = '_get_global_config'
    required_arguments1 = {'config': attr1}
    def _get_global_config_side_effect(config):
        if config == required_arguments1['config']:
            return func1_result
    lookuplib._get_global_config = MagicMock()
    lookuplib._get_global_config.side_effect = _get_global_config_side_effect
    function1_results = {attr1: func1_result}

    # mock results of function get_

# Generated at 2022-06-11 15:02:06.284425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Nothing throws during the run
    assert lookup_module.run(terms=['UNKNOWN_KEY'], variables={'DEFAULT_ACTION_PLUGIN': 'test.plugins.module', 'ANSIBLE_CONFIG': '/tmp/ansible'}) == []

    assert lookup_module.run(terms=['DEFAULT_ACTION_PLUGIN'], variables={'DEFAULT_ACTION_PLUGIN': 'test.plugins.module', 'ANSIBLE_CONFIG': '/tmp/ansible'}) == ['test.plugins.module']

# Generated at 2022-06-11 15:02:10.342969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    assert plugin.run(
        terms=['aaa', 'BBB', 'ccc', 'ddd'],
        variables=None,
        on_missing="error",
        plugin_type="test",
        plugin_name="test"
    ) == []


# Generated at 2022-06-11 15:02:20.085021
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize vars used by the method
    terms = ['item_1', 'item_2']
    variables = None

    # Create the object
    test_obj = LookupModule()

    # Set the instance attributes
    test_obj.set_options(var_options=variables)

    # Call method
    test_obj._display.display = lambda msg: msg

    try:
        # Call the method
        result = test_obj.run(terms, variables=None, on_missing='error')
        assert True == False

    except AnsibleOptionsError as e:
        # Test that the exception was thrown
        assert e.msg == '"on_missing" must be a string and one of "error", "warn" or "skip", not error'

    # Set up the variables used by the method
    variables = {}

# Generated at 2022-06-11 15:02:25.930540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('LookupModule_run')
    options = {'on_missing': 'error',
               'plugin_type': 'shell',
               'plugin_name': 'sh'}
    terms = ['remote_tmp']
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, options)
    # ipdb.set_trace()
    print('result: ', result)

if __name__ == '__main__':
    # test_LookupModule_run()
    pass

# Generated at 2022-06-11 15:02:32.274600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype = 'connection'
    pname = 'local'
    config = 'remote_user'
    on_missing = 'error'
    terms = [config]
    variables=None
    kwargs={'plugin_type':ptype, 'plugin_name':pname, 'on_missing':on_missing}
    l = LookupModule()
    ret = l.run(terms, variables, **kwargs)
    assert ret == [getattr(C, 'DEFAULT_REMOTE_USER')]

# Generated at 2022-06-11 15:02:36.706145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    args = {}
    args['on_missing'] = 'error'
    args['plugin_name'] = '_'
    args['plugin_type'] = 'connection'
    lookup_module.set_options(**args)
    terms = ['remote_user', 'port']
    try:
        lookup_module.run(terms, variables=None)
    except AnsibleError as e:
        assert e.args[0] == "Unable to find setting port"


# Generated at 2022-06-11 15:03:04.245169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_option = lambda x: None
    l.get_option.__self__ = (l, {})
    setattr(l, 'get_options', l.get_option)
    setattr(l, '_display', {'warning': lambda x: None})
    assert l.run(['DEFAULT_ROLES_PATH'], {}, {}, 'error') == [C.DEFAULT_ROLES_PATH]
    assert l.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'], {}, {}, 'error') == [C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER]

# Generated at 2022-06-11 15:03:10.715943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _tm = LookupModule()
    assert _tm.run(terms=["DEFAULT_BECOME_USER"]) == [C.DEFAULT_BECOME_USER]
    assert _tm.run(terms=["DEFAULT_BECOME_USER", "DEFAULT_BECOME_FLAGS"]) == [C.DEFAULT_BECOME_USER, C.DEFAULT_BECOME_FLAGS]

# Generated at 2022-06-11 15:03:18.322720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["vault_password_file"]) == [C.DEFAULT_VAULT_PASSWORD_FILE]
    assert LookupModule().run(["vault_password_file"], plugin_type="connection", plugin_name="local") == [C.DEFAULT_VAULT_PASSWORD_FILE]
    assert LookupModule().run(["vault_password_file", "non-existent"], plugin_type="connection", plugin_name="local") == [C.DEFAULT_VAULT_PASSWORD_FILE]

# Generated at 2022-06-11 15:03:27.160139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_config = dict(
        DEFAULT_BECOME_USER='root',
        DEFAULT_ROLES_PATH='/home/stack/ansible_roles',
        RETRY_FILES_SAVE_PATH='/var/lib/awx/job_status',
        COLOR_WARNING='black',
        COLOR_SKIP='cyan',
        COLOR_ERROR='firebrick',
        REMOTE_USER='ansible',
        DEFAULT_REMOTE_TMP='/tmp/$USER/ansible/tmp',
        CORE_ERROR_REPORTING='True',
        CORE_DEBUG='True',
        core_debug='False',
    )
    pname = 'ssh'
    ptype = 'connection'

# Generated at 2022-06-11 15:03:35.987432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test on_missing = error
    # term = "BAD_CONFIG"
    try:
        lookup.run(["BAD_CONFIG"],on_missing='error')
        assert False, "AnsibleLookupError should have been raised"
    except AnsibleLookupError:
        pass
    # term = "DEFAULT_BECOME_USER"
    # on_missing is error but no error with this config
    assert lookup.run(["DEFAULT_BECOME_USER"],on_missing='error') == ['root']
    # on_missing is error but no error with this config
    assert lookup.run(["DEFAULT_BECOME_USER"],on_missing='error') == ['root']

    # test on_missing = warn
    # term = "BAD_CONFIG"


# Generated at 2022-06-11 15:03:45.085523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_ROLES_PATH'], {}, on_missing='error') == [u'roles']
    assert lookup.run(['DEFAULT_ROLES_PATH'], {}, on_missing='warn') == [u'roles']
    assert lookup.run(['DEFAULT_ROLES_PATH'], {}, on_missing='skip') == [u'roles']
    assert lookup.run(['FAKE_ROLES_PATH'], {}, on_missing='error') == []
    assert lookup.run(['FAKE_ROLES_PATH'], {}, on_missing='warn') == []
    assert lookup.run(['FAKE_ROLES_PATH'], {}, on_missing='skip') == []

# Generated at 2022-06-11 15:03:56.749016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for C.config.get_config_value in config.py
    # Test 1:
    lookup = LookupModule()
    lookup.set_options({'plugin_type': 'connection', 'plugin_name': 'ssh', 'on_missing': 'error'})
    assert lookup.run(['remote_user']) == ['root']

    # Test 2:
    lookup = LookupModule()
    lookup.set_options({'plugin_type': 'become', 'plugin_name': 'sudo', 'on_missing': 'skip'})
    assert lookup.run(['become_user']) == ['root']

    # Tests for _get_plugin_config in config.py
    # Test 1:
    lookup = LookupModule()

# Generated at 2022-06-11 15:04:03.107101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with plugin_name and plugin_type.
    result = LookupModule().run(['remote_tmp'], _plugin_name="sh", _plugin_type="shell")
    assert result == ["$HOME/.ansible/tmp"]

    # Testing without plugin_name and plugin_type.
    result = LookupModule().run(['DEFAULT_ROLES_PATH'])
    assert result == [["/usr/share/ansible/roles", "~/.ansible/roles"]]

# Generated at 2022-06-11 15:04:14.269250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import builtins

    mock_getattr = {
        'COLOR_OK': 'green',
        'COLOR_CHANGED': 'yellow',
        'COLOR_SKIP': 'blue',
        'COLOR_ERROR': 'red',
    }
    from ansible.module_utils._text import to_bytes
    class MockDisplay:
        def __init__(self):
            self.warnings = []

        def warning(self, msg):
            self.warnings.append(to_bytes(str(msg)))

    class MockVars:
        def __init__(self):
            self.data = {'UNKNOWN': 'foo'}

    def mock_global_config(config):
        return mock_getattr.get(config)

    builtins.getattr = mock_global_config

# Generated at 2022-06-11 15:04:24.024781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # assert changed
    lookup.set_loader(None)
    result = lookup.run(['A', 'DEFAULT_BECOME_USER'])
    assert result == ['a_value', 'root']
    # assert not changed
    result = lookup.run([])
    assert result == []
    # assert AttributeError
    lookup.set_loader(None)
    try:
        lookup.run(['DEFAULT_BECOME_USER', 'A'])
    except AnsibleLookupError as e:
        assert to_native(e) == 'Unable to find setting A'
    # assert AnsibleError
    lookup.set_loader(None)

# Generated at 2022-06-11 15:04:56.861076
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from distutils.version import LooseVersion

    term = 'DEFAULT_MODULE_UTILS'
    variables = dict(var1='1', var2='2')

    nm = LookupModule(None)
    nm.set_options(var_options=variables, direct=dict(on_missing='error'))
    result = nm.run(term)

    assert result == [to_native(C.DEFAULT_MODULE_UTILS)]

# Generated at 2022-06-11 15:05:07.088510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader

    # Mock plugin loader
    plugin_loader_class = plugin_loader.__class__
    original_loader_class = plugin_loader.__dict__.pop('__class__')
    original_base_path = plugin_loader.__dict__.pop('_base_path')
    original_get = plugin_loader.__dict__.pop('get')
    original_get_all = plugin_loader.__dict__.pop('get_all')
    original_all = plugin_loader.__dict__.pop('all')
    plugin_loader.__dict__['__class__'] = plugin_loader_class
    plugin_loader._base_path = 'test_base_path'

    # Mock get method of plugin loader

# Generated at 2022-06-11 15:05:08.096700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add unit test
    pass

# Generated at 2022-06-11 15:05:10.142523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    m.run("DEFAULT_VAULT_PASSWORD_FILE")

# Generated at 2022-06-11 15:05:14.820863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_ROLES_PATH', 'UNKNOWN_SETTING']
    variables = dict()
    kwargs = dict()
    assert lookup.run(terms, variables, **kwargs) == [u'/etc/ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-11 15:05:25.571230
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:05:36.660298
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _get_variables(config):
        return {
            'ansible_connection': 'ssh',
            'ansible_ssh_common_args': '',
            'ansible_ssh_common_args_ssh': ''
        }


# Generated at 2022-06-11 15:05:46.812142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.loader import LookupModule

    test_lookup = LookupModule()
    try:
        test_result = test_lookup.run(['random_term'])
    except AnsibleLookupError:
        assert True

    test_result = test_lookup.run(['DEFAULT_ROLES_PATH'])
    import os
    assert test_result == os.path.expandvars(C.DEFAULT_ROLES_PATH)
    test_result = test_lookup.run(['random_term'], on_missing='warn')
    assert not test_result

    loader = plugin_loader.connection_loader
    test_plugin = loader.get('local', class_only=True)

# Generated at 2022-06-11 15:05:51.553255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms=['LOAD_CALLBACK_PLUGINS']
    variables={}
    kwargs={}
    constants = {'LOAD_CALLBACK_PLUGINS': True}
    ret = lookup.run(terms, variables, **kwargs)
    assert ret == [True]

# Generated at 2022-06-11 15:06:02.201810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(dict(plugin_type='shell', plugin_name='sh'))
    result = lookup.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']
    result = lookup.run(['remote_tmp', 'DEFAULT_ROLES_PATH'])
    assert result == ['$HOME/.ansible/tmp', '~/roles:/usr/share/ansible/roles:/etc/ansible/roles']
    result = lookup.run(['remote_tmp', 'DEFAULT_ROLES_PATH', 'DEFAULT_REMOTE_USER'])
    assert result == ['$HOME/.ansible/tmp', '~/roles:/usr/share/ansible/roles:/etc/ansible/roles', 'root']
    result = lookup

# Generated at 2022-06-11 15:06:40.065011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin_config = LookupModule()
    result = lookup_plugin_config.run(["DEFAULT_BECOME_USER"])
    assert result == ['root'], "result '%s' is not '%s' as expected" % (result, 'root')
    result = lookup_plugin_config.run(["DEFAULT_ROLES_PATH"])

# Generated at 2022-06-11 15:06:44.612641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test various configuration options with no plugin and no missing setting
    # Note that we have to manually call get_options to initialize the options
    # dictionary
    assert LookupModule().run(['DEFAULT_MODULE_NAME']) == ['command']

# Generated at 2022-06-11 15:06:50.432412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #https://docs.pytest.org/en/latest/getting-started.html#our-first-test-run
    #https://docs.pytest.org/en/latest/example/simple.html#control-skipping-of-tests-according-to-command-line-option
    #https://docs.pytest.org/en/latest/example/simple.html#passing-parameters-to-test-functions
    '''
    lmo = LookupModule()
    terms = ["ANSIBLE_CONFIG"]
    lmo.run(terms)
    '''
    assert True

# Generated at 2022-06-11 15:06:58.648514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var = 'FOO_BAR_USER'
    test_value = 'foo'

    terms = [test_var]
    variables = {test_var: test_value}
    module_name = 'config'

    from ansible.plugins.loader import lookup_loader
    lookup_plugin = lookup_loader.get(module_name)

    result = lookup_plugin.run(terms, variables, **{'on_missing': 'error'})
    assert (result == [test_value])

# Generated at 2022-06-11 15:07:00.186042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass

# Generated at 2022-06-11 15:07:08.766745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with option 'plugin_type' and 'plugin_name'
    LUM = LookupModule()
    terms = ['remote_tmp', 'remote_user']
    options = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    LUM.set_options(var_options=None, direct=options)
    result = LUM.run(terms=terms)
    assert result[0] == '$HOME/.ansible/tmp'
    assert result[1] == 'root'


# Generated at 2022-06-11 15:07:09.354152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:07:21.100321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test default on_missing 'error' case
    ret = module.run(['DEFAULT_ROLES_PATH'])
    assert ret[0] == C.DEFAULT_ROLES_PATH

    # Test default on_missing 'skip' case
    ret = module.run(['DEFAULT_ROLES_PATH', 'UNKNOWN_SETTING'], on_missing='skip')
    assert ret[0] == C.DEFAULT_ROLES_PATH
    assert len(ret) == 1

    # Test default on_missing 'warn' case
    ret = module.run(['DEFAULT_ROLES_PATH', 'UNKNOWN_SETTING'], on_missing='warn')
    assert ret[0] == C.DEFAULT_ROLES_PATH
    assert len(ret) == 1



# Generated at 2022-06-11 15:07:28.689817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
        'RETRY_FILES_SAVE_PATH',
        'COLOR_OK',
        'COLOR_CHANGED',
        'COLOR_SKIP',
        'UNKNOWN',
        'DEFAULT_REMOTE_USER',
        'DEFAULT_REMOTE_PORT',
        'DEFAULT_REMOTE_TMP'
    ]

    # Parse global settings
    variables = {
        'inventory_dir': '',
        'playbook_dir':''
    }
    plugin_type = None
    plugin_name = None
    on_missing = 'error'

# Generated at 2022-06-11 15:07:39.136338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Case 1
    # - Test on missing 'error'
    # - Options: var_options=True, direct=True
    terms = ['UNKNOWN']
    variables = True
    kwargs = {
        'plugin_type': 'shell',
        'plugin_name': 'sh',
        'on_missing': 'error'
    }
    try:
        lm.run(terms, variables, **kwargs)
    except AnsibleOptionsError:
        pass

    # Case 2
    # - Test on missing 'warn'
    # - Options: var_options=False, direct=False
    terms = ['UNKNOWN']
    variables = False
    kwargs = {
        'on_missing': 'warn'
    }

# Generated at 2022-06-11 15:08:54.644684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader.set_basedir("/home/wul/ansible_playbook")
    lookup_module._display = DummyDisplay()
    lookup_module._templar = DummyTemplar()
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH']) == ['/home/wul/ansible_playbook/roles', '/etc/ansible/roles']
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'],on_missing='warn') == ['/home/wul/ansible_playbook/roles', '/etc/ansible/roles']

# Generated at 2022-06-11 15:09:06.515722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.six
    import ansible.module_utils.json_utils
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.text
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.file
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.connection

    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.vars import BaseVarsPlugin

    fake_lookup = LookupModule()

# Generated at 2022-06-11 15:09:18.512220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

    # test for global setting
    data = 'DEFAULT_BECOME_USER'
    result = LookupModule().run([data], {})
    assert result == [C.DEFAULT_BECOME_USER]

    # test for plugin based setting
    # while testing we are not considering the case where the plugin is not loaded
    data = 'remote_tmp'
    p_type = 'shell'
    p_name = 'sh'
    result = LookupModule().run([data], {}, plugin_name=p_name, plugin_type=p_type)
    p = shell_loader.get(p_name, class_only=True)

# Generated at 2022-06-11 15:09:26.283820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define test variables
    terms = ['DEFAULT_BECOME_USER', 'FOO', 'BAR']
    variables=None
    kwargs = {'on_missing' : 'warn', 'plugin_name': None, 'plugin_type': None}
    # Init LookupModule
    lookup_mod = LookupModule()
    # Call run method of lookup_mod with test data
    result = lookup_mod.run(terms,variables,**kwargs)
    # Assert result is list of expected values
    assert(isinstance(result,list))
    assert(result == [u'root'])

# Generated at 2022-06-11 15:09:37.440741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary configuration file
    config_file = os.path.join(tmpdir, 'ansible.cfg')
    with open(config_file, 'w') as config_file_obj:
        config_file_obj.write('[defaults]\n')
        config_file_obj.write('retry_files_save_path = %s\n' % tmpdir)
        config_file_obj.write('inventory = %s\n' % tmpdir)
        config_file_obj.write('roles_path = %s\n' % tmpdir)
        config_file_obj.write('library = %s\n' % tmpdir)
        config_

# Generated at 2022-06-11 15:09:47.371474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # test value from DEFAULT_ROLES_PATH
    result = lookup_plugin.run(['DEFAULT_ROLES_PATH'], variables={'playbook_dir': 'playbook_dir_value'})
    assert result == [['playbook_dir_value/roles', '/usr/share/ansible/roles']]
    # test value from DEFAULT_ROLES_PATH with on_missing='warn' and not setting playbook_dir
    try:
        result = lookup_plugin.run(['DEFAULT_ROLES_PATH', 'unset_value'], variables={}, on_missing='warn')
    except Exception as e:
        assert 'Unable to find setting unset_value' in str(e)
    # test value from DEFAULT_ROLES_PATH with on

# Generated at 2022-06-11 15:09:52.459528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([u'DEFAULT_MODULE_UTILS', u'DEFAULT_COLLECTIONS_PATHS'])
    assert len(result) == 2
    assert result[0] == u'$ANSIBLE_LIBRARY/module_utils'
    assert result[1] == u'$ANSIBLE_LIBRARY/collections'

# Generated at 2022-06-11 15:10:03.379295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader
    from collections import namedtuple
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    # Only a single value to lookup
    terms = ['BECOME_METHOD']
    # The magic environment variable for unit tests
    source_vars = {'ANSIBLE_CONFIG': '/etc/ansible/ansible.cfg'}
    # The magic module_utils method for unit tests

# Generated at 2022-06-11 15:10:12.793377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instance of class LookupModule
    lookup_module = LookupModule()

    # List of arguments to be used in methods
    variables = {'gather_timeout': 10}
    kwargs = {'on_missing': 'warn'}
    terms = ['DEFAULT_BECOME_USER', 'gather_timeout']
    terms_without_config = ['DEFAULT_BECOME_USER', 'gather_timeout', 'DEFAULT_ROLES_PATH']

    # Test with plugin_type and plugin_name applied
    kwargs_with_plugin = {'on_missing': 'warn', 'plugin_type': 'become', 'plugin_name': 'become_method'}

    # Test missing setting

# Generated at 2022-06-11 15:10:22.019977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\nLookupModule - run\n")
    from ansible.utils.sentinel import Sentinel
    from ansible import constants as C
    from ansible.module_utils._text import to_native
    from ansible.plugins.lookup import LookupBase
    import ansible.plugins.loader as plugin_loader
    C.ANSIBLE_CONFIG = '/etc/ansible/ansible.cfg'
    terms1 = ['DEFAULT_BECOME_USER']
    ptype1 = 'become'
    pname1 = 'sudo'
    C.ANSIBLE_CONFIG = '/etc/ansible/ansible.cfg'
    lu1 = LookupModule()
    r = lu1.run(terms1, plugin_type=ptype1, plugin_name=pname1)
    assert r is not Sentinel
