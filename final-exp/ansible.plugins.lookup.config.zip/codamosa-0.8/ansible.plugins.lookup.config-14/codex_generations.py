

# Generated at 2022-06-11 15:01:32.125686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass

# Generated at 2022-06-11 15:01:39.499192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution as distro

    config_map = {
        "test": "config",
        "test_wantlist": ["a", "b", "c"]
    }
    display = Display()
    variable_manager = VariableManager()

    lookupmodule = LookupModule()
    lookupmodule.set_loader(DataLoader())
    lookupmodule.set_basedir("")
    lookupmodule.set_display(display)
    lookupmodule.set_options(var_options=config_map, direct={})

    result = lookupmodule.run(["test"], config_map)
    assert result

# Generated at 2022-06-11 15:01:49.585848
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockedModule:
        def __init__(self, log_line):
            self.log_line = log_line

        def fail_json(self, *args, **kwargs):
            pass

        def warn(self, warning_msg):
            self.log_line(warning_msg)

    m = MockedModule(print)
    lookup = LookupModule()
    lookup.set_loader(m)

    # Testing for missing configuration value using 'on_missing' option
    # Expected error message will be 'Unable to find setting UNKNOWN'
    unknown_config_options = 'UNKNOWN'
    on_missing_options = "error"

# Generated at 2022-06-11 15:01:57.975244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Validates that LookupModule's method run returns the expected results
    """
    import os
    import sys
    import tempfile

    # This adds our test to the python system path
    # To test this plugin using 'ansible-lookup' command
    # $ ansible-lookup -M lookup_plugins config
    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

    from ansible.module_utils import basic

    # variables to be passed to LookupModule
    t = tempfile.NamedTemporaryFile()
    variables = {'ansible_config_file': t.name}

    # plugin_type and plugin_name are required together

# Generated at 2022-06-11 15:01:59.448415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    lookup_obj.run([])

# Generated at 2022-06-11 15:02:07.743624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cur_config_filepath = os.path.join(os.path.dirname(__file__), 'test_config')
    if os.path.exists(cur_config_filepath):
        os.remove(cur_config_filepath)
    # Create a config file
    file = open(cur_config_filepath, 'w')
    file.write("""
[defaults]
vault_password_file = '~/vault_password'
vault_password = '~/vault_password'
inventory = '/path-test/test_inventory'
""")
    file.close()
    os.environ['ANSIBLE_CONFIG'] = cur_config_filepath
    from ansible.plugins.loader import lookup_loader
    # Prepare for the test

# Generated at 2022-06-11 15:02:11.835778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["DEFAULT_ROLES_PATH"], {}) == [
        ["/usr/share/ansible/roles", "/etc/ansible/roles", "~/.ansible/roles", "@{playbook_dir}/roles", "@{action_plugins}/roles"],
    ]

# Generated at 2022-06-11 15:02:21.356584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()

    lookup_var_options = {'_ansible_opts': {'config': 'ansible.cfg', 'private_key_file': '/file'}, 'PLAYBOOK_DIR': '/home', 'roles_path': '/root'}
    lookup_direct = {'plugin_type': 'connection', 'plugin_name': 'netconf'}
    lookup_terms = ['remote_port', 'remote_user']

    # Test when on_missing='error' and there is a missing setting
    L.set_options(var_options=lookup_var_options, direct=lookup_direct)
    L.set_options({"on_missing": "error"})


# Generated at 2022-06-11 15:02:27.591225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is necessary to prevent future bugs when constants or plugins
    # changes.
    # TODO: use unittest2 so we can use importlib.reload
    reload(plugin_loader)
    C.config = C._ConfigLoader()

    terms = 'DEFAULT_BECOME_USER'.split()
    config_in_var = 'UNKNOWN'
    results = LookupModule().run(terms, {'config_in_var': config_in_var})
    assert results[0] == 'root'



# Generated at 2022-06-11 15:02:36.003826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Unit test to test method run of class LookupModule
    #
    import os

    # Check config options are found
    #

# Generated at 2022-06-11 15:02:54.798644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock ansible.plugins.loader.connection_loader.get
    import mock
    load = mock.MagicMock(return_value=True)
    with mock.patch.object(plugin_loader.connection_loader, 'get', load):
        ret = LookupModule.run(
            LookupModule,
            terms=['remote_port', 'remote_user'],
            variables=None,
            plugin_type='connection',
            plugin_name='ssh',
            on_missing='error'
        )
        assert ret == [22, 'root']

    # mock ansible.plugins.loader.shell_loader.get

# Generated at 2022-06-11 15:03:03.621406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Ansible options
    class Options(object):
        def __init__(self):
            self.connection = 'smart'
            self.module_path = None
            self.forks = '5'
            self.become = None
            self.become_method = None
            self.become_user = 'someuser'
            self.check = False
            self.diff = False
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.vault_password_files = None
            self.vault_ids = None

    # Supply configuration and options to the module via a mock
    class Runner(object):
        def __init__(self):
            self.options = Options()

    # Runner object
    runner = Runner()



# Generated at 2022-06-11 15:03:15.019566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule")
    look = LookupModule()

# Generated at 2022-06-11 15:03:24.918272
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit tests for method run
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.connection.ssh as ssh

    terms = ['foo', 'bar']
    # set plugin type
    plugin_loader.connection_loader.set_plugin_type('ssh', ssh.ConnectionModule)

    # test without plugin type
    lm = LookupModule()
    # test with plugin name as ssh and terms has 'foo' and 'bar'
    result = lm.run(terms, plugin_name='ssh')
    assert result == [], 'not able to find remote_user and port for the connection plugin ssh'

    # test with plugin type ansible.plugins.connection.ssh
    # and plugin name as ssh and terms has 'foo' and 'bar'

# Generated at 2022-06-11 15:03:32.757740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize
    module = LookupModule()
    # prepare mocks
    c = C()
    c.COLLECTION_PATHS = ['/opt/ansible/local-collections', '/opt/ansible/private-collections']
    c.config = None
    c.DEFAULT_ROLES_PATH = '/etc/ansible/roles'
    c.DEFAULT_BECOME_USER = 'root'
    c.RETRY_FILES_SAVE_PATH = ''
    c.COLOR_OK = 'green'
    c.COLOR_CHANGED = 'yellow'
    c.COLOR_SKIP = 'blue'
    # initialize test params
    t1 = 'DEFAULT_ROLES_PATH'
    t2 = 'DEFAULT_BECOME_USER'

# Generated at 2022-06-11 15:03:39.971432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instantiate a LookupModule object
    lookup_module = LookupModule()

    # tests for error
    try:
        lookup_module.run(terms=[1, 2, 3], variables=None, on_missing='error')
    except AnsibleOptionsError as e:
        assert "Invalid setting identifier, \"1\" is not a string, its a %s" % type(1) in str(e)

    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'ANSIBLE_ROLES_PATH'], variables=None,
                          **{'on_missing': 'error'})
    except AnsibleLookupError as e:
        assert 'Unable to find setting ANSIBLE_ROLES_PATH' in str(e)

    # tests for

# Generated at 2022-06-11 15:03:43.908007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    ret = lu.run(terms)
    assert ret == [C.DEFAULT_BECOME_USER, C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-11 15:03:50.048024
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with empty options
    assert LookupModule().run(['FOO'], {}, {}) == []

    # Test with on_missing option ['error', 'warn', 'skip']
    assert LookupModule().run(['FOO'], {}, {'on_missing': 'error'}) == []
    assert LookupModule().run(['FOO'], {}, {'on_missing': 'warn'}) == []
    assert LookupModule().run(['FOO'], {}, {'on_missing': 'skip'}) == []

    # Test with plugin_type and plugin_name
    assert LookupModule().run(['FOO'], {}, {'plugin_type': 'shell', 'plugin_name': 'sh'}) == []

    # Test with a plugin name and without plugin_type

# Generated at 2022-06-11 15:03:54.359005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    lookup_module.run(terms)
    assert lookup_module.run(terms) == [C.DEFAULT_BECOME_USER]

# Generated at 2022-06-11 15:04:04.432209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.text.converters import to_text

    # TODO:  add tests for plugin_type and plugin_name options

# Generated at 2022-06-11 15:04:26.260760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import string_types

    result = []
    terms = []
    variables = {}
    lookup_instance = LookupBase()
    lookup_module = LookupModule()

    # test missing option
    var_options = {}
    try:
        lookup_module.run(terms, var_options, **{})
        assert False  # should never get here
    except AnsibleOptionsError as e:
        assert to_native(e) == '"on_missing" is required'

    # test invalid on_missing value
    var_options = {'on_missing': 'novalidvalue'}

# Generated at 2022-06-11 15:04:32.221496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock ansible.constants.color object
    c = lambda *args, **kwargs: 'COLOR_OK'
    c.COLOR_OK = 'COLOR_OK'
    c.COLOR_CHANGED = 'COLOR_CHANGED'
    c.COLOR_SKIP = 'COLOR_SKIP'
    p = lambda *args, **kwargs: 'DEFAULT_ROLES_PATH'
    p.DEFAULT_ROLES_PATH = 'DEFAULT_ROLES_PATH'
    p.DEFAULT_BECOME_USER = 'DEFAULT_BECOME_USER'
    p.RETRY_FILES_SAVE_PATH = 'RETRY_FILES_SAVE_PATH'
    p.UNKNOWN = 'UNKNOWN'
    plugin_loader.takeover_module('ansible.constants', c)

# Generated at 2022-06-11 15:04:39.386340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_parameters = {
        '_terms': [
            'DEFAULT_BECOME_USER',
            'UNKNOWN',
            'DEFAULT_ROLES_PATH'
        ],
        'on_missing': 'error',
        'plugin_type': None,
        'plugin_name': None
    }

    result = LookupModule().run(**test_parameters)
    assert result == ['root', ['roles']]



# Generated at 2022-06-11 15:04:49.404385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    results = lm.run(terms, variables={'playbook_dir': 'pbd'})
    assert len(results) == 1
    assert isinstance(results[0], list)
    assert len(results[0]) == 1
    assert '/etc/ansible/roles' in results[0]

    results = lm.run(['INVALID_SETTING'], variables={'playbook_dir': 'pbd'})
    assert len(results) == 0

    results = lm.run(['INVALID_SETTING'], variables={'playbook_dir': 'pbd'}, on_missing='warn')
    assert len(results) == 0


# Generated at 2022-06-11 15:05:00.349299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is to make sure the run method is behaving correctly by giving a variety of
    # inputs and correctly raising exceptions if given invalid options
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types

    l = LookupModule()
    l.set_loader()
    l.set_environment()

    # basic method to test, just runs it with a given term and validates the result
    # (only testing for global settings)
    def test_run_with_term(term, expected_result, expected_exception=None):
        ret = l.run([term])
        # both need to be true or neither are
        if expected_result is not None:
            assert len(ret) == 1
       

# Generated at 2022-06-11 15:05:09.071941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    lk.set_options(var_options={}, direct={'plugin_type': '', 'plugin_name': ''})
    terms = ['DEFAULT_RETRY_FILES_ENABLED', 'DEFAULT_STDOUT_CALLBACK', 'DEFAULT_BECOME_USER']
    result = lk.run(terms, variables={}, on_missing='error')
    assert result==[True, 'default', 'root']
    lk.set_options(var_options={}, direct={'plugin_type': 'become', 'plugin_name': 'test'})
    terms = ['test_become_ask_pass', 'test_become_method']
    result = lk.run(terms, variables={}, on_missing='error')
    assert result==[False, 'sudo']
   

# Generated at 2022-06-11 15:05:20.319379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Check with wrong plugin_name, plugin_type
    try:
        lookup_module.run(terms = ['remote_user', 'port'], plugin_name='ssh')
    except AnsibleOptionsError as e:
        assert "Both plugin_type and plugin_name are required" in to_native(e)

    # Check with wrong on_missing option
    try:
        lookup_module.run(terms = ['remote_user', 'port'], plugin_name='ssh', plugin_type='connection', on_missing='fatal')
    except AnsibleOptionsError as e:
        assert "on_missing must be a string and one of error, warn or skip" in to_native(e)

    # Check with wrong config, plugin_name, plugin_type

# Generated at 2022-06-11 15:05:28.614123
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:05:35.349481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests to see if you can fetch the callback plugin config values by providing
    # plugin_type, plugin_name and key.
    lookup_module = LookupModule()
    terms = ["default", "whitelist"]
    kwargs = {
        'plugin_type':'callback',
        'plugin_name':'json',
    }
    result = lookup_module.run(terms, **kwargs)
    assert result == ['default', 'whitelist']

# Generated at 2022-06-11 15:05:45.375278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests global_config
    t = LookupModule()
    t.set_options()
    result = t.run([
        'SYSTEM_WARNINGS',
        'DEVELOPMENT',
        'ERROR_ON_UNDEFINED_VARS'
    ])
    assert isinstance(result, list)
    assert len(result) == 3
    assert result[0] == True
    assert result[1] == False
    assert result[2] == True

    # Tests plugin config

# Generated at 2022-06-11 15:06:20.436889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Purpose : Test method 'run' of class LookupModule
    """

    lookup_module = LookupModule()
    pname = "ssh"
    ptype = "connection"

    lookup_module.run(terms=[pname], variables={}, plugin_type=ptype, plugin_name=pname)
    assert True



# Generated at 2022-06-11 15:06:27.772212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import json

    DEFAULT_BECOME_USER = 'root'
    DEFAULT_ROLES_PATH = [
        '/etc/ansible/roles',
        '/usr/share/ansible/roles'
    ]

    module = AnsibleModule(
        argument_spec=dict(
            _terms = dict(type='list'),
            on_missing = dict(default='error', choices=['error', 'skip', 'warn']),
            plugin_type = dict(choices=['become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars']),
            plugin_name = dict()
        )
    )

    result1 = {}

# Generated at 2022-06-11 15:06:34.360449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule Mock object for testing
    mock_caller = LookupModule()
    # Set the below ret variable's value to the results from LookupModule.run method
    ret = mock_caller.run(terms=['PATH'], variables={'a': 'b'}, on_missing='warn')
    assert ret == ['/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin']

# Generated at 2022-06-11 15:06:46.060288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up defaults
    term_to_return = "test_value"
    missing = 'error'
    pname = None
    ptype = None
    term = "test_setting"
    terms = [term]
    config_type = list()
    plugin_type = list()
    config_type_default = list()
    terms_data_type = list()

    # set up objects for testing
    lookup_module = LookupModule()
    # mock classes
    class MockConstants():
        def __getattr__(*args, **kwargs):
            if term_to_return == "test_value":
                return term_to_return
            else:
                raise LookupError

    class MockC(object):
        constants = MockConstants()


# Generated at 2022-06-11 15:06:57.697841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module._display = None
    terms = ['remote_user', 'host_key_checking', 'timeout']
    plugin_type = 'connection'
    plugin_name = 'ssh'
    r = lookup_module.run(terms, plugin_type=plugin_type, plugin_name=plugin_name)
    assert isinstance(r, list)
    assert len(r) == 2
    assert r[0] == 'root'
    assert r[1] == 10

    terms = ['timeout']
    plugin_type = 'connection'
    plugin_name = 'local'
    r = lookup_module.run(terms, plugin_type=plugin_type, plugin_name=plugin_name)
    assert isinstance(r, list)
   

# Generated at 2022-06-11 15:07:07.505386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP', 'UNKNOWN', 'remote_user', 'port', 'remote_tmp']
    ptype = 'connection'
    pname = 'ssh'

    # Global config
    l = LookupModule()
    l.set_options(var_options=None, direct={'on_missing':'error'})
    result = l.run(terms, variables=None, **{})
    assert result == ['root', ['/etc/ansible/roles'], 'green', 'yellow', 'cyan', 'UNKNOWN', None, 22, '/tmp/.ansible']

    # Global config
    l = LookupModule()

# Generated at 2022-06-11 15:07:13.512428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l.run([])
    l.run([''])
    l.run('test')
    l.run(['test'])

    l.run([None])
    l.run(['', None, None])
    l.run('test', on_missing='error')
    l.run('test', on_missing='warn')
    l.run('test', on_missing='skip')


# Generated at 2022-06-11 15:07:24.479161
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Create object of class LookupModule
    lookup_obj = LookupModule()

    # Test the run method of LookupModule class with unknown config option
    try:
        lookup_obj.run(terms=['random_config_option'], variables=None, on_missing='error')
        assert False
    except AnsibleOptionsError as e:
        assert True
    # Test the run method of LookupModule class with unknown on_missing option
    try:
        lookup_obj.run(terms=['random_config_option'], variables=None, on_missing='random_option')
        assert False
    except AnsibleOptionsError as e:
        assert True

    # Test the run method of LookupModule class with valid config option

# Generated at 2022-06-11 15:07:27.066793
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['ANSIBLE_TEST']
    variables = {'ANSIBLE_TEST': 'test_value'}
    result = LookupModule().run(terms=terms, variables=variables, on_missing='skip')
    assert result[0] == 'test_value'

# Generated at 2022-06-11 15:07:33.513867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'on_missing': 'skip',
                                                     'plugin_type': 'xx',
                                                     'plugin_name': 'xx'})
    lookup_module.run(['DEFAULT_MODULE_NAME'], variables={}, on_missing='skip', plugin_type='xx', plugin_name='xx')

# Generated at 2022-06-11 15:08:44.660179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The default settings from Ansible
    default_settings = [
        'DEFAULT_ROLES_PATH',
        'RETRY_FILES_SAVE_PATH',
        'COLOR_OK',
        'COLOR_CHANGED',
        'COLOR_SKIP'
    ]

    lookup_module = LookupModule()

    # Calling the method run with no missing settings
    run_result = lookup_module.run(default_settings)
    assert len(run_result) == len(default_settings)

    # Calling the method run with some missing settings
    missing_settings = default_settings + ['UNKNOWN']
    run_result = lookup_module.run(missing_settings)
    assert len(run_result) == len(default_settings)

# Generated at 2022-06-11 15:08:54.328817
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleOptionsError
    from ansible.parsing.dataloader import DataLoader
    test_loader = DataLoader()
    constants_mock = {
        'DEFAULT_ROLES_PATH': ['fixtures/default_roles_path'],
        'C': constants_mock
    }

    lookup = LookupModule(basedir=test_loader.path_loader.get_basedir(), runner=None, vars=None, config=constants_mock)
    lookup._display = mock.MagicMock()

    # MissingSetting exception is not raised, lookup succeeds
    terms = ['DEFAULT_ROLES_PATH']
    on_missing = 'warn'
    variables = None
    expected_list = [constants_mock['DEFAULT_ROLES_PATH']]
   

# Generated at 2022-06-11 15:09:06.044837
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:09:18.236788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import ansible.plugins.loader as plugin_loader
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../test_utils'))
    lu = LookupModule()
    secret_path = os.path.join(os.path.dirname(__file__), '../test_utils/data_files/vault_pass')
    secret_path = os.path.normpath(secret_path)
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = secret_path
    os.environ['ANSIBLE_VAULT_PASSPHRASE'] = 'YouKnowWhatIMean'
    print(lu.run(["VAULT_PASSWORD_PATH"]))

# Generated at 2022-06-11 15:09:23.074900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters
    # ----------
    # terms : string
    # variables : string
    # kwargs: dict
    # Returns
    # -------
    # none

    # Check for required
    # None

    # Check for unexpected
    # None

    # Verify returns
    # none

    # Verify calls
    # None

    raise Exception('Test not implemented')

# Generated at 2022-06-11 15:09:30.340017
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:09:39.810878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    # 3 different type of terms, each with 2 options, on_missing error, warn, skip
    # 1) global config var
    global_config_var_terms = [C.DEFAULT_ROLES_PATH]
    global_config_var_results = [['roles']]
    # 2) global config var with an underscore in it
    global_config_var_underscore_terms = [C.JINJA2_NATIVE_UNDERSCORE_START_STRING, C.JINJA2_NATIVE_UNDERSCORE_END_STRING]
    global_config_var_underscore_results = ['{{', '}}']
    # 3) non existent global config var

# Generated at 2022-06-11 15:09:49.073079
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.set_options(direct={'on_missing' : 'error', 'plugin_type' : 'connection', 'plugin_name' : 'ssh'})
    assert lookup.run(terms=['remote_user', 'port']) == ['ubuntu', '22']
    assert lookup.run(terms=['port']) == ['22']
    lookup.set_options(direct={'on_missing' : 'error', 'plugin_type' : 'shell', 'plugin_name' : 'sh'})
    assert lookup.run(terms=['remote_tmp']) == '/tmp'
    lookup.set_options(direct={'on_missing' : 'error', 'plugin_type' : 'netconf', 'plugin_name' : 'ssh'})

# Generated at 2022-06-11 15:09:59.807971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test function for ansible.plugins.lookup.config.LookupModule.run

    This test is for the case for config lookup for global config settings
    """
    lookup_module = LookupModule()

    # Case 1: expected result
    terms = ['ANSIBLE_CONFIG', 'DEFAULT_BECOME_USER']
    result = lookup_module.run(terms=terms, variables=None)
    assert 'ansible.cfg' in result[0]
    assert result[1] == 'root'

    # Case 2: expected exception
    terms = ['unknown_config']
    try:
        result = lookup_module.run(terms=terms, variables=None)
    except AnsibleLookupError as e:
        assert 'was not defined' in str(e)



# Generated at 2022-06-11 15:10:09.306734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    results = LookupModule().run(
        [ 'DEFAULT_ROLES_PATH', 'C.DEFAULT_ROLES_PATH', 'FOOBAR', 'C.FOOBAR' ],
        variables={'playbook_dir': '/Users/ianbytchek/temp/ansible-test'})
    print('\n'.join(['[%s]' % os.path.join(playbook_dir, c)
                    for playbook_dir, role_path in zip([os.path.expanduser('~'), '/Users/ianbytchek/temp/ansible-test'], results) for c in role_path]))
