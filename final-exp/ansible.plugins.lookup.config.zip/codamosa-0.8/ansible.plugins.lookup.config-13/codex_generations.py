

# Generated at 2022-06-11 15:01:37.348691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test global config setting
    l = LookupModule()
    l.set_options(direct={'on_missing':'skip'})
    ret = l.run(["UNKNOWN"])
    assert([] == ret)

    l = LookupModule()
    l.set_options(direct={'on_missing':'warn'})
    ret = l.run(["UNKNOWN"])
    assert([] == ret)

    l = LookupModule()
    l.set_options(direct={'on_missing':'error'})
    assert_raises(AnsibleLookupError, l.run, ["UNKNOWN"])

    # test plugin config setting
    l = LookupModule()

# Generated at 2022-06-11 15:01:48.001335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['DEFAULT_BECOME_USER'], variables=dict(DEFAULT_BECOME_USER='root',
                                                                     DEFAULT_ROLES_PATH='/etc/ansible/roles')) == ['root']

    assert LookupModule().run(['DEFAULT_ROLES_PATH'], variables=dict(DEFAULT_BECOME_USER='root',
                                                                     DEFAULT_ROLES_PATH='/etc/ansible/roles')) == ['/etc/ansible/roles']

    assert LookupModule().run(['DEFAULT_ROLES_PATH'], on_missing='warn') == []
    assert LookupModule().run(['DEFAULT_ROLES_PATH'], on_missing='skip') == []


# Generated at 2022-06-11 15:01:56.052440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options=dict(), direct=dict())
    lookup.get_option = dict().get

    # 1. empty option on_missing
    lookup.run(terms=['ansible_version'], variables=dict(), direct=dict())

    # 2. option on_missing with invalid value
    try:
        lookup.get_option = dict(on_missing='invalid').get
        lookup.run(terms=['ansible_version'], variables=dict(), direct=dict())
        assert False, "should be unreachable"
    except AnsibleOptionsError as e:
        assert str(e) == '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid'

    # 3. invalid setting identifier

# Generated at 2022-06-11 15:01:58.938734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    options = {'plugin_type': 'inventory', 'plugin_name': 'host_list'}
    assert lookup_plugin.run(terms=['host_list'], variables={}, **options) == []

# Generated at 2022-06-11 15:02:02.696071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    t = LookupModule()
    terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"]
    assert t.run(terms) == [C.DEFAULT_BECOME_USER, C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-11 15:02:07.500456
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Inputs
    terms = 'DEFAULT_BECOME_USER'
    varaibles = None
    kwargs = {'on_missing': 'error'}

    # Expected
    expected = ['root']

    # Run lookup
    lookup_instance = LookupModule()
    result = lookup_instance.run(terms, variables=varaibles, **kwargs)

    # Test if expected is same as result
    assert result == expected


# Generated at 2022-06-11 15:02:17.782878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.cfg and environment variables are not used in tests
    # so to get configuration we use Base class
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.compat import mock

    loader_mock = mock.MagicMock()
    lookup_loader.get = mock.Mock(return_value=loader_mock)
    loader_mock.get_basedir.return_value = './test/test_data'
    loader_mock.get_loader.return_value = None
    functions = dir(__import__('ansible.plugins.lookup.debug'))
    loader_mock.get_module_class.return_value = functions

    # terms, variables and kwargs are needed by the run method
    terms = ['FAKE_GLOBAL_CONFIG']
   

# Generated at 2022-06-11 15:02:26.768649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO

    module_out = StringIO()


# Generated at 2022-06-11 15:02:35.620504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    invalid_preset_terms = [123, ('a', 'b', 'c'), ('a', 'b'), ('a',), {'a': 'b', 'c': 'd'}]
    invalid_preset_values = [None, 123, False, 1.1, ('a',), {'a': 'b'}, ['a']]

    #create a LookupModule object to test
    lookup = LookupModule()

    #test when variable term is a string
    terms = 'COMMAND_WARNINGS'
    assert isinstance(lookup.run(terms, None)[0], string_types)

    #test when variable term is a list of strings
    terms = ['COMMAND_WARNINGS', 'COMMAND_WARNINGS']

# Generated at 2022-06-11 15:02:43.414516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fields = "DEFAULT_BECOME_USER, PORT, shell, sh".split(", ")
    plugin_types = "become, connection, shell, shell".split(", ")
    plugin_names = "sudo, ssh, sh".split(", ")
    configs = [
        (fields[0], None, None),
        (fields[1], plugin_types[1], plugin_names[1]),
        (fields[2], plugin_types[2], plugin_types[2]),
        (fields[3], plugin_types[3], plugin_names[2])
    ]
    expected = [
        'root',
        '22',
        'sh',
        'sh'
    ]
    lookup_obj = LookupModule()

# Generated at 2022-06-11 15:03:09.726175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(terms=['LOOKUP_PLUGINS', 'CACHE_PLUGINS'],
                        plugin_type="lookup",
                        plugin_name="ini",
                        on_missing='error')

    assert(result is not None)
    assert(len(result) == 2)
    assert(isinstance(result, list))



# Generated at 2022-06-11 15:03:15.508745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH", "RETRY_FILES_SAVE_PATH"]
    variables = {}
    lookup_module.get_option = lambda x: "error"
    lookup_module._display = lambda x: ""

    lookup_module.run(terms, variables)



# Generated at 2022-06-11 15:03:18.709160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    with pytest.raises(AnsibleOptionsError):
        lookup.run(terms = [], on_missing = 'non-existing-value')


# Generated at 2022-06-11 15:03:21.057810
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False, """
        This test needs implementation. When it will be ready,
        remove this comment and remove the assert.
        """

# Generated at 2022-06-11 15:03:28.968464
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # get_option is called from run with parameters var_options, direct
    # and returns value of parameter. Using lambda for this purpose
    lookup_module.get_option = lambda param, var_options=None, direct=None: None
    lookup_module.set_options = lambda var_options=None, direct=None: None
    lookup_module.set_options = lambda var_options=None, direct=None: None
    lookup_module.run([])

# Generated at 2022-06-11 15:03:37.214952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # fake the module
    module = None

    # fake the loader
    loader = None

    # fake the templar
    templar = None

    # fake the display
    display = None

    # instanciate object
    l_obj =  LookupModule(loader=loader, templar=templar, display=display)

    # Set the options to test
    l_obj.set_options(var_options=None, direct={"plugin_type":"connection", "plugin_name":"ssh"})

    # Set the terms to test
    terms = ["remote_user","port"]

    # Launch the loop
    res = l_obj.run(terms, variables=None)

    # assert the result
    assert res == ['root', '22']

    # Return True to validate the test
    return True

# Generated at 2022-06-11 15:03:43.607723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    # AnsibleOptionsError should be raised
    terms = ['DEFAULT_MODULE_UTILS']
    kwargs = {'on_missing': 'error'}
    variables = {}
    lu = LookupModule()

    try:
        lu.run(terms, variables, **kwargs)
        raise
    except AnsibleOptionsError as e:
        assert 'Unable to find setting DEFAULT_MODULE_UTILS' in to_native(e)



# Generated at 2022-06-11 15:03:47.965833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    terms = ['DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_USER']
    lookup_plugin = LookupModule()

    # Run
    result = lookup_plugin.run(terms)

    # Assert
    assert result == ['sudo', 'root'], 'Expected values to be equal'

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-11 15:03:59.816905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_config_file = """
    [defaults]
    DEFAULT_SUDO_USER='test_sudo_user'
    DEFAULT_REMOTE_USER='test_remote_user'
    DEFAULT_REMOTE_TMP='test_remote_tmp'
    """

    import io
    import os
    import shutil
    import tempfile
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.connection.ssh as ssh_connection
    import ansible.plugins.shell.sh as sh_shell

    # create a test config directory
    test_config_dir = tempfile.mkdtemp()
    with open(os.path.join(test_config_dir, 'ansible.cfg'), 'w') as f:
        f.write(test_config_file)

    # save original config and

# Generated at 2022-06-11 15:04:06.024268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    class Struct:
        def __init__(self, **entries):
            self.__dict__.update(entries)
    options = [Struct(name="on_missing", value="error", type="str", ini=None, vars=None, default=None, aliases=[], choices=['error', 'warn', 'skip'])]
    terms = ["timeout"]
    ret = lookup_obj.run(terms, variables=None, options=options, templar=None)
    assert type(ret) is list



# Generated at 2022-06-11 15:04:23.262218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:04:30.578304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['PATH', 'TESTING']
    variables = {}
    plugin_type = ''
    plugin_name = ''
    missing = 'error'

    try:
        lookup_plugin = LookupModule()
        result = lookup_plugin.run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name, on_missing=missing)
    except (AttributeError, ImportError):
        result = []

    assert len(result) == 2
    assert len(result[0]) > 0
    assert result[1] == 'y'

# Generated at 2022-06-11 15:04:34.608225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 1
    with pytest.raises(AnsibleOptionsError) as exc:
        LookupModule().run(terms)
    assert 'Invalid setting identifier, "1" is not a string, its a' in str(exc)

# Generated at 2022-06-11 15:04:39.166177
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_obj = {
        '_terms': 'DEFAULT_ROLES_PATH'
    }
    terms = [test_obj['_terms']]

    obj = LookupModule()
    assert obj.run(terms) == [C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-11 15:04:49.294401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    terms = ["DEFAULT_ROLES_PATH"]
    ptype = "connection"
    pname = "ssh"

    success_results = [
        "./roles:roles",
        "./roles:~/.ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles",
        "./roles:/usr/local/ansible/roles"
    ]

    exception_results = [
        "Invalid setting identifier, \"%s\" is not a string, its a %s",
        "Unable to find setting %s"
    ]
    
    # Invalid setting identifier, "%s" is not a string, its a %s
    # Unable to find setting %s


# Generated at 2022-06-11 15:04:55.885630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    terms = json.loads('''["host_key_checking", "roles_path", "SUCCESSFUL_LOGIN_RESPONSE", "UNKNOWN"]''')
    print(terms)
    lookup_mod = LookupModule()
    ret = lookup_mod.run(terms, {"on_missing":"skip"})
    for item in ret:
        print(item)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:05:06.275169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])

    options = Options(connection='local', module_path='/path/to/mymodules', forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)

    loader = DataLoader()

    host = Host(name="myhost")

# Generated at 2022-06-11 15:05:15.430851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    try:
        m.run('invalid')
    except AnsibleOptionsError as e:
        assert 'not a string' in to_native(e)

    try:
        m.run(['default_sudo_user'], variables={'ansible_user': 'u'}, direct={})
    except AnsibleOptionsError as e:
        assert 'not a string' in to_native(e)

    try:
        m.run(['default_sudo_user'], variables={'ansible_user': 'u'}, direct={'on_missing': 'invalid'})
    except AnsibleOptionsError as e:
        assert 'must be a string' in to_native(e)

# Generated at 2022-06-11 15:05:25.997456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for run method of class LookupModule """

    # Evaluate run method of class LookupModule with valid parameters
    lookup_module = LookupModule()
    terms = ["DEFAULT_ROLES_PATH"]
    variables = {'ANSIBLE_ROLES_PATH': '/test/roles'}
    kwargs = {'wantlist': True}
    result = lookup_module.run(terms, variables, **kwargs)
    expected = ['/test/roles']
    assert result == expected

    # Evaluate run method of class LookupModule with invalid parameters
    lookup_module = LookupModule()
    terms = ["DEFAULT_ROLES_PATH"]
    variables = {'ANSIBLE_ROLES_PATH': '/test/roles'}
    kwargs = {'wantlist': 'False'}


# Generated at 2022-06-11 15:05:36.827795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run a simple test by instantiating a module and passing a term(s)
    # to the run method.
    # The result is compared with the expected result.
    import sys
    import ansible.plugins.loader as plugin_loader
    ansible.plugins.loader.add_directory('./lookup_plugins')
    lm = plugin_loader._lookup_fragment_loader.get("config")
    result = lm.run(terms=["DEFAULT_HOST_LIST"])
    assert(result == ["local/inventory"])
    # Test the plugin type and plugin name options with 'connection' and 'ssh' options
    # and the term 'remote_user'.
    del sys.modules[lm.__module__]

    ansible.plugins.loader.add_directory('./lookup_plugins')
    lm

# Generated at 2022-06-11 15:06:19.986900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock objects and patch ansible.plugins.loader so that
    # the real ansible.plugins.loader is not used.
    original_get = plugin_loader.get
    plugin_loader.get = lambda *args, **kwargs: 'test'

    lookup_obj = LookupModule()

    # Create mock objects and patch ansible.constants so that
    # the real ansible.constants is not used.
    original_C_config_get_config_value = C.config.get_config_value
    original_C_setattr = C.__setattr__
    original_C_getattr = C.__getattribute__
    C.__setattr__ = lambda *args, **kwargs: None
    C.__getattribute__ = lambda *args, **kwargs: 'test'
    C.config.get_config

# Generated at 2022-06-11 15:06:27.602491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #test invocation with missing options
    l = LookupModule()

    try:
        l.run(terms=["var"],
              variables={},
              on_missing='error',
              plugin_type="connection",
              plugin_name=None)
        assert False, "no error thrown for missing options"
    except AnsibleOptionsError:
        pass
    except Exception as e:
        assert False, "unexpected exception thrown: %s" % e

    # test invocation with valid options
    ret = l.run(terms=["var"],
                variables={})

    assert ret == [C.var], "expected variable not returned"

    # test invocation with invalid on_missing option

# Generated at 2022-06-11 15:06:35.770715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Global config settings
    lookup_mod = LookupModule()
    lookup_mod.set_options(direct={'plugin_type': None, 'plugin_name': None})
    assert lookup_mod.run([C.DEFAULT_ROLES_PATH])[0].split(":") == C.DEFAULT_ROLES_PATH.split(":")

    # plugin config settings
    lookup_mod.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_mod.run(['executable', 'local_tmp']) == ['sh', '/tmp']

# Generated at 2022-06-11 15:06:47.154651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import io
    from ansible.utils.display import Display
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import PY3
    try:
        from __main__ import display
    except ImportError:
        display = Display()

    config = LookupModule(loader=None, templar=None, display=display)

    # tests for _get_global_config
    global_config = {
        'ANSIBLE_DEBUG': 'true',
        'ANSIBLE_BECOME_TIMEOUT': '30',
        'ANSIBLE_PORT': '22',
        'ANSIBLE_PRIVATE_KEY_FILE': '/home/vagrant/ansible/key.pem',
        'ANSIBLE_HOST_KEY_CHECKING': 'False'
    }



# Generated at 2022-06-11 15:06:58.799638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # 1. Establish a class object for testing (record return value for test condition)
    lookup = LookupModule()

    # 2. Given class method run, when calling run to test a config, then ensure the return value is correct
    # 2.1 Given a normal config, when calling run to test, then ensure the return value is correct
    test_value = {'color': 'blue'}
    test_terms = 'user'
    assert lookup.run(test_terms)[0] == C.DEFAULT_REMOTE_USER
    test_terms = 'hash_behavior'
    assert lookup.run(test_terms)[0] == C.HASH_BEHAVIOUR

    # 2.2 Given a missing config, when calling run with on_missing as 'warn', then ensure the return value is empty and
    # a warning is logged

# Generated at 2022-06-11 15:07:06.855721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_mod = LookupModule()

    # Create dictionary for ansible variables
    variables = dict()

    # Create variable for ansible playbook
    playbook_dir = '/home/ansible/playbook'

    # Create list of variable for ansible options
    var_options = list()

    # Create variable for ansible options
    direct = dict()

    # Call method run of class LookupModule
    lookup_mod.run(terms=['DEFAULT_REMOTE_TMP'], variables=variables,
                   playbook_dir=playbook_dir, var_options=var_options, direct=direct)

# Generated at 2022-06-11 15:07:08.514608
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert len(LookupModule.run) == 5

# Generated at 2022-06-11 15:07:20.328565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = __import__('ansible.plugins.lookup.config', fromlist=['lookup_plugin'])
    terms = ['DEFAULT_REMOTE_TMP']
    kwargs = dict()
    lm = module.LookupModule()
    result = lm.run(terms=terms, variables=None, **kwargs)
    assert result == [C.DEFAULT_REMOTE_TMP]
    terms = ['DEFAULT_REMOTE_TMP', 'DEFAULT_REMOTE_TMP']
    result = lm.run(terms=terms, variables=None, **kwargs)
    assert result == [C.DEFAULT_REMOTE_TMP, C.DEFAULT_REMOTE_TMP]
    terms = ['deafult_remote_tmp']
    kwargs = dict(on_missing='skip')


# Generated at 2022-06-11 15:07:28.309294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins
    ansible.plugins.lookup_loader._load_lookup_plugins('lookup_plugins')

    lm = LookupModule()
    cm = {'DEFAULT_ROLES_PATH': ['/etc/ansible/roles', '/usr/share/ansible/roles']}
    terms = ['DEFAULT_ROLES_PATH']
    ret = lm.run(terms=terms, variables=cm)
    assert len(ret) == 1
    assert isinstance(ret[0], list)
    assert len(ret[0]) == 2
    assert len(ret[0][0]) == 18

    cm = {'DEFAULT_BECOME_USER': 'root'}
    terms = ['DEFAULT_BECOME_USER']

# Generated at 2022-06-11 15:07:38.130715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = LookupModule()
    assert config.run(["DEFAULT_BECOME_USER"], dict(), on_missing='skip') == ["root"]
    assert config.run(["DEFAULT_BECOME_USER"], dict(), on_missing='warn') == ["root"]

    try:
        config.run(["DEFAULT_BECOME_USE"], dict(), on_missing='error')
    except AnsibleOptionsError as e:
        assert "Unable to find setting DEFAULT_BECOME_USE" in str(e)

    try:
        config.run(["DEFAULT_BECOME_USER"], dict(), on_missing='error')
    except AnsibleOptionsError as e:
        assert e

# Generated at 2022-06-11 15:08:45.362995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    ret = lookup.run(terms, variables=None)
    assert ret == [C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-11 15:08:55.099277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    class MockLoader:
        @staticmethod
        def get(*args, **kwargs):
            return to_bytes(Mock())

    variables = {'vault_password': AnsibleVaultEncryptedUnicode(u'vault')}
    l = LookupModule()

    l.set_loader = Mock(return_value=MockLoader())

    # Test with invalid on_missing option
    l._display = Mock()
    l.run([], variables=variables, on_missing='junk')

# Generated at 2022-06-11 15:09:06.969640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for run method

    import mock
    import os
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', 'lib'))
    import ansible.plugins.loader as plugin_loader

    from ansible.errors import AnsibleError, AnsibleLookupError, AnsibleOptionsError
    from ansible.module_utils._text import to_native
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel

    from ansible.module_utils._text import to_bytes, to_native

    lookup_plugin = plugin_loader.lookup_loader.get('config', class_only=True)
    lookup_instance = lookup_plugin()

# Generated at 2022-06-11 15:09:18.902835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils._text import to_text
    class Params(object):
        def __init__(self, args=None, **kwargs):
            self.args = args or {}
            self.kwargs = kwargs
    assert LookupModule.run(Params(terms=['a'], variables={'b': 1}), on_missing='error') == ['a']
    assert LookupModule.run(Params(terms=['a']), on_missing='error') == ['a']

# Generated at 2022-06-11 15:09:20.548154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(LookupModule(), ['DEFAULT_BECOME_USER'], variables=None, **dict())

# Generated at 2022-06-11 15:09:31.672379
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test using class mock created by mock.patch and ProcessRelease
    import mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import shlex_quote

    class MockLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            self._display = mock.Mock()
            self._display.warning = mock.Mock()
            super(MockLookupModule, self).__init__(**kwargs)


# Generated at 2022-06-11 15:09:40.449375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.loader import callback_loader
    if not PY3:
        from ansible.utils import plugin_docs
        plugin_docs.register_lookup_plugin_docs()

    # Load dummy lookup module class
    dummy1 = AnsibleLoader('', '', True).load_from_file('../plugins/lookup/dummy1.py')

    # Load dummy callback module class
    dummy_callback = AnsibleLoader('', '', True).load_from_file('../lib/ansible/plugins/callback/dummy.py')
    dummy_callback_class = callback_loader._get_all_plugin_loaders().get(dummy_callback.__name__)
    dummy_

# Generated at 2022-06-11 15:09:45.200640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    import os
    terms = ['DEFAULT_ROLES_PATH']
    result = lookup.run(terms, variables={'---':os.path.sep}, wantlist=True)
    
    assert result == [['---/roles', '---/../roles']]
    

# Generated at 2022-06-11 15:09:45.614871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

# Generated at 2022-06-11 15:09:56.148613
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Creating a mock class to simulate constants
    class MockClass:
        @property
        def ANSIBLE_NOCOLOR(self):
            return True

    mockObj = MockClass()
    mockObj.DEFAULT_ROLES_PATH = ['/bar/foo']

    # Creating a mock class to simulate C
    class MockConfigClass:
        @property
        def config(self):
            return mockObj

    mockC = MockConfigClass()
    # Creating a mock class to simulate AnsibleModule
    class MockAnsibleModule:
        @staticmethod
        def fail_json(*args, **kwargs):
            return {'failed': True, 'msg': kwargs}

    mockAM = MockAnsibleModule()

    # Creating a mock class to simulate LookupBase