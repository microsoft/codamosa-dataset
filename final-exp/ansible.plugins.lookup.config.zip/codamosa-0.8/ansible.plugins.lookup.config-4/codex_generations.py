

# Generated at 2022-06-11 15:01:38.845155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_config = LookupModule()
    assert lookup_config.run([], variables=None, **{}) == []
    assert lookup_config.run([], variables=None, **{'on_missing': 'error'}) == []
    assert lookup_config.run([], variables=None, **{'on_missing': 'warn'}) == []
    assert lookup_config.run([], variables=None, **{'on_missing': 'skip'}) == []
    assert lookup_config.run(['DEFAULT_ROLES_PATH'], variables=None, **{}) == []
    assert lookup_config.run(['DEFAULT_ROLES_PATH'], variables=None, **{'on_missing': 'error'}) == []

# Generated at 2022-06-11 15:01:49.028206
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # ----------------------------------------------------------------------------------------------
    # test case 1: return configuration value for the global config setting
    # ----------------------------------------------------------------------------------------------
    tems = ['DEFAULT_ASYNC_POLL_INTERVAL']
    lkp = LookupModule()
    result = lkp.run(tems, variables=None)
    assert result[0] == 10

    # ----------------------------------------------------------------------------------------------
    # test case 2: return configuration value for the given plugin
    # ----------------------------------------------------------------------------------------------
    tems = ['remote_tmp']
    variables = {'ansible_connection': 'local'}
    lkp = LookupModule()
    result = lkp.run(tems, variables=variables, plugin_type='shell', plugin_name='sh')
    assert result[0] == '$HOME/.ansible/tmp'

    # ----------------------------------------------------------------------------------------------
    # test case

# Generated at 2022-06-11 15:01:49.914190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([]) == []

# Generated at 2022-06-11 15:01:57.107809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeLoader(object):
        def get(self, pname, class_only=True):
            return pname

    class FakeConfig(object):
        def get_config_value(self, config, plugin_type=None, plugin_name=None, variables=None):
            return 'test'

    def fake_sentinel():
        return Sentinel

    class FakeDisplay(object):
        def warning(self, msg):
            return

    class FakeVarsModule(object):
        def __init__(self):
            self.vars = dict()

        def set_options(self, var_options=None, direct=None):
            self.vars['var_options'] = var_options
            self.vars['direct'] = direct

    plugin_loader.cache_loader = FakeLoader()

# Generated at 2022-06-11 15:02:06.430677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from test.unit.unit.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variables = VariableManager(loader=loader, inventory=inventory)

    # test 'all' plugin config settings
    lm = LookupModule()
    lm.set_loader(DictDataLoader({}))
    lm.set_options(var_options=variables)
    result = lm.run(terms=["DEFAULT_CACHE_PLUGIN"], variables=variables)[0]
    assert result == 'memory'

    # test 'all' plugin config settings
   

# Generated at 2022-06-11 15:02:10.523404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock variables
    terms = ['DEFAULT_BECOME_USER']
    variables = {}

    # Create module instance and run method run
    lookup_mod = LookupModule()
    rc = lookup_mod.run(terms, variables=variables, direct=None)

    assert rc[0] == 'root'

# Generated at 2022-06-11 15:02:20.236242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 15:02:29.749166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import json
    from units.mock.loader import DictDataLoader

    lookup = LookupModule()
    try:
        lookup.run(['config', 'project_path'], dict())
    except AnsibleOptionsError as e:
        assert 'Invalid setting identifier' in str(e)

    try:
        lookup.run(['config', 'project_path'], dict(), on_missing='invalid_on_missing')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error",' in str(e)


# Generated at 2022-06-11 15:02:37.007600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    terms = ['remote_user', 'port']
    plugin_type = 'connection'
    plugin_name = 'ssh'
    kwargs = {'plugin_name': plugin_name, 'plugin_type': plugin_type}
    result = lookup_module.run(terms, **kwargs)
    assert result == [u'ansible_user', u'22']

    # Test with default plugin_type and plugin_name
    lookup_module = LookupModule()
    terms = ['remote_user', 'port']
    result = lookup_module.run(terms)
    assert result == [u'ansible_user', u'22']

    # Test with wrong on_missing param
    lookup_module = LookupModule()

# Generated at 2022-06-11 15:02:37.474643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:02:56.498047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = None
    i = None
    try:
        i = LookupModule()
        result = i.run([], [{'_ansible_no_log': True}])
        assert result is not None
    except AnsibleOptionsError as e:
        assert 'invalid option key' in str(e)
    except AnsibleError as e:
        print('\nCalled with:')
        print('\n{}'.format(i.run(terms=["foo"], variables=[{'_ansible_no_log': True}])))
        print('\nShould be:')
        print('\n[\'foo\']\n')
        assert False

    assert len(result) == 0


# Generated at 2022-06-11 15:03:02.185196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check if method run of class LookupModule works correctly"""
    from ansible.plugins.lookup.config import _get_plugin_config
    from ansible.plugins.loader import connection_loader

    conn_res = _get_plugin_config("ssh", "connection", "port", {})
    assert conn_res == 22

    con = connection_loader.get("ssh", class_only=True)
    _get_plugin_config(con._load_name, "connection", "port", {})

# Generated at 2022-06-11 15:03:13.613688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for invalid value of missing
    result = None
    try:
        result = LookupModule().run(terms=['a'], on_missing='invalid')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)

    # Test for invalid value of plugin_type
    result = None

# Generated at 2022-06-11 15:03:22.895219
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:03:32.541094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible import context
    from ansible.plugins.loader import lookup_loader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from io import StringIO

    playbook_path = 'test_playbook.yml'
    host_list = 'test_inventory.yml'

    display = context.CLIARGS['module_vars'].get('_display', None)

    host_file = StringIO()
    host_file.write(u"[localhost]\nlocalhost\n")
    host

# Generated at 2022-06-11 15:03:39.832684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock C.RETRY_FILES_SAVE_PATH
    C.RETRY_FILES_SAVE_PATH = "test_data"
    # Mock C.DEFAULT_BECOME_USER
    C.DEFAULT_BECOME_USER = "test_data"
    # Mock C.DEFAULT_ROLES_PATH
    C.DEFAULT_ROLES_PATH = "test_data"
    # Mock C.COLOR_OK
    C.COLOR_OK = "test_data"
    # Mock C.COLOR_CHANGED
    C.COLOR_CHANGED = "test_data"
    # Mock C.COLOR_SKIP
    C.COLOR_SKIP = "test_data"

    # Test for valid parameters

# Generated at 2022-06-11 15:03:48.162608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os.path
    sys.path.append(os.path.abspath('.'))
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # import config module to register the config callback
    from ansible.config.manager import ConfigManager
    loader = DataLoader()
    configmgr = ConfigManager(loader=loader)
    configmgr.load_plugins()

    # Create the inventory, use path to host config file as source or hosts in a comma

# Generated at 2022-06-11 15:03:59.851141
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"]
    variables = None
    kwargs = {}
    lookup = LookupModule()
    result = lookup.run(terms, variables, **kwargs)
    print(result)

    # Test 2
    terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"]
    variables = {
        'ansible_connection': 'local',
        'ansible_python_interpreter': '/usr/bin/python',
        'DEFAULT_BECOME_USER': 'root',
        'DEFAULT_ROLES_PATH': ['/etc/ansible/roles'],
        'DEFAULT_UNDEFINED': 'undefined_value'
    }

# Generated at 2022-06-11 15:04:08.458058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameter = {}
    parameter['_terms'] = ["DEFAULT_BECOME_USER"]
    parameter['wantlist'] = True
    parameter['variables'] = {}
    parameter['on_missing'] = "error"

    class MockVarManager(object):
        """Docker doesn't have a native python interpreter, so MockVarManager isn't importable.
        Hack this in here to please pylint."""
        def get_vars(self, loader, path, entities, cache=True):
            return dict()

    class MockLoader(object):
        def __init__(self):
            self.var_manager = MockVarManager()

        def get_basedir(self, host):
            return "/root"

        def path_dwim_relative(self, basedir, given, prefix, localedir):
            return given

    loader

# Generated at 2022-06-11 15:04:12.828714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_global_config(config):
        return getattr(C, config)

    def _get_plugin_config(pname, ptype, config, variables):
        loader = getattr(plugin_loader, '%s_loader' % ptype)
        p = loader.get(pname, class_only=True)
        if p is None:
            raise AnsibleLookupError('Unable to load %s plugin "%s"' % (ptype, pname))
        result = C.config.get_config_value(config, plugin_type=ptype, plugin_name=p._load_name, variables=variables)
        return result

    def _get_config(config, variables):
        result = Sentinel

# Generated at 2022-06-11 15:04:32.175963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: This is not a true unit test. It must be run by hand to observe output.
    # NOTE: Currently, this is mostly a copy and paste of the config.yml test.

    import os
    loader = os.path.join(os.path.dirname(__file__), '..', '..', 'loader.py')
    basedir = os.path.join(os.path.dirname(__file__), '..', '..', 'lookup_plugins')
    print("To use this, run `PYTHONPATH=%s ANSIBLE_CONFIG=%s/../../test/integration/config/ansible.cfg python %s config`" % (
        basedir, os.path.dirname(__file__), loader))

# Generated at 2022-06-11 15:04:44.083104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockDisplay:
        def __init__(self, *args, **kwargs):
            return

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            return

        def warning(self, msg):
            return

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variables = VariableManager(loader=loader, inventory=inventory)
    variables.extra_vars = {'my_var': 'pwd'}
    display = MockDisplay(verbosity=3)
    lookup_plugin = LookupModule()
    lookup_plugin.set_

# Generated at 2022-06-11 15:04:55.003028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.cfg set up to define following values in class constants module
    # [defaults]
    # DEFAULT_BECOME_USER = test_default_become_user
    # DEFAULT_ROLES_PATH = test_default_roles_path

    # Ansible has a few plugins loaded and available,
    # with ssh being available
    # and setting that defines port = 22

    lu = LookupModule()

    # test_default_become_user = "test_default_become_user"
    # test_default_roles_path = "test_default_roles_path"

# Generated at 2022-06-11 15:05:01.081359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import runpy
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    roles_path = os.getenv("ANSIBLE_ROLES_PATH")
    if not roles_path:
        raise AssertionError("ANSIBLE_ROLES_PATH not set")

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'default_tmp': '/tmp'}
    inventory = InventoryManager(loader=loader)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 15:05:09.337498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        plugin = LookupModule()
        plugin.run([], None)
        raise AssertionError('LookupModule.run did not fail as expected')
    except AnsibleOptionsError as e:
        assert 'did not receive any valid setting identifiers' in to_native(e)

    try:
        plugin = LookupModule()
        plugin.run(['is_valid_setting', 'ANOTHER_VALID_SETTING'], None)
        raise AssertionError('LookupModule.run did not fail as expected')
    except AnsibleOptionsError as e:
        assert 'invalid setting identifier, "is_valid_setting" is not a string' in to_native(e)

    plugin = LookupModule()

# Generated at 2022-06-11 15:05:14.485408
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    # Test result when config is missing
    result = lookup.run('UNKNOWN', on_missing='error')
    assert result == [], 'The result should be empty '
    result = lookup.run('UNKNOWN', on_missing='skip')
    assert result == [], 'The result should be empty '
    result = lookup.run('UNKNOWN', on_missing='warn')
    assert result == [], 'The result should be empty '
    # Test result when config is not missing
    result = lookup.run('DEFAULT_ROLES_PATH')
    assert isinstance(result, list), 'The result should be a list'
    assert isinstance(result[0], string_types), 'The result should be a string'

# Generated at 2022-06-11 15:05:21.061219
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup vars
    lookup = LookupModule()
    lookup.variables = dict()

    # setup mocks
    sentinel = Sentinel()
    sentinel.error = 'error'
    sentinel.warn = 'warn'
    sentinel.skip = 'skip'
    sentinel.VALUE = 'VALUE'
    sentinel.DEFAULT_ROLES_PATH = ['/etc/ansible/roles', '~/.ansible/roles']
    sentinel.PLUGIN_NAME = 'netconf'
    sentinel.PLUGIN_TYPE = 'connection'

    lookup.set_options(var_options=dict(), direct=dict())
    assert lookup._templar is not None

    # test that var_options and direct are set by expected values

# Generated at 2022-06-11 15:05:22.354131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-11 15:05:26.781337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={})
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    ret = lookup.run(terms, wantlist=True)
    assert len(ret) == len(terms)

# Generated at 2022-06-11 15:05:37.504517
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:06:16.237391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import PY2
    pytest.importorskip("yaml")
    if not PY2:
        pytest.skip("test only runs on python 2")

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    lookup = LookupModule()
    lookup._display = Display()  # because lookups are not run with the CLI
    lookup.set_options(var_options={'ANSIBLE_CONFIG': 'test/integration/ansible.cfg'}, direct={})

    # check config that does exist WITHOUT a plugin type
    result = lookup.run(['DEFAULT_BECOME_USER'])
    assert result[0] == AnsibleUnsafeText("root")

    # check config that does not exist WITHOUT a plugin type

# Generated at 2022-06-11 15:06:20.598397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()  # noqa
    terms = ['DEFAULT_BECOME_USER']
    variables = dict()

    result = lm.run(terms, variables=variables, **{})
    assert isinstance(result, list)


# Generated at 2022-06-11 15:06:21.226825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:06:25.411841
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # instantiating an empty class
    lookup_module = LookupModule()

    # calling the run method
    result = lookup_module.run(['DEFAULT_BECOME_USER'])

    # asserting the result
    assert result == [u'root']



# Generated at 2022-06-11 15:06:35.823158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    import pytest
    from units.mock.loader import DictDataLoader

    # Case 1: Check if everything works as expected when config options are provided
    #         in the order as stated in the documentation
    # Arrange
    lookup = LookupModule()
    lookup.set_loader(DictDataLoader({}))
    lookup._display = pytest.Mock()

    # Act
    result = lookup.run(terms=['TERM_1', 'TERM_2'], variables={'var_1': 'val_1', 'var_2': 'val_2'})

    # Assert
    assert type(result) == list
    assert len(result) == 2

    # Case 2: Check if everything works as expected when config options are provided
    #         in

# Generated at 2022-06-11 15:06:37.727119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run()
    print(result)
    assert not result


# Generated at 2022-06-11 15:06:48.526953
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_resp = LookupModule._get_plugin_config
    _get_plugin_config.restype = 'fake_get_plugin_config_return'

    class fake_config():

        def get_config_value(self, config, plugin_type=None, plugin_name=None, variables=None):
            return lookup_resp(config, plugin_type, plugin_name, variables)

    class fake_constants():
        config = fake_config()

    class fake_vars():
        pass

    class fake_options():
        var_options = fake_vars()
        direct = dict(on_missing='warn')

    class fake_loader():

        def get(self, pname, class_only=True):
            pass

    class fake_sentinel:
        pass

    sentinel = fake_sentinel()
    sent

# Generated at 2022-06-11 15:07:00.599750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # needed some variables, and since they would be picked up by the high level tests, they were needed as
    # temporary variables
    #
    ansible_vars_str = '''
        {
            "ansible_become_user": "user",
            "ansible_become_password": "pass",
            "ansible_become_method": "sudo",
            "ansible_become": true,
            "ansible_become_exe": "sudo",
            "ansible_become_flags": "-H"
        }
    '''
    ansible_vars = json.loads(ansible_vars_str)
    #
    # create the class object
    #
    lookup_mod_run = LookupModule()

# Generated at 2022-06-11 15:07:09.005720
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms = ['ansible_python_interpreter', 'ansible_port']
    variables = {}

    # Testing configuration setting ansible_python_interpreter
    try:
        result = module.run(terms, variables, on_missing="error")
        assert result[0] == C.DEFAULT_BECOME_ASK_PASS
    except AnsibleError as e:
        assert False, "Test failed: %s" % to_native(e)

    # Testing invalid configuration setting:
    try:
        result = module.run(['invalid_configuration_setting'], variables, on_missing="error")
        assert False, 'AnsibleError not raised'
    except AnsibleError:
        pass

    # Testing configuration setting ansible_port

# Generated at 2022-06-11 15:07:11.983033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['ERROR_ON_UNDEFINED_VARS']) == [True]

# Generated at 2022-06-11 15:08:10.428236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    # TODO

# Generated at 2022-06-11 15:08:17.101142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = LookupModule()
    config._display = DummyDisplay()
    config.set_options(var_options={"foo": "bar"}, direct={"on_missing": "error"})
    try:
        config.run(["foo"])
    except AnsibleLookupError as e:
        correct_msg = "Unable to find setting foo"
        assert correct_msg in to_native(e), "Wrong error message"
    else:
        raise Exception("Test failed, should raise AnsibleLookupError")


# Generated at 2022-06-11 15:08:27.903580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name not set for global configs
    lookup = LookupModule()
    terms = ['DEFAULT_SUDO_EXE', 'NON_EXISTENT']
    results = lookup.run(terms)
    assert results[0] == '/bin/sudo'
    assert results[1] == None

    # Test when on_missing is set to skip
    lookup = LookupModule()
    terms = ['DEFAULT_SUDO_EXE', 'NON_EXISTENT']
    results = lookup.run(terms, on_missing='skip')
    assert results[0] == '/bin/sudo'
    assert results[1] == None

    # Test when on_missing is set to warn
    lookup = LookupModule()

# Generated at 2022-06-11 15:08:36.682630
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test method run of class LookupModule in case when on_missing is error
    class Mock_C():
        class_attribute = 'class attribute'

        def class_method(self):
            return 'class method'

    constants = Mock_C()

    class Mock_display_warning():
        def __init__(self):
            self.warning_list = []

        def warning(self, msg):
            self.warning_list.append(msg)

    class Mock_VariableManager(object):
        def get_vars(self, loader, path=None, entities=None, cache=True, fail_on_undefined=True, include_priorities=None):
            return {'variable': 'manager'}


# Generated at 2022-06-11 15:08:44.576927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    assert t.run([]) == []
    assert t.run(terms=None) == []
    assert t.run(terms=None, variables="var1") == []
    assert t.run(terms="") == []
    assert t.run(terms=[]) == []
    assert isinstance(t.run(terms=[""]), list)
    assert isinstance(t.run(terms=[None]), list)
    assert isinstance(t.run(terms=[1]), list)

# Generated at 2022-06-11 15:08:54.209344
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = {
        'enable_plugins': True,
        'enable_plugins_path': {
            'ssh': True
        },
        'enable_plugins_deprecated': True,
        'become_method': 'sudo',
        'become_user': 'test',
        'become_method_user': 'test2',
        'become_method_flags': '-test3'
    }
    config = LookupModule.run(terms, variables)
    # Check if the result is a list
    assert isinstance(config, list)
    # Check if the result is the list of all config values
    assert config == ['root', '/etc/ansible/roles:/usr/share/ansible/roles']




# Generated at 2022-06-11 15:09:05.957668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER','DEFAULT_ROLES_PATH','RETRY_FILES_SAVE_PATH','COLOR_OK','COLOR_CHANGED','COLOR_SKIP','UNKNOWN']
    variables = None
    result = lookup_module.run(terms, variables, on_missing='skip')
    assert result is not None
    terms = ['test']
    try:
        result = lookup_module.run(terms, variables, on_missing='test')
    except AnsibleOptionsError:
        assert True
    try:
        result = lookup_module.run(terms, variables)
    except AnsibleLookupError:
        assert True

# Generated at 2022-06-11 15:09:18.157688
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # initialization
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup.config as plugin_lookup_config
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup.file as plugin_lookup_file
    import ansible.plugins.lookup.vars as plugin_lookup_vars
    plugin_loader.add_directory('./ansible/plugins/lookup')
    plugin_loader.add_directory('./ansible/plugins/vars')

    lu = LookupModule()

    terms = ['inventory_basedirs', 'ssh_executable']
    result = lu.run(terms)
    # test for inventory base directories
    assert result[0] == ['/etc/ansible/hosts']
    # test for ssh executable
   

# Generated at 2022-06-11 15:09:20.547501
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # get_option
    # set_options
    # set_env
    # display
    # warning

    # ptype = 'connection'
    # pname = 'local'
    pass

# Generated at 2022-06-11 15:09:25.673481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = C.DEFAULT_ROLES_PATH
    result = lookup_module.run(terms, dict())
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], string_types)
    assert result[0] == C.DEFAULT_ROLES_PATH
