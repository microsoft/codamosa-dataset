

# Generated at 2022-06-11 15:01:32.168316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'on_missing': 'error', 'plugin_type': None, 'plugin_name': None})
    ret = lookup_module.run(['DEFAULT_ROLES_PATH', 'UNKNOWN'])
    assert ret == [C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-11 15:01:36.010747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    PLUGIN_TYPE = 'inventory'
    PLUGIN_NAME = 'ini'
    SETTINGS = [
        'enable_plugins',
        'INVENTORY_ENABLED',
        'INVENTORY_UNPARSED_FAILED',
    ]
    assert LookupModule.run(['settings'], PLUGIN_TYPE, PLUGIN_NAME) == SETTINGS

# Generated at 2022-06-11 15:01:42.076300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize the plugin class
    l = LookupModule()

    ### start test set-1 of method run
    print('\n=== start test set-1 of method run')
    print('testing run method with invalid option')
    # initialize the variable to contain options
    opt = {'on_missing': 'blah'}
    try:
        # get the config values
        result = l.run(terms=['DEFAULT_BECOME_USER'], options=opt)
    except AnsibleOptionsError as e:
        print('failed as expected')
        print('message: {0}'.format(to_native(e)))

    print('testing run method with valid option')
    # initialize the variable to contain options
    opt = {'on_missing': 'warn'}
    # get the config values

# Generated at 2022-06-11 15:01:42.963274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add python unit tests
    pass

# Generated at 2022-06-11 15:01:52.626584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests cases with below conditions
    # 1. term is not a string
    # 2. on_missing is not a string
    # 3. on_missing is not in the list ['error', 'warn', 'skip']
    # 4. plugin_type and plugin_name are not provided
    # 5. plugin_type and plugin_name are provided
    # 6. term is present in config

    from ansible import constants as C
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.vars import VariableManager
    from ansible.template import Templar

    var_manager = VariableManager()
    var_manager.set_inventory(vars_loader.get("host_list", class_only=True))
   

# Generated at 2022-06-11 15:02:01.911365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import json
    import pytest

    # TODO: create separate test cases
    # NOTE: Each case is identified with '# Test Case #'
    @pytest.fixture
    def LookupModule_fixture(monkeypatch, tmpdir):
        monkeypatch.setattr(os, 'getcwd', lambda: str(tmpdir))
        monkeypatch.setattr(sys, 'argv', ['ansible-config', 'list'])

        dummy_plugins = {}
        dummy_plugins['connection'] = ['local', 'chroot', 'docker', 'lxc', 'lxd', 'paramiko', 'winrm', 'ssh']
        dummy_plugins['shell'] = ['powershell']
        dummy_plugins['strategy'] = ['linear', 'free']

# Generated at 2022-06-11 15:02:08.879977
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Options(object):
        var_options = None
    class Term(object):
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return self.name
    class Variables(object):
        def __init__(self, hostvars):
            self.vars = hostvars
        def get(self, key):
            return self.vars[key]

    class PlayContext(object):
        def __init__(self):
            pass

    pc = PlayContext()
    pc.settings = Options()

    lb = LookupModule()
    lb.set_play_context(pc)

    terms = []
    terms.append(Term('DEFAULT_ROLES_PATH'))
    terms.append(Term('UNKNOWN_OPTION'))
    terms

# Generated at 2022-06-11 15:02:18.862765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup.config as config
    import ansible.plugins.lookup.file as file
    import ansible.plugins.lookup.env as env
    import ansible.plugins.lookup.password as password
    import tempfile
    import types

    # save the original values

# Generated at 2022-06-11 15:02:28.209991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global LookupModule
    # Instantiate the object with set configuration
    lookup = LookupModule()

    lookup._display = DummyDisplay()

    # Test missing global config
    terms = ['UNKNOWN_CONFIG']
    result = lookup.run(terms=terms, on_missing='skip')
    for term in terms:
        assert term not in result

    # Test non-existent global config
    terms = ['UNKNOWN_CONFIG', 'DEFAULT_SUBSET']
    lookup.run(terms=terms, on_missing='error')

    # Test non-existent plugin config
    terms = ['host_key_auto_add', 'host_key_checking']
    lookup.run(terms=terms, plugin_type='connection', plugin_name='network_cli', on_missing='error')

    # Test existing global config

# Generated at 2022-06-11 15:02:36.253216
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import constants as C
    from ansible.module_utils.six import string_types

    values = {
        'name': 'layman',
        'key': 'ansible',
        'value': 'rocks'
    }

    # test for invalid argument errors
    # missing on_missing
    for missing in ['error', 'warn', 'skip']:
        l = LookupModule()
        try:
            l.run(terms=[values['name']], variables={values['key']: values['value']}, on_missing=missing)
        except AnsibleOptionsError as e:
            assert '"on_missing" must be a string and one of "error", "warn" or "skip", not %s' % missing in to_native(e)

    # invalid setting name
    l = LookupModule()

# Generated at 2022-06-11 15:02:47.735860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	pass

# Generated at 2022-06-11 15:02:52.190200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["DEFAULT_BECOME_USER"]
    variables = {'DEFAULT_BECOME_USER': 'root'}
    kwargs = {'wantlist': True}
    result = module.run(terms, variables, **kwargs)
    assert result == ['root']


# Generated at 2022-06-11 15:02:56.588090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo', 'bar']
    variables = {'foo': 'bar', 'bar': 'baz'}
    lm = LookupModule()
    ret = lm.run(terms, variables)
    assert ret == [variables['foo'], variables['bar']]

# Generated at 2022-06-11 15:03:00.792508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of the LookupModule
    # initialize the instance
    lookup_plugin = LookupModule()

    # test the run method
    try:
        lookup_plugin.run(terms=None, variables={}, **{})
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-11 15:03:08.245691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    print(lookup.run(["DEFAULT_BECOME_USER"], [], {'plugin_type': 'become'}))
    print(lookup.run(["DEFAULT_BECOME_USER"], [], {'plugin_type': 'become', 'plugin_name': 'su'}))
    print(lookup.run(["UNKNOWN", "UNKNOWN"], [], {'on_missing': 'skip'}))


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:03:19.301850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'DEFAULT_BECOME_USER'
    variables = {'foo': 'bar'}
    missing = 'error'
    ptype = ''
    pname = ''
    terms = [term]
    settings = {'DEFAULT_BECOME_USER': 'foo'}
    C.config = type('Config', (object,), settings)
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, variables, on_missing=missing, plugin_type=ptype, plugin_name=pname)
    assert result == ['foo']

    # Testing error
    missing = 'foo'

# Generated at 2022-06-11 15:03:26.873256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config_val1 = 'value1'
    config_val2 = 'value2'
    C.DEFAULT_BECOME_USER = config_val1
    C.DEFAULT_BECOME_PASS = config_val2

    list_settings = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS']
    config_setting = 'DEFAULT_BECOME_USER'
    lm = LookupModule()
    ret = lm.run(list_settings)
    assert ret[0] == config_val1
    assert ret[1] == config_val2

    ret = lm.run(config_setting)
    assert ret[0] == config_val1

# Generated at 2022-06-11 15:03:35.402986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible import context
    except ImportError:
        from ansible.utils.context import Context as context

    from ansible.parsing.dataloader import DataLoader

    context.CLIARGS = {}
    loader = DataLoader()


# Generated at 2022-06-11 15:03:45.045711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Retrieve the input parameters passed to the LookupModule.run method
    lookup_instance = LookupModule()
    term_name = 'C.DEFAULT_BECOME_USER'
    parameters = {'on_missing': 'skip', 'plugin_type': 'become', 'plugin_name': 'winrm'}
    lookup_instance.set_options(var_options=None, direct=parameters)

    # Test: if term is not of string type, error is raised
    with pytest.raises(AnsibleOptionsError):
        lookup_instance.run(['term'])

    # Test: if on_missing is not one of the allowed values, error is raised
    with pytest.raises(AnsibleOptionsError):
        lookup_instance.run([term_name])

    # Test: if 'on_missing' is

# Generated at 2022-06-11 15:03:49.711228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["DEFAULT_ROLES_PATH"],
                             variables={"DEFAULT_BECOME_PASS": "foo"},
                             on_missing="error") == [
        ["./roles", "../roles"]], "Test failed!"

# Generated at 2022-06-11 15:04:14.326252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create the variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'my_var': 'my_value', 'other_var': 'other_value'}

    # Create the loader
    loader = DataLoader()

    # Create the inventory
    inventory = InventoryManager(loader=loader, sources='localhost,')

    lookup_module = LookupModule()
    lookup_module.set_loader(loader)
    lookup_module.set_inventory(inventory)
    lookup_module.set_variable_manager(variable_manager)

    # Test 1
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module

# Generated at 2022-06-11 15:04:19.599973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = 'DEFAULT_ROLES_PATH'
    config_error = 'UNKNOWN'
    terms = [config, config_error]
    expected_result = C.DEFAULT_ROLES_PATH
    actual_result = LookupModule().run(terms)
    assert expected_result == actual_result[0]



# Generated at 2022-06-11 15:04:27.678303
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from collections import namedtuple
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # mock Variables, Dataloader and ConfigManager
    variables = namedtuple('variables', ('vars',))
    variables.vars = {'ansible_connection': 'local'}
    loader = namedtuple('loader', ('get_basedir',))
    loader.get_basedir = lambda x: '.'
    loader.path_dwim = lambda x, y: y
    config_mgr = ConfigManager()

    # instanciate a LookupModule
    lk = LookupModule()
    lk.set_loader(loader)

# Generated at 2022-06-11 15:04:35.427903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    if PY3:
        import unittest
        import sys
        import ansible
        test = unittest.TestCase()

        ##############
        # Successful #
        ##############
        terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']
        variables = {'ansible_python_interpreter': sys.executable}
        expected_result = [u'/etc/ansible/roles:/usr/share/ansible/roles', u'root']
        l = LookupModule()
        assert l.run(terms, variables=variables) == expected_result, 'test_LookupModule_run assert#1 has failed.'


# Generated at 2022-06-11 15:04:47.119025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # plugin_type and plugin_name are not None
    assert LookupModule().run(terms=['remote_tmp'], plugin_type='shell', plugin_name='sh') == ['$HOME/.ansible/tmp']
    # plugin_type and plugin_name are None
    assert LookupModule().run(terms=['DEFAULT_SUDO_USER']) == ['root']
    # on_missing is 'error'
    lookup_module = LookupModule()
    # plugin_type and plugin_name are None
    try:
        lookup_module.run(terms=['UNKNOWN'])
    except AnsibleLookupError as e:
        assert str(e) == 'Unable to find setting UNKNOWN'
    # plugin_type and plugin_name are not None

# Generated at 2022-06-11 15:04:57.817495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    pytest.importorskip("yaml")

    def _mock_display_warning(msg):
        assert msg == 'Skipping, did not find setting bar'
        return None

    def _mock_get_config_value(config, plugin_type, plugin_name, variables):
        if config == 'foo':
            if plugin_type == 'Connection' and plugin_name == 'paramiko':
                return 'test_foo'
            else:
                raise AnsibleLookupError('Unable to find foo in paramiko connection plugin')
        else:
            raise AttributeError


# Generated at 2022-06-11 15:05:07.549392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_HASH_BEHAVIOUR', 'DEFAULT_JINJA2_NATIVE']
    kwargs = {'on_missing': 'warn', 'plugin_type': None, 'plugin_name': None}
    lookup_plugin = LookupModule()
    # Test the successful return
    ret = lookup_plugin.run(terms, **kwargs)
    assert len(ret) == 2
    # Test with missing terms
    terms.append('NON-EXIST-SETTING')
    # Test the missing error handling
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_plugin.run(terms, **kwargs)
    excinfo.match('Unable to find setting NON-EXIST-SETTING')
    # Test the skip behavior
    kwargs['on_missing']

# Generated at 2022-06-11 15:05:18.503298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Configure with options
    lookup_obj = LookupModule()
    lookup_obj.set_options(dict(on_missing='warn'))

    # Testing for correct input
    for correct_input in ['COLOR_OK', 'DEFAULT_BECOME_USER']:
        # Input as a list
        assert lookup_obj.run([correct_input]) == [C.config.get_config_value(correct_input)]
        # Input as a string
        assert lookup_obj.run(correct_input) == [C.config.get_config_value(correct_input)]

# Generated at 2022-06-11 15:05:25.106346
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:05:36.177500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run(terms=['PROJECT_PATH', 'PROJECT_PATHS'], variables=None, on_missing='error')
    assert lookup_module_run == [C.DEFAULT_LOCAL_TMP, C.DEFAULT_REMOTE_TMP]

    lookup_module_run = lookup_module.run(terms=['PROJECT_PATH', 'PROJECT_PATHS'], variables=None, on_missing='warn')
    assert lookup_module_run == [C.DEFAULT_LOCAL_TMP, C.DEFAULT_REMOTE_TMP]

    lookup_module_run = lookup_module.run(terms=['PROJECT_PATH', 'PROJECT_PATHS'], variables=None, on_missing='skip')

# Generated at 2022-06-11 15:06:12.486275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assign
    terms = [ 'DEFAULT_BECOME_USER' ]

    # Mock
    class MockLookupBase(LookupBase):
        def __init__(self):
            self.ansible = "1.9"

    lookup_base = MockLookupBase()

    # Test
    result = LookupModule().run(terms, None, look_all_read=None, look_in_cache=None,
                                wantlist=None, parent_groups=(), task_vars={},
                                disable_lookups=False, loader='', _connection=None,
                                _play_context=None, _loader=None, passwords={},
                                inventory_basedir='', _basedir=None)

    # Assert
    assert result[0] == 'root'

# Generated at 2022-06-11 15:06:16.797604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()
    result = L.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{'on_missing': 'error', 'plugin_type': None, 'plugin_name': None})
    assert result == ['root']

# Generated at 2022-06-11 15:06:26.102698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_registry = plugin_loader.LookupModuleRegistry([LookupModule])
    lookup_registry.run_callback_plugins(callback_plugins_loaded=False)
    lookup_registry.populate()
    lookup_instance = lookup_registry.get(name='config')
    print(lookup_instance.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'playbook_dir': '/etc/ansible/roles'},
          on_missing='skip'))
    #print(lookup_instance.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'playbook_dir': '/etc/ansible/roles'},
    #      wantlist=True, on_missing='skip'))


# Generated at 2022-06-11 15:06:36.593244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    import ansible.constants as C
    import random
    import string
    import re

    # Prepare test environment
    random_string = ''.join(random.choice(string.ascii_lowercase) for _ in range(10))
    CLEANUP = [random_string + '_out', random_string + '_err']
    C.HOST_KEY_CHECKING = False

    loader = DataLoader()
    host_list = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = Variable

# Generated at 2022-06-11 15:06:47.748919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase
    lookup = lookup_loader.get("config", class_only=True)()
    lookup._display = MockDisplay()
    assert isinstance(lookup, LookupBase)
    lookup.set_options(direct={'plugin_name': 'ssh', 'plugin_type': 'connection'})
    assert lookup.run(['remote_user', 'port'], {}, on_missing='error', plugin_name='ssh', plugin_type='connection') == ['', '22']
    lookup.set_options(direct={'plugin_name': 'sh', 'plugin_type': 'shell'})

# Generated at 2022-06-11 15:06:59.326709
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with invalid 'missing' option
    l = LookupModule()
    l.set_options(var_options={'on_missing': 'invalid_option'})
    try:
        l.run(['test'])
        assert False
    except AnsibleOptionsError:
        pass

    # test with invalid config setting
    try:
        l.run(['invalid_setting'])
        assert False
    except AnsibleLookupError:
        pass

    # test with valid 'missing' option but missing key
    l.set_options(var_options={'on_missing': 'warn'})
    l.run(['invalid_setting'])
    assert True

    # test with both 'plugin_name' and 'plugin_type'

# Generated at 2022-06-11 15:07:04.217431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    assert test_LookupModule.run(['DEFAULT_BECOME_USER']) == ['root']
    assert test_LookupModule.run([]) == []
    assert test_LookupModule.run(['DEFAULT_ROLES_PATH']) == ['DEFAULT_ROLES_PATH']

# Generated at 2022-06-11 15:07:15.301121
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as plugin_loader
    import ansible.constants as C

    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.utils.sentinel import Sentinel

    plugin_options = {'plugin_type': 'connection', 'plugin_name': 'local'}
    test_class = LookupModule()

    ########################################################################################################
    # Both plugin_type and plugin_name not provided
    ########################################################################################################
    terms = ['DEFAULT_BECOME_METHOD']
    variables = None
    test_class.set_options(var_options=variables, direct=plugin_options)
    try:
        result = test_class.run(terms)
    except AnsibleOptionsError:
        pass
    except Exception as err:
        raise

# Generated at 2022-06-11 15:07:21.344613
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import constants

    constants.DEFAULT_REMOTE_USER = 'testinguser'
    constants.DEFAULT_PRIVATE_KEY_FILE = 'testingkeyfile'
    constants.DEFAULT_REMOTE_PASS = 'testingpass'

    result = LookupModule().run(['DEFAULT_REMOTE_USER'])

    assert result[0] == 'testinguser'

# Generated at 2022-06-11 15:07:28.829154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    lookup = LookupModule()

    # check run method in case of empty terms list
    assert lookup.run([], {}) == []
    # check run method in case of different terms list
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_FORKS'], {}) == ['root', 5]
    # check run method in case of negative scenario
    try:
        lookup.run(['DUMMY'], {}, on_missing="error")
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)
    try:
        lookup.run(['DEFAULT_BECOME_USER', 'DUMMY'], {}, on_missing="error")
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)

    #

# Generated at 2022-06-11 15:08:39.206562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test exception raised.
    with pytest.raises(AnsibleOptionsError):
        lookup_module = LookupModule()
        lookup_module.run(terms=["fake_term"], variables=None, plugin_type="fake_type")
    assert True

    # Test exception raised.
    with pytest.raises(AnsibleOptionsError):
        lookup_module = LookupModule()
        lookup_module.run(terms=["fake_term"], variables=None, plugin_type="fake_type")
    assert True

    # Test exception raised.
    with pytest.raises(AnsibleOptionsError):
        lookup_module = LookupModule()
        lookup_module.run(terms=["fake_term"], variables=None, on_missing="fake_missing")
    assert True

    # Test exception raised.

# Generated at 2022-06-11 15:08:48.425946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_loader({})
    l.set_application({})
    l.set_env({})
    l.set_play_context({})
    l.set_options({})

    terms = ['DEFAULT_BECOME_USER']
    result = l.run(terms=terms)
    assert result == ['root']

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = l.run(terms=terms)
    assert result == ['root', '/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/plugins/roles:/home/user/.ansible/plugins/roles']

    terms = ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
   

# Generated at 2022-06-11 15:08:59.409365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(LookupModule(),
                              terms='ANSIBLE_ROLES_PATH',
                              variables={},
                              on_missing='error',
                              plugin_name=None,
                              plugin_type=None)

    assert isinstance(result, list)
    assert len(result) == 1
    assert 'roles' == result[0]

    result = LookupModule.run(LookupModule(),
                              terms='ANSIBLE_ROLES_PATH',
                              variables={},
                              on_missing='error',
                              plugin_name='shell',
                              plugin_type='become')

    assert isinstance(result, list)
    assert len(result) == 1
    assert 'roles' == result[0]


# Generated at 2022-06-11 15:09:10.858809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    # constructor args
    terms=['DEFAULT_ROLES_PATH']
    kwargs={'wantlist':True}
    options={'plugin_type':'connection',
             'plugin_name':'ssh',
             'on_missing':'skip'}
    # expected result
    expected_result=['/usr/share/ansible/roles:/etc/ansible/roles:/ansible/roles']
    # create LookupModule object
    lookup_module = LookupModule()
    # run ansible-config method
    result = lookup_module.run(terms, **kwargs)
    # verify
    assert result == expected_result

    # constructor args
    terms=['port']

# Generated at 2022-06-11 15:09:21.305519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # define test data (as strings)
    test_terms = 'test_terms_test'
    test_variables = 'test_variables_test'
    test_kwargs = 'test_kwargs_test'

    # define test class and test object
    class TestClass:
        def set_options(self, a, b):
            self.result_set_options = a,b
        def get_option(self, a):
            return self.result_get_option
        def warning(self, a):
            self.warning_was_called = True
        def run(self, terms, variables=None, **kwargs):
            self.result_run = terms, variables, kwargs
        def expected_result(self, a, b, c):
            return self.run(a, b, c)

    test_object

# Generated at 2022-06-11 15:09:27.584907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    setattr(test_LookupModule, '_display', DummyDisplay())

    test_LookupModule.set_options(direct={'_original_file': '/test/path', '_original_module': '/test/module_name'})

    result = test_LookupModule.run(terms=['DEFAULT_NETWORK_OS'], variables={})
    assert result == ['default']

# Generated at 2022-06-11 15:09:38.268094
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader

    vault_pass = 'ansible'
    unvault_string = 'ansible'
    vault_string = VaultLib().encrypt(unvault_string, vault_pass)

    # Get the LookupModule class
    sandbox_class = [x for x in lookup_loader.all() if x.__name__ == 'LookupModule'][0]

    # Get the list of terms, e.g. ['DEFAULT_VAULT_PASSWORD_FILE', 'DEFAULT_VAULT_IDENTITY_LIST']
    term_list = sorted(dir(C))

    r = sandbox_class(loader=None, templar=None)

    result = r.run(terms=term_list)


# Generated at 2022-06-11 15:09:48.008243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from ansible.plugins.loader import become_plugin_loader
    from ansible.plugins.become import BecomeBase
    from ansible.plugins.lookup import LookupBase
    import sys

    old_stderr = sys.stderr
    sys.stderr = open('/dev/null', 'w')  # shut stderr up.
    display = Display()

    # fake_become_plugins is a list of classes that derive from BecomeBase.
    # We have to save references to them because otherwise the garbage collector
    # kicks in and destroys them before we can use them.
    fake_become_plugins = []

    # inject a fake plugin
    class FakePlugin1(BecomeBase):
        def __init__(self, *args, **kwargs):
            self.bec

# Generated at 2022-06-11 15:09:53.120973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
      'key_name',
      {
        'plugin_type': 'connection',
        'plugin_name': 'local'
      }
    ]
    kwargs = {
      'on_missing': 'skip'
    }
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(*args, **kwargs)
    assert 'result' in result

# Generated at 2022-06-11 15:09:59.461339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t1 = {'on_missing': 'error',
          'plugin_type': 'connection',
          'plugin_name': 'local'}
    l1 = LookupModule(loader=None, templar=None, **t1)

    assert l1.run(['remote_tmp']) == ['/tmp/ansible-${USER}@${HOSTNAME}']
    assert l1.run(['NO_SUCH_KEY']) == []