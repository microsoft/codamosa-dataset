

# Generated at 2022-06-11 15:01:36.110252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={})
    terms = ['DEFAULT_ROLES_PATH', '_ROLES_PATH']
    variables = {}
    ret = lookup_module.run(terms, variables)
    assert ret[0] == ret[1]

# Generated at 2022-06-11 15:01:37.201920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()



# Generated at 2022-06-11 15:01:47.833228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 1 to test lookup with valid config without plugin_type and plugin_name
    terms = 'C.DEFAULT_BECOME_USER'
    lookup_obj = LookupModule()
    lookup_obj.set_loader(None)
    lookup_obj.set_options({'_original_path': 'ansible/plugins/lookup/config.py',
        '_ansible_debug': False,
        '_ansible_verbosity': 0,
        '_ansible_no_log': False,
        'warnings': ['provided hosts list is empty, only localhost is available'],
        'on_missing': 'error',
        'plugin_type': None,
        'plugin_name': None})

    assert lookup_obj.run([terms]) == ["root"]

    # Case 2 to test lookup with valid config without plugin_type

# Generated at 2022-06-11 15:01:48.459956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0

# Generated at 2022-06-11 15:01:53.022232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term_list = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    options = {'on_missing': 'warn'}
    lookup_module.set_options(**options)
    terms = lookup_module.run(term_list)
    assert terms[0] == 'root'

# Generated at 2022-06-11 15:02:02.368443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six.moves import StringIO
    import sys

    # no options set
    try:
        assert lu._run([], [], {}) is None
    except AnsibleError as e:
        assert False, to_native(e)

    # with default option
    try:
        assert lu._run(['DEFAULT_BECOME_METHOD'], [], {}) is not None
    except AnsibleError as e:
        assert False, to_native(e)

    # with plugin_type and plugin_name option

# Generated at 2022-06-11 15:02:09.115435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    loader = plugin_loader.plugin_loader
    loader._package_paths = {'ansible.plugins.lookup.config': 'ansible/plugins/lookup/config',
                             'ansible.plugins.lookup': 'ansible/plugins/lookup'}
    loader._module_cache = {}
    loader._plugin_cache = {}

    plugin = loader.get('config')
    assert isinstance(plugin, LookupModule)
    assert isinstance(plugin.run(['DEFAULT_BECOME_USER'], variables={}), list)
    assert plugin.run(['DEFAULT_BECOME_USER'], variables={})[0] == 'root'

# Generated at 2022-06-11 15:02:19.067408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from _pytest.monkeypatch import MonkeyPatch
    monkeypatch = MonkeyPatch()

    def mock_set_options(self, var_options=None, direct=None):
        self.var_options = var_options
        self.direct = direct

    class MockClass:
        def __init__(self):
            self.result = []
        def set_options(self, var_options=None, direct=None):
            mock_set_options(self, var_options, direct)
        def get_option(self, option):
            if option == 'on_missing':
                return self.direct['on_missing']
            elif option == 'plugin_type':
                return self.direct['plugin_type']
            elif option == 'plugin_name':
                return self.direct['plugin_name']

# Generated at 2022-06-11 15:02:26.923519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup_module = LookupModule()
    my_term_list = ['DEFAULT_REMOTE_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH']
    my_option_dict = {
        'on_missing': 'warn',
        'plugin_type': None,
        'plugin_name': None
    }
    result = my_lookup_module.run(terms=my_term_list, **my_option_dict)
    assert isinstance(result, list), 'result is not a list'
    for res in result:
        assert isinstance(res, string_types), 'result element is not a string'


# Generated at 2022-06-11 15:02:35.708643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{myvar}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tasks = play.get_

# Generated at 2022-06-11 15:02:55.837598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test with missing option, setting and plugin
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=[], variables={'any_variable': 'any_value'})

    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['any_plugin'], variables={'any_variable': 'any_value'}, on_missing='any_wrong_state')

    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['any_setting'], variables={'any_variable': 'any_value'})

    # test with plugin_name and plugin_type options

# Generated at 2022-06-11 15:03:04.085852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule().run(terms=["COLOR_OK", "COLOR_SKIP", "COLOR_CHANGED"]) == ["green", "cyan", "yellow"])
    assert(LookupModule().run(terms=["COLOR_OK", "COLOR_SKIP", "COLOR_CHANGED"], on_missing='warn') == ["green", "cyan", "yellow"])
    assert(LookupModule().run(terms=["COLOR_OK", "COLOR_SKIP", "COLOR_CHANGED"], on_missing='skip') == ["green", "cyan", "yellow"])
    assert(LookupModule().run(terms=["COLOR_OK", "COLOR_SKIP", "COLOR_CHANGED", "COLOR_FATAL"]) == ["green", "cyan", "yellow"])

# Generated at 2022-06-11 15:03:15.170366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./plugins')
    test_terms = ['DEFAULT_BECOME_USER']
    test_variables = {
        'foo': 'bar',
    }
    test_plugin_type = 'become'
    test_plugin_name = 'sudo'
    test_on_missing = 'error'
    test_kwargs = {
        'direct': True,
    }
    lm = LookupModule()
    ret = lm.run(terms=test_terms, variables=test_variables, plugin_type=test_plugin_type, plugin_name=test_plugin_name, on_missing=test_on_missing, **test_kwargs)
    assert ret == ['root']

# Generated at 2022-06-11 15:03:19.575756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    test_obj = LookupModule()
    test_ret = test_obj.run(terms, None)
    assert len(test_ret) == 1
    assert test_ret[0] == 'root'



# Generated at 2022-06-11 15:03:31.437523
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:03:39.041273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing instances of class
    lookup_module = LookupModule()

    # Defining valid options to run method
    opts = {'plugin_type': 'cliconf', 'plugin_name': 'aruba_remote_access', 'wantlist': 'True'}

    # Defining valid args to run method
    terms = ['remote_base_dir', 'remote_tmp']

    # Testing method run for different scenarios
    results = lookup_module.run(terms, opts)
    assert results == C.DEFAULT_REMOTE_BASE_DIR, \
        "test_lookupmodule_run(): Failed to run with valid options and args"

    # Defining invalid args to run method
    terms = ['remote_base_dir', 'remote_tm']

    # Testing method run for different scenarios

# Generated at 2022-06-11 15:03:43.040382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_CONNECTION', 'UNKNOWN_KEY']
    result = lookup.run(terms)
    assert result[0] == 'smart'
    assert type(result[1]) == type(MissingSetting('Error message'))

# Generated at 2022-06-11 15:03:54.222407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note - this test is skipped in the unit test framework, it is known to be non deterministic
    # and other tests depend on it.  Run it manually if you want to tweak it.
    # see the end of the test/units/plugins/lookup/test_config.py for the other skipped tests
    from ansible.parsing import plugin_loader, vault

    config = plugin_loader.load_plugin_vars('./test/units/plugins/lookup/test_config.yaml')
    variables = plugin_loader.load_plugin_vars('./test/units/plugins/lookup/test_config_variables.yaml')
    vault_password_file = './test/units/plugins/lookup/test_config_vault_password_file.txt'

# Generated at 2022-06-11 15:04:04.360345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test: LookupModule_run"""
    module = LookupModule()
    # Test id of DEFAULT_BECOME_METHOD
    assert module.run(terms=["DEFAULT_BECOME_METHOD"], variables=None,
                      **{}) == ["sudo"]
    # Test id of UNKNOWN
    assert module.run(terms=["UNKNOWN"], variables=None,
                      **{}) == []
    # Test id of UNKNOWN with on_missing=warn
    assert module.run(terms=["UNKNOWN"], variables=None,
                      **{'on_missing': 'warn'}) == []
    # Test id of plugin_name=ssh_connection in module connection

# Generated at 2022-06-11 15:04:15.863196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    class MockVaultLib(VaultLib):
        def _get_vault_ids(self):
            return ['foo']

    class MockDisplay:
        def __init__(self):
            self.warning_msg = ''

        def warning(self, msg):
            self.warning_msg = msg

    mock_display = MockDisplay()

    test_lookup = LookupModule()
    test_lookup._display = mock_display
    test_lookup.set_options(
        dict(
            vault_password_file='dummy_pass',
            vault_ids=['foo']
        )
    )


# Generated at 2022-06-11 15:04:42.674929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test(terms, variables, plugin_type, plugin_name, on_missing):
        look = LookupModule()
        res = look.run(terms, variables, plugin_type=plugin_name, plugin_name=plugin_type, on_missing=on_missing)
        return res

    assert test(["DEFAULT_REMOTE_USER"], variables=None, plugin_type="connection", plugin_name="ssh", on_missing="error") == ['root']

    assert test(["DEFAULT_REMOTE_USER", "DEFAULT_MODULE_NAME"], variables=None, plugin_type=None, plugin_name=None, on_missing="error") \
           == ['root', 'command']


# Generated at 2022-06-11 15:04:54.216481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    ############################################################################################

# Generated at 2022-06-11 15:04:58.734888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # A lookup module needs to implement a run method which takes terms, kwargs, variables
    lookup_module = LookupModule()
    # The run methods returns a JSON string
    result = lookup_module.run(["DEFAULT_BECOME_USER"], '', DEFAULT_BECOME_USER="root")
    # The first result is the JSON string representation of the value of the key
    assert result == ["root"]

# Generated at 2022-06-11 15:05:08.182521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleLookupError
    from ansible.plugins.loader import become_loader, cache_loader, callback_loader, cliconf_loader, connection_loader, httpapi_loader, \
        inventory_loader, lookup_loader, netconf_loader, shell_loader, vars_loader
    from ansible.plugins.lookup import LookupBase
    from ansible import constants as C
    import sys

    class MockLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, shared_loader_obj=None):
            pass


# Generated at 2022-06-11 15:05:19.435632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    from ansible.errors import AnsibleError

    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupModule

    from ansible.module_utils.six import string_types

    from ansible.module_utils._text import to_native

    lookup_module = lookup_loader.get('config')

    # CASE 1:
    # test_LookupModule_run: missing is not error and term is defined
    # CASE 2:
    # test_LookupModule_run: missing is skip and term is not in config
    # CASE 3:
    # test_LookupModule_run: missing is skip and term is not in config
    # CASE 4:
    # test_LookupModule_run: missing is error and term is not in config
    # CASE 5:
    # test

# Generated at 2022-06-11 15:05:24.767903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    args = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']]
    opts = {'on_missing': 'skip'}
    lookup_plugin.run(terms=args, variables={}, **opts)

# Generated at 2022-06-11 15:05:28.905551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()
    result = test_module.run(['DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH'])
    assert result[0][2] == "."
    assert result[1] == "~/.ansible/retry"

# Generated at 2022-06-11 15:05:29.795959
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert(True)

# Generated at 2022-06-11 15:05:39.121837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel

    # This is a test for the method run of class LookupModule.
    # The inputs for which the methods should run are defined as dict below.
    # The output of the method run should be compared to the expected output,
    # which is also defined as a dict.

    # This is a tuple of two dicts.
    # The first dict contains the inputs and the second dict contains the expected
    # output.

# Generated at 2022-06-11 15:05:41.038922
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:06:21.859932
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()
    l.set_play_context(play_context=None)
    l.set_loader(loader=None)

    # lookup: q("config", "remote_user", "port", plugin_type="connection", plugin_name="ssh", on_missing='skip')
    assert l.run(terms=['remote_user', 'port'], variables=None, plugin_type='connection', plugin_name='ssh', on_missing='skip') == ['ansible', 22]

    # lookup: q("config", "remote_user", "port", plugin_type="connection", plugin_name="ssh", on_missing='skip')
    l = LookupModule()
    l.set_play_context(play_context=None)
    l.set_loader(loader=None)

# Generated at 2022-06-11 15:06:32.491987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with missing option
    with pytest.raises(AnsibleOptionsError, match='Missing required arguments: _terms'):
        lookup_module.run()

    # Test with invalid value of on_missing option
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {'on_missing': 'test'}
    with pytest.raises(AnsibleOptionsError, match='"on_missing" must be a string and one of "error", "warn" or "skip", not test'):
        lookup_module.run(terms=terms, variables=variables, **kwargs)

    # Test with invalid term type
    kwargs = {'on_missing': 'error'}
    terms = [1]

# Generated at 2022-06-11 15:06:43.996635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test fetching configuration values
    _val1 = LookupModule().run(['DEFAULT_BECOME_USER', 'RETRY_FILES_SAVE_PATH'])
    assert len(_val1) == 2
    assert isinstance(_val1, list)

    # test fetching configuration values
    _val2 = LookupModule().run(['DEFAULT_BECOME_USER', 'RETRY_FILES_SAVE_PATH', 'UNKNOWN_SETTING'])
    assert len(_val2) == 2
    assert isinstance(_val2, list)

    # test fetching configuration values
    _val3 = LookupModule().run(['DEFAULT_BECOME_USER', 'RETRY_FILES_SAVE_PATH', 'UNKNOWN_SETTING'],
                               on_missing='warn')

# Generated at 2022-06-11 15:06:51.466765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.utils.display import Display
    from collections import namedtuple

    # Create context and dummy display
    context.CLIARGS = {}
    display = Display()

    # Create a lookup module object
    lookup_obj = LookupModule()

    # Attach display and cliargs to the LookupModule object
    lookup_obj._display = display

    # Set the execution context
    lookup_obj.set_options({'plugin_name': 'ssh' ,'plugin_type': 'connection'})

    # reference: https://docs.ansible.com/ansible/latest/plugins/lookup/config.html
    result = lookup_obj.run(['remote_user', 'port'], {'config_base': './', 'user': 'default'})
    assert result == ['default', 22]

# Generated at 2022-06-11 15:07:03.821723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_assertions(a, b):
        # Create assert statements that can be used to easily diagnose lookup module failures.
        if isinstance(a, basestring):
            assert a == b, "\nFailed Assertion: %r != %r" % (a, b)
        elif isinstance(a, list):
            assert sorted(a) == sorted(b), "\nFailed Assertion: %r != %r" % (a, b)
        elif isinstance(a, set):
            assert sorted(a) == sorted(b), "\nFailed Assertion: %r != %r" % (a, b)
        elif isinstance(a, dict):
            assert sorted(a) == sorted(b), "\nFailed Assertion: %r != %r" % (a, b)

# Generated at 2022-06-11 15:07:15.136699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #pylint: disable=too-many-branches, too-many-statements
    lookup_inst = LookupModule()

    # Error case: Missing value in terms
    terms_without_values = []
    terms = terms_without_values[:]
    try:
        lookup_inst.run(terms)
    except AnsibleLookupError as exc:
        assert("_terms is required" in to_native(exc))

    # Error case: Wrong value in 'on_missing'
    wrong_on_missing = 'unknown'
    try:
        lookup_inst.run(terms, on_missing=wrong_on_missing)
    except AnsibleLookupError as exc:
        assert("must be a string and one of" in to_native(exc))

    # Error case: plugin_type and plugin_name are not specified
   

# Generated at 2022-06-11 15:07:17.996579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    u = LookupModule()

    assert u.run([], {}) == []


# Generated at 2022-06-11 15:07:26.960376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule
    lookup = LookupModule()
    lookup._display = None
    lookup.set_options(var_options={'DEFAULT_BECOME_USER': 'mitsuhiko'})

    assert lookup.run(['DEFAULT_BECOME_USER']) == ['mitsuhiko']
    assert lookup.run(['DEFAULT_BECOME_PATH']) == ['/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PATH']) == ['mitsuhiko', '/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin']

# Generated at 2022-06-11 15:07:27.634303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	assert True, True

# Generated at 2022-06-11 15:07:36.252347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=missing-docstring
    # TODO: this should be a pytest unit test
    from ansible.plugins.loader import connection_loader
    c = connection_loader.get('local', class_only=True)
    lu = LookupModule()
    lu.run(['shell.sh.remote_tmp'])
    lu = LookupModule()
    lu.run(['shell.sh.remote_tmp'], plugin_name=c._load_name, plugin_type='connection')

# Generated at 2022-06-11 15:08:47.742215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # No plugin_type or plugin_name
    results = lookup_module.run(['CACHE_PLUGIN_TIMEOUT'], {'_ansible_verbosity': 4})
    assert results == ['3600']
    results = lookup_module.run(['CACHE_PLUGIN_TIMEOUT', 'JUNK'], {'_ansible_verbosity': 4})
    assert results == ['3600']
    results = lookup_module.run(['CACHE_PLUGIN_TIMEOUT', 'JUNK'], {'_ansible_verbosity': 0})
    assert results == ['3600']

# Generated at 2022-06-11 15:08:58.497323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value of on_missing
    lm = LookupModule()
    lm.set_options()
    try:
        lm.run(terms=[None])
        assert False, "AnsibleOptionsError should be raised as term is not a string"
    except AnsibleOptionsError as e:
        assert str(e) == 'Invalid setting identifier, "None" is not a string, its a %s' % type(None)
    except:
        assert False, "Unexpected error %s" % sys.exc_info()[0]

    # Test with Invalid value of on_missing

# Generated at 2022-06-11 15:09:08.030384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['TEST_VAR']) == ['value of TEST_VAR']

    assert lookup_module.run(['TEST_VAR1'], on_missing='skip') == []

    terms = ['TEST_VAR', 'TEST_VAR1']
    result = lookup_module.run(terms, on_missing='warn')
    assert result == ['value of TEST_VAR']

    terms = ['TEST_VAR', 'TEST_VAR1']
    result = lookup_module.run(terms, on_missing='error')
    assert result == ['value of TEST_VAR']


# Generated at 2022-06-11 15:09:15.102594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test normal conditions with no plugin name provided.
    lm = LookupModule()
    lm._display = MockDisplay()

    # Test lookup with configured setting
    result = lm.run([u'DEFAULT_REMOTE_USER'], None)
    result = result[0]
    assert result == u'root', u'Incorrect value returned: %s' % result

    # Test lookup with missing setting
    try:
        result = lm.run([u'NOT_A_CONFIG'], None)
        assert False, "Expected a LookupError exception"
    except LookupError as e:
        pass
    except Exception as e:
        assert False, "Expected a LookupError exception but got: %s" % e

    # Test lookup with missing setting and on_missing=warn

# Generated at 2022-06-11 15:09:25.673392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # run with default plugin_name and plugin_type values
    terms = ['DEFAULT_BECOME_USER']
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=terms)
    assert result == ["root"], result

    # run with plugin_name and plugin_type values
    terms = ['remote_tmp']
    ptype = 'shell'
    pname = 'sh'
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=terms, plugin_name=pname, plugin_type=ptype)
    assert result == ["$HOME/.ansible/tmp"]

# Generated at 2022-06-11 15:09:26.290818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-11 15:09:37.439844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    import ansible.plugins.loader as plugin_loader
    from ansible.config.manager import ConfigManager
    from ansible.module_utils.six import string_types

    C.CONFIG_MANAGER = ConfigManager()

    # _get_global_config return value
    c_g_c = ''

    # _get_plugin_config return value
    c_p_c = ''

    # _get_global_config getattr return value - callable
    c_g_c_callable = lambda x: x

    # _get_global_config getattr return value - attribute error
    c_g_c_a_e = "attribute error"

    # _get_global_config getattr return value - not callable or string
    c_g_c_not_call

# Generated at 2022-06-11 15:09:47.360688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize
    config_value_obj = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    options = {'on_missing': 'error'}
    config_value_obj.set_options(var_options={}, direct=options)
    # call run() method
    result = config_value_obj.run(terms)
    # assert results (value for DEFAULT_BECOME_USER should be 'root')
    assert result == ['root']
    # set terms and options
    terms = ['DEFAULT_BECOME_USER', 'port']
    options = {'plugin_type': 'connection', 'plugin_name': 'ssh', 'on_missing': 'error'}
    config_value_obj.set_options(var_options={}, direct=options)
    # call run() method
    result

# Generated at 2022-06-11 15:09:57.870184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'RETRY_FILES_SAVE_PATH']
    result = lookup_module.run(terms, {}, on_missing='error')
    assert result == ['root', '/root/.ansible/retry']

    terms = ['UNKNOWN_SETTING']
    try:
        results = lookup_module.run(terms, {}, on_missing='error')
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN_SETTING' in e.message

    results = lookup_module.run(terms, {}, on_missing='warn')
    assert results == []

    results = lookup_module.run(terms, {}, on_missing='skip')
    assert results == []

# Generated at 2022-06-11 15:10:08.957659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #Test getting the return value of global config
    #Test on_missing = error
    terms = ['DEFAULT_BECOME_METHOD']
    ret = lookup.run(terms, on_missing='error')
    assert ret == ['sudo']
    #Test on_missing = skip
    ret = lookup.run(terms, on_missing='skip')
    assert ret == ['sudo']
    #Test on_missing = warn
    ret = lookup.run(terms, on_missing='warn')
    assert ret == ['sudo']
    #Test invalid type for on_missing