

# Generated at 2022-06-11 15:01:28.377505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:01:37.821704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    import sys
    from ansible.utils.display import Display

    lookup_plugin = lookup_loader.get('config', class_only=True)

    # test param missing
    try:
        lookup_plugin.run([])
        assert 'Incorrect behavior: must raise AnsibleOptionsError'
    except AnsibleOptionsError:
        pass

    # test param terms with type not string_types
    try:
        lookup_plugin.run([0])
        assert 'Incorrect behavior: must raise AnsibleOptionsError'
    except AnsibleOptionsError:
        pass

    # test param variables with wrong type

# Generated at 2022-06-11 15:01:48.324420
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeConstantsModule(object):
        pass

    class FakeLoaderModule(object):

        def get(pname, class_only=True):
            pass

    class FakeDisplayModule(object):

        def warning(msg):
            pass

    module_args = {
        'on_missing': 'error',
        'plugin_type': None,
        'plugin_name': None,
    }

    mock_get_global_config = MagicMock(return_value='global')
    mock_get_plugin_config = MagicMock(return_value='plugin')
    mock_FakeLoaderModule_get = mock_get_plugin_config
    mock_FakeDisplayModule_warning = MagicMock()


# Generated at 2022-06-11 15:01:55.091800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test creating an instance of LookupModule without specifying a loader class
    l = LookupModule()
    l.set_loader_class(None)
    l.set_basedir('/tmp')
    l.set_runner(None)
    l.set_environment(None)
    l.set_vars(None)

    terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']

    ret = l.run(terms, variables=None)

    assert ret[0] == C.DEFAULT_ROLES_PATH
    assert ret[1] == C.DEFAULT_BECOME_USER

# Generated at 2022-06-11 15:02:04.552426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupModule(LookupModule):
        def __init__(self, *a, **kw):
            pass
    def _mocked_getattr(name):
        if name == 'DEFAULT_ROLES_PATH':
            return ['/some/path']
        raise AttributeError('Unable to find setting "%s"' % name)

    def _mocked_get_config_value(name, variables, plugin_type='', plugin_name=''):
        return 'foo'


    C.getattr = _mocked_getattr
    C.get_config_value = _mocked_get_config_value

    lookup_module = MockLookupModule()
    variable = {'DEFAULT_ROLES_PATH': ['/var/roles', '/etc/roles']}


# Generated at 2022-06-11 15:02:15.362491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    C.BECOME_ERROR_STR = u'Error occurred'
    C.COLOR_ERROR = 42
    C.DEFAULT_CACHE_PLUGIN = u'memory'
    C.DEFAULT_CACHE_RECHECK = False
    C.DEFAULT_CALLBACK_WHITELIST = [u'yaml']
    C.DEFAULT_CLICONF_PLUGIN = u'basic'
    C.DEFAULT_CONNECTION = u'smart'
    C.DEFAULT_HTTPAPI_PLUGIN = u'httpapi'
    C.DEFAULT_INVENTORY = u'/etc/ansible/hosts'
    C.DEFAULT_LINUX_SUDO = False
    C.DEFAULT_LOOKUP_PLUGIN = u'file'
    C.DEFAULT_

# Generated at 2022-06-11 15:02:24.533585
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # When C doesn't have a setting
    C.DEFAULT_BECOME_USER = "my_default_become_user"

    # When C has a setting
    C.DEFAULT_BECOME_USER = "my_default_become_user"
    terms = ["DEFAULT_BECOME_USER"]
    l = LookupModule()
    assert l.run(terms, variables=None, **{'on_missing': 'error'}) == ["my_default_become_user"]

    # When C doesn't have a setting and on_missing='warn'
    terms = ["DEFAULT_BECOME_USER_2"]
    l = LookupModule()
    assert l.run(terms, variables=None, **{'on_missing': 'warn'}) == []

    # When C doesn't have a setting and on

# Generated at 2022-06-11 15:02:32.763169
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Load the testcases
    with open('tests/test_lookup_plugin_config.yml', 'r') as f:
        testcases = yaml.load(f.read())
    # iterate over all testcases and check for expectations
    for testcase in testcases:
        test_instance = LookupModule()

        # apply the testcase and check for the expected results
        if testcase['expected']['result'] == 'error':
            expect(lambda: test_instance.run(**testcase['test_case'])).to.throw
        else:
            expect(test_instance.run(**testcase['test_case'])).to.equal(testcase['expected']['result'])


# Generated at 2022-06-11 15:02:33.901026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-11 15:02:41.794556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''
    # pylint: disable=protected-access
    lookup_ret = LookupModule().run(['DEFAULT_ROLES_PATH'], variable_manager=None, loader=None, templar=None)
    assert lookup_ret == [C.DEFAULT_ROLES_PATH]

    # test on_missing option
    # test 'skip'
    lookup_ret_2 = LookupModule().run(['UNKNOWN_VARIABLE'], variable_manager=None, loader=None, templar=None,
                                      on_missing='skip')
    assert lookup_ret_2 == []
    # test 'warn'

# Generated at 2022-06-11 15:03:02.887591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import lookup_loader, callback_loader
    from ansible.utils.sentinel import Sentinel

    callback_loader.add_directory('./ansible/plugins/callback')
    lookup_loader.add_directory('./ansible/plugins/lookup')

    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=["localhost"]))

    lu = LookupModule()

# Generated at 2022-06-11 15:03:09.683092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["DEFAULT_BECOME_USER", "DEFAULT_REMOTE_USER"]
    result = lookup.run(terms)
    # result.pop(0) will return the first item of the list and remove it from it.
    first_result = result.pop(0)
    second_result = result.pop(0)
    assert first_result == 'root'
    assert second_result == 'default'

# Generated at 2022-06-11 15:03:20.712159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1: Success. Check type of object returned.
    terms = ['COLLECTION_PATHS']
    lookup_obj = LookupModule()
    result = lookup_obj.run(terms)
    assert(isinstance(result, list))

    # Test 2: Failure. Check for exception MissingSetting.
    terms = ['invalid_config']
    lookup_obj = LookupModule()
    try:
        lookup_obj.run(terms)
        assert(False)
    except MissingSetting:
        assert(True)

    # Test 3: Failure. Check for exception AnsibleLookupError.
    terms = [10]
    lookup_obj = LookupModule()
    try:
        lookup_obj.run(terms)
        assert(False)
    except AnsibleLookupError:
        assert(True)

    # Test 4

# Generated at 2022-06-11 15:03:31.888325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #setup
    class_instance = LookupModule()
    test_terms = [
        "DEFAULT_BECOME_USER",
        "DEFAULT_ROLES_PATH",
        "RETRY_FILES_SAVE_PATH",
        "COLOR_OK",
        "COLOR_CHANGED",
        "COLOR_SKIP"
    ]

# Generated at 2022-06-11 15:03:34.405913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create LookupModule object
    lookup_module = LookupModule()

    # Call run method of class LookupModule and assert the result is empty
    assert lookup_module.run(['test_term']) == []

# Generated at 2022-06-11 15:03:36.320868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'DEFAULT_BECOME_USER'
    variables = ''
    LookupModule().run(terms, variables)

# Generated at 2022-06-11 15:03:44.759102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init and init class
    lookup_module = LookupModule()
    lookup_module.set_options({})
    # init variable
    # create term to get ansible config value
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms=terms)
    # check DEFAULT_BECOME_USER is equal result (ansible config value get)
    assert result == ['root']

    # init variable
    # create term to get ansible config value
    terms = ['COLOR_OK']
    result = lookup_module.run(terms=terms)
    # check COLOR_OK is equal result (ansible config value get)
    assert result == ['green']


# Generated at 2022-06-11 15:03:56.342964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule as config_lm


# Generated at 2022-06-11 15:04:00.837631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert module.run(['DEFAULT_BECOME_USER'], variables={'DEFAULT_BECOME_USER': 'nobody'}, on_missing='error') == ['nobody']

# Generated at 2022-06-11 15:04:07.139730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Arrange
    #For AnsibleOptionError exception
    terms = ['string', 'DEFAULT_ROLES_PATH']
    variables = 'error'
    #For Sentinel exception
    terms = ['DEFAULT_ROLES_PATH', 'error']
    variables = 'error'
    #For AnsibleLookupError exception
    terms = ['DEFAULT_ROLES_PATH', 'error']
    variables = 'error'
    #For MissingSetting exception
    terms = ['DEFAULT_ROLES_PATH', 'error']
    variables = 'error'

    #Act
    test_obj = LookupModule()
    test_obj.run(terms, variables)
    #Assert

# Generated at 2022-06-11 15:04:31.096856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_global_config(config):
        try:
            result = getattr(C, config)
            if callable(result):
                raise AnsibleLookupError('Invalid setting "%s" attempted' % config)
        except AttributeError as e:
            raise MissingSetting(to_native(e))

        return result

    lookup = LookupModule()
    lookup._display = None
    lookup._templar = None
    lookup._options = None
    term = ['DEFAULT_BECOME_USER']
    ret = lookup.run(term)
    assert ret == [_get_global_config('DEFAULT_BECOME_USER')]

# Generated at 2022-06-11 15:04:43.604721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # test Illegal option paramater
    with pytest.raises(AnsibleOptionsError):
        lookup_plugin.run([u'foo'], [u'bar'])

    # test with all options
    assert lookup_plugin.run([u'foo'], on_missing='error') is None
    assert lookup_plugin.run([u'foo'], on_missing='warn') is None
    assert lookup_plugin.run([u'foo'], on_missing='skip') is None

    # test invalid on_missing option parameter
    with pytest.raises(AnsibleOptionsError):
        lookup_plugin.run([u'foo'], on_missing='bar')

    # test global config
    C.DEFAULT_STDOUT_CALLBACK = u'foo'
    assert lookup_plugin.run

# Generated at 2022-06-11 15:04:49.428151
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin_type = 'inventory'
    plugin_name = 'openstack_melbourne'
    terms = ['plugin:' + plugin_name + ',' + plugin_type + ',cache']
    variables=''

    lu = LookupModule()
    result = lu.run(terms, variables)

    print('\nResult of "run" method for lookup module config is : ', result)



# Generated at 2022-06-11 15:05:00.346985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    print(lookup.run(['DEFAULT_BECOME_USER']))
    print(lookup.run(['DEFAULT_BECOME_USER'], plugin_type='cache', plugin_name='memory'))
    print(lookup.run(['DEFAULT_BECOME_USER'], plugin_type='cliconf', plugin_name='ios'))
    print(lookup.run(['remote_user', 'port'], plugin_type='connection', plugin_name='ssh'))
    print(lookup.run(['DEFAULT_BECOME_USER', 'UNKNOWN_KEY']))
    print(lookup.run(['DEFAULT_BECOME_USER', 'UNKNOWN_KEY'], on_missing='warn'))

# Generated at 2022-06-11 15:05:06.667099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # setup
    test_terms = [
        'DEFAULT_BECOME_USER',
        'UNKNOWN'
    ]

    # set global config
    setattr(C, 'DEFAULT_BECOME_USER', 'test')

    # execute
    lu = LookupModule()
    result = lu.run(test_terms, on_missing='warn')

    # verify result
    assert result == ['test']



# Generated at 2022-06-11 15:05:10.676921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # simple test case
    test_module = LookupModule()
    test_source = [ "DEFAULT_BECOME_USER" ]
    assert test_module.run(terms=test_source, variables=None, on_missing="error") == [ 'root' ]

# Generated at 2022-06-11 15:05:13.463501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["INVALID_option"]
    variables = {}
    lookup = LookupModule()
    result = lookup.run(terms, variables)
    assert result == []

# Generated at 2022-06-11 15:05:20.245180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    args = {}
    args['terms'] = ['DEFAULT_ROLES_PATH']
    res = lookup_module.run(**args)
    assert res == C.DEFAULT_ROLES_PATH
    args['terms'] = ['UNKNOWN', 'DEFAULT_ROLES_PATH']
    res = lookup_module.run(**args)
    assert res == [C.DEFAULT_ROLES_PATH]
    args['on_missing'] = 'error'
    try:
        res = lookup_module.run(**args)
    except AnsibleLookupError:
        pass
    args['on_missing'] = 'skip'
    res = lookup_module.run(**args)
    assert res == []
    args['on_missing'] = 'warn'
    res = lookup

# Generated at 2022-06-11 15:05:26.001450
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    fake_lookup_obj = LookupModule()
    fake_terms = ['DEFAULT_CACHE_PLUGIN', 'DEFAULT_CACHE_PLUGIN', 'DEFAULT_CACHE_PLUGIN']
    variables = {}
    fake_result = fake_lookup_obj.run(fake_terms, variables)
    assert isinstance(fake_result, list)
    assert len(fake_result) == 3
    assert fake_result[0] == 'memory'

# Generated at 2022-06-11 15:05:36.828070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}
    kwargs = {}
    expected = []

    # Test 1. Missing parameters
    setting = LookupModule()
    assert setting.run(terms, variables, **kwargs) == expected

    # Test 2. Plugin type not set
    terms = ['remote_tmp', 'remote_port']
    pname = 'sh'
    variables = {}
    kwargs['plugin_name'] = pname
    with pytest.raises(AnsibleOptionsError):
        setting.run(terms, variables, **kwargs)

    # Test 3. Plugin name not set
    terms = ['remote_tmp', 'remote_port']
    ptype = 'shell'
    variables = {}
    kwargs['plugin_type'] = ptype

# Generated at 2022-06-11 15:06:12.909741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['UNKNOWN']) == []
    assert callable(lookup_module.run(terms=['DEFAULT_CALLBACK_PLUGINS'])[0])
    assert isinstance(lookup_module.run(terms=['DEFAULT_CALLBACK_WHITELIST'])[0], list)
    assert isinstance(lookup_module.run(terms=['DEFAULT_STDOUT_CALLBACK'])[0], string_types)
    assert isinstance(lookup_module.run(terms=['DEFAULT_STDOUT_CALLBACK'], plugin_name='minimal')[0], string_types)

# Generated at 2022-06-11 15:06:23.818140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up the test case, to return a value from get_option
    from ansible.plugins.loader import LookupModule
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    import ansible.plugins.loader as plugin_loader

    class mock_options:

        def __init__(self, option_values):
            self.mock_options = option_values

        def get_option(self, optionName):
            if optionName in self.mock_options:
                return self.mock_options[optionName]
            raise AnsibleError('Unsupported option name %s' % optionName)

        def __getitem__(self, item):
            return self.get_option(item)


# Generated at 2022-06-11 15:06:27.004736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    :return:
    """

    # Test code goes here


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:06:37.675859
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.set_options()

    # TestException
    try:
        lookup.run(terms=['some_nonexistent_config_key'], variables=None, **{'on_missing': 'error'})
    except AnsibleOptionsError as e:
        assert 'must be a string and one of' in e.message
    except Exception as e:
        assert False, 'Unknown exception: %s' % e

    try:
        lookup.run(terms=['some_nonexistent_config_key'], variables=None, **{'on_missing': 'warn'})
    except AnsibleOptionsError as e:
        assert 'must be a string and one of' in e.message
    except Exception as e:
        assert False, 'Unknown exception: %s' % e


# Generated at 2022-06-11 15:06:48.490088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert lookup_plugin._templar is None
    assert lookup_plugin._loader is None
    assert lookup_plugin._display is None
    assert lookup_plugin._options is None

    # Config is None
    assert lookup_plugin.run(terms=['foo']) == []

    C.config = None
    assert lookup_plugin.run(terms=['foo']) == []

    # config is not None and valid but the value is missing in config
    C.config = object()
    assert lookup_plugin.run(terms=['foo']) == []

    # config is valid but key not available
    C.config = object()
    C.config.get_config_value = lambda x, **kwargs: None
    assert lookup_plugin.run(terms=['foo']) == []

    # config is

# Generated at 2022-06-11 15:07:00.540842
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockPlugin:
        _load_name = 'mock'

    ptype = 'connection'
    pname = 'mock'
    config = 'remote_tmp'
    terms = [config]
    variables = {}
    options = {'plugin_type': ptype, 'plugin_name': pname}

    # Add the mock-up plugin to the plugin loader
    plugin_loader.connection_loader._modules[pname] = MockPlugin

    # Create and initialize a lookup module to use
    mock_loader = LookupModule()
    mock_loader.set_options(var_options=variables, direct=options)

    # Test with 'on_missing' option set to 'error', expecting AnsibleLookupError
    # thrown due to missing plugin configuration
    mock_loader.options['on_missing'] = 'error'

# Generated at 2022-06-11 15:07:08.975346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['history_save_path', 'history_filename', 'unknown', 'nodev']
    terms_with_plugin = ['remote_tmp', 'socket']
    terms_with_wrong_plugin = ['remote_tmp', 'socket']
    missing = 'skip'
    plugin_name = 'sh'
    plugin_type = 'shell'
    variables = {}
    result = []
    result.append(_get_global_config(terms[0]))
    result.append(_get_global_config(terms[1]))
    result.append(_get_plugin_config(plugin_name, plugin_type, terms[2], variables))
    result.append(_get_global_config(terms[3]))
    with pytest.raises(AnsibleLookupError):
        lookup_module

# Generated at 2022-06-11 15:07:16.614015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   #Arrange
   terms = ['DEFAULT_REMOTE_USER']
   setattr(C, 'DEFAULT_REMOTE_USER', 'vagrant')
   variables = {}
   on_missing = 'error'
   plugin_type = 0
   plugin_name = 0

   #Act
   lu = LookupModule()
   lu.set_options(var_options=variables, direct=locals())
   test_result = lu.run(terms)[0]

   #Assert
   assert test_result == 'vagrant'

# Generated at 2022-06-11 15:07:26.486260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_bytes
    terms = ['DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    lookup_module = LookupModule()
    assert lookup_module.run(terms) == [[u'/etc/ansible/roles:/usr/share/ansible/roles'],
                                        [u'/home/adnan/.ansible/retry'],
                                        [u'green'],
                                        [u'yellow'],
                                        [u'cyan']]
    term = 'foo'
    lookup_module = LookupModule()
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(term)

# Generated at 2022-06-11 15:07:38.017046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': "inventory", 'plugin_name': "static"})
    assert lookup_module.run(['cache=', 'cache_connection=','inventory_ignore_extensions=']) == [C.DEFAULT_CACHE_PLUGIN, None, ['.tmp', '.swp']]
    lookup_module.set_options(var_options={})
    assert lookup_module.run(['host_key_auto_add']) == [C.HOST_KEY_CHECKING]
    lookup_module.set_options(direct={'plugin_type': "vars", 'plugin_name': "host_group_vars"})
    assert lookup_module.run(['directory=']) == ['vars']
    lookup_module.set_options

# Generated at 2022-06-11 15:08:40.122223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No tests written"

# Generated at 2022-06-11 15:08:48.772518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP', 'UNKNOWN']
    variables = {'playbook_dir': '../'}
    kwargs = {'on_missing': 'skip'}

    class FakeLookupBase(object):
        def __init__(self, s):
            self._display = s
    class FakeDisplay(object):
        def __init__(self):
            self.warning = print
    s = FakeDisplay()
    lb = FakeLookupBase(s)
    lm = LookupModule()
    lm.set_loader(None)
    lm._display

# Generated at 2022-06-11 15:08:59.829390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    msg_ok = "Success with result = %s"
    msg_fail = "Failure: lookup returned %s, expected %s"
    success = 0
    total = 0

    # Init test variables
    term_test = "DEFAULT_LOCAL_TMP"
    term_success = "DEFAULT_LOCAL_TMP"
    term_success_array = ["DEFAULT_LOCAL_TMP", "DEFAULT_ROLES_PATH", "RETRY_FILES_SAVE_PATH"]
    term_not_exists = "UNKNOWN"
    term_not_exists_array = ["UNKNOWN", "Uknown_array"]

    # Init LookupModule object
    lookup_module = LookupModule()
    result_success = lookup_module.run(terms=term_success)[0]

# Generated at 2022-06-11 15:09:12.358675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    with pytest.raises(AnsibleOptionsError):
        lookup_plugin.run(terms, variables)

    kwargs = {'on_missing': 'error'}
    with pytest.raises(AnsibleLookupError):
        lookup_plugin.run(terms, variables, **kwargs)

    kwargs['on_missing'] = 'warn'
    ret = lookup_plugin.run(terms, variables, **kwargs)
    assert ret == []

    kwargs['on_missing'] = 'error'
    with pytest.raises(AnsibleLookupError):
        lookup_plugin.run(terms, variables, **kwargs)


# Generated at 2022-06-11 15:09:21.744789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ip = LookupModule()
    ip.set_options()

    # We need to check that we get the correct response when there is a missing option
    ip.set_options(var_options={'option': 'ANSIBLE_CACHE_PLUGIN_CONNECTION'}, direct={'on_missing': 'error'})
    try:
        ip.run(terms=['ANSIBLE_CACHE_PLUGIN_CONNECTION'], variables={'option': 'ANSIBLE_CACHE_PLUGIN_CONNECTION'}, on_missing='error', use_jinja=False)
    except AnsibleLookupError as e:
        pass
    except Exception as e:
        assert False, 'wrong exception was raised [%s] instead of AnsibleLookupError' % (e)

    # We need to check that we get the

# Generated at 2022-06-11 15:09:33.753711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeValidatedVarsModule(object):
        def __init__(self):
            self.params = {}

        def set_options(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct

    class FakeLookupBase(object):
        def __init__(self):
            self.params = {}
            self.settings = {}
            self.set_options_validate = FakeValidatedVarsModule()

    lookup_instance = LookupModule()
    lookup_instance._display = FakeLookupBase()
    lookup_instance._display.warning = lambda x: None
    lookup_instance._display.vvvv = lambda x, host=None: None
    lookup_instance._display.debug = lambda x: None
    lookup_instance._templar = FakeLookupBase

# Generated at 2022-06-11 15:09:41.112306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([], [], plugin_type = None, plugin_name = None, on_missing = 'error') == []
    assert LookupModule().run([None], [], plugin_type = None, plugin_name = None, on_missing = 'error') == []
    assert LookupModule().run([""], [], plugin_type = None, plugin_name = None, on_missing = 'error') == []
    assert LookupModule().run(["none"], [], plugin_type = None, plugin_name = None, on_missing = 'error') == []
    assert LookupModule().run(["none"], [], plugin_type = None, plugin_name = None, on_missing = 'error') == []

if __name__ == '__main__':
    print(test_LookupModule_run())

# Generated at 2022-06-11 15:09:49.811514
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import context
    context._init_global_context(None)

    args = {'_ansible_module_name': 'debug', '_ansible_module_args': {}}
    args2 = {'_ansible_module_name': 'debug', '_ansible_module_succeeded': True, '_ansible_module_result': {'msg': 'foo'}}
    args3 = {'_ansible_module_name': 'debug', '_ansible_module_succeeded': True, '_ansible_module_result': {'msg': 'foo'}}
    args4 = {'_ansible_module_name': 'debug', '_ansible_module_succeeded': True, '_ansible_module_result': {'msg': 'foo'}}



# Generated at 2022-06-11 15:10:00.996871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Load test input parameters
    test = LookupModule()
    test_terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    test_kwargs = {'plugin_type': 'connection', 'plugin_name': 'ssh'}
    # Intercept stdout/stderr
    import sys
    from io import StringIO
    output = StringIO() #StringIO object
    err_out = StringIO()
    real_stdout, sys.stdout = sys.stdout, output
    real_stderr, sys.stderr = sys.stderr, err_out
    # Run lookup run() method
    try:
        test.run(test_terms, **test_kwargs)
    except:
        actual_err = err_out.getvalue().strip()
        expected_err

# Generated at 2022-06-11 15:10:07.847163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup_module = LookupModule()
    ## test with config
    lookup_module.run(['DEFAULT_BECOME_USER'])

    ## test with no config
    try:
        lookup_module.run(['DEFAULT_DO_NOT_EXIST'])
        assert False, "Expecting a AnsibleLookupError"
    except AnsibleLookupError as e:
        pass

