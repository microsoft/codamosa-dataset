

# Generated at 2022-06-11 15:01:39.891303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    terms = ['remote_user', 'remote_port', 'port']
    variables = {'ansible_ssh_user': 'ansible', 'ansible_port': 2222}
    direct = {'plugin_type': 'connection', 'plugin_name': 'ssh'}
    lookup_instance.set_options(var_options=variables, direct=direct)
    result = lookup_instance.run(terms, variables, **direct)
    assert result == ['ansible', 2222]
    # this should fail with invalid `plugin_type` provided
    terms = ['remote_user', 'remote_port', 'port']
    variables = {'ansible_ssh_user': 'ansible', 'ansible_port': 2222}

# Generated at 2022-06-11 15:01:50.173268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    import tempfile
    import os

    # Test setup
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'plugins'))

    # Setup a variables manager
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'config': 'value', 'test_default': 'mytest'}

    # Setup a fake host
    class FakeHost(object):
        def __init__(self, name, groups=None):
            self.name = name
            if groups is None:
                groups = []
            self.groups = groups


# Generated at 2022-06-11 15:01:57.172534
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestException(Exception):
        pass

    class MockAnsibleError(AnsibleError):
        def __init__(self, msg, orig_exc=None):
            super(MockAnsibleError, self).__init__(msg)

    class MockAnsibleLookupError(AnsibleLookupError):
        def __init__(self, msg, orig_exc=None):
            super(MockAnsibleLookupError, self).__init__(msg)

    class MockAnsibleOptionsError(AnsibleOptionsError):
        def __init__(self, msg, orig_exc=None):
            super(MockAnsibleOptionsError, self).__init__(msg)


# Generated at 2022-06-11 15:01:58.813928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["COLOR_OK"]) == [C.COLOR_OK]


# Generated at 2022-06-11 15:02:07.500457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a lookup instance
    lookup = LookupModule()
    # Create a set of dummy settings that can be used
    dummyConfig = {'dummy':'value'}
    # Create a dummy environment to be used in the run of the lookup
    dummyVars = {'dummyVar':'value'}
    # Create some dummy terms to be used as input
    dummyTerms = ['dummy']
    # Create a dummy plugin type
    dummyPluginType = 'dummyPluginType'
    # Create a dummy plugin name
    dummyPluginName = 'dummyPluginName'
    # Create a dummy action when a setting is missing
    dummyAction = 'error'


    #####
    # Test the run of lookup when the lookup has not been set up
    # Expect AnsibleOptionsError with message "Attempted to run without options set"

# Generated at 2022-06-11 15:02:09.918154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_obj = LookupModule()
  #  assert lookup_module_obj.run(["ANSIBLE_LOG_PATH"]) == [None]

# Generated at 2022-06-11 15:02:19.736795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    # Initialize Variables
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    lookup = lookup_loader.get('config')
    templar = Templar(loader=DataLoader(), variables=variable_manager, fail_on_undefined=True)
    play_context = PlayContext()
    play_context._init_vars()

    # Setup test configuration
    variable_manager.extra_vars = play_

# Generated at 2022-06-11 15:02:28.450744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    ansible_vars = dict(foo='foo', fuu='fuu')
    assert lookup_obj.run(terms=["DEFAULT_ROLES_PATH"], variables=ansible_vars, on_missing="skip", plugin_type="connection", plugin_name="ssh") == []
    assert lookup_obj.run(terms=["DEFAULT_ROLES_PATH"], variables=ansible_vars) == ['roles']
    assert lookup_obj.run(terms="DEFAULT_ROLES_PATH", variables=ansible_vars, on_missing="warn") == ['roles']
    assert lookup_obj.run(terms="foo", variables=ansible_vars, on_missing="warn") == []

# Generated at 2022-06-11 15:02:36.372890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    lookup = LookupModule()

    # unit test: look up configuration of a plugin
    lookup.set_options({'plugin_type': 'connection', 'plugin_name': 'local'})
    ret = lookup.run(terms=['ssh_args', 'accelerate_port'], inject={'ansible_verbosity': '0'})
    assert ret == [[], []]

    # unit test: look up configuration of a global variable
    lookup.set_options({})
    ret = lookup.run(terms=['DEFAULT_VAULT_IDENTITY_LIST'], inject={'ansible_verbosity': '0'})
    assert ret == [[]]

    # unit test: look up configuration of a non-existing plugin
   

# Generated at 2022-06-11 15:02:38.268804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()
    results = test_module.run(terms=['test','test2'], on_missing='error')
    assert results == []

# Generated at 2022-06-11 15:02:56.281055
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with a term that is not a string
    try:
        LookupModule().run([None])
    except AnsibleOptionsError as e:
        assert "Invalid setting identifier, \"None\" is not a string" in str(e)
    else:
        raise Exception("Should have raised an AnsibleOptionsError")

    # test with a bad on_missing value
    try:
        LookupModule().run(['bar'], {}, on_missing='other')
    except AnsibleOptionsError as e:
        assert "\"on_missing\" must be a string and one of \"error\", \"warn\" or \"skip\"" in str(e)
    else:
        raise Exception("Should have raised an AnsibleOptionsError")

# Generated at 2022-06-11 15:03:04.348560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock of constants C
    class MockC(object):
        def __init__(self):
            self.DEFAULT_BECOME_USER = 'root'
            self.DEFAULT_ROLES_PATH = ['/etc/ansible/roles']
            self.RETRY_FILES_SAVE_PATH = "/etc/ansible/retry"
            self.COLOR_OK = 'green'
            self.COLOR_CHANGED = 'yellow'
            self.COLOR_SKIP = 'blue'
            self.UNKNOWN = None
    mock_C = MockC()

    # create mock of config
    class MockConfig(object):
        def __init__(self):
            self.get_config_value = Mock(name='Config.get_config_value')
    mock_config = MockConfig()

    # create

# Generated at 2022-06-11 15:03:14.012404
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up test
    lookup_module = LookupModule()
    
    # set test vars
    terms = ['ANSIBLE_SOME_SETTING', 'some_setting']
    variables = {'ANSIBLE_SOME_SETTING': 'some_value'}
    kwargs = {'plugin_type':None, 'plugin_name':None}
    
    # run test
    ret = lookup_module.run(terms, variables, **kwargs)
    
    # check result is as expected
    assert len(ret) == 2
    assert ret[0] == 'some_value'
    assert ret[1] == None

# Generated at 2022-06-11 15:03:23.923391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Unit test: ansible.plugins.lookup.config.LookupModule.run()
    #
    import mock
    import unittest

    # Setup of Mocks
    mock_display = mock.MagicMock()

    # Tests

# Generated at 2022-06-11 15:03:26.812283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    result = lookup.run(terms, variables=None, **{})
    assert result[0] == C.DEFAULT_BECOME_USER

# Generated at 2022-06-11 15:03:35.314764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run method
    # - using the global constants
    # - using a plugin config
    # - using a plugin name and type
    # - play around with on_missing

    class TestLoader(object):
        # Just a dummy loader, when this is instantiated just return itself
        def __init__(self, *args, **kwargs):
            return self

        def get(self, pname, class_only=False):
            return self

        def _load_name(self):
            return 'test'

    class TestPlugin(object):
        # Dummy plugin
        pass

    import ansible.plugins.loader as loader
    loader.shell_loader = TestLoader()
    loader.shell_loader.get_plugin = TestPlugin
    TestPlugin.settings = {'test': 'success'}

    # Test with global constants
    lookup

# Generated at 2022-06-11 15:03:45.045743
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    C.DEFAULT_BECOME_USER = "test"
    C.DEFAULT_ROLES_PATH = ["test1","test2"]
    C.RETRY_FILES_SAVE_PATH = "/tmp"
    C.COLOR_OK = "#0000ff"
    C.COLOR_CHANGED = "#fff"
    C.COLOR_SKIP = "#3300ff"

    value = [module.run(['./test/test_playbook'])]
    assert value[0][0] == ['./test/test_playbook']

    value = [module.run(['test'])]
    assert value[0][0] == ['./test/test_playbook']

    value = [module.run(['DEFAULT_BECOME_USER'])]
    assert value

# Generated at 2022-06-11 15:03:52.436630
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    result = lookup.run('DEFAULT_ROLES_PATH')
    assert result[0] == C.DEFAULT_ROLES_PATH

    # result = lookup.run('DEFAULT_ROLES_PATH asdf')
    # assert result[0] == C.DEFAULT_ROLES_PATH

    result = lookup.run('DEFAULT_ROLES_PATH', on_missing='skip')
    assert result[0] == C.DEFAULT_ROLES_PATH

# Generated at 2022-06-11 15:04:03.355519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils._text import to_bytes, to_text
    test_lookup_module = LookupModule()
    # Test DEFAULT_BECOME_USER
    os.environ['ANSIBLE_BECOME_USER'] = to_bytes('test_become_user')
    ret = test_lookup_module.run(['DEFAULT_BECOME_USER'])
    become_user_settings = 'test_become_user'
    assert to_text(become_user_settings) in ret
    # Test DEFAULT_ROLES_PATH
    ret = test_lookup_module.run(['DEFAULT_ROLES_PATH'])
    assert 'roles' in to_text(ret[0])
    # Test RETRY_FILES_SAVE_PATH
   

# Generated at 2022-06-11 15:04:04.198192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()



# Generated at 2022-06-11 15:04:25.999368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_plugin_config_(*args, **kwargs):
        return "plugin_config"

    def _get_global_config_(*args, **kwargs):
        return "global_config"

    from ansible.plugins.loader import connection_loader
    from ansible.plugins.connection import ConnectionBase
    conn_loader_save = connection_loader.get
    connection_loader.get = lambda *args, **kwargs: ConnectionBase()
    pname = 'host'
    ptype = 'user'
    terms = [
        'something',
        'plugin_type',
        'plugin_name'
    ]
    variables = {
        'plugin_name': pname,
        'plugin_type': ptype
    }
    # Mock methods called from method run
    l = LookupModule()
    l.set_

# Generated at 2022-06-11 15:04:34.587206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_plugin(plugin_name, class_only=False):
        return class_only

    def mock_get_config_value(config, plugin_type=None, plugin_name=None, variables=None):
        return config

    plugin_loader.become_loader = mock_plugin
    C.config.get_config_value = mock_get_config_value

    ret = LookupModule.run(
        LookupModule(),
        terms=['DEFAULT_BECOME_USER', 'remote_tmp'],
        variables={},
        plugin_type='become',
        plugin_name='su'
    )

    assert ret == ['DEFAULT_BECOME_USER', 'remote_tmp']


# Generated at 2022-06-11 15:04:42.336395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check config with default value
    assert LookupModule().run(['DEFAULT_ROLES_PATH']) == ['/etc/ansible/roles']
    # check config with a boolean value
    assert LookupModule().run(['HOST_KEY_CHECKING']) == [C.HOST_KEY_CHECKING]
    # check config with an integer value
    assert LookupModule().run(['LAUNCH_TIMEOUT']) == [C.LAUNCH_TIMEOUT]

# Generated at 2022-06-11 15:04:53.953707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # Success: runs without error
    terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {}
    assert lm.run(terms, variables, **kwargs)
    # Success: runs without error: on_missing='error'
    kwargs = {'on_missing': 'error'}
    assert lm.run(terms, variables, **kwargs)
    # Failure: raises AnsibleOptionsError('"on_missing" must be a string')
    kwargs = {'on_missing': False}
    try:
        lm.run(terms, variables, **kwargs)
        test_failed = False
    except AnsibleOptionsError:
        test_failed = True
    assert test_failed
   

# Generated at 2022-06-11 15:05:01.017794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    # mock terms
    terms =  [ "DEFAULT_ROLES_PATH", "LOOKUP_PLUGINS_CONNECTION", "DEFAULT_COLLECTION_PATHS", "DEFAULT_NETCONF_PLUGIN" ]
    # mock variables
    variables = ImmutableDict(ansible_playbook_python=None)
    # mock run result
    results = [
        [u"/home/hduser/roles:/home/hduser/.ansible/roles:/usr/share/ansible/roles"],
        [u"env", u"file", u"native"],
        [u"/home/hduser/.ansible/collections"],
        [u"netconf"]
    ]
    # The test will fail, if

# Generated at 2022-06-11 15:05:09.314310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1: on_missing is provided, but not in the list of recognized values
    # Verify:
    # 1. 'AnsibleOptionsError' exception is raised
    # 2. Exception message is '"on_missing" must be a string and one of "error", "warn" or "skip", not dummy_on_missing'
    on_missing = 'dummy_on_missing'
    l = LookupModule()
    with pytest.raises(AnsibleOptionsError) as excinfo:
        l.run('dummy_term', on_missing=on_missing)
    assert 'must be a string and one of "error", "warn" or "skip"' in str(excinfo.value)
    assert 'not %s' % on_missing in str(excinfo.value)

    # Test case 2: term is not a string

# Generated at 2022-06-11 15:05:14.951445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()
    assert lookup_mock is not None

    from ansible.module_utils._text import to_bytes
    class DummyVarsModule:
        def __init__(self):
            self.OPTIONS = dict()
        def get_option(self, key):
            return self.OPTIONS[key]
        def __setitem__(self, key, value):
            self.OPTIONS[key] = value

    lookup_mock.set_options(direct=dict(plugin_type="connection", plugin_name="smart"))
    assert lookup_mock is not None

    vars_mock = DummyVarsModule()
    vars_mock['host_key_checking'] = 'yes'
    vars_mock['ANSIBLE_HOST_KEY_CHECKING']

# Generated at 2022-06-11 15:05:22.258995
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin = LookupModule(loader=None, variables=None)
    # test with valid arguments
    actual = plugin.run(terms=['ACTION_WARNINGS'], variables=None, **{'on_missing': 'warn'})
    assert actual == [True]
    # test with invalid arguments
    with pytest.raises(AnsibleOptionsError):
        plugin.run(terms=['ACTION_WARNINGS'], variables=None, **{'on_missing': 'foo'})

# Generated at 2022-06-11 15:05:29.435032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    pname = 'shell'
    ptype = 'become'


# Generated at 2022-06-11 15:05:38.994072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Here are the types of config
    #   BOOLEAN_True
    #   BOOLEAN_False
    #   PATH
    #   LIST
    #   SET
    #   STRING
    #   INT

    # Uncomment below to test with the real config (you will need to comment out the mock config)
    # from ansible import constants as C
    # print(C.DEFAULT_DEBUG_STRING)

    # Mock config
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.utils.path import unfrackpath
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display


# Generated at 2022-06-11 15:06:07.895329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:06:17.684512
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def get_plugin_loader(loader_type):
        # Since plugin loader imports more plugins, we need to mock it
        class MockPluginLoader:
            def __init__(self):
                self.cache = {}

            def get(self, pname, class_only=True):
                if pname not in self.cache:
                    class MockPlugin:
                        def __init__(self, pname):
                            self._load_name = pname

                    self.cache.update({pname: MockPlugin(pname)})
                return 1 if class_only else self.cache[pname]

        return MockPluginLoader()

    p = plugin_loader._get_all_plugin_loaders()
    plugin_loader._PLUGIN_CACHE = {}

# Generated at 2022-06-11 15:06:21.220925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    result = lm.run(["DEFAULT_REMOTE_TMP"])
    assert result[0] == '$HOME/.ansible/tmp'

# Generated at 2022-06-11 15:06:31.888714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_bytes

    # initialize required objects
    lookup = LookupModule()
    lookup.display = pytest.Mock()
    lookup.set_options(var_options={}, direct={})

    # case where term is not string
    with pytest.raises(AnsibleOptionsError):
        lookup.run([["ansible_connection", "local"], "DEFAULT_REMOTE_USER"], variables=None)
    # case where on_missing is not a string
    with pytest.raises(AnsibleOptionsError):
        lookup.run(["ansible_connection", "DEFAULT_REMOTE_USER"], variables=None, on_missing=10)
    # case where on_missing is not one of ['error', 'warn', 'skip']

# Generated at 2022-06-11 15:06:43.491452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    pname = 'ssh'
    ptype = 'connection'

    # test with terms as list
    terms = ['remote_user', 'port', 'parameter_that_does_not_exist']
    variables = dict()
    kwargs = dict(on_missing='warn', plugin_type=ptype, plugin_name=pname)
    result = lookup.run(terms, variables, **kwargs)
    assert result == [C.REMOTE_USER, C.DEFAULT_SSH_PORT]

    # test with terms as string
    terms = 'remote_user'
    variables = dict()
    kwargs = dict(on_missing='warn', plugin_type=ptype, plugin_name=pname)
    result = lookup.run(terms, variables, **kwargs)
    assert result

# Generated at 2022-06-11 15:06:51.221497
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test Call: LookupModule_run(["DEFAULT_REMOTE_TMP"])
    # Expected result: None
    # Current Result: None
    assert LookupModule.run(["DEFAULT_REMOTE_TMP"]) == None

    # Test Call: LookupModule_run(["DEFAULT_ROLES_PATH"])
    # Expected result: None
    # Current Result: None
    assert LookupModule.run(["DEFAULT_ROLES_PATH"]) == None

    # Test Call: LookupModule_run(["UNKNOWN_CONFIG_SETTING"])
    # Expected result: AnsibleLookupError
    # Current Result: None
    try:
        LookupModule.run(["UNKNOWN_CONFIG_SETTING"])
    except AnsibleLookupError:
        pass

# Generated at 2022-06-11 15:07:03.660347
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _get_config(_self, config):
        return config

    # Add method to class LookupModule that is needed for testing
    def _set_global_config(_self, config):
        setattr(C, config, config)

    LookupModule._get_global_config = _get_config
    LookupModule.set_options = classmethod(_set_global_config)

    lookup_plugin_obj = LookupModule()
    lookup_plugin_obj._get_plugin_config = _get_config
    lookup_plugin_obj._display.warning = lambda warning: None  # Don't print warnings during test


# Generated at 2022-06-11 15:07:07.113514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tmp = LookupModule()
    terms = 'DEFAULT_BECOME_USER'
    variables = dict()
    variables["DEFAULT_BECOME_USER"] = "test"
    result = tmp.run(terms, variables)
    assert result == [variables["DEFAULT_BECOME_USER"]]



# Generated at 2022-06-11 15:07:16.420160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    result = lookup.run(terms)
    assert result == ['root']
    lookup = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    result = lookup.run(terms)
    assert isinstance(result, list)
    lookup = LookupModule()
    terms = ['UNKNOWN']
    try:
        result = lookup.run(terms)
    except AnsibleLookupError as e:
        assert e.message == 'Unable to find setting UNKNOWN'
    lookup = LookupModule()
    terms = ['UNKNOWN']
    result = lookup.run(terms, on_missing='warn')
    lookup = LookupModule()
    terms = ['UNKNOWN']

# Generated at 2022-06-11 15:07:26.378261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    new_inst = LookupModule()
    # Config file
    config_file_path = "tests/data/json_test.json"
    # Ansible config path
    config_path = "tests/data"
    # Ansible-config path set
    set_val = C.config.set_config_path(config_path)
    assert set_val == True

    # Refreshing ansible configuration data
    config = C.config
    config.load(config_file_path)

    # Hit the test
    test_terms = "config_settings"
    actual_result = new_inst.run(terms=test_terms, variables={})
    assert actual_result[0].get('config_settings') == {'settings': '123456'}


# Generated at 2022-06-11 15:08:37.445481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given a empty config, with default option value
    term = 'DEBUG'
    plugin_type = None
    plugin_name = None
    missing = 'error'
    config = {'plugin_type': plugin_type, 'plugin_name': plugin_name, 'on_missing': missing}
    ## Doesn't work, cannot access the value of module, how do we mock it?
    # When I look up the module
    # Then it should return error
    assert C.DEFAULT_DEBUG == 'False'
    # And I look up with True
    deafult = 'True'
    assert deafult == 'True'
    # Then it should return True

## http://pytest.org/latest/skipping.html
#@pytest.mark.skipif(condition, reason=None)
#def test_LookupModule_run():
#

# Generated at 2022-06-11 15:08:43.167601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = LookupModule()
    terms = ['short_description']
    ret = p.run(terms=terms)
    assert isinstance(ret, list)
    #p = LookupModule()
    #terms = ['c']
    #ret = p.run(terms=terms)

# Generated at 2022-06-11 15:08:46.325930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pname = "ssh"
    ptype = "connection"
    terms = ["remote_tmp"]
    lookup = LookupModule()
    result = lookup.run(terms, plugin_name=pname, plugin_type=ptype)
    assert False is not result


# Generated at 2022-06-11 15:08:50.543805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # 1. test for global config
    assert lookup.run(['ONLINE_CONFIG_PLUGINS'], []).pop() == False
    # 2. test for plugin config
    assert lookup.run(['remote_user'], [], plugin_type='connection', plugin_name='local').pop() == ''

# Generated at 2022-06-11 15:09:01.896502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # valid global term with valid on_missing
    terms = 'ANSIBLE_LIBRARY'
    on_missing = 'warn'
    # valid global term with valid on_missing
    result = lookup_module.run(terms, on_missing=on_missing)
    assert result
    assert isinstance(result[0], string_types)
    # valid global term with invalid on_missing
    with pytest.raises(AnsibleOptionsError):
        on_missing = 'error_missing'
        lookup_module.run(terms, on_missing=on_missing)
    # non string terms
    terms = [1]
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms)
    # valid plugin term

# Generated at 2022-06-11 15:09:14.530232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(
        [(i,) for i in ('''
            DEFAULT_BECOME_USER
            DEFAULT_ROLES_PATH
            RETRY_FILES_SAVE_PATH
            COLOR_OK
            COLOR_CHANGED
            COLOR_SKIP
            UNKNOWN
            '''.split()
        )],
        on_missing='skip',
    ) == [
        'root',
        'roles',
        '/var/lib/awx/.ansible/retry',
        'green',
        'dark yellow',
        'cyan',
    ]

# Generated at 2022-06-11 15:09:22.612388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleMapping

    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import LookupModule

    FakeVarsModule = namedtuple('VarsModule', ['vars'])
    FakePlayContext = namedtuple('FakePlayContext', ['vars', 'connection'])
    FakeOptions = namedtuple('FakeOptions', ['connection'])
    FakeConnection = namedtuple('FakeConnection', ['transport'])

    FakePlayContextVars = namedtuple('FakePlayContextVars', ['setdefault', 'update'])


# Generated at 2022-06-11 15:09:31.292666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(argument_spec=dict(
        _raw_params=dict(type='str', required=True),
        _uses_shell=dict(type='bool', required=False),
        _tmp_path=dict(type='str', required=False)
    ))
    lookup_module = LookupModule()
    lookup_module.set_environment(module._tmp_path, module._uses_shell)
    terms = 'ANSIBLE_TEST_INI_FILE'
    result = lookup_module.run(terms)
    module.exit_json(term=terms, result=result)


# Generated at 2022-06-11 15:09:38.883078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  The following configuration should be taken from the ansible.cfg, which should be present in the same directory
    config = {'lookup_plugins': './lookup_plugins', 'roles_path': './roles'}
    terms = ['DEFAULT_ROLES_PATH']
    lookup = LookupModule()
    lookup._get_plugin_config = _get_plugin_config
    lookup._display = Display()
    lookup.set_options(var_options=None, direct=config)
    results = lookup.run(terms=terms)
    assert results == config['roles_path']



# Generated at 2022-06-11 15:09:47.899308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test method run of class LookupModule
    '''
    t_lookup_module = LookupModule()
    arg_module = [
        'DEFAULT_ROLES_PATH',
        'COLOR_OK',
        'COLOR_CHANGED',
        'COLOR_SKIP'
    ]
    arg_variables = {}
    arg_kwargs = {}
    result = t_lookup_module.run(arg_module, arg_variables, **arg_kwargs)
    assert result[0] == 'DEFAULT_ROLES_PATH'
    assert result[1] == 'COLOR_OK'
    assert result[2] == 'COLOR_CHANGED'
    assert result[3] == 'COLOR_SKIP'