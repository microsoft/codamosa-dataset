

# Generated at 2022-06-11 15:01:38.370136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display

    class TestLookupModule_run(unittest.TestCase):

        def test_LookupModule_run(self):
            import ansible.utils.simplejson as json
            from ansible.parsing.yaml.loader import AnsibleLoader
            from io import StringIO


            class MockVariableManager:
                def __init__(self):
                    self.vars = {}


# Generated at 2022-06-11 15:01:44.490204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    test the basic functionality of run method
    '''
    print('Testing LookupModule.run')
    lookup_module = LookupModule()
    try:
        lookup_module.run(['DEFAULT_ROLES_PATH'],['/etc/ansible/roles'])
    except (AnsibleLookupError,AnsibleOptionsError,MissingSetting) as e:
        pass
    else:
        print('Passed')


# Generated at 2022-06-11 15:01:53.916024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest
    sys.modules['ansible'] = pytest.Mock()
    sys.modules['ansible.plugins'] = pytest.Mock()
    sys.modules['ansible.plugins.loader'] = pytest.Mock()
    sys.modules['ansible.utils'] = pytest.Mock()
    sys.modules['ansible.module_utils'] = pytest.Mock()
    sys.modules['ansible.module_utils.six'] = pytest.Mock()
    sys.modules['ansible.utils.sentinel'] = pytest.Mock()
    sys.modules['ansible.plugins.lookup'] = pytest.Mock()
    import ansible.plugins.lookup.config as config
    sys.modules['ansible.plugins.lookup.config'] = config
    l

# Generated at 2022-06-11 15:01:59.055363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_options = {}
    direct = {}
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    self = LookupModule(None, var_options, direct)
    result = self.run(terms, None)
    assert result == ['root', ['/Users/kranthi/ansible_practice/ansible_practice/roles']]
    self.set_options(var_options, direct)

# Generated at 2022-06-11 15:02:06.768053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    global_config = ['RETRY_FILES_ENABLED']
    all_config = global_config + ['remote_host']
    assert lu.run(global_config, on_missing='warn')[0] is False
    assert lu.run(all_config, on_missing='warn')[1] == '127.0.0.1'
    assert lu.run(['shell_executable'], plugin_type='shell', plugin_name='sh') == ['sh']
    assert lu.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == ['$HOME/.ansible/tmp']

# Generated at 2022-06-11 15:02:17.072717
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1
    lookup_obj = LookupModule()
    result = lookup_obj.run([])
    assert result == []

    # test case 2
    lookup_obj = LookupModule()
    result = lookup_obj.run(['host_record_facts'])
    assert result == ['yes']

    # test case 3
    lookup_obj = LookupModule()
    result = lookup_obj.run(['host_record_facts', 'host_record'])
    assert result == ['yes', '/var/log/ansible-host-record.log']

    # test case 4
    lookup_obj = LookupModule()
    result = lookup_obj.run(['host_record_facts', 'host_record', 'plugin_type'])

# Generated at 2022-06-11 15:02:22.204639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        '_terms': ['stdout_callback'],
        'on_missing': 'error',
        'plugin_type': 'callback',
        'plugin_name': 'default',
    }
    lm = LookupModule()
    lm.set_loader({})
    lm.set_options(var_options={})
    result = lm.run(**args)
    assert len(result) == 1
    assert result[0] == 'default'

# Generated at 2022-06-11 15:02:31.898810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible.plugins.lookup import LookupBase
    except ImportError:
        # Ansible 2.4
        from ansible.plugins import LookupBase

    # Dummy class that extends LookupModule
    class MockLookupModule(LookupBase):
        def __init__(self):
            self._display = None
            self._options = None
            self._loader = None

    # Dummy ansible.constants object
    class MockAnsibleConstants:
        def get_config_value(self, term, plugin_type='', plugin_name='', variables=None):
            if term == 'term1':
                return "123"
            elif term == 'term2':
                return "456"
            elif term == 'term3':
                return "789"
            return ""

    # Create a

# Generated at 2022-06-11 15:02:38.375750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _get_plugin_config_old = LookupModule._get_plugin_config
    _get_global_config_old = LookupModule._get_global_config

# Generated at 2022-06-11 15:02:47.570378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({})
    assert lookup_module.run(["DEFAULT_SUDO_USER"], {}) == [u'root']
    assert lookup_module.run(["DEFAULT_SUDO_USER"], {'on_missing': 'error'}) == [u'root']
    assert lookup_module.run(["DEFAULT_SUDO_USER", 'RETRY_FILES_SAVE_PATH'], {'on_missing': 'error'}) == [u'root', u'~/.ansible/retry']
    assert lookup_module.run(["UNKNOWN"], {'on_missing': 'error'}) == []
    assert lookup_module.run(["UNKNOWN"], {}) == []

# Generated at 2022-06-11 15:03:01.653829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["DEFAULT_BECOME_USER"]
    variables = {"var": "value", "DEFAULT_BECOME_USER": "sudo"}
    result = module.run(terms, variables=variables)
    assert result[0] == "sudo"


# Generated at 2022-06-11 15:03:07.439675
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        # Test methods
        if constants.__version__ >= '2.9':
            _get_plugin_config('set_fact', 'vars', 'set_fact_file', '')
            _get_global_config('CACHE_PLUGIN_FILENAME')
            p = LookupModule()
            p.set_options()
            p.get_option('blah')
    except Exception as e:
        raise e

# Generated at 2022-06-11 15:03:14.907706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['remote_tmp', 'port', 'remote_user']
    ptype = 'shell'
    pname = 'sh'
    # without plugin_type and plugin_name
    lookup_module = LookupModule()
    assert lookup_module.run(terms) == ['/tmp', '', 'root']
    # with plugin_type and plugin_name
    lookup_module.run(terms, plugin_type=ptype, plugin_name=pname) == ['/tmp', 22, 'root']

# Generated at 2022-06-11 15:03:24.861007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(['DEFAULT_ROLES_PATH'])
    assert isinstance(result, list)
    assert isinstance(result[0], string_types)
    assert result[0] == '/etc/ansible/roles:/usr/share/ansible/roles'
    result_plugin_1 = module.run(['remote_tmp'], plugin_type='shell', plugin_name='sh')
    assert isinstance(result_plugin_1, list)
    assert isinstance(result_plugin_1[0], string_types)
    assert result_plugin_1[0] == '/tmp'
    result_plugin_2 = module.run(['remote_user', 'port'], plugin_type='connection', plugin_name='ssh') 

# Generated at 2022-06-11 15:03:32.718091
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    def setup_mock_loader(type, result):
        loader = mock.MagicMock()
        loadexists = mock.MagicMock(return_value=True)
        loaderget = mock.MagicMock(return_value=result)
        loader.get = loaderget
        loader.exists = loadexists
        loader.__contains__ = loadexists
        ldict = {'connection_loader': loader}
        pdict = {'%s_loader' % type: loader}
        mock_plugin_loader = mock.MagicMock()
        mock_plugin_loader.__getitem__.side_effect = lambda x: pdict[x]

# Generated at 2022-06-11 15:03:42.596822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ unit testing for method run of class LookupModule """
    module = LookupModule()

    # testing conditions specified in documentation.
    # lookup('config', 'DEFAULT_BECOME_USER')
    terms = ['DEFAULT_BECOME_USER']
    result = module.run(terms)
    assert result[0] == C.DEFAULT_BECOME_USER

    # lookup('config', 'DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS')
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS']
    result = module.run(terms)
    assert result[0] == C.DEFAULT_BECOME_USER
    assert result[1] == C.DEFAULT_BECOME_PASS

    # lookup('config', 'remote_user', '

# Generated at 2022-06-11 15:03:53.245957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()

    # Testing with a global configuration that exists
    term = 'DEFAULT_RETRY_FILES_ENABLED'
    result = lookup_mod.run([term], {})
    assert result == [C.RETRY_FILES_ENABLED]

    # Testing with a global configuration that does not exist
    term = 'FAKE'
    try:
        lookup_mod.run([term], {})
    except AnsibleLookupError as e:
        assert 'Unable to find setting %s' % term == e.message
    else:
        raise AssertionError("AnsibleLookupError not raised")

    # Testing with a plugin configuration that exists
    term = 'connection_retry_interval'
    ptype = 'connection'
    pname = 'local'
    result = lookup

# Generated at 2022-06-11 15:04:03.754188
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test invalid config
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'on_missing': 'invalid'})
    try:
        lookup_plugin.run(terms=['invalid'])
    except AnsibleOptionsError as e:
        assert e.message == 'Invalid setting identifier, "invalid" is not a string, its a <class \'str\'>'
    except Exception:
        assert False

    # Test invalid config
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'on_missing': 'invalid'})
    try:
        lookup_plugin.run(terms=[10])
    except AnsibleOptionsError as e:
        assert e.message == 'Invalid setting identifier, "10" is not a string, its a <class \'int\'>'


# Generated at 2022-06-11 15:04:15.159906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    loader = plugin_loader.get('lookup')
    lookup = loader.get('config')
    # missing setting
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-11 15:04:15.783252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0

# Generated at 2022-06-11 15:04:42.941681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests global settings
    assert LookupModule.run(LookupModule(), terms=['DEFAULT_ROLES_PATH']) == [['~/.ansible/roles:/usr/share/ansible/roles']]
    assert LookupModule.run(LookupModule(), terms=['DEFAULT_ROLES_PATH', 'DEFAULT_SKIP_TAGS']) == [['~/.ansible/roles:/usr/share/ansible/roles'], ['skip_tags']]
    assert LookupModule.run(LookupModule(), terms=['UNKNOWN_OPTION_FOR_TESTING_PURPOSE'], on_missing='error') == LookupError

    # Tests global settings on_missing=warn

# Generated at 2022-06-11 15:04:54.510456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    lookup = LookupModule()
    val = ['foo', 'bar']

    # Test error on not string terms
    terms = [dict(), list()]
    with mock.patch.object(LookupBase, 'set_options') as mock_set_options:
        mock_set_options.return_value = None
        with pytest.raises(AnsibleOptionsError) as exinfo:
            lookup.run(terms=terms)
    assert 'Invalid setting identifier' in str(exinfo.value)

    # Test error on invalid on_missing value
    lookup = LookupModule()
    terms = ['foo']
    with mock.patch.object(LookupBase, 'set_options') as mock_set_options:
        mock_set_options.return_value = None

# Generated at 2022-06-11 15:05:01.016694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a missing setting -
    # 1. on_missing="error", expect exception should be raised
    # 2. on_missing="warn" expect warning should be printed
    # 3. on_missing="skip", expect an empty list should be returned
    lookup = LookupModule()

    # 1. test with on_missing="error", expect an exception should be raised
    try:
        lookup.run(terms='FAKE_SETTING', on_missing='error')
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)
        assert e.message == 'Unable to find setting FAKE_SETTING'

    # 2. test with on_missing="warn", expect a warning should be printed
    lookup._display.warning = lambda x: x

# Generated at 2022-06-11 15:05:09.314076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._display = MockDisplay()
    lookup._get_plugin_config = lambda pname, ptype, config, variables: 'pconfig'
    lookup._get_global_config = lambda config: 'gconfig'
    lookup.run = mock.Mock(side_effect=lookup.run)

    # happy path, return global config
    res = lookup.run(['foo'])
    assert res == ['gconfig']
    lookup.run.assert_called_once_with(['foo'], variables=None, on_missing='error', plugin_type=None, plugin_name=None)

    # happy path, return plugin config
    res = lookup.run(['foo'], on_missing='warn', plugin_type='role', plugin_name='fooname')
    assert res == ['pconfig']


# Generated at 2022-06-11 15:05:15.164948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test to see if lookup module can be run.
    """
    lookup_module = LookupModule()
    term = 'DEFAULT_NETWORK_OS'
    assert 'ios' == lookup_module.run([term])[0]
    term = 'DEFAULT_NETWORK_OS'
    assert 'ios' == lookup_module.run([term], plugin_type='cliconf', plugin_name='ios')[0]


# Generated at 2022-06-11 15:05:18.004308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']

# Generated at 2022-06-11 15:05:27.440911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader

# Generated at 2022-06-11 15:05:38.004773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup args
    terms = ['DEFAULT_BECOME_USER']
    ptype = 'become'
    pname = 'become_user'
    pload = 'become_user'
    missing = 'skip'

    # Setup return values
    expected_result = 'root'
    expected_ret = [expected_result]

    # Setup test context

    # Setup mocks
    mock_C = Mock()
    mock_C.__getattribute__.return_value = expected_result
    mock_plugin_loader = Mock()
    mock_loader = Mock()
    mock_loader.get.return_value = Mock()
    mock_loader.get.return_value.__dict__ = {'_load_name': pload}
    mock_plugin_loader.__getattribute__.return_value = mock_loader



# Generated at 2022-06-11 15:05:47.875464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get the class
    lookup_module = LookupModule()

    # Get the default path of the file
    default_file = lookup_module.get_option('file')
    assert default_file is None, "Default option value of file is wrong: expected: None, got: %s" % default_file

    # Check if the default config is empty
    default_config = lookup_module.get_option('config')
    assert default_config is None, "Default config value is wrong: expected: None, got: %s" % default_config

    # Check if the default value of validate is empty
    default_validate = lookup_module.get_option('validate')
    assert default_validate is None, "Default value of validate is wrong: expected: None, got: %s" % default_validate

    # Check if key_name is a

# Generated at 2022-06-11 15:05:49.846295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['DEFAULT_BECOME_USER']) == ['root']

# Generated at 2022-06-11 15:06:27.182708
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _get_plugin_config_side_effect(pname, ptype, config, variables):
        if ptype == 'connection' and pname == 'ssh' and config == 'remote_user':
            return 'ansible_user'
        elif pname == 'ssh' and config == 'port':
            return 22
        elif ptype == 'shell' and config == 'remote_tmp':
            return '/tmp/ansible-${USER}'
        else:
            return Sentinel

    lookup_mock = plugin_loader.LookupModule()
    lookup_mock.run.side_effect = lambda terms, variables=None, **kwargs: terms
    lookup_mock.set_options.return_value = None

    C.overrides = dict()
    C.DEFAULT_REMOTE_USER = 'ansible_default'

# Generated at 2022-06-11 15:06:37.827365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global C
    C = Sentinel
    import ansible.utils.sentinel as sentinel
    from ansible.errors import AnsibleLookupError

    class Options(sentinel.Sentinel):
        def __init__(self):
            sentinel.Sentinel.__init__(self, dict(
                on_missing='error',
                plugin_type=None,
                plugin_name=None,
            ))
        def __delitem__(self, key):
            pass

    my_options = Options()

    class PluginLoaderSentinel(sentinel.Sentinel):
        def get(self, *args, **kwargs):
            pass

    class SentinelPluginsLoader(sentinel.Sentinel):
        become_loader = PluginLoaderSentinel()
        cache_loader = PluginLoaderSentinel()
        callback_loader = PluginLoaderSentinel()


# Generated at 2022-06-11 15:06:48.592268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    search_result = "test"
    global_config = 'result'

    def test_normal_plugin_result(var_name):
        if var_name == 'test':
            return search_result

    def test_normal_global_config(var_name):
        if var_name == 'test':
            return 'test_test_test'

    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms)

        def _get_plugin_config(self, pname, ptype, config, variables):
            return test_normal_plugin_result(config)

        def _get_global_config(self, config):
            return test_normal_global_config(config)

    assert TestLookupModule().run

# Generated at 2022-06-11 15:07:00.659885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test LookupModule's method run (with success)
    print('Test LookupModule\'s method run (with success)')
    lm = LookupModule()
    lm._display.verbosity = 3
    terms = ['vault_password_file']
    try:
        print(lm.run(terms))
    except AnsibleLookupError as e:
        print(e)
        print('Test failed !')

    # Test LookupModule's method run (with failure)
    print('\nTest LookupModule\'s method run (with failure)')
    lm = LookupModule()
    lm._display.verbosity = 3
    terms = ['settings_file']
    try:
        print(lm.run(terms))
    except AnsibleLookupError as e:
        print(e)
        print

# Generated at 2022-06-11 15:07:06.696936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = {'plugin_type': 'cache', 'plugin_name': 'memory'}
    config_in_var = {'config_in_var': 'UNKNOWN'}
    variables = {'playbook_dir': 'playbook_dir'}
    lm = LookupModule()
    result = lm.run([config['plugin_type'], config['plugin_name'], config_in_var['config_in_var']], variables, **config)
    assert isinstance(result, list)


# Generated at 2022-06-11 15:07:16.308614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.parsing.plugin_docs import read_docstub
    from ansible.plugins.loader import lookup_loader
    doc, plainexamples, returndocs, metadata = read_docstub(LookupModule)

    if 'options' in metadata:
        del metadata['options']
    if 'extends_documentation_fragment' in metadata:
        del metadata['extends_documentation_fragment']
    if 'version_added' in metadata:
        del metadata['version_added']


# Generated at 2022-06-11 15:07:26.346416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    C.ANSIBLE_ROLES_PATH = '/etc/ansible/roles'
    C.REMOTE_USER = 'test_user'
    C.INVENTORY_UNPARSED_FAILED = False
    C.DEFAULT_VAULT_ID_MATCH = '^(?!common)([^:]+)(?:\\:.*)?$'
    C.HOST_KEY_CHECKING = False

    try:
        config = LookupModule()
        assert isinstance(config, LookupModule)
    except NameError as e:
        assert False, 'LookupModule class not found'
    except AttributeError as e:
        assert False, 'LookupModule class does not have run method'


# Generated at 2022-06-11 15:07:37.861682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = LookupModule()


    # test_LookupModule_run_different_terms test
    terms = ['DEFAULT_BECOME_USER','DEFAULT_ROLES_PATH','RETRY_FILES_SAVE_PATH','COLOR_OK','COLOR_CHANGED','COLOR_SKIP']
    result = config.run(terms=terms)
    assert result == ['root', ['/etc/ansible/roles', u'../'], u'~/', 'green', 'dark yellow', 'cyan'], "Expected: ['root', ['/etc/ansible/roles', u'../'], u'~/', 'green', 'dark yellow', 'cyan'], Actual: " + str(result)

    # test_LookupModule_run_on_missing_error test

# Generated at 2022-06-11 15:07:42.029713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms=["DEFAULT_BECOME_USER"]
    variables=None
    kwargs=None
    result = lookup_plugin.run(terms,variables,**kwargs)
    assert result == ['root']

# Generated at 2022-06-11 15:07:43.433362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Implement this unit test
    pass

# Generated at 2022-06-11 15:08:55.276564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test value from _get_plugin_config
    val = _get_plugin_config('connection', 'connection', 'forks', variables={})
    assert val == C.DEFAULT_FORKS

    # test value from _get_global_config
    val = _get_global_config('DEFAULT_ROLES_PATH')
    assert val == C.DEFAULT_ROLES_PATH

    # test with plugin_type and plugin_name
    ret = lookup.run([
        'remote_user',
        'port',
        'plugin_type=connection',
        'plugin_name=ssh',
        'on_missing=skip',
    ],
        variables={},
    )
    assert len(ret) == 2
    assert ret[0] == C.DEFAULT_REMOTE_USER
   

# Generated at 2022-06-11 15:09:07.147022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for ansible.plugins.lookup.config.LookupModule.run(terms, variables=None, **kwargs)
    # Here, we only test for one specific case:
    # When the first two arguments (`terms` and `variables`) are strings

    # This is the unit test data
    gVariables = "bar"
    gTerms = "foo"
    gKwargs = {'on_missing': 'error'}

    # Here is the answer we expect
    gAnswer = AnsibleLookupError

    # Create the object used for testing
    testObj = LookupModule()

    # Run the test
    try:
        testObj.run(gTerms, gVariables, **gKwargs)
    except gAnswer:
        print("Test pass!")

# Generated at 2022-06-11 15:09:14.677395
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:09:22.687435
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_run(
            config_vars,
            terms,
            plugin_type,
            plugin_name,
            on_missing,
            want_ret
    ):
        from ansible.plugins.loader import callback_loader
        from ansible.plugins.loader import lookups_loader

        m = LookupModule()
        m.set_options(variables=config_vars, plugin_type=plugin_type, plugin_name=plugin_name, on_missing=on_missing)
        assert m.run(terms) == want_ret

    config_vars = dict(ANSIBLE_CALLBACK_WHITELIST='timer', ANSIBLE_STDOUT_CALLBACK='timer')
    plugin_type = 'callback'

    # test plugin_type and plugin_name

# Generated at 2022-06-11 15:09:24.617748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    l = LookupModule()
    l.run(terms)

# Generated at 2022-06-11 15:09:29.030376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    setattr(module, 'get_option', lambda x: 'error')
    try:
        module.run([1, 2, 3], None, on_missing='bad')
        assert False
    except AnsibleOptionsError:
        assert True

# Generated at 2022-06-11 15:09:39.049577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup = lookup_loader.get('config')
    assert lookup

    inventory = Host(name="test", port=1234)
    variable_manager = VariableManager()
    loader = DataLoader()

    def get_plugin_config(plugin_name):
        """Return a dummy configuration for the plugin"""
        if plugin_name == 'ssh':
            return {'remote_user': 'ansible',
                    'port': 1234}
        elif plugin_name == 'sh':
            return {'remote_tmp': '/dev/null'}
        else:
            return {}

    variable_manager._extra_vars

# Generated at 2022-06-11 15:09:48.544942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for ansible.plugins.lookup.config.LookupModule.run() """

    # test missing setting
    module = LookupModule()
    terms = ['NOT_VALID']
    try:
        module.run(terms=terms)
    except AnsibleLookupError as e:
        assert 'Unable to find setting NOT_VALID' in str(e)
    else:
        assert False, 'Expecting an AnsibleLookupError exception'

    # test setting with explicit on_missing='error'
    module = LookupModule()
    terms = ['NOT_VALID']
    try:
        module.run(terms=terms, on_missing='error')
    except AnsibleLookupError as e:
        assert 'Unable to find setting NOT_VALID' in str(e)
    else:
        assert False

# Generated at 2022-06-11 15:09:59.503008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # plugin_type and plugin_name set
    lm.set_options(var_options=None, direct={'plugin_type': 'become', 'plugin_name': 'sudo'})
    results = lm.run([C.DEFAULT_BECOME_USER, C.DEFAULT_BECOME_METHOD, C.DEFAULT_BECOME_PASS], variables={C.DEFAULT_BECOME_USER: 'toto'})
    assert results == ['toto', 'sudo', None]

    # Missing setting
    with pytest.raises(AnsibleLookupError):
        results = lm.run([C.DEFAULT_BECOME_USER, 'unknown_setting'], variables={C.DEFAULT_BECOME_USER: 'toto'})

    # missing 'plugin

# Generated at 2022-06-11 15:10:10.462922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["ANSIBLE_CONFIG"]
    ret = lookup_module.run(terms)
    assert isinstance(ret, list) and len(ret) == 1 and isinstance(ret[0], string_types) and ret[0] == C.ANSIBLE_CONFIG
    terms = ["ANSIBLE_CONFIG", "ANSIBLE_CONFIG"]
    ret = lookup_module.run(terms)
    assert isinstance(ret, list) and len(ret) == 2 and isinstance(ret[0], string_types) and ret[0] == C.ANSIBLE_CONFIG and isinstance(ret[1], string_types) and ret[1] == C.ANSIBLE_CONFIG
    #TODO: It would be nice to test lookup_module.run with a plugin, but it's not so easy