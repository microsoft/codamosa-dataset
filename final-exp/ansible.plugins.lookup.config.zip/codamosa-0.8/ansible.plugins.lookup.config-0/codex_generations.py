

# Generated at 2022-06-11 15:01:37.714822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import text_type

    assert plugin_loader is not None

    result = LookupModule().run(terms=['DEFAULT_ROLES_PATH'], variables={})
    assert type(result[0]) is list

    result = LookupModule().run(terms=['DEFAULT_BECOME_USER'], variables={})
    assert type(result[0]) is text_type

    result = LookupModule().run(terms=['UNKNOWN_SETTING'], variables={}, on_missing='skip')
    assert result == []

    result = LookupModule().run(terms=['INVALID_ON_MISSING'], variables={}, on_missing='invalid')
    assert result == []


# Generated at 2022-06-11 15:01:48.277218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with valid config, should return result of config
    terms = ['DEFAULT_ROLES_PATH']
    variables = dict()
    variables['CWD'] = '.'
    variables['DEFAULT_ROLES_PATH'] = '/data/playbooks/roles:/data/playbooks/roles2'
    ret = lookup_module.run(terms, variables)
    assert ret[0] == variables['DEFAULT_ROLES_PATH']

    # Test with invalid config, should raise error
    terms = ['INVALID_CONFIG']
    try:
        lookup_module.run(terms, variables)
    except AnsibleLookupError:
        pass
    except Exception as e:
        raise AssertionError(e)

    # Test with invalid config, should skip because of on_

# Generated at 2022-06-11 15:01:56.217411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import yaml

    sys.path.append('../plugins/lookup/')
    sys.path.append('../plugins/')
    look = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    play_context = {}
    play_context['project_path'] = 'project_path'
    play_context['playbook_dir'] = 'playbook_dir'

    # Test with the first term in the list of terms
    terms_0 = terms[0]
    result = look.run(terms_0, play_context)
    expected_result = [play_context['playbook_dir'] + '/roles']
    assert result == expected_result, "The result should be '" + str(expected_result) + "'"

    # Test with all the terms in the list of terms
   

# Generated at 2022-06-11 15:01:57.029572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: complete test
    pass

# Generated at 2022-06-11 15:01:58.651545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Takes two arguments
    assert len(LookupModule.run.__code__.co_varnames) == 3

# Generated at 2022-06-11 15:02:07.396103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = plugin_loader.lookup_loader.get('config', class_only=True)
    l = p()
    result = l.run([],{'variable':'date'})
    assert isinstance(result,list)
    assert result == []
    result = l.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'],{'variable':'date'})
    assert isinstance(result,list)
    assert result != []
    assert result[0] == C.DEFAULT_ROLES_PATH
    assert result[1] == C.DEFAULT_BECOME_USER
    result = l.run(['unknown_key'])
    assert isinstance(result,list)
    assert result == []

# Generated at 2022-06-11 15:02:17.782766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    keys = ['a', 'b']
    config = {'host_key_checking': False, 'h': {'default_user': 'test', 'b': 'test1'}, 'a': 'test2'}

# Generated at 2022-06-11 15:02:25.739772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupBase()
    lookup_mock.set_options({})
    lookup_mock.get_option = lambda option: 'error'
    assert lookup_mock.run([]) == []
    assert lookup_mock.run(123) == []
    assert lookup_mock.run('') == []
    assert lookup_mock.run('bogus') == []
    assert lookup_mock.run('bogus', ptype='bogus') == []
    assert lookup_mock.run('bogus', pname='bogus') == []
    assert lookup_mock.run('bogus', ptype='bogus', pname='bogus') == []

# Generated at 2022-06-11 15:02:34.892557
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text

    # Generate 'AnsibleBase' or 'Base' class based on Ansible version
    AnsibleBaseClass = getattr(plugin_loader.ModuleLoader, '%sBase' % ("Ansible" if PY3 else "Base"))
    class BaseClass(AnsibleBaseClass):
        def __init__(self):
            self._display = None
            self._options = None
            self._task = None
            self._ds = None
            self._connection = None
            self._play_context = None
            self._loader = None
            self._variable_manager = None
            self._shared_loader_obj = None


    # Generate 'AnsibleModule' or 'AnsibleModule' class based

# Generated at 2022-06-11 15:02:40.759367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check if the module is supported on the running platform
    if LookupModule.supports_lookup_plugin(LookupBase):
        lookup_module = LookupModule()
        result = lookup_module.run("DEFAULT_BECOME_USER")
        # check the result
        if result is not None:
            print("Test success: %s" % result)
            return True
        else:
            print("Test failed")
            return False
    else:
        print("Platform not supported")
        return False

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:03:02.550782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([]) == [], 'It should return empty list for no terms'
    assert lookup_plugin.run(['DEFAULT_BECOME_USER']) == ['root'], 'It should return value of "DEFAULT_BECOME_USER"'
    assert lookup_plugin.run(['DEFAUT_BECOME_USER'], on_missing='warn') == [], 'It should return empty list for invalid term DEFAUT_BECOME_USER'
    assert lookup_plugin.run(['DEFAULT_ROLES_PATH'], on_missing='warn') == ['/etc/ansible/roles'], "It should return list with value '/etc/ansible/roles'"

# Generated at 2022-06-11 15:03:14.102913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['DEFAULT_LOCAL_TMP'], {}, on_missing='error') == ['/tmp/ansible/tmp']
    assert LookupModule().run(['DEFAULT_LOCAL_TMP'], {}, on_missing='warn') == ['/tmp/ansible/tmp']
    assert LookupModule().run(['DEFAULT_LOCAL_TMP'], {}, on_missing='skip') == ['/tmp/ansible/tmp']

    assert LookupModule().run(['UNKNOWN_OPTION'], {}, on_missing='error') == []
    assert LookupModule().run(['UNKNOWN_OPTION'], {}, on_missing='warn') == []
    assert LookupModule().run(['UNKNOWN_OPTION'], {}, on_missing='skip') == []

    assert Lookup

# Generated at 2022-06-11 15:03:14.691566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:03:24.577475
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestClass(LookupModule):
        def __init__(self, **kwargs):
            self.sentinel = Sentinel
            super(TestClass, self).__init__(**kwargs)

        def get_connection(self, host, user, port, variables, conn_type='smart', connect_timeout=30, connect_kwargs=None):
            return self.sentinel

        def get_option(self, option):
            if option == 'on_missing':
                return 'error'
            if option == 'plugin_type':
                return 'shell'
            if option == 'plugin_name':
                return 'sh'
            if option == 'var_options':
                return {'ansible_connection': 'ssh'}
            if option == 'direct':
                return {'special_arg': True}


# Generated at 2022-06-11 15:03:25.109249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == False

# Generated at 2022-06-11 15:03:32.870541
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: using the global setting paths
    #       this could be changed to use the ANSIBLE_CONFIG env or fixtures
    #       C.config_file is used by the Config class to use the correct config
    #       setting up the env is a bit more involved
    C.config_file = ['/etc/ansible/ansible.cfg']
    C.DEFAULT_ROLES_PATH = ['/var/lib/ansible/roles', '/etc/ansible/roles']
    C.RETRY_FILES_SAVE_PATH = '/var/lib/ansible/ansible-retry'
    C.DEFAULT_BECOME_USER = 'root'

    lookup = LookupModule()

    # Test Simple Plugin Configuration

# Generated at 2022-06-11 15:03:39.133623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # Source code: https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/lookup/config.py
        import ansible.plugins.lookup.config as mylookup
        lookup_module = mylookup.LookupModule()
        lookup_module.run(terms="DEFAULT_BECOME_METHOD")
        lookup_module.run(terms="FAKE")
    except Exception as e:
        print(type(e))  # the exception instance
        print(e.args)   # arguments stored in .args
        print(e)        # __str__ allows args to be printed directly


# Generated at 2022-06-11 15:03:47.966067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #########################################
    # Expected values for test of run method
    ########################################
    from ansible.compat import to_text

    exp_rc = 0
    exp_config = None
    exp_settings_list = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    exp_redirect_list = ['STDOUT', 'STDERR']
    exp_logger_type = 'AnsibleLogger'
    exp_term_list = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'STDOUT', 'STDERR', 'LOGGER_TYPE']
    exp_msg = u'[u\'my_value\']'
    exp_plugin_type = 'shell'
    exp_plugin_name = 'sh'

# Generated at 2022-06-11 15:03:59.807500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing")
    module = LookupModule()
    expected_results = {'DEFAULT_REMOTE_TMP': '/tmp', 'DEFAULT_ROLES_PATH': ["/etc/ansible/roles", "/usr/share/ansible/roles"]}
    for key, expected_value in expected_results.items():
        value = module.run([key], plugin_name=None, plugin_type=None, on_missing='error')
        assert value == expected_value, "%s do not match %s and %s" % (key, expected_value, value)


# Generated at 2022-06-11 15:04:06.230729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.constants import get_config

    # Arrange
    configpath = os.path.join(os.path.dirname(__file__), 'test', 'lookup_fixtures', 'ansible.cfg')
    config = get_config(configpath, 'roles_path')

    lm = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    kwargs = {'warnings': []}

    # Act
    results = lm.run(terms, **kwargs)

    # Assert
    assert results[0] == config

# Generated at 2022-06-11 15:04:32.218982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO

    lookup = LookupModule()

    # retrieve multiple settings
    terms = ['vault_password_file', 'python_version', 'strange_var']
    result = lookup.run(terms, None)
    assert result == [C.DEFAULT_VAULT_PASSWORD_FILE, C.DEFAULT_PYTHON_VERSION, None], result

    # retrieve a single setting
    result = lookup.run(['vault_password_file'], None)
    assert result == [C.DEFAULT_VAULT_PASSWORD_FILE], result

    # retrieve the value of a callback plugin setting
    display = getattr(lookup._display, 'display', None)
    output = StringIO()

# Generated at 2022-06-11 15:04:44.083430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils.pycompat24 import get_exception, reduce
        from ansible.module_utils.parsing.convert_bool import boolean, to_python
    else:
        from ansible.module_utils.parsing.convert_bool import boolean, to_python, get_exception
        from functools import reduce
    from ansible.plugins.lookup import LookupBase

    import ansible.plugins.loader as plugin_loader
    plugin_loader.add_directory('./library')

    import ansible.plugins.cache.memory as memory
    memory.CacheModule()

    import ansible.plugins.connection.network_cli as network_cli
    network_cli.ConnectionModule()


# Generated at 2022-06-11 15:04:52.928195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    lookup_obj.run(terms=["DEFAULT_ROLES_PATH"])
    lookup_obj.run(terms=["DEFAULT_ROLES_PATH"], plugin_type="become", plugin_name="pbrun")
    lookup_obj.run(terms=["DEFAULT_ROLES_PATH", "C", "COLOR_OK"], on_missing="error")
    lookup_obj.run(terms=["C", "COLOR_OK"])
    lookup_obj.run(terms=["C", "COLOR_OK"], on_missing="error")


# Generated at 2022-06-11 15:05:03.584262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import LookupModule
    from ansible.plugins.loader import connection_loader
    import ansible.constants as C

    os.environ['ANSIBLE_CONFIG'] = os.path.join('data', 'ansible.cfg')
    _display = Display()
    lookup_module = LookupModule(_display)
    lookup_module.set_options(var_options=MutableMapping(), direct=MutableMapping())

    # Tests the successful scenario when all required paramaters are passed.

# Generated at 2022-06-11 15:05:08.922756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l_module = LookupModule()

    terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH", "RETRY_FILES_SAVE_PATH"]
    kwargs = {"plugin_type":"connection", "plugin_name":"local", "on_missing": "error"}

    l_module.run(terms, **kwargs)
    # Need more assertions to confirm the method work as expected.

# Generated at 2022-06-11 15:05:20.221304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.color import AnsiColor
    from ansible.plugins.loader import become_loader, connection_loader, shell_loader
    from ansible import constants as C

    constants = C

# Generated at 2022-06-11 15:05:28.560845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModuleTest(LookupModule):
        def __init__(self):
            self.terms = ['ANSIBLE_CONFIG']

        def get_option(self, key):
            if key == 'on_missing':
                return Sentinel
            elif key == 'plugin_name':
                return None
            elif key == 'plugin_type':
                return None
            else:
                return None

        def set_options(self, var_options, direct=None):
            self.variables = var_options

        def _display(self):
            class Display:
                def __init__(self):
                    pass

                def warning(self, msg):
                    return msg
            return Display()

    lookup_module_test = LookupModuleTest()
    result = lookup_module_test.run(['ANSIBLE_CONFIG'])

# Generated at 2022-06-11 15:05:38.708840
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize the macro, this way we can change the values passed during run
    from ansible.plugins.loader import lookup_loader

    lookup_loader.add_directory('./lib')

    lookup_macro = lookup_loader.get('config')
    lookup_macro = lookup_macro()

    # Test with valid values
    terms = ['LIBDIR']
    # Test with variables set
    variables = dict(LIBDIR='/usr/share/ansible')
    result = lookup_macro.run(terms, variables)
    assert result[0] == '/usr/share/ansible'

    # Test without variables set
    variables = dict()
    result = lookup_macro.run(terms, variables)
    assert result[0] == '/usr/share/ansible/'

    # Test to get multiple values at once
    terms

# Generated at 2022-06-11 15:05:47.906232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    print()
    # term that is an int should raise AnsibleOptionsError
    print("Test 1: no plugin specified and term is not a string")
    term = 1
    try:
        lookup_module.run(terms=[term], variables=None, direct=None)
    except AnsibleOptionsError as e:
        print("Success. Got expected error: %s" % e)
    else:
        print("Failed. Expected AnsibleOptionsError since term is not a string or list of strings")

    print()
    # test with on_missing setting to 'error' - this is the default
    print("Test 2: no plugin specified and on_missing is 'error' - this is the default")
    term = "DEFAULT_ROLES_PATH"

# Generated at 2022-06-11 15:05:59.021491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleError, AnsibleOptionsError, AnsibleLookupError
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    # set up config variables
    config_manager = ConfigManager()
    config_manager.set('DEFAULT_REMOTE_USER', 'testuser')
    variables = dict()
    variables['config_dir'] = '/etc/ansible'

    # create display
    display = Display()

    # define string and file
    data_string = 'string'
    data_file = '/etc/ansible/hosts'

    # define test groups

# Generated at 2022-06-11 15:06:29.393044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([],)
    assert result == []
    result = LookupModule().run(["should be a string"],)
    assert result == []

# Generated at 2022-06-11 15:06:30.524231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise NotImplementedError

# Generated at 2022-06-11 15:06:41.429502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #First run
    lookup_obj = LookupModule()
    terms = [ 'DEFAULT_BECOME_USER' ]
    variables = {}
    kwargs = {'plugin_name': 'ansible_test'}

    result = lookup_obj.run( terms, variables, **kwargs )
    assert result[0] == 'root'

    #Second run
    lookup_obj = LookupModule()
    terms = [ 'DEFAULT_BECOME_USER' ]
    variables = {}
    kwargs = {}

    result = lookup_obj.run( terms, variables, **kwargs )
    assert result[0] == 'root'

    #Third run
    lookup_obj = LookupModule()
    terms = [ 'DEFAULT_BECOME_USER' ]
    variables = {}

# Generated at 2022-06-11 15:06:43.130208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-11 15:06:51.090580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No error raised
    pname = 'ssh'
    ptype = 'connection'
    config = 'remote_user'
    variables = None
    test_term = 'remote_user'
    test_terms = ['I_am_bogus_term', test_term]

    assert not isinstance(sentinel, Sentinel)
    assert isinstance(sentinel, Sentinel)

    # Assert that lookup_plugin.run returns a list
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin.run(test_terms, pname=pname, ptype=ptype, config=config, variables=variables), list)
    assert isinstance(lookup_plugin.run(test_terms, variables=variables, config=config), list)

# Generated at 2022-06-11 15:07:03.513066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_test = LookupModule()
    terms_test = ['C.DEFAULT_REMOTE_USER']
    variables_test = {}

    # test when on_missing is not a string
    lookup_test.set_options(var_options=variables_test)
    lookup_test.set_options(direct={'on_missing': 3})
    try:
        lookup_test.run(terms_test, variables=None)
        assert False
    except AnsibleOptionsError as e:
        assert to_native(e) == '"on_missing" must be a string and one of "error", "warn" or "skip", not 3'

    # test when on_missing is a string but not one of 'error', 'warn', 'skip'
    lookup_test.set_options(direct={'on_missing': 'ignore'})


# Generated at 2022-06-11 15:07:14.784876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible
    from ansible.plugins.loader import lookup_loader

    lookup_loader.add_directory(ansible.__path__[0] + '/lib/ansible/plugins/lookup')
    test_lookup = lookup_loader.get('config', class_only=True)()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH']
    variables = None
    kwargs = {
        'plugin_type': 'connection',
        'plugin_name': 'local'
    }
    result = test_lookup.run(terms, variables, **kwargs)
    assert type(result) == list
    assert len(result) == len(terms)
    assert result[0] == 'root'

# Generated at 2022-06-11 15:07:15.433259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:07:18.965378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ 'DEFAULT_ROLES_PATH' ]
    lookup_module.run(terms)
    assert True

# Generated at 2022-06-11 15:07:27.553551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_get_config_value(config, variables=None, plugin_type='', plugin_name='', expand_lists=False, convert_bare=False, va=None):
        variables = variables if variables else {}
        if not config.lower() in ['config_in_var', 'another_config']:
            raise AnsibleLookupError('Unable to load config "%s" for plugin "%s"' % (config, plugin_name))
        return (variables.get(config) or config) in ['good', 'other_good']

    class C(object):
        def __getattr__(self, config):
            if config == 'remote_user':
                return 'ansible'
            elif config == 'port':
                return 22
            raise AnsibleLookupError('Unable to load config "%s"' % config)


# Generated at 2022-06-11 15:08:32.664686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["DEFAULT_BECOME_USER"], {"on_missing": "error", "_ansible_remote_tmp": "tmp"}) == ["root"]

# Generated at 2022-06-11 15:08:39.364312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test run, type of terms is list
    # test case 1, on_missing is error, get global config
    terms = ['DEFAULT_ROLES_PATH']
    kwargs1 = {'on_missing': 'error'}
    expected_result1 = ['/etc/ansible/roles:/usr/share/ansible/roles']
    result1 = module.run(terms, kwargs=kwargs1)
    assert result1 == expected_result1

    # test case 2, on_missing is warn, get global config
    terms = ['RANDOM_CONFIG']
    kwargs2 = {'on_missing': 'warn'}
    expected_result2 = []
    module.run(terms, kwargs=kwargs2)

    # test case 3, on_

# Generated at 2022-06-11 15:08:44.277768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    sys.path.append('lib/ansible/plugins/lookup')
    from ansible.plugins.lookup import config
    lookup = config.LookupModule()
    result = lookup.run(terms=['version'])
    print(result)


# Unit test of function _get_plugin_config

# Generated at 2022-06-11 15:08:45.876222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.run(terms='DEFAULT_ROLES_PATH')



# Generated at 2022-06-11 15:08:55.593084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

# Generated at 2022-06-11 15:09:07.058474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test case to check the output of run method in ansible.plugins.lookup.config.LookupModule
    """
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader(), variable_manager=variable_manager))
    terms = ['retry_files_save_path']
    result = lookup_loader.get('config', loader=None, templar=None, shared_loader_obj=None).run(terms, variable_manager=variable_manager, all_vars={})
    assert result == [u'~/.ansible/retry']

# Generated at 2022-06-11 15:09:14.624730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock

    class MyLookupModule(LookupModule):
        def __init__(self):
            self.runner = mock.MagicMock()

        def get_option(self, option):
            return self.runner.get_option(option)

    lookup_plugin = MyLookupModule()
    lookup_plugin.runner.get_option = mock.MagicMock(return_value=False)

    terms = ["foo"]
    variables = {}

    try:
        returned_value = lookup_plugin.run(terms, variables)
        assert returned_value == []
    except AnsibleOptionsError as e:
        assert False

    class MyLookupModule(LookupModule):
        def __init__(self):
            self.runner = mock.MagicMock()

        def get_option(self, option):
            return self.runner

# Generated at 2022-06-11 15:09:18.796925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"], {},
                        on_missing='error', plugin_type='connection', plugin_name="ssh")
    assert isinstance(result, list)
    assert len(result) == 1

# Generated at 2022-06-11 15:09:29.523916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    # Create a tempfile for vault secret
    tmp_vault_f = tempfile.NamedTemporaryFile()
    vault_secret = VaultSecret('password', tmp_vault_f.name)
    vault = VaultLib([vault_secret])
    vault.encrypt_string(VaultSecret('secret_vault_password'), 'secret_vault_password')
    tmp_vault_f.seek(0)

    variables = {"secret_vault_password": tmp_vault_f.name}

    # Test with DEFAULT_PRIVATE_ROLE_VARS

# Generated at 2022-06-11 15:09:39.365123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Check the case where 'plugin_type' is not specified
    terms = ['DEFAULT_BECOME_USER']
    ret = module.run(terms=terms)
    assert ret == ['root'], 'Failed to return the expected value for config key %s' % terms
    # Check the case where 'plugin_type' is not specified and one of the key is invalid
    terms = ['DEFAULT_BECOME_USER', 'invalid']