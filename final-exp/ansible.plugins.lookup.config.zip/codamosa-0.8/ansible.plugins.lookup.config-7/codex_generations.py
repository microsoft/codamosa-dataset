

# Generated at 2022-06-11 15:01:39.571985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    conf = [ 'localhost', 'default', 'context', 'ask_sudo_pass' ]

# Generated at 2022-06-11 15:01:49.661516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Success
    class plugin_loader_return():
        def get(self, pname, class_only):
            class pclass():
                _load_name = 'pname'
            return pclass()

    class C():
        config = config_return()
        DEFAULT_BECOME_USER = 'DEFAULT_BECOME_USER'
        UNKNOWN = 'UNKNOWN'
        port = 'port'
        COLOR_OK = 'COLOR_OK'
        COLOR_CHANGED = 'COLOR_CHANGED'
        COLOR_SKIP = 'COLOR_SKIP'
        RETRY_FILES_SAVE_PATH = 'RETRY_FILES_SAVE_PATH'
        remote_tmp = 'remote_tmp'
        remote_user = 'remote_user'


    class variables():
        playbook_dir

# Generated at 2022-06-11 15:01:57.063465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid option value for on_missing
    lookup_ret = LookupModule().run([], {}, on_missing='invalid')
    assert lookup_ret == []
    lookup_ret = LookupModule().run(['unused'], {}, on_missing='invalid')
    assert lookup_ret == []

    # Test with invalid plugin_type value
    lookup_ret = LookupModule().run([], {}, plugin_type='invalid', plugin_name='invalid')
    assert lookup_ret == []
    lookup_ret = LookupModule().run(['unused'], {}, plugin_type='invalid', plugin_name='invalid')
    assert lookup_ret == []
    lookup_ret = LookupModule().run([], {}, plugin_type='become')
    assert lookup_ret == []

# Generated at 2022-06-11 15:02:01.202511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'ANSIBLE_RETRY_FILES_SAVE_PATH'
    variables = {}
    kwargs = {'on_missing':'warn', 'plugin_type':'connection', 'plugin_name':'ssh'}
    lookup = LookupModule()
    assert lookup.run(term, variables, **kwargs)

# Generated at 2022-06-11 15:02:04.242400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock

    #
    module = mock.Mock()
    result = LookupModule.run(module, terms=['DEFAULT_BECOME_USER'])
    assert result[0] == 'root'

# Generated at 2022-06-11 15:02:15.111028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils.six import StringIO
    output = StringIO()
    #Given
    terms = ["UNKNOWN_CONFIG_1", "UNKOWN_CONFIG_2", "UNKNOWN_CONFIG_3"]
    variables = {'u': 'v'}

    module_lookup = LookupModule()
    module_lookup._display.display = output.write
    #When and then
    #correct match
    try:
        module_lookup.run(terms, variables=variables)
        assert False, "AnsibleOptionsError should be raised"
    except AnsibleOptionsError:
        pass

    #incorrect match

# Generated at 2022-06-11 15:02:22.206552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Tests for the function that gets invoked by Ansible for the lookup plugin
    '''
    lookup_plugin = LookupModule()
    # test that a config value can be retrieved from the global config via this lookup plugin
    assert lookup_plugin.run(terms=["DEFAULT_FORKS"], **{}) == [C.DEFAULT_FORKS]
    # test that a config value can be retrieved from a  connection plugin config via this lookup plugin
    assert lookup_plugin.run(terms=["persistent_command"], plugin_type='connection', plugin_name='local', **{}) == [C.DEFAULT_PERSISTENT_COMMAND_TIMEOUT]



# Generated at 2022-06-11 15:02:31.898294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test with plugin option
    look = LookupModule()
    result = look.run([u'variable_name'], plugin_type = u'lookup', plugin_name = u'string', on_missing = u'warn')
    assert result == [u'string']

    result = look.run([u'variable_name'], plugin_type = u'lookup', plugin_name = u'file', on_missing = u'warn')
    assert result == [u'file']

    result = look.run([u'variable_name'], plugin_type = u'connection', plugin_name = u'ssh', on_missing = u'warn')
    assert result == [u'ssh']


# Generated at 2022-06-11 15:02:37.955718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test the run method to confirm that type and plugin_name are set
    # if one is set
    class Options():
        def __init__(self):
            self.plugin_type = 'shell'

    class MockDisplay():
        def warning(self, msg):
            pass

    class MockVariableManager():
        def get_vars(self):
            return {}

    lookup_module = LookupModule(MockDisplay(), MockVariableManager())
    lookup_module.set_options(Options())
    try:
        lookup_module.run(['TERM'])
        assert False, 'This should fail because plugin_name is not set even though plugin_type is set.'
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(e)

# Generated at 2022-06-11 15:02:46.562476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(terms=['DEFAULT_MODULE_PATH'])
    assert isinstance(result, list)
    assert result == [C.DEFAULT_MODULE_PATH]

    # test on_missing options
    try:
        result = LookupModule().run(terms=['UNKNOWN_VAR'], variables=dict(ANSIBLE_LOOKUP_MISSING='error'))
        assert False
    except AnsibleLookupError:
        assert True

    result = LookupModule().run(terms=['UNKNOWN_VAR'], variables=dict(ANSIBLE_LOOKUP_MISSING='warn'))
    assert result == []

    result = LookupModule().run(terms=['UNKNOWN_VAR'], variables=dict(ANSIBLE_LOOKUP_MISSING='skip'))

# Generated at 2022-06-11 15:03:04.745436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Test local configuration lookup
    lookup = lookup_loader.get('config')
    assert lookup.run([['DEFAULT_ROLES_PATH']], {}, wantlist=True) == [['/etc/ansible/roles:/usr/share/ansible/roles']]
    assert lookup.run([['DEFAULT_ROLES_PATH']], {}, wantlist=False) == ['/etc/ansible/roles:/usr/share/ansible/roles']
    assert lookup.run(['DEFAULT_ROLES_PATH'], {}, wantlist=False) == '/etc/ansible/roles:/usr/share/ansible/roles'

# Generated at 2022-06-11 15:03:16.457939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock get_option
    LookupModule.get_option = lambda self, name: 'error'
    # mock display
    LookupModule._display = lambda self: type('MockDisplay', (object,), {'warning': lambda *args, **kwargs: None})()

    lm = LookupModule()

    # Error when on_missing is set to invalid value
    try:
        lm.run(terms=['foo', 'bar'], on_missing='invalid')
    except AnsibleOptionsError as e:
        assert 'on_missing' in to_native(e)
        assert 'invalid' in to_native(e)

    # Warn when on_missing is set to warn
    lm.run(terms=['foo', 'bar'], on_missing='warn')

    # Skip when on_missing is set to skip

# Generated at 2022-06-11 15:03:26.161996
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()
    assert type(lm.run([], [], on_missing='error')) == list
    assert lm.run(['DEFAULT_LOG_PATH'], [], on_missing='error') == ['/var/log/ansible.log']
    assert lm.run([''], [], on_missing='error') == []
    assert lm.run(['UNKNOWN_CONFIG_OPTION'], [], on_missing='warn') == []
    assert lm.run(['UNKNOWN_CONFIG_OPTION'], [], on_missing='skip') == []
    assert lm.run(['UNKNOWN_CONFIG_OPTION'], [], on_missing='error') == []

# Generated at 2022-06-11 15:03:30.767712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['remote_user', 'port']
    ptype = 'connection'
    pname = 'ssh'
    result = lookup_module.run(terms, plugin_type=ptype, plugin_name=pname, on_missing='skip')
    assert result == ['mock_user', 22]

# Generated at 2022-06-11 15:03:34.167096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['ANSIBLE_CONFIG'], dict())[0] == u'(Ansible internal file)'
    assert LookupModule().run(['ANSIBLE_CONFIG'])[0] == u'(Ansible internal file)'


# Generated at 2022-06-11 15:03:43.995926
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1
    # with invalid setting identifier
    l = LookupModule()
    l_obj = l.__class__.run
    with pytest.raises(AnsibleOptionsError) as e:
        l_obj(l, terms=1, variables=None, **{})
    assert "Invalid setting identifier," in str(e.value)

    # Test case 2
    # with invalid on_missing
    with pytest.raises(AnsibleOptionsError) as e:
        l_obj(l, terms=["var1"], variables=None, **{"on_missing": "invalid"})
    assert "on_missing" in str(e.value)

    # Test case 3
    # without plugin_type, plugin_name
    with pytest.raises(AnsibleOptionsError) as e:
        l

# Generated at 2022-06-11 15:03:55.702275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock AnsibleOptions instance
    ao = mock.Mock()
    ao.on_missing = 'error'
    # Create a mock config instance
    config = mock.Mock()
    # Create a mock constants instance
    constants = mock.Mock()
    # Create a mock display instance
    display = mock.Mock()
    # Create a mock display instance
    plugins = mock.Mock()
    # Create a mock plugin loader instance
    p_loader = mock.Mock()
    # Create a mock shell instance
    shell = mock.Mock()
    # Create a mock display instance
    util = mock.Mock()
    # Create a mock ansible variables instance
    ans_vars = mock.Mock()
    # Create a mock sentinel instance
    sen = mock.Mock()

    # Create an instance

# Generated at 2022-06-11 15:04:05.312300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-11 15:04:17.317581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
        ('COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'),
        'UNKNOWN'
    ]
    # Make sure the config values can be found
    assert LookupModule().run(terms)

    # Make sure the config values can be found
    assert LookupModule().run(terms, on_missing='warn')

    # Make sure the config values can be found
    assert LookupModule().run(terms, on_missing='skip')

    # Make sure the config raises error for missing term
    try:
        assert LookupModule().run(terms, on_missing='error')
    except AnsibleLookupError:
        pass

    # Make sure an error is thrown invalid option for on_missing parameter

# Generated at 2022-06-11 15:04:19.514835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    module.run(["DEFAULT_ROLES_PATH"])

# Generated at 2022-06-11 15:04:30.820180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'INVALID_SETTING']
    variables = {}
    ret = lookup.run(terms=terms, variables=variables)

    assert ret[0] == 'root'
    assert len(ret) == 1

# Generated at 2022-06-11 15:04:43.254153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test method run with plugin_type and plugin_name specified
    class Test_LookupModule_1(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            self.set_options(var_options=variables, direct=kwargs)
            ptype = self.get_option('plugin_type')
            pname = self.get_option('plugin_name')
            assert(isinstance(ptype, string_types))
            assert(isinstance(pname, string_types))
            assert(ptype == 'shell')
            assert(pname == 'sh')
            assert(isinstance(terms, list))
            assert(len(terms) == 1)
            assert(isinstance(terms[0], string_types))
            assert(terms[0] == 'remote_tmp')

# Generated at 2022-06-11 15:04:54.636293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ANSIBLE_HOST_KEY_CHECKING', 'ANSIBLE_CALLBACK_WHITELIST']
    variables = {'ANSIBLE_CALLBACK_WHITELIST': 'profile_tasks'}
    ansible_config = [{'_ansible_no_log': False, '_ansible_verbosity': 0, 'ANSIBLE_HOST_KEY_CHECKING': True, 'ANSIBLE_CALLBACK_WHITELIST': 'profile_tasks'}]
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_env('', '', '', None)
    lookup._display.display = Mock(return_value=None)
    lookup._display.verbosity = 0
    assert lookup.run(terms, variables) == ansible_config
    assert lookup._display

# Generated at 2022-06-11 15:04:55.942100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-11 15:05:06.314753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run(["ANSIBLE_REMOTE_TMP", "DEFAULT_REMOTE_TMP"], ptype='connection', pname='local', variables=None, on_missing='warn')
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0] == C.ANSIBLE_REMOTE_TMP
    results = lookup_module.run(["ANSIBLE_REMOTE_TMP", "DEFAULT_REMOTE_TMP"], ptype='connection', pname='local', variables=None, on_missing='skip')
    assert isinstance(results, list)
    assert len(results) == 0

# Generated at 2022-06-11 15:05:16.857276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LM = LookupModule()
    LM.set_options(None, direct=dict(on_missing='skip'))
    assert LM.run(['DEFAULT_SUDO_USER'])
    assert LM.run(['DEFAULT_SUDO_USER']) == C.DEFAULT_SUDO_USER
    assert LM.run(['BOGUS_CONFIG_VALUE']) == []

    # test plugin config
    LM.set_options(None, direct=dict(on_missing='skip', plugin_type='shell', plugin_name='sh'))
    assert LM.run(['remote_tmp']) == C.DEFAULT_REMOTE_TMP

    # test non-existent plugin

# Generated at 2022-06-11 15:05:26.988627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check run method raises exception when AnsibleOptionsError is thrown
    lookup_module = LookupModule()
    terms = [u'ANSIBLE_DEBUG']
    variables = {}
    kwargs = {}
    try:
        lookup_module.run(terms, variables, **kwargs)
    except AnsibleOptionsError as err:
        assert err is not None
    else:
        assert u'Method run should throw AnsibleOptionsError exception'
        # when option on_missing is not one of 'error', 'warn' or 'skip'

    kwargs = {u'on_missing': u'error'}
    try:
        lookup_module.run(terms, variables, **kwargs)
    except AnsibleOptionsError as err:
        assert err is not None

# Generated at 2022-06-11 15:05:37.696312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert lookup_plugin

    # lookup from
    # https://github.com/ansible/ansible/blob/stable-2.4/lib/ansible/plugins/lookup/config.py#L47
    # which is the method that this unit test is testing
    # It appears that this is the same as calling get_config_value(self, config, plugin_type=None, plugin_name=None, variables=None):
    # with plugin_type = None and plugin_name = None
    # so we could just call that.
    # we should look into this

# Generated at 2022-06-11 15:05:47.618490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import LookupModule as LM
    from ansible.module_utils._text import to_text

    test_terms = ['DEFAULT_BECOME_USER']
    test_variables = {'command_warnings': 'False'}
    test_kwargs = {'cacheable': 'True'}

    mock_display = None

    lm = LM()

    lm._display = mock_display
    lm.set_options(var_options=test_variables, direct=test_kwargs)

    assert test_terms == lm.run(test_terms)

    lm = LM()
    lm._display = mock_display
    lm.set_options(var_options=test_variables, direct=test_kwargs)

# Generated at 2022-06-11 15:05:58.679876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel

    ansible_vars = {
        'env': {
            'simple_var': 'simple value',
            'list_var': [
                'item 1',
                'item 2',
            ]
        }
    }

    # None plugin name or type
    cm = LookupModule()
    cm.set_options({'var_options': ansible_vars})
    # none plugin
    result = cm.run(["simple_var"])
    assert isinstance(result[0], str)
    assert result[0] == 'simple value'
    # list plugin, none plugin_name, plugin_type
    result = cm.run(["list_var"])
    assert isinstance(result[0], list)

# Generated at 2022-06-11 15:06:19.532913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 1: testing when both ptype and pname are not passed
    lookup_module = LookupModule()
    terms = ['host_key_checking']
    ret = lookup_module.run(terms)
    # expected result for host_key_checking setting is False
    assert ret[0] == False

    # Case 2: testing when pname is passed but ptype is not
    lookup_module = LookupModule()
    terms = ['speed']
    ret = lookup_module.run(terms, plugin_name='network_cli')
    # expected result for speed setting is 1.0
    assert ret[0] == 1.0

    # Case 3: testing when ptype and pname both are passed
    lookup_module = LookupModule()
    terms = ['stdin_add_newline']

# Generated at 2022-06-11 15:06:27.419292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    class FakeVars(object):
        def __init__(self):
            self.ansible_connection = "netconf"

    def setup_module(self):
        self.lm = LookupModule()
        self.variables = FakeVars()
        self.terms = ["ANSIBLE_SCP_IF_SSH", "ANSIBLE_NETCONF_AUTO_ROLLBACK"]

    def test_error(self):
        with pytest.raises(AnsibleOptionsError):
            self.lm.run(self.terms, self.variables, on_missing="error")

    def test_warn(self):
        with pytest.raises(AnsibleOptionsError):
            self.lm.run(self.terms, self.variables, on_missing="warn")


# Generated at 2022-06-11 15:06:33.649000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    variables = {}
    kwargs = {'on_missing': 'error'}

    # test calling of method run of LookupModule
    result = lookup_module.run(terms, variables, kwargs)
    assert result == ['/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-11 15:06:36.220687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    terms = ["DEFAULT_FORKS"]
    plugin._display = MockDisplay()
    results = plugin.run(terms)
    assert results == [5]

# Generated at 2022-06-11 15:06:47.493251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo', 'bar']
    lm = LookupModule()
    # Test use of variables, the plugin_type and plugin_name options
    variables = {'ansible_shell_type': 'powershell'}
    results = lm.run(terms, variables=variables, plugin_type='shell', plugin_name='powershell')
    assert len(results) == 2
    # Test use of on_missing='error' option
    try:
        results = lm.run(terms, on_missing='error')
        assert False
    except AnsibleLookupError:
        assert True
    # Test use of on_missing='skip' option
    results = lm.run(terms, on_missing='skip')
    assert len(results) == 0
    # Test use of on_missing='warn' option
    results = l

# Generated at 2022-06-11 15:06:50.026940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  result = lookup_module.run(terms=['DEFAULT_BECOME_USER'])
  assert result == ['root']

# Generated at 2022-06-11 15:07:01.633118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    test_term = "BECOME_TIMEOUT"
    test_result = 10
    my_lookup = LookupModule()
    my_result = my_lookup.run([test_term])
    assert my_result[0] == test_result
    print ("Testcase 1: assert my_result[0] == test_result")

    # Test case 2:
    test_term = "RETRY_FILES_ENABLED"
    test_result = False
    my_lookup = LookupModule()
    my_result = my_lookup.run([test_term])
    assert my_result[0] == test_result
    print ("Testcase 2: assert my_result[0] == test_result")

# Generated at 2022-06-11 15:07:09.518886
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:07:21.206158
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test 1: missing option is not allowed
    assert_raises(AnsibleOptionsError, LookupModule().run, terms=['invalid_setting'], on_missing='invalid_value')

    # test 2: request to connect to a remote host (ssh)
    result = LookupModule().run(terms=['remote_user', 'port', 'ansible_host'], on_missing='skip')
    assert result[0] == 'root'
    assert result[1] == 22
    assert result[2] == 'localhost'

    # test 3: request to connect to a remote host (docker)
    result = LookupModule().run(terms=['remote_user', 'port', 'ansible_host'], on_missing='skip', plugin_type='connection', plugin_name='docker')
    assert result[0] == 'root'

# Generated at 2022-06-11 15:07:21.796311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-11 15:07:47.556775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import ansible.constants as C
    import ansible.module_utils._text as t
    import ansible.utils.sentinel as sentinel

    def fake_get_option(self, foo):
        if foo == 'on_missing':
            return 'error'
        return None

    fake_display = type('', (), {})()
    fake_display.warning = lambda x: x
    fake_display.display = lambda x, y, z: True

    module = LookupModule()
    module.set_options = lambda x: None
    module.get_option = fake_get_option
    module.get_option_from_plugins = lambda x: None
    module.get_option_from_configparser = lambda x, cp, sec, key, defval=None, **kwargs: None


# Generated at 2022-06-11 15:07:54.618540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters = {'_terms': ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], 'on_missing': 'error', 'plugin_type': 'become', 'plugin_name': 'test_plugin_name'}
    #print(test_LookupModule.run([parameters]))
    # results:
    #   test_LookupModule.run([parameters])
    #   [u'root', u'/etc/ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-11 15:08:02.320418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setting ansible.cfg with constants.DEFAULT_CONFIG_FILE
    C = ansible.config.define

    C.DEFAULT_RETRY_FILES_ENABLED = True
    C.DEFAULT_RETRY_FILES_SAVE_PATH = '~/.ansible-retry'
    C.DEFAULT_VAULT_PASSWORD_FILE = '~/.ansible/vault_pass.txt'
    C.DEFAULT_BECOME_METHOD = 'sudo'
    C.DEFAULT_BECOME = True
    C.DEFAULT_BECOME_USER = 'root'
    C.DEFAULT_BECOME_ASK_PASS = True
    C.DEFAULT_FORKS = 5
    C.DEFAULT_EXECUTABLE = '/bin/sh'
    C.DEFAULT_MODULE

# Generated at 2022-06-11 15:08:09.329319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    lookup = LookupModule()
    # set terms for which we want to know the value
    terms = ['remote_user', 'RETRY_FILES_SAVE_PATH']
    # set values to be associated with these terms
    variables = {'remote_user': 'ansible', 'RETRY_FILES_SAVE_PATH': '/var/log/ansible_retry' }
    # set the options
    kwargs = {'on_missing': 'error'}
    # call method of run to get the configuration value
    lookup.run(terms, variables, **kwargs)



# Generated at 2022-06-11 15:08:11.474467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(terms=['DEFAULT_ROLES_PATH'])
    assert True

# Generated at 2022-06-11 15:08:21.478826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.config.manager
    import ansible.plugins.loader
    import ansible.plugins.lookup

    # Test function _get_plugin_config
    # Create a fake config object
    acm = ansible.config.manager.ConfigManager()
    # Create a fake configurations of ssh connection plugin
    acm._inventory_cache[('connection', 'ssh')].update({'remote_tmp':'/tmp/.ansible', 'remote_user':'joe'})
    # Update cache
    ansible.config.manager.project._inventory_cache.update(acm._inventory_cache)
    cls = ansible.plugins.loader.connection_loader.get('ssh', class_only=True)
    cls._load_name = 'ssh'

    # Test assert _get_plugin_config() raise exception when plugin_type/plugin_

# Generated at 2022-06-11 15:08:28.798723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for fetching a config for a particular connection plugin
    module = LookupModule(loader=None, templar=None)
    # set plugin_type and plugin_name option
    term = module.run(["remote_tmp", "remote_uid", "accelerate"])
    assert len(term) == 3
    assert term[0] == "$HOME/.ansible/tmp"
    assert term[1] == "$HOME/.ansible/tmp"
    assert term[2] == False



# Generated at 2022-06-11 15:08:29.634877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:08:32.690905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = LookupModule().run(terms)
    assert 'root' in result
    assert './roles:./site' in result

# Generated at 2022-06-11 15:08:42.691744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    def _lookup_loader_mock(name, loader, templar, **kwargs):
        fake = FakeLookupModule()
        fake._display = DisplayMock()
        return fake

    # Mock lookup_loader
    lookup_loader.get = _lookup_loader_mock

    # Mock Display
    DisplayMock.warning = DisplayMock.display = DisplayMock.display_error = lambda self, *args, **kwargs: None

    module = LookupModule()

    def assertRaisesAnsibleError(term, options=dict()):
        try:
            module.run(terms=term, **options)
        except AnsibleError:
            pass
        else:
            assert False, "Expected AnsibleError to be raised"

    # Global config
   

# Generated at 2022-06-11 15:09:21.306025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    tmp = LookupModule(
            loader=DataLoader(),
            variables={},
            play_context=PlayContext()
    )
    from ansible.plugins.loader import connection_loader
    connection_loader.get('local')
    import ansible_mitogen.connection
    ansible_mitogen.connection.unload_all()
    assert 'local' in tmp.run(terms=['DEFAULT_CONNECTION'])[0]
    assert 'local' in tmp.run(terms=['DEFAULT_CONNECTION'], plugin_type='connection', plugin_name='local')[0]

# Generated at 2022-06-11 15:09:33.251128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleOptionsError, AnsibleLookupError
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib

    lookup_module = LookupModule()

    # test_non_string_terms_raise_exception
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run([])

    # test_non_string_missing_raise_exception
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['my_term'], on_missing=None)

    # test_invalid_missing_raise_exception
    with pytest.raises(AnsibleOptionsError):
        lookup_module

# Generated at 2022-06-11 15:09:40.890635
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup test environment
    from ansible.plugins.loader import lookup_loader

    # create instance of LookupModule
    l = lookup_loader.get('config')

    # setup args, kwargs
    args = (['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'],)
    kwargs = dict(on_missing='error')

    # call run with the given args, kwargs
    # ret should be a list with 2 strings
    # as DEFAULT_BECOME_USER and DEFAULT_ROLES_PATH are available in settings.
    # DEFAULT_BECOME_USER and DEFAULT_ROLES_PATH are defined as constants,
    # not as callables.
    ret = l.run(*args, **kwargs)
    assert isinstance(ret, list)

# Generated at 2022-06-11 15:09:47.635019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    module = AnsibleModule(
        argument_spec = dict(
            terms = dict(required=True, type='list'),
        )
    )

    class ClassLookupModule(LookupModule):

        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = ClassLookupModule()

    module.exit_json(**{'ins': lookup_plugin.run(terms=module.params['terms'], inject=dict(variables=dict()))})


# Generated at 2022-06-11 15:09:58.654520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test single global config
    module_glob_config = LookupModule()
    module_glob_config.set_options(var_options={}, direct={'plugin_name': None, 'plugin_type': None})
    assert module_glob_config.run(['DEFAULT_BECOME_USER'], {}) == ['root']
    # Test if config is missing
    module_glob_config.set_options(var_options={}, direct={'plugin_name': None, 'plugin_type': None, 'on_missing': 'error'})
    assert module_glob_config.run(['UNKNOWN'], {}) == ['root']
    # Test multiple global config
    module_glob_config.set_options(var_options={}, direct={'plugin_name': None, 'plugin_type': None})
   

# Generated at 2022-06-11 15:09:59.226692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:10:10.201129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test default
    assert LookupModule(None, None, None).run(["DEFAULT_ROLES_PATH"]) == [C.DEFAULT_ROLES_PATH]

    # Test invalid setting
    try:
        LookupModule(None, None, None).run(["BOGUS_ROLES_PATH"])
        assert(False)
    except:
        assert(True)

    # Test plugin with config
    assert LookupModule(None, None, None).run(["remote_tmp", "plugin_type=shell", "plugin_name=sh"], variables={}) == [C.DEFAULT_REMOTE_TMP]
    # Test plugin without config

# Generated at 2022-06-11 15:10:15.945855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = None
    obj = LookupModule()
    result = obj.run(terms, variables)
    assert result == ['root', ['/etc/ansible/roles']]

# Generated at 2022-06-11 15:10:26.886166
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    terms=[ 'DEFAULT_BECOME_USER', 'C.DEFAULT_BECOME_USER' ]
    variables = {"C.DEFAULT_BECOME_USER":"root"}
    ret = lookup.run(terms, variables)
    assert(ret[0] == "root") # C.DEFAULT_BECOME_USER has been overridden
    assert(ret[1] != "root") # DEFAULT_BECOME_USER has not been overridden

    lookup = LookupModule()
    terms=[ 'non-existing', 'existing' ]
    ret = lookup.run(terms)
    # An exception should be raised when using default action error
    try:
        lookup.run(terms)
    except AnsibleOptionsError as e:
        pass

    lookup = LookupModule()

# Generated at 2022-06-11 15:10:34.785750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1: Load setting 'DEFAULT_BECOME_USER'
    test_1_term = 'DEFAULT_BECOME_USER'
    test_result_1 = LookupModule().run([test_1_term], 'connection', 'ssh')[0]
    assert test_result_1 == 'root'

    # Test case 2: Load settings 'DEFAULT_BECOME_USER', 'DEFAULT_SUDO_EXE'
    test_2_terms = ['DEFAULT_BECOME_USER', 'DEFAULT_SUDO_EXE']
    test_result_2 = LookupModule().run(test_2_terms, 'connection', 'ssh')
    assert test_result_2 == ['root', '/bin/sudo']

    # Test case 3: Load setting 'DEFAULT_BECOME_USER' and