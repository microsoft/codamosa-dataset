

# Generated at 2022-06-11 15:01:37.120609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(
        [
            'DEFAULT_ROLES_PATH',
            'UNKNOWN_SETTING',
            'COLOR_OK',
            'COLOR_CHANGED',
            'COLOR_SKIP'
        ],
        {
            'some_var': 'some_value'
        },
        on_missing='warn'
    )
    assert result == module.run(
        [
            'DEFAULT_ROLES_PATH',
            'COLOR_OK',
            'COLOR_CHANGED',
            'COLOR_SKIP'
        ],
        {
            'some_var': 'some_value'
        }
    )

# Generated at 2022-06-11 15:01:47.756626
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # AnsiblePlugins
    def get_plugins_of_type_mock():
        plugin = {
            'httpapi': {
                'httpapi_name': 'mock_httpapi_name'
            }
        }
        return plugin

    def get_plugins_metadata_mock():
        metadata = {
            "httpapi": {
                "mock_httpapi_name": {
                    "DOCUMENTATION": "httpapi mock_httpapi_name plugin",
                    "EXAMPLES": "httpapi mock_httpapi_name plugin example"
                }
            },
        }
        return metadata

    import Ansible.module_utils.ansible_lookup_plugins.config as config_module
    import types

    # create an instance of the class LookupModule
    lookup_module = config_module.LookupModule

# Generated at 2022-06-11 15:01:55.968082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # lookup('config', 'DEFAULT_BECOME_USER')
    result = LookupModule.run(LookupModule, ['DEFAULT_BECOME_USER'], {})
    assert result == [u'root']

    # lookup('config', 'UNKNOWN', on_missing='skip')
    result = LookupModule.run(LookupModule, ['UNKNOWN'], {}, on_missing='skip')
    assert result == []

    # lookup('config', 'UNKNOWN', on_missing='warn')
    result = LookupModule.run(LookupModule, ['UNKNOWN'], {}, on_missing='warn')
    assert result == []

    # lookup('config', 'UNKNOWN')

# Generated at 2022-06-11 15:02:05.494538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({'var_options': {'abc': 'abc', 'xyz': 'xyz'}})
    with pytest.raises(AnsibleOptionsError) as error:
        lookup_plugin.run(['DEFAULT_ROLES_PATH'])

    with pytest.raises(AnsibleOptionsError) as error:
        lookup_plugin.run(['DEFAULT_ROLES_PATH'], on_missing='invalid')

    with pytest.raises(AnsibleError) as error:
        lookup_plugin.run(['DEFAULT_ROLES_PATH'], on_missing='error')

    with pytest.raises(AnsibleOptionsError) as error:
        lookup_plugin

# Generated at 2022-06-11 15:02:16.044935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test case 1 - Default values for on_missing and plugin_type
    # on_missing = 'error', plugin_type = None
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    result = lookup_module.run(terms, variables)
    expect_result = [C.DEFAULT_BECOME_USER]
    assert result == expect_result

    # Test case 2 - to check on_missing values
    terms = ['DEFAULT_ROLES_PATH']
    variables = {}
    # on_missing = "error"
    lookup_module.set_options(var_options=variables)
    result = lookup_module.run(terms, variables)
    expect_result = [C.DEFAULT_ROLES_PATH]
    assert result == expect_result

# Generated at 2022-06-11 15:02:21.622173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['inventory']
    #assert lookup_module.run(terms,variables=None,on_missing=None) == ['/etc/ansible/hosts']
    assert lookup_module.run(terms,variables=None,on_missing='error') == []
    assert lookup_module.run(terms,variables=None,on_missing='warn') == []
    assert lookup_module.run(terms,variables=None,on_missing='skip') == []

# Generated at 2022-06-11 15:02:31.264035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Create a LookupModule object.
    lookup = LookupModule()
    # Set values of members.
    lookup._display = Sentinel()
    lookup._templar = Sentinel()

    # Prepare setting which will be used as terms parameter.
    terms = [Sentinel(), Sentinel()]

    # Prepare variables setting which will be used as variables parameter.
    variables = {
        'foo': 'bar',
        'baz': 'qux'
    }

    # Prepare kwargs setting which will be used as kwargs parameter.
    kwargs = {
        'plugin_type': 'shell',
        'plugin_name': 'sh'
    }

    # Test with default on_missing setting.

# Generated at 2022-06-11 15:02:31.818317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:02:37.916805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Exercise the run() method of the LookupModule class"""
    # All of the following tests use the same starting conditions:
    #   1. a valid configuration value
    #   2. a configuration value that will raise a non-fatal error
    #   3. a configuration value that does not exist
    # The configuration values used are hard-coded in the source code and
    # should be changed if they are modified in the code.
    #
    # Note that the following tests do not exercise the config code inside
    # of ansible. Older versions of the config (pre-2.8.0) had a bug where
    # some of the lookup_plugin values were not set as variables and this
    # caused the config code to return None instead of raising an error.
    # The tests that are impacted by that bug were commented out until the
    # bug has been fixed

# Generated at 2022-06-11 15:02:45.581646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["ANSIBLE_ROLES_PATH", "ANSIBLE_RETRY_FILES_SAVE_PATH", "ANSIBLE_CACHE_PLUGIN_CONNECTION"]
    ptype = "vars"
    pname = "host_info"
    missing = "error"
    module.set_options(direct={'plugin_type': ptype, 'plugin_name': pname, 'on_missing': missing})

    assert isinstance(terms, list)
    assert isinstance(missing, str)
    assert isinstance(ptype, str)
    assert isinstance(pname, str)
    assert len(terms) > 0

    assert module.run(terms)

# Generated at 2022-06-11 15:03:00.792444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.plugins.loader import LookupModule

  lookup_module = LookupModule()
  results = lookup_module.run(['DEFAULT_BECOME_USER'], {})
  assert results[0] == 'root'

# Generated at 2022-06-11 15:03:11.399109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
       pass

    mock_loader = TestLookupModule()
    term_list = ['DEFAULT_ROLES_PATH']
    variables=dict(DEFAULT_ROLES_PATH="/etc/ansible/roles:/usr/share/ansible/roles")
    plugin_type = 'lookup'
    plugin_name = 'plugin_name'
    on_missing = 'error'
    supplied_variable = dict(plugin_type=plugin_type,
                             plugin_name=plugin_name,
                             on_missing=on_missing)
    results = mock_loader._get_plugin_config(plugin_name, plugin_type, term_list, variables)
    for res in results:
        assert res in term_list, 'Expected result to be in term_list'

# Generated at 2022-06-11 15:03:22.176591
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # Test invalid options
    try:
        lookup.run([], variables=None, **{'plugin_type': 'cliconf'})
        assert False, 'we should not get here'
    except AnsibleOptionsError:
        pass
    try:
        lookup.run([], variables=None, **{'plugin_name': 'ios'})
        assert False, 'we should not get here'
    except AnsibleOptionsError:
        pass
    # Test invalid on_missing option
    try:
        lookup.run([], variables=None, **{'on_missing': 'invalid'})
        assert False, 'we should not get here'
    except AnsibleOptionsError:
        pass
    # Test invalid config setting

# Generated at 2022-06-11 15:03:25.235001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    result = plugin.run([["DEFAULT_BECOME_USER"]], dict())
    assert result == ["root"]

# Generated at 2022-06-11 15:03:25.787559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:03:34.975991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as loader
    import ansible.plugins.lookup.config as config
    import tempfile

    fd, path = tempfile.mkstemp()
    with open(path, "w") as f:
        f.write("""
[inventory_plugins]
custom.*=%s
""" % path)

    configpath = os.path.dirname(config.__file__)
    lm = loader.LookupModule(loader.find_plugin(os.path.join(configpath, "config.py")))

    terms = ["DEFAULT_REMOTE_TMP", "UNKNOWN_REMOTE_TMP"]

# Generated at 2022-06-11 15:03:44.716578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_module = LookupModule()

    # Call _get_global_config with valid term and variables
    result = lookup_module._get_global_config(C.DEFAULT_LOG_PATH)

    # Assert if the result is equal to the expected value
    assert result == C.DEFAULT_LOG_PATH

    # Call _get_global_config with invalid term and valid variables
    try:
        lookup_module._get_global_config(C.DEFAULT_FOO_BAR)
    except MissingSetting as e:
        pass

    # Create an instance of class LookupModule
    lookup_module = LookupModule()

    # Call _get_plugin_config with valid plugin name, type and variables

# Generated at 2022-06-11 15:03:56.291925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = LookupModule()
    terms = ('module_setup', 'roles_path', 'become_user', 'host_key_checking')
    # Lookup global config values
    assert r.run(terms) == [True, ['roles'], 'root', True]
    assert r.run(terms, variables={'DEFAULT_ROLES_PATH': ['test1', 'test2']}) == [True, ['test1', 'test2'], 'root', True]
    # Lookup without terms
    with pytest.raises(AnsibleOptionsError):
        r.run()
    # Lookup without terms (with variables)
    with pytest.raises(AnsibleOptionsError):
        r.run(variables={'DEFAULT_ROLES_PATH': ['test1', 'test2']})
    #

# Generated at 2022-06-11 15:04:01.511288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_option = lambda option: option
    l.set_options(var_options={})
    assert l.run(terms='ANSIBLE_LIBRARY') == ['/usr/share/ansible']
    assert l.run(terms='ANSIBLE_INVENTORY') == ['/etc/ansible/hosts']


# Generated at 2022-06-11 15:04:05.366983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = None
    try:
        result = LookupModule().run(terms='test', variables={})
    except Exception:
        print("test_LookupModule_run")
        print("test_LookupModule_run")
        print("test_LookupModule_run")
        raise Exception
    assert result == None

# Generated at 2022-06-11 15:04:26.835087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_sentinel = Sentinel()
    mock_options = {'plugin_name': 'mock', 'plugin_type': 'connection', 'var_options': {}, 'direct': {}}
    mock_module = type('module', (object,), {'get_option': lambda self,opt: mock_options[opt]})
    config_setting = 'mock_setting'
    config_setting_value = 'mock_setting_value'

    def mock_get_plugin_config(plugin_name, plugin_type, config_setting, variables=None):
        assert plugin_name == mock_options['plugin_name']
        assert plugin_type == mock_options['plugin_type']
        assert config_setting == config_setting
        assert variables == mock_options['var_options']
        return mock_sentinel


# Generated at 2022-06-11 15:04:32.499261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    test_LookupModule_run: test the scenario of 'run' method of LookupModule class
    '''
    lookup_mod = LookupModule()
    # running the 'run' method of LookupModule class
    # with valid parameters
    lookup_mod.run(terms=["DEFAULT_BECOME_USER"])

    # running the 'run' method of LookupModule class
    # with missing parameters
    try:
        lookup_mod.run(terms=["DEFAULT_BECOME_UUUUSER"])
    except AnsibleLookupError:
        assert True
    except:
        assert False

    # running the 'run' method of LookupModule class
    # with missing parameter for plugin_type

# Generated at 2022-06-11 15:04:34.905261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(terms=["DEFAULT_BECOME_USER", "DEFAULT_BECOME_PASS"], on_missing="error")

# Generated at 2022-06-11 15:04:46.710302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import logging
    import os
    import sys

    try:
        import __main__
        __main__.lookup = __import__('ansible.plugins.lookup.config')
    except ImportError:
        # define a fake module to hold the lookup_plugin
        import imp
        module = imp.new_module('__main__')
        sys.modules['__main__'] = module
        module.lookup = __import__('ansible.plugins.lookup.config')

    # set up a fake display for the lookup plugin logger
    class FakeDisplay:
        def __init__(self):
            self.logged_msgs = []

        def warning(self, msg):
            self.logged_msgs.append(msg)

    fake_display = FakeDisplay()
    module.lookup.display = fake_display

   

# Generated at 2022-06-11 15:04:51.379596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._terms = ['DEFAULT_BECOME_USER']
    lookup_module._options = {'on_missing': 'error'}
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']


# Generated at 2022-06-11 15:05:02.259353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # call method run of class LookupModule
    result = module.run(["DEFAULT_ROLES_PATH"], {"playbook_dir" : "playbook_dir_1"}, plugin_type="vars")
    # result should be an array
    assert isinstance(result, list)
    # it should not be empty
    assert result != []
    # each item should be a string
    assert all(isinstance(x, str) for x in result)
    # it should contain the system setting for roles
    assert "/etc/ansible/roles:/usr/share/ansible/roles" in result
    # it should also contain the playbook_dir/roles
    assert "playbook_dir_1/roles" in result

    # now call the run method with an unknown setting in on_missing='error

# Generated at 2022-06-11 15:05:08.212915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['DEFAULT_ROLES_PATH']
    test_variables = {'a': 'b'}
    test_options = {}
    test_kwargs = {}

    lookup_module = LookupModule()

    lookup_module.set_options(var_options=test_variables, direct=test_options)

    result = lookup_module.run(terms=test_terms, variables=test_variables, **test_kwargs)

    assert result == [['./roles', './', '~/roles', '/etc/ansible/roles']]

# Generated at 2022-06-11 15:05:19.485021
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as loader
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import action_loader

    # create the objects that are needed by the LookupModule class
    LookupModule.display = loader.get_plugin('display')
    LookupModule.display.verbosity = 5
    LookupModule.display.verbosity = 5
    lookup_pr = lookup_loader._create_plugin_class('LookupModule')
    lookup_obj = lookup_pr()
    action_pr = action_loader._create_plugin_class('LookupModule')
    action_obj = action_pr()

    # create the object

# Generated at 2022-06-11 15:05:25.806985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_obj = LookupModule()
    lookup_opts = {'wantlist': True, 'on_missing' : 'skip'}
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = class_obj.run(terms, variables=None, **lookup_opts)
    assert (result[0] == 'root')
    assert (result[1] == './roles:./library:./vendor/roles:~/.ansible/roles')

# Generated at 2022-06-11 15:05:33.156559
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    # test successful config lookup
    returned_value = lookup_module.run(["COLLECTION_PATH"], terms=["COLLECTION_PATH"])
    assert returned_value == [ C.COLLECTION_PATH ]
    # test failed config lookup
    try:
        lookup_module.run(["UNKNOWN_OPTION"], terms=["UNKNOWN_OPTION"])
    except MissingSetting:
        pass
    else:
        assert False, 'MissingSetting exception should be raised'

# Generated at 2022-06-11 15:06:04.009978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ls = LookupModule()
    ls.set_options(var_options=None,direct=None)
    assert ls.run(['DEFAULT_REMOTE_USER'],variables=None,**{}) == ['root']

# Generated at 2022-06-11 15:06:09.749277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config_lookup = LookupModule()
    result = config_lookup.run([], None)
    assert result == []
    result = config_lookup.run(['DEFAULT_BECOME_USER'], None)
    assert result[0] == 'root'
    from ansible.constants import DEFAULT_VAULT_IDENTITY_LIST
    result = config_lookup.run(['DEFAULT_VAULT_IDENTITY_LIST'], None)
    assert result[0] is DEFAULT_VAULT_IDENTITY_LIST


# Generated at 2022-06-11 15:06:20.652559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test fixture
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=dict())

    # Test missing 'on_missing' option
    with pytest.raises(AnsibleOptionsError) as result:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    assert 'required' in str(result)

    # Test 'on_missing' option not one of "error", "warn" or "skip"
    with pytest.raises(AnsibleOptionsError) as result:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='something')
    assert 'required' in str(result)

    # Test 'on_missing' option is None

# Generated at 2022-06-11 15:06:27.849090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(terms=['DEFAULT_BECOME_USER']) == ['root']
    assert module.run(terms=['FAKE_SETTING'], variables={'FAKE_SETTING': 'fake'}) == ['fake']
    assert module.run(terms=['FAKE_SETTING'], variables={'FAKE_SETTING': ['fake']}) == [['fake']]
    assert module.run(terms=['FAKE_SETTING'], on_missing='skip') == []
    assert module.run(terms=['FAKE_SETTING'], on_missing='warn') == []
    assert module.run(terms=['FAKE_SETTING'], on_missing='error') == []

# Generated at 2022-06-11 15:06:38.586520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   # Used to test the method run a LookupModule, will be changed to proper unit test in future
   # Assumption for the test:
   # 1. Configuration file (ansible.cfg) is in the same folder as the python file, in this case the test file
   # 2. ansible.cfg contains the following, which are the default settings
   # [defaults]
   # ask_pass = True
   # ask_sudo_pass = True
   # ask_su_pass = True
   # ask_vault_pass = True
   #
   lookup_module = LookupModule()
   lookup_module.set_options(var_options=None)

   result = lookup_module.run(["ask_pass"])
   assert result == ["True"]

   result = lookup_module.run(["missing_key"])
   assert result == []

# Generated at 2022-06-11 15:06:46.393335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_base = LookupBase()
    assert hasattr(lookup_base, 'run')
    lookup = LookupModule()
    lookup.set_options(var_options='foo')
    assert lookup.get_option('var_options') == 'foo'
    assert lookup.run(terms='foo') == ['foo']
    assert lookup.run(terms=['foo'], variables=['foo']) == ['foo']
    assert lookup.run(terms=[1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 15:06:57.949191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase

    # Use the lookup module - const
    lookup_plugin_class = lookup_loader.find_plugin("config")
    lookup_plugin_instance = lookup_plugin_class()


    # Create a mock variables dictionary
    vardict = dict(foo="bar")

    # Check on_missing is "error" by default
    # If a setting is not found then AnsibleLookupError should be raised
    terms = ["DEFAULT_ROLES_PATH"]
    try:
        lookup_plugin_instance.run(terms, vardict)
    except AnsibleLookupError:
        pass
    except Exception as e:
        # If any other exception gets raised but not AnsibleLookupError then it's a bug
        assert False

   

# Generated at 2022-06-11 15:07:07.675613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    temp = {
        'plugin_type': 'shell',
        'plugin_name': 'sh',
        'on_missing': 'error',
        'wantlist': True
    }
    terms = ['remote_tmp']
    from ansible.plugins.loader import lookup_loader
    lookup_module = lookup_loader.get('config')
    result = lookup_module.run(terms, **temp)
    assert result == [C.DEFAULT_REMOTE_TMP]
    assert lookup_module.run(terms, on_missing='warn') == []
    assert lookup_module.run(terms, on_missing='skip') == []
    terms = ['bad_term', 'DEFAULT_MODULE_PATH']
    assert lookup_module.run(terms, **temp) == [None, C.DEFAULT_MODULE_PATH]

# Generated at 2022-06-11 15:07:11.517252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    sys.path.append("lib/ansible/plugins/lookup")
    from config import LookupModule
    lookupmodule =  LookupModule()
    assert lookupmodule.run(["DEFAULT_BECOME_USER"]) == ['root']

# Generated at 2022-06-11 15:07:22.199192
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

    become = become_loader.get('sudo', class_only=True)
    ssh = connection_loader.get('ssh', class_only=True)
    sh = shell_loader.get('sh', class_only=True)

    # testing lookup config for become plugins
    assert isinstance(LookupModule().run(['DEFAULT_BECOME_USER'], variables={}), list)
    assert LookupModule().run(['DEFAULT_BECOME_PLUGIN'], variables={}, plugin_type='become', plugin_name=become._load_name) == become._load_name

# Generated at 2022-06-11 15:08:23.457282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run("DEFAULT_BECOME_USER")

# Test ansible-doc

# Generated at 2022-06-11 15:08:24.100810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:08:34.487050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    loader, inventory, variable_manager, loader_pattern, host_list = setup_inventory()
    variable_manager.extra_vars = {'host_file': 'inventory/hosts', 'host_list': host_list}


# Generated at 2022-06-11 15:08:42.691066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    c = LookupModule()
    c.run(['DEFAULT_BECOME_USER'])
    c.run(['DEFAULT_BECOME_USER'], on_missing='warn')
    c.run(['DEFAULT_BECOME_USER'], on_missing='skip')

    try:
        c.run(['DEFAULT_BECOME_USER'], on_missing='unsupported')
        assert False, 'Should have raised AnsibleOptionsError'
    except AnsibleOptionsError:
        pass

    c.run([1], raise_errors=True)

# Generated at 2022-06-11 15:08:48.983117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_args = dict(
        _terms=['vault_password_files'],
        on_missing='error'
    )
    config = dict(
        vault_password_files=['/etc/ansible/vaultkeys']
    )
    assert LookupModule.run(LookupModule(), module_args, config) == ['/etc/ansible/vaultkeys']
    config.pop('vault_password_files')
    assert LookupModule.run(LookupModule(), module_args, config) == []
    module_args['on_missing'] = 'warn'
    assert LookupModule.run(LookupModule(), module_args, config) == []



# Generated at 2022-06-11 15:08:50.724451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_cls = LookupModule()
    assert lookup_cls is not None

# Generated at 2022-06-11 15:09:02.104417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # The following is test for init method of class LookupBase.
    assert lookup.set_options
    assert lookup._templar

    loader = AnsibleLoader()
    # The following is test for method run
    terms = ["DEFAULT_BECOME_USER"]
    result = lookup.run(terms=terms)
    assert result[0] == 'root'

    # The following is test for on_missing error
    terms = ["DEFAULT_BECOME_USER", "UNKNOWN"]
    try:
        lookup.run(terms=terms)
    except AnsibleLookupError as err:
        assert "Unable to find setting UNKNOWN" in err.args[0]

    # The following is test for on_missing warn
    terms = ["UNKNOWN"]

# Generated at 2022-06-11 15:09:14.707412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    # test terms is not string
    terms = [None, 'dummy']
    variables = {'var1': 'dummy1', 'var2': 'dummy2'}
    options = {}
    with pytest.raises(AnsibleOptionsError) as excinfo:
        LookupModule.run(terms, variables, options)
    assert 'Invalid setting identifier, "None" is not a string' in to_native(excinfo.value)

    # test on_missing is not string
    terms = ['dummy']
    variables = {'var1': 'dummy1', 'var2': 'dummy2'}
    options = {'on_missing': []}

# Generated at 2022-06-11 15:09:20.047760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(list(LookupModule(None).run(('C.DEFAULT_MODULE_NAME',)))) == 1
    assert len(list(LookupModule(None).run(('DEFAULT_MODULE_NAME',)))) == 1
    assert len(list(LookupModule(None).run(('DEFAULT_MODULE_NAME', 'DEFAULT_KEEP_REMOTE_FILES'), variables={'DEFAULT_MODULE_NAME': 'command'}))) == 2

# Generated at 2022-06-11 15:09:30.935265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test unit tests are generating expected output
    assert True == True

    # Test run is raising AnsibleOptionsError with terms as empty string
    t = LookupModule()
    terms = ''
    variables = ''
    try:
        t.run(terms, variables)
        assert False
    except AnsibleOptionsError:
        assert True

    # Test run is raising AnsibleOptionsError with terms as list of empty strings
    terms = ['', '']
    try:
        t.run(terms, variables)
        assert False
    except AnsibleOptionsError:
        assert True

    # Test run is raising AnsibleOptionsError with terms as a list of non-string objects
    terms = [None, None]
    try:
        t.run(terms, variables)
        assert False
    except AnsibleOptionsError:
        assert True

    # Test