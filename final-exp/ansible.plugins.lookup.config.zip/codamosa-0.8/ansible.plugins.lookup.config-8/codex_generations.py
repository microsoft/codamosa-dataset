

# Generated at 2022-06-11 15:01:39.228349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ptype = 'connection'
    pname = 'local'
    variables = {'inventory_config_path': './inventories/'}
    result = lookup_module.run(["ANSIBLE_CONFIG", "ANSIBLE_LIBRARY"], variables, plugin_type=ptype, plugin_name=pname)
    assert result == ['/home/jkremser/.ansible.cfg', None]
    result = lookup_module.run(["ANSIBLE_ROLES_PATH"], variables, plugin_type=ptype, plugin_name=pname)
    assert result == ['/home/jkremser/.ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-11 15:01:49.319034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Set up
    import os

    this_dir = os.path.dirname(os.path.realpath(__file__))
    lookup = os.path.join(this_dir, '..', 'lookup_plugins', 'config.py')

    if not os.path.exists(lookup):
        # Test if skipped
        assert True
        return

    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager
        import ansible.constants as C
    except ImportError:
        # Test if skipped
        assert True


# Generated at 2022-06-11 15:01:56.641911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # test method run of class LookupModule
    def test_run(self, *args, **kwargs):
        """Unit test for method run of class LookupModule"""

        # create a new setting
        self.set_options(var_options=None, direct=kwargs)

        # create a new setting
        missing = self.get_option('on_missing')

        # create a new setting
        ptype = self.get_option('plugin_type')

        # create a new setting
        pname = self.get_option('plugin_name')

        # test return value of method run of class LookupModule
        ret = []

        # test return value of method run of class LookupModule
        result = None

        return ret

# Generated at 2022-06-11 15:02:01.786717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule
    config = {"remote_port": "1111", "remote_user": "ansible", "port": "22"}
    lookup_module = LookupModule()
    assert lookup_module.run(["remote_port", "remote_user"], config) == ["1111", "ansible"]
    assert lookup_module.run(["port"], config) == ["22"]

# Generated at 2022-06-11 15:02:04.793397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    results = ['ok', 'changed']
    terms = ['COLOR_OK', 'COLOR_CHANGED']

    result = t.run(terms)
    assert result == results


# Generated at 2022-06-11 15:02:06.519919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["foo"]) == [Sentinel]

# Generated at 2022-06-11 15:02:12.493903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["port", "remote_user"]
    terms_list = [terms]
    variables = []
    direct = {"plugin_type": "connection", "plugin_name": "local"}
    lookup_module.set_options(var_options=variables, direct=direct)
    run_result = lookup_module.run(terms, variables=variables, **direct)
    assert run_result == ["22", "root"]



# Generated at 2022-06-11 15:02:16.641177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    config = {'ansible_connection': 'ssh'}
    actual = LookupModule(load_options=config)
    # Actual
    actual = actual.run([])
    # Assert
    assert actual == ['ssh']


# Generated at 2022-06-11 15:02:20.859157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    config = {'plugin_type': 'become'}
    variables = {}
    on_missing = 'error'
    l = LookupModule()
    l.set_options(None, config)
    l.run(terms, variables, on_missing)


# Generated at 2022-06-11 15:02:30.430206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Since this is a helper module, it will not be loaded and invoked by ansible
    # but we can test it by getting reference to the class and calling its run method
    # directly.
    import ansible.utils.module_docs as module_docs
    lookup_cls = module_docs.find_plugin('LookupModule', class_only=True)

    # assert LookupModule.run
    global_config = {
        'DEFAULT_ROLES_PATH': ['/home/user/.ansible/roles', '/usr/share/ansible/roles']
    }
    lookup_obj = lookup_cls()
    lookup_obj.set_options(var_options=global_config)
    result = lookup_obj.run(['DEFAULT_ROLES_PATH'])

# Generated at 2022-06-11 15:02:53.368076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    try:
        lookup_module.run(['DEFAULT_BECOME_USER'], {})
    except AnsibleLookupError as e:
        print("Caught exception: " + to_native(e))
        assert False


# Generated at 2022-06-11 15:03:02.974420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible.plugins.loader import vars_loader
        from ansible.plugins.lookup import LookupBase
        from ansible.utils.sentinel import Sentinel
        from ansible.utils.display import Display
        from ansible.vars import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.utils.vars import load_extra_vars
        from ansible.parsing.dataloader import DataLoader
        from ansible.constants import defs

        if not hasattr(defs, 'DEFAULT_ROLES_PATH'):
            raise SkipTest('The DEFAULT_ROLES_PATH environment variable is not defined.')
    except ImportError:
        raise SkipTest('Ansible environment cannot be loaded.')

    # Create the config object used to parse user input.

# Generated at 2022-06-11 15:03:06.570843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = lookup.run(terms)
    assert result == ['root', '/etc/ansible/roles']

# Generated at 2022-06-11 15:03:18.149424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    t = ['DEFAULT_FROM_EMAIL', 'DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']
    v = {'HOME': '/root'}
    assert (l.run(t) == [C.DEFAULT_FROM_EMAIL, C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER])
    assert (l.run([t[0]], v) == [C.DEFAULT_FROM_EMAIL])
    assert (l.run([t[1]], v) == [C.DEFAULT_ROLES_PATH])
    assert (l.run([t[2]], v) == [C.DEFAULT_BECOME_USER])

# Generated at 2022-06-11 15:03:19.835149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Provide the unit test for the function
    pass

# Generated at 2022-06-11 15:03:30.924779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # GetLookupModule
    print("Test")
    lookupCls = lookup.LookupModule()
    # Create the lookup with the list of input data
    # Input data should be key value paired list with the first element as the key and the value being the second element
    # In this case, the key is "DEFAULT_BECOME_USER" and the value is "root".
    # Type of the value is a list
    # Dictionary of the input data is defined in the constructor
    lookupCls.lookup_opts = dict(DEFAULT_BECOME_USER=["root"])
    # Retrieve the value associated with a key
    result = lookupCls.run()
    print(result)
    assert result == "root"


# Generated at 2022-06-11 15:03:38.818233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of a LookupModule
    lm = LookupModule()
    # Create a dummy variables object to be passed to the lookup module
    variables = {}
    # Create a dictionary to be use as the terms object to be passed to the lookup module
    terms = [{'_ansible_verbosity': '4'}, {'DEFAULT_ROLES_PATH': '/home/shelbyspeegle/ansible/roles:/usr/share/ansible/roles'}]
    # Create a dictionary to be used as the kwargs object to be passed to the lookup module
    kwargs = {}
    # Expected result of the run method call
    expectedResult = ['4', ['/home/shelbyspeegle/ansible/roles', '/usr/share/ansible/roles']]
    # Make the call

# Generated at 2022-06-11 15:03:44.206629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    options = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    test_terms = ['remote_tmp', 'remote_interrupt']

    ret = lookup.run(test_terms, **options)
    assert len(ret) == len(test_terms)
    assert ret[0] is not None
    assert ret[1] is not None

# Generated at 2022-06-11 15:03:55.052379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing simple vars
    terms = ['DEFAULT_BECOME_USER','inventory','NORMAL','UNREACHABLE','PARSED','UNREACHABLE','UNREACHABLE','CONNECTION','CONNECTION','connection:local', 'fart']
    missing='error'
    variables="abc"
    kwargs='xyz'

    # Checking for :
    # Variable initialized properly
    assert terms == ['DEFAULT_BECOME_USER','inventory','NORMAL','UNREACHABLE','PARSED','UNREACHABLE','UNREACHABLE','CONNECTION','CONNECTION','connection:local', 'fart']
    assert missing == 'error'
    assert variables == "abc"
    assert kwargs == 'xyz'

# Generated at 2022-06-11 15:04:04.907506
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:04:27.679538
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:04:29.955889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    #Adding the method to support unit testing.
    # The tests are not yet implemented as all the returning values are not yet decided
    """

    assert False

# Generated at 2022-06-11 15:04:42.672752
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def __init__(self, *args, **kwargs):
        pass

    def run(self, terms, variables=None, **kwargs):
        return terms[0]

    obj = LookupModule(*args, **kwargs)
    obj.get_option = mock
    obj.get_option.side_effect = ['error', None, None]
    obj.set_options = __init__

    def test():
        return obj.run(terms, variables=None)

    # on_missing='error' is default, so 'error' is returned
    obj.get_option.side_effect = ['error', None, None]
    assert test() == 'error'

    # on_missing='warn' is not expected
    obj.get_option.side_effect = ['warn', None, None]

# Generated at 2022-06-11 15:04:49.663309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = LookupModule()
    assert p.run(terms=['INVALID_TERM'], variables={}) == []
    assert p.run(terms=['INVALID_TERM'], on_missing='warn') == []
    assert p.run(terms=['INVALID_TERM'], on_missing='skip') == []
    assert p.run(terms=['DEFAULT_BECOME_USER'], variables={})[0] == 'root'

# Generated at 2022-06-11 15:05:00.611088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup mocks of LookupModule and AnsiblePlugin
    import imp
    import json
    import os
    import sys

    current_folder = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.path.join(current_folder, '../../'))

    test_utils = imp.load_source('test_utils', os.path.join(current_folder, 'test_utils.py'))

    imp.load_source('ansible.plugins.loader', os.path.join(current_folder, '../../lib/ansible/plugins/loader/__init__.py'))

# Generated at 2022-06-11 15:05:06.898838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import pytest

    sys.path.insert(0, os.path.dirname(__file__))

# Generated at 2022-06-11 15:05:17.912570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    strategy = 'linear'
    hostvars = {'testhost': {'ansible_connection': 'local'}}
    new_variables = {'inventory_hostname': 'testhost', 'ansible_connection': 'local'}
    ansible_vars = {'inventory_dir': '/home/ansible/inventory', 'playbook_dir': '/home/ansible/test'}
    terms = ['ANSIBLE_NOCOWS', 'ANSIBLE_DEBUG']
    kwargs = {'var_options': new_variables, 'direct': ansible_vars, 'strategy': strategy, 'hostvars': hostvars}
    lookup_plugin.set_options(**kwargs)
    result = lookup_plugin.run(terms)
    assert result == [False, False]

# Generated at 2022-06-11 15:05:27.388914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import os
    import shlex
    import tempfile

    # test that a malformed plugin name raises AnsibleOptionsError
    lu = LookupModule()
    terms = [ 'foo' ]
    ret = lu.run(terms, {}, plugin_type='foo', plugin_name='bar')
    assert ret == []

    # test using plugin_name and plugin_type and lookup value is present
    lu = LookupModule()
    terms = [ 'ansible_shell_type' ]
    variables = { 'ansible_shell_type': 'csh' }
    ret = lu.run(terms, variables, plugin_type='shell', plugin_name='csh')
    assert ret == [ 'csh' ]

    # test using plugin_name and plugin_type and lookup value is missing
    lu = Look

# Generated at 2022-06-11 15:05:38.007167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    from ansible.plugins.loader import lookup_loader, connection_loader
    from ansible.config.manager import ConfigManager, Setting
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup = lookup_loader.get('config')
    connection = connection_loader.all()
    tmp = tempfile.mkdtemp()


# Generated at 2022-06-11 15:05:47.874558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    The test for the method "run" for class "LookupModule"
    '''

    # Setup
    # Dummy variable that does not exist in config
    dummy_config = 'dummy_config'

    # Dummy variable that does not exist in plugin
    dummy_plugin = 'dummy_plugin'

    # Dummy variable that does not exist in plugin's config
    dummy_plugin_config = 'dummy_plugin_config'

    # Instantiate with dummy
    inst = LookupModule()

    # Test 1 (Config variable exists)
    # Test 1.1 (Retrieve config variable)
    # We're gonna use a variable that we're sure exists
    test1_term = 'INVENTORY_ENABLED'

    # Run
    result1 = inst.run(term=[test1_term])

    # Ass

# Generated at 2022-06-11 15:06:23.894230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ("UNKNOWN", "COLOR_OK", "COLOR_SKIP", "COLOR_ERROR", "COLOR_STD", "COLOR_WARN")
    on_missing = 'error'
    plugin_type = None
    plugin_name = None

    LookupModule().run(terms, on_missing=on_missing, plugin_type=plugin_type, plugin_name=plugin_name)

# Generated at 2022-06-11 15:06:34.589035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
        unit test for lookup module run method
        Assume that configuration already exists
    '''
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    lookup_results = lookup.run(terms)
    assert type(lookup_results) is list
    assert len(lookup_results) == 1
    assert lookup_results[0] == 'root'

    lookup = LookupModule(loader=None, templar=None, variables=None)
    terms = ['DEFAULT_BECOME_USER']
    lookup_results = lookup.run(terms)
    assert type(lookup_results) is list
    assert len(lookup_results) == 1
    assert lookup_results[0] == 'root'


# Generated at 2022-06-11 15:06:46.268494
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_run = LookupModule()

# Generated at 2022-06-11 15:06:52.274284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin_name = 'test'
    plugin_type = 'shell'
    terms = ['remote_tmp', 'unknown']
    variables = {'a': 'b'}
    kwargs = {'plugin_type': plugin_type, 'plugin_name': plugin_name}
    test_lookup = LookupModule()
    assert test_lookup.run(terms, variables, **kwargs) == [u'/tmp/ansible-test']


# Generated at 2022-06-11 15:07:04.475659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple

    TestCase = namedtuple('TestCase', ['terms', 'config_object', 'variables', 'expect_result', 'expect_msg', 'expect_traceback'])

# Generated at 2022-06-11 15:07:15.459824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for global settings
    LOOKUP_PLUGIN = LookupModule()
    LOOKUP_PLUGIN.set_options(direct={'plugin_type': None})
    # The test is to get the setting of 'ANSIBLE_DEBUG' with the explicit value 'True'
    assert LOOKUP_PLUGIN.run(terms=['ANSIBLE_DEBUG'], variables={'ANSIBLE_DEBUG': True}) == ['True']
    # The test is to get the setting of 'ANSIBLE_DEBUG' with the explicit value 'False'
    assert LOOKUP_PLUGIN.run(terms=['ANSIBLE_DEBUG'], variables={'ANSIBLE_DEBUG': False}) == ['False']
    # The test is to get the setting of 'ANSIBLE_CALLBACK_FILTERS' with the explicit value of list
    assert LOOKUP_PLUGIN.run

# Generated at 2022-06-11 15:07:25.794453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup

    lookup_instance = ansible.plugins.lookup.LookupModule()

    # Test with config term.
    terms = ['DEFAULT_BECOME_USER']
    ret = lookup_instance.run(terms)

    assert terms[0] in ret

    # Test with a config term that does not exist.
    terms = ['DOES_NOT_EXIST']
    try:
        ret = lookup_instance.run(terms)
    except AnsibleError as e:
        ret = str(e)

    assert 'Invalid setting identifier' in ret

    # Test with an invalid config term that is not a string.
    terms = [1]
    try:
        ret = lookup_instance.run(terms)
    except AnsibleError as e:
        ret = str(e)


# Generated at 2022-06-11 15:07:30.863019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_REMOTE_USER']) == ['root', 'root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'UNKNOWN']) == ['root']

    assert lookup.run(terms=['DEFAULT_BECOME_USER'], on_missing='warn') == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'UNKNOWN'], on_missing='warn') == ['root']

    assert lookup.run(terms=['DEFAULT_BECOME_USER'], on_missing='skip') == ['root']

# Generated at 2022-06-11 15:07:31.890023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m

# Generated at 2022-06-11 15:07:36.406156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Only run this test if constants has a value for BECOME_METHODS
    if hasattr(C, 'BECOME_METHODS'):
        assert LookupModule().run(['BECOME_METHODS']) == [C.BECOME_METHODS]

# Generated at 2022-06-11 15:08:47.953323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Empty terms with 'error' in missing, should raise error
    module = LookupModule()
    results = module.run(terms=[], variables=None, on_missing='error')
    assert results == []

    # Empty terms with 'warn' in missing, should warn, but return empty list
    module = LookupModule()
    results = module.run(terms=[], variables=None, on_missing='warn')
    assert results == []

    # Empty terms with 'skip' in missing, should return empty list
    module = LookupModule()
    results = module.run(terms=[], variables=None, on_missing='skip')
    assert results == []

    # Terms with invalid variables, should raise error
    module = LookupModule()

# Generated at 2022-06-11 15:08:58.746137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    fake_loader = DataLoader()
    fake_variable_manager = VariableManager()
    fake_fact_cache = dict()

    # Setup fake context
    context.CLIARGS = ImmutableDict()

    play_context = PlayContext()

    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(fake_loader)
    lookup_plugin.set_variable_manager(fake_variable_manager)
    lookup_plugin.set_fact_cache(fake_fact_cache)
    lookup_plugin._display.verbosity = 3
    terms = ['RETRY_FILES_ENABLED']
    lookup_plugin.run(terms, play_context)

# Generated at 2022-06-11 15:09:05.065207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get_global_config
    config = LookupModule()
    assert config.run(['DEBUG']) == [True]
    assert config.run(['NODEBUG']) == []

    # get_plugin_config
    config = LookupModule()
    assert config.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == ['/var/tmp']

# Generated at 2022-06-11 15:09:05.663242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:09:07.064572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Implementing LookupModule_run test")
    # Add code to test run method of LookupModule
    # raise Exception("Test not implemented")


# Generated at 2022-06-11 15:09:14.624778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Successful case:
    # look up a setting that is in the config
    result = lookup_module.run(terms=["DEFAULT_BECOME_USER"],
                               on_missing="error",
                               plugin_type="become",
                               plugin_name="sudo")
    assert result == ['root']

    # raise error when value is not found
    try:
        result = lookup_module.run(terms=["BECOME_SUDO_BINARY"],
                                   on_missing="error",
                                   plugin_type="become",
                                   plugin_name="sudo")
    except AnsibleLookupError:
        pass

    # skip if value is not found

# Generated at 2022-06-11 15:09:22.662315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run test 1
    mylookup = LookupModule()
    mylookup.set_loader(plugin_loader=plugin_loader.action_loader)
    mylookup.set_loader(plugin_loader=plugin_loader.cache_loader)
    mylookup.set_loader(plugin_loader=plugin_loader.connection_loader)
    mylookup.set_loader(plugin_loader=plugin_loader.shell_loader)
    mylookup.set_loader(plugin_loader=plugin_loader.vars_loader)
    mylookup.set_loader(plugin_loader=plugin_loader.cliconf_loader)
    mylookup.set_loader(plugin_loader=plugin_loader.inventory_loader)

    # LookupModule.run test 2
    mylookup.run(['asd'])

# Generated at 2022-06-11 15:09:34.490930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This method is used to test whether the run method of class LookupModule correctly handles given input.

    test_LookupModule_run() takes in no input and returns a dict that contains dict with keys
        - 'status': string. can either be PASS or FAIL
        - 'trace': string. denotes the stack trace for the test that failed
    """
    testcase_results = []

# Generated at 2022-06-11 15:09:38.105750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    config_variable = 'ANSIBLE_NET_USERNAME'
    terms = [config_variable]
    variables = {config_variable: 'test'}
    result = LookupModule().run(terms, variables=variables)
    assert result == ['test']



# Generated at 2022-06-11 15:09:47.935838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import py.test
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.module_utils.six import string_types
    sys.path.append(os.path.join(os.path.dirname(__file__), 'test_utils'))
    from ansible_test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    class TestAnsibleModule(ModuleTestCase):
        def test_config_inventory_dir(self, mocker):
            from ansible.module_utils.ansible_release import __version__
            mocker.patch.object(AnsibleModule, 'run_command')
            mocker.patch.object(AnsibleModule, 'get_bin_path')