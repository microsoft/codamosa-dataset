

# Generated at 2022-06-11 15:01:39.172034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import copy
    C.CONFIG_FILE = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'config_file_for_unittest')
    test_conf = copy.deepcopy(C)

    test_conf.DEFAULT_INVENTORY = '~/unittest_inventory'
    test_conf.DEFAULT_REMOTE_TMP = '~/unittest_tmp'
    test_conf.DEFAULT_REMOTE_USER = 'unittest_user'
    test_conf.DEFAULT_BECOME_USER = 'unittest_become_user'
    test_conf.DEFAULT_SUDO_USER = 'unittest_sudo_user'
    test_conf.errors = {}
    test_conf.settings = {}

# Generated at 2022-06-11 15:01:49.318044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing execution of global config
    lookup_obj = LookupModule()
    # Testing with config value DEFAULT_BECOME_USER
    term = 'DEFAULT_BECOME_USER'
    returned_value = lookup_obj.run(terms=term)
    assert returned_value == [C.DEFAULT_BECOME_USER]
    # Testing with config value DEFAULT_ROLES_PATH
    term = 'DEFAULT_ROLES_PATH'
    returned_value = lookup_obj.run(terms=term)
    assert returned_value == [C.DEFAULT_ROLES_PATH]
    # Testing with config value RETRY_FILES_SAVE_PATH
    term = 'RETRY_FILES_SAVE_PATH'
    returned_value = lookup_obj.run(terms=term)
    assert returned_

# Generated at 2022-06-11 15:01:54.410773
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['DEFAULT_GATHERING']
    sentence = 'gathering facts'
    result = [sentence]
    assert result == LookupModule().run(terms)


    result = []
    try:
        result = LookupModule().run('INVALID_SETTING')
    except AnsibleException as e:
        assert "Unable to find setting INVALID_SETTING" in e.message

    assert result == []

# Generated at 2022-06-11 15:01:56.236894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(['FAKE_CONFIG'], on_missing='error')
    assert result == []

# Generated at 2022-06-11 15:01:59.095228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ('DEFAULT_BECOME', 'DEFAULT_BECOME_USER')
    actual_results = lookup_module.run(terms)
    assert actual_results == [True, 'root']

# Generated at 2022-06-11 15:02:07.625015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from unittest.mock import MagicMock
  from ansible.vars.hostvars import HostVars
  from ansible.vars.manager import VariableManager
  from ansible.utils.vars import combine_vars

  variables = {'foo': 'bar'}
  variables = combine_vars(variables, HostVars(dict(), "test"))
  variable_manager = VariableManager(loader=None, variables=variables)

  lookup_mock = LookupModule()
  lookup_mock.get_option = MagicMock(side_effect=['error', 'skip', 'warn'])
  lookup_mock.set_options(var_options=variable_manager, direct={})

  assert lookup_mock.run(['DEFAULT_BECOME_USER'], variable_manager) == [None]


# Generated at 2022-06-11 15:02:17.784316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test basic functionality - setting lookup
    configure_lookup_module = {
        '_ansible_options': {
            u'variables': {},
            u'direct': {
                u'plugin_name': None,
                u'plugin_type': None,
                u'on_missing': u'error'
            },
            '_ansible_no_log': False,
            u'shell': False,
            u'_ansible_module_name': u'',
            u'_ansible_module_post_args': '',
            u'_ansible_module_builtin': True,
            '_ansible_diff': False
        }
    }

    # assert true for valid lookup module
    lookup_module = LookupModule(runner=None)

# Generated at 2022-06-11 15:02:26.768670
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['DEFAULT_ROLES_PATH']
    # C.DEFAULT_ROLES_PATH
    # '/etc/ansible/roles:/usr/share/ansible/roles:/usr/share/ansible/plugins/modules/roles'

    # define a fake class
    class AnsibleLookupBase:
        def set_options(self, *args):
            pass


    # create a fake self object
    self = AnsibleLookupBase()

    # create a fake class for option
    class __opts__():
        def __init__(self):
            self.__dict__  = {}


    # create a fake vars object
    class __vars__():
        def __init__(self):
            self.__dict__ = {}


    # create a fake ansible constants

# Generated at 2022-06-11 15:02:35.655335
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import is here to prevent circular import
    from ansible.plugins.loader import config_loader
    from ansible.plugins.loader import get_all_plugin_loaders

    def get_loader(name):
        for loader in get_all_plugin_loaders():
            if name in loader.all():
                return loader

    lm = LookupModule()
    # test the case when on_missing is not specified
    result = lm.run(['DEFAULT_BECOME_USER'])
    assert result[0] == 'root'

    result = lm.run(['UNKNOWN_CONFIG'])
    assert 'did not find setting' in result[0]
    assert len(result) == 1

    # test the case when on_missing is set to 'skip'

# Generated at 2022-06-11 15:02:43.488519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # no plugin
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run([], plugin_name='sh')

    with pytest.raises(AnsibleOptionsError):
        LookupModule().run([], plugin_type="shell")

    # normal usage
    assert LookupModule().run(['DEFAULT_REMOTE_TMP']) == [C.DEFAULT_REMOTE_TMP]
    # regular usage with a plugin
    assert LookupModule().run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == [C.config.get_config_value('remote_tmp', plugin_type='shell', plugin_name='sh')]

    # missing setting
    with pytest.raises(AnsibleLookupError):
        LookupModule().run

# Generated at 2022-06-11 15:03:04.446281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Retrieve global config
    lookup_plugin = LookupModule()
    global_config  = lookup_plugin.run(["COLLECTION_PATH"])[0]
    assert global_config == C.COLLECTION_PATH

    #Retrieve config for connection ssh plugin
    lookup_plugin = LookupModule()
    ssh_config  = lookup_plugin.run(["port", "remote_user"], plugin_name="ssh", plugin_type="connection")
    assert ssh_config[0] == C.config.get_config_value("port", plugin_type="connection", plugin_name="ssh")
    assert ssh_config[1] == C.config.get_config_value("remote_user", plugin_type="connection", plugin_name="ssh")

    #Retrieve config for multiple plugins
    lookup_plugin = LookupModule()

# Generated at 2022-06-11 15:03:16.061921
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up parameters and mocks
    terms = ['foo', 'bar', 'baz']
    variables = None
    kwargs = {'on_missing': 'error', 'plugin_name': 'ssh', 'plugin_type': None, 'config': '/path/to/ansible.cfg'}
    config_mock = MagicMock(return_value=getattr(C, 'RETRY_FILES_ENABLED'))
    file_config_mock = MagicMock(return_value=getattr(C, 'DEFAULT_ROLES_PATH'))
    display_mock = MagicMock(spec=AnsibleDisplay)
    error_mock = MagicMock()

    # set up mock
    imp.find_module('ansible.module_utils.six')
    six_mock = MagicMock()

# Generated at 2022-06-11 15:03:20.401526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils import plugin_docs

    assert 'the type of the plugin referenced by "plugin_name" option.' in plugin_docs('lookup/config')
    assert 'name of the plugin for which you want to retrieve configuration settings.' in plugin_docs('lookup/config')

# Generated at 2022-06-11 15:03:23.899932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(['DEFAULT_BECOME_USER'], dict())

# Generated at 2022-06-11 15:03:32.891950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Stub class
    class StubDisplay(object):
        def __init__(self):
            self.messages = []

        def display(self, msg, color=None):
            self.messages.append(msg)

        def info(self, msg):
            self.messages.append(msg)

        def warning(self, msg):
            self.messages.append(msg)

        def error(self, msg):
            self.messages.append(msg)

    # Stub class
    class StubOptions(object):
        def __init__(self, options, direct=None):
            self.options = options
            self.direct = direct

    # Stub class

# Generated at 2022-06-11 15:03:40.059363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # Check if the method returns correct value of global configuration
    lm.set_options(direct={'on_missing': 'warn'})
    result = lm.run((('DEFAULT_BECOME_USER',)))
    assert result == [C.DEFAULT_BECOME_USER]
    # Check for not existing global configuration
    with pytest.raises(AnsibleOptionsError):
        lm.run((('NOT_EXISTING_KEY',)))
    # Check for not existing plugin configuration
    lm.set_options(direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'not_existing_plugin_name'})
    with pytest.raises(AnsibleLookupError):
        lm.run((('remote_tmp',)))

# Generated at 2022-06-11 15:03:48.293725
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    f = LookupModule()
    f._display = DummyDisplay()

    assert f.run([''], on_missing='skip') == []

    # Check that it ignores current C.DEFAULT_CACHE_PLUGIN
    assert f.run(['DEFAULT_CACHE_PLUGIN'], on_missing='skip') == []

    # Check that it returns the value of C.DEFAULT_CACHE_PLUGIN
    assert f.run(['DEFAULT_CACHE_PLUGIN'], on_missing='error') == ['jsonfile']

    # Check it doesn't find unknown constants
    assert f.run([''], on_missing='error') == []

    class o(object):
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-11 15:03:59.984017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test with a valid config value
    config_value = 'DEFAULT_BECOME_USER'
    config_return_value = lookup.run(terms=[config_value])[0]
    assert(config_return_value == C.DEFAULT_BECOME_USER)

    # Test with an invalid config value
    no_exist_config_value = 'UNKNOWN_VALUE'
    try:
        lookup.run(terms=[no_exist_config_value])
    except AnsibleLookupError as e:
        assert(e.message == 'Unable to find setting %s' % no_exist_config_value)

    # Test that the lookup fails if a non-string value is passed
    non_string_value = ['UNKNOWN_VALUE']

# Generated at 2022-06-11 15:04:00.695720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:04:07.467439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    mod = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', elements='str'),
        ),
        supports_check_mode=True,
    )
    mod.exit_json(msg="%s" % str(mod.params['_terms']), changed=False)

    lm = LookupModule()
    res = lm.run(['_terms'])
    assert res == ['_terms']



# Generated at 2022-06-11 15:04:24.359340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=import-error
    import ansible.plugins.loader as plugin_loader
    # pylint: disable=too-many-arguments,global-statement
    # Creating Class Instance
    obj = plugin_loader.get('LookupModule', class_only=True)()
    # Testing method run of class LookupModule
    # It returns AnsibleLookupError: Unable to find setting UNKNOWN
    try:
        obj.run(['remote_user', 'UNKNOWN'])
    except AnsibleLookupError as e:
        pass
    # Testing method run of class LookupModule
    # It returns AnsibleLookupError: Unable to find setting UNKNOWN
    try:
        obj.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        pass
    assert True

# Generated at 2022-06-11 15:04:33.690693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_dict = {'DEFAULT_ROLES_PATH': '/foo/bar:/baz/qux', 'STRING_VALUE': 'I am a string variable', 'INT_VALUE': 1,
                 'BOOLEAN_VALUE': True, 'LIST_VALUE': ['foo', 'bar'], 'DICT_VALUE': {'foo': 'bar'}}

# Generated at 2022-06-11 15:04:41.806942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    lm = lookup_loader.get('config', class_only=True)()
    lm.set_options(var_options={}, direct={
        'on_missing': 'skip',
        'plugin_type': 'shell',
        'plugin_name': 'sh',
    })
    terms = ['remote_tmp', 'remote_tmp1']
    assert lm.run(terms) == ["${HOME}/.ansible/tmp", None]

# Generated at 2022-06-11 15:04:53.868068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # Setup
    lookup_data = LookupModule()
    lookup_data._display = DummyDisplay()
    # Test missing options
    lookup_data.set_options(var_options=None, direct=None)
    assert 'on_missing' not in lookup_data._available_options
    assert 'plugin_type' not in lookup_data._available_options
    assert 'plugin_name' not in lookup_data._available_options
    # Test invalid terms
    terms = ['invalid term']
    lookup_data.set_options(var_options=None, direct={'on_missing': 'error'})  # on_missing is required
    with pytest.raises(AnsibleLookupError):
        lookup_data.run(terms)
    # Test emtpy terms

# Generated at 2022-06-11 15:05:00.994064
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import StringIO

    # Take a look at the following test cases:
    # get_config_value method should raise a AnsibleError when configuration key is missing
    # get_config_value method should raise a AnsibleError when plugin type is not loaded
    # get_config_value method should raise a AnsibleError when plugin name is not loaded of a particular type
    # get_config_value method should raise a AnsibleOptionsError on invalid setting
    # get_config_value method should return the value when a setting is present
    # get_config_value method should only raise a AnsibleError when the plugin is not loaded
    # get_config_value method should raise a AnsibleError when the plugin name is not of a plugin type

    # get_config_value method should raise a AnsibleError when configuration key is missing
    assert get

# Generated at 2022-06-11 15:05:09.314621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    # mock class
    class MockDisplay(object):
        def __init__(self):
            pass

        def vvv(self, msg):
            pass

        def warning(self, msg):
            pass
    # init and add mock
    LookupModule._display = MockDisplay()
    plugin_loader.connection_loader.plugins = {
        "netconf": "ansible.plugins.connection.netconf",
        "ssh": "ansible.plugins.connection.ssh"
    }
    plugin_loader.connection_loader.aliases = {
        "ansible.netcommon.network_cli": "netconf",
    }
    plugin_loader.shell_loader.plugins = {
        "sh": "ansible.plugins.shell.sh"
    }
    # init lookup module

# Generated at 2022-06-11 15:05:09.950014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:05:21.123259
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:05:24.480535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module.run(["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"], variables={"DEFAULT_BECOME_USER": "test"}, on_missing="error")

# Generated at 2022-06-11 15:05:35.449702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import sys

    lookup = LookupModule()
    # mock the method set_options of class LookupBase
    lookup.set_options = mock.MagicMock()

    # mock the method get_option of class LookupBase
    lookup.get_option = mock.MagicMock(side_effect=["test"])

    # mock the method get_global_config of class LookupModule
    def _get_global_config_side_effect(config):
        if config == "test":
            return 'Unit test for LookupModule'
        else:
            return Sentinel

    lookup._get_global_config = mock.MagicMock(side_effect=_get_global_config_side_effect)

    expected_result = 'Unit test for LookupModule'
    result = lookup.run(["test"], variables={})
   

# Generated at 2022-06-11 15:06:01.809175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['remote_user']) == [C.DEFAULT_REMOTE_USER]
    assert lookup.run(terms=['accelerate_port']) == [C.ACCELERATE_PORT]
    assert lookup.run(terms=['accelerate_port', 'remote_user']) == [C.ACCELERATE_PORT, C.DEFAULT_REMOTE_USER]
    assert lookup.run(terms=['UNKNOWN_CONFIG'], variables={"ANSIBLE_UNKNOWN_CONFIG": "42"}) == ["42"]
    assert lookup.run(terms=['ACCELE_PORT'], variables={"ANSIBLE_ACCELE_PORT": "0"}, on_missing='warn') == ["0"]

# Generated at 2022-06-11 15:06:10.374639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    # test invalid arguments, plugin_type and plugin_name must both be provided
    terms = ['UNKNOWN']
    with pytest.raises(AnsibleOptionsError):
        test_LookupModule.run(terms, plugin_type='connection')
    with pytest.raises(AnsibleOptionsError):
        test_LookupModule.run(terms, plugin_name='ssh')
    # test invalid arguments, terms must be a string or a list of string
    terms = 1
    plugin_type = 'connection'
    plugin_name = 'ssh'
    with pytest.raises(AnsibleOptionsError):
        test_LookupModule.run(terms, plugin_type='connection', plugin_name='ssh')
    # test invalid arguments, on_missing must be one of 'error',

# Generated at 2022-06-11 15:06:21.269910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.sentinel import Sentinel

    lookup_plugin = LookupModule(loader=None, basedir=None, runner=None, paths=None, variables=None)

    for term in [{'a': 1}, 42, 42.2]:
        try:
            lookup_plugin.run([term, term], variables=None)
            assert False, "Should have thrown AnsibleOptionsError"
        except AnsibleOptionsError:
            pass


# Generated at 2022-06-11 15:06:31.940329
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:06:43.542539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class _TestLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            super(_TestLookupModule, self).__init__(*args, **kwargs)

            self._display = kwargs.get("display")
            self._sentinel = kwargs.get("sentinel")

            self.plugin_type = "_Test_plugin_type"
            self.plugin_name = "TestPluginName"
            self.on_missing = kwargs.get("on_missing")

            self.calls = []
            self.return_values = []

        def _get_global_config(self, config):
            self.calls.append("_get_global_config")

            if len(self.return_values) == 0:
                raise self._sentinel


# Generated at 2022-06-11 15:06:51.272590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS', 'DEFAULT_ROLES_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    result = module.run(terms, dict(variable_manager=dict(extra_vars=dict(DEFAULT_BECOME_USER='the_one',
                                                                           DEFAULT_BECOME_PASS='the_one',
                                                                           DEFAULT_ROLES_PATH='/path/to/roles:',
                                                                           COLOR_OK='green',
                                                                           COLOR_CHANGED='yellow',
                                                                           COLOR_SKIP='blue'))))

# Generated at 2022-06-11 15:07:03.693362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'UNKNOWN', 'remote_user', 'port']

    lookup_obj = LookupModule()
    results = lookup_obj.run(terms)
    assert len(results) == 4

    results = lookup_obj.run(terms, on_missing='warn')
    assert len(results) == 4

    results = lookup_obj.run(terms, on_missing='skip')
    assert len(results) == 3

    terms.append('remote_user')
    results = lookup_obj.run(terms, on_missing='warn')
    assert len(results) == 4

    terms = ('DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'remote_user', 'port')
    results = lookup_

# Generated at 2022-06-11 15:07:05.503051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['DEFAULT_ROLES_PATH'], dict(), wantlist=True)

# Generated at 2022-06-11 15:07:16.135472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    # create instance of LookupModule
    lookup_module = LookupModule()

    # prepare args
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    kwargs = {}

    # call method run
    result = lookup_module.run(terms, **kwargs)
    assert result == ['root', ['/etc/ansible/roles'], '/home/vagrant/.ansible/retry', 'green', 'yellow', 'cyan']


# Generated at 2022-06-11 15:07:20.385728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test with missing option
    result = module.run([])
    assert result, 'LookupModule_run should return all ansible configuration'
    assert isinstance(result, list), 'LookupModule_run should return lists'

# Generated at 2022-06-11 15:07:49.876782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   pass

# Generated at 2022-06-11 15:07:59.562457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Calling LookupModule class and method run from it
    test_object = LookupModule()
    test_terms = ['DEFAULT_BECOME_USER']
    test_terms_not_string = [1, 2, 3]
    test_terms_not_string_2 = [('a', 1), ('b', 2), ('c', 3)]
    test_variables = None
    kwargs = dict(on_missing='error')
    result = test_object.run(test_terms, test_variables, **kwargs)
    assert result is not None, "Failed to get a value"
    assert isinstance(result, list), "Returned value is not list"
    assert isinstance(result[0], string_types), "Returned value is not string"

# Generated at 2022-06-11 15:08:09.441135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verify that settings can be looked up by name.
    settings = (
        'DEFAULT_FORKS',
        'DEFAULT_MODULE_LANG',
        'DEFAULT_PRIVATE_ROLE_VARS',
    )
    output = []
    for setting in settings:
        output.extend(
            LookupModule().run(
                terms=[setting],
                variables=dict(),
                on_missing='error'
            )
        )
    assert len(output) == len(settings), \
        'Expected output of %s settings, actual output was %s' % (
            len(settings), len(output))

    # Verify that an error is not thrown if 'on_missing' is set to 'error'
    # and the requested setting does not exist.

# Generated at 2022-06-11 15:08:19.302694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH", "RETRY_FILES_SAVE_PATH", "COLOR_OK", "COLOR_CHANGED", "COLOR_SKIP", "DEFAULT_PORT"]
    test_variables = {"DEFAULT_BECOME_USER": "foo", "DEFAULT_ROLES_PATH": "/foo/bar"}

    test_missing = ["error", "warn", "skip"]
    test_plugin_type = ["connection", "lookup", "vars"]
    test_plugin_name = ["ssh", "shell", "env"]

    tempLookupModule = LookupModule()
    lookup_module_ret = tempLookupModule.run(test_terms, test_variables)


# Generated at 2022-06-11 15:08:30.866768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock constants
    import ansible.constants as C
    orig_DEFAULT_ROLES_PATH = C.DEFAULT_ROLES_PATH
    orig_RETRY_FILES_SAVE_PATH = C.RETRY_FILES_SAVE_PATH

    test_DEFAULT_ROLES_PATH = ['/test/path']
    test_RETRY_FILES_SAVE_PATH = '/test/path'

    # Setup mock constants
    C.DEFAULT_ROLES_PATH = test_DEFAULT_ROLES_PATH
    C.RETRY_FILES_SAVE_PATH = test_RETRY_FILES_SAVE_PATH

    test_terms = ['DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH']
    test_missing = 'error'
    test

# Generated at 2022-06-11 15:08:32.562030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    retrieved_val = lookup.run(terms=['DEFAULT_NETCONF_PLUGIN'])
    assert retrieved_val == ['tailf']

# Generated at 2022-06-11 15:08:42.493948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    test_dir = os.path.dirname(os.path.realpath(__file__))
    src_dir = os.path.dirname(test_dir)
    lib_dir = os.path.join(src_dir, 'lib')
    module_dir = os.path.join(lib_dir, 'ansible', 'modules')
    old_path = list(sys.path)
    sys.path.insert(0, module_dir)
    from ansible.plugins.loader import action_loader
    from ansible.modules.source_control.git import GitRepo


# Generated at 2022-06-11 15:08:47.648414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._display = DummyDisplay()

    # Test_1: Invalid setting identifier
    l.run([1])

    # Test_2: Test for exceptions
    l.run(['nonexistent'])

    # Test_3: Valid config
    l.run(['DEFAULT_ROLES_PATH'])

    # Test_4: Sentinal value
    l.run(['DEFAULT_BECOME_USER'])


# Generated at 2022-06-11 15:08:58.353525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin_test1 = LookupModule()
    lookup_plugin_test1.set_options({'on_missing': 'error', 'plugin_type': 'vars','plugin_name': 'yaml'})
    lookup_plugin_test1.set_loader('LoaderMockup')

    def get_global_config(config):
        if config == 'DEFAULT_ROLES_PATH':
            return '/a/b/c'
        else:
            raise MissingSetting('Cannot find settings', orig_exc=None)

    lookup_plugin_test1.get_global_config = get_global_config

    settings_when_yaml_vars_is_set = lookup_plugin_test1.run(['DEFAULT_ROLES_PATH'])

# Generated at 2022-06-11 15:09:09.669518
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use a dict as a mock AnsibleOptionsError object
    error_dict = dict(msg="Mock error Object", orig_exc=None)

    # Use a dict as a mock AnsibleLookupError object
    lookup_dict = dict(msg="Mock lookup object", orig_exc=None)

    # Use a dict as a mock MissingSetting object
    missing_dict = dict(msg="Mock missing setting", orig_exc=None)


    # unit test 1
    lookup_module = LookupModule() # instantiate a mock LookupModule object
    assert_raises(AnsibleOptionsError, lookup_module.run, terms=['config'], variables=None, **dict(on_missing='bad_value'))

    # unit test 2

# Generated at 2022-06-11 15:10:12.713331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = 'config'
    terms = ['failed_when']
    variables = ['failed']
    kwargs = {'_raw_params': ['run', 'failed_when'], '_terms': ['failed_when']}

    # setup mock
    class MockLookupBase(LookupBase):
        def get_option(self, config):
            return 'error'
        def set_options(self, var_options, direct):
            pass
        def run(self, terms, variables=None, **kwargs):
            pass
    setattr(MockLookupBase, '_display', {'warning': lambda *args, **kwargs: None})

    # init module
    class MockLookupModule(LookupModule):
        def __init__(self, config):
            pass

# Generated at 2022-06-11 15:10:21.991067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error',
                                      'plugin_name': 'ssh',
                                      'plugin_type': 'connection'})

    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['remote_user', 'port'], variables=None)

    with pytest.raises(AnsibleOptionsError):
        lookup_module.set_options(direct={'on_missing': 'error',
                                          'plugin_name': None,
                                          'plugin_type': 'connection'})
        lookup_module.run(['remote_user', 'port'], variables=None)


# Generated at 2022-06-11 15:10:31.783585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    defaults = C.config.DEFAULTS['DEFAULT']
    results = lookup.run(terms=['DEFAULT_REMOTE_USER'], variables=defaults)
    assert results == ['root']
    try:
        results = lookup.run(terms=['UNKNOWN_OPTION'], variables=defaults)
        assert False
    except Exception as e:
        assert 'Unable to find setting' in e.message
    results = lookup.run(terms=['UNKNOWN_OPTION'], variables=defaults, on_missing='warn')
    assert results == []
    results = lookup.run(terms=['UNKNOWN_OPTION'], variables=defaults, on_missing='skip')
    assert results == []

# Generated at 2022-06-11 15:10:42.403972
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocking class object
    class MockConfig(object):
        DEFAULT_BECOME_USER = 'ansible_become'
        DEFAULT_ROLES_PATH = '/opt/myroles'
        RETRY_FILES_SAVE_PATH = '/tmp'
        COLOR_OK = 'blue'
        COLOR_CHANGED = 'yellow'
        COLOR_SKIP = 'green'


# Generated at 2022-06-11 15:10:49.244236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockModule(object):
        def __init__(self):
            self.params = {
                "plugin_type": "connection",
                "plugin_name": "ssh",
                "on_missing": "error",
                "variable": "remote_user",
                "another_term": "DEFAULT_BECOME_METHOD"
            }

    class MockDisplay(object):
        def __init__(self):
            self.warning = False
        
        def warning(self, msg):
            self.warning = True

    # no plugin specified
    lookup_module = LookupModule()
    lookup_module.set_options({})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run([])

    # invalid plugin type
    lookup_module = LookupModule()
    lookup_module.set

# Generated at 2022-06-11 15:10:58.412797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None, None, None, None).run(['DEFAULT_BECOME_USER',]) == ['root',]
    assert LookupModule(None, None, None, None, None).run(['DEFAULT_ROLES_PATH','DEFAULT_ROLES_PATH'], variables={'ansible_version': {'full': '2.3.0.0'}}) == ['~/.ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles', '~/.ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles']
    assert LookupModule(None, None, None, None, None).run(['UNKOWN_CONFIG_VALUE'], on_missing='error')

# Generated at 2022-06-11 15:11:07.186796
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # '_get_plugin_config' mocked to return the 1st parameter, 'config'
    # '_get_global_config' mocked to return the 1st parameter, 'term'
    # '_get_plugin_config' mocked to return the 1st parameter, 'config'
    # 'getattr' mocked to return the 1st parameter, 'config'

    terms = ['retry_files_save_path', 'retry_files_save_path', 'retry_files_save_path']
    variables = None
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'warn'}

    lookup_module = LookupModule()

    expected = ['retry_files_save_path', 'retry_files_save_path', 'retry_files_save_path']


# Generated at 2022-06-11 15:11:11.674019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['DEFAULT_HOST_LIST'], variables={}) == [C.DEFAULT_HOST_LIST]


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    try:
        test_LookupModule_run()
    except AssertionError:
        raise AssertionError('The test of method run of class LookupModule fails')

# Generated at 2022-06-11 15:11:20.989233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run("DEFAULT_ROLES_PATH")
    assert isinstance(result, list)
    assert all(isinstance(item, str) for item in result)

    result = LookupModule().run("DEFAULT_ROLES_PATH", on_missing='error')
    assert isinstance(result, list)
    assert all(isinstance(item, str) for item in result)

    result = LookupModule().run("DEFAULT_ROLES_PATH", on_missing='warn')
    assert isinstance(result, list)
    assert all(isinstance(item, str) for item in result)

    result = LookupModule().run("DEFAULT_ROLES_PATH", on_missing='skip')
    assert isinstance(result, list)