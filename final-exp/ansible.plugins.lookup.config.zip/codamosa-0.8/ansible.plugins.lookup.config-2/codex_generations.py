

# Generated at 2022-06-11 15:01:38.908561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case where plugin type and plugin name are specified but one of the two is missing
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._display = None
    lookup_module.set_options(var_options=None, direct=None)
    try:
        lookup_module.run(["test_term"], plugin_type='test_plugin_type')
    except AnsibleOptionsError as e:
        assert "Both plugin_type and plugin_name are required, cannot use one without the other" in to_native(e)


# Generated at 2022-06-11 15:01:49.112576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Ideally we would mock the return values of functions which are called within run, but that gets increasingly complicated as
    # we continue down the rabbit hole of functions that get called within other functions. Thus, we are using a wrapper class
    # instead.
    class MockSentinel:
        def __init__(self, value):
            self.value = value

    class MockModule:
        def __init__(self):
            self.result = None
            self.message = None
            self.options = None
            self.option_overrides = None
            self.param_options = None

        def fail_json(self, result, message):
            self.result = result
            self.message = message

        # this function is not needed in the test, but it is present so that the MockLookupModule class can be used as a drop-in
        # replacement for

# Generated at 2022-06-11 15:01:56.721514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lkup = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    lkup.set_options(direct={'on_missing': 'skip'})
    result = lkup.run(terms, variables={})
    assert result[0] is not None

    lkup.set_options(direct={'on_missing': 'error'})
    lkup.run(terms, variables={})  # should succeed

    terms.append('UNKNOWN')
    try:
        lkup.run(terms, variables={})  # should raise error
    except AnsibleLookupError as e:
        assert str(e) == 'Unable to find setting UNKNOWN'

    lkup.set_options(direct={'on_missing': 'warn'})

# Generated at 2022-06-11 15:02:06.163463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    values = {
        'on_missing': 'error',
        'plugin_type': '',
    }

    def setup_module_mocks(mocker):
        module_mocks = {'set_options': mocker.MagicMock(name='set_options'), 'get_option': mocker.MagicMock(name='get_option')}
        module_mocks['set_options'].return_value = None
        module_mocks['get_option'].side_effect = lambda key, default=None: values[key]
        return module_mocks

    module_mocks = setup_module_mocks(mocker)
    instance = LookupModule(None)
    instance.set_options = module_mocks['set_options']
    instance.get_option = module_mocks['get_option']
    instance

# Generated at 2022-06-11 15:02:06.675951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:02:16.991115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    # basic sanity test, just ensure nothing throws an exception
    lookup_loader.add('config', LookupModule)
    lookup_loader.get('config').run(['DEFAULT_ROLES_PATH'], variables={})

    # Test invalid settings
    lookup_loader.add('config', LookupModule)
    try:
        lookup_loader.get('config').run([1234], variables={})
    except Exception as e:
        assert isinstance(e, AnsibleOptionsError)

    # Test unknwon setting
    lookup_loader.add('config', LookupModule)
    try:
        lookup_loader.get('config').run(['unknown'], variables={})
    except Exception as e:
        assert isinstance(e, AnsibleOptionsError)

    # Test retrieving non-

# Generated at 2022-06-11 15:02:25.856088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import unittest
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2
    if PY2:
        import mock
    else:
        from unittest import mock

    # import the class we are testing
    class_to_test = 'ansible.plugins.lookup.config'
    module_to_test = __import__(class_to_test, fromlist=[class_to_test])
    class_instance = getattr(module_to_test, 'LookupModule')()

    # instantiate the class we are testing, essentially this is 'l = LookupModule()' from the example
    class_instance = class_instance

    # AttributeError: module 'ansible.constants' has no attribute 'JINJA2_OVER

# Generated at 2022-06-11 15:02:34.956238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module = LookupModule()

    # Create a list of terms 
    terms = ['DEFAULT_GATHERING']

    # Create an empty dictionary of variables
    variables = dict()
    
    # Run the method run with the following parameters
    # @terms: a list of terms, each term is a string
    # @variables: an empty dictionary of variables
    result = lookup_module.run(terms, variables)
        
    # Assert that the result is list of DEFAULT_GATHERING
    assert result[0] == 'implicit'
    
    # Create a list of terms 
    terms = ['ansible_ssh_host']

    # Create an dictionary of variables
    variables = {'ansible_ssh_host': '127.0.0.1' }
    
   

# Generated at 2022-06-11 15:02:39.476086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupPlugin = LookupModule()
    terms = [
        'DEFAULT_BECOME_METHOD',
        'DEFAULT_BECOME_USER',
        'DEFAULT_KEEP_REMOTE_FILES'
    ]
    result = lookupPlugin.run(terms)
    assert type(result) == list
    assert len(result) == 3
    assert result[0] == 'sudo'
    assert result[1] == 'root'
    assert result[2] == False

# Generated at 2022-06-11 15:02:41.639191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['DEFAULT_BECOME_USER'], {'DEFAULT_BECOME_USER': 'tester'}) == ['tester']

# Generated at 2022-06-11 15:02:59.930903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    lookup = LookupModule()
    tmpfile = tempfile.NamedTemporaryFile()
    terms = ['host_key_checking']
    files = [tmpfile.name]
    vars = {'ansible_config': files}
    ret = lookup.run(terms, variables=vars)
    assert len(ret) == 1
    assert ret[0] is True

# Generated at 2022-06-11 15:03:10.593191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_object = LookupModule()
    terms = [ 'DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS' ]
    assert lookup_object.run(terms) == [ 'root', '' ]
    terms = [ 'DEFAULT_BECOME_USER', 'foo' ]
    assert lookup_object.run(terms, on_missing='warn') == ['root']
    assert lookup_object.run(terms) == ['root']
    terms = [ 'DEFAULT_BECOME_USER', 'foo' ]
    assert lookup_object.run(terms, on_missing='skip') == ['root']
    assert lookup_object.run(terms) == ['root']
    terms = [ 'DEFAULT_BECOME_USER', 'foo' ]
    assert lookup_object.run(terms, on_missing='error')

# Generated at 2022-06-11 15:03:21.441460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data_str = 'str'
    data_bool = False
    data_int = 42
    config_str = 'FAKE_CONFIG_STR'
    config_bool = 'FAKE_CONFIG_BOOL'
    config_int = 'FAKE_CONFIG_INT'
    config_not_exists = 'FAKE_CONFIG_NOT_EXISTS'
    configs = [config_str, config_bool, config_int, config_not_exists]
    setattr(C, config_str, data_str)
    setattr(C, config_bool, data_bool)
    setattr(C, config_int, data_int)
    # Ensure that get_global_config will work with our test config

# Generated at 2022-06-11 15:03:32.295450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', required=True)
    args, unknown_args = parser.parse_known_args()

    lu = LookupModule()

    if args.mode == 'skip':
        result = lu.run([], variables={}, on_missing='skip')
        assert result == []
    elif args.mode == 'warn':
        with pytest.warns(UserWarning) as rec:
            result = lu.run([], variables={}, on_missing='warn')
        assert result == []
        assert len(rec) == 1
    elif args.mode == 'error':
        with pytest.raises(AnsibleLookupError):
            result = lu.run([], variables={}, on_missing='error')

# Generated at 2022-06-11 15:03:39.194536
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin_loader._find_plugins('./lib/ansible/plugins/action')
    plugin_loader._find_plugins('./lib/ansible/plugins/connection')
    plugin_loader._find_plugins('./lib/ansible/plugins/test')
    plugin_loader._find_plugins('./lib/ansible/plugins/lookup')
    plugin_loader._find_plugins('./lib/ansible/plugins/callback')
    plugin_loader._find_plugins('./lib/ansible/plugins/vars')

    x = LookupModule()
    x.set_options(var_options=None, direct=None)
    result = x.run(['DEFAULT_ROLES_PATH'])
    assert type(result) is list

# Generated at 2022-06-11 15:03:43.865906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    l = LookupModule()
    terms = ['COLOR_OK']
    if PY2:
        expected = [u'ok']
    else:
        expected = ['ok']
    result = l.run(terms, variables={})
    assert result == expected


# Generated at 2022-06-11 15:03:50.031596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up class C.
    C.DEFAULT_PRIVATE_KEY_FILE = '/home/ansible/.ssh/id_rsa'
    C.DEFAULT_ROLES_PATH = ['/etc/ansible/roles', '/home/ansible/roles']
    C.RETRY_FILES_SAVE_PATH = '/home/ansible/retry'
    C.LOCALHOST = '127.0.0.1'

    # Set up class C.
    C.COLOR_OK = '\033[0;32m'
    C.COLOR_CHANGED = '\033[0;31m'
    C.COLOR_SKIP = '\033[0;33m'

    # Test default plugin_type and plugin_name.
    test = LookupModule()

# Generated at 2022-06-11 15:04:01.468942
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import callback_loader

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.utils.sentinel import Sentinel

    # Setup Default Args and Mock Data
    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='')

# Generated at 2022-06-11 15:04:08.153232
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:04:19.963514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock methods import
    import imp

    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError

    # mock methods
    imp.reload(plugin_loader)
    plugin_loader.get_all_plugin_loaders.return_value = {}
    to_native.return_value = "error_msg"
    mock_sentinel = object()
    C.config.get_config_value.return_value = mock_sentinel
    setattr(C, "setting_name", mock_sentinel)

    # init tests
    variables = {}
    terms = ["setting_name"]

    # run test
    lookup_module = LookupModule()
    result = lookup_module.run(terms)

    # verify tests
    plugin_loader.get_all

# Generated at 2022-06-11 15:04:36.622546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look_obj = LookupModule()
    assert look_obj.run(['ANSIBLE_NOCOWS'], on_missing='error', plugin_name='sh', plugin_type='shell') == [False]

# Generated at 2022-06-11 15:04:39.210010
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule.run(terms=['foo', 'bar'], variables=dict(foo='foo'), plugin_type='ptype', plugin_name='pname')

# Generated at 2022-06-11 15:04:49.323528
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockDisplay(object):

        def __init__(self):
            self.warning_msg = None

        def warning(self, msg):
            self.warning_msg = msg

    class MockConfig(object):

        def __init__(self):
            self.DEFAULT_CACHE_PLUGIN = 'memory'

        def get_config_value(self, setting, plugin_type=None, plugin_name=None, variables=None):
            return self._check_setting(setting)

        def _check_setting(self, setting):
            if not isinstance(setting, string_types):
                raise AnsibleOptionsError('Invalid setting identifier, "%s" is not a string, its a %s' % (setting, type(setting)))


# Generated at 2022-06-11 15:05:00.257742
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Calling module with invalid option name
    try:
        ret = LookupModule().run(terms='missing', on_missing='invalid')
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError('AnsibleOptionsError not raised')

    # Calling module with invalid option value
    try:
        ret = LookupModule().run(terms='missing', on_missing='invalid_option')
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError('AnsibleOptionsError not raised')

    # Calling module with config option not found
    try:
        ret = LookupModule().run(terms='missing')
    except AnsibleLookupError:
        pass
    else:
        raise AssertionError('AnsibleLookupError not raised')

    # Calling module with config

# Generated at 2022-06-11 15:05:09.016563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    l = LookupModule()
    assert l.run(terms=['_ansible_version'], variables={}) == [C._ansible_version]
    assert l.run(terms=['_ansible_version', '_ansible_no_log'], variables={'_ansible_no_log': 'Cannot log'}) == [C._ansible_version, 'Cannot log']
    assert l.run(terms=['_ansible_version'], variables={}, plugin_type='connection', plugin_name='local') == [C.config._settings['connection_plugins']['local']['_ansible_version']]

# Generated at 2022-06-11 15:05:20.319849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    import os

    if not isinstance(lookup_loader, Mapping):
        lookup_loader = lookup_loader._lookup_plugins

    lookup = lookup_loader.get('config')
    if not lookup:
        raise AssertionError('Could not load lookup config')

    # No value for key in config
    result = lookup.run([to_bytes(u'config1')], {}, {})
    assert result == []

    # Error for wrong value of on_missing

# Generated at 2022-06-11 15:05:28.614233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize ansible.plugins.lookup.LookupBase
    class test_LookupBase(LookupBase):
        def __init__(self):
            super(test_LookupBase, self).__init__()

    # Initialize ansible.plugins.lookup.config.LookupModule

# Generated at 2022-06-11 15:05:38.761810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Test for error behavior when terms is not a string
    terms = [1]
    kwargs = {'on_missing': 'error'}
    try:
        lm.run(terms=terms, **kwargs)
        assert False, 'LookupModule::run did not raise AnsibleOptionsError'
    except AnsibleOptionsError:
        pass

    # Test for error behavior when on_missing is None
    terms = ['DEFAULT_BECOME_USER']
    kwargs = {'on_missing': None}
    try:
        lm.run(terms=terms, **kwargs)
        assert False, 'LookupModule::run did not raise AnsibleOptionsError'
    except AnsibleOptionsError:
        pass

    # Test for error behavior when on_missing is not one of '

# Generated at 2022-06-11 15:05:47.931402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Because this is an abstract base class, first instantiate a concrete derived class
    from ansible.plugins.lookup.consul import LookupModule as ConcreteLookupModule
    lookup = ConcreteLookupModule()

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    term = 'DEFAULT_NETCONF_PLUGIN'
    config = 'netconf'
    one_term = [term]
    two_term = [term, term]

    # Test 1: get a global setting
    res = lookup.run(terms=one_term)

# Generated at 2022-06-11 15:05:50.839180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = None
    lookup_module = LookupModule(test_module)
    result = lookup_module.run([])
    assert result == []


# Generated at 2022-06-11 15:06:26.817209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup LookupModule instance
    lu = LookupModule()

    # Setup dictionary of arguments passed to module
    args = {
        'terms': ['color_diff_highlight', 'color_ok', 'color_skipped'],
        'plugin_name': 'sh',
        'plugin_type': 'shell',
        'on_missing': 'warn'
    }

    # Check if lookup module raises an AnsibleError
    try:
        result = lu.run(**args)
        assert result == [C.COLOR_DIFF_HIGHLIGHT, C.COLOR_OK, C.COLOR_SKIPPED]
    except AnsibleError as e:
        assert False, 'Unexpected AnsibleError raised: %s' % e

# Generated at 2022-06-11 15:06:37.474029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {'test_host': {'ansible_port': 10022, 'ansible_user': 'test_user', 'ansible_connection': 'ssh'}}}
    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.network_os = 'default'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'test_user'

    lookup_plugin = LookupModule()

# Generated at 2022-06-11 15:06:46.562138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note:  Cannot test with actual config since Config() is cached for the entire life of the process
    l = LookupModule()
    l.set_options({})
    assert l.run(['bar'], {}) == []

    l.set_options({'missing': 'error'})
    assert l.run(['bar'], {}) == []

    l.set_options({'missing': 'warn'})
    assert l.run(['bar'], {}) == []

    l.set_options({'missing': 'skip'})
    assert l.run(['bar'], {}) == []

# Generated at 2022-06-11 15:06:58.101936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    class AnsibleOptionsError(Exception):
        pass
    class Sentinel(object):
        pass

    C = sys.modules['ansible.constants']
    C.DEFAULT_NETWORK_OS = 'test_os'
    class AnsibleLookupError(Exception):
        pass
    class C(object):
        class config(object):
            @staticmethod
            def get_config_value(config, plugin_type=None, plugin_name=None, variables=None):
                return config
    class LookupModule(object):
        def run(self, terms, variables=None, **kwargs):
            self.get_option = lambda x: 'error'
            self.var_options = variables
            self.direct = kwargs

            missing = self.get_option('on_missing')
           

# Generated at 2022-06-11 15:07:07.803068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'UNKNOWN', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    result_variables = {'playbook_dir':'/home/ansible'}

    # set config/variables/kwargs
    module.set_options(var_options=result_variables, direct=dict())

    # won't raise error
    terms1 = ['DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'UNKNOWN', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    result1 = module.run(terms1)

# Generated at 2022-06-11 15:07:16.630431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    # unit test for global configuration 
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_obj.run(terms)
    assert result[0] == 'root'

    # unit test for global configuration when setting is missing
    terms = ['_BAD_SETTING']
    try:
        result = lookup_obj.run(terms)
    except AnsibleLookupError as e:
        assert 'did not find' in to_native(e)

    # unit test for plugin configuration
    terms = ['remote_tmp']
    variables = dict(plugin_type='shell', plugin_name='sh')
    result = lookup_obj.run(terms, variables=variables)
    assert result[0] == '~/.ansible/tmp'

    # unit test for plugin configuration when setting

# Generated at 2022-06-11 15:07:26.486428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    result = lookup_module.run(terms)
    assert result == [['roles']]

    # TODO: need to implement test for plugin type and plugin name,
    # since these are not currently implemented.
    # To test for plugin type, you need to instantiate a instance of connection plugin class, e.g.
    # ```
    # from ansible.plugins.connection import ssh
    # plugin = ssh.Connection()
    # ```
    # You can look at example test case in plugins/lookup/lineinfile.py
    #
    # To test for plugin name, we need to mock the plugin_loader,
    # in order to mock plugin_loader, there is no easy way,
    # since plugin_loader.py imports ans

# Generated at 2022-06-11 15:07:37.977909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with blank terms
    with pytest.raises(AnsibleError):
        LookupModule().run([])

    # test with invalid term
    with pytest.raises(AnsibleError):
        LookupModule().run([{}])

    # test with valid term
    assert LookupModule().run(['DEFAULT_BECOME_USER']) == [C.DEFAULT_BECOME_USER]

    # test with invalid plugin_type
    with pytest.raises(AnsibleError):
        LookupModule().run(['ANSIBLE_LIBRARY'], plugin_type='NOT_A_TYPE')

    # test with valid plugin_type
    assert LookupModule().run(['ANSIBLE_LIBRARY'], plugin_type='action') == [C.DEFAULT_ACTION_PLUGIN_PATH]

# Generated at 2022-06-11 15:07:44.951964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    terms = ['DEFAULT_HASH_BEHAVIOUR']
    result = lookup_mock.run(terms, variables=None, **dict())
    assert result == C.DEFAULT_HASH_BEHAVIOUR, 'Expected DEFAULT_HASH_BEHAVIOUR, but result is: %s' % result

# Generated at 2022-06-11 15:07:50.851984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        # setup
    lookup = LookupModule()

    # test
    # test 1
    terms = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
        'RETRY_FILES_SAVE_PATH',
        'COLOR_OK',
        'COLOR_CHANGED',
        'COLOR_SKIP',
        'UNKNOWN'
    ]

    result = lookup.run(terms, variables = 'playbook_dir', on_missing = 'skip')
    assert result == ['root', ['/usr/share/ansible/roles'], '/root/.ansible/retry', 'green', 'yellow', 'cyan']

    # teardown

# Generated at 2022-06-11 15:09:02.421056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    # test various options of run method
    LookupModule()
    result = LookupModule().run(terms=["UNKNOWN_CONFIG"])
    assert result == []
    result = LookupModule().run(terms=["UNKNOWN_CONFIG"], variables={"ANSIBLE_INVENTORY": "hosts", "ANSIBLE_CONFIG": "ansible.cfg"})
    assert result == []
    # test on_missing options
    result = LookupModule().run(terms=["UNKNOWN_CONFIG"], on_missing='error', variables={"ANSIBLE_INVENTORY": "hosts", "ANSIBLE_CONFIG": "ansible.cfg"})


# Generated at 2022-06-11 15:09:03.770447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 15:09:04.949336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise NotImplementedError

# Generated at 2022-06-11 15:09:12.478141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('config')
    assert lookup.run(terms=['DEFAULT_REMOTE_TMP']) == [C.DEFAULT_REMOTE_TMP]
    assert lookup.run(terms=['DEFAULT_REMOTE_USER']) == [C.DEFAULT_REMOTE_USER]
    assert lookup.run(terms=['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]

    assert lookup.run(terms=['DEFAULT_REMOTE_TMP'], plugin_type='shell', plugin_name='sh') == [C.DEFAULT_REMOTE_TMP]

# Generated at 2022-06-11 15:09:15.709955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    # Use isinstance to check whether test_LookupModule_run returns a list or not
    assert isinstance(lu.run(terms=[]), list)
    assert isinstance(lu.run(terms=['test']), list)
    assert isinstance(lu.run(terms=['test', 'test2']), list)

# Generated at 2022-06-11 15:09:26.942850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Testing config 'DEFAULT_BECOME_USER'
    term = 'DEFAULT_BECOME_USER'
    ret = lookup.run([term], variables={}, on_missing='error')
    assert ret == [C.DEFAULT_BECOME_USER]
    ret = lookup.run([term], variables={}, on_missing='skip')
    assert ret == [C.DEFAULT_BECOME_USER]
    ret = lookup.run([term], variables={}, on_missing='warn')
    assert ret == [C.DEFAULT_BECOME_USER]

    # Testing config 'DEFAULT_ROLES_PATH'
    term = 'DEFAULT_ROLES_PATH'
    ret = lookup.run([term], variables={}, on_missing='error')

# Generated at 2022-06-11 15:09:37.831348
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing catch of error when using plugin config without plugin type
    try:
        # pylint: disable=redefined-outer-name
        LookupModule().run(terms=["remote_user"], plugin_name="ssh")
    except AnsibleOptionsError as e:
        assert "'plugin_type' is required" in str(e)

    # Testing catch of error when using plugin config without plugin name
    try:
        # pylint: disable=redefined-outer-name
        LookupModule().run(terms=["remote_user"], plugin_type="connection")
    except AnsibleOptionsError as e:
        assert "'plugin_name' is required" in str(e)

    # Testing catch of error when using unknown plugin name

# Generated at 2022-06-11 15:09:47.713846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import time

    testlookupmodule = LookupModule('testRun', 'test_module')

    result1 = testlookupmodule.run(terms=['RETURN_TIME'])
    assert result1 == [time.time()]

    result2 = testlookupmodule.run(terms=['DEFAULT_ROLES_PATH'], variables={'playbook_dir': '/some/path'})
    assert result2 == [['/etc/ansible/roles', '/some/path']]

    result3 = testlookupmodule.run(terms=['DEFAULT_ROLES_PATH'])
    assert result3 == [['/etc/ansible/roles']]


# Generated at 2022-06-11 15:09:48.298392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 15:09:59.264264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lmodule = LookupModule()
    assert lmodule.run(terms=['DEFAULT_REMOTE_USER']) == [ 'root' ]
    assert lmodule.run(terms=['TRUE_SETTING']) == [ True ]
    assert lmodule.run(terms=['FALSE_SETTING']) == [ False ]
    assert lmodule.run(terms=['NONE_SETTING']) == [ None ]
    assert lmodule.run(terms=[ 'INCOMPLETE_SETTING' ], on_missing='error') == [ 'ERROR: Unable to find setting INCOMPLETE_SETTING' ]
    assert lmodule.run(terms=[ 'INCOMPLETE_SETTING' ], on_missing='skip') == [ ]