

# Generated at 2022-06-25 10:22:40.179334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.get_option('on_missing')
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.get_option('plugin_type')
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.get_option('plugin_name')

    lookup_module_0.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-25 10:22:47.947399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    assert lookup_module_0.run(['DEFAULT_BECOME_USER'],dict()) == ['root']
    assert lookup_module_0.run(['DEFAULT_CALLBACK_WHITELIST'],dict()) == [['stdout', 'logging']]
    assert lookup_module_0.run(['DEFAULT_MODULE_UTILS'],dict()) == ['ansible.module_utils.basic']
    assert lookup_module_0.run(['DEFAULT_PLUGINS'],dict()) == ['callback', 'connection', 'filter', 'inventory', 'lookup', 'module_utils', 'shell_plugin', 'strategy', 'test', 'vars']


# Generated at 2022-06-25 10:22:52.312555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  args = dict(
    terms = [
      'DEFAULT_ROLES_PATH'
    ],
    on_missing = 'skip'
  )

  assert lookup_module_0.run(**args) == [('./roles:/usr/share/ansible/roles:./vendor/roles',)]

# Generated at 2022-06-25 10:23:01.548352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  no_inputs = {
      'on_missing': 'error',
      'plugin_type': None,
      'plugin_name': None 
  }
  lookup_module_0 = LookupModule()
  lookup_module_0.set_options(var_options=None, direct=no_inputs)
  terms = ['DEFAULT_BECOME_USER', 'DEFAULT_RETRY_FILES_ENABLED', 'DEFAULT_ROLES_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
  expected_result = ['root', True, '/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles:/etc/ansible/roles', 'green', 'yellow', 'blue']
  result

# Generated at 2022-06-25 10:23:03.071204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:23:05.697941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: will create some test cases when the logic is clear
    pass

# Generated at 2022-06-25 10:23:08.193561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .. import DEFAULT_TIMEOUT
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['DEFAULT_TIMEOUT'])

# Generated at 2022-06-25 10:23:16.281974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['async_dir'], {'ansible_check_mode': False})
    lookup_module_1.run(['async_dir', 'accelerate_timeout'], {'ansible_check_mode': False})
    lookup_module_1.run(['async_dir', 'accelerate_timeout'], {'ansible_check_mode': False, 'on_missing': 'warn'})
    lookup_module_1.run(['async_dir', 'accelerate_timeout'], {'ansible_check_mode': False, 'on_missing': 'error'})

# Generated at 2022-06-25 10:23:26.038927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    lookup_module_obj = LookupModule()
    lookup_module_obj.set_options({u'on_missing': u'error', u'plugin_name': u'ini'})
    lookup_module_obj.set_options({u'on_missing': u'error'})
    lookup_module_obj.set_options(variables=None)
    lookup_module_obj.set_options(variables=None, direct=None)
    lookup_module_obj.run([u'inventory_plugins'], variables=['ansible', 'ansible'])

# Generated at 2022-06-25 10:23:32.707638
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # global case
    # Given:
    global_view = True
    term = 'DEFAULT_ROLES_PATH'

    # When:
    ret = _get_global_config(term)

    # Then:
    assert ret == C.DEFAULT_ROLES_PATH

    # plugin case
    # Given:
    term = 'executable'
    ptype = 'shell'
    pname = 'sh'
    variables = None

    # When:
    ret = _get_plugin_config(pname, ptype, term, variables)

    # Then:
    assert ret == '/bin/sh'

# Generated at 2022-06-25 10:23:48.799717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [lookup_module_0, lookup_module_0, lookup_module_0]
    variables = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    test_case_0()

# vim:et:fdm=marker:sts=4:sw=4:ts=4

# Generated at 2022-06-25 10:23:59.811938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['s3_cache_subdir', '_ansible_dev_python_version', 'use_shell', 'sudo_exe', 'action_plugins', 'nested_vars_plugins', 'get_host_vars', 'local_tmp', 'new_only', 'loop_control_regexp', 'playbook_dir', 'host_vars_plugins', 'ssh_args', 'roles_path', 'callback_whitelist']
    variables_0 = 'd9mhvn1$jm'
    obj_0 = LookupModule()
    # lookup_module_0 = LookupModule()
    # list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0

# Generated at 2022-06-25 10:24:02.735015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = [lookup_module, lookup_module, lookup_module, lookup_module, lookup_module, lookup_module, lookup_module]
    var = lookup_run(lookup_module, lookup_module)

# Generated at 2022-06-25 10:24:12.749344
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test Case 0
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

    # Test Case 1
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1]
    var_1 = lookup_run(lookup_module_1, lookup_module_1)

    # Test Case 2
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:24:21.088314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _terms = dict()
    _terms['color_ok'] = ['color_warn', 'color_critical', 'color_highlight']
    _terms['color_change'] = ['color_warn', 'color_critical', 'color_highlight']
    _terms['color_skip'] = ['color_warn', 'color_critical', 'color_highlight']
    _terms['color_warn'] = ['color_warn', 'color_critical', 'color_highlight']
    _terms['color_critical'] = ['color_warn', 'color_critical', 'color_highlight']
    _terms['color_highlight'] = ['color_warn', 'color_critical', 'color_highlight']

    _terms['remote_user'] = []
    _terms['remote_port'] = []

    lm = LookupModule()


# Generated at 2022-06-25 10:24:26.347462
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    string_0 = lookup_module_0.run(list_0)
    print(string_0)

# Generated at 2022-06-25 10:24:30.053688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Implement test to check that the ansible.plugins.lookup.config.LookupModule().run() method raises AnsibleOptionsErrorException 
    pass # TODO: implement your test here


# Generated at 2022-06-25 10:24:32.018796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _get_plugin_config_0 = plugin_loader.get_plugin_loader.get_plugin.get_loader('shell_loader').get('sh')
    test_case_0()


# Generated at 2022-06-25 10:24:37.617734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_module_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:24:47.677240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # default is error, so this should error out
    try:
        with pytest.raises(AnsibleLookupError):
            lookup_module_0.run(lookup_module_0)
    except Exception:
        pytest.fail('unexpected exception raised')
    # skip should skip this
    list_0 = lookup_module_0.run(lookup_module_0, on_missing='skip')

# Generated at 2022-06-25 10:25:04.205358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(list_0, dict_0)


# Generated at 2022-06-25 10:25:12.021514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    sentinel = Sentinel()
    sentinel2 = Sentinel()
    lookup_module_0 = LookupModule()
    lookup_module_0._load_name = sentinel
    pname = sentinel2
    # These three pass options as second arg. One tests a good option, the others
    # good and bad options
    assert lookup_module_0.run(pname, plugin_name=pname) == []
    assert lookup_module_0.run(pname, plugin_name=pname, plugin_type='') == []
    assert lookup_module_0.run(pname, plugin_name=pname, plugin_type='') == []
    # These three pass options as direct kwargs
    assert lookup_module_0.run(pname, plugin_name=pname) == []

# Generated at 2022-06-25 10:25:14.860425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:25:19.064834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:25:24.020643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
# no unit tests for _get_plugin_config, _get_global_config

# Generated at 2022-06-25 10:25:30.116154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {"terms": list_0}
    kwargs = {"variables": var_0}
    setattr(args, 'direct', kwargs)
    if len(args) != len(set(args.keys())):
        raise AnsibleFilterError('Arguments share a name: %s' % ', '.join(arg for arg in kwargs if kwargs.count(arg) > 1))

# Generated at 2022-06-25 10:25:34.894718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:25:40.005218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  '''
  Test if on_missing is an invalid string and should be 'error', 'warn', or 'skip'
  '''
  t = LookupModule()
  try:
    t.run(terms=['DEFAULT_BECOME_USER'], on_missing='invalid_option')
  except AnsibleOptionsError:
    pass
  else:
    assert False, "AnsibleOptionsError not raised"


# Generated at 2022-06-25 10:25:49.689713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    terms_0 = [1, 2, 3]
    variables_0 = [1, 2, 3]
    kwargs_0 = {"1":1, "2":2}
    test_case_0(lookup_module_run_0, terms_0, variables_0, kwargs_0)
    list_1 = [lookup_module_run_0, lookup_module_run_0, lookup_module_run_0, lookup_module_run_0, lookup_module_run_0, lookup_module_run_0, lookup_module_run_0]
    for item_0 in list_1:
        var_1 = lookup_run(item_0, item_0)

# Generated at 2022-06-25 10:25:52.954390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = [lookup_module]
    result = lookup_run(lookup_module, lookup_module, terms=list, variables=lookup_module, plugin_type=lookup_module, plugin_name=lookup_module)
    assert result == False


# Generated at 2022-06-25 10:26:31.538501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Create a function to patch over the original run() method
    def run_mock(self, terms, variables=None, **kwargs):
        return [None]


# Generated at 2022-06-25 10:26:35.484123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 10:26:43.444007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]

    # test function run
    # Note: The parameters (variables, **kwargs) are not used.
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0 == list_0

# Generated at 2022-06-25 10:26:47.374075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1]
    var_1 = lookup_run(list_1, lookup_module_1)


# Generated at 2022-06-25 10:26:51.785733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, 'basic')
    assert var_0 == ansible_builtin_lookup_result_0

ansible_builtin_lookup_result_0 = "GALAXY_SERVER"


# Generated at 2022-06-25 10:26:53.691071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass  # TODO: implement your test here


# Generated at 2022-06-25 10:26:55.804670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(lookup_module_0) == None

# Test case for invalid setting identifier

# Generated at 2022-06-25 10:27:06.130208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    list_1 = ['error', 'warn', 'skip']
    for item_0 in list_1:
        var_0 = lookup_run(lookup_module_0, lookup_module_0)
        lookup_module_0 = LookupModule()
        var_0 = lookup_run(lookup_module_0, lookup_module_0)
        lookup_module_0 = LookupModule()
        var_0 = lookup_run(lookup_module_0, lookup_module_0)
        lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:27:15.576434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'on_missing': 'error'})
    lookup_module_0.set_options(direct={'plugin_name': 'ssh'})
    lookup_module_0.set_options(direct={'plugin_type': 'connection'})
    lookup_module_0.set_options(var_options={'plugins': 'completed'})
    lookup_run(lookup_module_0, lookup_module_0)
    lookup_module_0.set_options(var_options={'plugins': 'completed'})
    lookup_module_0.set_options(var_options={'plugins': 'completed'})
    lookup_module_0.set_options(var_options={'plugins': 'completed'})
    lookup_

# Generated at 2022-06-25 10:27:24.098042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0, list_0]
    var_0 = lookup_run('GALAXY_ROLE_FILES', 'plugin_type', 'plugin_name', 'on_missing', 'variables', 'wantlist', list_0)
    assert var_0 is 'Error: Invalid setting identifier, "%s" is not a string, its a %s'

# Generated at 2022-06-25 10:28:27.183861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:28:31.441560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'foo'
    list_0 = [str_0, str_0, str_0, str_0, str_0, str_0, str_0]

    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0 == ['foo', 'bar', 'baz', 'foo', 'bar', 'baz', 'foo']

# Generated at 2022-06-25 10:28:34.647799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
# END OF FILE
# #####################################################

# Generated at 2022-06-25 10:28:38.489916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 10:28:39.678128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule(), 'run'))

# Generated at 2022-06-25 10:28:47.341467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = None
    plugin_type = 'connection'
    plugin_name = 'ssh'
    on_missing = 'error'

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct=None)
    lookup_module_0.get_option = MagicMock(return_value=plugin_type)
    lookup_module_0.set_options = MagicMock(return_value=None)
    lookup_module_0.run(terms, variables, plugin_type, plugin_name, on_missing)



# Generated at 2022-06-25 10:28:51.538566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    dict_0 = {'lookup_module_1': lookup_module_1}
    var_3 = lookup_module_1.run(lookup_module_1, dict_0)
    var_4 = lookup_module_1.run(lookup_module_1, dict_0)

# Generated at 2022-06-25 10:28:55.484247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:29:03.160656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1]
    lookup_run(lookup_module_1, lookup_module_1)
    var_1 = [lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1]


# Generated at 2022-06-25 10:29:04.257919
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:31:26.757778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list__0 = [lookup_module, lookup_module, lookup_module, lookup_module, lookup_module, lookup_module, lookup_module]
    var__0 = lookup_run(lookup_module, lookup_module)

# Generated at 2022-06-25 10:31:34.352514
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = AnsibleModule(
        argument_spec = dict(
            _terms = dict(type='list', elements='str', required=True),
            on_missing = dict(type='str', default="error", choices=["error", "skip", "warn"]),
        )
    )
    set_module_args(module.params)
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=["BECOME_METHOD"], inject={'vars': {}})
    result == module.params['_terms']

# Generated at 2022-06-25 10:31:39.620410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case with all possible arguments
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:31:43.057580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    # check the return value, Note: no env variable is set in the test framework
    assert lookup_module_0.run(terms) == list_0

# Generated at 2022-06-25 10:31:49.985324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 10:31:54.341029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0, lookup_module_0]
    var_0 = lookup_run(lookup_module_0, lookup_module_0)



# Generated at 2022-06-25 10:31:56.431200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule = LookupModule()
    lookupmodule.run('')

test_case_0()

# Generated at 2022-06-25 10:31:59.350305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1, lookup_module_1]
    var_1 = lookup_run(lookup_module_1, lookup_module_1)

# Generated at 2022-06-25 10:32:05.276838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_13 = list()
    var_14 = None
    var_13.append(var_14)
    var_13.append(var_14)
    var_15 = dict()
    var_15 = dict()
    var_16 = dict()
    var_16 = dict()
    var_16 = dict()
    var_16 = dict()
    var_13.append(var_14)
    var_17 = "2"
    var_13.append(var_17)
    var_13.append(var_14)
    # Run the actual method and store its result
    res_0 = lookup_module_0.run(var_13)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:32:05.891956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert list_0 == var_0