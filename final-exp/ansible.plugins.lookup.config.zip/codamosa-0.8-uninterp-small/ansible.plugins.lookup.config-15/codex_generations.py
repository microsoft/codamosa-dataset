

# Generated at 2022-06-25 10:22:38.765379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'DEFAULT_ROLES_PATH'
    variables = {
        'hostvars': {},
        'vars': {
            'some_variable': None
        }
    }
    kwargs = {
        'on_missing': 'error',
        'plugin_type': None,
        'plugin_name': None,
        'wantlist': False
    }
    try:
        result = lookup_module_0.run(**kwargs)
    except AnsibleError as result:
        pass


# Generated at 2022-06-25 10:22:46.725592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_result = lookup_module.run(["remote_user"], {}, ["ssh"])
    assert(test_result[0] == "root")
    test_result = lookup_module.run(["remote_user"], {}, ["connector"])
    assert(test_result[0] == "connector")
    test_result = lookup_module.run(["remote_user"], {"ansible_connection": "connector"})
    assert(test_result[0] == "connector")
    test_result = lookup_module.run(["remote_tmp"], {"ansible_connection": "connector"})
    assert(test_result[0] == "/tmp")

# Generated at 2022-06-25 10:22:50.946625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "DEFAULT_BECOME_USER"
    variables = {}
    try:
        result = lookup_module_0.run(terms, variables)
    except Exception as e:
        result = str(e)

    assert 'garethr' in result


# Generated at 2022-06-25 10:23:00.829795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options = MagicMock()
    lookup_module.get_option = MagicMock(side_effect=['error', 'connection', 'ssh', ''])
    lookup_module._display = MagicMock()
    lookup_module.run = MagicMock(return_value=['22'])

    assert lookup_module.run(['port', 'not_found'], None, plugin_name='ssh', plugin_type='connection') == ['22']
    lookup_module.set_options.assert_called_with(var_options=None, direct={'plugin_name': 'ssh', 'plugin_type': 'connection'})

# Generated at 2022-06-25 10:23:11.183012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  member_0  = LookupModule()
  item_0    = ['error', 'skip', 'warn']
  item_1    = ['error', 'skip', 'warn']
  item_2    = ['error', 'skip', 'warn']
  item_3    = ['error', 'skip', 'warn']
  item_4    = ['error', 'skip', 'warn']
  for member in [member_0]:
    for item in [item_0, item_1, item_2, item_3, item_4]:
      result_0 = member.run(item)
    pass


if __name__ == '__main__':
    # Get around pytest's monkeypatching by importing Ansible here again
    import ansible.plugins.loader as plugin_loader

    AnsibleError = AnsibleError
    AnsibleLookupError

# Generated at 2022-06-25 10:23:15.090499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = {'playbook_dir': 'playbook_dir_val'}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == ['root', ['playbook_dir_val/roles', '/usr/share/ansible/roles', '/etc/ansible/roles']]

# Generated at 2022-06-25 10:23:20.039351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule
    terms_0 = ['DEFAULT_ROLES_PATH']
    lookup_module_0.run(terms_0)
    terms_0 = ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 10:23:30.467956
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Handle Exception raised by method run of class LookupModule
    # Failed lookup plugin (config) took 0.000 seconds for 0 items.
    # default action to take if term is missing from config
    # Error will raise a fatal error
    # Skip will just ignore the term
    # Warn will skip over it but issue a warning
    # action to take if term is missing from config
    # Error will raise a fatal error
    # Skip will just ignore the term
    # Warn will skip over it but issue a warning
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module_0.run(terms=None, variables=None, on_missing=None)

# Generated at 2022-06-25 10:23:35.952953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_0_args = None
    test_LookupModule_run_0_kwargs = {}
    test_LookupModule_run_0_kwargs['terms'] = 'test'
    test_LookupModule_run_0_kwargs['variables'] = {}
    test_LookupModule_run_0_kwargs['on_missing'] = 'error'

    lookup_module_0 = LookupModule()

    try:
        lookup_module_0.run(**test_LookupModule_run_0_kwargs)
    except Exception as exception:
        assert True
    else:
        assert False, 'Expected an exception'



# Generated at 2022-06-25 10:23:44.479356
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:24:04.878121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    os.environ["LOOKUP_CONFIG_on_missing"] = "error"
    lookup_module_0 = LookupModule()

    # ansible-config list is not available
    try:
        lookup_module_0.run(terms=["DEFAULT_BECOME_USER"], variables=None, wantlist=None)
    except Exception as e:
        # Verify exception message
        assert e.args[0] == "Unable to find setting DEFAULT_BECOME_USER"
        pass

    # ansible-config is available, but config value is not

# Generated at 2022-06-25 10:24:07.463618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=["DEFAULT_BECOME_USER"])
    assert result == ['root']


# Generated at 2022-06-25 10:24:13.036079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["DEFAULT_ROLES_PATH"]
    variables_1 = ["DEFAULT_ROLES_PATH"]
    kwargs_1 = {"on_missing": "error"}
    result_1 = lookup_module_1.run(terms=terms_1, variables=variables_1, **kwargs_1)
    assert isinstance(result_1, list)


# Generated at 2022-06-25 10:24:17.373584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["test"]
    variables = id
    get_option = MagicMock(return_value=Sentinel)
    set_options = MagicMock()
    lookup_module_0.get_option = get_option
    lookup_module_0.set_options = set_options
    ret = lookup_module_0.run(terms, variables)
    assert ret[0] is Sentinel

# Generated at 2022-06-25 10:24:23.528564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['remote_user']
    plugin_name='ssh'
    plugin_type='connection'
    variables=None
    kwargs={}
    result = lookup_module.run(terms,variables,plugin_name=plugin_name,plugin_type=plugin_type,**kwargs)
    assert result == [u'root'], "Result should be 'root'"

# Generated at 2022-06-25 10:24:29.488658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = dict()
    result = lookup_module_0.run(terms, variables=variables)
    assert type(result) == list
    assert result == [u'root']

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:24:35.827324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1_terms = [
        'UNKNOWN_SETTING',
        'UNKNOWN_SETTING_2'
    ]
    lookup_module_1_variables = {
        'var1': 'val1'
    }
    lookup_module_1_kwargs = {
        'plugin_type': 'httpapi'
    }
    try:
        lookup_module_1.run(
            terms = lookup_module_1_terms,
            variables = lookup_module_1_variables,
            **lookup_module_1_kwargs
        )
    except Exception as e:
        print(e)
        assert isinstance(e, AnsibleOptionsError)

# Generated at 2022-06-25 10:24:40.700198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = ['remote_tmp', 'port']
    ptype = 'shell'
    pname = 'sh'
    result = lookup_module.run(term, plugin_type=ptype, plugin_name=pname)
    if result:
        return result
    else:
        return None


# Generated at 2022-06-25 10:24:44.211907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    temp_var_0 = "DEFAULT_BECOME_USER"
    temp_var_1 = lookup_module_0.run([temp_var_0])
    #assert(temp_var_1 == "foo")


# Generated at 2022-06-25 10:24:52.923831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check if ansible.constants was set
    if C._ANSIBLE_CONSTANTS_MODULE is None:
        C.set_constants_prefix('C')
        assert C._ANSIBLE_CONSTANTS_MODULE == 'ansible.constants'
    # check if ansible.plugins.loader was set
    if C._ANSIBLE_LOADER_MODULE is None:
        C.set_loader_name('ansible.plugins.loader')
        assert C._ANSIBLE_LOADER_MODULE == 'ansible.plugins.loader'
    # check if ansible.config was set
    if C._ANSIBLE_CONFIG_MODULE is None:
        C.set_config_file('ansible.cfg')
        assert C._ANSIBLE_CONFIG_MODULE == 'ansible.config'

    # check

# Generated at 2022-06-25 10:25:23.397456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Setup
  lookup_module_1 = LookupModule()
  terms = ['DEFAULT_BECOME_USER']
  variables = ['DEFAULT_BECOME_USER']
  kwargs = ['DEFAULT_BECOME_USER']

  ret = lookup_module_1.run(terms, variables, **kwargs)
  print(ret)

# Generated at 2022-06-25 10:25:34.115163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.utils.sentinel import Sentinel
  lookup_module_0 = LookupModule()
  assert lookup_module_0.run(['DEFAULT_BECOME_METHOD']) ==  ['sudo']
  assert lookup_module_0.run(['DEFAULT_BECOME_METHOD'], ansible_become_method='sudo') == ['sudo']
  assert lookup_module_0.run(['DEFAULT_BECOME_METHOD'], ansible_become_method=None) == ['sudo']
  assert lookup_module_0.run([]) == []
  assert lookup_module_0.run(['DEFAULT_BECOME_METHOD'], ansible_become_method="") == ['sudo']

# Generated at 2022-06-25 10:25:35.778102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run("")

# Generated at 2022-06-25 10:25:38.153194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0_obj = LookupModule()
    lookup_module_0_obj.set_options(var_options=None, direct=None)


# Generated at 2022-06-25 10:25:44.223214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a LookupModule object
    lookup_module_1 = LookupModule()
    # Test if the method run of class LookupModule throws a exception when its argument is not a list
    with pytest.raises(AnsibleOptionsError):
        lookup_module_1.run('test', [])
    # Test if the type of the returned value of method run of class LookupModule is a list when its argument is a list
    assert isinstance(lookup_module_1.run(['test'], []), list)

# Generated at 2022-06-25 10:25:53.154327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with settings/terms given in list
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result_0 = lookup_module_0.run(terms_0)
    assert result_0[0] == "root"
    assert result_0[1] == [u'roles']

    # Test with settings/terms given as string
    lookup_module_1 = LookupModule()
    terms_1 = "DEFAULT_BECOME_USER"
    result_1 = lookup_module_1.run(terms_1)
    assert result_1[0] == "root"

    # Test with settings/terms given as string and list
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:26:00.037285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['ANSIBLE_LIBRARY']) == ['/Users/sharadaggarwal/.ansible/plugins/modules:/usr/share/ansible/plugins/modules']
    assert lookup_module_0.run(['ANSIBLE_SSH_PIPELINING']) == [False]
    assert lookup_module_0.run(['ANSIBLE_HOST_KEY_CHECKING']) == [True]
    assert lookup_module_0.run(['ANSIBLE_FORKS']) == [5]

# Generated at 2022-06-25 10:26:10.011740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a LookupModule object for testing
    lookup_module_0 = LookupModule()
    # Generate test param 'terms'
    terms_0 = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']

    # Call run() with params args
    result_0 = lookup_module_0.run(terms=terms_0, variables=None, **{'direct':None})
    # Verify result_0
    assert result_0 == ['root', '/etc/ansible/roles:/usr/share/ansible/roles']
    # Call run() with params args
    result_1 = lookup_module_0.run(terms=terms_0, variables=None, **{'direct':None})
    # Verify result_1

# Generated at 2022-06-25 10:26:16.917948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # call LookupModule.run with terms set to 'DEFAULT_BECOME_USER' and variable set to None
        lookup_module = LookupModule()
        terms = ['DEFAULT_BECOME_USER']
        variable = None
        lookup_module.run(terms, variable)
    except AnsibleLookupError as e:
        print(e)
        pass
    except Exception as e:
        print(e)
        pass



# Generated at 2022-06-25 10:26:19.005813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [1]
    result = lookup_module_0.run(term_0)
    assert True


# Generated at 2022-06-25 10:27:17.210875
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    terms = ['FOO', 'BAR']
    variables = {}
    ret = lookup_module_1.run(terms=terms, variables=variables)


# Generated at 2022-06-25 10:27:20.417458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    y = "success"
    x = LookupModule()
    try:
        x.run(terms="success")
        assert y == "success"
    except:
        raise AssertionError("Testcase Failed")


# Generated at 2022-06-25 10:27:23.649368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # test_case_num = 0
  lookup_module = LookupModule()
  lookup_module.run(terms, variables=None, **kwargs)
  

# Generated at 2022-06-25 10:27:27.454296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [ 'foo' ]
    kwargs_0 = {}
    ret_val = lookup_module_0.run(terms_0, **kwargs_0)

# Generated at 2022-06-25 10:27:32.244494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER']
    variables_0 = None
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert isinstance(ret_0, list)
    assert len(ret_0) == 1
    assert ret_0[0] == C.DEFAULT_BECOME_USER


# Generated at 2022-06-25 10:27:36.211240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    lookup_module_instance.set_options(direct={'plugin_name': 'yaml', 'plugin_type': 'inventory'})
    lookup_module_instance.run([
        'host_list',
        'group_list',
        'yaml_extensions'
    ], variables={})


# Generated at 2022-06-25 10:27:43.785033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check if run() works with missing parameters"""
    import sys
    def mock_LookupBase_run():
        list_of_objects = []
        class MockLookupBase_object:
            def __init__(self, on_missing, plugin_type, plugin_name):
                self.on_missing = on_missing
                self.plugin_type = plugin_type
                self.plugin_name = plugin_name
                list_of_objects.append(self)
            def set_options(self, var_options, direct):
                pass

            def get_option(self, option):
                for obj in list_of_objects:
                    if obj.on_missing == option:
                        return obj.on_missing
                    elif obj.plugin_name == option:
                        return obj.plugin_name

# Generated at 2022-06-25 10:27:46.932046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_METHOD']
    result = LookupModule().run(terms)
    assert result[0] == 'sudo'

# Generated at 2022-06-25 10:27:56.077006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:28:01.532866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        assert lookup_module.run([u'things', u'other_things']) == []
    except AnsibleOptionsError as e:
        assert str(e) == u'"on_missing" must be a string and one of "error", "warn" or "skip", not None'

# Generated at 2022-06-25 10:29:03.341337
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = []
    args_0 = ('On_missing',)
    args_1 = {'wantlist': True, }
    kwargs_0 = {}
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module_0.run(terms_0, *args_0, **kwargs_0)

    # verify exception
    assert 'Invalid setting identifier, "On_missing" is not a string, its a ' in str(excinfo.value)

# Generated at 2022-06-25 10:29:06.178443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_2=[0, '']
    variables_2=None
    assert lookup_module_2.run(terms_2) is not None, 'Return value of method run of class LookupModule is None'


# Generated at 2022-06-25 10:29:15.177429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(["items"])
    res = lookup_module_0.run(["user"])
    res = lookup_module_0.run(["inventory"])
    res = lookup_module_0.run(["inventory","aux_path"])
    res = lookup_module_0.run(["inventory","groups"])
    res = lookup_module_0.run(["inventory","patterns"])
    res = lookup_module_0.run(["inventory","path"])
    res = lookup_module_0.run(["inventory","script"])
    res = lookup_module_0.run(["inventory","smart"])
    res = lookup_module_0.run(["inventory","sources"])

# Generated at 2022-06-25 10:29:17.251717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule() # instantiate
    assert lookup.run('DEFAULT_BECOME_USER') == ['root'] # test for success using valid identifier


# Generated at 2022-06-25 10:29:19.354190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_obj = LookupModule()
  assert lookup_module_obj.run(["JUNIPER_VC_LOGIN_PROMPT"]) == ['% Login:']

# Generated at 2022-06-25 10:29:23.387698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    setattr(lookup_module_1, '_display', test_case_1)
    terms_1 = 'persistent_connection'
    variables_1 = {}
    try:
        lookup_module_1.run(terms_1, variables_1)
        assert False
    except AnsibleOptionsError as e:
        assert e.msg == "Both plugin_type and plugin_name are required, cannot use one without the other"


# Generated at 2022-06-25 10:29:26.161951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    assert lookup_module.run(terms) == ['root']
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS']
    assert lookup_module.run(terms) == ['root', '']



# Generated at 2022-06-25 10:29:33.270841
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:29:42.862014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        ['a setting'],  # terms
        {},  # variables
        { # kwargs
            'plugin_type': 'bogus',
            'plugin_name': 'invalid',
            'on_missing': 'error'
        }
    ]

    # Needed since ansible.constants is run only after ansible is executed
    # from the command line
    from ansible.constants import DEFAULT_BECOME_USER
    from ansible.vars.reserved import DEFAULT_VAULT_IDENTITY_LIST

    # As of Ansible 2.9.9 and ansible-vault 3.2.2, the
    # value returned from ansible-vault list-keys is a
    # str, not a list as documented.
    #
    # In addition, the documentatin for
   

# Generated at 2022-06-25 10:29:44.928760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    r = lookup_module_0.run(['DEFAULT_BECOME_USER'], None)
    if r == None:
        raise AssertionError("check name for r")


# Generated at 2022-06-25 10:32:12.003859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    params = []
    result = lookup_module_0.run(params)
    assert result == []

# Generated at 2022-06-25 10:32:21.027752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['DEFAULT_ROLES_PATH'], variables=None, on_missing='error')
    lookup_module_0.run(terms=['remote_user', 'port'], variables=None, plugin_name='ssh', plugin_type='connection', on_missing='error')
    lookup_module_0.run(terms=['remote_tmp'], variables=None, plugin_name='sh', plugin_type='shell', on_missing='error')
    lookup_module_0.run(terms=['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'], variables=None, on_missing='error')

# Generated at 2022-06-25 10:32:30.354842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global lookup_module_0

    lookup_module_0.run(terms=["DEFAULT_BECOME_USER"], variables=None)


# This is an autogenerated test to verify that the
# 'lookup_module_0' object was generated correctly.
#
# This will generate a test function for every function in
# 'LookupModule' that starts with 'test_'.

# Import dependency modules
from ansible.module_utils.basic import AnsibleModule

from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.plugins.callback import CallbackBase