

# Generated at 2022-06-25 10:22:35.645094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms_0 = ['DEFAULT_BECOME_USER',]

    ret = LookupModule.run(LookupModule, test_terms_0)
    assert isinstance(ret, list)
    assert ret[0] == 'root'


# Generated at 2022-06-25 10:22:42.236627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Testing exception for invalid value in option 'on_missing'
    wrong_options = {'on_missing': 'not_valid','plugin_type': '', 'plugin_name': ''}
    terms = ['DEFAULT_BECOME_USER']
    assert_exception_msg = '''"on_missing" must be a string and one of "error", "warn" or "skip", not not_valid'''
    try:
        lookup_module.run(terms, **wrong_options)
    except AnsibleOptionsError as exception:
        assert str(exception) == assert_exception_msg


# Generated at 2022-06-25 10:22:46.546781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run_0 = LookupModule()
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms_0, variables_0=None)
    result_1 = lookup_module_0.run(terms_1)
    test_run_0.run(terms_0, variables_0=None)
    test_run_0.run(terms_1)

# Generated at 2022-06-25 10:22:51.093200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["DEFAULT_REMOTE_TMP", "DEFAULT_REMOTE_TMP_ERROR"]
    variables = {"ansible_connection": "local"}
    ret = lookup_module.run(terms=terms, variables=variables)
    assert ret == [u"$HOME/.ansible/tmp", u"ERROR!"]


# Generated at 2022-06-25 10:22:57.768216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ["DEFAULT_ROLES_PATH"]
    variables_0 = None
    ret_0 = lookup_module_0.run(term_0, variables_0)
    return ret_0

if __name__ == "__main__":
    ret_0 = test_LookupModule_run()
    if ret_0 is not None:
        print(ret_0)
    else:
        print("None")

# Generated at 2022-06-25 10:22:58.991940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-25 10:23:00.119858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(lookup_module_0.run, object)

# Generated at 2022-06-25 10:23:10.420863
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin_loader_loader = None
    ansible_options = None
    terms = None
    variables = None
    lookup_module_0 = LookupModule()
    #########################################
    #  This is the test case for an error  #
    #########################################
    try:
        lookup_module_0.run(terms, variables)
        raise AssertionError("AnsibleOptionsError not raised")
    except AnsibleOptionsError:
        pass
    #########################################
    #  This is the test case for an error  #
    #########################################
    try:
        lookup_module_0.run(terms, variables)
        raise AssertionError("AnsibleOptionsError not raised")
    except AnsibleOptionsError:
        pass
    #########################################
    #  This is the test case for an error  #
    #################################

# Generated at 2022-06-25 10:23:11.629387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() == 'return_value'

# Generated at 2022-06-25 10:23:12.668631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['config']) == ['error']

# Generated at 2022-06-25 10:23:27.882119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Calling run() with arguments args=('foo=bar') and kwargs={'pname': 'bar'}
    assert lookup_module_0.run('foo=bar', pname='bar') == ['bar']


# Generated at 2022-06-25 10:23:36.400775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = None

    lookup_module_0 = LookupModule()


# Test for run in 'test_LookupModule_run'
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:23:40.743020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_BECOME_USER'], dict(DEFAULT_BECOME_USER='testuser')) == ['testuser']

# Generated at 2022-06-25 10:23:42.510807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER']) == ['root']


# Generated at 2022-06-25 10:23:49.945721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with DEFAULT_HOST_LIST option
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type':None, 'plugin_name':None})
    terms = ['DEFAULT_HOST_LIST']
    result = lookup_module.run(terms, variables=None)
    assert result == [C.DEFAULT_HOST_LIST]

    # Test with on_missing option
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type':None, 'plugin_name':None, 'on_missing':'error'})
    terms = ['BAD_SETTING']
    with pytest.raises(AnsibleOptionsError):
        result = lookup_module.run(terms, variables=None)

    # Test with plugin_type option


# Generated at 2022-06-25 10:23:54.272014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['BIN_ANSIBLE']
    kwargs = dict()
    result_0 = lookup_module_0.run(terms, **kwargs)
    assert result_0 == ['/usr/bin/ansible']



# Generated at 2022-06-25 10:23:56.481596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('host_key_checking') == [False]

# Generated at 2022-06-25 10:23:58.748966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run()
    assert lookup_module_run != None


# Generated at 2022-06-25 10:24:01.133785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["ansible_connection"]
    variables = dict()
    result = lookup_module_0.run(terms, variables)
    assert result == []


# Generated at 2022-06-25 10:24:05.017110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run()
    except Exception as e:
        assert False


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:24:35.363848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(dict(wantlist=False))
    try:
        result = lookup_module_0.run(['DEFAULT_REMOTE_USER'], dict())
    except AnsibleLookupError as e:
        assert not isinstance(e, AnsibleOptionsError)


# Generated at 2022-06-25 10:24:45.722055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct=None)

    # Test case 1
    test_param_1_terms = ['DEFAULT_BECOME_USER']
    test_param_1_variables = None
    print(" result=" + str(lookup_module_1.run(test_param_1_terms, test_param_1_variables)))

    # Test case 2
    test_param_2_terms = ['DEFAULT_BECOME_USER', 'C.ANSIBLE_FOO']
    print(" result=" + str(lookup_module_1.run(test_param_2_terms, test_param_1_variables)))

    # Test case 3

# Generated at 2022-06-25 10:24:49.819728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'FOO_BAR'
    variables_0 = {}
    kwargs_0 = {}
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert len(result) == 0



# Generated at 2022-06-25 10:24:54.053862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'become', 'plugin_name': 'dummy'})
    data = lookup_module.run(terms=['foo'], variables=None, **{'on_missing': 'error'})
    assert data == list()


# Generated at 2022-06-25 10:25:03.701509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    import ansible.plugins.loader as plugin_loader
    plugin_loader.connection_loader._base_class = None
    plugin_loader.httpapi_loader._base_class = None
    plugin_loader.shell_loader._base_class = None
    plugin_loader.cache_loader._base_class = None
    plugin_loader.lookup_loader._base_class = None
    plugin_loader.filter_loader._base_class = None
    plugin_loader.callback_loader._base_class = None
    plugin_loader.become_loader._base_class = None
    plugin_loader.action_loader._base_class = None
    plugin_loader.cliconf_loader._base_class = None
    plugin_loader.terminal_loader._base_class = None
    plugin_

# Generated at 2022-06-25 10:25:11.734494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    variables = {'inventory_hostname':'host1'}
    # Test with failure case
    data = [terms, variables]
    lookup_module = LookupModule()
    result = lookup_module.run(data)
    assert type(result) == list, "Return should be a list"
    assert result[0] == 'root'

    # Test with success case
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = {'inventory_hostname':'host1'}
    data = [terms, variables]
    result = lookup_module.run(data)
    assert type(result) == list, "Return should be a list"
    assert result[0] == 'root'

# Generated at 2022-06-25 10:25:17.559528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    class struct(object):
        orig_exc = None
        def __init__(self, **attributes):
            for name, value in attributes.items():
                setattr(self, name, value)
    import mock
    ret = []
    with mock.patch('ansible.plugins.lookup.LookupModule._get_plugin_config', side_effect=struct(message='msg', orig_exc=struct())):
        try:
            lookup_module_0.run(['DEFAULT_MODULE_NAME'])
        except AnsibleLookupError as e:
            ret.append(e)
        assert isinstance(ret[0], AnsibleLookupError)
        assert str(ret[0]) == 'Unable to find setting DEFAULT_MODULE_NAME'

# Generated at 2022-06-25 10:25:21.619988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [1, 2, 3]
    variables = ['variables']
    options = {'plugin_type': 'plugin_type'}
    assert lookup_module_0.run(terms, variables, **options) == [], "Did not retrieve the value of an Ansible configuration setting."

# Generated at 2022-06-25 10:25:32.182818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()


# Generated at 2022-06-25 10:25:37.241725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term = "DEFAULT_BECOME_USER"
    plugin_type = ""
    plugin_name = ""
    on_missing = "error"
    assert lookup_module_1.run([term], plugin_type=plugin_type, plugin_name=plugin_name, on_missing=on_missing) == ["root"]


# Generated at 2022-06-25 10:26:29.005625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    return_value = lookup_module_run.run()
    return return_value == []

# Unit test main function

# Generated at 2022-06-25 10:26:36.565747
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term = 'DEFAULT_BECOME_USER'
    vars = None
    direct = {}

    lookup_module_0 = LookupModule()
    # Unit test to verify that setting 'on_missing' to a valid value doesn't raise error
    direct[u'on_missing'] = 'skip'
    lookup_module_0.set_options(var_options=vars, direct=direct)

    # Unit test to verify that setting 'on_missing' to an invalid value raises error
    direct[u'on_missing'] = 'test_value'
    lookup_module_0.set_options(var_options=vars, direct=direct)

    # Unit test to verify that term is a string.
    terms = [term, 1234]
    lookup_module_0.run(terms)

# Generated at 2022-06-25 10:26:40.777713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  try:
    lookup_module.run(['foo'])
    assert(False) # This is a bit of a hack.
  except Exception as exception:
    assert(exception.__class__.__name__ == 'AnsibleLookupError')

# Generated at 2022-06-25 10:26:50.109851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    params = dict(terms=['remotefile'],
                  variables=dict(role_path=[])
                  )

# Generated at 2022-06-25 10:26:54.104430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['DEFAULT_BECOME_USER'], {})
    assert result == ['root']

# Generated at 2022-06-25 10:27:03.988765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 10:27:09.310630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing lookup of a value from config which doesn't exists
    lookup_module_1 = LookupModule()
    assert_raises(AnsibleLookupError, lookup_module_1.run, ['UNKNOWN'])
    assert_equals(lookup_module_1.run(['UNKNOWN'], on_missing='warn'), [])

# Generated at 2022-06-25 10:27:13.614432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["C.DEFAULT_BECOME_USER"]
    params_0 = dict(
        on_missing="warn",
    )
    lookup_module_0.set_options(params_0)
    result = lookup_module_0.run(terms_0)
    assert result == ['root']


# Generated at 2022-06-25 10:27:15.261401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    return lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:27:19.955922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate lookup module instance
    lookup_module_1 = LookupModule()

    # Call method run of lookup module
    result = lookup_module_1.run(terms = ["ANSIBLE_CONFIG"], variables = None)

    # Assertion error if assert is false
    assert result == []



# Generated at 2022-06-25 10:29:06.743434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = ['ANSIBLE_LOG_PATH']
    try:
        ret_3 = lookup_module_1.run(terms_2)
    except Exception as e:
        raise AssertionError(str(e))
    assert type(ret_3) is list


# Generated at 2022-06-25 10:29:14.050449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['show_custom_stats']
    variables_0 = {}
    on_missing_0 = 'error'
    plugin_type_0 = 'connection'
    plugin_name_0 = 'local'
    result_0 = lookup_module_0.run(terms_0, variables_0, on_missing=on_missing_0, plugin_type=plugin_type_0, plugin_name=plugin_name_0)
    print('Value of result_0:')
    print(result_0)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:29:15.522315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:29:21.900396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # First test, no default provided and no config setting found
    with pytest.raises(Exception, match='Unable to find setting UNKNOWN'):
        lookup_module_0.run(['UNKNOWN'], dict(), on_missing='error')
    # Second test, no default provided and config setting found
    actual = lookup_module_0.run(['DEFAULT_HASH_BEHAVIOUR'], dict(), on_missing='warn')
    assert actual == []
    # Third test, default provided, config setting found and equals to default
    actual = lookup_module_0.run(['DEFAULT_ROLES_PATH'], dict(), on_missing='skip')
    assert actual == ['/etc/ansible/roles']
    # Fourth test, default provided, config setting found and not equal

# Generated at 2022-06-25 10:29:24.164699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = { "plugin_type": "become", "plugin_name": "sudo"}

    lookup_module = LookupModule()

    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root']

# Generated at 2022-06-25 10:29:28.881589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["TEST_ANSIBLE_CONFIG", "TEST_ANSIBLE_CONFIG"])
    lookup_module_0.run(["TEST_ANSIBLE_CONFIG", "TEST_ANSIBLE_CONFIG", "TEST_ANSIBLE_CONFIG"])
    lookup_module_0.run(["TEST_ANSIBLE_CONFIG", "TEST_ANSIBLE_CONFIG", "TEST_ANSIBLE_CONFIG"])
    lookup_module_0.run(["TEST_ANSIBLE_CONFIG", "TEST_ANSIBLE_CONFIG", "TEST_ANSIBLE_CONFIG"])

# Generated at 2022-06-25 10:29:38.231432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # dummy parameter, as it is called directly
    dummy_self = None

    # placing this test case here, as it calls a method to initialize the constants
    # explicitly calling constants.load_constants() in ansible/__init__.py is failing

    # as the constants are initialized once and are cached, next time lookup is called
    # constants from the previous invocation are returned.
    # so calling lookup with some different set of terms will return the results from the previous invocation.
    # Example:
    # ansible localhost -m debug -a "msg={{lookup('config', 'DEFAULT_ROLES_PATH', wantlist=True)}}" -vvvv
    # # (1st invocation, returns DEFAULT_ROLES_PATH)
    # ansible localhost -m debug -a "msg={{lookup('config', 'DEFAULT_B

# Generated at 2022-06-25 10:29:40.540607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["a", "b"])



# Generated at 2022-06-25 10:29:42.053345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run({}) == []

# Generated at 2022-06-25 10:29:47.966781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.config.manager import ConfigManager, Setting, SettingType
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    test_setting = Setting(setting_id='SOME_SETTING',
                           setting_type=SettingType.STRING,
                           default=None,
                           env_var='TEST_SETTING',
                           ini_paths=['/etc/ansible/ansible.cfg'],
                           cli_args=['--test'],
                           cli_kwargs={'dest': 'TEST_SETTING'},
                           section='TEST',
                           aliases=[])
    ansible_config = ConfigManager()
    ansible_config.add_setting(test_setting)


# Generated at 2022-06-25 10:32:02.755028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = []
    var_1 = lookup_run(list_1)
    assert isinstance(var_1, list)

# Generated at 2022-06-25 10:32:07.619469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    list_1 = []
    list_2 = ["ansible_playbook_python"]
    var_0 = lookup_run(list_0, 'test_task_vars')

    try:
        var_1 = lookup_module_0.run(list_1, 'test_task_vars')
    except AnsibleOptionsError as exception_0:
        print(exception_0.message)

    try:
        var_2 = lookup_module_0.run(list_2, 'test_task_vars', on_missing='test_on_missing')
    except AnsibleOptionsError as exception_1:
        print(exception_1.message)

# Generated at 2022-06-25 10:32:14.524763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ROLE_PATH']
    variables = {}
    lookup_module = LookupModule()
    result = lookup_module.run(terms,variables,plugin_name='ssh',plugin_type='connection')
    assert result == ["/usr/share/ansible/roles:/etc/ansible/roles"]

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:32:15.562888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 10:32:17.255438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["list_1", "list_2", "list_3"]
    var_0 = lookup_run(terms_0)

# Generated at 2022-06-25 10:32:20.753688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 10:32:22.432228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    str_0 = 'error'
    lookup_run(list_0, on_missing='error')


# Generated at 2022-06-25 10:32:31.466178
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create an instance of the class, lookup module
    lookup_module = LookupModule()

    # create an instance, list_0 of list type, containing arg values to be passed to the
    # run method of class lookup module
    list_0 = []
    list_0.append("DEFAULT_BECOME_USER")
    list_0.append("DEFAULT_ROLES_PATH")

    # call the run method of class lookup module, with variable list_0 as the arg
    var_return_value = lookup_module.run(list_0)

    # and check that the first item in the list is equal to the value of the variable
    # DEFAULT_BECOME_USER
    assert var_return_value[0] == C.DEFAULT_BECOME_USER
    # and check that the second item in the list is equal to