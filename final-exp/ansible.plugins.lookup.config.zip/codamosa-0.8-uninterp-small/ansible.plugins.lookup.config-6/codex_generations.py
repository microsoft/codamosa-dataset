

# Generated at 2022-06-25 10:22:37.760749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {}

    result = lookup_module_0.run(terms, variables, on_missing='warn', plugin_type='shell', plugin_name='sh')

    assert result == []


if __name__ == '__main__':
    import os
    import pytest
    import sys
    my_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(my_path)
    result = pytest.main([my_path, "-s", "--tb=native"])

# Generated at 2022-06-25 10:22:45.726073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # If on_missing is "error" and term is not found in config, should raise a AnsibleLookupError
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct=dict(on_missing="error"))
    with pytest.raises(AnsibleLookupError):
        lookup_module_1.run(terms=["UNKNOWN"], variables=None, direct=dict())

    # If on_missing is "skip" and term is not found in config, should append an empty list to ret
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options(var_options=None, direct=dict(on_missing="skip"))
    ret = lookup_module_2.run(terms=["UNKNOWN"], variables=None, direct=dict())


# Generated at 2022-06-25 10:22:47.481441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=None, variables=None)
    assert result is not None

# Generated at 2022-06-25 10:22:51.390870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH','DEFAULT_ROLES_PATH','DEFAULT_ROLES_PATH','DEFAULT_ROLES_PATH']
    result = lookup_module_0.run(terms)
    assert len(result) == 4

# Generated at 2022-06-25 10:22:55.709678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['DEFAULT_REMOTE_USER'])[0] == 'root'
    assert lookup_module.run(['DEFAULT_REMOTE_USER']) == ['root']


# Generated at 2022-06-25 10:23:00.198057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    ret = lookup_module_0.run([u'DEFAULT_BECOME_USER'], )
    assert type(ret) is list
    assert len(ret) > 0
    assert ret[0] is not None
    assert type(ret[0]) is str
    assert ret[0] == u'root'


# Generated at 2022-06-25 10:23:03.281000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = C.config.get_config_value("DEFAULT_ROLES_PATH")
    lookup_module = LookupModule()
    terms = [u"DEFAULT_ROLES_PATH"]
    assert lookup_module.run(terms) == [ret]


# Generated at 2022-06-25 10:23:05.061294
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:23:13.987192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with all the permutations of plugin_type and plugin_name
    # not both set
    looked_up_cmd_str = lookup_module.run(['DEFAULT_BECOME_USER'])[0]
    assert looked_up_cmd_str == 'root'
    looked_up_cmd_str = lookup_module.run(['DEFAULT_BECOME_USER'], plugin_type='become')[0]
    assert looked_up_cmd_str == 'root'
    looked_up_cmd_str = lookup_module.run(['DEFAULT_BECOME_USER'], plugin_type='become', plugin_name="sudo")[0]
    assert looked_up_cmd_str == 'root'
    looked_up_cmd_str = lookup_module.run

# Generated at 2022-06-25 10:23:15.474937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('DEFAULT_BECOME_USER')

# Generated at 2022-06-25 10:23:34.791233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = 'DEFAULT_DEFAULT_LOG_PATH'
    variables = 'DEFAULT_DEFAULT_LOG_PATH'
    kwargs = 'DEFAULT_DEFAULT_LOG_PATH'
    global result
    result = lookup_module.run(terms, variables, **kwargs)
    assert result is not None, "Expected an object but got a None type"

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:23:38.341208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER']
    variables_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == ['root']


# Generated at 2022-06-25 10:23:43.267517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms_list = ['test_term_1', 'test_term_2']
    expected_result = ['test_term_1', 'test_term_2']
    # Invoke method run of class LookupModule
    actual_result = lookup_module_0.run(terms=test_terms_list)
    assert actual_result == expected_result

# Generated at 2022-06-25 10:23:46.576623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run([])
    assert ret == []
    ret = lookup_module_0.run(['C.ANSIBLE_DEFAULT_HASH_BEHAVIOUR'])
    assert ret == []


# Generated at 2022-06-25 10:23:57.836804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    lookup_module = LookupModule()
    #test_args_0 = {"variables": {}, "args": {}, "wantlist": False, "terms": ("COLORS",)}
    test_args_1 = {
        "variables": {},
        "args": {},
        "kwargs": {},
        "terms": ["action_plugins", "shell_type"],
        "wantlist": True
    }
    #result_0 = lookup_module.run(**test_args_0)
    result_1 = lookup_module.run(**test_args_1)
    assert result_1 == [C.action_plugins, C.shell_type]
    #assert result_0 == [AnsibleUnicode(u'COLOR_

# Generated at 2022-06-25 10:24:03.959542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Ensure proper inputs
    # Variables
    #ansible_var_vars =
    #ansible_var_templar =
    #ansible_var_plugin_loader =
    #ansible_var_self =
    #ansible_var_terms =
    #ansible_var_kwargs =
    #ansible_var_display =
    
    # Variables check
    #assert True
    
    # Run the method with all arguments
    result = lookup_module_0.run(ansible_var_terms, ansible_var_kwargs)
    
    # Check the results
    #assert True


# Generated at 2022-06-25 10:24:10.639820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    the_terms_0 = []
    the_variables_0 = {}
    the_kwargs_0 = {}
    returned_0 = lookup_module_0.run(the_terms_0, the_variables_0, **the_kwargs_0)
    expected_0 = []
    msg_0 = "Expected: %s\n but got: %s" % (expected_0, returned_0)
    assert returned_0 == expected_0, msg_0

# Generated at 2022-06-25 10:24:11.879531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = dict()
    ret = lookup_module_0.run(terms_0, variables_0)
    assert ret == []

# Generated at 2022-06-25 10:24:14.333410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs = {'on_missing': 'skip'}
    terms = ['DEFAULT_BECOME_USER']
    assert lookup_module_0.run(terms, **kwargs) == ['root']

# Generated at 2022-06-25 10:24:17.441425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['foo']
    variables=dict()
    variables['lookup_plugin'] = 'someplugin'
    variables['inventory_dir'] = 'inventories'
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 10:24:52.507352
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:24:56.529624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1_actual = lookup_module_1.run(terms=["FAKE_TERM"], variables=["FAKE_VARIABLES"], **kwargs)
    lookup_module_1_expected = {}
    assert lookup_module_1_actual == lookup_module_1_expected

# Generated at 2022-06-25 10:24:58.945397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=['DEFAULT_ROLES_PATH']) == C.DEFAULT_ROLES_PATH

# Generated at 2022-06-25 10:25:01.370828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(["DEFAULT_BECOME_USER"])
    assert result[0] == "root"


# Generated at 2022-06-25 10:25:05.192324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    try:
        lookup_module_run_0.run(terms, variables=None, **kwargs)
    except Exception as exception:
        print("Caught " + exception)
        assert(False)


# Generated at 2022-06-25 10:25:12.797606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_variables = {'ansible_connection': 'network_cli', u'ansible_ssh_user': u'cisco'}
    # test_terms = ['ansible_connection']
    # test_kwargs = {'plugin_name': 'ios', 'plugin_type': 'cliconf'}

    # lookup_module_0 = LookupModule()
    # lookup_module_0.run(test_terms, test_variables, **test_kwargs)

    # var_options=test_variables, direct=test_kwargs

    test_variables = {'ansible_connection': 'network_cli', u'ansible_ssh_user': u'cisco'}
    test_terms = ['ansible_connection']

# Generated at 2022-06-25 10:25:21.087207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # No arguments
    result_0 = lookup_module.run()
    assert result_0 == None
    # One argument
    result_1 = lookup_module.run(terms='test_terms')
    assert result_1 == None
    # Two arguments
    result_2 = lookup_module.run(terms='test_terms', variables='test_variables')
    assert result_2 == None
    # Three arguments
    result_3 = lookup_module.run(terms='test_terms', variables='test_variables', **{'kwargs':'test_kwargs'})
    assert result_3 == None
    # Four arguments

# Generated at 2022-06-25 10:25:31.469763
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    import ansible.constants as C


# Generated at 2022-06-25 10:25:34.383438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run(terms=["a","b","c"])
    assert lookup_module_run == [Sentinel]*3



# Generated at 2022-06-25 10:25:35.184328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[])

# Generated at 2022-06-25 10:26:12.561952
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    path_0 = ')>F;,Sbp:Wc*_i[)5pK~'
    str_0 = '*'
    set_0 = {str_0}
    lookup_module_0 = LookupModule(set_0)
    lookup_module_0.run(path_0)
    path_1 = 'L'
    set_1 = {path_1}
    lookup_module_1 = LookupModule(set_1)
    lookup_module_1.run(path_1)
    path_2 = '9'
    set_2 = {path_2}
    lookup_module_2 = LookupModule(set_2)
    lookup_module_2.run(path_2)
    path_3 = '1'
    set_3 = {path_3}
    lookup

# Generated at 2022-06-25 10:26:21.256796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '"Lh`~J'
    str_1 = 'N_3qnv'
    str_2 = '2TbT:z,oz2r"1Lm=j!9X0"JG,>|d6h{'
    str_6 = ':'
    str_7 = 'D#jX9nB>J}'
    str_8 = '{U~%6g_s$b;hR&x~lXj%Aq3!k!'
    str_9 = 'b>j'
    str_10 = 'j}'
    str_11 = 'B}J#j'
    str_12 = 'yG|bE.'
    str_13 = '1X9'
    str_14 = ' H'

# Generated at 2022-06-25 10:26:28.060010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    set_0 = {bool_0}
    str_0 = '4P`eBe03?f{\n|jkQVBpp'
    dict_0 = {str_0: str_0}
    missing_setting_0 = MissingSetting(str_0, dict_0)
    lookup_module_0 = LookupModule(missing_setting_0)
    lookup_module_0.run(set_0)

# Generated at 2022-06-25 10:26:34.878021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype = 'lookup'
    pname = '7d'
    missing = 'warn'
    terms = [pname, missing, ptype, 'b', pname, 'c', ptype, missing, 'a']
    variables = {pname: 'w', missing: 'd'}
    kwargs = {missing: 's', pname: ptype}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct=kwargs)
    lookup_module_1 = lookup_module_0.run(terms, variables='d', **kwargs)


# Generated at 2022-06-25 10:26:40.112579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['DEFAULT_BECOME_USER']
    var_1 = None
    var_1 = dict(on_missing='error')
    lookup_module_0.run(var_0, variables=var_1)


# Generated at 2022-06-25 10:26:49.259684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = True
    set_1 = {bool_1}
    list_0 = [False, '4P`eBe03?f{\n|jkQVBpp', 1.0, 62264.69667714168]
    list_1 = [list_0, 1.0, '4P`eBe03?f{\n|jkQVBpp', None, '4P`eBe03?f{\n|jkQVBpp']
    lookup_run_0 = lookup_module_0.run(list_0)
    lookup_run_1 = lookup_module_0.run(set_1)
    lookup_run_2 = lookup_module_0.run(list_1)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:26:58.109266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = False
    set_1 = {bool_1}
    str_1 = '\x1a'
    dict_1 = {str_1: str_1}
    missing_setting_1 = MissingSetting(str_1, dict_1)
    lookup_module_1 = LookupModule(missing_setting_1)
    str_2 = 'V-NuQ,\x7fP'
    dict_2 = {str_2: bool_1}
    var_1 = lookup_module_1.run(set_1, dict_2)

    return var_1 == set_1


if __name__ == "__main__":
    from ansible.module_utils.basic import *

    main()

# Generated at 2022-06-25 10:27:00.217524
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test with keyword arguments
    lookup_module_0 = LookupModule()
    lookup_run(lookup_module_0)


# Generated at 2022-06-25 10:27:04.855731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = 't\x00t'
    vars_0 = {str_0: str_0}
    lookup_module_0 = LookupModule()
    lookup_run(bool_0, vars_0)


# Generated at 2022-06-25 10:27:10.974125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = True
    set_1 = {bool_1}
    str_1 = '`)l`v[a1$|0_?;'
    dict_1 = {str_1: set_1}
    missing_setting_1 = MissingSetting(str_1, dict_1)
    lookup_module_1 = LookupModule(missing_setting_1)
    lookup_module_1(set_1)

# Generated at 2022-06-25 10:28:18.531822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    set_0 = {bool_0}
    str_0 = '4P`eBe03?f{\n|jkQVBpp'
    dict_0 = {str_0: str_0}
    missing_setting_0 = MissingSetting(str_0, dict_0)
    lookup_module_0 = LookupModule(missing_setting_0)
    terms_0 = {str_0}
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == [str_0]

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:28:28.836551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    set_0 = {bool_0}
    str_0 = ''
    missing_setting_0 = MissingSetting(str_0, set_0)
    lookup_module_0 = LookupModule(missing_setting_0)
    terms_0 = {bool_0}
    variables_0 = {'[Ad': str_0}
    # Test using a class
    assert_equal(lookup_module_0.run(terms_0, variables_0), list)
    # Test using an instance
    assert_equal(lookup_module_0.run(terms_0, variables_0), list)
    # Test using a callable
    assert_equal(lookup_module_0.run(terms_0, variables_0), list)
    # Test using a function

# Generated at 2022-06-25 10:28:34.619617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters testing
    # run(terms, variables=None, **kwargs)
    # var = "  "
    # var = "a"
    # var = 0
    # var = (0,0,0)
    # var = {'a':'a'}
    var = True
    # var = set()
    # var = [1,2,3]
    # var = ""
    # var = ""
    # var = ""
    # var = ""
    # var = "\"\""
    # var = ""
    lookup_module_0 = LookupModule(var)
    var_0 = lookup_module_0.run()
    print(var_0)


# Generated at 2022-06-25 10:28:39.099811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pname = 'c%o^>x(FgSQ|7VX(1~.{7VX'
    ptype = '|dw>z{q3mq3mq3mq3'
    lookup_module_0 = LookupModule()
    terms = [str_0]
    missing = missing_setting_0
    var_1 = lookup_module_0.run(terms, missing, pname = pname, ptype = ptype)
    assert var_1 == ['error']

# Generated at 2022-06-25 10:28:44.841878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    set_0 = {bool_0}
    str_0 = '4P`eBe03?f{\n|jkQVBpp'
    dict_0 = {str_0: str_0}
    missing_setting_0 = MissingSetting(str_0, dict_0)
    lookup_module_0 = LookupModule(missing_setting_0)
    var_0 = lookup_module_0.run(set_0)

# Generated at 2022-06-25 10:28:47.731635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        set_0 = set()
        missing_setting_0 = MissingSetting('', dict())
        lookup_module_0 = LookupModule(missing_setting_0)
        var_0 = lookup_module_0.run(set_0)
    except MissingSetting as e:
        assert False


# Generated at 2022-06-25 10:28:49.972382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set_0)
    assert isinstance(var_0, set)

# Generated at 2022-06-25 10:28:59.528317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  import ansible.plugins.loader as plugin_loader
  from ansible import constants as C
  from ansible.errors import AnsibleError, AnsibleLookupError, AnsibleOptionsError
  from ansible.module_utils._text import to_native
  from ansible.module_utils.six import string_types
  from ansible.plugins.lookup import LookupBase
  from ansible.utils.sentinel import Sentinel

  class MissingSetting(AnsibleOptionsError):
      pass


# Generated at 2022-06-25 10:29:07.391903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['RvR', 'B', '|', 'I{'
              'bY,', '@MoZL', '<Q\x7f%', ':', '_?g5U6\x7fO', '', '%c', 'G']
    str_1 = 'V'
    lookup_module_0 = LookupModule(list_0, str_1)
    str_3 = 'F;.[G'
    str_4 = '@sR00iyzFY'
    str_5 = 'W\x7f'
    list_1 = [str_3, str_4, str_5]
    lookup_module_1 = lookup_module_0.run(list_1)
    for item_0 in lookup_module_1:
        str_2 = item_0
       

# Generated at 2022-06-25 10:29:15.523790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    set_0 = {bool_0}
    str_0 = '4P`eBe03?f{\n|jkQVBpp'
    dict_0 = {str_0: str_0}
    missing_setting_0 = MissingSetting(str_0, dict_0)
    lookup_module_0 = LookupModule()
    str_1 = '&RZWp-*(bw%c|E'
    ansible_options_error_0 = AnsibleOptionsError(str_1)
    test_case_0(lookup_module_0, missing_setting_0, ansible_options_error_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:31:35.649997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'PW'
    set_0 = {str_0}
    lookup_module_0 = LookupModule(str_0)
    int_0 = lookup_run(set_0)


# Generated at 2022-06-25 10:31:43.554549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms, variables, kwargs = set(), dict(), dict()
    sentinel, result = Sentinel(0), Sentinel(1)
    def get_option(key):
        if key == 'on_missing':
            return sentinel
        return None
    def set_options(*args): pass
    lookup_module = LookupModule(None)
    lookup_module.set_options = set_options
    lookup_module.get_option = get_option
    assert lookup_module.run(terms, variables, **kwargs) == result

# Generated at 2022-06-25 10:31:53.288842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    bool_0 = False
    set_0 = {bool_0}
    str_0 = '4P`eBe03?f{\n|jkQVBpp'
    dict_0 = {str_0: str_0}
    missing_setting_0 = MissingSetting(str_0, dict_0)
    lookup_module_0 = LookupModule(missing_setting_0)
    terms = set_0
    variables = set_0
    kwargs = {'on_missing': 'error'}

    # Invoke method
    ret = lookup_module_0.run(terms, variables, **kwargs)

    # Verify
    assert ret == [bool_0]

# Generated at 2022-06-25 10:31:57.539618
# Unit test for method run of class LookupModule
def test_LookupModule_run():

	# function run() returns ansible.module_utils.basic.AnsibleFallbackNotFound
	set_0 = {False, True}
	dict_0 = {'plugin_type': 'lookup', 'plugin_name': 'config'}
	assert lookup_module_run(set_0, dict_0)

# Generated at 2022-06-25 10:32:07.909209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.render_args({})
    lookup_module_0._get_plugin_config("_wN_my3", "connection", "remote_user", {})
    lookup_module_0.run("Rm0bU6", {"m3gt<bQ": "^Dy|9M>a&1;U@e.{n"}, plugin_name="ssh", plugin_type="connection", on_missing="skip")
    lookup_module_0.set_options(direct={}, var_options={"B<Nxy\x7f": "_A30)2"})
    lookup_module_0._templar.template("^t_=8]p\"<<7m0sX_4", lookup_module_0.get_options())
    lookup_module

# Generated at 2022-06-25 10:32:17.549767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['DEFAULT_BECOME_USER']
    dict_0 = {}
    dict_1 = {}
    dict_1['dest'] = str
    dict_2 = {}
    dict_2['dest'] = str
    dict_3 = {}
    dict_3['dest'] = str
    dict_4 = {}
    dict_4['dest'] = str
    dict_4['choices'] = {'error', 'skip', 'warn'}
    dict_0['_terms'] = terms_0
    dict_0['on_missing'] = dict_1
    dict_0['plugin_type'] = dict_2
    dict_0['plugin_name'] = dict_3
    dict_0['_orig_basename'] = dict_4
    dict_5 = {}
    dict_6 = {}
    dict

# Generated at 2022-06-25 10:32:21.689899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = {'DEFAULT_BECOME_USER'}
    variables = {}
    var_0 = LookupModule_run(terms, variables)
    assert var_0  # TODO: Better assert