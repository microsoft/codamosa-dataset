

# Generated at 2022-06-25 10:22:37.386901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    options = {'direct': {'plugin_type': None, 'on_missing': 'error', 'plugin_name': None}}
    lookup_module.set_options(var_options={}, direct=options['direct'])
    terms = ['ANSIBLE_RETRY_FILES_ENABLED']
    variables={}
    assert lookup_module.run(terms, variables) == [False]


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:22:41.083072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'lookup_plugin_timeout'
    kwargs_0 = 'lookup_plugin_timeout'
    result_0 = lookup_module_0.run(terms_0, kwargs_0)
    assert result_0 == ['10']


# Generated at 2022-06-25 10:22:48.627472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

  # Testing with terms = [], variables = (Optional)
  terms = []
  variables = ''
  result = lookup_module.run(terms, variables)
  assert result == []

  # Testing with terms = ['term1'], variables = (Optional)
  terms = ['term1']
  variables = ''
  result = lookup_module.run(terms, variables)
  assert result == ['term1']

  # Testing with terms = ['term1', 'term2', 'term3'], variables = (Optional)
  terms = ['term1', 'term2', 'term3']
  variables = ''
  result = lookup_module.run(terms, variables)
  assert result == ['term1', 'term2', 'term3']

  # Testing with terms = ['term1'], variables = {'

# Generated at 2022-06-25 10:22:54.437486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_ROLES_PATH']
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert type(result_0) == list
    assert result_0 == []


# Generated at 2022-06-25 10:22:57.592974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module = LookupModule()
   terms = 'DEFAULT_BECOME_USER'
   variables = None
   kwargs = {}
   lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:23:00.657833
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test Teardown
    def test_teardown():
        pass

    # Test Setup
    def test_setup():
        pass

    test_setup()

    # Test Execution
    lookup_module = LookupModule()

    # Test Call #1
    terms = None
    variables = None
    kwargs = None
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == [], 'Expected different value for LookupModule.run(terms, variables, **kwargs)'

    test_teardown()



# Generated at 2022-06-25 10:23:02.783133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = ""
    results = lookup_module_0.run(term)
    assert True


# Generated at 2022-06-25 10:23:05.738605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run("", "") == []



# Generated at 2022-06-25 10:23:08.958528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args = []
    kwargs = {'wantlist': True}
    result_1 = lookup_module_1.run(args, **kwargs)
    assert result_1 == None

# Generated at 2022-06-25 10:23:13.799493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        'DEFAULT_BECOME_USER'
    ]
    variables_1 = {}
    kwargs_1 = {}
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert result_1 == ['root']
    # test_case_0 is not used


# Generated at 2022-06-25 10:23:31.575636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 9199
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    var_1 = lookup_run(int_0)
    var_2 = lookup_run(int_0)
    var_3 = lookup_run(int_0)
    var_4 = lookup_run(int_0)
    var_5 = lookup_run(int_0)
    var_6 = lookup_run(int_0)
    var_7 = lookup_run(int_0)
    var_8 = lookup_run(int_0)
    var_9 = lookup_run(int_0)
    var_10 = lookup_run(int_0)
    var_11 = lookup_run(int_0)

# Generated at 2022-06-25 10:23:40.034909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1614
    boolean_1 = False
    lookup_run(int_0)
    variable_0 = False
    variable_1 = ['DEFAULT_ROLES_PATH']
    variable_2 = 'warn'
    variable_3 = None
    variable_4 = 'skip'
    variable_5 = 'remote_user'
    variable_6 = True
    variable_7 = 'inventory'
    variable_8 = 'error'
    variable_9 = None
    variable_10 = 'error'
    variable_11 = None
    variable_12 = 'port'
    variable_13 = None
    variable_14 = 'connection'
    variable_15 = 'ssh'
    variable_16 = None
    variable_17 = 'remote_tmp'
    variable_18 = None
    variable_19 = 'shell'

# Generated at 2022-06-25 10:23:41.413999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()



# Generated at 2022-06-25 10:23:43.640059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1614
    var_0 = lookup_run(int_0)

# Generated at 2022-06-25 10:23:44.407466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert not True


# Generated at 2022-06-25 10:23:46.467755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert (var_0 is False)


# Generated at 2022-06-25 10:23:48.047710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 0
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)

# Generated at 2022-06-25 10:23:52.638998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 1119
    var_1 = "remote_user"
    var_2 = "port"
    var_3 = "connection"
    var_4 = "ssh"
    var_5 = "skip"
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=var_0, direct=var_0)
    res = lookup_module_0.run(terms=var_1, variables=var_2, plugin_type=var_3, plugin_name=var_4, on_missing=var_5)
    assert res == "test"

# Generated at 2022-06-25 10:23:57.121207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = get_var(int_0)
    lookup_module_0.run()

    if (var_0):
        var_0 = null
    try:
        var_0

    except:
        var_0 = null
# END OF FILE

# Generated at 2022-06-25 10:24:00.967675
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Get the global config for each term
    # This can either be a value or a callable that returns the value.
    int_0 = 1614
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)
    assert (var_0 == None)

# Generated at 2022-06-25 10:24:16.340893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1614
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)

# Generated at 2022-06-25 10:24:18.117382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:24:20.425835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1615
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)



# Generated at 2022-06-25 10:24:30.871730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 834
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    int_1 = 533
    lookup_module_2 = LookupModule()
    int_2 = 649
    lookup_module_3 = LookupModule()
    int_3 = 594
    lookup_module_4 = LookupModule()
    str_0 = lookup_module_4.run(int_3)
    str_1 = lookup_module_3.run(int_2)
    str_2 = lookup_module_2.run(int_1)
    str_3 = lookup_module_1.run(int_0)
    str_4 = lookup_module_0.run(str_3, int_2)

# Generated at 2022-06-25 10:24:34.047970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {"terms": "ansible", "on_missing": "Fatal"}
    test_case = LookupModule()
    assert test_case.run(**args)

# Generated at 2022-06-25 10:24:36.213523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = -1
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)

# Generated at 2022-06-25 10:24:37.450700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_LookupModule_run()



# Generated at 2022-06-25 10:24:47.496409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1614
    var_0 = lookup_run(int_0)
    int_1 = 4968
    var_1 = lookup_run(int_1)
    int_2 = 0
    var_2 = lookup_run(int_2)
    int_3 = 2
    var_3 = lookup_run(int_3, int_1)
    int_4 = 4975
    var_4 = lookup_run(int_4, int_1)
    int_5 = 4978
    var_5 = lookup_run(int_5)
    int_6 = 4977
    var_6 = lookup_run(int_6)
    assert var_6 == var_0
    assert var_3 == var_1
    assert var_5 == var

# Generated at 2022-06-25 10:24:49.127582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1614
    lookup_module_0 = LookupModule()
    source_0 = lookup_module_0.run(int_0)


# Generated at 2022-06-25 10:24:55.597531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Declare variables for instantiation of the class
    terms = 'DEFAULT_UNDEFINED_VAR_BEHAVIOR'

# Generated at 2022-06-25 10:25:24.581796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 3674
    var_0 = lookup_run(int_0)


# Generated at 2022-06-25 10:25:27.575500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1614
    lookup_module_0 = LookupModule()
    lookup_module_0.run(int_0)


# Generated at 2022-06-25 10:25:30.652851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result =  lookup_module_0.run(terms, variables=None, **kwargs)
    assert result == result == [C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-25 10:25:32.810422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1614
    lookup_module_0.run(int_0)

# Generated at 2022-06-25 10:25:41.967094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _modules_loaded = False
    _plugins_loaded = False
    _lookup_inspect_cache = {}
    lookup_loader = plugin_loader._create_loader('lookup', 'LookupModule')
    lookup_plugins = plugin_loader.find_plugins(LookupBase, lookup_loader, include_hidden=False, _override_paths='/ansible/modules/')
    for plugin in lookup_plugins:
        if plugin._searchpath is None:
            plugin._searchpath = '/ansible/modules/'

        if not plugin._load_name in _lookup_inspect_cache:
            _lookup_inspect_cache[plugin._load_name] = plugin.load()
    lookup_plugins = [x for x in lookup_plugins if x._load_name in _lookup_inspect_cache]
    _plugins

# Generated at 2022-06-25 10:25:51.680633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 2611
    lookup_module_0 = LookupModule()
    int_0 = 823
    int_1 = 634
    int_2 = 937
    int_3 = 422
    int_4 = 716
    int_5 = 763
    var_1 = [int_5]
    int_6 = 476
    var_2 = [int_6]
    int_7 = 1749
    int_8 = 358
    int_9 = 937
    int_10 = 962
    int_11 = 1686
    int_12 = 1894
    int_13 = 313
    int_14 = 1179
    int_15 = 240
    int_16 = 1444
    int_17 = 894
    int_18 = 675
    int_19 = 1242
   

# Generated at 2022-06-25 10:25:55.647535
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ''
    variables = ''
    plugin_type = ''
    plugin_name = ''

    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(terms, variables, plugin_type, plugin_name)

    assert('the value of result_1 is equal to result_2')

# Generated at 2022-06-25 10:25:57.908376
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    int_0 = 886
    assert not lookup_module.run(int_0)


# Generated at 2022-06-25 10:26:00.806835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1614
    a = lookup_module_0.run(terms=int_0,variables=None)


# Generated at 2022-06-25 10:26:02.269264
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_case_0()

# Generated at 2022-06-25 10:27:01.447277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for int_0 in range(1,5):
        lookup_module_0 = LookupModule()
        var_0 = lookup_module_0.run(int_0)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:27:05.340937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0, int_0)
    assert var_0 is not None
    assert var_0 == lookup_module_0._collections_paths

# Generated at 2022-06-25 10:27:08.292861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(dir_0)



# Generated at 2022-06-25 10:27:09.572904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(int_0) == var_0

# Generated at 2022-06-25 10:27:12.193412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Pass no values as a dict to param and store the result in var
    var = lookup_module_0.run({})
    assert var is None

# Generated at 2022-06-25 10:27:22.638827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    argv_0 = []
    argv_0.append("argv_0")
    argv_0.append("argv_1")
    argv_0.append("argv_2")
    argv_0.append("argv_3")
    argv_0.append("argv_4")
    argv_0.append("argv_5")
    argv_0.append("argv_6")
    argv_0.append("argv_7")
    argv_0.append("argv_8")
    argv_0.append("argv_9")
    argv_0.append("argv_10")
    argv_0.append("argv_11")
    argv_0.append("argv_12")

# Generated at 2022-06-25 10:27:24.820296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1714
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)


# Generated at 2022-06-25 10:27:30.716365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        var_0 = lookup_module_0.run()
    except Exception as exception:
        # AssertionError if raised in this block
        return False
    else:
        # AssertionError if raised in this block, then pass to test.py
        pass
        # Exception raised if the following line is reached
        # assert False
        return True
    finally:
        pass


# Generated at 2022-06-25 10:27:32.437408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = False
    var_1 = True

    test_case_0()


# Generated at 2022-06-25 10:27:40.647624
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Ensure we get a empty array when there are no known constants.
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = len(var_0)
    assert var_1 == 0

    # Ensure we get a array of the expected size.
    lookup_module_1 = LookupModule()
    var_2 = lookup_run(lookup_module_1)
    var_3 = len(var_2)
    assert var_3 == 0

    # Ensure we get a array of the expected size.
    lookup_module_2 = LookupModule()
    var_4 = lookup_run(lookup_module_2)
    var_5 = len(var_4)
    assert var_5 == 0

    # Ensure we get a array of the expected

# Generated at 2022-06-25 10:29:38.629365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = run(terms, variables=None, **kwargs)
    assert result == expected


# Generated at 2022-06-25 10:29:40.345412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1614
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    assert var_0 is int_0


# Generated at 2022-06-25 10:29:41.567319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1614
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)


# Generated at 2022-06-25 10:29:44.058869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = 'DEFAULT_BECOME_USER'
    plugin_type_0 = 'connection'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0, plugin_type=plugin_type_0)
    if var_0 is not None:
        pass


# Generated at 2022-06-25 10:29:45.105479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert run(int_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:29:46.437051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1614
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.lookup(int_0)

# Generated at 2022-06-25 10:29:48.344098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1614
    res_0 = lookup_module_0.run(int_0)

if __name__ == "__main__":
    import nose2
    nose2.main()

# Generated at 2022-06-25 10:29:52.106626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = [str_0, str_1]
    variables_0 = None
    var_0 = lookup_module_0.run(terms_0)


# Generated at 2022-06-25 10:29:54.437201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 9448
    lookup_module_1 = lookup_module_0.run(int_0)



# Generated at 2022-06-25 10:29:57.086533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True

# Testing of function run