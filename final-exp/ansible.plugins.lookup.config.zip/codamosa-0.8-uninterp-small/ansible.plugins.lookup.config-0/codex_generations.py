

# Generated at 2022-06-25 10:22:34.947485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER']
    variables_0 = {}
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == []

    lookup_module_1 = LookupModule()
    terms_1 = ['DEFAULT_BECOME_USER']
    variables_1 = {}
    result = lookup_module_1.run(terms_1, variables_1)
    assert result == ['root']

# Generated at 2022-06-25 10:22:43.442232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Config(terms=None, variables=None, **kwargs)
    # Create a new configuration object based on an existing configuration object
    # and optionally override some items in it.
    # This is needed so we can read configs without affecting other tests
    import ansible.config.manager
    config_1 = ansible.config.manager.ConfigManager()
    config_1._open_conf_file(config_1.get_config_file_path())
    config_1.load_from_file()
    lookup_module_1.set_options(var_options=config_1, direct=None)
    # Sentinel(name, value=)
    # Sentinel object for use as default value for function arguments
    # Initialize and return a new Sentinel object. Once initialized, the returned
    # Sentinel object

# Generated at 2022-06-25 10:22:45.707160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['BECOME_METHOD']
    variables = None
    assert lookup_module.run(terms, variables) == ['sudo']


# Generated at 2022-06-25 10:22:55.574999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
    ]
    lookup_result = lookup_module.run(terms, variables=None, on_missing='error')
    assert lookup_result == ['root', ['/usr/share/ansible/roles']]
    terms = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
    ]
    lookup_result = lookup_module.run(terms, variables=None, on_missing='warn')
    assert lookup_result == ['root', ['/usr/share/ansible/roles']]
    terms = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
    ]

# Generated at 2022-06-25 10:23:03.474044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ANSIBLE_PRIVATE_KEY_FILE']
    variables = {}
    kwargs = {}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == [None]

    terms = ['ANSIBLE_PRIVATE_KEY_FILE']
    variables = {}
    kwargs = {'on_missing': 'skip'}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == []

    terms = ['ANSIBLE_PRIVATE_KEY_FILE']
    variables = {}
    kwargs = {'on_missing': 'warn'}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:23:05.852386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test the method run of class LookupModule with the following parameter values:
    terms: ['DEFAULT_ROLES_PATH']
    """
    result = []

    result.append(LookupModule.run(['DEFAULT_ROLES_PATH']))

    return result

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:23:12.126497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_1 = LookupModule()
        terms = [u'DEFAULT_REMOTE_USER', u'DEFAULT_REMOTE_PASS']
        kwargs = {'on_missing': u'skip', 'plugin_type': u'connection', 'plugin_name': u'ssh'}
        result = lookup_module_1.run(terms=terms, variables=None, **kwargs)
        assert result == [u'root', u'devops']
    except AnsibleError as e:
        pass



# Generated at 2022-06-25 10:23:17.081577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['DEFAULT_BECOME_USER']
    lookup_module_0.run(terms=term_0)
    term_1 = ['DEFAULT_ROLES_PATH']
    lookup_module_0.run(terms=term_1)
    term_2 = ['RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    lookup_module_0.run(terms=term_2, wantlist=True)

# Generated at 2022-06-25 10:23:28.705245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_terms_2 = [
        "DEFAULT_ROLES_PATH",
        "plugin_name"
    ]
    test_variables_3 = dict(
        {
            'nested': dict(
                {
                    'var': 'value'
                }),
            'var': 'value'
        }
    )
    test_kwargs_4 = dict(
        {
            'plugin_name': 'template',
            'on_missing': 'error',
            'plugin_type': 'shell'
        }
    )
    test_result_5 = lookup_module_1.run(test_terms_2, test_variables_3, **test_kwargs_4)

# Generated at 2022-06-25 10:23:31.716761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    result = lookup_module_0.run(terms, variables)
    assert result == [u'root']


# Generated at 2022-06-25 10:23:50.243620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Invalid setting identifier, "DEFAULT_BECOME_USER" is not a string, its a <type 'unicode'>
    terms = u'DEFAULT_BECOME_USER'
    variables = None
    kwargs = dict()
    assert lookup_module_1.run(terms, variables, **kwargs) == [u'root']


# Generated at 2022-06-25 10:23:55.247694
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module.set_templar(None)

    # all_results = lookup_module.run(terms, variables=None, **kwargs)
    # TODO: implement this test, use assertEquals?
    assert all_results is not None

# Generated at 2022-06-25 10:24:02.659895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup mocks
    lookup_module_0 = LookupModule()
    terms_0 = ["test_terms_0", "test_terms_1"]
    variables_0 = {}
    wanted_result = ["test_LookupModule_run_result_0", "test_LookupModule_run_result_1"]
    lookup_module_0.run = MagicMock(return_value=wanted_result)
    # Call function run of class LookupModule with arguments terms_0 and variables_0
    actual_result = lookup_module_0.run(terms_0, variables_0)
    assert actual_result == wanted_result

# Generated at 2022-06-25 10:24:05.911768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_values = [
         'DEFAULT_BECOME_USER'
    ]
    lookup_module_0.run(terms_values)

# Generated at 2022-06-25 10:24:08.174819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = "remote_user"
    lookup_module_0.run(terms=[term_0])

# Generated at 2022-06-25 10:24:12.405779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    args = dict(terms=[u'_ansible_remote_tmp'])

    runs = 1
    expected = u'/home/ansible/tmp'

    for i in range(runs):
        assert lookup_module_1.run(**args) == expected



# Generated at 2022-06-25 10:24:14.856618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    retval = lookup_module_0.run(terms, variables=None, **kwargs)
    assert retval is not None


# Generated at 2022-06-25 10:24:24.835179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_global_config(config):
        return getattr(C, config)

    with pytest.raises(AnsibleOptionsError):
        options = {'var_options': {'test': 'test'}, 'direct':{'on_missing': 'test', 'plugin_type': None, 'plugin_name': None}}
        lookup_module = LookupModule()
        lookup_module.set_options(**options)
        lookup_module.run(terms=['test'])

    with pytest.raises(AnsibleOptionsError):
        options = {'var_options': {'test': 'test'}, 'direct':{'on_missing': None, 'plugin_type': 'test', 'plugin_name': None}}
        lookup_module = LookupModule()
        lookup_module.set_options(**options)


# Generated at 2022-06-25 10:24:30.674922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = lookup_module_0
    lookup_module_obj.set_loader(DictDataLoader({}))

    # this is a bad test, probably should be using mock, but oh well
    result = lookup_module_obj.run(["foo"], templar=MagicMock())
    # if config is not defined, return an empty list
    assert not result, result


# Generated at 2022-06-25 10:24:34.087156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=["DEFAULT_BECOME_USER"], variables=None)
    assert result == [u'root']


# Generated at 2022-06-25 10:25:02.915954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []



# Generated at 2022-06-25 10:25:11.099690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module_1.run(['DEFAULT_ROLES_PATH']) == ['/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/plugins/modules/roles', '/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/plugins/modules/roles', '/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/plugins/modules/roles']

# Generated at 2022-06-25 10:25:17.062231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  setattr(lookup_module_0,
          '_display',
          {'CLIARGS': {'verbosity': 0}})
  terms_0 = None
  variables_0 = None
  kwargs_0 = {'plugin_type': 'cliconf', 'plugin_name': 'ios'}
  assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) is None
  kwargs_1 = {'plugin_name': 'ios'}
  assert lookup_module_0.run(terms_0, variables_0, **kwargs_1) is None
  kwargs_2 = {'plugin_type': 'cliconf'}

# Generated at 2022-06-25 10:25:23.357812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = ['$ANSIBLE_CONFIG', '$PWD']
    variables_3 = {u'debug': False}
    kwargs_4 = {}
    nxc_5 = {u'debug': False}
    try:
        result_6 = lookup_module_1.run(terms_2, variables_3, **kwargs_4)
    except Exception as e_7:
        result_8 = e_7

    assert type(result_8) == AnsibleLookupError

# Generated at 2022-06-25 10:25:31.796661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # DEFINE VARS
    lookup_module_1 = LookupModule()
    terms_1 = [
        'DEFAULT_BECOME_USER'
    ]
    variables_1 = {
        'foo': 'bar'
    }
    kwargs_1 = {
        'wantlist': True
    }
    # CALL METHOD UNDER TEST
    result_1 = lookup_module_1.run(
        terms_1,
        variables_1,
        **kwargs_1
    )
    # CHECK RESULT
    assert result_1 == ['root']


# Generated at 2022-06-25 10:25:41.158452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Test case with no value set for the option "on_missing".
    # Test expectation: The plugin should raise an exception and fail.
    lookup_module_1 = LookupModule()
    terms_1 = 'UNKNOWN'
    variables_1 = None
    kwargs_1 = {}
    try:
        lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    except AnsibleLookupError:
        pass
    else:
        raise AssertionError('Expected failure did not occur.')
    # Test case 2:
    # Test case with option "on_missing" set to an invalid value.
    # Test expectation: The plugin should raise an exception and fail.
    lookup_module_2 = LookupModule()
    terms_2 = 'UNKNOWN'


# Generated at 2022-06-25 10:25:43.656374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = "foo"
    result = lookup_module.run(terms)
    assert result == ['foo']


# Generated at 2022-06-25 10:25:46.362515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms                                                    = ['DEFAULT_BECOME_USER']
    variables                                                = {}
    kwargs                                                   = {}
    assert lookup_module_1.run(terms, variables, kwargs)     == ['root']


# Generated at 2022-06-25 10:25:52.074515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test code without the keyword arguments
    lookup_object = LookupModule()
    lookup_object.get_option = Mock(return_value='error')
    lookup_object.run([], {})
    lookup_object.get_option.assert_called_once_with('on_missing')
    # test code with the keyword arguments
    lookup_object.get_option = Mock(return_value='error')
    lookup_object.run([], {}, **{'var_options' : {}, 'direct' : {}})
    lookup_object.get_option.assert_called_once_with('on_missing')


# Generated at 2022-06-25 10:25:59.464124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    """Tests run with default terms. """
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    terms_0 = ['remote_tmp']
    variables_0 = {}

    result = lookup_module_run_0.run(terms_0, variables_0)
    assert result == ['/tmp/ansible-tmp-1475877654.73-147729857856000']


# Generated at 2022-06-25 10:27:05.577690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ansible_vars = dict()
    ansible_vars['ansible_user'] = 'vagrant'
    ansible_vars['ansible_password'] = 'vagrant'
    ansible_vars['ansible_port'] = '22'
    ansible_vars['ansible_host'] = 'localhost'
    ansible_vars['ansible_connection'] = 'ssh'
    ansible_vars['ansible_ssh_user'] = 'vagrant'
    ansible_vars['ansible_ssh_pass'] = 'vagrant'
    ansible_vars['ansible_become_method'] = 'sudo'
    ansible_vars['ansible_become_user'] = 'root'

# Generated at 2022-06-25 10:27:09.573286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options = None, direct = {})
    lookup_module.run([u'DEFAULT_ROLES_PATH'], variables = None, **{})


# Generated at 2022-06-25 10:27:12.989102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    print("")
    print("In test_LookupModule_run")
    print("")

    if (lookup_module_1.run("foo", {}) == []):
        print("LookupModule_run is correct")
    else:
        print("LookupModule_run not correct")


# Generated at 2022-06-25 10:27:16.578074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['DEFAULT_BECOME_METHOD']
    variables = None
    result = lookup_module_1.run(terms, variables)
    assert len(result) == 1


# Generated at 2022-06-25 10:27:22.665604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['']
    variables_1 = {}
    kwargs_1 = {}
    ret = lookup_module_1.run(terms_1,variables_1,**kwargs_1)
    # No assertions, as the method just returns
    return ret


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:27:28.347390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # kwargs
    kwargs = {"spew": "spew"}
    # terms
    terms_1 = []
    # LookupModule: 1st position, direct flag set is True
    assert lookup_module_1.run(terms_1) == lookup_module_1.run(terms_1, **kwargs)


# Generated at 2022-06-25 10:27:31.165354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms=[ "example" ]
  keywords={ "on_missing":"warn" }
  lookup_module_0 = LookupModule()
  lookup_module_0.run(terms, **keywords)

# Generated at 2022-06-25 10:27:36.475151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["%(lookup_fqcn)s"]
    # Setup the mocked variables
    variables_0 = {}
    # Invoke method
    result = lookup_module_0.run(terms_0, variables_0)
    # Check the result
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == "ansible.plugins.lookup.config"

# Generated at 2022-06-25 10:27:39.390998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0) == LookupModule
    ret = lookup_module_0.run(['DEFAULT_BECOME_USER'])
    assert ret == ['root'], ret


# Generated at 2022-06-25 10:27:46.258414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ANSIBLE_CONFIG']
    kwargs_0 = {}
    lookup_module_0.run(terms_0, kwargs_0)
    lookup_module_1 = LookupModule()
    terms_1 = ['DEFAULT_BECOME_USER']
    kwargs_1 = {}
    lookup_module_1.run(terms_1, kwargs_1)
    lookup_module_2 = LookupModule()
    terms_2 = ['DEFAULT_ROLES_PATH']
    kwargs_2 = {}
    lookup_module_2.run(terms_2, kwargs_2)
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 10:29:47.017319
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case arguments
    ansible_configs = []


# Generated at 2022-06-25 10:29:52.249556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ['DEFAULT_ROLES_PATH']
    variables_2 = {}
    kwargs_3 = {}

# Generated at 2022-06-25 10:29:53.976675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run("DEFAULT_BECOME_USER") == "root"


# Generated at 2022-06-25 10:30:04.262640
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert 'lookup_plugin_config' == LookupModule.run.__name__

    # test without any parameters
    try:
        LookupModule.run(terms, variables, **kwargs)
    except SystemExit:
        pass

    # test with options
    options = {'_terms': 'ansible_python_version', 'on_missing': 'error', 'plugin_type': None, 'plugin_name': None}
    LookupModule.run(terms, variables, **options)

    # test without parameters
    LookupModule.run(terms, variables)

    # test with invalid value for on_missing parameter
    options = {'_terms': 'ansible_python_version', 'on_missing': 'wrongvalue', 'plugin_type': None, 'plugin_name': None}

# Generated at 2022-06-25 10:30:09.744141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    setattr(lookup_module_1,'set_options',lambda x: None)
    setattr(lookup_module_1,'get_option',lambda x: None)

    setattr(lookup_module_1,'run',lambda terms,variables=None, **kwargs:typing_test_LookupModule_run(lookup_module_1,terms,variables, **kwargs))
    lookup_module_1.run(terms = "terms_0",variables = "variables_0", **"kwargs_0")



# Generated at 2022-06-25 10:30:15.432118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options()
    terms = ['DEFAULT_ROLES_PATH']

# Generated at 2022-06-25 10:30:17.685941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_result = lookup_instance.run(['DEFAULT_BECOME_USER'], {})
    assert lookup_result == ['root']

# Generated at 2022-06-25 10:30:26.345381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(terms=["DEFAULT_BECOME_USER"])
    except AnsibleOptionsError:
        assert True
    except Exception:
        assert False, "Unexpected exception"
    else:
        assert False, "Expected exception"

    try:
        lookup_module_1.run(terms=["DEFAULT_BECOME_USER"], variables=["DEFAULT_BECOME_USER"])
    except AnsibleOptionsError:
        assert True
    except Exception:
        assert False, "Unexpected exception"
    else:
        assert False, "Expected exception"


# Generated at 2022-06-25 10:30:34.772363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = 'DEFAULT_BECOME_USER'
    assert lookup_module.run([term])[0] == 'root'
    term = 'DEFAULT_ROLES_PATH'
    assert lookup_module.run([term])[0] == ['/etc/ansible/roles', '/usr/share/ansible/roles']
    term = 'RETRY_FILES_SAVE_PATH'
    assert lookup_module.run([term])[0] == '~/.ansible/retry'
    term = 'COLOR_OK'
    term1 = 'COLOR_CHANGED'
    term2 = 'COLOR_SKIP'
    assert lookup_module.run([term, term1, term2], **{'wantlist': True}) == ['green', 'yellow', 'cyan']

# Generated at 2022-06-25 10:30:43.668606
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
