

# Generated at 2022-06-25 10:22:36.696045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Test missing option
    result = lookup_module_1.run(['UNKNOWN_KEY'])
    assert len(result) == 0

    # Test valid configuration
    result = lookup_module_1.run(['DEFAULT_BECOME_USER'])
    assert len(result) == 1
    assert result[0] == 'root'

# Generated at 2022-06-25 10:22:39.808908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['default_remote_user']
    variables = {}
    kwargs = {'wantlist': True}
    result=lookup_module.run(terms, variables, **kwargs)
    assert [u'root'] == result

# Generated at 2022-06-25 10:22:42.672649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # FIXME: Uncomment when run() is implemented.
    # assert lookup_module_0.run(terms) == 'Invalid setting identifier, "1" is not a string, its a '

# Generated at 2022-06-25 10:22:44.024359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 10:22:51.037657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'ssh', 'var_options': {'vars': {'ansible_ssh_port': 22, 'ansible_user': 'root'}}})
    test_terms_0 = ['remote_host', 'private_key_file']
    result_0 = lookup_module_0.run(test_terms_0)
    assert result_0[0] == '*'
    assert result_0[1] == '~/.ssh/id_rsa'

# Generated at 2022-06-25 10:22:54.111960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['accelerate_port'], variables=None, ) == [22]


# Generated at 2022-06-25 10:22:58.992081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Multiple terms and setting should be same as terms
    terms = ['foo', 'bar']
    assert lookup_module_0.run(terms, variables=None) == terms
    # Single term
    terms = 'foo'
    assert lookup_module_0.run(terms, variables=None) == ['foo']


# Generated at 2022-06-25 10:23:09.942736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    terms_0 = ['DEFAULT_BECOME_USER']
    terms_1 = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS']
    # FIXME: add more tests
    terms_2 = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS', 'DEFAULT_BECOME_PASS', 'COLOR_OK', 'COLOR_SKIP', 'COLOR_UNREACHABLE', 'COLOR_CHANGED']

    # FIXME: add more tests

# Generated at 2022-06-25 10:23:10.511440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:23:15.203226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_1 = (C.RETRY_FILES_SAVE_PATH, C.ACTION_WARNINGS, C.DEFAULT_ROLES_PATH)
    var_options = {}
    direct = {}
    lookup_module_0._display = None
    var_options = {}
    direct = {}
    lookup_module_0.set_options(var_options, direct)
    lookup_module_0.run(tuple_1, var_options)

# Generated at 2022-06-25 10:23:26.820800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    var_1 = C.lookup_module_1.run()


# Generated at 2022-06-25 10:23:29.132864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    assert var_0 == False

# Generated at 2022-06-25 10:23:37.162148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(['DEFAULT_BECOME_USER'], {}, on_missing='error')

    with pytest.raises(AnsibleLookupError):
        l.run(['DEFAULT_BECOME_USER'])

    l.run(['DEFAULT_BECOME_USER'], {}, on_missing='warn')
    l.run(['DEFAULT_BECOME_USER'], {}, on_missing='skip')

    with pytest.raises(AnsibleOptionsError):
        l.run(['DEFAULT_BECOME_USER'], {}, on_missing='bad')

    with pytest.raises(AnsibleOptionsError):
        l.run([17], {}, on_missing='warn')

# Generated at 2022-06-25 10:23:43.463995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    if not var_0: 
        raise Exception("[FAIL] - invalid return type for lookup_module.run")
    try:
        var_0 = lookup.run(bool_0)
    except AnsibleOptionsError as e:
        print(e)

test_LookupModule_run()

# Generated at 2022-06-25 10:23:46.052573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    type(var_0) is list  # AssertionError


# Generated at 2022-06-25 10:23:48.460964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run(["config_key"])


# Generated at 2022-06-25 10:23:52.886207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    plugin_type_0 = null()
    plugin_name_0 = null()
    on_missing_0 = null()
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 10:23:54.577785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Insert code here
    pass


# Generated at 2022-06-25 10:23:57.524679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    var_0 = lookup_module_0.run(bool_0)



# Generated at 2022-06-25 10:24:01.004744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)

    # testcase
    result = lookup_module_0.run(var_0)
    assert result is None

# Generated at 2022-06-25 10:24:15.994119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bool_1 = True
    var_1 = lookup_run(bool_1)


# Generated at 2022-06-25 10:24:17.569170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 10:24:22.837410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_1.run(bool_0)
    bool_1 = False
    var_1 = lookup_module_1.run(bool_1)
    bool_2 = False
    var_2 = lookup_module_1.run(bool_2)
    bool_3 = False
    var_3 = lookup_module_1.run(bool_3)
    bool_4 = False
    var_4 = lookup_module_1.run(bool_4)
    bool_5 = False
    var_5 = lookup_module_1.run(bool_5)
    bool_6 = False
    var_6 = lookup_module_1.run(bool_6)
    bool_7 = False

# Generated at 2022-06-25 10:24:29.965996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    assert(var_0 == None)

if __name__ == "__main__":
    import sys
    import nose
    from ansible.utils.color import colorize, hostcolor
    arguments = [sys.argv[0], '-vvs', '-x', '--pdb', '--pdb-failure']
    nose.main(argv=arguments)

# Generated at 2022-06-25 10:24:36.059981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_parameters = {
        "terms": [
            "C.DEFAULT_BECOME_USER"
        ],
        "variables": {
            "C.DEFAULT_BECOME_USER": "root"
        },
        "kwargs": {
            "direct": {
                "C.DEFAULT_BECOME_USER": "root"
            },
            "var_options": {
                "C.DEFAULT_BECOME_USER": "root"
            }
        }
    }
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=set_parameters["var_options"], direct=set_parameters["kwargs"])
    bool_1 = True

# Generated at 2022-06-25 10:24:41.703901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "Unable to find setting DEFAULT_BECOME_USER"
    lookup_module_1 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    bool_1 = True
    var_1 = lookup_module_1.run(bool_0)


# Generated at 2022-06-25 10:24:45.820851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.get_option()
    lookup_module_0.run(bool_0)
    lookup_module_0.run(bool_0)


# Generated at 2022-06-25 10:24:46.854419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = lookup_module_0.run(['inventory_file'])
    eq_('', bool_0)



# Generated at 2022-06-25 10:24:48.827610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 10:24:50.575268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 10:25:20.202908
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    bool_0 = False
    var_1 = lookup_run(bool_0)

    assert var_1 is not None

# Generated at 2022-06-25 10:25:22.028265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    lookup_module_0.run(bool_0)

# Generated at 2022-06-25 10:25:31.469064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("In test_LookupModule_run")
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:25:37.295274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    assert(var_0 == 0)

###############################################################################
# Program test
#
# In this test we run the tests/test.yml playbook with
# -vvvv
#
# We check that in the debug output we have no mention of [WARNING] or [ERROR]
###############################################################################

# Generated at 2022-06-25 10:25:39.439120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 10:25:42.789720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    var_0 = lookup_run(bool_0)

# Run lookup_run with args
# args[0]: a boolean 

# Generated at 2022-06-25 10:25:45.069290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    assert var_0 == 'error'

# Generated at 2022-06-25 10:25:47.814283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    lookup_module_0.set_options(var_options=bool_0, direct=None)
    lookup_module_0.run('DEFAULT_BECOME_USER')


# Generated at 2022-06-25 10:25:49.401386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 10:25:52.235290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(["DEFAULT_ROLES_PATH"], {"DEFAULT_ROLES_PATH": "/home/user/.ansible/roles"})
    assert result == ["/home/user/.ansible/roles"]



# Generated at 2022-06-25 10:26:50.852976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_instance = LookupModule()
    terms = ['']
    on_missing = 'error'
    plugin_type = 'connection'
    plugin_name = 'ssh'
    lookup_module_run_instance.run(terms, on_missing=on_missing, plugin_type=plugin_type, plugin_name=plugin_name)



# Generated at 2022-06-25 10:26:55.923499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_1 = LookupModule()
        bool_0 = False
        terms_0 = "DEFAULT_BECOME_USER"
        var_0 = lookup_module_1.run(bool_0, terms_0)
    except Exception as e:
        assert False
    return True


# Generated at 2022-06-25 10:26:58.646624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:27:01.447268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1
    dict_0 = dict()
    lookup_module_0 = LookupModule()
    int_1 = run_method_0(int_0)

# Generated at 2022-06-25 10:27:04.032460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 10:27:10.417802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'direct': {'_terms': ['DEFAULT_BECOME_USER']}})
    lookup_module_0._load_name = 'DEFAULT_BECOME_USER'
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    print(lookup_module_0._display.display)

# Generated at 2022-06-25 10:27:17.778763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    terms_0 = ['DEFAULT_BECOME_USER']
    terms_1 = ['DEFAULT_ROLES_PATH']
    terms_2 = ['RETRY_FILES_SAVE_PATH']
    terms_3 = ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    terms_4 = ['UNKNOWN']
    terms_5 = ['remote_user', 'port']
    terms_6 = ['remote_tmp']
    variables_0 = None
    variables_1 = None
    variables_2 = None
    variables_3 = None
    variables_4 = None
    variables_5 = None
    variables_6 = None
    plugin_type_0 = None
    plugin_type_1 = None
    plugin_type

# Generated at 2022-06-25 10:27:28.925670
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    list_0 = [1, 2, 3, 4]
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24

# Generated at 2022-06-25 10:27:31.916415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 10:27:40.388810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = None
    bool_0 = True
    var_0 = lookup_run(term_0, bool_0)
    var_1 = lookup_run(term_0, bool_0)
    var_2 = "unknown"
    var_3 = lookup_run(term_0, bool_0, unknown=var_2)
    lookup_module_1 = LookupModule()
    term_1 = None
    bool_1 = True
    var_4 = lookup_run(term_1, bool_1)
    lookup_module_2 = LookupModule()
    term_2 = None
    bool_2 = True
    var_5 = lookup_run(term_2, bool_2)
    lookup_module_3 = LookupModule()
    term_3

# Generated at 2022-06-25 10:29:42.507520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)


# Generated at 2022-06-25 10:29:48.368233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = True
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = True
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = True
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = True

# Generated at 2022-06-25 10:29:58.999586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # bool_0 is an instance of bool
    bool_0 = True
    list_0 = ['foo']
    # 'variables' is an instance of list
    variables = []
    ret_0 = lookup_module_0.run(list_0, variables, ANSIBLE_CACHE_PLUGIN='', ANSIBLE_RETRY_FILES_ENABLED=True, ANSIBLE_CACHE_PLUGIN_CONN='', ANSIBLE_JINJA2_EXTENSIONS=True, ANSIBLE_FORKS=True, ANSIBLE_REMOTE_TEMP='', ANSIBLE_CONFIG='', ANSIBLE_SSH_RETRIES='', ANSIBLE_INVENTORY_ENABLED=True,)
    assert type(ret_0)

# Generated at 2022-06-25 10:30:04.525623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)
    assert(var_0 == "dummy_image")
    assert(var_0 == "dummy_image")
    assert(var_0 == "dummy_image")
    assert(var_0 == "dummy_image")
    assert(var_0 == "dummy_image")


# Generated at 2022-06-25 10:30:06.908612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    options = { 'on_missing': 'error',  }
    terms = 'UNKNOWN_TERM'
    test_args = [terms,]
    LookupModule.run(self, terms, **options)

# Generated at 2022-06-25 10:30:10.363224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    bool_2 = False
    str_0 = 'DEFAULT_ROLES_PATH'
    list_0 = [str_0]
    var_0 = lookup_run(bool_2, list_0=list_0)
    var_1 = lookup_run(bool_2, list_0=list_0)
    if var_0 != var_1:
        raise AssertionError("var_0 != var_1")


# Generated at 2022-06-25 10:30:18.475713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)


# Generated at 2022-06-25 10:30:20.791987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    bool_arg = False
    var_arg = lookup_run(bool_arg)


# Generated at 2022-06-25 10:30:30.185102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # The following boolean is True for when the unittest will fail, false if it will pass
    bool_0 = False
    var_0 = lookup_run(bool_0)

    # The following boolean is True for when the unittest will fail, false if it will pass
    bool_1 = False
    var_1 = lookup_run(bool_1)

    # The following boolean is True for when the unittest will fail, false if it will pass
    bool_2 = False
    var_2 = lookup_run(bool_2)

    # The following boolean is True for when the unittest will fail, false if it will pass
    bool_3 = False
    var_3 = lookup_run(bool_3)

    # The following boolean is True for when the unittest will fail

# Generated at 2022-06-25 10:30:32.276351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    assert var_0 == []
