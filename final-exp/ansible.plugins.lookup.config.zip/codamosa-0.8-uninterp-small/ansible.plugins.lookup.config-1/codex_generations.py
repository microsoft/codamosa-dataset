

# Generated at 2022-06-25 10:22:36.621308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_base_0 = LookupBase()
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.get_option(option='on_missing')
    lookup_module_0.get_option(option='plugin_type')
    lookup_module_0.get_option(option='plugin_name')
    lookup_module_0.run(terms=lookup_base_0, variables=None, **lookup_base_0)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:22:38.490772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    assert lookup_module_0.run(terms) == []

# Generated at 2022-06-25 10:22:45.280559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_1 = set()
    LookupModule_1 = LookupModule()
    terms_1 = set_1
    variables_1 = set_1
    kwargs_1 = dict()
    kwargs_1['on_missing'] = "error"
    kwargs_1['plugin_name'] = "global"
    kwargs_1['plugin_type'] = "connection"
    result = LookupModule_1.run(terms=terms_1, variables=variables_1, **kwargs_1)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == set_1


# Generated at 2022-06-25 10:22:50.228383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_options_0 = dict()
    set_options_0['var_options'] = Sentinel
    set_options_0['direct'] = Sentinel
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(**set_options_0)
    terms_0 = list()
    try:
        lookup_module_0.run(terms_0)
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-25 10:22:54.346548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = "expected value"
    terms_0 = [term_0]
    variables_0 = {}
    result_0 = LookupModule().run(terms_0, variables=variables_0)

    assert result_0[0] == term_0

# Generated at 2022-06-25 10:23:02.111932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up object
    term0 = ['DEFAULT_ROLES_PATH']
    variable0 = None
    variable1 = 'error'
    variable2 = 'ssh'
    variable3 = 'connection'
    variable4 = 'skip'
    lookup_module0 = LookupModule()
    lookup_module0.set_loader(None)

    # call the method
    try:
        result = lookup_module0.run(term0, variable0, on_missing=variable1, plugin_type=variable3, plugin_name=variable2, on_missing=variable4)
    except AnsibleLookupError:
        pass
    else:
        assert False, "AnsibleLookupError not raised"


# Generated at 2022-06-25 10:23:08.090563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype_0 = 'shell'
    pname_0 = 'sh'
    term_0 = 'remote_tmp'
    ret_0 = LookupModule().run(terms=[term_0], plugin_type=ptype_0, plugin_name=pname_0)
    expected_0 = '/tmp'
    assert ret_0 == [expected_0]


# Generated at 2022-06-25 10:23:10.760484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_module = LookupModule()
    set_0 = set()
    assert test_lookup_module.run(set_0).__class__.__name__ == 'list'

# Generated at 2022-06-25 10:23:11.629049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise NotImplementedError

# Generated at 2022-06-25 10:23:18.517504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    # Test the first path
    terms_0 = ['DEFAULT_BECOME_USER']
    variables_0 = None
    kwargs_0 = {}
    ret_0 = lookupModule.run(terms_0, variables_0, **kwargs_0)
    # Test the second path
    terms_1 = ['DEFAULT_BECOME_USER']
    variables_1 = None
    kwargs_1 = {}
    ret_1 = lookupModule.run(terms_1, variables_1, **kwargs_1)
    if ret_0 != ret_1:
        raise AssertionError('Return values do not match')
    terms_2 = ['DEFAULT_BECOME_USER']
    variables_2 = None
    kwargs_2 = {}

# Generated at 2022-06-25 10:23:29.346082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    # invoke func
    var_0 = lookup_module_1.run(tuple_1)
    assert var_0 == []

# Generated at 2022-06-25 10:23:34.083031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    tuple_3 = ()
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)
    assert var_0 == ()

# Generated at 2022-06-25 10:23:36.476845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import six
    if six.PY3:
        test_LookupModule_run._test(six.u(''))
    else:
        test_LookupModule_run._test(None)


# Generated at 2022-06-25 10:23:44.009436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # SUT
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

# Generated at 2022-06-25 10:23:54.491222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (0)
    tuple_1 = ('string0', 1, 2.0, tuple_0)
    lookup_module_0 = LookupModule(tuple_1, str())
    # var_0 = lookup_module_0.run(tuple_1)
    # Test case 'on_missing'
    # Should raise the following exception:
    # `AnsibleOptionsError('"on_missing" must be a string and one of "error", "warn" or "skip", not %s' % missing)`
    #
    # Test case 'plugin_type'
    # Should raise the following exception:
    # `AnsibleOptionsError('Both plugin_type and plugin_name are required, cannot use one without the other')`

    # Test case 'plugin_name'
    # Should raise the following exception:
    #

# Generated at 2022-06-25 10:24:03.375339
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:24:10.388482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    dict_0 = {'plugin_name': 'qrqrq', 'on_missing': 'qrqrq'}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(list_0)


# Generated at 2022-06-25 10:24:17.845157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup data
    tuple_0 = ()
    lookup_module_3 = LookupModule(tuple_0)
    var_0 = None
    str_0 = 'CHANGED'
    dict_0 = {str_0: False}
    # LookupModule.run(self, terms, variables=None, **kwargs)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 10:24:23.060641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0]
    set_0 = set()
    tuple_1 = (list_0, set_0)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_module_0.run(tuple_1)
    # test for errors

# Generated at 2022-06-25 10:24:30.138663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set(["DEFAULT_BECOME_USER"])
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

# Generated at 2022-06-25 10:24:44.617822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert type(test_case_0()) == list


# Generated at 2022-06-25 10:24:51.908491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)
    if var_0 == tuple_0:
        print('Successful')
    else:
        raise AssertionError('incorrect value returned by LookupModule.run')

# Generated at 2022-06-25 10:24:54.828891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pname = 'ansible'
    ptype = 'cliconf'
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run(pname, ptype)
    assert x == False

# Generated at 2022-06-25 10:25:00.874215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)
    assert var_0 == []

# Generated at 2022-06-25 10:25:07.068475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(tuple_0)
    var_0 = lookup_module_1.run(tuple_1)
    assert len(var_0) == 3

# Generated at 2022-06-25 10:25:14.190606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleOptionsError

    lookup_module = LookupModule(None)

    # test correct exception if 'on_missing' is not a string
    with pytest.raises(AnsibleOptionsError) as error:
        lookup_module.run(
            terms=None,
            variables={"on_missing": None},
        )

    # test correct exception if 'on_missing' is not a valid string
    with pytest.raises(AnsibleOptionsError) as error:
        lookup_module.run(
            terms=None,
            variables={"on_missing": "not_one_of_error_warn_skip"},
        )

    # test correct exception if 'plugin_type' or 'plugin_name' is specified but not both

# Generated at 2022-06-25 10:25:21.582087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

    assert len(var_0) == 3
    assert var_0[0] == tuple_0
    assert var_0[1] == list_0
    assert var_0[2] == set_0

# Generated at 2022-06-25 10:25:22.829098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == len(LookupModule().run('abc', 'def'))

# Generated at 2022-06-25 10:25:24.180097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Unit test end



# Generated at 2022-06-25 10:25:26.130459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run_test_0(LookupModule(None))


# Generated at 2022-06-25 10:25:57.871479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        "terms": ["term_1"],
        "variables": "var_1",
        "plugin_type": "plugin_type_1",
        "plugin_name": "plugin_name_1",
        "on_missing": "error"
    }
    lookup_module_0 = LookupModule(**args)
    ret_0 = lookup_module_0.run(**args)
    assert ret_0[0] == "var_1"

# Generated at 2022-06-25 10:26:04.062903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)



# Generated at 2022-06-25 10:26:10.393869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)
    test_case_0()

# Generated at 2022-06-25 10:26:17.161787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

# Generated at 2022-06-25 10:26:21.760988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

# Generated at 2022-06-25 10:26:28.099739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule({})
    assert m.run(terms=['foo'], wantlist=True)
    assert m.run(terms=['foo'], wantlist=False)
    assert m.run(terms=['foo'], wantlist=True, plugin_name='test', plugin_type='test')
    assert m.run(terms=['foo'], wantlist=False, plugin_name='test', plugin_type='test')

# Generated at 2022-06-25 10:26:35.172099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)
    assert (var_0 == [tuple_0, list_0, set_0])

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:26:46.242496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_0._display = dict()
    lookup_module_0._display["vv"] = None
    lookup_module_0._display["vvv"] = None
    tuple_1 = (None, )
    var_0 = lookup_module_0.run(tuple_1)
    tuple_2 = ()
    lookup_module_1 = LookupModule(tuple_2)
    tuple_3 = (lookup_module_1, )
    var_1 = lookup_module_1.run(tuple_3)
    var_2 = lookup_module_1.run(tuple_3)
    var_3 = lookup_module_1.run(tuple_3)
    var_4 = lookup_module_

# Generated at 2022-06-25 10:26:47.898120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:26:54.734169
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:27:53.779924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [("ansible_service_mgr"), ("DEFAULT_ROLES_PATH"), ("DEFAULT_JINJA2_NATIVE")]
    variables = {}
    tuple_0 = (terms, variables)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_module_0.run(terms)
    return var_0

# Generated at 2022-06-25 10:28:01.615594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        tuple_0 = ()
        list_0 = [tuple_0, tuple_0]
        set_0 = set()
        tuple_1 = (tuple_0, list_0, set_0)
        tuple_2 = ()
        lookup_module_0 = LookupModule(tuple_2)
        lookup_module_1 = LookupModule(lookup_module_0)
        var_0 = lookup_module_1.run(tuple_1)
        assert len(var_0) == 1
    except:
        assert False
        raise

# Generated at 2022-06-25 10:28:10.028095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    # lookups = ['a', 'b', 'c']
    lookups = ['DEFAULT_BECOME_USER', 'DEFAULT_RETRY_FILES_SAVE_PATH', 'DEFAULT_ROLES_PATH']

    # var_0 = lookup_module_1.run(tuple_1)
    var_0 = lookup_module_1.run(lookups)
    print(var_0)


# Generated at 2022-06-25 10:28:21.030995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = ()
    args_1 = {}
    args_2 = ('DEFAULT_BECOME_USER',)
    args_3 = {'wantlist': True, 'ptype': 'become', 'pname': 'sudo'}
    self_0 = LookupModule(args_0)
    self_1 = LookupModule(args_0)
    self_2 = LookupModule(args_0)
    self_3 = LookupModule(args_0)
    self_4 = LookupModule(args_0)
    self_5 = LookupModule(args_0)
    self_6 = LookupModule(args_0)
    self_7 = LookupModule(args_0)
    self_8 = LookupModule(args_0)
    self_9 = LookupModule(args_0)

# Generated at 2022-06-25 10:28:28.255403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

# Generated at 2022-06-25 10:28:33.414017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

# Generated at 2022-06-25 10:28:37.318041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    var_0 = lookup_module_0.run(tuple_1)



# Generated at 2022-06-25 10:28:46.772918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test run() function of class LookupModule"""

    # Testing exception: AnsibleLookupError
    try:
        tuple_0 = ()
        set_0 = set()
        tuple_1 = (tuple_0, set_0)
        print('Calling run() of class LookupModule')
        lookup_module_0 = LookupModule(tuple_1)
        lookup_module_0.run(tuple_1)
    except Exception as e:
        print(' Caught exception')
        print('%s: %s' % (type(e), str(e)))

    # Testing exception: AnsibleLookupError

# Generated at 2022-06-25 10:28:55.561441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test a missing setting
    try:
        result = C.config.get_config_value('NO_SUCH_SETTING')
    except MissingSetting:
        pass  # this is the expected outcome

    # Test a simple global setting
    result = C.config.get_config_value('ANSIBLE_CONFIG')
    assert result is not None
    assert result == C.ANSIBLE_CONFIG

    # Test a setting that requires the variables to be passed in
    result = C.config.get_config_value('DEFAULT_ROLES_PATH', variables={'playbook_dir': '/etc'})
    assert result is not None
    assert result == '/etc/roles'

    # Test a setting that requires the variables to be passed in, but with an
    # atypical value
    result = C.config.get_config_

# Generated at 2022-06-25 10:29:05.087278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tup = ()
    lis = [tup, tup]
    set_0 = set()
    tup = (tup, lis, set_0)
    tup_1 = ()
    lookup_module_0 = LookupModule(tup_1)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tup)


tests = { "test_case_0" : test_case_0,
          "test_LookupModule_run" : test_LookupModule_run,
         }

# Usage
if __name__ == '__main__':

    # Testing
    import sys
    import doctest
    _doctest_flags = doctest.NORMALIZE_WHITESPACE | doctest.ELLIPS

# Generated at 2022-06-25 10:31:17.786546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_3 = LookupModule(tuple_2)
    test_case_0()
    var_0 = lookup_module_3.run(tuple_1)
    assert var_0 is tuple_0


# Generated at 2022-06-25 10:31:22.368108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)

# Generated at 2022-06-25 10:31:27.718717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    module = LookupModule(None)
    terms = (None,)
    variables = None
    kwargs = None
    expected_error_msg = 'Invalid setting identifier, "None" is not a string, its a %s' % type(None)
    # Verify
    try:
        module.run(terms, variables, **kwargs)
    except AnsibleOptionsError as err:
        assert str(err) == expected_error_msg


# Generated at 2022-06-25 10:31:33.038089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)



# Generated at 2022-06-25 10:31:40.645625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test run')
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    tuple_1 = ()
    lookup_module_0.run(tuple_0)
    lookup_module_0.run(tuple_1, variables=None, on_missing='error', plugin_type='httpapi', plugin_name='netconf')
    lookup_module_0.run(tuple_0, variables=None, on_missing='warn', plugin_type='netconf', plugin_name='become')

# Generated at 2022-06-25 10:31:43.896688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    var_0 = lookup_module_1.run(tuple_1)


# Generated at 2022-06-25 10:31:51.691349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0]
    set_0 = set()
    tuple_1 = (tuple_0, list_0, set_0)
    tuple_2 = ()
    lookup_module_0 = LookupModule(tuple_2)
    lookup_module_1 = LookupModule(lookup_module_0)
    str_0 = lookup_module_1.run(tuple_1)
    assert str_0 == tuple_0

# Generated at 2022-06-25 10:31:58.653439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = (1,)
    variables = None
    LookupModule_1 = LookupModule()
    LookupModule_2 = LookupModule(LookupModule_1)
    with pytest.raises(AnsibleOptionsError) as excinfo: # LookupBase#run
        LookupModule_1.run(terms)
    with pytest.raises(AnsibleOptionsError) as excinfo: # LookupBase#run
        LookupModule_2.run(terms, variables)

# Generated at 2022-06-25 10:32:04.241113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = ()
    dict_0 = {1: tuple_0}
    lookup_module_0 = LookupModule(dict_0)
    tuple_1 = ()
    str_0 = lookup_module_0.run(tuple_1)

# Generated at 2022-06-25 10:32:05.308060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_case_0()

    test_cases.test_case_0()