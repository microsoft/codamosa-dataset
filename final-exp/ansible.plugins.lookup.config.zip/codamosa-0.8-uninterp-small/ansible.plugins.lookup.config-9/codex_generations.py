

# Generated at 2022-06-25 10:22:37.300887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    config_label = 'DEFAULT_ROLES_PATH'
    config_value = lookup.run(terms=[config_label], variables={}, on_missing='warn')[0]
    assert config_label in config_value
    assert len(config_value) > 0


# Generated at 2022-06-25 10:22:41.843158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['DEFAULT_BECOME_USER']
    variables = {'role_path': '/home/user/ansible/my_roles'}
    kwargs = {'wantlist': True, 'on_missing': 'warn'}
    result = lookup_module.run(terms, variables, **kwargs)

    assert result[0] == 'root'



# Generated at 2022-06-25 10:22:46.474504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests if a MissingSetting exception is raised when a lookup value doesn't exist
    # Creates a LookupModule instance
    lookupMod = LookupModule()
    # Initialized the list of terms to look up in the config
    terms = [
        'missing_term'
    ]
    # Tests the run method of class LookupModule
    # Expected to raise a MissingSetting exception
    with pytest.raises(MissingSetting):
        lookupMod.run(terms)

# Generated at 2022-06-25 10:22:49.036129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        [
            '/foo/bar'
        ],
        {
        }
    ]
    kwargs = {
        'identity_only': True
    }
    check = LookupModule().run(*args,**kwargs)
    assert check == args[0]


# Generated at 2022-06-25 10:22:59.347792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # obj is a LookupModule object
    lookup_plugin = LookupModule()

    # set lookup plugin options which don't require edit
    def get_option(param, required=True, boolean=False, default=None, fallback=None, type='str', choices=None, no_log=False):
        return None

    lookup_plugin.get_option = get_option

    # set required lookup plugin options which require edit
    def set_options(var_options=None, direct=None):
        return None

    lookup_plugin.set_options = set_options

    # set required lookup plugin options which require edit
    def display(msg, color=None, stderr=False, screen_only=False, log_only=False):
        return None

    lookup_plugin.display = display

    # test when parameters terms, variables and kwargs

# Generated at 2022-06-25 10:23:09.985274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 1
    p = plugin_loader.get('debug')
    p = plugin_loader.get('debug', class_only=True)
    p._load_name = None
    p._setup_obj()
    p._setup_obj('asd')
    p.get_option()
    p.get_option('var')
    p.get_option('var', True)
    p.get_option('var', 1)
    p.get_option('var', 'hello')
    # Case 2
    p._load_name = "asd"
    p._setup_obj()
    p._setup_obj('asd')
    p.get_option()
    p.get_option('var')
    p.get_option('var', True)
    p.get_option('var', 1)

# Generated at 2022-06-25 10:23:14.542371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    sentence = 'This is just a test sentence'
    sentence_string = 'This is just a test sentence'
    lookup = LookupModule()
    # test raise exception
    with pytest.raises(AnsibleOptionsError):
        lookup.run(sentence, 'error', 'test_plugin')
    # test return a list
    assert lookup.run(sentence_string, 'error', None) == [sentence_string]

# Generated at 2022-06-25 10:23:20.392416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test 1 failed:
    # LookupError: Unable to find setting ''
    with pytest.raises(AnsibleLookupError) as AnsibleLookupError_0:
        lookup_module.run([''])
    assert AnsibleLookupError_0.value.orig_exc == missing_setting_0

# Generated at 2022-06-25 10:23:30.839900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure that our global variables are set
    C.DEFAULT_CONNECTION_NAME
    C.DEFAULT_DISPLAY_SKIPPED_HOSTS
    C.DEFAULT_STDOUT_CALLBACK

    # Make sure that values are set for plugin settings
    C.config.get_config_value('connection.local.shell', 'connection', 'local')

    # check that NonAscii settings are hit
    C.config.get_config_value('gettext_module', 'defaults', 'default')

    # check that new plugin settings are hit
    C.config.get_config_value('ssh.executable', 'connection', 'ssh')

    # Check the 'run' method of our LookupModule
    lookup_module = LookupModule()

    # Make sure that DEFAULT_STDOUT_CALLBACK lookup works
    default

# Generated at 2022-06-25 10:23:36.487739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pname = 'test_plugin'
    ptype = 'test_type'

    config = 'test_config'

    terms = [config]

    variables = {'test_variable': 'test_value'}

    mock_display = Mock()

    mock_plugin_loader = Mock()

    test_module = LookupModule(loader=mock_plugin_loader, display=mock_display)

    test_module._get_plugin_config = Mock()
    test_module._get_global_config = Mock()

    test_module.run(terms, variables)

    test_module._get_global_config.assert_called_once_with(config)

    mock_display.warning.assert_not_called()



# Generated at 2022-06-25 10:24:00.290508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    b_global_config = Sentinel
    b_conf = {'__ansible_module__': 'ansible.builtin.config', '_terms': ['b_term'], '_options': {'var_options': None, 'direct': {'plugin_type': 'b_plugin_type', 'plugin_name': 'b_plugin_name'}}, '_display': {}, '_lookup_plugin_cache': {}, '_templar': {}, '_loader': {}, '_connection_info': {}}
    b_variables = Sentinel
    b_ansible_module = Sentinel
    the_class = LookupModule
    the_method = LookupModule.run
    fail_msg = "Unable to find setting c_term"
    show_diff = False

    class b_C:
        c_config = Sentinel


# Generated at 2022-06-25 10:24:10.385686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given: a list of terms to lookup and a variable
    base_terms = [
        "DEFAULT_BECOME_USER",
        "DEFAULT_ROLES_PATH",
        "RETRY_FILES_SAVE_PATH"
    ]
    base_variables = dict()

    # When: get_config_vals is called
    lookupModule = LookupModule()
    result = lookupModule.run(base_terms, variables=base_variables)

    # Then: return list with values for "DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH", "RETRY_FILES_SAVE_PATH"
    assert len(result) == 3
    assert result[0] == "root"

# Generated at 2022-06-25 10:24:11.340647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.run("""
    {%regex%}
    """)


# Generated at 2022-06-25 10:24:14.745736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod.run('DEFAULT_BECOME_USER')
    lookup_mod.run('PORT', plugin_type='connection', plugin_name='ssh')
    lookup_mod.run('remote_tmp', plugin_type='shell', plugin_name='sh')

# Generated at 2022-06-25 10:24:23.729655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Normal Case for option on_missing.
    try:
        #_get_global_config(config)
        #_get_plugin_config(pname, ptype, config, variables)
        _get_global_config('CONFIG_FILE')
    except Exception as e:
        print(e)
    else:
        print('Test Failed')
    # Abnormal Case for option on_missing.
    try:
        lookup = LookupModule()
        lookup.run([])
    except AnsibleOptionsError as e:
        print(e)
    else:
        print('Test Failed')


if __name__ == '__main__':

    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:24:31.888670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # test argument missing
    try:
        module.run()
        assert False, 'The method run of LookupModule should raise an error if argument terms is missing'
    except:
        pass
    # test with invalid argument terms
    try:
        module.run('test_terms')
        assert False, 'The method run of LookupModule should raise an error if argument terms is invalid'
    except:
        pass
    # test with valid argument terms
    try:
        assert module.run(['test_terms']) == [], 'The method run of LookupModule does not return the expected result'
    except:
        pass

# Generated at 2022-06-25 10:24:35.281912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(['remote_tmp'], 'shell', 'sh')
    assert result == '/tmp/ansible-tmp'

# Generated at 2022-06-25 10:24:39.575124
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize an object of class LookupModule
    lookup_module = LookupModule()

    # Check for the method run in class LookupModule
    assert hasattr(lookup_module, 'run')  # True

    # Call the run method of LookupModule
    lookup_module.run()

# Generated at 2022-06-25 10:24:47.403454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We want to check the return of run() so we need to create an instance
    lookup_mod = LookupModule()

    # DEFAULT_CACHE_PLUGIN is the key we want to test here
    terms = C.DEFAULT_CACHE_PLUGIN
    variables = None
    kwargs = dict()

    # Get the return of run()
    result = lookup_mod.run(terms=terms, variables=variables, **kwargs)

    # Since we are only checking the return of run() and not its effects we can
    # use assertEqual()
    assertEqual(result, 'jsonfile')



# Generated at 2022-06-25 10:24:52.890867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:

        # Declare object of class LookupModule
        module = LookupModule()

        # Declare variables
        variables = {}

        # Declare terms
        terms = 'DEFAULT_MODULE_NAME'

        # Define kwargs
        kwargs = {'on_missing': 'error', 'plugin_type': None, 'plugin_name': None}

        # Calling run method of object module
        result = module.run(terms, variables, **kwargs)
        
        return result
    except Exception:
        return False


# Generated at 2022-06-25 10:25:29.341540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # LookupModule.run takes the following parameters:
  # 1: terms - A list of keys to look up
  # 2: variables - An optional dictionary of variables
  # 3: onmissing - An optional string describing what to do if the key is missing
  #    The options are "skip" (skip the item), "warn" (issue a warning), and
  #    "error" (raise a AnsibleLookupError)
  # 4: plugin_type - An optional string indicating the type of plugin from which
  #    to lookup the setting
  # 5: plugin_name - An optional string indicating the name of the plugin from
  #    which to lookup the setting

  # Test Case 0 - Try to look up a missing setting, which will raise an error
  #               because the default value of onmissing is "error"
  onmissing = "error"

# Generated at 2022-06-25 10:25:31.233297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.run(terms='DEFAULT_ROLES_PATH')


# Generated at 2022-06-25 10:25:35.961426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {'plugin_name':'', 'plugin_type':'shell', 'on_missing':'skip',
            'terms':['remote_tmp'], 'variables':None}
    # TODO: need to test expected results and error conditions
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(**args)
    return result

# Generated at 2022-06-25 10:25:37.116623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    try:
        result = lookup.run(['UNKNOWN_KEY'])
    except MissingSetting as e:
        pass



# Generated at 2022-06-25 10:25:44.742726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization
    expected_results = []
    expected_results.append(C.DEFAULT_BECOME_USER)
    expected_results.append(C.DEFAULT_ROLES_PATH)
    expected_results.append(C.RETRY_FILES_SAVE_PATH)
    expected_results.append(C.DEFAULT_ROLES_PATH)
    expected_results.append([C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_SKIP])
    expected_results.append(C.DEFAULT_BECOME_USER)
    expected_results.append(C.DEFAULT_ROLES_PATH)
    expected_results.append(C.REMOTE_USER)
    expected_results.append(C.DEFAULT_REMOTE_TMP)
    look = LookupModule()


# Generated at 2022-06-25 10:25:51.542374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['DEFAULT_ROLES_PATH']
    test_variables = {'_ansible_sourced': False}
    test_kwargs = {'plugin_type': 'lookup', 'plugin_name': 'template'}
    tst = LookupModule()
    tst.set_options(var_options=test_variables, direct=test_kwargs)
    assert 'DEFAULT_ROLES_PATH' in [term for term in tst.run(test_terms, test_variables, **test_kwargs)]


# Generated at 2022-06-25 10:25:57.763346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    params = [
        {
            'terms': ['DEFAULT_BECOME_USER']
        }
    ]
    results = [dict(result=['root'])]
    for i, (param, result) in enumerate(zip(params, results), 1):
        try:
            actual = lookup_module.run(**param)
            assert actual == result
        except AssertionError:
            raise AssertionError('case {} failed: {}'.format(i, actual))

# Generated at 2022-06-25 10:26:01.813137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Set C.DEFAULT_ROLES_PATH to value
    C.DEFAULT_ROLES_PATH = ['/etc/ansible/roles']
    # Create variable variable
    variable = []
    # Set variable variable to value
    variable = ['/etc/ansible/roles']
    # Create variable terms
    terms = []
    # Set variable terms to value
    terms = ['DEFAULT_ROLES_PATH']

    # Calling method
    result = lookup_module.run(terms)
    assert result[0] == variable



# Generated at 2022-06-25 10:26:05.280949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # AnsibleLookupError will be raised
        LookupModule().run('DEFAULT_BECOME_USER')
    except AnsibleLookupError as e:
        assert 'DEFAULT_BECOME_USER' in to_native(e)

# Generated at 2022-06-25 10:26:15.607250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests the following line:
    # raise AnsibleOptionsError('Both plugin_type and plugin_name are required, cannot use one without the other')
    # plugin_type is None, plugin_name is None
    with pytest.raises(AnsibleOptionsError):
        lookup_plugin = LookupModule()
        lookup_plugin.run(terms=None, variables=None, plugin_type=None, plugin_name=None)
    # plugin_type is None, plugin_name is set
    with pytest.raises(AnsibleOptionsError):
        import ansible.plugins.loader as plugin_loader
        lookup_plugin = LookupModule()
        lookup_plugin.run(terms=None, variables=None, plugin_type=None, plugin_name=plugin_loader.NAME)
    # plugin_type is set, plugin_name is None

# Generated at 2022-06-25 10:26:45.683421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'DEFAULT_REMOTE_USER'
    lm = LookupModule()
    result = lm.run(terms)
    assert result[0] == 'ansible'


# Generated at 2022-06-25 10:26:54.223429
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:27:02.663881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup1 = LookupModule()
    lookup1._display.warning = lambda x: x
    try:
        lookup1.run(['fizz', 'buzz'], None, on_missing='warn', plugin_name='ssh', plugin_type='connection')
    except AnsibleLookupError as e:
        assert getattr(e, 'orig_exc', None) is not None

    try:
        lookup1.run(['fizz', 'buzz'], None, on_missing='warn', plugin_name='ssh')
    except AnsibleOptionsError as e:
        assert str(e) == 'Both plugin_type and plugin_name are required, cannot use one without the other'

# Generated at 2022-06-25 10:27:05.653386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo']
    variables = {}
    kwargs = {}
    ql = LookupModule()
    assert ql.run(terms, variables, **kwargs) == [C.foo]


# Generated at 2022-06-25 10:27:09.659904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = ['DEFAULT_BECOME_USER']
    expected_term = 'root'

    actual_term = lookup.run(terms)
    assert expected_term in actual_term



# Generated at 2022-06-25 10:27:12.599127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule(
          loader=None,
          variable_manager=None,
          loader_class=None
    )
    print(lm.run(
        terms=["DEFAULT_ROLES_PATH"]
    ))

# Generated at 2022-06-25 10:27:23.198397
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict

    import ansible.plugins.connection.network_cli as connection_network_cli

    class MockModule(object):
        # Mock module needed to create the plugin object
        def __init__(self, paramgram):
            self.params = paramgram

    ansible.plugins.connection.network_cli._create_class_instance = lambda x, y: MockModule(y)
    connection_plugin = connection_network_cli.ConnectionModule()
    connection_plugin.get_option = lambda x: None
    

# Generated at 2022-06-25 10:27:32.244351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options=dict(foo='bar'))
    l._display.warning = lambda x: x
    # On missing is default 'error', valid values passed
    terms = ['bar', 'foo']
    res = l.run(terms=terms, variables=dict(foo='bar'))
    assert res == ['bar', 'bar']
    # On missing is warn, valid values passed
    terms = ['bar', 'foo']
    try:
        res = l.run(terms=terms, variables=dict(foo='bar'), on_missing='warn')
    except AnsibleLookupError:
        pass
        # If this fails it means that mocking failed
    # On missing is error, valid values passed
    terms = ['bar', 'foo']

# Generated at 2022-06-25 10:27:40.504093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """unit testing method run of class LookupModule"""
    lookup = LookupModule()

    # test with an option error, on_missing value is not in ("error", "warn", "skip")
    # AnsibleOptionsError exception expected, on_missing must be a string and one of "error", "warn" or "skip", not {}'
    try:
        lookup.run(terms='UNKNOWN', variables='UNKNOWN', on_missing={}, plugin_type='UNKNOWN', plugin_name='UNKNOWN')
        assert False
    except AnsibleOptionsError:
        assert True
    except AnsibleLookupError:
        assert False

    # test with a config option error, plugin_name or plugin_type is missing
    # AnsibleOptionsError exception expected, Both plugin_type and plugin_name are required, cannot use one without the other'

# Generated at 2022-06-25 10:27:41.632769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert(lookup.run("default_remote_user") == ['root'])


# Generated at 2022-06-25 10:28:17.634127
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:28:28.216094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # case 0:
    # pylint: disable=protected-access
    assert module._get_global_config('DEFAULT_BECOME_USER') == 'root'
    # pylint: enable=protected-access

    # case 1:
    # pylint: disable=protected-access
    assert module._get_plugin_config('ssh', 'connection', 'remote_user', None) == None
    # pylint: enable=protected-access

    # case 2:
    # pylint: disable=protected-access
    assert module._get_plugin_config('sh', 'shell', 'remote_tmp', None) == '$HOME/.ansible/tmp'
    # pylint: enable=protected-access

    # case 3:
    # pylint: disable=protected-access
   

# Generated at 2022-06-25 10:28:34.797810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Call method run with a term that does not exist in DEFAULT_CONFIG
    result = lookup.run(['UNKNOWN'])
    assert result == ['UNKNOWN']

    # Call method run with a term that exists in DEFAULT_CONFIG
    result = lookup.run(['DEFAULT_BECOME_METHOD'])
    assert result == ['sudo']

    # Call method run with a term that exists in DEFAULT_CONFIG and additional
    # options
    result = lookup.run(['DEFAULT_RETRY_FILES_ENABLED'], on_missing='skip', plugin_name='sh', plugin_type='shell')
    assert result == [True]

    # Call method run with a term that doesn't exist in DEFAULT_CONFIG and
    # additional options, with on_missing set to 'warn'

# Generated at 2022-06-25 10:28:39.303427
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    parameters = {
        'on_missing': 'skip',
        'plugin_type': 'become',
        'plugin_name': 'sudo'
    }

    config = {
        'DEFAULT_BECOME_USER': 'root',
        'DEFAULT_ROLES_PATH': ['/etc/roles/']
    }

    class MockConfig(object):
        @classmethod
        def get_config_value(cls, term=None, plugin_type=None, plugin_name=None, variables=None):
            return config.get(term)
    C = MockConfig()

    expected = ['root', ['/etc/roles/']]

    lookup_module = LookupModule()
    result = lookup_module

# Generated at 2022-06-25 10:28:43.201808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    values = ['test_key1', 'test_key2']
    yaml_file = open('test_case/test.yaml')
    obj = yaml.load(yaml_file)
    result = LookupModule().run(terms=values)
    
    assert result == obj
# Working on this test case

# Generated at 2022-06-25 10:28:48.426205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert C.RETRY_FILES_ENABLED == lookup.run(["RETRY_FILES_ENABLED"], {})
    assert C.RETRY_FILES_ENABLED == lookup.run(["RETRY_FILES_ENABLED"], on_missing='skip')
    assert C.RETRY_FILES_ENABLED == lookup.run(["RETRY_FILES_ENABLED"], on_missing='warn')
    assert 'Missing setting: UNKNOWN was not defined in configuration file' in lookup.run(["UNKNOWN"], on_missing='error')

# Generated at 2022-06-25 10:28:50.472040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    o = LookupModule()
    assert o.run([terms]) != AnsibleLookupError, "Failed test_LookupModule_run"

# Generated at 2022-06-25 10:29:00.048737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # A dictionary of arguments passed to this module
    # The key is the name of the parameter and the value is the value of the parameter
    module_args = dict(
        _terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'],
        on_missing='error',
        plugin_name=None,
        plugin_type=None
    )
    # A dictionary of the return values
    result = dict(
        _raw=['root', '/etc/ansible/roles:/usr/share/ansible/roles']
    )
    # A dictionary of boolean return values that the mock should return
    module_returns = {}
    fake_ansible = {}

    # A dictionary of mocked objects
    mock_objects = {}

    # Import the module

# Generated at 2022-06-25 10:29:07.784720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = ['term']
    terms = ['terms']
    variables = {}
    kwargs = {}

    lookup = LookupModule()
    lookup.set_loader(NameError('AnsibleError'))

    lookup.set_loader(AnsibleLookupError('AnsibleLookupError'))
    lookup.set_loader(AnsibleOptionsError('AnsibleOptionsError'))
    lookup.set_loader(MissingSetting('MissingSetting'))
    lookup.set_loader(Sentinel('Sentinel'))

    lookup.set_loader(C.COLOR_OK)
    lookup.set_loader(C.COLOR_SKIP)
    lookup.set_loader(C.COLOR_CHANGED)


# Generated at 2022-06-25 10:29:10.589023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    try:
        lookup.run(['test_case_0'])
    except AnsibleError as e:
        assert e.orig_exc
    else:
        assert False

# Generated at 2022-06-25 10:30:20.133071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import __builtin__ as builtins

    module_name = 'ansible.plugins.lookup.config'
    LookupModule_class_name = 'LookupModule'

    dict_value = {
        '_terms': ['_terms'],
        'on_missing': 'on_missing',
        '_loader': '_loader',
        '_templar': '_templar',
        '_display': '_display'
    }

    mock_AnsibleLookupError = mock.MagicMock()
    mock_AnsibleOptionsError = mock.MagicMock()
    mock_Sentinel = mock.MagicMock()

    mock_os = mock.MagicMock()

    mock_open_name = '%s.open' % module_name

# Generated at 2022-06-25 10:30:24.978118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test method with error missing
    lookup = LookupModule()
    lookup.set_options(on_missing='error')
    try:
        lookup.run('UNKNOWN')
    except MissingSetting as e:
        error = str(e)
        assert error == 'UNKNOWN was not defined'
    else:
        raise AssertionError('MissingSetting was not raised')

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:30:33.739732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import tempfile

    (dummy_fd, dummy_file) = tempfile.mkstemp()
    dummy_fd.close()


# Generated at 2022-06-25 10:30:34.766384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = ['FAKE_REMOTE_USER']
    result = lookup.run(term)
    assert not result

# Generated at 2022-06-25 10:30:43.669117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['DATA_DIR'], kwargs={'plugin_name': 'posix', 'plugin_type': ''}) == Sentinels.DATA_DIR
    assert lookup.run(terms=['ANSIBLE_CONFIG'], kwargs={'plugin_name': 'file', 'plugin_type': 'cache'}) is Sentinels.ANSIBLE_CONFIG
    assert lookup.run(terms=['C.DEFAULT_ROLES_PATH'], kwargs={'plugin_name': 'shell', 'plugin_type': 'shell'}) is Sentinels.DEFAULT_ROLES_PATH

# Generated at 2022-06-25 10:30:45.325579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(terms=["foo"], variables=None, **{}) == []



# Generated at 2022-06-25 10:30:47.315784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    terms = ["DEFAULT_BECOME_USER=root"]
    lookup_module.run(terms)

# Generated at 2022-06-25 10:30:51.455928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH'
    ]
    var_options = {}
    direct = {'on_missing': 'error'}
    lm = LookupModule()
    ret = lm.run(terms=args, variables=var_options,**direct)
    print(ret)
    return ret

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:30:57.999187
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error',
                                      'plugin_type': 'shell',
                                      'plugin_name': 'sh'})
    #
    # On_missing option has options ['error', 'warn', 'skip']
    #
    # Invalid option
    #
    try:
        lookup_module.set_options(direct={'on_missing': 'option'})
    except AnsibleOptionsError as e:
        assert 'on_missing" must be a string and one of "error", "warn" or "skip", not option' == to_native(e)
    #
    # Invalid type of on_missing option
    #

# Generated at 2022-06-25 10:31:02.115789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    # Placeholder for lookup_plugins
    lookup_plugins = None
    terms_in = ['DEFAULT_BECOME_METHOD']
    variables_in = {'ansible_play_hosts': ['localhost']}
    kwargs_in = {}
    ret = lu.run(terms_in, variables_in, **kwargs_in)
    print("result in test_LookupModule_run: {}".format(ret))