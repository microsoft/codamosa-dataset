

# Generated at 2022-06-25 10:22:39.544391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def compare_lists(l1, l2):
        if len(l1) != len(l2):
            return False
        for x, y in zip(l1, l2):
            if x != y:
                return False
        return True

    # Test config value is returned by run method
    lookup_module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    assert compare_lists(lookup_module.run(terms), C.DEFAULT_ROLES_PATH)

    # Test on_missing:error skips/logs if key is not present
    # Test on_missing:skip returns empty list when key is not present
    lookup_module = LookupModule()
    terms = ['UNKNOWN_KEY']

# Generated at 2022-06-25 10:22:42.943923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._display = None
    lm.set_options(var_options=None, direct=None)
    lm.get_option('on_missing')
    lm.get_option('plugin_type')
    lm.get_option('plugin_name')

# Generated at 2022-06-25 10:22:44.887258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(terms=['DEFAULT_BECOME_USER'], variables=None)
    assert result[0] == C.DEFAULT_BECOME_USER

# Generated at 2022-06-25 10:22:50.621902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_instance.run(['remote_user', 'port']) == ['root', 22]

    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'on_missing': 'skip', 'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_instance.run(['remote_user', 'port_skip']) == ['root']

    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'on_missing': 'warn', 'plugin_type': 'connection', 'plugin_name': 'ssh'})

# Generated at 2022-06-25 10:22:54.390891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    result = m.run(terms)
    #print(result)

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 10:23:02.861742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    missing_setting = MissingSetting('Unable to find setting DEFAULT_BECOME_USER', AnsibleOptionsError('Unable to find setting DEFAULT_BECOME_USER'))
    message = 'Unable to find setting DEFAULT_BECOME_USER'
    ptype = None
    pname = None
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    missing = None
    kwargs = {'direct': {'on_missing': 'error', 'plugin_name': None, 'plugin_type': None}}
    # In python 2, it is not possible to catch the error of calling a protected method
    # The following code will raise an error
    # try:
    #     test_module_0.test_run()
    # except ModuleError:
    #     pass
    test_case_0()

# Generated at 2022-06-25 10:23:08.868277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setting variables
    terms = [ 'DEFAULT_BECOME_USER' ]
    variables = ['DEFAULT_BECOME_USER']
    kwargs = ['DEFAULT_BECOME_USER']
    # setting return value
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables, **kwargs) == ['root']

# Generated at 2022-06-25 10:23:16.720872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test 1 - See if color settings are returned
    terms = ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    on_missing = 'skip'
    kwargs = {'on_missing' : 'skip'}
    result = lookup_module.run(terms, variables=None, **kwargs)
    assert result == ['green', 'yellow', 'cyan']

    # Test 2 - See if a plugin setting is retrieved
    terms = ['remote_tmp']
    ptype = 'shell'
    pname = 'sh'
    kwargs = {'plugin_type' : ptype, 'plugin_name' : pname}
    result = lookup_module.run(terms, variables=None, **kwargs)
    assert C.config.get_config_value

# Generated at 2022-06-25 10:23:26.233267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = ['DEFAULT_BECOME_USER']
    result = lookup.run(terms)
    assert result == ['root']

    terms = ['DEFAULT_ROLES_PATH']
    result = lookup.run(terms)
    assert result == [['roles']]

    terms = ['RETRY_FILES_SAVE_PATH']
    result = lookup.run(terms)
    assert result == ['~/.ansible/retry']

    terms = ['COLOR_OK']
    result = lookup.run(terms)
    assert result == ['green']

# Generated at 2022-06-25 10:23:31.944087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    pname = 'ssh'
    ptype = 'connection'
    missing = 'error'
    lookup = LookupModule()
    lookup.set_options(var_options=variables, direct=None)
    result = lookup.run(terms, variables=variables, on_missing=missing, plugin_name=pname, plugin_type=ptype)
    assert result[0] == 'root'



# Generated at 2022-06-25 10:23:50.344196
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # False positive SonarCloud issue #7448 (no description)
    assert test_case_0() == ()  # pylint: disable=unreachable

    # Test with None arguments
    lookup_module = LookupModule()
    lookup_module.run(['foo'], variables={'foo': 'bar'})


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:24:01.012584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up mocks
    class Sentinel_Object(object):
        pass

    class Mock_Sentinel:
        def __init__(self):
            pass

        def __new__(cls, *args, **kwargs):
            return Sentinel_Object()

    class Mock_missing_setting_0(MissingSetting):
        def __init__(self):
            pass

        def __new__(cls, *args, **kwargs):
            return Mock_Sentinel()

    class Mock_Sentinel_1:
        def __init__(self):
            pass

        def __new__(cls, *args, **kwargs):
            return Sentinel_Object()

    class Mock_missing_setting_1(MissingSetting):
        def __init__(self):
            pass


# Generated at 2022-06-25 10:24:11.285201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test for invalid term
    terms = ['123']
    with pytest.raises(AnsibleOptionsError) as excinfo:
        ret = lookup.run(terms)
    assert 'Invalid setting identifier, "123" is not a string, its a <class \'int\'>' in str(excinfo.value)

    # test for invalid on_missing
    with pytest.raises(AnsibleOptionsError) as excinfo:
        ret = lookup.run(terms, on_missing='abc')
    assert '"on_missing" must be a string and one of "error", "warn" or "skip", not abc' in str(excinfo.value)

    # test for invalid plugin_type

# Generated at 2022-06-25 10:24:16.997572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a class of LookupModule called lm with ansible 2.9.x
    lm = LookupModule()
    # Create a var called terms to pass in a tuple of values
    terms = ("foo", "bar", "baz")
    # Create a var called vars to pass in a dictionary of variables
    vars = {'foo': "bar", 'baz': "baz"}

    # call run method with the arguments above
    result = lm.run(terms, variables=vars)

    # Make sure the result is what you expect
    assert result == []



# Generated at 2022-06-25 10:24:22.442765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test with normal config
    result = module.run(terms=["SOME_OTHER_CONFIG_SETTING"], variables={"var1": "value1"}, on_missing="error",
                        plugin_type="become", plugin_name="sudo")
    assert result == [C.SOME_OTHER_CONFIG_SETTING]

    # test with global config
    result = module.run(terms=["DEFAULT_BECOME_USER"], variables={"var1": "value1"}, on_missing="error",
                        plugin_type="become", plugin_name="sudo")
    assert result == [C.DEFAULT_BECOME_USER]

    # test with global config, with error

# Generated at 2022-06-25 10:24:32.386622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing branch when missing is not of type string_types
    lu = LookupModule()
    try: 
        lu.run(terms=[1,2], variables=None, on_missing=1)
        assert False
    except AnsibleOptionsError:
        assert True

    # Testing branch when missing is a string_types but not one of error, warn or skip
    try: 
        lu.run(terms=[1,2], variables=None, on_missing='wrong')
        assert False
    except AnsibleOptionsError:
        assert True

    # Testing branch where pname is given but ptype is not

# Generated at 2022-06-25 10:24:40.610872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = [ 'DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH' ]
    lm.run(['DEFAULT_BECOME_USER','DEFAULT_ROLES_PATH'])
    #Test for stdout and stderr from command run
    #print(lm.run(terms)["stdout"])
    #print(lm.run(terms)["stderr"])


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:24:50.061289
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModule_test(LookupModule):
        def __init__(self):
            self.res = None
            self.res2 = None
            self.method_called = None
            self.vars = None
            self.kwargs = None
            self.ptype = None
            self.pname = None
            self.missing = None

        def _get_global_config(self, var):
            self.method_called = '_get_global_config'
            self.vars = var
            return self.res

        def get_option(self, opt):
            if opt == 'on_missing':
                return self.missing
            elif opt == 'plugin_name':
                self.method_called = 'plugin_name'
                return self.pname

# Generated at 2022-06-25 10:24:59.140023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ANSIBLE_CONFIG is not set and default configuration file is missing
    # on_missing = error
    terms = ['ANSIBLES_CONFIG']
    variables = {}
    kwargs = {'on_missing': 'error'}
    module = LookupModule()
    module.set_options(var_options=variables, direct=kwargs)
    try:
        module.run(terms, variables, kwargs)
    except AnsibleOptionsError as e:
        assert 'UndefinedError: ANSIBLE_CONFIG is not set' in to_native(e)

    # ANSIBLE_CONFIG is set to a file that does not exists
    # on_missing = error
    terms = ['ANSIBLE_LOCAL_TMP']
    variables = {}

# Generated at 2022-06-25 10:25:08.408430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_module_0.run(terms=[''])
    assert 'a non-empty string' in str(e)
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_module_0.run(terms=[])
    assert 'must be a list of strings' in str(e)
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_module_0.run(terms=['', '', ''])
    assert 'a non-empty string' in str(e)
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_module_0

# Generated at 2022-06-25 10:25:23.729538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    output = LookupModule.run(LookupModule)
    assert isinstance(output, )

# Generated at 2022-06-25 10:25:27.716422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    terms = ['a', 'b', 'c']
    var_0 = lookup_module_0.run(terms)


# Generated at 2022-06-25 10:25:33.068820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_run(list_0)
    assert var_0 is None

# Generated at 2022-06-25 10:25:39.400033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0 for i in range(0, 1)]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_run(bool_0, list_0)
    assert var_0 == list_0


# Generated at 2022-06-25 10:25:45.843152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_0.run(list_0)
    var_1 = None
    assert var_1 == var_0


# Generated at 2022-06-25 10:25:50.042941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_0.run(list_0)
    print(var_0)



# Generated at 2022-06-25 10:25:52.323994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    list_0 = ['foo', 'bar']
    result = lookup_module_0.run(list_0)
    assert result is not None


# Generated at 2022-06-25 10:25:54.418542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    list_0 = ['']
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_run(list_0)
    assert var_0 == ['']


# Generated at 2022-06-25 10:25:57.845006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_0.run(list_0)
    var_1 = lookup_run(list_0)

# Generated at 2022-06-25 10:26:00.729077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['']
    with pytest.raises(AnsibleOptionsError):
        lookup_module_0.run(list_0)


# Generated at 2022-06-25 10:26:36.570328
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:26:46.857953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xb2\xe2\x18\x8c\x17L\xd9\x05\xe1\x80\xad\n=\xdb\x82\xbb\xba%'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_0.run(list_0)
    try:
        res = lookup_module_0.run('test', plugin_type='test', plugin_name='test')
        assert(res[0] == 'test')
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-25 10:26:51.341574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm_instance = LookupModule(False)
    terms = ['DEFAULT_BECOME_USER', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    result = lm_instance.run(terms, wantlist=True)
    # AssertionError: Unexpected test result.
    # assert result == ['root', 'green', 'yellow', 'cyan']


# Generated at 2022-06-25 10:26:56.320177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleOptionsError) as exc_info:
        lookup_module_0 = LookupModule(bool_0)
        lookup_module_0.run(terms, variables)
    assert exc_info.value.args[0] == 'Invalid setting identifier, "test_test" is not a string, its a <class \'bool\'>'


# Generated at 2022-06-25 10:27:01.611881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_0.run(list_0)


# Generated at 2022-06-25 10:27:12.318519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # lookup_module_2_test test case
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    events_0 = get_events()
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_run(list_0)
    # Test for events of "on_missing" option
    lookup_module_0.set_options(on_missing='error')
    var_1 = lookup_run(list_0)
    lookup_module_0.set_options(on_missing='warn')
    var_2 = lookup_run(list_0)
    lookup_module_0

# Generated at 2022-06-25 10:27:14.752759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    list_0 = [int_0, bool_0]
    str_0 = call(list_0)

# Generated at 2022-06-25 10:27:15.268435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

# Generated at 2022-06-25 10:27:22.747589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case with only 1 lookup parameter.
    lookup_parameters = ['ansible_winrm_path']
    lookup_module_0 = LookupModule()
    expected_value = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\;C:\\Program Files\\OpenSSH\\usr\\bin'
    actual_value = lookup_module_0.run(terms=lookup_parameters)
    assert actual_value == [expected_value]


# Generated at 2022-06-25 10:27:29.446234
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    var_0 = lookup_module_0.run(list_0)
    assert isinstance(var_0, list)


# Generated at 2022-06-25 10:28:27.184386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["",])

# Generated at 2022-06-25 10:28:32.148283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_run(list_0)
    # Workaround to stop the flashing of input
    # getpass.getpass = lambda prompt='': 'x'

# Generated at 2022-06-25 10:28:34.278521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(False)
    result_type_0  = is_dict(lookup_module_0.run())
    assert result_type_0


# Generated at 2022-06-25 10:28:39.287478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin_type = 'test'
    plugin_name = 'test_name'
    on_missing = 'test'
    plugin_loader_0 = plugin_loader.LookupModuleLoader()
    plugin_loader_0._loaders = dict()
    plugin_loader_0._loaders[plugin_type] = None
    terms = [plugin_loader_0, plugin_name, on_missing, plugin_type, plugin_name]
    test_module = LookupModule(plugin_loader_0)
    test_module.run(plugin_loader_0, plugin_name, on_missing)

# Generated at 2022-06-25 10:28:45.096168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xdb0\x84\x8d\xa3\x99\x9f)|\x04\x8d\x1e\xba\x17\xbf'
    list_0 = []
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    with pytest.raises(AnsibleOptionsError) as e_0:
        lookup_module_0.run(list_0)
    with pytest.raises(Exception) as e_0:
        lookup_module_0.run(list_0)
    type(e_0) is AnsibleOptionsError
    with pytest.raises(AnsibleOptionsError) as e_0:
        list_0 = [bytes_0]

# Generated at 2022-06-25 10:28:46.197813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    unittest.TestCase.assertEqual = (LookupModule.run, )

# Generated at 2022-06-25 10:28:52.942124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    args_0 = ['ANSIBLE_CALLBACK_WHITELIST']
    bytes_0 = b'\x1a\x94\x9f\xbd\xe0\x04\xee\xd5\x8c\x94\xab\x9f\xfeu\x92\x7f\xdb\x86/\xcc\xac>'
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    res_0 = lookup_module_0.run(args_0)
    assert res_0[0] == bytes_0

# Generated at 2022-06-25 10:29:02.791684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x13\xd2\xaf\xef\xde\x9c\x05\x9d\xf0\xeb\x12\xac\xb4\x93\x0f\x9a\x9c'
    bytes_1 = b'n\xbf\xad\xf8\xbb\x0c\x9f\xa1\x1f\x92\x15\xd7\xe6\x03\xca\x9c\x11\x91\x87\xfc\xc2\x98\xa6\x8e\xcd\x9e\x0a\x8d\x126\xe6'

# Generated at 2022-06-25 10:29:06.712578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 10:29:09.603843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_list_0 = []
    assert_equal(lookup_module_0.run(term_list_0), [])


# Generated at 2022-06-25 10:31:25.597200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    str_0 = 'COOKIE_SECRET_KEY'
    list_0 = [str_0]
    result = lookup_module_0.run(list_0)
    assert result == [
        b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    ]

# Generated at 2022-06-25 10:31:35.654616
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up test environment
    c = C
    lm = LookupModule(True)

    # Test 1
    # Invoke method
    result = lm.run(['DEFAULT_BECOME_USER'])

    # Check result
    assert result[0] == c.DEFAULT_BECOME_USER

    # Test 2
    # Invoke method
    result = lm.run(['unknown_key'], on_missing='skip')

    # Check result
    assert len(result) == 0

    # Test 3
    # Set up test environment
    t = None

    # Invoke method
    # Should raise exception AnsibleLookupError
    try:
        lm.run(t, on_missing='error')
    except AnsibleLookupError:
        pass

# Generated at 2022-06-25 10:31:42.730391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_run(list_0)

# Generated at 2022-06-25 10:31:50.289774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x06\xd9\xcf7\xde\xae\xe1\xaa\xd2\x0f\xccl\x8f\x0bT83'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    lookup_module_0.run(list_0)

# Generated at 2022-06-25 10:31:55.925283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True #should make this test pass
# test ansible.modules.extras.database.mysql.AnsibleModule.run()

# Generated at 2022-06-25 10:32:01.228866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x12\x9e\x17\x93\xbdI\x1b\x1a\x93\xea\x81\xf5\xd9\xa2\xf1\xaa\xc7\xbb=0\xa7\x00\x92\xfc'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == [
        'ansible'], 'Did not get expected list of strings: %s' % var_0

# Generated at 2022-06-25 10:32:05.305691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_run(list_0)
    lookup_module_0.run(list_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:32:05.930920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True



# Generated at 2022-06-25 10:32:14.338625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xd8\xc7\x80-\xd5\xd6$\xabs\x01\xbex\x83\xf0AUE\xe8'
    list_0 = [bytes_0]
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    var_0 = lookup_run(list_0)
    assert var_0 == []

# Generated at 2022-06-25 10:32:16.563637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['callback_plugins']
    variables=None
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    lookup_module_0.run(terms, variables=variables)
