

# Generated at 2022-06-25 10:22:33.709280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config_name = 'DEFAULT_BECOME_USER'
    kwargs = {}
    lookup_module = LookupModule()
    result = lookup_module.run([config_name],**kwargs)
    assert result == [u'root']

# Generated at 2022-06-25 10:22:36.344896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    ret_0 = lookup_module_0.run(terms_0)
    assert ret_0 == []

# Generated at 2022-06-25 10:22:40.397600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER']
    variables_0 = None
    test_result = lookup_module_0.run(terms_0, variables_0)
    return True


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:22:42.788892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=['DEFAULT_BECOME_USER'], variables=dict())
    assert ret == ['root']


# Generated at 2022-06-25 10:22:46.651150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleOptionsError) as AE:
        LookupModule().run(terms=['DEFAULT_RETRY_FILES_ENABLED'], on_missing='unknown')
    assert "\"on_missing\" must be a string and one of \"error\", \"warn\" or \"skip\", not unknown" in str(AE.value)


# Generated at 2022-06-25 10:22:49.782663
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = "DEFAULT_BECOME_METHOD"
    variables = None
    kwargs = {}
    lookup_obj = LookupModule()
    lookup_obj.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:22:51.792577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=['DEFAULT_BECOME_USER'],variables=None,**{})

# Generated at 2022-06-25 10:22:57.370992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        'DEFAULT_BECOME_USER'
        ]
    variables = {
        'DEFAULT_BECOME_USER': 'string'
        }
    result = lookup_module.run(terms, variables)
    assert isinstance(result, list)
    assert result[0] == 'string'


# Generated at 2022-06-25 10:23:04.400849
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with plugin_name and plugin_type
    lookup_module = LookupModule()
    result = lookup_module.run(["remote_tmp", "remote_tmpdir"], plugin_name="sh", plugin_type="shell")
    assert result[0] == C.DEFAULT_REMOTE_TMP
    assert result[1] == C.DEFAULT_REMOTE_TEMPDIR

    # test with missing plugin name
    lookup_module = LookupModule()
    result = lookup_module.run(["remote_tmp"], plugin_type="shell")
    assert result is None

    # test with missing plugin type
    lookup_module = LookupModule()
    result = lookup_module.run(["remote_tmp"], plugin_name="shell")
    assert result is None

    # test with missing plugin name and missing plugin type
    lookup_module

# Generated at 2022-06-25 10:23:08.238670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    # this is needed since we are not doing the full command line setup
    assert result == ['root']

# Generated at 2022-06-25 10:23:22.404581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement this test
    raise Exception('Test Not Implemented')

# Generated at 2022-06-25 10:23:28.056975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "CONFIG"
    variables = "CONFIG"
    kwargs = {'on_missing': 'CONFIG', 'plugin_type': 'CONFIG', 'plugin_name': 'CONFIG'}
    assert lookup_module_0.run(terms=terms, variables=variables, **kwargs) == []

# Generated at 2022-06-25 10:23:32.656866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    kwargs = dict(plugin_type='become',plugin_name='sudo')
    lookup_module.run(terms,variables,**kwargs)
    # This test does not assert anything because it has no return value
    # But if it correctly runs without error, then it passes
    pass

# Generated at 2022-06-25 10:23:34.902704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options='test1',direct='test2')
    lookup_module.run('test')

# Generated at 2022-06-25 10:23:38.489030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    terms = ['inventory', 'hosts', 'hosts_file']
    variables = 'hosts_file=hosts'
    kwargs = 'ansible_config=ansible.cfg'
    lookup_module_run.run(terms, variables, kwargs)

# Generated at 2022-06-25 10:23:43.455433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._display.verbosity = 1
    lookup_module_0._display.color = True
    lookup_module_0._display.warning('Skipping, did not find setting %s' % 'dummy')
    lookup_module_0.run((('dummy', 'skip'),), {}, on_missing="warn", plugin_name="dummy", plugin_type="dummy")

# Generated at 2022-06-25 10:23:50.564591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    mock_terms_0 = "DEFAULT_BECOME_USER"
    mock_variables_0 = "None"

# Generated at 2022-06-25 10:24:01.152203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test using a class
    lookup_module_0.set_options({'var_options': {}, 'direct': {}})

    # Test using a dictionary
    lookup_module_0.set_options(**{'var_options': {}, 'direct': {}})
    # Test using args
    lookup_module_0.set_options(var_options={}, direct={})

    lookup_module_0.set_options(var_options={}, direct={'plugin_type': 'var_options', 'plugin_name': 'direct', 'on_missing': 'var_options'})
    # Test using kwargs

# Generated at 2022-06-25 10:24:11.443635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct=None)

    # test missing param
    lookup_module_1.run(terms=None, variables=None, **{})
    lookup_module_1.run(terms=None, variables=None, **{'on_missing':'error'})
    lookup_module_1.run(terms=None, variables=None, **{'on_missing':'warn'})
    lookup_module_1.run(terms=None, variables=None, **{'on_missing':'skip'})
    
    # test default missing value
    lookup_module_1.run(terms=None, variables=None, **{'on_missing':'error'})

# Generated at 2022-06-25 10:24:16.305064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    argument_0 = ['DEFAULT_ROLES_PATH']
    argument_1 = None
    argument_2 = 'skip'
    lookup_module_0.set_options(var_options=argument_1, direct=argument_2)
    result_0 = lookup_module_0.run(argument_0)
    assert result_0[0] == C.DEFAULT_ROLES_PATH
    
test_LookupModule_run()

# Generated at 2022-06-25 10:24:48.403294
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader

    try:
        lookup_module_0 = LookupModule(loader=None, basedir=None)
        lookup_module_0.run(["DEFAULT_ROLES_PATH"], {"DEFAULT_ROLES_PATH": ["/usr/share/ansible/roles"]})
        lookup_module_0.run(["remote_user"], {"remote_user": ["claro"]})
        lookup_module_0.run(["COLOR_HIGHLIGHT"])
    except Exception as e:
        raise


# Generated at 2022-06-25 10:24:51.452092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Input parameters
    terms = []
    variables = None
    kwargs = dict()

    # Expected result
    expected_result = []

    # Actual result
    result = lookup_module.run(terms, variables, **kwargs)

    assert expected_result == result

# Generated at 2022-06-25 10:24:57.341336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=["ANSIBLE_CALLBACK_WHITELIST"], variables={"ANSIBLE_CALLBACK_WHITELIST": "ansible.callback.debug"})
    assert lookup_module_1.run(terms=["ANSIBLE_CALLBACK_WHITELIST"], variables={"ANSIBLE_CALLBACK_WHITELIST": "ansible.callback.debug"}) == ["ansible.callback.debug"]

# Generated at 2022-06-25 10:25:01.668824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "PLAYBOOK_DIR"
    variables_0 = None
    kwargs_0 = {}
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result[0] == result[0]

# Generated at 2022-06-25 10:25:10.457783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    options = dict()
    options['remote_user'] = 'ansible-test-user'
    options['connection'] = 'local'
    options['_ansible_check_mode'] = False
    options['_ansible_diff'] = True
    options['_ansible_debug'] = False
    options['_ansible_verbosity'] = 0
    options['port'] = '22'
    options['plugin_name'] = 'ssh'
    options['plugin_type'] = 'connection'
    options['_ansible_module_name'] = 'ansible.module_utils.basic.AnsibleModule'

# Generated at 2022-06-25 10:25:12.676727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    lookup_module = LookupModule()
    lookup_module._load_name = 'test-load-name'
    lookup_module.set_options()
    lookup_module.run(['DEFAULT_BECOME_USER'], {'DEFAULT_BECOME_USER' : 'test'})

# Generated at 2022-06-25 10:25:17.123563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'on_missing': 'error'})
    lookup_module_0.run([u'CACHED_CONNECTION'], {})
    lookup_module_0.run([u'DEFAULT_ROLES_PATH'], {})
    lookup_module_0.run([u'DEFAULT_BECOME_USER', u'UNKNOWN'], {})

# Generated at 2022-06-25 10:25:22.142033
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    global lookup_module_0
    lookup_module_0 = LookupModule()
    # global terms
    terms = [ 'foo', 'bar' ]
    # global variables
    variables = {'foo': 'bar'}
    # global kwargs
    kwargs = {'var_options': variables, 'direct': 'foo'}
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:25:31.185334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    kwargs_0 = {}
    result = lookup_module_0.run(terms_0, **kwargs_0)
    assert result == ['root', ['/etc/ansible/roles']]

    lookup_module_1 = LookupModule()
    terms_1 = ['DEFAULT_BECOME_USER']
    kwargs_1 = {'variables': 'variables_0'}
    result = lookup_module_1.run(terms_1, **kwargs_1)
    assert result == ['root']

# Generated at 2022-06-25 10:25:40.368863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    #testing with valid input
    assert lookup_module_1.run(["DEFAULT_ROLES_PATH"]) == [u'/etc/ansible/roles']
    #testing with invalid input
    assert lookup_module_1.run(["DEFAULT_ROLES_PATH","xyz"]) == [u'/etc/ansible/roles']
    #testing with missing input
    assert lookup_module_1.run(["DEFAULT_ROLES_PATH","xyz"],{'on_missing':'warn'}) == [u'/etc/ansible/roles']
    #testing for KeyError
    assert lookup_module_1.run(["xyz"]) == [u'/etc/ansible/roles']

# Generated at 2022-06-25 10:26:33.616586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for method run of class LookupModule
    """
    lookup_module_0 = LookupModule()  # instantiate class
    lookup_module_0.run(terms=['asdf'], variables='variables', on_missing='error', plugin_name='plugin_name', plugin_type='plugin_type')

# Generated at 2022-06-25 10:26:44.266119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TEST CASE 1
    cwd_val = os.getcwd()
    os.chdir(os.path.expanduser('~'))
    lookup_module_0 = LookupModule()
    # TEST CASE 2
    lookup_module_1 = LookupModule()
    terms_val = ["a", "b", "c"]
    variables_val = {}
    # TEST CASE 3
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:26:52.516135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    try:
        lookup_module_0.run(terms=[], variables=None, **{})
        lookup_module_1.run(terms=["ansible_lookup_plugin_min_file_size"], variables=None, **{})
        lookup_module_2.run(terms=["unittest_plugin_name"], variables=None, **{})
    except:
        pass

if __name__ == "__main__":
    import __main__
    print("in main")
    print(__main__.__file__)
    print(__file__)
    # test_case_0()
    # test_LookupModule_run()

# Generated at 2022-06-25 10:27:02.796478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['TERM']
    variables_0 = {}
    result = lookup_module_0.run(terms_0, variables=variables_0)
    assert result == 'TERM'

    # test legacy support
    lookup_module_1 = LookupModule()
    terms_1 = ['ANSI_COLOR']
    variables_1 = {}
    result = lookup_module_1.run(terms_1, variables=variables_1)
    assert result == 'ansi_color'

    lookup_module_2 = LookupModule()
    terms_2 = ['PLAYBOOK_VARS']
    variables_2 = {}
    result = lookup_module_2.run(terms_2, variables=variables_2)
    assert result == 'PLAYBOOK_VARS'

# Generated at 2022-06-25 10:27:05.789318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms='default_become_user') == ['root']


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:27:15.310708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_module_0 = LookupModule()
        test_terms_0 = [u'HOST_KEY_CHECKING', u'DEFAULT_ROLES_PATH']
        try:
            test_result_0 = lookup_module_0.run(test_terms_0)
            assert False
        except AssertionError:
            pass
        else:
            assert True


        # lookup_module_0.run(test_terms_0)
        # lookup_module_0.run(test_terms_1)
        # lookup_module_0.run(test_terms_2)
        # lookup_module_0.run(test_terms_3)
        # lookup_module_0.run(test_terms_4)
        # lookup_module_0.run(test_terms_5)
        # lookup_module

# Generated at 2022-06-25 10:27:19.972174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arguments = [None, None, {'plugin_type': 'connection', 'plugin_name': 'local'}]
    with pytest.raises(AnsibleOptionsError):
        lookup_module_0 = LookupModule()
        lookup_module_0.run(*arguments)

test_LookupModule_run()

# Generated at 2022-06-25 10:27:28.509815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    kwargs = {
        'plugin_type': 'become',
        'plugin_name': 'sudo'
    }
    result = lookup_module.run(terms, variables=variables, **kwargs)

    ansible_config = C.config.get_config_value('DEFAULT_BECOME_USER', variables=variables, plugin_type='become', plugin_name='sudo')
    assert result == [ansible_config]


# Generated at 2022-06-25 10:27:29.676174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(lookup_module_0.run() == [])

# Generated at 2022-06-25 10:27:35.730882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_native
    from ansible.modules.system.setup import _variable_maker
    from ansible.variables.manager import VariableManager
    _variable_manager = VariableManager()
    _variables = _variable_manager.get_vars(play=dict(vars=_variable_maker()))
    # When there is no pname, terms=['DEFAULT_BECOME_USER'], variables=_variables
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=['DEFAULT_BECOME_USER'], variables=_variables)
    assert result[0] == 'root'
    # When there is no pname, terms=['DEFAULT_ROLES_PATH'],

# Generated at 2022-06-25 10:29:27.000502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run with required args
    lookup_module_1 = LookupModule()
    try:
        print(lookup_module_1._run__options['_terms'])
    except Exception as exception:  # noqa
        print('An error occurred: {0}'.format(exception))


# Generated at 2022-06-25 10:29:34.037508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Configure the module to only care about the key DEFAULT_ROLES_PATH in the configuration
    terms = ['DEFAULT_ROLES_PATH']
    variables = None
    kwargs = {'on_missing': 'error', 'plugin_type': None, 'plugin_name': None}
    lookup_module_0.set_options(var_options=variables, direct=kwargs)
    # Run the lookup module and get the result
    result = lookup_module_0.run(terms, variables)
    # Check the result
    assert result[0] == '/home/runner-work/vars/workspace/roles:/etc/ansible/roles'

if __name__ == '__main__':
    print("Running unit test(s)")
    test_

# Generated at 2022-06-25 10:29:40.613660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LOAD_TERMS_0 = ["DEFAULT_BECOME_USER"]

    LOAD_VARS_0 = {}

    LOAD_KWARGS_0 = {}

    with pytest.raises(AnsibleLookupError) as exec_info:
        lookup_module_0.run(LOAD_TERMS_0, LOAD_VARS_0, **LOAD_KWARGS_0)
    assert exec_info.value.args[0] == 'Ansible runtime is not present'



# Generated at 2022-06-25 10:29:43.769730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test on missing value in config
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(direct={'plugin_type': 'fake_plugin_type',
                                        'plugin_name': 'fake_plugin_name'})
    try:
        lookup_module_1.run(['fake_term'])
    except AnsibleLookupError as e:
        assert str(e) == 'Invalid setting "%s" attempted' % 'fake_term'
    else:
        raise AssertionError('Expected exception')



# Generated at 2022-06-25 10:29:45.589477
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = [u'DEFAULT_TIMEOUT']
    assert lookup_module_0.run(terms=terms_0) == [10]


# Generated at 2022-06-25 10:29:48.194206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'DEFAULT_TASK_TIMEOUT'
    variables_0 = None
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_0 == [(300,)]

# Generated at 2022-06-25 10:29:56.461608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = test_case_0()

    #Test case with the following args and expected result

    terms = ['DEFAULT_BECOME_USER']
    variables = {'ansible_connection': 'local', 'ansible_inventory_cache': 'memory', 'ansible_play_hosts': {'127.0.0.1': None}, 'ansible_playbook_python': '/usr/bin/python3'}
    kwargs = {}

    result = lookup_module_run_0.run(terms, variables, **kwargs)

    assert result == [None]

# Generated at 2022-06-25 10:29:57.008842
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert(False)

# Generated at 2022-06-25 10:29:58.511107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([Sentinel()])

# Generated at 2022-06-25 10:30:02.830878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    # Attempt to retrieve the global config setting for 'DEFAULT_BECOME_USER'
    result_0 = _get_global_config("DEFAULT_BECOME_USER")
    print("SUCCESS")
  except (AnsibleError, AnsibleLookupError) as e:
    print("FAIL")


# Generated at 2022-06-25 10:32:21.590372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = None
    lookup_module_0 = LookupModule()
    try:
        assert lookup_module_0.run(set_0) == 'FAIL'
    except:
        lookup_module_0.run(set_0) == 'FAIL'


if __name__ == '__main__':
    test_case_0()