

# Generated at 2022-06-25 10:22:40.434887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # need to retry this test since the color values will change
    for try_count in range(5):
        ret_result = False
        try:
            lookup_module_1 = LookupModule()
            kwargs_1 = {'on_missing': 'warn', 'plugin_type': 'lookup', 'plugin_name': 'identity', 'var_options': {}, 'direct': {}}
            terms_1 = ['DEFAULT_ROLES_PATH', 'HOST_KEY_CHECKING']
            result_1 = lookup_module_1.run(terms_1, **kwargs_1)
            ret_result = True
        except AnsibleOptionsError as e:
            ret_result = True


# Generated at 2022-06-25 10:22:44.572830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['remote_user']
    variables = {'ansible_user': 'ec2-user'}
    kwargs = {'plugin_name': 'local'}
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret[0] == variables['ansible_user']



# Generated at 2022-06-25 10:22:54.210745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=None, variables=None, **{'on_missing': 'error', 'plugin_type': 'become', 'plugin_name': 'pam'})
    lookup_module.run(terms="test_terms", variables={}, **{'on_missing': 'error', 'plugin_type': 'become', 'plugin_name': 'pam'})
    lookup_module.run(terms=[], variables=None, **{'on_missing': 'error', 'plugin_type': 'become', 'plugin_name': 'pam'})
    lookup_module.run(terms=None, variables={}, **{'on_missing': 'warn', 'plugin_type': 'become', 'plugin_name': 'pam'})

# Generated at 2022-06-25 10:23:02.744692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import inspect
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Get all needed constructor arguments for class LookupModule
    params = inspect.signature(LookupModule.__init__).parameters
    args = dict()
    for key, param in params.items():
        if key == 'self':
            continue
        if param.default == inspect.Parameter.empty:
            args[key] = None
    lookup_module_0 = LookupModule(**args)

    # Construct a mock of argument 'loader'
    loader_0 = DataLoader()

    # Construct a mock of argument 'templar'
    templar_0 = None

    # Construct a mock of argument 'vars'
    vars_0 = VariableManager()

    # Construct a mock

# Generated at 2022-06-25 10:23:09.101583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # check for missing in global config
    with pytest.raises(AnsibleLookupError):
        lookup_module_1.run(terms=['missing_key'])
    with pytest.raises(AnsibleLookupError):
        lookup_module_1.run(terms=['missing_key'], on_missing='error')


# Generated at 2022-06-25 10:23:12.988720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    config = {'ptype': 'connection', 'pname': 'ssh'}
    variables = {}
    terms = ['remote_user', 'remote_port']
    kwargs = {'on_missing': 'error'}
    result = obj.run(terms, variables, **kwargs)
    print(result)

# Generated at 2022-06-25 10:23:22.913612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0=None
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []

# Generated at 2022-06-25 10:23:32.890663
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:23:36.091000
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    results_0 = lookup_module_0.run(['DEFAULT_BECOME_USER'])
    #assert isinstance(results_0, list)
    assert results_0[0] == 'root'


# Generated at 2022-06-25 10:23:42.273299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result is not None
    assert isinstance(result, list)
    assert not result
    assert len(result) == 0


# Generated at 2022-06-25 10:24:02.276344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the second item in terms is an invalid result
    terms = ['DEFAULT_BECOME_USER', 'color_changed']
    variables = {'color_changed': 'yellow'}
    plugin_type = 'connection'
    plugin_name = 'smart'
    on_missing = 'skip'

    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct={'on_missing': on_missing, 'plugin_type': plugin_type, 'plugin_name': plugin_name})
    assert lookup_module.run(terms, variables) == ['root', 'changed']

# Generated at 2022-06-25 10:24:05.509061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(['DEFAULT_BECOME_USER'])
    assert(result == ['root'])


# Generated at 2022-06-25 10:24:11.163169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['']
    variables_0 = {}
    test_case_0_1_ret = lookup_module_0.run(terms_0, variables_0, **{'on_missing' : 'error', 'plugin_name' : 'ssh', 'plugin_type' : 'connection'})
    assert(test_case_0_1_ret == [])


# Generated at 2022-06-25 10:24:13.636019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with missing setting
    output = lookup_module.run(['UNKNOWN'], on_missing='warn')
    assert output == []


# Generated at 2022-06-25 10:24:22.864298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:24:32.416561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh', 'on_missing': 'error'})
    assert lookup_module_0.run(['remote_user', 'port'], variables=None) == ['root', '22'], 'the value of lookup_module_0.run([\'remote_user\', \'port\'], variables=None) is not [\'root\', \'22\'], but rather \'%s\'' % lookup_module_0.run(['remote_user', 'port'], variables=None)

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:24:43.147892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    print(lookup_module_1.run(terms=['DEFAULT_ROLES_PATH'], variables='DEFAULT_ROLES_PATH'))
    try:
        lookup_module_1.run(terms=['DEFAULT_ROLES_PATH'], variables='DEFAULT_ROLES_PATH', on_missing='error')
    except AnsibleOptionsError as e:
        print(e)
    try:
        lookup_module_1.run(terms=['DEFAULT_ROLES_PATH'], variables='DEFAULT_ROLES_PATH', plugin_name='root', plugin_type='become')
    except AnsibleOptionsError as e:
        print(e)

# Generated at 2022-06-25 10:24:46.289971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['config_key']
    result = lookup_module_0.run(terms_0)
    assert result == []


# Generated at 2022-06-25 10:24:48.995843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['DEFAULT_BECOME_USER']) == ['root']

test_LookupModule_run()

# Generated at 2022-06-25 10:24:53.507764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = {}
    kwargs = {'on_missing': 'skip',
              'plugin_type': 'become',
              'plugin_name': 'sudo'}
    lookup_module = LookupModule()
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:25:28.601510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_1 = (['DEFAULT_ROLES_PATH'], {'DEFAULT_BECOME_USER': 'root'}, {'on_missing': 'warn', 'plugin_type': 'shell', 'plugin_name': 'sh'})
    expected_result_1 = ['/etc/ansible/roles:/usr/share/ansible/roles']
    expected_result_2 = ['/usr/share/ansible:/etc/ansible']
    output_1 = LookupModule().run(input_1[0], input_1[1], **input_1[2])
    if output_1 != expected_result_1 and output_1 != expected_result_2:
        #pytest.fail("Expected: %s, but got: %s" % (expected_result_1, output_1))
        assert False


# Generated at 2022-06-25 10:25:31.283478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['DEFAULT_BECOME_USER']) == [None]


# Generated at 2022-06-25 10:25:36.384401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    lookup_module_0 = LookupModule()
    # use the run method of LookupModule class to test
    assert True == lookup_module_0.run(terms="DEFAULT_BECOME_USER",variables="hostvars['hostname'])",plugin_type="become",plugin_name="sudo",on_missing='error')

# Generated at 2022-06-25 10:25:44.248182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test using mock_get_option()
    lookup_module.get_option = mock_get_option

    # Test using mock_get_plugin_config()
    lookup_module.get_plugin_config = mock_get_plugin_config

    # Test using mock_get_global_config()
    lookup_module.get_global_config = mock_get_global_config

    assert lookup_module.run(['SETTING']) == ['1']
    #assert lookup_module.run(['SETTING'], group='Group') == []
    #assert lookup_module.run(['SETTING'], plugin_type='Plugin Type', plugin_name='Plugin Name') == []
    #assert lookup_module.run(['SETTING'], var_options='Variables', direct='Direct') == []



# Generated at 2022-06-25 10:25:53.155816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = dict()
    variables['playbook_dir'] = '/home/ansible/playbooks'
    variables['ansible_connection'] = 'ssh'
    variables['port'] = 22
    variables['host_key_checking'] = False
    variables['remote_user'] = 'ansible'
    variables['ansible_python_interpreter'] = '/usr/bin/python3'
    variables['ansible_shell_type'] = 'sh'
    variables['plugin_type'] = 'shell'
    variables['plugin_name'] = 'sh'
    terms = ['playbook_dir']
    kwargs = dict()
    kwargs['var_options'] = variables
    actual = lookup_module.run(terms, variables=variables, **kwargs)

# Generated at 2022-06-25 10:25:55.077554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run == LookupModule.run


# Generated at 2022-06-25 10:26:00.338851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test case with correct input
    # Input args contains a list of config keys
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']

    # Input args: variables = None
    # Input args: kwargs = {}
    res = lookup_module_0.run(terms)
    assert res == ['root', [ './roles', '~/.ansible/roles', '/usr/share/ansible/roles' ]]

    # Test case with correct input
    # Input args contains a list of config keys
    terms = ['host_key_checking']

    # Input args: variables = None
    # Input args: kwargs = {'on_missing': 'warn'}

# Generated at 2022-06-25 10:26:06.944337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = (
        u'DEFAULT_BECOME_USER',
    )
    variables = {
        u'inventory_dir': u'/etc/ansible/hosts',
        u'playbook_dir': u'/etc/ansible/playbooks',
    }
    kwargs = {}
    ret = lookup_module_0.run(terms, variables, **kwargs)
    assert ret == ['root']

# Generated at 2022-06-25 10:26:17.200136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variable_0 = {}
    variable_0['ANSIBLE_REMOTE_TEMP'] = None
    variable_0['ANSIBLE_PIPELINING'] = None
    variable_0['ANSIBLE_ROLES_PATH'] = None
    variable_0['ANSIBLE_SSH_ARGS'] = None
    variable_0['ANSIBLE_HOST_KEY_CHECKING'] = None
    variable_0['ANSIBLE_PRIVATE_KEY_FILE'] = None
    variable_0['ANSIBLE_FORKS'] = None
    variable_0['ANSIBLE_MAX_FAIL_PERCENTAGE'] = None
    variable_0['ANSIBLE_REMOTE_USER'] = None
    variable_0['ANSIBLE_KEEP_REMOTE_FILES'] = None
    variable_0

# Generated at 2022-06-25 10:26:23.672767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arguments = [
            'DEFAULT_BECOME_USER',
            'DEFAULT_ROLES_PATH',
            'RETRY_FILES_SAVE_PATH',
            'COLOR_OK',
            'COLOR_CHANGED',
            'COLOR_SKIP',
            'config_in_var',
            'remote_user',
            'port',
            'remote_tmp',
            ]
    arguments1 = [
            'on_missing',
            'plugin_type',
            'plugin_name',
            ]
    arguments2 = [
            'var',
            ]

# Generated at 2022-06-25 10:27:16.621313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ANSIBLE_DEBUG']
    variables = None
    result_run = lookup_module.run(terms, variables)
    assert result_run == [C.DEFAULT_DEBUG]



# Generated at 2022-06-25 10:27:26.498164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['']) == []
    assert lookup_module_1.run(['', '']) == []
    assert lookup_module_1.run(['', '', '']) == []
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run(['RUN_ALL_MODULE_UTILS_PRIOR_TO_HOOKS', '', '']) == ['True']
    assert lookup_module_2.run(['', 'CHECKPOINT_DISABLE', '']) == ['False']
    assert lookup_module_2.run(['', '', 'STDERR_ENABLED']) == ['True']



# Generated at 2022-06-25 10:27:33.827110
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = 'DEFAULT_BECOME_USER'
    variables = {'ansible_become_user': None}
    ret = lookup_module.run(terms, variables=variables)
    assert ret == [u'root']

    terms = 'DEFAULT_ROLES_PATH'
    variables = None
    ret = lookup_module.run(terms, variables=variables)
    assert ret == [u'/etc/ansible/roles:/usr/share/ansible/roles']

    terms = 'RETRY_FILES_SAVE_PATH'
    variables = None
    ret = lookup_module.run(terms, variables=variables)
    assert ret == [u'/home/ubuntu/.ansible_retry']


# Generated at 2022-06-25 10:27:38.622585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['inventory', 'library', 'module_utils', 'filter_plugins', 'fact_caching', 'callback_plugins', 'action_plugins'], dict()) is None
    assert lookup_module_0.run(['become_plugins'], dict()) is None
    assert lookup_module_0.run(['colored'], dict()) is None
    assert lookup_module_0.run(['command_warnings'], dict()) is None
    assert lookup_module_0.run(['command_timeout'], dict()) is None
    assert lookup_module_0.run(['config_file'], dict()) is None
    assert lookup_module_0.run(['connection_plugins'], dict()) is None

# Generated at 2022-06-25 10:27:45.744790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _stash = []

    def _stash_append(val):
        _stash.append(val)

    lookup_module_0 = LookupModule()

    _stash_append(lookup_module_0.run([u'DEFAULT_BECOME_USER']))
    _stash_append(lookup_module_0.run([u'DEFAULT_BECOME_USER', u'DEFAULT_BECOME_PASS'],
                                      on_missing=u'warn', plugin_name=u'ssh', plugin_type=u'connection'))
    _stash_append(lookup_module_0.run([u'DEFAULT_BECOME_USER', u'DEFAULT_BECOME_PASS'],
                                      on_missing=u'skip'))

# Generated at 2022-06-25 10:27:52.310618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'COLOR_OK'

    variables_0 = {}
    direct_0 = {}
    result = lookup_module_0.run(terms_0, variables_0, direct_0)
    assert result == 'ok'
    assert result is not None
    assert result is not 'OK'

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:28:02.391260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = None
    kwargs_0 = {'on_missing': 'warn'}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == []
    terms_1 = []
    variables_1 = None
    kwargs_1 = {'plugin_name': 'ssh'}
    result_1 = lookup_module_0.run(terms_1, variables_1, **kwargs_1)
    assert result_1 == []
    terms_2 = []
    variables_2 = None
    kwargs_2 = {'plugin_type': 'shell'}

# Generated at 2022-06-25 10:28:04.648150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._display.warning('Skipping, did not find setting config_in_var')

# Generated at 2022-06-25 10:28:06.818233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(["HOST_KEY_CHECKING"]) == [False]



# Generated at 2022-06-25 10:28:13.656291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_path = os.path.join(os.path.dirname(__file__), 'lookup_plugins/config_test.py')
    plugin_loader_path = os.path.join(os.path.dirname(__file__), 'plugins/loader/__init__.py')

# Generated at 2022-06-25 10:30:03.462983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables=None
    result = lookup_instance.run(terms, variables)
    assert isinstance(result, list), "Result should be a list"
    assert len(result) == 1, "Result list should have only one element"
    assert result[0] is not None, "Result should not be None"


# Generated at 2022-06-25 10:30:09.153305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test using config variable
    result = lookup_module_0.run(terms = ["DEFAULT_BECOME_USER"],variables = None,on_missing = "error")
    # There is no assert, or checking of the returned data, just execution.
    # I think we can assume that if the code runs without error, that
    # the test result is positive.
    assert result == ['root']
    result = lookup_module_0.run(terms = ["DEFAULT_ROLES_PATH"],variables = None,on_missing = "error")
    assert result == [['/etc/ansible/roles']]
    result = lookup_module_0.run(terms = ["RETRY_FILES_SAVE_PATH"],variables = None,on_missing = "error")

# Generated at 2022-06-25 10:30:11.583010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # unit_test_found_result = lookup_module.run(terms, variables=None, **kwargs)
    # assertEqual(unit_test_expected_result, unit_test_found_result)

    assert(True)

# Generated at 2022-06-25 10:30:13.228028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = ""
    result = lookup_module_0.run(term)
    assert type(result) == list

# Generated at 2022-06-25 10:30:15.499256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['DEFAULT_FORKS'], variables=None) == [5]


# Generated at 2022-06-25 10:30:18.310663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ""
    variables = ""
    kwargs = ""
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(terms=terms, variables=variables, kwargs=kwargs)
    assert res == ""

# Generated at 2022-06-25 10:30:21.140830
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_instance = LookupModule()

    terms = []
    variables = []
    kwargs = dict()

    results=  lookup_instance.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:30:23.806381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    kwargs = {}
    ret = lookup_module_0.run(terms, **kwargs)
    assert ret == []


# Generated at 2022-06-25 10:30:25.189136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('test_Terms') == ['test_Terms']

# Generated at 2022-06-25 10:30:26.665797
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print(test_case_0())

test_LookupModule_run()