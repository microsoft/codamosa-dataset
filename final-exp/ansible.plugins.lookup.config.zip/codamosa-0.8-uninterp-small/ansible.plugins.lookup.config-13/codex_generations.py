

# Generated at 2022-06-25 10:22:38.248339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule(list_0)
    # below should not raise a MissingSetting error
    lookup_module_0.run(list_0, on_missing='warn')
    lookup_module_0.run(list_0, on_missing='skip')
    # below should raise a MissingSetting error
    lookup_module_0.run(list_0, on_missing='error')

test_LookupModule_run()

# Generated at 2022-06-25 10:22:43.325808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    variables_0 = {}
    lookup_module_0 = LookupModule(list_0)
    term_0 = "DEFAULT_BECOME_USER"
    try:
        lookup_module_0.run(terms=term_0, variables=variables_0)
    except AnsibleLookupError as e:
        assert "Unable to find setting %s" % term_0 in to_native(e)
    else:
        raise AssertionError()

# Generated at 2022-06-25 10:22:46.904724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ["unknown"]
    list_1 = lookup_module_0.run(list_0)
    list_2 = []
    print(list_1)
    assert list_1 == list_2

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:22:50.050315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule(list_0)
    try:
        lookup_module_0.run(list_0, {})
    except AnsibleError as ae:
        pass


# Generated at 2022-06-25 10:22:53.777206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule(list_0)
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.get_opti

# Generated at 2022-06-25 10:23:02.493293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule([])
  assert lookup_module_0.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], {})
  assert lookup_module_0.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], {}, on_missing = 'error')
  assert lookup_module_0.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], {}, on_missing = 'warn')
  assert lookup_module_0.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], {}, on_missing = 'skip')

# Generated at 2022-06-25 10:23:06.240797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule(list_0)

    assert type(lookup_module_0) == LookupModule


# Generated at 2022-06-25 10:23:14.920855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.utils.sentinel import Sentinel

    lookup_module_0 = LookupModule([u'DEFAULT_BECOME_USER'])
    assert lookup_module_0.run(u'DEFAULT_BECOME_USER') == [u'root']

    lookup_module_1 = LookupModule([u'DEFAULT_ROLES_PATH'])
    assert lookup_module_1.run(u'DEFAULT_ROLES_PATH') == [u'/etc/ansible/roles:/usr/share/ansible/roles']

    lookup_module_2 = LookupModule([u'RETRY_FILES_SAVE_PATH'])

# Generated at 2022-06-25 10:23:26.483071
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test passing invalid 'terms' param
    options_0 = {'direct': {}, 'var_options': {}}
    value_0 = 'y'
    list_0 = [value_0]
    lookup_module_0 = LookupModule(list_0)
    try:
        lookup_module_0.run(terms={}, **options_0)
    except AnsibleOptionsError:
        pass
    else:
        assert False

    # test passing invalid 'on_missing' param
    err = None
    value_0 = 'q'
    value_1 = 'y'

    list_0 = [value_0]
    lookup_module_0 = LookupModule(list_0)
    options_0 = {'direct': {'on_missing': list_0}, 'var_options': {}}

# Generated at 2022-06-25 10:23:35.126750
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:23:59.326943
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:24:09.061843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run: Missing options
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options={"ansible_connection": "local"}, direct={"plugin_type": "become", "plugin_name": "test"})
    try:
        lookup_module_1.run(["DEFAULT_BECOME_USER"], variables={"ansible_connection": "local"})
        raise AssertionError("The LookupModule.run method did not raise an AnsibleOptionsError exception when missing 'on_missing' option.")
    except AnsibleOptionsError:
        pass
    except Exception as e:
        raise AssertionError("The LookupModule.run method did not raise an AnsibleOptionsError exception when missing 'on_missing' option. It raised %s instead." % e)
    #

# Generated at 2022-06-25 10:24:17.202346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Exception raised when "on_missing" is neither "error", "skip" or "warn".
    with pytest.raises(AnsibleOptionsError) as excinfo:
        LookupModule().run(terms=["DEFAULT_ROLES_PATH"], variables={}, on_missing="warn_skipping_the_fatal_error")
    assert "Invalid value for 'on_missing'" in str(excinfo.value)

    # Exception when the plugin name is not specified
    with pytest.raises(AnsibleOptionsError) as excinfo:
        LookupModule().run(terms=["DEFAULT_ROLES_PATH"], variables={}, plugin_type="become")
    assert "Both plugin_type and plugin_name are required" in str(excinfo.value)

    # Exception when the plugin type is not specified

# Generated at 2022-06-25 10:24:21.529643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['remote_port']
    ptype = 'connection'
    pname = 'httpapi'
    variables = {}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, variables)
    print(result)

# Generated at 2022-06-25 10:24:25.361551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = 'DEFAULT_BECOME_USER'
    variables = {}
    try:
        lookup_module.run(terms=term,variables=variables)
    except AnsibleLookupError:
        pass

# Generated at 2022-06-25 10:24:34.146520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run(terms=["ansible_pipelining"])
    except AnsibleOptionsError as e:
        assert(to_native(e).startswith('"on_missing" must be a string and one of'))
    except Exception as e:
        assert(False)

    try:
        lookup_module_2 = LookupModule()
        lookup_module_2.run(terms=["foo"])
    except Exception as e:
        assert(to_native(e).startswith('Unable to find setting foo'))
    else:
        assert(False)


# Generated at 2022-06-25 10:24:44.302734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([__file__]) == [__file__]
    assert lookup_module_0.run(['ANSIBLE_INTERNAL_DATA']) == [C.ANSIBLE_INTERNAL_DATA]
    assert lookup_module_0.run(['ANSIBLE_INTERNAL_DATA']) == [C.ANSIBLE_INTERNAL_DATA]
    assert lookup_module_0.run(['ANSIBLE_INTERNAL_DATA', 'ANSIBLE_INTERNAL_DATA']) == [C.ANSIBLE_INTERNAL_DATA, C.ANSIBLE_INTERNAL_DATA]

# Generated at 2022-06-25 10:24:52.986400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(Sentinel.loader)

# Generated at 2022-06-25 10:25:01.711211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # cases = [
    #     {
    #         'terms': [
    #             'DEFAULT_BECOME_USER'
    #         ],
    #         'expect': 'root'
    #     }
    # ]
    # for case in cases:
    #     result = lookup_module_0.run(case['terms'])
    #     print(result)
    #     assert result == case['expect']
    terms = ['DEFAULT_BECOME_USER']
    print(lookup_module_0.run(terms))

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()
    pass

# Generated at 2022-06-25 10:25:10.492828
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Not testing the following keywords of run:
    # 'terms', 'variables', '**kwargs':

    # Testing 'on_missing':
    with pytest.raises(AnsibleOptionsError):
        lookup_module = LookupModule()
        terms = 'terms'
        variables = 'variables'
        on_missing = 'not on_missing'
        lookup_module.run(terms, variables=variables, on_missing=on_missing)

    with pytest.raises(AnsibleOptionsError):
        lookup_module = LookupModule()
        terms = 'terms'
        variables = 'variables'
        on_missing = None
        lookup_module.run(terms, variables=variables, on_missing=on_missing)

    with pytest.raises(AnsibleOptionsError):
        lookup_module

# Generated at 2022-06-25 10:25:41.082569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # remove arg, not called for lookups
    res = lookup_module_0.run([])
    assert res == [], res
    # remove arg, not called for lookups
    res = lookup_module_0.run([], variable_manager=[])
    assert res == [], res


# Generated at 2022-06-25 10:25:43.746330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = Sentinel

    # Testing if exception is raised
    # Constant assumptions that match the real environment
    try:
        lookup_module_0.run(terms)
    except ValueError as e:
        assert e is not None


# Generated at 2022-06-25 10:25:47.491914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(
            terms=['random_1','random_2'],
            variables=None,
            plugin_type='shell',
            plugin_name='sh') == []


# Generated at 2022-06-25 10:25:49.639423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['DEFAULT_BECOME_USER'], None)
    assert result[0] == 'root'

# Generated at 2022-06-25 10:25:55.636560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options( var_options=None, direct=None )

    # Test if the type of the run() return value is a list.
    assert isinstance( lookup_module.run(terms=None, variables=None, **None),list )

    # Test if the return value of the run() is empty list.
    lookup_module.set_options( var_options=None, direct={'on_missing': 'skip'} )
    assert lookup_module.run(terms=[ 'DEFAULT_BECOME_USER' ], variables=None, **None) == []

# Generated at 2022-06-25 10:25:58.558655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    json_from_file = {}
    attribute = "color_changed"
    expected_value = "#C00000"
    actual_value = ""
    lookup_module_0 = LookupModule()
    actual_value = lookup_module_0.run([attribute])
    assert type(actual_value) == list
    assert len(actual_value) == 1
    assert actual_value[0] == expected_value

# Generated at 2022-06-25 10:26:08.762928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit tests for lookup module
    import sys
    import pytest
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleOptionsError

    ############################################################################
    # The following test cases check throwing of AnsibleLookupError exceptions.
    ############################################################################

    def test_case_1():
        # test case id: 1
        # validate lookup module run method with invalid configuration parameter
        lookup_module_1 = LookupModule()
        lookup_module_1.set_options({'plugin_type': 'connection', 'plugin_name': 'ssh'})
        terms_list_1 = ['remote_user']
        with pytest.raises(AnsibleLookupError) as err:
            lookup_module_1.run(terms_list_1, {})
        assert err.value.args

# Generated at 2022-06-25 10:26:13.227028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        terms = ["test"]
        lookup_module.run(terms, **{'wantlist': True})
    except AnsibleOptionsError as e:
        raise AssertionError(to_native(e))

# Generated at 2022-06-25 10:26:18.306968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = 'DEFAULT_BECOME_USER'
    variables_0 = 'DEFAULT_BECOME_USER'
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms_0, variables_0)
    assert result_0 == ['root'], "Test case 0, expected result = ['root'], actual result = %s" % result_0


# Generated at 2022-06-25 10:26:22.548751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case tries to lookup a non existing term with on_missing value as error.
    # Should raise exception with message as "did not find setting"
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(terms=['non_existing_term'], variables=None, on_missing='error')
    except AnsibleLookupError as e:
        if 'did not find setting' in str(e):
            return True
    return False


# Generated at 2022-06-25 10:27:18.409009
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_0 = config
    x_0 = LookupModule()
    x_1 = x_0.run(terms_0)

# Generated at 2022-06-25 10:27:28.842566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    import sys
    m = mock.mock_open()
    with mock.patch("lookup_plugins.config.open", m, create=True):
        if sys.version_info < (2, 7):
            m.return_value.__file__ = "foo"
        lookup_module_0 = LookupModule()
        terms = ['foo', 'bar']
        variables = {}
        kwargs = {}
        kwargs['on_missing'] = 'error'
        kwargs['plugin_type'] = 'become'
        kwargs['plugin_name'] = 'sudo'
        ret = lookup_module_0.run(terms, variables, **kwargs)
        assert ret == [Sentinel]


# Generated at 2022-06-25 10:27:33.562455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(['DEFAULT_BECOME_USER'], dict(), on_missing=Sentinel.error)) == 1
    assert len(lookup_module_0.run(['DEFAULT_ROLES_PATH'], dict(), on_missing=Sentinel.error)) == 1


# Generated at 2022-06-25 10:27:39.549446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_global_config(self, config):
        if config == 'DEFAULT_BECOME_USER':
            return 'Nobody'
        else:
            raise NotImplementedError

    lookup_module = LookupModule()

    lookup_module.get_option = MagicMock(return_value = 'error')
    lookup_module.set_options = MagicMock()
    lookup_module.get_option = MagicMock(return_value = None)
    lookup_module.set_options = MagicMock()
    lookup_module.run('DEFAULT_BECOME_USER')

# Generated at 2022-06-25 10:27:40.371610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    lookup_module = LookupModule()
    assert lookup_module.run() == []

# Generated at 2022-06-25 10:27:42.881614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['DEFAULT_BECOME_USER', 'UNKNOWN']
    variables_1 = dict()
    kwargs_1 = dict()
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert result_1 == ['root']

# Generated at 2022-06-25 10:27:47.165419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Direct test for method run of class LookupModule

    # Case 1
    # Return values:
    var_params_1 = [["FOO", "BAR", "BAZ"], None, {}]
    var_terms_1 = ["FOO", "BAR", "BAZ"]
    var_variables_1 = None
    var_kwargs_1 = {}
    # Calls:
    # Return value: [C.DEFAULT_FOO, C.DEFAULT_BAR, C.DEFAULT_BAZ]
    try:
        var_ret_1 = lookup_module_0.run(*var_params_1)
    except Exception as var_e:
        var_ret_1 = str(var_e)

# Generated at 2022-06-25 10:27:50.486806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['']) == []
    assert lookup_module_0.run(terms=[''], variables=None) == []
    assert lookup_module_0.run(terms=['UNKNOWN_SET_VALUE']) == []
    assert lookup_module_0.run(terms=['UNKNOWN_SET_VALUE'], variables=None) == []

# Generated at 2022-06-25 10:27:52.893291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:27:58.490565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with on_missing "skip"
    assert lookup_module.run(['absent_settings'], None, {}, on_missing='skip') == []
    # test with on_missing "warn"
    assert lookup_module.run(['absent_settings'], None, {}, on_missing='warn') == []
    # test with on_missing "error"
    try:
        lookup_module.run(['absent_settings'], None, {}, on_missing='error')
        assert False
    except MissingSetting:
        assert True
    except:
        assert False
    # test with on_missing "invalid_value"

# Generated at 2022-06-25 10:29:51.407335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    module_return = lookup_module_0.run(terms, variables='', **{'plugin_name': ''})
    assert module_return == ['rsa', 'rsa']

# Generated at 2022-06-25 10:29:54.356240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=['foo'], variables=None, **{'plugin_name': 'bar', 'plugin_type': 'baz'})


# Generated at 2022-06-25 10:29:57.655601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['DEBUG'], {'a': 'b'}) == ['False']


# Generated at 2022-06-25 10:30:05.148226
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 0
    DIRS = ("dir_a", "dir_b")
    lookup = LookupModule()
    terms = [x for x in DIRS]
    wanted = [x for x in DIRS]
    assert wanted == lookup.run(terms, variables={}, on_missing='warn')

    # Case 1
    DIRS = ("dir_a", "dir_b", "dir_c")
    lookup = LookupModule()
    terms = [x for x in DIRS]
    wanted = [x for x in DIRS]
    assert wanted == lookup.run(terms, variables={}, on_missing='skip')

# Generated at 2022-06-25 10:30:08.391640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(*[]) == []
    assert lookup_module_0.run(*[[]], **{u'plugin_name': 'shell'}) == []
    assert lookup_module_0.run(*[['VERSION']], **{u'plugin_name': 'connection'}) == []

# Generated at 2022-06-25 10:30:09.615511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert callable(getattr(lookup_module_0, 'run'))

# Generated at 2022-06-25 10:30:15.224586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['bar']
    kwargs = {}
    # Test with adding the missing parameter on_missing in kwargs
    try:
        assert lookup_module_0.run(terms, **kwargs) == ['bar']
    except Exception:
        assert False

    # Test with missing parameter  in kwargs
    try:
        assert lookup_module_0.run(terms) == ['bar']
    except Exception as e:
        assert "on_missing" in str(e)
        assert False



# Generated at 2022-06-25 10:30:16.863026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True == lookup_module_0.run(terms=[])

# Generated at 2022-06-25 10:30:22.750235
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    remote_user = lookup_module.run(terms=["remote_user"])
    assert remote_user[0] == C.DEFAULT_REMOTE_USER
    remote_port = lookup_module.run(terms=["port"], variables={"ansible_default_ipv4": {"port": 22}})
    assert remote_port[0] == 22
    assert str(remote_port[0]) == "22"
    assert remote_port[0] == C.DEFAULT_REMOTE_PORT

# Generated at 2022-06-25 10:30:31.750468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER']
    variables_0 = None
    assert lookup_module_0.run(terms=terms_0, variables=variables_0) == [u'root']
    terms_1 = []
    variables_1 = None
    assert lookup_module_0.run(terms=terms_1, variables=variables_1) == []
    kwargs = dict()