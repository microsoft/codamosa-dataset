

# Generated at 2022-06-25 10:22:35.331882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The lookup_module_0 argument is an object of the class LookupModule
    lookup_module_0 = LookupModule()
    terms = ["hosts"]
    variables = None
    lookup_module_0.run(terms, variables)



# Generated at 2022-06-25 10:22:39.231555
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = []
    variables = {}
    kwargs = {
        'plugin_type': None,
        'plugin_name': None,
        'on_missing': u'error'
    }

    lookup_module_0 = LookupModule()

    results = lookup_module_0.run(terms, variables, **kwargs)

    assert results == []

# Generated at 2022-06-25 10:22:40.033924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0().run() == []

# Generated at 2022-06-25 10:22:44.608338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0=['DEFAULT_ROLES_PATH','DEFAULT_BECOME_USER']
    ret_0 = lookup_module_0.run(terms_0)
    assert ret_0 == [['data/ansible_collections/',
                      '/usr/share/ansible/roles',
                      '~/.ansible/roles',
                      'library'], 'root']


# Generated at 2022-06-25 10:22:51.081714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['missing_variable']
    variables_0 = {'missing_variable': 'test'}
    result_0 = lookup_module_0.run(terms_0, variables=variables_0)
    assert result_0 == ['test']
    terms_1 = ['missing_variable']
    variables_1 = {'missing_variable': 'test'}
    result_1 = lookup_module_0.run(terms_1, variables=variables_1)
    assert result_1 == ['test']

# Generated at 2022-06-25 10:22:57.415801
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_self = MagicMock(spec=LookupModule)
    mock_self.run.return_value = '{"key": "value"}'

    mock_terms = MagicMock(spec=str)
    result = LookupModule.run(mock_self, mock_terms)

    assert result == '{"key": "value"}'
    mock_self.run.assert_called_once_with(mock_terms, variables=None)

# Generated at 2022-06-25 10:23:04.224689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["Blackhole", "log_path", "nocows", "strategy", "warnings_filter_file", "radio", "radio", "radio", "radio", "radio", "radio" ]
    variables_1 = {}
    kwargs_1 = {}
    lookup_module_1.set_options(var_options=variables_1, direct=kwargs_1)

    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == [
        '.ansible_async', './log/ansible.log', True, 'linear', './filter_warnings', 'radio', 'radio', 'radio', 'radio', 'radio', 'radio']


# Generated at 2022-06-25 10:23:12.326409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        'on_missing': 'error',
        'plugin_type': 'cliconf',
        'plugin_name': 'junos',
    }
    terms = ['mapping']
    variables = None
    lookup_module = LookupModule()
    lookup_module.get_option = lambda x: args.get(x)
    lookup_module._display = Display()
    lookup_module.cleanup = lambda: None
    lookup_module.set_options(var_options=variables, direct=args)
    lookup_module_return = lookup_module.run(terms, variables=variables, **args)
    assert lookup_module_return == "mapping"

# Generated at 2022-06-25 10:23:18.966192
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:23:23.601944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from units.compat.mock import patch, MagicMock
    from collections import namedtuple

    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

    class TestAnsibleLookupBase(object):
        def __init__(self):
            self.sentinel = object()
            self.test_config_variable_1 = 'config_variable_1'
            self.test_config_variable_3 = 'config_variable_3'

# Generated at 2022-06-25 10:23:36.498828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.errors import AnsibleOptionsError
  lookup_base = LookupModule()
  # Test with invalid str_0
  str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
  var_0 = lookup_base.run(str_0)
  # Test with invalid str_0
  str_0 = "\\rf/'^'=v,iK\rq8Avt"
  var_0 = lookup_base.run(str_0)
  # Test with invalid str_0
  str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
  var_0 = lookup_base.run(str_0)

# Generated at 2022-06-25 10:23:43.072879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert raises(AnsibleError, LookupModule.run())
    lookup_module_0 = LookupModule()
    terms = []
    variables = None
    var_0 = lookup_module_0.run(terms, variables)
    assert var_0 == [], 'Expected [], got {0}.'.format(var_0)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:23:47.252587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:23:54.406963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_2 = 'IQNu5C5AVh9KjVui/'
    str_3 = 'K30pDpW7r8TAqWR^|'
    lookup_module_1 = LookupModule(str_3, str_3)
    str_1 = "test"
    var_2 = lookup_module_1.run(str_1)
    var_2 = lookup_module_1.run(str_1)


# Generated at 2022-06-25 10:23:59.728192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_str = '/N.vAJ>|P'
    missing_str = 'error'
    ptype_str = 'callback'
    pname_str = 'default'
    LookupModule_obj = LookupModule(terms_str, missing_str, ptype_str, pname_str)
    ret = LookupModule_obj.run()
    assert ret == {}

# Generated at 2022-06-25 10:24:02.672696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    lookup_module_0 = LookupModule(str_0, str_0)
    lookup_run(str_0)


# Generated at 2022-06-25 10:24:11.723220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'XO\x0c'
    str_1 = '\x1a\x03\x10\x10\x07\x1c\x0f\x00\x1f'
    str_2 = '\x11\x0c\x0c\x0c\x1b\x0f\x0b\x03\x07'
    test_0 = lookup_module_0.run(str_0, str_1, str_2)
    print(test_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:24:15.673457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:24:20.673278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:24:31.410157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(lookup_provider=None, loader=None, variables={})
    terms = {'color_changed': '\x1b[31m', 'color_portable': '\x1b[34m', 'color_error': '\x1b[31m', 'color_recoverable': '\x1b[31m', 'color_plugin': '\x1b[3m', 'color_skip': '\x1b[30m', 'color_ok': '\x1b[32m', 'color_debug': '\x1b[36m', 'color_unreachable': '\x1b[31m'}
    variables = {}
    actual_result_0 = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 10:24:49.657556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n      Returns a new RoleMetadata object based on the datastructure passed in.\n      '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    lookup_run(str_0)


# Generated at 2022-06-25 10:24:57.650490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_3 = var_0
    var_0 = to_native(var_3)
    var_1 = 'error'
    var_4 = var_1
    var_1 = to_native(var_4)
    var_2 = 'skip'
    var_5 = var_2
    var_2 = to_native(var_5)
    var_6 = var_0
    var_0 = to_native(var_6)


# Generated at 2022-06-25 10:25:07.542511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('plugin_type', 'plugin_name')
    lookup_module_1 = LookupModule(str_0, str_0)
    term_0 = 'cb8cb5b2-5cdb-4695-b00c-d7f5'
    term_1 = 'invalid setting identifier, "%s" is not a string, its a %s'
    term_2 = 'invalid setting identifier, "%s" is not a string, its a %s'
    term_3 = 'invalid setting identifier, "%s" is not a string, its a %s'
    term_4 = 'invalid setting identifier, "%s" is not a string, its a %s'
    term_5 = 'invalid setting identifier, "%s" is not a string, its a %s'
    var_

# Generated at 2022-06-25 10:25:09.604413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:25:13.788458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)
    var_0 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:25:18.301507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:25:27.999696
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.utils.display
    # Constructor for class LookupModule
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)

# Generated at 2022-06-25 10:25:32.228209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pname = 'test'
    ptype = 'test'
    missing = 'error'
    term = 'test'
    lookup_module = LookupModule()
    lookup_module.run(terms=term, plugin_name=pname, plugin_type=ptype, on_missing=missing)

# Generated at 2022-06-25 10:25:39.316713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_0.run(str_0, dict_0)

    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    dict_0 = {'test': 'Hi', 'test2': 'test2'}
    lookup_module_0 = LookupModule(str_0, dict_0)
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    var_0 = lookup_run(str_1)


# Generated at 2022-06-25 10:25:43.584301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 'test-test'
    lookup_module_0 = LookupModule(var_0, var_0)
    var_1 = ''
    var_2 = 'test-test'
    lookup_module_0.run('test-test', var_1, var_2)
    var_2 = 'test-test'
    lookup_module_0.run('test-test', var_1, var_2)


# Generated at 2022-06-25 10:26:16.291166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arguments passed to test_case_0
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"

    # calling test_case_0
    test_case_0(str_0, str_1)



# Generated at 2022-06-25 10:26:22.599459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    str_2 = 'Returns a new RoleMetadata object based on the datastructure passed in.'
    str_3 = "\\rf/'^'=v,iK\rq8Avt"
    str_4 = "\\rf/'^'=v,iK\rq8Avt"
    var_0 = lookup_run(str_2)


# Generated at 2022-06-25 10:26:27.940480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
	str_1 = "\\rf/'^'=v,iK\rq8Avt"
	lookup_module_0 = LookupModule(str_1, str_1)
	var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:26:29.078956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # LookupModule.run is tested with test_case_0
  lookup_run()

# Generated at 2022-06-25 10:26:32.034179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    st_0 = LookupModule()
    st_1 = ''

    lookup_module_0 = LookupModule(st_1, st_1)
    lookup_module_1 = lookup_module_0.run(st_1)


# Generated at 2022-06-25 10:26:38.387570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    lookup_module_0 = LookupModule(str_0, str_0)
    str_1 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_2 = "\\rf/'^'=v,iK\rq8Avt"
    str_3 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_4 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '

# Generated at 2022-06-25 10:26:48.057650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ansible_runner'
    str_1 = 'ansible_connection'
    str_2 = "{u'inventory_dir': u''}"

    # If you want to make the test fail, comment out the following 2 lines, then make the call to lookup_module_0.run fail.
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)

    # assert var_0.run.is_equal_to(str_2), "This test should pass, but is failing for some reason."
    # assert lookup_module_0.run.is_equal_to(str_2), "This test should pass, but is failing for some reason."
    # assert True, "This test should pass, but is failing for some reason."


# Generated at 2022-06-25 10:26:52.237211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)
    assert var_0 == None

# Generated at 2022-06-25 10:26:53.558570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:26:56.639318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = 'config/retry'
    var_2 = 'base_type'
    var_3 = var_0.run(var_1, var_2)
    assert var_3 == 'retry'



# Generated at 2022-06-25 10:27:59.672165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:28:02.890083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    lookup_module_0 = LookupModule(str_0, str_0)
    var_0 = test_case_0()

# Generated at 2022-06-25 10:28:10.893691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = '\x04\x0f\x0e\x10\x01'
    str_0 = '\x1b\x0f\x0f\x14\x00'
    str_1 = '\x1a\x10'
    str_2 = '\x04\x01\x00'
    var_0 = lookup_run(term_0)
    term_1 = '\x00'
    var_1 = lookup_run(term_1)
    term_2 = '\x02\x05\x1c\x1a\x1d\x1a\x19\x06\x02\x15\x0f\x0e\x1c'

# Generated at 2022-06-25 10:28:16.741205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ".w_\n'c~O\\"
    str_1 = "N\nM[1L^f8"
    lookup_module_0 = LookupModule(str_0, str_1)
    lookup_module_0.set_options(None, None, None)

test_LookupModule_run()

# Generated at 2022-06-25 10:28:21.696634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Asserting plugins of lookup_plugins.yaml')
    print('Asserting all.filter of lookup_plugins.yaml')
    print('Asserting random.choice of lookup_plugins.yaml')
    #test_case_0()

if __name__ == "__main__":
    test_LookupModule_run()
    print("All tests passed")

# Generated at 2022-06-25 10:28:27.726957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_2 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_2, str_2)
    lookup_module_0.run(str_1)



# Generated at 2022-06-25 10:28:33.122812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  str_0 = 'zA\x1c-\x1a\x10\x18d\x07\x0e\x03\x1b$\x1e\x10;\x1e*\x16\x0e\x1b\x1a\x09_.\x0b\x16\n\x1c\x1b\n\x1c8\x19\x02'
  lookup_module_0 = LookupModule(str_0)
  var_0 = lookup_module_0.run(str_0)
  return var_0


# Generated at 2022-06-25 10:28:36.716856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)



# Generated at 2022-06-25 10:28:43.000573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 's'
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    lookup_run(str_0)

# main()
if __name__ == "__main__":
    print('')
    print('Executing unit tests for module lookup_plugins.config')
    print('--------------------------------------------------')
    print('')
    print('Unit test for method run of class LookupModule')
    print('--------------------------------------------------')
    print('')
    test_LookupModule_run()
    print('')
    print('--------------------------------------------------')
    print('Unit test for method run of class LookupModule')
    print('--------------------------------------------------')
    print('')

# end of lookup

# Generated at 2022-06-25 10:28:49.704922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_2 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_3 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_1 = LookupModule(str_3, str_3)
    var_1 = lookup_run(str_2)
    var_2 = lookup_get_option('on_missing')
    var_3 = lookup_get_option('plugin_type')
    var_4 = lookup_get_option('plugin_name')

# Generated at 2022-06-25 10:31:04.933841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 10:31:09.117381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/home/prakruthi/ansible-2.7/cp'
    str_1 = 'test_lookup'
    lookup_module_0 = LookupModule(str_0)
    lookup_module_0.run(str_1)



# Generated at 2022-06-25 10:31:18.332382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing the test Object

    # Testing for case where both plugin_type and plugin_name is not present
    lookup_module_0 = LookupModule('plugin_name',
                                   'plugin_type',
                                   'terms',
                                   'variables',
                                   'on_missing')
    try:
        lookup_module_0.run()
    except Exception as e:
        pass

    # Testing for case where plugin_name alone is present
    lookup_module_1 = LookupModule('plugin_name',
                                   '',
                                   'terms',
                                   'variables',
                                   'on_missing')
    try:
        lookup_module_1.run()
    except Exception as e:
        pass

    # Testing for case where plugin_type alone is present

# Generated at 2022-06-25 10:31:20.861695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule('test')
    lookupModule_instance_0 = lookup_module.run(str_0)
    assert(lookupModule_instance_0 == bool_0)

# Generated at 2022-06-25 10:31:29.500520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '"on_missing" must be a string and one of "error", "warn" or "skip"'
    var_1 = 'Unable to find setting %s'
    var_2 = 'Skipping, did not find setting %s'
    var_3 = 'Invalid setting identifier, "%s" is not a string, its a %s'
    var_4 = 'Both plugin_type and plugin_name are required, cannot use one without the other'
    var_5 = '"on_missing" must be a string and one of "error", "warn" or "skip", not skip'
    var_6 = ''
    var_7 = "Could not load class for connection_type 'null': No module named 'ansible.plugins.connection.null'"
    var_8 = 'Unable to load connection plugin "null"'

#

# Generated at 2022-06-25 10:31:37.172469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_module_0.run(str_0)
    var_1 = ''
    for var_2 in var_0:
        var_1 = var_1 + var_2
    assert var_1 == str_0

# Generated at 2022-06-25 10:31:44.137769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = '\x1e+\x18\x1d\n\r\r@\r\x06\x0f\x15'
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_module_0.run(str_0)
    str_2 = '\x1e+\x18\x1d\n\r\r@\x0f\x15'
    str_3 = '\x1e+\x18\x1d\n'
    lookup_module_2 = LookupModule(str_2, str_3)

# Generated at 2022-06-25 10:31:47.632136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule(None, None)
  # insert your test code here


# Generated at 2022-06-25 10:31:53.243757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    str_1 = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(str_1, str_1)
    var_0 = lookup_run(str_0)
    assert var_0 == "\"\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        \"", var_0


# Generated at 2022-06-25 10:32:00.863215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    missing = "\\rf/'^'=v,iK\rq8Avt"
    str_0 = '\n        Returns a new RoleMetadata object based on the datastructure passed in.\n        '
    ptype = "\\rf/'^'=v,iK\rq8Avt"
    pname = "\\rf/'^'=v,iK\rq8Avt"
    lookup_module_0 = LookupModule(term, missing)
    var_0 = lookup_run(str_0)
    result = lookup_module_0.run(term, missing, ptype=ptype, pname=pname)