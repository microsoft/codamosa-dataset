

# Generated at 2022-06-25 10:22:37.386439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # args
    terms = 'DEFAULT_BECOME_USER'
    # kwargs
    var_options = None
    direct = {}
    direct['plugin_name'] = None
    direct['on_missing'] = 'error'
    _result = lookup_module_0.run(terms, var_options, **direct)
    assert not _result

# Generated at 2022-06-25 10:22:45.619691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run_assert_type = None
    run_assert_type_msg = None
    run_assert_kwargs = None
    run_assert_kwargs_msg = None
    run_assert_ret = None
    run_assert_ret_msg = None

# Generated at 2022-06-25 10:22:51.010813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.set_loader(None)
    lookup_module_0.set_environment(None)
    lookup_module_0.set_templar(None)
    lookup_module_0.set_basedir(None)
    lookup_module_0.set_vars(None)
    lookup_module_0.set_inventory(None)
    lookup_module_0.set_play_context(None)
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.set_loader(None)
    lookup_module_0.set_environment(None)
    lookup_module_0.set_templ

# Generated at 2022-06-25 10:22:53.615977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['_terms'], '_terms') == [True]

# Generated at 2022-06-25 10:23:02.360877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options={u'config_in_var': u'UNKNOWN'}, direct={u'on_missing': u'skip'})
    lookup_module_1._display.vvvv = 4
    lookup_module_1._display.verbosity = 4
    lookup_module_1._search_paths = []
    lookup_module_1._templar = None
    lookup_module_1._loader = None
    lookup_module_1._inventory = None
    lookup_module_1._play = None
    lookup_module_1._task = None
    lookup_module_1._connection = None
    lookup_module_1._shell = None
    lookup_module_1._stdin = None
    lookup_module_1._play_context

# Generated at 2022-06-25 10:23:07.182752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(terms, variables=None, **kwargs)
    assert 'Unable to find setting' in str(excinfo.value)
    assert 'orig_exc' in str(excinfo.value)

# Generated at 2022-06-25 10:23:09.667474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(['DEFAULT_BECOME_USER'])
    assert result[0] == 'root'



# Generated at 2022-06-25 10:23:12.247084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    ret = lookup_module_1.run(["ANSIBLE_CONFIG"])
    assert ret == ['/etc/ansible/ansible.cfg']

# Generated at 2022-06-25 10:23:17.837339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_1 = ['default_cache_plugin']
    var_2 = 'PATH'
    var_3 = 'module_utils'
    var_4 = 'DEFAULT_ROLES_PATH'
    var_5 = 'DEFAULT_ROLES_PATH'
    var_6 = 'DEFAULT_ROLES_PATH'
    var_7 = 'DEFAULT_ROLES_PATH'
    result_1 = lookup_module_0.run(term_1, var_2, var_3, var_4, var_5, var_6, var_7)


# Generated at 2022-06-25 10:23:29.266549
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:23:44.575296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert callable(getattr(lookup_module_0, 'run'))

# Generated at 2022-06-25 10:23:49.743006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_ROLES_PATH']
    lookup_module_0.run(terms_0)
    terms_1 = ['RETRY_FILES_SAVE_PATH']
    lookup_module_0.run(terms_1)
    terms_2 = ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    lookup_module_0.run(terms_2)
    terms_3 = ['UNKNOWN']
    lookup_module_0.run(terms_3)


# Generated at 2022-06-25 10:23:56.985848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_RETRY_FILES_ENABLED', 'DEFAULT_STDOUT_CALLBACK']
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    with pytest.raises(AnsibleError, match=r'^Unable to load shell plugin "sh"$'):
        assert lookup_module.run(terms, **kwargs) == []



# Generated at 2022-06-25 10:23:59.933206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    #assert test_case_0() == expected_output


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:24:06.620230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options()
    lookup_module_1._display.display = mock_display()
    lookup_module_1._templar.template = mock_template()
    lookup_module_1._templar._available_variables = mock__available_variables()
    lookup_module_1.get_option = mock_get_option()
    assert lookup_module_1.run(['DEFAULT_BECOME_USER']) == ['root']


# Generated at 2022-06-25 10:24:13.519005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['DEFAULT_BECOME_USER']
    variables_0 = {}
    kwargs_0 = {'on_missing': 'error', 'plugin_type': Sentinel, 'plugin_name': Sentinel}

    try:
        result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except (AnsibleLookupError, AnsibleOptionsError) as e:
        result = e.message
    assert result == "Unable to find setting DEFAULT_BECOME_USER"

# Generated at 2022-06-25 10:24:16.593188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = list()
    terms.append('DEFAULT_REMOTE_TMP')
    terms.append('DEFAULT_ROLES_PATH')
    terms.append('ANSIBLE_REMOTE_TMP')
    terms.append('ANSIBLE_ROLES_PATH')
    lookup_module_0.run(terms)

# Generated at 2022-06-25 10:24:20.590383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['term', 'term']
    variables = None
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) == []


# Generated at 2022-06-25 10:24:31.333951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with required args
    term = "DEFAULT_BECOME_USER"
    variables = 'some_string'
    result = lookup_module_0.run(terms=term, variables=variables)
    assert result == ['root']
    # Test with on_missing
    term = "DEFAULT_BECOME_USER_new"
    variables = 'some_string'
    on_missing = 'skip'
    result = lookup_module_0.run(terms=term, variables=variables, on_missing=on_missing)
    assert result == []
    term = "DEFAULT_BECOME_USER_new"
    variables = 'some_string'
    on_missing = 'warn'

# Generated at 2022-06-25 10:24:42.311525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    look_var = "DEFAULT_NETCONF_PORT"
    look_val = 830
    when_missing = "error"
    look_plugin_type = "netconf"
    look_plugin_name = "netconf"

    lookup_module.set_loader_for_testing('lookup_plugin', 'netconf')
    plugin_loader.netconf_loader.get.return_value = None  # force "missing plugin" error

    with pytest.raises(AnsibleLookupError) as error_info:
        lookup_module.run(look_var, None, on_missing=when_missing, plugin_type=look_plugin_type, plugin_name=look_plugin_name)

    # Test for successful scenario


# Generated at 2022-06-25 10:25:13.222258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Configuration parameters and expected results.
    DEFAULT_BECOME_USER = lookup_module_0.run(["DEFAULT_BECOME_USER"])
    assert DEFAULT_BECOME_USER == ['root']
    print ("PASS: DEFAULT_BECOME_USER defined properly")
    DEFAULT_ROLES_PATH = lookup_module_0.run(["DEFAULT_ROLES_PATH"])
    assert DEFAULT_ROLES_PATH == ["/etc/ansible/roles", "/usr/share/ansible/roles"]
    print ("PASS: DEFAULT_ROLES_PATH defined properly")
    RETRY_FILES_SAVE_PATH = lookup_module_0.run(["RETRY_FILES_SAVE_PATH"])

# Generated at 2022-06-25 10:25:15.422543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run(terms=["term_0"], variables=None, **dict(on_missing="error")) == []


# Generated at 2022-06-25 10:25:24.417604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
        'RETRY_FILES_SAVE_PATH'
    ]
    variables_1 = None
    ret_0 = lookup_module_1.run(terms_1, variables=variables_1)
    if ret_0[0] != 'root':
        raise AssertionError("Unexpected value %s" % ret_0[0])
    elif ret_0[1] != '/etc/ansible/roles:/usr/share/ansible/roles:/usr/local/share/ansible/roles:/usr/share/ansible/plugins/modules/roles:/home/bobby/.ansible/plugins/modules/roles':
        raise

# Generated at 2022-06-25 10:25:29.809044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["lookup_module_0", "lookup_module_0", "lookup_module_0"]
    variables_0 = None
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == []


# Generated at 2022-06-25 10:25:39.521914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Testing case
    #
    #
    # vars:
    #   terms:
    #     - ANSIBLE_FORKS
    #   variables:
    #     {'ANSIBLE_FORKS': 5}
    #   kwargs:
    #     {'on_missing': 'error', 'plugin_type': None, 'plugin_name': None}
    # result ('terms')
    #   5
    #

    # from ansible.parsing.dataloader import DataLoader
    # data_loader = DataLoader()
    #
    # from ansible.vars.manager import VariableManager
    # variable_manager = VariableManager()
    #
    # terms = data_loader.load_from_file("test_cases/test_case_0/terms")


# Generated at 2022-06-25 10:25:41.450590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.run('unittest')




# Generated at 2022-06-25 10:25:45.144497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    assert lookup_module_0.run(['foo'], None, **{'on_missing': 'warn'}) is None

# Generated at 2022-06-25 10:25:48.035383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # exception thrown when space does not match
    assertEqual(lookup_module_0.run('COLOR_OK'), [])

# Generated at 2022-06-25 10:25:51.197244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'plugin_name': 'httpapi', 'plugin_type': 'httpapi'})
    terms = 'httpapi_auth_uri'
    variables = {}
    lookup_module_0.run(terms, variables)
    assert True


# Generated at 2022-06-25 10:25:54.569988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Call method run of class LookupModule
    lookup_module_0.run(terms=[])
    # Call method run of class LookupModule
    lookup_module_0.run(terms=[], variables=None)
    # Call method run of class LookupModule
    lookup_module_0.run(terms=[], variables=None, **kwargs)

# Generated at 2022-06-25 10:26:49.764573
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    ret = lookup_module.run(["DEFAULT_ROLES_PATH"])
    print('test_LookupModule_run:', ret)

# Generated at 2022-06-25 10:26:52.277338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:26:56.521626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    ret = lookup_module_1.run(['DEFAULT_ROLES_PATH'], variables=None)
    assert ret == ['/etc/ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-25 10:27:05.875620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(direct=dict(on_missing="error",plugin_type="",plugin_name=""))

    terms_0 = ['DEFAULT_BECOME_USER']
    lookup_module_2 = test_case_0()

    test_exception = None
    try:
        lookup_module_1.run(terms_0, variables=None, **{'on_missing': 'error', 'plugin_type': '', 'plugin_name': ''})
    except Exception as exception:
        test_exception = exception

    assert test_exception is None, "Method run of lookup_module raised exception unexpectedly."


# Generated at 2022-06-25 10:27:08.115745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == []

# Generated at 2022-06-25 10:27:12.802329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l_obj=LookupModule()
    assert not l_obj.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'])
    assert not l_obj.run(terms=['DEFAULT_ROLES_PATH'])
    assert not l_obj.run(terms=['DEFAULT_BECOME_USER'])


test_LookupModule_run()

# Generated at 2022-06-25 10:27:17.339237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={'plugin_name': None, 'plugin_type': None, 'on_missing': 'error'})
    lookup_module_0.run(['DEFAULT_VAULT_PASSWORD_FILE'], {})

# Generated at 2022-06-25 10:27:20.696474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    new_module = LookupModule()
    new_module.run(["DEFAULT_ROLES_PATH"])

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:27:26.696236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['GMT TIME']
    variable = None
    kwargs = {"on_missing":"error"}
    lookup_module_0 = LookupModule()
    try:
        res = lookup_module_0.run(terms, variable, **kwargs)
        print(res)
    except Exception as err:
        print('Error happened: %s' % err )


# Generated at 2022-06-25 10:27:33.924665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    import ansible.plugins.loader as plugin_loader
    from ansible.utils.unsafe_proxy import wrap_var
    ret_Boolean = False
    ret_str = ""
    ret_List = []
    terms_List = []
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(None)
    lookup_module_0.set_environment(None)
    lookup_module_0.set_basedir(None)
    from ansible.parsing.dataloader import DataLoader
    data_loader_1 = DataLoader()
    lookup_module_0.set_loader(data_loader_1)

# Generated at 2022-06-25 10:29:26.971599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables=None
    kwargs = {
        'on_missing': 'error',
    }
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == []


# Generated at 2022-06-25 10:29:29.130487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(['COLOR_WARN'], Sentinel, None)
    assert result == ['yellow']

# Generated at 2022-06-25 10:29:31.727416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = 'DEFAULT_BECOME_USER'
    variables_1 = None
    ret = lookup_module_1.run(terms_1, variables_1)
    assert ret[0] == 'root'


# Generated at 2022-06-25 10:29:36.966523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['DEFAULT_REMOTE_TMP']
    variables = {'ansible_connection': 'winrm'}
    kwargs = {'variables': variables}
    result = lookup_module_0.run(
        terms,
        variables=variables,
        **kwargs
    )
    assert result == [u'$HOME/.ansible/tmp']



# Generated at 2022-06-25 10:29:37.551092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:29:42.267304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [Sentinel]
    variables_0 = Sentinel
    kwargs_0 = dict(plugin_type=Sentinel)
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result == [], "Expected [], got {}".format(result)

# Generated at 2022-06-25 10:29:47.314562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule -> run
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []
    assert lookup_module_1.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module_1.run('DEFAULT_BECOME_USER') == ['root']
    assert lookup_module_1.run("DEFAULT_BECOME_USER") == ['root']
    #assert lookup_module_1.run(terms=["DEFAULT_BECOME_USER"]) == ['root']
    #assert lookup_module_1.run(DEFAULT_BECOME_USER) == ['root']

# Generated at 2022-06-25 10:29:50.490584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['foo']
    variables = {'a': 'b'}
    pytest.raises(AnsibleOptionsError, lookup_module.run, terms, variables)

    terms = ['foo']
    variables = {'a': 'b'}
    pytest.raises(AnsibleOptionsError, lookup_module.run, terms, variables, plugin_type='foo')


# Generated at 2022-06-25 10:29:54.050211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(DEFAULT_ROLES_PATH=["/etc/ansible/roles"])
    obj = LookupModule()
    retVal = obj.run(terms=args)
    assert retVal == ["/etc/ansible/roles"]


# Generated at 2022-06-25 10:29:58.064923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  ptype = "connection"
  pname = "ssh"
  terms = ["remote_user", "port"]
  lookup_module.run(terms, plugin_type=ptype, plugin_name=pname)

# Generated at 2022-06-25 10:32:23.812938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = var_0
    on_missing_0 = 'warn'