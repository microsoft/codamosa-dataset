

# Generated at 2022-06-21 05:43:07.262240
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_string = 'test_string'
    test_exc = 'test_exc'
    exc = MissingSetting(test_string, orig_exc=test_exc)
    assert exc.message == test_string
    assert exc.orig_exc.message == test_exc.message

# Generated at 2022-06-21 05:43:19.284846
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})

    # Test on_missing for other options than error, warn or skip
    with pytest.raises(AnsibleOptionsError) as error:
        lookup_module.run(terms=['DEFAULT_ROLES_PATH'], on_missing='not_error_warn_skip')

    assert str(error.value) == '"on_missing" must be a string and one of "error", "warn" or "skip", not not_error_warn_skip'

    # Test base_path invalid
    with pytest.raises(AnsibleOptionsError) as error:
        lookup_module.run(terms='DEFAULT_ROLES_PATH', on_missing='')


# Generated at 2022-06-21 05:43:20.071329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 05:43:26.837468
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config_terms = ['COLOR_OK', 'COLOR_WARN', 'COLOR_ERROR']
    lm = LookupModule()
    config_values = lm.run(config_terms)
    assert config_values[0] == 'green'
    assert config_values[1] == 'yellow'
    assert config_values[2] == 'red'

# Generated at 2022-06-21 05:43:30.935418
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """
    Verify that MissingSetting subclasses AnsibleOptionsError.
    """
    assert issubclass(MissingSetting, AnsibleOptionsError)


# Generated at 2022-06-21 05:43:34.445949
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test error')
    except MissingSetting as e:
        assert e.__class__.__name__ == 'MissingSetting'

# Generated at 2022-06-21 05:43:46.416618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            terms=dict(type='list'),
        )
    )

    module.params['terms'] = ['RETRY_FILES_ENABLED']
    ansible_config = C
    plugin_loader.connection_loader.get('local')
    plugin_loader.shell_loader.get('command')
    lm = LookupModule()
    result = lm.run(terms=module.params['terms'])
    assert result == [True]

    # Test case 2
    module.params['terms'] = ['RETRY_FILES_ENABLED', 'UNKNOWN']
    result = lm.run(terms=module.params['terms'], on_missing='error')
   

# Generated at 2022-06-21 05:43:53.946746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        LookupModule().run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'])
        LookupModule().run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables = {'DEFAULT_ROLES_PATH': '~/roles'})
        LookupModule().run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], plugin_type="become", plugin_name="sudo")
        LookupModule().run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], plugin_type="become", plugin_name="sudo", variables = {'DEFAULT_ROLES_PATH': '~/roles'})
    except:
        assert False

# Generated at 2022-06-21 05:44:00.790830
# Unit test for constructor of class LookupModule
def test_LookupModule():
    arg_dict = dict(
        _terms= ['port'],
        on_missing= 'error',
        plugin_type= 'connection',
        plugin_name= 'ssh',
    )

    my_lookup = LookupModule()

    my_lookup.run(terms=arg_dict['_terms'], variables=None, on_missing=arg_dict['on_missing'], plugin_type=arg_dict['plugin_type'], plugin_name=arg_dict['plugin_name'])

# Generated at 2022-06-21 05:44:04.170556
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'this is a test'
    orig_exc = KeyError('this is original exception')
    ex = MissingSetting(msg)
    assert msg == ex.message
    assert ex.orig_exc is None

    ex2 = MissingSetting(msg, orig_exc)
    assert msg == ex2.message
    assert orig_exc == ex2.orig_exc

# Generated at 2022-06-21 05:44:18.582060
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible import errors
    try:
        raise errors.AnsibleError("Foo Bar")
    except errors.AnsibleError as e:
        # Test constructor
        try:
            raise MissingSetting("Foo Bar", orig_exc=e)
        except MissingSetting as e:
            assert e.msg == "Foo Bar"
            assert e._orig_exc.msg == "Foo Bar"
            assert isinstance(e, errors.AnsibleError)

# Generated at 2022-06-21 05:44:25.112933
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test', orig_exc=Exception('Test Exception'))
    except MissingSetting as e:
        assert e.orig_exc.args[0] == 'Test Exception'
        assert e.message == 'Test'

# Generated at 2022-06-21 05:44:26.539926
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert isinstance(MissingSetting("hello"), MissingSetting)

# Generated at 2022-06-21 05:44:29.551083
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    catch = None
    try:
        raise MissingSetting()
    except MissingSetting as e:
        catch = repr(e)
    assert catch == "AnsibleOptionsError('',)"

# Generated at 2022-06-21 05:44:33.431436
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test')
    except Exception as e:
        assert isinstance(e, MissingSetting)
        assert 'Test' in str(e)

# Generated at 2022-06-21 05:44:42.145410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['FOO'], on_missing='error') == []
    assert lookup.run(['FOO'], on_missing='warn') == []
    assert lookup.run(['FOO'], on_missing='skip') == []
    assert lookup.run(['FOO', 'BAR'], on_missing='error') == []
    assert lookup.run(['FOO', 'BAR'], on_missing='warn') == []
    assert lookup.run(['FOO', 'BAR'], on_missing='skip') == []

# Generated at 2022-06-21 05:44:46.940154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup_module = LookupModule()
    assert lookup_module.run(["DEFAULT_BECOME_USER"]) == [u'root']

# Generated at 2022-06-21 05:44:49.493220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 05:44:59.141055
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

# Generated at 2022-06-21 05:45:06.102227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_global_config(config):
        global dict_config
        return dict_config.get(config, [])

    def _get_plugin_config(pname, ptype, config, variables):
        global dict_config
        plugin_name = ptype + '_' + pname
        dict_plugin = dict_config.get(plugin_name, {})
        return dict_plugin.get(config, [])

    global dict_config

# Generated at 2022-06-21 05:45:20.092630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 05:45:23.727778
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("A test error message")
    except:
        pass
    try:
        raise MissingSetting("A test error message", "A test orig_exc")
    except:
        pass

# Generated at 2022-06-21 05:45:35.400505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Testing run() when all parameters are correct
    expected = ['stat', 'logfile', 'splay', 'fact-caching', 'task-caching', 'gathering', 'fact-caching-connection',
                'fact-caching-prefix', 'vault_password_file']
    terms = ['DEFAULT_GATHER_SUBSET', 'DEFAULT_GATHERING', 'DEFAULT_CACHE_PLUGIN', 'DEFAULT_CACHE_PLUGIN_CONNECTION',
             'DEFAULT_CACHE_PLUGIN_PREFIX', 'DEFAULT_VAULT_PASSWORD_FILE']

    # AssertionError if expected != result
    assert module.run(terms) == expected

    # Testing run() when list of terms is empty
    expected = []
    terms

# Generated at 2022-06-21 05:45:40.601082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    result = lookup_module.run(terms, variables)
    print(result)

# Generated at 2022-06-21 05:45:42.280822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run(['host_key_checking'], C.base_vars, on_missing='warn')

    assert result == ['False']

# Generated at 2022-06-21 05:45:43.220838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ut = LookupModule()
    ut.run([], [])

# Generated at 2022-06-21 05:45:44.604862
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 05:45:47.103982
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 05:45:58.876415
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.vars import combine_vars

    variables = combine_vars(dict(), dict())
    lookup_plugin = LookupModule()
    lookup_plugin.run(terms=['DEFAULT_BECOME'], variables=variables)
    lookup_plugin.set_options(var_options=variables, direct=dict())
    lookup_plugin.run(terms=['DEFAULT_BECOME'], variables=variables)    
    lookup_plugin.set_options(var_options=variables, direct=dict())
    lookup_plugin.run(terms=['DEFAULT_BECOME'], variables=variables, on_missing='error')    
    lookup_plugin.set_options(var_options=variables, direct=dict())

# Generated at 2022-06-21 05:46:09.104835
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    try:
        raise MissingSetting('oops')
    except MissingSetting as e:
        # Test if __cause__ is the same as orig_exc
        assert e.orig_exc is e.__cause__
        # Test if __str__ is the same as message
        assert str(e) == e.message
        # Test if __str__ is different than orig_exc
        assert str(e) != str(e.orig_exc)
    except Exception as generic:
        # If it catches everything, then __cause__ is not the same as orig_exc
        assert False
    else:
        # If it did not catch Exception, then orig_exc is not defined
        assert False

# Generated at 2022-06-21 05:46:42.639980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' unit test for lookup/config.py:LookupModule#run '''
    from ansible.utils import context_objects as co
    from ansible.parsing.dataloader import DataLoader

    myloader = DataLoader()
    myvars = {}
    myco = co.VariableManager()
    myco.set_loader(myloader)

    myplugin = LookupModule()
    myplugin._display = co.Display()
    myplugin._display.verbosity = 3
    myplugin._templar = co.Templar(loader=myloader, variables=myvars)
    myplugin._loader = myloader
    myplugin._templar.set_available_variables(myvars)


# Generated at 2022-06-21 05:46:45.848429
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.run
    #  assert module.run('DEFAULT_BECOME_USER') == ['root']

# Generated at 2022-06-21 05:46:49.943446
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test error')
    except MissingSetting as e:
        assert e.message == 'test error'

# Note: These are not unit tests, but a way to provide example of configuration options


# Generated at 2022-06-21 05:46:54.763103
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # If this test raises an exception, something is wrong with the class definition
    foo = MissingSetting('missing something')
    assert foo.message == 'missing something'
    assert not foo.orig_exc

# Generated at 2022-06-21 05:47:03.680817
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test with no arguments
    try:
        raise MissingSetting()
    except MissingSetting as e:
        assert "No configuration value found for the setting" in to_native(e)
        assert to_native(e) == 'No configuration value found for the setting'

    # Test with a single string argument
    try:
        raise MissingSetting('SETTING_NAME')
    except MissingSetting as e:
        assert "No configuration value found for the setting SETTING_NAME" in to_native(e)
        assert to_native(e) == 'No configuration value found for the setting SETTING_NAME'

    # Test with a single integer argument
    try:
        raise MissingSetting(1234)
    except MissingSetting as e:
        assert "No configuration value found for the setting '1234'" in to_native(e)

# Generated at 2022-06-21 05:47:04.138154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert cls

# Generated at 2022-06-21 05:47:09.072699
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'This is a test error message'
    orig_exc = 'This is a test original exception'
    test_obj = MissingSetting(msg, orig_exc)
    assert msg in str(test_obj)
    assert orig_exc is test_obj.orig_exc

# Generated at 2022-06-21 05:47:17.155125
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # a helper function to test run method of LookupModule
    def run_test_case(terms, variables, plugin_type=None, plugin_name=None, on_missing='error', expected=None):
        l = LookupModule()
        l.set_loader(plugin_loader)
        l.set_options({'plugin_type': plugin_type, 'plugin_name': plugin_name, 'on_missing': on_missing, 'var_options': variables})

        if expected is not None:
            if not isinstance(expected, list):
                raise Exception('expected message should be a list')

            result = l.run(terms, variables)

# Generated at 2022-06-21 05:47:25.465210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Set options
    lookup_module.set_options({'_ansible_opts': None, '_ansible_check_mode': False, '_ansible_debug': False, '_ansible_diff': False})

    # Run the run method with some data
    lookup_module.run(['DEFAULT_BECOME_USER'])

    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], {}, plugin_name='sh', plugin_type='shell') == ['root', '/etc/ansible/roles:/usr/share/ansible/roles']
    assert lookup_module.run([], {}, plugin_name='sh', plugin_type='shell') == []
    assert lookup_

# Generated at 2022-06-21 05:47:26.900169
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-21 05:48:18.900716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

if __name__ == "__main__":
    test_LookupModule()

# Generated at 2022-06-21 05:48:23.120153
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('some text', orig_exc=None)
    assert missing_setting.message == 'some text'
    assert missing_setting.orig_exc is None

# Generated at 2022-06-21 05:48:32.775249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleOptionsError, match="Missing required options: plugin_type, plugin_name"):
        LookupModule().run(["remote_tmp"], plugin_type="shell")

    with pytest.raises(AnsibleOptionsError, match="Both plugin_type and plugin_name are required, cannot use one without the other"):
        LookupModule().run(["remote_tmp"], plugin_name="sh")

    with pytest.raises(AnsibleOptionsError, match="'on_missing' must be a string and one of "):
        LookupModule().run(["remote_tmp"], plugin_type="shell", plugin_name="sh", on_missing=1)


# Generated at 2022-06-21 05:48:37.391611
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err_str = 'Test error'
    err_exc = Exception('Test exception')
    error = MissingSetting(err_str, err_exc)
    assert error.args[0] == err_str and error.orig_exc == err_exc

# Generated at 2022-06-21 05:48:50.386098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # test with a setting with value
    assert lm.run(['DEFAULT_BECOME_USER']) == ['root']
    # test with a setting with no value
    assert lm.run(['DEFAULT_CACHE_PLUGIN']) == [None]
    # test with a setting with callable
    assert lm.run(['DEFAULT_STDOUT_CALLBACK']) == ['default']
    # test with a non existing setting
    try:
        assert lm.run(['foo'])
        assert False, 'non existing setting should raise AnsibleLookupError'
    except AnsibleLookupError:
        pass
    # test with a setting with callable

# Generated at 2022-06-21 05:48:55.333133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lm = LookupModule()
  lm.run(["DEFAULT_ROLES_PATH"])
  assert lm.run(["UNKNOWN_ROLES_PATH"]) == []

# Generated at 2022-06-21 05:49:01.006101
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    try:
        module.run(terms)
    except AnsibleLookupError as e:
        assert e.orig_exc.__class__.__name__ == 'AttributeError'
        assert e.orig_exc.args[0] == "'Sentinel' object has no attribute 'append'"

# Generated at 2022-06-21 05:49:08.118159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test case for testing the lookup.run method"""

    class FakeVarMgr(object):
        def __init__(self):
            self.vars = {}

    class FakeDisplay(object):
        def __init__(self):
            self.warns = []

        def warning(self, msg):
            self.warns.append(msg)

    class FakeOptions(object):
        def __init__(self):
            self.var_options = {}

    class FakeLookup(LookupModule):
        def __init__(self):
            self.prompts = []

        def prompt(self, prompt, private=True):
            self.prompts.append(prompt)
            return "pass"

    fake_lookup = FakeLookup()

    fake_lookup.display = FakeDisplay()
    fake_

# Generated at 2022-06-21 05:49:14.997985
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    error_msg = 'test MissingSetting exception'

    try:
        raise AnsibleLookupError(error_msg)
    except AnsibleLookupError as e:
        exception = MissingSetting(e, orig_exc=e)

    assert exception.orig_exc.message == error_msg

# Generated at 2022-06-21 05:49:17.919602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.__class__.__name__ == 'LookupModule'


# Generated at 2022-06-21 05:51:12.508349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import Ansible config to override internal config for testing
    import ansible.constants as C
    C.DEFAULT_ANSIBLE_CONFIG = "tests/unit/modules/lookup/config.yml"
    C.DEFAULT_GATHERING = 'implicit'


# Generated at 2022-06-21 05:51:14.605544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor should not raise any exceptions
    l = LookupModule()


# Generated at 2022-06-21 05:51:18.972634
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Use these lines to run a test while developing
    # plugin = LookupModule()
    # import json
    # print(json.dumps(plugin.run(['DEFAULT_BECOME_USER'], {'_ansible_syslog_facility': 'LOG_USER'}, on_missing='warn'), indent=4))
    assert True

# Generated at 2022-06-21 05:51:22.294471
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.six import assertRaisesRegex
    with assertRaisesRegex(Exception, 'error message'):
        raise MissingSetting('error message')

# Generated at 2022-06-21 05:51:25.267384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the default value for the 'on_missing' option must be 'error'
    assert LookupModule.run.__defaults__[0] == 'error'

# Generated at 2022-06-21 05:51:37.257261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Default value for argument terms
    terms = ''
    # Default value for argument variables
    variables = ''
    # Default value for argument kwargs
    kwargs = dict()
    # Default value for option on_missing
    on_missing = 'error'
    # Default value for option plugin_type
    plugin_type = ''
    # Default value for option plugin_name
    plugin_name = ''
    kwargs['plugin_type'] = plugin_type
    kwargs['plugin_name'] = plugin_name
    kwargs['on_missing'] = on_missing
    module.run(terms, variables, **kwargs)

# Generated at 2022-06-21 05:51:48.717530
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Set up a configuration to be used for constructing LookupModule object
    test_config = {
        'on_missing': 'warn',
        'plugin_type': 'cliconf',
        'plugin_name': 'ios',
    }
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct=test_config)
    assert lookup_plugin.get_option('on_missing') == 'warn'
    assert lookup_plugin.get_option('plugin_type') == 'cliconf'
    assert lookup_plugin.get_option('plugin_name') == 'ios'


# Generated at 2022-06-21 05:51:52.186216
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting("AnsibleLookupError", orig_exc="AnsibleLookupError")

# Generated at 2022-06-21 05:51:59.831548
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Because we don't have the full logic, just run the code and make sure we get the
    # expected exception
    try:
        raise MissingSetting('MESSAGE')
    except MissingSetting as e:
        assert e.args[0] == 'MESSAGE'

    try:
        raise MissingSetting('MESSAGE', 'VALUE', 'ARG')
    except MissingSetting as e:
        assert e.args[0] == 'MESSAGE'
        assert e.args[1] == 'VALUE'
        assert e.args[2] == 'ARG'

# Generated at 2022-06-21 05:52:03.418224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    lookup_module = LookupModule()
    lookup_module.set_options({'plugin_type': 'shell', 'plugin_name': 'sh'})
    result_iterable = lookup_module.run(['remote_tmp'])
    result = next(result_iterable)
    assert result == '$HOME/.ansible/tmp'