

# Generated at 2022-06-21 05:43:07.213396
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test default values of options
    lookup_obj = LookupModule()

    # Test option validation
    terms = [10]

    try:
        lookup_obj.run(terms=terms)
    except AnsibleOptionsError as e:
        assert "Invalid setting identifier" in '{0}'.format(e)

    # Test options error for invalid on_missing option
    variables = dict()
    variables['on_missing'] = 'skip1'
    lookup_obj = LookupModule()
    try:
        lookup_obj.run(terms=terms, variables=variables)
    except AnsibleOptionsError as e:
        assert "one of \"error\", \"warn\" or \"skip\"" in '{0}'.format(e)

    # Test options error for using plugin_type without plugin_name
    variables = dict()

# Generated at 2022-06-21 05:43:09.823951
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(terms="foo") == []

# Generated at 2022-06-21 05:43:11.806561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup
    assert repr(lookup) == '<ansible.plugins.lookup.config.LookupModule object at 0x%x>' % id(lookup)



# Generated at 2022-06-21 05:43:13.849578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert isinstance(module, LookupBase)

# Generated at 2022-06-21 05:43:15.893585
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup_plugin = LookupModule()
   assert lookup_plugin

# Generated at 2022-06-21 05:43:22.879605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lm = LookupModule(loader=loader)
    assert len(lm.run(['action_plugins'], dict())) == 1
    assert len(lm.run(['action_plugins', 'lib_plugins'], dict())) == 2


# Generated at 2022-06-21 05:43:25.431887
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting("message")
    assert "message" == exc.message
    assert "message" == str(exc)

# Generated at 2022-06-21 05:43:29.803278
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mc_map = { 'DEFAULT_BECOME_USER': 'root' }
    mc_map.update(C.__dict__)
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    LookupModule(basedir=None, runner=None, paths=None, variables=mc_map)

# Generated at 2022-06-21 05:43:41.622435
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    # Both 'msg' and 'orig_exc' args provided
    m = MissingSetting('msg_value', orig_exc='an exception')
    # Both 'msg' and 'orig_exc' args provided and 'orig_exc' is NOT an instance AnsibleError
    m2 = MissingSetting('msg_value', orig_exc='another exception')
    m3 = MissingSetting('msg_value')
    assert m.msg == 'msg_value'
    assert m.orig_exc.__name__ == 'AnsibleError'
    assert m2.msg == 'msg_value'
    assert m2.orig_exc == 'another exception'
    assert m3.msg == 'msg_value'
    assert m3.orig_exc == None

# Generated at 2022-06-21 05:43:45.289395
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    message = 'Unable to find setting'
    exc = None
    constructor = lambda x: MissingSetting(exc)
    missing = MissingSetting(message, exc)
    assert message == missing.message

# Generated at 2022-06-21 05:43:57.131826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(["COLOR_OK"]) == [C.COLOR_OK]
    assert lm.run(["REMOTE_TMP"]) == [C.DEFAULT_REMOTE_TMP]
    assert lm.run(["non_existing_item"]) == []

# Generated at 2022-06-21 05:43:59.099173
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_set = MissingSetting()
    assert missing_set.message is not None
    assert missing_set.orig_exc is None

# Generated at 2022-06-21 05:44:02.013844
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('msg')
    except MissingSetting as e:
        assert 'msg' == to_native(e)

# Generated at 2022-06-21 05:44:04.668057
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Did not find setting'
    e = AnsibleOptionsError(msg)

    with pytest.raises(AnsibleLookupError) as err:
        raise MissingSetting(msg, orig_exc=e)
    assert msg in str(err)

# Generated at 2022-06-21 05:44:11.956876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m.run('DEFAULT_ROLES_PATH') == ['/etc/ansible/roles:/usr/share/ansible/roles']
    assert m.run(['DEFAULT_ROLES_PATH', 'DEFAULT_CALLBACK_WHITELIST'], variables={'foo': 'bar'}) == ['/etc/ansible/roles:/usr/share/ansible/roles', 'stdout,timer']
    assert m.run('DEFAULT_BECOME_USER', variables={'foo': 'bar'}) == ['root']
    assert m.run('BAD_KEY', variables={'foo': 'bar'}, on_missing='skip') == []
    assert m.run('BAD_KEY', variables={'foo': 'bar'}, on_missing='error') == []


# Generated at 2022-06-21 05:44:13.464976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return_lookup_module = LookupModule()
    assert return_lookup_module is not None


# Generated at 2022-06-21 05:44:21.382379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    lm = lookup_loader._create_lookup_instance('config')
    assert lm is not None

    # tests invalid input for plugin_type and plugin_name option
    try:
        lm.run(terms=['remote_user'], variables=dict(), plugin_name='ssh')
    except AnsibleOptionsError as e:
        assert to_native(e) == 'Both plugin_type and plugin_name are required, cannot use one without the other'

    # tests invalid input for on_missing option

# Generated at 2022-06-21 05:44:24.240217
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-21 05:44:26.251750
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting('msg')
    assert result.message == 'msg'

# Generated at 2022-06-21 05:44:29.392771
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = """Error in config: Invalid setting name: 'log_path'. The setting 'log_path' was not defined."""
    m = MissingSetting(msg)
    assert m.msg == msg

# Generated at 2022-06-21 05:44:50.189686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = "test"
    lo = LookupModule()
    lo.set_options(direct={'plugin_name':'ssh', 'plugin_type': 'connection'})
    ret = lo.run(["remote_user"], variables=None, on_missing='skip')
    assert(ret[0] == 'root')

# Generated at 2022-06-21 05:45:01.232298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.plugins.loader import lookup_loader

    con_instance = context.CLIARGS._store['connection']
    context.CLIARGS._store['connection'] = 'network_cli'

    lookup_plugin = lookup_loader.get('config')
    assert lookup_plugin.lookup({'_terms': 'remote_user', 'plugin_type': 'connection', 'plugin_name': 'network_cli', 'on_missing': 'error'}) == 'ansible'

    context.CLIARGS._store['connection'] = con_instance

# Generated at 2022-06-21 05:45:05.578816
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lm = LookupModule()
    except Exception:
        print('Failed to create instance of LookupModule.')


# Generated at 2022-06-21 05:45:16.903686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Creating the objects
    lookup_obj = LookupModule()
    display_obj = lookup_obj._display

    # Test case when the given plugin type and name are present
    ptype = "cliconf"
    pname = "eos"

    # Test case when the given plugin name is not present
    ptype1 = "cliconf"
    pname1 = "eos1"

    # Test case when the given plugin type and name are not present
    ptype2 = "cliconf1"
    pname2 = "eos1"

    # Test case when the given plugin type and name are present but the lookup value is not present
    ptype3 = "cliconf"
    pname3 = "eos"
    lterm = "cisco_ios"

    # Test case when the given plugin type and name are present

# Generated at 2022-06-21 05:45:23.727545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        plugin_type='shell',
        plugin_name='sh',
    )
    want = None
    result = LookupModule().run(terms=['shell_executable'], **args)[0]
    assert result == want

# Generated at 2022-06-21 05:45:25.190799
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    dummy_obj = MissingSetting('dummy')
    assert dummy_obj.orig_exc == None

# Generated at 2022-06-21 05:45:26.384135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert isinstance(lk, LookupModule)

# Generated at 2022-06-21 05:45:28.920313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert type(lookup_plugin) == LookupModule

# Generated at 2022-06-21 05:45:32.560815
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert 'config' == lm.lookup_plugin.name
    assert 'Lookup module for retrieving Ansible configuration settings' == lm.lookup_plugin.short_help

# Generated at 2022-06-21 05:45:34.521806
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("bad setting")
    assert(str(e) == "bad setting")

# Generated at 2022-06-21 05:46:04.070133
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert hasattr(a, 'run')

# Generated at 2022-06-21 05:46:11.872329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: this test will fail if run from "working directory = tests"
    # note: option -vvvv or higher required to display debug statements
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'_terms': ['action_plugins'], 'verbosity': 4})
    # test a single term (as a string)
    assert lookup_module.run(['action_plugins'], variables={}) == ['/usr/share/ansible_plugins/action_plugins', '/usr/lib/python2.7/site-packages/ansible/plugins/action']
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'_terms': ['action_plugins', 'callback_plugins'], 'verbosity': 4})

# Generated at 2022-06-21 05:46:17.156867
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Method run has one argument but we need to count the default argument
    # pylint: disable=unexpected-keyword-arg
    # This is a loadable plugin so it might not be loaded
    # pylint: disable=no-member
    assert LookupModule().run([], wantlist=True) == []

# Generated at 2022-06-21 05:46:25.013842
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        l = LookupModule()
        l.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
        assert l.get_option('plugin_type') == 'connection'
        assert l.get_option('plugin_name') == 'local'
    except Exception:
        assert False, "LookupModule() failed"

# Generated at 2022-06-21 05:46:29.378093
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test error message'
    exc = AnsibleOptionsError(msg)
    try:
        raise MissingSetting(msg, orig_exc=exc)
    except MissingSetting as e:
        assert msg == e.message
        assert exc == e.orig_exc

# Generated at 2022-06-21 05:46:38.458272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader()
    terms = ('DEFAULT_ROLES_PATH',)
    variables = {}
    config = {}
    ret = lookup_module.run(terms, variables, config=config)
    assert(isinstance(ret, list))
    assert(ret[0] == lookup_module._loader.path_dwim('desktop/roles'))

    terms = ('DEFAULT_ROLES_PATH', 'DEFAULT_REMOTE_TEMP')
    ret = lookup_module.run(terms, variables, config=config)
    assert(isinstance(ret, list))
    assert(ret[0] == lookup_module._loader.path_dwim('desktop/roles'))
    assert(ret[1] == '~/.ansible/tmp')

   

# Generated at 2022-06-21 05:46:49.649653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import connection_loader
    lookup_plugin = lookup_loader._create_lookup_plugin(LookupModule, 'config', None)
    connection_plugin = connection_loader._create_loader_plugin(connection_loader.get('local', class_only=True), 'local', None)
    assert lookup_plugin._get_plugin_config(connection_plugin._load_name, 'connection', 'executable', None) is not Sentinel
    lookup_plugin.set_options({'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'warn'})
    lookup_plugin._display.warning = lambda msg: ''
    assert lookup_plugin.run(['executable'])

# Generated at 2022-06-21 05:46:51.326140
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-21 05:47:02.923343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.basic as basic
    from ansible.parsing.yaml.loader import AnsibleLoader

    import os
    import sys
    import logging
    from types import ModuleType
    from ansible.utils.display import Display
    from ansible.utils import context_objects as co

    class FakeLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            self.msgs = []
            logging.Logger.__init__(self, *args, **kwargs)


# Generated at 2022-06-21 05:47:09.438413
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting(msg='test', orig_exc=None)
    assert isinstance(err, AnsibleOptionsError)
    assert err.message == "The config value 'test' was not defined."
    assert err.orig_exc is None
    assert str(err) == "The config value 'test' was not defined."

# Generated at 2022-06-21 05:47:38.771467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-21 05:47:46.718017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.parsing.dataloader
    terms = ['hostfile', 'host_key_checking=False']
    options = {'plugin_type': 'become', 'plugin_name': 'become', 'on_missing': 'error'}
    lookup_plugin = LookupModule(loader=ansible.parsing.dataloader.DataLoader(),
                                 templar=ansible.parsing.dataloader.DataLoader(),
                                 variables={},
                                 **options)
    assert lookup_plugin.run(terms) == []

# Generated at 2022-06-21 05:47:50.920918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert hasattr(lookup_obj, 'run')
    assert hasattr(lookup_obj, 'set_options')
    assert isinstance(lookup_obj, LookupModule)

# Generated at 2022-06-21 05:47:52.640542
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # test correctly constructed object
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:47:58.785343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert 'config' == lookup_plugin.lookup_type
    assert 'Lookup current Ansible configuration values' == lookup_plugin.short_description
    assert 0 < len(lookup_plugin.description)
    assert len(lookup_plugin.options) > 0

    # Verify options_list
    #for key, value in lookup_plugin.options.items():
    #    assert len(value) == 2
    #    assert isinstance(key, str)
    #    assert isinstance(value[0], str)
    #    assert isinstance(value[1], bool)

# Generated at 2022-06-21 05:48:04.516286
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting('Testing', orig_exc=Exception())
    assert isinstance(err, AnsibleOptionsError)
    assert isinstance(err, AnsibleLookupError)
    assert isinstance(err, AnsibleError)
    assert isinstance(err, Exception)
    assert err.msg == 'Testing'

# Generated at 2022-06-21 05:48:09.465769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule) is True, 'test_LookupModule: class LookupModule not instantiated properly'


# Generated at 2022-06-21 05:48:19.315168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils.six import string_types
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    display = Display()
    lookup_loader.get("config", display, InventoryManager(), lookup_loader, VariableManager())

    config = LookupModule(display)

    # Test case 1
    config_terms = ["DEFAULT_BECOME_USER"]
    config_var = { "config_missing" : "error"}

    config_result = [u"root"]

# Generated at 2022-06-21 05:48:25.327827
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Error message'
    orig_exc = 'Original exception'
    m = MissingSetting(msg, orig_exc, 'xxx')
    assert m.message == msg
    assert m.orig_exc == orig_exc
    assert str(m) == 'Error message'

# Generated at 2022-06-21 05:48:27.055826
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    x = MissingSetting('This is a test')
    assert x.message == 'This is a test'
    assert x.orig_exc is None

# Generated at 2022-06-21 05:49:33.464622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test config file
    def test_config_file(tmp_path_factory):
        p = tmp_path_factory.mktemp('unittest')
        config_path = str(p / 'config')

        with open(config_path, 'w') as config_file:
            config_file.write('[defaults]\n')
            config_file.write('remote_user=test_user\n')
            config_file.write('port=5678\n')
            config_file.write('[ssh_connection]\n')
            config_file.write('remote_user=ssh_user\n')
            config_file.write('port=1234\n')

        old_args = C.CLIARGS

# Generated at 2022-06-21 05:49:35.321128
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 05:49:40.498174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check wrong plugin_type
    lookup = LookupModule()
    lookup.set_options(direct={'plugin_type': 'bad',
                               'plugin_name': 'ssh'})
    terms = ["remote_tmp"]
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup.run(terms, variables={})
    assert "Both plugin_type and plugin_name are required, cannot use one without the other" in str(excinfo.value)

    # check wrong plugin_name
    lookup = LookupModule()
    lookup.set_options(direct={'plugin_type': 'shell',
                               'plugin_name': 'bad'})
    terms = ["remote_tmp"]
    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(terms, variables={})


# Generated at 2022-06-21 05:49:43.562075
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup.run(["FOO"], variables=None, **{}) == []

# Generated at 2022-06-21 05:49:46.740355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_HASH_BEHAVIOUR', 'DEFAULT_ROLES_PATH']
    lookup_module.set_loader({'vars': dict(), 'paths': dict()})
    result = lookup_module.run(terms, {})
    assert result[0] == 'replace'
    assert result[1] == ['/etc/ansible/roles', '/usr/share/ansible/roles']



# Generated at 2022-06-21 05:49:55.186731
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_vars = {
        'color': {
            'color_changed': 'purple',
            'color_ok': 'green',
            'color_skipped': 'blue'
        }
    }
    # The last line from color_plugin.py file: LookupBase.register_lookup_plugin(LookupModule)
    # In this test, we want to test constructor of class LookupModule.
    # So, we need to cancel that registration.
    lookup_base = LookupBase()
    lookup_base['color'] = None
    colorme = lookup_base.lookup_loader.get('color')

    terms = ['color_ok', 'color_changed', 'color_skipped']
    colorme.run(terms, my_vars, on_missing='error')

# Generated at 2022-06-21 05:50:06.526176
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Test for LookupModule.run => missing=error
    def check(terms, variables, **kwargs):
        lookup_instance = LookupModule()
        lookup_instance.set_options(var_options=variables, direct=kwargs)
        try:
            lookup_instance.run(terms, variables, **kwargs)
        except AnsibleLookupError as e:
            return False, "AnsibleLookupError: %s" % to_native(e)
        else:
            return True, "No error" if lookup_instance.run(terms, variables, **kwargs) is not None else None

    # basic test
    assert check(['DEFAULT_BECOME_USER'], None, on_missing='error')[0]

    # should fail with error

# Generated at 2022-06-21 05:50:13.016266
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    from ansible.utils.sentinel import Sentinel
    try:
        raise LookupModule.MissingSetting("test_MissingSetting")
    except LookupModule.MissingSetting as e:
        assert(isinstance(e, LookupModule.MissingSetting))
        assert(isinstance(e, AnsibleError))

# Generated at 2022-06-21 05:50:14.475726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})

# Generated at 2022-06-21 05:50:20.668758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test params parsing
    lm = LookupModule()
    _terms = AnsibleLoader(None).load('foo: bar\n')
    lm.run(_terms, variables=dict(foo_bar='bar'))

    lm = LookupModule()
    _terms = AnsibleLoader(None).load('foo: bar\n')
    lm._display.warning = lambda x: x
    lm.get_option = lambda x: 'warn'
    lm.run(_terms, variables=dict(foo_bar='bar'))

    lm = LookupModule()
    _terms = AnsibleLoader(None).load('foo: bar\n')
    lm.get_option = lambda x: 'skip'

# Generated at 2022-06-21 05:52:23.288416
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting("test exception")
    assert(exc.message == "test exception")
    assert(exc.orig_exc is None)

# Generated at 2022-06-21 05:52:25.945942
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting("test")

    assert result.message == "test"
    assert result.orig_exc is None

# Generated at 2022-06-21 05:52:27.969508
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-21 05:52:29.925724
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ansible_config_error = MissingSetting("An error in ansible configuration")
    assert str(ansible_config_error) == "An error in ansible configuration"

# Generated at 2022-06-21 05:52:41.984695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options()
    # test for case where on_missing is not a string and not one of error, warn and skip
    try:
        lookup.run(terms=['DEFAULT_BECOME_USER'], variables={'on_missing': True})
    except AnsibleOptionsError:
        pass
    else:
        assert False
    # test for case where on_missing is set to error
    try:
        lookup.run(terms=['test'], variables={'on_missing': 'error'})
    except AnsibleOptionsError:
        pass
    else:
        assert False
    # test for case where on_missing is set to warn

# Generated at 2022-06-21 05:52:44.725831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import LookupModule as lm

    l = lookup_loader.get('config')
    l.run = lm.run
    assert l.run(terms=['DEFAULT_REMOTE_USER']) == [u'root']

# Generated at 2022-06-21 05:52:54.489167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize mock objects
    from ansible.module_utils.basic import AnsibleModule

    # Define 'ansible_options' dict
    ansible_options = dict()

    # Set 'ansible_options['on_missing']' to 'error'
    ansible_options['on_missing'] = 'error'

    # Set 'ansible_options_plugin_type' to 'connection'
    ansible_options['plugin_type'] = 'connection'

    # Set 'ansible_options['plugin_name']' to 'ssh'
    ansible_options['plugin_name'] = 'ssh'

    # Create object of module type 'AnsibleModule'
    module = AnsibleModule(argument_spec=(), supports_check_mode=True)

    # Define 'term' and 'variables'