

# Generated at 2022-06-21 05:42:59.590988
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('message', 'orig_exc')
    assert m.message == 'message'
    assert m.orig_exc == 'orig_exc'

# Generated at 2022-06-21 05:43:01.959335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import LookupModule as lm
    lookup_plugin = lm(None, None)

# Generated at 2022-06-21 05:43:03.077106
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True

# Generated at 2022-06-21 05:43:08.397156
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Expects to instantiate MissingSetting with parent AnsibleOptionsError
    missingSetting = MissingSetting("Test Error")

    # Tests MissingSetting, expect it to be an instance of MissingSetting and AnsibleOptionsError
    assert isinstance(missingSetting, (MissingSetting, AnsibleOptionsError))
    assert missingSetting.message == "Test Error"

# Generated at 2022-06-21 05:43:09.405894
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("This is an AnsibleOptionsError test message.")
    except MissingSetting:
        assert True
    except:
        assert False

# Generated at 2022-06-21 05:43:12.101059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert type(obj) == LookupModule


# Generated at 2022-06-21 05:43:13.556921
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m = LookupModule()
    assert m is not None

# Generated at 2022-06-21 05:43:23.096666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule
    from ansible.module_utils.six import string_types
    import os
    import json
    import datetime
    lookup = LookupModule()
    os.environ["ANSIBLE_CONFIG"] = "ansible.cfg"
    lookup.set_options({'plugin_type' : 'connection', 'plugin_name' : 'paramiko'})
    tt = datetime.datetime.now()
    result = lookup.run([u'become_user'])
    subtt = datetime.datetime.now() - tt
    res = {}
    res['Output'] = result
    res['Time'] = str(subtt)
    print (json.dumps(res))
    assert result == ['root']


# Generated at 2022-06-21 05:43:26.701265
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('missing setting', orig_exc=None)
    assert e
    assert e.message == 'missing setting'
    assert e.orig_exc is None

# Generated at 2022-06-21 05:43:30.379825
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_missing_setting = MissingSetting('test')
    assert test_missing_setting.message.startswith('test')

# Generated at 2022-06-21 05:43:40.192459
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()

# Generated at 2022-06-21 05:43:51.225037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupBase(LookupBase):
        def run(self, *args, **kwargs):
            return lookup_plugin
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={'inventory_hostname': 'localhost'})

    # get default value for DEFAULT_BECOME_USER
    assert lookup_plugin.run(['DEFAULT_BECOME_USER'],'error','become','sudo') == [u'root']

    # skip missing value for UNKNOWN_BECOME_USER
    assert lookup_plugin.run(['UNKNOWN_BECOME_USER'],'skip','become','sudo') == []

    # get default value for DEFAULT_ROLES_PATH

# Generated at 2022-06-21 05:43:54.988009
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('not found')
    except Exception as e:
        assert e.args[0] == 'not found'

# Generated at 2022-06-21 05:43:56.894463
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test_msg')
    assert e.message == 'test_msg'

# Generated at 2022-06-21 05:43:59.204303
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Check if object of class LookupModule can be constructed"""
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:44:02.627040
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Instantiate a new instance of the class LookupModule(LookupBase)"""
    try:
        lookup_module = LookupModule()
    except Exception as e:
        raise e

# Generated at 2022-06-21 05:44:10.880182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockC():
        HOST_KEY_CHECKING = True
        DEFAULT_BECOME_METHOD = 'sudo'
        ANSIBLE_CACHE_PLUGIN = 'yaml'
        ret = []
        def get_config_value(self, term, variables=None, plugin_type=None, plugin_name=None):
            ret = []
            if term == 'DEFAULT_BECOME_METHOD':
                ret.append(self.DEFAULT_BECOME_METHOD)
            elif term == 'ANSIBLE_CACHE_PLUGIN':
                ret.append(self.ANSIBLE_CACHE_PLUGIN)
            elif term == 'ANSIBLE_CACHE_PLUGIN_CONNECTION':
                ret.append('/tmp')
            return ret


# Generated at 2022-06-21 05:44:12.244168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:44:13.608083
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-21 05:44:22.061682
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:44:39.051141
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting("this should raise an exception", orig_exc=Exception())

# Generated at 2022-06-21 05:44:54.227581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager

    lookup = lookup_loader.get('config', class_only=True)
    t = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'REMOTE_TMP', 'LOCAL_TMP']
    plugin_type = 'shell'
    plugin_name = 'sh'
    opts = {'plugin_type': plugin_type}
    var_opts = {'plugin_name': plugin_name}
    vars_tmp = VariableManager()
    vars_tmp.extra_vars = var_opts

    config_out = lookup.run(t, variables=vars_tmp, **opts)
    assert isinstance(config_out, list)
    assert config_out[0]

# Generated at 2022-06-21 05:44:55.028183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:44:58.871629
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = AnsibleError('message')
    msg = MissingSetting('message', orig_exc=e)
    assert msg.message == 'message'
    assert msg.orig_exc == e

# Generated at 2022-06-21 05:45:06.039570
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:45:10.747208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    exp = ['failed']
    ans = l.run(terms=['DEFAULT_FAIL_UNDEFINED_VARS'])
    assert ans == exp


# Generated at 2022-06-21 05:45:11.745699
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod.options == {'_terms': None, 'plugin_type': None, 'plugin_name': None}

# Generated at 2022-06-21 05:45:15.758925
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    errmsg = 'Unknown setting'
    cause = Exception("my exception")
    ms = MissingSetting(errmsg, cause)
    assert ms.orig_exc == cause, 'Unexpected cause, expected %s, got %s' % (cause, ms.orig_exc)
    assert errmsg in str(ms), 'Unexpected err string, expected %s, got %s' % (errmsg, ms)

# Generated at 2022-06-21 05:45:22.319467
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # pylint: disable=redundant-unittest-assert
    assert MissingSetting('msg')
    assert MissingSetting('msg', orig_exc=IOError('msg'))

    msg = 'this is a test message'
    assert msg in MissingSetting(msg).message
    assert msg in MissingSetting(msg, orig_exc=IOError(msg)).message

# Generated at 2022-06-21 05:45:30.592751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize variables
    terms = ['DEFAULT_BECOME_USER']
    variable='ABC'
    kwards={}
    # Create an instance of class LookupModule
    l1 = LookupModule()
    # Call method run
    #print(l1.run(terms, variable, **kwards))

#Unit test for method run_q of class LookupModule

# Generated at 2022-06-21 05:46:09.725615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module
    assert isinstance(lookup_module, LookupModule)

    # config_in_var being UNKNOWN should default to C.DEFAULT_REMOTE_TMP
    assert lookup_module.run(["UNKNOWN"]) == [u"$HOME/.ansible/tmp"]

    # C.DEFAULT_REMOTE_TMP is an actual variable
    assert lookup_module.run(["DEFAULT_REMOTE_TMP"]) == [u"$HOME/.ansible/tmp"]

    # C.DEFAULT_ROLES_PATH is a list but returned as a comma-separated string
    assert lookup_module.run(["DEFAULT_ROLES_PATH"]) == [u'/etc/ansible/roles:/usr/share/ansible/roles']

    #

# Generated at 2022-06-21 05:46:10.540891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:46:21.269067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    import ansible.plugins.loader as plugin_loader
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.sentinel import Sentinel
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.loader as plugin_loader

# Generated at 2022-06-21 05:46:24.792479
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting('message', orig_exc=Exception('original exception'))
    assert obj.orig_exc.args[0] == 'original exception'

# Generated at 2022-06-21 05:46:35.057089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    assert lookup_module.run(terms) == ['root']

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_FLAGS']
    assert lookup_module.run(terms) == ['root', '-S']

    terms = ['DEFAULT_ROLES_PATH']
    assert lookup_module.run(terms) == ['/etc/ansible/roles:/usr/share/ansible/roles']

    # test on_missing
    terms = ['UNKNOWN_SETTING']
    assert lookup_module.run(terms, on_missing='skip') == []

    terms = ['UNKNOWN_SETTING']
    assert lookup_module.run(terms, on_missing='warn') == []


# Generated at 2022-06-21 05:46:48.835734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for get_global_config
    # Key exists
    p = LookupModule()
    p.set_options({'plugin_name': '', 'plugin_type': '', 'on_missing': 'error'})
    assert p.run(['DEFAULT_BECOME_METHOD'], []) == ['sudo']
    # Key isn't present
    with pytest.raises(AnsibleLookupError):
        p.run(['this_is_not_a_key'], [])

    # test for get_plugin_config
    # missing plugin_name
    p = LookupModule()
    p.set_options({'plugin_type': 'connection', 'on_missing': 'error'})

# Generated at 2022-06-21 05:47:02.065390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = "BECOME_METHOD"
    lu = LookupModule()
    terms = [1,2,3]
    assert_raises(AnsibleOptionsError, lu.run, terms=terms)

    # Test with no become method
    lu = LookupModule()
    terms = [config]
    variables = {'ansible_become_method': ""}
    assert_equals(lu.run(terms, variables=variables), [u'', ])

    # Test with become method
    lu = LookupModule()
    terms = [config]
    variables = {'ansible_become_method': "sudo"}
    assert_equals(lu.run(terms, variables=variables), [u'sudo', ])

    # Test with non string config
    lu = LookupModule()
    terms

# Generated at 2022-06-21 05:47:13.766893
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a loop that create object of LookupModule and run the method
    for sp in [None, 'shell', 'connection']:
        for spn in [None, 'sh', 'ssh']:
            lookup_plugin=LookupModule()
            loader = DataLoader()
            variable_manager = VariableManager()
            inventory = InventoryManager(loader=loader, sources="localhost")
            variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 05:47:17.903003
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # missing arg
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert 'test' in str(e)
        assert e.orig_exc is None

    # missing arg with exception
    try:
        raise MissingSetting('test', Exception('test 2'))
    except MissingSetting as e:
        assert 'test' in str(e)
        assert 'test 2' in str(e.orig_exc)

# Generated at 2022-06-21 05:47:23.617026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel

    yaml_key_value_list = [
        ('ssh_connection', 'smart'),
        ('remote_port', '22'),
        ('pipelining', 'False'),
        ('timeout', '10'),
        ('remote_tmp', '/tmp')]

    yaml_setting_list = [item[0] for item in yaml_key_value_list]
    yaml_setting_list.extend(['key_not_found_in_yaml', 'accept_host_key'])

    test = [('testdata', 'test/unit/lib/unit_test_data/test_config_plugin.yml')]
    lookup_instance = LookupModule(basedir=None, runner=None, templar=None)

# Generated at 2022-06-21 05:48:29.854422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # C.AUTOMATIC_DEBUG_CATEGORIES = ['plugin', 'runner', 'lookup']
    # C.ANSIBLE_VERBOSITY = 4
    # C.ANSIBLE_DEBUG = True
    lm = LookupModule()
    # Test1:
    terms = ['asdfff']
    variables = {}
    kwargs = {}
    try:
        result = lm.run(terms, variables=variables, **kwargs)
    except AnsibleLookupError as e:
        if not isinstance(e, AnsibleLookupError):
            raise AnsibleLookupError('Unable to find setting %s' % terms[0], orig_exc=e)

# Generated at 2022-06-21 05:48:40.847697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # load_plugins()
    lookup_module = LookupModule()
    term = ('HOST_KEY_CHECKING', 'DEFAULT_ROLES_PATH')
    wrong_term = ('HOST_KEY_CHECKIN', 'DEFAULT_ROLES_PAT')
    plugin_term = ('become_method', 'remote_tmp', 'remote_user')
    plugin_name = 'ssh'
    plugin_type = 'connection'
    lookup_module.run(term) == lookup_module.run(wrong_term, error='error')
    lookup_module.run(term, on_missing='warn') == lookup_module.run(wrong_term, on_missing='warn')
    lookup_module.run(term, on_missing='skip') == lookup_module.run(wrong_term, on_missing='skip')
    lookup

# Generated at 2022-06-21 05:48:42.647442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.run is not None

# Generated at 2022-06-21 05:48:45.975690
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('An error message')
    assert isinstance(exc, AnsibleOptionsError)
    assert exc.message == 'An error message'

# Generated at 2022-06-21 05:48:46.803549
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert 1 == 1

# Generated at 2022-06-21 05:48:50.923907
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting("message")
    assert exc.on_missing == 'error'
    assert exc.orig_exc is None
    assert exc.message == 'message'

    Named = namedtuple('Named', 'name')
    named = Named('name')

    exc = MissingSetting("message", orig_exc=named)
    assert exc.orig_exc == named

# Generated at 2022-06-21 05:48:53.436200
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting()
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-21 05:48:56.090414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')


# Generated at 2022-06-21 05:49:02.197092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # create a object of class LookupModule
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {'DEFAULT_BECOME_USER': None, 'DEFAULT_BECOME_METHOD': 'sudo'}
    kwargs = {'on_missing': 'error'}
    # test run with valid input
    with pytest.raises(AnsibleLookupError):
        lookup.run(terms=terms, variables=variables, on_missing='error')


# Generated at 2022-06-21 05:49:13.143568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock object of class LookupModule
    LookupModule_test = LookupModule()

    # function get_option should return the value in "variable_options"
    # for key "on_missing"
    variable_options = {'on_missing' : 'skip'}
    LookupModule_test.get_option = lambda variable_name: variable_options[variable_name]

    # function get_global_config should return value of "term" passed.
    # Which means the value of term matches value of the setting.
    def get_global_config(term):
        return term

    # function set_options updates variable_options to "data"
    # written to the mock object instance variable "options".
    # it should also update variables to "variables"
    # written to the mock object instance variable "_variables".

# Generated at 2022-06-21 05:51:02.957117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    assert isinstance(c, LookupModule)


# Generated at 2022-06-21 05:51:05.211298
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting("test")
    assert obj is not None

# Generated at 2022-06-21 05:51:08.531536
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Create object MissingSetting
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        message = str(e)
        exception = e.orig_exc
    # Compare message of exception with string 'test'
    assert message == 'test'
    # Compare exception with None
    assert exception is None

# Generated at 2022-06-21 05:51:18.869729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Store the current sys param so it can be restored
    old_sys = sys.argv
    try:
        # Setup the sys param
        sys.argv = ['ansible-config', 'list']
        # Build a default config
        config = AnsibleConfig()
        lookup = LookupModule(config=config)
        lookup.set_options(set())
        # Test the run method of LookupModule
        result = lookup.run(terms=['DEFAULT_REMOTE_USER'], variables=None)
        assert result == ['root']
    finally:
        # Restore the original sys param
        sys.argv = old_sys

# Generated at 2022-06-21 05:51:24.139454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # sentinel value isn't stored anywhere, it is created just to be used here.
    sentinel = Sentinel()
    
    # mock_plugin_loader is just a class which has a method get with name mock_get
    # which raises AnsibleLookupError.

# Generated at 2022-06-21 05:51:26.995400
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting("message", orig_exc=Exception())
    assert len(err.args) == 2
    assert err.args[0] == 'message'
    assert isinstance(err.args[1], Exception)

# Generated at 2022-06-21 05:51:39.435878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test the method run of class LookupModule
    '''
    # The arguments required for the constructor of class LookupModule
    terms = ['DEFAULT_BECOME_USER']

# Generated at 2022-06-21 05:51:46.585664
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.value == 'test'
        assert 'test' in e.message
        assert e.msg == 'test'
        assert e.message == 'test'
        assert 'No configuration setting found for:' in e.advice
        assert 'test' in e.options
        assert e.orig_exc is None
        assert not e.errors

    try:
        raise MissingSetting( 'test', [4, 6], {'name': 'mike'} )
    except MissingSetting as e:
        assert e.value == 'test'
        assert 'test' in e.message
        assert e.msg == 'test'
        assert e.message == 'test'
        assert 'No configuration setting found for:' in e.advice

# Generated at 2022-06-21 05:51:49.766383
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Assert that there are no errors
    assert lookup.run([]) == []

# Generated at 2022-06-21 05:51:54.129069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        assert True == isinstance(LookupModule(), LookupBase)
    except Exception:
        raise Exception("AnsibleLookupError: not isinstance of LookupBase")