

# Generated at 2022-06-21 05:43:03.330759
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Exercise that MissingSetting constructor does what it's supposed to do."""
    msg = 'bar'
    ms = MissingSetting(s)
    assert isinstance(ms, MissingSetting)
    assert isinstance(ms, AnsibleOptionsError)
    assert msg in ms.message

# Generated at 2022-06-21 05:43:05.305012
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for class LookupModule'''
    mod = LookupModule()
    mod_const = LookupModule()

# Generated at 2022-06-21 05:43:14.459095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for an invalid value for on_missing
    try:
        LookupModule().run(terms=['unknown_setting'], variables=None, on_missing='invalid', plugin_type=None, plugin_name=None)
    except AnsibleOptionsError as e:
        assert "on_missing" in to_native(e)

    # Tests when on_missing is set to skip
    try:
        LookupModule().run(terms=['unknown_setting'], variables=None, on_missing='skip', plugin_type=None, plugin_name=None)
        assert True
    except:
        assert False

    # Tests when on_missing is set to error

# Generated at 2022-06-21 05:43:15.183727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 05:43:23.694565
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader
    from ansible.errors import AnsibleOptionsError
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # First we need to create dummy class for LookupModule
    class DummyLookupModule(LookupModule):
        def __init__(self, loader, templar, **kwargs):
            super(DummyLookupModule, self).__init__(loader, templar, **kwargs)

    # And we need to create one dummy plugin
    class DummyPlugin:
        _load_name = 'DummyPluginName'

        def get_option(self, option):
            return 'DummyPluginName'

    terms = [AnsibleUnicode('remote_user'), AnsibleUnicode('port'), AnsibleUnicode('remote_tmp')]


# Generated at 2022-06-21 05:43:33.298656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is needed to include the tests directory in the module search path
    import sys
    import os

    import unittest

    # load the plugins needed for the test
    lookup = LookupModule()
    loader = plugin_loader.get_loader('lookup', 'config')
    lookup.set_loader(loader)

    # set some config values for testing
    os.environ['ANSIBLE_CONFIG'] = '/dev/null'
    C.DEFAULT_ROLES_PATH = '"roles/path/1" "roles/path/2"'
    C.LOCALHOST_WARNING = False
    C.RETRY_FILES_ENABLED = True
    C.RETRY_FILES_SAVE_PATH = 'dir_save_path'

    # tests

# Generated at 2022-06-21 05:43:40.529123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init vars
    lookup_obj = LookupModule()
    search_term = 'DEFAULT_ROLES_PATH'
    expected_result = ["/usr/local/etc/ansible/roles", "/usr/share/ansible/roles", "/etc/ansible/roles"]
    # run the test
    test_result = lookup_obj.run([search_term])
    # check the result
    assert test_result[0] == expected_result

# Generated at 2022-06-21 05:43:49.014583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_REMOTE_USER']
    variables = {}
    kwargs = {}

    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root']

    terms = ['DEFAULT_REMOTE_USER']
    variables = {}
    kwargs = {'plugin_type': 'connection', 'plugin_name': 'ssh'}

    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root']

# Generated at 2022-06-21 05:43:49.866785
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('message')

# Generated at 2022-06-21 05:43:55.212173
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'This is the message'
    orig_exc = 'This is the original exception'
    my_missing_setting = MissingSetting(msg, orig_exc)

    assert msg in str(my_missing_setting)
    assert orig_exc in str(my_missing_setting)

# Generated at 2022-06-21 05:44:02.957585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 05:44:04.400870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance.get_option('plugin_name') is None

# Generated at 2022-06-21 05:44:05.721630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True

# Generated at 2022-06-21 05:44:10.794575
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Verifies that the MissingSetting constructor takes the right parameters"""
    msg = "setting was not defined"
    exc = AnsibleError("setting was not defined")
    try:
        m = MissingSetting(msg, orig_exc=exc)
        assert m.orig_exc == exc
    except Exception as e:
        assert False("Could not create object: %s" % e)

# Generated at 2022-06-21 05:44:18.305490
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    lookup_module.run(terms=['COLOR_OK'], variables={'playbook_dir':'/root/ansible/sample'}, direct={'on_missing':'error'})
    lookup_module.run(terms=['COLOR_OK'], variables={'playbook_dir':'/root/ansible/sample'}, direct={'on_missing':'skip'})
    lookup_module.run(terms=['COLOR_OK'], variables={'playbook_dir':'/root/ansible/sample'}, direct={'on_missing':'warn'})

# Generated at 2022-06-21 05:44:22.839666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        config_lookup = LookupModule()
    except Exception:
        config_lookup = None
    assert config_lookup is not None

# Generated at 2022-06-21 05:44:27.775282
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()
    config_value = lm.run(terms=['DEFAULT_BECOME_USER'], variables={'ANSIBLE_BECOME_USER': 'test'})
    assert config_value[0] == 'test'

# Generated at 2022-06-21 05:44:30.013365
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.set_options()

    lookup_module.run(terms="localhost")

# Generated at 2022-06-21 05:44:31.104381
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test')
    assert e.message == 'test'

# Generated at 2022-06-21 05:44:42.962942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import ConnectionLoader
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from io import StringIO
    import sys

    results = []
    # Mock stdout and stderr
    sysout = sys.stdout
    sys.stdout = StringIO()
    sys.stderr = StringIO()

    def my_self_warning(msg):
        results.append(msg)
    def my_self_get_option(option):
        return None

# Generated at 2022-06-21 05:44:52.233914
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()



# Generated at 2022-06-21 05:44:55.214862
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:44:56.004608
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    assert look is not None

# Generated at 2022-06-21 05:45:01.432731
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_msg = "This is for testing"
    exception = Exception("mock exception")

    # Test only one argument
    try:
        raise MissingSetting(error_msg)
    except MissingSetting as e:
        assert e.message == error_msg
        assert e.orig_exc == None

    # Test two argument
    try:
        raise MissingSetting(error_msg, exception)
    except MissingSetting as e:
        assert e.message == error_msg
        assert e.orig_exc == exception

# Generated at 2022-06-21 05:45:04.489987
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-21 05:45:05.429264
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:45:16.832964
# Unit test for method run of class LookupModule
def test_LookupModule_run(): 
    # test the argument not of type string
    lookup = LookupModule()
    try:
        lookup.run([1])
    except AnsibleOptionsError:
        pass
    else: 
        raise 
    
    # test the argument is a string but does not exist
    try:
        lookup.run(['UNKNOWN'])
    except AnsibleLookupError:
        pass
    else: 
        raise 

    # test the argument is a string and does exist
    try:
        lookup.run(['DEFAULT_ROLES_PATH'])
    except:
        raise 

    # test the argument is a string and does exist, but will return an object that is not a string 
    try:
        lookup.run(['INTERNAL_CALLBACK_PLUGINS'])
    except:
        raise

# Generated at 2022-06-21 05:45:19.529899
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting('This is a test')
    assert err.message == 'This is a test'

# Generated at 2022-06-21 05:45:20.371595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 05:45:22.509807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['USERNAME']

    lookup = LookupModule()
    assert terms == lookup.run(terms)

# Generated at 2022-06-21 05:45:46.776661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with missing option set to error
    try:
        LookupModule().run(terms='config_default_for_foo_bar', on_missing='error')
    except AnsibleLookupError as e:
        assert 'Unable to find setting config_default_for_foo_bar' == str(e)

    try:
        LookupModule().run(terms='config_default_for_foo_bar', on_missing='error', plugin_type='shell', plugin_name='sh')
    except AnsibleLookupError as e:
        assert 'Unable to find setting config_default_for_foo_bar' == str(e)

    # Testing with missing option set to warn
    LookupModule().run(terms='config_default_for_foo_bar', on_missing='warn')

# Generated at 2022-06-21 05:45:58.759251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_1 = LookupModule()
    lookup_2 = LookupModule()
    lookup_3 = LookupModule()
    lookup_4 = LookupModule()
    lookup_5 = LookupModule()

    ret_1 = lookup_1.run(['ANSIBLE_HOST_KEY_CHECKING'], variables=None, **{})
    assert(ret_1[0])

    ret_2 = lookup_2.run(['ANSIBLE_HOST_KEY_CHECKING', 'DEFAULT_BECOME_USER'], variables=None, **{})
    assert(ret_2[0])
    assert(ret_2[1])

    ret_3 = lookup_3.run(['ANSIBLE_HOST_KEY_CHECKING'], variables=None, **{'on_missing': 'error'})

# Generated at 2022-06-21 05:46:06.707999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    options = {'plugin_type': 'callback', 'plugin_name': 'human_log'}
    lookup_module.set_options(var_options=None, direct=options)
    terms = ['show_custom_stats', 'show_repl_custom_stats']
    result = lookup_module.run(terms)
    assert result == [True, True]

# Generated at 2022-06-21 05:46:19.651919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First test without plugin type and name
    l = LookupModule()
    l.set_options({'var_options': {'playbook_dir': '/etc/ansible'}, 'direct': {'on_missing': 'error'}})
    try:
        result = l.run(['INVALID'])
        assert False, 'AnsibleLookupError was not raised'
    except AnsibleLookupError as e:
        assert 'Unable to find setting INVALID' in str(e)

    # Next test with [shell]:[sh] plugin
    l = LookupModule()

# Generated at 2022-06-21 05:46:31.944553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    if sys.version_info[:2] == (2, 6):
        raise unittest.SkipTest("Python 2.6 does not support mock")
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.errors import AnsibleOptionsError, AnsibleLookupError
    import ansible.plugins.lookup
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.loader import LookupModule


# Generated at 2022-06-21 05:46:40.973709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.common.collections import ImmutableDict
    lookup_loader.add_directory(path='../../lookup_plugins/')
    lookup = lookup_loader._lookup_plugins['config']
    lookup.set_loader(lookup.loader)
    assert lookup.run is not None
    assert lookup.run([]) == []
    assert lookup.run(['DUMMY_CONFIG']) == []
    assert isinstance(lookup.run(['DUMMY_CONFIG'],
                                 variables=ImmutableDict(hostvars=ImmutableDict(DEFAULT_RETURN_VALUES='dummy'))), list)
    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run

# Generated at 2022-06-21 05:46:50.438874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeModule():
        def __init__(self):
            self._display = FakeModule()

        def warning(self, msg):
            print(msg)

    class FakeLoader():
        class FakeObj():
            def __init__(self):
                self._load_name = 'ssh'

        def get(self, name, class_only):
            if name == 'ssh':
                return FakeObj()
            return None

    lm = LookupModule()
    lm.set_loader(FakeLoader())
    lm._display = FakeModule()
    lm._display.warning = FakeModule().warning

    C.c = FakeModule()
    C.c.get_config_value = lambda y,x,z: '123'

    C.DEFAULT_REMOTE_USER = 'root'
    C.DEFAULT_REM

# Generated at 2022-06-21 05:46:57.881024
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test_terms = [ 'foo' ]
    test_variables = { 'foo' : 'bar'}
    test_kwargs = { 'bar' : 'foo' }
    test.run(test_terms, test_variables, **test_kwargs)

# Generated at 2022-06-21 05:46:59.881662
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        MissingSetting("test-error")
    except MissingSetting as e:
        assert e.message == "test-error"

# Generated at 2022-06-21 05:47:09.438153
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = {'_original_file': './test/ansible/data/templates/template2.j2.j2'}
    lookup = LookupModule()
    lookup.set_options(var_options=None, direct=options)
    assert lookup.get_option('_original_file') == './test/ansible/data/templates/template2.j2.j2'


# Generated at 2022-06-21 05:47:38.433690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:47:38.930400
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:47:45.615584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./lookup_plugins')
    lookup_loader.add_directory('./plugins/lookup')

    mock_runner = object()

    # test loading of plugin_type and plugin_name
    l = LookupModule()
    l.set_runner(mock_runner)
    result = l.run(['remote_user'], variables={}, plugin_name='ssh', plugin_type='connection')
    assert re

# Generated at 2022-06-21 05:47:54.185507
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Testing with all arguments provided
    try:
        raise MissingSetting('setting was not defined', orig_exc=AttributeError)
    except MissingSetting as e:
        assert e.__class__.__name__ == 'MissingSetting'
    # Testing with no argument provided
    try:
        raise MissingSetting()
    except MissingSetting as e:
        assert e.__class__.__name__ == 'MissingSetting'
    # Testing with only one argument provided
    try:
        raise MissingSetting('setting was not defined')
    except MissingSetting as e:
        assert e.__class__.__name__ == 'MissingSetting'
    return True

# Generated at 2022-06-21 05:47:57.075979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:47:58.708901
# Unit test for constructor of class LookupModule
def test_LookupModule():
        obj = LookupModule()

# Generated at 2022-06-21 05:48:00.698478
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        missing_setting = MissingSetting("message")
    except Exception as e:
        print("Exception raised: {}".format(e))
        pytest.fail("constructor of class MissingSetting() failed")


# Generated at 2022-06-21 05:48:05.455909
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_msg = 'Unable to find setting foo'
    test_e = AttributeError(test_msg)
    test_exc = MissingSetting(test_msg, orig_exc=test_e)
    assert test_exc.message == test_msg
    assert test_exc.orig_exc == test_e

# Generated at 2022-06-21 05:48:18.163169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config_value = 'test_config'
    term = 'term'
    plugin_type = 'plugin_type'
    plugin_name = 'plugin_name'
    terms = [term]
    variables = {}
    config_dict = {
        '_ansible_lookup_plugin_class': 'AnsibleLookupModule',
        'run': 'AnsibleLookupModule_run',
        'on_missing': 'error',
        'plugin_type': plugin_type,
        'plugin_name': plugin_name,
        '_ansible_module_name': 'config'
    }

    # test case : terms is valid
    class LookupModule:
        def run(self, terms, variables=None, **kwargs):
            return []
    # test case : terms is invalid

# Generated at 2022-06-21 05:48:25.408153
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting(msg='test message for MissingSetting', orig_exc='test original exception for MissingSetting')
    except MissingSetting as e:
        assert e.msg == 'test message for MissingSetting'
        assert e.orig_exc == 'test original exception for MissingSetting'
        assert e.options is None
        assert e.obj is None

# Generated at 2022-06-21 05:49:30.057429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    assert ['ansible-config'] == lookup_obj.run(terms=['config_module_names'])
    assert 'ansible-config' == lookup_obj.run(terms=['config_module_names'],wantlist=False)
    assert ['ansible-config'] == lookup_obj.run(terms=['config_module_names'],wantlist=True)
    assert [] == lookup_obj.run(terms=['UNKNOWN_TERM'],on_missing='skip')

# Generated at 2022-06-21 05:49:32.022449
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Constructor
    lm = LookupModule()

    assert len(lm._templates) == 0
    assert len(lm._templates_basedirs) == 0
    assert len(lm._options) == 0

# Generated at 2022-06-21 05:49:34.525617
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Just create an instance of class MissingSetting
    # and check if str(instance) raises no exceptions
    try:
        str(MissingSetting('Test'))
    except Exception as e:
        raise AssertionError('Failed to obtain string representation of class MissingSetting instance: %s' % e)

# Generated at 2022-06-21 05:49:36.623432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Set options
    options = {
        'var_options': {},
        'direct': {}
    }

    lookup.set_options(**options)

    # Check set_options result
    assert lookup._options == options

    # Check run with error
    terms = [1, 2]
    var_options = {}
    result = lookup.run(terms, var_options)
    assert result == []

# Generated at 2022-06-21 05:49:44.927768
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:49:48.815383
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("my message")
    except MissingSetting as e:
        assert e.message == "my message"

# Generated at 2022-06-21 05:49:50.880718
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert str(MissingSetting('This is a test')) == 'This is a test'

# Generated at 2022-06-21 05:50:00.494317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config = 'A'
    kwargs = {'var_options': { 'c' : 'C' }, 'direct': { 'd' : 'D' }}
    module = LookupModule()
    module.set_options(**kwargs)
    assert module.get_option('var_options') == kwargs['var_options']
    assert module.get_option('direct') == kwargs['direct']


# Generated at 2022-06-21 05:50:07.300864
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test with a string
    err1 = MissingSetting("You really messed up!")
    assert "You really messed up!" in str(err1)

    # Test with a string and original exception
    class TestException(Exception):
        pass
    err2 = MissingSetting("You really, really messed up!", TestException())
    assert "You really, really messed up!" in str(err2)
    assert "TestException" in str(err2)

    # Test with a class instance of an exception (no string provided)
    class TestException(Exception):
        pass
    err3 = MissingSetting(TestException())
    assert "TestException" in str(err3)

# Generated at 2022-06-21 05:50:07.870432
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    q = MissingSetting('XXXX')
    assert q

# Generated at 2022-06-21 05:52:09.056719
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    from ansible.errors import AnsibleOptionsError
    # matches expected exception type
    with pytest.raises(AnsibleOptionsError) as excinfo:
        # raises exception with expected message
        raise MissingSetting('message')
    assert 'message' in str(excinfo.value)

# Generated at 2022-06-21 05:52:21.202366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = {'all': {'ansible_connection': 'local',
                        'ansible_host': 'localhost',
                        'ansible_user': 'me',
                        'ansible_network_os': 'default',
                        'ansible_python_interpreter': '/usr/bin/python',
                        'ansible_distribution': 'Default',
                        'ansible_distribution_version': 'Default',
                        'ansible_os_family': 'Default',
                        'ansible_playbook_python': '/usr/bin/python',
                        'ansible_module_setup': True}}
    inventory = {"_meta": {"hostvars": hostvars}}
    look = LookupModule()

# Generated at 2022-06-21 05:52:31.892208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class _LookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            self._result = None
            self._options = kwargs
            self._display = self.__FakeDisplay()

        class __FakeDisplay:
            def __init__(self):
                self.display = ""

            def warning(self, msg):
                self.display += "Warning: %s" % msg

        def set_options(self, *args, **kwargs):
            self._options = kwargs

        def get_option(self, term):
            if term in self._options:
                return self._options[term]
            else:
                return None

    # Test DEFAULT_BECOME_USER

# Generated at 2022-06-21 05:52:42.925750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert None is lookup_module.run([])
    assert ['error'] is lookup_module.run(['DEFAULT_ERRORS_TO_STDERR'])
    assert [u'test'] is lookup_module.run(['ANSIBLE_LIBRARY'])
    assert [u'bearer'] is lookup_module.run(['DEFAULT_NETCONF_AUTH_TYPE'])
    assert [u'local'] is lookup_module.run(['DEFAULT_LOCAL_TMP'])
    assert [u'linux'] is lookup_module.run(['DEFAULT_SUDO_EXE'])
    assert [u'/usr/bin/python'] is lookup_module.run(['DEFAULT_MODULE_INTERPRETER'])
    assert [u'FILE, PACMAN'] is lookup_

# Generated at 2022-06-21 05:52:50.353371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_ROLES_PATH']
    test_name = 'test_name'
    expected_result = ['roles', 'roles']
    test_class = LookupModule()

    result = test_class.run(test_terms, None, plugin_name=test_name)

    assert result == expected_result