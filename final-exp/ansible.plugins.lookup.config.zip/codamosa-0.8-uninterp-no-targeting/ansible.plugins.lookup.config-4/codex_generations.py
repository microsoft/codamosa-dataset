

# Generated at 2022-06-21 05:43:10.196299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import os
    import json


    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-21 05:43:11.583943
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()


# Generated at 2022-06-21 05:43:15.776655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = ['DEFAULT_ROLES_PATH', 'DEFAULT_ROLES_PATH']
    result = lookup.run(term)
    assert len(result) == len(term)
    assert result[0] == result[1]
    assert result[0] == C.DEFAULT_ROLES_PATH

# Generated at 2022-06-21 05:43:17.076984
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:43:22.796727
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError) as raised_exception:
        # Call constructor of class MissingSetting with invalid option type for on_missing
        MissingSetting('', unknown=None)
    assert 'required: on_missing' in str(raised_exception.value)

# Generated at 2022-06-21 05:43:26.882445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["remote_user"], {"remote_user": "_test_user"}) == ["_test_user"]
    

# Generated at 2022-06-21 05:43:40.809762
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test different versions of missing options
    local_vars = {}
    local_vars['config'] = 'UNKNOWN'
    local_vars['plugin_type'] = 'shell'
    local_vars['plugin_name'] = 'sh'
    local_vars['on_missing'] = 'warn'

    lookup_mod = LookupModule()
    result = lookup_mod.run(terms=['remote_user'], variables=local_vars)
    assert result == ['root']

    local_vars['on_missing'] = 'skip'
    lookup_mod = LookupModule()
    result = lookup_mod.run(terms=['remote_user'], variables=local_vars)
    assert result == []

    local_vars['on_missing'] = 'error'
    lookup_mod = LookupModule()

# Generated at 2022-06-21 05:43:51.516003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    # test empty terms
    assert(lookup_obj.run(terms=[]) == [])
    # test invalid missing option
    try:
        lookup_obj.run(terms=["_"], on_missing="dummy")
    except AnsibleOptionsError:
        pass
    # test invalid plugin_type and plugin_name
    try:
        lookup_obj.run(terms=["_"], plugin_type="dummy")
    except AnsibleOptionsError:
        pass
    # test valid options
    lookup_obj.run(terms=["DEFAULT_PRIVATE_ROLE_VARS_FOLDER"], on_missing="skip")
    lookup_obj.run(terms=["DEFAULT_PRIVATE_ROLE_VARS_FOLDER"], on_missing="warn")
    lookup

# Generated at 2022-06-21 05:43:56.965514
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("missing setting")
    except MissingSetting as e:
        assert "missing setting" in e.message
        assert e.orig_exc is None
    else:
        assert False, "Failed to raise a MissingSetting exception"

# Generated at 2022-06-21 05:44:08.817286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import u
    from ansible.module_utils import basic
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    module = basic.AnsibleModule(
        argument_spec = dict(
            terms = dict(type='list', elements='str', required=True),
            plugin_type = dict(type='string', choices=['become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars'], default=None),
            plugin_name = dict(type='string', default=None),
            on_missing = dict(type='string', choices=['error', 'warn', 'skip'], default='error')
        )
    )

   

# Generated at 2022-06-21 05:44:17.739810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 05:44:31.540710
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize test objects for lookup_plugin.config results testing
    class Options(object):
        def __init__(self, var_options, direct):
            self.var_options = var_options
            self.direct = direct

    class Term(object):
        def __init__(self, value):
            self.value = value

    class AnsibleModule(object):
        def __init__(self):
            self.CHECK_MODE = False
            self.params = {}

    class Display(object):
        def __init__(self):
            self.warning = None


# Generated at 2022-06-21 05:44:35.562872
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting("error message")
    assert isinstance(exception, AnsibleLookupError)
    assert isinstance(exception, AnsibleOptionsError)


# Generated at 2022-06-21 05:44:37.117336
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-21 05:44:41.791809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(["DEFAULT_ROLES_PATH"], {"foo": "bar"})
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert isinstance(ret[0], list)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 05:44:43.817897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 05:44:47.392031
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('msg')
    except MissingSetting as e:
        assert e.args[0] == 'msg'

# Generated at 2022-06-21 05:44:52.049206
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception_str = 'This is a test exception'
    orig_exc = Exception(exception_str)
    try:
        raise MissingSetting('test message', orig_exc=orig_exc)
    except MissingSetting as error:
        msg = str(error)
        assert exception_str in msg


# Generated at 2022-06-21 05:45:03.676649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play
    from ansible.vars import VariableManager

    loader = DataLoader()
    lookup_module = LookupModule()
    play_context = ansible.playbook.play.PlayContext()
    variable_manager = VariableManager()

    lookup_module.set_loader(loader)
    lookup_module.set_play_context(play_context)
    lookup_module.set_variable_manager(variable_manager)

    result = lookup_module.run(terms=["remote_user"], variables={"remote_user": "test"})
    assert result[0] == "test"

    result = lookup_module.run(terms=["proxy_command"], variables={"proxy_command": "test"})

# Generated at 2022-06-21 05:45:08.480222
# Unit test for constructor of class LookupModule
def test_LookupModule():
   import ansible.plugins.loader as plugin_loader
   lm = LookupModule()
   # call constructor of LookupModule
   assert lm != None, "testcase passed"


# Generated at 2022-06-21 05:45:26.108311
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert e.message == "test"

# Generated at 2022-06-21 05:45:27.498203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 05:45:36.371899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()

    assert t.run([]) == []
    assert t.run(['foo'], on_missing='error') == []

    assert t.run([C.DEFAULT_BECOME_USER], on_missing='error') == [C.DEFAULT_BECOME_USER]
    assert t.run([C.DEFAULT_BECOME_USER], on_missing='warn') == [C.DEFAULT_BECOME_USER]
    assert t.run([C.DEFAULT_BECOME_USER], on_missing='skip') == [C.DEFAULT_BECOME_USER]


# Generated at 2022-06-21 05:45:38.583453
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test instantiating class MissingSetting with arguments
    e = MissingSetting('msg', orig_exc='orig_exc')
    assert 'msg' in str(e)
    assert 'orig_exc' in str(e)
    # Try with only msg
    e = MissingSetting('msg')
    assert 'msg' in str(e)
    assert 'orig_exc' not in str(e)

# Generated at 2022-06-21 05:45:40.983883
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    t = MissingSetting('test exception')
    assert t is not None

# Generated at 2022-06-21 05:45:42.010485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_object = LookupModule()


# Generated at 2022-06-21 05:45:45.414896
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup_plugins.config as config

    l = config.LookupModule()

    res = l.run(terms=['remote_user', 'remote_port'],
                variables=None,
                plugin_type='connection',
                plugin_name='ssh',
                on_missing='error')
    assert res == ['root', 22]

# Generated at 2022-06-21 05:45:53.754814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with patch('ansible_collections.ansible.community.plugins.module_utils.common.config.Config.get_config_value', return_value='foo'):
        p = LookupModule()
        assert p.run(['DEFAULT_VAULT_ID_MATCH']) == ['foo']

# Generated at 2022-06-21 05:45:59.558687
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("a", "b", "c")
    except MissingSetting as exc:
        # getmessage return a python2 string (str)
        # content of the message should contain the string "a"
        assert "a" in str(exc)
        # args is a tuple containing (a, b, c)
        assert str(exc.args) == "('a', 'b', 'c')"
        # orig_exc is b
        assert str(exc.orig_exc) == "b"
    else:
        raise Exception("Missed the expected exception")

# Generated at 2022-06-21 05:46:03.833696
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test', orig_exc='original test')
    assert str(e) == 'test'
    assert e.orig_exc == 'original test'

# Generated at 2022-06-21 05:46:31.986931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Tests for missing setting

# Generated at 2022-06-21 05:46:40.999891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.plugins.action.debug.ActionModule
    mock_variables = {}
    mock_options = {}
    lookup_base = LookupBase()
    lookup_base.display = lambda *args, **kwargs: None

    lookup_module = LookupModule()
    lookup_module.set_loader = lambda *args, **kwargs: None
    lookup_module.set_environment = lambda *args, **kwargs: None
    lookup_module._get_plugin_term = lambda *args, **kwargs: None
    lookup_module.set_options = lambda *args, **kwargs: None
    lookup_module.set_display = lambda *args, **kwargs: None
    lookup_module._display = lookup_base.display
    lookup_module.run = lambda *args, **kwargs: None
    lookup_module.run

# Generated at 2022-06-21 05:46:44.262285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run() normal call
    l = LookupModule()
    l.set_options(Sentinel)
    l.run(['DEFAULT_ROLES_PATH', 'SOME_CUSTOM_VARIABLE'])

    # Test run() with plugin_type and plugin_name
    l = LookupModule()
    l.set_options(Sentinel, plugin_type='connection', plugin_name='local')
    l.run(['remote_tmp'])

# Generated at 2022-06-21 05:46:54.779920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with 1 term
    l = LookupModule()
    assert l.run(['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]

    # Test with multiple terms
    assert l.run(['DEFAULT_ROLES_PATH', 'DEFAULT_REMOTE_TMP']) == [C.DEFAULT_ROLES_PATH, C.DEFAULT_REMOTE_TMP]

    # Test with invalid term

# Generated at 2022-06-21 05:46:57.094198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = dict(
        _terms      = 'foo',
        on_missing  = 'error',
        plugin_type = 'vars',
        plugin_name = 'lookup',
    )
    lookup_instance = LookupModule()
    lookup_instance.set_options(var_options=None, direct=options)
    assert lookup_instance

# Generated at 2022-06-21 05:47:01.005659
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = ["remote_tmp"]
    variables = {"var1": "value1"}
    kwargs = {"plugin_type" : "shell", "plugin_name": "sh", "on_missing": "error"}
    lm.run(terms, variables=variables, **kwargs)

# Generated at 2022-06-21 05:47:13.173041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # create mock settings, cache loader and lookup base
    class MockSettings(object):
        def get_config_value(self, term, plugin_type=None, plugin_name=None, variables=None):
            return "Test"
    settings = MockSettings()

    # mock config
    class MockConfig(object):
        def __init__(self, config):
            self.config = config
        def __getattr__(self, name):
            if name == "settings":
                return settings
    C.config = MockConfig(config=C.config)

    # mock plugin loader and loader cache
    class MockLoader(object):
        def get(self, name, class_only=True):
            return None

# Generated at 2022-06-21 05:47:16.503392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, {}, None, None, None, None, None)


# Generated at 2022-06-21 05:47:18.624668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert (module != None)

# Generated at 2022-06-21 05:47:19.996356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test creation of a LookupModule instance
    test_lookup = LookupModule()
    assert test_lookup is not None

# Generated at 2022-06-21 05:48:20.222022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={'DEFAULT_BECOME_USER': 'nobody'}) == ['nobody']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD'], variables={'DEFAULT_BECOME_USER': 'nobody'}) == ['nobody', 'sudo']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER', 'ANSIBLE_DEFAULT_BECOME_USER'], variables={'DEFAULT_BECOME_USER': 'nobody'}) == ['nobody', 'root']

# Generated at 2022-06-21 05:48:28.843418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit tests for the class LookupModule.
    """

    # How to create a class instance
    # https://docs.python.org/2/tutorial/classes.html#class-objects
    # lm = LookupModule()
    lm = LookupBase()

    # Unit test for method run
    def run(terms, variables=None, **kwargs):

        # For example,
        # result = lm.run([1, 2], variables={'a': 'b'}, direct={'c': 'd'})

        # lm.set_options(var_options=variables, direct=kwargs)
        lm.set_options(var_options=variables, direct=kwargs)

        # result = lm.get_option('on_missing')
        # result = lm.get_option('

# Generated at 2022-06-21 05:48:30.425952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 05:48:37.650952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'set_options')
    assert callable(lookup_module.set_options)
    assert hasattr(lookup_module, 'get_option')
    assert callable(lookup_module.get_option)
    assert hasattr(lookup_module, 'run')
    assert callable(lookup_module.run)

# Generated at 2022-06-21 05:48:41.427080
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print ("lookup module test")
    lookup = LookupModule()
    assert lookup != None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:48:44.805432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(["DEFAULT_BECOME_USER"])
    assert result == ["root"]
    result = module.run(["DEFAULT_BECOME_USER"], {"DEFAULT_BECOME_USER": "bozo"})
    assert result == ["bozo"]

# Generated at 2022-06-21 05:48:48.101265
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # testing constructor
    with pytest.raises(AnsibleOptionsError) as excinfo:
        raise MissingSetting("error")

    assert excinfo.match("error")

# Generated at 2022-06-21 05:49:00.891284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.utils.color import AnsiColor
    from ansible.module_utils.compat.inspect import getargspec

    old_stdout = AnsiColor.stdout
    old_stderr = AnsiColor.stderr
    old_quiet = C.DEFAULT_SYSTEM_WARNINGS
    old_args = getargspec(plugin_loader.plugin_loader.get)
    old_rc = C.defaults()
    rc = {}
    rc.update(C.defaults())
    rc['COLOR_STDERR'] = False
    rc['COLOR_STDOUT'] = False
    rc['DISPLAY_SKIPPED_HOSTS'] = True

# Generated at 2022-06-21 05:49:01.439906
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    pass

# Generated at 2022-06-21 05:49:12.699939
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes, to_text

    from ansible.compat.tests import unittest

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    display = Display()

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.loader = DictDataLoader({})
            self.pm = plugin_loader.PluginLoader(
                'lookup',
                'lookup_plugins',
                C.get_config(parsed=False, variables=dict(), converting=False),
                '',
                '',
                display
            )
            self.lookup_plugin

# Generated at 2022-06-21 05:51:10.678429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO(nishanth) - Move the following tests to integration/plugins/lookup_plugins/config/tests

    # test 1
    # test for config that does not exist
    with pytest.raises(AnsibleOptionsError) as ex:
        result = LookupModule().run(terms=['CONFIG'], variables={}, on_missing='config')
    assert ex.value.message == '"on_missing" must be a string and one of "error", "warn" or "skip", not config'

    # test 2
    # test for setting that does not exist
    result = LookupModule().run(terms=['CONFIG'], variables={}, on_missing='skip')
    assert result == [Sentinel]

    # test 3
    # test for passing non-string terms

# Generated at 2022-06-21 05:51:12.648743
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting('Test message')
    assert str(ms) == 'Test message'
    assert 'Test message' in repr(ms)

# Generated at 2022-06-21 05:51:21.466030
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with some invalid on_missing values
    l = LookupModule()
    l.set_options(direct={'on_missing': None})
    try:
        l.run(terms=['DEFAULT_ROLES_PATH'])
        assert False, "run method of LookupModule with invalid on_missing value did not throw AnsibleOptionsError"
    except AnsibleOptionsError:
        pass
    l.set_options(direct={'on_missing': []})
    try:
        l.run(terms=['DEFAULT_ROLES_PATH'])
        assert False, "run method of LookupModule with invalid on_missing value did not throw AnsibleOptionsError"
    except AnsibleOptionsError:
        pass
    l.set_options(direct={'on_missing': "abcd"})

# Generated at 2022-06-21 05:51:26.839497
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    orig_exception = Exception('test_orig_exception')
    try:
        raise MissingSetting('test_MissingSetting', orig_exc=orig_exception)
    except MissingSetting as e:
        assert e.message == 'test_MissingSetting'
        assert e.orig_exc == orig_exception
        assert str(e) == 'test_MissingSetting'

# Generated at 2022-06-21 05:51:28.275231
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-21 05:51:31.211348
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('Error in missing setting')
    assert isinstance(error, AnsibleOptionsError)

# Generated at 2022-06-21 05:51:35.105113
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test' , orig_exc=None)
    except MissingSetting as e:
        assert(e.args[0] == 'test')

# Generated at 2022-06-21 05:51:36.661816
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-21 05:51:39.170263
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run('nonexistentvar')

# Generated at 2022-06-21 05:51:41.883105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run([]) is None, "Should have returned nothing."