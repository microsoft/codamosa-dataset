

# Generated at 2022-06-21 05:43:11.672980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # with default on_missing='error'
    result = lookup.run([])
    assert result == []
    result = lookup.run(['FOO', 'FOO1'], variables={'FOO': 'FOO_VALUE'})
    assert result == [Sentinel, Sentinel]
    result = lookup.run(['FOO'], variables={'FOO': 'FOO_VALUE'})
    assert result == ['FOO_VALUE']
    result = lookup.run(['FOO', 'FOO1'], on_missing='skip')
    assert result == []
    # with missing not in ['error', 'warn', 'skip']
    result = lookup.run(['FOO', 'FOO1'], on_missing='foo')
    assert result == []
    # with global config
    result = lookup

# Generated at 2022-06-21 05:43:21.245847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No plugin option
    terms = []
    terms.append('DEFAULT_KEEP_REMOTE_FILES')
    terms.append('DEFAULT_ROLES_PATH')
    variables = {}
    kwargs = {}
    kwargs['on_missing'] = 'error'
    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(terms, variables, **kwargs)
    assert len(ret) == 2
    assert ret[0] is False
    assert ret[1] == ['/usr/share/ansible/roles', '/etc/ansible/roles']
    # Plugin option
    kwargs['plugin_type'] = 'shell'
    kwargs['plugin_name'] = 'sh'
    terms = []
    terms.append('remote_tmp')

# Generated at 2022-06-21 05:43:22.879545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lo = LookupModule()
    assert True

# Generated at 2022-06-21 05:43:25.277030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class LookupModule(object):
        def __init__(self, **kwargs):
            self.kwargs = kwargs
    l = LookupModule(plugin_type='shell', plugin_name='sh')
    assert(l.kwargs == {'plugin_type': 'shell', 'plugin_name': 'sh'})

# Generated at 2022-06-21 05:43:33.825474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.utils.color import colorize, hostcolor
    display = Display()
    import os
    import tempfile
    temp_dir = tempfile.gettempdir()

    # Test on_missing='error'
    lookup_inst = LookupModule()
    lookup_inst.set_options(direct=dict(on_missing='error'))
    try:
        terms = ['invalid_term']
        lookup_inst.run(terms)
        assert 1 == 0, 'Expecting an AnsibleLookupError to be raised'
    except AnsibleLookupError as e:
        print(e)
        assert 'Unable to find setting' in to_native(e)

    # Test on_missing='skip'
    lookup_inst = LookupModule()
    lookup_

# Generated at 2022-06-21 05:43:34.818101
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-21 05:43:35.957814
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test message'
    x = MissingSetting(msg)
    assert x.message == msg

# Generated at 2022-06-21 05:43:37.115803
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting('test_message')
    MissingSetting('test_message', 'test_orig_exc')

# Generated at 2022-06-21 05:43:42.941431
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = LookupModule()
    exception = MissingSetting('a')

    assert exception.orig_exc is None
    assert exception.obj is None
    assert exception.reason == 'a'
    assert exception.msg is None


# Generated at 2022-06-21 05:43:48.242660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_result = LookupModule().run(terms=['vault_password_file'], variables=dict(vault_password_file='/test/test_vault_file'))
    assert lookup_result == ['/test/test_vault_file']

    lookup_result = LookupModule().run(terms=['no_such_setting'], variables=dict(no_such_setting='/test/test_vault_file'))
    assert lookup_result == []

    lookup_result = LookupModule().run(terms=['no_such_setting'],
                                       variables=dict(no_such_setting='/test/test_vault_file'),
                                       on_missing='error')
    assert lookup_result == []


# Generated at 2022-06-21 05:44:10.673640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.yaml
    

# Generated at 2022-06-21 05:44:11.710044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)

# Generated at 2022-06-21 05:44:13.499746
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Missing setting test')
    except MissingSetting as e:
        assert 'Missing setting test' == to_native(e)

# Generated at 2022-06-21 05:44:16.918451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-21 05:44:19.042369
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_plugin = LookupModule()
    except Exception as err:
        assert False , 'Unable to create LookupModule object. Error: {}'.format(err)

# Generated at 2022-06-21 05:44:21.601801
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 05:44:27.927795
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # Test constructor without params
    assert MissingSetting() is not None

    # Test 'args' parameter
    assert MissingSetting('Test message').args[0] == 'Test message'

    # Test 'cause' parameter
    assert MissingSetting('Test message', cause=ValueError('Test cause')).args[0] == 'Test message'

# Generated at 2022-06-21 05:44:29.353440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert getattr(LookupModule, 'run') is not None

# Generated at 2022-06-21 05:44:42.252179
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:44:47.618287
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_msg = 'test error message'
    orig_exc = None
    e = MissingSetting(error_msg, orig_exc)
    assert error_msg in to_native(e)
    assert e.orig_exc is orig_exc

# Generated at 2022-06-21 05:45:04.715488
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert isinstance(MissingSetting("UNKNOWN", None), MissingSetting)

# Generated at 2022-06-21 05:45:07.541523
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
  # MissingSetting instantiation
  ms = MissingSetting()
  # Then calling str() on it
  str(ms)

# Generated at 2022-06-21 05:45:17.638230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    # creating instance of LookupModule class
    lookup_module = LookupModule()

    # check if the required class attribute got initialized
    assert hasattr(lookup_module, '_display')

    # check if the specified plugin_type exists in the config file
    plugin_type = 'become'
    assert plugin_type in C.config.settings.keys()

    # check if the specified plugin_name exists in the config file
    plugin_name = 'su'
    assert plugin_name in C.config.get_config_value(plugin_type)

    # execute run method and check if the output is as expected
    result = lookup_module.run

# Generated at 2022-06-21 05:45:27.370102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3

    # a sub-directory to use for storing configuration values
    # for this test
    subdir = '.lookup_test_config'

    # we need to make sure we're using the correct directory for
    # this test
    import os
    original_path = os.environ.get('ANSIBLE_CONFIG', None)
    if not original_path:
        original_path = os.environ.get('ANSIBLE_CONFIG', None)

    # clean out the cache and make sure it's empty before we run unit test
    import ansible.plugins.loader as plugin_loader
    plugin_loader.clear_cache()
    assert plugin_loader._CACHE == {}

    # now set the config path to be the test config subdir
    import ansible.constants as C


# Generated at 2022-06-21 05:45:37.907496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Unit Test for error case 1
    try:
        lookup_module.run(terms=["ANSIBLE_RETRY_FILES_ENABLED", "ANSIBLE_RETRY_FILES_SAVE_PATH"], plugin_type="become", plugin_name="default")
    except AnsibleOptionsError as e:
        assert e.message == 'Both plugin_type and plugin_name are required, cannot use one without the other'

    # Unit Test for error case 2

# Generated at 2022-06-21 05:45:43.988268
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # test no arguments
    with pytest.raises(TypeError):
        MissingSetting()
    # test with msg
    with pytest.raises(TypeError):
        MissingSetting('msg')
    # valid call with msg and orig_exc
    MissingSetting('msg', orig_exc=AnsibleOptionsError('orig_exc'))

# Generated at 2022-06-21 05:45:51.005742
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    c = MissingSetting('Test default')
    assert c.msg == 'Test default'
    assert c.orig_exc is None

    c = MissingSetting('Test with original exception', orig_exc='blah')
    assert c.msg == 'Test with original exception'
    assert c.orig_exc == 'blah'

# Generated at 2022-06-21 05:45:59.965026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['foo']).__len__() == 0
    assert module.run(['foo'], dict(ansible_config_file='/etc/ansible/ansible.cfg')).__len__() > 0
    assert module.run(['DEFAULT_ROLES_PATH']).__len__() > 0
    assert module.run(['DEFAULT_ROLES_PATH'], dict(ansible_config_file='/etc/ansible/ansible.cfg')).__len__() > 0
    assert module.run(['DEFAULT_ROLES_PATH', 'DEFAULT_CACHE_PLUGIN']).__len__() > 0

# Generated at 2022-06-21 05:46:01.593505
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert str(MissingSetting('error')) == "error"

# Generated at 2022-06-21 05:46:05.178706
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Unit test for constructor of class MissingSetting"""
    m = MissingSetting('test message')
    assert m.message == 'test message'

# Generated at 2022-06-21 05:46:34.808661
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = AnsibleOptionsError('foo')
    m = MissingSetting('bar', orig_exc=e)
    assert m.orig_exc == e

# Generated at 2022-06-21 05:46:40.478995
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting('test error')
    assert exception.message == 'test error'
    exception = MissingSetting(Exception('test error'))
    assert exception.message == 'Unhandled exception while looking up a setting: test error'

# Generated at 2022-06-21 05:46:46.292913
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    args = 'more-than-one-argument'
    exc = LookupError('this is an exception')
    test_value = MissingSetting(args, orig_exc=exc)
    assert test_value.message == args
    assert test_value.orig_exc == exc

# Generated at 2022-06-21 05:46:49.795696
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_obj = LookupModule()
    assert lookup_obj is not None



# Generated at 2022-06-21 05:46:58.344421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Test constructor
    '''
    plugin_config = 'ansible.cfg'
    loader = plugin_loader.LookupModuleLoader(None, None)
    lookup = LookupModule(loader=loader, basedir=None, runner=None, templar=None, vim_sense=None)
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 05:46:59.088440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:47:12.061740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO

    # set up the environment for the next call
    # format of constants.CONFIG_FILE_LOOKUP_ORDER:
    # [
    #    '/path/to/a/file',
    #    { 'module': 'ModName', 'arg1': "a", 'arg2': 1 }
    # ]
    C.CONFIG_FILE_LOOKUP_ORDER = [
        '/path/to/a/file',
        {'module': 'LookupModule'}
    ]
    # format of constants.CONFIG_FILE_PARSER_CONFIG:
    # {
    #    'foo1': 'bar1',
    #    'foo2': 'bar2'
    # }
    C.CONFIG_FILE_PARSER_CONFIG

# Generated at 2022-06-21 05:47:14.921727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=dict())
    result = lookup_plugin.run([u'DEFAULT_ROLES_PATH'])
    assert result == [C.DEFAULT_ROLES_PATH]


# Generated at 2022-06-21 05:47:19.989366
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('message', orig_exc=AnsibleLookupError())
    assert exc.message == 'message'
    assert isinstance(exc.orig_exc, AnsibleLookupError)
    assert str(exc) == 'message'

# Generated at 2022-06-21 05:47:24.823112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'UNKNOWN_CONFIG_KEY'], variables=None, on_missing='error') == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'UNKNOWN_CONFIG_KEY'], variables=None, on_missing='warn') == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'UNKNOWN_CONFIG_KEY'], variables=None, on_missing='skip') == ['root']

# Generated at 2022-06-21 05:48:25.559987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_arr = ['configuration_value']
    # test_arr1 = ['configuration_value', 'configuration_value']
    # test_arr1 = ['configuration_value', 'configuration_value']
    # test_arr_fail = ['configuration_value', 'configuration_value']
    # test_arr_fail = ['configuration_value', 'configuration_value']
    # test_arr_fail = ['configuration_value', 'configuration_value']

# Generated at 2022-06-21 05:48:26.408479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(str(LookupModule()) != None)

# Generated at 2022-06-21 05:48:28.643752
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting('Test Error')

    assert ms.message == 'Test Error'

# Generated at 2022-06-21 05:48:32.578087
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    testee = MissingSetting('test exception')
    assert testee.orig_exc is None
    assert testee.message == 'test exception'

# Generated at 2022-06-21 05:48:42.115148
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test that a lookup with missing options fails
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[], variables = {}, on_missing = 'error', plugin_type = 'connection', plugin_name = 'ssh')
        assert False, 'Should not be able to run with missing terms'
    except AnsibleLookupError:
        pass

    try:
        lookup_module.run(terms=['remote_user'], variables = {}, on_missing = 'error', plugin_type = 'connection', plugin_name = 'ssh')
        assert False, 'Should not be able to run with plugin_type and plugin_name missing'
    except AnsibleLookupError:
        pass


# Generated at 2022-06-21 05:48:52.537120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {}, 'grains': {}}
    loader = DataLoader()
    lookup_loader = LookupLoader(None, loader=loader)
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    mock_task_vars = {"inventory_hostname": "test_hostname"}
    mock_play_context = type('obj', (object,), {"VERBOSITY": 0})()
    lookup_instance = LookupModule()
    lookup_instance.set_loader(lookup_loader)
    # lookup used with a single term
    terms = "localhost"
    result = lookup_instance.run(terms, variables=mock_task_vars, runner_items=[])

# Generated at 2022-06-21 05:49:02.245510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert 'AnsibleLookupError' in str(
        lookup.run(['user'], on_missing='error'))

    assert 'Unable to find setting' in str(
        lookup.run(['user'], on_missing='warn'))
    assert 'AnsibleLookupError' in str(
        lookup.run(['user'], on_missing='something else'))

    assert 'AnsibleLookupError' in str(
        lookup.run(['user'], on_missing='error'))

    assert 'AnsibleLookupError' in str(
        lookup.run(['user'], on_missing='error'))

    assert 'Skipping' in str(
        lookup.run(['user'], on_missing='warn'))


# Generated at 2022-06-21 05:49:08.118338
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting("AnsibleOptionError", "ValueError")

    assert m.message == "AnsibleOptionError"
    assert 'orig_exc' in m.kwargs
    assert repr(m) == "<MissingSetting message:AnsibleOptionError,orig_exc:ValueError>"

# Generated at 2022-06-21 05:49:09.819060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-21 05:49:20.896088
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.playbook.play_context import PlayContext

    def test_var(value):
        return {'ansible_config_var': value}

    def test_vars(config, plugin_name=None, plugin_type=None):
        variables = {'config': {'plugin_name': plugin_name,
                                'plugin_type': plugin_type}}
        return combine_vars(variables, config)

    def test_options(config=None, plugin_name=None, plugin_type=None, on_missing='error'):
        combined_vars = test_vars(test_var(config), plugin_name, plugin_type)

# Generated at 2022-06-21 05:51:20.810555
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    m1 = MissingSetting("Error Message")
    assert m1.msg == "Error Message"
    assert m1.orig_exc is None

    e = Exception("Original Exception")
    m2 = MissingSetting("Error Message",orig_exc=e)
    assert m2.msg == "Error Message"
    assert m2.orig_exc == e

# Generated at 2022-06-21 05:51:25.019700
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.kwargs['orig_exc'] is None
        assert e.args == ('test',)

# Generated at 2022-06-21 05:51:38.235405
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test with only the message
    msg = 'This is a message'
    test_error = MissingSetting(msg)
    assert test_error.message == msg

    # Test with message and original exception
    exc = Exception('This is the original exception')
    test_error = MissingSetting(msg, exc)
    assert test_error.message == msg
    assert test_error.orig_exc == exc

    # Test with original exception only
    test_error = MissingSetting(None, exc)
    assert test_error.message == str(exc)
    assert test_error.orig_exc == exc

    # Test with empty string
    test_error = MissingSetting('')
    assert test_error.message == ''
    assert test_error.orig_exc is None

    # Test with empty string and original exception

# Generated at 2022-06-21 05:51:50.368102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a dummy config file
    config_file = open("test_ansible.cfg", "w+")
    config_file.write("[defaults]\n")
    config_file.write("test1 = test2\n")
    config_file.close()
    # create a dummy plugin
    test_plugin = open("test_plugin.py", "w+")
    test_plugin.write("from ansible.plugins.loader import connection_loader\n")
    test_plugin.write("from ansible.plugins.connection import ConnectionBase\n")
    test_plugin.write("class ConnectionModule(ConnectionBase):\n")
    test_plugin.write("    pass\n")
    test_plugin.close()
    # invoke the method
    lm = LookupModule()

# Generated at 2022-06-21 05:51:55.906461
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Will produce a warning and return [None]
    lm = LookupModule()
    lm.set_options(direct=dict(on_missing='warn'))
    assert lm.run(['foo']) == [None]

# Generated at 2022-06-21 05:52:01.287981
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    from ansible.utils.sentinel import Sentinel


    # Test constructor with only the `msg` parameter
    msg = "Test message"
    missing_setting = MissingSetting(msg)
    assert missing_setting.msg == msg
    assert missing_setting.orig_exc == Sentinel

    # Test constructor with all parameters
    orig_exc = AnsibleOptionsError("Ansible error message")
    missing_setting = MissingSetting(msg, orig_exc=orig_exc)
    assert missing_setting.msg == msg
    assert missing_setting.orig_exc == orig_exc

# Generated at 2022-06-21 05:52:05.613375
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Constructor with one parametr
    exc = MissingSetting('e')
    assert exc.orig_exc is None
    assert 'e' in str(exc)

    try:
        # Constructor with two parameters
        raise MissingSetting('a', 'b')
    except MissingSetting as exc:
        assert exc.orig_exc is 'b'
        assert 'a' in str(exc)

# Generated at 2022-06-21 05:52:06.787978
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(["DEFAULT_BECOME_USER"])

# Generated at 2022-06-21 05:52:09.765165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([]) == []


# Generated at 2022-06-21 05:52:16.496658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    kwargs = {'on_missing': 'error', 'plugin_type': 'become', 'plugin_name': 'sudo'}
    lm = LookupModule()
    res = lm.run(terms=terms, **kwargs)
    assert res == ['root']

