

# Generated at 2022-06-21 05:43:04.353194
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import patch
    from ansible.plugins.lookup import LookupBase

    lookup_module = LookupModule()
    assert lookup_module is not None
    assert isinstance(lookup_module, LookupBase)


# Generated at 2022-06-21 05:43:04.933899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-21 05:43:09.073788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)

# Generated at 2022-06-21 05:43:11.217557
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 05:43:15.026600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as loader
    assert isinstance(loader.new('ansible.plugins.lookup.config', ClassArgs()), LookupModule)



# Generated at 2022-06-21 05:43:19.321055
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    constructor_exception_messages = (
        {
            'args': [],
            'msg': 'Exception message is missing'
        },
        {
            'args': ['message'],
            'msg': 'message'
        },
    )

    for test in constructor_exception_messages:
        assert test['msg'] == MissingSetting(*test['args']).message

# Generated at 2022-06-21 05:43:20.865537
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
  try:
    raise MissingSetting('error message')
  except MissingSetting as e:
    assert 'error message' in str(e)

# Generated at 2022-06-21 05:43:28.980072
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # AnsibleModule will be needed to create object of LookupModule
    class AnsibleModule:

        def __init__(self):
            # Will be used to instantiate object of LookupBase in LookupModule
            class AnsibleModuleApi(LookupBase):

                def __init__(self):
                    self.params = {}
            self.params = {}
            self.api = AnsibleModuleApi()

    lookup_obj = LookupModule(AnsibleModule())
    assert lookup_obj is not None

# Generated at 2022-06-21 05:43:41.661448
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting()
    assert exc.orig_exc is None
    assert exc.option_name is MissingSetting.default_option_name
    assert exc.env_var is None
    assert exc == MissingSetting(MissingSetting.default_option_name)

    orig_exc = Exception('test')
    option_name = 'test'
    env_var = 'test'
    exc = MissingSetting(option_name, orig_exc=orig_exc, options=env_var)
    assert exc.orig_exc is orig_exc
    assert exc.options is env_var
    assert exc.option_name is option_name
    assert exc.env_var is env_var

    assert exc != MissingSetting(option_name)

    exc2 = MissingSetting(option_name, orig_exc=orig_exc, options=env_var)
   

# Generated at 2022-06-21 05:43:46.134156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Run the run method of lookup module.
    DEFAULT_BECOME_USER is a global configuration setting and
    'color' is a setting of cliconf plugin.
    :return:
    """
    lookup_module_obj = LookupModule()
    terms = ["DEFAULT_BECOME_USER"]
    plugin_type = "cliconf"
    plugin_name = "color"
    lookup_module_obj.run(terms)
    result = lookup_module_obj.run(terms, plugin_type=plugin_type, plugin_name=plugin_name)
    print(result)

# Generated at 2022-06-21 05:44:02.450995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''

    # init
    lm = LookupModule()
    test_terms = ['foo', 'bar', 'baz', 'hello', 'world']
    test_vars = {'ansible_check_mode': True}

    # test with plugin_type, plugin_name
    plugin_type = 'inventory'
    plugin_name = 'foo'
    test_options = {'plugin_type': plugin_type, 'plugin_name': plugin_name, 'default': 'test_ok'}
    lm.set_options(**test_options)
    result = lm.run(terms=test_terms, variables=test_vars)
    assert result == ['test_ok'] * 5

    # test with on_missing

# Generated at 2022-06-21 05:44:10.774410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test a valid term
    terms = ['DEFAULT_BECOME_USER']
    expected = C.DEFAULT_BECOME_USER
    result = lookup_module.run(terms)
    assert result == [expected]

    # Test a invalid term
    terms = ['DEFAULT_BECOME_USER_foo']
    expected = []
    result = lookup_module.run(terms)
    assert result == expected

    # Test a list of terms, both valid and invalid
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_USER_foo']
    expected = [C.DEFAULT_BECOME_USER]
    result = lookup_module.run(terms)
    assert result == expected

    # Test a missing term, with option on_missing = skip


# Generated at 2022-06-21 05:44:20.027140
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    terms = [
        'some_bool',
        'some_int',
        'some_string',
        'some_list',
        'some_dict',
        'some_unicode',
        'some_invalid_key'
    ]

    variables = {
        'some_bool': True,
        'some_int': 42,
        'some_string': 'some_value',
        'some_list': [1, 2, 3],
        'some_dict': {'a': 1, 'b': 2},
    }

    expected = [True, 42, 'some_value', [1, 2, 3], {'a': 1, 'b': 2}, None, None]

    # Act
    lookupModule = LookupModule()
    results = lookupModule.run(terms, variables)

   

# Generated at 2022-06-21 05:44:32.416243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import yaml
    from ansible.plugins.loader import lookup_loader

    config_data = '''
    DEFAULT_BECOME_USER: "root"
    DEFAULT_ROLES_PATH: "/var/lib/ansible/roles"
    RETRY_FILES_SAVE_PATH: "/var/lib/ansible/retry"
    '''

    config_yaml = yaml.safe_load(config_data)
    lookup_plugin = lookup_loader.get('config')
    result = lookup_plugin.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH'], config_yaml)
    assert result == ['root', '/var/lib/ansible/roles', '/var/lib/ansible/retry']

# Generated at 2022-06-21 05:44:37.714551
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_msg = 'test message'
    orig_exc = Exception('test')
    instance = MissingSetting(test_msg, orig_exc)
    assert instance.msg == test_msg
    assert instance.orig_exc == orig_exc

# Generated at 2022-06-21 05:44:39.050790
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 05:44:42.489725
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_mod = LookupModule()
    assert test_lookup_mod is not None

# Generated at 2022-06-21 05:44:50.190052
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term = 'COLOR_OK'
    result = LookupModule().run(terms=term, variables=None, **{'var_options':{'ansible_python_interpreter':'/usr/bin/python'}, 'direct':{'on_missing':'error', 'plugin_type':'shell', 'plugin_name':'sh'}})
    assert result[0] == 'green'

# Generated at 2022-06-21 05:44:51.874293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Testing of method run
    """
    pass

# Generated at 2022-06-21 05:44:58.081321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["one", "two"]
    result = module.run(terms, variables={}, plugin_type="connection", plugin_name="ssh")
    print(result)

# Execute test
# test_LookupModule_run()

# Generated at 2022-06-21 05:45:14.446539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 05:45:25.409173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''

    # External dependencies
    import os

    # Define an object of LookupModule
    lookup_module = LookupModule()

    # Get the value for the config
    result = lookup_module.run("DEFAULT_BECOME_USER")
    assert result == ['root']

    lookup_module.set_options(var_options={'CONFIG_PATH': os.path.dirname(os.path.dirname(os.path.abspath(__file__)))})
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run('executable')
    assert result == [lookup_module._get_bin_path('sh')]

# Generated at 2022-06-21 05:45:35.167555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader
    class FakeSentinel():
        def __init__(self, name):
            self.name = name
    terms = 'config_setting'
    variables = None
    kwargs= {'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'sh'}
    lookup_plugin = LookupModule()
    lookup_plugin._display = ansible.plugins.loader.lookup_loader._display
    ansible.plugins.loader.lookup_loader._display = None
    assert lookup_plugin.run(terms, variables, **kwargs) == [FakeSentinel('fake_sentinel')]
    ansible.plugins.loader.lookup_loader._display = lookup_plugin._display

# Generated at 2022-06-21 05:45:45.609954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with direct
    lookup = LookupModule()
    lookup.set_options(direct={'on_missing': 'error'})
    assert lookup.get_option('on_missing') == 'error'

    # Test with var_options
    lookup = LookupModule()
    lookup.set_options(var_options='{"on_missing": "error"}')
    assert lookup.get_option('on_missing') == 'error'

    # Test with both var_options and direct
    lookup = LookupModule()
    lookup.set_options(var_options='{"on_missing": "error"}', direct={'on_missing': 'warn'})
    assert lookup.get_option('on_missing') == 'warn'

# Generated at 2022-06-21 05:45:58.267894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run of class LookupModule

    Asserts that:
        * method run returns a list of strings
        * method run raise AnsibleOptionsError when 'on_missing' is not in ['error', 'warn', 'skip']
        * method run raise AttributeError when term is not found
        * method run return a list of strings when on_missing is 'warn'
    """

    import ansible.constants as C

    lookup_module = LookupModule()

    # GIVEN
    terms = ['DEFAULT_BECOME_USER']
    on_missing = 'error'
    # WHEN
    result = lookup_module.run(terms, on_missing=on_missing)
    # THEN
    assert isinstance(result, list), 'run method should return a list of strings'

# Generated at 2022-06-21 05:46:04.384726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj.file_name is None
    assert lookup_obj._display is not None
    assert lookup_obj.unique is False

    assert lookup_obj.options == {}
    assert lookup_obj.var_options == None


# Generated at 2022-06-21 05:46:07.272328
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # pylint: disable=protected-access
    assert MissingSetting._instance is None
    assert MissingSetting._args is None
    assert MissingSetting._kwargs is None

# Generated at 2022-06-21 05:46:10.184084
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:46:12.752567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Only constructor tests.
    assert bool(LookupModule())

# Generated at 2022-06-21 05:46:16.994405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ returns the value of DEFAULT_BECOME_USER """
    results = LookupModule().run(['DEFAULT_BECOME_USER'], variables=None, direct={})
    assert results == [C.DEFAULT_BECOME_USER]


# Generated at 2022-06-21 05:46:45.633915
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
   assert(str(MissingSetting("example message", orig_exc=None)) == "example message")

# Generated at 2022-06-21 05:46:48.717628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 05:47:01.995188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global_config = {
        'DEFAULT_ROLES_PATH': ['/home/user/.ansible/roles'],
        'RETRY_FILES_SAVE_PATH': '/home/user/.ansible/retry'
    }

# Generated at 2022-06-21 05:47:08.242256
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    "missing setting test"

    # This is not a functional test, just a unit test for the class MissingSetting
    try:
        raise MissingSetting('This is a test exception')
    except:
        assert type(AnsibleOptionsError) == type(sys.exc_info()[0])

# Generated at 2022-06-21 05:47:10.519492
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('No such setting', 'UNKNOWN_SETTING')
    assert m.message == 'No such setting'
    assert m.setting == 'UNKNOWN_SETTING'

# Generated at 2022-06-21 05:47:19.561039
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # MissingSetting has 2 hidden args: msg, orig_exc
    # 2nd one is set to None by default
    m1 = MissingSetting('test msg')

    # Check __str__()
    assert str(m1) == 'test msg'

    # Check msg
    assert m1.args[0] == 'test msg'

    # Check orig_exc
    assert m1.orig_exc is None

# Generated at 2022-06-21 05:47:21.196179
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'foo bar baz'
    orig_exc = None
    MissingSetting(msg, orig_exc)

# Generated at 2022-06-21 05:47:24.980462
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.missing_key == 'test'

# Generated at 2022-06-21 05:47:27.052909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupBase()
    assert isinstance(instance, LookupBase)

# Generated at 2022-06-21 05:47:36.123309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup mocks
    mock_self = mock.MagicMock(spec_set=LookupModule)
    mock_terms = ['DEFAULT_BECOME_USER']
    mock_variables = dict(ansible_become_user='foo')
    mock_kwargs = dict(on_missing='error')

    # create a fake plugin class to mock plugin loading
    class fake_plugin(object):
        def __init__(self):
            self._load_name = 'fake_plugin'

    # We need to mock the ansible.plugins.loader.XXX_loader to load the fake_plugin
    # Above in __init__ we set the name of the fake_plugin to 'fake_plugin' so that
    # we can later use it for lookup.
    mock_loader = mock.MagicMock()

# Generated at 2022-06-21 05:48:32.003096
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    try:
        raise MissingSetting("Message")
    except MissingSetting as e:
        assert e.message == "Message"

# Generated at 2022-06-21 05:48:38.478860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for global scope
    pm = LookupModule()
    result = pm.run([])
    assert result == ['error']

    # Test for lookup configuration at plugin level
    pm = LookupModule(plugin_type='connection', plugin_name='ssh')
    result = pm.run(['remote_user', 'port'])
    assert result[0] == 'remote_user' and result[1] == 22

# Generated at 2022-06-21 05:48:40.691090
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('This is a test')
    except AnsibleOptionsError as e:
        assert e.orig_exc is not None
    else:
        assert False, "Should have raised exception"

# Generated at 2022-06-21 05:48:41.566554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()

# Generated at 2022-06-21 05:48:43.644134
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('This is a unit test for the constructor of class MissingSetting')
    except MissingSetting as e:
        assert(str(e) == 'This is a unit test for the constructor of class MissingSetting')

# Generated at 2022-06-21 05:48:46.274550
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert lookupModule is not None, "lookupModule is None"

# Generated at 2022-06-21 05:48:48.260911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # default on_missing = error
    l = LookupModule()
    assert type(l) is LookupModule

# Generated at 2022-06-21 05:48:52.754107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import inspect
    import sys
    import os

    test_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    top_dir = os.path.dirname(test_dir)
    sys.path.insert(0, top_dir)
    from ansible.plugins.loader import lookup_loader

    lookup_plugin_class = lookup_loader.get('config')

    assert lookup_plugin_class == LookupModule

# Generated at 2022-06-21 05:48:54.980083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.set_options()
    result = LookupModule.run(terms=["DEFAULT_ROLES_PATH"])
    assert result == ["/etc/ansible/roles:/usr/share/ansible/roles"]

# Generated at 2022-06-21 05:48:55.883593
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('error').msg == 'error'

# Generated at 2022-06-21 05:50:43.215232
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Unable to find setting %s' % 'foo'
    e = MissingSetting(msg)
    assert e.message == msg

# Generated at 2022-06-21 05:50:45.303512
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:50:49.363869
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting("foo bar")
    assert error.setting_name == 'foo bar'
    assert error.orig_exc is None
    assert error.setting_name in str(error)

# Generated at 2022-06-21 05:50:57.820944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a 'dummy' class, which inherits class LookupModule.
    # This is necessary because class LookupModule requires some attributes which are implemented in the parent class
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/lookup/__init__.py#L56-L73
    class Test(LookupModule):
        def __init__(self, *args, **kwargs):
            self.display = kwargs.get('display')
            self.options = kwargs.get('options')


    # Instatinate class Test
    t = Test(loader=None, display=None, options=None)

    # Test for method run
    # Test case 1: when the type of 'terms' is a string

# Generated at 2022-06-21 05:51:04.251681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    res = lm.run(['DEFAULT_ROLES_PATH', 'UNKNOWN_PATH'], variables={}, on_missing='warn', plugin_type='connection', plugin_name='winrm')
    assert res == [[u'roles'], []]



# Generated at 2022-06-21 05:51:04.793877
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    l.run()

# Generated at 2022-06-21 05:51:10.632369
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Expected result with a message and an origin exception
    expected_result = "message1"
    origin_exception = AnsibleOptionsError("message2")
    # Test constructor and getters
    msg = MissingSetting("message1", origin_exception)
    assert expected_result == msg.get_message()
    assert origin_exception == msg.get_origin_exception()
    return True

# Generated at 2022-06-21 05:51:19.310408
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    '''Test to ensure that the constructor of class MissingSetting properly formats exceptions'''
    msg = 'test message'
    orig_exc = Exception('orig message')

    # Test without original exception
    exc = MissingSetting(msg)
    assert exc.message == msg
    assert exc.orig_exc is None
    assert str(exc) == msg

    # Test with original exception
    exc = MissingSetting(msg, orig_exc)
    assert exc.message == msg
    assert exc.orig_exc == orig_exc
    assert str(exc) == msg + " (original exception: " + str(orig_exc) + ")"

# Generated at 2022-06-21 05:51:26.092134
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    plugin_name = 'raw'
    plugin_type = 'shell'

    test_val = MissingSetting('Unable to find setting %s' % plugin_name)
    assert isinstance(test_val, AnsibleOptionsError)

    test_val = MissingSetting('Unable to find setting %s' % plugin_type)
    assert isinstance(test_val, AnsibleOptionsError)

# Generated at 2022-06-21 05:51:38.418352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import AnsibleVars
    import sys

    vars_orig = AnsibleVars(combine_vars(loader=None, variables=dict()), include_cache=dict())
    for var in vars_orig.data:
        assert var not in vars_orig.cache

    test_LookupModule = LookupModule()

    # object is initialized correctly
    assert test_LookupModule.vars_cache == dict()
    assert test_LookupModule.vars == vars_orig
    assert test_LookupModule.basedir == None
    assert test_LookupModule.current_basedir == None

    # no error thrown when no argument is passed
    test_LookupModule.run([], dict())

    # AnsibleOptions