

# Generated at 2022-06-21 05:42:59.643322
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # Just run the constructor for now
    msg = 'test msg'
    exc = MissingSetting(msg)

    assert msg == str(exc)

# Generated at 2022-06-21 05:43:03.720318
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # create class instance
    cls = MissingSetting("test setting", orig_exc=Exception("testing"))

    # check that the attribute 'orig_exc' is defined
    if not hasattr(cls, 'orig_exc'):
        raise Exception("MissingSetting instance is missing 'orig_exc' attribute!")

# Generated at 2022-06-21 05:43:08.282137
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-21 05:43:12.175172
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Example import from docs
    from ansible.plugins.lookup import LookupModule
    # Example from docs
    l = LookupModule()
    l.run()

# Generated at 2022-06-21 05:43:14.802462
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e1 = MissingSetting('test message')
    exc = AnsibleOptionsError('test message', orig_exc=e1)
    assert e1.orig_exc == exc

# Generated at 2022-06-21 05:43:16.101489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global ret
    l = LookupModule()
    l.run({'DEFAULT_BECOME_USER'})

# Generated at 2022-06-21 05:43:29.377977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms='DEFAULT_ROLES_PATH') == [u'/etc/ansible/roles']
    assert lookup_module.run(terms='DEFAULT_ROLES_PATH', on_missing='skip') == [u'/etc/ansible/roles']
    assert lookup_module.run(terms='DEFAULT_ROLES_PATH', on_missing='warn') == [u'/etc/ansible/roles']
    assert lookup_module.run(terms='DEFAULT_ROLES_PATH', on_missing='error') == [u'/etc/ansible/roles']
    assert lookup_module.run(terms='UNKNOWN_ROLES_PATH', on_missing='error') == []

# Generated at 2022-06-21 05:43:34.439191
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test message'
    orig_exc = 'test exception'
    e = MissingSetting(msg, orig_exc)
    assert e.message == msg
    assert e.orig_exc == orig_exc

# Generated at 2022-06-21 05:43:37.718404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if __name__ == '__main__':
        print("Test LookupModule")
        lookup = LookupModule()
        lookup.run("COLOR_OK", wantlist=True)

# Generated at 2022-06-21 05:43:41.461593
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting('test error')

# Generated at 2022-06-21 05:43:57.399748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 05:43:59.382260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor for class LookupModule
    """
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 05:44:00.160647
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:44:01.277031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()


# Generated at 2022-06-21 05:44:05.879055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is a simple test that just validates that the lookup can be run
    # without errors.  The other unit tests test the internals of the module
    # in detail.
    lookup_instance = LookupModule()
    terms = 'DEFAULT_ROLES_PATH'.split()
    result = lookup_instance.run(terms)
    assert result == [['roles']]

# Generated at 2022-06-21 05:44:11.710208
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Empty config value
    module = LookupModule()
    assert(module.run("host") == [])
    assert(module.run("host_key_checking") == [])

    # Non empty config value
    module = LookupModule(variables={'DEFAULT_HOST_LIST':'/dev/null'})
    assert(module.run("host") == ['/dev/null'])
    assert(module.run("host_key_checking") == [False])

# Generated at 2022-06-21 05:44:15.337450
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # If constructor throws an exception, unit test failed.
    # So, if this test passes, it proves that constructor succeeded
    assert True

# Generated at 2022-06-21 05:44:22.301110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{lookup("config", "foo")}}')))
             ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None


# Generated at 2022-06-21 05:44:23.151457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 05:44:33.194039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Sent:
        def __init__(self, obj=None):
            self.obj = obj

    assert (LookupModule().run(["doesntexist"], {}, on_missing="error") == Sent(obj=[None]))
    assert (LookupModule().run(["doesntexist"], {}, on_missing="warn") == Sent(obj=[None]))
    assert (LookupModule().run(["doesntexist"], {}, on_missing="skip") == Sent(obj=[]))

    assert (LookupModule().run(["doesntexist", "alsodoesntexist"], {}, on_missing="error") == Sent(obj=[None, None]))
    assert (LookupModule().run(["doesntexist", "alsodoesntexist"], {}, on_missing="warn") == Sent(obj=[None, None]))

# Generated at 2022-06-21 05:44:49.420070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit  test lookup constructor."""
    assert callable(LookupModule)


# Generated at 2022-06-21 05:44:50.865552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 05:44:52.884911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:44:56.793166
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    the_class = MissingSetting()
    correct_type = isinstance(the_class, AnsibleOptionsError)
    assert correct_type

# Generated at 2022-06-21 05:44:58.871954
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting(msg='test')
    assert e.msg == 'test'

# Generated at 2022-06-21 05:45:01.842686
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('A is not defined', orig_exc=Exception())
    except AnsibleOptionsError as e:
        assert 'A is not defined' in str(e)
        assert 'Exception()' in str(e)
        assert e.orig_exc is not None


# Generated at 2022-06-21 05:45:07.316765
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert str(MissingSetting("foo bar bar")) == "foo bar bar"
    assert str(MissingSetting("foo bar bar", AttributeError("bar bar bar"))) == "foo bar bar (bar bar bar)"

# Generated at 2022-06-21 05:45:08.339002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        assert False, "Unable to instantiate module class"

# Generated at 2022-06-21 05:45:11.193405
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 05:45:13.074709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:45:44.226708
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'no such config'
    try:
        raise LookupModule.MissingSetting(msg)
    except LookupModule.MissingSetting as e:
        assert isinstance(e, LookupModule.MissingSetting)
        assert e.args[0] == msg
        assert e.args[1] is None

# Generated at 2022-06-21 05:45:56.329262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import pytest

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader, variable_manager)
    variable_manager.set_inventory(inventory_manager)

    c = LookupModule(display=display)
    result = c.run([], {"plugin_type": "shell", "plugin_name": "sh"})
    result_string = "".join(result)

    assert "Plugin not found" in result_string

# Generated at 2022-06-21 05:45:58.409988
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting('test')

# Generated at 2022-06-21 05:46:10.177093
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import ansible.plugins.loader as plugin_loader

    # no fail without plugin_name and plugin_type
    l = LookupModule()
    l.set_options(dict(direct=dict()))
    settings = ['DEFAULT_BECOME_USER', 'ANSIBLE_ROLES_PATH']

    for setting in settings:
        assert l.run([setting])[0] == getattr(C, setting)

    # we can get errors, so let the test fail
    settings_with_errors = ['ANSIBLE_COW_SELECTION']

    for setting in settings_with_errors:
        with pytest.raises(AnsibleOptionsError):
            l.run([setting])

    # we can skip settings too
    settings_to_skip = ['ANSIBLE_COW_SELECTION']

# Generated at 2022-06-21 05:46:15.509825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor 
    lookup = LookupModule()
    assert lookup.get_option('on_missing') == 'error'
    assert lookup.get_option('plugin_type') is None
    assert lookup.get_option('plugin_name') is None

# Generated at 2022-06-21 05:46:18.398288
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test message.'
    orig_exc = 'original exception.'
    ms = MissingSetting(msg, orig_exc=orig_exc)
    assert ms.message == msg
    assert ms.orig_exc == orig_exc

# Generated at 2022-06-21 05:46:24.711001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # GIVEN
    options = {'plugin_type': 'connection', 'plugin_name': 'local'}

    # WHEN
    result = lookup.run(['executable'], **options)

    # THEN
    assert result == ['/bin/sh']



# Generated at 2022-06-21 05:46:35.005167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    if not PY3:
        raise SkipTest

    class Settings:
        # This class will be used to replace ansible.constants.C in the test
        # so that we can specify what value should the config return
        class DEFAULT_REMOTE_USER:
            pass

    class TestClass:
        lookup_plugin_name = 'config'
        args = ['DEFAULT_REMOTE_USER']
        options = {}

        def run(self, **kwargs):
            import ansible.module_utils.six as six
            from ansible.parsing.plugin_docs import read_docstring

            display = kwargs.get('display', None)

# Generated at 2022-06-21 05:46:39.826488
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting(msg='test')
    except MissingSetting as err:
        assert err.msg == 'test'

# Generated at 2022-06-21 05:46:45.219737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    import unittest, mock
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel

    class LookupBaseMock(LookupBase):
        def __init__(self):
            self.display = mock.MagicMock()
            self.display_vars = []
            self.value = None
            self.options = {}
            self.value2 = None
            self.options2 = {}

        def set_options(self, var_options=None, direct=None):
            if var_options != None:
                self.value = var_options[0]
                self.options = var_options[1]
            if direct != None:
                self.value2 = direct['var_options']
                self.options2 = direct['direct']


# Generated at 2022-06-21 05:47:43.881673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.get_option('var_options') == None
    assert lookup_module.get_option('direct') == None
    lookup_module.set_options(var_options='variables', direct='kwargs')
    assert lookup_module.get_option('var_options') == 'variables'
    assert lookup_module.get_option('direct') == 'kwargs'

# Generated at 2022-06-21 05:47:45.289139
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 05:47:47.255583
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-21 05:47:55.905506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test on_missing=error and missing setting
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)
    terms = ['UNKNOWN']
    lookup_obj.set_options({'on_missing': 'error'})
    try:
        lookup_obj.run(terms)
        assert False,"Should have failed but did not"
    except AnsibleLookupError as e:
        assert e.message == 'Unable to find setting UNKNOWN'
        pass

    #Test on_missing=warn and missing setting
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)
    terms = ['UNKNOWN']
    lookup_obj.set_options({'on_missing': 'warn'})

# Generated at 2022-06-21 05:47:56.825370
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 05:47:58.716704
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l.get_option('var_options'), dict)

# Generated at 2022-06-21 05:48:04.478102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert lookup_module.get_option('on_missing') == 'error'
    assert lookup_module.get_option('plugin_name') is None
    assert lookup_module.get_option('plugin_type') is None

# Generated at 2022-06-21 05:48:17.920812
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    try:
        lookup.run(terms=[], variables=None, on_missing='error', plugin_type='connection', plugin_name='local')
    except AnsibleOptionsError as exc:
        pass
    else:
        assert False, "should have raised exception"
    try:
        lookup.run(terms=[], variables=None, on_missing='error', plugin_type='connection')
    except AnsibleOptionsError as exc:
        pass
    else:
        assert False, "should have raised exception"
    try:
        lookup.run(terms=[], variables=None, on_missing='error', plugin_name='local')
    except AnsibleOptionsError as exc:
        pass
    else:
        assert False, "should have raised exception"

# Generated at 2022-06-21 05:48:30.204846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Executing tests of LookupModule module')

    class MyLookupModule(LookupModule):
        def __init__(self):
            self.cwd = '/my/path/'
            self.tmpdir = '/tmp/'
            self.basedir = '/my/path/'
            self.get_option = lambda opt, var_options, direct=None : 'error'

    m = MyLookupModule()

    try:
        result = m.run('/bad/path', variables={'var1': 'value1'})
        raise Exception('The run() method did not raise AnsibleOptionsError for invalid term')
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-21 05:48:34.583007
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print ("Testing constructor of class LookupModule")
    obj = LookupModule()
    assert isinstance(obj, LookupModule)
    # assert obj.run


# assert hasattr(obj, 'run')

# Generated at 2022-06-21 05:50:22.346543
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test_MissingSetting")
    except MissingSetting as e:
        assert e.message == "test_MissingSetting"

# Generated at 2022-06-21 05:50:26.215679
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with pytest.raises(AnsibleOptionsError):
        LookupModule(runner=None, templar=None, variables=None).run(terms=[], on_missing='error')[0]
    assert LookupModule(runner=None, templar=None, variables=None).run(terms=[], on_missing='warn')[0] == []
    assert LookupModule(runner=None, templar=None, variables=None).run(terms=[], on_missing='skip')[0] == []

# Generated at 2022-06-21 05:50:27.376980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:50:35.499739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run( ["localhost"], None, on_missing='default', plugin_type='connection', plugin_name='local')
    assert result == []
    result = lookup.run( ["localhost"], None, on_missing='default', plugin_type='connection', plugin_name='local')
    assert result == []

    result = lookup.run( ["existsetting"], None, on_missing='error', plugin_type='connection', plugin_name='local')
    assert result == []
    result = lookup.run( ["existsetting"], None, on_missing='warn', plugin_type='connection', plugin_name='local')
    assert result == []
    result = lookup.run( ["existsetting"], None, on_missing='skip', plugin_type='connection', plugin_name='local')
    assert result == []


# Generated at 2022-06-21 05:50:37.879905
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 05:50:42.388323
# Unit test for constructor of class LookupModule
def test_LookupModule():
  terms=['DEFAULT_BECOME_USER']
  variables={}
  ret = LookupModule().run(terms, variables=variables)
  assert len(ret) == 1 and ret[0] == 'root'

# Generated at 2022-06-21 05:50:48.348440
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockModuleUtils(object):
        def __init__(self, module_utils):
            self.module_utils = module_utils
            self.plugins = []
            self.instances = []

        def setup_loader(self):
            pass

        def add_plugin(self, plugin, *args, **kwargs):
            self.plugins.append(plugin)

        def get_plugin(self, name, *args, **kwargs):
            return self.plugins.pop(0)

        def plugin_class(self, name, *args, **kwargs):
            pass

        def _load_plugins(self, *args, **kwargs):
            pass

        def _create_instances(self, *args, **kwargs):
            pass


# Generated at 2022-06-21 05:50:52.207281
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Unable to find setting test')
    except MissingSetting as e:
        assert str(e) == 'Unable to find setting test'

# Generated at 2022-06-21 05:50:58.748985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # test empty term
    result = module.run([''], {}, on_missing='error')
    assert result == []

    # test missing lookup
    try:
        module.run(['bad_lookup'], on_missing='error')
    except AnsibleLookupError as e:
        assert 'did not find setting' in str(e)
    else:
        assert False, "Expecting AnsibleLookupError exception raised"

    # test missing global setting
    try:
        module.run(['bad_setting'], on_missing='error')
    except AnsibleLookupError as e:
        assert 'did not find setting' in str(e)
    else:
        assert False, "Expecting AnsibleLookupError exception raised"

    # test good global setting
    result = module.run

# Generated at 2022-06-21 05:51:09.561044
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule, with retry_files_enable
    result = LookupModule().run(terms=['retry_files_enabled'],
                                variables={'C.RETRY_FILES_ENABLED': True})
    assert result[0] == True

    # Unit test for method run of class LookupModule, with retry_files_save_path
    result = LookupModule().run(terms=['retry_files_save_path'],
                                variables={'C.RETRY_FILES_SAVE_PATH': '/path/to/dir'})
    assert result[0] == '/path/to/dir'

    # Unit test for method run of class LookupModule, with retry_files_save_path