

# Generated at 2022-06-21 05:43:00.831544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_cls = LookupModule()
    assert 'on_missing' in lookup_cls.options

# Generated at 2022-06-21 05:43:03.004122
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule) == True

# Generated at 2022-06-21 05:43:08.063137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    assert len(lookup_instance) == 0
    assert isinstance(lookup_instance, LookupBase)
    assert isinstance(lookup_instance, LookupModule)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-21 05:43:09.932716
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    def check(result):
        assert isinstance(result, MissingSetting)
        assert result.orig_exc

    check(MissingSetting('msg', orig_exc='original_exception'))

# Generated at 2022-06-21 05:43:14.290997
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert 'test' in str(e)
        assert 'was not defined' in str(e)

# Generated at 2022-06-21 05:43:16.109378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-21 05:43:18.850896
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    missing_setting = MissingSetting("Missing Setting")
    msg = 'Missing Setting'
    assert missing_setting.message == msg

# Generated at 2022-06-21 05:43:22.881442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_module = LookupModule()
        assert lookup_module
    except Exception as e:
        assert False, "unable to create object LookupModule"


# Generated at 2022-06-21 05:43:23.378435
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('test')

# Generated at 2022-06-21 05:43:28.007670
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Unable to find configuration specified by 'CONFIG_KEY'"
    orig_exc = AnsibleOptionsError(msg)
    obj = MissingSetting(msg, orig_exc)
    assert obj.message == msg
    assert obj.orig_exc == orig_exc

# Generated at 2022-06-21 05:43:48.453690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = dict(
            var_options={
                'start_at_task': 'yes'
            },
            direct={
                'plugin_type': 'shell',
                'plugin_name': 'bash',
                'on_missing': 'warn'
            })
    lookup_module = LookupModule()
    lookup_module.set_options(**options)
    assert lookup_module.get_option('on_missing') == 'warn'

# Generated at 2022-06-21 05:43:53.710288
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    instance = MissingSetting('The ANSIBLE_CONFIG environment variable is not set.")')
    assert instance.message == 'The ANSIBLE_CONFIG environment variable is not set.)'

# Generated at 2022-06-21 05:43:58.833821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    parameters = {
        "var_options": {},
        "direct": {
            "_terms": []
        }
    }
    class_under_test = LookupModule()
    class_under_test.run(terms=parameters["direct"]["_terms"], variables=parameters["var_options"])

# Generated at 2022-06-21 05:44:10.867122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_1():
        #prerequisites
        class VarManager():
            def __init__(self, variables=dict()):
                self.variables = variables
            def get_vars(self, loader, path, entities):
                return self.variables
        class VarOptions():
            def __init__(self, direct=dict()):
                self.direct = direct
            def __getitem__(self, key):
                return self.direct[key]

        #test execution
        lookup = LookupModule()
        lookup.set_loader = lambda loader: None
        lookup.set_env = lambda env: None
        lookup.set_vault_secrets = lambda vault_secrets: None
        lookup.set_variables = lambda var_manager: var_manager

# Generated at 2022-06-21 05:44:17.014293
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.six import PY3
    msg = "setting not defined"
    if PY3:
        import builtins
        builtins.__dict__['__AnsibleError__'] = AnsibleError
        base = AnsibleError
    else:
        base = Exception
    e = MissingSetting(msg, orig_exc=base)
    assert e.message == msg
    assert e.orig_exc == base

# Generated at 2022-06-21 05:44:18.589785
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test missing setting')
    assert e.args[0] == 'test missing setting'

# Generated at 2022-06-21 05:44:31.997045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option (on_missing) is 'error'
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'on_missing': 'error'})
    try:
        lookup_module.run([])
    except AnsibleLookupError:
        pass
    else:
        assert False, 'should have raised an exception'

    # Test if on_missing option is not one of ('error', 'warn', 'skip')
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'on_missing': 'invalid_type'})
    try:
        lookup_module.run([])
    except AnsibleLookupError:
        pass
    else:
        assert False, 'should have raised an exception'

    # Test if

# Generated at 2022-06-21 05:44:40.056690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    lookup_instance.set_options(var_options=None, direct={})
    loookup_instance_result = lookup_instance.run(['DEFAULT_ROLES_PATH'], variables=None, on_missing='skip', plugin_type=None, plugin_name=None)
    expected_result = lookup_instance._templar.template(loookup_instance_result[0])
    return expected_result

# Generated at 2022-06-21 05:44:42.717063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 05:44:46.939502
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('message')
    except AnsibleError as e:
        assert e.message == 'message'
        assert e.orig_exc is None


# Generated at 2022-06-21 05:45:10.054613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['name1']
    variables = {}
    kwargs = {}
    missing = 'error'
    ptype = None
    pname = None

    mod = LookupModule()
    mod.set_loader(None)
    mod.set_environment(None)
    result = mod.run(terms, variables, **kwargs)

    assert result is not None
    assert len(result) == 1

# Generated at 2022-06-21 05:45:13.154681
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([C.DEFAULT_BECOME_USER])
    l.run('DEFAULT_BECOME_USER')

# Generated at 2022-06-21 05:45:21.176245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        # Test for constructor without parameters
        result = LookupModule()

    except AnsibleOptionsError as e:
        # Show what is the error
        print('There is some error when using LookupModule(): %s' % str(e))

    except Exception as e:
        # Show the error to the user
        print('Unknown error occurs: %s' % str(e))

# Generated at 2022-06-21 05:45:25.620925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    # import os
    # if 'ANSIBLE_LIBRARY' in os.environ:
    #     p = os.environ['ANSIBLE_LIBRARY']
    #     os.environ['ANSIBLE_LIBRARY'] = ''
    # ansible.plugins.lookup.LookupModule = LookupModule
    # from ansible.plugins.loader import lookup_loader
    # lookup_plugin = lookup_loader.get('config')
    lookup_plugin = LookupModule()
    # os.environ['ANSIBLE_LIBRARY'] = p
    result = lookup_plugin.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    assert to_bytes(result[0]) == 'root'
    result = lookup_plugin

# Generated at 2022-06-21 05:45:27.577573
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 05:45:31.083333
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with no params
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')
    assert not hasattr(lookup_module, '_display')

# Generated at 2022-06-21 05:45:32.559111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 05:45:40.520376
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    tmpConfig = 'blablabla'
    tmpError = 'error'
    tmpOrigExc = 'fake'
    tmp = MissingSetting(tmpConfig, tmpOrigExc)
    assert tmp.config == tmpConfig
    assert tmp.orig_exc == tmpOrigExc
    assert tmp.strerror == '%s: %s' % (tmpError, tmp.config)

# Generated at 2022-06-21 05:45:42.884435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:45:46.281276
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestLookupModule(LookupModule):
        def __init__(self):
            pass

    assert TestLookupModule() is not None

# Generated at 2022-06-21 05:46:16.633365
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'error message'
    orig = 'exception message'
    x = MissingSetting(msg, orig_exc=orig)
    assert x.message == msg
    assert x.orig_exc == orig

# Generated at 2022-06-21 05:46:20.620341
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert len(e.args) == 1
        assert e.args[0] == 'test'

# Generated at 2022-06-21 05:46:32.539594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    uri = lu.run(['ssh_connection'], plugin_type="connection", plugin_name="ssh")
    assert uri == 'ssh'
    uri = lu.run(['remote_user'], plugin_type="vars", plugin_name="os")
    assert uri == 'root'
    uri = lu.run(['invalid'], plugin_type="connection", plugin_name="ssh")
    assert uri == []
    uri = lu.run(['invalid'], plugin_type="connection", plugin_name="ssh", on_missing='warn')
    assert uri == []
    uri = lu.run(['invalid'], plugin_type="connection", plugin_name="ssh", on_missing='error')

# Generated at 2022-06-21 05:46:35.102173
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Setup failed'
    exc = Exception()
    m = MissingSetting(msg, orig_exc=exc)
    assert m.msg == msg
    assert m.orig_exc == exc

# Generated at 2022-06-21 05:46:38.546247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:46:43.967060
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        # MissingSetting is raised when config value is not defined
        raise MissingSetting('test msg')
    except AnsibleOptionsError as e:
        # validate that object is of type MissingSetting
        assert isinstance(e, MissingSetting)


# Generated at 2022-06-21 05:46:47.727043
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting("test error", AnsibleError("AnsibleError"))
    assert str(error) == "test error"
    assert repr(error) == "AnsibleOptionsError('test error', orig_exc=AnsibleError('AnsibleError',))"

# Generated at 2022-06-21 05:46:55.642083
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    config = 'foo'
    module = 'bar'
    msg = 'Something went wrong'
    eobj = Exception(msg)
    obj = MissingSetting(config, module, eobj)
    assert msg == obj.orig_exc.message
    assert config == obj.config
    assert module == obj.module

# Generated at 2022-06-21 05:46:58.206020
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert "test" in str(e)

# Generated at 2022-06-21 05:47:07.802534
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not hasattr(LookupModule, '_connection'), \
            "_connection should not be defined for LookupModule"
    assert not hasattr(LookupModule, '_templar'), \
            "_templar should not be defined for LookupModule"
    assert not hasattr(LookupModule, '_loader'), \
            "_loader should not be defined for LookupModule"

    # TODO: Constructor is called with class name, not 'self'
    #lm = LookupModule()

# Generated at 2022-06-21 05:48:04.202206
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:48:08.751269
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test constructor
    obj = MissingSetting('test message')
    assert obj.message == 'test message'
    assert obj.orig_exc is None

# Generated at 2022-06-21 05:48:19.072761
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1
    terms = ['DEFAULT_BECOME_USER']
    variables = {'ansible_become_user': 'local_admin'}
    kwargs = {'on_missing': 'error'}
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, variables, **kwargs)
    assert result == ['local_admin']

    # Test case 2
    terms = ['DEFAULT_BECOME_USER']
    variables = {'ansible_become_user': 'local_admin'}
    kwargs = {'on_missing': 'warn', 'plugin_type': 'connection', 'plugin_name': 'local'}
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, variables, **kwargs)
    assert result == []

# Generated at 2022-06-21 05:48:24.577137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = LookupModule()
    term = "loader"
    # assert that the terms is ansible.constants.loader_name
    assert config.run(term) == [C.DEFAULT_LOADER_NAME]



# Generated at 2022-06-21 05:48:26.703554
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test message', orig_exc='test exception')
    assert m.message == 'test message'
    assert m.orig_exc == 'test exception'

# Generated at 2022-06-21 05:48:39.895946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable = dict(name='John', job='Developer')
    ploader = plugin_loader.connection_loader
    p = ploader.get('local', class_only=True)
    ploader._get_plugins(variables=variable, include_cache=True)
    p.set_options(direct=dict(var_options=variable))
    p.login = {'user': None}
    p._load_name = 'local'
    p.has_pipelining = False
    p.ssh_executable = None
    p.bin_path = None
    p.control_path = None
    p.passwords = {'vault': None}
    p.set_options(var_options=variable)

    plugin_loader.connection_loader.set_global_vars(variable)
    plugin_loader.bec

# Generated at 2022-06-21 05:48:46.722709
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    exception = AnsibleOptionsError(msg='example error message')
    with pytest.raises(AnsibleOptionsError) as excinfo:
        raise MissingSetting(msg='example error message', orig_exc=exception)
    assert str(exception) == 'example error message'

# Generated at 2022-06-21 05:48:54.159743
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common._collections_compat import Mapping

    class MockDisplay:
        def __init__(self, stream):
            self.stream = stream

        def warning(self, msg):
            print(msg, file=self.stream)

    class MockHashes:
        def __init__(self, hash_str):
            self.hash_str = hash_str

        def hexdigest(self):
            return self.hash_str

    # Create mock loader object
    class MockPluginLoader:
        def __init__(self):
            self.plugins = {}


# Generated at 2022-06-21 05:49:02.642391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test missing
    try:
        lookup.run([], on_missing='not_error_warn_or_skip')
        assert False
    except AnsibleOptionsError:
        assert True

    # plugin config
    assert lookup.run(['remote_tmp', 'vault_password_file'], plugin_name='sh', plugin_type='shell') == [None, '/root/.vault_pass.txt']

    # constant config
    assert lookup.run(['DEFAULT_LOG_PATH', 'DEFAULT_BECOME_METHOD']) == ['/var/log/ansible.log', 'sudo']

    # missing setting does not raise error
    assert lookup.run(['not_there_for_sure'], on_missing='error') == []

# Generated at 2022-06-21 05:49:04.678383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Implement in Ansible >= 2.8
    pass

# Generated at 2022-06-21 05:50:09.359880
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    result=LookupModule().run(['i3'])
    assert result == ['i3']

    result=LookupModule().run(['i3','i2'])
    assert result == ['i3','i2']

# Generated at 2022-06-21 05:50:10.866594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule != None

# Generated at 2022-06-21 05:50:14.203392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # check if object is LookupBase
    from ansible.plugins.lookup import LookupBase
    assert isinstance(lookup, LookupBase)
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:50:15.884443
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError) as excinfo:
        raise MissingSetting("msg")
    assert "msg" in str(excinfo)

# Generated at 2022-06-21 05:50:18.055983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module)
    assert(lookup_module._display)
    assert(lookup_module._templar)
    assert(lookup_module._display.verbosity == 3)

# Generated at 2022-06-21 05:50:23.277539
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    config = 'test_config'
    e = LookupError('test exception')
    missing_setting = MissingSetting(msg=config, orig_exc=e)
    assert missing_setting.kwargs['msg'] == config
    assert missing_setting.kwargs['orig_exc'] == e

# Generated at 2022-06-21 05:50:28.941882
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        lookupModule = LookupModule()
        assert False
    except Exception:
        # No error handling as this is the test
        pass

    try:
        lookupModule = LookupModule(loader=None, templar=None, shared_loader_obj=None)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-21 05:50:32.645022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''
    lookup_obj = LookupModule()
    assert len(lookup_obj.run('only_one_key')) == 1
    assert type(lookup_obj.run(['first_key', 'second_key'])) is list


# Generated at 2022-06-21 05:50:42.767367
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    ex = MissingSetting('This is a test')
    assert 'AnsibleOptionsError' in str(ex)
    assert 'This is a test' in str(ex)
    assert ex.orig_exc is None

    ex = MissingSetting('This is another test', orig_exc=True)
    assert 'AnsibleOptionsError' in str(ex)
    assert 'This is another test' in str(ex)
    assert ex.orig_exc is True

# Generated at 2022-06-21 05:50:52.207905
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test msg'
    exc = AnsibleLookupError('test ansible lookup error')

    try:
        raise MissingSetting(msg, orig_exc=exc)
    except MissingSetting as e:
        assert msg == to_native(e)
        assert 'test ansible lookup error' in to_native(e)
        assert e.orig_exc == exc
    else:
        raise RuntimeError("Didn't raise!")