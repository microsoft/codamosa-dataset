

# Generated at 2022-06-21 05:43:11.500963
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    L = LookupModule()
    L.set_options(direct={'on_missing': 'error'})

    # Get 'DEFAULT_BECOME_USER' configuration
    result = L.run(['DEFAULT_BECOME_USER'])
    assert result == [C.DEFAULT_BECOME_USER]

    # Get 'PIPELINING' configuration
    result = L.run(['PIPELINING'])
    assert result == [C.PIPELINING]

    # Get 'DEFAULT_ROLES_PATH' configuration
    result = L.run(['DEFAULT_ROLES_PATH'], variables={'playbook_dir': '/playbook'})
    assert result == C.DEFAULT_ROLES_PATH

    # Get 'RETRY_FILES_SAVE_PATH' & '

# Generated at 2022-06-21 05:43:15.334804
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    a = MissingSetting('a')
    assert a.orig_exc is None
    b = MissingSetting('b', orig_exc='c')
    assert b.orig_exc == 'c'

# Generated at 2022-06-21 05:43:17.312044
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_obj = LookupModule()
  assert isinstance(lookup_obj, LookupModule)


# Generated at 2022-06-21 05:43:18.708488
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    object=MissingSetting();
    assert object.missing == all

# Generated at 2022-06-21 05:43:30.626070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.errors import AnsibleOptionsError

    class MyVLModule(LookupModule):
        def __init__(self, basedir=None, runner=None, **kwargs):
            self._display = False
            self._options = ImmutableDict(kwargs)
            self._basedir = basedir
            self._loader = runner.loader

    def my_display_warning(msg):
        assert msg == 'Skipping, did not find setting TERM'

    my_runner = MockRunner()
    my_runner.set_display({'warning': my_display_warning})

    my_lookup_module = MyVLModule(basedir=None, runner=my_runner, on_missing='warn')


# Generated at 2022-06-21 05:43:33.389187
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:43:35.194966
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting("Variable UNKNOWN is not defined")
    assert err.message == "Variable UNKNOWN is not defined"
    assert str(err) == "Variable UNKNOWN is not defined"
    assert repr(err) == "Variable UNKNOWN is not defined"

# Generated at 2022-06-21 05:43:37.463584
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('Some message')
    assert isinstance(exc, AnsibleOptionsError)

# Generated at 2022-06-21 05:43:50.446249
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    class MockLookupBase:
        def __init__(self, *args, **kwargs):
            pass

    class MockC:
        def get_config_value(self, *args, **kwargs):
            return args[0]

    class MockOptionsError(Exception):
        pass

    class MockAnsibleOptionsError(Exception):
        pass

    class MockAnsibleError(Exception):
        pass

    class MockAnsibleLookupError(Exception):
        pass

    C.config = MockC()
    lookup_module = LookupModule(MockLookupBase())
    terms = ['A', 'B']
    variables = {'A': 'A value', 'B': 'B value'}
    kwargs = {'param1': 'value1', 'param2': 'value2'}



# Generated at 2022-06-21 05:43:54.711921
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test error'
    exc = TypeError
    assert isinstance(MissingSetting(msg), MissingSetting)
    assert isinstance(MissingSetting(msg, orig_exc=exc), MissingSetting)

# Generated at 2022-06-21 05:44:04.401063
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError) as exc:
        raise MissingSetting("whatever", "dummy exception")

    assert "whatever" in str(exc.value)
    assert "dummy exception" in str(exc.value)

# Generated at 2022-06-21 05:44:08.351445
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_msg = to_native('test_message')
    orig_exc = KeyError('orig_exc')
    m = MissingSetting(test_msg, orig_exc)
    assert m.orig_exc == orig_exc
    assert m.message == test_msg
    assert to_native(m) == test_msg

# Generated at 2022-06-21 05:44:20.034358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['DEFAULT_BECOME_USER', 'illegal_plugin_type', 'undefined_plugin_name', 'UNKNOWN']
    variables = None
    ignore_missing = 'warn'
    plugin_name = None
    plugin_type = None

    lookup_obj = LookupModule()

    # Test
    try:
        ret = lookup_obj.run(terms, variables, on_missing=ignore_missing, plugin_type=plugin_type, plugin_name=plugin_name)
        assert ret == ['root', 'root', 'root']
    except Exception as e:
        print(str(e))
        assert False

    plugin_type = 'become'
    plugin_name = 'sudo'


# Generated at 2022-06-21 05:44:20.692417
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:44:25.363168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)
    assert hasattr(lookup_plugin, 'run')
    assert callable(lookup_plugin.run)

# Generated at 2022-06-21 05:44:31.432377
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    from ansible.errors import AnsibleOptionsError

    msg = 'Unknown option'

    # Without original exception
    err = MissingSetting(msg)
    assert str(err) == msg
    assert err.orig_exc is None

    # With original exception
    err = MissingSetting(msg, orig_exc=AnsibleOptionsError('Something unexpected happend'))
    assert str(err) == msg
    assert err.orig_exc is not None

# Generated at 2022-06-21 05:44:32.501396
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:44:39.640819
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test for unknow config term
    exception = MissingSetting('test')
    assert "test" in str(exception)
    assert "UNKNOWN" in str(exception)

    # Test for known config term
    exception = MissingSetting('test', orig_exc="test")
    assert "test" in str(exception)
    assert "UNKNOWN" not in str(exception)

# Generated at 2022-06-21 05:44:53.119955
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockLookupModule(LookupModule):

        def set_options(self, var_options, direct=None):
            super(MockLookupModule, self).set_options(var_options, direct)
            self.option1 = direct.get('option1', 1)

        def get_option(self, option_name):
            return getattr(self, option_name)

    # First test without plugin_type and plugin_name
    class MockPluginLoader:
        @staticmethod
        def connection_loader(name, class_only=False):
            if name == 'local':
                return None
            raise AnsibleError('Unknown connection plugin: %s' % name)

        @staticmethod
        def lookup_loader(name, class_only=False):
            if name == 'template':
                return None

# Generated at 2022-06-21 05:45:01.238686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def getattr(self, attr):
        if attr == '_display':
            raise AnsibleOptionsError('Invalid setting identifier, "%s" is not a string, its a %s' % (attr, type(attr)))

    def setattr(self, attr, value):
        if attr == '_options':
            raise AnsibleOptionsError('Invalid setting identifier, "%s" is not a string, its a %s' % (attr, type(attr)))

    LookupModule.__getattr__ = getattr
    LookupModule.__setattr__ = setattr
    test_obj = LookupModule()
    test_terms = [""]
    print(test_obj.run(test_terms))


# Generated at 2022-06-21 05:45:15.713425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = list()
    ret = lm.run(terms, dict())
    assert ret == list(), 'failed to handle empty terms'
    terms = ['invalid', 'test_term']
    ret = lm.run(terms, dict())
    assert ret == list(), 'failed to handle invalid term'
    terms = ['test_term']
    ret = lm.run(terms, dict())
    assert ret == ['test_ret'], 'failed to get correct value'

# Generated at 2022-06-21 05:45:21.457587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    ret = lookup_module.run(terms=terms)
    print(ret)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 05:45:27.865014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils import context_objects as co

    terms = ['foo', 'bar']
    variables = {'foo': 'bar', 'boo': 'baz'}
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'error'}
    lookup = LookupModule()

    with co.GlobalVars(args=['myplaybook', '--inventory-file', '/tmp/myfile']):
        result = lookup.run(terms, variables=variables, **kwargs)

    assert isinstance(result, list)
    assert result == ['bar', 'baz']

# Generated at 2022-06-21 05:45:36.351626
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Check for the case that only exception message is provided
    try:
        raise MissingSetting('message')
    except AnsibleOptionsError as e:
        assert e.message == 'message'
        assert e.orig_exc is None
        assert str(e) == 'message'

    # Check for the case that exception message and original exception are supplied
    try:
        raise KeyError('original')
    except KeyError as e_orig:
        try:
            raise MissingSetting('message', e_orig)
        except AnsibleOptionsError as e:
            assert e.message == 'message'
            assert e.orig_exc is e_orig
            assert str(e) == 'message'

# Generated at 2022-06-21 05:45:46.625324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.sentinel import Sentinel

    class TestLookupModule(LookupModule):
        def get_option(self, option):
            if option == 'on_missing':
                return 'skip'
            else:
                return Sentinel

        def set_options(self, var_options=None, direct=None):
            assert var_options is None
            assert direct is None

    # Test 1. Testing with nonexistent global config settings.
    # Expected: empty list

    lookup = TestLookupModule()
    terms = [
        'nonexistent_global_setting_1'
    ]
    result = lookup.run(terms)
    assert result == []

    # Test 2. Testing with existent global config settings.
    # Expected: list containing the values of global settings



# Generated at 2022-06-21 05:45:47.478469
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:45:49.926944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()

# Generated at 2022-06-21 05:45:56.081829
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    bad_settings = ['dne', 'foo']
    msg = 'Setting was not defined: %s' % ' and '.join(bad_settings)
    msg_parsed = 'Setting was not defined: dne and foo'

    with pytest.raises(AnsibleOptionsError) as exc_info:
        raise MissingSetting(msg)

    assert str(exc_info.value) == msg_parsed

# Generated at 2022-06-21 05:46:09.253544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    t_terms = ['all.yml', 'site.yml']
    t_variables = {}

    t_loader = plugin_loader.connection_loader
    t_getattr = plugin_loader.connection_loader.get
    t_pname = 'local'

    t_config = 'playbook_path'
    t_config_2 = 'nope'

    # Return Values
    rv_getplugin = {}
    rv_getplugin_2 = getattr(C, t_config)

    def t_get_plugin(*args, **kwargs):
        if args[0] == t_pname:
            return rv_getplugin
        return rv_getplugin_2

    l_getattr = {
        (t_loader, 'get'): t_get_plugin,
    }

# Generated at 2022-06-21 05:46:20.705307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['remote_tmp', 'remote_user']  # type: List[str]
    plugin_type = 'shell'  # type: str
    plugin_name = 'sh'  # type: str
    l = LookupModule()
    l.set_options(var_options={'config': 'global'}, direct={'plugin_type': plugin_type, 'plugin_name': plugin_name})
    assert l.get_option('on_missing') == 'error'
    assert l.get_option('plugin_type') == plugin_type
    assert l.get_option('plugin_name') == plugin_name
    assert l.run(terms) == [C.DEFAULT_REMOTE_TMP, C.DEFAULT_REMOTE_USER]

    # Test on_missing options
    # On missing = skip (default)
   

# Generated at 2022-06-21 05:46:38.622246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['DEFAULT_BECOME_USER']) == ['root']

# Generated at 2022-06-21 05:46:49.725042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test with AnsibleOption error
    lookup_plugin = LookupModule()
    test_term = dict()
    test_term['plugin_type'] = "connection"
    test_term['plugin_name'] = "local"
    test_term['on_missing'] = 'error'
    test_term['_terms'] = list(['local_tmp'])
    try:
        lookup_plugin.run(test_term['_terms'])
    except AnsibleOptionsError as e:
        assert('Both plugin_type and plugin_name are required, cannot use one without the other' in e.message)

    #Test with AnsibleOptions error
    test_term['plugin_type'] = 'connection'
    test_term['plugin_name'] = 'local'
    test_term['on_missing'] = 'error'
    test_term

# Generated at 2022-06-21 05:47:02.420357
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:47:08.116041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(["DEFAULT_ROLES_PATH"],None)
    assert result == ["../:./roles"]

# Generated at 2022-06-21 05:47:09.411041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Test init")
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:47:17.703084
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """
    This unit test tests whether the constructor of the class MissingSetting creates the proper object of the desired type
    with the arguments provided and the expected defaults for missing arguments.
    :return:
    """
    ms = MissingSetting("MissingSetting message", orig_exc=AttributeError())
    assert(ms.message == "MissingSetting message")
    assert(isinstance(ms.orig_exc, AttributeError))

# Generated at 2022-06-21 05:47:22.767298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    CUR_DIR = os.path.dirname(os.path.realpath(__file__))
    import ansible.config
    from ansible.utils.sentinel import Sentinel

    ansible.config.load_config_file()
    terms = ['DEFAULT_BECOME_METHOD', 'DEFAULT_REMOTE_TMP']
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

    # Test whether the lookup module return the corresponding content for the term
    result = lm.run(terms)
    assert result[0] == 'sudo'
    assert result[1] == '/tmp/ansible-${USER}'

    # Test whether the lookup module can skip the term with on_missing=skip

# Generated at 2022-06-21 05:47:26.147437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # to check if the 'hasattr' function is working as expected
    assert hasattr(LookupModule, 'run')



# Generated at 2022-06-21 05:47:27.580640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 05:47:36.319157
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    module.set_options({'on_missing': 'warn'})

# Generated at 2022-06-21 05:48:14.319755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # verify that LookupModule.run raises an error if plugin_type and plugin_name are not provided together
    lookup = LookupModule()
    with pytest.raises(AnsibleOptionsError):
        lookup.run(terms=['foo'], plugin_type='connection', variables={})
    with pytest.raises(AnsibleOptionsError):
        lookup.run(terms=['foo'], plugin_name='ssh', variables={})

# Generated at 2022-06-21 05:48:19.696227
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import fragment_loader
    from ansible.module_utils.six import text_type

    lu = LookupModule()
    assert not lu.run(('UNKNOWN',), None)

    # 'on_missing' is not one of valid options. Should raise AnsibleOptionsError exception
    lu = LookupModule()
    try:
        lu.run(('UNKNOWN',), None, on_missing='unknown')
    except AnsibleOptionsError:
        pass
    else:
        assert False, "Should get an AnsibleOptionsError exception"

    # valid option. Should return empty list
    lu = LookupModule()
    assert not lu.run(('UNKNOWN',), None, on_missing='skip')

    # valid option. Should display a warning message
    lu = LookupModule()


# Generated at 2022-06-21 05:48:24.018500
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'foo'
    e = AnsibleError(msg)
    m = MissingSetting(msg, orig_exc=e)
    assert m.orig_exc == e

# Generated at 2022-06-21 05:48:28.142562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    # Test default 'on_missing' argument.
    assert module.options['on_missing'] == 'error'

    # Test constructor raises an error with invalid 'on_missing' argument.
    try:
        module = LookupModule(on_missing='invalid')
    except AnsibleOptionsError:
        pass
    else:
        assert False, "Expected AnsibleOptionsError not raised."

# Generated at 2022-06-21 05:48:31.571185
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing = MissingSetting('AnsibleOptionsError')

    assert missing.message == 'AnsibleOptionsError'

# Generated at 2022-06-21 05:48:36.057872
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "test"
    oe = Exception("orig")
    ms = MissingSetting(msg, oe)
    assert ms.orig_exc == oe
    assert str(ms) == msg

# Generated at 2022-06-21 05:48:40.146513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(var_options=None, direct=None)
    assert len(lookup.get_option('on_missing')) > 0
    assert len(lookup.get_option('plugin_type')) == 0
    assert len(lookup.get_option('plugin_name')) == 0
    # TODO add test_terms

# Generated at 2022-06-21 05:48:51.334647
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Checking the constructor of class LookupModule with invalid plugin_type"""
    lookup_plugins = plugin_loader.lookup_loader.all(class_only=True)
    lookup_plugin_class = lookup_plugins['config']
    lookup_plugin = lookup_plugin_class()

    assert lookup_plugin.on_missing == 'error'
    assert lookup_plugin.plugin_type is None
    assert lookup_plugin.plugin_name is None

    lookup_plugin.set_options(direct={'on_missing': 'skip', 'plugin_type': 'foo', 'plugin_name': 'bar'})
    assert lookup_plugin.on_missing == 'skip'
    assert lookup_plugin.plugin_type is 'foo'
    assert lookup_plugin.plugin_name is 'bar'

# Generated at 2022-06-21 05:48:55.083614
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('blah')
    assert exc.orig_exc is None

# Unit tests for constructor of class LookupModule
# pylint: disable=redefined-outer-name

# Generated at 2022-06-21 05:48:55.418136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:49:55.436769
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Instantiate the MissingSetting class
    result = MissingSetting()

    # Verify that the MissingSetting class is correctly instantiated
    assert isinstance(result, MissingSetting)

# Generated at 2022-06-21 05:49:59.917471
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting(msg="test msg")
    except MissingSetting as e:
        assert e.msg == "test msg"
        return 0


# Generated at 2022-06-21 05:50:06.245053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    Lookup = LookupModule()

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variables = VariableManager()

    testvars = {
        'term': 'DEFAULT_FORKS',
    }

    result = Lookup.run([testvars['term']], variables=None, variable_manager=variables, loader=loader)

    print("************ Result is ")
    print(result)

    assert result[0] == testvars['term']

# Generated at 2022-06-21 05:50:09.153020
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting('this is a test')
    assert result.message == 'this is a test'

# Generated at 2022-06-21 05:50:12.700376
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('This is a test' )
    except AnsibleOptionsError as me:
        assert me.message == 'This is a test', 'The message was not set properly'

# Generated at 2022-06-21 05:50:25.337926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_get_plugin_config_succeed(config):
        pname = 'test_plugin'
        ptype = 'test_plugin_type'
        try:
            plugin_loader.test_plugin_type_loader = lambda _: pname
            result = _get_plugin_config(pname, ptype, config, variables={})
        finally:
            del plugin_loader.test_plugin_type_loader
        return result

    def test_get_global_config_succeed(config):
        return _get_global_config(config)

    def test_get_global_config_fail(config):
        try:
            result = _get_global_config(config)
        except MissingSetting:
            pass

# Generated at 2022-06-21 05:50:26.587720
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 05:50:28.354122
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj._terms is None, '_terms should be None'

# Generated at 2022-06-21 05:50:33.692470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [ 'DEFAULT_BECOME_USER' ]
    terms = None
    variables = {}
    options = None
    basedir = None
    env = None
    loader = None
    templar = None
    Result = None
    lookup = LookupModule(Result, basedir, env, loader, templar, **options)
    expected = 'root'
    result = lookup.run(args, variables=variables)
    assert expected == result[0]

# Generated at 2022-06-21 05:50:45.745366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Make this unit test similate a lookup plugin more,
    # and check for more cases, such as config values that have default values defined,
    # and config values that have environment variables,
    # and config values that have the value passed in through the command line.
    # This unit test is mostly only checking the inputs.
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    # Strings to test with
    test_string_valid   = 'DEFAULT_BECOME_USER'
    test_string_invalid = 'DEFAULT_BECOME_USER@'
    test_string_numeric = '7777777'
    test_string_numeric_valid = 'DEFAULT_BECOME_TIMEOUT'

    # Test error cases
    test

# Generated at 2022-06-21 05:52:53.676204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config_lookup_module = LookupModule()
    #test for C.DEFAULT_ROLES_PATH config
    assert config_lookup_module.run(['DEFAULT_ROLES_PATH']) == [u'/etc/ansible/roles:/usr/share/ansible/roles']