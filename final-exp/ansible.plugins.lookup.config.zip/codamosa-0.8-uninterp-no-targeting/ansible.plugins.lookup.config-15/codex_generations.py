

# Generated at 2022-06-21 05:43:07.318576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None, "Failed to create LookupModule"
    # Test the run command
    res = lookup._call_backend('run', terms='UNKNOWN', on_missing='skip')
    assert res is None, "Failed to run LookupModule"
    res = lookup._call_backend('run', terms='UNKNOWN', on_missing='error')
    assert res is None, "Failed to run LookupModule"
    res = lookup._call_backend('run', terms='UNKNOWN', on_missing='error')
    assert res is None, "Failed to run LookupModule"
    res = lookup._call_backend('run', terms='DEFAULT_LOG_PATH', on_missing='error')
    assert res is not None, "Failed to run LookupModule"
    res

# Generated at 2022-06-21 05:43:08.719011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule(None)

# Generated at 2022-06-21 05:43:20.034939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins

    class Options:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Runner:
        def __init__(self, host_vars):
            self.host_vars = host_vars

    class RunnerOptions:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class RunnerConnection:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class RunnerData:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class LookupBase:
        def __init__(self, runner, ds, **kwargs):
            self.runner = runner
           

# Generated at 2022-06-21 05:43:31.928913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    var_manager = VariableManager(loader=loader, inventory=inv)
    pctx = PlayContext()

    lookup_plugin = LookupModule()
    lookup_plugin._display = lambda msg: msg

    terms = [
        'inventory_file',
        'deprecation_warnings',
        'default_roles_path',
        'host_key_checking',
        'UNKNOWN',
        'lookup_table'
    ]

# Generated at 2022-06-21 05:43:42.736571
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule object
    lookup_obj = LookupModule()

    # Test the run method with options on_missing=error, plugin_type=connection and plugin_name=ssh
    data = lookup_obj.run(['remote_user', 'port'], {}, on_missing='error', plugin_type='connection', plugin_name='ssh')
    assert data == [C.REMOTE_USER, C.DEFAULT_REMOTE_PORT]

    # Test the run method with options on_missing=warn, plugin_type=shell and plugin_name=sh
    data = lookup_obj.run(['remote_tmp'], {}, on_missing='warn', plugin_type='shell', plugin_name='sh')
    assert data == [C.DEFAULT_REMOTE_TMP]

    # Test the run method with options on_missing=skip

# Generated at 2022-06-21 05:43:52.327074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock variables and methods
    class MockedVars():
        def __init__(self, DEFAULT_ROLES_PATH):
            self.DEFAULT_ROLES_PATH = DEFAULT_ROLES_PATH
    class MockedLookupModule():
        options = {}
        def set_options(self, var_options=None, direct=None):
            self.options['var_options'] = var_options
            self.options['direct'] = direct
        def run(self, terms, variables=None, **kwargs):
            self.terms = terms
            self.variables = variables
            return self.options
    variables = MockedVars('/foo/bar')

    # Create object of class LookupModule
    lookup_module = MockedLookupModule()

    # Test for first use case

# Generated at 2022-06-21 05:44:02.125597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    :return:
    """
    # Check if lookup returns correct global configuration
    lookup_module = LookupModule()
    assert lookup_module.run(["ANSIBLE_CHECKPOINTS_DIR"], {}) == [C.ANSIBLE_CHECKPOINTS_DIR]

    # Check if lookup returns correct plugin configuration
    lookup_module = LookupModule()
    # Check if lookup raises exception if plugin_name is None
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(["ANSIBLE_CHECKPOINTS_DIR"], {"plugin_type": "module"}, on_missing="skip")

    # Check if lookup raises exception if plugin_type is None

# Generated at 2022-06-21 05:44:08.092820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_base_test = None
    ptype = "shell"
    pname = "sh"
    term = "remote_tmp"
    missing = "error"
    test_obj = LookupModule(lookup_base_test)
    test_obj.set_options(direct={'plugin_type': ptype, 'plugin_name': pname, 'on_missing': missing})
    result = test_obj.run(terms=[term], variables=None)
    assert len(result) == 1
    assert isinstance(result, list)

# Generated at 2022-06-21 05:44:16.352378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_vars = dict()
    if '_terms' in global_vars:
        del global_vars['_terms']
    if '__' in global_vars:
        del global_vars['__']
    l = LookupModule(None, global_vars, **{})
    assert isinstance(l, LookupBase)

# Generated at 2022-06-21 05:44:19.184004
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """ Test whether constructor of class MissingSetting works correctly or not. """
    exc = MissingSetting("configuration setting some_setting not defined")
    assert exc.value == "configuration setting some_setting not defined"
    assert exc.orig_exc == None

# Generated at 2022-06-21 05:44:29.550704
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Message', 'AnsibleOptionsError')
    except AnsibleError as e:
        assert e.msg == 'Message'
        assert e.orig_exc == 'AnsibleOptionsError'

# Generated at 2022-06-21 05:44:40.339858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'])[0] == 'root'
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='warn')[0] == 'root'
    assert lookup_module.run(terms=['UNKNOWN_VAR']) == []
    assert lookup_module.run(terms=['UNKNOWN_VAR'], on_missing='warn') == []
    assert lookup_module.run(terms=['UNKNOWN_VAR'], on_missing='skip') == []

# Generated at 2022-06-21 05:44:47.467283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    assert isinstance(lookup._loader, DataLoader)
    assert lookup._options is None
    assert lookup._templar is None



# Generated at 2022-06-21 05:44:48.125841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupModule)

# Generated at 2022-06-21 05:44:58.232473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def dummy_get_plugin_config(pname, config, variables):
        if pname == "accelerate":
            if config == "accelerate_port":
                return 7890
            elif config == "accelerate_timeout":
                return 10
        elif pname == "ssh":
            if config == "accelerate_port":
                return 8999
            elif config == "accelerate_timeout":
                return 30
        return None

    def dummy_get_global_config(variable):
        if variable == "DEFAULT_NETWORK_OS":
            return "ios"
        elif variable == "DEFAULT_NET_OS":
            return "iosx"

    # If a valid plugin name and variable is given then the plugin variable is returned
    m = LookupModule(basedir=None, runner=None)

# Generated at 2022-06-21 05:45:05.843403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for run of class LookupModule'''
    from ansible.module_utils.facts.system.distribution import DistributionFact
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFact
    from ansible.module_utils.facts.system.platform import PlatformFact
    from ansible.module_utils.facts.system.cpu import CPUFact
    from ansible.module_utils.facts.system.virtual import VirtualFact
    from ansible.module_utils.facts.system.last_boot import LastBootFact
    from ansible.module_utils.facts.system.date_time import DateTimeFact
    from ansible.module_utils.facts.system.user import UserFact
    from ansible.module_utils.facts.system.service import ServiceFact

# Generated at 2022-06-21 05:45:17.008891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import pytest
    # pytest.set_trace()
    # import unittest
    # unittest.set_trace()
    import json

    """
    Unit test for method run of class LookupModule
    """
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    from sys import version_info
    if version_info[0] < 3:
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    # Define input variables
    terms = ['DEFAULT_ROLES_PATH']
    variables = {}
    kwargs = {'plugin_type': 'vars', 'plugin_name': 'json'}

    # Define expected output

# Generated at 2022-06-21 05:45:27.093398
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:45:33.893073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        {'_terms': 'first_term'},
        {'_terms': 'second_term'},
        {'_terms': 'third_term'}
    ]
    variable = {'FOO': "BAR"}
    lm = LookupModule(terms, variable)

    assert 'first_term' in lm.run()
    assert 'second_term' in lm.run()
    assert 'third_term' in lm.run()

# Generated at 2022-06-21 05:45:42.566826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a class instance which will be used to call LookupModule
    lookup_plugin = LookupModule()
    # Assert the name property of LookupModule
    assert lookup_plugin._load_name == 'config'
    # Assert the docs property of LookupModule
    assert lookup_plugin._get_doc.__doc__ == 'This function is used to get the documentation string for the specified class/method'

# Generated at 2022-06-21 05:45:57.181613
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    pass

# Generated at 2022-06-21 05:45:58.704869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:46:01.517549
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting('message', orig_exc=None)

# Generated at 2022-06-21 05:46:02.489318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0 == 1

# Generated at 2022-06-21 05:46:05.518630
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting('test message')

# Generated at 2022-06-21 05:46:12.230996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'workdir': '/root'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['workdir']) == ['/root']

    lookup_module.set_options(var_options={'workdir': '/root'}, direct={'plugin_type': 'connection', 'plugin_name': 'fake', 'on_missing': 'skip'})
    assert not lookup_module.run(['workdir'])

    lookup_module.set_options(var_options={'workdir': '/root'}, direct={'plugin_type': 'connection', 'plugin_name': 'fake', 'on_missing': 'error'})

# Generated at 2022-06-21 05:46:23.681775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    lu.set_loader(None)
    lu.set_basedir('/ansible_path')
    lu.set_environ({})
    variable = {}

    #1. LookupModule.run does not throw any exception
    ret = lu.run(terms=['DEFAULT_BECOME_USER'], variables=variable)
    assert len(ret) == 1
    assert ret[0] == ''

    #2. LookupModule.run does throw exception if the given plugin_name is not found from the plugins
    # as we cannot add pluginis in loader.py, we are not able to test this.

    #3. LookupModule.run throws exception if plugin_name and plugin_type is not specified

# Generated at 2022-06-21 05:46:25.618563
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('')
    assert isinstance(missing_setting, Exception)

# Generated at 2022-06-21 05:46:35.698613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils._text import to_text

    PLUGIN_LOOKUP_OPT = 'role_path'
    PLUGIN_TYPE = 'vars'
    PLUGIN_NAME = 'role_name'

    class MockC(object):
        ''' mock Ansible config class '''
        pass

    class MockLookupModule(LookupBase):
        def __init__(self, config_name, config, plugin_type=None, plugin_name=None):
            self._lookup_name = config_name

# Generated at 2022-06-21 05:46:40.968189
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test_message')
    except MissingSetting as e:
        assert(e.args[0] == 'test_message')
        assert(e.orig_exc is None)


# Generated at 2022-06-21 05:47:15.571907
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    assert lookup_module.run(terms=['RANDOM_VARIABLE'], variables={}, on_missing='skip') == []
    assert lookup_module.run(terms=['RANDOM_VARIABLE'], variables={}, on_missing='warn') == []

    try:
        lookup_module.run(terms=['RANDOM_VARIABLE'], variables={}, on_missing='error')
    except AnsibleLookupError:
        pass
    else:
        assert False, 'Failed to raise an error'

    try:
        lookup_module.run(terms=['RANDOM_VARIABLE'], variables={}, on_missing='blah')
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-21 05:47:17.702938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-21 05:47:25.645340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins import loader

    lookup = loader.lookup_loader.get('config', class_only=True)
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {}
    ret = lookup.run(terms, variables=variables, **kwargs)
    assert ret[0] == 'root'

    lookup = loader.lookup_loader.get('config', class_only=True)
    terms = ['UNKNOWN']
    variables = {}
    kwargs = {}
    try:
        ret = lookup.run(terms, variables=variables, **kwargs)
    except AnsibleOptionsError as e:
        assert "Invalid setting" in to_native(e)

    lookup = loader.lookup_loader.get('config', class_only=True)

# Generated at 2022-06-21 05:47:30.058282
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    # Test __init__(self)
    assert l.params is None
    assert l.basedir is None
    assert l.templar is None
    assert l.runner is None

# Generated at 2022-06-21 05:47:37.809957
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os

    from ansible.module_utils.six import PY3

    from ansible.plugins.loader import lookup_loader

    from ansible.utils.sentinel import Sentinel

    class MockConfig(object):
        def __init__(self):
            self.DEFAULT_ANSIBLE_LOG_PATH = '/tmp/ansible.log'
            self.DEFAULT_MODULE_NAME = 'command'

    # generate a fake class with the same signature as LookupModule
    class FakeLookupModule(object):
        def __init__(self, basedir=None, runner=None, variables=None, **kwargs):
            self._display = runner
            self._basedir = basedir
            self._loader = lookup_loader
            self._templar = None
            self.config = MockConfig()
            self.sentinel = Sentinel

# Generated at 2022-06-21 05:47:48.556758
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting()
    assert exc.message == 'Ansible lookup plugin failed to find setting'
    assert exc.orig_exc is None
    assert exc.kwargs == {}
    exc = MissingSetting('Foo was not found', orig_exc=AnsibleError(), foo='bar')
    assert exc.message == 'Foo was not found'
    assert exc.orig_exc is not None
    assert exc.kwargs == {'foo': 'bar'}
    exc_2 = MissingSetting(orig_exc=exc, some_kwarg='baz')
    assert exc_2.message == 'Ansible lookup plugin failed to find setting'
    assert exc_2.orig_exc == exc
    assert exc_2.kwargs == {'some_kwarg': 'baz'}
    exc_str = '%s' % exc

# Generated at 2022-06-21 05:47:51.701006
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('foo', orig_exc=AnsibleLookupError('bar'))
    assert m.orig_exc.message == 'bar'

# Generated at 2022-06-21 05:47:55.045402
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert 'was not defined' in str(MissingSetting('message'))
    assert 'message' in str(MissingSetting('message', orig_exc=Exception('message')))
    ansible_setting = MissingSetting('message', orig_exc=Exception('message'))
    assert 'message' in str(ansible_setting)
    assert 'message' in str(ansible_setting.orig_exc)

# Generated at 2022-06-21 05:47:56.749904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:47:57.199472
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:48:55.083314
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ex = MissingSetting('foo')
    assert ex.message == 'foo'


# Generated at 2022-06-21 05:49:01.281514
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Importing required module for test
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # Setup data loader and variable manager
    loader = DataLoader()
    variables = VariableManager()

    # Create LookupModule object
    lm = LookupModule()
    # Invoke run method
    lm.run(terms=['action_plugins'], variables=variables)

# Generated at 2022-06-21 05:49:04.612689
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing = MissingSetting("msg", "orig_exc")
    assert missing.msg == "msg"
    assert missing.orig_exc == "orig_exc"

# Generated at 2022-06-21 05:49:14.169310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing instances of LookupModule and AnsibleFile as needed for the test
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_loader_object(None)
    lookup.set_basedir('/home/ansible/')
    lookup.set_environment(None)
    lookup.set_vars(None)
    lookup.set_options(None, None)
    lookup.basedir = '/home/ansible/'
    lookup.templar = None
    lookup.set_play_context(None)

    # Testing empty terms
    assert lookup.run([]) == [], 'Terms should be empty'

    # Testing a term that is not a string
    try:
        lookup.run([12])
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-21 05:49:18.695777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'FOO_BAR']
    variables = {'FOO_BAR': 'abc'}

    ret = lm.run(terms, variables)
    assert ret == ['root', 'abc']

# Generated at 2022-06-21 05:49:22.183579
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('Test error message')
    assert exc.message == 'Test error message'
    assert str(exc) == 'Test error message'

# Generated at 2022-06-21 05:49:27.167285
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test for constructor of class LookupModule
    # Expected result:test obj is a instance of LookupModule class
    test_obj=LookupModule()
    assert isinstance(test_obj,LookupModule)

# Generated at 2022-06-21 05:49:34.525142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_config = {'color_changed': 'yellow', 'color_ok': 'green'}
    my_connection = 'ssh'
    my_port = 22
    my_plugin_type = 'connection'
    my_plugin_name = 'ssh'
    my_remote_user = 'ansible'
    my_remote_tmp = '/tmp/ansible_tmp'
    my_remote_port = '22'
    my_shell = 'sh'
    my_return = []

    lb = LookupModule()

    lb.set_options(var_options=my_config)
    my_return = lb.run(['color_ok', 'color_changed'], variables=my_config)
    assert my_return == ['green', 'yellow']


# Generated at 2022-06-21 05:49:35.857697
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting is not None

# Generated at 2022-06-21 05:49:40.594634
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test with invalid value of on_missing option
    try:
        LookupModule().run(terms=[], on_missing='invalid')
    except AnsibleOptionsError:
        pass

    try:
        LookupModule().run(terms=[], plugin_type='become')
    except AnsibleOptionsError:
        pass

    try:
        LookupModule().run(terms=[], plugin_name='sudo')
    except AnsibleOptionsError:
        pass

    # test with invalid value of plugin_type option
    try:
        LookupModule().run(terms=[], plugin_type='invalid', plugin_name='sudo')
    except AnsibleOptionsError:
        pass

    LookupModule().run(terms=[], plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-21 05:51:37.696377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Lookup is not available, so just call _get_plugin_config directly
    test_config = 'REMOTE_TMP'
    result = _get_plugin_config(pname='sh', ptype='shell', config=test_config, variables=None)
    # To keep compatibility with previous behavior, use str(result)
    assert str(result) == '$HOME/.ansible/tmp'

# Generated at 2022-06-21 05:51:40.954596
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('message', orig_exc='original exception')
    except MissingSetting as e:
        pass

# Generated at 2022-06-21 05:51:42.468679
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule("lookup_module.test")

# Generated at 2022-06-21 05:51:51.553590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory"])
    variables = VariableManager(loader=loader, inventory=inventory)

    lookup_obj = LookupModule()

    # Test Global setting
    global_setting = "DEFAULT_ROLES_PATH"
    result = lookup_obj.run(terms=[global_setting])
    assert result[0] == C.DEFAULT_ROLES_PATH

    # Test setting for SSH
    plugin_type = "connection"
    plugin_setting = "port"
    plugin_name = "ssh"

# Generated at 2022-06-21 05:52:01.070582
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.utils import context_objects as co
    from ansible.plugins.loader import lookup_loader

    # Setup module
    p = lookup_loader.get('config')

    # Setup args
    terms = ['DEFAULT_BECOME_USER']
    variables = dict()
    kwargs = dict(plugin_type="become",
                  plugin_name="local")

    context = co.TowerCLIRunnerContext()

    # Instantiate the class
    l = LookupModule()
    l.runner = context.runner  # set context object
    l.set_options(var_options=variables,
                  direct=kwargs)

# Generated at 2022-06-21 05:52:02.118463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule([])

# Generated at 2022-06-21 05:52:05.170167
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert 'setting not found' in str(MissingSetting('missing setting'))
    assert 'not found' in str(AnsibleOptionsError('missing setting'))

# Generated at 2022-06-21 05:52:05.979927
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 05:52:11.575556
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    """
    Unit test for run method of class LookupModule
    """

    from ansible.plugins import LOADER
    from ansible.module_utils.six import PY3, text_type

    ##########################################################################
    ##################### setup the test fixtures ############################
    ##########################################################################

    # Since we are testing the run method of LookupModule,
    # we will first create an instance of a class LookupModule
    # and get its reference as lm in our test cases

    lm = LOADER.lookup_loader.get('config')

    ##########################################################################
    ###################### test when an invalid on_missing option is passed
    ##########################################################################

    # We will pass on_missing as None in this case and check whether
    # we are getting ValueError exception with a proper message


# Generated at 2022-06-21 05:52:16.554153
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'msg'
    orig_exc = 'orig_exc'
    missing_setting = MissingSetting(msg, orig_exc)
    assert missing_setting.msg == msg
    assert missing_setting.orig_exc == orig_exc