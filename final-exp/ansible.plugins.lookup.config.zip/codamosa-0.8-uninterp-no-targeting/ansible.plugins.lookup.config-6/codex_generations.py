

# Generated at 2022-06-21 05:43:06.891352
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    msg = 'msg'
    e = Exception(msg)
    try:
        raise MissingSetting(msg, orig_exc=e)
    except MissingSetting as ex:
        assert ex.orig_exc == e
        assert ex.message == msg
        assert isinstance(ex, AnsibleOptionsError)
        assert str(ex).endswith(msg)

# Generated at 2022-06-21 05:43:08.367665
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) == type

# Generated at 2022-06-21 05:43:14.091719
# Unit test for constructor of class MissingSetting
def test_MissingSetting(): 
    msg = 'Invalid setting'
    orig_exc = 'Original Exception'
    # Test with complete set of args
    ms = MissingSetting(msg, orig_exc=orig_exc)
    assert ms.message == msg
    assert ms.orig_exc == orig_exc

    # Test with only msg
    ms = MissingSetting(msg)
    assert ms.message == msg
    assert ms.orig_exc is None

    # Test with no args
    ms = MissingSetting()
    assert ms.message is None
    assert ms.orig_exc is None

# Generated at 2022-06-21 05:43:24.209084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'port']
    variables = {'ansible_user': 'ansible_user', 'ansible_port': '22', 'ansible_ssh_user': 'ansible_ssh_user',
                 'ansible_connection': 'ssh'}
    ptype = 'connection'
    pname = 'ssh'
    missing = 'error'
    module = LookupModule()
    module.set_options(var_options=variables, direct={'plugin_type': ptype, 'plugin_name': pname, 'on_missing': missing})
    module.run(terms, variables)

# Generated at 2022-06-21 05:43:33.480617
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ansible_modules = {
        'config': LookupModule(),
        'debug': DebugModule()
    }

    ansible_variables = {
        'ansible_connection': 'local'
    }
    ansible_variables['ansible_facts'] = Facts(ansible_variables, ansible_modules).populate()

    # Test for lookup_plugin.get('config', 'DEFAULT_BECOME_USER')
    test_action = {}
    test_action['debug'] = dict(msg='{{lookup(\'config\', \'DEFAULT_BECOME_USER\')}}')
    action = ActionModule(task=dict(action=test_action), variables=ansible_variables)


# Generated at 2022-06-21 05:43:43.518203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    pname = 'debug'
    ptype = 'lookup'
    config = 'VERBOSITY'
    lookup = lookup_loader.get(pname, class_only=True)

    # pname and ptype are present, call _get_plugin_config
    lookup.run([config], plugin_type=ptype, plugin_name=pname)

    # pname is present, ptype is absent, raise AnsibleOptionsError
    try:
        lookup.run([config], plugin_name=pname)
    except AnsibleOptionsError as e:
        assert e.message == 'Both plugin_type and plugin_name are required, cannot use one without the other'

    # pname is present, ptype is present but empty, raise AnsibleOptionsError

# Generated at 2022-06-21 05:43:52.609369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global __file__

    import os
    import sys

    __file__ = os.path.realpath(__file__)
    if __file__.endswith('.pyc'):
        __file__ = __file__[:-1]

    sys.path.append(os.path.dirname(__file__))

    from ansible.plugins.loader import lookup_loader
    global lookup_loader
    lookup_loader.add_directory(os.path.dirname(__file__))


    global LookupBase
    from ansible.plugins.lookup import LookupBase

    lookupModule = lookup_loader.get('config')
    if lookupModule is None:
        raise Exception('config lookup plugin could not be loaded from %s' % os.path.dirname(__file__))

    lookupModule = lookupModule()
    result

# Generated at 2022-06-21 05:43:55.711886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = plugin_loader.filter_loader.get('config')
    assert isinstance(module.run(['foo']), list)

# Generated at 2022-06-21 05:44:00.333039
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting("First exception")
    if exception.args[0] != "First exception":
        return False
    exception = MissingSetting("Second exception", "First exception")
    if exception.args[0] != "Second exception":
        return False
    if exception.args[1] != "First exception":
        return False
    return True

# Generated at 2022-06-21 05:44:06.275639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(AnsibleSequence(elements=[AnsibleUnicode(value='DEFAULT_ROLES_PATH')])), list)
    assert isinstance(lookup_module.run(AnsibleSequence(elements=[AnsibleUnicode(value='DEFAULT_BECOME_USER')])), list)

# Generated at 2022-06-21 05:44:32.229889
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:44:36.979551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader

    mock_loader = lookup_loader.get('config')

    assert mock_loader._plugins[0].__class__.__name__ == 'LookupModule'

# Generated at 2022-06-21 05:44:39.005936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module,'run')

# Generated at 2022-06-21 05:44:46.413457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "loglevel".split()
    path = "/hello/world"
    lu = LookupModule()
    lu.set_loader()
    value = lu.run(terms, variables=None, direct={"__ansible_config_file":path})
    assert len(value) == 1

# Generated at 2022-06-21 05:44:50.488744
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Unable to find setting'
    e1 = AnsibleLookupError(msg)
    e2 = MissingSetting(msg, orig_exc=e1)
    assert e2.orig_exc == e1

# Generated at 2022-06-21 05:44:59.829761
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    msg = "foo"
    exc = Exception()
    missing = MissingSetting(msg, orig_exc=exc)

    if missing.msg != msg:
        raise Exception("MissingSetting constructor failed to set msg.")
    if missing.orig_exc != exc:
        raise Exception("MissingSetting constructor failed to set orig_exc.")
    if missing.args[0] != msg:
        raise Exception("MissingSetting constructor failed to set args.")

    return True

# Generated at 2022-06-21 05:45:01.873100
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    msg = 'message'
    orig_exc = Exception()
    ms = MissingSetting(msg, orig_exc=orig_exc)
    assert ms.message == msg
    assert ms.orig_exc is orig_exc

# Generated at 2022-06-21 05:45:04.116317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 05:45:10.747069
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:45:19.842035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Case1: Positive test case
    # Case1.1: Negative test case
    # Case2: Positive test case
    # Case2.1: Negative test case
    # Case3: Negative test case
    # Case3.1: Negative test case
    # Case3.2: Negative test case
    terms = ['DEFAULT_ROLES_PATH']
    ret = lookup.run(terms, variables=None, on_missing='error', plugin_type='', plugin_name='')
    assert len(ret) == 1 and isinstance(ret, list)
    # Case4: Negative test case
    # Case4.1: Negative test case
    # Case4.2: Negative test case

# Generated at 2022-06-21 05:45:43.387239
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    constants.HOST_KEY_CHECKING = 'False'
    constants.DEFAULT_REMOTE_USER = 'foo'

    terms = ['DEFAULT_REMOTE_USER', 'HOST_KEY_CHECKING']

    variables = {'ansible_python_interpreter': '/usr/bin/python'}

    on_missing = 'warn'

    kwargs = {}

    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['foo', 'False']

# Generated at 2022-06-21 05:45:44.610782
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting('test')

# Generated at 2022-06-21 05:45:55.580433
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    def test_construction_without_orig_exc():
        try:
            raise MissingSetting("MSG")
        except MissingSetting as e:
            assert e.orig_exc is None

    def test_construction_with_orig_exc():
        try:
            try:
                raise Exception("MSG")
            except Exception as e:
                raise MissingSetting("MSG", orig_exc=e)
        except MissingSetting as e:
            assert str(e.orig_exc) == "MSG"

    test_construction_without_orig_exc()
    test_construction_with_orig_exc()

# Generated at 2022-06-21 05:46:08.991556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    try:
        lookup_module.run()
    except AnsibleOptionsError:
        pass
    # AnsibleOptionsError: Missing required terms argument

    lookup_module = LookupModule()
    try:
        lookup_module.run(None)
    except AnsibleOptionsError:
        pass

    # AnsibleOptionsError: Missing required terms argument

    lookup_module = LookupModule()
    try:
        lookup_module.run([])
    except AnsibleOptionsError:
        pass
    # AnsibleOptionsError: Missing required terms argument

    # Success Case
    lookup_module = LookupModule()
    try:
        lookup_module.run('foo')
    except AnsibleOptionsError:
        pass

    # Success Case
    lookup_module = LookupModule()

# Generated at 2022-06-21 05:46:12.058723
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert AnsibleOptionsError  # Ensure importer imported AnsibleOptionsError class.
    assert isinstance(MissingSetting(), AnsibleOptionsError)

# Generated at 2022-06-21 05:46:23.681609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text       import to_text
    from ansible.module_utils.six.moves   import StringIO


# Generated at 2022-06-21 05:46:30.674351
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()

  # the 'assert' statement asserts that the first parameter is equal to the second parameter
  # if the first parameter is not equal to the second parameter, an AssertionError
  # is raised and the test is failed.
  # to learn more about the 'assert' statement, google it

  # test that the 'run' method of class LookupModule exists and is
  # the same method defined in LookupModule
  assert lm.run == LookupModule.run

# Generated at 2022-06-21 05:46:32.662424
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options()
    l.run(['DEFAULT_ROLES_PATH'])

# Generated at 2022-06-21 05:46:33.602701
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('test message')

# Generated at 2022-06-21 05:46:34.066315
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    raise Sentinal("Test")

# Generated at 2022-06-21 05:47:01.993403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.errors import AnsibleLookupError
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import lookup_loader

    for name, instance in C.config.data.items():
        if not hasattr(instance, '__call__'):
            #lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), name))
            lookup = LookupModule()

            lookup.run(terms=[name], variables=None, **{'on_missing': Sentinel, 'plugin_type': Sentinel, 'plugin_name': Sentinel})

            lookup.run(terms=[name], variables=None, **{'on_missing': 'error', 'plugin_type': Sentinel, 'plugin_name': Sentinel})


# Generated at 2022-06-21 05:47:13.699093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os.path
    import json
    import tempfile

    class Options(object):
        variable_manager = None
        connection_loader = None
        strategy = 'free'
        vault_password = None
        loader = None
        stdout_callback = 'default'
        default_vars = None
        on_unimplemented_module = None
        filter_loaded_modules = None
        no_log = None
        tags = None
        skip_tags = None
        verbosity = 0
        check = None
        diff = None
        force_handlers = None
        flush_cache = None
        listhosts = None
        listtags = None
        listtasks = None
        module_path = None
        step = None
        start_at_task = None
        target_host = None
        forks = None
        inventory

# Generated at 2022-06-21 05:47:20.451823
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    errmsg = 'test'
    term = 'test_term'

    with pytest.raises(AnsibleOptionsError) as exc_info:
        MissingSetting(errmsg, orig_exc=Exception(errmsg), term=term)
    assert exc_info.value.message.endswith(errmsg)

    with pytest.raises(AnsibleOptionsError) as exc_info:
        MissingSetting(errmsg, orig_exc=Exception(errmsg), term=term, option='test_opt')
    assert exc_info.value.message.endswith(term)

    with pytest.raises(AnsibleOptionsError) as exc_info:
        MissingSetting(errmsg, orig_exc=Exception(errmsg), term=term, option='test_opt', const=1)

# Generated at 2022-06-21 05:47:33.612497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['str1', 'str2']
    options = {'plugin_name': 'test_plugin_name', 'plugin_type': 'test_plugin_type', 'on_missing': 'test_on_missing'}
    from ansible.module_utils.six import PY2
    if PY2:
        from mock import patch
    else:
        from unittest.mock import patch

    with patch.object(LookupBase, 'run', return_value=['str1', 'str2']):
        with patch.object(plugin_loader, 'get', return_value=True):
            with patch.object(C.config, 'get_config_value', return_value='return_value'):
                lookup_inst = LookupModule()

# Generated at 2022-06-21 05:47:36.668933
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('test_message')
    assert missing_setting.message == 'test_message'

# Generated at 2022-06-21 05:47:39.536852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test any missing argument
    lookup_module_obj = LookupModule() # On missing argument


# Generated at 2022-06-21 05:47:48.691445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test of config parameter on_missing
    # on_missing is set to 'error'
    result_error = LookupModule().run([''], {}, on_missing='error')
    assert isinstance(result_error, list) and result_error == []
    result_warn = LookupModule().run([''], {}, on_missing='warn')
    assert isinstance(result_warn, list) and result_warn == []
    result_skip = LookupModule().run([''], {}, on_missing='skip')
    assert isinstance(result_skip, list) and result_skip == []
    # Test of config parameter plugin_type
    # plugin_type is set to 'cliconf'
    result = LookupModule().run(['persistent_command_timeout'], {}, plugin_type='cliconf')
    assert isinstance

# Generated at 2022-06-21 05:47:52.932491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {'ansible_become_user': None}
    kwargs = {}
    lookup.run(terms, variables, **kwargs)
    assert len(lookup) == 1

# Generated at 2022-06-21 05:47:59.504227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # args = [terms, variables, **kwargs (direct)]
    terms = ['COLLECTION_PATHS', 'DEFAULT_ROLES_PATH']
    variables = {'ansible_collections_path': '/abc/'}
    kwargs = {'on_missing': 'warn'}
    expected_output = ['/abc/',
                       '/home/centos/.ansible/roles:/usr/share/ansible/roles']
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == expected_output, "Expected Output: %s \n Result: %s" % (expected_output, result)

# Generated at 2022-06-21 05:48:06.541075
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Construtor can be called with a single string argument and a single
    additional keyword argument, both of which are required.

    """
    try:
        MissingSetting()  # pylint: disable=no-value-for-parameter
    except TypeError:
        pass

    try:
        MissingSetting('This is a string', some_other_argument=1)
    except TypeError:
        pass

    assert isinstance(MissingSetting('This is a string', orig_exc=Exception), MissingSetting)

# Generated at 2022-06-21 05:48:35.354089
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:48:48.802252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test plugin_type and plugin_name
    # The plugin should be loaded if the correct ptype and pname are provided
    # Test case 1: ptype and pname present, config present
    expected_out=['stub_value']
    got_out=LookupModule().run([ "stub_setting1" ], variables=None, plugin_name='stub_name', plugin_type='stub_type' )
    assert got_out == expected_out

    # Test case 2: ptype and pname present, config not present
    expected_out=[]
    got_out=LookupModule().run([ "stub_setting2" ], variables=None, plugin_name='stub_name', plugin_type='stub_type' )
    assert got_out == expected_out

    # Test case 3: pname present and ptype

# Generated at 2022-06-21 05:49:00.989136
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initializing LookupModule
    l = LookupModule()

    # Creating a mock_context
    class mock_context():
        def __init__(self, r):
            self.r = r

        def get_config_value(x,y):
            return self.r

    class mock_plugins():
        def __init__(self, r):
            self.r = r

        def get_plugins(x):
            return self.r

    # Creating a mock_config
    class mock_config():
        def __init__(self, r):
            self.r = r

        def get_config_value(x,y):
            return self.r

    # Setting the mock object for config_loader
    plugin_loader.config_loader = mock_config(None)

    # Setting the mock_context for config
    C

# Generated at 2022-06-21 05:49:03.711101
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    settings = MissingSetting('test param')
    assert settings.msg == 'test param'
    assert settings.orig_exc == None

# Generated at 2022-06-21 05:49:13.801822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import traceback
    import tempfile
    import subprocess
    import shutil
    import ansible_runner
    import ansible.utils.plugins
    import json

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data = {'test': 'test1',
                 'test_none': None,
                 'test_false': False,
                 'test_true': True,
                 'test_empty': '',
                 'test_int': 123,
                 'test_float': 12.3,
                 'test_list': ['item1', 'item2', 'item3'],
                 'test_dict': {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
                 }

   

# Generated at 2022-06-21 05:49:22.354829
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create instance of class LookupModule
    lookup = LookupModule()

    # Mock playbook
    playbook = PlayContext()

    # Create mock task
    task = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    task._play = playbook

    # Mock play
    play = task._play
    play.become = 'test_become'

    # Mock consumer to use as callback
    consumer = object()

    # Use consumer to set task
    consumer._task = task
    consumer._play = task._play

    # Mock callback
    callback = consumer.on_v2_playbook_item_on_

# Generated at 2022-06-21 05:49:26.168291
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test')
    except MissingSetting as e:
        assert not e.orig_exc
        assert e.message == 'Test'

# Generated at 2022-06-21 05:49:32.851788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test the method run of class LookupModule"""
    # Arrange
    terms = ['ANSIBLE_LOG_PATH','ANSIBLE_CACHE_PLUGIN','ANSIBLE_CACHE_PLUGIN_CONNECTION','ANSIBLE_LIBRARY','ANSIBLE_LIBRARY']
    variables = None
    expected_results = ['/tmp/ansible.log', 'memory', '', '/path/to/ansible', '/path/to/ansible']
    lookup_mod = LookupModule()

    # Act
    results = lookup_mod.run(terms, variables)

    # Assert
    assert results == expected_results

# Generated at 2022-06-21 05:49:35.741259
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('test_msg', 'test_orig_exc')
    assert missing_setting.message == 'test_msg'
    assert missing_setting.orig_exc == 'test_orig_exc'


# Generated at 2022-06-21 05:49:37.019229
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l

if __name__ == '__main__':
    print(test_LookupModule())

# Generated at 2022-06-21 05:50:35.622565
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 05:50:39.279582
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting:
        msg = to_native(e)
        return msg == 'test'

# Generated at 2022-06-21 05:50:41.366387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-21 05:50:46.264358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # Create a mock object
    mock_lookupmodule = LookupModule()
    # mock the call to set_options()
    mock_lookupmodule.set_options = lambda var_options, direct : None
    # mock the call to get_option()
    mock_lookupmodule.get_option = lambda opt_name : None
    ret = mock_lookupmodule.run([])
    assert isinstance(ret, list)
    assert ret == []

# Generated at 2022-06-21 05:50:56.717695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.config.manager import ConfigManager
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types

    # Test code to test the run method from LookupModule.
    # This is a unit test for run method of LookupModule class.
    # This Unit Test only tests the set_option method of LookupModule.
    #
    # To test the LookupModule.run method, the tests needs to call the
    # LookupModule.run directly which is not possible as the
    # LookupModule.run is called from AnsibleTemplate class.
    #
    # AnsibleTemplate class is inside the template module.
    # So instead of loading the Template module, that test should
    # load the LookupModule class directly and test the

# Generated at 2022-06-21 05:51:05.141049
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    orig_exc = AnsibleError('Test exception')
    test_msg = 'This is a test exception'
    assert isinstance(AnsibleError, Exception)
    assert isinstance(AnsibleError('Test exception'), Exception)
    assert isinstance(MissingSetting(test_msg, orig_exc=orig_exc), AnsibleError)

# Generated at 2022-06-21 05:51:18.051836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from ansible.plugins.loader import callback_loader

    # create a lookup object
    lookup_obj = LookupModule()
    display_obj = Display()

    # set options on the object
    lookup_obj.set_options({'display_obj': display_obj})

    # run the lookup plugin with normalized options
    result = lookup_obj.run(terms=['DEFAULT_MODULE_LANG'], variables={'module_name': 'uri'}, on_missing='error', plugin_type=None, plugin_name=None, **{'var': 'module_name'})

    assert result == ['python']

    # run the lookup plugin with non-normalized options

# Generated at 2022-06-21 05:51:23.170535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.utils import context_objects as co

    stdout = StringIO()
    stderr = StringIO()

    with co.global_context_manager.push(stdout=stdout, stderr=stderr):
        lm = LookupModule(basedir=[])
        assert lm.run([''], {'DEFAULT_ROLES_PATH':'/my/fake/roles/path'}) == ['/my/fake/roles/path']
        assert lm.run(['non_existing_setting'], {}, on_missing='warn') == []
        assert lm.run(['non_existing_setting'], {}) == []

# Generated at 2022-06-21 05:51:26.678859
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(var_options={'foo': 'bar'}, direct={'plugin_type': 'become', 'plugin_name': 'root', 'on_missing': 'error'})
    l.run([None])

# Generated at 2022-06-21 05:51:38.589692
# Unit test for constructor of class LookupModule
def test_LookupModule():
  """This is a unit test for the constructor of class LookupModule"""
  import ansible.plugins.loader as plugin_loader
  import ansible.constants as C
  import ansible.module_utils._text as to_native
  import ansible.utils.sentinel as Sentinel
  import ansible.errors as AnsibleError
  import ansible.module_utils.six as string_types
  import ansible.plugins.lookup as LookupBase
  from ansible.errors import AnsibleOptionsError
  from ansible.module_utils.six import string_types
  from ansible.plugins.lookup import LookupBase
  from ansible.utils.sentinel import Sentinel
 
  # Test for class LookupBase