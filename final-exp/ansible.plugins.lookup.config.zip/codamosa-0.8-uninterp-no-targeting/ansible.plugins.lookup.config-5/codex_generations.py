

# Generated at 2022-06-21 05:43:03.143008
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error1 = MissingSetting('Unable to find setting', orig_exc='')
    assert error1.message == 'Unable to find setting'
    assert error1.orig_exc == ''

# Generated at 2022-06-21 05:43:08.436141
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    test_msg = 'Test msg'
    s = MissingSetting(test_msg)
    assert s.message == test_msg

    test_exc = Exception('TestException')
    s = MissingSetting(test_msg, orig_exc=test_exc)
    assert s.message == test_msg
    assert s.orig_exc.message == test_exc.message

# Generated at 2022-06-21 05:43:09.480573
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('foo')
    assert missing_setting.message == 'foo'

# Generated at 2022-06-21 05:43:20.367016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.sentinel import Sentinel

    # lookup module
    lookup_module = lookup_loader.get('config', class_only=True)

    # LookupModule object
    lookup_object1 = lookup_module()

    # test case 1
    ans_config = 'DEFAULT_BECOME_USER'
    plugin_type = 'connection'
    plugin_name = 'ssh'
    term_is_not_string_type = 1234
    on_missing = 'error'
    assert lookup_object1.run([term_is_not_string_type], variables=None, on_missing = on_missing) == []



# Generated at 2022-06-21 05:43:32.101310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create objects that can be used by lookup
    mock_loader = Mock(**{'get.return_value': None})
    mock_module_utils_six = Mock(string_types=['connect'])

    with patch.multiple(
        plugin_loader,
        connection_loader=mock_loader,
        **{'module_utils.six': mock_module_utils_six}
    ):
        # create LookupModule object
        lookup_obj = LookupModule()

        # create test terms
        terms = [
            'connection',
            'ok',
            'connection1',
            'connection2',
            'connection3'
        ]
        # create test variables

# Generated at 2022-06-21 05:43:42.847808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    lookup = LookupModule()
    assert lookup.run([b'python_version'], on_missing='warn') == ['2.7']
    assert lookup.run([b'python_version'], on_missing='skip') == ['2.7']
    assert lookup.run([b'python_version'], on_missing='error') == ['2.7']
    assert lookup.run([b'python_version'], on_missing='doesnotexist') == []

    try:
        lookup.run(None, on_missing="error")
    except AnsibleOptionsError as e:
        assert str(e) == '"on_missing" must be a string and one of "error", "warn" or "skip", not None'


# Generated at 2022-06-21 05:43:44.240726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 05:43:45.550796
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupBase))

# Generated at 2022-06-21 05:43:48.675147
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Test message"
    orig_exc = "Exception object"
    ms = MissingSetting(msg, orig_exc)
    assert msg == ms.message
    assert orig_exc == ms.orig_exc

# Generated at 2022-06-21 05:44:00.159501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_get_config_value(config, plugin_type=None, plugin_name=None, variables=None):
        if config == 'plugin_setting':
            return 'plugin_setting_value'
        else:
            raise MissingSetting(u'Unable to find setting %s' % config)

    module = LookupModule()
    module.set_options(var_options={'role_path': 'foo'})
    terms = ['DEFAULT_ROLES_PATH', 'UNKNOWN_SETTING']
    C.config.get_config_value = mock_get_config_value
    result = module.run(terms=terms)
    assert result == ['foo']



# Generated at 2022-06-21 05:44:16.280562
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("ERROR")
    except MissingSetting as e:
        assert str(e) == "ERROR"

# Generated at 2022-06-21 05:44:18.623239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['REMOTE_PORT']
    module_run = module.run(terms)
    assert module_run == [22]


# Generated at 2022-06-21 05:44:32.032237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    constants = {'FOO': {'path': '/foo/bar'}, 'BAR': {'path': '/baz/quux'}}

    class Loader(object):
        class C(object):
            def __init__(self, plugin_type, plugin_name):
                self._load_name = '%s.%s' % (plugin_type, plugin_name)

    class PL(object):
        def get(self, pname, class_only=None):
            if plugin_type == 'connection' and pname == 'local':
                pname = 'ssh'
            if plugin_type == 'lookup' and pname == 'password':
                pname = 'ansible.plugins.lookup.password.LookupModule'

# Generated at 2022-06-21 05:44:43.292986
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_vars = {}
    plugin_vars = {}
    inventory = Mock(host_list=['127.0.0.1'], get_host_variables='127.0.0.1')
    connection = Mock(transport='ssh', connect_timeout=5, conn_timeout=5, become_method='sudo',
                      become_username='root', become_password=None, become_exe=None, become_flags=None)
    task_vars = {'hostvars': {'127.0.0.1': plugin_vars}}
    loader = Mock()
    session = Mock(play=play, task=task, inventory=inventory, connection=connection, loader=loader)
    new_term = LookupModule()


# Generated at 2022-06-21 05:44:55.557129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.compat.cStringIO import StringIO

    class FakeVars():
        ansible_connection = 'local'
        ansible_python_interpreter = '/usr/bin/python'

    class FakeOpts():
        module_name = 'fake_module'
        private_key_file = 'key.pem'
        connection = 'ssh'
        become_user = 'ansible'
        forks = 5
        remote_user = 'ansible'
        cache_plugin = 'fake_module'
        terminal_history_dir = '/tmp/fake'
        host_vars = '/tmp/fake'
        group_vars = '/tmp/fake'
        library = '/tmp/fake'
        roles_path = '/tmp/fake'
        runner_async = True

# Generated at 2022-06-21 05:44:57.176476
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ex = MissingSetting('Unable to find setting foo')
    assert ex.message == 'Unable to find setting foo'

# Generated at 2022-06-21 05:45:01.238863
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Something is missing'
    e = Exception()
    x = MissingSetting(msg, orig_exc=e)
    assert x.orig_exc == e, 'orig_exc is not properly initialized'
    assert x.message == msg, 'Message is not properly initialized'
    x = MissingSetting(msg)
    assert x.orig_exc is None, 'orig_exc is not properly initialized'

# Generated at 2022-06-21 05:45:06.191666
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    #Test the constructor and the get_msg method
    error = MissingSetting("setting not found")
    assert error.get_msg() == "setting not found"


# Generated at 2022-06-21 05:45:10.897851
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # create an exception
    exception = MissingSetting("I am a MissingSetting exception")
    # check the exception
    assert exception.message == "I am a MissingSetting exception"
    assert exception.orig_exc is None

# Generated at 2022-06-21 05:45:11.442028
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing = MissingSetting('Unit Test')

# Generated at 2022-06-21 05:45:28.355012
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config = LookupModule()
    assert hasattr(config, '_templar')
    assert hasattr(config, '_display')


# Generated at 2022-06-21 05:45:30.953818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ut_lookup = LookupModule()
    assert isinstance(ut_lookup, LookupModule)
    assert ut_lookup.fail_on_undefined_errors is False


# Generated at 2022-06-21 05:45:38.165785
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    #Test with valid exception
    e = AnsibleOptionsError('AnsibleOptionsError')
    m = MissingSetting('MissingSetting', orig_exc=e)
    assert "AnsibleOptionsError" in m.message
    assert str(m.__class__) in 'ansible.module_utils.ansible_release._tls_wrappers.MissingSetting'

    #Test with invalid exception
    m = MissingSetting('MissingSetting', orig_exc=2)
    assert 'AnsibleOptionsError' not in m.message
    assert str(m.__class__) in 'ansible.module_utils.ansible_release._tls_wrappers.MissingSetting'

# Generated at 2022-06-21 05:45:40.225872
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting("Message", "")

# Generated at 2022-06-21 05:45:40.977887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:45:46.989463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # get a plug and run it
    plug = LookupModule()
    result = plug.run(["DEFAULT_ROLES_PATH"])
    assert result[0] == C.DEFAULT_ROLES_PATH
    # get a plug and run it
    plug = LookupModule()
    result = plug.run(["ANSIBLE_CONFIG"], {})
    assert result[0] == C.ANSIBLE_CONFIG
    # get a plug and run it
    plug = LookupModule()
    result = plug.run(["HOST_KEY_CHECKING"], {})
    assert result[0] == C.HOST_KEY_CHECKING


# Generated at 2022-06-21 05:45:50.673880
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config = LookupModule()
    assert config.run(None, None) == True

# Generated at 2022-06-21 05:45:59.858896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupBase(object):
        def __init__(self):
            self.sentinel = Sentinel()

        def set_options(self, var_options, direct):
            self.var_options = var_options
            self.direct = direct

        def get_option(self, option):
            return self.direct.get(option, self.sentinel)

    # Arrange
    mBase = MockLookupBase()
    lu = LookupModule()
    lu.set_loader(mBase)

    mBase.set_options = MockLookupBase.set_options
    mBase.get_option = MockLookupBase.get_option

    res = [
        'test_value',
        'test_value2'
    ]

    # Act

# Generated at 2022-06-21 05:46:02.250043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-21 05:46:05.098668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert "localhost" == module.run(["DEFAULT_HOST"])

# Generated at 2022-06-21 05:46:32.027670
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupBase.__init__

# Generated at 2022-06-21 05:46:33.598620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    assert plugin.run(['DEFAULT_BECOME_USER']) == ['root']

# Generated at 2022-06-21 05:46:42.239141
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create LookupModule instance named 'test_module'
    test_module = LookupModule()
    # Check type of instance
    assert isinstance(test_module, LookupModule)
    # Check type of information returned by run()
    assert isinstance(test_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{}), list)
    # Check return value
    assert test_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{}) == ['root']
    # Check if any exception is thrown
    assert test_module.run(terms=["ABCD"], variables=None, **{}) == []
    # Check if any exception is thrown
    assert test_module.run(terms=[None], variables=None, **{}) == []
    assert test_module

# Generated at 2022-06-21 05:46:44.057348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_args = {'_terms': ['one','two','three'],'direct': {}}
    lookup_module = LookupModule()
    lookup_module.run(**test_args)

# Generated at 2022-06-21 05:46:54.587702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Checking for AnsibleOptionError
    # Invalid missing argument value, only error, skip and warn are valid values
    # For test purpose we assign in_valid_missing value to variable missing
    # So the variable missing is invalid, we should get AnsibleOptionError
    missing = 'in_valid_missing'
    try:
        # If we have got AnsibleOptionError then this line should not execute
        # Because the variable is invalid
        module.run([], 'variables', on_missing=missing)
    except AnsibleOptionsError as e:
        # If we have got AnsibleOptionError then this block should execute
        assert "\"on_missing\" must be a string and one of \"error\", \"warn\" or \"skip\", not in_valid_missing" == to_native(e)

    # Checking for AnsibleOptionError

# Generated at 2022-06-21 05:47:01.425398
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(['DEFAULT_ROLES_PATH'])
    assert ret == ['/etc/ansible/roles:/usr/share/ansible/roles']
    ret = lookup_plugin.run(['DEFAULT_ROLES_PATH'], variables={'DEFAULT_ROLES_PATH': '/tmp/ansible/roles'})
    assert ret == ['/tmp/ansible/roles']

# Generated at 2022-06-21 05:47:04.263730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the constructor of the class LookupModule"""
    assert LookupModule is not None

# Generated at 2022-06-21 05:47:11.495331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test invoking plugin using ptype and pname
    # global config are tested in test_defaults module, we only need to test plugin config
    plugin = 'test'
    ptype = 'shell'
    lookup_plugin = LookupModule()
    terms = ["remote_tmp"]

    result = lookup_plugin.run(terms, plugin_type=ptype, plugin_name=plugin, on_missing='warn')

    assert len(result) == 1
    assert result[0] == '/tmp/ansible'

# Generated at 2022-06-21 05:47:21.645754
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible.utils.sentinel import Sentinel
    assert issubclass(MissingSetting, AnsibleError)
    assert issubclass(MissingSetting, AnsibleOptionsError)
    assert issubclass(MissingSetting, LookupError)

    missing_setting = MissingSetting('', '', '')
    assert isinstance(missing_setting, MissingSetting)
    assert isinstance(missing_setting, Sentinel)

    assert 'AnsibleError' in [x.__name__ for x in MissingSetting.__mro__]

# Generated at 2022-06-21 05:47:33.743730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    test_dir = os.path.dirname(sys.modules[__name__].__file__)
    lookup_file = os.path.join(test_dir, 'lookup_plugins', 'config.py')

    # Load the LookupModule class definition for the test
    with open(lookup_file, 'rb') as f:
        exec(compile(f.read(), lookup_file, 'exec'), globals(), locals())

    # Call the run method
    result_list = locals()['LookupModule']().run(['DEFAULT_BECOME_USER'])

    if len(result_list) > 0:
        result = result_list[0]
        assert result == 'root'
    else:
        assert False

# Generated at 2022-06-21 05:48:06.572857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    with open('test_data/test_lookup_config.yaml', 'r') as f:
        terms = yaml.safe_load(f)
    ret = lookup.run(terms)
    assert ret == [C.DEFAULT_ROLES_PATH, [C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_SKIP], ['/home/test/test_ansible/retry/test.retry']]

# Generated at 2022-06-21 05:48:10.200175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("test_LookupModule")
    # pylint: disable=unused-variable
    LookupModuleResult = LookupModule()

# Generated at 2022-06-21 05:48:17.149480
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    m = MissingSetting('abc')
    assert m.message == 'abc'
    assert m.orig_exc is None

    from ansible.module_utils.common._collections_compat import OrderedDict
    a = AnsibleError("Error Message", orig_exc=OrderedDict([("a", 1), ("b", 2)]))
    m = MissingSetting("Error Message", orig_exc=a)
    assert m.orig_exc is a

# Generated at 2022-06-21 05:48:20.779008
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_str = "foo isn't configured"
    orig_exc = AnsibleError(error_str)
    test_missing_settings = MissingSetting(error_str, orig_exc=orig_exc)
    assert test_missing_settings.msg == error_str
    assert isinstance(test_missing_settings.orig_exc, AnsibleError)
    assert test_missing_settings.orig_exc.msg == error_str

# Generated at 2022-06-21 05:48:29.931734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    for plugin_type in ['become', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars']:
        plugin_name = plugin_type + '_plugin'
        lookup.set_options(plugin_type=plugin_type, plugin_name=plugin_name)

        for missing in ['error', 'warn', 'skip']:
            lookup.set_options(on_missing=missing)
            assert [missing] == lookup._run(['on_missing'], dict())

        assert ['debug'] == lookup._run(['DEFAULT_CALLBACK_WHITELIST'], dict())
        assert ['password'] == lookup._run(['DEFAULT_BECOME_PASS'], dict())

# Generated at 2022-06-21 05:48:41.023369
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests for plugin related lookup
    # A keep this in alphabetical order
    module = AnsibleModule(dict(config_name='git_multilevel_subdirectory_support', lookup_type='config', plugin_name='git', plugin_type='connection'))

    lookup_obj = LookupModule()
    result = lookup_obj.run(terms=['DEFAULT_BECOME_USER'])
    assert result == ['root'], "DEFAULT_BECOME_USER should be root"

    module = AnsibleModule(dict(config_name='force', lookup_type='config', plugin_name='git', plugin_type='vars'))
    result = lookup_obj.run(terms=['DEFAULT_BECOME_USER'])
    assert result == ['root'], "DEFAULT_BECOME_USER should be root"

   

# Generated at 2022-06-21 05:48:49.481269
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('This is my message')
    except MissingSetting as e:
        assert str(e) == 'This is my message'
        assert str(e.orig_exc) == 'None'
    try:
        raise MissingSetting('This is my message', orig_exc=AnsibleError('This is the original message'))
    except MissingSetting as e:
        assert str(e) == 'This is my message'
        assert str(e.orig_exc) == 'This is the original message'

# Generated at 2022-06-21 05:49:01.291464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import get_all_plugin_loaders

    # To test run method of class LookupModule, we need to first initialize some parameters, the value
    # for those parameters either come from ansible.cfg or call get_all_plugin_loaders to get value from
    # all plugins under ansible/plugins. To do that, we need to do following:
    # 1. create an ansible.cfg, set library path and roles path.
    # 2. create an ansible/plugins/action folder, add a test_action plugin
    # 3. set ansible.cfg location in the environment variable ANSIBLE_CONFIG
    # 4. set default_roles_path in the variable roles_path_sentinel
    # 5. remove ansible/plugins/action/test_action.py at the end

    import os
    import temp

# Generated at 2022-06-21 05:49:03.209984
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Bad setting encountered")
    except AnsibleOptionsError as e:
        assert str(e) == "Bad setting encountered"


# Generated at 2022-06-21 05:49:05.174494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: add unit tests for LookupModule
    pass

# Generated at 2022-06-21 05:50:03.027886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    lookup = LookupModule()

    # test the var_options variable
    lookup.set_options(var_options='ansible.cfg')
    assert lookup.run(['DEFAULT_BECOME_USER'])[0] == 'root'

    os.environ['ANSIBLE_CONFIG'] = 'ansible.cfg'
    lookup = LookupModule()

    # test lookup
    assert lookup.run(['DEFAULT_BECOME_USER'])[0] == 'root'
    assert lookup.run(['DEFAULT_LOG_PATH'])[0] == './ansible.log'

    # test missing attribute

# Generated at 2022-06-21 05:50:05.246742
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting("Unable to look up setting", orig_exc=None)
    assert missing_setting.message == "Unable to look up setting"
    assert missing_setting.orig_exc is None

# Generated at 2022-06-21 05:50:07.204544
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Testing')
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-21 05:50:17.387829
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test class vars
    lookup = LookupModule()
    # test to ensure the config function raises a warning
    lookup.get_option = lambda x: None
    lookup.set_options = lambda **kwargs: None
    lookup._display = lambda **kwargs: None
    lookup.get_option = lambda x: 'warn'
    lookup.set_options = lambda **kwargs: None
    lookup._display = lambda **kwargs: None

    # Test class methods
    assert len(lookup.run(['C.DEFAULT_MODULE_NAME'], {})) == 1
    assert lookup.run(['C.DEFAULT_MODULE_NAME'], {}) == ['command']
    assert len(lookup.run(['C.DEFAULT_MODULE_NAME', 'C.ANSIBLE_HOST_KEY_CHECKING'], {}))

# Generated at 2022-06-21 05:50:19.337601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 05:50:23.375377
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    test = True
    if result is None:
        test = False
    elif len(result) == 0:
        test = False

    assert test


# Generated at 2022-06-21 05:50:33.054876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._display = lambda msg: None

    # missing is error and no plugin info
    result = lm.run(['bad_term'])
    assert result == []

    # missing is error and no plugin info
    lm.set_options(direct={'on_missing': 'error'})
    result = lm.run(['bad_term'])
    assert result == []

    # missing is error, plugin_type and plugin_name
    lm.set_options(direct={'on_missing': 'error', 'plugin_type': 'lookup', 'plugin_name':'file'})
    result = lm.run(['bad_term'])
    assert result == []

    # missing is skip, plugin_type and plugin_name

# Generated at 2022-06-21 05:50:38.236702
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('This is a test exception')
    except MissingSetting as e:
        assert e.args[0] == 'This is a test exception'

# Generated at 2022-06-21 05:50:42.652862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert lu is not None
    # Test for missing value
    result = lu.run([], variables={'debug': True}, on_missing='skip')
    assert result == []

# Generated at 2022-06-21 05:50:46.609571
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test_message')
    assert e.message == 'test_message'
    assert e.orig_exc is None

# Generated at 2022-06-21 05:52:50.896896
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        missing_setting_object = MissingSetting('This is a test exception.')
        if missing_setting_object.orig_exc is not None:
            raise
    except Exception:
        assert False, 'Failed to create a valid MissingSetting object.'
    else:
        assert True, 'Successfully created a valid MissingSetting object.'