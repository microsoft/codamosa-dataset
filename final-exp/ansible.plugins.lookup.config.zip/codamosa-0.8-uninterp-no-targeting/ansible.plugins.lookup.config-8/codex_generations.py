

# Generated at 2022-06-21 05:43:00.651587
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 05:43:03.131711
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('test')
    assert error.message == 'test'
    assert error.orig_exc is None



# Generated at 2022-06-21 05:43:05.183851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-21 05:43:17.192002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set1 = LookupModule()
    terms = ["DEFAULT_ROLES_PATH"]
    variables = {'roles_path' : "/etc/ansible/roles:/usr/share/ansible/roles"}
    set1.run(terms, variables, on_missing="error")

    set2 = LookupModule()
    terms = ["DEFAULT_ROLES_PATH"]
    set2.run(terms, on_missing="error")

    set3 = LookupModule()
    terms = [["DEFAULT_ROLES_PATH"]]
    set3.run(terms, on_missing="error")

# Generated at 2022-06-21 05:43:18.637889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 05:43:25.513463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up some variables that can be used by the tests.
    test_sentinel = Sentinel
    variables = dict()
    terms1 = ['hostfile']
    terms2 = ['hostfile', 'host_key_checking']
    result_terms1 = None
    result_terms2 = None
    result_terms1_missing = None

    # call the run method with no variables and one term in the terms object
    # to get the result that can be used to test run on the second call.
    lm = LookupModule()
    result_terms1 = lm.run(terms1, variables)

    # call the run method with no variables and two terms in the terms object
    # to get the result for testing the run method.
    lm = LookupModule()
    result_terms2 = lm.run(terms2, variables)

   

# Generated at 2022-06-21 05:43:27.155188
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting("help")
    assert m.message == "help"

# Generated at 2022-06-21 05:43:28.858626
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert issubclass(MissingSetting, AnsibleOptionsError)

# Generated at 2022-06-21 05:43:41.587176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p1_load_name = 'lookup_shell_test_plugin'
    p2_load_name = 'lookup_shell_test_plugin2'
    p1_name = 'lookup_shell_test_plugin.py'
    p2_name = 'lookup_shell_test_plugin2.py'

    class TestPlugin(object):
        def __init__(self):
            self._load_name = p1_load_name

    class TestPlugin2(object):
        def __init__(self):
            self._load_name = p2_load_name

    class TestLoader(object):
        def __init__(self):
            self._plugins = { p1_load_name:TestPlugin(), p2_load_name:TestPlugin2() }


# Generated at 2022-06-21 05:43:43.590218
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting("test")
    assert missing_setting.message == "test"
    assert missing_setting.orig_exc is None
    assert str(missing_setting) == "test"



# Generated at 2022-06-21 05:43:57.741911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run(terms, variables=None, **kwargs)

    # test no setting
    # test no plugin_type setting
    # test on_missing with error
    # test on_missing with warn
    # test on_missing with skip
    # test with plugin_type setting
    # test with plugin_type and plugin_name
    pass

# Generated at 2022-06-21 05:44:00.401117
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    from ansible.utils.sentinel import Sentinel

    try:
        raise MissingSetting(Sentinel)
    except MissingSetting as e:
        assert(e.orig_exc is Sentinel)

# Generated at 2022-06-21 05:44:02.619492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.get_option(None)
    l.get_option("attribute_name")
    l.set_options(None, None)
    l.run(None, None)

# Generated at 2022-06-21 05:44:04.362800
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('Something is missing', {
        'msg': 'Something is missing',
        'orig_exc': 'Something is missing'
    })

# Generated at 2022-06-21 05:44:06.313170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.get_option()

# Generated at 2022-06-21 05:44:16.680769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for valid term and normal scenario
    g = globals()
    l = locals()
    lookup_module = LookupModule(g, l, None, {})
    assert lookup_module.run(
        [
            "DEFAULT_BECOME_USER"
        ],
        {
            "ansible_connection": "local",
            "ansible_inventory": "inventory.local",
            "ansible_playbook_python": "/usr/bin/python",
            "ansible_python_interpreter": "/usr/bin/python",
            "ansible_shell_type": "sh"
        }
    ) == [C.DEFAULT_BECOME_USER]

    # Test for invalid term and valid scenario

# Generated at 2022-06-21 05:44:17.655432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:44:30.013542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'on_missing': 'skip'})
    assert lookup.run(['DEFAULT_HOST_LIST'], variables={}) == [['127.0.0.1']]
    assert lookup.run(['UNKNOWN_KEY'], variables={}) == []
    lookup.set_options({'on_missing': 'error'})
    with pytest.raises(AnsibleLookupError) as exc:
        lookup.run(['UNKNOWN_KEY'], variables={})
    assert exc.value.kwargs['orig_exc'].orig_exc.args[0] == 'was not defined in configuration'

# Generated at 2022-06-21 05:44:38.338436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_ROLES_PATH']
    variables = {}

    lm = LookupModule()
    lm.set_options( var_options=variables, direct='DEFAULT_ROLES_PATH')
    result = lm.run(terms, variables)
    assert(result == ['/etc/ansible/roles:/usr/share/ansible/roles'])
    return

# Generated at 2022-06-21 05:44:40.055044
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting
    except MissingSetting as e:
        assert e.message is None

# Generated at 2022-06-21 05:44:57.730762
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.module_utils.six
    assert issubclass(LookupModule, ansible.module_utils.six.with_metaclass(LookupBase, object))

# Generated at 2022-06-21 05:45:04.537135
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.module_utils.common.collections import ImmutableDict

    args = ['DEFAULT_VAULT_PASSWORD_FILE']
    opt = {
        "plugin_type": "vault",
        "plugin_name": "identity",
        "on_missing": "error"
    }

    l = LookupModule()
    l.set_loader(plugin_loader.get('lookup'))
    l.set_options(var_options=ImmutableDict())
    l.set_options(direct=opt)

    assert l.run(args) == ['/some/path/to/vault.key']

# Generated at 2022-06-21 05:45:06.769573
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-21 05:45:15.913752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    # expected result
    result = ['tests/roles/test_roles/roles']
    # test
    assert m.run(terms, variables=None, direct=None) == result
    # test with plugin_type and plugin_name
    kwargs = {"plugin_type": 'connection', "plugin_name": 'local'}
    terms = ['connection_user', 'persistent_connection']
    # expected result
    result = ['localhost', True]
    # test
    assert m.run(terms, variables=None, direct=kwargs) == result

# Generated at 2022-06-21 05:45:25.189603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError

    options = {'plugin_type': 'connection', 'plugin_name': 'ssh'}

    # Test case 1
    lm = LookupModule()
    lm.get_option = mock.MagicMock()
    lm.get_option.return_value = 'error'

    result = lm.run(['unknown_term'], **options)

    assert result is False
    lm.get_option.assert_called_with('on_missing')
    assert lm.get_option.call_count == 1

    # Test case 2
    lm.get_option.reset_mock()

    result = lm.run(['remote_user'], **options)
    assert result == [u'ansible_user']

# Generated at 2022-06-21 05:45:26.758840
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # all supported options are tested
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 05:45:31.393369
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'foo'
    orig_exc = Exception()
    obj = MissingSetting(msg, orig_exc)
    # Test if the initialization works properly
    assert obj.message == msg
    assert obj.orig_exception == orig_exc

# Generated at 2022-06-21 05:45:34.646446
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    from ansible.utils.sentinel import Sentinel
    exc = Sentinel()
    msg = "test message"
    try:
        raise MissingSetting(msg, orig_exc=exc)
    except AnsibleLookupError as e:
        assert e.orig_exc == exc

# Generated at 2022-06-21 05:45:37.125414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-21 05:45:40.665742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert isinstance(ret, LookupModule)


# Generated at 2022-06-21 05:46:10.740627
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test error', orig_exc=IOError)
    assert(isinstance(e, IOError))

# Generated at 2022-06-21 05:46:14.976108
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting(msg="my message")
    except MissingSetting:
        pass
    else:
        assert(False, "test should have raised exception")

# Generated at 2022-06-21 05:46:19.011599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # missing_setting(config_arg_name, on_missing=None, orig_exc=None, **kwargs):
    #config_arg_name:
    #on_missing:
    #orig_exc:
    #kwargs:

    assert LookupModule.run("") == 'None'

# Generated at 2022-06-21 05:46:24.187079
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    lookup._display = MockDisplay()
    lookup.set_options()

    assert lookup.get_option('on_missing') == 'error'


# Unit tests for the 'run' method of the LookupModule class

# Generated at 2022-06-21 05:46:27.393655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([], {})
    assert result is None


# Generated at 2022-06-21 05:46:36.635518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(['DEFAULT_ROLES_PATH', 'REMOTE_USER'])
    assert result == ['roles', 'root']
    result = lookup_module.run(['DEFAULT_ROLES_PATH', 'custom_val'])
    assert result == ['roles']
    result = lookup_module.run(['DEFAULT_ROLES_PATH', 'custom_val'], on_missing='warn')
    assert result == []
    result = lookup_module.run(['DEFAULT_ROLES_PATH', 'REMOTE_USER', 'custom_val'])
    assert result == ['roles', 'root', 'root']

# Generated at 2022-06-21 05:46:39.520245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert hasattr(my_lookup, "run")

# Generated at 2022-06-21 05:46:41.400920
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('Testing')
    assert error.message == 'Testing'
    assert error.orig_exc is None
    assert error.python_version is None

# Generated at 2022-06-21 05:46:46.143743
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert len(MissingSetting.__bases__) == 2
    assert MissingSetting.__bases__[0] == AnsibleOptionsError
    assert MissingSetting.__bases__[1] == AnsibleError

# Generated at 2022-06-21 05:46:51.173972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms = ['DEFAULT_ROLES_PATH', 'INVENTORY_UNPARSED_FAILED', 'DEFAULT_ROLES_PATH']
    result = lu.run(terms)
    assert result[0] == './roles:roles'
    assert result[1] == 'ignore'
    assert result[2] == './roles:roles'

# Generated at 2022-06-21 05:47:50.276241
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    a = MissingSetting('test_setting')
    if a.setting == 'test_setting':
        print("Succes")
    else:
        print("Fail")

# Generated at 2022-06-21 05:47:52.603464
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Config key not specified", None)
    except MissingSetting as e:
        assert e.message == "Config key not specified"

# Generated at 2022-06-21 05:48:00.145024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule, json

    def exec_module(module_args):
        lookup_plugin = LookupModule()

# Generated at 2022-06-21 05:48:01.509156
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting("Test message", orig_exc=AnsibleError("Original exception"))
    assert str(missing_setting) == "Test message"

# Generated at 2022-06-21 05:48:03.568912
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None
    return module

# Generated at 2022-06-21 05:48:05.652307
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    variable = 'foo'
    exception = None
    missing_setting = MissingSetting('foo was not defined', exception)
    assert missing_setting.display == 'foo was not defined', missing_setting.display

# Generated at 2022-06-21 05:48:18.192215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader_fixture import \
        get_loader_with_multiple_configs_and_multiple_plugins_in_config

    def _call_for_test(terms, variables=None, **kwargs):
        m = LookupModule()
        return m.run(terms, variables, **kwargs)

    # test 1
    terms = ['lookup_plugin.value']

    loader = get_loader_with_multiple_configs_and_multiple_plugins_in_config()

    # pylint: disable=protected-access
    expected_result = loader.get('lookup_plugin.value', plugin_type='lookup')
    assert _call_for_test(terms) == expected_result

    # test 2
    terms = ['lookup_plugin.value2']

    # pylint: disable=

# Generated at 2022-06-21 05:48:18.592685
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting('test')

# Generated at 2022-06-21 05:48:25.804232
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    class MyExc(Exception):
        pass

    exc = MyExc("MyException")
    miss = MissingSetting("foo", orig_exc=exc)
    assert "foo" == miss.msg
    assert "MyException" == miss.orig_exc.args[0]
    assert True == isinstance(miss.orig_exc, MyExc)


# Generated at 2022-06-21 05:48:26.920860
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    lookuperr = MissingSetting('test')
    assert lookuperr.message == 'test'

# Generated at 2022-06-21 05:50:19.821746
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    inst = MissingSetting('', orig_exc=None)
    assert inst.orig_exc == None
    assert inst.message == ''

# Generated at 2022-06-21 05:50:29.206937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test Case
    test_case = {
        'module_defaults': {
            'warn_only': False,
            'verbosity': 0,
            'check': False,
            'force': False,
            'no_log': False,
            'remote_user': None,
            'remote_pass': None,
            'remote_port': None
        },
        'terms': ['_ansible_verbose_override', 'remote_user', 'remote_pass', 'remote_port'],
        'Plugin': None,
        'result': [False, 'root', None, None]
    }

    # Return class LookupModule

# Generated at 2022-06-21 05:50:31.310553
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('test')
    assert error.error_message == 'test'
    assert error.orig_exc is None
    assert not error.fixes

# Generated at 2022-06-21 05:50:36.347828
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest

    with pytest.raises(AnsibleOptionsError) as excinfo:
        MissingSetting('msg')

    assert str(excinfo.value) == 'msg'

# Generated at 2022-06-21 05:50:40.032012
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.utils.sentinel import Sentinel
    ms = MissingSetting('dummy error msg')
    assert ms.orig_exc == Sentinel

# Generated at 2022-06-21 05:50:42.608409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['DEFAULT_BECOME_USER'],'') is not None

# Generated at 2022-06-21 05:50:55.625818
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test missing setting exception
    lookup_module_obj = LookupModule()
    try:
        lookup_module_obj.run(terms=['UNKNOWN_SETTING'], variables={}, on_missing="error")
        assert False
    except AnsibleLookupError:
        pass

    # test missing setting error
    lookup_module_obj = LookupModule()
    assert lookup_module_obj.run(terms=['UNKNOWN_SETTING'], variables={}, on_missing="error",
                                 fail_on_undefined=True) == []
    try:
        lookup_module_obj.run(terms=['UNKNOWN_SETTING'], variables={}, on_missing="error",
                              fail_on_undefined=True)
        assert False
    except AnsibleLookupError:
        pass

    # test missing setting warn


# Generated at 2022-06-21 05:51:00.474684
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    inst = MissingSetting("Invalid")
    assert inst.message == "Invalid"
    assert inst.orig_exc is None
    assert inst.errors() == []


# Generated at 2022-06-21 05:51:01.920529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 05:51:11.044368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verify lookups for get_all_config for a plugin
    lookup_module = LookupModule()
    terms = []
    variables = {}
    result = lookup_module.run(terms, variables, plugin_name='netconf', plugin_type='connection')
    assert result[0]['host'] == '{{ inventory_hostname }}'

    # Verify lookups for get_all_config for a non-existent plugin
    lookup_module = LookupModule()
    terms = []
    variables = {}
    result = lookup_module.run(terms, variables, plugin_name='noconf', plugin_type='connection')
    assert type(result[0]) == str

    # Verify lookups for get_all_config for a global config
    lookup_module = LookupModule()
    terms = []
    variables = {}
    result = lookup_