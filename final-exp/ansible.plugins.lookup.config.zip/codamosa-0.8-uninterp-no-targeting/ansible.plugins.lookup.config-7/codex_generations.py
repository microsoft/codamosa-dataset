

# Generated at 2022-06-21 05:43:05.057635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        assert LookupModule()
    except:
        print("Failed to instantiate a lookup module")
        return False
    return True

# Test for method run of class LookupModule

# Generated at 2022-06-21 05:43:08.085002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-21 05:43:10.777959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-21 05:43:12.174973
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 05:43:24.784242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create class
    l = LookupModule()

    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    # generate args for test run
    args_list = [
        dict(terms=['default_test_test'], variables={}),
        dict(terms=['default_test_test'], variables={}, on_missing='error'),
        dict(terms=['default_test_test'], variables={}, on_missing='warn'),
        dict(terms=['default_test_test'], variables={}, on_missing='skip'),
        dict(terms=['default_test_test'], variables={}, plugin_type='become', plugin_name='sudo'),
        dict(terms=['default_test_test'], variables={}, plugin_name='test'),
    ]

    # generate expected

# Generated at 2022-06-21 05:43:27.502300
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    with pytest.raises(MissingSetting) as exception:
        raise MissingSetting('new error')

    assert str(exception.value) == 'new error'

# Generated at 2022-06-21 05:43:29.000632
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 05:43:32.223315
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting("message")
    assert err.message == "message"
    assert err.orig_exc is None

# Generated at 2022-06-21 05:43:42.900572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instances of the class LookupBase
    lookup_base = LookupBase()
    lookup_base.set_options(direct={'on_missing':'error'})

    # Test the method run with all permutations
    try:
        # Test the method run of class LookupBase with no terms
        lookup_base.run((), {}, on_missing='error')
    except AnsibleOptionsError:
        pass

    try:
        # Test the method run of class LookupBase with a term that is not a string
        lookup_base.run((123,), {}, on_missing='error')
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-21 05:43:48.451592
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_cls = LookupModule
    lookup = lookup_cls()
    print('\n' + repr(lookup.run(terms=['DEFAULT_ROLES_PATH'], variables=None,
                             on_missing='error', foo='bar')))


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:44:02.240879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 05:44:03.713927
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert not issubclass(Exception, MissingSetting)
    assert issubclass(MissingSetting, Exception)


# Generated at 2022-06-21 05:44:06.754335
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    ex = MissingSetting('message', 'orig_exc')

    assert ex.message == 'message'
    assert ex.orig_exc == 'orig_exc'

# Generated at 2022-06-21 05:44:08.891772
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'ABC'
    result = MissingSetting(msg)
    assert (result.msg == msg), 'Error Message does not match'

# Generated at 2022-06-21 05:44:20.080540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule
    from ansible.module_utils.lookup_loader import LookupModuleLoader
    import sys
    class MockLoader:
        def __init__(self):
            self.mock = {}

        def get(self, name, class_only=False):
            if class_only:
                return self.mock.get(name)
            else:
                return self.mock[name]

    lk = LookupModule()
    terms = ["DEFAULT_BECOME_USER"]
    mock_loader = MockLoader()
    mock_loader.mock['ssh'] = LookupModuleLoader.get('ssh', class_only=True)
    sys.modules['ansible.plugins.loader'] = mock_loader

# Generated at 2022-06-21 05:44:21.984053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(["date_format"]) == [C.DEFAULT_DATE_FORMAT] == [C.config.get_config_value("date_format", variables=None)]



# Generated at 2022-06-21 05:44:32.821021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test1: Test run with no arguments
    try:
        lookup_result = LookupModule().run([])
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError("Expected error was not thrown")

    # Test2: Test run with invalid setting identifier
    try:
        lookup_result = LookupModule().run([None])
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError("Expected error was not thrown")

    # Test3: Test run with normal setting identifier
    lookup_result = LookupModule().run(["__TEST_ANSIBLE_CONFIG__"])
    assert eq(lookup_result[0], False) is True

    # Test4: Test run with error option

# Generated at 2022-06-21 05:44:40.623018
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.basic import AnsibleModule
    assert not MissingSetting("")
    module = AnsibleModule(argument_spec={})
    e = AnsibleOptionsError("")
    with pytest.raises(AnsibleOptionsError) as exc:
        raise AnsibleOptionsError("")
    assert MissingSetting("", orig_exc=e).args == ("",)
    assert str(MissingSetting("", orig_exc=e)) == ""

# Generated at 2022-06-21 05:44:43.141656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # All tests are done in test_lookup_plugins.py
    pass

# Generated at 2022-06-21 05:44:50.866043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule
    lookup_cmd = LookupModule()
    assert isinstance(lookup_cmd, LookupModule)

    # test method run
    terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"]
    result = lookup_cmd.run(terms)
    assert isinstance(result, list)
    assert len(result) == 2


# Generated at 2022-06-21 05:45:16.332500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    result = lookup_obj.run(['DEFAULT_ROLES_PATH'])
    assert ['~/.ansible/roles:/usr/share/ansible/roles'] == result
    result = lookup_obj.run(['UNDEFINED_VARIABLE'], variables={'UNDEFINED_VARIABLE': '/tmp'})
    assert ['/tmp'] == result
    with pytest.raises(AnsibleOptionsError):
        lookup_obj.run([''])
    with pytest.raises(AnsibleOptionsError):
        lookup_obj.run(['DEFAULT_ROLES_PATH'], on_missing='invalid')

# Generated at 2022-06-21 05:45:20.156119
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting('a', 'b')
    assert type(ms) == MissingSetting
    assert str(ms) == 'b'
    assert ms.orig_exc == 'a'

# Generated at 2022-06-21 05:45:28.534678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    # Test missing setting
    with pytest.raises(AnsibleOptionsError) as e:
        m.run([1,2])
    # Test invalid on_missing input
    with pytest.raises(AnsibleOptionsError) as e:
        m.run([1,2], on_missing='notvalid')
    # Test invalid plugin_type input
    with pytest.raises(AnsibleOptionsError) as e:
        m.run([1,2], plugin_type='notvalid')
    # Test invalid plugin_name input
    with pytest.raises(AnsibleOptionsError) as e:
        m.run([1,2], plugin_name='notvalid')
    # Test plugin_type without plugin_name

# Generated at 2022-06-21 05:45:29.347747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 05:45:38.165998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    import ansible.constants as C
    ansible_consts = C
    C.DEFAULT_ROLES_PATH = "test"
    result_1 = lookup_mod.run(['DEFAULT_ROLES_PATH'], {})
    assert result_1 == [C.DEFAULT_ROLES_PATH]
    result_2 = lookup_mod.run(['DEFAULT_ROLES_PATH'], {}, on_missing='skip')
    assert result_2 == [C.DEFAULT_ROLES_PATH]
    result_3 = lookup_mod.run(['DEFAULT_ROLES_PATH'], {}, on_missing='warn')
    assert result_3 == [C.DEFAULT_ROLES_PATH]
    result_4 = lookup_mod.run

# Generated at 2022-06-21 05:45:43.734886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with one term
    # Test with valid and invalid on_missing
    # Test with multiple terms
    # Test with one and two pair of plugin_name and plugin_type, valid and invalid
    # Test with all global, all plugin or a mix of the two
    variables = dict()
    ret1 = ['v1', 'v2']
    ret2 = ['v3', 'v4']
    variables['var_options'] = ret1
    terms = ['ansible_user']
    # Test with one term
    look = LookupModule()
    look.set_options(var_options=variables, direct=None)
    results = look.run(terms, variables=variables, direct=None)
    assert(results == ret1)
    # Test with valid and invalid on_missing
    result_test2 = ''

# Generated at 2022-06-21 05:45:48.068139
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise AnsibleOptionsError('"on_missing" must be a string and one of "error", "warn" or "skip", not %s' % missing)
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-21 05:45:54.939528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = ['DEFAULT_BECOME_USER']
    test_variables = {'foo': 'bar'}
    test_kwargs = {'plugin_type': 'shell'}
    lookup_plugin = LookupModule()
    lookup_plugin.run(test_terms, test_variables, **test_kwargs)

# Generated at 2022-06-21 05:45:58.232730
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """
    This is a simple unit test to verify that `MissingSetting` class
    is constructed correctly.

    Returns:
        None.
    """

    try:
        raise MissingSetting("Test error")
    except MissingSetting as e:
        assert e.message == "Test error"

# Generated at 2022-06-21 05:46:10.121183
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting('This is a test exception')
    assert isinstance(exception, AnsibleOptionsError)
    assert isinstance(exception, AnsibleError)
    assert exception.orig_exc is None
    assert exception.__unicode__() == 'This is a test exception'
    assert str(exception) == 'This is a test exception'

    assert isinstance(exception.to_json(), dict)
    assert exception.to_json() == {
        'exception': 'AnsibleOptionsError',
        'exception_type': 'exceptions.AnsibleOptionsError',
        'msg': 'This is a test exception',
        'orig_exception': None,
    }

    assert isinstance(exception.to_nice_json(indent=2, sort_keys=False), string_types)
    assert exception

# Generated at 2022-06-21 05:46:49.045365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(dict(var_options = dict(), direct = dict()))
    # Test case 1 - simple config variable
    config_terms = ['CACHE_PLUGIN_CONNECTION']
    actual_result = lookup_module.run(config_terms, dict())
    assert actual_result == ['local']
    # Test case 2 - None config variable
    config_terms = ['NON_EXISTENT_CONFIG']
    actual_result = lookup_module.run(config_terms, dict())
    assert actual_result == []
    # Test case 3 - list of config variables
    config_terms = ['CACHE_PLUGIN_CONNECTION', 'NON_EXISTENT_CONFIG']

# Generated at 2022-06-21 05:46:52.406001
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('foo')
    assert missing_setting.args[0] == 'foo'

# Generated at 2022-06-21 05:46:56.229418
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    Args = ('Test MissingSetting', 'test_MissingSetting')
    err = MissingSetting(*Args)
    assert Args[0] in str(err)

# Generated at 2022-06-21 05:47:01.806835
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # On missing is "error"
    try:
        raise MissingSetting("Test message", orig_exc=TypeError("Original exception"))
    except MissingSetting as e:
        assert str(e) == "Test message"
        assert type(e.orig_exc) == TypeError
        assert e.orig_exc.args[0] == "Original exception"
    # On missing is "warn" or "skip" (should not be raised)
    pass

# Generated at 2022-06-21 05:47:07.665794
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test message", orig_exc="test exception")
    except MissingSetting as e:
        assert(e.message == "test message")
        assert(e.orig_exc == "test exception")

# Generated at 2022-06-21 05:47:09.410771
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert lookup.get_option('on_missing') == 'error'


# Generated at 2022-06-21 05:47:15.224477
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting(u'Error message')
    except MissingSetting as e:
        assert type(e.message) is unicode
        assert e.message == u'Error message'
        assert e.orig_exc is None

# Generated at 2022-06-21 05:47:16.739514
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:47:20.691289
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.orig_exc is None
        assert e.args[0] == 'test'



# Generated at 2022-06-21 05:47:33.643920
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # test no terms
    terms = []
    if len(lookup_plugin.run(terms)) != 0:
        raise AssertionError('no input expected to return []')
    # test one unknown term
    terms = ['UNKNOWN']
    try:
        lookup_plugin.run(terms)
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError('unknown term should raise AnsibleOptionsError')
    # test one known term
    terms = ['DEFAULT_HOST_LIST']
    if lookup_plugin.run(terms) != C.DEFAULT_HOST_LIST:
        raise AssertionError('Known term should return C.DEFAULT_HOST_LIST')
    # test two terms

# Generated at 2022-06-21 05:48:26.370228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    actual = lookup.get_option("on_missing")
    expected = "error"
    assert actual == expected

# Generated at 2022-06-21 05:48:39.686560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_ROLES_PATH']
    variables = {'somevar': 'someval'}
    mylookup = LookupModule(sentinel.loader, sentinel.environment, terms, variables, sentinel.basedir, sentinel.FailOnUndefined, sentinel.plugin_filter)
    assert mylookup.loader == sentinel.loader
    assert mylookup.environment == sentinel.environment
    assert mylookup.terms == terms
    assert mylookup.variables == variables
    assert mylookup.basedir == sentinel.basedir
    assert mylookup.FailOnUndefined == sentinel.FailOnUndefined
    assert mylookup.plugin_filter == sentinel.plugin_filter
    assert mylookup.plugin_type is None
   

# Generated at 2022-06-21 05:48:45.288111
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'This is a message to test the constructor of class MissingSetting'
    ex = AnsibleError(msg)
    obj = MissingSetting(msg, orig_exc=ex)
    assert obj.message == msg
    assert obj.orig_exc == ex

# Generated at 2022-06-21 05:48:53.613479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # note, this is only testable if ansible.cfg environment is properly setup
    # ie, the correct ROLE_PATH and COLOR_* environment variables are set
    variables = {}
    config = None
    ret = []
    cls = LookupModule(config, variables)

    # test RED_FACTS
    terms = ['RED_FACTS']
    ret = cls.run(terms)
    assert ret[0] == '#FF0000'

    # test DEFAULT_ROLES_PATH
    terms = ['DEFAULT_ROLES_PATH']
    ret = cls.run(terms)
    assert ret[0] == '/etc/ansible/roles:/usr/share/ansible/roles'

    # test COLOR_*

# Generated at 2022-06-21 05:48:56.228902
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-21 05:49:03.148979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of the LookupModule
    l = LookupModule()

    # Setup mocks for the run method
    l.set_options = MagicMock()
    l.get_option = MagicMock()

    l.get_option.return_value = 'error'

    # Test when plugin_type and plugin_name is provided
    l.get_option.side_effect = [None, "become", "sudo"]
    assert l.run(terms=["DEFAULT_BECOME_USER"], variables=None, **None) == []

    # Test when plugin_type and plugin_name is not provided
    l.get_option.side_effect = [None, None, None]
    assert l.run(terms=["DEFAULT_BECOME_USER"], variables=None, **None) == []

    # Test when plugin

# Generated at 2022-06-21 05:49:13.564550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.constants.DEFAULT_ROLES_PATH will be changed to 'role_path'
    # in Ansible 2.8, see https://github.com/ansible/ansible/pull/40956
    # We need to use C.DEFAULT_ROLES_PATH here to pass unit test.
    test_lookup = LookupModule()
    test_lookup._display.warning = lambda x: None
    terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_HOST_LIST']
    assert test_lookup.run(terms) == [C.DEFAULT_ROLES_PATH, []]
    assert test_lookup.run(terms, on_missing='warn') == [C.DEFAULT_ROLES_PATH, []]

# Generated at 2022-06-21 05:49:16.646436
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    instance = MissingSetting()
    assert instance.msg_path == u''
    assert instance.obj == None
    assert isinstance(instance, AnsibleOptionsError)

# Generated at 2022-06-21 05:49:18.502216
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_instance = MissingSetting('error', 'test')
    assert hasattr(test_instance, 'orig_exc')

# Generated at 2022-06-21 05:49:31.230363
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins import lookup_loader
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    import os
    import sys

    lookup_loader.set_available_lookups(set(['config']))

    os.environ['ANSIBLE_CONFIG'] = 'tests/testconfig.cfg'

    sys.path.insert(0, os.path.join(os.getcwd(), 'lookup_plugins'))

    test_lookup_module = lookup_loader.get('config', class_only=True)


# Generated at 2022-06-21 05:51:23.646240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    # check type
    assert type(L) is LookupModule 
    # check return_value
    assert L.run([]) == []

# Generated at 2022-06-21 05:51:30.805040
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:51:32.615838
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test message", orig_exc=None)
    except MissingSetting as e:
        assert "test message" == e.message
        assert e.orig_exc is None

# Generated at 2022-06-21 05:51:34.199464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()

# Generated at 2022-06-21 05:51:37.368137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(['hostfile'])
    assert result == ['/etc/ansible/hosts']

# Generated at 2022-06-21 05:51:39.316608
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:51:41.955739
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('foo')
    assert 'foo' in str(exc)
    assert exc.orig_exc is None

# Generated at 2022-06-21 05:51:43.451091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 05:51:51.782499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pkg_mgr = plugin_loader.package_mgr

    # test missing parameter 'terms'.
    def test_missing_terms():
        lookup = LookupModule()
        assert_raises_specific(AnsibleLookupError, 'missing required arguments: terms', lookup.run)

    # test for empty parameter 'terms'.
    def test_empty_terms():
        lookup = LookupModule()
        assert_raises_specific(AnsibleOptionsError, 'missing required arguments: terms', lookup.run, [])

    # test for invalid 'terms' value.
    def test_invalid_terms():
        lookup = LookupModule()
        assert_raises_specific(AnsibleOptionsError, 'Invalid setting identifier, "123" is not a string, its a ',
                               lookup.run, [123])

    # test for invalid

# Generated at 2022-06-21 05:51:56.764870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule(sentinel.loader, sentinel.templar, sentinel.shared_loader_obj)
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False
