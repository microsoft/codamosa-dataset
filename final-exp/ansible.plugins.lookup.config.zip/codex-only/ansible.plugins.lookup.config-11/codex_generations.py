

# Generated at 2022-06-23 11:18:14.717258
# Unit test for constructor of class LookupModule
def test_LookupModule():
    host_list = ['localhost', '192.168.220.128']
    t = LookupModule()
    assert t._templates == {}
    assert t._display.verbosity == 0
    assert t._host is None
    assert t._hosts is host_list

# Generated at 2022-06-23 11:18:24.177000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    basedir = os.path.dirname(__file__)
    test_data = os.path.join(basedir, 'test.yml')

    # Pick a simple configuration value
    results = LookupModule().run([
        'LIBRARY_PATH',  # Standard setting
        'DEFAULT_MODULE_NAME',  # Setting defined in the configuration file, not in code
        'THIS_IS_NOT_A_SETTING',  # Invalid setting
    ])
    assert results == ['/usr/share/ansible', 'raw', None]

    # test configuration variables that do not exist.
    results = LookupModule().run(['THIS_IS_NOT_A_SETTING'])
    assert results == [None]

    # test on_missing=fail, on_missing=skip, on_missing=warn
    results = Lookup

# Generated at 2022-06-23 11:18:24.969256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ansible_config_module = LookupModule()

# Generated at 2022-06-23 11:18:26.303395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-23 11:18:35.417628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global LookupBase 
    LookupBase = object
    L = LookupModule()
    # global C
    C = object
    
    # case 1:
    try:
        L.run(['foo'], {'plugin_type': 'foo'})
    except(AnsibleOptionsError):
        #print('pass!')
        pass
    else:
        exception_message = 'fail to raise AnsibleOptionsError if plugin_type and plugin_name is not both set!'
        raise Exception(exception_message)

    # case 2:
    try:
        L.run(['foo'], {'on_missing': 'bar'})
    except(AnsibleOptionsError):
        #print('pass!')
        pass

# Generated at 2022-06-23 11:18:40.122919
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_msg = 'test error message'
    orig_exc = AnsibleError('test original exception')
    try:
        raise MissingSetting(error_msg, orig_exc=orig_exc)
    except MissingSetting as e:
        assert error_msg == str(e)
        assert orig_exc == e.orig_exc

# Generated at 2022-06-23 11:18:40.879174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 11:18:48.847966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = dict()
    # case 1: plugin_name and plugin_type is set
    lookup = LookupModule()
    terms = ['DEFAULT_REMOTE_TMP', 'DEFAULT_REMOTE_USER']
    print(lookup.run(terms, variables, plugin_name='ssh', plugin_type='connection'))
    # case 2: plugin_name and plugin_type is not set
    lookup = LookupModule()
    terms = ['DEFAULT_REMOTE_TMP', 'DEFAULT_REMOTE_USER']
    print(lookup.run(terms, variables))
    # case 3: missing is skip
    lookup = LookupModule()
    terms = ['DEFAULT_REMOTE_TMP', 'DEFAULT_REMOTE_USER', 'UNKNOWN_DEFAULT_REMOTE_USER']

# Generated at 2022-06-23 11:18:58.735297
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Data
    loader = DataLoader()
    def _lookup_plugin(name, **kwargs):
        class TestLookupModule(object):
            name = name
            def run(self, terms, **kwargs):
                return terms
        return TestLookupModule()
    loader.set_basedir("/foo/bar")
    pc = PlayContext()
    # Test
    e = AnsibleError()
    m = MissingSetting("msg", orig_exc=e)
    # Assertions
    assert isinstance(m, AnsibleOptionsError)
    assert m.message == to_

# Generated at 2022-06-23 11:19:08.662614
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test correct parametrization of constructor, with some optional parameters
    a = MissingSetting('test_message', 'test_orig_exception', 'test_source_file', 'test_line_number', loader)

    # Verify that the values were correctly entered, and are accessible via the getters
    assert a.message == 'test_message'
    assert a.orig_exc == 'test_orig_exception'
    assert a.source_file == 'test_source_file'
    assert a.line_number == 'test_line_number'
    assert a.data_loader == loader

# Generated at 2022-06-23 11:19:10.051454
# Unit test for constructor of class LookupModule
def test_LookupModule():
    p = LookupModule()
    assert hasattr(p, 'run')

# Generated at 2022-06-23 11:19:13.404923
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Unable to locate valid 'lmao' setting in configuration file."
    e = AnsibleOptionsError(msg)
    v = MissingSetting(msg, e)
    assert v.options_vars == {'orig_exc':e}

# Generated at 2022-06-23 11:19:16.129884
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "message"
    try:
        raise MissingSetting(msg)
    except AnsibleOptionsError as e:
        assert e.args[0] == msg

# Generated at 2022-06-23 11:19:17.478299
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('test message')
    assert exc.message == 'test message'

# Generated at 2022-06-23 11:19:18.724541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    test_object.run([])

# Generated at 2022-06-23 11:19:26.214607
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types

    msg = to_native('Error Loading Lplugin')
    orig_exc = 'Something went wrong'

    with pytest.raises(AnsibleOptionsError) as exc:
        raise MissingSetting(msg, orig_exc)

    assert msg in str(exc)
    assert 'Something went wrong' in str(exc)


# Generated at 2022-06-23 11:19:28.034344
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule()

# Generated at 2022-06-23 11:19:32.330682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # module = LookupModule()
    # terms = ["DEFAULT_ROLES_PATH"]
    # result = module.run(terms, variables=None, **{'on_missing':'skip'})
    # print(result)
    assert True

# Generated at 2022-06-23 11:19:36.629458
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # MissingSetting exception is expected from the given config setting
    exception = MissingSetting('exception', orig_exc=Exception('orig_exc'))
    assert exception.exception == 'exception'
    assert exception.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:19:47.527221
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

    # on_missing is validated
    try:
        lookup.run(terms=['test'], on_missing='bad value')
        assert False, 'Expected AnsibleOptionsError'
    except AnsibleOptionsError as e:
        assert 'invalid value' in to_native(e)

    # plugin_type is validated
    try:
        lookup.run(terms=['test'], plugin_type='bad value')
        assert False, 'Expected AnsibleOptionsError'
    except AnsibleOptionsError as e:
        assert 'invalid value' in to_native(e)

    # plugin_name requires plugin_type

# Generated at 2022-06-23 11:19:52.207039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import pytest

    # Test if exception is raised when both plugin_type and plugin_name are defined or not.
    with pytest.raises(AnsibleOptionsError) as execinfo:
        LookupModule(None, dict(), dict(), dict(), dict())
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(execinfo.value)

    # Test if exception is raised when plugin_type or plugin_name is not a string.
    with pytest.raises(AnsibleOptionsError) as execinfo:
        LookupModule(None, dict(plugin_type=None), dict(), dict(), dict())
    assert "Invalid setting identifier, 'plugin_type' is not a string" in str(execinfo.value)

    # Test if exception is raised when on_missing

# Generated at 2022-06-23 11:19:53.104046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert isinstance(result, LookupModule)

# Generated at 2022-06-23 11:19:54.030024
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:19:55.483175
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting('foo')
    assert str(err) == 'foo'

# Generated at 2022-06-23 11:19:59.915115
# Unit test for constructor of class LookupModule
def test_LookupModule():
	terms = ('foo', 'bar')
	variables={'c':'d'}
	kwargs={'e':'f'}
	
	ret_expected=[['foo','bar']]
	
	lk = LookupModule()
	ret = lk.run(terms, variables, **kwargs)
	assert (ret == ret_expected)
	print("Passed test_LookupModule")
	
if __name__ == "__main__":
	test_LookupModule()

# Generated at 2022-06-23 11:20:11.998730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class C:
        def __init__(self):
            self.verbosity = 5
            self.DEFAULT_UNIX_TMP_PATH = '/tmp/ansible'

    c = C()
    lm = LookupModule()

    # test on missing setting
    lm.set_options(var_options={}, direct={'on_missing': 'skip'})
    ret = lm.run(['UNKNOWN_SETTING'])
    assert not ret

    # test on missing setting
    lm.set_options(var_options={}, direct={'on_missing': 'error'})
    try:
        ret = lm.run(['UNKNOWN_SETTING'])
        assert False  # should have thrown an exception
    except AnsibleLookupError:
        pass

    # test valid setting
    lm.set

# Generated at 2022-06-23 11:20:13.854044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:20:15.364661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:20:18.717294
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError

    print(MissingSetting)
    try:
        raise MissingSetting
    except Exception:
        print("exception raised")
    try:
        raise AnsibleOptionsError
    except Exception:
        print("wrong exception raised!")


# Generated at 2022-06-23 11:20:20.541399
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
  try:
    raise MissingSetting("test exception")
  except MissingSetting:
    pass

# Generated at 2022-06-23 11:20:28.515799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Module needs to be referenced by its absolute path
    module = __import__('ansible.plugins.lookup.config', fromlist=['LookupModule'])
    lookup_module = module.LookupModule()
    term = 'DEFAULT_BECOME_USER'
    result = lookup_module.run(terms=term, on_missing='error')
    result2 = lookup_module.run(terms=[term], on_missing='error')
    if isinstance(result, str):
        result = [result]
    assert result == result2 == ['root']

    result = lookup_module.run(terms=[term], on_missing='warn')
    result2 = lookup_module.run(terms=[term], on_missing='skip')
    assert result == result2 == []


# Generated at 2022-06-23 11:20:30.287465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    assert isinstance(c, LookupModule)

# Generated at 2022-06-23 11:20:30.914415
# Unit test for constructor of class MissingSetting

# Generated at 2022-06-23 11:20:40.213910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.lookup import LookupBase

    lookup = LookupModule()
    lookup._loader = mock.MagicMock()
    lookup._templar = mock.MagicMock()
    lookup._display = mock.MagicMock()
    lookup._display.warning = mock.MagicMock()
    lookup.set_options = mock.MagicMock()
    lookup.get_option = mock.MagicMock()
    lookup.get_option.return_value = 'error'
    #lookup.get_option.return_value = ''

    #test invalid on_missing option
    terms = ['invalid_option']

# Generated at 2022-06-23 11:20:45.559219
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = None
    try:
        raise MissingSetting('Unable to find setting UNKNOWN')
    except Exception as e:
        exc = e
    assert isinstance(exc, MissingSetting)
    assert exc.orig_exc is None
    assert exc.msg == 'Unable to find setting UNKNOWN'


# Generated at 2022-06-23 11:20:55.766574
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()

    def test_run(terms, variables, **kwargs):
        return lookup_module.run(terms=terms, variables=variables, **kwargs)

    # Uncomment this test for debugging
    #import pdb; pdb.set_trace()

    # Test basic functionality
    result = test_run(['DEFAULT_HOST_LIST'], variables={}, on_missing='error')
    assert result == [['/etc/ansible/hosts']]

    # Test with multiple terms
    result = test_run(['DEFAULT_HOST_LIST', 'DEFAULT_REMOTE_TMP'], variables={}, on_missing='error')
    assert result == [['/etc/ansible/hosts', '$HOME/.ansible/tmp']]

    # Test with a list as a term
   

# Generated at 2022-06-23 11:21:04.630264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert type(lookup.run(terms=["DEFAULT_BECOME_USER"])) == list
    assert type(lookup.run(terms=["DEFAULT_ROLES_PATH"])) == list
    assert type(lookup.run(terms=["RETRY_FILES_SAVE_PATH"])) == list
    assert type(lookup.run(terms=["COLOR_OK", "COLOR_CHANGED"], wantlist=True)) == list
    assert type(lookup.run(terms=["UNKNOWN"], on_missing="skip")) == list


# Generated at 2022-06-23 11:21:13.575022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.constants as C
    import ansible.module_utils.six as six

    C.HOST_KEY_CHECKING = False
    C.DEFAULT_HASH_BEHAVIOUR = 'replace'
    C.DEFAULT_PRIVATE_ROLE_VARS = False
    C.DEFAULT_ROLES_PATH = ['/path/to/roles', '/other/path/to/roles']
    C.DEFAULT_ROLES_LOOKUP = True
    C.DEFAULT_ROLES_REQUIREMENT_WHITELIST = [u'^[\w-]+$']
    C.DEFAULT_SUDO_PASS = 'not a secret'
    C.DEFAULT_SUDO_EXE = '/bin/sudo'
    C.DEFAULT_SUDO_FLAG

# Generated at 2022-06-23 11:21:15.842998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert 'success' == lookup_module.run(['DEFAULT_NETWORK_OS'])[0]

# Generated at 2022-06-23 11:21:21.517108
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('some_msg')
    assert e.orig_exc is None
    assert e.args == ('some_msg',)

    e = MissingSetting('some_msg', 'original_exc')
    assert e.orig_exc == 'original_exc'
    assert e.args == ('some_msg', 'original_exc')

# Generated at 2022-06-23 11:21:22.501498
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 11:21:30.926643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run() with a specific Ansible configuration setting
    assert LookupModule().run(['DEFAULT_BECOME_USER']) == ['root']

    # Test run() with a non-existent Ansible configuration setting
    try:
        assert LookupModule().run(['UNKNOWN_SETTING'])
    except AnsibleLookupError as e:
        assert to_native(e) == 'Unable to find setting UNKNOWN_SETTING'

    # Test run() with Ansible configuration settings that are not strings
    try:
        assert LookupModule().run(['CONFIGURABLE_TIMEOUT'])
    except AnsibleLookupError as e:
        assert to_native(e) == 'Invalid setting identifier, "CONFIGURABLE_TIMEOUT" is not a string, its a <class \'int\'>'

    # Test run() with

# Generated at 2022-06-23 11:21:37.599327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
            'DEFAULT_BECOME_USER',
            'DEFAULT_ROLES_PATH',
            'COLOR_OK',
            'COLOR_CHANGED',
            'COLOR_SKIP',
            'RETRY_FILES_SAVE_PATH'
        ]
    kwargs = {'wantlist': True, 'on_missing': 'skip'}

    obj = LookupModule()
    result = obj.run(terms, None, **kwargs)
    print(result)

# Generated at 2022-06-23 11:21:42.305325
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test constructor of class LookupModule
    lm = LookupModule()

    # Test run method of class LookupModule
    lm.run(terms=["lookup_plugin_counter"],
           variables=["lookup_plugin_counter"])

# Generated at 2022-06-23 11:21:44.281330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_test = LookupModule()
    assert lookup_test.run(['DEFAULT_CACHE_PLUGIN']) == ['memory']
    assert lookup_test.run(['NON_EXISTING'], on_missing='error') == []

# Generated at 2022-06-23 11:21:46.162743
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('This is a test')
    assert m.__str__() == 'This is a test'

# Generated at 2022-06-23 11:21:57.547204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:22:06.420625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule
    """
    # create the test LookupModule class
    lookup_module = LookupModule()
    # get the result of method run of the class
    result = lookup_module.run(terms=['DEFAULT_ROLES_PATH', 'HOST_KEY_CHECKING'],
                               variables={'test_var': 'test_value'},
                               on_missing='warn')

    # test if the result is of same type as expected
    assert isinstance(result, list), "The result should be a list"

# Generated at 2022-06-23 11:22:07.464189
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('missing setting message')
    assert m.message == 'missing setting message'

# Generated at 2022-06-23 11:22:17.543002
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.message == 'test'
        assert not hasattr(e, 'orig_exc')
        assert e.orig_exc is None

    # Test constructor with orig_exc argument
    try:
        class Exc(Exception):
            pass
        remote_exc = ValueError('example')
        raise MissingSetting('test', orig_exc=remote_exc)
    except MissingSetting as e:
        assert e.message == 'test'
        assert e.orig_exc is remote_exc

    # Test constructor with orig_exc argument and not Exception type
    try:
        class Exc(Exception):
            pass
        raise MissingSetting('test', orig_exc=1)
    except MissingSetting as e:
        assert e.message == 'test'

# Generated at 2022-06-23 11:22:18.562009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance is not None

# Generated at 2022-06-23 11:22:27.640041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    module = LookupModule()
    result = module.run(['DEFAULT_BECOME_METHOD'],wantlist=True)
    assert result[0] == 'sudo' or result[0] == 'su' or result[0] == 'pbrun' or result[0] == 'pfexec' or result[0] == 'doas' or result[0] == 'dzdo' or result[0] == 'ksu' or result[0] == 'pmrun' or result[0] == 'runas'

# Generated at 2022-06-23 11:22:30.741689
# Unit test for constructor of class LookupModule
def test_LookupModule():
    args = dict(terms=['DEFAULT_ROLES_PATH'], variables=dict())
    lookup_plugin = LookupModule()
    lookup_plugin.run(**args)



# Generated at 2022-06-23 11:22:31.935807
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("test message",None)
    assert e.message == "test message"

# Generated at 2022-06-23 11:22:35.099099
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test message')
    print(e.args[0])
    assert e.args[0] == 'test message'

# Generated at 2022-06-23 11:22:45.334755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule

    def get_config_value_sentinel():
        raise AnsibleError('was not defined')

    def get_config_value_sentinel_sh():
        return

    # Mock C.COLOR_OK
    _mock_color_ok = Sentinel()
    setattr(C, 'COLOR_OK', _mock_color_ok)

    # Mock get_config_value(DEFAULT_ROLES_PATH)
    _mock_default_path = Sentinel()
    _mock_get_config_value = Sentinel()
    setattr(C, 'get_config_value', _mock_get_config_value)
    setattr(C.config, 'DEFAULT_ROLES_PATH', _mock_default_path)

    # Mock C.RETRY

# Generated at 2022-06-23 11:22:47.627508
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('Message', orig_exc="Exception")
    assert 'Message' in str(e)
    assert 'Exception' in str(e)

# Generated at 2022-06-23 11:22:51.291758
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'The value of UNKNOWN_OPTION is not defined in configuration file.'
    exception = MissingSetting(msg)
    assert exception.message == msg
    assert exception.orig_exc is None

# Generated at 2022-06-23 11:22:53.182755
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupBase)

# Generated at 2022-06-23 11:22:56.047451
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    try:
        raise MissingSetting()
    except AnsibleOptionsError:
        pass


if __name__ == '__main__':
    test_MissingSetting()

# Generated at 2022-06-23 11:23:06.760175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check valid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    options = {
        'plugin_type': 'httpapi',
        'plugin_name': 'curl',
    }
    # Check valid plugin_type and plugin_name
    lookup_plugin.set_options(var_options=None, direct=options)
    # Check invalid plugin_type and plugin_name
    options = {
        'plugin_type': 'httpapi',
    }
    try:
        lookup_plugin.set_options(var_options=None, direct=options)
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required' in e.args[0]

# Generated at 2022-06-23 11:23:13.030841
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError

    test_msg = 'this is a test'
    test_exc = AnsibleOptionsError(test_msg)
    test_obj = MissingSetting(test_msg, orig_exc=test_exc)

    assert(test_msg in test_obj.message)
    assert(test_exc == test_obj.orig_exc)

# Generated at 2022-06-23 11:23:19.874323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global C
    C = type("obj",(object,),{'DEFAULT_BECOME_USER':'root','DEFAULT_ROLES_PATH':'common/roles'})
    import os,sys
    MODULE_PATH = os.path.dirname(os.path.realpath(__file__))
    module = MODULE_PATH + '/../../lookup_plugins/config.py'
    modulepath = MODULE_PATH + '/../../lookup_plugins'
    sys.path.insert(1, modulepath)
    from config import LookupModule
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    #Asserting the values returned by method

# Generated at 2022-06-23 11:23:30.160188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    validate that run method of LookupModule class
    """
    import json
    import sys
    import os
    import pytest
    plugin_class = getattr(
            __import__('ansible.plugins.lookup.config',
                       fromlist=['LookupModule']),
            'LookupModule')

    # Using real ansible config
    main_dir = os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

    C.config.settings_dirs = [os.path.join(main_dir, 'test/unit/utils/test_data/ansible.cfg')]
    # Resetting the lookup plugins to load real ones
    plugin_loader.lookup

# Generated at 2022-06-23 11:23:42.303434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    l = LookupModule()
    l._display = MockDisplay()

    #Plugin name and type given
    opts = {'plugin_name': 'ssh', 'plugin_type': 'connection'}
    terms = ('remote_user', 'port')
    ans = {'remote_user': 'joe', 'port': 22}
    assert l.run(terms, variables={}, **opts) == [ans['remote_user'], ans['port']]

    #Plugin name or type not given or both missing
    opts = {}
    terms = ('remote_user', 'port')
    with pytest.raises(AnsibleOptionsError) as execinfo:
        l.run(terms, variables={}, **opts)
    #Unable to find

# Generated at 2022-06-23 11:23:46.664390
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [ 'DEFAULT_REMOTE_USER' ]
    var_options = 'DEFAULT_REMOTE_USER'
    direct = True
    lookup_instance = LookupModule()
    lookup_instance.set_options(var_options=var_options, direct=direct)
    result = lookup_instance.run(terms, variables=var_options, direct=direct)
    assert result == ['root']


# Generated at 2022-06-23 11:23:48.406135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()



# Generated at 2022-06-23 11:23:49.807026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:23:54.152075
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting("Message")
    assert exc.message == "Message"
    assert exc.orig_exc is None

    exc1 = RuntimeError("Something bad happened")
    exc = MissingSetting("Message", orig_exc=exc1)
    assert exc.message == "Message"
    assert exc.orig_exc == exc1

# Generated at 2022-06-23 11:23:58.231906
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "MissingSetting(msg, orig_exc=None)"
    try:
        raise MissingSetting(msg, orig_exc=None)
    except MissingSetting as e:
        assert e.orig_exc is None and e.msg == msg

# Generated at 2022-06-23 11:24:03.368613
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Additional optional argument is used in Ansible 2.7 - 2.12 to
    # preserve original exception in error message.
    # In Ansible 2.13 this argument has been renamed
    # to make it compatible with Python 3.
    try:
        raise MissingSetting("missing setting", orig_exc=Exception("this is called original exception"))
    except MissingSetting as e:
        assert e.orig_exc.args[0] == "this is called original exception"

# Generated at 2022-06-23 11:24:05.289444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiation of class LookupModule
    um = LookupModule()
    return True

# Generated at 2022-06-23 11:24:06.905903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([])
    assert result == []

# Generated at 2022-06-23 11:24:16.633896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import json
    import yaml
    from ansible.module_utils._text import to_text
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    #This is needed for the exception handling to work
    sys.modules['ansible'] = type('FakeAnsibleModule', (), {})()
    sys.modules['ansible.module_utils'] = type('FakeAnsibleModuleUtils', (), {})()

    basic._ANSIBLE_ARGS = None
    arguments = {}
    #This is needed for the exception handling to work
    sys.modules['ansible.module_utils.basic'] = type('FakeAnsibleModuleUtilsBasic', (), arguments)()

   

# Generated at 2022-06-23 11:24:18.446290
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting:
        assert True
    else:
        assert False

# Generated at 2022-06-23 11:24:28.390510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import vars_loader
    t = LookupModule()
    t.set_options(direct={'plugin_type': 'vars', 'plugin_name': 'vault'})
    assert t.get_option('plugin_type') == 'vars'
    assert t.get_option('plugin_name') == 'vault'
    vault_secret = "vault_secret"
    assert t.run([vault_secret])[0] == vars_loader.get('vault').get_vault_secret(None)
    assert isinstance(t.run([vault_secret])[0], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 11:24:29.995780
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('message')

# Generated at 2022-06-23 11:24:40.709648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    #
    # Verify that a missing setting throws a AnsibleLookupError
    #
    try:
        lookup.run(terms=["UNKNOWN_SETTING_1"], variables=None, on_missing="error")
        assert False
    except AnsibleLookupError:
        pass

    #
    # Verify that a missing setting with on-missing = 'warn' issues a warning and returns empty string
    #
    ret = lookup.run(terms=["UNKNOWN_SETTING_2"], variables=None, on_missing="warn")
    assert len(ret) == 0

    #
    # Verify that a missing setting with on-missing = 'skip' returns empty string
    #
    ret = lookup.run(terms=["UNKNOWN_SETTING_3"], variables=None, on_missing="skip")

# Generated at 2022-06-23 11:24:50.994857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['DEFAULT_REMOTE_TMP']
    ret = module.run(terms)
    assert len(ret) == 1
    assert ret[0] == '~/.ansible/tmp'

    #use a plugin name and type
    terms = ['accelerate', 'fork', 'accelerate_timeout', 'timeout', 'accelerate_connect_timeout', 'connect_timeout']
    ret = module.run(terms, plugin_type='connection', plugin_name='accelerate')
    assert len(ret) == 3
    assert ret[0] == 10
    assert ret[1] == 30
    assert ret[2] == 0.3
    #use an unknown plugin name and type
    ret = module.run(terms, plugin_type='connection', plugin_name='beehive')
   

# Generated at 2022-06-23 11:24:54.203904
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_obj = LookupModule()
    assert isinstance(lookup_module_obj, LookupModule)

# Generated at 2022-06-23 11:25:05.089062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class AnsibleOptionsErrorStub(Exception):
        pass

    class AnsibleOptionsErrorStub2(Exception):
        pass

    class AnsibleOptionsErrorStub3(Exception):
        pass

    class MissingSettingStub(Exception):
        pass

    class MissingSettingStub2(Exception):
        pass

    class MissingSettingStub3(Exception):
        pass

    class MissingSettingStub4(Exception):
        pass

    class AnsibleLookupErrorStub(Exception):
        pass

    class AnsibleLookupErrorStub2(Exception):
        pass

    class AnsibleLookupErrorStub3(Exception):
        pass

    class CStub:
        DEFAULT_BECOME_USER = "user"
        DEFAULT_ROLES_PATH = "/path/to/roles"
        RETRY_FILES_

# Generated at 2022-06-23 11:25:06.147735
# Unit test for constructor of class LookupModule
def test_LookupModule():
  result = LookupModule()

# Generated at 2022-06-23 11:25:07.974625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:25:09.698771
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('test')

# Generated at 2022-06-23 11:25:12.762873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms, variables, kwargs = [{'a': 0, 'b': 1}], {'a': 0, 'b': 1}, {'a': 0, 'b': 1}
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-23 11:25:15.940003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    result = lookup_module.run(terms,variables=None, **{'on_missing':'error'})
    assert(result == [[]], 'LookupModule.run() failed to return list value' )

# Generated at 2022-06-23 11:25:26.623994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = {'a': 1}
    lookup = LookupModule()
    lookup.set_options(var_options=data)
    assert lookup.run([]) == []
    assert lookup.run(['a']) == [1]
    assert lookup.run(['a', 'b', 'c']) == [1]
    assert lookup.run(['a', 'b', 'c'], on_missing='warn') == [1]
    assert lookup.run(['a', 'b', 'c'], on_missing='error') == [1]
    assert lookup.run(['a', 'b', 'c'], on_missing='skip') == [1]

    assert lookup.run(['a'], plugin_type='shell') == [1]

# Generated at 2022-06-23 11:25:27.603543
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    raise MissingSetting("Setting is missing")

# Generated at 2022-06-23 11:25:38.393516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    # Simple test cases
    # Positive test cases
    # For DEFAULT_ROLES_PATH
    terms = ["DEFAULT_ROLES_PATH"]
    result = LookupModule().run(terms, variables=None, **{})
    assert result[0] == ['/home/engineer/roles']

    # For COLOR_OK
    terms = ["COLOR_OK"]
    result = LookupModule().run(terms, variables=None, **{})
    assert result[0] == 'green'

    # For COLOR_CHANGED
    terms = ["COLOR_CHANGED"]
    result = LookupModule().run(terms, variables=None, **{})
    assert result[0] == 'yellow'

    # For COLOR_SKIP
   

# Generated at 2022-06-23 11:25:48.118471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test to test method run of class LookupModule
    loader = plugin_loader.get(class_only=True)
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(loader)

    # Scenario 1 - Positive case
    # Test lookup for a setting which exists
    # Expected result - should return a list with 1 element
    # Actual result - returned a list with 1 element
    assert lookup_plugin.run(["DEFAULT_BECOME_USER"]) == [C.DEFAULT_BECOME_USER]

    # Scenario 2 - Positive case
    # Test lookup for multiple settings which exist
    # Expected result - should return a list containing setting values
    # Actual result - returned a list containing setting values

# Generated at 2022-06-23 11:25:54.777063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test terms:
        # a string terminology
        # a non-string terminology
        # null
    # test missing:
        # error
        # warn
        # skip
    # test ptype:
        # valid
        # non-valid
    # test pname:
        # null
        # valid
        # non-valid
    return

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:25:55.822857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-23 11:25:59.193162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert len(lookup_instance.get_options()) == 0
    assert len(lookup_instance.run(['DEFAULT_BECOME_USER'], {})) == 1

# Generated at 2022-06-23 11:26:02.324193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create instance of LookupModule
    l = LookupModule()
    # Check if the __init__ method of LookupModule can be called and does not raise any errors
    assert l is not None

# Generated at 2022-06-23 11:26:07.699255
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import context
    from ansible.context import CLIContext


# Generated at 2022-06-23 11:26:09.296869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dictionary = {}

    lookup = LookupModule()
    lookup.run(terms = dictionary, variables = None, **dictionary)

# Generated at 2022-06-23 11:26:19.075757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = lookup_plugins.get('config')
    lookup_obj.set_options(var_options={})
    assert lookup_obj.run([]) == []  # lookup should return an empty list if nothing defined
    assert lookup_obj.run(['DEFAULT_ROLES_PATH'])[0] == ['/etc/ansible/roles', '/usr/share/ansible/roles']  # '[]' around result means it is a list
    assert lookup_obj.run(['DEFAULT_ROLES_PATH'])[1] == None
    assert lookup_obj.run(['DEFAULT_ROLES_PATH', 'UNKNOWN'])[0] == ['/etc/ansible/roles', '/usr/share/ansible/roles']

# Generated at 2022-06-23 11:26:22.111356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with config string as parameter
    look = LookupModule()
    assert(look)
    # Test with a list of config strings as parameters
    look = LookupModule()
    assert(look)


# Generated at 2022-06-23 11:26:30.354366
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # pylint: disable=protected-access
    with MissingSetting(msg="Message") as exc:
        assert isinstance(exc, AnsibleError)
        assert exc.orig_exc is None
        assert exc.args[0] == "Message"
        assert exc._in_template is False
        assert exc._in_deprecated is False
        assert exc._in_plugin is False
    # Pass original exception
    orig_exc = Exception("Original exception")
    with MissingSetting(msg="Message", orig_exc=orig_exc) as exc:
        assert exc.orig_exc == orig_exc

# Generated at 2022-06-23 11:26:34.174870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_ROLES_PATH'], {'playbook_dir': '.'}) == ['.']

# Generated at 2022-06-23 11:26:35.914605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:26:44.253891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.parsebool import boolean
    from ansible.utils.listify import expand_list_accumulator
    from ansible.module_utils.six import string_types
    import ansible.module_utils._text as t
    mod = LookupModule()

    mod.set_options({'var_options': '_ansible_all_vars'}, direct={'plugin_name': 'ssh', 'plugin_type': 'connection', 'on_missing': 'skip'})
    assert mod._templar is None
    assert mod._loader is None
    assert mod._basedir is None
    assert mod._connection is None
    assert mod._play_context is None
    assert mod._task is None
    assert mod._plugin_name == 'ssh'
    assert mod._plugin_type == 'connection'
    assert mod._

# Generated at 2022-06-23 11:26:51.981956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' unit test for lookup_plugin.LookupModule class'''
    print('')
    print('unit test for lookup_plugin.LookupModule class')

    LookupModule.Options = {var_options: None, direct: None}
    LookupModule.Variables = {var_options: None}
    LookupModule.set_options = {self: LookupModule, var_options: None, direct: None}
    LookupModule.lookup_data = {self: LookupModule, terms: None, variables: None, inject: None}
    LookupModule.run = {self: LookupModule, terms: None, variables: None, inject: None, **kwargs}

    return

# Generated at 2022-06-23 11:26:55.051363
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except AnsibleOptionsError as e:
        assert e.message == 'test'
        assert e.orig_exc is None

# Generated at 2022-06-23 11:26:59.199184
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Something bad"
    tb = '<traceback object at 0x1018f18c0>'
    ms = MissingSetting(msg, tb)
    assert ms.msg == msg
    assert isinstance(ms.orig_tb, str)
    assert isinstance(ms.orig_exc, str)

# Generated at 2022-06-23 11:27:04.755852
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('A test exception', 'foo')
    except MissingSetting as e:
        # Check we captured the string
        assert e.message == 'A test exception', 'Failed to capture the message'
        # Check we captured the original exception
        assert e.orig_exc == 'foo', 'Failed to capture the original exception'

# Generated at 2022-06-23 11:27:15.283055
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_config = {
        'plugin_type': 'shell',
        'plugin_name': 'sh',
        'on_missing': 'error'
    }
    lm = LookupModule(None, test_config, None, None)
    assert lm.get_option('plugin_type') == 'shell'
    assert lm.get_option('plugin_name') == 'sh'
    assert lm.get_option('on_missing') == 'error'
    # on_missing is set to a value in choices, so no error will be raised
    lm.set_options(var_options=None, direct={'on_missing': 'skip'})
    assert lm.get_option('on_missing') == 'skip'
    # on_missing is invalid, error will be raised

# Generated at 2022-06-23 11:27:21.060575
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("{}")
    except Exception as e:
        assert issubclass(type(e), AnsibleOptionsError)
        assert isinstance(e, MissingSetting)
        assert isinstance(e, AnsibleOptionsError)
        assert 'Ansible options error detected' in e.message
    else:
        assert False, "Exception not raised"

# Generated at 2022-06-23 11:27:23.437115
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lmp = LookupModule()
    assert isinstance(lmp, LookupModule)


# Generated at 2022-06-23 11:27:31.956717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class FixupThingy(object):
        def __getattr__(self, name):
            return None

    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert not hasattr(lookup_module, '_templar')
    lookup_module._templar = FixupThingy()
    assert isinstance(lookup_module._templar, FixupThingy)
    assert not hasattr(lookup_module, '_display')
    lookup_module._display = FixupThingy()
    assert isinstance(lookup_module._display, FixupThingy)
    assert not hasattr(lookup_module, '_loader')
    lookup_module._loader = FixupThingy()

# Generated at 2022-06-23 11:27:43.382511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import PY3

    pm = LookupModule(sentinel=None, loader=lookup_loader, templar=sentinel, shared_loader_obj=sentinel)

    pm.set_options(var_options={'ansible_ssh_common_args': '-o ProxyCommand="ssh -W %h:%p -o StrictHostKeyChecking=no localhost -p 1234"'})
    assert '-o ProxyCommand="ssh -W %h:%p -o StrictHostKeyChecking=no localhost -p 1234"' == pm.run(["ansible_ssh_common_args"], tokenize=False)[0]


# Generated at 2022-06-23 11:27:49.149072
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Unit test for constructor of class MissingSetting"""
    from ansible.errors import AnsibleLookupError
    with pytest.raises(Exception):
        raise MissingSetting("test Exception")
    with pytest.raises(AnsibleLookupError):
        raise MissingSetting("test AnsibleLookupError")

# Generated at 2022-06-23 11:27:50.959935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-23 11:27:53.599914
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('dummy for testing')
    except MissingSetting as e:
        assert str(e) == 'dummy for testing'

# Generated at 2022-06-23 11:27:56.332771
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(MissingSetting) as excinfo:
        MissingSetting('The setting %s is missing!')
        excinfo.match('The setting %s is missing!')

# Generated at 2022-06-23 11:27:57.720506
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting
    except MissingSetting as dummy:
        pass

# Generated at 2022-06-23 11:28:04.282429
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting(msg="test-message")
    # Test __str__ to ensure it returns a string
    assert isinstance(str(exception), string_types)
    # Test __repr__ to ensure it returns a string
    assert isinstance(repr(exception), string_types)
    # Test __unicode__ if python3
    try:
        unicode(exception)
    except NameError:
        pass
    # Test __unicode__ if python2
    except AttributeError:
        pass
    assert exception.orig_exc is None

# Generated at 2022-06-23 11:28:16.334954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase

    a = LookupBase()
    a.set_options(var_options=dict(ansible_verbosity='1'))

    assert a.get_option('verbosity') == '1'
    assert a.get_option('verbosity') == 1
    assert a.get_option('verbosity', default='5') == 1
    assert a.get_option('verbosity', default=5) == 1

    assert a.get_option('foo') is None
    assert a.get_option('foo', default='5') == '5'
    assert a.get_option('foo', default=5) == 5

    # Cvars are case insensitive
    assert a.get_option('VERBOSITY') == 1
    assert a