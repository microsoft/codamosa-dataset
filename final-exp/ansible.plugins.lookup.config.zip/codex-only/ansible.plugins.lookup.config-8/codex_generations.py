

# Generated at 2022-06-23 11:18:21.658026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import pytest
    term = 'term'
    variables = 'variables'
    assert(sys.getrefcount(term) == 1)
    lookup = LookupModule()
    assert(sys.getrefcount(term) == 2)
    lookup.set_options(var_options=variables, direct=dict())
    assert(sys.getrefcount(term) == 3)
    assert(lookup._display)
    with pytest.raises(AnsibleOptionsError):
        lookup.run(terms=term, variables=variables, on_missing='foo')
    assert(sys.getrefcount(term) == 3)
    with pytest.raises(AnsibleOptionsError):
        lookup.run(terms=term, variables=variables, on_missing='error', plugin_type='foo')
   

# Generated at 2022-06-23 11:18:23.417821
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert isinstance(MissingSetting('test'), AnsibleOptionsError)

# Generated at 2022-06-23 11:18:27.423262
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Arrange
    msg = "Ansible error message"
    orig_exc = AnsibleOptionsError("Some exception message", obj="Some object")

    # Act
    missing_setting = MissingSetting(msg, orig_exc=orig_exc)

    # Assert
    assert missing_setting.msg == msg
    assert missing_setting.orig_exc is orig_exc

# Generated at 2022-06-23 11:18:32.782375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a class object
    l = LookupModule()

    # Declaring parameter 'terms'
    terms = ['DEFAULT_BECOME_USER']

    # Declaring parameter 'variables'
    variables = {}

    # Declaring parameter 'wantlist'
    wantlist = True
    # Calling method run of LookupModule with parameters terms, variables and wantlist
    l.run(terms, variables, wantlist)



# Generated at 2022-06-23 11:18:40.610660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global_result = Sentinel
    cresult = Sentinel
    presult = Sentinel
    def _get_plugin_config(pname, ptype, config, variables):
        assert pname == 'name'
        assert ptype == 'ptype'
        assert config == 'config'
        assert variables == 'variables'
        return presult
    def _get_global_config(config):
        global global_result
        assert config == 'config'
        global_result = 'global'
        return global_result
    module = LookupModule()
    module._display = type('', (), {'warning': lambda self, msg: print(msg)})
    module.get_option = lambda x: 'value'
    module.set_options = lambda x, y: print(x)

# Generated at 2022-06-23 11:18:41.272957
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:18:41.900610
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:18:44.044511
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except AnsibleError as e:
        assert isinstance(e, MissingSetting)

# Generated at 2022-06-23 11:18:49.616775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(['DEFAULT_BECOME_USER'], dict(PLAYBOOK_DIR='/vagrant/playbook1', PLAY_SRC='/vagrant/hosts'))
    assert result == ['root'], "Unable to find setting DEFAULT_BECOME_USER"

# Generated at 2022-06-23 11:18:51.918372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-23 11:18:52.946476
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_x = LookupModule()
    pass

# Generated at 2022-06-23 11:18:53.905538
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting("test error message")

# Generated at 2022-06-23 11:18:55.266192
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test')
    assert m.message == 'test'

# Generated at 2022-06-23 11:18:57.810506
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    txt = 'Unable to load'
    msg = 'is not a string, its a'
    obj = MissingSetting(msg, txt)
    assert obj._orig_exc == txt
    assert obj.message == msg

# Generated at 2022-06-23 11:19:09.287118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.constants import DEFAULT_DEBUG
    from ansible.module_utils.six.moves import builtins

    # Setup class
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})

    # Setup global variable
    DEFAULT_DEBUG = True

    # Create a class that would map to the terminal debug output
    class display:

        def __init__(self):
            self.warning_count = 0
            self.deprecation_count = 0

        def debug(self, msg):
            print(msg)

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            print(msg)

        def vvv(self, msg):
            self.display(msg)


# Generated at 2022-06-23 11:19:10.915845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    assert(lookup_module.run(terms=['test']) == [])

# Generated at 2022-06-23 11:19:20.426483
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import ansible.plugins
    import tempfile

    # make sure the config file exists
    tempfile.mkstemp()

    defaults_body = {
        'DEFAULT_REMOTE_TMP': '$HOME/tmp',
        'DEFAULT_REMOTE_USER': 'root',
        'DEFAULT_PRIVATE_ROLE_VARS': True,
    }
    inventory_body = {
        'plugin': 'smart',
    }
    inventory = '{{"plugin":"smart"}}'
    defaults = {}
    for key in defaults_body:
        tmp_value = defaults_body[key]
        default_config = ansible.plugins.get_default_configfile_path()

# Generated at 2022-06-23 11:19:22.869817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert isinstance(test,LookupModule)


# Generated at 2022-06-23 11:19:25.010439
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('A test error message', None)
    except MissingSetting as ex:
        assert 'A test error message' in ex.message

# Generated at 2022-06-23 11:19:32.959604
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock out constants for constants.py
    class mock_constants(object):
        def __init__(self):
            self.DEFAULT_ROLES_PATH = 'default_roles_path'

    # Mock out config for constants.py
    class mock_config(object):
        def __init__(self):
            self.DEFAULT_ROLES_PATH = 'default_roles_path'

    # Mock out loader for loader.py
    class mock_loader(object):
        class shell_loader(object):
            def get(self, pname, class_only=None):
                return mock_shell_loader_class()

    # Mock out shell_loader_class for loader.py

# Generated at 2022-06-23 11:19:34.671345
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting("msg")
    assert error.message == "msg"

# Generated at 2022-06-23 11:19:46.576340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variables = VariableManager(loader=loader, inventory=inventory)
    c = LookupModule()
    # Ensure that all terms are string types
    terms = ['remote_tmp']
    args = dict(plugin_type='shell', plugin_name='sh')
    result = to_text(c.run(terms, variables=variables, **args))
    assert result == 'ssh'
    # Test if missing set
    terms = ['remote_tmp']

# Generated at 2022-06-23 11:19:57.636503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('In test_LookupModule_run')

    import ansible.errors as ans_errors
    import ansible.module_utils._text as mod_utils_text
    import ansible.utils.sentinel as utils_sentinel
    import ansible.plugins.loader as plugins_loader

    class obj:
        def __init__(self):
            self.on_missing = "error"
            self.plugin_type = ""
            self.plugin_name = ""

    class obj_C:
        def __init__(self):
            self.DEFAULT_ROLES_PATH = "default_roles_path"

    class obj_Loader:
        def __init__(self):
            self.p_class = None
            self.return_val = None
            self.ptype = ""
            self.pname = ""

# Generated at 2022-06-23 11:20:00.046276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit tests for run method of LookupModule class
    '''
    lookup_obj = LookupModule()
    assert lookup_obj.run(terms=['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-23 11:20:05.155008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Set default options for Lookup Module
    try:
        lookup_module.set_options()
    except Exception as e:
        assert "fail" in str(e)

    # Set custom options for Lookup Module
    try:
        lookup_module.set_options(var_options={'cache_timeout': 3600}, direct={'plugin_name': 'script'})
    except Exception as e:
        assert "fail" in str(e)

    try:
        lookup_module.set_options(var_options={'cache_timeout': 3600}, direct={'plugin_type': 'lookup', 'plugin_name': 'script'})
    except Exception as e:
        assert "fail" in str(e)


# Generated at 2022-06-23 11:20:07.457456
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:20:09.383825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:20:10.017580
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting

# Generated at 2022-06-23 11:20:17.851569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    :return: 
    """
    lookup=LookupModule()
    result=lookup.run(terms=['DEFAULT_ROLES_PATH'])
    logger.info("result={0}".format(result))

if __name__ == '__main__':
    import logging
    logger = logging.getLogger("test_config")
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    test_LookupModule_run()

# Generated at 2022-06-23 11:20:20.265569
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Setting some_setting was not defined'
    e = MissingSetting(msg)
    assert msg in str(e)

# Generated at 2022-06-23 11:20:28.399250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['DEFAULT_REMOVABLE_STORAGE_DETECT_CONTENTS']) == [C.DEFAULT_REMOVABLE_STORAGE_DETECT_CONTENTS]
    assert lookup.run(terms='DEFAULT_REMOVABLE_STORAGE_DETECT_CONTENTS') == [C.DEFAULT_REMOVABLE_STORAGE_DETECT_CONTENTS]
    assert lookup.run(terms='DEFAULT_REMOTABLE_STORAGE_DETECT_CONTENTS', on_missing='skip') == []
    assert lookup.run(terms='DEFAULT_REMOTABLE_STORAGE_DETECT_CONTENTS', on_missing='warn') == []

# Generated at 2022-06-23 11:20:37.171770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # To test if a new configuration value is added and if our lookup module 'config' is correctly able to
    # retrieve the value
    C.POST_PROCESS_DATA = {
        'ok': 'success',
        'changed': 'diff',
        'skipped': 'leaving unchanged',
    }

    # prepare a test object which can be used to call the run function and
    # check if the result is correct
    lookup_module_obj = LookupModule()
    # we are going to check the value of C.POST_PROCESS_DATA against the result
    # returned by run function
    result = lookup_module_obj.run(terms=['POST_PROCESS_DATA'])
    assert result[0] == C.POST_PROCESS_DATA

# Generated at 2022-06-23 11:20:38.980180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([''])
    assert len(result) == 1
    assert result[0] == 'error'

# Generated at 2022-06-23 11:20:44.463373
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleOptionsError

    try:
        exc = MissingSetting('Testing class MissingSetting')
        assert isinstance(exc, AnsibleError)
        assert isinstance(exc, AnsibleOptionsError)
    except:
        assert False, 'Unable to instantiate MissingSetting'

# Generated at 2022-06-23 11:20:54.930672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.config as config

    class DummyLookupModule(LookupModule):
        def __init__(self, **kwargs):
            self.params = kwargs

    class DummyVars:
        def get_vars(self):
            return {'env': {'ANSIBLE_CONFIG': '/path/to/ansible/config', 'HOME': '/home/ansible'}}

    # Test run with plugin_type, plugin_name and term
    term = ['remote_tmp']
    dummy_lookup = config.LookupModule()
    dummy_vars = DummyVars()
    dummy_options = {'plugin_type': 'shell', 'plugin_name': 'sh', 'var_options': dummy_vars.get_vars()}
    dummy_lookup.set_options

# Generated at 2022-06-23 11:20:58.781709
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    attr = 'foo'
    try:
        raise MissingSetting(attr)
    except MissingSetting as e:
        assert e.attribute == attr
        assert str(e) == 'invalid setting for foo'

# Generated at 2022-06-23 11:20:59.853561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj != None;

# Generated at 2022-06-23 11:21:01.327400
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:21:12.165781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for case when all option values are correct
    module = LookupModule()
    assert module.run(['COLLECTION_PATHS'])

    # Test for case when a setting is not present
    try:
        module = LookupModule()
        module.run(['UNKNOWN'])
    except AnsibleLookupError:
        pass

    # Test for case when a plugin is not present but plugin_type is valid
    try:
        module = LookupModule()
        module.run(['connection'], {'plugin_type': 'connection'})
    except AnsibleLookupError:
        pass

    # Test for case where plugin_name and plugin_type are provided but are not correct

# Generated at 2022-06-23 11:21:13.724945
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting()
    except MissingSetting as e:
        pass

# Generated at 2022-06-23 11:21:14.639892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:21:18.627892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run('color_stdout_highlight')
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == C.COLOR_STDOUT_HIGHLIGHT

# Generated at 2022-06-23 11:21:20.124973
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule().run(None, None)



# Generated at 2022-06-23 11:21:24.661684
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    args = ('Failed to load some_config',)
    keywds = {'orig_exc': 'Exception: failed to load'}
    m = MissingSetting(*args, **keywds)
    assert isinstance(m, Exception)
    assert m.message == args[0]
    assert m.orig_exc == keywds['orig_exc']

# Generated at 2022-06-23 11:21:28.324705
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'setting not in config'
    orig_exc = Exception()
    x = MissingSetting(msg, orig_exc)
    assert x.orig_exc == orig_exc
    assert x.msg == msg

# Generated at 2022-06-23 11:21:37.097561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    log = logging.getLogger()
    log.info("Start a test of constructor of class LookupModule")

    terms = [
        "DEFAULT_ROLES_PATH",
        "UNKNOWN",
        "UNKNOWN2"
    ]
    on_missing = "skip"
    lookup_plugin = LookupModule()
    options = dict(
        _terms=terms,
        on_missing=on_missing,
        _extras={
            'verbosity': 0,
        }
    )
    lookup_plugin.set_options(**options)
    lookup_plugin.basedir = 'server/plugins/lookup'
    lookup_plugin.runner = None
    lookup_plugin.templar = None
    lookup_plugin.vars = dict()
    lookup_plugin.inventory = dict()

    ret = lookup_plugin

# Generated at 2022-06-23 11:21:40.293295
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "test"
    orig_exc = Exception("test")
    ms = MissingSetting(msg, orig_exc)
    assert str(ms) == msg
    assert ms.orig_exc is orig_exc

    ms = MissingSetting("message", orig_exc)
    assert str(ms) == "message"
    assert ms.orig_exc is orig_exc

# Generated at 2022-06-23 11:21:52.532762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable = dict()

    lookup = LookupModule()
    lookup.set_options(var_options=variable)

    result = lookup.run(terms=["DEFAULT_ROLES_PATH"], variables=variable, on_missing="error")
    assert result[0] == C.DEFAULT_ROLES_PATH
    result = lookup.run(terms=["DEFAULT_ROLES_PATH"], variables=variable, on_missing="warn")
    assert result[0] == C.DEFAULT_ROLES_PATH
    result = lookup.run(terms=["DEFAULT_ROLES_PATH"], variables=variable)
    assert result[0] == C.DEFAULT_ROLES_PATH

    lookup.run(terms=["DEFAULT_ROLES_PATH", "foo", "bar"], variables=variable, on_missing="warn")

# Generated at 2022-06-23 11:21:54.070411
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module= LookupModule()
    assert module


# Generated at 2022-06-23 11:21:57.175887
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # When a message is given as a string
    exc = MissingSetting('This is a test')
    # And that message has been set
    assert exc.message == 'This is a test'


# Generated at 2022-06-23 11:22:06.736619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    This method tests the ability of Ansible to use constants.
    It does so by assigning a value to a constant,
    then calling the constant.
    '''
    C.ANSIBLE_RETRY_FILES_SAVE_PATH = "to_change"
    module = LookupModule()
    result = module.run(["ANSIBLE_RETRY_FILES_SAVE_PATH"])
    assert result[0] == "to_change"
    # need to do this so it doesn't pollute other tests
    C.ANSIBLE_RETRY_FILES_SAVE_PATH = "~/.ansible/retry"

# Generated at 2022-06-23 11:22:14.419937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([], {}) == []
    assert module.run(['---'], {}) == ['-', '-', '-']
    assert module.run([None], {}) == []
    assert module.run(['DEFAULT_BECOME_USER'], {}) == ['root']
    assert module.run(['DEFAULT_ROLES_PATH'], {'playbook_dir': '/playbook/path'}, on_missing='skip') == [
        u'/playbook/path/../', u'/playbook/path/roles', u'/usr/share/ansible/roles', u'/etc/ansible/roles']
    assert module.run(['UNKNOWN'], {'on_missing': 'warn'}) == []

# Generated at 2022-06-23 11:22:17.321413
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test', orig_exc='test')
    assert m.orig_exc == 'test'
    assert to_native(m) == 'test'

# Generated at 2022-06-23 11:22:28.634841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={'plugin_type': 'vars'}, direct={'on_missing': 'warn'})
    assert l.run(['DEFAULT_GROUP_VARS']) == [C.DEFAULT_GROUP_VARS]
    assert l.run(['DEFAULT_GROUP_VARS', 'DEFAULT_HOST_VARS']) == [C.DEFAULT_GROUP_VARS, C.DEFAULT_HOST_VARS]
    assert l.run(['UNKNOWN_VAR']) == []
    l.set_options(var_options={'plugin_type': 'vars'}, direct={'on_missing': 'warn'})
    assert l.run(['DEFAULT_GROUP_VARS']) == [C.DEFAULT_GROUP_VARS]

# Generated at 2022-06-23 11:22:30.488757
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(['DEFAULT_BECOME_USER'])
    assert(True)

# Generated at 2022-06-23 11:22:31.542489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule,object)

# Generated at 2022-06-23 11:22:33.345424
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mm = LookupModule()
    assert mm is not None

# Generated at 2022-06-23 11:22:38.747479
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    def input_test():
        raise MissingSetting("test_MissingSetting")

    try:
        input_test()
    except MissingSetting as e:
        if "test_MissingSetting" in str(e):
            return True
        else:
            return False
    except Exception as e:
        return False

# Generated at 2022-06-23 11:22:41.287701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    term = 'remote_user'
    variables = {}
    result = lookup_module.run(terms=term, variables=variables)
    assert result == ['root']

# Generated at 2022-06-23 11:22:53.002433
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing default option 'on_missing' set to 'error'

    # Case 1 : A proper setting, should return the setting
    C.DEFAULT_REMOTE_USER = 'retuser'
    settings_dict = {'terms': ['DEFAULT_REMOTE_USER'], 'variables': None, 'plugin_type': None, 'plugin_name': None, 'on_missing': 'error'}
    assert LookupModule().run(**settings_dict) == ['retuser']

    # Case 2 : A non existing setting, this should raise an exception
    settings_dict = {'terms': ['WRONG_SETTING'], 'variables': None, 'plugin_type': None, 'plugin_name': None, 'on_missing': 'error'}

# Generated at 2022-06-23 11:22:59.077629
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
  plugin_type = None
  plugin_name = None
  setting_name = None
  orig_exc = None
  result = MissingSetting(plugin_type, plugin_name, setting_name, orig_exc)
  assert result.args[0] == 'Attempted to read setting %s for plugin %s/%s but it is not set.' % (setting_name, plugin_type, plugin_name)

# Generated at 2022-06-23 11:23:09.611312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.six as six
    import sys
    import textwrap
    import yaml

    class FakePlugin(object):
        def __init__(self, name, classname):
            self.name = name
            self.classname = classname

        def get_opt(self, x):
            return C.config.get_config_value(x, plugin_name=self.classname, plugin_type=self.name)


# Generated at 2022-06-23 11:23:18.368790
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import os
    import pytest
    from io import StringIO
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('config')

    lookup._display.debug = True
    lookup._display.verbosity = True

    lookup.set_options(direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'sh'})
    lookup.run(['remote_tmp'])

    # test on_missing options of lookup module
    lookup.set_options(direct={'on_missing': 'skip', 'plugin_type': 'shell', 'plugin_name': 'sh'})
    lookup.run(['remote_tmp'])

# Generated at 2022-06-23 11:23:20.874851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None, "LookupModule class instance creation failed."

# Generated at 2022-06-23 11:23:30.901407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setUp
    AnsibleOptionsError = 'ansible.errors.AnsibleOptionsError'
    AnsibleLookupError = 'ansible.errors.AnsibleLookupError'
    LookupModule1 = LookupModule(loader=None, templar=None, shared_loader_obj=None)

    # missing should be a string and one of "error", "warn" or "skip", not Error

# Generated at 2022-06-23 11:23:32.664726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.config import LookupModule
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:23:35.841869
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test message')
    except MissingSetting as e:
        assert e.args[0] == 'test message'

# Generated at 2022-06-23 11:23:43.937372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #global C
    #C = {
    #    "DEFAULT_BECOME_USER": "root",
    #    "DEFAULT_ROLES_PATH": ["/etc/ansible/roles", "~/.ansible/roles"]
    #}
    #l = LookupModule()
    #t = l.run(["DEFAULT_ROLES_PATH"])
    #assert t == [["/etc/ansible/roles", "~/.ansible/roles"]]
    pass


# Generated at 2022-06-23 11:23:45.947547
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod is not None

# Generated at 2022-06-23 11:23:50.424520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule

    """
    # pylint: disable=protected-access
    assert isinstance(LookupModule, object)
    assert LookupModule._options is None
    assert LookupModule._display is None

# Generated at 2022-06-23 11:23:56.191392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    L._display = "None"
    L.set_options(var_options=None, direct=None)
    try:
        test_terms = ["DEFAULT_ROLES_PATH", "foo_bar_baz", "inventory_dir"]
        L.run(test_terms)
    except Exception as e:
        print("Test Failed")
        print(e)
    else:
        print("Test Successful")

# Generated at 2022-06-23 11:24:04.247525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest import TestCase
    from ansible import constants as C
    from ansible.utils.sentinel import Sentinel

    C.DEFAULT_ROLES_PATH = '/some/roles/path'
    C.DEFAULT_BECOME_USER = 'some_user'

    class MockLookupBase(LookupBase):
        def __init__(self):
            pass

        def set_options(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct

        def get_option(self, k):
            return self.direct[k] if k in self.direct else self.var_options[k]

    class MockDisplay(object):
        def __init__(self, *args, **kwargs):
            self.warnings = []


# Generated at 2022-06-23 11:24:11.341047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # assert error msg in case of invalid on_missing option
    assert_expected = ansible.errors.AnsibleOptionsError
    assert_exception = None
    try:
        lookup_module.run(terms=[], variables=None, **{'on_missing': 'error/warn/skip'})
    except Exception as e:
        assert_exception = type(e)
    assert assert_exception == assert_expected

    # assert error msg in case of invalid term type provided
    assert_expected = ansible.errors.AnsibleOptionsError
    assert_exception = None
    try:
        lookup_module.run(terms=[1], variables=None, **{'on_missing': 'error'})
    except Exception as e:
        assert_exception = type(e)

# Generated at 2022-06-23 11:24:13.389185
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:24:20.558173
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Check exc constructor with no args
    exc = MissingSetting()
    assert exc.message == ''
    assert exc.orig_exc is None
    assert to_native(exc) == '[ERROR]: AnsibleOptionsError: '
    # Check exc constructor with message only
    exc = MissingSetting('message1')
    assert exc.message == 'message1'
    assert exc.orig_exc is None
    assert to_native(exc) == '[ERROR]: AnsibleOptionsError: message1'
    # Check exc constructor with original exception only
    exc = MissingSetting(orig_exc='orig_exc1')
    assert exc.message == ''
    assert exc.orig_exc == 'orig_exc1'
    assert to_native(exc) == '[ERROR]: AnsibleOptionsError: '
    # Check exc constructor with message and original exception

# Generated at 2022-06-23 11:24:23.733083
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """This test case is to test the constructor of class MissingSetting."""
    config = 'UNKNOWN'
    msg = 'was not defined as an Ansible setting'
    e = AnsibleError(msg)
    missing_setting = MissingSetting(msg, orig_exc=e)

    assert str(missing_setting) == 'was not defined as an Ansible setting'
    assert missing_setting.orig_exc == e
    assert missing_setting.config == 'UNKNOWN'

# Generated at 2022-06-23 11:24:33.102469
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:24:38.273755
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Check that LookupModule is defined
    lookup_module_class = getattr(LookupModule, '_LookupModule', None)
    assert lookup_module_class is not None, 'LookupModule is undefined.'

    # Check that constructor works
    lookup_module = LookupModule()
    assert lookup_module is not None, 'LookupModule constructor failed.'

# Generated at 2022-06-23 11:24:48.596115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.loader import become_loader,cache_loader,callback_loader,cliconf_loader,connection_loader,httpapi_loader,inventory_loader,lookup_loader,netconf_loader,shell_loader,vars_loader
    import ansible
    from ansible.module_utils.six import string_types
    ansible.plugins.lookup.LookupBase = LookupBase
    ansible.plugins.lookup.LookupModule = LookupModule
    ansible.plugins.loader.become_loader = become_loader
    ansible.plugins.loader.cache_loader = cache_loader
    ansible.plugins.loader.callback_loader = callback_loader
    ansible.plugins.loader.cliconf_loader = cliconf_loader

# Generated at 2022-06-23 11:24:59.478205
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ex = MissingSetting('test')
    assert isinstance(ex, AnsibleOptionsError)
    assert ex.orig_exc is None
    assert ex.message == 'test'
    assert str(ex) == 'test'
    ex = MissingSetting('test', orig_exc=Exception('oops'))
    assert ex.orig_exc is not None
    assert str(ex) == 'test'
    ex = MissingSetting(Exception('oops'), orig_exc=Exception('oops'))
    assert ex.orig_exc is not None
    assert str(ex) == 'AnsibleLookupError: oops'
    assert repr(ex) == '<ansible.plugins.lookup.config.MissingSetting original exception oops>'


# Generated at 2022-06-23 11:25:08.232232
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # test missing setting attribute
    try:
        _get_global_config('UNKNOWN')
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert e.name == 'UNKNOWN'
        assert isinstance(e.orig_exc, AttributeError)
    else:
        assert False, 'Expected MissingSetting exception.'

    # test missing setting option
    try:
        _get_plugin_config('dummy', 'callback', 'UNKNOWN', {})
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert 'UNKNOWN was not defined' in e.name
        assert isinstance(e.orig_exc, AnsibleOptionsError)
    else:
        assert False, 'Expected MissingSetting exception.'

# Generated at 2022-06-23 11:25:09.647431
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-23 11:25:16.802951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import unittest
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY2

    class TestLookupModule(unittest.TestCase):
        def test_LookupModule_run(self):
            lookup_module = LookupModule()

            #
            # Test with plugin_type, plugin_name and setting
            #
            res = lookup_module.run(terms=["remote_tmp"], variables={}, plugin_type="shell", plugin_name="sh")
            self.assertEqual(res, [C.DEFAULT_REMOTE_TMP])

            #
            # Test with plugin_type, plugin_name and missing setting
            #

# Generated at 2022-06-23 11:25:18.713478
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module
    assert module.run

# Generated at 2022-06-23 11:25:22.515266
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_option('on_missing') == 'error'
    assert len(l.get_option('_terms')) == 0
    assert l.get_option('plugin_name') is None
    assert l.get_option('plugin_type') is None


# Generated at 2022-06-23 11:25:24.365982
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('something bad happened')
    except MissingSetting as e:
        assert 'something bad happened' in to_native(e)

# Generated at 2022-06-23 11:25:32.487081
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test constructor with 'message' parameter
    missing_setting = MissingSetting('test_message')
    assert missing_setting.message == 'test_message'

    # Test constructor with 'message' and 'orig_exc' parameter
    try:
        raise Exception('test_orig_exc')
    except Exception:
        orig_exc = Exception('test_orig_exc')
        missing_setting = MissingSetting('test_message', orig_exc=orig_exc)
        assert missing_setting.message == 'test_message'
        assert missing_setting.orig_exc == orig_exc

# Generated at 2022-06-23 11:25:35.442777
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # create object of the exception class
    miss_setting = MissingSetting('my message', 'my orig_exc')
    assert miss_setting is not None

# Generated at 2022-06-23 11:25:37.693273
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = []
    variables = {}
    kwargs = {}
    lookup = LookupModule()
    lookup.run(terms, variables, **kwargs)

# Generated at 2022-06-23 11:25:39.538814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 11:25:41.395955
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('Testing', orig_exc='original exception')
    assert 'Testing' == error.message
    assert 'original exception' == error.orig_exc

# Generated at 2022-06-23 11:25:51.910952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instance creation
    instance = LookupModule()
    # execution of the method with invalid value for terms
    result = instance.run(terms=77)
    assert result is None

    # execution of the method with invalid value for on_missing
    result = instance.run(terms='remote_port', variables=dict(remote_port='77'), on_missing='so_missing')
    assert result == []

    # execution of the method with missing plugin_type
    result = instance.run(terms='remote_port', variables=dict(remote_port='77'), plugin_name='ssh')
    assert result == []

    # execution of the method with missing plugin_name
    result = instance.run(terms='remote_port', variables=dict(remote_port='77'), plugin_type='connection')
    assert result == []

    # execution of the method with valid

# Generated at 2022-06-23 11:25:52.497429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:26:00.919504
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    sys.path.append('/usr/local/lib/python3.5/site-packages/ansible/plugins')
    import ansible.plugins.loader as plugin_loader
    plugin_loader.add_directory(None)

    import ansible.plugins.lookup.config as config
    lookup = config.LookupModule()

    assert lookup.on_missing == 'error'
    assert lookup.plugin_name is None
    assert lookup.plugin_type is None
    assert lookup.run(['DEFAULT_REMOTE_USER']) == ['root']
    assert lookup.run(['abc']) == []

# Generated at 2022-06-23 11:26:10.596042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleOptionsError
    from ansible import constants as C
    from ansible.module_utils.six import string_types

    constants_backup = C.get_config_data()

    C.DEFAULT_ANSIBLE_CONFIG = ''


# Generated at 2022-06-23 11:26:13.684779
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise AnsibleLookupError
    except AnsibleLookupError:
        _e = MissingSetting(msg='Error LookupError')
        assert 'Error LookupError' in _e.message

    try:
        raise AnsibleOptionsError
    except AnsibleOptionsError:
        _e = MissingSetting(msg='Error OptionsError')
        assert 'Error OptionsError' in _e.message

# Generated at 2022-06-23 11:26:16.077789
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Test String"
    ex = Exception()
    ms = MissingSetting(msg, orig_exc=ex)

    assert ms.message == msg
    assert ms.orig_exc == ex

# Generated at 2022-06-23 11:26:24.760798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert not lookup.run([], variables=None, **{})
    assert lookup.run(['DEFAULT_BECOME_USER'], variables=None, **{}) == [u'root']
    assert lookup.run(['DEFAULT_ROLES_PATH'], variables=None, **{}) == [u'status=0', u'rc=0']
    assert lookup.run(['RETRY_FILES_SAVE_PATH'], variables=None, **{}) == []
    assert lookup.run(['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{}) == [u'green', u'yellow', u'cyan']
    assert lookup.run(['UNKNOWN'], variables=None, **{}) == []


# Generated at 2022-06-23 11:26:25.991070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()


# Generated at 2022-06-23 11:26:27.796009
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.name == 'test'

# Generated at 2022-06-23 11:26:40.272735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys
    import os
    import tempfile
    # Load the ansible module
    ansible_module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    if ansible_module_path not in sys.path:
        sys.path.append(ansible_module_path)
    from ansible.plugins.loader import lookup_loader
    lookup_class = lookup_loader._load_lookup_plugin('config')
    lookup = lookup_class()
    # Create test instance 
    test_instance = unittest.TestCase()
    # Get the test data path

# Generated at 2022-06-23 11:26:41.876857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:26:45.146451
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test_MissingSetting")
    except MissingSetting as e:
        assert e.message == "test_MissingSetting"

# Generated at 2022-06-23 11:26:49.978675
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert 'test' == str(e)
        assert e.orig_exc is None
    try:
        importerror = ImportError('test')
        raise MissingSetting('test', importerror)
    except MissingSetting as e:
        assert 'test' == str(e)
        assert e.orig_exc == importerror

# Generated at 2022-06-23 11:26:58.500989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_ROLES_PATH','DEFAULT_BECOME_USER']
    pname = 'ssh'
    ptype = 'connection'
    kwargs = {'on_missing':'warn'}
    lookup_module = LookupModule()
    res = lookup_module.run(terms, None, **kwargs)
    assert 'become_user' in res[1]
    res = lookup_module.run(terms, None, plugin_type=ptype, plugin_name=pname)
    assert 'become_user' in res[0]
    assert isinstance(res[0], tuple)
    assert len(res[0]) == 2

# Generated at 2022-06-23 11:26:59.929679
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('some message')
    assert(e)

# Generated at 2022-06-23 11:27:05.898975
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    msg = "Testing display of Error message with and without original exception"
    try:
        raise MissingSetting("Missing configuration setting", orig_exc=True)
    except AnsibleOptionsError as e:
        assert msg in str(e)
    try:
        raise MissingSetting("Missing configuration setting")
    except AnsibleOptionsError as e:
        assert msg not in str(e)

# Generated at 2022-06-23 11:27:12.894366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    config_settings = []
    with open(C.DEFAULTS_PATH) as f:
        for line in f.readlines():
            if line.startswith('#') or not line.strip():
                continue
            name, _, value = line.strip().partition("=")
            if name.startswith("DEFAULT_"):
                config_settings.append(name)
    config_settings.append("DEFAULT_ERROR_ON_MISSING_HANDLER") # Ensure that it can handle non-config settings
    config_settings.append("DEFAULT_LOAD_CALLBACK_PLUGINS")
    config_settings.append("DEFAULT_CALLBACK_WHITELIST")
    config_settings.append("DEFAULT_CALLBACK_PLUGINS")
    config_settings

# Generated at 2022-06-23 11:27:15.273688
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('This is a test error message')
    assert e.message == 'This is a test error message'
    assert e.orig_exc is None

# Generated at 2022-06-23 11:27:20.647803
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    exc = MissingSetting('Invalid setting')
    if PY2:
        assert to_bytes(exc) == '{"msg": "Invalid setting"}'
    else:
        assert str(exc) == '{"msg": "Invalid setting"}'

# Generated at 2022-06-23 11:27:25.191673
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test", orig_exc="test")
    except Exception as exc:
      assert type(exc).__name__ == "MissingSetting", 'MissingSetting was not raised'
      assert str(exc) == 'test', 'Error message was not set properly'

# Generated at 2022-06-23 11:27:26.400417
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:27:32.173642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.config.manager import ConfigManager
  from ansible.plugins.loader import lookup_loader

  config = ConfigManager()
  loader = lookup_loader
  config.load_config_file()

  lm = LookupModule(loader=loader, templar=None, variables=config.data)

  result = lm.run(["DEFAULT_BECOME_USER"], variables=config.data)
  assert(result[0] == config.get_setting_value("DEFAULT_BECOME_USER"))

# Generated at 2022-06-23 11:27:43.632487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes

    lm = LookupModule()

    # Valid data
    terms = ['DEFAULT_BECOME_USER']
    lm.set_options(direct={'on_missing': 'error'})
    for term in terms:
        result = lm.run([term], variables=None, **{'on_missing': 'error'})
        assert result == [C.DEFAULT_BECOME_USER]
        assert result[0] == C.DEFAULT_BECOME_USER

    # Invalid data
    lm.set_options(direct={'on_missing': 'error'})
    terms = ['INVALID_SETTING']
    try:
        lm.run(terms, variables=None)
    except AnsibleError as ae:
        assert ae

# Generated at 2022-06-23 11:27:56.379987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing get_global_config method of the class LookupModule
    lb = LookupModule()
    # check if the method will raise error if the setting is not a string
    try:
        lb.run(['playbook_dir'], {}, {'plugin_type': None, 'plugin_name':None, 'on_missing': 'error'})
    except Exception:
        assert True

    # check if the method will raise error if the option is neither error, warn nor skip
    try:
        lb.run(['playbook_dir'], {}, {'plugin_type': None, 'plugin_name':None, 'on_missing': 'sdfsfd'})
    except Exception:
        assert True

    # check if the method will not raise error if the setting is a string

# Generated at 2022-06-23 11:28:04.933102
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test missing options
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct=kwargs)
    result = lookup_module.run(terms, variables)
    assert result == ['root']
    result = lookup_module.run(None, variables)
    assert result == []

    # Test missing=error
    lookup_module.set_options(var_options=variables, direct=kwargs)
    terms = ['BAD_DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {'on_missing': 'error'}
    lookup_module.set_options(var_options=variables, direct=kwargs)

# Generated at 2022-06-23 11:28:06.190931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l1 = LookupModule()
    assert l1

# Generated at 2022-06-23 11:28:09.505714
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Test message")
    except MissingSetting as e:
        assert e.message == "Test message"

# Generated at 2022-06-23 11:28:10.154956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:28:16.049828
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader

    # Create an object of LookupModule class
    lookup_obj = lookup_loader.get('config')

    # Retrieve the values for given configuration setting using the method run of the class LookupModule
    result = lookup_obj.run(['DEFAULT_BECOME_USER'])

    # Check if the returned value is not empty
    assert result[0] is not None