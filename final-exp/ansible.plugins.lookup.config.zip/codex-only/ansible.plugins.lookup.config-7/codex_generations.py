

# Generated at 2022-06-23 11:18:12.396478
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:18:13.769320
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:18:16.503880
# Unit test for constructor of class LookupModule
def test_LookupModule():
# LookupModule is a child class of LookupBase
    lookup_plugin = LookupModule()

    assert isinstance(lookup_plugin, LookupBase)


# Generated at 2022-06-23 11:18:18.586990
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    foo = MissingSetting('test')
    assert foo.message == 'test'
    assert foo.orig_exc is None

# Generated at 2022-06-23 11:18:27.642910
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import binary_type

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = dict()
            for k,v in kwargs.items():
                self.params[k] = v


# Generated at 2022-06-23 11:18:36.420677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing 'invalid' option value
    #
    # Setup
    term = 'invalid'
    dummy_loader = getattr(plugin_loader, 'dummy_loader')
    p = dummy_loader.get(term, class_only=True)
    if p is None:
        raise AnsibleLookupError('Unable to load dummy_loader plugin "%s"' % term)
    # Test
    with pytest.raises(AnsibleOptionsError) as err:
        p.run('invalid')
    # Verify
    assert 'Invalid setting identifier' in err.value.message
    assert 'is not a string' in err.value.message

    # Testing 'missing' option value
    #
    # Setup
    test_term = 'dummy'
    # Test

# Generated at 2022-06-23 11:18:43.943821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None
    # plugin_type and plugin_name are required and must be used together
    test_variables = dict()
    test_variables['plugin_type'] = 'connection'
    test_variables['plugin_name'] = 'ssh'
    test_variables['on_missing'] = 'skip'
    lookup_module.set_options(var_options=test_variables, direct=dict())
    setting_value = lookup_module.run(terms=['remote_user'], variables=test_variables)
    assert setting_value == ['root']

# Generated at 2022-06-23 11:18:47.125385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = {}
    l = LookupModule()
    l.run('DEFAULT_BECOME_USER', terms=terms)

# Generated at 2022-06-23 11:18:54.235224
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        # Here we call the constructor of the class MissingSetting and pass test_msg as a parameter to it.
        raise MissingSetting(msg="test_msg")
    except AnsibleOptionsError as e:
        # If AnsibleOptionsError exception was not raised then the test fails.
        assert False, "AnsibleOptionsError exception is not raised."
    # If AnsibleOptionsError exception was raised then the test passes.
    assert True, "AnsibleOptionsError exception is raised."


# Generated at 2022-06-23 11:18:56.704637
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Foo')
    except MissingSetting as e:
        assert isinstance(e, MissingSetting), 'Missing Setting is an instance of MissingSetting'

# Generated at 2022-06-23 11:19:00.055132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'plugin_name': 'foo'})
    assert(lookup_module.run(['foo']) is None)

# Generated at 2022-06-23 11:19:05.474989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with an unknown variable.
    unknown_variable = 'UNKNOWN'
    with pytest.raises(AnsibleOptionsError, match=r'\"on_missing\" must be a string and one of \"error\", \"warn\" or \"skip\", not UNKNOWN'):
        LookupModule(unknown_variable, unknown_variable)

# Generated at 2022-06-23 11:19:06.889387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret.run([]) == []

# Generated at 2022-06-23 11:19:07.693848
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert not MissingSetting(''), "parameter error"

# Generated at 2022-06-23 11:19:17.831101
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check case which callable is sent to missing #
    lm = LookupModule()
    assert isinstance(lm, LookupModule), "Instance doesn't created successfully"
    # Check case which on_missing is not a string #
    lm.set_options(var_options={}, direct={'on_missing': 22})
    try:
        lm.run(terms=['foo'])
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not 22' in str(e)
    # Check case which on_missing is not in error, warn or skip #
    lm.set_options(var_options={}, direct={'on_missing': 'not_in'})

# Generated at 2022-06-23 11:19:18.312702
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:19:23.543843
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Unable to find setting %s'
    exc = AnsibleOptionsError('a message')
    missing_setting_obj = MissingSetting(msg, orig_exc=exc)
    assert msg in missing_setting_obj.message
    assert missing_setting_obj.orig_exc is exc

# Generated at 2022-06-23 11:19:24.860752
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except:
        assert False


# Generated at 2022-06-23 11:19:32.884116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    from ansible.plugins.loader import callback_loader, connection_loader, cliconf_loader
    from ansible.constants import DEFAULT_CALLBACK_WHITELIST
    from ansible.plugins.strategy.linear import StrategyModule
    import os
    import sys

    # create a mock for class LookupModule
    class MockLookupModule:
        def __init__(self):
            pass

        def run(self, terms, variables=None, **kwargs):
            return terms

    # create a mock for class callbackLoad
    class MockCallbackLoad:
        def __init__(self):
            pass

        def get(self, callback, class_only=False):
            return callback

    # create a mock for class connectionLoad

# Generated at 2022-06-23 11:19:35.831151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options({'on_missing':'error'})
    assert "error" == lookup.get_option('on_missing')

# Generated at 2022-06-23 11:19:38.356578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _m = LookupModule()
    assert isinstance(_m, LookupModule)

# Generated at 2022-06-23 11:19:42.713248
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Simple test to show exception text
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        print("test_MissingSetting: %s" % str(e))
        # this just shows that the code is reached. No assertion needed

# Generated at 2022-06-23 11:19:50.944622
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with valid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.plugin_type == None
    assert lookup_plugin.plugin_name == None

    # Test with invalid plugin_type and plugin_name
    lookup_plugin = LookupModule(plugin_type='conne', plugin_name='s')
    assert lookup_plugin.plugin_type == 'conne'
    assert lookup_plugin.plugin_name == 's'

    # Test with valid plugin_type and invalid plugin_name
    lookup_plugin = LookupModule(plugin_type='connection', plugin_name='s')
    assert lookup_plugin.plugin_type == 'connection'
    assert lookup_plugin.plugin_name == 's'

    # Test with invalid plugin_type and valid plugin_name

# Generated at 2022-06-23 11:19:53.411611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(["DEFAULT_BECOME_USER"], variables={"playbook_dir":"./playbooks"}, on_missing="error")
    assert result == ["root"]

# Generated at 2022-06-23 11:20:03.425655
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of LookupModule class
    test_instance_LookupModule = LookupModule()

    # Create test cases

    # Positive test case - returns list of Ansible configuration settings
    terms_1 = [ 'ANSIBLE_INVENTORY', 'DEFAULT_FORKS']
    result_1 = test_instance_LookupModule.run(terms_1)
    expected_result_1 = [to_native(C.DEFAULT_INVENTORY), to_native(C.DEFAULT_FORKS)]
    assert (result_1 == expected_result_1)

    # Positive test case - returns list of Ansible configuration settings when plugin_name and plugin_type are given for a cache plugin
    terms_2 = ['plugin_name', 'plugin_type', 'plugin_path']

# Generated at 2022-06-23 11:20:06.435783
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('msg', orig_exc='')
    assert e.msg == 'msg'
    assert e.orig_exc == ''

# Generated at 2022-06-23 11:20:07.715829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(['hostfile'])

# Generated at 2022-06-23 11:20:10.050654
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.get_option('on_missing') == 'error'


# Generated at 2022-06-23 11:20:19.803433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    configs = [{'ptype': 'connection', 'pname': 'ssh', 'term': 'remote_user', 'result': 'test_user'},
               {'ptype': 'connection', 'pname': 'netconf', 'term': 'port', 'result': '99'},
               {'ptype': 'shell', 'pname': 'sh', 'term': 'remote_tmp', 'result': 'test_remote_tmp'},
               {'term': 'DEFAULT_ROLES_PATH', 'result': 'test_DEFAULT_ROLES_PATH'},
               {'term': 'HOST_KEY_CHECKING', 'result': 'test_HOST_KEY_CHECKING'},
               ]


# Generated at 2022-06-23 11:20:25.100836
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    o = MissingSetting(msg='Some error message', orig_exc=Exception('Some exception'))
    assert o.msg == 'Some error message'
    assert o.orig_exc.__str__() == 'Some exception'
    assert o.to_dict() == {'msg': o.msg, 'orig_exc': o.orig_exc}
    assert o.to_json() == {'msg': o.msg, 'orig_exc': o.orig_exc}

# Generated at 2022-06-23 11:20:27.573765
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    assert isinstance(MissingSetting(), MissingSetting) is True
    assert isinstance(MissingSetting('Testing initialization of MissingSetting'), MissingSetting) is True

# Generated at 2022-06-23 11:20:38.162246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for on_missing in ('error', 'warn', 'skip'):
        lookup_module = LookupModule()
        lookup_module.set_options(var_options=None, direct={'on_missing': on_missing})
        lookup_module.run(('DEFAULT_ROLES_PATH', 'nonexistent-key'))
        # Test with a nonexistent term
        with pytest.raises(AnsibleLookupError):
            lookup_module.run(('nonexistent-key',))
        # Test with a nonexistent plugin type
        with pytest.raises(AnsibleOptionsError):
            lookup_module.set_options(var_options=None, direct={'plugin_type': 'nonexistent-plugin-type'})
        # Test with only plugin type (requires plugin name to be provided as well)

# Generated at 2022-06-23 11:20:49.638917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create dummy values for testing
    ret = []
    ret.append('value1')
    ret.append('value2')

    # create dummy class which will be overwritten by LookupModule
    class DummyClass(object):

        def run(self, terms, variables=None, **kwargs):
            pass

    # create dummy ansible_play_context
    class AnsiblePlayContext(object):

        def __init__(self):
            self.settings = 'settings'
            self.vars = 'vars'

    # create dummy constants
    class constants:

        def __init__(self):
            self.config = 'config'
            self.settings = 'settings'
            self.vars = 'vars'

    # create dummy variables for testing
    variables = {}

# Generated at 2022-06-23 11:20:51.980671
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    variable_name = "non_existent_variable"
    missing_setting = MissingSetting(variable_name)
    assert variable_name in str(missing_setting)

# Generated at 2022-06-23 11:20:53.052099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l



# Generated at 2022-06-23 11:21:05.992387
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test with no terms
    terms = []
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms)

    # test with non-string terms
    terms = [None]
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms)

    # test with invalid on_missing setting
    terms = ['no_such_setting']
    invalid_on_missing = 'invalid'
    module_args = dict(
        _terms=terms,
        on_missing=invalid_on_missing
    )
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms, module_args=module_args)

    # test with missing on_missing setting
    terms = ['no_such_setting']
    module_args

# Generated at 2022-06-23 11:21:06.941263
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:21:10.306410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["DEFAULT_ROLES_PATH", "C.DEFAULT_ROLES_PATH"]
    ret = lookup.run(terms)
    assert True == set(ret).issubset(C.DEFAULT_ROLES_PATH)

# Generated at 2022-06-23 11:21:11.234162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    return 0

# Generated at 2022-06-23 11:21:14.904314
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run(terms=['DEFAULT_BECOME_USER'], variables={'ansible_become_user': 'default_become_user'}) == ['default_become_user']


# Generated at 2022-06-23 11:21:18.333480
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('A message', orig_exc='An original exception')
    assert e.message == 'A message'
    assert e.orig_exc == 'An original exception'

# Generated at 2022-06-23 11:21:20.358069
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Something bad happened"
    e = RuntimeError(msg)
    ansible_error = MissingSetting(msg, e)
    assert ansible_error.orig_exc == e
    assert str(ansible_error) == msg

# Generated at 2022-06-23 11:21:22.281565
# Unit test for constructor of class LookupModule
def test_LookupModule():
    k1 = LookupModule()
    assert k1.get_option('on_missing') == 'error'

# Generated at 2022-06-23 11:21:24.375368
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("setting was not defined")
    except MissingSetting as e:
        assert str(e) == "setting was not defined"

# Generated at 2022-06-23 11:21:26.705237
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Test Exception")
    except AnsibleOptionsError as e:
        assert "Test Exception" in e.message
        assert e.orig_exc is None

# Generated at 2022-06-23 11:21:28.735450
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for constructor of class LookupModule'''
    assert 'LookupModule' in globals()
    lm = LookupModule()



# Generated at 2022-06-23 11:21:37.440827
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from collections import namedtuple
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.six.moves import UserDict
    from ansible.plugins.cache.jsonfile import CacheModule as cache_jsonfile
    from ansible.plugins.loader import callback_loader
    from io import BytesIO
    import pytest
    import sys

    # Tests require a 'mock_ansible_module' fixture that returns
    # the 'ansible_module' object created by the test harness for each test,
    # and a 'mock_ansible_module_results' fixture that returns the
    # results of ansible.module_utils.basic.AnsibleModule.exit

# Generated at 2022-06-23 11:21:39.047566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(['DEFAULT_BECOME_USER'])

# Generated at 2022-06-23 11:21:41.932670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Just test that the constructor doesn't throw an error
    LookupModule()

# Generated at 2022-06-23 11:21:45.394625
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
         raise MissingSetting("msg")
    except MissingSetting as exc:
        assert exc.message == "msg"
        assert exc.option_name is None
        assert exc.args[0] == "msg"

# Generated at 2022-06-23 11:21:47.635336
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_module = LookupModule()
    assert isinstance(test_module, LookupModule)

# Generated at 2022-06-23 11:21:49.454956
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting("Test exception")
    assert exception.msg == "Test exception"



# Generated at 2022-06-23 11:21:55.790872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModuleTest(LookupModule):
        def __init__(self, basedir=None, runner=None, variables=None, **kwargs):
            super(LookupModuleTest, self).__init__(basedir=basedir, runner=runner, variables=variables, **kwargs)
            self._display = DummyDisplay()

    class DummyDisplay(object):
        def __init__(self):
            self.w = []

        def warning(self, msg):
            self.w.append(msg)

 
    class DummyRunner(object):
        def __init__(self):
            self.c = []

        def get_option(self, opt):
            self.c.append(opt)


# Generated at 2022-06-23 11:21:56.782872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 11:21:57.641430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 11:21:58.841558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(lm)

# Generated at 2022-06-23 11:22:02.132946
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting
    except Exception as e:
        assert 'Invalid setting identifier' in str(e)

# Generated at 2022-06-23 11:22:03.322326
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('error')
    assert e.args[0] == 'error'

# Generated at 2022-06-23 11:22:04.430713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-23 11:22:05.868788
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("missing setting test")
    except MissingSetting as e:
        assert 'missing setting test' in str(e)

# Generated at 2022-06-23 11:22:07.903745
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.__class__.__name__ == "LookupModule"

# Generated at 2022-06-23 11:22:14.469656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get("config", class_only=True)
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    module = LookupModule()
    result = module.run(terms)
    assert(len(result) == 2)
    assert(result[0] == 'root')
    terms = [MissingSetting]
    try:
        module.run(terms, on_missing='error')
    except MissingSetting as e:
        assert(isinstance(e, Exception))
    assert('these are the configured role paths' in module.run(terms, on_missing='skip')[0].lower())

# Generated at 2022-06-23 11:22:16.647497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-23 11:22:18.089018
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Could not find setting foo.')
    except MissingSetting:
        pass

# Generated at 2022-06-23 11:22:22.715987
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test', orig_exc=Exception('test exception'))
    except MissingSetting as e:
        assert e.orig_exc.args[0] == 'test exception'
        assert str(e) == 'test'

# Unit tests for function _get_plugin_config()

# Generated at 2022-06-23 11:22:23.396293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:22:26.280146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Constructor test"""

    # Create object
    lookup = LookupModule()

    # Check
    assert lookup is not None


# Generated at 2022-06-23 11:22:35.538318
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import sys
    import pytest

    try:
        raise LookupModule(None, None)._get_global_config('FOOBAR')
    except MissingSetting as e:
        msg = str(e)
        assert msg == 'FOOBAR was not defined', 'msg was "%s"' % msg
        assert isinstance(e, LookupBase), 'obj was not a LookupBase'
        assert isinstance(e, LookupError), 'obj was not a LookupError'
        assert isinstance(e, AnsibleLookupError), 'obj was not a AnsibleLookupError'
        assert isinstance(e, AnsibleError), 'obj was not a AnsibleError'
        assert isinstance(e, Exception), 'obj was not an Exception'
        assert isinstance(e, BaseException), 'obj was not a BaseException'
        pytest

# Generated at 2022-06-23 11:22:45.529641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.cache.memory
    import ansible.plugins.loader
    import ansible.plugins.shell.sh

    import os

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    ansible_path = os.path.join(cur_dir, os.path.pardir, os.path.pardir)
    plugin_path = os.path.join(ansible_path, 'plugins')

    plugin_loader.add_directory(plugin_path)

    # Setup Variables
    cache = ansible.plugins.cache.memory.CacheModule()
    cache.set_options({'language': 'en'})

# Generated at 2022-06-23 11:22:56.405283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    lookup.get_option = lambda arg: arg

    terms = ['DEFAULT_BECOME_USER']
    variables = dict(hostvars={'toto': 'titi'})

    result = lookup.run(terms, variables=variables, on_missing='warn')
    assert result == [C.DEFAULT_BECOME_USER]

    result = lookup.run(terms, variables=variables, on_missing='error')
    assert result == [C.DEFAULT_BECOME_USER]

    try:
        lookup.run(['UNKNOWN'], variables=variables, on_missing='error')
        assert False
    except AnsibleLookupError:
        assert True


# Generated at 2022-06-23 11:23:02.140318
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_exception = MissingSetting("test")
    # Check for correct exception
    assert isinstance(test_exception, AnsibleOptionsError)
    # Check for correct message
    assert test_exception.message == "test"
    # Check that we are picking up the orig_exc
    assert isinstance(test_exception.orig_exc, Exception)

# Generated at 2022-06-23 11:23:04.669262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(terms='ansible_user', variables='ansible_user', **{}) == ['ansible_user']

# Generated at 2022-06-23 11:23:11.189101
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test values to be used in test
    terms = ["DEFAULT_BECOME_USER"]
    variables = None
    on_missing = "error"

    l = LookupModule()
    l.set_loader(plugin_loader)
    ret = l.run(terms,variables,on_missing=on_missing)
    assert len(ret) == 1, 'LookupModule: run: Result for lookup module is incorrect'
    assert type(ret) is list, 'LookupModule: run: Result does not have the correct type'



# Generated at 2022-06-23 11:23:15.931264
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting("missing", orig_exc=Exception("orig"))
    assert to_native(exc) == "missing"
    assert str(exc) == "missing"
    assert repr(exc) == "missing"
    assert exc.orig_exc is not None
    assert to_native(exc.orig_exc) == "orig"

# Generated at 2022-06-23 11:23:19.938104
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'fake message'
    e = AnsibleError(msg)
    m = MissingSetting(msg, e)
    assert m.message == msg
    assert m.orig_exc == e

# Generated at 2022-06-23 11:23:26.001807
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting('test')
    assert str(ms) == 'test'
    assert ms.orig_exc is None

    with pytest.raises(AnsibleOptionsError):
        ms = MissingSetting('test', orig_exc=ValueError)

    ms = MissingSetting('test', orig_exc=ValueError)
    assert str(ms) == 'test'
    assert ms.orig_exc

# Generated at 2022-06-23 11:23:28.536803
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import sys

    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        return
    else:
        exc = Exception('new exception')
        exc_obj = MissingSetting('message', orig_exc=exc)
        actual_msg = exc_obj.args[0]
        expected_msg = 'message'
        assert actual_msg==expected_msg

# Generated at 2022-06-23 11:23:34.640654
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = [
        {
            'terms': ['DEFAULT_ROLES_PATH'],
            'variables': {'foo': 'bar'},
            'on_missing': 'error',
            'plugin_type': '',
            'plugin_name': ''
        },
        {
            'terms': ['DEFAULT_ROLES_PATH'],
            'variables': {'foo': 'bar'},
            'on_missing': '',
            'plugin_type': 'foo',
            'plugin_name': 'bar'
        }
    ]

    for d in data:
        l = LookupModule()
        l.set_options(var_options=d['variables'], direct=d)
        assert l.get_option('on_missing') == 'error'

# Generated at 2022-06-23 11:23:42.402311
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test that missing setting constructor creates correct error message
    expected_error_message = "Missing setting 'NONEXISTENT_TEST_CONFIG_VAR'"

    try:
        raise MissingSetting('NONEXISTENT_TEST_CONFIG_VAR')
    except MissingSetting as e:
        error_message = e.args[0]
        assert(error_message == expected_error_message)
    except:
        assert('Unexpected Error Occurred')


# Generated at 2022-06-23 11:23:44.167574
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('Error Message')
    assert exc.message == 'Error Message'
    assert exc.orig_exc is None

# Generated at 2022-06-23 11:23:56.189776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import is_sequence

    lookup = LookupModule()
    variables = getattr(lookup, '_templar', None)._available_variables
    assert isinstance(variables, MutableMapping)
    for key, value in variables.items():
        assert isinstance(key, string_types)
        if is_sequence(value) and not isinstance(value, string_types):
            value = [to_text(v, errors='surrogate_or_strict') for v in value]
        else:
            value = to_

# Generated at 2022-06-23 11:24:02.159157
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common.collections import ImmutableDict
    test_class = LookupModule()
    assert test_class.set_options(var_options=None, direct={}) is None
    assert test_class.set_options(var_options=ImmutableDict(), direct={}) is None
    pytest.raises(AnsibleOptionsError, test_class.run, terms=None)
    pytest.raises(AnsibleOptionsError, test_class.run, terms=12)
    pytest.raises(AnsibleOptionsError, test_class.run, terms='test')
    pytest.raises(AnsibleOptionsError, test_class.run, terms=['test'], variables=None, on_missing=None)

# Generated at 2022-06-23 11:24:13.157036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(direct={'plugin_type': 'become', 'plugin_name': 'sudo'})
    assert lookup.run(['become_method']) == ['sudo']
    lookup.set_options(direct={'on_missing': 'warn', 'plugin_name': 'sudo'})
    assert lookup.run(['become_method']) == ['sudo']
    lookup.set_options(direct={'on_missing': 'error', 'plugin_name': 'sudo'})
    assert lookup.run(['become_method']) == ['sudo']
    lookup.set_options(direct={'on_missing': 'error'})
    assert lookup.run(['become_method']) == ['sudo']
    lookup.set_options(direct={'on_missing': 'warn'})

# Generated at 2022-06-23 11:24:18.220573
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Derived from TestAnsibleOptions
    config = 'test_test'
    MissingSetting(config)
    # TestAnsibleOptions only raise AnsibleOptionsError, here we also raise MissingSetting
    # TODO: wrap AnsibleOptionsError in MissingSetting and catch
    # assertRaisesRegex(self, MissingSetting, re.escape('test_test was not defined'))

# Generated at 2022-06-23 11:24:28.326366
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test with all entries missing
    lm = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}

    try:
        lm.run(terms)
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError('AnsibleOptionsError not raised')

    # test with DEFAULT_BECOME_USER missing
    lm = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {'on_missing': 'error'}

    try:
        lm.run(terms, variables=variables)
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError('AnsibleOptionsError not raised')

    # test with DEFAULT_BECOME_USER found
    lm = Look

# Generated at 2022-06-23 11:24:29.214413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:24:33.352195
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('setting not found')
    except Exception:
        err = get_exception()
    assert isinstance(err, MissingSetting)
    assert err.message == "setting not found"
    assert to_native(err) == "setting not found"

# Generated at 2022-06-23 11:24:35.425985
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.set_options({'_ansible_verbosity': 2})

# Generated at 2022-06-23 11:24:39.522107
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        print('Exception raised: {}'.format(e))
    else:
        print('test_LookupModule passed')

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:24:43.604528
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    msg = "This is an error message"
    orig_exc = None
    assert_msg = 'msg and orig_exc not set properly'
    ms = MissingSetting(msg, orig_exc=orig_exc)
    assert ms.message == msg, assert_msg
    assert ms.orig_exc == orig_exc, assert_msg

# Generated at 2022-06-23 11:24:45.378958
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Setting name not found"
    ms = MissingSetting(msg)
    assert ms.message == msg

# Generated at 2022-06-23 11:24:46.507378
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting("test")
    assert(result)

# Generated at 2022-06-23 11:24:47.619870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:24:49.546889
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting("bad config option", "exc")
    assert exc.orig_exc == "exc"

# Generated at 2022-06-23 11:24:53.925543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #Test get_user plugin config
    lookup.run([
        'remote_user',
        'remote_tmp',
        'accelerate_port',
        'accelerate_timeout',
        'accelerate_connect_timeout',
        'persistent_accelerate',
        'persistent_command_timeout'],
        plugin_type='shell',
        plugin_name='sh')

# Generated at 2022-06-23 11:24:56.371063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    test_module = LookupModule()
    assert test_module


# Generated at 2022-06-23 11:25:06.964245
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm.run([]) == []
    lm = LookupModule()
    assert lm.run(terms=['DEFAULT_ROLES_PATH']) == ['/etc/ansible/roles:/usr/share/ansible/roles:/usr/local/share/ansible/roles']
    lm = LookupModule()
    assert lm.run([{'on_missing':'error'}]) == []

    lm = LookupModule()
    try:
        result = lm.run(['DEFAULT_ROLES_PATH'], variables={'inventory_dir':'/etc/inventory'})
    except Exception as e:
        assert isinstance(e, AnsibleLookupError)
        assert 'No such file or directory' in e.original_exception.strer

# Generated at 2022-06-23 11:25:07.611260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:25:09.094195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lkup = LookupModule()
    assert lkup is not None

# Generated at 2022-06-23 11:25:10.079467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:25:11.030052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:25:17.476394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype = None
    pname = None
    missing = 'error'

    terms = ['DEFAULT_BECOME_USER']

    # Test for _get_global_config
    class LookupModule_1(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(LookupModule_1, self).run(terms=terms,
                                                   variables=variables,
                                                   ptype=ptype,
                                                   pname=pname,
                                                   on_missing=missing)

    lookup_1 = LookupModule_1()
    result_1 = lookup_1.run(terms)

    # Test for _get_plugin_config

# Generated at 2022-06-23 11:25:26.018689
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # constructor with arg 'orig_exc'
    msg = 'some message'
    try:
        raise Exception('some exception')
    except Exception as e:
        with pytest.raises(MissingSetting) as exc:
            raise MissingSetting(msg, orig_exc=e)
        assert str(exc.value) == msg
        assert exc.value.orig_exc == e

    # constructor without arg 'orig_exc'
    msg = 'some message'
    with pytest.raises(MissingSetting) as exc:
        raise MissingSetting(msg)
    assert str(exc.value) == msg
    assert exc.value.orig_exc is None

# Generated at 2022-06-23 11:25:29.122674
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "msg"
    e = MissingSetting(msg)
    assert e.msg == msg
    assert e.orig_exc == None

# Generated at 2022-06-23 11:25:31.772406
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('lookup', 'setting_name')
    assert missing_setting.lookup == 'lookup'
    assert missing_setting.setting_name == 'setting_name'

# Generated at 2022-06-23 11:25:41.762015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.errors import AnsibleOptionsError, AnsibleLookupError
    from ansible.module_utils._text import to_text

    check = LookupModule()
    check.set_options(var_options=dict())
    result = check.run(["DEFAULT_ROLES_PATH"], dict())
    base_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '..'))
    assert result == [
        os.path.realpath(os.path.join(base_path, os.path.join("..", "..", "roles"))),
        os.path.join("/", "etc", "ansible", "roles"),
    ]

    result = check.run(["JUNK"], dict())
    assert result == []



# Generated at 2022-06-23 11:25:51.434381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with plugin_name
    plugin_name="yum"
    terms = ['port']
    host_groups=["all"]
    plugin_type = "inventory"
    lookup_plugin = LookupModule()
    print(lookup_plugin.run(terms, host_groups, plugin_name=plugin_name, plugin_type=plugin_type))

    # Test without plugin_name
    terms = ['DEFAULT_BECOME_USER']
    lookup_plugin = LookupModule()
    print(lookup_plugin.run(terms))

    # Test with invalid plugin_type
    terms = ['DEFAULT_BECOME_USER']
    plugin_type = "unknown_type"
    lookup_plugin = LookupModule()
    print(lookup_plugin.run(terms, plugin_type=plugin_type))

    # Test with

# Generated at 2022-06-23 11:26:02.206015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for terms starting with DEFAULT_
    # Argument names which are passed to functions
    # can be different than argument names which
    # are used in documentation
    lookup = LookupModule()
    # DEFAULT_SUDO_USER can return a string or a list
    # For this test case it is forced to return a string
    result = lookup.run(terms=['DEFAULT_SUDO_USER'], variables={'DEFAULT_SUDO_USER': 'test_user'})
    assert result[0] == 'test_user'
    # For this test case it is forced to return a list
    result = lookup.run(terms=['DEFAULT_SUDO_USER'], variables={'DEFAULT_SUDO_USER': ['test_user']})
    assert result[0] == ['test_user']
    # Invalid

# Generated at 2022-06-23 11:26:03.930103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 11:26:08.476938
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert isinstance(e, Exception)
        # Test that the original exception is preserved if provided
        assert isinstance(e.orig_exc, Exception)
        assert str(e) == "test"
        assert str(e.orig_exc) == "test"

# Generated at 2022-06-23 11:26:10.091180
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with MissingSetting('test') as e:
        assert e.orig_exc is None
        assert e.message == 'test'

# Generated at 2022-06-23 11:26:12.233619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH']

    # Assert if methods set_options, get_option and run are called
    assert module.run(terms) is not None

# Generated at 2022-06-23 11:26:13.649818
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('Message')
    assert isinstance(e, AnsibleOptionsError)

# Generated at 2022-06-23 11:26:15.661683
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("lookup error found")
    except MissingSetting as e:
        assert e.args[0] == "lookup error found"

# Generated at 2022-06-23 11:26:17.658501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['DEFAULT_HASH_BEHAVIOUR'])

# Generated at 2022-06-23 11:26:21.700606
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing constructor')
    try:
        LookupModule()
    except Exception as e:
        print('ERROR: Construction failed with exception %s' % e)
        return False
    return True


if __name__ == '__main__':
    print("Starting tests ...")
    print("Testing constructor ... %s" % test_LookupModule())

# Generated at 2022-06-23 11:26:22.516313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t

# Generated at 2022-06-23 11:26:23.940756
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests for empty dictionary passed to constructor

    # Tests for on_missing is not string type
    pass

# Generated at 2022-06-23 11:26:32.987360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # test variable ansible_python_interpreter
    result = module.run(["ansible_python_interpreter"], {"ansible_python_interpreter": "/usr/bin/python"})[0]
    assert result == "/usr/bin/python"
    # test config ANSIBLE_FORCE_COLOR
    result = module.run(["ANSIBLE_FORCE_COLOR"], {})[0]
    assert isinstance(result, int)
    # test plugin color callback
    result = module.run(["COLOR_OK"], {}, plugin_type="callback", plugin_name="color")[0]
    assert result == "green"
    # test plugin color callback
    result = module.run(["COLOR_CHANGED"], {}, plugin_type="callback", plugin_name="color")[0]


# Generated at 2022-06-23 11:26:36.938561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return terms
    obj = TestLookupModule()
    assert isinstance(obj, TestLookupModule)

# Generated at 2022-06-23 11:26:47.972370
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test for valid terms and ptype-pname combination
    # ptype and pname are set
    lookup_module = LookupModule()
    variables = dict()
    kwargs = dict(plugin_type='connection', plugin_name='netconf')
    lookup_module.set_options(var_options=variables, direct=kwargs)
    assert lookup_module._plugin_type == 'connection' and lookup_module._plugin_name == 'netconf'

    # ptype and pname not set
    lookup_module = LookupModule()
    variables = dict()
    kwargs = dict()
    lookup_module.set_options(var_options=variables, direct=kwargs)
    assert lookup_module._plugin_type is None and lookup_module._plugin_name is None

    # Test for invalid ptype, pname combination

# Generated at 2022-06-23 11:26:58.598707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is a very high level test that should check if _get_plugin_config and _get_global_config are called at least once for all 3 options
    import ansible.plugins.loader as plugin_loader
    from ansible.utils.sentinel import Sentinel
    import ansible.plugins.connection.ssh as plugin_ssh
    import ansible.plugins.shell.sh as plugin_sh

    def _get_plugin_config_mock(pname, ptype, config, variables):
        assert pname == 'ssh'
        assert ptype == 'connection'
        assert config == 'remote_user'
        assert variables == 'Mocked'
        return 'User'

    def _get_global_config_mock(config):
        assert config == 'COLOR_OK'
        return 'OK'


# Generated at 2022-06-23 11:27:10.085368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader, vars_loader

    lookup_loader.add_directory('./lib/ansible/plugins/lookup/')
    vars_loader.add_directory('./lib/ansible/plugins/vars/')

    lookup = lookup_loader.get('config')
    # with global configuration
    assert isinstance(lookup.run(['DEFAULT_MODULE_NAME'], {}, False)[0], string_types)
    # with global configuration (invoking with a list for wantlist=True)
    assert isinstance(lookup.run(['DEFAULT_MODULE_NAME'], {}, False), tuple)
    # with plugin_name and plugin_type

# Generated at 2022-06-23 11:27:18.546378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #global_config_value
    lookup = LookupModule()
    # case1. default setting DEFAULT_FORKS
    config_value = lookup.run(["DEFAULT_FORKS"])
    assert config_value[0] == 5
    # case2. setting remote_user
    config_value = lookup.run(["remote_user"])
    assert config_value[0] == ""
    # case3. setting SUPPRESS_ANNOYING_WARNINGS
    config_value = lookup.run(["SUPPRESS_ANNOYING_WARNINGS"])
    assert config_value[0] == False
    # case4. setting UNKNOWN
    try:
        lookup.run(["UNKNOWN"])
    except AnsibleLookupError:
        pass
    else:
        assert False
    # case5. setting PATTERN_ERRORS

# Generated at 2022-06-23 11:27:19.580240
# Unit test for constructor of class LookupModule
def test_LookupModule():
  l = LookupModule()

# Generated at 2022-06-23 11:27:29.803897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    # set up test data
    terms = ['COLORS_DEBUG']
    variables = {}
    ptype = 'callback'
    pname = 'json'

    # set up test object
    lookup_obj = LookupModule()

    # call method to be tested
    result = lookup_obj.run(terms, variables, plugin_type=ptype, plugin_name=pname)

    # assert that correct result was returned
    assert result == [False], "The result should be [False] but is %s" % result

    # set up test data
    terms = ['RETRY_FILES_ENABLED']
    variables = {}
    ptype = 'connection'
    pname = 'ssh'

    # set up test object
    lookup_obj = LookupModule()

    # call method to be tested

# Generated at 2022-06-23 11:27:31.059157
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    pass

# Generated at 2022-06-23 11:27:38.899697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    terms = ['action_plugins', 'lookup_plugins']
    variables = {'_ansible_config': 'ansible.cfg'}
    kwargs = {}
    p = LookupModule()
    a = p.run(terms, variables, **kwargs)
    assert a is not None
    assert 'action_plugins' in a[0]
    assert 'lookup_plugins' in a[1]

# Generated at 2022-06-23 11:27:47.128635
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:27:58.746325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', elements='str', required=True),
            on_missing=dict(type='str', default='error', choices=['error', 'skip', 'warn']),
            plugin_type=dict(type='str', choices=['become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars']),
            plugin_name=dict(type='str'),
        ),
        supports_check_mode=True
    )

    terms = module.params['_terms']
    plugin_type = module.params['plugin_type']
    plugin_name = module.params['plugin_name']

    # Prepare an instance of LookupModule

# Generated at 2022-06-23 11:28:00.513157
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('some_msg', 'some_exc').__str__() == 'some_msg'

# Generated at 2022-06-23 11:28:01.786810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:28:09.595958
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Started test_LookupModule')
    lookup_module = LookupModule()
    result = lookup_module.run(['DEFAULT_BECOME_USER'], None, on_missing='error')
    print(result)
    lookup_module = LookupModule()
    result = lookup_module.run(['DEFAULT_BECOME_USER = None'], None, on_missing='error')
    print(result)
    print('Completed test_LookupModule')


# Generated at 2022-06-23 11:28:17.826348
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    class invalid_config:
        def __init__(self):
            invalid_config.message = 'Invalid config'
            invalid_config.name = 'invalid_config'

    try:
        raise MissingSetting('invalid_config')
    except MissingSetting as e:
        assert 'Unable to find setting invalid_config' == to_native(e)
        assert e.orig_exc == None

    try:
        raise MissingSetting('invalid_config', orig_exc=invalid_config())
    except MissingSetting as e:
        assert 'Unable to find setting invalid_config' == to_native(e)
        assert e.orig_exc is not None