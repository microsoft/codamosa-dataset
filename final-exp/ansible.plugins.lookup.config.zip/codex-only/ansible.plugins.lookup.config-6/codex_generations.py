

# Generated at 2022-06-23 11:18:21.200325
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    lookup = LookupModule()
    msg = 'test msg'

    try:
        lookup.run(terms=['test'])
    except AnsibleLookupError as e:
        msg = to_native(e)
        assert msg.startswith('Unable to find setting test')
        assert ('UNKNOWN' in msg or 'UNDEFINED' in msg)

    try:
        lookup.run(terms=['test'], variables={'UNKNOWN': 'test'})
    except AnsibleLookupError as e:
        msg = to_native(e)
        assert msg.startswith('Unable to find setting test')
        assert ('UNKNOWN' in msg or 'UNDEFINED' in msg)


# Generated at 2022-06-23 11:18:25.349132
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_message = "Error Message"
    exception = Exception("Exception Message")
    missing_setting = MissingSetting(error_message, exception)

    assert isinstance (missing_setting, AnsibleLookupError)
    assert str(missing_setting) == error_message
    assert missing_setting.orig_exc == exception

# Generated at 2022-06-23 11:18:30.104171
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    from ansible.errors import AnsibleError
    import ansible.module_utils._text as to_text

    error = MissingSetting('The setting is missing!')
    assert error.message == 'The setting is missing!'
    assert error.orig_exc is None

    error = MissingSetting('The setting is missing!', orig_exc=AnsibleError('Test'))
    assert error.message == 'The setting is missing!'
    assert error.orig_exc.message == to_text.exception_message(AnsibleError('Test'))

# Generated at 2022-06-23 11:18:38.925584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  # set up class
    lm = LookupModule()
    #  # setup a fake ansible.constants object
    #  # first use of ansible.constants is used as an example of how to use 'sentinal'
    class const():
        def __init__(self):
            self.test_sentinal = Sentinel
    C = const()
    #  # now use a real value for C to use for testing
    C.test_sentinal = 'test_sentinal'
    C.test_global = 'test_global'
    #  # setup a fake ansible.plugins.loader.connection_loader object
    class connection():
        def __init__(self):
            self.test_connection = None
        def get(self, name, class_only=True):
            return self.test_connection
    # 

# Generated at 2022-06-23 11:18:47.852440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # object for LookupModule
    lookup_instance = LookupModule()

    # test for when config value is not a string
    with pytest.raises(AnsibleOptionsError) as error:
        lookup_instance.run(['LM_SHORT_DESCR', 1, 2, 3], None, **{'on_missing': 'error'})
    assert error.value.message == 'Invalid setting identifier, "1" is not a string, its a ' \
                                  '<class \'int\'>'

    # test for when on_missing is not an expected string
    with pytest.raises(AnsibleOptionsError) as error:
        lookup_instance.run(['LM_SHORT_DESCR'], None, **{'on_missing': 'flip'})

# Generated at 2022-06-23 11:18:51.606220
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "configuration error"
    try:
        raise MissingSetting(msg)
    except AnsibleOptionsError as e:
        assert msg in e.message
        assert isinstance(e, MissingSetting)

# Generated at 2022-06-23 11:18:58.283686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create fake values for plugin name and type
    pname = 'ssh'
    ptype = 'connection'

    # create a fake 'terms' list with key values
    terms = [
        'port',
        'remote_user',
    ]

    # get the lookup module and call the run function
    lookup = LookupModule()
    result = lookup.run(terms, plugin_name=pname, plugin_type=ptype)

    # assert that result is a dictionary and that it is not empty
    assert isinstance(result, list)
    assert len(result) > 0

# Generated at 2022-06-23 11:19:00.869695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance is not None


# Generated at 2022-06-23 11:19:11.130137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # defining a mock method
    class Myclass:
        def __init__(self):
            self.result = Sentinel
    myobj = Myclass()
    method_name = [
        '_get_global_config',
        '_get_plugin_config']

    # replacing _get_global_config and _get_plugin_config by mock methods
    # so that they can be controlled and tested separately

# Generated at 2022-06-23 11:19:16.269178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_module = LookupModule()
    result = my_lookup_module.run(('COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'), {'on_missing': 'skip'}, wantlist=True)
    assert result == [u'\033[0;32m', u'\033[0;36m', u'\033[0;33m']

# Generated at 2022-06-23 11:19:18.237415
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missingSetting = MissingSetting('test')
    assert missingSetting.message == 'test'
    assert missingSetting.orig_exc == None

# Generated at 2022-06-23 11:19:19.189826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()

# Generated at 2022-06-23 11:19:29.478889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([ 'DEFAULT_ROLES_PATH', 'UNKNOWN_TERM'], on_missing='error')
    assert result == [C.DEFAULT_ROLES_PATH]
    result = lookup.run([ 'DEFAULT_ROLES_PATH', 'UNKNOWN_TERM'], on_missing='warn')
    assert result == [C.DEFAULT_ROLES_PATH]
    result = lookup.run([ 'DEFAULT_ROLES_PATH', 'UNKNOWN_TERM'], on_missing='skip')
    assert result == [C.DEFAULT_ROLES_PATH]
    lookup = LookupModule()
    result = lookup.run([ 'UNKNOWN_TERM'], on_missing='error')
    assert result == []

# Generated at 2022-06-23 11:19:32.664236
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'this is a test'
    e = LookupError(msg)
    m = MissingSetting(msg, orig_exc=e)
    assert m.orig_exc == e

# Generated at 2022-06-23 11:19:43.051759
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_modules = [
        "config",
        "hg",
        "fileglob",
        "env",
        "path",
        "puppet",
        "password",
        "redis_kv",
        "file",
        "csvfile"
    ]
    for lookup_module in lookup_modules:
        try:
            LookupModule(loader=None, templar=None, loader_available_vars={}, lookup_loader=None, config_manager=None)
        except TypeError as e:
            raise AssertionError("%s lookup module is not a valid LookupBase" % lookup_module)

# Generated at 2022-06-23 11:19:53.328001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize class for testing
    lookup_module = LookupModule()

    # Test with all valid parameters
    terms = ['RETRY_FILES_ENABLED']
    ret = lookup_module.run(terms, variables=None, on_missing='error', plugin_type='connection', plugin_name='ssh')
    #assert(ret[0] == True)

    # Test with valid parameters and no plugin
    terms = ['RETRY_FILES_ENABLED']
    ret = lookup_module.run(terms, variables=None, on_missing='error')
    #assert(ret[0] == True)

    # Test with an invalid parameter
    terms = ['KEY_DOES_NOT_EXIST']
    ret = lookup_module.run(terms, variables=None, on_missing='error')
    assert(ret == [])



# Generated at 2022-06-23 11:19:55.484285
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting('foo', 'bar')
    assert result.arg == 'foo'
    assert result.orig_exc == 'bar'

# Generated at 2022-06-23 11:19:57.465424
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    class_exception = MissingSetting('Setting Not found', orig_exc=None)
    assert isinstance(class_exception, AnsibleOptionsError)

# Generated at 2022-06-23 11:20:03.748569
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Constructor of class MissingSetting works as expected"""

    # pylint: disable=redefined-variable-type
    # pylint has a bug where it thinks the object is not a MissingSetting

    m = MissingSetting('test')
    assert m.message == 'test'
    assert m.orig_exc is None

    m = MissingSetting('test2', orig_exc=m)
    assert m.message == 'test2'
    assert isinstance(m.orig_exc, MissingSetting)

# Generated at 2022-06-23 11:20:08.859346
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Error: foo not defined", "foo", "bar")
    except MissingSetting as e:
        assert "Error: foo not defined" == str(e)
        assert "foo" == e.setting
        assert "bar" == e.orig_exc

# Generated at 2022-06-23 11:20:11.870693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule

    result = LookupModule.run(['DEFAULT_BECOME_USER'])
    assert result == ['root']

# Generated at 2022-06-23 11:20:20.672172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    module = LookupModule()
    cm = config_mock.ConfigMock()

    assert module.run("ACME_SETTING_A", {}) == cm.ACME_SETTING_A
    assert module.run("ACME_SETTING_B", {}) == cm.ACME_SETTING_B
    assert module.run("ACME_SETTING_C", {}) == cm.ACME_SETTING_C

    assert module.run("too_much_for_one_setting", {}) == cm.too_much_for_one_setting

    # No value set - don't fail
    assert module.run("ACME_SOMETHING", {"ACME_SOMETHING_ERROR": "hide"}) is None

    # This is a fake config!
   

# Generated at 2022-06-23 11:20:22.579346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([])
    assert result == [], "Result is not empty when it should be"

# Generated at 2022-06-23 11:20:24.562728
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('not set')
    assert missing_setting.args[0] == 'not set'

# Generated at 2022-06-23 11:20:28.446260
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    lm = LookupModule()

    # Run method 'run' of class LookupModule
    result = lm.run(['ipv6'])

    # Check result
    assert result == [True]

# Generated at 2022-06-23 11:20:29.872674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = None
    assert lookup is None

# Generated at 2022-06-23 11:20:38.791254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global __file__
    __file__ = 'ansible/plugins/lookup/config.py'
    # Suppress deprecation warning
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning, module=r'.*ansible.modules.core.package_mgr')

    data = {
             'plugin_type': 'cliconf',
             'plugin_name': 'eos',
             'terms': 'device_type',
             'expected': 'eos'
           }

    l = LookupModule()
    ret = l.run(data['terms'], None, plugin_type=data['plugin_type'], plugin_name=data['plugin_name'])
    assert (ret[0] == data['expected'])

# Generated at 2022-06-23 11:20:40.268146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup.handle_unknown and 'only_if' in lookup.handle_unknown)

# Generated at 2022-06-23 11:20:41.436807
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:20:45.464949
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Missing setting")
    except MissingSetting as e:
        assert e.klass_name == "MissingSetting"
        assert e.message == "Missing setting"

# Generated at 2022-06-23 11:20:47.723360
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('test error')
    assert error.message == 'test error'
    assert error.orig_exc is None

# Generated at 2022-06-23 11:20:57.008427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({})

    assert lookup_module.run([]) == [] 

    # with error
    assert lookup_module.run(['a']) == []

    # with warn
    lookup_module.set_options({'on_missing': 'warn'})
    assert lookup_module.run(['a']) == []

    # with skip
    lookup_module.set_options({'on_missing': 'skip'})
    assert lookup_module.run(['a']) == []

    # with error, but valid term
    lookup_module.set_options({'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_ROLES_PATH']) != []

    # with warn, but valid term
    lookup_module.set_options

# Generated at 2022-06-23 11:21:04.236340
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting("Foo")
    assert err.orig_exc == None
    assert str(err) == "Foo"
    assert repr(err) == str("AnsibleOptionsError('Foo')")
    err = MissingSetting("Foo", orig_exc="Bar")
    assert err.orig_exc == "Bar"
    assert str(err) == "Foo"
    assert repr(err) == str("AnsibleOptionsError('Foo')")

# Generated at 2022-06-23 11:21:13.365378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # test with plugin_type and plugin_name in args
    test = dict(
        plugin_type = 'cliconf',
        plugin_name = 'ios',
        terms = ['host', 'username', 'password'],
        variables = {}
    )
    assert module.run(**test) == [u'{{ lookup("env", "ANSIBLE_NET_HOST") | default(omit) }}', u'{{ lookup("env", "ANSIBLE_NET_USERNAME") | default(omit) }}', u'{{ lookup("env", "ANSIBLE_NET_PASSWORD") | default(omit) }}']
    # test with plugin_type and plugin_name in kwargs

# Generated at 2022-06-23 11:21:15.720422
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting(msg='invalid')
    # Testing constructor with MSG option
    assert missing_setting.options['msg'] == 'invalid'

# Generated at 2022-06-23 11:21:17.460449
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting('msg')
    assert obj.msg == 'msg'

# Generated at 2022-06-23 11:21:19.295770
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    x = MissingSetting("msg")
    assert x.message == "msg"

# Generated at 2022-06-23 11:21:30.206039
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception_msg = '''Exception Error'''
    exception_obj = Exception(exception_msg)

    exception_type = '''Exception Type'''
    exception_msg1 = '''Exception Error1'''

    class TestException(Exception):
        pass

    try:
        raise TestException(exception_msg1)
    except TestException as e:
        pass

    exception_obj1 = e

    try:
        raise MissingSetting(exception_type, orig_exc=exception_obj)
    except MissingSetting as e:
        pass

    exception_obj2 = e

    try:
        raise MissingSetting(orig_exc=exception_obj1)
    except MissingSetting as e:
        pass

    exception_obj3 = e

    assert exception_obj2.orig_exception == exception_obj
    assert exception_

# Generated at 2022-06-23 11:21:35.368545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test error handling
    def run_error(message):
        try:
            LookupModule().run(terms=['missing'])
            assert False
        except AnsibleLookupError as e:
            assert message in to_native(e)

    run_error('Unable to find setting missing')

    # TODO: Test with valid terms

# Generated at 2022-06-23 11:21:36.586632
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 11:21:40.580066
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # test that the global plugin loader objects were created (noting that each is a singleton)
    assert lm.global_plugin_loader is not None

# Unit tests for _get_global_config

# Generated at 2022-06-23 11:21:52.682111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    ##Error
    try:
        lookup.run(['test'], [])
        assert False
    except AnsibleLookupError:
        assert True
    except Exception:
        assert False

    ##Missing
    try:
        lookup.run(['test'], [], on_missing='missing')
        assert False
    except AnsibleLookupError:
        assert True
    except Exception:
        assert False

    ##Skip
    try:
        lookup.run(['test'], [], on_missing='skip')
        assert True
    except Exception:
        assert False

    ##Warn
    try:
        lookup.run(['test'], [], on_missing='warn')
        assert False
    except AnsibleLookupError:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-23 11:21:56.738489
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'this is a test message'
    base_exc = Exception()
    exc = MissingSetting(msg, orig_exc=base_exc)
    assert exc.message == msg
    assert exc.orig_exc == base_exc
    assert exc.to_native() == msg

# Generated at 2022-06-23 11:22:08.034414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''

# Generated at 2022-06-23 11:22:10.505552
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    assert lookup_module.run([]) == []

    assert lookup_module.run(['unknown']) == []


# Generated at 2022-06-23 11:22:20.182123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['color_changed']
    # testcase 1:
    # plugin_type = 'connection'
    # plugin_name = 'ssh'

    # testcase 2:
    # plugin_type = 'shell'
    # plugin_name = 'sh'

    # testcase 3:
    # on_missing = 'error'

    # testcase 4:
    # on_missing = 'warn'

    # testcase 5:
    # on_missing = 'skip'

    lm = LookupModule()
    result = lm.run(terms, plugin_type='connection', plugin_name='ssh')
    assert result[0] == C.COLOR_CHANGED
    result = lm.run(terms, plugin_type='shell', plugin_name='sh')
    assert result[0] == C.COLOR_CHANGED


# Generated at 2022-06-23 11:22:21.068198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 11:22:23.494396
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
# Unit tests for run method

# Generated at 2022-06-23 11:22:34.160180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Options():
        def __init__(self):
            self.plugin_type = None
            self.plugin_name = None
            self.on_missing = None

    class VariableManager():
        def __init__(self):
            self.vars = None

    class Display():
        def __init__(self):
            self.verbosity = None
            self.warning = None
            self.colorize = None

    class FakeLoader():
        def __init__(self):
            self.plugins = None
            self.module_utils_paths = None

        def get(self, name=None, class_only=None):
            return FakePlugin()

    class FakePlugin():
        def __init__(self):
            self._load_name = None

    variable_manager = VariableManager()
    options = Options()
    display

# Generated at 2022-06-23 11:22:45.011244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Inventory:
        def __init__(self):
            self.host_list = {}

        def get_hosts(self, pattern="all"):
            return ["localhost"]

        def get_related_hosts(self, host):
            return []

        def get_groups_dict(self):
            return {}

    class PlayContext:
        def __init__(self):
            self.network_os = 'ios_cli'
            self.remote_addr = '127.0.0.1'
            self.become = True
            self.become_user = "admin"
            self.become_method = 'enable'
            self.become_pass = 'secret'
            self.remote_user = "admin"
            self.connection = 'network_cli'
            self.timeout = 5


# Generated at 2022-06-23 11:22:45.763538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:22:47.627306
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    settings = MissingSetting("test", 1)
    assert settings.message == "test"
    assert settings.orig_exc == 1

# Generated at 2022-06-23 11:22:51.292447
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    def f():
        raise MissingSetting('test exception')
    try:
        f()
    except MissingSetting as e:
        assert 'test exception' == str(e)

# Generated at 2022-06-23 11:22:53.876543
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """
    Generate the MissingSetting exception
    """
    msg = 'Failed to get something'
    exc = MissingSetting(msg)
    assert msg == str(exc)

# Generated at 2022-06-23 11:22:56.379816
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    argument = 'logfile'
    message = 'Lookup module config was unable to find the requested setting (%s).' % argument
    ms = MissingSetting(message)
    assert ms.message == message
    assert ms.argument == argument

# Generated at 2022-06-23 11:22:57.533702
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)

# Generated at 2022-06-23 11:23:00.157999
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:23:10.402323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.set_loader(None)
    lookup_instance.set_env(None)
    lookup_instance.set_templar(None)
    lookup_instance.set_basedir(None)
    lookup_instance.set_collections_paths([])

    # success: ret will be an array containing the value
    ret = lookup_instance.run(terms=["DEFAULT_ROLES_PATH"])
    assert ret[0] == C.DEFAULT_ROLES_PATH

    # success: ret will be an empty array
    ret = lookup_instance.run(terms=["DEFAULT_FORKS"])
    assert ret[0] == C.DEFAULT_FORKS

    # failure: ret will be an exception

# Generated at 2022-06-23 11:23:12.323709
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test exception')
    except MissingSetting as e:
        assert e

# Generated at 2022-06-23 11:23:20.507244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test on missing skip, term=DEFAULT_BECOME_USER, config is available
    res = lookup.run(terms=['DEFAULT_BECOME_USER'], on_missing='skip')
    assert res == [C.DEFAULT_BECOME_USER]

    # Test on missing error, term=DEFAULT_BECOME_USER, config is available
    res = lookup.run(terms=['DEFAULT_BECOME_USER'], on_missing='error')
    assert res == [C.DEFAULT_BECOME_USER]

    # Test on missing warn, term=DEFAULT_BECOME_USER, config is available
    res = lookup.run(terms=['DEFAULT_BECOME_USER'], on_missing='warn')

# Generated at 2022-06-23 11:23:25.726471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Expected results from the different options for the constructor of the class LookupModule:
        - On_missing='error'
            - raise error if the setting is not found
        - On_missing='warn'
            - raise warning if the setting is not found
        - On_missing='skip' (default)
            - return None if the setting is not found
    """
    c = LookupModule()
    # Test LookupModule constructor with on_missing=error
    try:
        c.run(['invalid_setting'], dict(), dict(), on_missing='error')
    except AnsibleLookupError:
        pass
    except:
        assert False
    # Test LookupModule constructor with on_missing=warn

# Generated at 2022-06-23 11:23:27.042103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(['DEFAULT_BECOME_USER'])
    assert ret == ['root']

# Generated at 2022-06-23 11:23:31.330660
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import constants as C
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.color import stringc
    import ansible.plugins.loader as plugin_loader


# Generated at 2022-06-23 11:23:43.525899
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:23:55.633738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    d = dict(plugin_type="connection", plugin_name="ssh", on_missing="warn")
    ret = LookupModule().run([], d)
    assert ret == []
    ret = LookupModule(vars=dict(remote_user='root')).run([], d)
    assert ret == []
    ret = LookupModule(vars=dict(remote_user='root')).run(['port'], d)
    assert ret == [22]
    ret = LookupModule(vars=dict(remote_user='root')).run(['port', 'remote_tmp'], d)
    assert ret == [22, "/tmp/ansible-${USER}"]
    ret = LookupModule(vars=dict(remote_user='root')).run(['foo'], d)
    assert ret == []
    ret = Look

# Generated at 2022-06-23 11:23:57.345251
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting('Fail')

# Generated at 2022-06-23 11:23:58.323430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:24:00.865115
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert e.message == "test"
        assert e.orig_exc is None

# Generated at 2022-06-23 11:24:07.202699
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test with no args
    try:
        raise MissingSetting
    except Exception as e:
        pass

    # Test with a message and no orig_exc
    try:
        raise MissingSetting('A test message')
    except Exception as e:
        pass

    # Test with a message and an orig_exc
    try:
        raise MissingSetting('A test message', orig_exc=Exception('A fake exception'))
    except Exception as e:
        pass

# Generated at 2022-06-23 11:24:09.332023
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missingSetting = MissingSetting()
    should_be_none = missingSetting.orig_exc

    assert should_be_none is None

# Generated at 2022-06-23 11:24:11.403490
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.kwargs['msg'] == 'test'

# Generated at 2022-06-23 11:24:19.636340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO

    fake_display = StringIO()
    lookup_base = LookupModule.LookupBase(None, fake_display)

    lookup_instance = LookupModule()
    lookup_instance.set_loader(None)
    lookup_instance.set_basedir(None)
    lookup_instance.set_display(fake_display)

    # Test for missing setting
    term = 'NOT_DEFINED'
    fake_variables = dict(lookup_plugin='config')
    options = dict(on_missing='error', plugin_type=None, plugin_name=None, var_options=fake_variables)
    with pytest.raises(AnsibleLookupError) as err:
        lookup_instance.run(terms=[term], variables=fake_variables, **options)

# Generated at 2022-06-23 11:24:29.033794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([], {}) == []
    assert LookupModule().run(["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"], {"inventories": []}) == ['root', ['roles', '/usr/share/ansible/roles']]
    assert LookupModule().run(["DEFAULT_BECOME_USER"], {"inventories": []}) == ['root']
    assert LookupModule().run(["RETRY_FILES_SAVE_PATH"], {"inventories": [], "playbook_dir": '/usr/home/test'}) == ['/usr/home/test']
    assert LookupModule().run(["PLAYBOOK_DIRECTORY"], {"inventories": []}) == [None]

# Generated at 2022-06-23 11:24:30.453212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None)

# Generated at 2022-06-23 11:24:32.929757
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_module = LookupModule()
    except:
        raise AssertionError("unable to instantiate LookupModule object")


# Generated at 2022-06-23 11:24:34.642795
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test message')
    except MissingSetting as e:
        assert e.message == 'test message'
        assert isinstance(e.orig_exc, AttributeError)

# Generated at 2022-06-23 11:24:42.073273
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # test with exc_info = None
    missing_setting_obj = MissingSetting('test1')
    assert missing_setting_obj.message == 'Ansible options error detected: test1'
    # test with exc_info = Exception object
    error_obj = AnsibleOptionsError('test2')
    missing_setting_obj = MissingSetting('test3', error_obj)
    assert missing_setting_obj.message == 'Ansible options error detected: test3: test2'
    # test with exc_info = (Exception type, Exception value, Exception traceback)
    error_obj_type = AnsibleOptionsError('test4')
    error_obj_val = AnsibleOptionsError('test5')
    error_obj_tback = AnsibleOptionsError('test6')

# Generated at 2022-06-23 11:24:52.222943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    options = {'on_missing': 'error'}
    # Test with one term
    term = "RETRY_FILES_SAVE_PATH"
    result = lookup.run(terms=term, variables=options, direct=None)
    assert result == [u'~/.ansible/retry']

    # Test with multiple terms
    terms = []
    terms.append("RETRY_FILES_SAVE_PATH")
    terms.append("DEFAULT_ROLES_PATH")
    result = lookup.run(terms=terms, variables=options, direct=None)
    assert result == [u'~/.ansible/retry', [u'/etc/ansible/roles', u'~/.ansible/roles', u'/usr/share/ansible/roles']]

# Generated at 2022-06-23 11:24:55.357246
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("key", "msg")
    assert e.key == "key"
    assert e.msg == "msg"
    assert e.orig_exc == None

# Generated at 2022-06-23 11:24:58.475453
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting('this is a test', 'unittest')
    assert str(ms) == "this is a test"
    assert ms.orig_exc == 'unittest'

# Generated at 2022-06-23 11:25:08.135851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin._templar = Dictable()

    # Test case when on_missing is error
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_plugin.run(terms=["foo"], variables=dict(), on_missing="not_error_or_warn_or_skip")
    assert to_native(e.value) == '"on_missing" must be a string and one of "error", "warn" or "skip", not not_error_or_warn_or_skip'

    with pytest.raises(AnsibleOptionsError) as e:
        lookup_plugin.run(terms=["foo"], variables=dict(), on_missing=123)

# Generated at 2022-06-23 11:25:09.156067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:25:09.741521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:25:16.826711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ('staging', )
    variables = {'staging': 'true', 'inventory': '/etc/ansible/hosts.ini'}
    kwargs = {
        '_ansible_socket': socket,
        '_ansible_start_time': time()
    }
    l = LookupModule()

    try:
        l.run(terms, variables, **kwargs)
    except AnsibleLookupError as ae:
        msg = ae.message
        assert 'Invalid setting identifier' in msg
        assert 'True' in msg
        assert 'str' in msg

    terms = ('inventory', )
    variables = {'staging': 'true', 'inventory': '/etc/ansible/hosts.ini'}

# Generated at 2022-06-23 11:25:20.281686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Try to initialize LookupModule class
    try:
        l = LookupModule()
    except:
        l = None
    assert l is not None

# Generated at 2022-06-23 11:25:21.729423
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting()

# Generated at 2022-06-23 11:25:32.268386
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # check if required terms is provided
    terms = None
    try:
        LookupModule().run(terms)
    except AnsibleOptionsError as e:
        assert(e.to_native() == 'Missing required terms argument')

    # check if on_missing option is valid
    terms = ['DEFAULT_ROLES_PATH']
    on_missing = 'invalid'

    try:
        LookupModule().run(terms, on_missing=on_missing)
    except AnsibleOptionsError as e:
        assert(e.to_native() == '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid')

    # check if plugin_type and plugin_name are both provided
    terms = ['remote_tmp']
    on_missing = 'warn'

# Generated at 2022-06-23 11:25:42.240167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import the plugin class
    from ansible.plugins.lookup import Config

    lookup = Config()

    # test normal case
    assert lookup.run(["DEFAULT_ROLES_PATH"], None) == [
        '/etc/ansible/roles:/usr/share/ansible/roles']

    # test option 'on_missing'
    # normal case, on_missing = 'error'
    with pytest.raises(AnsibleLookupError):
        lookup.run(["DEFAULT_ROLES_PATH_TEST"], None)
    # on_missing = 'warn'
    assert lookup.run(["DEFAULT_ROLES_PATH_TEST"], None, on_missing='warn') == []
    # on_missing = 'skip'

# Generated at 2022-06-23 11:25:44.450840
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('msg')
    except MissingSetting as e:
        assert e.message == 'msg'
        assert e.orig_exc is None

# Generated at 2022-06-23 11:25:46.945514
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # just create it, no particular reason for following args
    MissingSetting('Test', orig_exc=None)

# Generated at 2022-06-23 11:25:58.415571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockAnsibleModule:
        def fail_json(self, *args, **kwargs):
            raise AnsibleError(args[0])
    module = MockAnsibleModule()
    lookup_module = LookupModule()

    arguments = {
        "plugin_type": "inventory",
        "plugin_name": "yaml"
    }
    yaml_source = "test.yml"
    result = lookup_module.run([yaml_source], None, **arguments)
    assert result == [
        "{}/test.yml".format(C.DEFAULT_ROLES_PATH),
        "{}/test.yml".format(C.DEFAULT_ROLES_PATH),
        "{}/test.yml".format(C.DEFAULT_ROLES_PATH)
    ]

    arguments

# Generated at 2022-06-23 11:26:00.325216
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('A', 'B')
    assert str(MissingSetting('A', 'B')) == 'A'
    assert MissingSetting('A', 'B').orig_exc == 'B'

# Generated at 2022-06-23 11:26:05.434976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.sentinel import Sentinel
    c = LookupModule()
    c.set_options(direct=dict(debug=False))
    assert c
    assert isinstance(c.get_option('debug'), bool)
    assert c.get_option('debug') == False
    assert c.get_option('undefined') is None
    assert c.get_option('undefined', default='foo') == 'foo'
    assert c.get_option('undefined', default=None) is None
    assert c.get_option('undefined', default=Sentinel) is Sentinel


# Generated at 2022-06-23 11:26:15.163318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    class FakeConfig():
        ANSIBLE_FORCE_COLOR = True

    class FakeDisplay():
        def __init__(self, *kwargs, **kwargs2):
            pass

        def warning(self, text):
            print(text)
            sys.exit()

    class FakeLookupModule():
        def __init__(self, *kwargs, **kwargs2):
            self._display = FakeDisplay()
            self.set_options(var_options=None, direct=None)

        def get_option(self, key):
            return None

        def set_options(self, var_options=None, direct=None):
            pass

    class FakeVariables():
        def __init__(self):
            self.my_plugins = 'my_plugins'

# Generated at 2022-06-23 11:26:24.146173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import contextlib
    import tempfile
    import shutil
    import os

    with tempfile.NamedTemporaryFile() as f:
        with tempfile.TemporaryDirectory() as d:
            d_out = os.path.join(d, 'out')
            shutil.copytree(sys.path[0] + '/../testsuite/test_data/test_ansible_config', d_out)

# Generated at 2022-06-23 11:26:29.441320
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # test constructor with message
    x = MissingSetting('message')
    assert x is not None
    # test constructor with message and original exception
    from io import UnsupportedOperation
    import sys
    try:
        fp = open('/does/not/exist', 'rb')
    except Exception as exc:
        x = MissingSetting('message', orig_exc=exc)
        assert x is not None

# Generated at 2022-06-23 11:26:32.375170
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting('error message')
    assert err.message == 'error message'
    assert isinstance(err.orig_exc, AnsibleError)

# Generated at 2022-06-23 11:26:35.349091
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    class_args = ("test",)
    class_kwargs = {}
    assert MissingSetting(*class_args, **class_kwargs)

# Generated at 2022-06-23 11:26:36.530445
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup=LookupModule()
    assert True

# Generated at 2022-06-23 11:26:44.645244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {}
    assert module.run(terms, variables, **kwargs) == [C.DEFAULT_BECOME_USER]

    module = LookupModule()
    variables = {}

    # try calling with no parameters
    kwargs = {}
    with pytest.raises(AnsibleOptionsError) as exc:
        assert module.run(terms, variables, **kwargs)
        assert str(exc) == '"on_missing" must be a string and one of "error", "warn" or "skip", not None'

    # try calling with invalid parameters
    kwargs = {'on_missing':'huh'}

# Generated at 2022-06-23 11:26:48.223299
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('lookup failed')
    except AnsibleLookupError as e:
        assert isinstance(e, AnsibleLookupError)
        assert isinstance(e, AnsibleOptionsError)
    else:
        assert False, "MissingSetting not thrown"

# Generated at 2022-06-23 11:26:52.956342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # use a local config file with a defined DEFAULT_ROLES_PATH
    cnf = 'test/test-config/test-config.yml'
    _m = LookupModule(cnf)
    res = _m.run(['DEFAULT_ROLES_PATH'])
    assert len(res) == 1
    assert isinstance(res[0], list)
    assert len(res[0]) > 0
    assert '/tmp/roles1' in res[0]

# Generated at 2022-06-23 11:26:55.463230
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys

    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    options = {}
    lookup.run(terms, variables, **options)

    assert sys.exc_info() == (None, None, None)

# Generated at 2022-06-23 11:26:59.245974
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ansible_error = MissingSetting('foo')
    assert ansible_error.message == 'foo'
    assert ansible_error.orig_exc is None
    assert ansible_error.args == ('foo',)
    assert str(ansible_error) == 'foo'

# Generated at 2022-06-23 11:27:01.158826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:27:10.631258
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2}
    exc = Exception("Missing setting for example")
    msg = "Test exception"

    m = MissingSetting(msg, *args, **kwargs)
    assert m.message == msg
    assert m.args == args
    assert m.kwargs == kwargs

    m = MissingSetting(msg, orig_exc=exc, *args, **kwargs)
    assert m.message == msg
    assert m.args == args
    assert m.kwargs == kwargs
    assert m.orig_exc == exc

# Generated at 2022-06-23 11:27:19.880307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # expects a config setting that does not exist
    # invokes run with on_missing set to 'warn'
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader

    terms = ['DOES-NOT-EXIST-ANYWHERE']
    variables = {'var_name': 'value'}
    plugin = LookupModule()
    plugin.set_input(terms)
    plugin.set_loader(DataLoader())
    plugin.set_available_variables(variables)
    plugin.set_options(var_options=variables, direct=ImmutableDict({'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'warn'}))
    lookup_result = plugin.run()

# Generated at 2022-06-23 11:27:21.016877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-23 11:27:22.559695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, 'This test needs to be filled out'

# Generated at 2022-06-23 11:27:31.453704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # plugin_type and plugin_name must be provided together
    # test case where plugin_name is provided without plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_name': 'ssh', 'on_missing': 'skip'})
    try:
        lookup_module.run(['port'])
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError('AnsibleOptionsError should be raised if plugin_name is provided without plugin_type')

    # test case where plugin_type is provided without plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'on_missing': 'skip'})

# Generated at 2022-06-23 11:27:42.656028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]
    assert LookupModule(vars={}).run(terms=['DEFAULT_GATHERING']) == [C.DEFAULT_GATHERING]
    assert LookupModule(vars={'DEFAULT_REMOTE_TMP': '/my/tmp'}).run(terms=['DEFAULT_REMOTE_TMP']) == ['/my/tmp']
    assert LookupModule(vars={'DEFAULT_REMOTE_TMP': '/my/tmp'}).run(terms=['DEFAULT_REMOTE_TMP', 'DEFAULT_BECOME_METHOD']) == ['/my/tmp', 'sudo']

# Generated at 2022-06-23 11:27:45.644540
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    opt_err = AnsibleOptionsError('opt err message')
    assert issubclass(MissingSetting, AnsibleOptionsError)
    m = MissingSetting('message', opt_err)
    assert m.message == 'message'
    assert m.orig_exc == opt_err

# Generated at 2022-06-23 11:27:46.940513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 11:27:49.149834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 11:27:55.465904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_ins = LookupModule()
    result = lookup_ins.run(['DEFAULT_REMOTE_USER'],{})
    assert(result == C.DEFAULT_REMOTE_USER)

    # Testing on error mode
    test_result = lookup_ins.run(['remote_tmp', 'remote_tmp1'], {})

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:27:56.095017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0

# Generated at 2022-06-23 11:27:58.742048
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "ABC"
    orig_exc = "XYZ"
    c = MissingSetting(msg, orig_exc)
    assert c.msg == msg
    assert c.orig_exc == orig_exc

# Generated at 2022-06-23 11:27:59.579444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-23 11:28:03.855559
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    expected_msg = 'This is a test message'
    expected_exception = AttributeError('test exception')
    exception = MissingSetting(expected_msg, expected_exception)

    assert exception.args[0] == expected_msg
    assert exception.orig_exc == expected_exception

# Generated at 2022-06-23 11:28:05.523485
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test')
    assert m.message == 'test'

# Generated at 2022-06-23 11:28:07.497981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupBase)

# Generated at 2022-06-23 11:28:12.815253
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Constructor raises an error when called without an argument
    try:
        raise MissingSetting
    except TypeError:
        pass

    # Constructor raises an error when called with a non-string argument
    try:
        raise MissingSetting(None)
    except (TypeError, ValueError):
        pass