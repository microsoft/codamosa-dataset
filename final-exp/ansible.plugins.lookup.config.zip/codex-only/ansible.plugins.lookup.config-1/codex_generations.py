

# Generated at 2022-06-23 11:18:09.519313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Check that the constructor will create a LookupModule instance
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:18:14.398811
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # keep the 3rd param (orig_exc) to False as it causes problems when running the unit test
    missing = MissingSetting("test_message", orig_exc=False)
    assert type(missing) == AnsibleOptionsError, "missing is not an AnsibleOptionsError"

# Generated at 2022-06-23 11:18:14.978247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:18:18.547488
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_loader(None)
    assert l.get_loader() is None
    assert l.get_basedir() is None
    assert l.get_templar() is None

# Generated at 2022-06-23 11:18:21.467821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)
    assert 'LookupClass' == lookup.__class__.__name__
    assert 'LookupModule' == lookup.__class__.__module__

# Generated at 2022-06-23 11:18:23.970681
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Invalid Setting")
    except MissingSetting as e:
        assert "Invalid Setting" in e.message

# Generated at 2022-06-23 11:18:33.551899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit tests for ansible.plugins.lookup.config"""

    # Create a new lookup module with empty arguments
    lookup_module = LookupModule()

    # Check that the TypeError is raised by passing a non-string value to run()
    # Check that the AnsibleOptionsError is raised by
    #   passing an unsupported value to run()
    # Check that the AnsibleOptionsError is raised when passing in
    #   an invalid value for the option (i.e. on_missing)
    for unsupported_arg in [None, list(), dict()]:
        try:
            lookup_module.run([unsupported_arg])
            raise AssertionError("run() accepted invalid arguments")
        except TypeError:
            pass

# Generated at 2022-06-23 11:18:38.589205
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    class ExceptionClass(AnsibleLookupError):
        def __init__(self, msg, orig_exc=None):
            self.msg = msg
            self.orig_exc = orig_exc

    # test the constructor
    exc = ExceptionClass("test error message", orig_exc=ExceptionClass("original exception"))
    assert exc.msg == "test error message"
    assert isinstance(exc.orig_exc, ExceptionClass)
    assert exc.orig_exc.msg == "original exception"

# Generated at 2022-06-23 11:18:47.615685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing LookupModule.run')

    # Setup
    terms = ['DEFAULT_ANSIBLE_LOG_PATH', 'my_bad_term']
    variables = None
    on_missing = 'error'
    plugin_type = None
    plugin_name = None
    data = dict(on_missing=on_missing, plugin_type=plugin_type, plugin_name=plugin_name)
    lookup_module = LookupModule()
    lookup_module.set_loader()

    # Execute
    result = lookup_module.run(terms, variables, **data)

    # Assert

# Generated at 2022-06-23 11:18:58.049971
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    # Case: MissingSetting is thrown with error message, original exception and invalid option
    with pytest.raises(MissingSetting) as ex:
        raise MissingSetting("throwing MissingSetting")
    assert ex.value.message == "throwing MissingSetting"
    assert ex.value.options == list()
    assert ex.value.orig_exc is None

    # Case: MissingSetting is thrown with error message and original exception
    with pytest.raises(MissingSetting) as ex:
        error = "throwing MissingSetting with original exception"
        orig_exc = "original exception"
        raise MissingSetting(error, orig_exc=orig_exc)
    assert ex.value.message == "throwing MissingSetting with original exception"
    assert ex.value.options == list()
    assert ex.value.orig_exc == "original exception"

# Generated at 2022-06-23 11:19:08.782502
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import unittest

    class Test(unittest.TestCase):
        def test_constructor(self):
            # test 1
            exception = MissingSetting('Invalid setting: {0}', orig_exc=Exception('Foo bar'))
            self.assertEqual(exception.message, 'Invalid setting: {0}')
            self.assertEqual(exception.orig_exc.__str__(), 'Foo bar')
            # test 2
            exception = MissingSetting('Invalid setting: {0}', orig_exc=Exception())
            self.assertEqual(exception.message, 'Invalid setting: {0}')
            self.assertEqual(exception.orig_exc.__str__(), 'Exception()')
    unittest.main()

# Generated at 2022-06-23 11:19:18.724687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', elements='str', required=True),
            on_missing=dict(type='str', default='error', choices=['error', 'warn', 'skip']),
            plugin_type=dict(type='str'),  # must be defined for plugin_name
            plugin_name=dict(type='str'),  # must be defined for plugin_type
        )
    )

    # These tests should pass
    # global configs
    assert LookupModule().run([module.params['_terms'][0]], variables=module.params) == \
           [getattr(C, module.params['_terms'][0])]
    # plugin configs

# Generated at 2022-06-23 11:19:29.155713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test case 1: UNKNOWN setting
    # Expected result: An exception will be raised
    with pytest.raises(AnsibleLookupError) as excinfo:
        kw_args = dict(plugin_type='connection', plugin_name='ssh')
        lookup_plugin = LookupModule()
        lookup_plugin.run(['UNKNOWN_SETTING'], **kw_args)
    assert 'Unable to find setting UNKNOWN_SETTING' in str(excinfo.value)
    assert 'was not defined' in str(excinfo.value)

    # Test case 2: DEFAULT_REMOTE_USER
    # Expected result: The value of DEFAULT_REMOTE_USER will be returned
    kw_args = dict(plugin_type='connection', plugin_name='ssh')
    lookup_plugin = LookupModule()
   

# Generated at 2022-06-23 11:19:37.787766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This method is used for testing the run method.
    # When we call it, it calls the run method of the class 
    # LookupModule.

    # We import the class LookupModule.
    from ansible.plugins.lookup import LookupModule
    # We import the ansible module constants.
    from ansible import constants

    # We set the value of a constant is set to True.
    C.DEFAULT_DEBUG_MSG = True

    # We make a reference to a class LookupModule.
    lm = LookupModule()

    # We set the default value of the variable parameters to None.
    parameters = {}

    # We get the constants.
    constants = constants.get_config_value('constants')

    # We set the default value of the variable terms to None.
    terms = []

    # We set the

# Generated at 2022-06-23 11:19:38.412237
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:19:40.253283
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    x = MissingSetting('some_message')
    assert x.message == 'some_message'

# Generated at 2022-06-23 11:19:45.468818
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Empty class
    empty_class = LookupModule()
    assert empty_class != None

    # With options
    options = {
        'on_missing': 'warn',
        'plugin_type': 'become',
        'plugin_name': 'sudo'
    }
    class_with_options = LookupModule(**options)

# Generated at 2022-06-23 11:19:51.657959
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('msg', orig_exc=Exception('exception message'))
    except MissingSetting as e:
        assert str(e) == 'msg', 'Missing error message from MissingSetting exception'
        assert 'exception message' in str(e), 'Did not find original exception in MissingSetting message'

# Generated at 2022-06-23 11:19:53.416081
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:20:03.391507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1, basic test, Plugin name given and plugin_type given and config value is known.
    # expected result: Shell plugin's remote_tmp value "~/.ansible/tmp"
    test_input = {"plugin_name": 'sh', "plugin_type": 'shell', "terms": ['remote_tmp']}
    test_answer = LookupModule().run(**test_input)
    assert test_answer == ['~/.ansible/tmp']

    # Test case 2, basic test, Plugin name given and plugin_type given and config value is unknown.
    # expected result: None
    test_input = {"plugin_name": 'sh', "plugin_type": 'shell', "terms": ['unknown_config_value']}
    test_answer = LookupModule().run(**test_input)
    assert test_answer == []

    #

# Generated at 2022-06-23 11:20:07.971845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['ANSIBLE_PIPELINING']
    defaults = {'_terms': terms}
    my = LookupModule(None, defaults, None, None, None)
    assert my._templar._available_variables == defaults

# Generated at 2022-06-23 11:20:11.912872
# Unit test for constructor of class LookupModule
def test_LookupModule():

    config = LookupModule()
    assert(config.run(['DEFAULT_ROLES_PATH']) == ['/etc/ansible/roles:/usr/share/ansible/roles:/usr/local/share/ansible/roles'])

# Generated at 2022-06-23 11:20:17.179121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    plugin_name = 'not_existed_plugin'
    term = 'DEFAULT_ROLES_PATH'
    missing = 'error'
    try:
        result = lookup.run(terms=[term], plugin_name=plugin_name, on_missing=missing)
    except AnsibleOptionsError:
        pass
    else:
        raise Exception('AnsibleOptionsError should be raised')

# Generated at 2022-06-23 11:20:18.577820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:20:20.362466
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:20:28.424337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    passkey = "test"
    passkey_plugin = "test"
    success_expected_result = "success"
    success_expected_result_plugin = "success"
    error_expected_result = "Error"
    error_expected_result_plugin = "Error"

    # Error condition when on_missing is failed
    lookup = LookupModule()
    lookup.set_options(var_options=None, direct={"on_missing": "error"})
    ret = []

# Generated at 2022-06-23 11:20:31.470581
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test', 'test')
    assert isinstance(m, AnsibleOptionsError)
    assert str(m) == 'test'
    assert m._orig_exc == 'test'

# Generated at 2022-06-23 11:20:34.745333
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test_msg')

    assert isinstance(e, AnsibleOptionsError)
    assert e.args[0] == 'test_msg'
    assert e.orig_exc is None


# Generated at 2022-06-23 11:20:35.355684
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    pass

# Generated at 2022-06-23 11:20:37.023638
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('AnsibleOptionsError')
    except:
        return True

# Generated at 2022-06-23 11:20:39.735493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_cls = LookupModule()
    assert isinstance(lookup_cls, LookupModule)
    assert hasattr(lookup_cls, 'run')
    assert callable(lookup_cls.run)

# Generated at 2022-06-23 11:20:42.172374
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('SomeMessage', 'SomeOrigExc')
    except MissingSetting as e:
        assert e.args[0] == 'SomeMessage'
        assert e.orig_exc == 'SomeOrigExc'

# Generated at 2022-06-23 11:20:53.757322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    with pytest.raises(AnsibleOptionsError) as e:
        l.run(terms=['foo', 'bar'], variables={}, on_missing='invalid')

    assert e.value.message == '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid'

    with pytest.raises(AnsibleError) as e:
        l.run(terms=['foo', 'bar'], variables={}, on_missing='error')
    assert e.value.message == 'Unable to find setting foo'

    l.run(terms=['foo', 'bar'], variables={}, on_missing='warn')

    l.run(terms=['foo', 'bar'], variables={}, on_missing='skip')

# Generated at 2022-06-23 11:21:06.030532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule, _get_global_config, _get_plugin_config
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleOptionsError, AnsibleLookupError

    # test for invalid configs
    lookup_plugin = LookupModule()
    invalid_configs = [
        "!$^&*",
        "",
        "^*&^%$#",
        "PORT_FOR_SSH_CONNECTION",
        "port",
        "PORT",
        "remote_user",
    ]
    expected_error_message = "Invalid setting identifier, "


# Generated at 2022-06-23 11:21:10.974777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    configs = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH"]
    for config in configs:
        assert lookup_module.run([config]) == [getattr(C, config)], "Fail: LookupModule run method"


# Generated at 2022-06-23 11:21:11.938248
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    raise MissingSetting('foo')

# Generated at 2022-06-23 11:21:20.253780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LUM = LookupModule()
    LUM.set_options(var_options={})
    assert LUM.run(['LIBRARY_PATH']) == ['/home/ansible/ansible/lib']
    assert LUM.run([None]) == []
    assert LUM.run([1]) == []
    assert LUM.run([['LIST_ARRAY_1','LIST_ARRAY_2']]) == []
    assert LUM.run(['LIBRARY_PATH', 'COMMAND_WARNINGS', 'CONFIGURATION_WARNINGS']) == ['/home/ansible/ansible/lib', False, True]

# Generated at 2022-06-23 11:21:23.126952
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """
    Test the constructor of class MissingSetting
    """
    try:
        raise MissingSetting('foo')
    except AnsibleOptionsError as e:
        assert e.orig_exc is None
        assert to_native(e) == 'value not found: foo'
    try:
        raise MissingSetting('foo', orig_exc='bar')
    except AnsibleOptionsError as e:
        assert to_native(e) == 'value not found: foo'
        assert to_native(e.orig_exc) == 'bar'

# Generated at 2022-06-23 11:21:30.814132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = LookupModule()

    for missing_value in ['error', 'warn', 'skip']:
        assert lookup_plugin.run(['string'], on_missing=missing_value) == ['string']
        assert lookup_plugin.run([1], on_missing=missing_value) == [1]
        assert lookup_plugin.run([{'hash': 'val'}], on_missing=missing_value) == [{'hash': 'val'}]
        assert lookup_plugin.run([1, 'string'], on_missing=missing_value) == [1, 'string']

# Generated at 2022-06-23 11:21:34.924844
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_native
    try:
        raise AnsibleOptionsError('test_MissingSetting')
    except AnsibleOptionsError as e:
        missing_setting = MissingSetting(to_native('test_MissingSetting'), 'test', orig_exc=e)
        assert (missing_setting.orig_exc == e)

# Generated at 2022-06-23 11:21:35.781894
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert isinstance(MissingSetting(), AnsibleOptionsError)

# Generated at 2022-06-23 11:21:36.626690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:21:48.783286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins import module_loader
    import ansible.plugins.loader
    import ansible.plugins.connection
    import ansible.plugins.shell
    import ansible.plugins.cache

    config_terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    terms_with_missing = ['DEFAULT_BECOME_USER', 'UNKNOWN', 'RETRY_FILES_SAVE_PATH']
    terms_with_missing_and_plugin = ['remote_user', 'remote_tmp']
    config = LookupModule()
    config.display = lambda x, y=None: None



# Generated at 2022-06-23 11:21:51.459934
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test with original exception
    m = MissingSetting('msg', orig_exc=AttributeError('orig_exc'))
    assert m.orig_exc == 'orig_exc'
    assert m.__str__() == 'msg'

    # Test without original exception
    m = MissingSetting('msg')
    assert m.orig_exc is None
    assert m.__str__() == 'msg'

# Generated at 2022-06-23 11:22:00.904021
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test run with plugin_type and plugin_name passed
    lookup_module = LookupModule()
    test_term = 'remote_user'
    test_plugin_type = 'connection'
    test_plugin_name = 'local'
    test_result = lookup_module.run([test_term], plugin_type=test_plugin_type, plugin_name=test_plugin_name)
    assert test_result[0] == 'root'

    # test run with plugin_type and plugin_name passed, but term is not present
    lookup_module = LookupModule()
    test_term = 'remote_us'
    test_plugin_type = 'connection'
    test_plugin_name = 'local'

# Generated at 2022-06-23 11:22:11.257640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import tempfile
    import json

    conf_dir = tempfile.mkdtemp()

    # Configure ansible.cfg in conf_dir

# Generated at 2022-06-23 11:22:12.047151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:22:18.737881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype = 'connection'
    pname = 'local'
    terms = ['remote_user']
    lookup_mod = LookupModule()
    result = lookup_mod.run(terms, plugin_name=pname, plugin_type=ptype)
    assert result == [C.ANSIBLE_REMOTE_USER]
    # Asserting if Plugin Type and Plugin Name are not provided or one of them is missing
    with pytest.raises(AnsibleOptionsError) as err:
        lookup_mod.run(terms, plugin_name=pname)
        assert type(err) == AnsibleOptionsError
    with pytest.raises(AnsibleOptionsError) as err:
        lookup_mod.run(terms, plugin_type=ptype)
        assert type(err) == AnsibleOptionsError

# Generated at 2022-06-23 11:22:30.741894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l.set_options(direct={'on_missing': 'error'})
    assert l.run(['DEFAULT_REMOTE_USER'], variables={}) == ['root']

    l.set_options(direct={'on_missing': 'warn'})
    assert l.run(['banana'], variables={}) == []

    l.set_options(direct={'on_missing': 'skip'})
    assert l.run(['banana'], variables={}) == []

    l.set_options(direct={'on_missing': 'error'})
    with pytest.raises(AnsibleLookupError):
        l.run(['banana'], variables={})


# Generated at 2022-06-23 11:22:34.638480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype = 'connection'
    pname = 'ssh'
    terms = ['remote_user', 'port']
    variables = None
    kwargs = {}
    result = LookupModule().run(terms, variables, **kwargs)
    assert result[0] == 'remote_user'
    assert result[1] == '22'

# Generated at 2022-06-23 11:22:35.776432
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert issubclass(MissingSetting, AnsibleOptionsError)

# Generated at 2022-06-23 11:22:38.542178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:22:47.938579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self.loader = loader
            self.templar = templar
        def get_option(self, option):
            return self.options[option]
    lookup_plugin = TestLookupModule(**{'plugin_type': 'become', 'plugin_name': 'test',
                                           'var_options': {}, 'direct': {},
                                           'options': {'DEFAULT_BECOME_USER': 'test_user', 'on_missing': 'error'}})
    assert lookup_plugin.run(['DEFAULT_BECOME_USER']) == ['test_user']

# Generated at 2022-06-23 11:22:52.461002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(['DEFAULT_BECOME_USER'],
               variables={'ansible_network_os': 'ios'},
               plugin_type='connection',
               plugin_name='network_cli')

# Generated at 2022-06-23 11:22:54.050699
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert e.message == "test"

# Generated at 2022-06-23 11:22:56.159420
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test message')
    except MissingSetting as e:
        assert e.msg == 'Test message', e.msg


# Generated at 2022-06-23 11:22:57.576430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-23 11:22:59.267825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run()

# Generated at 2022-06-23 11:23:03.761486
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=[], variables={}, on_missing='error', plugin_type=None, plugin_name=None) == []
    assert lookup_module.run(terms=['foo'], variables={}, on_missing='error', plugin_type=None, plugin_name=None) == []

# Generated at 2022-06-23 11:23:04.898716
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('test')

# Generated at 2022-06-23 11:23:06.015632
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
     assert('test' in str(MissingSetting('test')))
     assert(isinstance(MissingSetting('test', e), Exception))

# Generated at 2022-06-23 11:23:09.610482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = 'DEFAULT_REMOTE_USER'
    result = lookup.run([term], {}, plugin_name='ssh', plugin_type='connection', on_missing='error')
    assert result == [getattr(C, term)]

# Generated at 2022-06-23 11:23:11.372425
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test if class __init__ works as expected"""
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:23:13.324490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run'), 'Unable to find "run" in LookupModule class'

# Generated at 2022-06-23 11:23:15.845972
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    from ansible.errors import AnsibleOptionsError

    m = MissingSetting('The config setting was not found.', 'the-key')

    assert m.key == 'the-key'

# Generated at 2022-06-23 11:23:20.982783
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test", AnsibleOptionsError("cause"))
    except MissingSetting as e:
        assert e.message == "test"
        assert isinstance(e.orig_exc, AnsibleOptionsError)
        assert e.orig_exc.message == "cause"

# Generated at 2022-06-23 11:23:30.936218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    missing = 'error'
    loader = plugin_loader.connection_loader
    p = loader.get('httpapi', class_only=False)
    variables = {}
    lookup = LookupModule()
    ret = lookup.run(terms, variables, on_missing=missing, plugin_type='connection', plugin_name='httpapi')
    assert ret == [p.get_option('remote_user')]

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    missing = 'warn'
    lookup = LookupModule()
    ret = lookup.run(terms, variables, on_missing=missing)
    assert ret == [p.get_option('remote_user')]
    assert lookup._display.display.call_count == 1

# Generated at 2022-06-23 11:23:35.651297
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test', orig_exc=None)
    except MissingSetting as e:
        pass
    assert(e.error_type == 'MissingSetting')
    assert(e.orig_exc is None)
    assert(e.error_message == 'Test')

# Generated at 2022-06-23 11:23:36.939065
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    return l

# Generated at 2022-06-23 11:23:42.059097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_terms
    # test_missing_setting
    # test_missing_setting_error
    # test_missing_setting_warn
    # test_missing_setting_skip
    # test_get_global_config
    # test_get_plugin_config
    # test_get_plugin_config_error
    pass

# Generated at 2022-06-23 11:23:44.873682
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('msg', orig_exc=None)
    except MissingSetting as e:
        print(e.message)
        print(e.orig_exc)



# Generated at 2022-06-23 11:23:46.533155
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert issubclass(MissingSetting, AnsibleOptionsError)



# Generated at 2022-06-23 11:23:50.244626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Does not make sense to test without arguments
    lookup_module = LookupModule(None, None, None, None)
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:23:51.356756
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting.__name__ == 'MissingSetting'

# Generated at 2022-06-23 11:23:53.720577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    module.run(terms)


# Generated at 2022-06-23 11:24:00.739785
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_msg = 'test message'
    try:
        raise AnsibleError(test_msg)
    except AnsibleError as e:
        ansible_error = e

    try:
        raise MissingSetting(test_msg, orig_exc=ansible_error)
    except MissingSetting as e:
        assert test_msg in e.message
        assert e.orig_exc is ansible_error
        assert test_msg in str(e)
        assert str(type(e)) in str(e)

# Generated at 2022-06-23 11:24:11.358463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()


# Generated at 2022-06-23 11:24:13.062466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement unit tests for this method
    pass



# Generated at 2022-06-23 11:24:20.377308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    plugin.set_options(var_options=None, direct={})
    terms = ['DEFAULT_ROLES_PATH']
    result = plugin.run(terms=terms)
    assert result == [['/etc/ansible/roles', './roles'], ]
    terms = ['REMOTE_TMP']
    result = plugin.run(terms=terms)
    assert result == [u'/tmp/ansible-${USER}', ]

    # Test plugin loaded
    plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    terms = ['REMOTE_TMP']
    result = plugin.run(terms=terms)
    assert result == [u'/tmp/ansible-$USER', ]

# Generated at 2022-06-23 11:24:25.514395
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        invalid_config_setting = "foo"
        _get_global_config(invalid_config_setting)
    except MissingSetting as e:
        exception_msg = to_native(e)
        assert exception_msg == 'Config option %s was not defined.' % invalid_config_setting
        assert isinstance(e.orig_exc, AttributeError)

# Generated at 2022-06-23 11:24:28.269294
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Bad setting"
    expected_msg = "Bad setting"
    exc = Exception()
    m = MissingSetting(msg, orig_exc=exc)
    assert m.message == expected_msg
    assert m.orig_exc == exc

# Generated at 2022-06-23 11:24:32.932103
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        msg = "TEST MESSAGE"
        e = Exception()
        raise MissingSetting(msg, e)
    except MissingSetting as e:
        assert e.message == msg
        assert e.orig_exc == e
        assert e.args[0] == "TEST MESSAGE"

# Generated at 2022-06-23 11:24:34.599911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(datastructure=None, variables=None)

# Generated at 2022-06-23 11:24:39.129355
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting('Some message')
    assert exception.message == 'Some message'
    assert exception.orig_exc is None
    exception = MissingSetting('Some message', orig_exc=Exception())
    assert exception.message == 'Some message'
    assert isinstance(exception.orig_exc, Exception)

# Generated at 2022-06-23 11:24:44.785628
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test with an empty message
    try:
        MissingSetting("")
    except AnsibleOptionsError:
        pass
    else:
        raise Exception("Failed to raise AnsibleOptionsError with a missing message")

    # Test with a valid message
    try:
        MissingSetting("message")
    except AnsibleOptionsError:
        raise Exception("Failed to instanciate MissingSetting with a valid message")
    else:
        pass

# Generated at 2022-06-23 11:24:47.619308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    terms = []
    variables = {}
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms, variables)


# Generated at 2022-06-23 11:24:59.263277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import get_all_plugin_loaders

    # Get list of all lookup plugins from ansible.plugins.lookup.get_all_plugin_loaders()
    lookup_plugins = get_all_plugin_loaders()

    # Test ansible.plugins.lookup.config.LookupModule().run()
    lm = lookup_plugins.get('config')().run

    # Test DEFAULT_BECOME_USER
    ret = lm(['DEFAULT_BECOME_USER'],[])
    assert ret == ['root']

    # Test UNKNOWN_BECOME_USER
    try:
        ret = lm(['UNKNOWN_BECOME_USER'],[])
        assert False
    except AnsibleLookupError:
        pass

    # Test UNKNOWN_BECOME_USER with on

# Generated at 2022-06-23 11:25:09.591727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(direct={'on_missing': 'error'})

    with pytest.raises(AnsibleOptionsError):
        l.run(['NotValid', 'NotValid2'])

    with pytest.raises(AnsibleOptionsError):
        l.run(['DEFAULT_BECOME_USER', 1])

    with pytest.raises(AnsibleLookupError):
        l.run(['unknown-config-key'])

    with pytest.raises(AnsibleLookupError):
        l.run(['DEFAULT_BECOME_USER', 'invalid-config-key'])

    assert l.run(['DEFAULT_BECOME_USER']) == [C.DEFAULT_BECOME_USER]

# Generated at 2022-06-23 11:25:12.261055
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Caching to speed up tests
    LookupModule._lookup_plugin_cache = {}

    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 11:25:18.968860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_config(terms, ptype=None, pname=None, missing='error'):
        return LookupModule().run(terms, plugin_type=ptype, plugin_name=pname, on_missing=missing)

    from ansible import constants as C
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_native

    try:
        _get_config([], missing='foo')
        assert False, "should have raised AnsibleOptionsError"
    except AnsibleOptionsError:
        pass

    try:
        _get_config(['foo'], missing='bar')
        assert False, "should have raised AnsibleOptionsError"
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-23 11:25:21.687073
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(MissingSetting) as cm:
        raise MissingSetting("This is a test")
    ex = cm.value
    assert str(ex) == "This is a test"


# Generated at 2022-06-23 11:25:24.640891
# Unit test for constructor of class LookupModule
def test_LookupModule():
  l = LookupModule()
  assert l
  assert l.get_option('on_missing') == 'error'
  assert l.get_option('plugin_name') is None
  assert l.get_option('plugin_type') is None

# Generated at 2022-06-23 11:25:27.318271
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise LookupModule.MissingSetting
    except LookupModule.MissingSetting as e:
        assert isinstance(e.orig_exc, AttributeError)

# Generated at 2022-06-23 11:25:30.347516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert 'localhost' in lookup.run(['DEFAULT_HOST', 'DEFAULT_CONNECTION'])

# Generated at 2022-06-23 11:25:40.500989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_config_file = 'ansible.cfg'
    ansible_cfg_path = '/tmp'
    ansible_cfg_full_path = ansible_cfg_path + '/' + ansible_config_file
    os.environ['ANSIBLE_CONFIG'] = ansible_cfg_full_path

    ansible_config = ConfigParser.SafeConfigParser({'DEFAULT_BECOME_USER': None, 'DEFAULT_REMOTE_USER': None,
                                                    'DEFAULT_ROLES_PATH': None, 'RETRY_FILES_SAVE_PATH': None,
                                                    'COLOR_OK': None, 'COLOR_CHANGED': None, 'COLOR_SKIP': None})

    ansible_config.add_section('lookup')

# Generated at 2022-06-23 11:25:42.864618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule."""

    lookup_module = LookupModule()
    assert lookup_module is not None, "Failed to instantiate LookupModule class object."

# Generated at 2022-06-23 11:25:46.689018
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm != None
    lm.set_options(var_options = {}, direct = {})
    lm.run(terms = ["fixture_prefix"], variables=None, **{})

# Generated at 2022-06-23 11:25:58.126783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    lookup_plugin = LookupModule()

    # Test 1
    # Test lookup_plugin.run() with a missing option (on_missing)
    term = 'DEFAULT_BECOME_USER'
    # invoke method test_LookupModule_run()
    try:
        lookup_plugin.run(terms=[term], variables=None)
        assert False, 'expected an AnsibleOptionsError exception'
    except AnsibleOptionsError:
        assert True

    # Test 2
    # Test lookup_plugin.run() with an option(on_missing) that is not one of 'error', 'warn', or 'skip'

# Generated at 2022-06-23 11:26:08.052297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Global lookups
    # setting 'DEFAULT_ROLES_PATH' should return list
    assert sorted(LookupModule().run(['DEFAULT_ROLES_PATH'])) == sorted([
        'roles',
        '~/.ansible/roles:/usr/share/ansible/roles'
    ])
    assert sorted(LookupModule().run(['DEFAULT_ROLES_PATH'], variables={'DEFAULT_ROLES_PATH': 'role1:role2'})) == sorted([
        'role1', 'role2'
    ])
    # setting 'DEFAULT_BECOME_USER' should return string
    assert LookupModule().run(['DEFAULT_BECOME_USER']) == ['root']

# Generated at 2022-06-23 11:26:09.423847
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
   # construct a MissingSetting object with a default message
   assert isinstance(MissingSetting(''), MissingSetting)

# Generated at 2022-06-23 11:26:19.218013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    from ansible.utils.display import Display

    def get_config_value(config, plugin_type=None, plugin_name=None, variables=None):
        if plugin_type == 'vars':
            if config == 'my_var':
                return 'value of my_var'
            elif config == 'my_var_not_found':
                return None

    old_get_config_value = C.config.get_config_value
    C.config.get_config_value = get_config_value

    def get_config():
        return 'value of config'

    C._config = get_config

    lm = LookupModule(
        basedir='/home/test',
        params={},
        display=Display()
    )


# Generated at 2022-06-23 11:26:29.400009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule
    lookup = LookupModule()
    assert isinstance(lookup.run(['']), list)
    assert isinstance(lookup.run(['DEFAULT_ROLES_PATH']), list)
    assert isinstance(lookup.run(['DEFAULT_BECOME_USER']), list)
    assert isinstance(lookup.run(['remote_user'], variables={}, plugin_type='connection', plugin_name='ssh'), list)
    assert isinstance(lookup.run(['remote_tmp'], variables={}, plugin_type='shell', plugin_name='sh'), list)
    assert isinstance(lookup.run(['invalid_setting']), list)

# Generated at 2022-06-23 11:26:41.072549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_ansible_config_setting(self, C_):
        C_.DEFAULT_BECOME_USER = 'rundeck'
        C_.COLOR_OK = 'green'
        C_.COLOR_CHANGED = 'yellow'
        C_.COLOR_SKIP = 'cyan'

    lookup_obj = LookupModule()
    lookup_obj.set_options({'variable_manager': None, 'loader': None, 'inventory_manager': None, 'playbook': None, 'display': None, 'variable_manager': None, 'all_vars': None})

# Generated at 2022-06-23 11:26:50.616505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    args = {
        '_ansible_lookup_plugin': 'config',
        '_ansible_lookup_reader': 'mock_reader',
        '_ansible_lookup_provider': 'ansible.plugins.lookup.config',
        '_terms': ['remote_user'],
        '_on_missing': 'warn'
    }
    lookup_module = LookupModule(**args)

    # Test that constructor sets options with default values
    assert lookup_module.get_option('on_missing') == 'warn'
    assert lookup_module._terms == ['remote_user']
    assert lookup_module._reader._loader == 'mock_reader'
    assert lookup_module._loader == 'mock_reader'



# Generated at 2022-06-23 11:26:56.484711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get LookupModule class
    LookupModule = LookupModule()
    print(LookupModule)

    # test LookupModule class
    result = LookupModule.run(['DEFAULT_BECOME_USER'], {'DEFAULT_BECOME_USER': 'test'})
    print('result = %s' % result)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:27:07.795625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms=[], variables={'on_missing': 'error'}, plugin_type='shell', plugin_name='sh')
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms=[], variables={'on_missing': 'error'}, plugin_type='shell')
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms=[1], variables={'on_missing': 'error'}, plugin_type='shell', plugin_name='sh')
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(terms=['UNKNOWN'], variables={'on_missing': 'error'}, plugin_type='shell', plugin_name='sh')

# Generated at 2022-06-23 11:27:09.455569
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "message"
    e = MissingSetting(msg)
    assert isinstance(e, AnsibleOptionsError)
    assert e.args[0] == msg



# Generated at 2022-06-23 11:27:13.831397
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test')
    assert e.message == 'test'
    assert e.orig_exc is None
    assert e.kwargs == {}


if __name__ == '__main__':
    test_MissingSetting()

# Generated at 2022-06-23 11:27:25.580991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dummy_variable = {"ansible_user": "Test User"}
    dummy_options = {"on_missing": "error"}
    variables = {"user": "ansible_user"}
    terms = ["Test"]
    test_obj = LookupModule()
    test_obj.set_options(var_options = variables, direct = dummy_options)

    from ansible.plugins.loader import connection_loader
    cat_obj = connection_loader.get("local", class_only=True)

    plugin_name = cat_obj._load_name
    plugin_type = "connection"

    try:
        result = _get_plugin_config(plugin_name, plugin_type, terms[0], dummy_variable)
    except MissingSetting as e:
        assert missing == 'error'
        assert e.message == 'Unable to find setting %s'

# Generated at 2022-06-23 11:27:32.540846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    
    # Test with missing option (on_missing=None)
    try:
        lookup_plugin = LookupModule()
        lookup_plugin.run(terms=['DEFAULT_ROLES_PATH'])
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string' in str(e)
        
    # Test with invalid option (on_missing='invalid')
    try:
        lookup_plugin = LookupModule()
        lookup_plugin.run(terms=['DEFAULT_ROLES_PATH'], on_missing='invalid')
    except AnsibleOptionsError as e:
        assert 'must be one of "error", "warn" or "skip"' in str(e)

# Generated at 2022-06-23 11:27:40.985435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    lookup = LookupModule()
    res = lookup.run(terms=['DEFAULT_REMOTE_TMP', 'UNKNOWN_TERM'],
                     variables=ImmutableDict(hostvars=dict(), group_names=list(), group_vars=dict()),
                     on_missing='warn')
    try:
        assert res == ['$HOME/.ansible/tmp', C.DEFAULT_REMOTE_TMP]
    except AssertionError:
        raise



# Generated at 2022-06-23 11:27:42.232570
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test constructor of LookupModule class"""
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:27:48.939560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    display = Display()
    terms = ['BECOME_PARAM_DEBUG', 'BECOME_PARAM_SUDO_EXE']
    ptype = 'become'
    pname = 'pbrun'
    variables = None
    lookup = LookupModule(display)
    ret = lookup.run(terms, variables, plugin_type=ptype, plugin_name=pname)
    assert ret == [True, '/opt/pbis/bin/sudo']
    terms = ['remote_user', 'port']
    ptype = 'connection'
    pname = 'ssh'
    variables = None
    lookup = LookupModule(display)
    ret = lookup.run(terms, variables, plugin_type=ptype, plugin_name=pname)

# Generated at 2022-06-23 11:27:58.575629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from units.compat.mock import patch
    from units.compat.mock import MagicMock
    from ansible.module_utils.six import PY3

    # first use the legacy config, in Python3 the config will be migrated to
    # another module and _get_global_config() will not work in Python3
    terms = ['DEFAULT_HASH_BEHAVIOUR']
    _get_global_config = LookupModule()._get_global_config
    result = _get_global_config(terms)

    if PY3:
        self.assertEqual(result, None)
    else:
        self.assertEqual(result, 'merge')


# Generated at 2022-06-23 11:28:04.469071
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("A missing setting")
    except MissingSetting as e:
        assert e.message == "A missing setting"
        assert e.orig_exc is None
    try:
        raise MissingSetting("A missing setting", orig_exc=Exception("Original Problem"))
    except MissingSetting as e:
        assert e.message == "A missing setting"
        assert str(e.orig_exc) == "Original Problem"



# Generated at 2022-06-23 11:28:16.377691
# Unit test for method run of class LookupModule