

# Generated at 2022-06-23 11:18:08.251179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    p = LookupModule()
    print (p)

# Generated at 2022-06-23 11:18:17.706893
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock class _display (from ansible.plugins.loader)
    class Display:
        def __init__(self):
            self.display = None

        def warning(self, msg):
            self.display = msg

    def sentinel():
        pass

    # Mock class C (from ansible.constants)    
    class C:
        def __init__(self):
            self.DEFAULT_BECOME_USER = 'root'
            self.DEFAULT_ROLES_PATH = 'roles/'
            self.RETRY_FILES_SAVE_PATH = '~/.ansible_failed_retry'
            self.COLOR_OK = 'green'
            self.COLOR_CHANGED = 'yellow'
            self.COLOR_SKIP = 'cyan'
            self.UNKNOWN = 'unknown'

       

# Generated at 2022-06-23 11:18:26.342591
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# unit tests:
# - missing argument 'terms', must raise AnsibleOptionsError
# - unsupported value of 'on_missing', must raise AnsibleOptionsError
# - invalid 'terms', must raise AnsibleOptionsError
# - missing global config, must raise AnsibleLookupError
# - missing plugin config, must raise AnsibleLookupError
# - running the task with single key, must return list with single value
# - running the task with plugin settings, must return list with plugin configuration settings
# - running the task with list of keys, must return list with values
# - running the task with plugin settings, must return list with plugin configuration settings
# - running the task with missing settings and 'on_missing=warn', must return empty list
# - running the task with missing settings and 'on_missing

# Generated at 2022-06-23 11:18:28.328614
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # create object of class MissingSetting
    # check if instance of class
    assert isinstance(MissingSetting(msg="test", orig_exc="test"), MissingSetting)

# Generated at 2022-06-23 11:18:29.209490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()



# Generated at 2022-06-23 11:18:32.564399
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Config key "foo" was not defined.'
    e = AnsibleError()

    result = MissingSetting(msg, e)
    assert result.message == msg
    assert result.orig_exc == e


# Generated at 2022-06-23 11:18:34.453266
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('invalid key found')
    except MissingSetting as e:
        assert to_native(e) == 'invalid key found'

# Generated at 2022-06-23 11:18:37.184971
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:18:46.449447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    # config value exists
    ret = l.run(["DEFAULT_ROLES_PATH"])
    assert isinstance(ret[0], list)
    # config value does not exist
    with pytest.raises(AnsibleLookupError) as e:
        l.run(["BOGUS_CONFIG_VALUE"])
    assert "Unable to find setting BOGUS_CONFIG_VALUE" in to_native(e.value)
    # on_missing = warn
    ret = l.run(["BOGUS_CONFIG_VALUE"], on_missing="warn")
    assert len(ret) == 0
    assert "Skipping, did not find setting BOGUS_CONFIG_VALUE" in l._display.warning.call_args[0][0]
    # on_missing =

# Generated at 2022-06-23 11:18:56.120352
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create instance of LookupModule
    lookup_plugin = LookupModule()

    # Create variables
    test_variables = {
        "test_variable_1": "value_1",
        "test_variable_2": "value_2",
        "test_variable_3": "value_3"
    }

    # Assert that variables are "None" to begin with
    assert lookup_plugin._templar.variables is None

    # Unit test for set_options()
    lookup_plugin.set_options(var_options=test_variables)

    # Assert that variables were set correctly
    assert lookup_plugin._templar.variables == test_variables



# Generated at 2022-06-23 11:19:01.973840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(
        terms=[
            'DEFAULT_BECOME_METHOD',
            'PRIVATE_KEY_FILE',
            'DEFAULT_BECOME_USER',
            'DEFAULT_BECOME_PASS',
            'UNKNOWN_SETTING'
        ],
        variables=None,
        on_missing='skip'
    )

    assert ret[0] == 'sudo'
    assert ret[1] == C.DEFAULT_PRIVATE_KEY_FILE
    assert ret[2] == 'root'
    assert ret[3] is None
    assert len(ret) == 4

# Generated at 2022-06-23 11:19:04.583230
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """mocking MissingSetting class"""
    msg_test = 'msg'
    exception_test = 'exception'
    msg, exception = MissingSetting(msg_test, orig_exc=exception_test)
    if msg != msg_test or exception != exception_test:
        raise AssertionError

# Generated at 2022-06-23 11:19:06.048901
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:19:10.483961
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'testmsg'
    orig_exc = Sentinel()
    try:
        raise MissingSetting(msg, orig_exc=orig_exc)
    except MissingSetting as m_e:
        if not issubclass(type(m_e), AnsibleError):
            raise
        assert m_e.message == msg
        assert m_e.orig_exc == orig_exc

# Generated at 2022-06-23 11:19:14.896041
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # init the class
    error = MissingSetting('test msg')
    assert error.message == 'test msg'
    assert error.orig_exc is None
    # test with orig_exc
    error = MissingSetting('test msg', orig_exc=Exception())
    assert isinstance(error.orig_exc, Exception)

# Generated at 2022-06-23 11:19:15.524625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 11:19:17.250501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_result = LookupModule()
    assert(lookup_result is not None)



# Generated at 2022-06-23 11:19:20.634507
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    setting1 = 'UNKNOWN'
    missing_setting = MissingSetting(setting1)
    if missing_setting.orig_exc is None:
        assert missing_setting.orig_exc is None
    assert missing_setting

# Generated at 2022-06-23 11:19:25.774971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin._display = dict()
    lookup_plugin._templar = dict()
    lookup_plugin._loader = dict()

    result = lookup_plugin.run(["DEFAULT_BECOME_USER"], [])
    assert result == [C.DEFAULT_BECOME_USER]



# Generated at 2022-06-23 11:19:33.161090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test case 1
    module = LookupModule()
    # Test case 2
    module.run("DEFAULT_BECOME_USER")
    # Test case 3
    module.run("DEFAULT_ROLES_PATH")
    # Test case 4
    module.run("RETRY_FILES_SAVE_PATH")
    # Test case 5
    module.run("COLOR_OK")
    # Test case 6
    module.run("COLOR_CHANGED")
    # Test case 7
    module.run("COLOR_SKIP")
    # Test case 8
    module.run("UNKNOWN")
    # Test case 9
    module.run("remote_user")
    # Test case 10
    module.run("port")
    # Test case 11
    module.run("remote_tmp")

# Generated at 2022-06-23 11:19:45.457695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock constants
    constants = {}
    attr_value = 'test_value'
    constants['SOME_CONSTANT'] = attr_value
    class Mock_C:
        pass
    mock_obj = Mock_C()
    mock_obj.__dict__ = constants
    setattr(mock_obj, 'get_config_value', lambda a, b: attr_value)

    mock_C = Mock_C()
    mock_C.config = mock_obj
    # mock constants

    module_obj = LookupModule()

    def mock_getattr(self, key):
        return C.config[key]

    setattr(LookupModule, 'get_option', mock_getattr)
    setattr(C, 'SOME_CONSTANT', attr_value)

    # test case: get the

# Generated at 2022-06-23 11:19:52.628534
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create mock objects for testing
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.connection.paramiko_ssh import Connection as ssh_connection
    ssh_connection._load_name = 'ssh'
    connection_loader.all.append(ssh_connection)
    ssh_connection(Mock())

    from ansible.plugins.loader import shell_loader
    from ansible.plugins.shell import sh
    sh._load_name = 'sh'
    shell_loader.all.append(sh)
    sh(Mock())
    C.DEFAULT_REMOTE_TMP = '$local_tmp/.ansible/${USER}/tmp'

    class Mock(object):

        def __init__(self, test_case, msg='', ret=[]):
            self.test_case = test_case
            self

# Generated at 2022-06-23 11:19:59.031232
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    try:
        lookup.run("value.none")
        assert False, "Exception expected."
    except AnsibleOptionsError as e:
        assert 'on_missing' in to_native(e)
    try:
        lookup.run("value.none", on_missing='error')
        assert False, "Exception expected."
    except AnsibleLookupError as e:
        assert 'Unable to find setting value.none' in to_native(e)
    try:
        lookup.run("value.none", on_missing='warn')
        assert True, "Exception unexpected"
    except AnsibleLookupError:
        assert False, "Exception unexpected"
    assert lookup.run("value.none", on_missing='skip') == []

# Generated at 2022-06-23 11:20:09.384885
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1: negative test case
    l = LookupModule()

    # Test case 2: negative test case
    l = LookupModule()

    # Test case 3: negative test case
    l = LookupModule()

    # Test case 4: negative test case
    l = LookupModule()

    # Test case 5: positive test case
    l = LookupModule()

    # Test case 6: positive test case
    l = LookupModule()

    # Test case 7: positive test case
    l = LookupModule()

    # Test case 7: positive test case
    l = LookupModule()

    # Test case 7: positive test case
    l = LookupModule()

# Generated at 2022-06-23 11:20:12.084846
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.six import PY3
    from ansible.errors import AnsibleError, AnsibleOptionsError
    msg = "a message"
    orig_exc = Exception()
    assert isinstance(MissingSetting(msg, orig_exc), PY3, (AnsibleError, AnsibleOptionsError))
    assert isinstance(MissingSetting(msg, orig_exc), (AnsibleError, AnsibleOptionsError))

# Generated at 2022-06-23 11:20:19.302897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock
    from ansible.plugins.lookup import LookupBase
    terms = ["ansible_ssh_user"]
    obj = LookupModule()
    test_dict = {'ansible_ssh_user': 'testuser01'}

    with mock.patch.object(LookupBase, "_display", mock.Mock()), \
            mock.patch.object(plugin_loader, 'connection_loader', mock.Mock()), \
            mock.patch.object(C, 'ansible_ssh_user', mock.Mock(return_value=test_dict)):
        obj.run(terms)

# Generated at 2022-06-23 11:20:28.073671
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = C.DEFAULT_ROLES_PATH
    variables = None
    kwargs = {}

    lm = LookupModule()
    lm.set_options(var_options=variables, direct=kwargs)

    missing = lm.get_option('on_missing')
    ptype = lm.get_option('plugin_type')
    pname = lm.get_option('plugin_name')

    if (ptype or pname) and not (ptype and pname):
        raise AnsibleOptionsError('Both plugin_type and plugin_name are required, cannot use one without the other')


# Generated at 2022-06-23 11:20:30.164234
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert 'test' in str(e)

# Generated at 2022-06-23 11:20:36.026913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # setUp
  lookup = LookupModule()
  kwargs = {}
  kwargs["_terms"] = ["ANSIBLE_CALLBACK_PLUGINS"]
  kwargs["on_missing"] = "error"

  # run test
  lookup.run(
    terms=kwargs.get("_terms"),
    variables=kwargs.get("var_options"),
    direct=kwargs
  )

  # assert
  assert True

# Generated at 2022-06-23 11:20:42.462264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # global setting
    assert lookup.run(["DEFAULT_CACHE_PLUGIN"]) == ["memory"]

    # shell plugin
    assert "sh" in lookup.run(["BECOME_METHODS"], plugin_type="shell", plugin_name="sh")

    # ssh connection plugin
    assert "ssh" in lookup.run(["REMOTE_USER"], plugin_type="connection", plugin_name="ssh")

# Generated at 2022-06-23 11:20:45.838643
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('foo')
    except:
        pass
    try:
        raise MissingSetting('foo', orig_exc='bar')
    except:
        pass

# Generated at 2022-06-23 11:20:55.948935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct

    class LookupModule(object):
        def __init__(self, **kwargs):
            self.runner = kwargs.get('runner')
            self.inventory = kwargs.get('inventory')
            self.loader = kwargs.get('loader')
            self.vars = kwargs.get('vars')
            self._templar = kwargs.get('_templar')

        def set_options(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct

        @property
        def display(self):
            return self.runner.display



# Generated at 2022-06-23 11:21:00.938202
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')
    assert callable(lookup_module.run)
    assert hasattr(lookup_module, 'set_options')
    assert callable(lookup_module.set_options)

# Generated at 2022-06-23 11:21:02.821454
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display
    x = LookupModule(Display())
    return x

# Generated at 2022-06-23 11:21:03.835056
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule(None, None, None)
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 11:21:05.971604
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('missing_setting')
    if type(e) is not MissingSetting:
        raise AssertionError("Type should be MissingSetting")

# Generated at 2022-06-23 11:21:07.327069
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    a = MissingSetting('msg', orig_exc=None)
    assert a

# Generated at 2022-06-23 11:21:13.904330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule."""

    lm = LookupModule()

    # get_option is only defined for lookups run-time
    assert not hasattr(lm, 'get_option')

    assert lm._display.verbosity == 0

    assert lm.lookup_type == 'config'
    assert hasattr(lm, 'tempdir')
    assert hasattr(lm, '_temproot')

# Generated at 2022-06-23 11:21:24.837148
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:21:34.132604
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    terms = ['ANSIBLE_LIBRARY']
    term_result = lookup_module.run(terms)
    assert term_result == [C.DEFAULT_MODULE_PATH]

    term_result = lookup_module.run(['ANSIBLE_CONFIG'])
    assert term_result == [C.DEFAULT_CONFIG_FILE]

    terms = ['ANSIBLE_LIBRARY', 'ANSIBLE_CONFIG', 'ANSIBLE_REMOTE_TEMP']
    term_result = lookup_module.run(terms)
    assert term_result == [C.DEFAULT_MODULE_PATH, C.DEFAULT_CONFIG_FILE,
                           C.DEFAULT_REMOTE_TMP]

# Generated at 2022-06-23 11:21:38.635931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mock_loader = { 'test': 'mock_loader'}
    test_constants = { 'test': 'test_constants'}
    try:
        l = LookupModule(mock_loader, test_constants)
        if l.plugins == mock_loader and l.constants == test_constants:
           assert True
        else:
            assert False
    except NameError:
        assert False


# Generated at 2022-06-23 11:21:40.717100
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting('error message')

# Generated at 2022-06-23 11:21:49.009718
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils._text import to_text
    msg1 = to_text('Setting not found')
    test_err1 = MissingSetting(msg1)
    assert test_err1.msg == msg1

    msg2 = to_text('Setting not found: jabba=the_hutt')
    test_err2 = MissingSetting(msg2, 'jabba=the_hutt')
    assert test_err2.msg == msg2

    assert test_err1 != test_err2
    assert test_err1 == test_err1

# Generated at 2022-06-23 11:21:59.397091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test constructor of class LookupModule"""
    class Display(object):
        """Mocked Display class object"""
        def display(self, val):
            """Mocked display method"""
            pass
    class Constants(object):
        """Mocked Constants class object"""
        host_key_auto_add = 'bacon'
        host_key_checking = False
        scp_if_ssh = True
        gather_subset = 'nope'
        gather_timeout = 2
    class Options(object):
        """Mocked Options class object"""
        def __getattr__(self, name):
            """Mocked constructor for class Options"""
            if name == 'timeout':
                return 10
            return 'default'
        def get_option(self, name):
            """Mocked get_option method"""

# Generated at 2022-06-23 11:22:02.459063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert(lookup_plugin is not None)

# Generated at 2022-06-23 11:22:05.115738
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("marks")
    except AnsibleOptionsError as e:
        assert str(e) == "Invalid settings 'marks' is a list of strings, see documentation"

# Generated at 2022-06-23 11:22:13.586620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:22:22.799536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global C
    C = type('C', (object,), {})
    C.DEFAULT_HOST_LIST = []

    lookup = LookupModule()
    try:
        lookup._load_name = 'lookup_module_name'
        lookup.run(terms=None, variables=None)
    except AnsibleOptionsError as e:
        assert e.message == 'Missing required Terms'

    try:
        lookup.run(terms=['invalid'], variables=None)
    except AnsibleOptionsError as e:
        assert e.message == 'Invalid setting identifier, "invalid" is not a string, its a <class \'list\'>'

    lookup.set_options(dict(var_options=None, direct={'on_missing': 'invalid'}))

# Generated at 2022-06-23 11:22:25.517655
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing loading via constructor
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')



# Generated at 2022-06-23 11:22:28.896054
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_msg = "variable not defined"
    missing_setting = MissingSetting(error_msg)
    assert isinstance(missing_setting, AnsibleOptionsError)
    assert missing_setting.error_message == error_msg

# Generated at 2022-06-23 11:22:30.027741
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = str(MissingSetting('Test string', 'Test Exception'))
    assert result == 'Test string'

# Generated at 2022-06-23 11:22:31.448693
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup  # Assert it exists

# Generated at 2022-06-23 11:22:36.946417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up
    tests = {
        'a_string': 'test',
        'a_number': 123,
        'a_bool': True,
        'a_list': ['a', 'b', 'c'],
        'a_dict': {'a': 1, 'b': 2, 'c': 3},
        'a_tuple': (1, 2, 3),
        'a_set': {'a', 'b', 'c'},
    }
    for term, expected in tests.items():
        config = LookupModule()
        assert config.run([term]) == [expected]
    # tear down

# Generated at 2022-06-23 11:22:37.569526
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 11:22:40.889677
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    newobj = MissingSetting('msg', 'orig_exc')
    assert newobj._display.color == 7
    assert newobj.message == 'msg'
    assert newobj.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:22:42.001873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 11:22:53.582507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock class
    class AnsibleOptionsErrorMock:
        def __init__(self, msg):
            self.msg = msg
        def __str__(self):            # __unicode__ on Python 2
            return self.msg

    def _get_global_configMock(config):
        if config == 'DEFAULT_BECOME_USER':
            return 'some_user'

    def get_optionMock(option):
        if option == 'plugin_name':
            return 'cli'
        elif option == 'plugin_type':
            return 'cache'
        elif option == 'on_missing':
            return 'skip'

    # create mock class
    class SentinelMock:
        def __init__(self):
            pass

# Generated at 2022-06-23 11:22:54.943835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:22:58.604776
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("this is a test")
    except MissingSetting as ex:
        assert ex.message == "this is a test"
        assert str(ex) == "this is a test"
        assert repr(ex) == "this is a test"
        assert ex.orig_exc is None
        assert ex is not None

# Generated at 2022-06-23 11:23:09.372448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule:
        def __init__(self):
            self.value = None
        def __call__(self, value):
            self.value = value
    test_lookup_module = TestLookupModule()

# Generated at 2022-06-23 11:23:14.554600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with valid parameters
    try:
        LookupModule()
    except (AnsibleOptionsError, AnsibleLookupError) as e:
        assert False, "Unexpected Ansible exception: %s" % e
    except Exception as e:
        assert False, "Unexpected exception: %s" % e


# Generated at 2022-06-23 11:23:15.806562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor test
    l = LookupModule()


# Generated at 2022-06-23 11:23:20.085111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print("lookup module: {}".format(lookup_module))
    assert lookup_module

if __name__ == "__main__":
    test_LookupModule()

# Generated at 2022-06-23 11:23:30.312743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_cases = [
        dict(initial_terms=['DEFAULT_ROLES_PATH'], result_terms=['/etc/ansible/roles:/usr/share/ansible/roles']),
        dict(initial_terms=['DEFAULT_ROLES_PATH', 'DEFAULT_REMOTE_USER'], initial_plugin_type='shell',
             initial_plugin_name='sh', result_terms=['/etc/ansible/roles:/usr/share/ansible/roles', 'root']),
    ]

    for test_case in test_cases:
        lookup_mock = LookupModule()

# Generated at 2022-06-23 11:23:42.501984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    terms = ['DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_USER', 'DEFAULT_REMOTE_USER']
    result = my_lookup.run(terms)
    assert result[0] == 'sudo'
    assert result[1] == 'root'
    assert result[2] == 'root'
    result = my_lookup.run(terms, plugin_name='sh', plugin_type='shell')
    assert result[0] == 'sudo'
    assert result[1] == 'root'
    assert result[2] == 'root'
    result = my_lookup.run(terms, plugin_name='ssh', plugin_type='connection')
    assert result[0] == 'sudo'
    assert result[1] == 'root'

# Generated at 2022-06-23 11:23:44.252266
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('missing_setting_msg')
    assert m.message == 'missing_setting_msg'

# Generated at 2022-06-23 11:23:56.231920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    import json

    baselookup = lookup_loader.get("config")
    baselookup.set_options(var_options=dict(), direct=dict())

    l = LookupModule()
    l.set_options(var_options=dict(), direct=dict())

    try:
        l.run(["foo"], variables=dict())
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError expected"

    assert baselookup.run(["DEFAULT_ROLES_PATH"], variables=dict()) == l.run(["DEFAULT_ROLES_PATH"], variables=dict())

    l.set_options(var_options=dict(), direct=dict(on_missing="warn"))


# Generated at 2022-06-23 11:23:59.147393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['DEFAULT_BECOME_USER']
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=terms, variables={'test': 'whatever'})
    assert isinstance(result, list)
    assert result == ["root"]



# Generated at 2022-06-23 11:24:07.738604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.lookup.config import LookupModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, call, MagicMock

    # Mock the constants needed
    C.ANSIBLE_CONFIG = "/dev/null"
    C.ANSIBLE_CONFIG_FILE = "/dev/null"
    C.ANSIBLE_CALLBACK_WHITELIST = ["profile_tasks"]

# Generated at 2022-06-23 11:24:08.705667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:24:11.973607
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("AnsibleOptionsError")
    except AnsibleOptionsError as e:
        assert isinstance(e, AnsibleOptionsError)
    else:
        raise RuntimeError("MissingSetting is not an AnsibleOptionsError")

# Generated at 2022-06-23 11:24:19.949286
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    var_options = {"plugin_type": "callback"}
    direct = {"_orig_basename": "ansible-playbook", "_terms": "['action_plugins']"}

    lookup_module.set_options(var_options=var_options, direct=direct)
    terms = lookup_module.get_option("_terms")
    terms = terms[2:-2].split("', '")

    for term in terms:
        plugin_type = lookup_module.get_option("plugin_type")
        plugin_name = lookup_module.get_option("plugin_name")
        missing = lookup_module.get_option("on_missing")
        variables = {}
        result = Sentinel
        if (plugin_type or plugin_name) and not (plugin_type and plugin_name):
            raise Ans

# Generated at 2022-06-23 11:24:21.193473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add here unit test for method run of class LookupModule
    raise NotImplementedError()


# Generated at 2022-06-23 11:24:23.261967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert 'run' in dir(lookup_obj)

# Generated at 2022-06-23 11:24:32.623878
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()

    terms_test1 = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH'
    ]
    result_test1 = lm.run(terms_test1)
    assert result_test1 == ['root', ["/etc/ansible/roles", "~/.ansible/roles", "/usr/share/ansible/roles"]]

    terms_test2 = [
        'temp_variable',
        'DEFAULT_ROLES_PATH'
    ]
    result_test2 = lm.run(terms_test2, on_missing='error')

# Generated at 2022-06-23 11:24:34.753156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(terms=['DEFAULT_BECOME_USER'])

# Generated at 2022-06-23 11:24:41.147269
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    def assertion(e):
        assert isinstance(e, AnsibleError)
        assert isinstance(e, AnsibleOptionsError)
        assert e.orig_exc is not None
        assert 'was not defined' in str(e)
    try:
        raise MissingSetting('some random text')
    except MissingSetting as e:
        assertion(e)
    try:
        raise MissingSetting('some random text', orig_exc='foo')
    except MissingSetting as e:
        assertion(e)

# Generated at 2022-06-23 11:24:41.767297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:24:51.940837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest import mock
    from ansible import constants as C

    lookup = LookupModule()

    # Success case
    setattr(C, 'ANSIBLE_FOO', 'foo')
    assert lookup.run(terms=['ANSIBLE_FOO'], variables=None, on_missing='error', plugin_type=None, plugin_name=None) == ['foo']
    getattr = mock.MagicMock(return_value='foo')
    with mock.patch('ansible.plugins.loader.get_all_plugin_loaders_by_type', return_value=[(None, getattr)]):
        assert lookup.run(terms=['ANSIBLE_FOO'], variables=None, on_missing='error', plugin_type='bar', plugin_name=None) == ['foo']

    # Failure case

# Generated at 2022-06-23 11:25:03.624683
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:25:07.604752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    options = {
        'plugin_type': 'shell',
        'plugin_name': 'sh'
    }
    terms = ['remote_tmp']
    lookup = LookupModule()
    result = lookup.run(terms, options=options)
    assert isinstance(result[0], str)

# Generated at 2022-06-23 11:25:09.661026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.run([], [])
    assert test

# Generated at 2022-06-23 11:25:12.143169
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test message'
    orig_exc = Exception('original exception')
    e = MissingSetting(msg, orig_exc)

    assert e.message == msg
    assert e.orig_exc is orig_exc

# Generated at 2022-06-23 11:25:18.745919
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert isinstance(e, AnsibleOptionsError)
        assert isinstance(e, AnsibleError)
        assert str(e) == 'test'
        assert e.msg == 'test'
        assert e.orig_exc is None
    e = MissingSetting('test2', orig_exc=AnsibleError('test3'))
    assert isinstance(e, AnsibleOptionsError)
    assert isinstance(e, AnsibleError)
    assert str(e) == 'test2'
    assert e.msg == 'test2'
    assert isinstance(e.orig_exc, AnsibleError)
    assert str(e.orig_exc) == 'test3'
    assert e.orig_exc.msg == 'test3'

# Generated at 2022-06-23 11:25:28.313941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['ANSIBLE_NOCOWS']) == [False]
    # Test for plugin_type
    assert isinstance(lookup_module.run(terms=['connection'], plugin_type='callback', plugin_name='json')[0], str)
    # Test for exception
    try:
        lookup_module.run(terms=['BECOME_ASK'], variables={'BECOME_ASK': 12}, on_missing='error')
    except AnsibleOptionsError:
        pass
    #Test for exception
    try:
        lookup_module.run(terms=['BECOME_ASK'], variables={'BECOME_ASK': 12}, on_missing='bad')
    except AnsibleOptionsError:
        pass
    # Test for get

# Generated at 2022-06-23 11:25:33.861664
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ['remote_user']
    variables = {'remote_user': 'testing_user'}
    options = {'plugin_type': None, 'plugin_name': None}
    l = LookupModule(Loader())
    result = l.run(terms, variables, options)
    assert result[0] == 'testing_user'

    options['plugin_type'] = 'cliconf'
    options['plugin_name'] = 'junos'
    result = l.run(terms, variables, options)
    assert result[0] == 'testing_user'

    terms = ['remote_tmp']
    options['plugin_type'] = 'shell'
    options['plugin_name'] = 'sh'
    result = l.run(terms, variables, options)

# Generated at 2022-06-23 11:25:38.338055
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('foo')
    except MissingSetting as e:
        assert e.message == 'foo'
        assert e.orig_exc is None
        assert e.trace is None
        assert e.wrapped is None
        assert e.code == 255


# Generated at 2022-06-23 11:25:40.386168
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting()
    assert(result.msg == 'Ansible options error occured')

# Generated at 2022-06-23 11:25:44.301624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    lookup_module = LookupModule()
    result = lookup_module.run(test_terms)

# Generated at 2022-06-23 11:25:45.537476
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:25:49.127442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = C.config.get_config_value('DEFAULT_ROLES_PATH', plugin_type='vars', plugin_name='system', variables=None)
    assert result == C.DEFAULT_ROLES_PATH

# Generated at 2022-06-23 11:25:50.057168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _x = LookupModule()


# Generated at 2022-06-23 11:25:51.363987
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(lm is not None)

# Generated at 2022-06-23 11:25:53.084184
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dummyClass = LookupModule()
    assert dummyClass is not None


# Generated at 2022-06-23 11:25:53.852634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add tests for LookupModule_run
    assert False

# Generated at 2022-06-23 11:26:03.490678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # test for method run()
  lookupModule = LookupModule()

  # Test with a valid plugin_type and plugin_name
  plugin_name = 'local'
  plugin_type = 'connection'
  terms = ['local_tmp']
  result = lookupModule.run(terms, variables=None, plugin_type=plugin_type, plugin_name=plugin_name)
  assert result == [u'/tmp/ansible-${USER}/tmp']

  # Test with empty plugin_type and plugin_name
  plugin_name = ''
  plugin_type = ''
  terms = ['HOST_KEY_CHECKING']
  result = lookupModule.run(terms, variables=None, plugin_type=plugin_type, plugin_name=plugin_name)
  assert result == [True]

  # Test with invalid plugin_type and valid plugin_

# Generated at 2022-06-23 11:26:05.140240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_ins = LookupModule()
    assert lookup_ins.get_option('on_missing') == 'error'

# Generated at 2022-06-23 11:26:07.648975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['DEFAULT_BECOME_USER']
    config = LookupModule()
    config.run(terms)

# Generated at 2022-06-23 11:26:10.281952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: Write tests for non-existence of terms
    # TODO: Write tests for 'ret' not created properly
    # TODO: Write tests for 'ret' not used properly
    assert True

# Generated at 2022-06-23 11:26:12.451292
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('dummy')
    except MissingSetting as e:
        pass
    except Exception:
        assert False

# Generated at 2022-06-23 11:26:13.861386
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert isinstance(MissingSetting('a', 'b', 'c'), MissingSetting)

# Generated at 2022-06-23 11:26:18.041669
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('error message')
    except MissingSetting as e:
        assert e.args[0] == 'error message'
        assert e.orig_exc is None
        assert e.collection_name == ''
        assert e.collection_item_string == ''
        assert e.collection_item_key == ''

# Generated at 2022-06-23 11:26:22.980900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    term_value = ["ANSIBLE_CONFIG"]
    lookup_obj = LookupModule()
    ansible_options = dict(variables={}, direct={})
    lookup_obj.set_options(var_options=ansible_options.get('variables'), direct=ansible_options.get('direct'))
    result = lookup_obj.run(terms=term_value)
    assert(result[0] == C.CONFIG_FILE)

# Generated at 2022-06-23 11:26:25.374011
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test constructor
    ut_module = LookupModule()
    assert ut_module

# Generated at 2022-06-23 11:26:26.821907
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert(MissingSetting(u'Bad!', orig_exc='foo') ==
           AnsibleOptionsError(u'Bad!', orig_exc='foo'))

# Generated at 2022-06-23 11:26:27.838906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 11:26:29.399565
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test', orig_exc=AnsibleError())
    assert 'test' in str(e)

# Generated at 2022-06-23 11:26:32.375267
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('configuration setting should be string')
    assert error.message == 'configuration setting should be string'



# Generated at 2022-06-23 11:26:36.762199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    variable = {"ansible_python_interpreter": "/usr/bin/python3.7"}
    l.run('DEFAULT_LOAD_CALLBACK_PLUGINS', variable)


# Generated at 2022-06-23 11:26:47.970979
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()
    lm._display = type('MockDisplay', (object, ), {'warning': Mock()})
    lm.set_options(var_options={'ansible_check_mode': True})

    # test with on_missing="error"
    assert lm.run(['ansible_check_mode'], on_missing='error') == [True]

    # test with on_missing="warn"
    lm.run(['ansible_check_mode_inexistant'], on_missing='warn')
    lm._display.warning.assert_called_with('Skipping, did not find setting %s' % 'ansible_check_mode_inexistant')

    # test with on_missing="skip"

# Generated at 2022-06-23 11:26:55.365032
# Unit test for constructor of class LookupModule
def test_LookupModule():
    input_terms = ["inventory","playbook","playbooks","become_method"]
    input_variables = {"ansible_connection": "ssh", "ansible_become_user": "root", "ansible_become_password": "abc"}
    input_kwargs = {"plugin_name": "ssh", "plugin_type": "connection"}

    lookup_module_instance = LookupModule()
    lookup_module_instance.run(terms=input_terms, variables=input_variables, **input_kwargs)

    assert True

# Generated at 2022-06-23 11:27:06.547019
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test1: trying to lookup with non-string terms
    # Input: terms = [1,2]
    # Output: Exception: AnsibleOptionsError
    # Reason: AnsibleOptionsError occurs because terms should be a string type
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run([1,2])

    # Test2: trying to lookup with non-valid on_missing
    # Input: terms = 'test', on_missing = 'test'
    # Output: Exception: AnsibleOptionsError
    # Reason: AnsibleOptionsError occurs because 'on_missing' must be a string and one of "error", "warn" or "skip", not 'test'
    with pytest.raises(AnsibleOptionsError):
        LookupModule().run(['test'], on_missing='test')

# Generated at 2022-06-23 11:27:07.472849
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 11:27:13.096796
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Test the constructor of the class MissingSetting"""
    msg = 'foo'
    err = MissingSetting(msg)
    assert msg == err.message, "Unexpected message attribute"
    assert None is err.orig_exc, "Unexpected orig_exc attribute"
    assert str(err) == msg, "Unexpected str()"

# Generated at 2022-06-23 11:27:19.979905
# Unit test for constructor of class LookupModule
def test_LookupModule():
    the_list = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    p = LookupModule()
    p.set_options(var_options={'DEFAULT_BECOME_USER': 'test_user', 'DEFAULT_ROLES_PATH': '/path/to/roles'}, direct={'on_missing': 'warn'})
    assert p.run(the_list) == ['test_user', '/path/to/roles']

# Generated at 2022-06-23 11:27:26.144302
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError) as excinfo:
        raise MissingSetting('msg', orig_exc=AnsibleOptionsError('orig_exc'))

    assert 'msg' in str(excinfo.value)
    assert 'orig_exc' in str(excinfo.value)
    assert excinfo.value.orig_exc.args[0] == 'orig_exc'



# Generated at 2022-06-23 11:27:28.992714
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('yadda')
    except MissingSetting as e:
        assert 'yadda' in str(e)

# Generated at 2022-06-23 11:27:37.815606
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils._text import to_native
    from ansible.utils.sentinel import Sentinel
    dummy = Sentinel()
    lookup = LookupModule()
    lookup.set_options(direct={'on_missing':'error'})
    try:
        o = _get_plugin_config('dummy', 'dummyplugin', 'abc',  dummy)
        assert False
    except MissingSetting as e:
        msg = to_native(e)
        assert msg == 'Unable to find setting abc'

# Generated at 2022-06-23 11:27:39.007074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result

# Generated at 2022-06-23 11:27:43.505678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Begin unit tests")
    print("Define LookupModule object")
    lookup_obj = LookupModule()

    print("Retrieve object attrs")
    all_attrs = dir(lookup_obj)

    print("Check if all the required attrs are present in the object")
    assert(hasattr(lookup_obj, 'run'))

# Generated at 2022-06-23 11:27:45.528400
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule('')

# Generated at 2022-06-23 11:27:52.429180
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = 'ansible.plugins.lookup.config'
    try:
        mod_obj = __import__(lookup_module, fromlist=[''])
        obj_instance = mod_obj.LookupModule()
        assert obj_instance.__class__.__name__ == 'LookupModule'
    except ImportError:
        print('Error while importing module %s' % lookup_module)

# Generated at 2022-06-23 11:27:53.656392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    #TODO
    # module.run()
    pass

# Generated at 2022-06-23 11:28:02.341661
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.sentinel import SentinelFail
    from ansible.module_utils._text import to_native

# Generated at 2022-06-23 11:28:14.152607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Just check that __init__ of LookupBase is called
    lookup_plugin = LookupModule()

    # check that missing parameter is checked
    with pytest.raises(AnsibleOptionsError):
        lookup_plugin.run(terms=['CHANGED_COLOR', 'OK_COLOR'], on_missing='fake_value')

    # check that missing setting raises an AnsibleLookupError
    with pytest.raises(AnsibleLookupError) as exc:
        lookup_plugin.run(terms=['FAKE_SETTING', 'ANSIBLE_STDOUT_CALLBACK'], on_missing='error')
    assert 'Unable to find setting FAKE_SETTING' in str(exc)

    # check that missing setting does not raise an AnsibleLookupError when on_missing is 'skip'