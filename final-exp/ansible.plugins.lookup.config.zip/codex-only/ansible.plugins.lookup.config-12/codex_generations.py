

# Generated at 2022-06-23 11:18:20.927088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.path import unfrackpath

    LookupBase._get_plugin_class = lambda *args, **kwargs: LookupModule
    lookup_plugin = LookupModule()

    def _get_plugin_instance(plugin_class_name):
        class _DummyPlugin(object):
            _load_name = plugin_class_name
            def __init__(self):
                self.path_cache = None

        return _DummyPlugin()

    def _get_loader(loader_name):
        def _get_plugin_class(plugin_class_name, *args, **kwargs):
            return _get_plugin_instance(plugin_class_name)

        got_plugin = lambda *args, **kwargs: None

# Generated at 2022-06-23 11:18:29.430558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    class PathResetter():
        def __init__(self):
            self.prev_sys_path = sys.path[:]

        def __enter__(self):
            sys.path.insert(0, '../../lib')

        def __exit__(self, type, value, traceback):
            sys.path = self.prev_sys_path

    from ansible.plugins.loader import connection_loader

    with PathResetter():
        from ansible.plugins.connection.ssh import Connection as ssh_connection_class

        ssh_conn = ssh_connection_class()
        ssh_conn._load_name = 'ssh'
        connection_loader._cache[('ssh', 'connection')] = ssh_conn

        module = LookupModule()

        terms = ['remote_tmp']
        ptype = 'shell'
        pname

# Generated at 2022-06-23 11:18:31.076966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)


# Generated at 2022-06-23 11:18:32.782137
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert to_native(MissingSetting("test message", AnsibleError("test message"))) == "test message"

# Generated at 2022-06-23 11:18:40.640394
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class FakeDisplay():
        def warning(self, msg):
            pass

    class FakePluginLoader():
        def become_loader(self, pname, class_only=True):
            return FakePlugin()

    class FakePlugin():
        def __init__(self):
            self._load_name = 'become_method'

    display = FakeDisplay()
    pl = FakePluginLoader()
    module = LookupModule()
    module._display = display
    plugin_loader.become_loader = pl.become_loader

    module.set_options(var_options={}, direct={
        'plugin_type': 'become',
        'plugin_name': 'become_method',
        'on_missing': 'error',
    })
    assert module.get_option('on_missing') == 'error'
    assert module.get

# Generated at 2022-06-23 11:18:47.366021
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Creating a MissingSetting instance with empty arguments
    mssg = MissingSetting()

    # Checking default values of attributes
    assert mssg.orig_exc is None
    assert mssg.missing == 'UNDEFINED'
    assert str(mssg) is not None

    # Creating a MissingSetting instance with all arguments
    try:
        raise MissingSetting('one', 'two', 'three')
    except MissingSetting as mssg:
        assert mssg.orig_exc == 'two'
        assert mssg.missing == 'one'
        assert str(mssg) == 'one'

# Generated at 2022-06-23 11:18:49.563991
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    c = MissingSetting('test message')
    assert c.message == 'test message'
    assert c.orig_exc is None

# Generated at 2022-06-23 11:18:51.448989
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('msg')
    assert MissingSetting('msg', orig_exc=None)

# Generated at 2022-06-23 11:19:00.093840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    results = module.run(['DEFAULT_BECOME_USER'], {'ansible_config': C.config.loader}, on_missing='skip')
    assert results[0] == 'root'

    results = module.run(['DEFAULT_BECOME_USER'], {'ansible_config': C.config.loader}, on_missing='warn')
    assert results[0] == 'root'

    with pytest.raises(AnsibleLookupError) as e:
        module.run(['NonexistentSetting'], {'ansible_config': C.config.loader}, on_missing='error')
    assert 'Unable to find setting NonexistentSetting' in str(e.value)

    with pytest.raises(AnsibleLookupError) as e:
        module

# Generated at 2022-06-23 11:19:01.969782
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test')
    assert m.message == 'test'

# Generated at 2022-06-23 11:19:03.089493
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting()
    assert isinstance(exception, Exception)

# Generated at 2022-06-23 11:19:05.623323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:19:07.034125
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(MissingSetting):
        raise MissingSetting(msg='Error')

# Generated at 2022-06-23 11:19:11.234888
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_data = {
        'message': 'test_message',
        'orig_exc': 'test_orig_exc'
    }
    message, orig_exc = test_data.values()
    missing_setting = MissingSetting(message, orig_exc)
    assert missing_setting.message == message
    assert missing_setting.orig_exc == orig_exc

# Generated at 2022-06-23 11:19:11.914554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()



# Generated at 2022-06-23 11:19:13.450986
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(Exception):
        raise MissingSetting(msg='bar')

# Generated at 2022-06-23 11:19:14.828428
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test')
    assert 'test' in str(m)
    assert 'MissingSetting' in str(m)

# Generated at 2022-06-23 11:19:21.262368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.lookup.config import LookupModule
    config = 'DEFAULT_BECOME_USER'
    lookup = LookupModule()
    # Test default value for constructor of LookupModule class
    assert lookup._display.verbosity >= 0
    assert lookup._options is None
    # Test lookup and return value
    assert lookup.run([config]) == [C.DEFAULT_BECOME_USER]
    # Test that lookup of invalid config returns EmptyValueSentinel
    assert lookup.run(['NOT_CONFIG']) == [Sentinel]

# Generated at 2022-06-23 11:19:30.530254
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing global config
    C.DEFAULT_ROLES_PATH = ['/a/b/c', '/d/e/f']
    C.DEFAULT_BECOME_USER = 'root'
    mock_loader = plugin_loader.shell_loader
    mock_loader._matches = dict(sh='sh', bash='bash')
    mock_loader._all = dict(sh=['sh', 'sh'], bash=['bash', 'bash'])
    mock_loader._all_count = 2
    mock_loader._paths = dict(sh=['/c/d/e', '/f/g/h'], bash=['/i/j/k', '/l/m/n'])

    # Testing global config, single
    result = LookupModule().run(['DEFAULT_BECOME_USER'], [])


# Generated at 2022-06-23 11:19:32.417691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    b = LookupBase()
    assert(isinstance(b, LookupBase))

# Generated at 2022-06-23 11:19:34.510293
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('testing exception')
    except Exception as e:
        assert e.message == 'testing exception'

# Generated at 2022-06-23 11:19:36.629731
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("msg")
    assert e.message == "msg"

# Generated at 2022-06-23 11:19:47.526878
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test__get_plugin_config(pname, ptype, config, variables):
        return _get_plugin_config(pname, ptype, config, variables)
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    try:
        result = lookup_module.run(terms,variables=None, **{'on_missing':'error'})
        assert result == ['root']
    except MissingSetting as e:
        assert False, 'Unable to find setting'
    terms = ['INVALID_SETTING_NAME']
    try:
        result = lookup_module.run(terms,variables=None, **{'on_missing':'error'})
        assert False
    except MissingSetting as e:
        assert True

# Generated at 2022-06-23 11:19:52.172980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import pytest
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    pb = Playbook.load(sys.modules[__name__].__file__.replace('.pyc', '.yml'),
               variable_manager=VariableManager(), loader=DataLoader())

    tasks = pb.get_plays()[0].get_tasks()

    for task in tasks:
        if task.name == 'test_construct':
            task.args['config'] = 'test_a'
            task.args['plugin_type'] = 'test_b'
            task.args

# Generated at 2022-06-23 11:20:01.646402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test: Initialise LookupModule
    lookup_instance = LookupModule()

    # Test: Test None terms
    if lookup_instance.run(terms=None) is not None:
        raise AssertionError('Result should be None')

    # Test: Test invalid on_missing option
    if lookup_instance.run(terms=None, on_missing='Invalid') is not None:
        raise AssertionError('Result should be None')

    # Test: Test invalid terms
    if lookup_instance.run(terms=['Invalid']) is not None:
        raise AssertionError('Result should be None')

    # Test: Test plugin_type and plugin_name both need to be specified
    if lookup_instance.run(terms=[], plugin_type='None') is not None:
        raise AssertionError('Result should be None')

   

# Generated at 2022-06-23 11:20:13.779147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = lookup.run(terms, dict())
    assert result == [u'root', [u'/etc/ansible/roles']]

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'DEFAULT_MODULE_NAME']
    result = lookup.run(terms, dict())
    assert result == [u'root', [u'/etc/ansible/roles'], u'command']

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_MODULE_NAME', 'DEFAULT_ROLES_PATH']
    result = lookup.run(terms, dict())

# Generated at 2022-06-23 11:20:21.701184
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:20:28.955523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myLookupModule = LookupModule()
    # run_terms_missing
    result = myLookupModule.run(terms="UnkownSetting", on_missing="error")
    assert result == []

    # run_terms_discovery
    myLookupModule = LookupModule()
    result = myLookupModule.run(terms="DEFAULT_ROLES_PATH", on_missing="error")
    assert isinstance(result,list)
    assert len(result) == 1
    assert isinstance(result[0], list)
    assert len(result[0]) > 0
    assert isinstance(result[0][0], string_types)
    assert len(result[0][0]) > 0

    # run_terms_multidiscovery
    myLookupModule = LookupModule()

# Generated at 2022-06-23 11:20:31.210256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule """
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-23 11:20:40.466303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils import plugins

    lm = plugins.lookup_loader.get('config', class_only=True)
    terms = ['DEFAULT_LOGGER_NAME', 'UNKNOWN_SETTING']

    # test case: When setting exists in constants
    result = lm.run(terms, {}, on_missing='warn')
    assert result == ['default']

    # test case: When setting does not exist in constants
    result = lm.run(terms, {}, on_missing='error')
    assert result == ['default']

    # test case: When setting exists in connection plugin
    terms = ['ssh_executable', 'UNKNOWN_SETTING']

    # test case: When setting exists in constants
    result = lm.run(terms, {}, on_missing='warn', plugin_type='connection', plugin_name='ssh')

# Generated at 2022-06-23 11:20:44.322104
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('foo', 'bar')
    except MissingSetting as e:
        assert(e.kwargs['orig_exc'] == 'bar')

# Generated at 2022-06-23 11:20:45.701271
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:20:47.536495
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:20:50.384948
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin = LookupModule()
    result = plugin.run(('ANSIBLE_BECOME_USER', 'ANSIBLE_CACHE_PLUGIN'))

    print(result)

# Generated at 2022-06-23 11:20:54.730018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod.set_loader(None)
    lookup_mod.set_basedir("/tmp/fake_basedir")

    ret = lookup_mod.run(["DEFAULT_DEST"], {}, on_missing="error")

    assert ret == [C.DEFAULT_DEST_DIR]

# Generated at 2022-06-23 11:20:56.859044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Check if constructor of LookupModule class loads correctly"""
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:20:58.834026
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert(MissingSetting('test_message', orig_exc='test_orig_exc'))

# Generated at 2022-06-23 11:21:07.058958
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # get_option() must return the direct argument

    def _get_option(key, variables, **kwargs):
        return kwargs[key]

    try:
        lookup_module = LookupModule()
        lookup_module._get_option = _get_option
        lookup_module.run(terms=['plugin_type'], variables='test_var', plugin_type='test_value')
    except AnsibleLookupError:
        pass # This test is not valid, because the run() method is not mocked right
    except TypeError:
        pass
    else:
        raise AssertionError("Incorrect arguments were not rejected")

# Generated at 2022-06-23 11:21:11.717092
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=protected-access
    lookup = LookupModule()
    assert lookup._terms == []
    assert lookup._options == {'_original_terms': [],
                               '_terms': [],
                               'convert_data': True,
                               'fail_on_undefined': False,
                               'wantlist': True,
                               'wantlist_type': 'list'}

# Generated at 2022-06-23 11:21:14.597355
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'foo'
    orig_exc = TypeError
    test_case = MissingSetting(msg, orig_exc=orig_exc)
    assert isinstance(test_case, AnsibleOptionsError)
    assert test_case.msg == msg
    assert test_case.orig_exc == orig_exc

# Generated at 2022-06-23 11:21:19.746171
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Exception is generated, and __init__.args gets set to the error message,
    # so those will be returned by the class method.
    ex = MissingSetting('Foobar')
    assert str(ex) == 'Foobar'
    assert ex.args == ('Foobar',)

# Generated at 2022-06-23 11:21:20.389889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert False

# Generated at 2022-06-23 11:21:22.332805
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None, 'Unable to create LookupModule class'

# Generated at 2022-06-23 11:21:30.697980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test list of terms
    terms = ['default_become_user', 'default_become_method']
    assert LookupModule().run(terms) == ['root', 'sudo']

    # test single term
    assert LookupModule().run(terms[0]) == ['root']

    # test missing value
    with pytest.raises(AnsibleLookupError):
        LookupModule().run('bad_term')

    # test on_missing value
    assert LookupModule().run('missing_term', on_missing = 'warn') == []
    assert LookupModule().run('missing_term', on_missing = 'skip') == []

    # test option
    assert LookupModule().run('default_become_method', 'on_missing=skip') == ['sudo']

# Generated at 2022-06-23 11:21:34.752391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config = 'DEFAULT_DEBUG'
    terms = [config]

    module = LookupModule()
    result = module.run(terms)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == True

# Generated at 2022-06-23 11:21:36.266937
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # assert(isinstance(l, LookupModule))

# Generated at 2022-06-23 11:21:37.743387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dictionary = {'lookup_plugin': LookupModule()}
    assert dictionary['lookup_plugin']

# Generated at 2022-06-23 11:21:42.088846
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Test Message"
    orig_exc = "Original Exception"
    assert msg == MissingSetting(msg, orig_exc).msg
    assert orig_exc == MissingSetting(msg, orig_exc).orig_exc

# Generated at 2022-06-23 11:21:48.423087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # Call the run method with a 'config' in order to get the user name of the ansible config.
    result = lm.run(terms='remote_user', variables=None, direct=None)
    for item in result:
        # The user name of the ansible config will follow the format of root@
        assert item.startswith('root@', 0, len(item))

# Generated at 2022-06-23 11:21:58.957474
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:21:59.492625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:22:02.133558
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    raise MissingSetting("test exception")

# Generated at 2022-06-23 11:22:04.430742
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('some_message')
    assert e.message == 'some_message'
    assert not e.orig_exc

# Generated at 2022-06-23 11:22:06.026398
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        print(e)

# Generated at 2022-06-23 11:22:12.957729
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Ensure use of Message exception is not broken
    msg = 'A test error message'
    try:
        raise MissingSetting(msg)
    except MissingSetting as e:
        assert e.message == msg

    # Ensure use of Message exception with orig_exc is not broken
    orig_e = Exception('Unit test exception')
    try:
        raise MissingSetting(msg, orig_exc=orig_e)
    except MissingSetting as e:
        assert e.message == msg
        assert dir(e) == dir(orig_e)
        assert e.__str__() == orig_e.__str__()

# Generated at 2022-06-23 11:22:16.297597
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('message', 'orig_exc')
    except MissingSetting as e:
        assert e.orig_exc == 'orig_exc'
        assert 'message' in to_native(e)

# Generated at 2022-06-23 11:22:27.482104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestConfig:
        def __init__(self):
            self.BOOL_TRUE = True
            self.BOOL_FALSE = False
            self.STRING = "string"
            self.INT = 42
            self.LONG = 999999999999
            self.NONE = None
            self.DICT = dict(var1='1',var2='2')

    config = TestConfig()

    class TestLookupModule(LookupModule):
        def __init__(self):
            self.set_options()


# Generated at 2022-06-23 11:22:28.126842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:22:30.029084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = []
    module.run(terms, variables=None, **{})

# Generated at 2022-06-23 11:22:32.604490
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        a = MissingSetting('Some message')
        b = MissingSetting('Some message', orig_exc='Some exception')
    except Exception as e:
        print(e)

# Generated at 2022-06-23 11:22:34.674675
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    with pytest.raises(MissingSetting):
        raise MissingSetting("New Error")

# Generated at 2022-06-23 11:22:45.155214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    # Remove 'ansible.module_utils.common.plugins.lookup.config' from PYTHONPATH
    module_path = 'ansible.module_utils.common.plugins.lookup.config'
    if module_path in sys.modules:
        del sys.modules[module_path]

    from ansible.module_utils.common.plugins.lookup.config import LookupModule


# Generated at 2022-06-23 11:22:47.833440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Unit tests for method run of class LookupModule

# Generated at 2022-06-23 11:22:51.970280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert_matching_terms(lookup_module.run(["ANSIBLE_LIBRARY"]), [C.ANSIBLE_LIBRARY])


# Generated at 2022-06-23 11:23:02.411078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init the LookupModule class
    lookup = LookupModule()
    # run the method with different arguments,
    # each one of those would test a branch of run method
    # in order to validate the coverage
    # valid plugin_type and plugin_name
    res = lookup.run(['remote_user'], plugin_type='connection', plugin_name='ssh')
    assert 'root' in res
    # missing plugin_type,
    # it would raise an AnsibleOptionsError
    try:
        lookup.run(['remote_user'], plugin_name='ssh')
    except AnsibleOptionsError:
        assert True
    else:
        assert False
    # missing plugin_name
    # it would raise an AnsibleOptionsError

# Generated at 2022-06-23 11:23:04.031490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['INVALID_CONFIG']
    variables = None
    module.run(terms, variables)

# Generated at 2022-06-23 11:23:06.298046
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('message')
    except MissingSetting as e:
        assert(e.message == 'message')

# Generated at 2022-06-23 11:23:08.844969
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting("Test", "Test")
    assert missing_setting.message == "Test"
    assert missing_setting.orig_exc == "Test"

# Generated at 2022-06-23 11:23:19.137929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {}
    config = 'DEFAULT_ROLES_PATH'
    terms = [config]
    ptype = 'connection'
    pname = 'ssh'
    vars['ptype'] = ptype
    vars['pname'] = pname
    args = (terms, vars)
    kwargs = {'_ansible_check_mode': False, '_ansible_debug': False, '_ansible_diff': False,
              '_ansible_keep_remote_files': True, '_ansible_no_log': False}
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(*args, **kwargs), list)
    config = 'remote_user'
    terms = [config]
    config = 'port'
    terms.append(config)


# Generated at 2022-06-23 11:23:29.923742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping

    # testing with plugin_type and plugin_name,
    # as code is wrapped in if statements and it is not so easy to get coverage with combinations
    plugin_type = 'connection'
    plugin_name = 'local'

    # test missing 'on_missing' option
    try:
        terms = ['DEFAULT_REMOTE_USER', 'DEFAULT_REMOTE_PASS']
        lookup_mod = LookupModule()
        results = lookup_mod.run(terms, {"plugin_name": plugin_name, "plugin_type": plugin_type})
    except AnsibleOptionsError as e:
        assert_equals('"on_missing" must be a string and one of "error", "warn" or "skip", not None', to_native(e))

    #

# Generated at 2022-06-23 11:23:30.449024
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:23:32.166088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:23:40.349298
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Passing invalid input
    invalid_configs = [
        {'missing': 'warn'},
        {'missing': 'error', 'message': 'it is not a string'}
    ]
    for config in invalid_configs:
        try:
            _ = MissingSetting(**config)
            assert False, 'No exception thrown for invalid config %s' % config
        except AnsibleOptionsError:
            # This is what we expect
            pass


# Generated at 2022-06-23 11:23:42.688968
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting(msg='test_msg')
    obj = MissingSetting(msg='test_msg', orig_exc='test_orig_exc')

# Generated at 2022-06-23 11:23:49.059740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # term is missing in config, on_missing is default error
    assertLookupError(LookupModule, [''], [''])
    # term is missing in config, on_missing is skip, no exception
    assertLookupModule(LookupModule, [''], [''], on_missing='skip')
    # term is missing in config, on_missing is warn, no exception
    assertLookupModule(LookupModule, [''], [''], on_missing='warn')

    # config is True, on_missing is default error
    assertLookupModule(LookupModule, ['C.DEFAULT_KEEP_REMOTE_FILES'], [True])
    # config is True, on_missing is error

# Generated at 2022-06-23 11:23:50.101892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 11:23:59.248607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check when both ptype and pname are not given
    lookup_obj = LookupModule()
    try:
        lookup_obj.run(terms=['/tmp'], variables='variables', on_missing='error')
        assert False
    except AnsibleOptionsError:
        assert True

    # Check when only ptype is given
    try:
        lookup_obj.run(terms=['/tmp'], variables='variables', on_missing='error', plugin_type='vars')
        assert False
    except AnsibleOptionsError:
        assert True

    # Check when only pname is given
    try:
        lookup_obj.run(terms=['/tmp'], variables='variables', on_missing='error', plugin_name='vars')
        assert False
    except AnsibleOptionsError:
        assert True

    # Check

# Generated at 2022-06-23 11:24:06.622889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(direct={'on_missing': 'error'})
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS']
    result = l.run(terms, variables={})
    assert result == ['root', None]
    l.set_options(direct={'on_missing': 'warn'})
    result = l.run(terms, variables={})
    assert len(result) == 1
    assert 'did not find setting' in result[0]
    l.set_options(direct={'on_missing': 'skip'})
    result = l.run(terms, variables={})
    assert result == []

# Generated at 2022-06-23 11:24:13.142048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    # test LookupModule._get_plugin_config
    result = lu.run(terms="ssh_args", plugin_type='connection', plugin_name="ssh")
    assert result == ["-o ControlMaster=auto -o ControlPersist=60s -o ControlPath=/tmp/%%h-%%p-%%r"], \
        '_get_plugin_config method of LookupModule class is not working'
    result = lu.run(terms="httpapi_tcp_connection_timeout", plugin_type='httpapi', plugin_name="httpapi")
    assert result == [C.HTTPAPI_DEFAULT_TCP_CONN_TIMEOUT], \
        '_get_plugin_config method of LookupModule class is not working'

    # test LookupModule._get_global_config

# Generated at 2022-06-23 11:24:15.446986
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(MissingSetting) as exc:
        raise MissingSetting('mock message')
    assert exc.value.message == 'mock message'

# Generated at 2022-06-23 11:24:18.070867
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    AnsibleOptionsError.__init__ = lambda self, message, orig_exc=None: None
    msg = 'message'
    orig_exc = 1
    assert (str(MissingSetting(msg, orig_exc=orig_exc)) == 'message')

# Generated at 2022-06-23 11:24:20.927169
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_msg = "Test message"

    # test constructor
    er = MissingSetting(test_msg)
    assert er.args[0] == test_msg

# Generated at 2022-06-23 11:24:22.122945
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 11:24:29.719936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global C
    C = Sentinel()

    def test_get_config_value(config, plugin_type=None, plugin_name=None):
        assert config == 'TEST_CONFIG'
        assert plugin_type == 'TEST_PLUGIN_TYPE'
        assert plugin_name == 'TEST_PLUGIN_NAME'
        return 'TEST_CONFIG_VALUE'

    def test_get_config_value_missing(config, plugin_type=None, plugin_name=None):
        raise AnsibleOptionsError

    def test_getattr(config):
        assert config == 'TEST_CONFIG'
        return 'TEST_CONFIG_VALUE'

    C.get_config_value = test_get_config_value
    C.config = Sentinel()
    C.config.get_config_value = test_

# Generated at 2022-06-23 11:24:31.280168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:24:41.856860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert isinstance(LookupModule, object)
    lookup_plugin = LookupModule()
    assert lookup_plugin
    assert isinstance(lookup_plugin.run, object)
    j1 = lookup_plugin.run([u'DEFAULT_ROLES_PATH'], variables=dict())
    assert isinstance(j1, list)
    assert isinstance(j1[0], list)
    assert isinstance(j1[0][0], string_types)
    assert isinstance(j1[0][1], string_types)
    j2 = lookup_plugin.run([u'DEFAULT_VAULT_IDENTITY_LIST'], variables=dict())

# Generated at 2022-06-23 11:24:52.020569
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Success case: terms is a valid config variable, var_options is None, kwargs is empty
    # expected results: _get_global_config(terms)
    # returns [<value of the config variable>]
    terms = 'DEFAULT_BECOME_USER'
    assert LookupModule.run(LookupModule(), terms, None, {}) == [C.DEFAULT_BECOME_USER]

    # Success case: terms is invalid config variable, var_options is None, kwargs is empty
    # expected results: _get_global_config(terms)
    # raises AnsibleOptionsError
    terms = 'Default_Become_User'

# Generated at 2022-06-23 11:24:57.957324
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    my_lookup = LookupModule()

    assert my_lookup.run(['DEFAULT_JINJA2_NATIVE'], {'frank': 'nope'}) == [False]

    # logging is only available when running a test
    import logging
    my_lookup.set_options(module_log_level=logging.INFO)
    assert my_lookup.run(['DEFAULT_JINJA2_NATIVE'], {'DEFAULT_JINJA2_NATIVE': 'True'}) == [True]

    assert my_lookup.run(['DEFAULT_JINJA2_NATIVE'], {'DEFAULT_JINJA2_NATIVE': True}) == [True]


# Generated at 2022-06-23 11:25:01.531577
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        result = _get_global_config('ANSIBLE_TEST_CONFIG')
    except MissingSetting as e:
        assert e.message == 'ANSIBLE_TEST_CONFIG was not defined in configuration'

# Generated at 2022-06-23 11:25:03.977626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:25:06.098804
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('bad thing')
    assert e.msg == 'bad thing'



# Generated at 2022-06-23 11:25:09.046292
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('Message')
    assert exc.orig_exc is None
    exc = MissingSetting('Message', orig_exc='exception')
    assert exc.orig_exc == 'exception'

# Generated at 2022-06-23 11:25:10.747807
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert 'test' == str(e)

# Generated at 2022-06-23 11:25:17.330741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = []
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    lookup = LookupModule()

    result = lookup.run(terms, variables=None)
    assert(len(result) == 2)
    assert(result[0] == C.DEFAULT_BECOME_USER)
    assert(result[1] == C.DEFAULT_ROLES_PATH)

    # test on_missing
    test_terms = ['DEFAULT_BECOME_USER', 'INVALID_VAR', 'DEFAULT_ROLES_PATH']
    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(test_terms, variables=None, on_missing='error')

# Generated at 2022-06-23 11:25:19.389775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule.run(None, 'DEFAULT_ROLES_PATH'), list)

# Generated at 2022-06-23 11:25:20.610030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, 'This unit test needs to be implemented'

# Generated at 2022-06-23 11:25:31.215394
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    options = {
        'on_missing': 'error'
    }
    lookup.set_options(direct=options)
    assert (lookup.get_option('on_missing') == 'error')

    options = {
        'on_missing': 'skip'
    }
    lookup.set_options(direct=options)
    assert (lookup.get_option('on_missing') == 'skip')

    options = {
        'on_missing': 'warn'
    }
    lookup.set_options(direct=options)
    assert (lookup.get_option('on_missing') == 'warn')


# Generated at 2022-06-23 11:25:33.220765
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert None != lookup_module
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:25:38.252785
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_msg = "You must define DEFAULT_USER and DEFAULT_PASS as vars in your playbook"
    orig_exc = None
    m_setting = MissingSetting(error_msg, orig_exc)

    assert m_setting.message == error_msg
    assert m_setting.orig_exc is None

# Generated at 2022-06-23 11:25:46.496448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    configuration = {}
    configuration['DEFAULT_REMOTE_TMP'] = '/tmp'
    configuration['DEFAULT_ROLES_PATH'] = ['/tmp/role1', '/tmp/role2']
    configuration['DEFAULT_BECOME_USER'] = 'ansible'
    lookup_plugin = LookupModule()
    lookup_plugin._display = DummyDisplay()
    result = lookup_plugin.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'], configuration)
    assert result == ['/tmp/role1', '/tmp/role2', 'ansible'], "Configuration should be found"



# Generated at 2022-06-23 11:25:47.918544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 11:25:51.407116
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "message"
    e = AnsibleError("original exception")
    try:
        raise MissingSetting(msg, orig_exc=e)
    except MissingSetting as exc:
        assert exc.orig_exc == e
        assert msg in str(exc)

# Generated at 2022-06-23 11:25:52.767086
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('message')
    assert e.orig_exc is None
    assert e.args[0] == 'message'

# Generated at 2022-06-23 11:26:02.901237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure it runs with the correct parameters
    g = LookupModule()

    # Portion of config generator is tested by test_config_loader.py
    assert g.run(['DEFAULT_REMOTE_USER']) == [C.DEFAULT_REMOTE_USER]
    assert g.run(['DEFAULT_REMOTE_USER'], {}, on_missing='error') == [C.DEFAULT_REMOTE_USER]

    # Exceptions
    import pytest
    with pytest.raises(AnsibleOptionsError):
        g.run(['DEFAULT_REMOTE_USER'], {}, on_missing='no_msg')


# Generated at 2022-06-23 11:26:07.719255
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()

    # Test if it is initialized right
    assert isinstance(lookup_plugin, LookupModule)

    # Test if error is raised when asking for wrong attribute
    try:
        lookup_plugin.not_an_attribute
        assert False
    except AnsibleOptionsError:
        pass

    # Test if error is raised when asking for an attribute that should exist
    try:
        lookup_plugin.run
        assert True
    except AnsibleOptionsError:
        assert False

    # Test if error is raised when asking for wrong attribute
    try:
        lookup_plugin.run([], "", "", not_a_parameter=1)
        assert False
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-23 11:26:11.846374
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test using a standard global setting
    ret = _get_global_config('DEFAULT_SUDO')
    assert ret is False

    # test using a standard global setting
    ret = _get_global_config('DEFAULT_BECOME_USER')
    assert ret is False

    # test using a plugin setting
    ret = _get_plugin_config('ssh', 'connection', 'port', {})
    assert ret == 22

# Generated at 2022-06-23 11:26:13.187036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)



# Generated at 2022-06-23 11:26:16.015761
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # Pre-2.12
    value = MissingSetting('test', orig_exc='test')
    assert value.message == 'test'
    assert value.orig_exc == 'test'
    assert value.exception == 'test'

    # Post-2.12
    value = MissingSetting('test', orig_exc=LookupError('test'))
    assert value.message == 'test'
    assert value.orig_exc.message == 'test'
    assert value.exception.message == 'test'

# Generated at 2022-06-23 11:26:23.652444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert type(lookup_module) == LookupModule
    assert lookup_module.variable_manager is None
    assert lookup_module.loader is None
    assert lookup_module._display is not None
    assert type(lookup_module._display) == type(lookup_module._display)
    assert lookup_module.templar is None
    assert lookup_module.USE_DEFAULT is False
    assert lookup_module.current_vars is None
    assert lookup_module._options is None
    assert lookup_module.no_lookup is None
    assert lookup_module.cache is None
    assert lookup_module.env is None

# Generated at 2022-06-23 11:26:29.926279
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Constructor with two args
    try:
        raise MissingSetting('custom message', AnsibleOptionsError('error message', orig_exc='original exception'))
    except Exception as e:
        pass
    else:
        raise Exception('Exception not raised')

    # Constructor with single arg
    try:
        raise MissingSetting('custom message')
    except Exception as e:
        pass
    else:
        raise Exception('Exception not raised')

# Generated at 2022-06-23 11:26:32.429090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables = dict()
    lookup = LookupModule(variables)
    assert lookup is not None

# Generated at 2022-06-23 11:26:33.821322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-23 11:26:41.835285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.loader import get_all_plugin_loaders

    # Note: this test is not very complete, just testing that we don't get errors
    # currently
    # Note: we only test the first plugin type and first plugin in that type
    # due to time and scope constraints of this test
    # TODO: expand scope of this test

    loaders = get_all_plugin_loaders()
    # Py2/3 compat: list type/contents differ
    if PY3:
        # In Py3, the dict_values are not iterable
        loaders = list(loaders.values())
    pt, pn = next(iter(loaders))

    configs = read_

# Generated at 2022-06-23 11:26:45.483057
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('AnsibleLookupError: variable files are disabled')
    assert 'AnsibleLookupError: variable files are disabled' in str(e)

# Generated at 2022-06-23 11:26:46.843268
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:26:57.084909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    lkp = LookupModule()
    # create terms
    terms = ['color_changes', 'retry_files_save_path', 'remote_user']
    # get results
    results = lkp.run(terms)
    # assert that we got a list of values
    assert results is not None
    assert len(results) == len(terms)
    # assert that the retry_files_save_path is not empty string
    assert results[1] != ""
    # assert that remote_user is set to root
    assert results[2] == "root"
    # assert that color_changes is a Boolean True
    assert results[0] is True
    # repeat test for plugin_type and plugin_name (ssh/connection)
    terms = ['remote_user', 'port']
    plugin_

# Generated at 2022-06-23 11:27:00.284625
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting(msg='Test message')
    assert isinstance(exception, LookupBase)
    assert isinstance(exception, AnsibleOptionsError)
    assert exception.msg == 'Test message'

# Generated at 2022-06-23 11:27:03.100573
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting('example_error')
    assert ms.message == 'example_error'
    assert not hasattr(ms, 'orig_exc')

# Generated at 2022-06-23 11:27:06.351392
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    msg = 'AnsibleError: some error.'
    with pytest.raises(AnsibleOptionsError) as e:
        raise MissingSetting(msg)
    assert e.value.message == msg

# Generated at 2022-06-23 11:27:13.182678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(
        LookupModule().run(
            [
                'DEFAULT_BECOME_USER',
                'DEFAULT_ROLES_PATH',
                'RETRY_FILES_SAVE_PATH',
                'COLOR_OK',
                'COLOR_SKIP',
                'COLOR_CHANGED',
            ],
            wantlist=True,
        ) == ['root',
             ['/etc/ansible/roles', u'/usr/share/ansible/roles'],
             '/home/user/.ansible-retry',
             'green',
             'cyan',
             'yellow',
            ]
    )

    # test (1) the on_missing=error

# Generated at 2022-06-23 11:27:24.779313
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # testing setting plugin_name and plugin_type
    my_lm1 = LookupModule()
    my_lm1.set_options(direct={'plugin_name': 'local', 'plugin_type': 'connection'})

    result = my_lm1.run([u"executable"], variables={u'ansible_connection': u'local'})

    assert result == [u'/bin/sh']

    # testing setting on_missing = error
    my_lm2 = LookupModule()
    my_lm2.set_options(direct={'plugin_name': 'local', 'plugin_type': 'connection', 'on_missing': 'skip'})

    result = my_lm2.run([u"executable"], variables={u'ansible_connection': u'local'})


# Generated at 2022-06-23 11:27:33.067145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    config_val = list()

    assert isinstance(lookup_module, LookupModule)
    assert lookup_module.run(['DEFAULT_BECOME_USER'], {'DEFAULT_BECOME_USER': 'root'}) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER'], {'DEFAULT_BECOME_USER': ['root']}) == [['root']]
    with pytest.raises(AnsibleOptionsError) as exc:
        lookup_module.run(['DEFAULT_BECOME_USER'], {'FAKE_KEY': 'root'})
    assert 'Invalid setting identifier, "DEFAULT_BECOME_USER" is not a string' in to_native(exc.value)

# Generated at 2022-06-23 11:27:40.452767
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common.collections import ImmutableDict

    lookup_module = LookupModule()
    class_vars = vars(lookup_module)
    # Check for class instantiation
    assert class_vars["_display"] is not None
    # Check if 'run' method exists
    assert hasattr(lookup_module, 'run')
    assert callable(getattr(lookup_module, 'run'))

# Generated at 2022-06-23 11:27:43.160007
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'This is the message'
    orig_exc = AnsibleError('This is the original exception message')
    e = MissingSetting(msg, orig_exc=orig_exc)
    # Check if the constructor did it's job
    assert e._message == msg
    assert e.orig_exc == orig_exc

# Generated at 2022-06-23 11:27:46.808365
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "message"
    e = AnsibleError("test")
    ms = MissingSetting(msg,orig_exc=e)
    assert ms.message == msg
    assert ms.orig_exc == e

# Generated at 2022-06-23 11:27:47.443297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-23 11:27:52.018055
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    from ansible.errors import AnsibleOptionsError

    with pytest.raises(AnsibleOptionsError):
        MissingSetting('error')
        MissingSetting('warn')
        MissingSetting('skip')

# Generated at 2022-06-23 11:28:01.135996
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleOptionsError

    try:
        raise MissingSetting()
    except MissingSetting as e:
        assert str(e) == 'Option missing.'
        assert Sentinel in e.orig_exc
    else:
        assert False, 'Cannot reach here.'

    try:
        raise MissingSetting('missing')
    except MissingSetting as e:
        assert str(e) == 'Option missing.'
        assert 'missing' in e.orig_exc
    else:
        assert False, 'Cannot reach here.'

    try:
        raise MissingSetting('missing', orig_exc=AnsibleOptionsError('invalid'))
    except MissingSetting as e:
        assert str(e) == 'Option missing.'

# Generated at 2022-06-23 11:28:05.589605
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.six import PY3
    if not PY3:
        m = MissingSetting("test error", orig_exc="Unknown exception")
    else:
        m = MissingSetting("test error")
    assert m.message == 'test error'
    with pytest.raises(AnsibleOptionsError) as exc:
        raise m

# Generated at 2022-06-23 11:28:07.547829
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert isinstance(lm, LookupModule)


# Generated at 2022-06-23 11:28:09.449206
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting('An error message')


# Generated at 2022-06-23 11:28:16.498286
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting("test")
    assert m.orig_exc is None
    assert isinstance(m.message, string_types)
    assert m.message == "test"
    assert str(m)
    m = MissingSetting("test", orig_exc=Exception("orig"))
    assert m.orig_exc is not None
    assert isinstance(m.orig_exc, Exception)
    assert isinstance(m.message, string_types)
    assert m.message == "test"
    assert str(m)