

# Generated at 2022-06-23 11:18:10.164114
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('test-msg')
    assert exc.message == 'test-msg'
    assert exc.orig_exc is None

# Generated at 2022-06-23 11:18:12.397934
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert C.DEFAULT_HOST_LIST == './inventory', "Test to check default inventory file"

# Generated at 2022-06-23 11:18:14.577172
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "UNKNOWN is not defined in config"
    m = MissingSetting(msg)
    assert m.message == msg

# Generated at 2022-06-23 11:18:16.505335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_test = LookupModule()
    lookup_test.run(terms=["remote_user"])

# Generated at 2022-06-23 11:18:20.224721
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockClass(object):
        def __init__(self):
            self.display = ['msg']
        def warning(self, msg):
            return True
    mock_class = MockClass()
    try:
        LookupModule(mock_class)
    except Exception as e:
      assert "__init__()" in str(e)
      raise


# Generated at 2022-06-23 11:18:29.225235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule
    """
    # these are the module args which are used when running the module class
    args = dict(on_missing = 'error', plugin_type=None, plugin_name=None)

    terms = ['run_once', 'vault_password_file']
    config = {'run_once': 'False',
              'vault_password_file': '/tmp/testFile'}

    C.CONFIGURED = True

    # instantiate the LookupModule class
    lm = LookupModule(runner=None, 
                      loader=None, 
                      templar=None,
                      shared_loader_obj=None)

    # Add the config settings to the C object
    for key, val in config.items():
        setattr(C, key, val)

    # run

# Generated at 2022-06-23 11:18:37.472703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    terms_1 = [1]
    terms_2 = [2, '3']
    terms_3 = ['4', '5']
    terms_4 = [1, '2', '3']
    terms_5 = [1, 2, 3]
    terms_6 = ['foo', 'bar', 'baz']
    options = {}
    result_1 = [1]
    result_2 = [2, 3]
    result_3 = [4, 5]

    def _get_global_config_mock(config):
        if config == 4:
            return 4
        elif config == 5:
            return 5


# Generated at 2022-06-23 11:18:46.727823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    class FakeArgs:
        pass
    args = FakeArgs()
    args.on_missing = 'warn'
    args.plugin_type = 'become'
    args.plugin_name = 'sudo'
    # Test obsolete config setting
    terms = ['DEFAULT_HOST_LIST']
    try:
        lookup_plugin.run(terms, args)
    except AnsibleOptionsError as e:
        assert 'is no longer a valid setting' in to_native(e)
    # Test unknown config setting
    terms = ['UNKNOWN']
    try:
        lookup_plugin.run(terms, args)
    except AnsibleOptionsError as e:
        assert 'Unknown setting UNKNOWN' in to_native(e)
    # Test plugin type without plugin name

# Generated at 2022-06-23 11:18:54.616906
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    err = AnsibleError('An error message')
    assert err.get_error() == 'An error message'
    err.wrap_arounds('This is an error message.')
    assert err.get_error() == 'This is an error message.'
    err = MissingSetting(err)
    assert err.get_error() == 'An error message'
    err = MissingSetting('An error message', key='value')
    assert err.get_error() == 'An error message'



# Generated at 2022-06-23 11:19:01.920734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1: make sure that on_missing is not string, error should be raised
    lookup = LookupModule()
    options = {'plugin_type': 'cliconf', 'plugin_name': 'iosxr', 'on_missing': 123}
    result = lookup.run([], options, '')
    assert result[-1].startswith('on_missing')
    assert options['on_missing'] == 123

    # Test 2: make sure that on_missing is in ['error', 'warn', 'skip], otherwise error should be raised
    lookup = LookupModule()
    options = {'plugin_type': 'cliconf', 'plugin_name': 'iosxr', 'on_missing': 'test'}
    result = lookup.run([], options, '')
    assert result[-1].startswith('invalid setting')


# Generated at 2022-06-23 11:19:11.747867
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import sys
    import pytest
    from ansible.module_utils._text import to_native

    class Exp(AnsibleOptionsError):
        pass

    with pytest.raises(AnsibleOptionsError) as e:
        raise Exp('Terrible thing happened', orig_exc=Exp('Original exception'))
    assert to_native(e.value) == 'Terrible thing happened: Original exception'

    with pytest.raises(AnsibleOptionsError) as e:
        raise Exp('Terrible thing happened')
    assert to_native(e.value) == 'Terrible thing happened'

    Exp.__doc__ = 'I am a docstring'

    with pytest.raises(AnsibleOptionsError) as e:
        raise Exp('Terrible thing happened')

# Generated at 2022-06-23 11:19:19.926342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ut_params = {
        'terms': ['foo', 'bar'],
        'variables': {
            'foo': 'foovar',
            'bar': 'barvar',
        },
    }

    def test_runner(slf, terms, variables=None, **kwargs):
        return slf._get_plugin_config('test-plugin', 'test-type', terms, variables)

    l = LookupModule()
    l._get_plugin_config = test_runner
    assert l.run(variables=ut_params['variables'], **ut_params) == [ut_params['variable']['foo'], ut_params['variable']['bar']]

# Generated at 2022-06-23 11:19:27.070902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # module has no options
    assert LookupModule().run([], variables={'a': '1'}) == []

    # global config lookup should work
    assert LookupModule().run(['hostfile'], variables={'a': '1'}) == ['/home/user/.ansible_hosts']

    # plugin config lookup should work
    assert LookupModule().run(['remote_user'], variables={'a': '1'}, plugin_type='connection', plugin_name='local') == ['user']

# Generated at 2022-06-23 11:19:28.743920
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:19:30.454636
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')


# Generated at 2022-06-23 11:19:38.423548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a Dummy object for global config_module.C
    class Dummy:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    global config_module
    config_module_orig = config_module


# Generated at 2022-06-23 11:19:44.463921
# Unit test for constructor of class LookupModule
def test_LookupModule():
  import ansible.plugins.lookup.config, ansible.module_utils, ansible.module_utils._text, ansible.utils.sentinel

  # test with default constructor
  l = ansible.plugins.lookup.config.LookupModule()
  assert(isinstance(l, object))
  assert(isinstance(l, ansible.plugins.lookup.config.LookupModule))

# Generated at 2022-06-23 11:19:47.142988
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert str(MissingSetting()) == ""
    assert str(MissingSetting("Test message")) == "Test message"
    assert str(MissingSetting(["Test message", "Second entry"])) == "['Test message', 'Second entry']"

# Generated at 2022-06-23 11:19:50.773000
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupBase) is True, 'LookupModule is not a subclass of LookupBase'


# Generated at 2022-06-23 11:19:53.589421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    val = lookup_module.run(terms='DEFAULT_BECOME_USER')
    print(val)
    assert val[0]=='root'

# Generated at 2022-06-23 11:19:54.666661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Not implemented"


# Generated at 2022-06-23 11:19:55.971746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:20:02.921672
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=no-member
    lookup_module = LookupModule()
    assert not hasattr(lookup_module, '_templar')
    assert not hasattr(lookup_module, '_display')
    assert not hasattr(lookup_module, '_loader')
    assert not hasattr(lookup_module, '_templar')
    assert not hasattr(lookup_module, '_options')
    assert not hasattr(lookup_module, '_fail_on_undefined_errors')


# Generated at 2022-06-23 11:20:10.006865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import yaml
    terms=['test']
    variables=yaml.safe_load('''---
    ansible_connection: paramiko
    ansible_host: 127.0.0.1
    ansible_port: 22
    ansible_user: root
    ansible_password:
    ansible_ssh_pass:
    ''')
    l=LookupModule()
    l.run(terms, variables)
    return

# Generated at 2022-06-23 11:20:13.615581
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting()
    assert e.msg == '', e.msg
    assert e.orig_exc is None, e.orig_exc

    e = MissingSetting('message')
    assert e.msg == 'message', e.msg
    assert e.orig_exc is None, e.orig_exc

    e = MissingSetting('message', 'orig_exc')
    assert e.msg == 'message', e.msg
    assert e.orig_exc == 'orig_exc', e.orig_exc

# Generated at 2022-06-23 11:20:16.221528
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError) as execinfo:
        raise MissingSetting('test-message')
    assert str(execinfo.value) == 'test-message'

# Generated at 2022-06-23 11:20:21.146722
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("message")
    assert e.message == 'message'

    try:
        raise MissingSetting("message", AttributeError("Foo Bar"))
    except MissingSetting as e:
        assert e.orig_exc.args[0] == "Foo Bar"

# Generated at 2022-06-23 11:20:23.928763
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test_msg'
    orig_exc = 'orig_exc'
    ms = MissingSetting(msg, orig_exc)
    assert ms.msg == msg
    assert ms.orig_exc == orig_exc

# Generated at 2022-06-23 11:20:34.831994
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils.six import PY3
    if PY3:
        bla = b'bla'
        unicode_decode_error = UnicodeDecodeError(encoding='utf-8', object='xyz', start=0, reason='xyz')
    else:
        bla = 'bla'
        unicode_decode_error = LookupError('xyz')
    e = AttributeError('xyz')
    try:
        raise MissingSetting('Original exception was %s', orig_exc=e)
    except AnsibleLookupError as ae:
        assert type(ae) == AnsibleLookupError


# Generated at 2022-06-23 11:20:38.208688
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise AnsibleOptionsError('Invalid setting identifier, "%s" is not a string, its a %s' % (term, type(term)))
    except AnsibleOptionsError as e:
        raise MissingSetting(to_native(e), orig_exc=e)

# Generated at 2022-06-23 11:20:47.863228
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('AnsibleOptionsError msg', orig_exc='original exception')
    except MissingSetting as e:
        assert(e.orig_exc == 'original exception')
        assert(e.msg == 'AnsibleOptionsError msg')
        assert(e.CONSTANT == 'CONSTANT')
        assert(e.func_name == 'func_name')
        assert(e.func_args == 'func_args')
        assert(e.func_kwargs == 'func_kwargs')
        assert(e.to_text() == 'AnsibleOptionsError msg')
        assert(e.to_safe_text() == 'AnsibleOptionsError msg')

# Generated at 2022-06-23 11:20:49.150806
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 11:20:50.525200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:20:58.463216
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{plugin_name}} {{plugin_type}} {{on_missing}}')))
            ]
        )

    play = Play().load(play_source, variable_manager=variables, loader=loader)
    tqm = None

# Generated at 2022-06-23 11:21:02.100310
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Test message'
    orig_exc = 'Test original exception'
    x = MissingSetting(msg, orig_exc)
    assert x.msg == msg
    assert x.orig_exc == orig_exc

# Generated at 2022-06-23 11:21:02.775569
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting

# Generated at 2022-06-23 11:21:03.755967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-23 11:21:12.796533
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term = constants.DEFAULT_HOST_LIST
    LOOK = LookupModule()

    # test that a variable will cause an error
    with pytest.raises(AnsibleOptionsError):
        LOOK.run(terms=[term], variables={'foo': 'bar'})

    # test that a non string term gives an error
    with pytest.raises(AnsibleOptionsError):
        LOOK.run(terms=[term], variables={'foo': 'bar'})

    # test that a non string missing gives an error
    with pytest.raises(AnsibleOptionsError):
        LOOK.run(terms=[term], on_missing=1234)

    # test that a missing term warns

# Generated at 2022-06-23 11:21:20.809318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_value_dict = {}
    lookup_value_dict['terms'] = ['DEFAULT_ROLES_PATH', 'NON_EXISTING_SETTING']
    lookup_value_dict['plugin_type'] = 'inventory'
    lookup_value_dict['plugin_name'] = 'consul'
    lookup_value_dict['on_missing'] = 'error'
    lookup_module = LookupModule()
    result = []
    try:
        result = lookup_module.run(**lookup_value_dict)
    except AnsibleLookupError as e:
        assert 'Unable to find setting NON_EXISTING_SETTING' in to_native(e)
    assert result == ['@/etc/ansible/roles']

# Generated at 2022-06-23 11:21:24.512529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert isinstance(lookup_mod, LookupModule)
    # Test _get_plugin_config
    try:
        lookup_mod._get_plugin_config(None, "connection", "pname", 1, "term")
    except Exception:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-23 11:21:27.827676
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    instance = MissingSetting('test')

    assert instance.msg == 'test'
    assert 'test' in repr(instance)
    assert str(instance) == 'test'

# Generated at 2022-06-23 11:21:35.699278
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Invoke run without any arguments
    lookup_obj = LookupModule()
    assert lookup_obj.run() == []

    # Invoke run with invalid argument
    lookup_obj = LookupModule()
    assert lookup_obj.run(None) == []

    # Invoke run with valid arguments
    # args.terms = ['project_dir']
    # args.plugin_type = None
    # args.plugin_name = None
    # args.on_missing = 'error'
    # args.variable = None
    lookup_obj = LookupModule()
    assert lookup_obj.run(['project_dir']) == ['/Users/piyush/work/ansible-repo/ansible']

# Generated at 2022-06-23 11:21:37.173181
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lpm = LookupModule()
    result = lpm.run(['hostfile'])
    assert result is not None

# Generated at 2022-06-23 11:21:37.941751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    f = LookupModule()

# Generated at 2022-06-23 11:21:48.474302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule Test: test_LookupModule_run() - runs a simple test."""
    from ansible.plugins.loader import lookup_loader

    results = lookup_loader.get('config').run([
        'DEFAULT_BECOME_USER',
        'DEFAULT_BECOME_METHOD',
        'DEFAULT_BECOME_PASS',
    ], variables={
        'ansible_become_user': 'sudo_user',
        'ansible_become_method': 'enable',
        'ansible_become_pass': 'sudo_password'
    })

    assert results == ['root', 'sudo', 'sudo_password']

# Generated at 2022-06-23 11:21:58.993672
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case: LookupModule with global config
    result_global_config = {}
    result_global_config['name'] = 'ansible'
    result_global_config['version'] = 2.6
    result_global_config['default_remote_user'] = 'root'
    result_global_config['default_remote_tmp'] = '/tmp/ansible'
    result_global_config['default_module_name'] = 'command'
    result_global_config['default_sudo_user'] = 'root'

    terms_global_config = []
    terms_global_config.extend(result_global_config.keys())
    lookup_module_global_config = LookupModule()
    lookup_module_global_config.set_options(terms=terms_global_config)
    result_list_global_config = lookup_

# Generated at 2022-06-23 11:22:03.180433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a instance of LookupModule class
    instance = LookupModule.run(None, None)
    assert isinstance(instance, LookupModule, 'LookupModule class is not initialized')

# Generated at 2022-06-23 11:22:12.262693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup as lookup_plugins
    import ansible.plugins.shell as shell_plugins
    import ansible.plugins.httpapi as httpapi_plugins
    import ansible.plugins.cache as cache_plugins
    import ansible.plugins.cliconf as cliconf_plugins
    import ansible.plugins.connection as connection_plugins
    import ansible.plugins.inventory as inventory_plugins
    import ansible.plugins.vars as vars_plugins
    import ansible.plugins.netconf as netconf_plugins
    import ansible.plugins.shell as shell_plugins
    import ansible.plugins.callback as callback_plugins
    import ansible.plugins.action as action_plugins
    import ansible.plugins.become as become_plugins

# Generated at 2022-06-23 11:22:13.802830
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.get_option('on_missing') == 'error'
    return lookup_module


# Generated at 2022-06-23 11:22:22.941079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_REMOTE_USER']) == ['root'], 'Test case 1 failed'
    assert lookup.run(['DEFAULT_REMOTE_USER'], plugin_name='sh', plugin_type='shell') == ['root'], 'Test case 2 failed'
    assert lookup.run(['DEFAULT_REMOTE_USER', 'DEFAULT_ROLES_PATH']) == ['root', ['roles']], 'Test case 3 failed'
    assert lookup.run(['DEFAULT_REMOTE_USER', 'DEFAULT_ROLES_PATH'], plugin_name='sh', plugin_type='shell') == ['root', ['roles']], 'Test case 4 failed'

# Generated at 2022-06-23 11:22:26.657504
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'missing message'
    orig = 'original exception'
    instance = MissingSetting(msg, orig)
    assert instance.message == 'missing message'
    assert instance.orig_exc == 'original exception'

# Generated at 2022-06-23 11:22:32.291105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    my_test_terms = ['DEFAULT_BECOME_USER']
    my_test_on_missing = 'error'
    my_test_variables = None
    result = module.run(my_test_terms, my_test_variables, on_missing=my_test_on_missing)
    print(result)
    assert len(result) > 0


# Generated at 2022-06-23 11:22:38.594315
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test for correct message
    assert MissingSetting("message", orig_exc=Exception("orig_exception")).message
    # Test for no optional kwargs
    assert MissingSetting("message").message
    # Test for case of passing in a list as message
    assert MissingSetting(["mess", "age"], orig_exc=Exception("orig_exception")).message

# Generated at 2022-06-23 11:22:49.358201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run([]) == []

    terms = ['DEFAULT_BECOME_USER']
    assert lm.run(terms) == [u'root']

    terms = ['DEFAULT_ROLES_PATH']
    assert lm.run(terms) == [u'/etc/ansible/roles:/usr/share/ansible/roles']

    variables = {}
    assert lm.run(terms, variables) == [u'/etc/ansible/roles:/usr/share/ansible/roles']

    kwargs = {}
    assert lm.run(terms, variables, **kwargs) == [u'/etc/ansible/roles:/usr/share/ansible/roles']

    terms = ['UNKNOWN', 'U2']

# Generated at 2022-06-23 11:22:51.619470
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Test error message'
    exc = MissingSetting(msg)
    assert exc.message == msg

# Generated at 2022-06-23 11:22:54.822809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Returns the value for a config option.
    """
    terms = 'DEFAULT_BECOME_USER'
    lookup = LookupModule()
    ret = lookup.run(terms)

    result = 'root'
    assert ret == result

# Generated at 2022-06-23 11:23:02.207005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    import sys
    import os
    import pytest

    # Change the path to enable import of the plugin
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../../..'))
    from lib.ansible.plugins.lookup.config import LookupModule

    # create a mock variable manager
    class MockVariableManager(object):
        def __init__(self):
            self.vars = dict()

        def __getitem__(self, key):
            return self.vars[key]

        def __setitem__(self, key, value):
            self.vars[key] = value

    # mock display class for LookupModule for testing

# Generated at 2022-06-23 11:23:03.832690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        assert False, "Unit test for constructor of class LookupModule failed"

# Generated at 2022-06-23 11:23:13.227906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # simple run
    ret = lookup.run(terms=['DEFAULT_ROLES_PATH'])
    assert ret[0] == '/etc/ansible/roles:/usr/share/ansible/roles'
    # run with warning option
    ret = lookup.run(terms=['UNKNOWN_SETTING'], on_missing='warn') 
    ret = lookup.run(terms=['UNKNOWN_SETTING'], on_missing='warn') 

    # run with skipping option
    ret = lookup.run(terms=['UNKNOWN_SETTING'], on_missing='skip') 
    # run with error option
    ret = lookup.run(terms=['UNKNOWN_SETTING'], on_missing='error') 

    # run with plugin name and type

# Generated at 2022-06-23 11:23:16.413500
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting.__module__ + '.MissingSetting'
    err = MissingSetting("Setting not found")
    assert err.message == 'Setting not found'
    assert str(err) == 'Setting not found'
    assert repr(err) == error

# Generated at 2022-06-23 11:23:17.994929
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('setting', orig_exc=None)

# Generated at 2022-06-23 11:23:29.601760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()

    # verifying that a positive test case is working correctly
    # test with default options, find the value for option DEFAULT_ROLES_PATH
    assert plugin.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{}) == [u'/etc/ansible/roles']

    # verifying that a negative test case is raising the correct exception
    # when we are looking for an invalid option
    from ansible.errors import AnsibleOptionsError
    try:
        plugin.run(terms=['UNKNOWN_OPTION'], variables=None, **{})
        pytest.fail()
    except AnsibleOptionsError as e:
        assert to_native(e) == 'Unable to find setting UNKNOWN_OPTION'

    # verifying that a negative test case is raising the correct exception
    #

# Generated at 2022-06-23 11:23:35.308336
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(var_options={'inventory_hostname': 'fake.host'}, direct={'plugin_name': 'create_file', 'plugin_type': 'shell', 'on_missing': 'warn'})
    assert len(l.run([''])) == 0
    #if __name__ == '__main__':
    #    test_LookupModule()

# Generated at 2022-06-23 11:23:46.108840
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test global config
    #
    # Test that the config returns the correct value
    assert(LookupModule().run(terms=['DEFAULT_BECOME_USER'], variables=dict(), on_missing='error') == ['root'])
    # Test that the config returns an error when the configuration key is not present
    try:
        LookupModule().run(terms=['DEFAULT_BECOME_USER1'], variables=dict(), on_missing='error')
    except AnsibleLookupError:
        pass
    else:
        assert(0)
    # Test that the config returns an error when on_missing is not in the correct values
    try:
        LookupModule().run(terms=['DEFAULT_BECOME_USER'], variables=dict(), on_missing='error1')
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-23 11:23:51.456662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    expected_result = 'root'
    config = LookupModule()
    result = config.run(terms, variables=None, **{})
    assert result[0] == expected_result


# Generated at 2022-06-23 11:24:01.110208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["DEFAULT_BECOME_USER"]) == ["root"]

    module = LookupModule()
    assert module.run(["DEFAULT_BECOME_USER"], direct={"plugin_type":"shell"}) == ["root"]

    module = LookupModule()
    assert module.run(["DEFAULT_BECOME_USER"], direct={"plugin_type":"shell", "plugin_name":"sh"}) == ["root"]

    module = LookupModule()
    assert module.run(["DEFAULT_BECOME_USER"], direct={"on_missing":"skip"}) == ["root"]

    module = LookupModule()

# Generated at 2022-06-23 11:24:06.469016
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # Test the constructor
    m = MissingSetting('No such configuration option "foo" found.',
                       orig_exc=Exception('No such configuration option "foo" found.'))
    assert(isinstance(m, AnsibleOptionsError))
    assert(m.message == 'No such configuration option "foo" found.')
    assert(isinstance(m.orig_exc, Exception))
    assert(m.orig_exc.message == 'No such configuration option "foo" found.')

# Generated at 2022-06-23 11:24:10.140220
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Assert that MissingSetting raises an exception as expected"""
    try:
        raise MissingSetting("Could not find setting")
    except MissingSetting as my_e:
        assert 'MissingSetting' in str(my_e)
        assert 'Could not find setting' in str(my_e)

# Generated at 2022-06-23 11:24:18.462345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(["DEFAULT_BECOME_USER"], variables=dict([('ansible_user', 'test')])) == ['root']
    assert lm.run(["DEFAULT_BECOME_USER"], variables=dict([('ansible_user', 'test')]), plugin_type='connection', plugin_name='ssh') == ['root']
    assert lm.run(["DEFAULT_BECOME_USER"], variables=dict([('ansible_user', 'test')]), plugin_type='shell', plugin_name='sh') == ['root']
    assert lm.run(["DEFAULT_BECOME_USER"], variables=dict([('ansible_user', 'test')]), plugin_name='ssh') == []

# Generated at 2022-06-23 11:24:20.927077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # This is a no-op test, simply verify there is no Exception thrown
    assert True

# Generated at 2022-06-23 11:24:23.000626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:24:32.385776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_class = lookup_loader.get('config')
    assert lookup_class is not None

    # Assert that run raises exception when plugin_type is not given
    with pytest.raises(AnsibleOptionsError):
        lookup_class.run(terms=['port'], variables={}, plugin_name='ssh')

    # Assert that run raises exception when plugin_name is not given
    with pytest.raises(AnsibleOptionsError):
        lookup_class.run(terms=['port'], variables={}, plugin_type='connection')

    # Assert that run raises exception when terms is not of type string_types

# Generated at 2022-06-23 11:24:43.053229
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys

    import ansible.constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    from units.mock.loader import DictDataLoader
    from units.mock.lookup import MockLookup, LookupModuleMock, MockLoader, MockTask, MockVarsModule
    from units.mock.inventory import MockInventory
    from ansible.plugins.loader import lookup_loader

    # Create a mock loader object
    loader = DictDataLoader({})

    # Create a mock inventory object
    inventory = MockInventory(loader=loader)

    # Create a mock vars plugin object
    vars_plugin = MockVarsModule()

    # Create a mock task object
    task = MockTask()

    # Create a

# Generated at 2022-06-23 11:24:48.752386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    plugin_type = 'vars'
    plugin_name = 'setup'
    get_plugin_config = _get_plugin_config(plugin_name, plugin_type, 'ansible_all_ipv4_addresses', {})
    print(get_plugin_config)

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:24:49.981747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:25:02.759777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class AnsibleOptions:
        def __init__(self, **agent_kwargs):
            for key,value in agent_kwargs.items():
                setattr(self, key, value)

    def _get_plugin_config(pname, ptype, config, variables):
        return None

    def _get_global_config(config):
        return None

    class LookupBase:
        def run(self, terms, variables=None, **kwargs):
            # Verify that the correct method is called
            try:
                assert getattr(self, 'set_options')
                assert getattr(self, 'get_option')
                if terms == ['foo']:
                    return None
                else:
                    raise ValueError
            except AssertionError:
                raise AssertionError('Incorrect method called')

# Generated at 2022-06-23 11:25:13.265536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # Since the method depends on constants
    # so it is hard to test it, so we just
    # run it to see whether exceptions raise.

    lookup_ins = LookupModule()
    lookup_ins.run(terms=["FOO"], variables={"FOO": "BAR"})
    lookup_ins.run(terms=["DEFAULT_REMOTE_USER"], variables={"DEFAULT_REMOTE_USER": "BAR"})
    lookup_ins.run(terms=["DEFAULT_BECOME_USER"], variables={"DEFAULT_BECOME_USER": "BAR"})
    lookup_ins.run(terms=["DEFAULT_ROLES_PATH"], variables={"DEFAULT_ROLES_PATH": "BAR"})
    lookup_

# Generated at 2022-06-23 11:25:22.843621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    dummy_loader = DataLoader()
    dummy_inventory = Inventory(loader=dummy_loader, variable_manager=VariableManager(), host_list=[])

    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(dummy_loader)
    lookup_plugin.set_inventory(dummy_inventory)

    return lookup_plugin
# Unit test call to lookup
# lookup_plugin = test_LookupModule()
# result = lookup_plugin.run(terms=["C.DEFAULT_ROLES_PATH"])
# print(result)

# Generated at 2022-06-23 11:25:25.525084
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('I am broken')
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert e.message == 'I am broken'

# Generated at 2022-06-23 11:25:28.159134
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('A setting is missing')
    except MissingSetting as e:
        assert 'A setting is missing' == to_native(e)

# Generated at 2022-06-23 11:25:31.368747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin
    assert isinstance(lookup_plugin, LookupBase)
    assert lookup_plugin.set_options

# Generated at 2022-06-23 11:25:34.023957
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test code for LookupModule'''
    # Given
    lookup_module = LookupModule()
    # When
    lookup_module.run(terms=['DEFAULT_BECOME_USER'])

# Generated at 2022-06-23 11:25:43.836055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    temp = plugin_loader
    plugin_loader.connection_loader.get = lambda x, y: None
    from ansible.plugins.connection import ConnectionBase
    plugin_loader.connection_loader.all = lambda: {ConnectionBase._load_name: ConnectionBase}

# Generated at 2022-06-23 11:25:51.409950
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Check that input are strings
    with pytest.raises(AnsibleOptionsError) as e:
        lookup.run([{"setting": "DEFAULT_BECOME_USER"}])
    # Check that input is a valid setting
    with pytest.raises(AnsibleLookupError) as e:
        lookup.run(["UNKNOWN"])
    with pytest.raises(AnsibleOptionsError):
        lookup.run(['DEFAULT_BECOME_USER'], on_missing='bad')

# Generated at 2022-06-23 11:26:02.166566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.color import stringc
    from ansible.utils.sentinel import Sentinel

    lookup_module = LookupModule()
    assert(lookup_module.run([], [], {}) == [])
    assert(lookup_module.run(['DEFAULT_BECOME_USER'], [], {}) == ['root'])
    assert(lookup_module.run(['DEFAULT_BECOME_USER', 'ANSIBLE_CONFIG'], [], {}) == ['root', '/etc/ansible/ansible.cfg'])
    assert(lookup_module.run(['DEFAULT_BECOME_USER', 'ANSIBLE_CONFIG', 'COLOR_OK'], [], {}) == ['root', '/etc/ansible/ansible.cfg', stringc('ok', 'green')])

    # testing plugin

# Generated at 2022-06-23 11:26:06.478585
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting()
    assert isinstance(m, AnsibleError)
    assert isinstance(m, AnsibleOptionsError)
    m = MissingSetting('msg')
    assert m.msg == 'msg'
    m = MissingSetting('msg', orig_exc=Exception())
    assert isinstance(m.orig_exc, Exception)

# Generated at 2022-06-23 11:26:07.780253
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting("Missing setting foo")

# Generated at 2022-06-23 11:26:08.785801
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('test', orig_exc=AnsibleError('test')).message == 'test'
    assert MissingSetting('test').message == 'test'

# Generated at 2022-06-23 11:26:11.163332
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('some setting is missing', orig_exc=None)
    except AnsibleOptionsError as e:
        assert isinstance(e, MissingSetting)
        assert e.orig_exc == None

# Generated at 2022-06-23 11:26:12.981482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("\nUnit test for constructor of class LookupModule\n")
    lookup_module = LookupModule()



# Generated at 2022-06-23 11:26:17.218189
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        kwargs = {}
        kwargs['msg'] = 'message'
        kwargs['orig_exc'] = ''
        MissingSetting(**kwargs)

from ansible.module_utils.basic import AnsibleModule



# Generated at 2022-06-23 11:26:23.539864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    looker = LookupModule()
    res = looker.run(['DEFAULT_BECOME_METHOD'], {}, wantlist=True)
    assert len(res) == 1, res
    assert res.pop() == 'sudo', res
    res = looker.run(['DEFAULT_ROLES_PATH'], {}, wantlist=False)
    assert len(res) == 1, res
    assert res.pop().split(':') == ['/etc/ansible/roles', '~/.ansible/roles', '/usr/share/ansible/roles'], res

# Generated at 2022-06-23 11:26:24.577762
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None


# Generated at 2022-06-23 11:26:27.524930
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('msgvalue', 'orig_exc')
    assert e.msg == 'msgvalue'
    assert e.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:26:33.767736
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ansible_options_error = MissingSetting('Unable to find setting', 'Unable to load shell plugin "sh"')
    assert ansible_options_error.msg == 'Unable to find setting'
    assert ansible_options_error.orig_exc == 'Unable to load shell plugin "sh"'

# Generated at 2022-06-23 11:26:36.592216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:26:42.835552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock LookupModule
    lookup_plugin = LookupModule()

    # Set its attributes
    lookup_plugin.set_options(var_options={}, direct={})

    # Create a sample terms
    terms = [C.DEFAULT_BECOME_METHOD]

    # Invoke method run of LookupModule
    res = lookup_plugin.run(terms=terms, variables={}, plugin_type='become')

    # Assert method run return value
    assert res == ['sudo']

# Generated at 2022-06-23 11:26:46.933954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')
    assert hasattr(lookup.run, '__call__')
    assert callable(lookup.run)


# Generated at 2022-06-23 11:26:47.516997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:26:48.843259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:26:55.891282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH',
             'RETRY_FILES_SAVE_PATH', 'COLOR_OK','COLOR_CHANGED','COLOR_SKIP',
             'UNKNOWN', 'remote_user', 'port', 'remote_tmp']
    l = LookupModule()

    def mock_set_options(self, var_options=None, direct=None):
        self.var_options = var_options
        self.direct = direct

    def mock_get_option(self, option_key):
        return self.direct.get(option_key, None)


# Generated at 2022-06-23 11:26:56.853612
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:26:58.097266
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("foo")
    except MissingSetting as e:
        assert e.message == "foo"
        assert not e.orig_exc

# Generated at 2022-06-23 11:27:04.855289
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test if MissingSetting is raised as expected
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting("AnsibleOptionsError raised as expected")

    # Test if MissingSetting inherits from AnsibleOptionsError
    try:
        raise MissingSetting("AnsibleOptionsError raised as expected")
    except AnsibleOptionsError:
        assert True
    else:
        assert False, "AnsibleOptionsError not raised"

# Generated at 2022-06-23 11:27:05.493653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:27:15.682559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_type(terms, ptype, pname, expected):
        lookup_module = LookupModule()

        results = lookup_module.run(terms, plugin_type=ptype, plugin_name=pname)
        assert results == expected
        for result in results:
            assert isinstance(result, type(expected[0]))

    def test(terms, expected):
        test_type(terms, None, None, expected)

        # Testing with ssh plugin
        test_type(terms, 'connection', 'ssh', expected)

        # Testing with shell (sh) plugin
        expected_shell_plugin = [C.DEFAULT_SHELL_REMOTE_TMP]
        test_type(terms, 'shell', 'sh', expected_shell_plugin)


    # Testing with a list of strings

# Generated at 2022-06-23 11:27:24.520921
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting()
    assert error.orig_exc is None
    error = MissingSetting(msg='Test message')
    assert error.message == 'Test message'
    assert error.orig_exc is None
    error = MissingSetting(orig_exc=AttributeError('Example attribute error'))
    assert str(error.orig_exc) == 'Example attribute error'
    error = MissingSetting(msg='Test message', orig_exc=AttributeError('Example attribute error'))
    assert error.message == 'Test message'
    assert str(error.orig_exc) == 'Example attribute error'

# Generated at 2022-06-23 11:27:32.604667
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import connection_loader
    from ansible.errors import AnsibleError
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 11:27:33.475799
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 11:27:35.239424
# Unit test for constructor of class LookupModule
def test_LookupModule():
    y = LookupModule()


# Generated at 2022-06-23 11:27:39.199216
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("test")
    assert e.orig_exc is None

    e = MissingSetting("test", orig_exc=Exception("bad"))
    assert isinstance(e.orig_exc, Exception)

# Generated at 2022-06-23 11:27:43.700125
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.common.collections import ImmutableDict
    ex = MissingSetting('a message')
    assert ex.message == 'a message'
    assert ex.orig_exc is None

    ex = MissingSetting('a message', orig_exc=ValueError('An exception'))
    assert ex.message == 'a message'
    assert ex.orig_exc.message == 'An exception'

    ex = MissingSetting(ImmutableDict(key='value'))
    assert ex.message == 'An immutable object was encountered'
    assert ex.orig_exc is None

    ex = MissingSetting('', orig_exc=ValueError('An exception'))
    assert ex.message == 'An exception'
    assert ex.orig_exc.message == 'An exception'

# Generated at 2022-06-23 11:27:49.097837
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError

    msg = 'custom error message, an excType was not defined'
    exc = AnsibleError(msg)
    missing_setting = MissingSetting(msg, orig_exc=exc)
    assert missing_setting.orig_exc == exc

# Generated at 2022-06-23 11:27:50.910641
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.set_options() == {}

# Generated at 2022-06-23 11:28:01.123071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import connection_loader
    import ansible.constants as C

    p = connection_loader.get('local', class_only=True)
    p.set_options(direct={'transport': 'local'})

    lookup_module = LookupModule()

    # test with existing config value
    lookup_module.set_options(direct={'plugin_name': p._load_name, 'plugin_type': 'connection'})
    assert lookup_module.run(['module_path'], variables={'module_path': '/foo,/bar'}) == ['/foo,/bar']

    # test with missing config value
    lookup_module.set_options(direct={'plugin_name': p._load_name, 'plugin_type': 'connection'})

# Generated at 2022-06-23 11:28:02.294731
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:28:03.387739
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:28:07.051980
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Ansible configuration setting was not found")
    except MissingSetting as e:
        assert e.message == "Ansible configuration setting was not found"
        assert e.args == ("Ansible configuration setting was not found",)

# Generated at 2022-06-23 11:28:10.253212
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Unable to get config'
    MissingSetting(msg)
    MissingSetting(msg, orig_exc=RuntimeError('something went wrong'))