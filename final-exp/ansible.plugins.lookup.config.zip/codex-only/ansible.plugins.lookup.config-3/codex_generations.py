

# Generated at 2022-06-23 11:18:17.337997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_option = lambda *a, **kw: 'error'
    with pytest.raises(AnsibleOptionsError) as e:
        l.run([1])
    assert 'not a string' in to_native(e.value)
    with pytest.raises(AnsibleOptionsError) as e:
        l.run(['env', 'error'])
    assert 'one of "error", "warn" or "skip"' in to_native(e.value)
    with pytest.raises(AnsibleOptionsError) as e:
        l.run(['plugin_type', 'plugin_name'], plugin_type='become')
    assert 'Both plugin_type and plugin_name are required' in to_native(e.value)

# Generated at 2022-06-23 11:18:18.075531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:18:25.310070
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise AnsibleOptionsError('msg')
    except AnsibleError as e:
        assert str(e) == 'msg'
        assert isinstance(e, AnsibleError)
        assert not isinstance(e, AnsibleOptionsError)
        try:
            raise MissingSetting('msg', orig_exc=e)
        except AnsibleError as e2:
            assert str(e2) == 'msg'
            assert isinstance(e2, AnsibleOptionsError)
            assert not isinstance(e2, MissingSetting)
            assert isinstance(e2, AnsibleError)
            assert e == e._orig_exc

# Generated at 2022-06-23 11:18:26.303231
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()


# Generated at 2022-06-23 11:18:35.417187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We need to create an object for class LookupModule for unit testing
    # Create one with args we need
    lookup_obj = LookupModule(loader=None, templar=None, shared_loader_obj=None)

    # Test case of on_missing='error'
    # Run the run method with args we want
    try:
        lookup_obj.run(terms=['xyz'], on_missing='error')
    except Exception:
        pass
    else:
        raise Exception("Did not raise exception with on_missing='error'")

    # Test case of on_missing='warn'
    # Run the run method
    lookup_obj.run(terms=['xyz'], on_missing='warn')

    # Test case of on_missing='skip'
    # Run the run method

# Generated at 2022-06-23 11:18:37.196628
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting()
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)

# Generated at 2022-06-23 11:18:37.966347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._display

# Generated at 2022-06-23 11:18:38.935200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('config')

# Generated at 2022-06-23 11:18:43.632631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    opts = {'plugin_type': 'cliconf', 'plugin_name': 'netconf'}
    l.set_options(direct=opts)

    assert l.get_option('plugin_type') == 'cliconf'
    assert l.get_option('plugin_name') == 'netconf'

# Generated at 2022-06-23 11:18:46.920399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule """
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:18:50.454552
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test message'
    orig_exc = Exception(msg)
    x = MissingSetting(msg, orig_exc)
    assert msg == x.message
    assert orig_exc == x.orig_exc

# Generated at 2022-06-23 11:18:58.521687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock the config using the python mock module
    from unittest.mock import patch, MagicMock

    # mock the config option 'DEFAULT_BECOME_USER'
    C.DEFAULT_BECOME_USER = MagicMock(return_value='user')
    # mock the config option 'DEFAULT_BECOME_METHOD'
    C.DEFAULT_BECOME_METHOD = MagicMock(return_value='su')
    # mock the config option 'DEFAULT_REMOTE_USER'
    C.DEFAULT_REMOTE_USER = MagicMock(return_value='root')
    # mock the config option 'REMOTE_TMP'
    C.REMOTE_TMP = MagicMock(return_value='$HOME/.ansible/tmp')
    # mock the config option 'REMOTE_TMP'
   

# Generated at 2022-06-23 11:19:01.022735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 11:19:03.487268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l.set_options(var_options={"ANSIBLE_REMOTE_TMP": "/tmp"}, direct={"plugin_type": "shell", "plugin_name": "bash"})

    assert l.run(["remote_tmp"]) == ["/tmp"]



# Generated at 2022-06-23 11:19:10.781031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # initialise an object 
    look = LookupModule()
    plugin_name = 'foo'
    plugin_type = 'bar'
    config_name = 'fobar'
    config_value = 'barfoo'
    # prepare mock for C
    C.config = Mock()
    C.config.DEFAULT_BECOME_USER = config_value
    C.config.get_config_value.return_value = config_value
    # prepare mock for LookupBase
    LookupBase.set_options = Mock()
    LookupBase.set_options.return_value = config_value
    # create a mock for getattr
    def getattr(value):
        return value


# Generated at 2022-06-23 11:19:20.324194
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test class for the Ansible module 'debug'. This is required for initializing the constants
    # If a Ansible module is not initialized, the constants are not created
    from ansible.modules.debug import ModuleArgsParser
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars

    class DummyModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False, check_invalid_arguments=False, mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=False):
            self.boolean = 'yes'
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks


# Generated at 2022-06-23 11:19:29.974617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule instance
    lookup = LookupModule()

    # Test the run method by passing in a config term as a string
    test_config_term = "DEFAULT_FORKS"
    result = lookup.run(terms=test_config_term, variables={'var': 'foo'}, on_missing='error')
    assert result[0] == C.DEFAULT_FORKS
    # Test the run method by passing in a config term as a list
    result = lookup.run(terms=[test_config_term], variables={'var': 'foo'}, on_missing='error')
    assert result[0] == C.DEFAULT_FORKS

    # Test the run method for a missing config term
    test_config_term = "UNKNOWN_CONFIG_TERM"

# Generated at 2022-06-23 11:19:31.665526
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:19:36.449520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyClass(object):
        def __init__(self, value=None, name=None, config_name=None, config_value=None):
            self.value = value
            self.name = name
            self.config_name = config_name
            self.config_value = config_value
        def get_config(self):
            return self.config_value
    dummy_obj = DummyClass(name="test", config_name='test', config_value=True)

# Generated at 2022-06-23 11:19:38.406913
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run is not None
    assert lookup.run_is_direct is not None

# Generated at 2022-06-23 11:19:39.666323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()

# Generated at 2022-06-23 11:19:42.171329
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('Example of error message')
    assert missing_setting.message == 'Example of error message'

# Generated at 2022-06-23 11:19:43.266310
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting('Test')

# Generated at 2022-06-23 11:19:44.364731
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:19:46.079309
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('message')
    except MissingSetting as e:
        assert 'message' in str(e)

# Generated at 2022-06-23 11:19:57.513425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockModule(object):
        def __init__(self, return_value=None):
            self.return_value = return_value
        def get_option(self, option_name):
            return self.return_value

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import become_loader, cache_loader, callback_loader, cliconf_loader, connection_loader, httpapi_loader, inventory_loader, lookup_loader, netconf_loader, shell_loader, modules_loader, module_utils_loader, terminal_loader, test_loader, vars_loader

    # test case 1: PTY allocation is enabled by default in the constants module

# Generated at 2022-06-23 11:19:58.120356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:19:58.617862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:20:00.315072
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting("test")
    assert isinstance(obj, AnsibleOptionsError)

# Generated at 2022-06-23 11:20:03.113170
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # pylint: disable=maybe-no-member
    assert issubclass(MissingSetting, AnsibleOptionsError)
    assert issubclass(MissingSetting, Exception)

# Generated at 2022-06-23 11:20:14.832151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get_plugin_config
    terms = ['connection', 'port']
    plugin_type = 'connection'
    plugin_name = 'ssh'
    variables = {}
    assert LookupModule().run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name) == [22]

    # get_global_config
    terms = ['DEFAULT_ROLES_PATH']
    assert LookupModule().run(terms) == [u'/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/plugins/roles:/home/mofc/ansible_play/practice/roles']

    # get_plugin_config with error_missing = 'error'

# Generated at 2022-06-23 11:20:22.208936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing configuration settings with correct input
    lu = LookupModule()
    mock_find_file = lambda x, y, z: [x]
    lu._loader = Mock()
    lu._loader.get_basedir = lambda x: '.'
    lu.find_file_in_search_path = mock_find_file
    lu._display = Mock()
    terms = ['DEFAULT_BECOME_USER']
    test_res = lu.run(terms, variables=None, direct=dict())
    assert test_res == [C.DEFAULT_BECOME_USER]

    # Testing configuration settings without plugin name and type
    terms = ['UNKNOWN']
    with pytest.raises(AnsibleOptionsError):
        test_res = lu.run(terms, variables=None, direct=dict())

# Generated at 2022-06-23 11:20:33.137123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.constants as C
    from ansible.module_utils._text import to_text
    from io import StringIO
    from collections import namedtuple

    # test the error message when both are not set
    try:
        result = LookupModule.run.__wrapped__(None,['given_setting'])
        assert False, 'Exception was not raised'
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in to_text(e)

    # test the error message when only one is set

# Generated at 2022-06-23 11:20:37.246795
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = AnsibleOptionsError('invalid option "missing"')
    missing_setting = MissingSetting('Unable to find setting "missing"', orig_exc=exception)
    assert missing_setting.message == 'Unable to find setting "missing"'
    assert missing_setting.orig_exc.message == 'invalid option "missing"'

# Generated at 2022-06-23 11:20:40.396945
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test error message')
    except AnsibleOptionsError as e:
        assert isinstance(e, AnsibleOptionsError)
        assert str(e) == 'Test error message'

# Generated at 2022-06-23 11:20:49.593879
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test when plugin_name and plugin_type are not set
    lookup_module = LookupModule()
    test_terms = ['USERNAME']
    ret = lookup_module.run(test_terms)
    assert ret == [C.DEFAULT_REMOTE_USER]

    # test when plugin_type and plugin_name are set
    lookup_module = LookupModule()
    test_terms = ['remote_tmp']
    ret = lookup_module.run(test_terms, plugin_type='shell', plugin_name='sh')
    assert ret == [C.DEFAULT_REMOTE_TMP]

# Generated at 2022-06-23 11:20:53.797554
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # construct the exception
    try:
        raise MissingSetting(msg="test message")
    except MissingSetting as e:

        # check if the exception has message
        assert(e.message == "test message")

        # check if the exception has orig_exc
        assert(e.orig_exc == None)


# Generated at 2022-06-23 11:21:06.031443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'skip'})
    # Check for invalid setting identifier
    try:
        lookup_module.run([12], None)
        assert (False)
    except AnsibleOptionsError as e:
        assert str(e) == 'Invalid setting identifier, "12" is not a string, its a <class \'int\'>'
    # Check for invalid value of on_missing option
    lookup_module.set_options(direct={'on_missing': 'abcd'})

# Generated at 2022-06-23 11:21:14.949179
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # missing_setting = MissingSetting(msg="test_msg")
    missing_setting = MissingSetting(msg="test_msg", orig_exc="test_orig_exc")
    assert missing_setting.msg == "test_msg"
    assert missing_setting.orig_exc == "test_orig_exc"
    try:
        raise AnsibleOptionsError('Invalid setting identifier')
    except AnsibleOptionsError as e:
        # missing_setting = MissingSetting(msg="test_msg", orig_exc=e)
        assert missing_setting.msg == "test_msg"
        assert missing_setting.orig_exc == e

# Generated at 2022-06-23 11:21:16.560857
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert isinstance(MissingSetting('setting1'), AnsibleLookupError)

# Generated at 2022-06-23 11:21:20.629801
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader as plugin_loader
    plugin_loader.add_directory('./')
    lo = LookupModule()
    assert type(lo) is LookupModule


# Generated at 2022-06-23 11:21:28.911383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.utils.path import unfrackpath

    # Test with different values for 'on_missing'
    with open(unfrackpath("$testdir/test.ini"), 'w') as config_file:
        config_file.writelines(['[defaults]\n', 'host_key_checking = True\n'])

    old_config = C.config
    old_vars = C.get_config_variables()
    config = C.ConfigParser()
    config.read(unfrackpath("$testdir/test.ini"))
    config_vars = C.get_config_variables()

    C.config = config
    C.get_config_variables = lambda: dict(config_vars)

    # Test when lookup exits with

# Generated at 2022-06-23 11:21:30.250381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l


# Generated at 2022-06-23 11:21:37.955826
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # Test a message without a prior exception
    ms = MissingSetting('first message')
    assert ms.message == 'first message'

    # Test a message with original exception as a string
    ms = MissingSetting('first message', 'orig_exc')
    assert ms.message == 'first message'
    assert ms.orig_exc == 'orig_exc'

    # Test a message with original exception as a Exception
    class ErrorTest(Exception):
        pass
    ms = MissingSetting('first message', ErrorTest('An Exception'))
    assert ms.message == 'first message'
    assert isinstance(ms.orig_exc, ErrorTest)

# Generated at 2022-06-23 11:21:41.202534
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_module = LookupModule()
    assert lookup_module._templar is not None



# Generated at 2022-06-23 11:21:42.577796
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:21:43.701383
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()


# Generated at 2022-06-23 11:21:46.943384
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
  try:
    raise MissingSetting("Error msg")
  except MissingSetting as e:
    assert(e.message == "Error msg")
    assert(str(e) == "Error msg")

# Generated at 2022-06-23 11:21:48.243114
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test constructor of LookupModule
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:21:49.267626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupModule))

# Generated at 2022-06-23 11:21:51.798557
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('this is a test')
    except MissingSetting as e:
        assert e.message == 'this is a test'

# Generated at 2022-06-23 11:22:01.122310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with plugin_type and plugin_name
    plugin_type = "shell"
    plugin_name = "sh"
    term = "remote_tmp"
    variables = {}
    test = LookupModule()
    test_ret = test.run(terms=term, variables=variables, plugin_type=plugin_type, plugin_name=plugin_name)

    # test with no plugin_type and plugin_name
    term = "DEFAULT_ROLES_PATH"
    variables = {}
    test = LookupModule()
    test_ret = test.run(terms=term, variables=variables)

    # test with string on_missing
    term = "DEFAULT_ROLES_PATH"
    variables = {}
    test = LookupModule()

# Generated at 2022-06-23 11:22:11.284515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test LookupModule.run()
    """
    from ansible.plugins.lookup import LookupBase
    LookupBase.add_plugin_dir('./v2_modules/lookup_plugins')
    lookup_plugin = LookupModule()

    # Case 1: No plugin name and type is given
    plugin_type, plugin_name = None, None
    config = 'DEFAULT_BECOME_USER'
    val = lookup_plugin.run([config], {}, plugin_type=plugin_type, plugin_name=plugin_name)[0]
    assert val == 'root'

    # Case 2: No plugin type is given
    plugin_type, plugin_name = None, 'apt'
    config = 'allow_unauthenticated'

# Generated at 2022-06-23 11:22:13.147143
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test message')
    except MissingSetting as e:
        expected = 'test message'
        assert e.message == expected
        assert e.args == (expected,)

# Generated at 2022-06-23 11:22:21.963249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test no term, should return empty list
    assert lookup_module.run([]) == []

    # test invalid 'on_missing' setting
    try:
        lookup_module.run([], {}, **{'on_missing': 'test'})
        assert False
    except AnsibleOptionsError:
        assert True

    # test default 'on_missing' setting
    try:
        lookup_module.run(['test_term'])
        assert False
    except AnsibleLookupError:
        assert True

    # test 'on_missing' setting error
    try:
        lookup_module.run(['test_term'], {}, **{'on_missing': 'error'})
        assert False
    except AnsibleLookupError:
        assert True

    # test 'on_missing'

# Generated at 2022-06-23 11:22:33.203555
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'local'})

    assert l.get_option('on_missing') == 'error'
    assert l.get_option('plugin_type') == 'connection'
    assert l.get_option('plugin_name') == 'local'
    with pytest.raises(AnsibleOptionsError, match='not a string'):
        l.set_options(var_options={'on_missing': True})
    with pytest.raises(AnsibleOptionsError, match='not a string'):
        l.set_options(var_options={'plugin_type': True})

# Generated at 2022-06-23 11:22:35.200159
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting("test")
    assert "test" in str(exc) and "MissingSetting" in str(exc)

# Generated at 2022-06-23 11:22:45.413285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing nornal run of method run
    # Arrange
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 11:22:56.287144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for LookupModule.run() include:
    - Test default values for optional arguments
    - Test on_missing option error when it gets an invalid value.
    - Test that run raises AnsibleOptionsError when it receives an invalid option
    - Test that run raises AnsibleOptionsError when the supplied config is not a string.
    - Test that run raises AnsibleLookupError when the config value is not found
    - Test that run returns expected config value.
    - Test that run returns config value for plugin's conig.
    """
    expected_global_config_value = "WARN"
    test_global_config_value = "DEFAULT_LOG_PATH"
    # This is a plugin's default config value for PUT_JOB_STDOUT_TO_RESULTS
    expected_plugin_config_value = True
    plugin_type = "callback"
   

# Generated at 2022-06-23 11:23:08.087118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import ansible.plugins.loader
    import ansible.module_utils.six as six

    lookup_ins = LookupModule()

    assert isinstance(lookup_ins.run([''], {'_ansible_verbosity': 1}), list)

    # test when on_missing is not in ['error', 'warn', 'skip']
    assert lookup_ins.run([''], {'_ansible_verbosity': 1}, on_missing='error') is None
    assert lookup_ins.run([''], {'_ansible_verbosity': 1}, on_missing='warn') is None

# Generated at 2022-06-23 11:23:12.497818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # name of module is assigned automatically, hence we create a dummy here.
    class DummyModule:
        pass

    test_module = DummyModule()
    test_module.params = {}
    test_module.params['plugin_type'] = None
    test_module.params['plugin_name'] = None
    LookupModule(None, test_module)  # no exception expected


# Generated at 2022-06-23 11:23:20.615788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    # Test run method with option plugin_type and plugin_name for lookup config
    l = LookupModule()
    pname = 'file'
    ptype = 'inventory'
    term = 'script_path'
    l.run([term], direct={'plugin_type': ptype, 'plugin_name': pname})
    # Test run method when option plugin_type and plugin_name are not provided for lookup config
    l.run([term])
    # Test run method with missing setting key
    term_missing = 'script_path_missing'
    try:
        l.run([term_missing])
    except Exception as e:
        assert isinstance(e, AnsibleOptionsError)
    # Test run method when setting key is not string
    term_not_string = 123

# Generated at 2022-06-23 11:23:26.621217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arguments = dict(
        _terms=["PROJECTS_DATA_PATH"],
        on_missing='error',
        plugin_type='lookup',
        plugin_name='proxmox',
    )
    L = LookupModule()
    L.set_loader({})
    L.set_environment({})
    L._display = Display()
    L.run(**arguments)

# Generated at 2022-06-23 11:23:28.077428
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(runner=None) is not None
    assert LookupModule(runner=Sentinel()) is not None

# Generated at 2022-06-23 11:23:34.503196
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test to check exception is raised when plugin_type is provided, but plugin_name is not provided
    lookup_module = LookupModule()
    terms = 'DEFAULT_ROLES_PATH'
    variables = None
    ptype = 'inventory'
    pname = None
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_module.run(terms, variables, plugin_type=ptype, plugin_name=pname)
    assert str(e.value) == '"on_missing" must be a string and one of "error", "warn" or "skip", not error'

    # Test to check exception is raised when plugin_type is not provided, but plugin_name is provided
    lookup_module = LookupModule()
    terms = 'DEFAULT_ROLES_PATH'
    variables = None
   

# Generated at 2022-06-23 11:23:45.711114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set class attributes
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_basedir('/path/to/basedir')
    lookup.set_env({'ANSIBLE_LOOKUP_PLUGINS': '/path/to/lookup/plugins'})
    lookup.set_options()
    lookup.set_options({'var_options': {'key1':'value1', 'key2':'value2', 'key3':'value3'}, 'direct':{'direct_key1':'direct_value1'}})
    assert lookup.get_option('key1') == 'value1'
    assert lookup.get_option('key2') == 'value2'
    assert lookup.get_option('key3') == 'value3'

# Generated at 2022-06-23 11:23:56.809069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check if invalid setting identifier raises AnsibleOptionsError
    terms = [1]
    variables = {}
    missing = 'error'
    l = LookupModule()
    try:
        l.run(terms, variables, on_missing=missing)
    except AnsibleOptionsError:
        pass

    # Check if invalid on_missing value raises AnsibleOptionsError
    terms = ['DEFAULT_CACHE_PLUGIN']
    variables = {}
    missing = 'wrong'
    l = LookupModule()
    try:
        l.run(terms, variables, on_missing=missing)
    except AnsibleOptionsError:
        pass

    # Check if invalid plugin_name value raises MissingSetting
    terms = ['cache_plugin']
    variables = {}
    missing = 'error'
    ptype = 'cache'
    l = Look

# Generated at 2022-06-23 11:24:02.417050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    lookup_plugin = LookupModule()

    terms = 'DEFAULT_BECOME_USER'
    result = lookup_plugin.run(terms)

    assert len(result) == 1

    lookup_plugin = LookupModule()

    terms = 'DEFAULT_BECOME_USER'
    result = lookup_plugin.run(terms)

    assert len(result) == 1

    terms = 'DEFAULT_BECOME_USER'
    variables = {'ANSIBLE_DEFAULT_BECOME_USER': 'user'}
    result = lookup_plugin.run(terms)

    assert len(result) == 1

    terms = 'UNKNOWN_SETTING'
    result = lookup_plugin.run(terms)

    assert len(result) == 0


# Generated at 2022-06-23 11:24:04.243585
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:24:05.493908
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.run) == 3

# Generated at 2022-06-23 11:24:15.732323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == [C.DEFAULT_BECOME_USER]
    assert lookup_module.run(['DEFAULT_BECOME_USER'], {}, on_missing='warn') == [C.DEFAULT_BECOME_USER]
    assert lookup_module.run(['DEFAULT_BECOME_USER'], {}, on_missing='skip') == [C.DEFAULT_BECOME_USER]
    assert lookup_module.run([]) == []
    assert lookup_module.run([], {}, on_missing='warn') == []
    assert lookup_module.run([], {}, on_missing='skip') == []

# Generated at 2022-06-23 11:24:26.152633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Global configuration setting
    lm = LookupModule()
    lm.set_options(**{'_terms': ['DEFAULT_ROLES_PATH']})
    assert lm.run(**{'_terms': ['DEFAULT_ROLES_PATH']}) == [C.DEFAULT_ROLES_PATH]

    # Non-existant configuration setting
    lm = LookupModule()
    lm.set_options(**{'_terms': ['UNKNOWN']})
    assert lm.run(**{'_terms': ['UNKNOWN']}) == []

    # Plugin configuration setting
    lm = LookupModule()
    lm.set_options(**{'_terms': ['remote_tmp'], 'plugin_type': 'shell', 'plugin_name': 'sh'})

# Generated at 2022-06-23 11:24:28.535623
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise AnsibleOptionsError('foo')
    except AnsibleOptionsError as e:
        m = MissingSetting('bar', orig_exc=e)
        assert m.orig_exc == e

# Generated at 2022-06-23 11:24:30.666362
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('Unit test for MissingSetting').message == 'Unit test for MissingSetting'

# Generated at 2022-06-23 11:24:41.242975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.utils import context_objects as co
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    import json
    import tempfile
    import os
    import shutil
    import copy

    # create local config file
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 11:24:45.024182
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Unable to find term test"
    orig_exc = "Unable to find term test"
    missing_setting = MissingSetting(msg, orig_exc)
    assert missing_setting.message == msg
    assert missing_setting.orig_exc == orig_exc

# Generated at 2022-06-23 11:24:50.612342
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Test MissingSetting(AnsibleOptionsError)", orig_exc=AnsibleOptionsError("Sample exception"))
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert isinstance(e, AnsibleOptionsError)
        assert str(e) == "Test MissingSetting(AnsibleOptionsError)"
        assert str(e.orig_exc) == "Sample exception"

# Generated at 2022-06-23 11:24:54.920995
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    lookup_mis_para = MissingSetting("No Config Setting")
    assert (lookup_mis_para.args[0] == "No Config Setting")


# Generated at 2022-06-23 11:25:02.806500
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Check constructor with only one argument
    m = MissingSetting('Invalid setting!')
    assert str(m) == 'Invalid setting!'

    # Check constructor with two arguments
    m = MissingSetting('Invalid setting!', 'AttributeError')
    assert str(m) == 'Invalid setting!'
    assert m.orig_exc == 'AttributeError'

    # Check constructor with three arguments
    m = MissingSetting('Invalid setting!', 'AttributeError', 'foo')
    assert str(m) == 'Invalid setting!'
    assert m.orig_exc == 'AttributeError'

# Generated at 2022-06-23 11:25:09.094482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys, os

    # Create class LookupModule
    lookup_module = LookupModule()

    # Execute constructor code of class LookupModule
    terms = ""
    variables = ""
    lookup_module.run(terms, variables)


# Execute the 'main' function if module is not imported (unit test)
if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:25:10.182068
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global _
    _ = LookupModule()

# Generated at 2022-06-23 11:25:17.061950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import unittest
    import random

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            sys.argv = ['ansible-config', 'view']
            self.plugin_type, self.plugin_name = ('connection', 'ssh'),
            self.global_config = ('DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK', 'COLOR_SKIP', 'COLOR_CHANGED')
            self.config_list = self.global_config + ('remote_user', 'port')

        # Test for method run return type
        def test_return_type(self):
            terms = [random.choice(self.config_list) for _ in range(4)]
            data = LookupModule()
            actual

# Generated at 2022-06-23 11:25:27.268052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(plugin_loader)
    lookup_module.set_env({})
    lookup_module.set_options({})
    lookup_module._display = None
    # test: AnsibleOptionsError
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run([],{},on_missing='forbidden')
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run([],{},plugin_type='connection',plugin_name='ssh')
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run([],{},plugin_type='connection')
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run([],{},plugin_name='ssh')


# Generated at 2022-06-23 11:25:31.521102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'UNKNOWN_SETTING'], variables=dict(), on_missing='error') == ['root']


# Generated at 2022-06-23 11:25:34.148715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    variables = { 'var1': 'localhost', 'var2': '5001' }
    terms = ['var1', 'var2']
    lookup.run(terms, variables)

# Generated at 2022-06-23 11:25:43.914032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''_get_plugin_config is not tested because it is calling C.config which needs mocked up config. So it is tested in
    test_config.py'''
    import ansible.plugins.loader
    from ansible.errors import AnsibleOptionsError, AnsibleLookupError
    from ansible.plugins.lookup import LookupBase

    def dummy_set_options(self, var_options=None, direct=None):
        return

    def dummy_get_option(self, option=None):
        return option

    def dummy_getattr(attr=None):
        return attr

    orig_getattr = getattr(ansible.plugins.loader, "connection_loader")
    ansible.plugins.loader.connection_loader = orig_getattr

# Generated at 2022-06-23 11:25:52.432919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = lookup_plugin_class("config")
    assert module is not None

    # Invalid option
    options = dict(bad_option="bad_value")
    with pytest.raises(AnsibleOptionsError):
        module("name", options=options)

    # Invalid missing value
    options = dict(missing="bad_missing")
    with pytest.raises(AnsibleOptionsError):
        module("name", options=options)

    # Invalid plugin_type and pname
    options = dict(plugin_name="name")
    with pytest.raises(AnsibleOptionsError):
        module("name", options=options)

    # Invalid (non-string) term
    with pytest.raises(AnsibleOptionsError):
        module(dict(), options=options)

    # All is good

# Generated at 2022-06-23 11:25:54.883157
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    mt = MissingSetting('whatever')
    mt = MissingSetting('whatever', orig_exc='test')

# Generated at 2022-06-23 11:25:57.821184
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule() 
    l.set_options(None, {'on_missing': 'error'})
    assert l.get_option('on_missing') == "error"

# Generated at 2022-06-23 11:25:58.779938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global LookupModule
    lookup = LookupModule()

# Generated at 2022-06-23 11:26:08.705815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock display object to suppress output
    from ansible.utils.display import Display
    display = Display()
    import sys
    # Create a mock config object for testing
    class Config:
        def get_config_value(self, config, plugin_type=None, plugin_name=None, variables=None):
            if config == 'DEFAULT_BECOME_USER':
                return 'root'
            elif config == 'doesntexist':
                return None
            elif config == 'error':
                raise AnsibleLookupError('Some error')
            elif config == 'warning':
                display.warning('This should be a warning')
            elif config == 'COLOR_OK':
                return 'blue'
            elif config == 'COLOR_CHANGED':
                return 'yellow'

# Generated at 2022-06-23 11:26:14.418991
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """construct an error message string with a traceback"""
    from ansible.module_utils._text import to_bytes, to_native

    def foo():
        # raise an error to test the error traceback
        return bar()

    def bar():
        # method that does not exist
        return foo()

    try:
        foo()
    except AnsibleOptionsError as e:
        s = to_bytes(e)
        m = to_native(s)
    return m

# Generated at 2022-06-23 11:26:15.754890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:26:16.747182
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting("Test")

# Generated at 2022-06-23 11:26:25.128074
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    # Test the constructor with only one parameter
    try:
        raise MissingSetting("Test MissingSetting with only one parameter")
    except MissingSetting as e:
        assert e.message == "Test MissingSetting with only one parameter"
        assert e.orig_exc is None
        if hasattr(e, 'value'):
            assert e.value is None
    # Test the constructor with two parameters

# Generated at 2022-06-23 11:26:27.573728
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test message", orig_exc=RuntimeError)
    except Exception as e:
        assert type(e) is AnsibleOptionsError

# Generated at 2022-06-23 11:26:39.890983
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # Test with required arguments (msg and orig_exc)
    #
    # Constructor should:
    #   - Set the message
    #   - Set the original exception
    #
    msg = 'UnitTest Exception'
    orig_exc = Exception('Unit Test')
    missing_setting = MissingSetting(msg, orig_exc=orig_exc)
    assert missing_setting.message == msg
    assert missing_setting.orig_exc == orig_exc

    # Test with only message argument
    #
    # Constructor should:
    #   - Set the message
    #   - Set original exception to None
    #
    msg = 'UnitTest Exception'
    missing_setting = MissingSetting(msg)
    assert missing_setting.message == msg
    assert missing_setting.orig_exc is None

# Generated at 2022-06-23 11:26:41.151086
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missingSetting = MissingSetting('foo')
    assert missingSetting.message == 'foo'

# Generated at 2022-06-23 11:26:45.862030
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('test', 'test_orig_exception')
    assert missing_setting.message == 'test'
    # orig_exc is not used yet, but this test verifies that it is possible
    assert missing_setting.orig_exc == 'test_orig_exception'

# Generated at 2022-06-23 11:26:56.257249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check if LookupModule.run returns correct value"""
    val_err = 'Invalid setting identifier, "ERROR" is not a string'
    with pytest.raises(AnsibleOptionsError, match=val_err):
        LookupModule().run(terms=["ERROR","WARN"],variables=None)

    with pytest.raises(AnsibleOptionsError, match=val_err):
        LookupModule().run(terms=["ERROR","WARN"],variables=None, plugin_name="ssh")

    with pytest.raises(AnsibleOptionsError, match=val_err):
        LookupModule().run(terms=["ERROR","WARN"],variables=None, plugin_name="ssh", plugin_type="connection")


# Generated at 2022-06-23 11:26:58.163960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

if __name__ == '__main__':
     test_LookupModule()

# Generated at 2022-06-23 11:27:03.648917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is the test of the unit test module. It is only run when called directly.
    import sys
    import pytest
    from ansible.module_utils.six import PY3

    # Test group 1. Correctly formed calls.
    # Get a value from a configuration file (vars_prompt)
    # Get a value from a plugin (vars_prompt, which could be a callback, inventory plugin or lookup plugin)
    # Get a list of values from a configuration file
    # Get a list of values from a plugin
    # Call a configuration file setting that is actually a function.
    # Call a plugin setting that is actually a function.

    # Test group 2. Calls that should fail.
    # "on_missing" option is invalid.
    # "plugin_type" is present without a value.
    # "plugin_name" is present

# Generated at 2022-06-23 11:27:14.030946
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # run method should returns a list of values if terms is valid
    result = lookup_module.run(['DEFAULT_BECOME_USER'])
    assert isinstance(result, list) and len(result) == 1 and result[0] == C.DEFAULT_BECOME_USER

    # run method should returns a list of values if terms is a list
    result = lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD'])
    assert isinstance(result, list) and len(result) == 2 and result[0] == C.DEFAULT_BECOME_USER and result[1] == C.DEFAULT_BECOME_METHOD



# Generated at 2022-06-23 11:27:23.799490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable_manager = MockVariableManager()
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(["DEFAULT_ROLES_PATH"]) == ['roles']
    assert lookup_plugin.run(["DEFAULT_ROLES_PATH"], variables=variable_manager.extra_vars) == ['roles']
    assert lookup_plugin.run(["DEFAULT_ROLES_PATH"], variables=variable_manager.host_vars[0]) == ['roles']
    assert lookup_plugin.run(["DEFAULT_ROLES_PATH"], variables=variable_manager.task_vars) == ['roles']


# Generated at 2022-06-23 11:27:25.634723
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:27:26.573947
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    pass

# Generated at 2022-06-23 11:27:31.464016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    lookup_plugin = lookup_loader.get('config')
    if lookup_plugin is None:
        raise AssertionError("Unable to load 'config' plugin")

    ret = lookup_plugin.run(terms=["DEFAULT_BECOME_USER"])
    assert ret == ['root'], "Should be equal to list with item 'root'"

# Generated at 2022-06-23 11:27:32.363452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run()

# Generated at 2022-06-23 11:27:33.233225
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m = LookupModule()
    assert m is not None

# Generated at 2022-06-23 11:27:36.907367
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test of constructor for class LookupModule"""
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:27:40.102824
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test = MissingSetting('msg', 'orig_exc')

    assert test.message == "msg"
    assert test.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:27:42.150578
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('foo', 'bar')
    assert exc.message == 'foo'
    assert exc.orig_exc == 'bar'

# Generated at 2022-06-23 11:27:42.836154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:27:49.134602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import shutil

    from ansible.module_utils.six import StringIO
    from ansible.utils.sentinel import Sentinel

    from ansible.plugins.loader import connection_loader, shell_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import vars_loader

    extra_plugin_dir = os.path.join(os.path.dirname(__file__), '../lookup_plugins')
    connection_plugin_dir = os.path.join(extra_plugin_dir, 'connection_plugins')
    shell_plugin_dir = os.path.join(extra_plugin_dir, 'shell_plugins')
    lookup_plugin_dir = os.path.join(extra_plugin_dir, 'lookup_plugins')

# Generated at 2022-06-23 11:27:59.694671
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    lookup_module.set_options(var_options={'lookup_plugin_settings': 'ok'}, direct={})
    lookup_module.set_options(var_options={'lookup_plugin_name': 'ok'}, direct={})
    lookup_module.set_options(var_options={'lookup_plugin_type': 'ok'}, direct={})

    result = lookup_module.run([], {'lookup_plugin_settings': 'DEFAULT_BECOME_USER'}, lookup_plugin_name='nonexistent_var', lookup_plugin_type='become')
    assert result == [u'root']


# Generated at 2022-06-23 11:28:00.243709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:28:01.369516
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting.__init__

# Generated at 2022-06-23 11:28:12.769585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    unit test to cover lookup module run method
    '''
    #set up input and expected results
    terms = ('DEFAULT_FORKS', 'DEFAULT_REMOTE_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'UNKNOWN')
    ret_expected = [
        [
            "/home/doug/ansible/ansible-devel/lib/ansible/roles"
        ],
        [
            "root"
        ],
        [
            50
        ],
        [
            "/home/doug/.ansible/retry"
        ],
        [
        ]
    ]
    ret = []

    # call the lookup module
    for term in terms:
        result = Sentinel