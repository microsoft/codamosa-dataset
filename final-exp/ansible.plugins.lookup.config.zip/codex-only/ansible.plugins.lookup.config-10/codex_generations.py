

# Generated at 2022-06-23 11:18:08.838507
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run(["ANSIBLE_CONFIG"], {}, {})

# Generated at 2022-06-23 11:18:11.144404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance = LookupModule()
    assert test_instance is not None

# Generated at 2022-06-23 11:18:17.439575
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.utils.sentinel import Sentinel
    try:
        raise MissingSetting('something happened')
    except AnsibleOptionsError as e:
        assert isinstance(e, AnsibleOptionsError)
        assert isinstance(e, MissingSetting)
        assert not isinstance(e, Sentinel)
        assert e.message == 'something happened'
        assert e.orig_exc is None

# Generated at 2022-06-23 11:18:18.016957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:18:25.498027
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    """
    Unit test for method run of class LookupModule
    """

    # General variables for test
    result = dict()
    cls = LookupModule
    obj = cls()

    # General variables for this test
    test_terms = ['fact_caching_connection', 'fact_caching_prefix', 'fact_caching_timeout', 'fact_caching_local_connection']

    # Run the test
    result = obj.run(test_terms, variables=None, **dict())

    # Assertions
    assert isinstance(result, list)
    assert len(result) == len(test_terms)
    for elem in result:
        assert isinstance(elem, str)

# Generated at 2022-06-23 11:18:26.985900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not lookup.on_missing

# Generated at 2022-06-23 11:18:28.874269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mock = plugin_loader.get_all_plugin_loaders()
    lm = LookupModule(mock)
    assert lm


# Generated at 2022-06-23 11:18:32.564736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    plugin_loader.add_all_plugin_dirs()
    mylo = LookupModule()
    mylo.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='error')

# Generated at 2022-06-23 11:18:33.844138
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting()
    assert result.msg == 'Unable to find setting UNKNOWN'

# Generated at 2022-06-23 11:18:41.416756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verifying idempotency of getting lookup config
    first = LookupModule().run(["DEFAULT_INVENTORY_PLUGIN"],on_missing="error")[0]
    second = LookupModule().run(["DEFAULT_INVENTORY_PLUGIN"],on_missing="error")[0]
    assert first == second

    # Verifying on_missing
    assert LookupModule().run(["DEFAULT_INVENTORY_PLUGINS"],on_missing="warn") == []
    assert LookupModule().run(["DEFAULT_INVENTORY_PLUGINS"],on_missing="skip") == []

# Generated at 2022-06-23 11:18:43.943901
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test exception')
    except AnsibleError as e:
        assert e.msg == 'test exception'
        assert e.orig_exc is None

# Generated at 2022-06-23 11:18:55.826889
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing Case: on_missing set to error
    # Expected Output: raise AnsibleOptionsError error
    invalid_on_missing = dict()
    invalid_on_missing['on_missing'] = 'yes'

    lookupmodule = LookupModule()
    lookupmodule.set_options(direct=invalid_on_missing)
    try:
        lookupmodule.run(terms=["C.CONFIG_FILE"], variables=None)
        assert False
    except AnsibleOptionsError:
        assert True

    # Testing Case: on_missing set to warn
    # Expected Output: warning message
    import sys
    from contextlib import contextmanager

    @contextmanager
    def stdoutRecorder(stream=None):
        if stream is None:
            stream = sys.stdout
        old_stream = stream
        new_stream = sys.std

# Generated at 2022-06-23 11:18:56.711614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 11:19:08.621535
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:19:12.198934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _terms = ["DEFAULT_BECOME_USER"]
    _LookupModule = LookupModule()
    result = _LookupModule.run(_terms)
    assert isinstance(result, list)
    assert result[0] == "root"


# Generated at 2022-06-23 11:19:12.972633
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:19:15.330515
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Bad setting')
    except MissingSetting as e:
        assert isinstance(e, AnsibleError)



# Generated at 2022-06-23 11:19:18.141798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['FOO']) == [C.FOO]
    assert lookup.run(['C.FOO']) == [C.FOO]

# Generated at 2022-06-23 11:19:20.978169
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # pylint: disable=protected-access
    assert MissingSetting is AnsibleError._create_subclass_with_origin(FatalException=False)(MissingSetting)

# Generated at 2022-06-23 11:19:30.453757
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # pylint: disable=redefined-outer-name,no-self-use
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_native
    from ansible.utils.sentinel import Sentinel
    from pytest import raises
    try:
        raise MissingSetting('foobar is undefined')
    except MissingSetting as e:
        assert to_native(e) == 'foobar is undefined'
        assert e.orig_exc is None
        assert e.obj is Sentinel

    try:
        raise MissingSetting('foobar is undefined', orig_exc=LookupModule('lookup')[0])
    except MissingSetting as e:
        assert to_native(e) == 'foobar is undefined'
        assert isinstance(e.orig_exc, AnsibleOptionsError)
        assert e.obj

# Generated at 2022-06-23 11:19:37.514643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an AnsibleLookupBase object
    lookupBase = LookupBase()
    # Create an instance of LookupModule inherited from AnsibleLookupBase
    lookupModule = LookupModule()
    # Set options for the instance of LookupModule
    lookupModule.set_options({'var_options': None, 'direct': None})
    # Call method run of class LookupModule
    ret = lookupModule.run(['DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_USER'])
    # Print the return value of method run of class LookupModule
    print(ret)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:19:40.700160
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_name = 'config'
    lookup_plugin = LookupModule()
    assert lookup_plugin._config_option_names == ('plugin_name', 'plugin_type', 'on_missing')

# Generated at 2022-06-23 11:19:49.979966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleOptionsError, AnsibleLookupError
    from ansible.parsing.yaml.objects import AnsibleSequence
    lu = LookupModule()

# Generated at 2022-06-23 11:19:59.542343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    try:
        result = lm.run(terms='foo', variables=['foo', 'bar'])
        assert False, "AnsibleOptionsError was not raised"
    except AnsibleOptionsError as e:
        assert 'Invalid setting identifier' in to_native(e), "AnsibleOptionsError raised with wrong error message"

    result = lm.run(['remote_user', 'port'], variables={'port': '2211'})
    assert result == ['root', '2211'], "Failed to get expected ansible config values"

    result = lm.run(['remote_tmp', 'remote_user'], plugin_name='sh', plugin_type='shell')

# Generated at 2022-06-23 11:20:02.030145
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    if not isinstance(module, LookupModule):
        print('Test failed')
        return
    print('Test passed')



# Generated at 2022-06-23 11:20:07.217078
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'message'
    orig_exc = Error('error')
    with pytest.raises(AnsibleOptionsError, match=msg) as excinfo:
        raise MissingSetting(msg, orig_exc=orig_exc)
    assert orig_exc == excinfo.value.orig_exc

# Generated at 2022-06-23 11:20:08.757220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 11:20:18.864053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_1: method run returns list of values of lookup keys
    # expected result: ret=[1,'abc123']
    lu = LookupModule()
    lu._display.warning = lambda *a, **kw: None
    ret = lu.run(['one', 'two'], variables={'one': 1, 'two': 'abc123'})
    assert ret == [1, 'abc123'],\
        'Unexpected result returned: %s' % ret

    # test_2: method run skips lookup key if lookup key not in variables dictionary
    # expected result: ret=[1]
    lu = LookupModule()
    lu._display.warning = lambda *a, **kw: None

# Generated at 2022-06-23 11:20:23.686467
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.six import PY3
    if not PY3:
        return

    orig_exc = ZeroDivisionError()
    try:
        raise MissingSetting("bad", orig_exc)
    except MissingSetting as e:
        assert e.orig_exc == orig_exc
        assert str(e) == "bad"

# Generated at 2022-06-23 11:20:34.550317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a instance for class LookupModule
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule), "lookup_plugin has invalid type. (Result: %s)" % type(lookup_plugin)

    terms = ["DEFAULT_ROLES_PATH"]
    result = lookup_plugin.run(terms)
    assert result[0] == C.DEFAULT_ROLES_PATH, "Unexpected configuration DEFAULT_ROLES_PATH. (Result: %s)" % result

    terms = ["DEFAULT_BECOME_USER"]
    result = lookup_plugin.run(terms)
    assert result[0] == C.DEFAULT_BECOME_USER, "Unexpected configuration DEFAULT_BECOME_USER. (Result: %s)" % result


# Generated at 2022-06-23 11:20:35.934354
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert str(MissingSetting("message")) == "message"

# Generated at 2022-06-23 11:20:37.192021
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 11:20:48.461636
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test the constructor with an error message
    msg = "This is an error message"
    e = MissingSetting(msg)
    assert e.message == msg
    assert str(e) == msg
    # Test the constructor with an error message and an original exception
    class CustomError(Exception):
        pass
    orig_exc = CustomError(msg)
    e = MissingSetting(msg, orig_exc)
    assert e.message == msg
    assert str(e) == msg
    assert e.orig_exc == orig_exc
    # Test the constructor with an original exception only
    e = MissingSetting(orig_exc=orig_exc)
    assert str(e) == msg
    assert e.message == msg
    assert e.orig_exc == orig_exc

# Generated at 2022-06-23 11:20:57.343193
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup.config import LookupModule

    # Create an instance of LookupModule
    lookup_instance = LookupModule()

    # Set the missing option to error
    lookup_instance.set_options(direct={'on_missing': 'error'})

    # assert that missing option is set to error
    assert lookup_instance.get_option('on_missing') == 'error'

    # Set the missing option to warn
    lookup_instance.set_options(direct={'on_missing': 'warn'})

    # assert that missing option is set to warn
    assert lookup_instance.get_option('on_missing') == 'warn'

    # Set the missing option to skip
    lookup_instance.set_options(direct={'on_missing': 'skip'})



# Generated at 2022-06-23 11:21:00.219562
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert(e.message == "test")


# Generated at 2022-06-23 11:21:11.617014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.constants as C
    import ansible.module_utils.six as six

    # Initialize LookupModule class object
    lookup_obj = LookupModule()

    # Create args list for lookup_obj.run method
    args_dict = {}
    args_dict['terms'] = ['DEFAULT_HASH_BEHAVIOUR', 'DEFAULT_ROLES_PATH']
    args_dict.setdefault('variables')
    args_dict.setdefault('plugin_name')
    args_dict.setdefault('plugin_type')
    args_dict.setdefault('on_missing')

    # Invoke lookup_obj.run method
    try:
        actual_result = lookup_obj.run(**args_dict)
    except Exception as err:
        actual_result = str(err)

    # Check if actual

# Generated at 2022-06-23 11:21:15.675851
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Variable definition
    exception = None

    # Setup
    try:
        1/0
    except Exception as e:
        exception = e
    # test
    try:
        raise MissingSetting("test", exception)
    except MissingSetting as e:
        assert str(e) == "test", "Unexpected exception message: %s" % str(e)
        assert e.orig_exc == exception, "Unexpected exception message: %s" % str(e.orig_exc)

# Generated at 2022-06-23 11:21:27.602694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    res = LookupModule().run(['DEFAULT_TASK_TIMEOUT'])
    assert(next(res) == C.DEFAULT_TASK_TIMEOUT)
    res = LookupModule().run(['DEFAULT_TASK_TIMEOUT'], plugin_type='shell', plugin_name = 'bash')
    assert(next(res) == C.config.get_config_value('DEFAULT_TASK_TIMEOUT', plugin_type='shell', plugin_name='bash'))
    res = LookupModule().run(['DEFAULT_TASK_TIMEOUT'], on_missing='warn')
    assert(next(res) == C.DEFAULT_TASK_TIMEOUT)

# Generated at 2022-06-23 11:21:29.259123
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert hasattr(lookup_obj, 'run')

# Generated at 2022-06-23 11:21:31.831340
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Test MissingSetting constructor"""
    instance = MissingSetting('msg')
    assert 'msg' == instance.message
    assert not instance.show_content



# Generated at 2022-06-23 11:21:37.368148
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_instance = LookupModule()
    terms = ['BECOME_METHOD', 'BECOME_USER']
    result = lookup_instance.run(terms)
    assert result == ['sudo', 'root']

    result = lookup_instance.run(['BECOME_METHOD', 'BECOME_USER', 'something_unimplemented'])
    assert result == ['sudo', 'root', None]

# Generated at 2022-06-23 11:21:43.749404
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Constructor for class MissingSetting.

    This unit test covers the constructor for the class MissingSetting.
    The message field is verified with the string passed in.

    Args:
        None
    Returns:
        Nothing
    Raises:
        Nothing
    """

    message = "test message"
    exception = MissingSetting(message)

    assert exception.message == message

# Generated at 2022-06-23 11:21:46.214645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as loader
    lookup_plugin = LookupModule()
    assert loader.find_plugin(LookupBase) == lookup_plugin

# Generated at 2022-06-23 11:21:48.870809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ret = lookup.run(['hostfile'])
    assert ret[0] == '/etc/ansible/hosts'

# Generated at 2022-06-23 11:21:52.532574
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting(msg='test')
    except AnsibleOptionsError as e:
        assert e.message == 'test'
        assert e.orig_exc == None
    except Exception as e:
        assert False

# Generated at 2022-06-23 11:21:56.609604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['DEFAULT_BECOME_METHOD'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')
    assert result == [u'sudo']

# Generated at 2022-06-23 11:22:03.892253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    result = obj.run(['DEFAULT_ROLES_PATH'])
    assert len(result) == 1, "TEST_FAILURE: expected 1, got %d" % len(result)
    assert result[0] == ['/etc/ansible/roles', './roles'], "TEST_FAILURE: expected '/etc/ansible/roles,./roles', got %s" % result[0]

# Generated at 2022-06-23 11:22:05.395226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(['DEFAULT_ROLES_PATH'])

# Generated at 2022-06-23 11:22:13.703772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    current_ansible_config_settings = {}
    current_ansible_config_settings['DEFAULT_BECOME_USER'] = 'root'

    config_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    config_file = os.path.join(config_dir, 'ansible.cfg')
    config_parser = ConfigParser.ConfigParser()
    config_parser.read(config_file)

    for section in config_parser.sections():
        for (name, value) in config_parser.items(section):
            current_ansible_config_settings[name] = value
   
    ############################################################
    # This unit test verifies that a valid key returns the 
    # expected value.
    ############################################################
    result = Lookup

# Generated at 2022-06-23 11:22:16.693490
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting()
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert isinstance(e, AnsibleOptionsError)

# Generated at 2022-06-23 11:22:18.088869
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting_obj = MissingSetting('test')
    assert isinstance(missing_setting_obj, MissingSetting)

# Generated at 2022-06-23 11:22:18.851407
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:22:30.749508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_ROLES_PATH'], plugin_name='ssh', plugin_type='connection') == ['/etc/ansible/roles', '~/.ansible/roles', '/usr/share/ansible/roles']
    assert lookup.run(['DEFAULT_ROLES_PATH','whatever_else'], plugin_name='ssh', plugin_type='connection') == ['/etc/ansible/roles', '~/.ansible/roles', '/usr/share/ansible/roles']
    assert lookup.run(['whatever'], plugin_name='ssh', plugin_type='connection', on_missing='warn') == []
    assert lookup.run(['whatever'], plugin_name='ssh', plugin_type='connection', on_missing='skip') == []

# Generated at 2022-06-23 11:22:31.935596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:22:43.924661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test _get_plugin_config
    assert lookup_module._get_plugin_config(config='remote_tmp', ptype='shell', pname='sh', variables={'UNKNOWN_VAR': 'UNKNOWN_VALUE'}) == '/tmp/ansible-${USER}'
    assert lookup_module._get_plugin_config(config='remote_tmp', ptype='shell', pname='sh') == '/tmp/ansible-${USER}'
    assert lookup_module._get_plugin_config(config='remote_tmp', ptype='shell', pname='sh', variables={'ANSIBLE_REMOTE_TMP': '/home/user/temp'}) == '/home/user/temp'

# Generated at 2022-06-23 11:22:55.410554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader as plugin_loader
    from ansible.errors import AnsibleError, AnsibleLookupError, AnsibleOptionsError
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils._text import to_native

    # Test init
    lu = LookupModule()
    assert lu.name == 'config'
    assert lu.author == 'Ansible Core Team'
    assert lu.version_added == '2.5'
    assert lu.description == 'Lookup current Ansible configuration values'
    assert lu.short_description == 'Lookup current Ansible configuration values'
    assert lu.options is None

    # Test missing setting

# Generated at 2022-06-23 11:23:02.806147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init the LookupModule class
    lookup_module = LookupModule()
    # call the method run of class LookupModule
    result = lookup_module.run([{'name': 'example-host', 'hostvars': {'ansible_user': 'example-user'}}, 'file'])
    # test the results
    assert result[0]['hostvars']['ansible_user'] == 'example-user'
    assert result[1] == 'file'


# Generated at 2022-06-23 11:23:09.027300
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
        try:
            raise MissingSetting('test_msg',0)
        except MissingSetting as e:
            # ensure that the exception raised is a MissingSetting exception
            assert(isinstance(e,MissingSetting))
            # ensure that the exception message is 'test_msg'
            assert(e.message == 'test_msg')
            # ensure that the exception orig_exc is the value '0'
            assert(e.orig_exc == 0)

# Generated at 2022-06-23 11:23:15.552443
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    set_loc = 'tests/fixtures/config_test/'
    msg = 'while attempting to read config_test/some_var: that var is missing'
    orig_exc = AnsibleLookupError(msg)
    result = MissingSetting(msg, orig_exc=orig_exc)
    assert result.set_loc == set_loc
    assert isinstance(result.orig_exc, AnsibleLookupError)

# Generated at 2022-06-23 11:23:16.167911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:23:28.272802
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    from . import config_test_data as test_data

    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = test_data.variables
    #kwargs = {"_terms":terms, "variables":variables}
    kwargs = {"_terms":terms}

    lookup_plugin = LookupModule()

    # Test to run method of class LookupModule where
    # plugin_name & plugin_type are not configured

# Generated at 2022-06-23 11:23:30.160023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert str(module) == '<LookupModule AnsibleModule:LookupBase>'

# Generated at 2022-06-23 11:23:31.854502
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest
    assert type(MissingSetting) is ansible.utils.sentinel.Sentinel



# Generated at 2022-06-23 11:23:32.381814
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:23:34.512573
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ret = MissingSetting("message")
    assert ret.message == "message"

# Generated at 2022-06-23 11:23:37.676836
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_exc = AnsibleError('Test message')
    test_obj = MissingSetting('Testing message', orig_exc=test_exc)
    assert test_obj.orig_exc == test_exc

# Generated at 2022-06-23 11:23:39.848714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:23:45.456143
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert e.orig_exc is None
        assert str(e) == 'test'
        assert e.args == ('test',)
    try:
        raise MissingSetting('test', orig_exc=e)
    except MissingSetting as e:
        assert e.orig_exc == e
        assert str(e) == 'test'
        assert e.args == ('test',)

# Generated at 2022-06-23 11:23:49.666305
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('foo')
    except MissingSetting as e:
        assert e.message == 'foo'
        assert 'missing setting' in e.message.lower()


# Generated at 2022-06-23 11:23:52.872950
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "test message"
    try:
        raise MissingSetting(msg)
    except MissingSetting as e:
        assert e.orig_exc is None
        assert e.message == msg

# Generated at 2022-06-23 11:24:00.657782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

    # Check that exception is raised when on_missing is not in required list
    try:
        lookup.run(["foo"], {"on_missing": "error"})
        assert False, "Should have raised exception"
    except AnsibleOptionsError as e:
        assert "\"on_missing\" must be a string and one of \"error\", \"warn\" or \"skip\", not error" in str(e)

    try:
        lookup.run(["foo"], {"on_missing": "warn"})
    except Exception:
        assert False, "Should not have raised exception"

    try:
        lookup.run(["foo"], {"on_missing": "skip"})
    except Exception:
        assert False, "Should not have raised exception"

    # Check that exception is

# Generated at 2022-06-23 11:24:02.644475
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    try:
        raise LookupModule.MissingSetting
    except AnsibleLookupError as e:
        assert "Unable to find setting" in str(e)

# Generated at 2022-06-23 11:24:06.619699
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exception = MissingSetting('test', orig_exc=AnsibleError())
    assert isinstance(exception, AnsibleError)
    assert exception.orig_exc is not None
    assert exception.message == 'test'

# Generated at 2022-06-23 11:24:13.994923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = None
    variable_manager = VariableManager()
    loader.set_basedir('tests/utils/tags/files/')
    context = PlayContext()
    context.console_logger = open('/dev/null', 'w')
    lm = LookupModule(loader=loader, variable_manager=variable_manager, play_context=context)
    return lm

# Generated at 2022-06-23 11:24:18.131871
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test message'
    ms = MissingSetting(msg)
    assert ms.message == msg
    assert not ms.orig_exc
    exc = Exception('orig_exc')
    ms = MissingSetting(msg, orig_exc=exc)
    assert ms.orig_exc == exc

# Generated at 2022-06-23 11:24:28.172588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Without values for plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_loader({'path': 'ansible.plugins.lookup.config', 'name': 'LookupModule'})
    assert lookup_module.run(['DEFAULT_JINJA2_NATIVE'], {}, on_missing='error') == [True]

    #With values for plugin_type and plugin_name
    assert lookup_module.run(['remote_user'], {}, on_missing='error', plugin_type='connection', plugin_name='ssh') == ['ansible']

    #Test with invalid plugin_type

# Generated at 2022-06-23 11:24:39.522511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    loader = DataLoader()

    lookup = LookupModule()
    lookup.set_loader(loader)
    lookup.set_variable_manager(variable_manager)

    # Tests default values for argument variables.
    assert lookup.run(terms=[''], variables={}, on_missing='error', plugin_type='', plugin_name='') == ['bar']

    # Tests args
    assert lookup.run(terms=[''], variables={'foo': 'foo'}, on_missing='warn', plugin_type='', plugin_name='') == ['foo']

    # Tests args

# Generated at 2022-06-23 11:24:44.397097
# Unit test for constructor of class LookupModule
def test_LookupModule():
    var = dict(
#        var_name='HOST_PORT',
        var_name='HOST_PORT',
        var_value=dict(
            ansible_port=22
        ),
    )
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'HOST_PORT': dict(ansible_port=22)}, direct=dict())

# Generated at 2022-06-23 11:24:49.731599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    ptype = 'shell'
    pname = 'sh'
    lookup_instance = LookupModule()
    result = lookup_instance.run(terms, plugin_type=ptype, plugin_name=pname, wantlist=True)
    assert len(result) == 3



# Generated at 2022-06-23 11:24:57.255956
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # test raising the exception
    try:
        raise MissingSetting("out missing")
    except MissingSetting as e:
        assert e.message == "out missing"
        assert isinstance(e, Exception)
    else:
        assert False, "Exception did not raise"

    # test instantiation of exception without raising it
    x = MissingSetting("out missing")
    assert x.message == "out missing"
    assert isinstance(x, Exception)

# Generated at 2022-06-23 11:24:58.530880
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 11:25:08.168309
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModuleTest(LookupModule):

        def __init__(self, terms, variables=None, **kwargs):
            self.set_options(var_options=variables, direct=kwargs)
            self._display = DummyDisplay()

    def runTest(terms, variables=None, **kwargs):
        lookup_plugin = LookupModuleTest(terms, variables, **kwargs)
        return lookup_plugin.run()

    class DummyDisplay(object):
        def __init__(self):
            self.display = []

        def warning(self, msg):
            self.display.append(msg)

        def display(self, msg):
            self.display.append(msg)

    global C


# Generated at 2022-06-23 11:25:16.825756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run.called = True
    test_setting = "DEFAULT_ROLES_PATH"
    test_lookup_module = LookupModule()
    test_terms = [test_setting]
    expected_result = C.DEFAULT_ROLES_PATH
    result = test_lookup_module.run(test_terms)
    assert result[0] == expected_result

# Test cases for method run of class LookupModule

# Generated at 2022-06-23 11:25:24.769049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys, os
    import ansible.module_utils.basic
    module_args = {'_raw_params': 'x',
        '_terms': 'C.DEFAULT_ROLES_PATH'
    }
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, **module_args)
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=module_args['_terms'], variables={})
    assert result != None, "lookup result should not be None"

# Generated at 2022-06-23 11:25:27.508706
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.loader as plugin_loader
    loader = plugin_loader.LookupModule()
    assert loader is not None
    assert hasattr(loader, 'run')

# Generated at 2022-06-23 11:25:30.554219
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('Missing Setting')
    assert missing_setting.value == 'Missing Setting'
    assert missing_setting.orig_exc is None

# Generated at 2022-06-23 11:25:35.568685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    test_data = ["DEFAULT_BECOME_USER"]
    test_variables = {}
    test_kwargs = {}
    result = lookup_plugin.run(test_data, variables=test_variables, **test_kwargs)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == "root"

# Generated at 2022-06-23 11:25:37.826225
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting('msg', 'orig_exc')
    assert obj.message == 'msg'
    assert obj.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:25:44.241709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['remote_user', 'unavailable_setting']
    variables = {}
    kwargs = {
        'plugin_type': 'connection',
        'plugin_name': 'ssh'
    }
    lookup_mod = LookupModule()
    lookup_mod.set_options(var_options=variables, direct=kwargs)
    assert lookup_mod.run(terms, variables=variables, **kwargs) == ['root', Sentinel]

# Generated at 2022-06-23 11:25:52.640731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']
    result = lookup.run(terms)
    # "DEFAULT_ROLES_PATH" and "DEFAULT_BECOME_USER" are known valid settings
    assert result and result[0] == 'roles' and result[1] == 'root'
    assert lookup.run([]) == []
    assert lookup.run(['testing']) == []

    term = 'DEFAULT_ROLES_PATH'
    result = lookup.run([term], on_missing='error')
    assert result and result[0] == 'roles'

    term = 'DEFAULT_ROLES_PATH'
    result = lookup.run([term], on_missing='warn')

# Generated at 2022-06-23 11:25:53.906349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:25:55.612132
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    a = MissingSetting('test')
    assert a.orig_exc is None

# Generated at 2022-06-23 11:25:57.344559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, LookupBase)

# Generated at 2022-06-23 11:25:57.981689
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:26:02.630949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.get_option = lambda x: None
    lookup_plugin.set_options = lambda **x: None
    lookup_plugin._display = lambda **x: None
    assert lookup_plugin.run([]) == []
    assert lookup_plugin.run(['']) == []
    assert lookup_plugin.run(['INVALID_SETTING']) == []

# Generated at 2022-06-23 11:26:05.657493
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = u'foo'
    exc = 'bar'
    inst = MissingSetting(msg, orig_exc=exc)
    assert inst.message == msg
    assert inst.orig_exc == exc

# Generated at 2022-06-23 11:26:08.433475
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Should not raise any errors
    error = AnsibleOptionsError("AnsibleOptionsError")
    missing = MissingSetting("A setting is missing", orig_exc=error)

# Generated at 2022-06-23 11:26:12.264658
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("No setting named 'X'")
    except MissingSetting as e:
        assert to_native(e) == "No setting named 'X'"
        assert isinstance(e, AnsibleOptionsError)
        assert isinstance(e, AnsibleError)
        assert isinstance(e, Exception)

# Generated at 2022-06-23 11:26:21.817049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel


# Generated at 2022-06-23 11:26:32.116710
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:26:33.359198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 11:26:35.230977
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('error message', orig_exc=KeyError('sub message'))
    assert str(e) == 'error message'
    assert str(e.orig_exc) == 'sub message'

# Generated at 2022-06-23 11:26:38.944193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(direct={'plugin_type': 'cliconf', 'plugin_name': 'ios', 'on_missing': 'warn' })
    result = l.run(['foo'])

# Generated at 2022-06-23 11:26:40.977254
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('missing_set')
    assert missing_setting.msg == 'missing_set'

# Generated at 2022-06-23 11:26:41.876784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()



# Generated at 2022-06-23 11:26:42.444446
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False

# Generated at 2022-06-23 11:26:45.384382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert 'config' == lookup_plugin.get_name()

# Generated at 2022-06-23 11:26:51.114510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    assert lookup_mod.get_option('on_missing') == 'error'
    assert lookup_mod.run(['DEFAULT_SUDO_USER']) == ['root']
    lookup_mod = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert lookup_mod.get_option('on_missing') == 'error'
    assert lookup_mod.run(['DEFAULT_SUDO_USER']) == ['root']

# Generated at 2022-06-23 11:27:01.552743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # with no parameters, should fail
    try:
        ll = LookupModule()
        ll.run(terms=['foo'])
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError("Should have raised AnsibleOptionsError!")

    # with bad plugin_type, should fail
    try:
        ll = LookupModule()
        ll.run(terms=['foo'], plugin_type='bad')
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError("Should have raised AnsibleOptionsError!")

    # with bad plugin_name, should fail
    try:
        ll = LookupModule()
        ll.run(terms=['foo'], plugin_type='connection', plugin_name='bad')
    except MissingSetting:
        pass

# Generated at 2022-06-23 11:27:08.021027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader({'vars': {}})
    lookup_module.set_play_context({'_run_async': False})
    lookup_module.set_variable_manager({})

    assert lookup_module.run([C.DEFAULT_BECOME_USER], {}) == [C.DEFAULT_BECOME_USER]


# Generated at 2022-06-23 11:27:10.133095
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:27:10.606268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Not yet implemented")
    assert 1 == 1

# Generated at 2022-06-23 11:27:11.842970
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # TODO: Write a test for this class
    pass

# Generated at 2022-06-23 11:27:18.960019
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #AssertionError: Unable to find setting term
    lookup = LookupModule()
    assert lookup.run('term') is None

    #AssertionError: Cannot use one without the other
    lookup.run('term', plugin_type='ptype')

    #AnsibleOptionsError: Both plugin_type and plugin_name are required, cannot use one without the other
    lookup.run('term', plugin_name='pname')

    #Unable to find setting term
    lookup.run('term', on_missing='error')

    #AssertionError: Must be a string and one of "error", "warn" or "skip"
    lookup.run('term', on_missing='test')

    #AssertionError: Invalid setting identifier, x is not a string
    lookup.run(x)

# Generated at 2022-06-23 11:27:21.785839
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.utils.sentinel import Sentinel
    # Give an error message and an original exception to catch
    msg = 'Test on_missing=error'
    orig_exc = Sentinel('test')

    # Check if MissingSetting constructor returns the right info
    obj = MissingSetting(msg, orig_exc)
    assert obj.msg == msg
    assert obj.orig_exc == orig_exc

# Generated at 2022-06-23 11:27:27.996969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    s = '../../../ansible/plugins/lookup/config'
    from imp import load_module
    # load the module
    Lookup = load_module(s, *imp.find_module(s, ['/home/circleci/project/python/ansible-extras/ansible/plugins/lookup']))
    # instantiate class
    config = Lookup.LookupModule()
    # call method
    config.run('DEFAULT_TASK_TIMEOUT')

# Generated at 2022-06-23 11:27:29.553068
# Unit test for constructor of class MissingSetting

# Generated at 2022-06-23 11:27:41.850171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    # called for both ansible 2.4.x and ansible 2.5.x
    module_utils = __import__('ansible.module_utils', fromlist=['ModuleBase', 'AnsibleModule', 'DEFAULT_ASK_BECOME_PASS_PROMPT'])
    module_utils = __import__('ansible.module_utils', fromlist=['AnsibleModule'])
    # called for both ansible 2.4.x and ansible 2.5.x
    module_utils.AnsibleModule = __import__('ansible.module_utils.basic', fromlist=['AnsibleModule'])

# Generated at 2022-06-23 11:27:53.506766
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Test constructor of class MissingSetting
    :return:
    """
    msg1 = "'option_bla' was not defined in config."
    msg2 = "'option_bla' was not defined in config.bla = True."

    ms1 = MissingSetting(msg1)
    ms2 = MissingSetting(msg2)

    # Check that correct messages are returned
    assert ms1.message == "'option_bla' was not defined in config."
    assert ms2.message == "'option_bla' was not defined in config.bla = True."

    # Check that correct values are returned
    assert ms1.option == 'option_bla'
    assert ms2.option == 'option_bla'

    assert ms1.config == 'config'
    assert ms2.config == 'config'

    # Check that value is not set

# Generated at 2022-06-23 11:28:03.739856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'])
    assert result == ['green', 'yellow', 'cyan']

    result = LookupModule().run(terms=['COLOR_OK'])
    assert result == ['green']

    result = LookupModule().run(terms=[])
    assert result == []

    rc, out, err = LookupModule().run(terms=['COLOR_OK', 'FAKE_CONFIG'])
    assert 'did not find setting FAKE_CONFIG' in out
    assert 'Skipping, did not find setting FAKE_CONFIG' in out
    assert rc == 1

    rc, out, err = LookupModule().run(terms=['COLOR_OK', 'FAKE_CONFIG'], on_missing='error')

# Generated at 2022-06-23 11:28:08.921456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # LookupModule(, basedir=None)
    lookup = LookupModule(basedir="./")
    result = lookup.run(["foo"])
    assert len(result) == 1
    assert result[0] == "foo"
    assert lookup.get_option("on_missing") == "error"