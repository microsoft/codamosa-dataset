

# Generated at 2022-06-23 11:18:20.807329
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_message = "Abc"
    exception_object = Exception(error_message)

    # test if class is created with correct error message and not exception object
    missing_setting = MissingSetting(error_message)
    assert(missing_setting.message == error_message)
    assert(missing_setting.orig_exc is None)

    # test if class is created with correct error message and exception object
    missing_setting = MissingSetting(error_message, orig_exc=exception_object)
    assert(missing_setting.message == error_message)
    assert(missing_setting.orig_exc == exception_object)

    # test if error message and exception object is not provided
    missing_setting = MissingSetting()
    assert(missing_setting.message == "")
    assert(missing_setting.orig_exc is None)


# Generated at 2022-06-23 11:18:29.378832
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.lookup.config import LookupModule
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

    my_env = dict(
        ANSIBLE_CONFIG='/tmp/ansible.cfg'
    )

    lookup_plugin = LookupModule()
    mock_loader = plugin_loader.get('connection_loader')
    mock_loader.all = {
        'local': plugin_loader.connection_loader.all['local'],
        'winrm': plugin_loader.connection_loader.all['winrm'],
        'docker': plugin_loader.connection_loader.all['docker'],
        'smart': plugin_loader.connection_loader.all['smart'],
    }

    shell_loader

# Generated at 2022-06-23 11:18:30.010202
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    pass

# Generated at 2022-06-23 11:18:37.864939
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a mock object of class LookupBase and set MOCK_VARS
    lookup_base_obj = LookupBase()
    MOCK_VARS = {'ansible_port': 2222,
                 'ansible_user': 'mock_user',
                 'port': 333}
    lookup_base_obj.set_options(var_options=MOCK_VARS, direct=None)

    # Create an object of class LookupModule and call its method run
    lookup_obj = LookupModule()
    lookup_obj.set_loader(lookup_base_obj._loader)
    lookup_obj.set_basedir(lookup_base_obj._basedir)
    lookup_obj.set_templar(lookup_base_obj._templar)

    # Call method run using different options
    assert lookup_obj

# Generated at 2022-06-23 11:18:40.877081
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert "test_connection.py was not defined as expected in config" in str(e)
        assert "test" in str(e)

# Generated at 2022-06-23 11:18:42.987074
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('unable to find setting')
    assert error.message == 'unable to find setting'
    assert error.orig_exc is None

# Generated at 2022-06-23 11:18:44.239277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert test_lookup

# Generated at 2022-06-23 11:18:48.090087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest

    x = LookupModule()
    assert isinstance(x, LookupModule)

# Unit test to test methods of class LookupModule

# Generated at 2022-06-23 11:18:49.669650
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('Some message')
    assert e.message == 'Some message'

# Generated at 2022-06-23 11:18:54.712206
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleModuleError
    from ansible.module_utils._text import to_text
    e = AnsibleModuleError('Unable to find setting test')
    result = MissingSetting('Unable to find setting test', orig_exc=e)
    assert to_text(result) == 'Unable to find setting test'

# Generated at 2022-06-23 11:18:56.334990
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj.get_option('var_options') is None


# Generated at 2022-06-23 11:19:02.752473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'ssh'}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh', 'on_missing': 'warn'})

# Generated at 2022-06-23 11:19:08.661667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookups_terms = ['DEFAULT_ROLES_PATH']
    lookup_result = lookup_module.run(lookups_terms)
    assert isinstance(lookup_result, list)
    assert len(lookup_result) == 1
    result = lookup_result.pop()
    assert isinstance(result, string_types)
    assert isinstance(result, string_types)

# Generated at 2022-06-23 11:19:10.781727
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    try:
        raise MissingSetting('msg')
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-23 11:19:15.101960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyClassLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            pass

    Dummy = DummyClassLookupModule('', '', {})
    Dummy.run(terms=['test'], variables={}, on_missing='test')
    try:
        Dummy.run(terms=['test'], variables={}, on_missing='test')
    except SystemExit:
        pass

# Generated at 2022-06-23 11:19:15.929198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:19:21.013003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialise LookupModule object
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    # test repr output
    repr(lookup_module)
    ansible_error = True
    try:
        lookup_module.run([])
    except AnsibleLookupError:
        ansible_error = False
    assert not ansible_error

# Generated at 2022-06-23 11:19:23.195239
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Constructor does not return anything
    assert LookupModule() is None

# Generated at 2022-06-23 11:19:24.168818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:19:32.480511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    def _get_terms():
        lookup_module = LookupModule()
        lookup_module.set_loader(loader)
        lookup_module.set_variable_manager(variable_manager)
        return lookup_module.run(terms=[
            "DEFAULT_ROLES_PATH",
            "UNKNOWN_KEY"],
            variables=variable_manager.get_vars(),
            direct={'on_missing': 'warn'}
        )

    assert len(_get_terms()) == 1

    def _get_terms_with_plugin_info():
        lookup_module = LookupModule()
        lookup_module.set_loader(loader)
        lookup

# Generated at 2022-06-23 11:19:37.065458
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    errmsg = "This is a test"
    orig = "This is an original"

    err = MissingSetting(errmsg, orig_exc=orig)

    assert err.errmsg == errmsg
    assert err.orig_exc == orig



# Generated at 2022-06-23 11:19:47.838180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            raise Exception

    class MockDisplay(object):
        def __init__(self):
            self.error = lambda msg: None

    import ansible.plugins.lookup.config
    lookup = ansible.plugins.lookup.config.LookupModule()
    lookup._display = MockDisplay()
    lookup._templar = MockTemplar()

    class MockConfig(object):
        def __getattr__(self, item):
            return 'config_%s' % item


# Generated at 2022-06-23 11:19:54.256255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    # Add CWD to the path to import ansible
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir)))
    import ansible
    ansible_base = ansible.__file__
    ansible_base = os.path.abspath(os.path.join(ansible_base, os.pardir))
    sys.path.append(os.path.join(ansible_base, 'lib', 'ansible'))
    import ansible.plugins  # noqa: E402

# Generated at 2022-06-23 11:19:58.347567
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('variable foo is not defined').message == 'variable foo is not defined'
    assert MissingSetting('variable foo is not defined', orig_exc=ValueError).message == 'variable foo is not defined'
    assert MissingSetting('variable foo is not defined', orig_exc=ValueError).orig_exc.__class__.__name__ == 'ValueError'

# Generated at 2022-06-23 11:20:08.913180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Load test data from module fixture
    data = load_fixture('config_plugin.yml')

    # Create instance of lookup plugin
    lm = LookupModule()

    # Run test
    terms = data['input']['terms']
    variables = data['input']['variables']
    on_missing = data['input']['on_missing']
    ptype = data['input']['plugin_type']
    pname = data['input']['plugin_name']
    result = lm.run(terms, variables, on_missing=on_missing, plugin_type=ptype, plugin_name=pname)

    # Verify results
    assert result == data['expected']['result']

# Generated at 2022-06-23 11:20:15.182916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results_test = LookupModule().run(terms=['DEFAULT_REMOTE_USER'], variables={'remote_user': 'test_user'})
    results_ansible = LookupModule().run(terms=['DEFAULT_REMOTE_USER'], variables={'remote_user': 'ansible'})

    assert results_test[0] == 'test_user'
    assert results_ansible[0] == 'ansible'

# Generated at 2022-06-23 11:20:18.558464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = dict(
        on_missing='error',
        plugin_type=None,
        plugin_name=None
    )
    assert LookupModule(None, options, None).run(['DEFAULT_BECOME_USER'], None) == [u'root']


# Generated at 2022-06-23 11:20:27.659361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # To test that the option parser is working correctly, redefine
    # the C.get_config_value method and call
    # LookupModule.run(['FOO_BAR']...
    def mocked_get_config_value(term, variables=None, capture_errors=True, plugin_type=None, plugin_name=None):
        return "mocked_get_config_value_result"

    old_method = C.get_config_value
    C.get_config_value = mocked_get_config_value


# Generated at 2022-06-23 11:20:31.286453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ansible_colors = ['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']
    result = lookup.run(ansible_colors, wantlist=True)
    assert len(result) == 3

# Generated at 2022-06-23 11:20:32.107317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:20:34.782999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    result = test_obj.run(['get_user_callbacks'])
    assert result[0] == ['default']

# Generated at 2022-06-23 11:20:35.758072
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup = LookupModule()

# Generated at 2022-06-23 11:20:37.697646
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("A setting is missing")
    except MissingSetting as ex:
        assert str(ex) == 'A setting is missing'

# Generated at 2022-06-23 11:20:38.875624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-23 11:20:39.697699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Fix this test
    assert True

# Generated at 2022-06-23 11:20:40.773979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-23 11:20:45.890533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype = 'vars'
    pname = 'defaults'
    terms = ['DEFAULT_ROLES_PATH']
    variables = dict()
    test = LookupModule()
    test.run(terms, variables, plugin_type = ptype, plugin_name = pname)

# Generated at 2022-06-23 11:20:47.345716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:20:50.940846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options=None, direct={'on_missing': 'skip'})
    assert lookup.run(['DEFAULT_BECOME_USER'], None, on_missing='skip') != []

# Generated at 2022-06-23 11:20:52.965656
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    instance = MissingSetting("Hello World!")

    assert instance.kwargs['msg'] == "Hello World!"

# Generated at 2022-06-23 11:20:56.435186
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        MissingSetting()


# Generated at 2022-06-23 11:20:57.484057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None)

# Generated at 2022-06-23 11:21:01.997630
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.utils.sentinel import Sentinel

    sent = Sentinel('my sentinel')
    error = MissingSetting('test', orig_exc=sent)
    assert(error.orig_exc is sent)
    assert(error.msg == 'test')

# Generated at 2022-06-23 11:21:12.697281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from ansible.plugins.loader import become_loader
    term = 'DEFAULT_BECOME_USER'
    config = {'on_missing': 'error'}
    lu = LookupModule(Display(), config=config)
    result = lu.run([term])
    assert result == [C.DEFAULT_BECOME_USER]

    term = 'ANSIBLE_HOST_KEY_CHECKING'
    config = {'on_missing': 'skip'}
    lu = LookupModule(Display(), config=config)
    result = lu.run([term])
    assert result == []

    term = ['DEFAULT_BECOME_USER', 'FOO_BAR']
    config = {'on_missing': 'warn'}
    lu = LookupModule

# Generated at 2022-06-23 11:21:13.468703
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize the class
    l = LookupModule()

# Generated at 2022-06-23 11:21:15.429863
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('foo', 'bar')
    assert missing_setting.orig_exc == 'bar'

# Generated at 2022-06-23 11:21:16.738053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 11:21:28.545009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert '_get_plugin_config' == LookupModule.run.__code__.co_varnames[0]
    assert '_get_global_config' == LookupModule.run.__code__.co_varnames[1]
    assert 'AnsibleOptionsError' == LookupModule.run.__code__.co_varnames[2]
    assert 'AnsibleLookupError' == LookupModule.run.__code__.co_varnames[3]
    assert 'Sentinel' == LookupModule.run.__code__.co_varnames[4]
    assert 'string_types' == LookupModule.run.__code__.co_varnames[5]
    assert 'AnsibleError' == LookupModule.run.__code__.co_varnames[6]

# Generated at 2022-06-23 11:21:31.832074
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "test message"
    try:
        raise RuntimeError("failed test")
    except RuntimeError as e:
        ex = MissingSetting(msg, e)
    assert ex.orig_exc is not None
    assert ex.message == msg

# Generated at 2022-06-23 11:21:39.673189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()

    # Test 1
    plugin._display.verbosity = 4

    ret = plugin.run(['DEFAULT_BECOME_USER'], dict())
    assert ret == ['root'], 'Unexpected result: %s' % (ret)

    # Test 2
    plugin._display.verbosity = 0

    ret = plugin.run(['DEFAULT_ROLES_PATH'], dict())
    assert ret == [u'/etc/ansible/roles:/usr/share/ansible/roles'], 'Unexpected result: %s' % (ret)

    # Test 3
    ret = plugin.run(['DEFAULT_UNKNOWN'], dict(), on_missing='warn')
    assert ret == [], 'Unexpected result: %s' % (ret)

    # Test 4
    ret = plugin.run

# Generated at 2022-06-23 11:21:42.514278
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test'
    m = MissingSetting(msg)
    assert m.msg == msg

# Generated at 2022-06-23 11:21:44.080676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    check_method_run(LookupModule)


# Generated at 2022-06-23 11:21:46.110553
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
  exc = MissingSetting('msg', 'orig_exc')
  assert exc.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:21:47.538266
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert 'MissingSetting' in str(MissingSetting())

# Generated at 2022-06-23 11:21:49.360967
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    me = MissingSetting('test')
    assert me.message == 'test'
    assert me.orig_exc is None

# Generated at 2022-06-23 11:21:58.801817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run([]) == []
    assert l.run(['ANSI_COLOR']) == [C.ANSIBLE_COLOR]
    assert l.run(['ANSIBLE_NOCOLOR']) == [C.ANSIBLE_NOCOLOR]
    assert l.run(['UNKNOWN']) == []
    assert l.run(['UNKNOWN'], on_missing='error') == []
    assert l.run(['UNKNOWN'], on_missing='warn') == []
    assert l.run(['UNKNOWN'], on_missing='skip') == []
    assert l.run(['C.ANSIBLE_NOCOLOR'], on_missing='error') == []

# Generated at 2022-06-23 11:22:09.450560
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # No exception, only set message
    try:
        raise MissingSetting('message')
    except AnsibleOptionsError as e:
        assert 'message' in str(e)
        assert e.orig_exc is None

    # Only set exception
    try:
        raise MissingSetting(orig_exc='exception')
    except Exception as e:
        assert 'exception' in str(e)
        assert 'orig_exc' not in str(e)

    # Set exception and message
    try:
        raise MissingSetting('message', orig_exc='exception')
    except Exception as e:
        assert 'message' in str(e)
        assert 'exception' in str(e)
        assert 'orig_exc' not in str(e)

# Generated at 2022-06-23 11:22:19.507860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    parent_path = os.path.dirname(os.path.realpath(__file__))

    ptype = 'lookup'
    pname = 'first_found'
    config = 'paths'
    term_missing = 'foo'
    term_ok = 'FIRST_FOUND_LOOKUP_PLUGIN_PATHS'

    terms = [ term_missing, term_ok ]

    if PY2:
        fake_stdin = open(os.devnull, 'w')
        sys.stdin = fake_stdin

# Generated at 2022-06-23 11:22:24.360523
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    terms = ["DEFAULT_ROLES_PATH", "DEFAULT_BECOME_USER"]

    result = lookup.run(terms)
    assert isinstance(result, list)
    assert "~/.ansible/roles" in result
    assert "root" in result

# Generated at 2022-06-23 11:22:28.895000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(
        terms=['DEFAULT_BECOME_USER'],
        variables={
            'ansible_become_user': 'admin',
            'ansible_become_password': 'secret',
        }
    )[0] == 'root'

# Generated at 2022-06-23 11:22:35.509162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test
    """

    # get an instance of the LookupModule
    lookup_module = LookupModule()

    # get the options from the map
    option_map = lookup_module.get_option_map()

    # expected options and their types
    expected_options = {
        'on_missing': str,
        'plugin_type': str,
        'plugin_name': str
    }

    # check that the option map is equal to the expected map
    assert option_map == expected_options, \
    'expected option map does not match the option map'


# Generated at 2022-06-23 11:22:38.747275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create object 'object' of class LookupModule
    object = LookupModule()
    assert isinstance(object, LookupModule)

# Generated at 2022-06-23 11:22:41.172116
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config = LookupModule()
    assert hasattr(config, 'run')
    assert hasattr(config, 'set_options')


# Generated at 2022-06-23 11:22:46.933244
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert to_native(e) == "test"
    try:
        e = MissingSetting("test2")
        raise MissingSetting("test1", orig_exc=e)
    except MissingSetting as e:
        assert to_native(e) == "test1"
        assert str(e.orig_exc) == "test2"

# Generated at 2022-06-23 11:22:47.991895
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj=LookupModule()


# Generated at 2022-06-23 11:22:58.212096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    globals_dict = globals()
    globals_dict['C'] = type(Sentinel)()

    def test_get_config_value_side_effect(key,
                                          plugin_type=Sentinel,
                                          plugin_name=Sentinel,
                                          variables=Sentinel):
        if key == 'DEFAULT_BECOME_USER':
            return 'root'

        elif key == 'DEFAULT_ROLES_PATH':
            return ['/etc/ansible/roles', '/etc/ansible/library']

        elif key == 'RETRY_FILES_SAVE_PATH':
            return '/etc/ansible/retry'

        elif key == 'COLOR_OK':
            return 'green'

        elif key == 'COLOR_CHANGED':
            return 'yellow'

       

# Generated at 2022-06-23 11:23:03.288983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mockery = get_module_mock()
    mockery.playbook = get_playbook_mock()
    mockery.display = get_display_mock()

    mod = LookupModule(mockery._loader, mockery._templar, mockery._shared_loader_obj)
    assert isinstance(mod, LookupModule)


# Generated at 2022-06-23 11:23:04.739779
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting('test exception')
    assert err.msg == 'test exception'

# Generated at 2022-06-23 11:23:07.911714
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('my message', orig_exc=LookupBase())
    assert m.message == 'my message'
    assert m.orig_exc.__class__.__name__ == 'AnsibleUndefinedVariable'

# Generated at 2022-06-23 11:23:16.378723
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Success: plugin_type and plugin_name
    result = LookupModule(Sentinel.loader, ptype='vars', pname='set_fact', variables=Sentinel.variables, on_missing=Sentinel.on_missing).run(terms=Sentinel.term)
    assert result == (C.config.get_config_value(Sentinel.term[0], plugin_type='vars', plugin_name='set_fact', variables=Sentinel.variables),)

    # Failure: plugin_type and plugin_name
    result = LookupModule(Sentinel.loader, pname='set_fact', variables=Sentinel.variables, on_missing=Sentinel.on_missing).run(terms=Sentinel.term)
    assert isinstance(result, AnsibleOptionsError)

    # Success: normal

# Generated at 2022-06-23 11:23:24.869993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    kwargs = {'on_missing': 'error', 'plugin_name': 'ssh'}
    variables = {}
    lookup = LookupModule()
    lookup.set_options(var_options=variables, direct=kwargs)
    lookup.run(terms, variables, **kwargs)
    assert lookup.set_options(var_options=variables, direct=kwargs) == None


# Generated at 2022-06-23 11:23:31.630763
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "test can not find config"
    e = MissingSetting(msg)
    assert isinstance(e, Exception)
    assert str(e) == msg
    assert e.orig_exc is None
    assert e.cfg_key is None
    assert e.cfg_section is None
    e = MissingSetting(msg, orig_exc='fake', cfg_key='key', cfg_section='section')
    assert e.orig_exc == 'fake'
    assert e.cfg_key == 'key'
    assert e.cfg_section == 'section'
    assert str(e) == msg


# Generated at 2022-06-23 11:23:34.814391
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    setting = "UNKNOWN"
    msg = u"Configuration error: '%s' is not a legal setting name" % setting
    error = MissingSetting(msg)
    assert error.message == msg

# Generated at 2022-06-23 11:23:45.920941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # Global config
    configs = ["PRIVATE_ROLE_VARS_PATH"]
    for config in configs:
        ret = l.run([config])
        assert ret[0] == config

    # Plugin config
    ret = l.run(["remote_tmp"], plugin_type="shell", plugin_name="sh")
    assert ret[0] == "~/.ansible/tmp"

    # default_roles_path
    ret = l.run(["DEFAULT_ROLES_PATH"], on_missing="warn")
    assert ret[0] == "./roles:/usr/share/ansible/roles"

    # missing config
    with pytest.raises(AnsibleLookupError):
        ret = l.run(["MISSING_CONFIG"])

   

# Generated at 2022-06-23 11:23:49.618691
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    c = MissingSetting('test exception', orig_exc=AnsibleError('test exception'))  # pylint: disable=unused-variable



# Generated at 2022-06-23 11:23:57.436888
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    try:
        lookup.run([None])
    except AnsibleOptionsError:
        pass
    else:
        raise Exception("AnsibleOptionsError was not raised")

    try:
        lookup.run(1)
    except AnsibleOptionsError:
        pass
    else:
        raise Exception("AnsibleOptionsError was not raised")

    try:
        lookup.run([1, 2])
    except AnsibleOptionsError:
        pass
    else:
        raise Exception("AnsibleOptionsError was not raised")

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 11:24:00.403462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    expected_result = ['test_result']
    result = test_lookup.run(terms=['test_config'])
    assert result == expected_result


# Generated at 2022-06-23 11:24:05.553011
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils._text import to_native

    msg = 'test_message'
    exc = AnsibleLookupError(msg)
    try:
        raise MissingSetting(msg, orig_exc=exc)
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert isinstance(e, AnsibleLookupError)
        assert msg == to_native(e)

# Generated at 2022-06-23 11:24:06.200531
# Unit test for constructor of class LookupModule
def test_LookupModule():
     assert LookupModule

# Generated at 2022-06-23 11:24:08.009066
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()
    lookup_plugin.run([])



# Generated at 2022-06-23 11:24:09.269222
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert isinstance(lookup_mod, LookupModule)

# Generated at 2022-06-23 11:24:11.355703
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)
    assert hasattr(lm, 'run')

# Generated at 2022-06-23 11:24:18.037961
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test that MissingSetting(msg, orig_exc=None) takes two parameters.
    # msg (str) --> parameter for the message
    # orig_exc (Exception) --> an optional original exception that is the base
    # for this exception.
    try:
        # MissingSetting is raised when the configuration setting is missing.
        raise MissingSetting("test_message")
    except MissingSetting as e:
        # Check if the message is the same
        assert e.message == "test_message"
        # Check that the original exception is none
        assert e.orig_exc is None


# Generated at 2022-06-23 11:24:18.985224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:24:25.433342
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting('test')
    assert m.str == 'test'
    assert str(m) == 'test'

    m2 = MissingSetting(orig_exc='a')
    assert m2.orig_exc == 'a'

    m3 = MissingSetting('test', orig_exc='a')
    assert m3.orig_exc == 'a'
    assert m3.str == 'test'
    assert str(m3) == 'test'

# Generated at 2022-06-23 11:24:25.932658
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:24:34.082767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_REMOTE_TMP', 'CACHEDIR']
    variables = {}
    result = lookup.run(terms, variables)
    assert result == [u'$HOME/.ansible/tmp', u'$HOME/.ansible/tmp']
    # test with plugin option
    result = lookup.run(terms, variables, plugin_type='shell', plugin_name='sh')
    assert result == [u'$HOME/.ansible/tmp', u'$HOME/.ansible/tmp']
    # test with invalid plugin option
    result = lookup.run(terms, variables, plugin_type='shell')
    assert result == [u'$HOME/.ansible/tmp', u'$HOME/.ansible/tmp']
    # test on_missing='warn' option

# Generated at 2022-06-23 11:24:40.532332
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""

    # Constructor without parameters
    test = LookupModule()

    # Check attributes after construction
    assert test._templar is None
    assert test._loader is None
    assert not test._display
    assert not test._options
    assert not test._templar_options
    assert not test._use_cache
    assert not test._runner_cache
    assert test._display_options
    assert not test._variables



# Generated at 2022-06-23 11:24:41.901642
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        MissingSetting()

# Generated at 2022-06-23 11:24:43.352308
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 11:24:43.961525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:24:44.596479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:24:54.030381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.utils import plugin_docs
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring

    lookup_plugin = lookup_loader.get('config', class_only=True)
    display = Display()
    lookup_plugin._display = display

    lookup_plugin._load_name = 'config'
    lookup_plugin.set_options({})

    # Test with DEFAULT_ROLES_PATH, DEFAULT_ROLES_PATH is list, returns list.
    lookup_plugin.run(['DEFAULT_ROLES_PATH'], variables=None)
    # Test with DEFAULT_ROLES_PATH, DEFAULT_ROLES_PATH is list, returns list.

# Generated at 2022-06-23 11:24:56.065642
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('on_missing') == 'error'


# Generated at 2022-06-23 11:25:06.787015
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with no parameters
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None
    assert lookup_plugin.get_option('on_missing') == 'error'
    assert lookup_plugin.get_option('plugin_type') == None
    assert lookup_plugin.get_option('plugin_name') == None

    # Test with parameters
    lookup_plugin = LookupModule(terms=['localhost'], on_missing='warn', plugin_type='vars', plugin_name='foo')
    assert lookup_plugin is not None
    assert lookup_plugin.get_option('on_missing') == 'warn'
    assert lookup_plugin.get_option('plugin_type') == 'vars'
    assert lookup_plugin.get_option('plugin_name') == 'foo'

    # Test with invalid on_missing value

# Generated at 2022-06-23 11:25:08.999313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert hasattr(LookupBase, '__module__')


# Generated at 2022-06-23 11:25:17.025273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test MissingSetting
    lookup_module = LookupModule()
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_module.run(terms=[''], variables=None, on_missing='not_error_not_warn_not_skip')
    assert '"on_missing" must be a string and one of "error", "warn" or "skip", not ' in str(e.value)
    with pytest.raises(AnsibleOptionsError) as e:
        lookup_module.run(terms=[0], variables=None, on_missing='error')
    assert 'Invalid setting identifier, "0" is not a string, its a <' in str(e.value)

# Generated at 2022-06-23 11:25:20.136447
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Missing config setting")
    except MissingSetting as e:
        assert 'setting' in e.message

# Generated at 2022-06-23 11:25:21.488811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:25:24.443983
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    m = MissingSetting("this is the message", orig_exc=Exception("this is the original exception"))
    assert m.message == "this is the message"
    assert m.orig_exc.args[0] == "this is the original exception"

# Generated at 2022-06-23 11:25:25.002994
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting('error')

# Generated at 2022-06-23 11:25:26.888180
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)

# Generated at 2022-06-23 11:25:37.559254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # need to mock the display object so warnings come through
    import unittest.mock
    display = unittest.mock.MagicMock()
    LookupModule.display = display

    # setup a fake config we can read
    C.DEFAULT_BECOME_USER = 'testy'

    # invalid setting - should raise
    lookup = LookupModule()
    try:
        lookup.run([1], variables=None)
        assert False, 'Should have raised AnsibleOptionsError'
    except AnsibleOptionsError as e:
        assert 'invalid' in to_native(e).lower()

    # invalid setting - should raise

# Generated at 2022-06-23 11:25:47.541135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys

    test_path = os.path.join(os.path.dirname(__file__), 'lookup_demos/lookup_demo_config.yml')
    test_vars = {'global_config': 'library'}

    print("Running " + os.path.basename(__file__))
    print("Ansible: " + os.environ.get("ANSIBLE_VERSION", "unknown version"))
    print("python: " + sys.version)
    print("platform: " + sys.platform + "\n")

    lm = LookupModule()
    lm.set_option_from_plugin('config', {})
    results = lm.run(["ROLES_PATH", "RETRY_FILES_SAVE_PATH"], variables=test_vars)
   

# Generated at 2022-06-23 11:25:52.040941
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Setting not found'
    e = Exception("An exception")
    try:
        raise MissingSetting(msg, orig_exc=e)
    except MissingSetting as e:
        print("message: %s, orig_exc: %s" % (e.message, e.orig_exc))

# Generated at 2022-06-23 11:25:55.717209
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError

    try:
        raise MissingSetting("test")

    except MissingSetting as e:
        assert e.message == "test", "Did not create message as expected"

# Generated at 2022-06-23 11:26:04.372146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = [('FOO', {}), ('FOO', {'on_missing': 'error'}), ('FOO', {'on_missing': 'warn'}), ('FOO', {'on_missing': 'skip'})]
    answers = [AnsibleLookupError, AnsibleLookupError, None, None]

    # Example of variables containg "foo"
    # variables = {
    #     'variable': {
    #         'foo': 'bar'
    #     },
    #     'variable_manager': {
    #         'extra_vars': {
    #             'foo': 'bar'
    #         },
    #         'host_vars': {
    #             'foo': 'bar'
    #         },
    #         'group_vars': {
    #             'foo': '

# Generated at 2022-06-23 11:26:14.133975
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 11:26:23.318374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables =  dict(ansible_connection='ssh')
    kwargs = dict()
    result = lookup.run(terms, variables, **kwargs)
    assert result[0] == 'root'
    assert result[1] == ['/etc/ansible/roles', '/usr/share/ansible/roles']


# Generated at 2022-06-23 11:26:24.380787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Un-implemented, remains to be seen how this will work
    pass

# Generated at 2022-06-23 11:26:27.430359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        assert False, "Failed to instantiate LookupModule: %s" % to_native(e)

# Generated at 2022-06-23 11:26:30.657446
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_msg = "foo was not defined"
    missing_error = MissingSetting(error_msg)
    assert missing_error.message == error_msg

# Generated at 2022-06-23 11:26:41.899419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil
    import pytest
    from ansible.module_utils._text import to_bytes

    # create a directory to test
    temp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(temp_dir, 'foobar')
    os.mkdir(test_dir)

    test_file_name = os.path.join(temp_dir, 'test.yml')

    # create a test config file
    test_file = open(test_file_name, 'wb')
    fd1 = to_bytes(
        '''
        ---
        test: 'value'
        '''
    )
    test_file.write(fd1)
    test_file.close()

    # create a test playbook
    test_playbook = to

# Generated at 2022-06-23 11:26:51.957412
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import lookup_loader
    from ansible.utils import context_objects as co
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars


    def _mock_run(self, terms, variables=None, **kwargs):
        return terms

    LookupModule.run = _mock_run

    # Mixin method in LookupModule doesn't use self
    # pylint: disable=unused-argument

# Generated at 2022-06-23 11:26:54.688502
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test_msg')
    except MissingSetting as e:
        assert str(e) == 'test_msg'

# Generated at 2022-06-23 11:27:05.796928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.constants import AnsibleUnsafe

    def _mock_C_config__get_config_value(config, plugin_type=None, plugin_name=None, variables=None):
        import ansible.utils.unsafe_proxy as unsafe_proxy

        if config == 'DEFAULT_BECOME_USER':
            return unsafe_proxy.wrap_var(AnsibleUnsafe('root'))
        elif config == 'DEFAULT_ROLES_PATH':
            return unsafe_proxy.wrap_var(AnsibleUnsafe([u'/home/user1/roles', u'/home/user2/roles']))
        elif config == 'RETRY_FILES_SAVE_PATH':
            return unsafe_proxy.wrap_var(AnsibleUnsafe('/home/user/'))

# Generated at 2022-06-23 11:27:10.280186
# Unit test for constructor of class LookupModule
def test_LookupModule():
   test_terms = ['DEFAULT_BECOME_USER']
   test_variables = {'DEFAULT_BECOME_USER': 'test_var'}
   result = LookupModule(None, test_variables, test_terms).run()
   assert result == ['test_var']


# Generated at 2022-06-23 11:27:12.902154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run([], None, on_missing='error')
    assert result == []

# Generated at 2022-06-23 11:27:18.314991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    # Testing with lookup plugin 'config'
    inst = lookup_loader.get('config')
    assert(len(terms) == len(inst.run(terms=terms, variables=variables, on_missing=missing)))

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 11:27:19.785845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.display is not None

# Generated at 2022-06-23 11:27:30.005099
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.utils.sentinel import Sentinel

    # test __init__(self, msg, orig_exc=None)
    m = MissingSetting('msg1')
    assert m.msg == 'msg1'
    assert m.orig_exc is None
    m = MissingSetting('msg2', orig_exc=Sentinel)
    assert m.msg == 'msg2'
    assert m._orig_exc is Sentinel

    # test __str__(self)
    assert str(m) == 'msg2'

    # test __repr__(self)
    assert repr(m) == 'AnsibleOptionsError(msg=\'msg2\', orig_exc=Sentinel())'
    m = MissingSetting('msg3', orig_exc=None)

# Generated at 2022-06-23 11:27:31.928130
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting('The setting X is missing')

# Generated at 2022-06-23 11:27:33.154014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:27:35.627497
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('no key')
    assert 'no key' == str(missing_setting)

# Generated at 2022-06-23 11:27:39.599501
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting.__name__ == 'MissingSetting'
    assert MissingSetting.__doc__ == 'Fatal error when option or config is missing'
    assert not issubclass(MissingSetting, Exception)



# Generated at 2022-06-23 11:27:41.715892
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Error')
    except MissingSetting as e:
        assert str(e) == 'Error'



# Generated at 2022-06-23 11:27:43.703780
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(terms=["foo", "bar"])
    assert ret == [], ret

# Unit tests for _get_plugin_config()

# Generated at 2022-06-23 11:27:49.097830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(terms=["LIBRARY_PATH"])
    print(result)
    assert result == ['/usr/share/my_ansible/modules', '/usr/share/ansible/plugins/modules']


# Generated at 2022-06-23 11:27:59.693401
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.common.parameters import MissingParameter, MissingParameterDict, MissingParameterDictKey
    from ansible.module_utils.common.parameters import MissingRequiredArgumentError, MissingRequiredArgument, MissingRequiredActionArgument

    check_list = [MissingParameter(), MissingParameterDict(), MissingParameterDictKey('test_key'),
        MissingRequiredArgumentError(), MissingRequiredArgument('test_arg'), MissingRequiredActionArgument('test_action')]

    for obj in check_list:
        ansible_options_error = MissingSetting(obj.explanation, orig_exc=obj)
        assert isinstance(ansible_options_error.orig_exc, AnsibleOptionsError)
        assert isinstance(MissingSetting(explanation=obj.explanation, orig_exc=obj), AnsibleOptionsError)

# Generated at 2022-06-23 11:28:01.867054
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting as e:
        assert e.__class__ == AnsibleOptionsError

# Generated at 2022-06-23 11:28:13.396761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {
        'var_a': 'var_a',
        'var_b': 'var_b'
    }
