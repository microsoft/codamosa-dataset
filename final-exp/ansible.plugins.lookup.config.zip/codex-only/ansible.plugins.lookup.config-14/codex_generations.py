

# Generated at 2022-06-23 11:18:14.720596
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:18:24.022144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a mock object to pass in to LookupModule constructor
    class MockDisplay:
        def warning(self, msg):
            pass
    display = MockDisplay()

    # Instantiate a LookupModule object
    obj = LookupModule(loader=None, templar=None, shared_loader_obj=None, display=display)

    # Make sure on_missing is properly set
    assert obj.get_option('on_missing') == 'error'

    # Test to make sure constructor raises
    # AnsibleOptionsError if on_missing is not
    # equal to error, warn, or skip
    try:
        obj.set_options(on_missing='bad_value')
        raise RuntimeError("failed to raise AnsibleOptionsError")
    except AnsibleOptionsError:
        pass

# Unit test to test run() method
# of class

# Generated at 2022-06-23 11:18:33.595019
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ####
    #### test 1:
    ####
    lookup_plugin = LookupModule()

    terms = ["LOGGING_CONFIG_FILE", "REMOTE_USER"]
    result_list = lookup_plugin.run(terms, variables=None, **dict(on_missing='error'))

    # Check that output is a list and not a string
    assert isinstance(result_list, list)

    assert result_list == [C.LOGGING_CONFIG_FILE, C.DEFAULT_REMOTE_USER]

    ####
    #### test 2:
    ####
    lookup_plugin = LookupModule()

    # Generate an exception on invalid setting identifier
    terms = ["LOGGING_CONFIG_FILE", 3]

# Generated at 2022-06-23 11:18:34.714274
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None


# Generated at 2022-06-23 11:18:45.699162
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    # Test valid combination of plugin_name and plugin_type
    plugin_name = 'executable'
    plugin_type = 'connection'
    lm = LookupModule()
    options = {'plugin_name': plugin_name,
               'plugin_type': plugin_type}
    result = lm.run(terms=['remote_tmp'], variables={}, **options)
    assert result == ['/tmp/ansible-tmp-1543211551.33-25168123431741']

    # Test invalid plugin_name and plugin_type combination
    plugin_name = 'executable'
    plugin_type = 'shell'
    lm = LookupModule()

# Generated at 2022-06-23 11:18:48.993622
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'this is a test'
    exc = ValueError(msg)
    m = MissingSetting(msg, orig_exc=exc)
    assert msg in str(m)

# Generated at 2022-06-23 11:18:52.544215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'USER']
    variables = None
    settings = LookupModule().run(terms, variables)
    assert type(settings) == list
    assert settings[0] == 'root'
    assert settings[1] == 'root'

# Generated at 2022-06-23 11:19:00.691620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Effectively make module_utils.config an alias to constants
    class C:
        DEFAULT_RETRY_FILES_ENABLED = 'DEFAULT_RETRY_FILES_ENABLED'
        HOST_KEY_CHECKING = 'HOST_KEY_CHECKING'
        class config:
            @staticmethod
            def get_config_value(term, variables, plugin_type=None, plugin_name=None):
                if plugin_type or plugin_name:
                    return 'value for {} in {} {}'.format(term, plugin_type, plugin_name)
                else:
                    return getattr(C, term, '')

    from ansible.config import constants as C2
    C2.DEFAULT_RETRY_FILES_ENABLED = 'DEFAULT_RETRY_FILES_ENABLED'
    C

# Generated at 2022-06-23 11:19:02.272956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 11:19:04.241810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_LookupModule = LookupModule()


# Generated at 2022-06-23 11:19:07.305915
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test', orig_exc='test')
    except MissingSetting as e:
        assert str(e) == 'test'
        assert e.orig_exc == 'test'

# Generated at 2022-06-23 11:19:17.342833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    # create an instance of LookupModule
    module = LookupModule()
    try:
        # calls the run method of the LookupModule class with valid terms on the instance 'module'
        # this should return a list with a string in it
        result = module.run(terms=["DEFAULT_ROLES_PATH"])
        assert isinstance(result, list)
        assert isinstance(result[0], string_types)
    except AnsibleLookupError as e:
        # fail the test if any of the lines above raises an exception
        assert False, to_native(e)


# Generated at 2022-06-23 11:19:18.642491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert type(l) == LookupModule

# Generated at 2022-06-23 11:19:21.203938
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    result = MissingSetting("Invalid setting")
    assert result.message == "Invalid setting"
    assert isinstance(result, AnsibleOptionsError)


# Generated at 2022-06-23 11:19:27.332748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=no-member
    module = LookupModule()
    assert module.get_option('on_missing') == 'error'
    assert module.on_missing == module.get_option('on_missing')
    module.set_options(var_options=None, direct={'on_missing': 'skip'})
    assert module.on_missing == 'skip'
    assert module.get_option('on_missing') == 'skip'

# Generated at 2022-06-23 11:19:30.618064
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    try:
        raise MissingSetting('an error occurred')
    except AnsibleOptionsError as e:
        assert 'an error occurred' in to_native(e)

# Generated at 2022-06-23 11:19:32.158681
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, "run")

# Generated at 2022-06-23 11:19:44.308060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.vars import VariableManager

# Generated at 2022-06-23 11:19:45.311095
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule())

# Generated at 2022-06-23 11:19:46.575298
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_x = LookupModule()
    assert(lookup_x != None)

# Generated at 2022-06-23 11:19:57.635927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Non-string terms
    terms = [1, 2, 3]
    try:
        actual_result = module.run(terms)
    except AnsibleOptionsError as e:
        expected_result = 'Invalid setting identifier, "1" is not a string, its a '
        assert str(e).startswith(expected_result)

    # Wrong value for plugin_type
    kwargs = {'plugin_type': 'event_handler'}
    try:
        actual_result = module.run([], **kwargs)
    except AnsibleOptionsError as e:
        expected_result = 'Invalid plugin_type, must be one of: become, cache, callback, cliconf, connection, httpapi, inventory, lookup, netconf, shell, vars'

# Generated at 2022-06-23 11:19:59.875462
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin_class = plugin_loader.get('config')
    lookup_plugin = lookup_plugin_class()

# Unit test: see https://github.com/ansible/ansibullbot/pull/615 for context

# Generated at 2022-06-23 11:20:11.957288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def make_test(terms, variables, options, expected):
        class Test(LookupBase):
            def run(self, terms, variables=None, **kwargs):
                self.set_options(var_options=variables, direct=options)
                return super(Test, self).run(terms, variables=variables, **kwargs)
        t = Test()
        try:
            result = t.run(terms=terms, variables=variables, **options)
            assert result == expected
        except Exception as e:
            assert type(e) == expected

    yield make_test, ['x'], {}, {}, AnsibleOptionsError
    yield make_test, ['x'], {}, {'on_missing': 'x'}, AnsibleOptionsError

# Generated at 2022-06-23 11:20:13.436123
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 11:20:21.508803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Set up inventory for test
    inventory = {'_variables': {'my_variable': 'my_value'}}
    # Set up constants for test
    setattr(C, 'my_value_constant', 'my_value_constant_to_test')
    # Set up plugin config
    setattr(C.config, 'get_config_value', get_config_value_mock)
    # Run 'run' method
    test_result = lookup_module.run([
        'my_variable',
        'my_value_constant',
        'my_missing_constant'
    ], inventory, on_missing='skip')
    # Assert results
    assert test_result == ['my_value', 'my_value_constant_to_test']



# Generated at 2022-06-23 11:20:26.363500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var_options = ""
    direct = {"plugin_name":"sh","plugin_type":"shell"}
    lookup_module.set_options(var_options=var_options, direct=direct)
    terms = 'DEFAULT_REMOTE_TMP'
    lookup_module_result = lookup_module.run(terms=terms)
    assert 'DEFAULT_REMOTE_TMP' in lookup_module_result

# Generated at 2022-06-23 11:20:32.945170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test no args constructor
    try:
        test = LookupModule()
    except TypeError as e:
        # Exception message is not standardized, so check it out with startswith
        assert e.args[0].startswith("__init__() missing")
        test = None
    assert test == None

    # Test constructor with args
    test = LookupModule('test')
    assert test != None
    assert isinstance(test, LookupModule)

# Generated at 2022-06-23 11:20:38.376012
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('this is the message')
    except MissingSetting as e:
        assert str(e) == 'this is the message'
        assert e.orig_exc == None
    try:
        raise MissingSetting('this is the message', orig_exc='this is the original exception')
    except MissingSetting as e:
        assert e.orig_exc == 'this is the original exception'
        assert str(e) == 'this is the message'

# Generated at 2022-06-23 11:20:42.293365
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[], variables=None, **{'_ansible_verbosity': 4})
    except Exception as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not None' in str(e)
    else:
        raise Exception('Failed to assert')

# Generated at 2022-06-23 11:20:51.550483
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # test that exception can be constructed with two parameters
    try:
        raise MissingSetting("foo", "bar")
    except MissingSetting as e:
        assert e.args[0] == "foo"
        assert e.args[1] == "bar"
    else:
        raise Exception("Failed to construct MissingSetting with 2 parameters")
    # test that exception can be constructed with one parameter
    try:
        raise MissingSetting("foo")
    except MissingSetting as e:
        assert e.args[0] == "foo"
    else:
        raise Exception("Failed to construct MissingSetting with 1 parameter")

# Generated at 2022-06-23 11:20:52.538714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 11:21:05.915483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    class FakeSelf:
        class FakeDisplay:
            class FakeWarning:
                def __repr__(self):
                    return 'Warning'
            FakeWarning = FakeWarning()

            def warning(*args, **kwargs):
                return FakeSelf.FakeDisplay.FakeWarning
        FakeDisplay = FakeDisplay()

    self = FakeSelf
    self.set_options = lambda x, y: 0
    self._display = FakeSelf.FakeDisplay
    self.get_option = lambda x: 'skip'
    constants = C

# Generated at 2022-06-23 11:21:16.723215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_native
    from ansible.plugins.loader import lookup_loader, filter_loader
    from ansible.plugins.loader import _get_all_subclasses
    from ansible.plugins.loader import _get_filters, _get_lookups
    from ansible import constants as C
    import os

    # We need to load all the plugins to get their class variables
    # to know what options they may define.
    basedir = os.path.dirname(__file__).split(os.sep)
    basedir = os.sep.join(basedir[0:-1])

# Generated at 2022-06-23 11:21:18.333584
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 11:21:20.230099
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Not sure how to test constructors, so just make sure it runs
  LookupModule()

# Generated at 2022-06-23 11:21:31.042334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # test with missing=error
    lookup_plug = LookupModule()
    lookup_plug.set_options(var_options=None, direct={'on_missing': 'error'})
    with pytest.raises(AnsibleLookupError) as exec_info:
        lookup_plug.run(terms=['config', 'var'])
    msg = str(exec_info.value)
    assert msg.startswith('Unable to find setting config')

    # test with missing=warn
    lookup_plug.set_options(var_options=None, direct={'on_missing': 'warn'})
    result = lookup_plug.run(terms=['config', 'var'])
    assert result == []

    # test with missing=skip

# Generated at 2022-06-23 11:21:32.244280
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 11:21:40.009938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = [
        'DEFAULT_VAULT_PASSWORD_FILE',
        'DEFAULT_REMOTE_TMP',
        'DEFAULT_LOCAL_TMP'
    ]

    ret = lookup_module.run(terms)

    fail_msg = 'Expected %s, but got %s'

    assert len(ret) == len(terms), fail_msg % (len(terms), len(ret))

    assert ret[0] == '~/.vault_pass.txt', fail_msg % (terms[0], ret[0])
    assert ret[1] == '$HOME/.ansible/tmp', fail_msg % (terms[1], ret[1])

# Generated at 2022-06-23 11:21:43.921065
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Some error"
    orig_exc = "An exception"
    ms = MissingSetting(msg, orig_exc=orig_exc)
    assert ms.message == msg
    assert ms._orig_exc == orig_exc

# Generated at 2022-06-23 11:21:45.141451
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting('Test').message == 'Test'

# Generated at 2022-06-23 11:21:45.757701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:21:57.176843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Fixture: arguments and expected return value
    lookup = LookupModule()
    lookup._display = Display()
    terms = ['DEFAULT_ROLES_PATH']
    expected = ['DEFAULT_ROLES_PATH [u\'roles/\']']

    # Exercise: Call run method
    lookup.set_options(direct={'on_missing': 'error'})
    run_result = lookup.run(terms)
    # Verify: Method run returned expected results
    assert expected == run_result

    # Exercise: Call run method
    lookup.set_options(direct={'on_missing': 'warn'})
    terms = ['DEFAULT_RETURN_ANSIBLE_CONFIG', 'abcxyz123']
    expected = []
    run_result = lookup.run(terms)
    # Verify: Method run returned expected results

# Generated at 2022-06-23 11:21:58.360791
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global module
    module = LookupModule()


# Generated at 2022-06-23 11:22:03.567662
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Oops", orig_exc=None)
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert str(e) == "Error accessing config setting for 'Oops'"
        assert isinstance(e.orig_exc, MissingSetting)

# Generated at 2022-06-23 11:22:06.418672
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msetting = MissingSetting("ERROR: Setting not defined")
    assert isinstance(msetting, AnsibleOptionsError)
    assert msetting.message == "ERROR: Setting not defined"

# Generated at 2022-06-23 11:22:14.018302
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest

    with pytest.raises(AnsibleOptionsError) as excinfo:
        m = MissingSetting('foo')

    assert excinfo.type == AnsibleOptionsError
    assert str(excinfo.value) == 'foo'
    assert excinfo.value.orig_exc is None

    with pytest.raises(AnsibleOptionsError) as excinfo:
        try:
            raise ValueError('oops')
        except ValueError as e:
            raise MissingSetting('foo', orig_exc=e)

    assert excinfo.type == AnsibleOptionsError
    assert str(excinfo.value) == 'foo'
    assert excinfo.value.orig_exc is not None

    # implicit assert: no exception raised
    MissingSetting('foo', orig_exc=None)

# Generated at 2022-06-23 11:22:17.325628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not lookup.confluent
    assert not lookup.panic_mode
    assert not lookup.CONSTANT
    assert not lookup.prompt_loop


# Generated at 2022-06-23 11:22:18.315664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _test = LookupModule()
    assert isinstance(_test, LookupModule)

# Generated at 2022-06-23 11:22:23.236473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    with pytest.raises(AnsibleError):
        lookup.run(["missing"], "error")
        lookup.run(["missing"], "warn")
        lookup.run(["missing"], "skip")
    assert lookup.run(["DEFAULT_ROLES_PATH"], "error")

# Generated at 2022-06-23 11:22:32.338210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dbg = os.environ['ANSIBLE_DEBUG']
    os.environ['ANSIBLE_DEBUG'] = '1'
    class_LookupModule = LookupModule()
    terms = [ 'FORMAT', 'DEFAULT_BECOME_USER', 'JUNKSETTING']
    variables = [ 'ERROR', 'WARN', 'SKIP']
    try:
        for missing in variables:
            for term in terms:
                class_LookupModule.run(terms=[term], variables={}, on_missing=missing)
    except:
        traceback.print_exc()
    os.environ['ANSIBLE_DEBUG'] = dbg

# Generated at 2022-06-23 11:22:34.678338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)


# Generated at 2022-06-23 11:22:43.494429
# Unit test for constructor of class LookupModule
def test_LookupModule():

    global_setting = 'DEFAULT_ROLES_PATH'
    plugin_setting = 'remote_tmp'
    plugin_type = 'shell'
    plugin_name = 'sh'
    missing = 'error'
    lm = LookupModule()
    lm_1 = LookupModule()
    lm_1.set_options(var_options=None, direct=dict(remote_tmp=plugin_setting, plugin_type=plugin_type, plugin_name=plugin_name, on_missing=missing))
    lm.run(terms=[global_setting])
    lm_1.run(terms=[plugin_setting])

# Generated at 2022-06-23 11:22:55.186537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test for missing setting
    lookup.set_options(direct={'on_missing': 'error'})
    assert lookup.run(['non_existing_setting']) == []
    # Test for setting with a custom plugin_name and plugin_type
    assert lookup.run(['remote_tmp'], plugin_name='sh', plugin_type='shell') == ['~/.ansible/tmp']
    # Test with on_missing set to 'warn'
    lookup.set_options(direct={'on_missing': 'warn'})
    assert lookup.run(['non_existing_setting']) == []
    # Test for invalid option for on_missing
    failure = False

# Generated at 2022-06-23 11:22:58.806970
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_args = dict(
        _terms = [''],
        on_missing = 'error',
        plugin_type = 'connection',
        plugin_name = 'ssh'
    )
    lookup = LookupModule()
    lookup.set_options(lookup_args)
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 11:23:06.387565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m.run(terms=['DEFAULT_LOAD_CALLBACK_PLUGINS'], variables={}) == [True]
    assert m.run(terms=['UNKNOWN_SETTING'], variables={'on_missing': 'warn'}) == []
    assert m.run(terms=['UNKNOWN_SETTING_2'], variables={'on_missing': 'skip'}) == []
    assert m.run(terms=['UNKNOWN_SETTING_3'], variables={'on_missing': 'error'}) == []

# Generated at 2022-06-23 11:23:17.560529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.utils.path import unfrackpath
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('config')

    basedir = unfrackpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', os.pardir))
    if os.name == 'nt':
        # os.pardir more likely to be '..'
        if not os.path.isdir(basedir):
            basedir = unfrackpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))


# Generated at 2022-06-23 11:23:29.192916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    module = LookupModule()
    plugin_loader.add_directory('./plugins')

    # Test with one term
    terms = ['DEFAULT_BECOME_USER']
    result = module.run(term=terms, variables={})
    assert result == ['root'], "the first result should be root"

    # Test with two terms
    terms = ['DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_USER']
    result = module.run(term=terms, variables={})
    assert result == ['sudo', 'root'], "the first result should be sudo and the second root"

    # Test without term
    terms = []
    result = module.run(term=terms, variables={})
    assert result == [], "the result should be empty"

   

# Generated at 2022-06-23 11:23:31.295137
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        myLookupModule = LookupModule()
    except Exception as e:
        raise
    else:
        print (myLookupModule)


# Generated at 2022-06-23 11:23:34.865793
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert isinstance(l, LookupBase)
    assert hasattr(l, 'run')


# Generated at 2022-06-23 11:23:45.953540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # raises if term is not string
    config = LookupModule()
    x = (1,2,3)
    try:
        config.run(terms=x)
        assert False
    except Exception as e:
        assert e.__class__ == AnsibleOptionsError
        assert e.message == 'Invalid setting identifier, "1" is not a string, its a <class \'int\'>'
    # raises if missing is not valid
    x = 'testing-class'
    try:
        config.run(terms=['any_string'], on_missing=x)
        assert False
    except Exception as e:
        assert e.__class__ == AnsibleOptionsError
        assert e.message == '"on_missing" must be a string and one of "error", "warn" or "skip", not testing-class'
    # raises

# Generated at 2022-06-23 11:23:56.968493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = dict(
        DEFAULT_REMOTE_TMP='/tmp',
        DEFAULT_REMOTE_PORT=22,
        DEFAULT_REMOTE_USER='root',
    )
    b = dict(a)
    b['DEFAULT_REMOTE_PORT'] = 23
    c = dict(b)
    c['DEFAULT_REMOTE_USER'] = None


# Generated at 2022-06-23 11:24:01.973405
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run(
        ['DEFAULT_ROLES_PATH'],
        {},
        on_missing='skip',
        plugin_type='shell',
        plugin_name='fish',
    ) == [
        "/home/travis/.ansible/roles:/usr/share/ansible/roles:/usr/local/share/ansible/roles"
    ]

# Generated at 2022-06-23 11:24:05.939755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test.set_options(plugin_name='local', plugin_type='connection')
    assert test.run(['local_tmp']) == [C.DEFAULT_LOCAL_TMP]



# Generated at 2022-06-23 11:24:09.043505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves.builtins import str
    from ansible.plugins.loader import lookup_loader
    lookup_loader._create_lookup_plugin(LookupModule)

# Generated at 2022-06-23 11:24:12.304821
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('foo', orig_exc=None)
    assert isinstance(error, AnsibleError)
    assert isinstance(error, Exception)
    assert hasattr(error, 'orig_exc')
    assert str(error) == 'foo'

# Generated at 2022-06-23 11:24:13.141346
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert 'unknown' in str(MissingSetting('unknown setting'))

# Generated at 2022-06-23 11:24:13.914930
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-23 11:24:18.757197
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # constructor with arguments
    error1 = MissingSetting('msg', 'orig_exc')
    assert error1.msg == 'msg'
    assert error1.orig_exc == 'orig_exc'

    # constructor with no arguments
    error2 = MissingSetting()
    assert error2.msg == 'An unspecified error occurred'
    assert error2.orig_exc == None

# Generated at 2022-06-23 11:24:22.318713
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting('MissingSetting message')
    obj.orig_exc = RuntimeError
    assert str(obj) == 'MissingSetting message'
    assert obj.orig_exc == RuntimeError

# Generated at 2022-06-23 11:24:29.777543
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up look up module
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)

    # test config variables
    # test config variable ansible_winrm_timeout
    result = lookup_module.run(terms=['ansible_winrm_timeout'])
    assert len(result) == 1
    assert result[0] == C.DEFAULT_WINRM_TIMEOUT

    # test config variable ansible_winrm_cert_validation
    result = lookup_module.run(terms=['ansible_winrm_cert_validation'])
    assert len(result) == 1
    assert result[0] == C.DEFAULT_WINRM_CERT_VALIDATION

    # test config variable ansible_winrm_cusom_endpoint
    result = lookup

# Generated at 2022-06-23 11:24:40.488666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    expected = [2]
    mock_utils = Mock()
    mock_utils.constants.C.DEFAULT_TIMEOUT = 2
    mock_utils.constants.C.ZIP_MODULE = 'zipfile'
    lookup_module = LookupModule()
    lookup_module.set_module_utils(mock_utils)

    # test non global config, zipfile
    result = lookup_module.run(['zipfile'])
    assert result == ['zipfile']
    # test global config, DEFAULT_TIMEOUT
    result = lookup_module.run(['DEFAULT_TIMEOUT'])
    assert result == expected
    # test fail condition
    mock_utils.constants.C.some_junk = None
    result = lookup_module.run(['some_junk'])
    assert result == []

    #

# Generated at 2022-06-23 11:24:41.855899
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error_msg = 'error_msg'
    MissingSetting(error_msg)

# Generated at 2022-06-23 11:24:52.020616
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms = 'DEFAULT_BECOME_USER'
    ret = module.run(terms=terms, variables='', on_missing='skip')
    assert len(ret) == 1
    assert ret[0] == 'root'

    ret = module.run(terms=terms, variables='', on_missing='warn')
    assert len(ret) == 1
    assert ret[0] == 'root'

    terms = 'DEFAULT_ROLES_PATH'
    ret = module.run(terms=terms, variables='', on_missing='skip')
    assert len(ret) == 1
    assert ret[0] == ['/usr/share/ansible/roles', '/usr/share/ansible/plugins/modules/roles']


# Generated at 2022-06-23 11:24:53.689776
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """LookupModule - constructor test"""
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-23 11:25:04.749376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModuleMock:
        def set_options(self, var_options=None, direct=None):
            return
        def get_option(self, option):
            if option == 'on_missing':
                return "error"
            elif option == 'plugin_type':
                return None
            elif option == 'plugin_name':
                return None

        def _display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            print(msg)

    lookup = LookupModuleMock()
    terms = ["DEFAULT_BECOME_PASS", "DEFAULT_ROLES_PATH", "RETRY_FILES_SAVE_PATH", "COLOR_OK", "COLOR_CHANGED", "COLOR_SKIP"]

    # For each term, check if the

# Generated at 2022-06-23 11:25:10.347850
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        # The following line should raise an exception
        raise MissingSetting(msg="Error message")
    # Catch the exception
    except AnsibleOptionsError as e:
        # Test for the message in the exception
        assert e.message == "Error message"
    # If the test is successful, "AssertionError" is expected
    # Otherwise the error that has occurred is printed

# Generated at 2022-06-23 11:25:12.585510
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_exception = MissingSetting("AnsibleOptionsError: Invalid setting identifier")
    assert test_exception.message == "AnsibleOptionsError: Invalid setting identifier"

# Generated at 2022-06-23 11:25:13.991141
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import pytest

    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting('No value')

# Generated at 2022-06-23 11:25:16.507663
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except AnsibleOptionsError as e:
        assert(str(e) == "test")

# Generated at 2022-06-23 11:25:27.044764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up objects needed by method under test
    terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']
    plugin_type = 'connection'
    plugin_name = 'network_cli'
    on_missing = 'error'
    variables = None
    lookup_base_instance = LookupModule()
    lookup_base_instance.set_options(var_options=variables, direct={'plugin_type':plugin_type, 'plugin_name':plugin_name, 'on_missing':on_missing})
    # Test when setting identifier is a string
    assert lookup_base_instance.run(terms) == ['/etc/ansible/roles:/usr/share/ansible/roles', 'root']
    # Test when setting identifier is not a string

# Generated at 2022-06-23 11:25:30.448008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_cls = LookupModule()

    assert lookup_cls.run(terms=['invalid'], variables={}, on_missing='error') == []



# Generated at 2022-06-23 11:25:31.471255
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_obj = LookupModule()

# Generated at 2022-06-23 11:25:32.499232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run()

# Generated at 2022-06-23 11:25:38.086875
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["C.DEFAULT_BECOME_USER"]
    variables = {}
    module_name = "config"
    test_class_instance = LookupModule()
    test_class_instance.set_options(
        var_options=variables,
        direct={}
    )

    result = test_class_instance.run(terms, variables)
    assert result == [C.DEFAULT_BECOME_USER]

# Generated at 2022-06-23 11:25:42.327978
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    class E(AnsibleOptionsError):
        pass

    msg = "Error Message"
    orig_exc = E("Original Message")
    setting = MissingSetting(msg, orig_exc=orig_exc)
    assert setting.orig_exc == orig_exc
    assert setting.message == msg


test_MissingSetting()

# Generated at 2022-06-23 11:25:45.251203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    Module = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    Module.run(terms)

# Generated at 2022-06-23 11:25:48.950595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options({})
    assert lookup.get_option('var_options') is None
    assert lookup.get_option('direct') is {}


# Generated at 2022-06-23 11:25:50.115805
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 11:25:52.876249
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule(loader=None, templar=None, variables=None)
    except Exception:
        assert False and "Failed to create instance of LookupModule"

# Generated at 2022-06-23 11:25:55.192612
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("missing")
    assert e.message == "missing"
    assert e.orig_exc is None

# Generated at 2022-06-23 11:25:58.127501
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('This is a test error message', orig_exc=Exception())
    except Exception as e:
        assert str(e) == 'This is a test error message'

# Generated at 2022-06-23 11:25:59.095797
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # assert no errors
    MissingSetting("test")

# Generated at 2022-06-23 11:26:01.755042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not lookup.get_option('plugin_name')
    assert not lookup.get_option('plugin_type')
    assert lookup.get_option('on_missing') == 'error'

# Generated at 2022-06-23 11:26:02.724177
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _ = LookupModule()


# Generated at 2022-06-23 11:26:06.626145
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_options = {
        'missing': 'warn',
        'plugin_type': 'shell',
        'plugin_name': 'sh'
    }
    lookup_instance = LookupModule()
    lookup_instance.set_options(lookup_options)

    assert lookup_options == lookup_instance.get_options()

# Generated at 2022-06-23 11:26:14.510397
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class TestException(Exception, AnsibleBaseYAMLObject):
        def __init__(self):
            self._data = dict()
            self._data['msg'] = 'test msg'
            self._data['orig_exc'] = 'test orig_exc'

    test_exception = TestException()
    test_MissingSetting = MissingSetting('test msg', orig_exc=test_exception)
    assert test_MissingSetting.message == 'test msg'
    assert test_MissingSetting.orig_exc._data['msg'] == 'test msg'

# Generated at 2022-06-23 11:26:16.686456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for testing the constructor
    """
    assert LookupModule(loader=None, templar=None, variables=None)

# Generated at 2022-06-23 11:26:20.067981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_params = dict()
    assert LookupModule in LookupModule.__subclasses__()
    obj = LookupModule(loader=None, templar=None, shared_loader_obj=None, **module_params)
    assert obj is not None

# Generated at 2022-06-23 11:26:23.131399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_params = None
    lookup_obj = LookupModule(loader=None, runner=None, templar=None, **lookup_params)
    assert lookup_obj is not None , \
        "test_LookupModule: object constructor test failed"

# Generated at 2022-06-23 11:26:32.672275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 11:26:36.191468
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Testcase for the MissingSetting exception defined above."""
    msg = 'Sample message'
    e = MissingSetting(msg)
    assert e.message == msg, 'Should have the same message.'

# Generated at 2022-06-23 11:26:38.165794
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:26:43.025947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    options = dict(
        var_options=None,
        direct=dict(
            on_missing='error',
            plugin_name='ssh',
            plugin_type='connection'
        )
    )
    terms = ['remote_user', 'port']
    variables = None
    lookup_module.run(terms, variables, **options)

# Generated at 2022-06-23 11:26:52.753547
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_native
    from ansible.utils.sentinel import Sentinel

    result = Sentinel
    try:
        result = _get_global_config('xyzzy')
    except MissingSetting as e:
        assert e.args[0] == "object has no attribute 'xyzzy'"
    else:
        raise Exception("Expected MissingSetting exception, got '%s'" % to_native(result))

    result = Sentinel
    try:
        result = _get_plugin_config('nonexistent', 'connection', 'xyzzy', dict())
    except MissingSetting as e:
        assert e.args[0].startswith('Unable to load connection plugin "nonexistent"')

# Generated at 2022-06-23 11:26:54.464278
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()  # pylint: disable=invalid-name

# Generated at 2022-06-23 11:27:05.543613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for method run, in that case config for ping plugin
    lu = LookupModule()

    plugin_name = 'ping'
    plugin_type = 'connection'
    lookup_term = 'timeout'
    lookup_result = lu.run(terms=[lookup_term], plugin_name=plugin_name, plugin_type=plugin_type)
    assert lookup_result == [10]

    # test for method run with missing parameter
    plugin_name = 'ping'
    plugin_type = 'connection'
    lookup_term = 'timeout'
    missing = 'error'
    lookup_result = lu.run(terms=[lookup_term], plugin_name=plugin_name, plugin_type=plugin_type, on_missing=missing)
    assert lookup_result == [10]

    plugin_name = 'ping'
   

# Generated at 2022-06-23 11:27:13.543306
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader

    # Test LookupModule constructor
    lookup_plugin = lookup_loader.get('config')

    # Test LookupModule constructor with bad args
    incorrect_args = {'plugin_name': 'test'}
    incorrect_args2 = {'plugin_type': 'test'}
    lookup_plugin_incorrect_arg = lookup_loader.get('config', **incorrect_args)
    lookup_plugin_incorrect_arg_2 = lookup_loader.get('config', **incorrect_args2)

# Generated at 2022-06-23 11:27:25.192071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test for config value which is not in config file
    lookup_module.set_options(direct={'on_missing': 'error'})
    # test for config value which is not in config file
    try:
        lookup_module.run(['NOT_A_CONFIG_VALUE'])
    except AnsibleLookupError as ae:
        assert isinstance(ae, AnsibleLookupError)

    # test for config value which is not in config file
    lookup_module.set_options(direct={'on_missing': 'warn'})
    assert not lookup_module.run(['NOT_A_CONFIG_VALUE'])

    # test for config value which is not in config file
    lookup_module.set_options(direct={'on_missing': 'skip'})
    assert not lookup

# Generated at 2022-06-23 11:27:32.977365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case for error checks when on_missing is invalid
    LookupModule.run(None,Sentinel,on_missing='error')
    LookupModule.run(None,Sentinel,on_missing='warn')
    LookupModule.run(None,Sentinel,on_missing='skip')

    # Test case for error checks when on_missing is invalid
    try:
        LookupModule.run(None,Sentinel,on_missing='error1')
        assert False
    except AnsibleOptionsError:
        pass

    try:
        LookupModule.run(None,Sentinel,on_missing=True)
        assert False
    except AnsibleOptionsError:
        pass

    # Test case for error checks when plugin_type and plugin_name are not both provided

# Generated at 2022-06-23 11:27:35.417442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_module = LookupModule()
    assert isinstance(test_lookup_module, LookupModule)

# Generated at 2022-06-23 11:27:42.359022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixtures = {
        'plugin_name': "local",
        'plugin_type': "connection",
        'terms': ["", "remote_tmp", "local_tmp"],
        'config': "remote_tmp",
    }

    result = LookupModule().run(fixtures['terms'], variables=None, plugin_name=fixtures['plugin_name'], plugin_type=fixtures['plugin_type'])
    assert result == ['/tmp/.ansible-tmp']

# Generated at 2022-06-23 11:27:46.948496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    lu.set_loader(None)
    lu.set_environment(None)
    lu.set_options(var_options={}, direct={})
    lu.run(['DEFAULT_BECOME_METHOD'])
    lu.run(['DEFAULT_BECOME_METHOD'], {}, {}, None)
    lu.run(['DEFAULT_BECOME_METHOD'], {}, {}, 'unknown')

# Generated at 2022-06-23 11:27:56.038937
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class AnsibleOptionsTest(object):
        def __init__(self, variable=None, direct=None):
            self.variable = variable
            self.direct = direct
        def get_option(self, option):
            return self.direct[option]

    lo = LookupModule()
    lo.set_options = LookupBase.set_options
    lo.get_option = AnsibleOptionsTest.get_option
    lo.run(['remote_user'], variables='test', on_missing='test', plugin_type='test', plugin_name='test')
    # No exception
    assert True

# Generated at 2022-06-23 11:27:56.655629
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:28:05.951570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    ptype = 'connection'
    pname = 'ssh'
    missing = 'error'
    variables = None
    lu = LookupModule()

    terms = ['DEFAULT_BECOME_USER']
    ptype = 'connection'
    pname = 'ssh'
    missing = 'error'
    variables = None
    lu = LookupModule()
    result = lu.run(terms, variables, on_missing = missing, plugin_type = ptype, plugin_name = pname)
    assert isinstance(result, list)
    assert result[0] == 'root'
    assert len(result) == 1


# Generated at 2022-06-23 11:28:14.323099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['Yes', 'No']
    variables = {'ansible_check_mode': 'True'}
    pname = 'local'
    ptype = 'shell'
    missing = 'error'
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, plugin_type=ptype, plugin_name=pname, on_missing=missing)
    print('---')
    print(result)
    print('---')

if __name__ == '__main__':
    test_LookupModule_run()