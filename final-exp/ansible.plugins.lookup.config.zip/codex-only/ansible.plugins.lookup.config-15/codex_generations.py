

# Generated at 2022-06-23 11:18:09.882915
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_module = LookupModule()
  assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:18:11.905355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule(None, None, None, None, None)

# Generated at 2022-06-23 11:18:14.003327
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Invalid setting identifier'
    err = MissingSetting(msg)
    assert str(err) == msg

# Generated at 2022-06-23 11:18:17.212950
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('problem with multiline text')
    assert str(e) == 'Ansible lookup plugin option "on_missing" "error" is invalid, problem with multiline text'

# Generated at 2022-06-23 11:18:19.898627
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    err_msg_attrs = {
        'msg': 'Unable to find setting %s',
        'orig_exc': AttributeError
    }
    missing_setting = MissingSetting('Unable to find setting %s', AttributeError)
    for attr_name, attr_val in err_msg_attrs.items():
        assert missing_setting.__getattribute__(attr_name) == attr_val

# Generated at 2022-06-23 11:18:21.274378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:18:23.417067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # AnsibleOptionsError can't be unit tested without calling
    # the lookup module itself
    assert True

# Generated at 2022-06-23 11:18:26.877908
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    msg = "No config file found"
    e = Exception(msg)
    m = MissingSetting(msg, orig_exc=e)
    assert m.message == msg
    assert str(m) == msg

    m = MissingSetting(msg)
    assert m.message == msg
    assert str(m) == msg

# Generated at 2022-06-23 11:18:35.803473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

    terms = ['remote_user', 'remote_tmp']
    variables = {}
    kwargs = {}
    kwargs['direct'] = {}
    kwargs['direct']['plugin_type'] = 'connection'
    kwargs['direct']['plugin_name'] = 'netconf'

    fc = LookupModule()
    gc = LookupModule()
    fc.set_options(var_options=variables, direct=kwargs)
    fc.get_option = MagicMock(return_value=kwargs['direct']['plugin_name'])
    fc.run(terms, variables, **kwargs)
    assert fc._display.warning.called


# Generated at 2022-06-23 11:18:37.626961
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader

    lookup_cls = lookup_loader.get('config')
    assert lookup_cls is not None

# Generated at 2022-06-23 11:18:44.398068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    from ansible.module_utils.six import binary_type

    from units.mock.loader import DictDataLoader

    basedir = '%s/test_lookup_plugin_ansible_config/' % os.getcwd()
    loader = DictDataLoader({basedir: {'hosts': b'localhost'}})

    inventory = InventoryManager(loader=loader, sources=basedir + 'hosts')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 11:18:56.291282
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    permitted_values_msg = "Valid values are ['error', 'warn', 'skip']"
    try:
        raise MissingSetting('string')
    except MissingSetting as e:
        assert to_native(e) == 'string'
    try:
        raise MissingSetting('string', 'setting')
    except MissingSetting as e:
        assert to_native(e) == 'string'
        assert e.setting == 'setting'
    try:
        raise MissingSetting('string', 'setting', 'valid', 'got', 'unknown')
    except MissingSetting as e:
        assert to_native(e) == 'string'
        assert e.setting == 'setting'
        assert e.valid == 'valid'
        assert e.got == 'got'
        assert to_native(e.valid_options_msg) == permitted_values_msg

# Generated at 2022-06-23 11:19:02.735124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible import context
    from ansible.plugins.loader import become_loader

    result = []
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']

    for term in terms:
        result = lookup_loader.get('config').run(terms=term, variables=context.CLIARGS._get_vars(), wantlist=True)

    assert result == [C.DEFAULT_BECOME_USER, C.DEFAULT_ROLES_PATH]

    result = []
    terms = ['DEFAULT_REMOTE_TMP', 'DEFAULT_MODULE_NAME']

# Generated at 2022-06-23 11:19:06.096931
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting(msg='fake msg', orig_exc='fake orig_exc')
    assert e.msg == 'fake msg'
    assert e.orig_exc == 'fake orig_exc'

# Generated at 2022-06-23 11:19:15.802684
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeVars:
        fake1 = 'fake1'

    # Getting a setting that is not defined in C config
    test_instance = LookupModule()
    terms_1 = ['UNKNOWN']
    variables_1 = FakeVars()
    on_missing_1 = 'error'
    kwargs_1 = {}
    try:
        result_1 = test_instance.run(terms_1, variables_1, on_missing=on_missing_1, **kwargs_1)
    except AnsibleLookupError:
        pass
    else:
        raise Exception("The AnsibleLookupError was not raised")

    # Getting a setting that is defined in C config
    kwargs_2 = {}
    terms_2 = ['DEFAULT_STDOUT_CALLBACK']
    variables_2 = FakeVars()
    on

# Generated at 2022-06-23 11:19:23.260145
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import sys
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import StringIO

    def to_native(obj, encoding='utf-8'):
        if isinstance(obj, bytes):
            obj = obj.decode(encoding)
        return obj

    try:
        raise AnsibleOptionsError('TestError')
    except AnsibleOptionsError:
        exc_type, exc_value, exc_traceback = sys.exc_info()
    try:
        raise AnsibleOptionsError('TestError')
    except AnsibleOptionsError as e:
        test_exc = type(e)

    # Create the exception

# Generated at 2022-06-23 11:19:25.010774
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    x = MissingSetting('message')
    assert x.message == 'message'
    assert x.orig_exc is None

# Generated at 2022-06-23 11:19:26.307593
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting()

# Generated at 2022-06-23 11:19:27.245376
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: Implement this
    assert True == False

# Generated at 2022-06-23 11:19:36.685732
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    variable = 'variable'
    variable2 = 'variable2'
    val = Sentinel()
    val2 = Sentinel()
    msg = 'msg'
    msg2 = 'msg2'
    orig_exc = Sentinel()
    orig_exc2 = Sentinel()
    return_val = MissingSetting(variable)
    return_val2 = MissingSetting(variable2, val2)
    return_val3 = MissingSetting(variable, val)
    return_val4 = MissingSetting(variable, val, msg2, orig_exc2)
    return_val5 = MissingSetting(variable, val, msg)

    assert return_val.message == variable
    assert return_val.has_option('variable') is False
    assert return_val2.message == variable2
    assert return_val2.has_option('variable2') is True
    assert return_

# Generated at 2022-06-23 11:19:42.179933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test all branches
    # plugin_type and plugin_name provided, setting found, no variables, error on missing setting
    l = LookupModule()
    assert l.run(['remote_tmp', 'remote_user'], plugin_type='shell', plugin_name='sh', on_missing='error') == ['$HOME/.ansible/tmp', '$USER']

    # plugin_type and plugin_name provided, setting found, no variables, no error on missing setting
    l = LookupModule()
    assert l.run(['remote_tmp', 'invalid_setting'], plugin_type='shell', plugin_name='sh', on_missing='warn') == ['$HOME/.ansible/tmp']

    # plugin_type and plugin_name provided, setting found, no variables, skip on missing setting
    l = LookupModule()
    assert l.run

# Generated at 2022-06-23 11:19:51.456465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global _get_global_config
    global _get_plugin_config
    global plugin_loader
    ret = []
    config = 'DEFAULT_BECOME_USER'
    global constants
    global original_C

    # Create a class object
    obj_run = LookupModule()

    # Create a list of terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'RETRY_FILES_SAVE_PATH', 'COLOR_OK']

    # Create a dictionary of options
    options = {'on_missing': 'error', 'plugin_type': '', 'plugin_name': '', 'var_options': None, 'direct': {}}

    # Create an object of missing setting error
    missing_setting_error = 'Unable to find setting DEFAULT_BECOME_USER'



# Generated at 2022-06-23 11:19:59.188613
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ex1 = None
    ex2 = None
    try:
        raise LookupModule.MissingSetting('Test')
    except LookupModule.MissingSetting as e:
        ex1 = e
    try:
        raise LookupModule.MissingSetting('Test', orig_exc=ex1)
    except LookupModule.MissingSetting as e:
        ex2 = e
    assert ex2 is not None
    assert str(ex2) == 'Test'
    assert _exception_info(ex2) == 'original exception: Test'

    assert ex1 is not None
    assert str(ex1) == 'Test'
    assert _exception_info(ex1) == ''

# Generated at 2022-06-23 11:20:01.860847
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        if str(e) != "test":
            raise AssertionError("MissingSetting constructor doesn't work properly")

# Generated at 2022-06-23 11:20:14.052897
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestPluginClass(object):
        _load_name = 'mock'

    class TestPluginLoader(object):
        def get(self, name, *args, **kwargs):
            return TestPluginClass()

    import ansible.plugins.loader
    saved_loaders = {}

    # Save the original values
    for attr in ('become_loader', 'cache_loader', 'callback_loader', 'cliconf_loader', 'connection_loader', 'httpapi_loader',
                 'inventory_loader', 'lookup_loader', 'netconf_loader', 'shell_loader', 'vars_loader'):
        saved_loaders[attr] = getattr(ansible.plugins.loader, attr)

    # Mocked loaders
    setattr(ansible.plugins.loader, 'become_loader', TestPluginLoader())


# Generated at 2022-06-23 11:20:21.844525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    mock_loader = Mock()
    mock_loader.get = MagicMock(return_value=None)
    plugin_loader.shell_loader.get = mock_loader.get
    lookup_plugin = LookupModule()
    # Asserts
    assert lookup_plugin.run([1,2]) is None

    # Test 2
    # Asserts
    assert lookup_plugin.run(["DEFAULT_ROLES_PATH"]) is None

    # Test 3
    mock_loader = Mock()
    mock_loader.get = MagicMock(return_value="")
    plugin_loader.shell_loader.get = mock_loader.get
    lookup_plugin = LookupModule()
    # Asserts
    assert lookup_plugin.run(["DEFAULT_ROLES_PATH"]) is None

# Generated at 2022-06-23 11:20:25.111637
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'Setting not found'
    orig_exc = Exception()

    ms = MissingSetting(msg, orig_exc=orig_exc)

    assert isinstance(ms, AnsibleOptionsError)
    assert ms.msg == msg



# Generated at 2022-06-23 11:20:27.075509
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    print(l)
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:20:37.766397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    # Testing run()
    assert lm.run([]) == []
    assert lm.run(['CONFIG_FILE', 'ANSIBLE_CONFIG'], variables={'ANSIBLE_CONFIG':'./test/ansible.cfg'}) == ['./test/ansible.cfg', './test/ansible.cfg']
    # Since ANSIBLE_CONFIG has been set in env, the first time will give ./test/ansible.cfg, the 2nd time will give ./test/ansible.cfg
    # Otherwise the value of 'CONFIG_FILE' will be given
    assert lm.run(['CONFIG_FILE'], variables={'ANSIBLE_CONFIG':'./test/ansible.cfg'}) in [['./test/ansible.cfg'], []]

    # Testing __init__

# Generated at 2022-06-23 11:20:38.228947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) is type

# Generated at 2022-06-23 11:20:49.737940
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 11:20:52.917754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    result = lookup_instance.run(['DEFAULT_ROLES_PATH'])
    assert result[0] == C.config.DEFAULT_ROLES_PATH

# Generated at 2022-06-23 11:20:55.980358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, 'This test needs to be filled out'


# Generated at 2022-06-23 11:21:00.109623
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Invalid value")
    except MissingSetting as e:
        assert e.message == "Invalid value", "The exception message was not set correctly"
        assert e.orig_exc is None, "The original exception was not set correctly"

# Generated at 2022-06-23 11:21:02.409951
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test")
    except MissingSetting as e:
        assert e.message == "test"

# Generated at 2022-06-23 11:21:02.996930
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:21:05.044424
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup
    assert lookup.CONSTANTS_LOOKUP_PLUGIN_CLASS
    assert lookup.CONSTANTS_LOOKUP_PLUGIN_NAME

# Generated at 2022-06-23 11:21:13.884137
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "dummy error"
    e = Exception(msg)
    missing_setting = MissingSetting(msg, orig_exc=e)
    assert missing_setting.msg == msg
    assert missing_setting.orig_exc == e
    assert str(missing_setting) == msg
    # Test Error Message for all lookup types
    assert 'must be a string' in str(AnsibleOptionsError('dummy error'))
    assert 'must be one of' in str(AnsibleOptionsError('dummy error'))
    assert 'is not a string' in str(AnsibleOptionsError('dummy error'))
    assert 'not found in configured module search path' in str(AnsibleOptionsError('dummy error'))
    assert 'invalid lookup parameter was given,' in str(AnsibleOptionsError('dummy error'))

# Generated at 2022-06-23 11:21:16.328722
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        missing = MissingSetting('problem', AnsibleError('original problem'))
    except Exception as e:
        # The underlying exception is not missing
        assert e.orig_exc.message == 'original problem'
        # The message is the problem
        assert e.message == 'problem'

# Generated at 2022-06-23 11:21:28.199309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    mock_options = {'on_missing': 'skip', 'plugin_type': None, 'plugin_name': None}
    mock_variables = {u'playbook_dir': u'/home/user/ansible/playbooks'}
    mock_qs = {'foo': u'bar', 'one': 1, 'twelve': 12, 'var': u'/home/user/ansible/playbooks'}
    ans_constants_cache = {'CACHE_PLUGIN': u'jsonfile', 'CACHE_PLUGIN_CONNECTION': u'', 'CACHE_PLUGIN_PREFIX': None}
    C.__dict__.update(ans_constants_cache)


# Generated at 2022-06-23 11:21:37.921040
# Unit test for constructor of class LookupModule
def test_LookupModule():

    def in_get_config_value(key, plugin_type, plugin_name, variables, config_file=None, section=None):
        return key + plugin_type + plugin_name + config_file + section

    class fake_plugins():

        class lookup_loader():

            @staticmethod
            def get(name, class_only=False):
                return fake_plugins()

            @staticmethod
            def list():
                return None


        class become_loader():

            @staticmethod
            def get(name, class_only=False):
                return fake_plugins()

            @staticmethod
            def list():
                return None

        class cache_loader():

            @staticmethod
            def get(name, class_only=False):
                return fake_plugins()

            @staticmethod
            def list():
                return None


# Generated at 2022-06-23 11:21:44.726920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()
    # The terms to lookup
    terms = ["DEFAULT_ROLES_PATH", "DEFAULT_GATHERING_STRATEGY"]
    # The kwargs
    kwargs = {}
    # Return the lookup result
    return lookup_module.run(terms, **kwargs)

# Generated at 2022-06-23 11:21:48.629762
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('message')

    assert exc is not None
    assert exc.args == ('message',)
    assert exc.kwargs == {}
    assert exc.message == 'message'
    assert exc.orig_exc is None



# Generated at 2022-06-23 11:21:59.102961
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Dummy terms
    terms = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
        'RETRY_FILES_SAVE_PATH',
        'COLOR_OK',
        'COLOR_CHANGED',
        'COLOR_SKIP',
        'config_in_var',
        'foo',
        '", plugin_type="connection", plugin_name="ssh',
        '", plugin_type="shell", plugin_name="sh',
    ]
    # Sample case

# Generated at 2022-06-23 11:22:03.326553
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    with pytest.raises(AnsibleOptionsError) as excinfo:
        raise MissingSetting("msg")
    assert str(excinfo.value) == 'msg'

# Generated at 2022-06-23 11:22:10.759485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    # simple tests to verify if it uses the right config setting
    assert lu.run(["ANSIBLE_CACHE_PLUGIN"], {}) == [C.ANSIBLE_CACHE_PLUGIN]
    assert lu.run(["ANSIBLE_CACHE_PLUGIN_CONNECTION"], {}) == [C.ANSIBLE_CACHE_PLUGIN_CONNECTION]
    # now test the on_missing setting
    assert lu.run(["ALIBALA"], {}, on_missing="warn") == []
    assert lu.run(["ALIBALA"], {}, on_missing="skip") == []
    # this test will fail because of not finding a setting

# Generated at 2022-06-23 11:22:15.631474
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    for args in [ (), [], {}, None, 42, 'foo' ]:
        try:
            ms = MissingSetting(*args)
            raise AssertionError('MissingSetting with args "%s" did not raise an exception' % (args,))
        except TypeError:
            # this is the behavior we expect, so continue
            pass

# Generated at 2022-06-23 11:22:23.545628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Ansible lookup moduel unit test method run """

    lookup_moduel_inst = LookupModule()

    # test pname and ptype
    terms = ["basic_sh_plugin_setting","basic_sh_plugin_setting_1","basic_sh_plugin_setting_2","basic_sh_plugin_setting_3"]
    plugin_type = "shell"
    plugin_name = "Basic"
    on_missing = "warn"
    result = lookup_moduel_inst.run(terms, plugin_type=plugin_type, plugin_name=plugin_name, on_missing=on_missing)

    assert result[0] == "/bin/sh"
    assert result[1] == "basic_sh_plugin_setting_1"
    assert result[3] == 456

# Generated at 2022-06-23 11:22:34.195918
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class mock_config_class(object):
        COLOR_OK = True
        COLOR_CHANGED = True
        COLOR_SKIP = True

    C = mock_config_class()

    class mock_variables(object):
        # used to create vars
        __getitem__ = lambda self, key: None  # noqa

    class mock_display_class(object):
        # used to mock display module
        warning = lambda self, msg: None  # noqa

    class mock_sentinel_class(object):
        # this is to create the sentinel object
        # since the sentinel object does not have an __init__ method
        pass


# Generated at 2022-06-23 11:22:44.786101
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Check correct exception is raised when required attributes are missing
    with pytest.raises(TypeError) as excinfo:
        MissingSetting()
    assert 'missing 3 required positional arguments' in str(excinfo)
    # Check correct exception is raised when given more parameters than required
    with pytest.raises(TypeError) as excinfo:
        MissingSetting('test', 'test', 'test', 'test')
    assert 'takes 3 positional arguments but 4 were given' in str(excinfo)
    # Check MissingSetting class correctly instantiates
    test_ms = MissingSetting('test1', 'test2', 'test3')
    assert 'test1' == test_ms.message
    assert 'test2' == test_ms.config_key
    assert 'test3' == test_ms.orig_exc

# Generated at 2022-06-23 11:22:47.479261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert hasattr(l, 'run')
    assert callable(l.run)

# Generated at 2022-06-23 11:22:57.881904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = 'ansible.plugins.lookup.config'
    ptype = 'inventory'
    pname = 'yaml'
    term = 'inventory_ignore_extensions'
    missing = 'error'
    terms = [term]
    setattr(C, term, 'test')
    ret = []
    try:
        result = _get_plugin_config(pname, ptype, term, {})
    except MissingSetting as e:
        if missing == 'error':
            raise AnsibleLookupError('Unable to find setting %s' % term, orig_exc=e)
        elif missing == 'warn':
            self._display.warning('Skipping, did not find setting %s' % term)
        elif missing == 'skip':
            pass  # this is not needed, but added to have all 3 options stated

# Generated at 2022-06-23 11:22:59.762095
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:23:10.045190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleOptionsError):
        LookupModule("config").run("DEFAULT_ROLES_PATH", plugin_name="ssh")
    with pytest.raises(AnsibleOptionsError):
        LookupModule("config").run("DEFAULT_ROLES_PATH", plugin_type="ssh")
    with pytest.raises(AnsibleOptionsError):
        LookupModule("config").run("DEFAULT_ROLES_PATH", plugin_type="connection", plugin_name="")
    with pytest.raises(AnsibleOptionsError):
        LookupModule("config").run("DEFAULT_ROLES_PATH", plugin_type="connection", plugin_name=None)

# Generated at 2022-06-23 11:23:19.415992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   MODULE = "lookup_plugins.config_plugin.LookupModule"
   MOCK_OPTIONS = {'plugin_name': 'ssh', 'plugin_type': 'connection'}
   MOCK_SETTINGS = {
     'DEFAULT_ROLES_PATH': [
            '/etc/ansible/roles',
            '/usr/share/ansible/roles',
            '~/.ansible/roles'
        ]
   }
   MOCK_TERMS = ['DEFAULT_ROLES_PATH']

   C.get_config_value = lambda x, **kwargs: MOCK_SETTINGS[x]

   lookup = __import__(MODULE, fromlist=['LookupModule'])
   module = lookup.LookupModule()
   module._display = object()

# Generated at 2022-06-23 11:23:27.206201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import merge_hash

    vlt = VaultLib(['--vault-id', 'dummy@prompt', '--vault-password-file=vault_password'])

    terms = ['DEFAULT_ROLES_PATH']
    kwargs = dict(wantlist=True)

    # Act
    result = LookupModule().run(terms, **kwargs)

    # Assert
    assert result


# Generated at 2022-06-23 11:23:32.293349
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting()
    assert missing_setting.message == 'An unknown error occurred'
    assert missing_setting.orig_exc is None

    msg = 'This is a message'
    orig_exc = 'Exception'
    missing_setting = MissingSetting(msg, orig_exc)
    assert missing_setting.message == msg
    assert missing_setting.orig_exc == orig_exc

# Generated at 2022-06-23 11:23:44.549459
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

    # construct LookupModule instance

# Generated at 2022-06-23 11:23:56.271027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # basic test
    args = [
        'remote_user',
        'port'
    ]
    out = lookup.run(args, variables={
        'ansible_connection': 'netconf',
        'ansible_port': '22',
        'ansible_user': 'root',
        'ansible_user_pass': 'password',
        'ansible_network_os': 'iosxe',
    })
    assert out == ['root', 22]

    # missing setting, which is skipped
    args = [
        'foo'
    ]

# Generated at 2022-06-23 11:24:04.564540
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    plugin_loader.plugins.__setitem__('my_plug', {'my_hook': MockPlugin('my_plug', 'my_hook')})
    terms = ["my_hook", "my_plug"]
    lookup_plugin = LookupModule()
    try:
        ret = lookup_plugin.run(terms, None, plugin_type='my_plug', plugin_name='my_hook', on_missing=MissingSetting("%s"))
    except AnsibleError as e:
        assert 'did not define' in e.args[0]
        assert 'my_hook' in e.args[0]
        assert 'my_plug' not in e.args[0]
        assert 'my_hook' in e.args[1].name
        assert 'my_hook' in e.args[1].orig_exc.args[0]
       

# Generated at 2022-06-23 11:24:06.147209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test direct call
    LookupModule().run(['ping_timeout'])

# Generated at 2022-06-23 11:24:16.210058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    my_terms = ['DEFAULT_BECOME_METHOD', 'GARBAGE_VALUE']
    my_cliconf_plugin_name = 'cliconf'
    my_plugin_type = 'cliconf'

    my_cliconf_plugin_loader = plugin_loader.cliconf_loader
    my_cliconf_plugin = my_cliconf_plugin_loader.get(my_cliconf_plugin_name, class_only=True)

    my_loader = DataLoader()
    my_var_manager = VariableManager()

    my_lookup = LookupModule()

    with pytest.raises(AnsibleOptionsError) as exc_info:
        my_lookup.run

# Generated at 2022-06-23 11:24:19.915391
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    message = "Unable to find setting 'UNKNOWN'"
    ex = AnsibleLookupError(message, orig_exc=None)
    assert MissingSetting(message, orig_exc=ex).__str__() == message

# Generated at 2022-06-23 11:24:22.635366
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_module = LookupModule()
    assert isinstance(my_lookup_module, LookupModule)

# Generated at 2022-06-23 11:24:25.004539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm


if __name__ == '__main__':
    # Unit test
    print(test_LookupModule())

# Generated at 2022-06-23 11:24:33.809331
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.config import LookupModule as _LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import os

    # Ansible Plugin Manager finds only default C.DEFAULT_ROLES_PATH defined in constants.py
    cur_dir = os.getcwd()
    C.DEFAULT_ROLES_PATH = os.path.join

# Generated at 2022-06-23 11:24:35.576623
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test exception message')
    except MissingSetting as e:
        assert e.message == 'test exception message'

# Generated at 2022-06-23 11:24:42.393123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.constants as C
    import ansible.plugins.loader as plugin_loader
    C.DEFAULT_ROLES_PATH = 'roles/path'
    C.ANSIBLE_RETRY_FILES_SAVE_PATH = 'retry/path'
    C.ANSIBLE_NOCOLOR = False
    C.ANSIBLE_NOCOWS = False
    # test for connection plugin of ssh
    C.DEFAULT_SSH_RETRY_FILES_ENABLED = True
    C.DEFAULT_SSH_RETRY_FILES_ENABLED = '/tmp'
    C.DEFAULT_SSH_RETRY_FILES_SAVE_PATH = 'default/path'
    C.DEFAULT_SSH_CONNECTION_RETRY_TIMEOUT = 10

    C.DEFAULT_BEC

# Generated at 2022-06-23 11:24:52.414282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible import constants as C

    # Initialize current ansible configuration
    C.config = ImmutableDict({'DEFAULT_BECOME_USER': 'root'})

    # Initialize lookup module
    lookup_module = LookupModule()

    # Test config lookup of 'DEFAULT_BECOME_USER'
    result = lookup_module.run(["DEFAULT_BECOME_USER"])
    assert result == ['root']

    # Test invalid config setting
    try:
        result = lookup_module.run(["DEFAULT_BECOME_USER_INVALID"])
    except AnsibleLookupError as e:
        pass
    else:
        raise Exception("Failed to detect invalid config setting")

    # Test invalid config in var

# Generated at 2022-06-23 11:24:53.234522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule().run([], None, None)

# Generated at 2022-06-23 11:24:53.935518
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule()

# Generated at 2022-06-23 11:24:55.511956
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ms = MissingSetting("my message")
    assert ms.msg == "my message"

# Generated at 2022-06-23 11:25:06.408933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_test_cases_positive = [
        'DEFAULT_BECOME_USER',
        'DEFAULT_ROLES_PATH',
        'RETRY_FILES_SAVE_PATH',
        'COLOR_OK',
        'COLOR_CHANGED',
        'COLOR_SKIP',
        'DEFAULT_BECOME_USER',
        'DEFAULT_BECOME_USER',
        'DEFAULT_BECOME_USER',
        'DEFAULT_BECOME_USER',
        'DEFAULT_BECOME_USER',
        'DEFAULT_BECOME_USER',
    ]

# Generated at 2022-06-23 11:25:15.018999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_plugin_config_mock(*args, **kwargs):
        raise AnsibleLookupError('Unable to load %s plugin "%s"' % ('some_type', 'some_name'))

    def _get_global_config_mock(*args, **kwargs):
        raise AnsibleLookupError('Invalid setting "%s" attempted' % 'some_term')

    l = LookupModule()
    l.set_options(direct={'plugin_name': 'some_name', 'plugin_type': 'some_type'})
    l._get_plugin_config_mock = _get_plugin_config_mock


# Generated at 2022-06-23 11:25:23.110901
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils.common.validation import Error
    from ansible.module_utils._text import to_text
    e = Error('error', 'invalid_value')
    m = MissingSetting('value not found', orig_exc=e)
    assert to_text(m) == 'value not found'
    assert to_text(m.orig_exc) == 'invalid_value'
    assert repr(m) == 'MissingSetting(\'value not found\', orig_exc=AnsibleModuleError(\'error\', \'invalid_value\'))'

# Generated at 2022-06-23 11:25:26.350070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ptype = None
    pname = None
    terms = ["DEFAULT_BECOME_USER"]
    lookup_module.run(terms, ptype, pname)
    assert True

# Generated at 2022-06-23 11:25:36.588372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This function is a unit test for Ansible core's method run() of class LookupModule. It simply tests to
    make sure that run() raises AnsibleOptionsError if plugin_type is specified but plugin_name is not
    and vice versa.
    """
    module = LookupModule()
    terms = [
        'some_plugin_type', 'some_plugin_name'
    ]

    try:
        module.run(terms)
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in to_native(e)
    else:
        assert False, "No exception thrown"

    terms = [
        'some_plugin_type'
    ]


# Generated at 2022-06-23 11:25:39.062716
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting("Invalid setting", orig_exc=None)
    assert e.message == "Invalid setting"

# Generated at 2022-06-23 11:25:40.293956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase) == True

# Generated at 2022-06-23 11:25:42.794392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('on_missing') == 'error'
    assert lookup.get_option('plugin_type') is None
    assert lookup.get_option('plugin_name') is None

# Generated at 2022-06-23 11:25:54.003761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_plugin_config(pname, ptype, config, variables):
        return "pname: " + pname + ", ptype: " + ptype + ", config: " + config
    def _get_global_config(config):
        return "config: " + config

    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory(LookupModule.lookup_loader_paths)

    lookup = lookup_loader.get('config')

    # test plugin_type and plugin_name is required if one of them is provided
    e = None
    try:
        lookup.run(['ssss'], plugin_name='httpapi', plugin_type='httpapi')
    except AnsibleOptionsError as ex:
        e = ex
    assert e is None

    e = None

# Generated at 2022-06-23 11:25:57.147701
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError) as excinfo:
        e = MissingSetting("FOO")
    assert 'FOO' in str(excinfo.value)

# Generated at 2022-06-23 11:25:58.707893
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 11:25:59.755757
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:26:01.960626
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    x = MissingSetting("Test")
    assert x.msg == "Test"

# Generated at 2022-06-23 11:26:07.284678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    :return:
    """
    fail_pass = ['error', 'warn', 'skip']
    for fail in fail_pass:
        for ptype in plugin_loader.all_plugin_loaders:
            try:
                LookupModule(fail, ptype, ptype)
            except AnsibleOptionsError:
                LookupModule(fail, 'UNKNOWN_TYPE', ptype)


# Generated at 2022-06-23 11:26:10.019870
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('message', 'orig_exc')
    assert missing_setting.message == 'message'
    assert missing_setting.orig_exc == 'orig_exc'


# Generated at 2022-06-23 11:26:11.728647
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("Setting xxyz is missing")
    except MissingSetting as e:
        assert(e.message == "Setting xxyz is missing" )

# Generated at 2022-06-23 11:26:21.353400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''

    terms = ['DEFAULT_SUDO_USER', 'DEFAULT_SUDO_FLAGS']
    variables = {
        'DEFAULT_SUDO_USER': 'admin',
        'DEFAULT_SUDO_FLAGS': '-i',
    }
    on_missing = 'error'

    my_lookup = LookupModule()
    my_lookup.set_options(var_options=variables, direct={'on_missing': on_missing})

    def _get_global_config(config):
        return getattr(C, config)

    my_lookup.run = _get_global_config
    result = my_lookup.run(terms)
    assert result == [u'root', u'--ask-become-pass']

# Generated at 2022-06-23 11:26:22.627735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 11:26:24.719582
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert str(MissingSetting("custom error message", Exception()))

# Generated at 2022-06-23 11:26:27.223026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Return a 'Null' ansible.module_utils.six.string_types object."""
    lm = LookupModule()
    return lm

# Generated at 2022-06-23 11:26:35.611286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    ptype = "connection"
    pname = "ssh"
    setting_name = "remote_user"
    lookup = LookupModule()
    lookup.set_options({'plugin_type': ptype, 'plugin_name': pname})
    expected_result = 'ansible_user'
    # Run
    result = lookup.run([setting_name])
    # Assert
    assert result[0] == expected_result

# Generated at 2022-06-23 11:26:37.660860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None
    assert module.run is not None

# Generated at 2022-06-23 11:26:42.483012
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "my error message"
    orig_exc = Exception("this is my original exception")
    try:
        raise MissingSetting(msg, orig_exc=orig_exc)
    except AnsibleOptionsError as e:
        assert str(e) == msg
        assert e.orig_exc == orig_exc
        assert str(e) == msg

# Generated at 2022-06-23 11:26:50.339359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    print(module.run(terms=["DEFAULT_BECOME_USER"], variables="", **{"on_missing": "error"}))
    print(module.run(terms=["DEFAULT_BECOME_USER", "DEFAULT_BECOME_METHOD"], variables="", **{"on_missing": "warn"}))
    print(module.run(terms=["DEFAULT_BECOME_USER", "DEFAULT_BECOME_METHOD", "DEFAULT_BECOME_PASS"], variables="", **{"on_missing": "skip"}))

# Generated at 2022-06-23 11:26:54.641818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('config')
    lookup.set_options({'var_options': {}})

    # Act
    res = lookup.run([])

    # Assert
    assert type(res) == list

# Generated at 2022-06-23 11:26:55.228003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 11:27:06.399832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case: 2 terms are used, config value of 2nd term is not available
    # Expected: 2nd term is skipped
    lookup_plugin = LookupModule()
    var_options = dict(COLLECTION_PATH='./')
    lookup_plugin.set_options(var_options=var_options, direct={})
    # on_missing is set to 'warn'
    lookup_plugin.set_options(dict(on_missing='warn'))
    terms = ['COLLECTION_PATHS', 'COLLECTION_PATH']
    ret = lookup_plugin.run(terms)
    assert len(ret) == 1 and ret[0] == './'

    # Case: no terms are used
    # Expected: AnsibleOptionsError is raised
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 11:27:07.885102
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting(msg='some message', orig_exc='some exception')

# Generated at 2022-06-23 11:27:13.831679
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = "Some error message"
    e = AnsibleError()
    missingSetting = MissingSetting(msg)
    assert missingSetting.message == msg
    assert missingSetting.orig_exc is None

    # Set orig_exc and check value
    missingSetting = MissingSetting(msg, orig_exc=e)
    assert missingSetting.message == msg
    assert missingSetting.orig_exc == e

# Generated at 2022-06-23 11:27:15.319132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run

# Generated at 2022-06-23 11:27:19.424361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return {
            'terms'           :   ['DEFAULT_BECOME_USER'],
            'variables'       :   None,
            'kwargs'          :   {},
            'return'          :   ['root']
            }

# Generated at 2022-06-23 11:27:23.174668
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Arrange
    try:
        # Act
        msg = 'Unable to load connection plugin "netconf"'
        MissingSetting(msg)
    except:
        assert False, "Unable to use MissingSetting constructor"

# Generated at 2022-06-23 11:27:26.543148
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Create a MissingSetting object
    msg = 'test message'
    ms = MissingSetting(msg)

    # Check that value returned by str(ms) is the same as the value passed to the constructor
    assert str(ms) == msg

    return True

# Generated at 2022-06-23 11:27:29.323620
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lkp_obj = LookupModule()
    assert isinstance(lkp_obj, LookupModule)


# Generated at 2022-06-23 11:27:34.368521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_ROLES_PATH', 'DEFAULT_ALLOW_WORLD_READABLE_TMPFILES']
    vari = {'some_var': 'some_value'}
    LookupModule.run(terms, vari, on_missing='error', plugin_type=None, plugin_name=None)

# Generated at 2022-06-23 11:27:35.972289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    con = LookupModule()
    assert con is not None


# Generated at 2022-06-23 11:27:41.035011
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native

    e = AnsibleError('Test')
    m = MissingSetting('Test', orig_exc=e)

    assert m.orig_exc == e
    assert to_native(m) == 'Test'

# Generated at 2022-06-23 11:27:46.983434
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    expected = [
        {
            'on_missing': 'a',
            'test_case': 'Invalid option for on_missing',
            'expected': AnsibleOptionsError
        },
        {
            'on_missing': 'error',
            'test_case': 'valid option for on_missing',
            'expected': MissingSetting
        }
    ]
    for test_case in expected:
        try:
            raise MissingSetting('test', 'test')
        except test_case['expected']:
            pass

# Generated at 2022-06-23 11:27:56.470290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    pl = plugin_loader.lookup_loader

    lookup = pl.get('config')

    # set up env
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    variables = VariableManager(loader=loader, inventory=inv_manager)

    # do test
    result = lookup.run(terms=["DEFAULT_JINJA2_NATIVE"], variables=variables)

    assert result == [False]

# Generated at 2022-06-23 11:28:03.547259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _terms = [ "foo", "bar" ]
    _variables = { "q": "qqq" }
    _kwargs = { "on_missing": "error", "plugin_type": "become", "plugin_name": "become_plugin" }
    lm = LookupModule()
    lm.run(_terms, _variables, **_kwargs)
    assert lm.get_option("on_missing") == "error"
    assert lm.get_option("plugin_name") == "become_plugin"

# Generated at 2022-06-23 11:28:08.718531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    p = plugin_loader.action_loader.get('assert', class_only=True)
    assert p

    result = (LookupModule()).run(
        terms=['plugins'],
        hostvars={},
        variables={},
        plugin_type='action', plugin_name='assert', on_missing='error',
    )

    assert result == [
        ['assert', 'async_wrapper', 'debug', 'mail', 'meta', 'pause', 'ping', 'raw', 'script', 'shell', 'sleep', 'unarchive', 'uri']
    ]


if __name__ == '__main__':
    # Unit test configuration
    test_LookupModule_run()