

# Generated at 2022-06-23 11:18:15.783220
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import os
    import pytest

    missing_setting = MissingSetting("test_msg")
    test_msg = 'trying to set nonexistent variable'
    missing_setting.message = 'trying to set nonexistent variable'
    assert missing_setting.message == test_msg

    # test MissingSetting.message
    with pytest.raises(AttributeError):
        missing_setting.msg = 'trying to set nonexistent variable'

# Generated at 2022-06-23 11:18:24.969456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Unhappy path: if terms is not a string
    terms = None
    try:
        module.run(terms, variables=None, **{})
        assert False, "This should not happen"
    except AnsibleOptionsError as e:
        assert 'Invalid setting identifier, "\'None\'" is not a string' in to_native(e)

    # Unhappy path: if terms is string but not included in constants
    terms = 'MYHOME'
    try:
        module.run(terms, variables=None, **{})
        assert False, "This should not happen"
    except MissingSetting as e:
        assert "was not defined" in to_native(e)

    # Happy path: if terms is string and included in constants
    terms = 'DEFAULT_ROLES_PATH'

# Generated at 2022-06-23 11:18:34.568142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupModule():
        def __init__(self):
            self.var1 = 'value 1'
            self.var2 = 'value 2'
            self.var3 = 'value 3'
            # mock Ansible constants to make sure we are not using the global, real Ansible constants
            from ansible.constants import __constants_version__
            self.constants = type('AnsibleConstants', (object,), {"__constants_version__": __constants_version__})

    lm = LookupModule()
    lm.set_loader(MockLookupModule())

    # set default option
    lm.set_options(var_options={}, direct={'on_missing': 'error'})
    # raise error if lookup cannot find any of the terms

# Generated at 2022-06-23 11:18:37.252517
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 11:18:38.416163
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('test')
    assert e.args[0] == 'test'

# Generated at 2022-06-23 11:18:41.127595
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test message')
    except MissingSetting as err:
        assert err.message == 'test message'
        assert err.orig_exc is None

# Generated at 2022-06-23 11:18:43.301289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    mod = LookupModule()

    assert mod is not None


# Generated at 2022-06-23 11:18:47.273628
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'err msg'
    e = Exception('err')

    x = MissingSetting(msg, orig_exc=e)
    assert x.error == msg
    assert x.orig_exc == e

# Generated at 2022-06-23 11:18:51.192405
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        result = MissingSetting('this is a test')
    except Exception as e:
        print('This is just a test. The following exception is expected:')
        print('%s' % e)

# Generated at 2022-06-23 11:18:53.047828
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting("test")
    assert isinstance(error, AnsibleOptionsError)

# Generated at 2022-06-23 11:19:01.012299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for error: both plugin_type and plugin_name are required, cannot use one without the other
    with pytest.raises(AnsibleOptionsError):
        ret = LookupModule().run(terms=['remote_user'], variables=None, plugin_type='connection', plugin_name=None)

    # Test for error: Invalid setting identifier
    with pytest.raises(AnsibleOptionsError):
        ret = LookupModule().run(terms=['param1', 'param2'])

    # Test for error: Invalid setting identifier
    with pytest.raises(AnsibleOptionsError):
        ret = LookupModule().run(terms=['param1', False])

    if C.DEFAULT_REMOTE_USER == 'testuser':
        assert LookupModule().run(terms=['DEFAULT_REMOTE_USER'])

# Generated at 2022-06-23 11:19:11.228528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Module(object):
        def __init__(self, params=None, options=None):
            self.params = params or {}
            self.options = options or {}
            self.args = ['foo']

    class MyLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            super(MyLookupModule, self).__init__(loader=loader, templar=templar, **kwargs)

    class Mock(object):
        def __init__(self, name):
            self.name = name
            self.vars = {'name': self.name}

    mp = Mock('ansible.cfg')


# Generated at 2022-06-23 11:19:12.565779
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 11:19:19.290404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test run method of LookupModule class for managing Ansible config values"""
    # build arguments for the method
    args = dict()
    args['terms'] = ['DEFAULT_ROLES_PATH']
    args['variables'] = None
    args["on_missing"] = "error"
    args['plugin_type'] = None
    args['plugin_name'] = None

    # instance object of class LookupModule
    lookup_module = LookupModule()

    result = lookup_module.run(**args)

    # assert type of result
    assert isinstance(result, list)

    # assert result
    assert result == ["~/.ansible/roles", "/etc/ansible/roles"]



# Generated at 2022-06-23 11:19:22.978938
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Error from test')
    except MissingSetting as error:
        assert error.message == 'Error from test'
        assert isinstance(error, AnsibleOptionsError)

# Generated at 2022-06-23 11:19:26.169655
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'the term'
    orig_exception = ValueError('the message')
    exc = MissingSetting(msg, orig_exc=orig_exception)
    assert exc.orig_exc == orig_exception
    assert exc.message == msg

# Generated at 2022-06-23 11:19:28.408161
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Testing constructor of MissingSetting.
    # If object is created properly, then no error is raised
    try:
        raise MissingSetting('test message')
    except MissingSetting:
        pass

# Generated at 2022-06-23 11:19:30.412217
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        raise MissingSetting("this setting is missing")

# Generated at 2022-06-23 11:19:32.287701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupBase)

# Generated at 2022-06-23 11:19:35.000036
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'test message'
    out = MissingSetting(msg)
    assert out.value == msg
    assert out.orig_exc is None
    assert out.arg_names == []

# Generated at 2022-06-23 11:19:37.390777
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    s = MissingSetting('ansible')
    assert s.message == 'ansible'

# Generated at 2022-06-23 11:19:48.094921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    # Test whether the "terms" parameter is required
    assert_raises(AnsibleOptionsError, lookup_obj.run)
    # Test whether the "on_missing" parameter is optional and whether has a default value
    assert_true(lookup_obj.get_option('on_missing') == 'error')
    # Test whether the "plugin_type" parameter is optional and whether has a default value
    assert_true(lookup_obj.get_option('plugin_type') is None)
    # Test whether the "plugin_name" parameter is optional and whether has a default value
    assert_true(lookup_obj.get_option('plugin_name') is None)
    # Test whether on_missing can be a valid non-default value
    lookup_obj = LookupModule(on_missing='skip')

# Generated at 2022-06-23 11:19:57.842523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.hashing import md5s
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    config_lookup = LookupModule()

    # Test with on_missing set to error
    config_lookup.set_options({'on_missing': 'error'})

    # Test with string value
    assert [md5s(C.ANSIBLE_NOCOWS)] == config_lookup.run(['ANSIBLE_NOCOWS'])

    # Test with list value
    assert C.QUERY_FILTERS == config_lookup.run(['QUERY_FILTERS'])

    # Test with on_missing set to skip
    config_lookup.set_options({'on_missing': 'skip'})

    # Test with number value
    assert ['0']

# Generated at 2022-06-23 11:20:03.882651
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as plugin_loader
    plugin_loader.add_directory(u'/etc/ansible/plugins')
    module = LookupModule()
    module._display = DummyDisplay()

    # test on_missing option. "error" is default, see above, so no need to test it separately
    module.set_options(on_missing='warn', direct={})
    results = module.run(["ANSIBLE_RETRY_FILES_ENABLED"], variables={})
    assert results == []
    module.set_options(on_missing='skip', direct={})
    results = module.run(["ANSIBLE_RETRY_FILES_ENABLED"], variables={})
    assert results == []

    module.set_options(on_missing='error', direct={})
    # test multiple terms, only one fails, should

# Generated at 2022-06-23 11:20:11.782370
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret.run(['DEFAULT_BECOME_USER']) == [C.DEFAULT_BECOME_USER]

    assert ret.run(['DEFAULT_BECOME_USER', 'DEFAULT_REMOTE_TMP']) == [C.DEFAULT_BECOME_USER, C.DEFAULT_REMOTE_TMP]

    assert ret.run(['UNKNOWN'], on_missing='error')


# Generated at 2022-06-23 11:20:20.615331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'error'})
    result = lookup_module.run(['remote_tmp'])

    assert len(result) == 1
    assert result[0] == '$HOME/.ansible/tmp'

    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'warn'})
    result = lookup_module.run(['unknown_setting'])

    assert len(result) == 0

    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'skip'})

# Generated at 2022-06-23 11:20:22.822247
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('test message')
    assert str(exc) == 'test message'
    assert exc.value == 'test message'

# Generated at 2022-06-23 11:20:24.194198
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exceptions.MissingSetting("Test")

# Generated at 2022-06-23 11:20:25.943226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:20:36.811984
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    config_key = "FOO_BAR"
    explanation = "The setting 'FOO_BAR' was not defined in configuration, check docs at https://docs.ansible.com/ansible/latest/user_guide/playbooks_variables.html#ansible-configuration-settings or AnsibleUnsafeText('%s')" % config_key
    ansible_version = "ansible 2.8.1"
    ansible_version_raw = "2.8.1"
    msg = "The setting '%s' was not defined in configuration, check docs at https://docs.ansible.com/ansible/latest/user_guide/playbooks_variables.html#ansible-configuration-settings or AnsibleUnsafeText('%s')" % (config_key, config_key)

# Generated at 2022-06-23 11:20:39.859389
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('msg', orig_exc=None)
    assert(str(e) == 'msg')
    assert(isinstance(e, Exception))
    assert(isinstance(e, AnsibleError))
    assert(isinstance(e, AnsibleOptionsError))

# Generated at 2022-06-23 11:20:45.805127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import os
    from ansible.utils.sentinel import Sentinel

    # Create a temporary file to write module input to
    (handle, path) = tempfile.mkstemp()
    os.close(handle)

    name = sys._getframe().f_code.co_name

    # Create an ansible.module_utils.basic.AnsibleModule object as a mock
    mock_am = mock.Mock(spec=AnsibleModule)
    mock_am.params = {}
    mock_am.check_mode = False

    # Create an instance of class LookupModule
    lookup_plugin = LookupModule()

    # Test case when input string is not a string and exception is raised
    with pytest.raises(AnsibleOptionsError) as exec_info:
        lookup_plugin.run([123])

   

# Generated at 2022-06-23 11:20:49.816920
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Validate constructor', orig_exc='orig_exc')
    except MissingSetting as e:
        assert e.message == 'Validate constructor'
        assert e.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:20:52.538233
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """
    Fake the code that's not possible to test in this function
    """
    MissingSetting('ansible.errors.AnsibleError.constructor_test')

# Generated at 2022-06-23 11:21:05.879495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    results = []

    def run_module_stub(self, conn, tmp, module_name, module_args, inject, complex_args=None, **kwargs):
        results.append({'kwargs': kwargs, 'module_name': module_name, 'module_args': module_args})

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=['localhost,']),
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_tree=False,
    )

    tqm._stdout_callback = run_module_stub


# Generated at 2022-06-23 11:21:07.409147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert( hasattr( LookupModule(), "run" ) )

# Generated at 2022-06-23 11:21:15.145699
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:21:27.137898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test that the run method returns AnsibleLookupError when the plugin_name and plugin_type options are provided but either plugin_type or plugin_name is not provided
    :return:
    """
    from ansible.plugins.lookup.config import LookupModule
    from ansible.utils.sentinel import Sentinel

    # Test that an error is raised when plugin_type and plugin_name is provided but plugin_name is not provided
    lm = LookupModule()
    lm.set_options(var_options=dict(foo='bar'), direct=dict(plugin_name='foo'))
    try:
        lm.run(['foo'])
    except AnsibleError:
        pass
    else:
        assert False, "Expected AnsibleEror not raised."

    # Test that an error is raised when plugin_type and plugin

# Generated at 2022-06-23 11:21:29.886160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    class LookupModule(TestCase):
        def test_global_config(self):
            print('test global config')


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 11:21:38.327355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.config import LookupModule
    ansible_config = {}
    ansible_config['ssh_args'] = "-C -o ControlMaster=auto -o ControlPersist=60s"
    ansible_config['sudo_exe'] = "/usr/bin/sudo"
    ansible_config['connection_plugins'] = "/home/ansible/.ansible/plugins/connection/"
    ansible_config['__DEFAULT_TEMPFILE_PLUGIN'] = "tempfile"

# Generated at 2022-06-23 11:21:44.726919
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting("can't find it")
    assert 'can not find it' in str(missing_setting)
    error = Exception("lookup exception")
    missing_setting = MissingSetting("can't find it", error)
    assert 'can not find it' in str(missing_setting)
    assert 'lookup exception' in str(missing_setting)

# Generated at 2022-06-23 11:21:49.181357
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    plugin_mock = {
        'plugin_type': 'shell',
        'plugin_name': 'sh'
    }
    
    terms_mock = [
        'remote_tmp'
    ]

    variables_mock = {
        'C.BECOME_PASS': 'test_variable'
    }

    lookup_mock = LookupModule()

    result = lookup_mock.run(terms=terms_mock, variables=variables_mock, **plugin_mock)
    assert result == ['/tmp/ansible-tmp-1534877827.55-267039584901585']


# Generated at 2022-06-23 11:21:52.836741
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LUT = LookupModule()
    except Exception as e:
        print('Exception raised: {0}'.format(e))
    else:
        print('LookupModule object created successfully')


# Generated at 2022-06-23 11:21:54.303681
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run('DEFAULT_BECOME_USER')

# Generated at 2022-06-23 11:22:02.495935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader, vars_loader, connection_loader
    from ansible import constants as C
    # patch the lookup module and class to be able to override C.DEFAULT_ROLES_PATH
    C.DEFAULT_ROLES_PATH = '/test/roles'
    lu = LookupModule()
    lu._loader = lookup_loader
    lu._display = None  # avoid display.DeprecationWarnings
    lu.set_options(var_options={}, direct={})
    assert lu.run(['DEFAULT_ROLES_PATH']) == ['/test/roles']
    # check the var plugin is loaded
    vars_loader.get("var")
    # check the connection plugin is loaded
    connection_loader.get("sh")
    assert lu

# Generated at 2022-06-23 11:22:08.966070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert hasattr(lookup, 'run'), "LookupModule must have 'run' method"
    # test the default on_missing value
    assert lookup.set_options(direct={}).get_option('on_missing') == 'error'

    assert_args = {
        'terms': 'DEFAULT_BECOME_USER',
        'variables': 'root',
        'kwargs': None,
    }
    assert lookup.run(**assert_args) == ['root']

# Generated at 2022-06-23 11:22:10.463256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 11:22:20.148577
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import StringIO
    import sys

# Generated at 2022-06-23 11:22:31.354743
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Run the tests for the LookupModule class

    The tests are run from the root test directory and should be run with python
    setup.py test (no root privs needed)
    """

    import pytest

    from ansible.plugins.loader import lookup_loader

    # Force the LookupModule class not to be cached by the PluginLoader
    # NOTE: This may break if the PluginLoader is changed to cache
    #       LookupModule classes in the future.
    lookup_loader._module_cache.pop(LookupModule.__name__, None)

    # Create an instance of the LookupModule class and run the test
    lookup_module = lookup_loader.get(LookupModule.__name__, class_only=True)()
    lookup_module._display.verbosity = 1

# Generated at 2022-06-23 11:22:38.099454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_iterable
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    local_vars = VariableManager()
    local_vars.set_variable('role_paths', ['./my/playbook/roles'])
    local_vars.set_variable('playbook_dir', './my/playbook')

    class Options(object):
        def __init__(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct or {}


# Generated at 2022-06-23 11:22:39.326711
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:22:42.040311
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    terms = "remote_port"
    # This function is used to test the function self.run in LookupModule
    instance.run(terms)

# Generated at 2022-06-23 11:22:42.807686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupModule))

# Generated at 2022-06-23 11:22:52.706155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for success case
    try:
        terms = ['DEFAULT_MODULE_LIST', 'DEFAULT_MODULE_PATH']
        variables = {}

        lookup_module = LookupModule()
        lookup_module.run(terms, variables)
    except Exception as e:
        assert False, 'Unable to create lookup module instance'

    # Test for error case
    try:
        terms = ['DEFAULT_MODULE_LIST', 'DEFAULT_MODULE_PATH']
        variables = None

        lookup_module = LookupModule()
        lookup_module.run(terms, variables)
    except Exception as e:
        assert True


# Generated at 2022-06-23 11:22:53.148841
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 11:22:55.434633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    y = LookupModule()
    var = ['/home/ansible']
    y.run(terms=var, variables=None, wantlist=True)

# Generated at 2022-06-23 11:22:57.232110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # assert equal
    assert lookup_module is not None

# Generated at 2022-06-23 11:23:00.248665
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('abc', 'abc')
    except MissingSetting as e:
        assert 'abc' == e.message

# Generated at 2022-06-23 11:23:05.566638
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import _get_all_plugin_loaders
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    display = Display()
    lookup_loader.add_directory(to_text(u'/root/lookup_plugins'))
    const = _get_all_plugin_loaders(to_bytes(u'lookup'))
    l = LookupModule(display=display, loader=lookup_loader, basedir='/root/lookup_plugins')
    l.run(terms=['age'])

# Generated at 2022-06-23 11:23:06.709839
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:23:08.534070
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:23:10.744970
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(direct=dict())
    lookup.set_options(var_options=dict())
    assert callable(lookup.run)

# Generated at 2022-06-23 11:23:19.656993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    import os
    from ansible.plugins.loader import lookups_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    

# Generated at 2022-06-23 11:23:25.094610
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import Mapping
    from ansible.parsing.ajson import AnsibleJSONEncoder

    import sys
    import ansible.plugins.lookup.config

    config = ansible.plugins.lookup.config.LookupModule()
    config_variables = {'ansible_ssh_user': 'test_user'}

    if PY3:
        SomeStdOut = StringIO()
    else:
        SomeStdOut = StringIO('stub')

    # save stdout
    SavedStdOut = sys

# Generated at 2022-06-23 11:23:28.758490
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    test_object = MissingSetting("test_message_print", orig_exc=AnsibleOptionsError("test_orig_exc_print"))
    assert isinstance(test_object.msg, str)
    assert test_object.orig_exc.msg == "test_orig_exc_print"

# Generated at 2022-06-23 11:23:30.260933
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:23:31.972342
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test for constructor of class LookupModule
    assert LookupModule(None, None, None)

# Generated at 2022-06-23 11:23:34.461120
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert issubclass(MissingSetting, AnsibleOptionsError)
    assert issubclass(MissingSetting, AnsibleError)

# Generated at 2022-06-23 11:23:45.677203
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:23:53.620725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = '''
    ---
    - hosts: localhost
      tasks:
         - debug:
              msg: "{{lookup('config', 'DEFAULT_ROLES_PATH')}}"
        '''
    import ansible.constants as C

    test_obj = LookupModule()
    result = test_obj.run(terms=[C.DEFAULT_ROLES_PATH])

    assert type(result) is list
    assert len(result) == 1
    assert 'roles' in result[0]

# Generated at 2022-06-23 11:23:54.933897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:23:56.873673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing constructor of LookupModule")
    L = LookupModule()
    assert L



# Generated at 2022-06-23 11:23:58.233073
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    inst = MissingSetting('test_msg')
    assert inst.message == 'test_msg'

# Generated at 2022-06-23 11:24:00.109685
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Error')
    except MissingSetting as e:
        assert e.msg == 'Error'

# Generated at 2022-06-23 11:24:04.985076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test LookupModule.run method
    """

    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {'on_missing': 'error',
              'plugin_type': None,
              'plugin_name': None}

    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)

    assert result == ['root']

# Generated at 2022-06-23 11:24:07.762333
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Ensure MissingSetting Error can be created"""
    try:
        raise MissingSetting("Testing")
    except AnsibleOptionsError as e:
        assert str(e) == "Testing"

# Generated at 2022-06-23 11:24:17.337018
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Setup test variables
    terms = ['DEFAULT_DEBUG', 'DEFAULT_PERM_RETRY']
    on_missing = 'error'
    plugin_type = 'become'
    plugin_name = 'su'

    # Create instance of LookupModule
    module = LookupModule()

    # Populate run variables
    try:
        module.run(terms, on_missing=on_missing, plugin_type=plugin_type, plugin_name=plugin_name)
    except AnsibleOptionsError as e:
        assert (e.message == 'Both plugin_type and plugin_name are required, cannot use one without the other')
    except:
        assert (False)
    else:
        assert (False)

    # Populate run variables
    on_missing = 'warn'

# Generated at 2022-06-23 11:24:19.807471
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    with pytest.raises(AnsibleOptionsError) as excinfo:
        raise MissingSetting("test")
    assert str(excinfo.value) == "test"

# Generated at 2022-06-23 11:24:28.536631
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """ Unit test for constructor of class MissingSetting.
        Tests for type error are also included.
    """

    # create an instance of class MissingSetting
    ms = MissingSetting()

    # test constructor of class MissingSetting
    assert isinstance(ms, AnsibleOptionsError)
    assert str(ms) == ''
    assert ms.orig_exc is None

    # test constructor with message and original exception
    ms = MissingSetting('test', 'original exception')
    assert str(ms) == 'test'
    assert ms.orig_exc == 'original exception'

    # test constructor, when arguments are of wrong type
    try:
        ms = MissingSetting(100, 200)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 11:24:30.717441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:24:32.071606
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.plugin_type == 'lookup'

# Generated at 2022-06-23 11:24:34.137257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l
    assert l._display
    assert l._templar

# Generated at 2022-06-23 11:24:37.481786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    ret = lookup_obj.run(terms)
    assert ret is not None

# Generated at 2022-06-23 11:24:39.291826
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test message")
    except MissingSetting as e:
        assert(str(e) == "test message")

# Generated at 2022-06-23 11:24:40.620466
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        e = MissingSetting("")

# Generated at 2022-06-23 11:24:48.700016
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['DEFAULT_BECOME_USER', 'remote_tmp']
    variables = {'DEFAULT_BECOME_USER': 'root'}
    plugin_type = 'shell'
    plugin_name = 'sh'
    lookup_obj = LookupModule(loader=None, variables=variables)
    assert (lookup_obj._get_global_config('DEFAULT_BECOME_USER') == 'root')
    assert (lookup_obj._get_plugin_config(plugin_name, plugin_type, 'remote_tmp', variables) == '/tmp/ansible-${USER}')

# Generated at 2022-06-23 11:24:54.596277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    out = {}
    out['global_var'] = C.DEFAULT_REMOTE_USER
    out['plugin_var'] = C.config.get_config_value('remote_tmp', plugin_type='shell', plugin_name='sh')

    global_config = LookupModule()
    global_config.run(['DEFAULT_REMOTE_USER']) == out['global_var']

    plugin_config = LookupModule()
    plugin_config.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == out['plugin_var']

# Generated at 2022-06-23 11:25:05.383632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ptype = 'shell'
    pname = 'sh'
    setting = 'remote_tmp'
    class LookupModule_test_class(LookupModule):
        def __init__(self):
            pass

        def run(self, terms, variables=None, **kwargs):
            self.run_lookup('config', terms, variables, ptype=ptype, pname=pname, on_missing='warn')

    test_obj = LookupModule_test_class()

    # simulate a config file which defines remote_tmp setting for sh plugin in [shell_sh] section
    constants_copy = C.config.config.copy()
    constants_copy['shell_sh']['remote_tmp'] = 'temp'
    C.config.config = constants_copy

    # run lookup plugin and test result
    result = test_obj

# Generated at 2022-06-23 11:25:10.700261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module=LookupModule()
    print("The value of module is: " + str(module))
    print("The value of module.set_options() is: " + str(module.set_options()))
    print("The value of module.get_option() is: " + str(module.get_option('')))
    print("The value of module.run() is: " + str(module.run('')))

# Generated at 2022-06-23 11:25:17.308778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ptype = 'connection'
    pname = 'netconf'
    term = 'remote_port'
    terms = ['remote_port', 'remote_user']
    result = lookup.run([term], plugin_type=ptype, plugin_name=pname)
    assert result == [830]
    result = lookup.run(terms, plugin_type=ptype, plugin_name=pname)
    assert result == [830, 'ansible']
    result = lookup.run(terms, plugin_type=ptype, plugin_name=pname, on_missing='warn')
    assert result == [830, 'ansible']
    result = lookup.run(terms, plugin_type=ptype, plugin_name=pname, on_missing='skip')
    assert result == ['ansible']

# Generated at 2022-06-23 11:25:26.204109
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    import six
    if six.PY2:
        m = MissingSetting('test error msg')
        # Attribute orig_exc is not present in a legacy python version
        assert not hasattr(m, 'orig_exc')
        assert m.message == 'test error msg'
    else:
        import sys
        m = MissingSetting('test error msg', orig_exc=ValueError)
        assert m.orig_exc is not None
        assert m.message == 'test error msg'
        assert issubclass(m.__cause__, ValueError)
        assert m.__suppress_context__ is True
        assert m.__context__ is sys.exc_info()[1]

# Generated at 2022-06-23 11:25:26.894243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:25:31.526382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=[]) == []
    assert lookup.run(terms='') == []
    assert lookup.run(terms='', variables={'lookup_plugin.run_passed_term': 'bar'}) == ['bar']

# Generated at 2022-06-23 11:25:32.834713
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('attribute "foo" was not defined')
    except MissingSetting as e:
        assert e.attribute == 'foo'

# Generated at 2022-06-23 11:25:34.935704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['unknown_setting'], {}, on_missing='error') == []



# Generated at 2022-06-23 11:25:44.067926
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.plugins import connection_loader

    # mock the lookup itself
    class MockLookupModule(LookupModule):
        def __init__(self):
            self._display = MockDisplay()
            self._plugin_paths = []

        def _find_needle(self, needle, haystack):
            return haystack.index(needle)

        def get_option(self, option):
            return True

    # mock the Display class used by LookupModule
    class MockDisplay(object):
        def __init__(self, error=None):
            self.error = error

        def warning(self, msg):
            print('Warning: %s' % msg)


# Generated at 2022-06-23 11:25:45.620292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)



# Generated at 2022-06-23 11:25:48.047110
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    o = MissingSetting('test_message')
    assert o.message == 'test_message'
    assert o.help_msg == ''

# Generated at 2022-06-23 11:25:59.386889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests using the global config (version)
    global_setting_tests = [
        ('version', True, [C.__version__]),
        ('DEFAULT_ROLES_PATH', True, [C.DEFAULT_ROLES_PATH]),
        ('DEFAULT_BECOME_USER', True, [C.DEFAULT_BECOME_USER]),
        ('DEFAULT_LIBRARY_PATH', False, [C.DEFAULT_LIBRARY_PATH]),
        ('SOMETHING_NOT_REAL', False, [C.SOMETHING_NOT_REAL]),
        ]
    # Tests using a shell plugin

# Generated at 2022-06-23 11:26:01.989322
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('msg', 'orig_exc')
    assert e.__class__ == MissingSetting
    assert e.msg == 'msg'
    assert e.orig_exc == 'orig_exc'

# Generated at 2022-06-23 11:26:04.054188
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    x = MissingSetting("Dummy Exception", orig_exc="Some exception object")
    assert x.args[0] == "Dummy Exception"
    assert x.orig_exc == "Some exception object"

# Generated at 2022-06-23 11:26:05.736085
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for class LookupModule
    """
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 11:26:06.272582
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:26:08.648261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule) # constructed object is an instance of LookupModule


# Generated at 2022-06-23 11:26:09.553060
# Unit test for constructor of class LookupModule
def test_LookupModule():
  print("")

# Generated at 2022-06-23 11:26:12.068976
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Build some args
    exception = Exception()
    message = 'barfoo'
    # Using the constructor
    missingSetting = MissingSetting(message, exception)
    # Asserts
    assert message == missingSetting.message
    assert exception == missingSetting.orig_exc

# Generated at 2022-06-23 11:26:16.828248
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exp_msg = 'test_setting was not defined in configuration'
    exp_orig = AssertionError('test_setting was not defined in configuration')
    try:
        raise MissingSetting(exp_msg,orig_exc=exp_orig)
    except MissingSetting as exc:
        assert exc.msg==exp_msg
        assert exc.orig_exc==exc_orig

# Generated at 2022-06-23 11:26:18.147447
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None, "Init of lookup failed"

# Generated at 2022-06-23 11:26:29.112779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_basedir('.')
    lookup.set_environment({})
    lookup._display = None
    assert lookup.run([], {}) == []
    assert lookup.run(['CHANGED_COLOR'], {}) == ['yellow']

    assert lookup.run(['CHANGED_COLOR'], {}, on_missing='warn') == ['yellow']
    assert lookup.run(['FOO'], {}, on_missing='warn') == []

    assert lookup.run(['CHANGED_COLOR'], {}, on_missing='skip') == ['yellow']
    assert lookup.run(['FOO'], {}, on_missing='skip') == []


# Generated at 2022-06-23 11:26:36.940449
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test when given a proper message and exception string
    error = MissingSetting('message', orig_exc=Exception('exception string'))
    assert error.message == 'message'
    assert str(error) == 'exception string'

    # Test when passed an exception message instead of an exception object
    error = MissingSetting('exception string', orig_exc='Exception')
    assert error.message == 'exception string'
    assert str(error) == 'exception string'

# Generated at 2022-06-23 11:26:37.682082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # No exception should be raised
    LookupModule()

# Generated at 2022-06-23 11:26:40.067105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:26:41.665172
# Unit test for constructor of class LookupModule
def test_LookupModule():
  """Test constructor of class LookupModule"""
  module = LookupModule()
  assert isinstance(module, LookupModule)

# Generated at 2022-06-23 11:26:51.741736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test for missing option plugin_type, plugin_name
    try:
        lookup.run(['remote_user'], plugin_name='ssh')
        assert False, "Failed to raise AnsibleOptionsError"
    except AnsibleOptionsError:
        pass

    # Test for invalid option plugin_type
    try:
        lookup.run(['remote_user'], plugin_name='ssh', plugin_type='abc')
        assert False, "Failed to raise AnsibleOptionsError"
    except AnsibleOptionsError:
        pass

    # Test for invalid option plugin_name
    try:
        lookup.run(['remote_user'], plugin_name='ssh', plugin_type='connection')
        assert False, "Failed to raise AnsibleLookupError"
    except AnsibleLookupError:
        pass

# Generated at 2022-06-23 11:26:55.929476
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    config_fail = 'UNKNOWN_CONFIG'
    # ensure that the exception is raised when the config is missing
    try:
        _get_global_config(config_fail)
    except MissingSetting as e:
        assert config_fail in to_native(e)

# Generated at 2022-06-23 11:26:57.923709
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('my message')
    except MissingSetting as e:
        assert e.orig_exc is None
        # Test the message is handled correctly
        assert str(e) == 'my message'

# Generated at 2022-06-23 11:27:00.180018
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test Message')
    except MissingSetting as e:
        assert str(e) == 'Test Message'

# Generated at 2022-06-23 11:27:04.035376
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('error message', orig_exc=LookupError('some lookup error'))
    assert e.message == 'error message'
    assert e.orig_exc.args[0] == 'some lookup error'

# Generated at 2022-06-23 11:27:14.890910
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit tests for ansible.plugins.lookup.config.LookupModule
    """
    from ansible.compat.tests.mock import patch, MagicMock

    with patch("ansible.plugins.lookup.config.plugin_loader") as plugin_loader:

        plugin_loader.lookup_loader.get.return_value = None
        plugin_loader.vars_loader.get.return_value = None
        plugin_loader.connection_loader.get.return_value = None
        plugin_loader.shell_loader.get.return_value = None

        lookup_obj = LookupModule()

        # Test with unset on_missing
        with patch("ansible.plugins.lookup.config.AnsibleOptionsError") as AnsibleOptionsError:
            lookup_obj.run([])

# Generated at 2022-06-23 11:27:26.454836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.common.process import get_bin_path
    from ansible.plugins.loader import lookup_loader

    ansible_cfg = StringIO()
    ansible_cfg.write("[defaults]\n")
    ansible_cfg.write("inventory = /home/nilesh/Projects/ansible/examples/hosts\n")
    ansible_cfg.write("roles_path = /home/nilesh/Projects/ansible/examples/roles\n")
    ansible_cfg.write("library = /home/nilesh/Projects/ansible/examples/library\n")

# Generated at 2022-06-23 11:27:27.995161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert hasattr(LookupModule, 'set_options')

# Generated at 2022-06-23 11:27:34.758990
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test with all argument types.
    msg = 'Testing message'
    obj_type = LookupModule
    obj_var = 'Plugin_class'
    obj_name = 'Plugin_name'
    orig_exc = Exception

    # Test without original message
    result = MissingSetting(msg)
    assert result.message == msg
    assert result.obj_type is None
    assert result.obj_var is None
    assert result.obj_name is None
    assert result.orig_exc is None

    # Test without original exception
    result = MissingSetting(msg, obj_type=obj_type, obj_var=obj_var, obj_name=obj_name)
    assert result.message == msg
    assert result.obj_type == obj_type
    assert result.obj_var == obj_var

# Generated at 2022-06-23 11:27:37.004286
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    missing_setting = MissingSetting('test')
    assert isinstance(missing_setting, MissingSetting)

# Generated at 2022-06-23 11:27:43.955476
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.config import LookupModule
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.six import string_types

    lookup_module = LookupModule()
    result = lookup_module.run(['DEFAULT_ROLES_PATH'], ['/test/roles', '/test/roles2'], wantlist=True)
    assert isinstance(result, Sequence)
    assert isinstance(result[0], string_types)

# Generated at 2022-06-23 11:27:54.818566
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Test missing with string 'error'
    try:
        raise MissingSetting('error')
    except MissingSetting as e:
        assert e.orig_exc is None
        assert e.value == 'error'
    else:
        assert False, "MissingSetting should have been raised"

    # Test missing with string 'error', with orig_exc
    err_msg = 'error msg'
    try:
        raise MissingSetting('error', orig_exc=Exception(err_msg))
    except MissingSetting as e:
        assert str(e.orig_exc) == err_msg
        assert e.value == 'error'
    else:
        assert False, "MissingSetting should have been raised"

# Generated at 2022-06-23 11:27:55.769713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 11:28:03.548004
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    x1 = MissingSetting("msg")
    assert isinstance(x1, AnsibleOptionsError)

    # Validate constructor option "orig_exc"
    assert x1.orig_exc is None

    # Validate constructor option "rc"
    assert x1.rc == 0

    # Validate constructor option "cmd"
    assert x1.cmd is None

    # Validate constructor option "stdout"
    assert x1.stdout is None

    # Validate constructor option "stderr"
    assert x1.stderr is None

    # Validate constructor option "msg"
    assert x1.msg == "msg"

# Generated at 2022-06-23 11:28:04.594201
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 11:28:16.496082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys
    import os
    import tempfile
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import builtins

    def get_mocked_lookup(module_paths=None):
        if module_paths is None:
            module_paths = []

        class MockedLookup(LookupModule):
            def __init__(self, *args, **kwargs):
                super(MockedLookup, self).__init__(*args, **kwargs)
                self._plugin_paths = module_paths

            def _load_name_to_path_module(self, name, subdir):
                pass

        return MockedLookup()

    def __getattribute__(self, name):
        return os.getenv