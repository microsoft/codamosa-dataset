

# Generated at 2022-06-23 11:18:14.694885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(('DEFAULT_BECOME_USER','DEFAULT_BECOME_METHOD'), {}, on_missing="skip")
    assert result == ['root', 'sudo'], result

    result = module.run(('DEFAULT_BECOME_USER','DEFAULT_BECOME_METHOD'), {}, on_missing="error")
    assert result == ['root', 'sudo'], result

    result = module.run(('DEFAULT_BECOME_USER','DEFAULT_BECOME_METHOD'), {}, on_missing="warn")
    assert result == ['root', 'sudo'], result

    result = module.run(('DEFAULT_BECOME_USER','DEFAULT_BECOME_METHOD'), {}, plugin_type='shell', plugin_name='sh', on_missing="warn")


# Generated at 2022-06-23 11:18:23.977522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Success case
    # test on missing option with value skip
    # expect result: return empty list
    lookup_obj = LookupModule()
    lookup_obj.set_options(direct={'on_missing': 'skip'})

    try:
        result = lookup_obj.run(terms=['test', 'abc'])
    except Exception as err:
        assert False, 'Unexpected exception raised when "on_missing" option set to "skip": %s' % to_native(err)

    assert result == [], 'Expected result is empty list, but got: %s' % result

    # test on missing option with value warn
    # expect result: return empty list
    lookup_obj.set_options(direct={'on_missing': 'warn'})


# Generated at 2022-06-23 11:18:29.401285
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """
    Ensure that exception can be created with string, tuple or multi-line string exception messages.
    """
    # A string
    msg = 'This is a message.'
    e = MissingSetting(msg)
    assert e.message == msg

    # A tuple or list
    msg = ['This is a multi-line message.', 'This is a second line.']
    e = MissingSetting(tuple(msg))
    assert e.message == '\n'.join(msg)
    e = MissingSetting(list(msg))
    assert e.message == '\n'.join(msg)

# Generated at 2022-06-23 11:18:33.791111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule()
  l._display = type('StringClass', (object,), dict(warning=print))()
  l.set_options(direct=dict(on_missing='error'))
  assert l.run([2]) == 2

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 11:18:41.401538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    lookup_args = {}

    # Ansible `config`
    lookup_args[("DEFAULT_ROLES_PATH",)] = {
        "terms": [("DEFAULT_ROLES_PATH",)],
        "variables": None,
        "plugin_type": None,
        "plugin_name": None
    }

    # Ansible Plugin `config`

# Generated at 2022-06-23 11:18:49.127924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule.
    """
    # Create a dict to pass as environment variables.
    # File lookup_plugins/config.py sets C.DEFAULT_ROLES_PATH as a list containing
    # the values in DEFAULT_ROLES_PATH env variable.
    env_vars_dict = dict()
    env_vars_dict['DEFAULT_ROLES_PATH'] = '~/.ansible/roles'

    # Create a lookup_module object to use in this test.
    lookup_module = LookupModule()

    # Test 1:
    # Input:
    #   config_name = DEFAULT_ROLES_PATH
    #   variables = env_vars_dict
    #   kwargs = {}
    # Expected result:
    #   ['~/.

# Generated at 2022-06-23 11:18:53.497812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()
    assert instance.run(terms=['DEFAULT_REMOTE_TMP']) == ['/home/chris/.ansible/tmp']
    assert instance.run(terms=['PLUGINS_CALLBACK']) == ['yaml']

# Generated at 2022-06-23 11:19:01.271151
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_run(self, terms, variables=None, **kwargs):
        super(LookupModule, self).run(terms, variables, **kwargs)

    LookupModule.run = test_run
    lm = LookupModule()
    lm.get_option = lambda x: None
    lm.get_option.__name__ = 'get_option'
    lm._display = object()
    lm._display.warning = lambda x: None
    lm._display.warning.__name__ = 'warning'
    lm.set_options = lambda x: None
    lm.set_options.__name__ = 'set_options'
    terms = ['ANSIBLE_INVENTORY', 'ANSIBLE_CALLBACK_PLUGINS']
    # run with plugin_name and plugin_type
    kw

# Generated at 2022-06-23 11:19:02.428458
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 11:19:04.546105
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('test')
    assert 'test' == str(exc)

# Generated at 2022-06-23 11:19:06.406069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:19:16.364137
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create object of class LookupModule
    obj = LookupModule()

    # call method run of class LookupModule
    obj.run(terms=['a', 'b'], variables=None, **{'on_missing':'error'})

    # call method run of class LookupModule
    obj.run(terms=['a', 'b'], variables=None, **{'on_missing':'warn'})

    # call method run of class LookupModule
    obj.run(terms=['a', 'b'], variables=None, **{'on_missing':'skip'})

    # call method run of class LookupModule
    obj.run(terms=['a', 'b'], variables=None, **{'plugin_type':'shell', 'plugin_name':'sh', 'on_missing':'error'})

   

# Generated at 2022-06-23 11:19:20.666129
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # Test that settings can be found
    l.run(['DEFAULT_BECOME_METHOD'])
    # Test that settings can be found using custom plugin_type and plugin_name
    l.run(['directory_tree'], plugin_type='vars', plugin_name='filetree')

# Generated at 2022-06-23 11:19:28.837179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["DEFAULT_BECOME_USER", "DEFAULT_ROLES_PATH", "RETRY_FILES_SAVE_PATH", "COLOR_OK", "COLOR_CHANGED", "COLOR_SKIP", "UNKNOWN"]
    options = {"on_missing": "skip"}
    result = lookup_module.run(terms, None, **options)
    assert result == ['root', ['roles', '/usr/share/ansible/roles'], '.ansible/retry', 'green', 'green', 'cyan', None], "LookupModule.run() should return a list"

# Generated at 2022-06-23 11:19:30.910444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = LookupModule().run([])
    assert isinstance(results, list)
    assert not results

# Generated at 2022-06-23 11:19:33.411865
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import LookupModule as test_steps
    test_steps_instance = test_steps()
    assert test_steps_instance

# Generated at 2022-06-23 11:19:38.051773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    If on_missing = 'error', then lookup should throw an error
    """
    lookup = LookupModule()
    with pytest.raises(AnsibleLookupError):
        lookup.run(['foo'], on_missing='error', variables={})

# Generated at 2022-06-23 11:19:48.617671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnreadableVaultError
    from ansible.plugins.lookup.config import LookupModule as LookupModule_config
    import os
    import json

    # create test data
    data = [sentinel.Sentinel(), ['list'], {'dict': sentinel.Sentinel()}]

# Generated at 2022-06-23 11:19:54.799530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # test missing setting
    # test on_missing=error
    try:
        lookup_plugin.run(terms=['UNKNOWN'], variables=None, on_missing='error')
    except AnsibleLookupError as e:
        assert 'did not find setting UNKNOWN' in to_native(e)
        # test on_missing=warn
        lookup_plugin.run(terms=['UNKNOWN'], variables=None, on_native='warn')
    # there should be no exception if on_missing=skip
    lookup_plugin.run(terms=['UNKNOWN'], variables=None, on_native='skip')
    # test known setting
    # test global setting
    result = lookup_plugin.run(terms=['DEFAULT_MODULE_NAME'], variables=None, on_missing='error')

# Generated at 2022-06-23 11:19:55.530713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 11:19:59.549712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # attempt to access a nonexistent setting
    assert module.run(['nonexistent_setting']) == []

    # attempt to access a setting using a plugin option
    assert module.run(['remote_user', 'port'],
                      plugin_type='connection',
                      plugin_name='ssh') == [C.DEFAULT_REMOTE_USER, C.DEFAULT_REMOTE_PORT]

# Generated at 2022-06-23 11:20:06.938731
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    error = MissingSetting('error message')
    assert str(error) == 'error message'
    assert error.orig_exc is None

    another_error = MissingSetting('error message', ValueError('test exception'))
    assert str(another_error) == 'error message'
    assert another_error.orig_exc is not None
    assert isinstance(another_error.orig_exc, ValueError)
    assert str(another_error.orig_exc) == 'test exception'

# Generated at 2022-06-23 11:20:09.436865
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert MissingSetting("msg", None).message == "msg"
    assert MissingSetting("msg", RuntimeError("foo")).message == "msg"

# Generated at 2022-06-23 11:20:19.340343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.lookup_loader import FsLoader
    # empty term test
    lookup_instance = LookupModule(loader=FsLoader())
    assert len(lookup_instance.run([])) == 0
    # test a valid term
    assert len(lookup_instance.run(['inventory_hostnames'])) == 1
    # invalid term test
    try:
        lookup_instance.run(['not.a.real.term'])
    except AnsibleLookupError as e:
        assert "Unable to find setting not.a.real.term" in str(e)
        assert 'was not defined' in str(e.orig_exc)
    # invalid term test, with on_missing skip

# Generated at 2022-06-23 11:20:22.723302
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test error", "test orig_exc")
    except MissingSetting as e:
        assert(e.message == "test error")
        assert(e.orig_exc == "test orig_exc")

# Generated at 2022-06-23 11:20:33.783835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a plugin instance
    plugin = LookupModule()
    # Get a configuration value
    result = plugin.run(terms=['DEFAULT_ROLES_PATH'],
                        variables={'playbook_dir': '/root/ansible/test/test_playbook'},
                        on_missing='error')
    assert result == ['/root/ansible/test/test_playbook/../roles', '/root/ansible/test/test_playbook/roles', '/etc/ansible/roles']
    # Get multiple configuration values
    result = plugin.run(terms=['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'],
                        variables={'playbook_dir': '/root/ansible/test/test_playbook'},
                        on_missing='error')

# Generated at 2022-06-23 11:20:34.974217
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 11:20:35.987945
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 11:20:37.889873
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting("This is missing")
    assert obj.message == "This is missing"
    assert obj.orig_exc is None

# Generated at 2022-06-23 11:20:44.605736
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible import constants as C

    # Test case: lookup global setting
    lookup_mod = LookupModule()
    lookup_mod.set_options(direct={})
    result = lookup_mod.run(terms=['DEFAULT_SUDO_USER'])
    assert result == [C.DEFAULT_SUDO_USER]

    # Test case: lookup plugin setting
    lookup_mod = LookupModule()
    lookup_mod.set_options(direct={'plugin_type':'connection', 'plugin_name':'ssh'})
    result = lookup_mod.run(terms=['remote_user'])
    assert result == [C.DEFAULT_REMOTE_USER]

    # Test case: lookup no setting
    lookup_mod = LookupModule()

# Generated at 2022-06-23 11:20:47.251800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    result = lookup_plugin.run([], {}, on_missing='error')
    assert result == []

# Generated at 2022-06-23 11:20:48.855504
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    MissingSetting(missing_key='missing_key', orig_exc=Exception())

# Generated at 2022-06-23 11:20:50.223745
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    assert str(MissingSetting("Message", AttributeError("attribute error"))) == "Message"

# Generated at 2022-06-23 11:20:51.745465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run([]) == []

# Generated at 2022-06-23 11:20:52.359493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:20:57.463540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    lookup_module = LookupModule()
    lookup_module._display = DummyDisplay()
    terms = ['a','b','c']
    variables = {}
    lookup_module.set_options(var_options=variables, direct={'on_missing': 'error', 'plugin_name': 'ssh', 'plugin_type': 'connection'})
    ret = lookup_module.run(terms, variables)
    assert ret == ['a','b','c']

# Generated at 2022-06-23 11:20:59.901648
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    exc = MissingSetting('Foo not defined')
    assert str(exc) == 'Foo not defined'

# Generated at 2022-06-23 11:21:03.015302
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('Test MissingSetting')
    except MissingSetting as e:
        assert 'Test MissingSetting' in e
        assert not hasattr(e, 'orig_exc')

# Generated at 2022-06-23 11:21:05.045107
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """ Tests the constructor of the class MissingSetting
    """

    exception = AnsibleError('Test')
    missing_setting = MissingSetting('Test message', orig_exc=exception)
    assert missing_setting.orig_exc == exception

# Generated at 2022-06-23 11:21:07.152942
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)



# Generated at 2022-06-23 11:21:09.451669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    module = LookupModule()
    assert module


# Generated at 2022-06-23 11:21:12.793740
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    e = MissingSetting('msg', orig_exc=None)
    assert str(e) == 'msg'
    assert e.errno == 255
    assert e.orig_exc is None
    assert e.kwargs == {'orig_exc': None}
    assert e.message == 'msg'


# Generated at 2022-06-23 11:21:17.253030
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # First, test the type of exception created
    exc = MissingSetting('', '')
    assert isinstance(exc, AnsibleOptionsError)
    assert isinstance(exc, AnsibleError)

    # Then, test the constructor of the exception
    exc = MissingSetting('', '')
    assert exc.message == ''
    assert exc.orig_exc == ''

# Generated at 2022-06-23 11:21:28.727147
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case #1: Test that the config value is properly returned when the setting exists
    module = LookupModule()
    terms = ("DEFAULT_CACHE_PLUGIN",)
    variables = None
    kwargs = {
        'plugin_type': None,
        'plugin_name': None,
        'on_missing': "error",
        '_new_stdin': None,
        '_original_file_name': None,
        '_ansible_no_log': False,
        '_ansible_debug': False,
        '_ansible_check_mode': False
    }
    expected_result = [C.DEFAULT_CACHE_PLUGIN]
    ret = module.run(terms, variables, **kwargs)
    assert ret == expected_result

    # Test case #2: Test

# Generated at 2022-06-23 11:21:37.440535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockDisplay(object):
        def __init__(self):
            self.warnings = []
            self.errors = []
        def warning(self, msg):
            self.warnings.append(msg)
        def error(self, msg, orig_exc=None):
            e = Exception(msg)
            self.errors.append(e)
            if orig_exc is not None:
                e.__cause__ = orig_exc
            raise e

    import sys
    import __main__ as main

    def mock_get_plugin_config(pname, ptype, config, variables):
        if ptype == 'cliconf':
            return {'pname': pname, 'ptype': ptype, 'config': config, 'variables': variables}

        raise MissingSetting(u'Invalid configuration test')

    # missing is

# Generated at 2022-06-23 11:21:45.346278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Tests the method run of class LookupModule.
    :raise: no
    :return: no
    """
    # TODO: This test method can be improved.
    lm = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    variables = {'playbook_dir': '.'}
    result = lm.run(terms, variables=variables)
    assert isinstance(result, list)
    assert isinstance(result[0], string_types)

# Generated at 2022-06-23 11:21:47.191563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:21:53.306565
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test(terms, expected_terms):
        lookup_module = LookupModule()
        lookup_module.run(terms)
        assert terms == expected_terms

    test(['DEFAULT_BECOME_USER'], ['DEFAULT_BECOME_USER'])
    test(['DEFAULT_BECOME_USER', 'remote_user'], ['DEFAULT_BECOME_USER', 'remote_user'])

# Generated at 2022-06-23 11:21:59.397234
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        test_MissingSetting.error_msg = "this is a test error message"
        test_MissingSetting.original_exception = Exception('this is an original exception')
        raise MissingSetting(
            test_MissingSetting.error_msg,
            orig_exc=test_MissingSetting.original_exception
        )
    except MissingSetting as e:
        assert e.orig_msg == test_MissingSetting.error_msg
        assert e.orig_exc == test_MissingSetting.original_exception

# Generated at 2022-06-23 11:22:01.793502
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    obj = MissingSetting(msg="Unable to find setting")

# Generated at 2022-06-23 11:22:05.197320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test passing an invalid type for 'on_missing' option
    #
    # Create an instance of LookupModule
    lm = LookupModule()

    # Call run method which should raise AnsibleOptionsError
    try:
        lm.run(terms=[], variables=None, on_missing=0.1)
    except AnsibleOptionsError as e:
        s = str(e)
        assert "on_missing" in s
        assert "float" in s
    else:
        assert False


# Generated at 2022-06-23 11:22:05.982689
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 11:22:13.993015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_module_utils_module = 'ansible.utils.module_docs_fragments.AnsibleModule'
    mock_module_utils_module_args = {'argument_spec': 'default'}
    mock_module_class = type('AnsibleModule', (object,), dict(run_command=lambda *args: dict(rc=0, stdout=b'', stderr=b'')))

# Generated at 2022-06-23 11:22:23.054788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.compat.tests.mock as mock
    # Instantiate class
    my_object = LookupModule()
    # test_on_missing
    my_object.set_options(var_options={"on_missing": "error"})
    on_missing = my_object.get_option("on_missing")
    assert on_missing == "error"
    # test_valid_config
    my_object.set_options(var_options={"plugin_type": "connection", "plugin_name": "ssh"})
    plugin_type = my_object.get_option("plugin_type")
    plugin_name = my_object.get_option("plugin_name")
    assert plugin_type == "connection" and plugin_name == "ssh"
    # test_invalid_config
    # Invalid values for plugin_

# Generated at 2022-06-23 11:22:26.764558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj.run(terms=['retry_files_save_path', 'inventory_directory'], variables=['/']) == ['/tmp/ansible-retry']

# Generated at 2022-06-23 11:22:31.637740
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    msg = 'foo is undefined'
    exc = AnsibleError('bar is undefined')
    try:
        raise MissingSetting(msg, exc)
    except MissingSetting as ansible_exception:
        assert(str(ansible_exception) == msg)
        assert(ansible_exception.orig_exc.message == exc.message)

# Generated at 2022-06-23 11:22:34.155685
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    with pytest.raises(AnsibleOptionsError):
        MissingSetting('message')

# Generated at 2022-06-23 11:22:44.999691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    constants_plugin_loader = {'connection_loader': 'MockConnectionLoader', 'shell_loader': 'MockShellLoader'}
    plugin_loader.connection_loader = MockConnectionLoader()
    plugin_loader.shell_loader = MockShellLoader()
    l = LookupModule()
    l.set_options(var_options='', direct={'plugin_type': 'connection', 'plugin_name': 'ssh', 'on_missing': 'warn'})
    ret = l.run('REMOTE_USER')
    assert ret == ['user']
    l.set_options(var_options='', direct={'plugin_type': 'connection', 'plugin_name': 'ssh2', 'on_missing': 'warn'})
    ret = l.run('REMOTE_USER')
    assert ret == []

# Generated at 2022-06-23 11:22:46.162294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test that the object is initialized correctly
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)


# Generated at 2022-06-23 11:22:53.138317
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # test with default Message
    try:
        m = MissingSetting("")
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert str(e) == 'A settings has not been defined'

    # test with custom Message
    try:
        m = MissingSetting("A custom Message")
    except MissingSetting as e:
        assert isinstance(e, MissingSetting)
        assert str(e) == 'A custom Message'

# Generated at 2022-06-23 11:22:57.448477
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    term = 'test'
    obj = MissingSetting(term)
    assert obj.orig_exc == None and obj.term == term
    term = 'test_with_orig'
    obj = MissingSetting(term, 'my original exception')
    assert obj.orig_exc == 'my original exception' and obj.term == term

# Generated at 2022-06-23 11:23:02.707995
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    from ansible.errors import AnsibleLookupError
    m = MissingSetting(message='This is a test')
    assert m.message == 'This is a test'
    assert m.orig_exc is None
    m = MissingSetting(message='This is a test', orig_exc=AnsibleLookupError('this is the cause of the problem'))
    assert m.message == 'This is a test'
    assert m.orig_exc == 'this is the cause of the problem'
    assert m.to_dict() == {'message': 'This is a test', 'orig_exc': 'this is the cause of the problem'}

# Generated at 2022-06-23 11:23:08.936050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = lookup()
    lookup._display = Display()
    lookup.set_options(direct=dict(on_missing='error'))
    lookup._get_plugin_config = Mock(return_value=True)
    lookup._get_global_config = Mock(return_value=True)
    terms = ['foo', 'bar']
    res = lookup.run(terms=terms, variables=None)
    assert res[0] and res[1]

# Generated at 2022-06-23 11:23:12.983552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER']
    m = LookupModule()
    result = m.run(terms)
    assert(result[0] == 'root')



# Generated at 2022-06-23 11:23:13.871322
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    raise MissingSetting

# Generated at 2022-06-23 11:23:20.436966
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    """Test if MissingSetting works correctly when it's instantiated."""
    # instantiate the class with 'msg' and 'orig_exc' arguments
    class_missing_setting = MissingSetting('the key is missing in the config', 'the key is not found')
    # assert that the class is instantiated correctly
    assert class_missing_setting.msg == 'the key is missing in the config'
    assert class_missing_setting.orig_exc == 'the key is not found'


# Generated at 2022-06-23 11:23:23.093329
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert hasattr(lookup_module,'run')
    assert hasattr(lookup_module,'set_options')



# Generated at 2022-06-23 11:23:32.308521
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookupModule = LookupModule()
    options = {}
    lookupModule.set_options(var_options=options)
    assert(lookupModule.get_option('on_missing') == 'error')

    options['on_missing'] = 'skip'
    lookupModule.set_options(var_options=options)
    assert(lookupModule.get_option('on_missing') == 'skip')

    options['on_missing'] = 'warn'
    lookupModule.set_options(var_options=options)
    assert(lookupModule.get_option('on_missing') == 'warn')

    options['on_missing'] = 'ERROR'
    with pytest.raises(AnsibleOptionsError):
        lookupModule.set_options(var_options=options)

    options['on_missing'] = 'SKIP'
   

# Generated at 2022-06-23 11:23:34.865300
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # make sure we get a LookupModule instance
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 11:23:39.544807
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)
    # No exception if constructed LookupModule without variables and kwargs
    LookupModule(variables={}, direct={})


# Generated at 2022-06-23 11:23:40.770467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm

# Generated at 2022-06-23 11:23:48.239452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = []
    lk = LookupModule()
    lk.set_options()
    try:
        result = lk.run(['DEFAULT_ROLES_PATH'])
    except Exception as e:
        print("Error: {0}".format(e))
        print(type(e))
        print(e.args)
        raise

    if len(result) != 1:
        print("testLookupModule_run: Fail: Result not as expected. Expected length = 1. Actual length = {0}".format(len(result)))
        print("testLookupModule_run: Fail: Result not as expected. Expected value = {0}. Actual value = {1}".format(['/etc/ansible/roles'], result))
        return False

# Generated at 2022-06-23 11:23:50.807192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['COLOR_ERROR'], {'A': 1, 'B': 2}) == [C.COLOR_ERROR]


# Generated at 2022-06-23 11:23:59.706433
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader as plugin_loader
    from ansible.module_utils.ansible_modlib.common.collections import ImmutableDict

    # test to make sure exceptions are raised for invalid options in plugin config
    def test_get_plugin_config_exceptions():
        pname = 'invalid_plugin_name'
        ptype = 'shell'
        config = 'remote_tmp'
        variables = {}
        try:
            _get_plugin_config(pname, ptype, config, variables)
        except AnsibleLookupError as e:
            assert 'Unable to load %s plugin "%s"' % (ptype, pname) in to_native(e)
        pname = 'sh'
        ptype = 'shell'

# Generated at 2022-06-23 11:24:00.558397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule  # silence pyflakes

# Generated at 2022-06-23 11:24:10.140593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(direct={'on_missing': 'skip'})
    l.set_options(var_options={})
    assert '' != l.run(['DEFAULT_REMOTE_USER'])[0]
    assert 'skip' == l.get_option('on_missing')
    assert '' == l.run(['UNKNOWN_KEY'])[0]
    assert [] == l.run(['NOTKNOWN_KEY'], on_missing='error')[0]
    assert [] == l.run(['NOTKNOWN_KEY'], on_missing='warn')[0]
    assert [] == l.run(['NOTKNOWN_KEY'], on_missing='skip')[0]

# Generated at 2022-06-23 11:24:18.309642
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    # Test case when config value is not set
    try:
        module.run(terms=["UNKNOWN"], on_missing='error')
    except Exception as e:
        assert type(e) == AnsibleLookupError

    # Test case when config value is present
    assert len(module.run(terms=["DEFAULT_BECOME_USER"], on_missing='error')) == 1

    # Test case when multiple config values are present
    results = module.run(terms=["DEFAULT_BECOME_USER", "DEFAULT_SUDO_EXE"], on_missing='error')
    assert len(results) == 2
    assert results[0] == "root"
    assert results[1] == "sudo"

    # Test case when config value is missing and on_missing is set to skip
   

# Generated at 2022-06-23 11:24:21.619170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = []
    module = LookupModule()
    term = 'COLOR_OK'
    ret = module.run(term, variables=None)
    print(ret)



# Generated at 2022-06-23 11:24:29.407284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create object of class LookupModule
    obj_lookup_module = LookupModule()

    # Create a list of ansible configuration setting identifiers
    terms = ['DEFAULT_REMOTE_TMP', 'DEFAULT_REMOTE_USER']

    # Get the values of ansible configuration settings corresponding to terms
    ret = obj_lookup_module.run(terms, variables=None)

    # Check if the return type is a list
    assert isinstance(ret, list)

    # Check if the return list contains more than one element
    assert len(ret) > 1

    # Check the return value of one of the ansible configuration settings
    # The return value should be the string value of the ansible configuration setting
    assert ret[0] == '/tmp/ansible-${USER}'

# Generated at 2022-06-23 11:24:40.494778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run()')

    terms = ('DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH')
    variables = {'_ansible_check_mode': True}

# Generated at 2022-06-23 11:24:42.644553
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("test message")
    except MissingSetting as e:
        assert e.message == "test message"

# Generated at 2022-06-23 11:24:45.227190
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    t = MissingSetting("Lookup failed for %s", orig_exc='foo')
    assert t.message == "Lookup failed for %s"
    assert t.orig_exc == 'foo'

# Generated at 2022-06-23 11:24:54.395949
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # the first param of the LookupModule instance is [0] in the args list
    # the second param of the LookupModule instance is [1] in the args list
    # the third param of the LookupModule instance is [2] in the args list

    lookup = LookupModule(None, None, None)

    assert lookup.run([1, 2], variables=None, **{}) == []
    assert lookup.run(None, variables=None, **{}) == []
    assert lookup.run(["junk1", "junk2"], variables=None, **{}) == []
    assert lookup.run(["remote_user", "junk2"], variables=None, **{}) == []
    assert lookup.run(["junk1", "remote_user"], variables=None, **{}) == []

# Generated at 2022-06-23 11:25:05.238500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock ansible.utils.display.Display class
    class MockDisplay:
        class Display:
            def __init__(self):
                self.warnings = []

            def warning(self, message):
                self.warnings.append(message)

    # mock ansible.plugins.loader.action_loader class
    class MockAction_loader:
        class ActionLoader:
            def get(self, pname, **kwargs):
                return self

            @property
            def _load_name(self):
                return 'testplugin'

    # mock ansible.plugins.cache.CacheModule class
    class MockCacheModule:
        class CacheModule:
            def __init__(self, *args, **kwargs):
                pass

            def get_basedir(self, variables):
                return '/some/cache/dir'

    #

# Generated at 2022-06-23 11:25:07.804095
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    err = MissingSetting('MissingSetting', orig_exc=None)
    assert isinstance(err, AnsibleError)
    assert isinstance(err, AnsibleOptionsError)

# Generated at 2022-06-23 11:25:13.029322
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Simple run test for method run of class LookupModule
    lu = LookupModule()
    lu.set_options(var_options={'ansible_user':'deepak'}, direct={'plugin_type':'connection','plugin_name':'ssh'})
    result = lu.run(['remote_user','port'])

    # Checks if LookupModule class's run method returns a runnable object
    assert result is not None

# Generated at 2022-06-23 11:25:15.898359
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Call constructor of class MissingSetting
    msg = 'msg'
    orig_exc = 'orig_exc'
    ms = MissingSetting(msg, orig_exc)
    assert ms.message == msg
    assert ms.orig_exc == orig_exc

# Generated at 2022-06-23 11:25:25.410850
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    # Empty input
    err = MissingSetting()
    assert err is not None

    # 1 simple input
    err = MissingSetting('Some error message')
    assert err.msg == 'Some error message'
    assert err.orig_exc is None

    # 2 inputs
    err = MissingSetting('Some error message', 'orig. exception')
    assert err.msg == 'Some error message'
    assert err.orig_exc == 'orig. exception'

    # 3 inputs
    err = MissingSetting('Some error message', 'orig. exception', 'Some detail')
    assert err.msg == 'Some error message'
    assert err.orig_exc == 'orig. exception'
    assert err.detail == 'Some detail'

# Generated at 2022-06-23 11:25:36.080371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()

    # Case 1: check the execution of run method when on_missing = error and config = 'DEFAULT_REMOTE_USER'
    terms = ['DEFAULT_REMOTE_USER']
    expected_result = [u'root']
    lookup_obj.set_options(direct={'on_missing': 'error'})
    result = lookup_obj.run(terms, variables=None)
    assert result == expected_result, \
        'Expected: %s, but returned: %s' % (expected_result, result)

    # Case 2: check the execution of run method when on_missing = warn and config = 'UNKNOWN'
    terms = ['UNKNOWN']
    expected_result = []
    lookup_obj.set_options(direct={'on_missing': 'warn'})
    result = lookup

# Generated at 2022-06-23 11:25:44.897156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # test with missing option on_missing (required)
  lookup_plugin = LookupModule()
  assert lookup_plugin.run([]) == [], 'Missing option "on_missing" should have returned an empty list.'

  # test when on_missing option is set to error
  lookup_plugin = LookupModule(on_missing='error')
  assert lookup_plugin.run([]) == [], 'Missing option "on_missing" should have returned an empty list.'

  # test when on_missing option is set to skip
  lookup_plugin = LookupModule(on_missing='skip')
  assert lookup_plugin.run([]) == [], 'Missing option "on_missing" should have returned an empty list.'

  # test when on_missing option is set to warn
  lookup_plugin = LookupModule(on_missing='warn')
  assert lookup_plugin

# Generated at 2022-06-23 11:25:51.278298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ptype = 'shell'
    terms = ['remote_tmp', 'remote_tmp', 'remote_tmp']
    assert lookup_module.run(terms, plugin_name='sh', plugin_type=ptype) == ['${HOME}/.ansible/tmp', '${HOME}/.ansible/tmp', '${HOME}/.ansible/tmp']


# Generated at 2022-06-23 11:25:54.633530
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting
    except MissingSetting as e:
        assert "AnsibleOptionsError" in repr(e)


# Helper function

# Generated at 2022-06-23 11:25:56.788324
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None, "Cannot create LookupModule object"

# Generated at 2022-06-23 11:26:00.092847
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('TEST')
    except MissingSetting as e:
        assert isinstance(e, AnsibleOptionsError)
        assert isinstance(e, AnsibleError)
        assert str(e) == 'TEST'

# Generated at 2022-06-23 11:26:01.673928
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

    assert x
    assert x._display
    assert x.options

# Generated at 2022-06-23 11:26:04.478666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_CACHE_PLUGIN'])[0] == 'memory'


# Generated at 2022-06-23 11:26:05.508490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule.__doc__)

# Generated at 2022-06-23 11:26:15.205922
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test LookupModule constructor fails with missing terms
    terms = []
    with pytest.raises(AnsibleOptionsError) as excinfo:
        LookupModule(terms)
    result = to_text(excinfo.value)
    assert "must supply value for '_terms'" in result

    # Test LookupModule constructor fails with missing option
    terms = ['DEFAULT_BECOME_USER']
    with pytest.raises(AnsibleOptionsError) as excinfo:
        LookupModule(terms, options={'on_missing': 'fail'})
    result = to_text(excinfo.value)
    assert "must supply value for 'on_missing'" in result

    # Test LookupModule constructor fails with missing plugin_type and plugin_name
    terms = ['remote_user']

# Generated at 2022-06-23 11:26:17.947636
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_config():
        module = LookupModule()
        assert module
        #
        # module.set_options()
        # module.run()
    test_config()

# Generated at 2022-06-23 11:26:19.668464
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ret = MissingSetting("test_msg", "test_exc")
    assert "test_exc" == str(ret)

# Generated at 2022-06-23 11:26:21.219155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, '_templar')

# Generated at 2022-06-23 11:26:23.577414
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    msg = 'test msg'
    orig_exc = 'test exception'

    err = MissingSetting(msg, orig_exc=orig_exc)
    assert err.message == msg
    assert err.orig_exc == orig_exc

# Generated at 2022-06-23 11:26:25.267198
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule() is not None)

# Generated at 2022-06-23 11:26:29.028910
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    # Create a Mock object for the class display and attach it to the instance of LookupModule class
    lookup_module.set_display(Mock())
    assert lookup_module.get_option('on_missing') == "error"

# Generated at 2022-06-23 11:26:33.884644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        clsmembers = dict(inspect.getmembers(LookupModule))
        if 'run' in clsmembers:
            return True
        else:
            return False
    except Exception:
        return False

# Generated at 2022-06-23 11:26:43.264051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up mock for LookupBase class
    lookup_base = LookupBase()
    lookup_base.display = None

    lookup_module = LookupModule()
    lookup_module.display = None
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        # fail when trying to get an invalid setting
        lookup_module.run([None])
        # fail when on_missing param is not valid
        lookup_module.run(['foo'])
    except AnsibleOptionsError:
        pass
    else:
        assert False
    # fail when trying to get a plugin setting missing the plugin_name param
    try:
        lookup_module.run(['foo'], plugin_type='shell')
    except AnsibleOptionsError:
        pass
    else:
        assert False

# Generated at 2022-06-23 11:26:46.033760
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # prep
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS']
    variables = {'PORT': '1863'}
    kwargs = {'on_missing': 'warn'}

    # execute
    lu = LookupModule()
    ret = lu.run(terms, variables, **kwargs)

    # verify
    assert len(ret) == 2
    assert ret[0] == 'root'
    assert ret[1] == '~ANSIBLE_VAULT~'


# Generated at 2022-06-23 11:26:54.130755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._display = {
        'warning': lambda *args, **kwargs: None
    }
    # Normalize returns because dict order isn't constant
    assert sorted(lookup.run(['DEFAULT_REMOTE_USER'], dict())) == sorted(['root'])
    assert not lookup.run(['DEFAULT_REMOTE_USER'], dict(on_missing='skip'))
    assert not lookup.run(['UNKNOWN'], dict(on_missing='skip'))
    assert not lookup.run(['UNKNOWN', 'DEFAULT_REMOTE_USER'], dict(on_missing='skip'))
    assert not lookup.run(['DEFAULT_REMOTE_USER', 'UNKNOWN'], dict(on_missing='skip'))

    from ansible.errors import AnsibleLookupError
   

# Generated at 2022-06-23 11:26:55.462073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm,LookupModule)

# Generated at 2022-06-23 11:26:56.773193
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    ex = MissingSetting('message')
    assert ex.message == 'message'
    assert isinstance(ex, AnsibleError)

# Generated at 2022-06-23 11:26:59.059198
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting("This is an error message")
    except Exception as e:
        assert e.message == "This is an error message"

# Generated at 2022-06-23 11:27:00.596336
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        raise MissingSetting('test')
    except MissingSetting:
        pass

# Generated at 2022-06-23 11:27:02.834395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test if the constructor returns the type LookupModule
    assert(isinstance(LookupModule(),LookupModule))

# Generated at 2022-06-23 11:27:05.847632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    lookup_module.run(terms)

# Generated at 2022-06-23 11:27:09.978795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["UNKNOWN", "C.DEFAULT_ROLES_PATH"]
    result = module.run(terms, dict())
    assert result == ['/etc/ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-23 11:27:18.480781
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This is to test function _get_global_config
    
    # This will fail because setting of that name is not found
    class fakeVars(object):
        def __init__(self):
            self.names = []

        def get(self,name,default=None,search_params=[]):
            self.names.append(name)
            return None

        def keys(self):
            return []

        def __getitem__(self,name):
            return None

        def __setitem__(self,name,val):
            self.names.append(name)

    variables = fakeVars()
    config = 'FAKE_CONFIG'

    try:
        _get_global_config(config)
    except MissingSetting as e:
        msg = to_native(e)

# Generated at 2022-06-23 11:27:20.402893
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestClass(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return [1]
    loader = plugin_loader.LookupModuleLoader()
    results = loader.get(TestClass, class_only=True)
    assert results == 1

# Generated at 2022-06-23 11:27:30.425434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    # Create dict with valid plugin type and invalid plugin name
    terms = dict(plugin_type = "vars", plugin_name = "no_exist")
    assert l.run(terms) == "plugin_name cannot be empty"
    # Create dict with valid plugin type and valid plugin name
    terms = dict(plugin_type = "vars", plugin_name = "hostvars")
    assert l.run(terms)["hostvars"] == "hostvars.yml"
    # Create dict with invalid plugin type and valid plugin name
    terms = dict(plugin_type = "invalid_type", plugin_name = "hostvars")
    assert l.run(terms) == "invalid_type is not a supported plugin type"
    # Create dict with valid plugin type and valid plugin name and invalid setting
    terms

# Generated at 2022-06-23 11:27:42.319720
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    # Try to raise exception with no args
    try:
        raise MissingSetting()
    except MissingSetting:
        pass
    else:
        assert False, 'Raising MissingSetting() did not work'

    # Try to raise exception with only 'msg'
    try:
        raise MissingSetting('msg')
    except MissingSetting:
        pass
    else:
        assert False, 'Raising MissingSetting("msg") did not work'

    # Try to raise exception with only 'orig_ex'
    try:
        raise MissingSetting(orig_ex=AnsibleError())
    except MissingSetting:
        pass
    else:
        assert False, 'Raising MissingSetting(orig_ex=AnsibleError("msg")) did not work'

    # Try to raise exception with both 'msg' and 'orig_ex'

# Generated at 2022-06-23 11:27:44.961008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupBase)
    if hasattr(lookup_obj, 'run'):
        lookup_obj.run()

# Generated at 2022-06-23 11:27:49.097397
# Unit test for constructor of class MissingSetting
def test_MissingSetting():
    try:
        temp = MissingSetting("test")
    except Exception as x:
        assert False, "Unexpected exception was raised: " + str(x)
    else:
        assert isinstance(temp, MissingSetting)



# Generated at 2022-06-23 11:27:53.694089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    config_vars = dict()
    config_vars['ANSIBLE_NOCOWS'] = 1
    terms = ["ANSIBLE_NOCOWS"]
    ret = lookup.run(terms, config_vars)
    print(ret)

# Generated at 2022-06-23 11:27:57.254183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    variables = {'key1': 'value1'}
    lookup_plugin.set_options(var_options=variables, direct={'on_missing': 'error'})



# Generated at 2022-06-23 11:27:59.135028
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["DEFAULT_ROLES_PATH"]
    variables = {}
    config = LookupModule()
    config.run(terms)

# Generated at 2022-06-23 11:28:07.520416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_options = {'on_missing':
                      {'required': False, 'type': 'str', 'choices': ['error', 'skip', 'warn'], 'default': 'error'},
                      'plugin_type':
                      {'required': False, 'type': 'str', 'choices':
                          ['become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup',
                           'netconf', 'shell', 'vars']},
                      'plugin_name':
                      {'required': False, 'type': 'str'}}
    setattr(C, 'DEFAULT_BECOME_USER', 'test_user')
    setattr(C, 'DEFAULT_ROLES_PATH', '/test/roles/path')

# Generated at 2022-06-23 11:28:10.311173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run('ANSIBLE_CONFIG') is not None

# Generated at 2022-06-23 11:28:12.718136
# Unit test for constructor of class MissingSetting
def test_MissingSetting():

    exc_obj = MissingSetting('foo')
    assert exc_obj.message == 'foo'
    assert exc_obj.orig_exc is None