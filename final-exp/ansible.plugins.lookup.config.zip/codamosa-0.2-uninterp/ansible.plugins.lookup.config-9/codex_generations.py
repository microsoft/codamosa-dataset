

# Generated at 2022-06-17 12:15:46.619904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'invalid'})
    result = lookup_module.run(['remote_tmp'])
    assert result == []

    # Test with invalid plugin_type and valid plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:15:55.261223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:16:07.030843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512371205.34-242533001578983']

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh1'})
    try:
        result = lookup_module.run(['remote_tmp'])
    except AnsibleLookupError as e:
        assert 'Unable to load shell plugin "sh1"' in to_

# Generated at 2022-06-17 12:16:11.750022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='error') == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='warn') == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='skip') == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='error', plugin_type='become', plugin_name='sudo') == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='warn', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:16:19.361789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel

    # Setup
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config/tests')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/tests')

# Generated at 2022-06-17 12:16:29.921196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:16:40.729148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of class LookupModule
    # Args:
    #    None
    # Returns:
    #    None
    # Raises:
    #    None

    # test run method of class LookupModule
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root']

    # test run method of class LookupModule
    lookup_module = LookupModule()
    terms = ['DEFAULT_ROLES_PATH']
    variables = None
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-17 12:16:44.849124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result[0] == '$HOME/.ansible/tmp'

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result[0] == '$HOME/.ansible/tmp'

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:16:48.217861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 12:16:57.669787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid on_missing value
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='invalid') == []

    # Test with valid on_missing value
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='error') == ['root']

    # Test with invalid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['remote_user'], variables=None, plugin_type='invalid', plugin_name='invalid') == []

    # Test with valid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-17 12:17:13.472491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid_plugin_name'})

# Generated at 2022-06-17 12:17:21.948822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1515653552.8-240786788490148']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:32.508374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test for missing setting
    try:
        lookup.run(['UNKNOWN_SETTING'], dict(), on_missing='error')
        assert False
    except AnsibleLookupError:
        pass
    # Test for missing plugin
    try:
        lookup.run(['remote_tmp'], dict(), plugin_type='shell', plugin_name='UNKNOWN_PLUGIN', on_missing='error')
        assert False
    except AnsibleLookupError:
        pass
    # Test for missing plugin_type
    try:
        lookup.run(['remote_tmp'], dict(), plugin_name='sh', on_missing='error')
        assert False
    except AnsibleOptionsError:
        pass
    # Test for missing plugin_name

# Generated at 2022-06-17 12:17:42.867921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512473579.13-132567770188882']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])

# Generated at 2022-06-17 12:17:54.837788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    ptype = 'shell'
    pname = 'sh'
    variables = None
    lookup = LookupModule()
    result = lookup.run(terms, variables, plugin_type=ptype, plugin_name=pname)
    assert result == ['/tmp/ansible-tmp-1523553388.86-140465187859097']

    # Test with plugin_type and plugin_name
    terms = ['remote_user']
    ptype = 'connection'
    pname = 'ssh'
    variables = None
    lookup = LookupModule()
    result = lookup.run(terms, variables, plugin_type=ptype, plugin_name=pname)
    assert result == ['root']

    # Test with plugin_type and

# Generated at 2022-06-17 12:17:59.045393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:18:09.804851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid setting
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with an invalid setting
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['UNKNOWN']) == []

    # Test with an invalid setting and on_missing set to error
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'on_missing': 'error'})
    try:
        lookup_plugin.run(['UNKNOWN'])
        assert False
    except AnsibleLookupError:
        assert True

    # Test with an invalid setting and on_missing set to warn
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:18:20.437140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(terms=['remote_user'])
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(terms=['remote_tmp'])
    assert result == ['/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:18:27.913362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh'
    variables = None
    result = lookup_module.run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh'
    variables = None
    result = lookup_module.run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == ['/tmp/ansible-${USER}']

# Generated at 2022-06-17 12:18:40.752778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(['DEFAULT_BECOME_USER'])
    lookup_module.run(['DEFAULT_BECOME_USER'], on_missing='warn')
    lookup_module.run(['DEFAULT_BECOME_USER'], on_missing='skip')
    lookup_module.run(['DEFAULT_BECOME_USER'], on_missing='error')
    lookup_module.run(['DEFAULT_BECOME_USER'], on_missing='error', plugin_type='become', plugin_name='sudo')
    lookup_module.run(['DEFAULT_BECOME_USER'], on_missing='error', plugin_type='become', plugin_name='sudo')
   

# Generated at 2022-06-17 12:19:06.053678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    # Test case with missing plugin_type and plugin_name
    # Expected result: AnsibleOptionsError
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['remote_user'])

    # Test case 2
    # Test case with missing plugin_name
    # Expected result: AnsibleOptionsError
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['remote_user'])

    # Test case 3

# Generated at 2022-06-17 12:19:17.241999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})

    # test for invalid 'on_missing' option
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='invalid')
        assert False
    except AnsibleOptionsError:
        assert True

    # test for invalid 'plugin_type' option
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, plugin_type='invalid')
        assert False
    except AnsibleOptionsError:
        assert True

    # test for invalid 'plugin_name' option

# Generated at 2022-06-17 12:19:27.270883
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:19:31.474741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {}
    result = lm.run(terms, variables, **kwargs)
    assert result == ['root']


# Generated at 2022-06-17 12:19:42.350615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(terms=['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)
    else:
        assert False, 'AnsibleLookupError not raised'

    # Test for invalid on_missing value
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'invalid'})

# Generated at 2022-06-17 12:19:48.475593
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:19:57.376478
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:20:08.621675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    except AnsibleOptionsError as e:
        assert 'Missing required connection option' in to_native(e)

    # Test with invalid on_missing option
    lookup_module.set_options(var_options={}, direct={'on_missing': 'invalid'})
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)

    # Test with invalid

# Generated at 2022-06-17 12:20:20.957479
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:20:27.191450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in str(e)
    else:
        assert False, 'AnsibleLookupError not raised'

    # Test for missing plugin
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'UNKNOWN'})
    try:
        lookup_module.run(['remote_tmp'])
    except AnsibleLookupError as e:
        assert 'Unable to load shell plugin "UNKNOWN"' in str(e)

# Generated at 2022-06-17 12:21:06.043854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    assert lookup_module.run(terms=['remote_user']) == []

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    assert lookup_module.run(terms=['remote_user']) == []

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'invalid'})
    assert lookup_

# Generated at 2022-06-17 12:21:16.410171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1528378023.03-251548653949094']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:21:21.281588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with on_missing=error
    try:
        lookup_module.run(['UNKNOWN'], on_missing='error')
    except AnsibleLookupError:
        pass
    else:
        assert False, 'AnsibleLookupError not raised'

    # test with on_missing=warn
    lookup_module.run(['UNKNOWN'], on_missing='warn')

    # test with on_missing=skip
    assert lookup_module.run(['UNKNOWN'], on_missing='skip') == []

    # test with plugin_type and plugin_name
    assert lookup_module.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == ['/tmp']

    # test with plugin_type and plugin_name

# Generated at 2022-06-17 12:21:32.449027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    lookup_module.run(['DEFAULT_BECOME_USER'])
    lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'])
    lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'playbook_dir': '.'})
    lookup_module.set_options(direct={'on_missing': 'warn'})
    lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'])
    lookup_module.set_options(direct={'on_missing': 'skip'})

# Generated at 2022-06-17 12:21:42.451161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:21:51.566530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with an invalid term
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['INVALID_TERM']) == []

    # Test with an invalid term and on_missing set to error
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'on_missing': 'error'})
    try:
        lookup_plugin.run(['INVALID_TERM'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting INVALID_TERM' in to_native(e)

    # Test with an invalid term and on_missing set to warn
    lookup_

# Generated at 2022-06-17 12:21:58.597296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    lookup_module.set_options(direct={'on_missing': 'warn'})
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'UNKNOWN_SETTING']) == ['root', 'sudo']
    lookup_module.set_options(direct={'on_missing': 'skip'})

# Generated at 2022-06-17 12:22:03.840330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'])
    lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'DEFAULT_ROLES_PATH': '/tmp/roles'})
    lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'DEFAULT_ROLES_PATH': '/tmp/roles'}, on_missing='warn')

# Generated at 2022-06-17 12:22:13.720451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['remote_user'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['remote_user'])

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options

# Generated at 2022-06-17 12:22:21.558218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a variable
    variable = {'ansible_ssh_port': '22'}

    # Create a term
    term = 'ansible_ssh_port'

    # Create a list of terms
    terms = [term]

    # Create a variable
    variables = variable

    # Create a kwargs
    kwargs = {}

    # Test the method run of class LookupModule
    result = lookup_module.run(terms, variables, **kwargs)

    # Assert the result
    assert result == [22]

# Generated at 2022-06-17 12:23:31.065362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')

# Generated at 2022-06-17 12:23:40.464657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='warn') == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='skip') == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='error') == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='error') == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='error') == ['root']
    assert lookup

# Generated at 2022-06-17 12:23:51.857614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with invalid plugin_type
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], plugin_type='invalid_plugin_type', plugin_name='ssh')
    except AnsibleOptionsError as e:
        assert 'plugin_type must be one of' in to_native(e)
    # Test with invalid plugin_name
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], plugin_type='connection', plugin_name='invalid_plugin_name')
    except AnsibleLookupError as e:
        assert 'Unable to load connection plugin "invalid_plugin_name"' in to_native(e)
    # Test with invalid on_missing

# Generated at 2022-06-17 12:24:00.378566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import os
    import sys
    import json
    import pytest


# Generated at 2022-06-17 12:24:12.128740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={}, direct={})
    assert l.run(['DEFAULT_BECOME_USER']) == ['root']
    assert l.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS']) == ['root', None]
    assert l.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS', 'DEFAULT_BECOME_METHOD']) == ['root', None, 'sudo']
    assert l.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_PASS', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_FLAGS']) == ['root', None, 'sudo', '']

# Generated at 2022-06-17 12:24:22.342295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:24:36.776709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS']) == ['root', 'sudo', None]
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS', 'DEFAULT_BECOME_EXE']) == ['root', 'sudo', None, 'sudo']

# Generated at 2022-06-17 12:24:43.884459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['UNKNOWN_ROLES_PATH'], variables={}, on_missing='warn')
    lookup_module.run(terms=['UNKNOWN_ROLES_PATH'], variables={}, on_missing='skip')
    lookup_module.run(terms=['UNKNOWN_ROLES_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['UNKNOWN_ROLES_PATH'], variables={}, on_missing='warn')

# Generated at 2022-06-17 12:24:55.374490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.module_utils.six import PY3
    import ansible.plugins.loader as plugin_loader
    import ansible.constants as C
    import ansible.errors as errors
    import ansible.module_utils.six as six
    import ansible.utils.sentinel as sentinel
    import ansible.module_utils._text as text
    import ansible.plugins.lookup as lookup
    import ansible.module_utils.basic as basic
   

# Generated at 2022-06-17 12:25:06.095814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    terms = ['DEFAULT_BECOME_USER']
    result = LookupModule().run(terms, variables=None, **{})
    assert result == ['root']

    # Test with a invalid term
    terms = ['DEFAULT_BECOME_USERS']
    try:
        result = LookupModule().run(terms, variables=None, **{})
    except AnsibleLookupError as e:
        assert 'Unable to find setting DEFAULT_BECOME_USERS' in to_native(e)

    # Test with a invalid term and on_missing as warn
    terms = ['DEFAULT_BECOME_USERS']
    result = LookupModule().run(terms, variables=None, **{'on_missing': 'warn'})
    assert result == []

    # Test with a