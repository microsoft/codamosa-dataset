

# Generated at 2022-06-17 12:15:42.827218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()
    # Create a variable
    variable = 'DEFAULT_BECOME_USER'
    # Create a list of terms
    terms = [variable]
    # Create a variable for plugin_type
    plugin_type = 'become'
    # Create a variable for plugin_name
    plugin_name = 'sudo'
    # Create a variable for on_missing
    on_missing = 'error'
    # Create a variable for variables
    variables = None
    # Call method run of class LookupModule
    result = lookup_module.run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name, on_missing=on_missing)
    # Assert the result
    assert result == ['root']

# Generated at 2022-06-17 12:15:53.816561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp']

    # Test with plugin_type and plugin_name but invalid plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'invalid'})
    try:
        lookup_plugin.run(['remote_tmp'])
    except AnsibleLookupError as e:
        assert 'Unable to load shell plugin "invalid"' in to_native(e)

    # Test with plugin_type and plugin_name

# Generated at 2022-06-17 12:16:05.184489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'invalid_plugin_name'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(terms=['invalid_term'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(excinfo.value)

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'invalid_on_missing'})

# Generated at 2022-06-17 12:16:15.544530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid_type', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'plugin_type must be one of' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid_name'})

# Generated at 2022-06-17 12:16:19.042629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=["DEFAULT_BECOME_USER"])

# Generated at 2022-06-17 12:16:29.694809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp/ansible-tmp-1515123957.04-184713997977982']
    # Test with plugin_type and plugin_name
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_plugin.run(['remote_user', 'port']) == ['root', 22]
    # Test with plugin_type and plugin_name

# Generated at 2022-06-17 12:16:34.592291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:16:42.154595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(terms=['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1539897332.9-271323651516077']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(terms=['remote_tmp'])

# Generated at 2022-06-17 12:16:50.116071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:16:59.688346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp']

    # Test with plugin_type and plugin_name and on_missing
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'warn'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp']

    # Test with plugin_type and plugin_name and on_missing
    lookup_plugin = LookupModule()
    lookup_plugin.set_

# Generated at 2022-06-17 12:17:21.978177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:32.508718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with invalid plugin_type
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], plugin_type='invalid', plugin_name='ssh')
        assert False
    except AnsibleOptionsError:
        pass
    # test with invalid plugin_name
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], plugin_type='connection', plugin_name='invalid')
        assert False
    except AnsibleLookupError:
        pass
    # test with invalid on_missing
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='invalid')
        assert False
    except AnsibleOptionsError:
        pass
    # test with invalid term
   

# Generated at 2022-06-17 12:17:42.828134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER']) == [C.DEFAULT_BECOME_USER]
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='skip') == [C.DEFAULT_BECOME_USER]
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='warn') == [C.DEFAULT_BECOME_USER]
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='error') == [C.DEFAULT_BECOME_USER]

# Generated at 2022-06-17 12:17:54.806140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(terms=['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512779839.94-246945774900963']

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh1'})
    result = lookup_module.run(terms=['remote_tmp'])
    assert result == []

    # Test with invalid plugin_type and valid plugin

# Generated at 2022-06-17 12:18:05.664557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['remote_tmp'], plugin_type='shell', plugin_name='sh') == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['remote_user'], plugin_type='connection', plugin_name='ssh') == ['root']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['remote_user'], plugin_type='connection', plugin_name='local') == ['root']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:18:13.482498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables={}, on_missing='error', wantlist=True)
    lookup_module.run(terms=['UNKNOWN'], variables={}, on_missing='skip')

# Generated at 2022-06-17 12:18:21.004533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_type', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'plugin_type must be one of' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid_name'})
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_module.run(['remote_user'])

# Generated at 2022-06-17 12:18:29.203887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{lookup("config", "DEFAULT_BECOME_USER")}}')))
        ]
    )

# Generated at 2022-06-17 12:18:41.163734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1524098983.13-137588581457861']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and

# Generated at 2022-06-17 12:18:49.616963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.loader import LookupModule
    from ansible.errors import AnsibleLookupError
    from ansible.module_utils._text import to_native

    # Test case 1:
    # Test case to check if the exception is raised when plugin_type and plugin_name are not provided
    # Expected result:
    # AnsibleOptionsError should be raised
    try:
        lookup_module = LookupModule()
        lookup_module.run(['remote_user'])
    except AnsibleOptionsError as e:
        assert to_native(e) == 'Both plugin_type and plugin_name are required, cannot use one without the other'

    # Test case 2:
    # Test case to check if the exception is raised when plugin_type and plugin_name are not provided
   

# Generated at 2022-06-17 12:19:27.288312
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:19:36.275575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:19:46.503892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['accelerate_port']) == [None]
    assert lookup_module.run(['accelerate_port'], on_missing='warn') == []
    assert lookup_module.run(['accelerate_port'], on_missing='skip') == []
    assert lookup_module.run(['accelerate_port'], on_missing='error') == []
    assert lookup_module.run(['accelerate_port'], on_missing='error') == []
    assert lookup_module.run(['accelerate_port'], on_missing='error') == []

# Generated at 2022-06-17 12:19:51.248106
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:19:57.888099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1524058983.94-140791458471423']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule

# Generated at 2022-06-17 12:20:08.662905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(terms=['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512077703.82-244577404077961']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_module.run(terms=['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type

# Generated at 2022-06-17 12:20:21.000362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:20:31.010379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a variable
    variable = {}

    # Create a term
    term = 'DEFAULT_BECOME_USER'

    # Create a list of terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']

    # Create a plugin_type
    plugin_type = 'connection'

    # Create a plugin_name
    plugin_name = 'ssh'

    # Create a on_missing
    on_missing = 'error'

    # Create a variables
    variables = {}

    # Create a kwargs
    kwargs = {}

    # Set options
    lookup_module.set_options(var_options=variables, direct=kwargs)

    # Test run method

# Generated at 2022-06-17 12:20:42.075318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    terms = ['accelerate_port', 'accelerate_timeout', 'accelerate_connect_timeout']
    result = lookup_module.run(terms)
    assert result == [None, 30, 10]

    # Test 2
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    terms = ['accelerate_port', 'accelerate_timeout', 'accelerate_connect_timeout', 'accelerate_multi_key']
    result = lookup_module.run(terms)


# Generated at 2022-06-17 12:20:46.500237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:21:49.143874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{}) == ['root']

    # Test for missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    assert lookup_module.run(terms=['UNKNOWN'], variables=None, **{}) == []

    # Test for missing setting with on_missing=warn
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'warn'})

# Generated at 2022-06-17 12:21:56.972305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    try:
        lookup_module.run(['remote_user'])
    except AnsibleOptionsError as e:
        assert 'plugin_type' in str(e)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    try:
        lookup_module.run(['remote_user'])
    except AnsibleLookupError as e:
        assert 'Unable to load connection plugin' in str(e)

    # Test

# Generated at 2022-06-17 12:22:08.437157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS']) == ['root', 'sudo', None]
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS', 'DEFAULT_BECOME_ALL']) == ['root', 'sudo', None, False]

# Generated at 2022-06-17 12:22:18.108534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleLookupError, AnsibleOptionsError
    from ansible.plugins.loader import lookup_loader

    lookup_plugin = lookup_loader.get('config')
    assert lookup_plugin is not None

    # Test invalid setting identifier
    terms = [1]
    variables = {}
    kwargs = {}
    try:
        lookup_plugin.run(terms, variables, **kwargs)
    except AnsibleOptionsError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test invalid on_missing value
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {'on_missing': 'invalid'}

# Generated at 2022-06-17 12:22:26.710712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'], on_missing='warn') == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'], on_missing='skip') == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'], on_missing='error') == [C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-17 12:22:34.862130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test with plugin_type and plugin_name
    terms = ['remote_tmp']
    variables = {}
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    result = lookup.run(terms, variables, **kwargs)
    assert result[0] == '$HOME/.ansible/tmp'
    # test with on_missing=warn
    terms = ['UNKNOWN']
    variables = {}
    kwargs = {'on_missing': 'warn'}
    result = lookup.run(terms, variables, **kwargs)
    assert result == []
    # test with on_missing=skip
    terms = ['UNKNOWN']
    variables = {}
    kwargs = {'on_missing': 'skip'}

# Generated at 2022-06-17 12:22:39.847072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a variable
    variable = {'ansible_connection': 'local'}

    # Create a term
    term = 'ansible_connection'

    # Create a kwargs
    kwargs = {'plugin_type': 'connection', 'plugin_name': 'local'}

    # Test the run method
    result = lookup_module.run(terms=term, variables=variable, **kwargs)

    # Assert the result
    assert result == ['local']

# Generated at 2022-06-17 12:22:49.821572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={'ansible_connection': 'local'})
    result = lookup.run(['DEFAULT_ROLES_PATH'], variables={'ansible_connection': 'local'})
    assert result == ['/etc/ansible/roles:/usr/share/ansible/roles']
    result = lookup.run(['DEFAULT_ROLES_PATH'], variables={'ansible_connection': 'local'}, on_missing='warn')
    assert result == ['/etc/ansible/roles:/usr/share/ansible/roles']
    result = lookup.run(['DEFAULT_ROLES_PATH'], variables={'ansible_connection': 'local'}, on_missing='skip')

# Generated at 2022-06-17 12:22:58.517527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.lookup = LookupModule()

        def tearDown(self):
            pass

        def test_run_with_plugin_type_and_plugin_name(self):
            terms = ['remote_user', 'port']
            variables = {'ansible_connection': 'ssh'}
            kwargs = {'plugin_type': 'connection', 'plugin_name': 'ssh'}
            result = self.lookup.run(terms, variables, **kwargs)
            self.assertEqual(result, ['root', 22])


# Generated at 2022-06-17 12:23:04.801531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dict for the options
    options = dict()

    # Create a dict for the variables
    variables = dict()

    # Create a list of terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']

    # Run the run method
    result = lookup_module.run(terms, variables, **options)

    # Check the result
    assert result == ['root', ['/etc/ansible/roles', '/usr/share/ansible/roles']]

# Generated at 2022-06-17 12:24:58.170642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with missing plugin
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'UNKNOWN'})
    try:
        lookup_module.run(['remote_tmp'])
    except AnsibleLookupError as e:
        assert 'Unable to load shell plugin "UNKNOWN"' in to_native(e)

    # Test with missing setting in plugin

# Generated at 2022-06-17 12:25:06.690873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:25:17.192160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1501484836.29-254727989829079']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = Lookup

# Generated at 2022-06-17 12:25:25.154806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={'DEFAULT_BECOME_USER': 'test'}) == ['test']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={'DEFAULT_BECOME_USER': 'test'}, on_missing='warn') == ['test']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={'DEFAULT_BECOME_USER': 'test'}, on_missing='skip') == ['test']

# Generated at 2022-06-17 12:25:39.208129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    l = LookupModule()
    l.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert l.run(['remote_tmp']) == ['/tmp/ansible-tmp-1512497980.81-140795907823456']

    # Test with plugin_type and plugin_name
    l = LookupModule()
    l.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert l.run(['remote_tmp']) == ['/tmp/ansible-tmp-1512497980.81-140795907823456']

    # Test with plugin_type and plugin_name