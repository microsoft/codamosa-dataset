

# Generated at 2022-06-17 12:15:40.040289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')

# Generated at 2022-06-17 12:15:44.811035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with an invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    terms = ['DEFAULT_BECOME_USER', 'INVALID_TERM']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with a valid term and a valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)

# Generated at 2022-06-17 12:15:54.747680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.set_options(var_options={}, direct={'on_missing': 'error'})
    lookup_module.set_options(var_options={}, direct={'on_missing': 'warn'})
    lookup_module.set_options(var_options={}, direct={'on_missing': 'skip'})
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection'})
    lookup_module.set_options(var_options={}, direct={'plugin_name': 'ssh'})
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    lookup_module.set_

# Generated at 2022-06-17 12:16:02.356122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    lookup_module.run(['DEFAULT_BECOME_USER'])

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    lookup_module.run(['remote_user', 'port'])

# Generated at 2022-06-17 12:16:07.068605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for method run
    # Returns:   None
    # Raises:    AnsibleOptionsError, AnsibleLookupError
    # Example:
    #           lookup_instance = LookupModule()
    #           lookup_instance.run(terms, variables=None, **kwargs)
    pass

# Generated at 2022-06-17 12:16:16.470518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1527078982.8-247544281267984']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])

# Generated at 2022-06-17 12:16:25.854216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:16:39.436048
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:16:49.516152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_plugin.run(['accelerate_port']) == [None]
    assert lookup_plugin.run(['accelerate_port'], on_missing='warn') == []
    assert lookup_plugin.run(['accelerate_port'], on_missing='skip') == []
    assert lookup_plugin.run(['accelerate_port'], on_missing='error') == []
    assert lookup_plugin.run(['accelerate_port'], on_missing='error') == []
    assert lookup_plugin.run(['accelerate_port'], on_missing='error') == []

# Generated at 2022-06-17 12:16:52.540420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

# Generated at 2022-06-17 12:17:06.786432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a terms list
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']

    # Create a variables dictionary
    variables = {}

    # Create a kwargs dictionary
    kwargs = {}

    # Call the run method of LookupModule
    result = lookup_module.run(terms, variables, **kwargs)

    # Check the result
    assert result == [u'root', [u'/etc/ansible/roles']]

# Generated at 2022-06-17 12:17:14.550006
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:17:22.020480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp/ansible-tmp-1533355972.5-149813342659098']

    # test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_plugin.run(['remote_user', 'port']) == ['root', 22]

    # test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:17:32.508470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid_plugin_name'})

# Generated at 2022-06-17 12:17:42.827260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1523992733.72-181225775034962']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])

# Generated at 2022-06-17 12:17:46.418951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={'test_var': 'test_value'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup.run(['DEFAULT_REMOTE_TMP', 'test_var'])
    assert result == ['/tmp/ansible', 'test_value']

# Generated at 2022-06-17 12:17:52.609382
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:18:00.688080
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:18:11.126904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1524098984.9-282360585938894']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule

# Generated at 2022-06-17 12:18:20.420989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    try:
        lookup_module.run(terms=['UNKNOWN'], variables=None)
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test for missing plugin
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'UNKNOWN'})

# Generated at 2022-06-17 12:18:46.150987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    variables = {}
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    lm = LookupModule()
    lm.set_options(var_options=variables, direct=kwargs)
    result = lm.run(terms, variables, **kwargs)
    assert result == ['/tmp/ansible-tmp-1512078115.67-135907913553929']

    # Test with plugin_type and plugin_name
    terms = ['remote_user']
    variables = {}
    kwargs = {'plugin_type': 'connection', 'plugin_name': 'ssh'}
    lm = LookupModule()

# Generated at 2022-06-17 12:18:54.756113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'])
    lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={}, on_missing='skip')

# Generated at 2022-06-17 12:19:05.305704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_name and plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_name': 'ssh', 'plugin_type': 'connection'})
    terms = ['remote_user', 'port']
    result = lookup_module.run(terms)
    assert result == ['root', 22]

    # Test with plugin_name and plugin_type and on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_name': 'ssh', 'plugin_type': 'connection', 'on_missing': 'warn'})
    terms = ['remote_user', 'port', 'unknown']
    result = lookup_module.run(terms)
    assert result == ['root', 22]

    #

# Generated at 2022-06-17 12:19:16.891139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.six.moves import unittest

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.lookup = LookupModule()

        def tearDown(self):
            pass


# Generated at 2022-06-17 12:19:27.265002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Test case with plugin_type and plugin_name
    # Expected result:
    #   - Return value of the key(s) in the config
    #   - Return type: raw
    #   - Return value: ['/usr/bin/python']
    terms = ['executable']
    variables = None
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['/usr/bin/python']
    assert isinstance(result, list)

    # Test case 2:
    # Test case with plugin_type and plugin_name
    # Expected result:
    #   - Return value of the key(s) in the config


# Generated at 2022-06-17 12:19:36.276649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Test case with valid input
    # Expected result:
    # The result should be a list of values of the given keys
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = lookup_module.run(terms, variables=None, **{})
    assert result == ['root', ['/etc/ansible/roles']]

    # Test case 2:
    # Test case with invalid input
    # Expected result:
    # The result should be a list of values of the given keys
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)

# Generated at 2022-06-17 12:19:46.499179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})

    # Test with invalid value of on_missing
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='invalid')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)

    # Test with invalid value of plugin_type

# Generated at 2022-06-17 12:19:50.828215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Test case with valid input
    # Expected result:
    # Should return the value of the key
    lookup_obj = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_obj.run(terms, variables=None, **{})
    assert result == ['root']

    # Test case 2:
    # Test case with invalid input
    # Expected result:
    # Should raise AnsibleOptionsError
    lookup_obj = LookupModule()
    terms = ['DEFAULT_BECOME_USER']

# Generated at 2022-06-17 12:19:57.662091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with invalid on_missing
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='invalid')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)
    # Test with invalid term
    try:
        lookup_module.run(terms=['invalid'], variables=None, on_missing='error')
    except AnsibleOptionsError as e:
        assert 'Invalid setting identifier, "invalid" is not a string, its a <class \'str\'>' in to_native(e)
    # Test with invalid plugin_type

# Generated at 2022-06-17 12:20:08.660590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with on_missing option set to error
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {'on_missing': 'error'}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root']

    # Test with on_missing option set to warn
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    variables = {}
    kwargs = {'on_missing': 'warn'}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root']

    # Test with on_missing option set to skip
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:20:43.754565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with global config
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    result = lookup_module.run(['DEFAULT_BECOME_USER'])
    assert result == ['root']

    # Test with plugin config
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['executable'])
    assert result == ['/bin/sh']

    # Test with missing config
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})

# Generated at 2022-06-17 12:20:50.634949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result[0] == '$HOME/.ansible/tmp'

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result[0] == '$HOME/.ansible/tmp'

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:21:01.993868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    terms = ['remote_tmp']
    result = lookup_module.run(terms)
    assert result == ['/tmp/ansible-tmp-1512078983.55-140987924386090']

    # Test with an invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    terms = ['remote_tmp_invalid']

# Generated at 2022-06-17 12:21:13.554135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'], variables=None)
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'], variables=None)
    assert result == ['root', 22]

    # Test with global config
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:21:20.135118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_plugin.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:21:31.786416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp', 'executable'])
    assert result == [u'$HOME/.ansible/tmp', u'/bin/sh']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
   

# Generated at 2022-06-17 12:21:43.284740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase

    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_loader.add_directory('./lookup_plugins')
    lookup_loader.add_lookup_class(TestLookupModule)

    loader = DataLoader()
    variable_manager = Variable

# Generated at 2022-06-17 12:21:46.169710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={'test_var': 'test_value'})
    result = lookup.run(['test_var'])
    assert result == ['test_value']

# Generated at 2022-06-17 12:21:56.752520
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:22:04.184339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Test case with invalid plugin_type
    # Expected result:
    # AnsibleOptionsError exception
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid_plugin_type'})
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    except AnsibleOptionsError as e:
        assert 'plugin_type' in to_native(e)

    # Test case 2:
    # Test case with invalid plugin_name
    # Expected result:
    # AnsibleOptionsError exception
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:23:10.659463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module

    # mock the display class
    class Display(object):
        def __init__(self):
            self.warning = StringIO()

    # mock the constants class
    class Constants(object):
        def __init__(self):
            self.DEFAULT_ROLES_PATH = 'roles_path'
            self.RETRY_FILES_SAVE_PATH = 'retry_files_save_path'

# Generated at 2022-06-17 12:23:20.613923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object for the lookup module
    lookup_module = LookupModule()

    # Create a mock object for the display
    display = MockDisplay()

    # Set the display object to the lookup module
    lookup_module._display = display

    # Create a mock object for the variables
    variables = MockVariables()

    # Set the variables object to the lookup module
    lookup_module._templar = variables

    # Create a mock object for the config
    config = MockConfig()

    # Set the config object to the lookup module
    lookup_module._config = config

    # Create a mock object for the loader
    loader = MockLoader()

    # Set the loader object to the lookup module
    lookup_module._loader = loader

    # Create a mock object for the plugin loader
    plugin_loader = MockPluginLoader()

    # Set the plugin loader

# Generated at 2022-06-17 12:23:26.317180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in to_native(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid_plugin_name'})

# Generated at 2022-06-17 12:23:36.834180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    kwargs = {'on_missing': 'error', 'plugin_type': None, 'plugin_name': None}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct=kwargs)

    # Act
    result = lookup_module.run(terms, variables, **kwargs)

    # Assert
    assert result == ['root']

# Generated at 2022-06-17 12:23:49.461714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lm = LookupModule()

    # Create a dict for the options
    options = dict()

    # Create a dict for the variables
    variables = dict()

    # Create a list for the terms
    terms = list()

    # Create a dict for the kwargs
    kwargs = dict()

    # Set the options
    options['on_missing'] = 'error'
    options['plugin_type'] = 'connection'
    options['plugin_name'] = 'local'

    # Set the terms
    terms.append('DEFAULT_CONNECTION')

    # Set the kwargs
    kwargs['var_options'] = variables
    kwargs['direct'] = options

    # Run the run method
    result = lm.run(terms, variables, **kwargs)

    #

# Generated at 2022-06-17 12:23:59.881422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    # Test with valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1512056337.18-243445756989766']
    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'invalid'})

# Generated at 2022-06-17 12:24:12.089099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER'], on_missing='warn') == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER'], on_missing='skip') == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER'], on_missing='error') == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER'], on_missing='invalid') == []
    assert lookup.run(['DEFAULT_BECOME_USER'], on_missing='invalid') == []
    assert lookup.run(['DEFAULT_BECOME_USER'], on_missing='invalid') == []

# Generated at 2022-06-17 12:24:22.273332
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:24:36.559394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:24:43.733769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})

    # Test with invalid on_missing value
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='invalid')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)

    # Test with invalid plugin_type value