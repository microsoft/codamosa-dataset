

# Generated at 2022-06-17 12:15:40.669094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_plugin.run(['remote_user']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_plugin.run(['remote_user', 'port']) == ['root', None]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup

# Generated at 2022-06-17 12:15:52.154269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user'])
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', None]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:15:55.218779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.get_option = lambda x: 'error'
    lookup_module._display = lambda x: None
    lookup_module.run(['DEFAULT_BECOME_USER'])

# Generated at 2022-06-17 12:16:06.990309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    # Test case with missing setting
    # Expected result: AnsibleLookupError
    # Actual result: AnsibleLookupError
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['UNKNOWN'], variables=None, on_missing='error')
    except AnsibleLookupError:
        pass
    else:
        assert False, "AnsibleLookupError not raised"

    # Test case 2
    # Test case with missing setting
    # Expected result: AnsibleLookupError
    # Actual result: AnsibleLookupError
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['UNKNOWN'], variables=None, on_missing='warn')
    except AnsibleLookupError:
        pass

# Generated at 2022-06-17 12:16:11.528575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    # Test with plugin_type and plugin_name
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_obj.run(['remote_user']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_obj.run(['remote_user', 'port']) == ['root', None]

    # Test with plugin_type and plugin_name
    lookup_obj = LookupModule()

# Generated at 2022-06-17 12:16:19.224758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'})
    assert lookup_module.run(['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']) == [C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER]
    assert lookup_module.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'], on_missing='warn') == [C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER]

# Generated at 2022-06-17 12:16:29.804912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512095201.7-184501078796869']

    # Test with plugin_type and plugin_name and on_missing
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'warn'})
    result = lookup_plugin.run(['remote_tmp'])

# Generated at 2022-06-17 12:16:40.648851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'shell'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(terms=['remote_tmp'])
    assert 'plugin_type must be one of' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'invalid_plugin_name'})

# Generated at 2022-06-17 12:16:47.077490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512597032.79-140144189898983']

# Generated at 2022-06-17 12:16:56.999496
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:17:16.971840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iter

# Generated at 2022-06-17 12:17:26.965816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user']) == ['root']
    assert lookup_module.run(['remote_user', 'port']) == ['root', None]
    assert lookup_module.run(['remote_user', 'port'], plugin_type='connection', plugin_name='local') == ['root', None]
    assert lookup_module.run(['remote_user', 'port'], plugin_type='connection', plugin_name='local', on_missing='skip') == ['root', None]

# Generated at 2022-06-17 12:17:33.353180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:17:43.481115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:17:55.077222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:18:05.688748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'invalid_plugin_name'})
    result = lookup_module.run(['remote_tmp'])
    assert result == []

    # Test with invalid plugin_type and valid plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:18:13.510715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
        assert False, 'Should have thrown exception'
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with missing setting, on_missing=warn
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'warn'})
    lookup_module.run(['UNKNOWN'])

    # Test with missing setting, on_missing=skip
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'skip'})

# Generated at 2022-06-17 12:18:16.851729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})

# Generated at 2022-06-17 12:18:26.981881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error', plugin_type='shell', plugin_name='sh')

# Generated at 2022-06-17 12:18:40.327613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=dict())
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **dict())
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not None' in str(e)

    # Test with invalid missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=dict(on_missing='invalid'))

# Generated at 2022-06-17 12:18:56.952382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:19:07.284431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    assert lookup.run(terms=['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_ROLES_PATH']) == ['root', 'sudo', ['/etc/ansible/roles', '/usr/share/ansible/roles']]

# Generated at 2022-06-17 12:19:17.760904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp/ansible-tmp-1512550155.29-240793924340103']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_plugin.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:19:24.406699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})


# Generated at 2022-06-17 12:19:29.493630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'invalid_plugin_name'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['invalid_term'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid_plugin_name'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['invalid_term'])

    # Test with invalid on_missing
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:19:40.901641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['remote_user'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(['remote_user'])

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'invalid'})
   

# Generated at 2022-06-17 12:19:47.591223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = lookup_module.run(terms)
    assert result[0] == 'root'
    assert result[1] == ['/etc/ansible/roles', '~/.ansible/roles']

# Generated at 2022-06-17 12:19:57.327433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error') == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='warn') == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='skip') == [C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-17 12:20:02.614717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:20:11.061241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['remote_user'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['remote_user'])

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'invalid'})

# Generated at 2022-06-17 12:20:48.649149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with a invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    terms = ['DEFAULT_BECOME_USER_INVALID']
    try:
        lookup_module.run(terms)
    except AnsibleLookupError as e:
        assert 'Unable to find setting DEFAULT_BECOME_USER_INVALID' in to_native(e)

    # Test

# Generated at 2022-06-17 12:21:00.133458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_module.run

# Generated at 2022-06-17 12:21:09.161935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name and on_missing
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'warn'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name and on_missing

# Generated at 2022-06-17 12:21:17.389090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module

# Generated at 2022-06-17 12:21:23.882869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh'
    result = lookup_plugin.run(terms, plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == ['/tmp/ansible-tmp-1528122660.45-247776120983514']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh'
    result = lookup_plugin.run(terms, plugin_type=plugin_type, plugin_name=plugin_name)

# Generated at 2022-06-17 12:21:28.136270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:21:40.937249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1516183617.44-140791388590592']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1516183617.44-140791388590592']

    # Test

# Generated at 2022-06-17 12:21:49.418348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(terms=['UNKNOWN'])
        assert False, 'AnsibleLookupError should be raised'
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in str(e)

    # Test for missing setting with on_missing=skip
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'skip'})
    assert lookup_module.run(terms=['UNKNOWN']) == []

    # Test for missing setting with on_missing=warn
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:21:57.062286
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:22:08.437524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'plugin_type must be one of' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_module.run(['remote_user'])

# Generated at 2022-06-17 12:23:17.492140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp', 'remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp', u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_plugin = Look

# Generated at 2022-06-17 12:23:27.178328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with an invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    terms = ['DEFAULT_BECOME_USER_INVALID']
    try:
        result = lookup_module.run(terms)
    except AnsibleLookupError as e:
        assert 'Unable to find setting DEFAULT_BECOME_USER_INVALID' in to_native(e)

    # Test with a valid term and on_missing=warn
    lookup_

# Generated at 2022-06-17 12:23:34.973279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:23:43.668546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config')

    lookup = lookup_loader.get('config')

    # test with a valid config
    result = lookup.run(['DEFAULT_BECOME_USER'])
    assert result == ['root']

    # test with an invalid config
    try:
        result = lookup.run(['INVALID_CONFIG'])
        assert False
    except AnsibleLookupError:
        assert True

    # test with a valid config and on_missing=warn
   

# Generated at 2022-06-17 12:23:54.032666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh'
    variables = None
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == ['/tmp/ansible-tmp-1516011749.04-267518155939073']

    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh'
    variables = None
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name)


# Generated at 2022-06-17 12:24:02.158523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid input
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'on_missing': 'error'})
    assert lookup_plugin.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{}) == ['root']

    # Test with invalid input
    lookup_plugin.set_options(var_options=None, direct={'on_missing': 'error'})
    assert lookup_plugin.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{'plugin_type': 'become'}) == []

    # Test with invalid input
    lookup_plugin.set_options(var_options=None, direct={'on_missing': 'error'})

# Generated at 2022-06-17 12:24:12.274412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1:
    #   - terms: ['DEFAULT_BECOME_USER']
    #   - variables: None
    #   - kwargs: None
    #   - expected: [u'root']
    #   - expected_type: list
    #   - expected_len: 1
    #   - expected_item_type: unicode
    #   - expected_item_value: u'root'
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    kwargs = None
    expected = [u'root']
    expected_type = list
    expected_len = 1
    expected_item_type = unicode
    expected_item_value = u'root'
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-17 12:24:22.419084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for method run of class LookupModule
    # This method is used to lookup current Ansible configuration values.
    #
    # Inputs:
    #    terms    - The key(s) to look up
    #    variables - The variables to use for looking up the terms
    #    kwargs   - Other arguments required for the lookup
    #
    # Outputs:
    #    ret      - The value(s) of the key(s) in the config

    # Create an instance of LookupModule class
    lookup_plugin = LookupModule()

    # Create an instance of AnsibleOptions class
    ansible_options = AnsibleOptions()

    # Create an instance of AnsibleVariableManager class
    ansible_variable_manager = AnsibleVariableManager()

    # Create an instance of AnsibleLoader class
    ansible_loader = Ansible

# Generated at 2022-06-17 12:24:36.827235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:24:43.907938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')